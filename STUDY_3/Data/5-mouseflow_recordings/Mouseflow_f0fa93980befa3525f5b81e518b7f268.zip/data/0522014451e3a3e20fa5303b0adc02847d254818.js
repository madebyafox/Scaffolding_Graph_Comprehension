var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0522014451e3a3e20fa5303b0adc02847d254818"] = {
  "startTime": "2018-05-22T23:12:00.8247479Z",
  "websitePageUrl": "/16",
  "visitTime": 68896,
  "engagementTime": 68355,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "f0fa93980befa3525f5b81e518b7f268",
    "created": "2018-05-22T23:12:00.8247479+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=2KONX",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "1c14903feafce13a82bbe132b0cc9553",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/f0fa93980befa3525f5b81e518b7f268/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 248,
      "e": 248,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 248,
      "e": 248,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 531,
      "y": 629
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 48775,
      "y": 34401,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1024,
      "e": 1024,
      "ty": 6,
      "x": 524,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 520,
      "y": 581
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 514,
      "y": 564
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 46864,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1302,
      "e": 1302,
      "ty": 2,
      "x": 514,
      "y": 563
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 515,
      "y": 563
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 46976,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1902,
      "e": 1902,
      "ty": 2,
      "x": 515,
      "y": 557
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 513,
      "y": 556
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 46752,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 514,
      "y": 551
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 520,
      "y": 547
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 47538,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2602,
      "e": 2602,
      "ty": 2,
      "x": 524,
      "y": 546
    },
    {
      "t": 2752,
      "e": 2752,
      "ty": 41,
      "x": 47988,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2788,
      "e": 2788,
      "ty": 3,
      "x": 524,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2790,
      "e": 2790,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2882,
      "e": 2882,
      "ty": 4,
      "x": 47988,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2882,
      "e": 2882,
      "ty": 5,
      "x": 524,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 568,
      "y": 601
    },
    {
      "t": 3110,
      "e": 3110,
      "ty": 7,
      "x": 610,
      "y": 648,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 769,
      "y": 776
    },
    {
      "t": 3252,
      "e": 3252,
      "ty": 41,
      "x": 5332,
      "y": 45654,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 773,
      "y": 781
    },
    {
      "t": 5337,
      "e": 5337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 5338,
      "e": 5338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5422,
      "e": 5422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 5487,
      "e": 5487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 5487,
      "e": 5487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5583,
      "e": 5583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yo"
    },
    {
      "t": 5591,
      "e": 5591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 5591,
      "e": 5591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5719,
      "e": 5719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you"
    },
    {
      "t": 5720,
      "e": 5720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 5720,
      "e": 5720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5798,
      "e": 5798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you "
    },
    {
      "t": 5902,
      "e": 5902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 5902,
      "e": 5902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5982,
      "e": 5982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 6103,
      "e": 6103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 6103,
      "e": 6103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6151,
      "e": 6151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 6231,
      "e": 6231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 6232,
      "e": 6232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6262,
      "e": 6262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 6359,
      "e": 6359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 6359,
      "e": 6359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6447,
      "e": 6447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 6511,
      "e": 6511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 6512,
      "e": 6512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6575,
      "e": 6575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 6591,
      "e": 6591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 6591,
      "e": 6591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6679,
      "e": 6679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 6759,
      "e": 6759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 6760,
      "e": 6760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6823,
      "e": 6823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 6864,
      "e": 6864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 6864,
      "e": 6864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6943,
      "e": 6943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 7048,
      "e": 7048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 7048,
      "e": 7048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7102,
      "e": 7102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 7167,
      "e": 7167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 7167,
      "e": 7167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7222,
      "e": 7222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 7255,
      "e": 7255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 7256,
      "e": 7256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7335,
      "e": 7335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 7368,
      "e": 7368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7368,
      "e": 7368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7455,
      "e": 7455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 7639,
      "e": 7639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 7640,
      "e": 7640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 7815,
      "e": 7815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7816,
      "e": 7816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7903,
      "e": 7903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8031,
      "e": 8031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 8032,
      "e": 8032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8119,
      "e": 8119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 8312,
      "e": 8312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 8312,
      "e": 8312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8382,
      "e": 8382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 8486,
      "e": 8486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 8487,
      "e": 8487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8568,
      "e": 8568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 8591,
      "e": 8591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 8592,
      "e": 8592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8695,
      "e": 8695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 8702,
      "e": 8702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8702,
      "e": 8702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8791,
      "e": 8791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8839,
      "e": 8839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 8839,
      "e": 8839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8927,
      "e": 8927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 8958,
      "e": 8958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 8959,
      "e": 8959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9047,
      "e": 9047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 9071,
      "e": 9071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 9072,
      "e": 9072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9143,
      "e": 9143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 9190,
      "e": 9190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9191,
      "e": 9191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9271,
      "e": 9271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9336,
      "e": 9336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9336,
      "e": 9336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9431,
      "e": 9431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 9455,
      "e": 9455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 9455,
      "e": 9455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9527,
      "e": 9527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 9639,
      "e": 9639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 9640,
      "e": 9640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9751,
      "e": 9751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 9767,
      "e": 9767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9768,
      "e": 9768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9871,
      "e": 9871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10312,
      "e": 10312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 10313,
      "e": 10313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10375,
      "e": 10375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 10520,
      "e": 10520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10520,
      "e": 10520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10623,
      "e": 10623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 10655,
      "e": 10655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 10655,
      "e": 10655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10752,
      "e": 10752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 10863,
      "e": 10863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10864,
      "e": 10864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10966,
      "e": 10966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12616,
      "e": 12616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12616,
      "e": 12616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12695,
      "e": 12695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 12803,
      "e": 12803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you l"
    },
    {
      "t": 12848,
      "e": 12848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12848,
      "e": 12848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12911,
      "e": 12911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 13544,
      "e": 13544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13544,
      "e": 13544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13583,
      "e": 13583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 13719,
      "e": 13719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 13720,
      "e": 13720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13792,
      "e": 13792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 13872,
      "e": 13872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13874,
      "e": 13874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13910,
      "e": 13910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13910,
      "e": 13910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13959,
      "e": 13959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 14015,
      "e": 14015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14111,
      "e": 14111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14112,
      "e": 14112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14174,
      "e": 14174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14247,
      "e": 14247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14247,
      "e": 14247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14302,
      "e": 14302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14351,
      "e": 14351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14352,
      "e": 14352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14406,
      "e": 14406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14847,
      "e": 14847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14886,
      "e": 14886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look ath"
    },
    {
      "t": 15003,
      "e": 15003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look ath"
    },
    {
      "t": 15006,
      "e": 15006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15031,
      "e": 15031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at"
    },
    {
      "t": 15204,
      "e": 15204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at"
    },
    {
      "t": 15255,
      "e": 15255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15257,
      "e": 15257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15302,
      "e": 15302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15383,
      "e": 15383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15383,
      "e": 15383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15439,
      "e": 15439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15454,
      "e": 15454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15456,
      "e": 15456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15520,
      "e": 15520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 15583,
      "e": 15583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15584,
      "e": 15584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15638,
      "e": 15638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15638,
      "e": 15638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15655,
      "e": 15655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 15711,
      "e": 15711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15815,
      "e": 15815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 15815,
      "e": 15815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15870,
      "e": 15870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 15983,
      "e": 15983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15983,
      "e": 15983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16071,
      "e": 16071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 16112,
      "e": 16112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16112,
      "e": 16112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16175,
      "e": 16175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16319,
      "e": 16319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16320,
      "e": 16320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16358,
      "e": 16358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 16422,
      "e": 16422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16423,
      "e": 16423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16494,
      "e": 16494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16560,
      "e": 16560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16561,
      "e": 16561,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16647,
      "e": 16647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16943,
      "e": 16943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16999,
      "e": 16999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the point"
    },
    {
      "t": 17087,
      "e": 17087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17088,
      "e": 17088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17151,
      "e": 17151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17151,
      "e": 17151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17167,
      "e": 17167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 17222,
      "e": 17222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17271,
      "e": 17271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17272,
      "e": 17272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17343,
      "e": 17343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17375,
      "e": 17375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17376,
      "e": 17376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17431,
      "e": 17431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 17464,
      "e": 17464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17464,
      "e": 17464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17535,
      "e": 17535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17606,
      "e": 17606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17608,
      "e": 17608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17672,
      "e": 17609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17703,
      "e": 17640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17703,
      "e": 17640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17774,
      "e": 17711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17814,
      "e": 17751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17814,
      "e": 17751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17879,
      "e": 17816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 18004,
      "e": 17941,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that a"
    },
    {
      "t": 18079,
      "e": 18016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18135,
      "e": 18072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that "
    },
    {
      "t": 18182,
      "e": 18119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 18183,
      "e": 18120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18271,
      "e": 18208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 18311,
      "e": 18248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18311,
      "e": 18248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18382,
      "e": 18319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18438,
      "e": 18375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18439,
      "e": 18376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18502,
      "e": 18439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 18599,
      "e": 18536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18600,
      "e": 18537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18638,
      "e": 18575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 18998,
      "e": 18935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18999,
      "e": 18936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19054,
      "e": 18991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19191,
      "e": 19128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19192,
      "e": 19129,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19302,
      "e": 19239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 19310,
      "e": 19247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 19310,
      "e": 19247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19383,
      "e": 19320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 19455,
      "e": 19392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19456,
      "e": 19393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19543,
      "e": 19480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 19623,
      "e": 19560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19623,
      "e": 19560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19711,
      "e": 19648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 19776,
      "e": 19713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 19776,
      "e": 19713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19856,
      "e": 19793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 19879,
      "e": 19816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19879,
      "e": 19816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19943,
      "e": 19880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20039,
      "e": 19976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20039,
      "e": 19976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20111,
      "e": 20048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20134,
      "e": 20071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20134,
      "e": 20071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20199,
      "e": 20136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 20278,
      "e": 20215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20279,
      "e": 20216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20335,
      "e": 20272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20359,
      "e": 20296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20359,
      "e": 20296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20447,
      "e": 20384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20471,
      "e": 20408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20471,
      "e": 20408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20527,
      "e": 20464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 20606,
      "e": 20543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20608,
      "e": 20545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20710,
      "e": 20647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 20718,
      "e": 20655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20718,
      "e": 20655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20782,
      "e": 20719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20974,
      "e": 20911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 20974,
      "e": 20911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21071,
      "e": 21008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 21631,
      "e": 21568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 21632,
      "e": 21569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21726,
      "e": 21663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 22015,
      "e": 21952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 22016,
      "e": 21953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22071,
      "e": 22008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 22204,
      "e": 22141,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12p"
    },
    {
      "t": 22263,
      "e": 22200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 22264,
      "e": 22201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22326,
      "e": 22263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 22383,
      "e": 22320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22383,
      "e": 22320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22455,
      "e": 22392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23095,
      "e": 23032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23095,
      "e": 23032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23183,
      "e": 23120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23352,
      "e": 23289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23352,
      "e": 23289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23399,
      "e": 23336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23439,
      "e": 23376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 23439,
      "e": 23376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23526,
      "e": 23463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 23567,
      "e": 23504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 23568,
      "e": 23505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23646,
      "e": 23583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 23726,
      "e": 23663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23727,
      "e": 23664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23799,
      "e": 23736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27128,
      "e": 27065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 27128,
      "e": 27065,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27222,
      "e": 27159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 27279,
      "e": 27216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 27279,
      "e": 27216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27343,
      "e": 27280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 27439,
      "e": 27376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27440,
      "e": 27377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27510,
      "e": 27377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27679,
      "e": 27546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27679,
      "e": 27546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27791,
      "e": 27658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 27950,
      "e": 27817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27951,
      "e": 27818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28031,
      "e": 27898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28103,
      "e": 27970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28103,
      "e": 27970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28151,
      "e": 28018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28312,
      "e": 28179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 28312,
      "e": 28179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28374,
      "e": 28241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 28454,
      "e": 28321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28454,
      "e": 28321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28511,
      "e": 28378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 28631,
      "e": 28498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28632,
      "e": 28499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28710,
      "e": 28577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 28783,
      "e": 28650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 28783,
      "e": 28650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28855,
      "e": 28722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 28887,
      "e": 28754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28888,
      "e": 28755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28966,
      "e": 28833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29095,
      "e": 28962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 29095,
      "e": 28962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29182,
      "e": 29049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29182,
      "e": 29049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29206,
      "e": 29073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 29238,
      "e": 29105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29415,
      "e": 29282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 29416,
      "e": 29283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29486,
      "e": 29353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 29603,
      "e": 29470,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by looking dir"
    },
    {
      "t": 29743,
      "e": 29610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30207,
      "e": 30074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by looking di"
    },
    {
      "t": 30391,
      "e": 30258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30430,
      "e": 30297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by looking d"
    },
    {
      "t": 30542,
      "e": 30409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30582,
      "e": 30449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by looking "
    },
    {
      "t": 30703,
      "e": 30570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30735,
      "e": 30602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by looking"
    },
    {
      "t": 31174,
      "e": 31041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31675,
      "e": 31542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31707,
      "e": 31574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31740,
      "e": 31607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31758,
      "e": 31625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by loo"
    },
    {
      "t": 31894,
      "e": 31761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31936,
      "e": 31762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by lo"
    },
    {
      "t": 32031,
      "e": 31857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32095,
      "e": 31921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by l"
    },
    {
      "t": 32183,
      "e": 32009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32247,
      "e": 32073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by "
    },
    {
      "t": 32391,
      "e": 32217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 32392,
      "e": 32218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32463,
      "e": 32289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 32624,
      "e": 32450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 32625,
      "e": 32451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32766,
      "e": 32592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 32766,
      "e": 32592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32767,
      "e": 32593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32863,
      "e": 32689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32879,
      "e": 32705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32880,
      "e": 32706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32974,
      "e": 32800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 33055,
      "e": 32881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33055,
      "e": 32881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33143,
      "e": 32969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33174,
      "e": 33000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33175,
      "e": 33001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33222,
      "e": 33048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33319,
      "e": 33145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33319,
      "e": 33145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33366,
      "e": 33192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 33366,
      "e": 33192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33390,
      "e": 33216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng"
    },
    {
      "t": 33455,
      "e": 33281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33511,
      "e": 33337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33511,
      "e": 33337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33590,
      "e": 33416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33622,
      "e": 33448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 33623,
      "e": 33449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33711,
      "e": 33537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 33743,
      "e": 33569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33744,
      "e": 33570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33807,
      "e": 33633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33927,
      "e": 33753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33928,
      "e": 33754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33974,
      "e": 33800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34151,
      "e": 33977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34152,
      "e": 33978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34222,
      "e": 34048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34550,
      "e": 34376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34614,
      "e": 34440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by creating an "
    },
    {
      "t": 34783,
      "e": 34609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34783,
      "e": 34609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34847,
      "e": 34673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 35007,
      "e": 34833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 35008,
      "e": 34834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35054,
      "e": 34880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 35086,
      "e": 34912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35087,
      "e": 34913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35191,
      "e": 35017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 35327,
      "e": 35153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 35328,
      "e": 35154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35390,
      "e": 35216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 35407,
      "e": 35233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 35407,
      "e": 35233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35470,
      "e": 35296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 35591,
      "e": 35417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35592,
      "e": 35418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35654,
      "e": 35480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 35670,
      "e": 35496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35670,
      "e": 35496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35774,
      "e": 35600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 35911,
      "e": 35737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 35912,
      "e": 35738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35975,
      "e": 35801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 36047,
      "e": 35873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 36047,
      "e": 35873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36101,
      "e": 35927,
      "ty": 2,
      "x": 774,
      "y": 781
    },
    {
      "t": 36127,
      "e": 35953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 36191,
      "e": 36017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36192,
      "e": 36018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36251,
      "e": 36077,
      "ty": 41,
      "x": 5389,
      "y": 45654,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 36278,
      "e": 36104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36543,
      "e": 36369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36544,
      "e": 36370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36630,
      "e": 36456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36735,
      "e": 36561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36735,
      "e": 36561,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36790,
      "e": 36561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 36918,
      "e": 36689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36918,
      "e": 36689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36982,
      "e": 36753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37199,
      "e": 36970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37263,
      "e": 37034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by creating an imaginary li"
    },
    {
      "t": 37343,
      "e": 37114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37398,
      "e": 37169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by creating an imaginary l"
    },
    {
      "t": 37479,
      "e": 37250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37526,
      "e": 37297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by creating an imaginary "
    },
    {
      "t": 37727,
      "e": 37498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 37728,
      "e": 37499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37798,
      "e": 37569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 37918,
      "e": 37689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37920,
      "e": 37691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38006,
      "e": 37777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38006,
      "e": 37777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38015,
      "e": 37786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 38103,
      "e": 37874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38204,
      "e": 37975,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by creating an imaginary ver"
    },
    {
      "t": 38222,
      "e": 37993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38223,
      "e": 37994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38278,
      "e": 38049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38294,
      "e": 38065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 38294,
      "e": 38065,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38358,
      "e": 38129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 38438,
      "e": 38209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 38439,
      "e": 38210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38510,
      "e": 38281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 38607,
      "e": 38378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38607,
      "e": 38378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38710,
      "e": 38481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 38766,
      "e": 38537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38767,
      "e": 38538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38838,
      "e": 38609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38911,
      "e": 38682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38912,
      "e": 38683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38974,
      "e": 38745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39070,
      "e": 38841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 39071,
      "e": 38842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39127,
      "e": 38898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 39191,
      "e": 38962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39192,
      "e": 38963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39238,
      "e": 39009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 39335,
      "e": 39106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 39335,
      "e": 39106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39366,
      "e": 39137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39367,
      "e": 39138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39391,
      "e": 39162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 39457,
      "e": 39228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40101,
      "e": 39872,
      "ty": 2,
      "x": 719,
      "y": 781
    },
    {
      "t": 40201,
      "e": 39972,
      "ty": 2,
      "x": 484,
      "y": 878
    },
    {
      "t": 40251,
      "e": 40022,
      "ty": 41,
      "x": 42930,
      "y": 49525,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 40302,
      "e": 40073,
      "ty": 2,
      "x": 438,
      "y": 882
    },
    {
      "t": 40374,
      "e": 40145,
      "ty": 6,
      "x": 376,
      "y": 669,
      "ta": "#strategyButton"
    },
    {
      "t": 40390,
      "e": 40161,
      "ty": 7,
      "x": 369,
      "y": 649,
      "ta": "#strategyButton"
    },
    {
      "t": 40401,
      "e": 40172,
      "ty": 2,
      "x": 369,
      "y": 649
    },
    {
      "t": 40501,
      "e": 40272,
      "ty": 2,
      "x": 366,
      "y": 636
    },
    {
      "t": 40501,
      "e": 40272,
      "ty": 41,
      "x": 22191,
      "y": 9348,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 40572,
      "e": 40343,
      "ty": 6,
      "x": 371,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 40601,
      "e": 40372,
      "ty": 2,
      "x": 374,
      "y": 659
    },
    {
      "t": 40701,
      "e": 40472,
      "ty": 2,
      "x": 379,
      "y": 668
    },
    {
      "t": 40752,
      "e": 40523,
      "ty": 41,
      "x": 22066,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 40764,
      "e": 40535,
      "ty": 3,
      "x": 379,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 40766,
      "e": 40536,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "you look at the x axis and the you look at the points that correspond to the 12pm tick by creating an imaginary vertical line"
    },
    {
      "t": 40767,
      "e": 40537,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40767,
      "e": 40537,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 40858,
      "e": 40628,
      "ty": 4,
      "x": 22066,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 40868,
      "e": 40638,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 40870,
      "e": 40640,
      "ty": 5,
      "x": 379,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 40874,
      "e": 40644,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 41101,
      "e": 40871,
      "ty": 2,
      "x": 379,
      "y": 672
    },
    {
      "t": 41252,
      "e": 41022,
      "ty": 41,
      "x": 12776,
      "y": 36783,
      "ta": "html > body"
    },
    {
      "t": 41702,
      "e": 41472,
      "ty": 2,
      "x": 380,
      "y": 671
    },
    {
      "t": 41751,
      "e": 41521,
      "ty": 41,
      "x": 13706,
      "y": 36229,
      "ta": "html > body"
    },
    {
      "t": 41801,
      "e": 41571,
      "ty": 2,
      "x": 540,
      "y": 655
    },
    {
      "t": 41873,
      "e": 41643,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 41874,
      "e": 41644,
      "ty": 6,
      "x": 1015,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41901,
      "e": 41671,
      "ty": 2,
      "x": 1015,
      "y": 655
    },
    {
      "t": 42001,
      "e": 41771,
      "ty": 2,
      "x": 1073,
      "y": 659
    },
    {
      "t": 42001,
      "e": 41771,
      "ty": 41,
      "x": 57316,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42401,
      "e": 42171,
      "ty": 2,
      "x": 1065,
      "y": 650
    },
    {
      "t": 42406,
      "e": 42176,
      "ty": 7,
      "x": 1059,
      "y": 642,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42501,
      "e": 42271,
      "ty": 2,
      "x": 1039,
      "y": 605
    },
    {
      "t": 42501,
      "e": 42271,
      "ty": 41,
      "x": 49962,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 42601,
      "e": 42371,
      "ty": 2,
      "x": 1033,
      "y": 576
    },
    {
      "t": 42624,
      "e": 42394,
      "ty": 6,
      "x": 1033,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42701,
      "e": 42471,
      "ty": 2,
      "x": 1033,
      "y": 563
    },
    {
      "t": 42751,
      "e": 42521,
      "ty": 41,
      "x": 48664,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42780,
      "e": 42550,
      "ty": 3,
      "x": 1033,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42781,
      "e": 42551,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42801,
      "e": 42571,
      "ty": 2,
      "x": 1033,
      "y": 562
    },
    {
      "t": 42850,
      "e": 42620,
      "ty": 4,
      "x": 48664,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42850,
      "e": 42620,
      "ty": 5,
      "x": 1033,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43759,
      "e": 43529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 43760,
      "e": 43530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43854,
      "e": 43624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 43886,
      "e": 43656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 43887,
      "e": 43657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43942,
      "e": 43712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 44294,
      "e": 44064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 44296,
      "e": 44066,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 44296,
      "e": 44066,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44297,
      "e": 44067,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44382,
      "e": 44152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 44719,
      "e": 44489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 44719,
      "e": 44489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44774,
      "e": 44544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 44782,
      "e": 44552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 44782,
      "e": 44552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44886,
      "e": 44656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 44886,
      "e": 44656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44894,
      "e": 44664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "usa"
    },
    {
      "t": 45002,
      "e": 44772,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "usa"
    },
    {
      "t": 45007,
      "e": 44777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "usa"
    },
    {
      "t": 45476,
      "e": 45246,
      "ty": 7,
      "x": 1033,
      "y": 593,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45501,
      "e": 45271,
      "ty": 2,
      "x": 1033,
      "y": 610
    },
    {
      "t": 45502,
      "e": 45272,
      "ty": 41,
      "x": 48664,
      "y": 21064,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 45560,
      "e": 45330,
      "ty": 6,
      "x": 1012,
      "y": 660,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45576,
      "e": 45346,
      "ty": 7,
      "x": 1004,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45594,
      "e": 45364,
      "ty": 6,
      "x": 997,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45601,
      "e": 45371,
      "ty": 2,
      "x": 997,
      "y": 679
    },
    {
      "t": 45702,
      "e": 45472,
      "ty": 2,
      "x": 973,
      "y": 704
    },
    {
      "t": 45709,
      "e": 45479,
      "ty": 7,
      "x": 969,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45751,
      "e": 45521,
      "ty": 41,
      "x": 33060,
      "y": 39055,
      "ta": "html > body"
    },
    {
      "t": 45795,
      "e": 45565,
      "ty": 3,
      "x": 968,
      "y": 713,
      "ta": "html > body"
    },
    {
      "t": 45796,
      "e": 45566,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "usa"
    },
    {
      "t": 45797,
      "e": 45567,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45801,
      "e": 45571,
      "ty": 2,
      "x": 968,
      "y": 713
    },
    {
      "t": 45906,
      "e": 45676,
      "ty": 4,
      "x": 33060,
      "y": 39055,
      "ta": "html > body"
    },
    {
      "t": 45906,
      "e": 45676,
      "ty": 5,
      "x": 968,
      "y": 713,
      "ta": "html > body"
    },
    {
      "t": 46043,
      "e": 45813,
      "ty": 6,
      "x": 970,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46101,
      "e": 45871,
      "ty": 2,
      "x": 971,
      "y": 705
    },
    {
      "t": 46147,
      "e": 45917,
      "ty": 3,
      "x": 971,
      "y": 705,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46148,
      "e": 45918,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46211,
      "e": 45981,
      "ty": 4,
      "x": 38694,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46212,
      "e": 45982,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46214,
      "e": 45984,
      "ty": 5,
      "x": 971,
      "y": 705,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46215,
      "e": 45985,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 46252,
      "e": 46022,
      "ty": 41,
      "x": 33163,
      "y": 38611,
      "ta": "html > body"
    },
    {
      "t": 46602,
      "e": 46372,
      "ty": 2,
      "x": 1199,
      "y": 703
    },
    {
      "t": 46702,
      "e": 46472,
      "ty": 2,
      "x": 1885,
      "y": 732
    },
    {
      "t": 46752,
      "e": 46522,
      "ty": 41,
      "x": 64708,
      "y": 40107,
      "ta": "html > body"
    },
    {
      "t": 46801,
      "e": 46571,
      "ty": 2,
      "x": 1887,
      "y": 732
    },
    {
      "t": 47001,
      "e": 46771,
      "ty": 2,
      "x": 1888,
      "y": 732
    },
    {
      "t": 47002,
      "e": 46772,
      "ty": 41,
      "x": 64742,
      "y": 40107,
      "ta": "html > body"
    },
    {
      "t": 47235,
      "e": 47005,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 47702,
      "e": 47472,
      "ty": 2,
      "x": 1888,
      "y": 725
    },
    {
      "t": 47751,
      "e": 47521,
      "ty": 41,
      "x": 64123,
      "y": 38334,
      "ta": "html > body"
    },
    {
      "t": 47802,
      "e": 47572,
      "ty": 2,
      "x": 1817,
      "y": 623
    },
    {
      "t": 47901,
      "e": 47671,
      "ty": 2,
      "x": 1455,
      "y": 291
    },
    {
      "t": 48002,
      "e": 47772,
      "ty": 2,
      "x": 1178,
      "y": 245
    },
    {
      "t": 48002,
      "e": 47772,
      "ty": 41,
      "x": 40292,
      "y": 13129,
      "ta": "html > body"
    },
    {
      "t": 48102,
      "e": 47872,
      "ty": 2,
      "x": 1026,
      "y": 253
    },
    {
      "t": 48202,
      "e": 47972,
      "ty": 2,
      "x": 974,
      "y": 270
    },
    {
      "t": 48252,
      "e": 48022,
      "ty": 41,
      "x": 29328,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 48302,
      "e": 48072,
      "ty": 2,
      "x": 912,
      "y": 275
    },
    {
      "t": 48401,
      "e": 48171,
      "ty": 2,
      "x": 863,
      "y": 256
    },
    {
      "t": 48501,
      "e": 48271,
      "ty": 2,
      "x": 854,
      "y": 246
    },
    {
      "t": 48501,
      "e": 48271,
      "ty": 41,
      "x": 26677,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 48602,
      "e": 48372,
      "ty": 2,
      "x": 841,
      "y": 243
    },
    {
      "t": 48717,
      "e": 48373,
      "ty": 6,
      "x": 839,
      "y": 243,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48752,
      "e": 48408,
      "ty": 41,
      "x": 53325,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48801,
      "e": 48457,
      "ty": 2,
      "x": 834,
      "y": 240
    },
    {
      "t": 48902,
      "e": 48558,
      "ty": 2,
      "x": 828,
      "y": 238
    },
    {
      "t": 48996,
      "e": 48652,
      "ty": 3,
      "x": 828,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48996,
      "e": 48652,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49002,
      "e": 48658,
      "ty": 41,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49066,
      "e": 48722,
      "ty": 4,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49066,
      "e": 48722,
      "ty": 5,
      "x": 828,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49066,
      "e": 48722,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 49947,
      "e": 49603,
      "ty": 7,
      "x": 833,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50002,
      "e": 49658,
      "ty": 2,
      "x": 845,
      "y": 262
    },
    {
      "t": 50002,
      "e": 49658,
      "ty": 41,
      "x": 17957,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 50100,
      "e": 49756,
      "ty": 2,
      "x": 848,
      "y": 282
    },
    {
      "t": 50202,
      "e": 49858,
      "ty": 2,
      "x": 846,
      "y": 290
    },
    {
      "t": 50255,
      "e": 49911,
      "ty": 41,
      "x": 7389,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 50306,
      "e": 49962,
      "ty": 2,
      "x": 842,
      "y": 295
    },
    {
      "t": 50318,
      "e": 49974,
      "ty": 6,
      "x": 837,
      "y": 297,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 50404,
      "e": 50060,
      "ty": 2,
      "x": 833,
      "y": 298
    },
    {
      "t": 50504,
      "e": 50160,
      "ty": 2,
      "x": 831,
      "y": 298
    },
    {
      "t": 50505,
      "e": 50161,
      "ty": 41,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 50551,
      "e": 50207,
      "ty": 3,
      "x": 831,
      "y": 298,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 50552,
      "e": 50208,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50553,
      "e": 50209,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 50621,
      "e": 50277,
      "ty": 4,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 50622,
      "e": 50278,
      "ty": 5,
      "x": 831,
      "y": 298,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 50622,
      "e": 50278,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 50904,
      "e": 50560,
      "ty": 2,
      "x": 832,
      "y": 298
    },
    {
      "t": 50933,
      "e": 50589,
      "ty": 7,
      "x": 854,
      "y": 302,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 51005,
      "e": 50661,
      "ty": 2,
      "x": 870,
      "y": 306
    },
    {
      "t": 51005,
      "e": 50661,
      "ty": 41,
      "x": 11528,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 51104,
      "e": 50760,
      "ty": 2,
      "x": 905,
      "y": 338
    },
    {
      "t": 51204,
      "e": 50860,
      "ty": 2,
      "x": 913,
      "y": 376
    },
    {
      "t": 51255,
      "e": 50911,
      "ty": 41,
      "x": 21733,
      "y": 8394,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 51305,
      "e": 50961,
      "ty": 2,
      "x": 909,
      "y": 394
    },
    {
      "t": 51404,
      "e": 51060,
      "ty": 2,
      "x": 880,
      "y": 411
    },
    {
      "t": 51504,
      "e": 51160,
      "ty": 2,
      "x": 870,
      "y": 415
    },
    {
      "t": 51504,
      "e": 51160,
      "ty": 41,
      "x": 56865,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 51604,
      "e": 51260,
      "ty": 2,
      "x": 849,
      "y": 420
    },
    {
      "t": 51705,
      "e": 51361,
      "ty": 2,
      "x": 835,
      "y": 421
    },
    {
      "t": 51751,
      "e": 51407,
      "ty": 6,
      "x": 835,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 51755,
      "e": 51411,
      "ty": 41,
      "x": 43243,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 51804,
      "e": 51460,
      "ty": 2,
      "x": 833,
      "y": 419
    },
    {
      "t": 51905,
      "e": 51561,
      "ty": 2,
      "x": 832,
      "y": 418
    },
    {
      "t": 51911,
      "e": 51567,
      "ty": 3,
      "x": 832,
      "y": 418,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 51912,
      "e": 51568,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 51912,
      "e": 51568,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 51958,
      "e": 51614,
      "ty": 4,
      "x": 28120,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 51959,
      "e": 51615,
      "ty": 5,
      "x": 832,
      "y": 418,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 51959,
      "e": 51615,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 52005,
      "e": 51661,
      "ty": 41,
      "x": 28120,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 52285,
      "e": 51941,
      "ty": 7,
      "x": 839,
      "y": 425,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 52304,
      "e": 51960,
      "ty": 2,
      "x": 846,
      "y": 431
    },
    {
      "t": 52405,
      "e": 52061,
      "ty": 2,
      "x": 880,
      "y": 461
    },
    {
      "t": 52505,
      "e": 52161,
      "ty": 2,
      "x": 911,
      "y": 586
    },
    {
      "t": 52505,
      "e": 52161,
      "ty": 41,
      "x": 21259,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 52605,
      "e": 52261,
      "ty": 2,
      "x": 947,
      "y": 606
    },
    {
      "t": 52756,
      "e": 52262,
      "ty": 41,
      "x": 29802,
      "y": 33253,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 52904,
      "e": 52410,
      "ty": 2,
      "x": 938,
      "y": 620
    },
    {
      "t": 53005,
      "e": 52511,
      "ty": 2,
      "x": 910,
      "y": 646
    },
    {
      "t": 53005,
      "e": 52511,
      "ty": 41,
      "x": 21021,
      "y": 8394,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 53105,
      "e": 52611,
      "ty": 2,
      "x": 900,
      "y": 652
    },
    {
      "t": 53204,
      "e": 52710,
      "ty": 2,
      "x": 876,
      "y": 664
    },
    {
      "t": 53256,
      "e": 52762,
      "ty": 41,
      "x": 13580,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 53304,
      "e": 52810,
      "ty": 2,
      "x": 862,
      "y": 666
    },
    {
      "t": 53353,
      "e": 52859,
      "ty": 6,
      "x": 837,
      "y": 671,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 53404,
      "e": 52910,
      "ty": 2,
      "x": 828,
      "y": 673
    },
    {
      "t": 53436,
      "e": 52942,
      "ty": 7,
      "x": 825,
      "y": 674,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 53504,
      "e": 53010,
      "ty": 2,
      "x": 825,
      "y": 675
    },
    {
      "t": 53504,
      "e": 53010,
      "ty": 41,
      "x": 960,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 53703,
      "e": 53209,
      "ty": 3,
      "x": 825,
      "y": 675,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 53704,
      "e": 53210,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 53766,
      "e": 53272,
      "ty": 4,
      "x": 960,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 53766,
      "e": 53272,
      "ty": 5,
      "x": 825,
      "y": 675,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 53766,
      "e": 53272,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 53766,
      "e": 53272,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 54336,
      "e": 53842,
      "ty": 6,
      "x": 826,
      "y": 675,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 54405,
      "e": 53911,
      "ty": 2,
      "x": 833,
      "y": 679
    },
    {
      "t": 54420,
      "e": 53926,
      "ty": 7,
      "x": 838,
      "y": 683,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 54505,
      "e": 54011,
      "ty": 2,
      "x": 848,
      "y": 698
    },
    {
      "t": 54505,
      "e": 54011,
      "ty": 41,
      "x": 6697,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 54605,
      "e": 54111,
      "ty": 2,
      "x": 848,
      "y": 703
    },
    {
      "t": 54705,
      "e": 54211,
      "ty": 2,
      "x": 848,
      "y": 712
    },
    {
      "t": 54755,
      "e": 54261,
      "ty": 41,
      "x": 6070,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 54804,
      "e": 54310,
      "ty": 2,
      "x": 847,
      "y": 725
    },
    {
      "t": 54905,
      "e": 54411,
      "ty": 2,
      "x": 848,
      "y": 750
    },
    {
      "t": 55005,
      "e": 54511,
      "ty": 2,
      "x": 848,
      "y": 782
    },
    {
      "t": 55005,
      "e": 54511,
      "ty": 41,
      "x": 14879,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 55105,
      "e": 54611,
      "ty": 2,
      "x": 848,
      "y": 790
    },
    {
      "t": 55205,
      "e": 54711,
      "ty": 2,
      "x": 850,
      "y": 799
    },
    {
      "t": 55256,
      "e": 54762,
      "ty": 41,
      "x": 19228,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 55304,
      "e": 54810,
      "ty": 2,
      "x": 856,
      "y": 811
    },
    {
      "t": 55405,
      "e": 54911,
      "ty": 2,
      "x": 857,
      "y": 809
    },
    {
      "t": 55505,
      "e": 55011,
      "ty": 2,
      "x": 847,
      "y": 769
    },
    {
      "t": 55505,
      "e": 55011,
      "ty": 41,
      "x": 6070,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 55571,
      "e": 55077,
      "ty": 6,
      "x": 839,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 55588,
      "e": 55094,
      "ty": 7,
      "x": 838,
      "y": 749,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 55606,
      "e": 55112,
      "ty": 2,
      "x": 836,
      "y": 744
    },
    {
      "t": 55641,
      "e": 55115,
      "ty": 6,
      "x": 833,
      "y": 733,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 55688,
      "e": 55162,
      "ty": 7,
      "x": 828,
      "y": 723,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 55705,
      "e": 55179,
      "ty": 2,
      "x": 828,
      "y": 721
    },
    {
      "t": 55755,
      "e": 55229,
      "ty": 41,
      "x": 1561,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 55805,
      "e": 55279,
      "ty": 2,
      "x": 828,
      "y": 715
    },
    {
      "t": 55904,
      "e": 55378,
      "ty": 2,
      "x": 828,
      "y": 713
    },
    {
      "t": 56004,
      "e": 55478,
      "ty": 2,
      "x": 829,
      "y": 712
    },
    {
      "t": 56005,
      "e": 55479,
      "ty": 41,
      "x": 1909,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 56105,
      "e": 55579,
      "ty": 2,
      "x": 829,
      "y": 711
    },
    {
      "t": 56159,
      "e": 55633,
      "ty": 3,
      "x": 829,
      "y": 711,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 56160,
      "e": 55634,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 56238,
      "e": 55712,
      "ty": 4,
      "x": 1909,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 56238,
      "e": 55712,
      "ty": 5,
      "x": 829,
      "y": 711,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 56239,
      "e": 55713,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56239,
      "e": 55713,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 56255,
      "e": 55729,
      "ty": 41,
      "x": 1909,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 56405,
      "e": 55879,
      "ty": 2,
      "x": 830,
      "y": 710
    },
    {
      "t": 56430,
      "e": 55904,
      "ty": 6,
      "x": 830,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56505,
      "e": 55979,
      "ty": 2,
      "x": 831,
      "y": 708
    },
    {
      "t": 56506,
      "e": 55980,
      "ty": 41,
      "x": 23079,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56711,
      "e": 56185,
      "ty": 7,
      "x": 831,
      "y": 710,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56755,
      "e": 56229,
      "ty": 41,
      "x": 3156,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 56755,
      "e": 56229,
      "ty": 6,
      "x": 838,
      "y": 735,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 56772,
      "e": 56246,
      "ty": 7,
      "x": 843,
      "y": 747,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 56805,
      "e": 56279,
      "ty": 2,
      "x": 848,
      "y": 755
    },
    {
      "t": 56904,
      "e": 56378,
      "ty": 2,
      "x": 906,
      "y": 819
    },
    {
      "t": 57004,
      "e": 56478,
      "ty": 2,
      "x": 949,
      "y": 837
    },
    {
      "t": 57004,
      "e": 56478,
      "ty": 41,
      "x": 30277,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 57205,
      "e": 56679,
      "ty": 2,
      "x": 929,
      "y": 859
    },
    {
      "t": 57255,
      "e": 56729,
      "ty": 41,
      "x": 8206,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 57272,
      "e": 56746,
      "ty": 6,
      "x": 839,
      "y": 940,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 57288,
      "e": 56762,
      "ty": 7,
      "x": 836,
      "y": 945,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 57305,
      "e": 56779,
      "ty": 2,
      "x": 836,
      "y": 945
    },
    {
      "t": 57404,
      "e": 56878,
      "ty": 2,
      "x": 833,
      "y": 954
    },
    {
      "t": 57406,
      "e": 56880,
      "ty": 6,
      "x": 833,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 57505,
      "e": 56979,
      "ty": 2,
      "x": 833,
      "y": 958
    },
    {
      "t": 57505,
      "e": 56979,
      "ty": 41,
      "x": 33161,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 57605,
      "e": 57079,
      "ty": 2,
      "x": 833,
      "y": 959
    },
    {
      "t": 57679,
      "e": 57153,
      "ty": 3,
      "x": 833,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 57679,
      "e": 57153,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 57680,
      "e": 57154,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 57755,
      "e": 57229,
      "ty": 41,
      "x": 33161,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 57757,
      "e": 57231,
      "ty": 4,
      "x": 33161,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 57758,
      "e": 57232,
      "ty": 5,
      "x": 833,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 57758,
      "e": 57232,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 57904,
      "e": 57378,
      "ty": 2,
      "x": 835,
      "y": 960
    },
    {
      "t": 57924,
      "e": 57398,
      "ty": 7,
      "x": 845,
      "y": 965,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58005,
      "e": 57479,
      "ty": 2,
      "x": 890,
      "y": 993
    },
    {
      "t": 58005,
      "e": 57479,
      "ty": 41,
      "x": 16275,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 58104,
      "e": 57578,
      "ty": 2,
      "x": 904,
      "y": 1003
    },
    {
      "t": 58122,
      "e": 57581,
      "ty": 6,
      "x": 905,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58205,
      "e": 57664,
      "ty": 2,
      "x": 907,
      "y": 1010
    },
    {
      "t": 58255,
      "e": 57714,
      "ty": 41,
      "x": 41013,
      "y": 15887,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58305,
      "e": 57764,
      "ty": 2,
      "x": 909,
      "y": 1013
    },
    {
      "t": 58367,
      "e": 57826,
      "ty": 3,
      "x": 909,
      "y": 1013,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58369,
      "e": 57828,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58369,
      "e": 57828,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58422,
      "e": 57881,
      "ty": 4,
      "x": 41013,
      "y": 15887,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58422,
      "e": 57881,
      "ty": 5,
      "x": 909,
      "y": 1013,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58424,
      "e": 57883,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58425,
      "e": 57884,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 58425,
      "e": 57884,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 58905,
      "e": 58364,
      "ty": 2,
      "x": 953,
      "y": 976
    },
    {
      "t": 59005,
      "e": 58464,
      "ty": 2,
      "x": 1022,
      "y": 861
    },
    {
      "t": 59005,
      "e": 58464,
      "ty": 41,
      "x": 34919,
      "y": 47253,
      "ta": "html > body"
    },
    {
      "t": 59105,
      "e": 58564,
      "ty": 2,
      "x": 1242,
      "y": 616
    },
    {
      "t": 59205,
      "e": 58664,
      "ty": 2,
      "x": 1247,
      "y": 608
    },
    {
      "t": 59255,
      "e": 58714,
      "ty": 41,
      "x": 42668,
      "y": 33238,
      "ta": "html > body"
    },
    {
      "t": 59510,
      "e": 58969,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 60105,
      "e": 59564,
      "ty": 2,
      "x": 1247,
      "y": 609
    },
    {
      "t": 60205,
      "e": 59664,
      "ty": 2,
      "x": 1225,
      "y": 657
    },
    {
      "t": 60255,
      "e": 59714,
      "ty": 41,
      "x": 44205,
      "y": 17855,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 60305,
      "e": 59764,
      "ty": 2,
      "x": 1166,
      "y": 708
    },
    {
      "t": 60405,
      "e": 59864,
      "ty": 2,
      "x": 1156,
      "y": 697
    },
    {
      "t": 60505,
      "e": 59964,
      "ty": 41,
      "x": 42434,
      "y": 16685,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 60705,
      "e": 60164,
      "ty": 2,
      "x": 1157,
      "y": 706
    },
    {
      "t": 60755,
      "e": 60214,
      "ty": 41,
      "x": 42434,
      "y": 52858,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 60805,
      "e": 60264,
      "ty": 2,
      "x": 1125,
      "y": 902
    },
    {
      "t": 60905,
      "e": 60364,
      "ty": 2,
      "x": 1084,
      "y": 974
    },
    {
      "t": 61005,
      "e": 60464,
      "ty": 2,
      "x": 1016,
      "y": 1005
    },
    {
      "t": 61005,
      "e": 60464,
      "ty": 41,
      "x": 35547,
      "y": 60847,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61105,
      "e": 60564,
      "ty": 2,
      "x": 1009,
      "y": 1015
    },
    {
      "t": 61204,
      "e": 60663,
      "ty": 2,
      "x": 1002,
      "y": 1051
    },
    {
      "t": 61255,
      "e": 60714,
      "ty": 41,
      "x": 34710,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61276,
      "e": 60735,
      "ty": 6,
      "x": 995,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 61305,
      "e": 60764,
      "ty": 2,
      "x": 993,
      "y": 1078
    },
    {
      "t": 61405,
      "e": 60864,
      "ty": 2,
      "x": 983,
      "y": 1088
    },
    {
      "t": 61505,
      "e": 60964,
      "ty": 2,
      "x": 979,
      "y": 1090
    },
    {
      "t": 61506,
      "e": 60965,
      "ty": 41,
      "x": 37955,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 66399,
      "e": 65858,
      "ty": 3,
      "x": 979,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 66401,
      "e": 65860,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 66485,
      "e": 65944,
      "ty": 4,
      "x": 37955,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 66486,
      "e": 65945,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 66486,
      "e": 65945,
      "ty": 5,
      "x": 979,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 66487,
      "e": 65946,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 67524,
      "e": 66983,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 68353,
      "e": 67812,
      "ty": 2,
      "x": 1130,
      "y": 759
    },
    {
      "t": 68354,
      "e": 67813,
      "ty": 41,
      "x": 40832,
      "y": 32801,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 68420,
      "e": 67879,
      "ty": 2,
      "x": 1140,
      "y": 714
    },
    {
      "t": 68505,
      "e": 67964,
      "ty": 2,
      "x": 1140,
      "y": 707
    },
    {
      "t": 68505,
      "e": 67964,
      "ty": 41,
      "x": 41305,
      "y": 32790,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 68605,
      "e": 68064,
      "ty": 2,
      "x": 1140,
      "y": 706
    },
    {
      "t": 68756,
      "e": 68215,
      "ty": 41,
      "x": 41305,
      "y": 32790,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 68896,
      "e": 68355,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 160350, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 160355, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 3114, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 164811, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 6714, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"juliet\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 172530, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 11392, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 185008, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 16414, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 202426, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 38065, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 241870, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-09 AM-08 AM-12 PM-04 PM-Z -A -B -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1105,y:1008,t:1527030316226};\\\", \\\"{x:1095,y:1006,t:1527030316238};\\\", \\\"{x:1061,y:999,t:1527030316256};\\\", \\\"{x:978,y:990,t:1527030316273};\\\", \\\"{x:889,y:977,t:1527030316289};\\\", \\\"{x:838,y:977,t:1527030316306};\\\", \\\"{x:806,y:977,t:1527030316322};\\\", \\\"{x:783,y:977,t:1527030316338};\\\", \\\"{x:767,y:977,t:1527030316355};\\\", \\\"{x:752,y:977,t:1527030316372};\\\", \\\"{x:738,y:977,t:1527030316388};\\\", \\\"{x:728,y:977,t:1527030316405};\\\", \\\"{x:724,y:977,t:1527030316422};\\\", \\\"{x:718,y:977,t:1527030316438};\\\", \\\"{x:713,y:977,t:1527030316455};\\\", \\\"{x:712,y:975,t:1527030316473};\\\", \\\"{x:710,y:973,t:1527030316488};\\\", \\\"{x:710,y:972,t:1527030316505};\\\", \\\"{x:714,y:970,t:1527030316922};\\\", \\\"{x:733,y:962,t:1527030316939};\\\", \\\"{x:749,y:952,t:1527030316956};\\\", \\\"{x:768,y:944,t:1527030316973};\\\", \\\"{x:792,y:934,t:1527030316989};\\\", \\\"{x:814,y:925,t:1527030317006};\\\", \\\"{x:830,y:915,t:1527030317022};\\\", \\\"{x:848,y:905,t:1527030317040};\\\", \\\"{x:869,y:896,t:1527030317056};\\\", \\\"{x:884,y:889,t:1527030317073};\\\", \\\"{x:899,y:884,t:1527030317090};\\\", \\\"{x:911,y:881,t:1527030317106};\\\", \\\"{x:927,y:878,t:1527030317123};\\\", \\\"{x:951,y:875,t:1527030317140};\\\", \\\"{x:976,y:872,t:1527030317156};\\\", \\\"{x:1005,y:868,t:1527030317173};\\\", \\\"{x:1038,y:868,t:1527030317190};\\\", \\\"{x:1070,y:868,t:1527030317207};\\\", \\\"{x:1103,y:863,t:1527030317223};\\\", \\\"{x:1132,y:862,t:1527030317239};\\\", \\\"{x:1163,y:862,t:1527030317257};\\\", \\\"{x:1187,y:862,t:1527030317273};\\\", \\\"{x:1203,y:862,t:1527030317290};\\\", \\\"{x:1205,y:862,t:1527030317306};\\\", \\\"{x:1205,y:866,t:1527030317562};\\\", \\\"{x:1202,y:872,t:1527030317573};\\\", \\\"{x:1197,y:883,t:1527030317589};\\\", \\\"{x:1196,y:893,t:1527030317607};\\\", \\\"{x:1193,y:900,t:1527030317623};\\\", \\\"{x:1192,y:906,t:1527030317640};\\\", \\\"{x:1192,y:911,t:1527030317656};\\\", \\\"{x:1192,y:915,t:1527030317673};\\\", \\\"{x:1194,y:921,t:1527030317690};\\\", \\\"{x:1198,y:925,t:1527030317707};\\\", \\\"{x:1202,y:930,t:1527030317723};\\\", \\\"{x:1206,y:933,t:1527030317739};\\\", \\\"{x:1208,y:934,t:1527030317756};\\\", \\\"{x:1209,y:935,t:1527030317773};\\\", \\\"{x:1210,y:936,t:1527030317809};\\\", \\\"{x:1210,y:937,t:1527030317858};\\\", \\\"{x:1210,y:939,t:1527030317873};\\\", \\\"{x:1210,y:941,t:1527030317890};\\\", \\\"{x:1210,y:943,t:1527030317907};\\\", \\\"{x:1210,y:945,t:1527030317924};\\\", \\\"{x:1210,y:946,t:1527030317940};\\\", \\\"{x:1210,y:950,t:1527030317957};\\\", \\\"{x:1212,y:952,t:1527030317974};\\\", \\\"{x:1215,y:955,t:1527030317990};\\\", \\\"{x:1218,y:957,t:1527030318006};\\\", \\\"{x:1220,y:958,t:1527030318023};\\\", \\\"{x:1221,y:958,t:1527030318050};\\\", \\\"{x:1222,y:958,t:1527030318058};\\\", \\\"{x:1222,y:959,t:1527030318074};\\\", \\\"{x:1224,y:959,t:1527030318089};\\\", \\\"{x:1225,y:960,t:1527030318107};\\\", \\\"{x:1228,y:960,t:1527030318124};\\\", \\\"{x:1232,y:960,t:1527030318140};\\\", \\\"{x:1239,y:960,t:1527030318157};\\\", \\\"{x:1249,y:960,t:1527030318174};\\\", \\\"{x:1260,y:960,t:1527030318190};\\\", \\\"{x:1269,y:960,t:1527030318207};\\\", \\\"{x:1278,y:960,t:1527030318224};\\\", \\\"{x:1283,y:962,t:1527030318241};\\\", \\\"{x:1290,y:962,t:1527030318256};\\\", \\\"{x:1294,y:962,t:1527030318274};\\\", \\\"{x:1296,y:962,t:1527030318290};\\\", \\\"{x:1294,y:963,t:1527030318451};\\\", \\\"{x:1293,y:963,t:1527030318458};\\\", \\\"{x:1283,y:964,t:1527030318474};\\\", \\\"{x:1275,y:966,t:1527030318491};\\\", \\\"{x:1265,y:967,t:1527030318507};\\\", \\\"{x:1261,y:967,t:1527030318524};\\\", \\\"{x:1259,y:967,t:1527030318541};\\\", \\\"{x:1258,y:968,t:1527030318557};\\\", \\\"{x:1257,y:968,t:1527030318650};\\\", \\\"{x:1256,y:968,t:1527030318658};\\\", \\\"{x:1253,y:968,t:1527030318674};\\\", \\\"{x:1249,y:968,t:1527030318691};\\\", \\\"{x:1242,y:970,t:1527030318708};\\\", \\\"{x:1233,y:971,t:1527030318724};\\\", \\\"{x:1224,y:972,t:1527030318741};\\\", \\\"{x:1211,y:974,t:1527030318757};\\\", \\\"{x:1200,y:976,t:1527030318773};\\\", \\\"{x:1190,y:977,t:1527030318792};\\\", \\\"{x:1176,y:979,t:1527030318809};\\\", \\\"{x:1158,y:980,t:1527030318824};\\\", \\\"{x:1138,y:980,t:1527030318841};\\\", \\\"{x:1104,y:980,t:1527030318859};\\\", \\\"{x:1071,y:977,t:1527030318874};\\\", \\\"{x:1046,y:972,t:1527030318891};\\\", \\\"{x:1020,y:969,t:1527030318908};\\\", \\\"{x:997,y:966,t:1527030318924};\\\", \\\"{x:980,y:966,t:1527030318941};\\\", \\\"{x:964,y:965,t:1527030318958};\\\", \\\"{x:953,y:962,t:1527030318974};\\\", \\\"{x:943,y:962,t:1527030318990};\\\", \\\"{x:935,y:961,t:1527030319008};\\\", \\\"{x:931,y:959,t:1527030319024};\\\", \\\"{x:928,y:959,t:1527030319040};\\\", \\\"{x:921,y:959,t:1527030319058};\\\", \\\"{x:919,y:959,t:1527030319074};\\\", \\\"{x:916,y:959,t:1527030319091};\\\", \\\"{x:912,y:959,t:1527030319107};\\\", \\\"{x:910,y:959,t:1527030319125};\\\", \\\"{x:909,y:959,t:1527030319140};\\\", \\\"{x:907,y:959,t:1527030319158};\\\", \\\"{x:906,y:959,t:1527030319202};\\\", \\\"{x:905,y:959,t:1527030319210};\\\", \\\"{x:904,y:959,t:1527030319233};\\\", \\\"{x:903,y:959,t:1527030319291};\\\", \\\"{x:902,y:959,t:1527030319308};\\\", \\\"{x:901,y:959,t:1527030319324};\\\", \\\"{x:899,y:959,t:1527030319730};\\\", \\\"{x:898,y:959,t:1527030319746};\\\", \\\"{x:897,y:959,t:1527030319770};\\\", \\\"{x:896,y:959,t:1527030319777};\\\", \\\"{x:895,y:959,t:1527030319792};\\\", \\\"{x:894,y:959,t:1527030319818};\\\", \\\"{x:892,y:959,t:1527030319834};\\\", \\\"{x:891,y:958,t:1527030319930};\\\", \\\"{x:889,y:958,t:1527030320002};\\\", \\\"{x:889,y:957,t:1527030320074};\\\", \\\"{x:888,y:957,t:1527030320977};\\\", \\\"{x:887,y:957,t:1527030320991};\\\", \\\"{x:886,y:956,t:1527030321008};\\\", \\\"{x:885,y:955,t:1527030321033};\\\", \\\"{x:885,y:954,t:1527030321066};\\\", \\\"{x:883,y:954,t:1527030322634};\\\", \\\"{x:882,y:954,t:1527030322930};\\\", \\\"{x:882,y:953,t:1527030322944};\\\", \\\"{x:882,y:952,t:1527030322961};\\\", \\\"{x:883,y:951,t:1527030322977};\\\", \\\"{x:884,y:951,t:1527030322993};\\\", \\\"{x:886,y:950,t:1527030323011};\\\", \\\"{x:888,y:950,t:1527030323032};\\\", \\\"{x:889,y:949,t:1527030323049};\\\", \\\"{x:891,y:949,t:1527030323065};\\\", \\\"{x:893,y:949,t:1527030323081};\\\", \\\"{x:896,y:949,t:1527030323094};\\\", \\\"{x:901,y:949,t:1527030323110};\\\", \\\"{x:908,y:949,t:1527030323126};\\\", \\\"{x:915,y:949,t:1527030323144};\\\", \\\"{x:924,y:949,t:1527030323160};\\\", \\\"{x:928,y:949,t:1527030323177};\\\", \\\"{x:935,y:949,t:1527030323193};\\\", \\\"{x:937,y:949,t:1527030323210};\\\", \\\"{x:938,y:949,t:1527030323227};\\\", \\\"{x:941,y:949,t:1527030323244};\\\", \\\"{x:945,y:949,t:1527030323260};\\\", \\\"{x:948,y:949,t:1527030323277};\\\", \\\"{x:952,y:949,t:1527030323295};\\\", \\\"{x:957,y:949,t:1527030323311};\\\", \\\"{x:960,y:948,t:1527030323326};\\\", \\\"{x:961,y:948,t:1527030323344};\\\", \\\"{x:962,y:948,t:1527030323361};\\\", \\\"{x:964,y:947,t:1527030323402};\\\", \\\"{x:962,y:947,t:1527030325714};\\\", \\\"{x:957,y:947,t:1527030325729};\\\", \\\"{x:954,y:948,t:1527030325746};\\\", \\\"{x:952,y:949,t:1527030325762};\\\", \\\"{x:951,y:949,t:1527030325850};\\\", \\\"{x:951,y:950,t:1527030325938};\\\", \\\"{x:952,y:950,t:1527030325953};\\\", \\\"{x:955,y:950,t:1527030325963};\\\", \\\"{x:957,y:950,t:1527030325979};\\\", \\\"{x:958,y:948,t:1527030325996};\\\", \\\"{x:962,y:946,t:1527030326626};\\\", \\\"{x:965,y:946,t:1527030326633};\\\", \\\"{x:968,y:946,t:1527030326646};\\\", \\\"{x:973,y:945,t:1527030326663};\\\", \\\"{x:978,y:942,t:1527030326680};\\\", \\\"{x:983,y:941,t:1527030326697};\\\", \\\"{x:987,y:939,t:1527030326713};\\\", \\\"{x:992,y:936,t:1527030326730};\\\", \\\"{x:999,y:933,t:1527030326746};\\\", \\\"{x:1007,y:930,t:1527030326763};\\\", \\\"{x:1015,y:925,t:1527030326780};\\\", \\\"{x:1022,y:924,t:1527030326797};\\\", \\\"{x:1034,y:919,t:1527030326813};\\\", \\\"{x:1044,y:915,t:1527030326830};\\\", \\\"{x:1054,y:910,t:1527030326847};\\\", \\\"{x:1063,y:906,t:1527030326863};\\\", \\\"{x:1069,y:905,t:1527030326880};\\\", \\\"{x:1077,y:901,t:1527030326898};\\\", \\\"{x:1088,y:897,t:1527030326913};\\\", \\\"{x:1104,y:893,t:1527030326930};\\\", \\\"{x:1117,y:888,t:1527030326947};\\\", \\\"{x:1130,y:885,t:1527030326963};\\\", \\\"{x:1147,y:881,t:1527030326981};\\\", \\\"{x:1167,y:876,t:1527030326997};\\\", \\\"{x:1181,y:871,t:1527030327013};\\\", \\\"{x:1194,y:866,t:1527030327030};\\\", \\\"{x:1206,y:861,t:1527030327047};\\\", \\\"{x:1214,y:857,t:1527030327063};\\\", \\\"{x:1222,y:854,t:1527030327081};\\\", \\\"{x:1226,y:852,t:1527030327097};\\\", \\\"{x:1234,y:847,t:1527030327114};\\\", \\\"{x:1248,y:841,t:1527030327130};\\\", \\\"{x:1260,y:836,t:1527030327147};\\\", \\\"{x:1275,y:830,t:1527030327163};\\\", \\\"{x:1295,y:824,t:1527030327180};\\\", \\\"{x:1310,y:819,t:1527030327197};\\\", \\\"{x:1330,y:812,t:1527030327213};\\\", \\\"{x:1354,y:805,t:1527030327231};\\\", \\\"{x:1372,y:800,t:1527030327247};\\\", \\\"{x:1383,y:796,t:1527030327264};\\\", \\\"{x:1392,y:792,t:1527030327281};\\\", \\\"{x:1399,y:790,t:1527030327297};\\\", \\\"{x:1407,y:787,t:1527030327314};\\\", \\\"{x:1408,y:787,t:1527030327330};\\\", \\\"{x:1411,y:785,t:1527030327347};\\\", \\\"{x:1416,y:782,t:1527030327364};\\\", \\\"{x:1422,y:778,t:1527030327380};\\\", \\\"{x:1427,y:775,t:1527030327397};\\\", \\\"{x:1430,y:772,t:1527030327414};\\\", \\\"{x:1431,y:771,t:1527030327431};\\\", \\\"{x:1432,y:771,t:1527030327458};\\\", \\\"{x:1432,y:772,t:1527030327818};\\\", \\\"{x:1430,y:774,t:1527030327831};\\\", \\\"{x:1426,y:777,t:1527030327848};\\\", \\\"{x:1424,y:779,t:1527030327864};\\\", \\\"{x:1422,y:780,t:1527030327882};\\\", \\\"{x:1420,y:781,t:1527030327897};\\\", \\\"{x:1419,y:783,t:1527030327915};\\\", \\\"{x:1417,y:785,t:1527030327931};\\\", \\\"{x:1416,y:789,t:1527030327947};\\\", \\\"{x:1414,y:790,t:1527030327964};\\\", \\\"{x:1413,y:793,t:1527030327981};\\\", \\\"{x:1410,y:796,t:1527030327997};\\\", \\\"{x:1409,y:800,t:1527030328015};\\\", \\\"{x:1406,y:803,t:1527030328031};\\\", \\\"{x:1405,y:808,t:1527030328048};\\\", \\\"{x:1404,y:810,t:1527030328065};\\\", \\\"{x:1402,y:814,t:1527030328081};\\\", \\\"{x:1401,y:817,t:1527030328098};\\\", \\\"{x:1399,y:822,t:1527030328114};\\\", \\\"{x:1398,y:826,t:1527030328132};\\\", \\\"{x:1398,y:828,t:1527030328148};\\\", \\\"{x:1396,y:832,t:1527030328164};\\\", \\\"{x:1396,y:835,t:1527030328181};\\\", \\\"{x:1395,y:839,t:1527030328197};\\\", \\\"{x:1395,y:842,t:1527030328214};\\\", \\\"{x:1395,y:847,t:1527030328231};\\\", \\\"{x:1395,y:850,t:1527030328248};\\\", \\\"{x:1394,y:854,t:1527030328265};\\\", \\\"{x:1392,y:859,t:1527030328281};\\\", \\\"{x:1392,y:864,t:1527030328298};\\\", \\\"{x:1392,y:866,t:1527030328314};\\\", \\\"{x:1391,y:868,t:1527030328331};\\\", \\\"{x:1389,y:873,t:1527030328348};\\\", \\\"{x:1388,y:877,t:1527030328364};\\\", \\\"{x:1387,y:881,t:1527030328382};\\\", \\\"{x:1386,y:887,t:1527030328399};\\\", \\\"{x:1383,y:894,t:1527030328414};\\\", \\\"{x:1378,y:903,t:1527030328432};\\\", \\\"{x:1376,y:908,t:1527030328448};\\\", \\\"{x:1375,y:911,t:1527030328464};\\\", \\\"{x:1375,y:913,t:1527030328482};\\\", \\\"{x:1374,y:914,t:1527030328498};\\\", \\\"{x:1374,y:915,t:1527030328522};\\\", \\\"{x:1374,y:916,t:1527030328532};\\\", \\\"{x:1372,y:920,t:1527030328549};\\\", \\\"{x:1369,y:925,t:1527030328565};\\\", \\\"{x:1367,y:932,t:1527030328581};\\\", \\\"{x:1363,y:939,t:1527030328599};\\\", \\\"{x:1358,y:944,t:1527030328614};\\\", \\\"{x:1354,y:950,t:1527030328631};\\\", \\\"{x:1349,y:957,t:1527030328649};\\\", \\\"{x:1346,y:961,t:1527030328664};\\\", \\\"{x:1344,y:963,t:1527030328681};\\\", \\\"{x:1343,y:965,t:1527030328698};\\\", \\\"{x:1342,y:965,t:1527030328714};\\\", \\\"{x:1341,y:968,t:1527030328731};\\\", \\\"{x:1340,y:968,t:1527030328753};\\\", \\\"{x:1339,y:969,t:1527030328766};\\\", \\\"{x:1338,y:969,t:1527030328782};\\\", \\\"{x:1337,y:971,t:1527030328799};\\\", \\\"{x:1336,y:972,t:1527030328817};\\\", \\\"{x:1335,y:972,t:1527030328842};\\\", \\\"{x:1334,y:974,t:1527030328849};\\\", \\\"{x:1333,y:974,t:1527030328866};\\\", \\\"{x:1332,y:974,t:1527030328889};\\\", \\\"{x:1330,y:975,t:1527030328913};\\\", \\\"{x:1329,y:975,t:1527030328954};\\\", \\\"{x:1328,y:975,t:1527030329066};\\\", \\\"{x:1327,y:975,t:1527030329099};\\\", \\\"{x:1326,y:974,t:1527030329115};\\\", \\\"{x:1326,y:972,t:1527030329138};\\\", \\\"{x:1326,y:971,t:1527030329170};\\\", \\\"{x:1325,y:970,t:1527030329210};\\\", \\\"{x:1325,y:969,t:1527030329242};\\\", \\\"{x:1325,y:968,t:1527030329466};\\\", \\\"{x:1325,y:966,t:1527030329506};\\\", \\\"{x:1325,y:965,t:1527030329515};\\\", \\\"{x:1325,y:964,t:1527030329538};\\\", \\\"{x:1325,y:963,t:1527030329570};\\\", \\\"{x:1326,y:962,t:1527030329583};\\\", \\\"{x:1326,y:961,t:1527030329610};\\\", \\\"{x:1326,y:960,t:1527030329626};\\\", \\\"{x:1326,y:959,t:1527030329642};\\\", \\\"{x:1327,y:959,t:1527030329658};\\\", \\\"{x:1328,y:958,t:1527030329665};\\\", \\\"{x:1329,y:958,t:1527030329683};\\\", \\\"{x:1330,y:957,t:1527030329699};\\\", \\\"{x:1330,y:956,t:1527030329715};\\\", \\\"{x:1332,y:954,t:1527030329732};\\\", \\\"{x:1335,y:954,t:1527030329749};\\\", \\\"{x:1336,y:953,t:1527030329765};\\\", \\\"{x:1337,y:952,t:1527030329783};\\\", \\\"{x:1338,y:951,t:1527030329799};\\\", \\\"{x:1340,y:951,t:1527030329816};\\\", \\\"{x:1341,y:950,t:1527030329833};\\\", \\\"{x:1344,y:950,t:1527030329850};\\\", \\\"{x:1345,y:950,t:1527030329866};\\\", \\\"{x:1349,y:950,t:1527030329883};\\\", \\\"{x:1355,y:950,t:1527030329899};\\\", \\\"{x:1359,y:950,t:1527030329915};\\\", \\\"{x:1364,y:950,t:1527030329932};\\\", \\\"{x:1370,y:950,t:1527030329950};\\\", \\\"{x:1375,y:950,t:1527030329965};\\\", \\\"{x:1379,y:950,t:1527030329983};\\\", \\\"{x:1383,y:951,t:1527030330000};\\\", \\\"{x:1385,y:951,t:1527030330015};\\\", \\\"{x:1387,y:951,t:1527030330034};\\\", \\\"{x:1388,y:952,t:1527030330074};\\\", \\\"{x:1389,y:953,t:1527030330098};\\\", \\\"{x:1390,y:953,t:1527030330130};\\\", \\\"{x:1391,y:954,t:1527030330138};\\\", \\\"{x:1392,y:954,t:1527030330150};\\\", \\\"{x:1396,y:957,t:1527030330166};\\\", \\\"{x:1402,y:961,t:1527030330181};\\\", \\\"{x:1409,y:963,t:1527030330199};\\\", \\\"{x:1420,y:967,t:1527030330216};\\\", \\\"{x:1436,y:975,t:1527030330231};\\\", \\\"{x:1460,y:982,t:1527030330249};\\\", \\\"{x:1478,y:989,t:1527030330265};\\\", \\\"{x:1492,y:993,t:1527030330282};\\\", \\\"{x:1505,y:998,t:1527030330298};\\\", \\\"{x:1515,y:1002,t:1527030330315};\\\", \\\"{x:1519,y:1003,t:1527030330332};\\\", \\\"{x:1521,y:1003,t:1527030330361};\\\", \\\"{x:1522,y:1005,t:1527030330530};\\\", \\\"{x:1522,y:1006,t:1527030330554};\\\", \\\"{x:1522,y:1008,t:1527030330570};\\\", \\\"{x:1522,y:1009,t:1527030330586};\\\", \\\"{x:1522,y:1011,t:1527030330600};\\\", \\\"{x:1522,y:1012,t:1527030330617};\\\", \\\"{x:1522,y:1014,t:1527030330633};\\\", \\\"{x:1522,y:1015,t:1527030330658};\\\", \\\"{x:1522,y:1016,t:1527030330674};\\\", \\\"{x:1522,y:1017,t:1527030330690};\\\", \\\"{x:1523,y:1017,t:1527030330922};\\\", \\\"{x:1524,y:1017,t:1527030330934};\\\", \\\"{x:1526,y:1016,t:1527030330949};\\\", \\\"{x:1528,y:1016,t:1527030330966};\\\", \\\"{x:1533,y:1013,t:1527030330983};\\\", \\\"{x:1539,y:1013,t:1527030331000};\\\", \\\"{x:1543,y:1010,t:1527030331016};\\\", \\\"{x:1553,y:1006,t:1527030331034};\\\", \\\"{x:1557,y:1005,t:1527030331050};\\\", \\\"{x:1562,y:1002,t:1527030331067};\\\", \\\"{x:1568,y:1001,t:1527030331083};\\\", \\\"{x:1575,y:1000,t:1527030331101};\\\", \\\"{x:1580,y:998,t:1527030331116};\\\", \\\"{x:1584,y:998,t:1527030331134};\\\", \\\"{x:1589,y:998,t:1527030331150};\\\", \\\"{x:1594,y:998,t:1527030331168};\\\", \\\"{x:1600,y:998,t:1527030331183};\\\", \\\"{x:1606,y:998,t:1527030331201};\\\", \\\"{x:1612,y:999,t:1527030331216};\\\", \\\"{x:1621,y:999,t:1527030331234};\\\", \\\"{x:1625,y:1002,t:1527030331250};\\\", \\\"{x:1628,y:1002,t:1527030331266};\\\", \\\"{x:1630,y:1003,t:1527030331284};\\\", \\\"{x:1632,y:1003,t:1527030331301};\\\", \\\"{x:1633,y:1004,t:1527030331316};\\\", \\\"{x:1634,y:1005,t:1527030331346};\\\", \\\"{x:1635,y:1005,t:1527030331386};\\\", \\\"{x:1636,y:1006,t:1527030331450};\\\", \\\"{x:1637,y:1007,t:1527030331466};\\\", \\\"{x:1638,y:1008,t:1527030331483};\\\", \\\"{x:1639,y:1009,t:1527030331522};\\\", \\\"{x:1639,y:1010,t:1527030331537};\\\", \\\"{x:1640,y:1011,t:1527030331570};\\\", \\\"{x:1641,y:1011,t:1527030331618};\\\", \\\"{x:1641,y:1012,t:1527030331674};\\\", \\\"{x:1642,y:1012,t:1527030332810};\\\", \\\"{x:1643,y:1012,t:1527030332818};\\\", \\\"{x:1645,y:1010,t:1527030332834};\\\", \\\"{x:1645,y:1008,t:1527030332852};\\\", \\\"{x:1646,y:1008,t:1527030332868};\\\", \\\"{x:1647,y:1007,t:1527030332884};\\\", \\\"{x:1648,y:1007,t:1527030332901};\\\", \\\"{x:1649,y:1005,t:1527030332917};\\\", \\\"{x:1650,y:1004,t:1527030332934};\\\", \\\"{x:1652,y:1004,t:1527030332952};\\\", \\\"{x:1653,y:1003,t:1527030332967};\\\", \\\"{x:1655,y:1002,t:1527030332984};\\\", \\\"{x:1656,y:1001,t:1527030333010};\\\", \\\"{x:1657,y:1001,t:1527030333034};\\\", \\\"{x:1658,y:1001,t:1527030333052};\\\", \\\"{x:1660,y:1000,t:1527030333068};\\\", \\\"{x:1662,y:1000,t:1527030333084};\\\", \\\"{x:1663,y:1000,t:1527030333102};\\\", \\\"{x:1665,y:998,t:1527030333118};\\\", \\\"{x:1667,y:997,t:1527030333135};\\\", \\\"{x:1669,y:996,t:1527030333152};\\\", \\\"{x:1671,y:996,t:1527030333169};\\\", \\\"{x:1672,y:996,t:1527030333184};\\\", \\\"{x:1676,y:996,t:1527030333201};\\\", \\\"{x:1683,y:996,t:1527030333218};\\\", \\\"{x:1688,y:996,t:1527030333235};\\\", \\\"{x:1696,y:996,t:1527030333251};\\\", \\\"{x:1704,y:996,t:1527030333269};\\\", \\\"{x:1706,y:996,t:1527030333285};\\\", \\\"{x:1707,y:996,t:1527030333302};\\\", \\\"{x:1710,y:996,t:1527030333318};\\\", \\\"{x:1711,y:996,t:1527030333334};\\\", \\\"{x:1712,y:996,t:1527030333351};\\\", \\\"{x:1710,y:996,t:1527030333538};\\\", \\\"{x:1707,y:996,t:1527030333551};\\\", \\\"{x:1701,y:994,t:1527030333568};\\\", \\\"{x:1693,y:992,t:1527030333586};\\\", \\\"{x:1685,y:991,t:1527030333601};\\\", \\\"{x:1678,y:990,t:1527030333618};\\\", \\\"{x:1670,y:988,t:1527030333636};\\\", \\\"{x:1663,y:985,t:1527030333651};\\\", \\\"{x:1654,y:984,t:1527030333668};\\\", \\\"{x:1642,y:980,t:1527030333685};\\\", \\\"{x:1629,y:977,t:1527030333701};\\\", \\\"{x:1611,y:971,t:1527030333718};\\\", \\\"{x:1586,y:965,t:1527030333735};\\\", \\\"{x:1565,y:957,t:1527030333751};\\\", \\\"{x:1541,y:951,t:1527030333768};\\\", \\\"{x:1508,y:932,t:1527030333785};\\\", \\\"{x:1484,y:919,t:1527030333801};\\\", \\\"{x:1465,y:909,t:1527030333818};\\\", \\\"{x:1451,y:900,t:1527030333835};\\\", \\\"{x:1437,y:888,t:1527030333851};\\\", \\\"{x:1422,y:878,t:1527030333869};\\\", \\\"{x:1406,y:866,t:1527030333886};\\\", \\\"{x:1394,y:859,t:1527030333901};\\\", \\\"{x:1383,y:854,t:1527030333918};\\\", \\\"{x:1375,y:850,t:1527030333936};\\\", \\\"{x:1369,y:848,t:1527030333952};\\\", \\\"{x:1363,y:846,t:1527030333968};\\\", \\\"{x:1359,y:845,t:1527030333985};\\\", \\\"{x:1358,y:845,t:1527030334002};\\\", \\\"{x:1356,y:845,t:1527030334018};\\\", \\\"{x:1356,y:844,t:1527030334049};\\\", \\\"{x:1355,y:844,t:1527030334082};\\\", \\\"{x:1354,y:844,t:1527030334098};\\\", \\\"{x:1353,y:844,t:1527030334122};\\\", \\\"{x:1352,y:844,t:1527030334146};\\\", \\\"{x:1350,y:844,t:1527030334152};\\\", \\\"{x:1349,y:844,t:1527030334201};\\\", \\\"{x:1348,y:845,t:1527030334209};\\\", \\\"{x:1346,y:846,t:1527030334217};\\\", \\\"{x:1344,y:848,t:1527030334235};\\\", \\\"{x:1342,y:849,t:1527030334252};\\\", \\\"{x:1340,y:851,t:1527030334268};\\\", \\\"{x:1339,y:852,t:1527030334285};\\\", \\\"{x:1338,y:853,t:1527030334302};\\\", \\\"{x:1337,y:854,t:1527030334318};\\\", \\\"{x:1337,y:855,t:1527030334353};\\\", \\\"{x:1337,y:856,t:1527030334370};\\\", \\\"{x:1338,y:857,t:1527030334385};\\\", \\\"{x:1341,y:858,t:1527030334402};\\\", \\\"{x:1343,y:860,t:1527030334418};\\\", \\\"{x:1349,y:861,t:1527030334434};\\\", \\\"{x:1358,y:861,t:1527030334452};\\\", \\\"{x:1375,y:861,t:1527030334469};\\\", \\\"{x:1394,y:861,t:1527030334484};\\\", \\\"{x:1419,y:861,t:1527030334502};\\\", \\\"{x:1444,y:861,t:1527030334519};\\\", \\\"{x:1470,y:862,t:1527030334535};\\\", \\\"{x:1490,y:864,t:1527030334552};\\\", \\\"{x:1515,y:864,t:1527030334569};\\\", \\\"{x:1530,y:864,t:1527030334585};\\\", \\\"{x:1544,y:864,t:1527030334602};\\\", \\\"{x:1560,y:864,t:1527030334619};\\\", \\\"{x:1577,y:863,t:1527030334636};\\\", \\\"{x:1594,y:859,t:1527030334652};\\\", \\\"{x:1608,y:855,t:1527030334669};\\\", \\\"{x:1620,y:852,t:1527030334685};\\\", \\\"{x:1634,y:848,t:1527030334702};\\\", \\\"{x:1643,y:847,t:1527030334719};\\\", \\\"{x:1653,y:844,t:1527030334736};\\\", \\\"{x:1662,y:842,t:1527030334753};\\\", \\\"{x:1676,y:839,t:1527030334769};\\\", \\\"{x:1683,y:838,t:1527030334786};\\\", \\\"{x:1687,y:838,t:1527030334803};\\\", \\\"{x:1689,y:838,t:1527030334819};\\\", \\\"{x:1693,y:836,t:1527030334836};\\\", \\\"{x:1694,y:836,t:1527030334852};\\\", \\\"{x:1695,y:836,t:1527030334870};\\\", \\\"{x:1697,y:836,t:1527030334886};\\\", \\\"{x:1697,y:835,t:1527030334903};\\\", \\\"{x:1698,y:834,t:1527030334921};\\\", \\\"{x:1697,y:834,t:1527030336586};\\\", \\\"{x:1688,y:838,t:1527030336604};\\\", \\\"{x:1675,y:842,t:1527030336621};\\\", \\\"{x:1663,y:843,t:1527030336638};\\\", \\\"{x:1651,y:844,t:1527030336654};\\\", \\\"{x:1642,y:846,t:1527030336671};\\\", \\\"{x:1635,y:846,t:1527030336688};\\\", \\\"{x:1629,y:847,t:1527030336703};\\\", \\\"{x:1625,y:848,t:1527030336721};\\\", \\\"{x:1613,y:850,t:1527030336738};\\\", \\\"{x:1603,y:851,t:1527030336754};\\\", \\\"{x:1596,y:852,t:1527030336771};\\\", \\\"{x:1588,y:854,t:1527030336787};\\\", \\\"{x:1578,y:855,t:1527030336804};\\\", \\\"{x:1567,y:856,t:1527030336821};\\\", \\\"{x:1554,y:857,t:1527030336838};\\\", \\\"{x:1545,y:860,t:1527030336855};\\\", \\\"{x:1536,y:861,t:1527030336871};\\\", \\\"{x:1526,y:861,t:1527030336887};\\\", \\\"{x:1513,y:864,t:1527030336904};\\\", \\\"{x:1502,y:866,t:1527030336921};\\\", \\\"{x:1481,y:869,t:1527030336938};\\\", \\\"{x:1467,y:870,t:1527030336954};\\\", \\\"{x:1457,y:871,t:1527030336971};\\\", \\\"{x:1443,y:871,t:1527030336988};\\\", \\\"{x:1427,y:871,t:1527030337005};\\\", \\\"{x:1411,y:873,t:1527030337020};\\\", \\\"{x:1396,y:874,t:1527030337038};\\\", \\\"{x:1381,y:877,t:1527030337055};\\\", \\\"{x:1363,y:880,t:1527030337071};\\\", \\\"{x:1353,y:881,t:1527030337088};\\\", \\\"{x:1344,y:881,t:1527030337105};\\\", \\\"{x:1338,y:883,t:1527030337121};\\\", \\\"{x:1334,y:883,t:1527030337138};\\\", \\\"{x:1332,y:883,t:1527030337157};\\\", \\\"{x:1329,y:883,t:1527030337170};\\\", \\\"{x:1324,y:883,t:1527030337187};\\\", \\\"{x:1316,y:883,t:1527030337204};\\\", \\\"{x:1309,y:883,t:1527030337220};\\\", \\\"{x:1303,y:882,t:1527030337237};\\\", \\\"{x:1296,y:879,t:1527030337254};\\\", \\\"{x:1289,y:876,t:1527030337270};\\\", \\\"{x:1288,y:875,t:1527030337287};\\\", \\\"{x:1285,y:873,t:1527030337305};\\\", \\\"{x:1284,y:871,t:1527030337320};\\\", \\\"{x:1284,y:869,t:1527030337337};\\\", \\\"{x:1282,y:867,t:1527030337355};\\\", \\\"{x:1282,y:866,t:1527030337371};\\\", \\\"{x:1282,y:864,t:1527030337387};\\\", \\\"{x:1281,y:862,t:1527030337404};\\\", \\\"{x:1281,y:860,t:1527030337422};\\\", \\\"{x:1281,y:857,t:1527030337438};\\\", \\\"{x:1281,y:856,t:1527030337455};\\\", \\\"{x:1281,y:854,t:1527030337472};\\\", \\\"{x:1281,y:852,t:1527030337488};\\\", \\\"{x:1281,y:851,t:1527030337505};\\\", \\\"{x:1281,y:850,t:1527030337522};\\\", \\\"{x:1281,y:848,t:1527030337538};\\\", \\\"{x:1281,y:847,t:1527030337555};\\\", \\\"{x:1281,y:844,t:1527030337572};\\\", \\\"{x:1281,y:843,t:1527030337587};\\\", \\\"{x:1281,y:841,t:1527030337605};\\\", \\\"{x:1281,y:839,t:1527030337621};\\\", \\\"{x:1281,y:837,t:1527030337642};\\\", \\\"{x:1281,y:835,t:1527030337660};\\\", \\\"{x:1281,y:834,t:1527030337687};\\\", \\\"{x:1281,y:832,t:1527030337704};\\\", \\\"{x:1281,y:831,t:1527030337761};\\\", \\\"{x:1282,y:830,t:1527030337978};\\\", \\\"{x:1287,y:830,t:1527030337990};\\\", \\\"{x:1310,y:830,t:1527030338005};\\\", \\\"{x:1360,y:830,t:1527030338021};\\\", \\\"{x:1424,y:830,t:1527030338038};\\\", \\\"{x:1502,y:830,t:1527030338054};\\\", \\\"{x:1569,y:830,t:1527030338071};\\\", \\\"{x:1622,y:830,t:1527030338088};\\\", \\\"{x:1656,y:830,t:1527030338104};\\\", \\\"{x:1688,y:830,t:1527030338121};\\\", \\\"{x:1700,y:830,t:1527030338138};\\\", \\\"{x:1704,y:829,t:1527030338154};\\\", \\\"{x:1706,y:827,t:1527030338171};\\\", \\\"{x:1707,y:827,t:1527030338188};\\\", \\\"{x:1709,y:825,t:1527030338204};\\\", \\\"{x:1712,y:822,t:1527030338222};\\\", \\\"{x:1713,y:822,t:1527030338257};\\\", \\\"{x:1713,y:821,t:1527030338274};\\\", \\\"{x:1713,y:822,t:1527030338418};\\\", \\\"{x:1712,y:825,t:1527030338434};\\\", \\\"{x:1712,y:826,t:1527030338441};\\\", \\\"{x:1710,y:827,t:1527030338455};\\\", \\\"{x:1706,y:829,t:1527030338472};\\\", \\\"{x:1701,y:833,t:1527030338488};\\\", \\\"{x:1698,y:834,t:1527030338506};\\\", \\\"{x:1696,y:835,t:1527030338522};\\\", \\\"{x:1695,y:836,t:1527030338539};\\\", \\\"{x:1694,y:836,t:1527030338556};\\\", \\\"{x:1693,y:836,t:1527030338586};\\\", \\\"{x:1692,y:837,t:1527030338594};\\\", \\\"{x:1691,y:837,t:1527030338618};\\\", \\\"{x:1690,y:837,t:1527030338634};\\\", \\\"{x:1689,y:837,t:1527030338650};\\\", \\\"{x:1688,y:837,t:1527030338666};\\\", \\\"{x:1687,y:837,t:1527030338754};\\\", \\\"{x:1686,y:837,t:1527030338777};\\\", \\\"{x:1685,y:837,t:1527030338792};\\\", \\\"{x:1684,y:837,t:1527030338809};\\\", \\\"{x:1683,y:837,t:1527030338825};\\\", \\\"{x:1682,y:836,t:1527030338838};\\\", \\\"{x:1682,y:835,t:1527030338857};\\\", \\\"{x:1682,y:834,t:1527030338888};\\\", \\\"{x:1682,y:833,t:1527030338905};\\\", \\\"{x:1681,y:832,t:1527030338922};\\\", \\\"{x:1681,y:831,t:1527030338994};\\\", \\\"{x:1681,y:830,t:1527030339010};\\\", \\\"{x:1679,y:830,t:1527030339834};\\\", \\\"{x:1674,y:830,t:1527030339843};\\\", \\\"{x:1665,y:832,t:1527030339857};\\\", \\\"{x:1646,y:837,t:1527030339873};\\\", \\\"{x:1614,y:842,t:1527030339890};\\\", \\\"{x:1592,y:846,t:1527030339907};\\\", \\\"{x:1571,y:846,t:1527030339923};\\\", \\\"{x:1544,y:846,t:1527030339940};\\\", \\\"{x:1522,y:846,t:1527030339957};\\\", \\\"{x:1499,y:847,t:1527030339973};\\\", \\\"{x:1477,y:849,t:1527030339990};\\\", \\\"{x:1455,y:852,t:1527030340007};\\\", \\\"{x:1439,y:852,t:1527030340023};\\\", \\\"{x:1423,y:853,t:1527030340040};\\\", \\\"{x:1408,y:853,t:1527030340057};\\\", \\\"{x:1397,y:853,t:1527030340072};\\\", \\\"{x:1389,y:853,t:1527030340090};\\\", \\\"{x:1384,y:853,t:1527030340106};\\\", \\\"{x:1380,y:853,t:1527030340123};\\\", \\\"{x:1375,y:853,t:1527030340140};\\\", \\\"{x:1369,y:853,t:1527030340157};\\\", \\\"{x:1361,y:853,t:1527030340173};\\\", \\\"{x:1346,y:853,t:1527030340190};\\\", \\\"{x:1329,y:852,t:1527030340206};\\\", \\\"{x:1311,y:851,t:1527030340223};\\\", \\\"{x:1296,y:851,t:1527030340239};\\\", \\\"{x:1283,y:849,t:1527030340256};\\\", \\\"{x:1265,y:847,t:1527030340273};\\\", \\\"{x:1259,y:846,t:1527030340289};\\\", \\\"{x:1256,y:846,t:1527030340306};\\\", \\\"{x:1254,y:845,t:1527030340323};\\\", \\\"{x:1254,y:844,t:1527030340377};\\\", \\\"{x:1254,y:843,t:1527030340393};\\\", \\\"{x:1254,y:842,t:1527030340425};\\\", \\\"{x:1256,y:841,t:1527030340441};\\\", \\\"{x:1256,y:840,t:1527030340456};\\\", \\\"{x:1262,y:839,t:1527030340473};\\\", \\\"{x:1266,y:837,t:1527030340490};\\\", \\\"{x:1268,y:836,t:1527030340507};\\\", \\\"{x:1269,y:836,t:1527030340524};\\\", \\\"{x:1271,y:836,t:1527030340578};\\\", \\\"{x:1271,y:835,t:1527030340590};\\\", \\\"{x:1273,y:834,t:1527030340607};\\\", \\\"{x:1274,y:833,t:1527030340624};\\\", \\\"{x:1276,y:832,t:1527030340640};\\\", \\\"{x:1279,y:831,t:1527030340657};\\\", \\\"{x:1279,y:830,t:1527030340673};\\\", \\\"{x:1280,y:829,t:1527030340713};\\\", \\\"{x:1282,y:827,t:1527030340738};\\\", \\\"{x:1283,y:826,t:1527030340753};\\\", \\\"{x:1284,y:826,t:1527030340769};\\\", \\\"{x:1285,y:824,t:1527030340883};\\\", \\\"{x:1287,y:826,t:1527030342650};\\\", \\\"{x:1287,y:827,t:1527030342659};\\\", \\\"{x:1287,y:828,t:1527030342681};\\\", \\\"{x:1287,y:829,t:1527030343178};\\\", \\\"{x:1287,y:828,t:1527030343225};\\\", \\\"{x:1220,y:792,t:1527030343241};\\\", \\\"{x:1118,y:752,t:1527030343258};\\\", \\\"{x:989,y:703,t:1527030343276};\\\", \\\"{x:872,y:660,t:1527030343291};\\\", \\\"{x:765,y:615,t:1527030343309};\\\", \\\"{x:703,y:587,t:1527030343326};\\\", \\\"{x:666,y:567,t:1527030343342};\\\", \\\"{x:653,y:557,t:1527030343358};\\\", \\\"{x:646,y:551,t:1527030343376};\\\", \\\"{x:641,y:545,t:1527030343393};\\\", \\\"{x:636,y:537,t:1527030343410};\\\", \\\"{x:625,y:525,t:1527030343427};\\\", \\\"{x:611,y:513,t:1527030343443};\\\", \\\"{x:596,y:500,t:1527030343460};\\\", \\\"{x:577,y:486,t:1527030343477};\\\", \\\"{x:549,y:471,t:1527030343493};\\\", \\\"{x:526,y:461,t:1527030343510};\\\", \\\"{x:509,y:456,t:1527030343527};\\\", \\\"{x:496,y:453,t:1527030343543};\\\", \\\"{x:481,y:452,t:1527030343560};\\\", \\\"{x:456,y:452,t:1527030343576};\\\", \\\"{x:446,y:452,t:1527030343594};\\\", \\\"{x:432,y:457,t:1527030343610};\\\", \\\"{x:419,y:460,t:1527030343627};\\\", \\\"{x:404,y:465,t:1527030343643};\\\", \\\"{x:396,y:469,t:1527030343660};\\\", \\\"{x:389,y:478,t:1527030343678};\\\", \\\"{x:389,y:484,t:1527030343694};\\\", \\\"{x:389,y:489,t:1527030343710};\\\", \\\"{x:391,y:493,t:1527030343728};\\\", \\\"{x:394,y:497,t:1527030343744};\\\", \\\"{x:398,y:501,t:1527030343761};\\\", \\\"{x:406,y:508,t:1527030343779};\\\", \\\"{x:411,y:511,t:1527030343793};\\\", \\\"{x:414,y:513,t:1527030343810};\\\", \\\"{x:413,y:514,t:1527030343890};\\\", \\\"{x:411,y:514,t:1527030343905};\\\", \\\"{x:409,y:515,t:1527030343913};\\\", \\\"{x:407,y:516,t:1527030343928};\\\", \\\"{x:401,y:517,t:1527030343944};\\\", \\\"{x:397,y:517,t:1527030343961};\\\", \\\"{x:394,y:520,t:1527030343978};\\\", \\\"{x:392,y:520,t:1527030343995};\\\", \\\"{x:388,y:520,t:1527030344011};\\\", \\\"{x:384,y:520,t:1527030344027};\\\", \\\"{x:382,y:521,t:1527030344045};\\\", \\\"{x:381,y:521,t:1527030344061};\\\", \\\"{x:380,y:522,t:1527030344078};\\\", \\\"{x:379,y:523,t:1527030351741};\\\", \\\"{x:381,y:531,t:1527030351753};\\\", \\\"{x:395,y:545,t:1527030351772};\\\", \\\"{x:410,y:558,t:1527030351786};\\\", \\\"{x:427,y:570,t:1527030351803};\\\", \\\"{x:449,y:582,t:1527030351820};\\\", \\\"{x:464,y:590,t:1527030351836};\\\", \\\"{x:481,y:600,t:1527030351852};\\\", \\\"{x:493,y:609,t:1527030351869};\\\", \\\"{x:511,y:620,t:1527030351887};\\\", \\\"{x:528,y:634,t:1527030351902};\\\", \\\"{x:538,y:643,t:1527030351919};\\\", \\\"{x:548,y:653,t:1527030351937};\\\", \\\"{x:558,y:668,t:1527030351954};\\\", \\\"{x:565,y:679,t:1527030351969};\\\", \\\"{x:567,y:685,t:1527030351986};\\\", \\\"{x:568,y:693,t:1527030352002};\\\", \\\"{x:569,y:701,t:1527030352019};\\\", \\\"{x:569,y:704,t:1527030352037};\\\", \\\"{x:567,y:708,t:1527030352054};\\\", \\\"{x:566,y:709,t:1527030352069};\\\", \\\"{x:563,y:711,t:1527030352088};\\\", \\\"{x:561,y:712,t:1527030352104};\\\", \\\"{x:554,y:716,t:1527030352120};\\\", \\\"{x:546,y:720,t:1527030352137};\\\", \\\"{x:540,y:720,t:1527030352154};\\\", \\\"{x:534,y:723,t:1527030352170};\\\", \\\"{x:530,y:723,t:1527030352187};\\\", \\\"{x:525,y:724,t:1527030352204};\\\", \\\"{x:525,y:725,t:1527030352220};\\\", \\\"{x:524,y:725,t:1527030352236};\\\", \\\"{x:523,y:725,t:1527030352268};\\\" ] }, { \\\"rt\\\": 8021, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 251218, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:726,t:1527030354989};\\\", \\\"{x:538,y:731,t:1527030355003};\\\", \\\"{x:564,y:736,t:1527030355022};\\\", \\\"{x:596,y:744,t:1527030355038};\\\", \\\"{x:628,y:746,t:1527030355056};\\\", \\\"{x:668,y:753,t:1527030355072};\\\", \\\"{x:704,y:757,t:1527030355089};\\\", \\\"{x:726,y:759,t:1527030355106};\\\", \\\"{x:747,y:762,t:1527030355122};\\\", \\\"{x:755,y:764,t:1527030355139};\\\", \\\"{x:760,y:766,t:1527030355156};\\\", \\\"{x:761,y:767,t:1527030355173};\\\", \\\"{x:762,y:768,t:1527030355204};\\\", \\\"{x:763,y:768,t:1527030355252};\\\", \\\"{x:764,y:768,t:1527030355620};\\\", \\\"{x:774,y:768,t:1527030355628};\\\", \\\"{x:778,y:768,t:1527030355640};\\\", \\\"{x:791,y:770,t:1527030355656};\\\", \\\"{x:828,y:779,t:1527030355674};\\\", \\\"{x:864,y:784,t:1527030355690};\\\", \\\"{x:896,y:791,t:1527030355707};\\\", \\\"{x:945,y:798,t:1527030355724};\\\", \\\"{x:977,y:803,t:1527030355740};\\\", \\\"{x:1007,y:808,t:1527030355758};\\\", \\\"{x:1036,y:810,t:1527030355774};\\\", \\\"{x:1066,y:815,t:1527030355791};\\\", \\\"{x:1093,y:815,t:1527030355807};\\\", \\\"{x:1118,y:817,t:1527030355823};\\\", \\\"{x:1142,y:817,t:1527030355840};\\\", \\\"{x:1160,y:819,t:1527030355857};\\\", \\\"{x:1182,y:819,t:1527030355873};\\\", \\\"{x:1209,y:819,t:1527030355891};\\\", \\\"{x:1246,y:819,t:1527030355906};\\\", \\\"{x:1301,y:819,t:1527030355923};\\\", \\\"{x:1335,y:819,t:1527030355941};\\\", \\\"{x:1377,y:819,t:1527030355957};\\\", \\\"{x:1422,y:819,t:1527030355974};\\\", \\\"{x:1455,y:819,t:1527030355991};\\\", \\\"{x:1470,y:813,t:1527030356008};\\\", \\\"{x:1480,y:805,t:1527030356023};\\\", \\\"{x:1483,y:800,t:1527030356041};\\\", \\\"{x:1483,y:789,t:1527030356058};\\\", \\\"{x:1481,y:776,t:1527030356074};\\\", \\\"{x:1474,y:763,t:1527030356091};\\\", \\\"{x:1459,y:743,t:1527030356108};\\\", \\\"{x:1447,y:727,t:1527030356124};\\\", \\\"{x:1439,y:718,t:1527030356141};\\\", \\\"{x:1429,y:707,t:1527030356158};\\\", \\\"{x:1420,y:699,t:1527030356176};\\\", \\\"{x:1413,y:690,t:1527030356191};\\\", \\\"{x:1408,y:683,t:1527030356208};\\\", \\\"{x:1407,y:679,t:1527030356225};\\\", \\\"{x:1404,y:672,t:1527030356241};\\\", \\\"{x:1403,y:666,t:1527030356258};\\\", \\\"{x:1400,y:659,t:1527030356275};\\\", \\\"{x:1400,y:652,t:1527030356291};\\\", \\\"{x:1398,y:637,t:1527030356307};\\\", \\\"{x:1398,y:626,t:1527030356325};\\\", \\\"{x:1398,y:616,t:1527030356342};\\\", \\\"{x:1398,y:608,t:1527030356358};\\\", \\\"{x:1398,y:602,t:1527030356375};\\\", \\\"{x:1398,y:598,t:1527030356392};\\\", \\\"{x:1398,y:595,t:1527030356408};\\\", \\\"{x:1399,y:592,t:1527030356425};\\\", \\\"{x:1400,y:590,t:1527030356442};\\\", \\\"{x:1401,y:589,t:1527030356458};\\\", \\\"{x:1403,y:589,t:1527030356476};\\\", \\\"{x:1407,y:589,t:1527030356492};\\\", \\\"{x:1414,y:589,t:1527030356509};\\\", \\\"{x:1425,y:596,t:1527030356525};\\\", \\\"{x:1436,y:607,t:1527030356543};\\\", \\\"{x:1452,y:629,t:1527030356559};\\\", \\\"{x:1475,y:670,t:1527030356575};\\\", \\\"{x:1491,y:711,t:1527030356592};\\\", \\\"{x:1510,y:750,t:1527030356609};\\\", \\\"{x:1518,y:784,t:1527030356625};\\\", \\\"{x:1522,y:814,t:1527030356642};\\\", \\\"{x:1524,y:838,t:1527030356659};\\\", \\\"{x:1524,y:857,t:1527030356675};\\\", \\\"{x:1521,y:874,t:1527030356692};\\\", \\\"{x:1518,y:882,t:1527030356708};\\\", \\\"{x:1517,y:888,t:1527030356726};\\\", \\\"{x:1512,y:896,t:1527030356742};\\\", \\\"{x:1509,y:902,t:1527030356759};\\\", \\\"{x:1507,y:907,t:1527030356776};\\\", \\\"{x:1502,y:912,t:1527030356792};\\\", \\\"{x:1499,y:917,t:1527030356809};\\\", \\\"{x:1495,y:919,t:1527030356826};\\\", \\\"{x:1492,y:921,t:1527030356842};\\\", \\\"{x:1488,y:924,t:1527030356859};\\\", \\\"{x:1484,y:927,t:1527030356877};\\\", \\\"{x:1482,y:929,t:1527030356893};\\\", \\\"{x:1480,y:931,t:1527030356909};\\\", \\\"{x:1479,y:932,t:1527030356926};\\\", \\\"{x:1478,y:934,t:1527030356948};\\\", \\\"{x:1477,y:934,t:1527030356959};\\\", \\\"{x:1476,y:935,t:1527030356977};\\\", \\\"{x:1473,y:936,t:1527030356994};\\\", \\\"{x:1471,y:936,t:1527030357009};\\\", \\\"{x:1468,y:937,t:1527030357027};\\\", \\\"{x:1465,y:937,t:1527030357043};\\\", \\\"{x:1463,y:938,t:1527030357059};\\\", \\\"{x:1459,y:938,t:1527030357076};\\\", \\\"{x:1457,y:938,t:1527030357093};\\\", \\\"{x:1456,y:938,t:1527030357110};\\\", \\\"{x:1454,y:938,t:1527030357126};\\\", \\\"{x:1453,y:938,t:1527030357143};\\\", \\\"{x:1451,y:938,t:1527030357161};\\\", \\\"{x:1450,y:937,t:1527030357176};\\\", \\\"{x:1449,y:936,t:1527030357193};\\\", \\\"{x:1449,y:932,t:1527030357210};\\\", \\\"{x:1449,y:929,t:1527030357226};\\\", \\\"{x:1452,y:924,t:1527030357243};\\\", \\\"{x:1458,y:920,t:1527030357260};\\\", \\\"{x:1461,y:917,t:1527030357276};\\\", \\\"{x:1466,y:914,t:1527030357293};\\\", \\\"{x:1469,y:912,t:1527030357310};\\\", \\\"{x:1474,y:908,t:1527030357328};\\\", \\\"{x:1481,y:903,t:1527030357343};\\\", \\\"{x:1487,y:898,t:1527030357360};\\\", \\\"{x:1496,y:891,t:1527030357377};\\\", \\\"{x:1506,y:885,t:1527030357393};\\\", \\\"{x:1516,y:876,t:1527030357411};\\\", \\\"{x:1531,y:865,t:1527030357427};\\\", \\\"{x:1541,y:856,t:1527030357444};\\\", \\\"{x:1546,y:851,t:1527030357460};\\\", \\\"{x:1549,y:848,t:1527030357477};\\\", \\\"{x:1550,y:846,t:1527030357494};\\\", \\\"{x:1551,y:845,t:1527030357510};\\\", \\\"{x:1552,y:842,t:1527030357528};\\\", \\\"{x:1553,y:839,t:1527030357544};\\\", \\\"{x:1555,y:832,t:1527030357560};\\\", \\\"{x:1555,y:826,t:1527030357578};\\\", \\\"{x:1556,y:814,t:1527030357594};\\\", \\\"{x:1556,y:806,t:1527030357610};\\\", \\\"{x:1557,y:796,t:1527030357627};\\\", \\\"{x:1560,y:781,t:1527030357643};\\\", \\\"{x:1565,y:769,t:1527030357661};\\\", \\\"{x:1567,y:761,t:1527030357677};\\\", \\\"{x:1570,y:752,t:1527030357695};\\\", \\\"{x:1575,y:742,t:1527030357711};\\\", \\\"{x:1579,y:731,t:1527030357728};\\\", \\\"{x:1585,y:711,t:1527030357744};\\\", \\\"{x:1591,y:693,t:1527030357762};\\\", \\\"{x:1596,y:672,t:1527030357777};\\\", \\\"{x:1599,y:650,t:1527030357794};\\\", \\\"{x:1602,y:632,t:1527030357811};\\\", \\\"{x:1604,y:592,t:1527030357828};\\\", \\\"{x:1604,y:569,t:1527030357844};\\\", \\\"{x:1604,y:546,t:1527030357861};\\\", \\\"{x:1598,y:525,t:1527030357878};\\\", \\\"{x:1588,y:506,t:1527030357894};\\\", \\\"{x:1579,y:492,t:1527030357912};\\\", \\\"{x:1568,y:480,t:1527030357928};\\\", \\\"{x:1557,y:466,t:1527030357944};\\\", \\\"{x:1550,y:455,t:1527030357961};\\\", \\\"{x:1544,y:447,t:1527030357979};\\\", \\\"{x:1541,y:438,t:1527030357994};\\\", \\\"{x:1538,y:429,t:1527030358012};\\\", \\\"{x:1535,y:422,t:1527030358028};\\\", \\\"{x:1535,y:418,t:1527030358046};\\\", \\\"{x:1535,y:414,t:1527030358061};\\\", \\\"{x:1536,y:408,t:1527030358078};\\\", \\\"{x:1539,y:404,t:1527030358095};\\\", \\\"{x:1541,y:402,t:1527030358111};\\\", \\\"{x:1543,y:400,t:1527030358129};\\\", \\\"{x:1546,y:400,t:1527030358145};\\\", \\\"{x:1549,y:400,t:1527030358161};\\\", \\\"{x:1552,y:400,t:1527030358179};\\\", \\\"{x:1555,y:402,t:1527030358196};\\\", \\\"{x:1558,y:404,t:1527030358212};\\\", \\\"{x:1560,y:404,t:1527030358228};\\\", \\\"{x:1561,y:405,t:1527030358244};\\\", \\\"{x:1564,y:407,t:1527030358261};\\\", \\\"{x:1566,y:408,t:1527030358278};\\\", \\\"{x:1569,y:409,t:1527030358295};\\\", \\\"{x:1575,y:410,t:1527030358311};\\\", \\\"{x:1580,y:411,t:1527030358327};\\\", \\\"{x:1590,y:411,t:1527030358345};\\\", \\\"{x:1601,y:411,t:1527030358362};\\\", \\\"{x:1611,y:411,t:1527030358378};\\\", \\\"{x:1618,y:411,t:1527030358396};\\\", \\\"{x:1627,y:412,t:1527030358412};\\\", \\\"{x:1630,y:412,t:1527030358429};\\\", \\\"{x:1631,y:412,t:1527030358460};\\\", \\\"{x:1632,y:413,t:1527030358508};\\\", \\\"{x:1632,y:414,t:1527030358573};\\\", \\\"{x:1632,y:416,t:1527030358580};\\\", \\\"{x:1632,y:420,t:1527030358596};\\\", \\\"{x:1628,y:424,t:1527030358612};\\\", \\\"{x:1627,y:426,t:1527030358629};\\\", \\\"{x:1624,y:427,t:1527030358646};\\\", \\\"{x:1623,y:428,t:1527030358662};\\\", \\\"{x:1621,y:428,t:1527030358679};\\\", \\\"{x:1620,y:429,t:1527030358699};\\\", \\\"{x:1617,y:430,t:1527030358747};\\\", \\\"{x:1616,y:431,t:1527030358803};\\\", \\\"{x:1615,y:431,t:1527030358835};\\\", \\\"{x:1614,y:431,t:1527030358867};\\\", \\\"{x:1613,y:431,t:1527030358908};\\\", \\\"{x:1613,y:434,t:1527030359060};\\\", \\\"{x:1613,y:437,t:1527030359069};\\\", \\\"{x:1613,y:441,t:1527030359080};\\\", \\\"{x:1611,y:452,t:1527030359096};\\\", \\\"{x:1611,y:465,t:1527030359113};\\\", \\\"{x:1611,y:476,t:1527030359130};\\\", \\\"{x:1612,y:487,t:1527030359147};\\\", \\\"{x:1615,y:499,t:1527030359164};\\\", \\\"{x:1617,y:521,t:1527030359180};\\\", \\\"{x:1620,y:537,t:1527030359197};\\\", \\\"{x:1621,y:549,t:1527030359213};\\\", \\\"{x:1621,y:555,t:1527030359231};\\\", \\\"{x:1621,y:557,t:1527030359248};\\\", \\\"{x:1621,y:560,t:1527030359263};\\\", \\\"{x:1617,y:561,t:1527030359281};\\\", \\\"{x:1605,y:562,t:1527030359298};\\\", \\\"{x:1582,y:566,t:1527030359313};\\\", \\\"{x:1546,y:567,t:1527030359331};\\\", \\\"{x:1496,y:567,t:1527030359348};\\\", \\\"{x:1349,y:567,t:1527030359364};\\\", \\\"{x:1213,y:567,t:1527030359380};\\\", \\\"{x:1055,y:569,t:1527030359397};\\\", \\\"{x:900,y:568,t:1527030359416};\\\", \\\"{x:792,y:568,t:1527030359429};\\\", \\\"{x:714,y:578,t:1527030359447};\\\", \\\"{x:687,y:584,t:1527030359460};\\\", \\\"{x:634,y:597,t:1527030359476};\\\", \\\"{x:610,y:609,t:1527030359493};\\\", \\\"{x:586,y:621,t:1527030359510};\\\", \\\"{x:561,y:636,t:1527030359525};\\\", \\\"{x:536,y:652,t:1527030359543};\\\", \\\"{x:513,y:666,t:1527030359558};\\\", \\\"{x:486,y:678,t:1527030359576};\\\", \\\"{x:453,y:686,t:1527030359591};\\\", \\\"{x:423,y:698,t:1527030359608};\\\", \\\"{x:385,y:712,t:1527030359626};\\\", \\\"{x:360,y:723,t:1527030359642};\\\", \\\"{x:345,y:727,t:1527030359659};\\\", \\\"{x:338,y:728,t:1527030359675};\\\", \\\"{x:332,y:728,t:1527030359692};\\\", \\\"{x:327,y:724,t:1527030359709};\\\", \\\"{x:325,y:715,t:1527030359726};\\\", \\\"{x:327,y:706,t:1527030359742};\\\", \\\"{x:341,y:694,t:1527030359759};\\\", \\\"{x:351,y:682,t:1527030359776};\\\", \\\"{x:364,y:668,t:1527030359792};\\\", \\\"{x:380,y:651,t:1527030359809};\\\", \\\"{x:396,y:637,t:1527030359827};\\\", \\\"{x:406,y:622,t:1527030359842};\\\", \\\"{x:410,y:611,t:1527030359860};\\\", \\\"{x:410,y:606,t:1527030359876};\\\", \\\"{x:409,y:602,t:1527030359892};\\\", \\\"{x:405,y:594,t:1527030359908};\\\", \\\"{x:400,y:586,t:1527030359925};\\\", \\\"{x:395,y:580,t:1527030359943};\\\", \\\"{x:391,y:574,t:1527030359959};\\\", \\\"{x:388,y:569,t:1527030359976};\\\", \\\"{x:387,y:567,t:1527030359992};\\\", \\\"{x:387,y:565,t:1527030360010};\\\", \\\"{x:386,y:565,t:1527030360026};\\\", \\\"{x:385,y:565,t:1527030360083};\\\", \\\"{x:384,y:565,t:1527030360099};\\\", \\\"{x:383,y:567,t:1527030360110};\\\", \\\"{x:377,y:574,t:1527030360127};\\\", \\\"{x:371,y:582,t:1527030360144};\\\", \\\"{x:360,y:586,t:1527030360159};\\\", \\\"{x:348,y:590,t:1527030360176};\\\", \\\"{x:334,y:594,t:1527030360192};\\\", \\\"{x:316,y:600,t:1527030360209};\\\", \\\"{x:296,y:605,t:1527030360225};\\\", \\\"{x:281,y:606,t:1527030360241};\\\", \\\"{x:272,y:607,t:1527030360260};\\\", \\\"{x:264,y:607,t:1527030360275};\\\", \\\"{x:260,y:608,t:1527030360292};\\\", \\\"{x:256,y:608,t:1527030360310};\\\", \\\"{x:253,y:610,t:1527030360327};\\\", \\\"{x:251,y:610,t:1527030360343};\\\", \\\"{x:248,y:612,t:1527030360360};\\\", \\\"{x:245,y:613,t:1527030360377};\\\", \\\"{x:237,y:616,t:1527030360394};\\\", \\\"{x:229,y:618,t:1527030360410};\\\", \\\"{x:224,y:621,t:1527030360428};\\\", \\\"{x:220,y:624,t:1527030360443};\\\", \\\"{x:210,y:626,t:1527030360459};\\\", \\\"{x:202,y:631,t:1527030360476};\\\", \\\"{x:193,y:634,t:1527030360493};\\\", \\\"{x:185,y:639,t:1527030360510};\\\", \\\"{x:178,y:641,t:1527030360526};\\\", \\\"{x:173,y:642,t:1527030360543};\\\", \\\"{x:169,y:643,t:1527030360560};\\\", \\\"{x:167,y:643,t:1527030360577};\\\", \\\"{x:166,y:643,t:1527030360593};\\\", \\\"{x:165,y:643,t:1527030360610};\\\", \\\"{x:163,y:643,t:1527030360636};\\\", \\\"{x:162,y:643,t:1527030360652};\\\", \\\"{x:161,y:643,t:1527030360667};\\\", \\\"{x:160,y:642,t:1527030360677};\\\", \\\"{x:159,y:642,t:1527030360693};\\\", \\\"{x:166,y:642,t:1527030360915};\\\", \\\"{x:177,y:643,t:1527030360927};\\\", \\\"{x:203,y:646,t:1527030360944};\\\", \\\"{x:227,y:648,t:1527030360959};\\\", \\\"{x:251,y:654,t:1527030360977};\\\", \\\"{x:285,y:660,t:1527030360993};\\\", \\\"{x:312,y:667,t:1527030361009};\\\", \\\"{x:343,y:674,t:1527030361027};\\\", \\\"{x:383,y:683,t:1527030361043};\\\", \\\"{x:409,y:688,t:1527030361060};\\\", \\\"{x:430,y:695,t:1527030361077};\\\", \\\"{x:446,y:699,t:1527030361093};\\\", \\\"{x:459,y:702,t:1527030361110};\\\", \\\"{x:467,y:705,t:1527030361126};\\\", \\\"{x:474,y:706,t:1527030361143};\\\", \\\"{x:479,y:708,t:1527030361160};\\\", \\\"{x:482,y:709,t:1527030361177};\\\", \\\"{x:488,y:710,t:1527030361194};\\\", \\\"{x:492,y:712,t:1527030361210};\\\", \\\"{x:498,y:713,t:1527030361226};\\\", \\\"{x:503,y:713,t:1527030361243};\\\", \\\"{x:505,y:713,t:1527030361331};\\\", \\\"{x:506,y:714,t:1527030362628};\\\", \\\"{x:511,y:717,t:1527030362645};\\\", \\\"{x:518,y:720,t:1527030362662};\\\", \\\"{x:528,y:724,t:1527030362679};\\\", \\\"{x:541,y:727,t:1527030362695};\\\", \\\"{x:557,y:730,t:1527030362712};\\\", \\\"{x:578,y:731,t:1527030362728};\\\", \\\"{x:600,y:736,t:1527030362745};\\\", \\\"{x:617,y:738,t:1527030362762};\\\", \\\"{x:627,y:740,t:1527030362778};\\\", \\\"{x:635,y:741,t:1527030362795};\\\", \\\"{x:637,y:741,t:1527030362812};\\\", \\\"{x:638,y:741,t:1527030362836};\\\" ] }, { \\\"rt\\\": 22309, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 274854, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -C -A -A -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:638,y:737,t:1527030363987};\\\", \\\"{x:637,y:733,t:1527030363995};\\\", \\\"{x:637,y:728,t:1527030364012};\\\", \\\"{x:637,y:723,t:1527030364029};\\\", \\\"{x:637,y:718,t:1527030364046};\\\", \\\"{x:642,y:711,t:1527030364063};\\\", \\\"{x:645,y:709,t:1527030364079};\\\", \\\"{x:654,y:704,t:1527030364096};\\\", \\\"{x:667,y:699,t:1527030364113};\\\", \\\"{x:686,y:699,t:1527030364129};\\\", \\\"{x:711,y:699,t:1527030364146};\\\", \\\"{x:733,y:699,t:1527030364163};\\\", \\\"{x:751,y:702,t:1527030364179};\\\", \\\"{x:774,y:709,t:1527030364196};\\\", \\\"{x:777,y:710,t:1527030364213};\\\", \\\"{x:778,y:711,t:1527030364229};\\\", \\\"{x:786,y:711,t:1527030364612};\\\", \\\"{x:808,y:711,t:1527030364630};\\\", \\\"{x:823,y:716,t:1527030364647};\\\", \\\"{x:846,y:719,t:1527030364663};\\\", \\\"{x:866,y:721,t:1527030364681};\\\", \\\"{x:878,y:724,t:1527030364696};\\\", \\\"{x:893,y:724,t:1527030364714};\\\", \\\"{x:910,y:726,t:1527030364730};\\\", \\\"{x:930,y:729,t:1527030364746};\\\", \\\"{x:967,y:733,t:1527030364763};\\\", \\\"{x:1001,y:739,t:1527030364779};\\\", \\\"{x:1046,y:745,t:1527030364796};\\\", \\\"{x:1079,y:749,t:1527030364813};\\\", \\\"{x:1110,y:751,t:1527030364830};\\\", \\\"{x:1139,y:755,t:1527030364846};\\\", \\\"{x:1166,y:758,t:1527030364863};\\\", \\\"{x:1200,y:763,t:1527030364880};\\\", \\\"{x:1230,y:768,t:1527030364896};\\\", \\\"{x:1253,y:770,t:1527030364913};\\\", \\\"{x:1276,y:773,t:1527030364930};\\\", \\\"{x:1300,y:776,t:1527030364946};\\\", \\\"{x:1320,y:776,t:1527030364964};\\\", \\\"{x:1365,y:778,t:1527030364980};\\\", \\\"{x:1404,y:778,t:1527030364996};\\\", \\\"{x:1437,y:779,t:1527030365014};\\\", \\\"{x:1457,y:779,t:1527030365031};\\\", \\\"{x:1471,y:779,t:1527030365047};\\\", \\\"{x:1488,y:781,t:1527030365064};\\\", \\\"{x:1508,y:786,t:1527030365081};\\\", \\\"{x:1523,y:787,t:1527030365097};\\\", \\\"{x:1536,y:791,t:1527030365114};\\\", \\\"{x:1546,y:794,t:1527030365130};\\\", \\\"{x:1549,y:794,t:1527030365148};\\\", \\\"{x:1550,y:794,t:1527030365163};\\\", \\\"{x:1551,y:795,t:1527030365180};\\\", \\\"{x:1553,y:796,t:1527030365197};\\\", \\\"{x:1554,y:797,t:1527030365213};\\\", \\\"{x:1557,y:798,t:1527030365230};\\\", \\\"{x:1561,y:804,t:1527030365248};\\\", \\\"{x:1568,y:814,t:1527030365264};\\\", \\\"{x:1576,y:824,t:1527030365281};\\\", \\\"{x:1583,y:834,t:1527030365298};\\\", \\\"{x:1590,y:845,t:1527030365314};\\\", \\\"{x:1597,y:854,t:1527030365331};\\\", \\\"{x:1609,y:869,t:1527030365347};\\\", \\\"{x:1613,y:874,t:1527030365364};\\\", \\\"{x:1618,y:879,t:1527030365380};\\\", \\\"{x:1619,y:881,t:1527030365398};\\\", \\\"{x:1619,y:883,t:1527030365413};\\\", \\\"{x:1621,y:885,t:1527030365431};\\\", \\\"{x:1621,y:887,t:1527030365448};\\\", \\\"{x:1622,y:890,t:1527030365465};\\\", \\\"{x:1623,y:891,t:1527030365480};\\\", \\\"{x:1623,y:893,t:1527030365498};\\\", \\\"{x:1623,y:894,t:1527030365515};\\\", \\\"{x:1623,y:895,t:1527030365530};\\\", \\\"{x:1621,y:895,t:1527030365548};\\\", \\\"{x:1618,y:895,t:1527030365564};\\\", \\\"{x:1616,y:895,t:1527030365580};\\\", \\\"{x:1612,y:895,t:1527030365597};\\\", \\\"{x:1611,y:895,t:1527030365614};\\\", \\\"{x:1608,y:896,t:1527030365631};\\\", \\\"{x:1606,y:896,t:1527030365648};\\\", \\\"{x:1604,y:896,t:1527030365665};\\\", \\\"{x:1602,y:896,t:1527030365681};\\\", \\\"{x:1598,y:896,t:1527030365698};\\\", \\\"{x:1597,y:896,t:1527030365715};\\\", \\\"{x:1594,y:895,t:1527030365730};\\\", \\\"{x:1587,y:892,t:1527030365748};\\\", \\\"{x:1578,y:887,t:1527030365764};\\\", \\\"{x:1571,y:885,t:1527030365781};\\\", \\\"{x:1565,y:883,t:1527030365798};\\\", \\\"{x:1560,y:881,t:1527030365815};\\\", \\\"{x:1557,y:879,t:1527030365831};\\\", \\\"{x:1554,y:877,t:1527030365847};\\\", \\\"{x:1553,y:877,t:1527030365868};\\\", \\\"{x:1552,y:876,t:1527030365884};\\\", \\\"{x:1552,y:875,t:1527030365900};\\\", \\\"{x:1550,y:875,t:1527030365916};\\\", \\\"{x:1550,y:874,t:1527030365931};\\\", \\\"{x:1549,y:874,t:1527030365947};\\\", \\\"{x:1548,y:874,t:1527030365965};\\\", \\\"{x:1547,y:873,t:1527030366021};\\\", \\\"{x:1546,y:873,t:1527030366036};\\\", \\\"{x:1545,y:873,t:1527030366060};\\\", \\\"{x:1544,y:872,t:1527030366068};\\\", \\\"{x:1544,y:871,t:1527030366081};\\\", \\\"{x:1543,y:871,t:1527030366100};\\\", \\\"{x:1543,y:870,t:1527030366116};\\\", \\\"{x:1542,y:870,t:1527030366132};\\\", \\\"{x:1541,y:868,t:1527030366148};\\\", \\\"{x:1540,y:868,t:1527030366172};\\\", \\\"{x:1540,y:864,t:1527030366619};\\\", \\\"{x:1540,y:861,t:1527030366631};\\\", \\\"{x:1540,y:858,t:1527030366648};\\\", \\\"{x:1541,y:856,t:1527030366667};\\\", \\\"{x:1541,y:855,t:1527030366684};\\\", \\\"{x:1541,y:854,t:1527030366698};\\\", \\\"{x:1541,y:853,t:1527030366715};\\\", \\\"{x:1542,y:852,t:1527030366731};\\\", \\\"{x:1542,y:851,t:1527030368573};\\\", \\\"{x:1542,y:850,t:1527030368636};\\\", \\\"{x:1541,y:849,t:1527030369428};\\\", \\\"{x:1540,y:849,t:1527030369436};\\\", \\\"{x:1539,y:849,t:1527030369452};\\\", \\\"{x:1536,y:849,t:1527030369467};\\\", \\\"{x:1530,y:849,t:1527030369484};\\\", \\\"{x:1526,y:849,t:1527030369500};\\\", \\\"{x:1524,y:849,t:1527030369517};\\\", \\\"{x:1519,y:850,t:1527030369534};\\\", \\\"{x:1516,y:850,t:1527030369550};\\\", \\\"{x:1509,y:850,t:1527030369567};\\\", \\\"{x:1504,y:851,t:1527030369583};\\\", \\\"{x:1496,y:853,t:1527030369601};\\\", \\\"{x:1485,y:854,t:1527030369617};\\\", \\\"{x:1474,y:856,t:1527030369634};\\\", \\\"{x:1465,y:857,t:1527030369651};\\\", \\\"{x:1454,y:857,t:1527030369666};\\\", \\\"{x:1440,y:857,t:1527030369684};\\\", \\\"{x:1432,y:857,t:1527030369701};\\\", \\\"{x:1426,y:857,t:1527030369717};\\\", \\\"{x:1419,y:858,t:1527030369734};\\\", \\\"{x:1413,y:858,t:1527030369751};\\\", \\\"{x:1408,y:860,t:1527030369767};\\\", \\\"{x:1403,y:861,t:1527030369784};\\\", \\\"{x:1399,y:861,t:1527030369800};\\\", \\\"{x:1396,y:861,t:1527030369817};\\\", \\\"{x:1392,y:862,t:1527030369834};\\\", \\\"{x:1389,y:862,t:1527030369851};\\\", \\\"{x:1387,y:864,t:1527030369867};\\\", \\\"{x:1386,y:864,t:1527030369883};\\\", \\\"{x:1385,y:864,t:1527030369901};\\\", \\\"{x:1383,y:864,t:1527030369917};\\\", \\\"{x:1381,y:864,t:1527030369934};\\\", \\\"{x:1377,y:864,t:1527030369950};\\\", \\\"{x:1375,y:865,t:1527030369968};\\\", \\\"{x:1370,y:865,t:1527030369984};\\\", \\\"{x:1365,y:866,t:1527030370001};\\\", \\\"{x:1359,y:866,t:1527030370017};\\\", \\\"{x:1354,y:866,t:1527030370034};\\\", \\\"{x:1348,y:866,t:1527030370050};\\\", \\\"{x:1340,y:866,t:1527030370068};\\\", \\\"{x:1335,y:866,t:1527030370084};\\\", \\\"{x:1332,y:866,t:1527030370101};\\\", \\\"{x:1330,y:866,t:1527030370118};\\\", \\\"{x:1329,y:866,t:1527030370134};\\\", \\\"{x:1328,y:866,t:1527030370151};\\\", \\\"{x:1327,y:866,t:1527030370219};\\\", \\\"{x:1328,y:867,t:1527030370275};\\\", \\\"{x:1330,y:867,t:1527030370284};\\\", \\\"{x:1333,y:866,t:1527030370301};\\\", \\\"{x:1339,y:864,t:1527030370317};\\\", \\\"{x:1345,y:863,t:1527030370334};\\\", \\\"{x:1354,y:859,t:1527030370350};\\\", \\\"{x:1367,y:856,t:1527030370367};\\\", \\\"{x:1379,y:851,t:1527030370384};\\\", \\\"{x:1392,y:843,t:1527030370401};\\\", \\\"{x:1409,y:830,t:1527030370417};\\\", \\\"{x:1427,y:813,t:1527030370435};\\\", \\\"{x:1455,y:781,t:1527030370450};\\\", \\\"{x:1483,y:744,t:1527030370468};\\\", \\\"{x:1493,y:730,t:1527030370484};\\\", \\\"{x:1495,y:721,t:1527030370502};\\\", \\\"{x:1498,y:711,t:1527030370518};\\\", \\\"{x:1500,y:699,t:1527030370535};\\\", \\\"{x:1500,y:692,t:1527030370551};\\\", \\\"{x:1500,y:682,t:1527030370568};\\\", \\\"{x:1499,y:672,t:1527030370585};\\\", \\\"{x:1499,y:668,t:1527030370601};\\\", \\\"{x:1499,y:666,t:1527030370618};\\\", \\\"{x:1498,y:666,t:1527030370634};\\\", \\\"{x:1496,y:664,t:1527030370651};\\\", \\\"{x:1487,y:664,t:1527030370668};\\\", \\\"{x:1486,y:664,t:1527030370684};\\\", \\\"{x:1485,y:664,t:1527030370716};\\\", \\\"{x:1492,y:666,t:1527030371197};\\\", \\\"{x:1506,y:672,t:1527030371204};\\\", \\\"{x:1515,y:676,t:1527030371218};\\\", \\\"{x:1534,y:683,t:1527030371235};\\\", \\\"{x:1558,y:695,t:1527030371252};\\\", \\\"{x:1570,y:701,t:1527030371268};\\\", \\\"{x:1579,y:706,t:1527030371285};\\\", \\\"{x:1584,y:710,t:1527030371301};\\\", \\\"{x:1586,y:712,t:1527030371319};\\\", \\\"{x:1586,y:717,t:1527030371335};\\\", \\\"{x:1586,y:722,t:1527030371352};\\\", \\\"{x:1578,y:737,t:1527030371369};\\\", \\\"{x:1563,y:755,t:1527030371385};\\\", \\\"{x:1544,y:772,t:1527030371402};\\\", \\\"{x:1521,y:787,t:1527030371419};\\\", \\\"{x:1496,y:797,t:1527030371435};\\\", \\\"{x:1459,y:810,t:1527030371452};\\\", \\\"{x:1436,y:820,t:1527030371468};\\\", \\\"{x:1416,y:828,t:1527030371485};\\\", \\\"{x:1401,y:835,t:1527030371502};\\\", \\\"{x:1391,y:839,t:1527030371519};\\\", \\\"{x:1386,y:842,t:1527030371535};\\\", \\\"{x:1383,y:843,t:1527030371552};\\\", \\\"{x:1380,y:845,t:1527030371569};\\\", \\\"{x:1379,y:846,t:1527030371585};\\\", \\\"{x:1376,y:847,t:1527030371602};\\\", \\\"{x:1372,y:848,t:1527030371619};\\\", \\\"{x:1368,y:849,t:1527030371635};\\\", \\\"{x:1360,y:850,t:1527030371652};\\\", \\\"{x:1356,y:850,t:1527030371669};\\\", \\\"{x:1351,y:850,t:1527030371685};\\\", \\\"{x:1342,y:850,t:1527030371702};\\\", \\\"{x:1334,y:850,t:1527030371719};\\\", \\\"{x:1325,y:849,t:1527030371736};\\\", \\\"{x:1316,y:848,t:1527030371752};\\\", \\\"{x:1307,y:846,t:1527030371769};\\\", \\\"{x:1298,y:843,t:1527030371786};\\\", \\\"{x:1288,y:838,t:1527030371802};\\\", \\\"{x:1278,y:835,t:1527030371819};\\\", \\\"{x:1270,y:831,t:1527030371836};\\\", \\\"{x:1266,y:829,t:1527030371852};\\\", \\\"{x:1264,y:829,t:1527030371869};\\\", \\\"{x:1260,y:827,t:1527030371886};\\\", \\\"{x:1259,y:827,t:1527030371924};\\\", \\\"{x:1257,y:827,t:1527030371940};\\\", \\\"{x:1256,y:827,t:1527030371956};\\\", \\\"{x:1254,y:827,t:1527030371969};\\\", \\\"{x:1251,y:829,t:1527030371986};\\\", \\\"{x:1248,y:831,t:1527030372002};\\\", \\\"{x:1247,y:832,t:1527030372018};\\\", \\\"{x:1245,y:834,t:1527030372035};\\\", \\\"{x:1244,y:835,t:1527030372059};\\\", \\\"{x:1243,y:835,t:1527030372091};\\\", \\\"{x:1242,y:836,t:1527030372101};\\\", \\\"{x:1241,y:837,t:1527030372118};\\\", \\\"{x:1239,y:838,t:1527030372135};\\\", \\\"{x:1235,y:839,t:1527030372151};\\\", \\\"{x:1234,y:840,t:1527030372169};\\\", \\\"{x:1232,y:840,t:1527030372185};\\\", \\\"{x:1230,y:840,t:1527030372201};\\\", \\\"{x:1229,y:840,t:1527030372219};\\\", \\\"{x:1223,y:840,t:1527030372236};\\\", \\\"{x:1218,y:840,t:1527030372253};\\\", \\\"{x:1213,y:840,t:1527030372269};\\\", \\\"{x:1211,y:840,t:1527030372286};\\\", \\\"{x:1210,y:839,t:1527030372303};\\\", \\\"{x:1209,y:839,t:1527030372319};\\\", \\\"{x:1209,y:838,t:1527030372336};\\\", \\\"{x:1208,y:836,t:1527030372353};\\\", \\\"{x:1208,y:835,t:1527030372380};\\\", \\\"{x:1208,y:834,t:1527030372396};\\\", \\\"{x:1208,y:833,t:1527030372445};\\\", \\\"{x:1208,y:831,t:1527030372460};\\\", \\\"{x:1209,y:830,t:1527030372502};\\\", \\\"{x:1211,y:830,t:1527030373475};\\\", \\\"{x:1212,y:830,t:1527030373507};\\\", \\\"{x:1214,y:830,t:1527030373519};\\\", \\\"{x:1215,y:830,t:1527030373546};\\\", \\\"{x:1216,y:830,t:1527030373562};\\\", \\\"{x:1217,y:830,t:1527030373595};\\\", \\\"{x:1216,y:830,t:1527030373915};\\\", \\\"{x:1215,y:830,t:1527030373931};\\\", \\\"{x:1214,y:830,t:1527030373955};\\\", \\\"{x:1213,y:830,t:1527030373971};\\\", \\\"{x:1212,y:830,t:1527030373986};\\\", \\\"{x:1211,y:830,t:1527030374107};\\\", \\\"{x:1211,y:829,t:1527030375132};\\\", \\\"{x:1215,y:829,t:1527030375148};\\\", \\\"{x:1216,y:829,t:1527030375155};\\\", \\\"{x:1217,y:829,t:1527030375171};\\\", \\\"{x:1219,y:829,t:1527030375188};\\\", \\\"{x:1220,y:829,t:1527030375331};\\\", \\\"{x:1221,y:829,t:1527030375347};\\\", \\\"{x:1222,y:829,t:1527030375363};\\\", \\\"{x:1224,y:829,t:1527030375380};\\\", \\\"{x:1226,y:829,t:1527030375387};\\\", \\\"{x:1228,y:829,t:1527030375405};\\\", \\\"{x:1231,y:829,t:1527030375421};\\\", \\\"{x:1234,y:829,t:1527030375437};\\\", \\\"{x:1236,y:829,t:1527030375455};\\\", \\\"{x:1239,y:829,t:1527030375471};\\\", \\\"{x:1241,y:830,t:1527030375500};\\\", \\\"{x:1242,y:830,t:1527030375524};\\\", \\\"{x:1243,y:830,t:1527030375540};\\\", \\\"{x:1245,y:830,t:1527030375684};\\\", \\\"{x:1246,y:830,t:1527030375700};\\\", \\\"{x:1247,y:830,t:1527030375724};\\\", \\\"{x:1248,y:830,t:1527030375748};\\\", \\\"{x:1249,y:830,t:1527030375772};\\\", \\\"{x:1250,y:830,t:1527030375788};\\\", \\\"{x:1251,y:830,t:1527030375812};\\\", \\\"{x:1253,y:830,t:1527030375901};\\\", \\\"{x:1254,y:830,t:1527030375916};\\\", \\\"{x:1255,y:830,t:1527030375931};\\\", \\\"{x:1256,y:830,t:1527030375940};\\\", \\\"{x:1257,y:830,t:1527030375956};\\\", \\\"{x:1260,y:830,t:1527030375972};\\\", \\\"{x:1261,y:830,t:1527030375988};\\\", \\\"{x:1263,y:830,t:1527030376005};\\\", \\\"{x:1265,y:830,t:1527030376022};\\\", \\\"{x:1267,y:830,t:1527030376039};\\\", \\\"{x:1268,y:830,t:1527030376055};\\\", \\\"{x:1269,y:830,t:1527030376072};\\\", \\\"{x:1270,y:830,t:1527030376088};\\\", \\\"{x:1271,y:829,t:1527030376196};\\\", \\\"{x:1271,y:828,t:1527030376236};\\\", \\\"{x:1272,y:828,t:1527030376252};\\\", \\\"{x:1273,y:828,t:1527030376276};\\\", \\\"{x:1273,y:827,t:1527030376316};\\\", \\\"{x:1274,y:828,t:1527030376620};\\\", \\\"{x:1275,y:828,t:1527030376635};\\\", \\\"{x:1276,y:828,t:1527030376645};\\\", \\\"{x:1276,y:829,t:1527030376672};\\\", \\\"{x:1276,y:830,t:1527030377108};\\\", \\\"{x:1276,y:831,t:1527030377164};\\\", \\\"{x:1276,y:832,t:1527030377187};\\\", \\\"{x:1275,y:832,t:1527030377230};\\\", \\\"{x:1274,y:832,t:1527030377252};\\\", \\\"{x:1274,y:833,t:1527030377260};\\\", \\\"{x:1273,y:833,t:1527030377273};\\\", \\\"{x:1272,y:833,t:1527030377291};\\\", \\\"{x:1271,y:833,t:1527030377306};\\\", \\\"{x:1270,y:834,t:1527030377323};\\\", \\\"{x:1269,y:834,t:1527030377339};\\\", \\\"{x:1266,y:834,t:1527030377356};\\\", \\\"{x:1263,y:835,t:1527030377373};\\\", \\\"{x:1259,y:835,t:1527030377389};\\\", \\\"{x:1257,y:835,t:1527030377407};\\\", \\\"{x:1255,y:835,t:1527030377424};\\\", \\\"{x:1252,y:836,t:1527030377439};\\\", \\\"{x:1250,y:837,t:1527030377457};\\\", \\\"{x:1244,y:838,t:1527030377473};\\\", \\\"{x:1241,y:838,t:1527030377490};\\\", \\\"{x:1239,y:838,t:1527030377506};\\\", \\\"{x:1234,y:838,t:1527030377524};\\\", \\\"{x:1229,y:838,t:1527030377539};\\\", \\\"{x:1227,y:839,t:1527030377556};\\\", \\\"{x:1225,y:839,t:1527030377573};\\\", \\\"{x:1222,y:839,t:1527030377590};\\\", \\\"{x:1219,y:839,t:1527030377607};\\\", \\\"{x:1217,y:840,t:1527030377626};\\\", \\\"{x:1216,y:840,t:1527030377639};\\\", \\\"{x:1214,y:840,t:1527030377656};\\\", \\\"{x:1213,y:840,t:1527030377672};\\\", \\\"{x:1212,y:840,t:1527030377691};\\\", \\\"{x:1210,y:840,t:1527030377705};\\\", \\\"{x:1208,y:840,t:1527030377722};\\\", \\\"{x:1204,y:840,t:1527030377739};\\\", \\\"{x:1203,y:840,t:1527030377756};\\\", \\\"{x:1201,y:840,t:1527030377772};\\\", \\\"{x:1200,y:840,t:1527030377790};\\\", \\\"{x:1198,y:839,t:1527030377861};\\\", \\\"{x:1197,y:838,t:1527030377884};\\\", \\\"{x:1197,y:837,t:1527030377988};\\\", \\\"{x:1197,y:836,t:1527030378012};\\\", \\\"{x:1197,y:834,t:1527030378036};\\\", \\\"{x:1198,y:833,t:1527030378100};\\\", \\\"{x:1199,y:833,t:1527030378148};\\\", \\\"{x:1200,y:833,t:1527030378157};\\\", \\\"{x:1203,y:833,t:1527030378173};\\\", \\\"{x:1206,y:832,t:1527030378190};\\\", \\\"{x:1207,y:832,t:1527030378207};\\\", \\\"{x:1208,y:832,t:1527030378223};\\\", \\\"{x:1209,y:832,t:1527030378240};\\\", \\\"{x:1209,y:831,t:1527030378257};\\\", \\\"{x:1210,y:831,t:1527030378292};\\\", \\\"{x:1211,y:831,t:1527030378308};\\\", \\\"{x:1212,y:831,t:1527030378324};\\\", \\\"{x:1216,y:831,t:1527030378500};\\\", \\\"{x:1219,y:831,t:1527030378508};\\\", \\\"{x:1223,y:831,t:1527030378524};\\\", \\\"{x:1232,y:831,t:1527030378540};\\\", \\\"{x:1242,y:831,t:1527030378557};\\\", \\\"{x:1249,y:831,t:1527030378574};\\\", \\\"{x:1254,y:831,t:1527030378590};\\\", \\\"{x:1256,y:831,t:1527030378608};\\\", \\\"{x:1257,y:831,t:1527030378685};\\\", \\\"{x:1259,y:831,t:1527030378692};\\\", \\\"{x:1260,y:831,t:1527030378707};\\\", \\\"{x:1265,y:830,t:1527030378724};\\\", \\\"{x:1269,y:830,t:1527030378740};\\\", \\\"{x:1272,y:828,t:1527030378758};\\\", \\\"{x:1276,y:828,t:1527030378775};\\\", \\\"{x:1279,y:828,t:1527030378790};\\\", \\\"{x:1283,y:827,t:1527030378807};\\\", \\\"{x:1284,y:827,t:1527030378824};\\\", \\\"{x:1286,y:827,t:1527030378840};\\\", \\\"{x:1289,y:826,t:1527030378859};\\\", \\\"{x:1290,y:826,t:1527030378875};\\\", \\\"{x:1292,y:825,t:1527030378891};\\\", \\\"{x:1291,y:825,t:1527030379397};\\\", \\\"{x:1290,y:825,t:1527030379452};\\\", \\\"{x:1288,y:826,t:1527030379484};\\\", \\\"{x:1287,y:826,t:1527030379500};\\\", \\\"{x:1287,y:827,t:1527030379508};\\\", \\\"{x:1285,y:828,t:1527030379524};\\\", \\\"{x:1283,y:828,t:1527030379541};\\\", \\\"{x:1281,y:829,t:1527030379558};\\\", \\\"{x:1279,y:830,t:1527030379574};\\\", \\\"{x:1278,y:830,t:1527030379620};\\\", \\\"{x:1277,y:830,t:1527030379645};\\\", \\\"{x:1278,y:830,t:1527030380012};\\\", \\\"{x:1281,y:830,t:1527030380025};\\\", \\\"{x:1284,y:830,t:1527030380041};\\\", \\\"{x:1288,y:831,t:1527030380060};\\\", \\\"{x:1290,y:831,t:1527030380075};\\\", \\\"{x:1292,y:831,t:1527030380091};\\\", \\\"{x:1293,y:831,t:1527030380108};\\\", \\\"{x:1295,y:831,t:1527030380125};\\\", \\\"{x:1296,y:831,t:1527030380142};\\\", \\\"{x:1301,y:831,t:1527030380158};\\\", \\\"{x:1309,y:830,t:1527030380175};\\\", \\\"{x:1317,y:830,t:1527030380191};\\\", \\\"{x:1323,y:830,t:1527030380208};\\\", \\\"{x:1329,y:829,t:1527030380226};\\\", \\\"{x:1332,y:829,t:1527030380241};\\\", \\\"{x:1333,y:829,t:1527030380258};\\\", \\\"{x:1334,y:829,t:1527030380275};\\\", \\\"{x:1335,y:829,t:1527030380291};\\\", \\\"{x:1336,y:829,t:1527030380309};\\\", \\\"{x:1337,y:829,t:1527030380326};\\\", \\\"{x:1339,y:829,t:1527030380342};\\\", \\\"{x:1341,y:829,t:1527030380388};\\\", \\\"{x:1343,y:829,t:1527030380477};\\\", \\\"{x:1345,y:829,t:1527030380491};\\\", \\\"{x:1348,y:829,t:1527030380509};\\\", \\\"{x:1349,y:829,t:1527030380526};\\\", \\\"{x:1351,y:829,t:1527030380542};\\\", \\\"{x:1352,y:829,t:1527030380559};\\\", \\\"{x:1352,y:828,t:1527030380604};\\\", \\\"{x:1351,y:829,t:1527030380957};\\\", \\\"{x:1350,y:830,t:1527030381005};\\\", \\\"{x:1349,y:831,t:1527030381053};\\\", \\\"{x:1349,y:832,t:1527030381068};\\\", \\\"{x:1349,y:833,t:1527030381076};\\\", \\\"{x:1349,y:834,t:1527030381101};\\\", \\\"{x:1349,y:835,t:1527030381109};\\\", \\\"{x:1349,y:836,t:1527030381125};\\\", \\\"{x:1349,y:838,t:1527030381143};\\\", \\\"{x:1348,y:839,t:1527030381159};\\\", \\\"{x:1348,y:840,t:1527030381188};\\\", \\\"{x:1348,y:841,t:1527030381196};\\\", \\\"{x:1348,y:842,t:1527030381210};\\\", \\\"{x:1348,y:843,t:1527030381225};\\\", \\\"{x:1348,y:845,t:1527030381242};\\\", \\\"{x:1348,y:849,t:1527030381259};\\\", \\\"{x:1348,y:852,t:1527030381276};\\\", \\\"{x:1348,y:854,t:1527030381292};\\\", \\\"{x:1348,y:856,t:1527030381309};\\\", \\\"{x:1348,y:860,t:1527030381327};\\\", \\\"{x:1348,y:864,t:1527030381342};\\\", \\\"{x:1348,y:869,t:1527030381360};\\\", \\\"{x:1348,y:873,t:1527030381377};\\\", \\\"{x:1348,y:876,t:1527030381392};\\\", \\\"{x:1348,y:879,t:1527030381409};\\\", \\\"{x:1348,y:881,t:1527030381426};\\\", \\\"{x:1347,y:883,t:1527030381442};\\\", \\\"{x:1347,y:886,t:1527030381459};\\\", \\\"{x:1347,y:890,t:1527030381475};\\\", \\\"{x:1347,y:891,t:1527030381508};\\\", \\\"{x:1347,y:892,t:1527030381516};\\\", \\\"{x:1347,y:893,t:1527030381527};\\\", \\\"{x:1347,y:894,t:1527030381542};\\\", \\\"{x:1347,y:896,t:1527030381559};\\\", \\\"{x:1347,y:897,t:1527030381580};\\\", \\\"{x:1347,y:898,t:1527030381596};\\\", \\\"{x:1347,y:899,t:1527030381611};\\\", \\\"{x:1347,y:900,t:1527030381932};\\\", \\\"{x:1346,y:900,t:1527030381943};\\\", \\\"{x:1341,y:899,t:1527030381960};\\\", \\\"{x:1333,y:897,t:1527030381976};\\\", \\\"{x:1321,y:894,t:1527030381993};\\\", \\\"{x:1309,y:889,t:1527030382009};\\\", \\\"{x:1290,y:883,t:1527030382027};\\\", \\\"{x:1245,y:868,t:1527030382044};\\\", \\\"{x:1205,y:856,t:1527030382059};\\\", \\\"{x:1152,y:839,t:1527030382077};\\\", \\\"{x:1101,y:832,t:1527030382094};\\\", \\\"{x:1045,y:822,t:1527030382109};\\\", \\\"{x:983,y:803,t:1527030382126};\\\", \\\"{x:914,y:786,t:1527030382144};\\\", \\\"{x:871,y:771,t:1527030382159};\\\", \\\"{x:835,y:760,t:1527030382176};\\\", \\\"{x:808,y:752,t:1527030382193};\\\", \\\"{x:786,y:742,t:1527030382209};\\\", \\\"{x:768,y:731,t:1527030382226};\\\", \\\"{x:754,y:721,t:1527030382243};\\\", \\\"{x:737,y:706,t:1527030382259};\\\", \\\"{x:730,y:700,t:1527030382276};\\\", \\\"{x:727,y:694,t:1527030382294};\\\", \\\"{x:726,y:687,t:1527030382310};\\\", \\\"{x:726,y:678,t:1527030382326};\\\", \\\"{x:726,y:671,t:1527030382344};\\\", \\\"{x:726,y:665,t:1527030382361};\\\", \\\"{x:731,y:657,t:1527030382376};\\\", \\\"{x:736,y:652,t:1527030382393};\\\", \\\"{x:743,y:643,t:1527030382410};\\\", \\\"{x:752,y:635,t:1527030382426};\\\", \\\"{x:765,y:624,t:1527030382443};\\\", \\\"{x:775,y:618,t:1527030382459};\\\", \\\"{x:783,y:611,t:1527030382478};\\\", \\\"{x:794,y:604,t:1527030382493};\\\", \\\"{x:801,y:600,t:1527030382509};\\\", \\\"{x:807,y:597,t:1527030382526};\\\", \\\"{x:809,y:595,t:1527030382544};\\\", \\\"{x:810,y:594,t:1527030382560};\\\", \\\"{x:811,y:594,t:1527030382578};\\\", \\\"{x:811,y:592,t:1527030382603};\\\", \\\"{x:810,y:592,t:1527030382611};\\\", \\\"{x:808,y:592,t:1527030382626};\\\", \\\"{x:798,y:595,t:1527030382644};\\\", \\\"{x:782,y:605,t:1527030382661};\\\", \\\"{x:756,y:622,t:1527030382678};\\\", \\\"{x:725,y:637,t:1527030382694};\\\", \\\"{x:684,y:653,t:1527030382711};\\\", \\\"{x:657,y:663,t:1527030382728};\\\", \\\"{x:640,y:668,t:1527030382745};\\\", \\\"{x:628,y:671,t:1527030382761};\\\", \\\"{x:623,y:671,t:1527030382778};\\\", \\\"{x:621,y:672,t:1527030382794};\\\", \\\"{x:612,y:672,t:1527030382811};\\\", \\\"{x:603,y:672,t:1527030382827};\\\", \\\"{x:582,y:672,t:1527030382844};\\\", \\\"{x:559,y:672,t:1527030382862};\\\", \\\"{x:536,y:669,t:1527030382878};\\\", \\\"{x:513,y:663,t:1527030382895};\\\", \\\"{x:490,y:657,t:1527030382911};\\\", \\\"{x:475,y:650,t:1527030382930};\\\", \\\"{x:460,y:642,t:1527030382945};\\\", \\\"{x:455,y:637,t:1527030382961};\\\", \\\"{x:449,y:633,t:1527030382978};\\\", \\\"{x:442,y:627,t:1527030382994};\\\", \\\"{x:439,y:625,t:1527030383011};\\\", \\\"{x:439,y:624,t:1527030383050};\\\", \\\"{x:436,y:622,t:1527030383060};\\\", \\\"{x:433,y:620,t:1527030383078};\\\", \\\"{x:424,y:620,t:1527030383095};\\\", \\\"{x:418,y:620,t:1527030383110};\\\", \\\"{x:409,y:619,t:1527030383129};\\\", \\\"{x:404,y:619,t:1527030383147};\\\", \\\"{x:399,y:619,t:1527030383161};\\\", \\\"{x:391,y:619,t:1527030383178};\\\", \\\"{x:365,y:619,t:1527030383195};\\\", \\\"{x:349,y:619,t:1527030383210};\\\", \\\"{x:337,y:619,t:1527030383227};\\\", \\\"{x:322,y:619,t:1527030383244};\\\", \\\"{x:303,y:616,t:1527030383261};\\\", \\\"{x:286,y:613,t:1527030383277};\\\", \\\"{x:270,y:609,t:1527030383296};\\\", \\\"{x:249,y:603,t:1527030383311};\\\", \\\"{x:235,y:598,t:1527030383327};\\\", \\\"{x:221,y:589,t:1527030383344};\\\", \\\"{x:211,y:578,t:1527030383362};\\\", \\\"{x:201,y:570,t:1527030383379};\\\", \\\"{x:189,y:561,t:1527030383395};\\\", \\\"{x:182,y:557,t:1527030383411};\\\", \\\"{x:176,y:553,t:1527030383428};\\\", \\\"{x:170,y:548,t:1527030383445};\\\", \\\"{x:164,y:546,t:1527030383461};\\\", \\\"{x:158,y:545,t:1527030383478};\\\", \\\"{x:156,y:545,t:1527030383494};\\\", \\\"{x:154,y:545,t:1527030383512};\\\", \\\"{x:153,y:545,t:1527030383564};\\\", \\\"{x:151,y:545,t:1527030383579};\\\", \\\"{x:147,y:548,t:1527030383596};\\\", \\\"{x:146,y:550,t:1527030383612};\\\", \\\"{x:144,y:553,t:1527030383628};\\\", \\\"{x:144,y:554,t:1527030383645};\\\", \\\"{x:149,y:554,t:1527030383933};\\\", \\\"{x:156,y:554,t:1527030383945};\\\", \\\"{x:180,y:558,t:1527030383962};\\\", \\\"{x:239,y:566,t:1527030383980};\\\", \\\"{x:285,y:574,t:1527030383996};\\\", \\\"{x:336,y:583,t:1527030384013};\\\", \\\"{x:398,y:604,t:1527030384030};\\\", \\\"{x:464,y:621,t:1527030384046};\\\", \\\"{x:543,y:651,t:1527030384062};\\\", \\\"{x:632,y:691,t:1527030384079};\\\", \\\"{x:697,y:729,t:1527030384094};\\\", \\\"{x:744,y:756,t:1527030384112};\\\", \\\"{x:764,y:769,t:1527030384129};\\\", \\\"{x:776,y:778,t:1527030384145};\\\", \\\"{x:781,y:782,t:1527030384162};\\\", \\\"{x:781,y:786,t:1527030384178};\\\", \\\"{x:780,y:788,t:1527030384194};\\\", \\\"{x:769,y:788,t:1527030384211};\\\", \\\"{x:752,y:784,t:1527030384228};\\\", \\\"{x:722,y:776,t:1527030384245};\\\", \\\"{x:680,y:758,t:1527030384262};\\\", \\\"{x:630,y:734,t:1527030384278};\\\", \\\"{x:578,y:714,t:1527030384295};\\\", \\\"{x:517,y:686,t:1527030384312};\\\", \\\"{x:462,y:661,t:1527030384329};\\\", \\\"{x:405,y:632,t:1527030384347};\\\", \\\"{x:356,y:611,t:1527030384362};\\\", \\\"{x:302,y:588,t:1527030384378};\\\", \\\"{x:281,y:576,t:1527030384396};\\\", \\\"{x:269,y:570,t:1527030384412};\\\", \\\"{x:256,y:563,t:1527030384429};\\\", \\\"{x:249,y:560,t:1527030384444};\\\", \\\"{x:243,y:555,t:1527030384462};\\\", \\\"{x:236,y:549,t:1527030384478};\\\", \\\"{x:230,y:544,t:1527030384495};\\\", \\\"{x:224,y:540,t:1527030384512};\\\", \\\"{x:223,y:540,t:1527030384529};\\\", \\\"{x:219,y:540,t:1527030384545};\\\", \\\"{x:212,y:540,t:1527030384562};\\\", \\\"{x:198,y:544,t:1527030384579};\\\", \\\"{x:185,y:549,t:1527030384595};\\\", \\\"{x:176,y:552,t:1527030384612};\\\", \\\"{x:171,y:554,t:1527030384629};\\\", \\\"{x:169,y:556,t:1527030384647};\\\", \\\"{x:167,y:558,t:1527030384662};\\\", \\\"{x:165,y:560,t:1527030384679};\\\", \\\"{x:163,y:564,t:1527030384696};\\\", \\\"{x:162,y:565,t:1527030384712};\\\", \\\"{x:162,y:566,t:1527030384979};\\\", \\\"{x:167,y:566,t:1527030384996};\\\", \\\"{x:182,y:566,t:1527030385012};\\\", \\\"{x:202,y:566,t:1527030385029};\\\", \\\"{x:229,y:571,t:1527030385046};\\\", \\\"{x:262,y:579,t:1527030385063};\\\", \\\"{x:310,y:594,t:1527030385080};\\\", \\\"{x:363,y:610,t:1527030385095};\\\", \\\"{x:408,y:632,t:1527030385114};\\\", \\\"{x:453,y:653,t:1527030385130};\\\", \\\"{x:491,y:667,t:1527030385146};\\\", \\\"{x:545,y:705,t:1527030385163};\\\", \\\"{x:572,y:728,t:1527030385180};\\\", \\\"{x:591,y:751,t:1527030385196};\\\", \\\"{x:611,y:773,t:1527030385212};\\\", \\\"{x:627,y:791,t:1527030385229};\\\", \\\"{x:635,y:802,t:1527030385246};\\\", \\\"{x:638,y:804,t:1527030385263};\\\", \\\"{x:638,y:805,t:1527030385280};\\\", \\\"{x:637,y:805,t:1527030385315};\\\", \\\"{x:632,y:805,t:1527030385331};\\\", \\\"{x:616,y:798,t:1527030385346};\\\", \\\"{x:576,y:778,t:1527030385364};\\\", \\\"{x:551,y:769,t:1527030385379};\\\", \\\"{x:536,y:761,t:1527030385397};\\\", \\\"{x:527,y:755,t:1527030385414};\\\", \\\"{x:523,y:752,t:1527030385431};\\\", \\\"{x:520,y:748,t:1527030385446};\\\", \\\"{x:520,y:746,t:1527030385467};\\\", \\\"{x:520,y:745,t:1527030385480};\\\", \\\"{x:520,y:744,t:1527030385496};\\\", \\\"{x:520,y:742,t:1527030385513};\\\", \\\"{x:520,y:738,t:1527030385530};\\\", \\\"{x:520,y:732,t:1527030385547};\\\", \\\"{x:520,y:731,t:1527030385563};\\\", \\\"{x:522,y:731,t:1527030386107};\\\", \\\"{x:527,y:731,t:1527030386114};\\\", \\\"{x:533,y:731,t:1527030386130};\\\", \\\"{x:548,y:722,t:1527030386147};\\\", \\\"{x:549,y:719,t:1527030386164};\\\", \\\"{x:556,y:719,t:1527030386660};\\\", \\\"{x:564,y:715,t:1527030386667};\\\", \\\"{x:571,y:711,t:1527030386681};\\\", \\\"{x:584,y:702,t:1527030386697};\\\", \\\"{x:597,y:695,t:1527030386714};\\\", \\\"{x:624,y:680,t:1527030386746};\\\", \\\"{x:626,y:679,t:1527030386746};\\\", \\\"{x:631,y:677,t:1527030386764};\\\", \\\"{x:635,y:677,t:1527030386781};\\\", \\\"{x:638,y:677,t:1527030386796};\\\", \\\"{x:642,y:677,t:1527030386814};\\\" ] }, { \\\"rt\\\": 19865, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 295929, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM-03 PM-04 PM-E -E -04 PM-U -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:644,y:681,t:1527030386987};\\\", \\\"{x:654,y:695,t:1527030387013};\\\", \\\"{x:654,y:696,t:1527030387031};\\\", \\\"{x:656,y:697,t:1527030387411};\\\", \\\"{x:656,y:698,t:1527030387419};\\\", \\\"{x:657,y:698,t:1527030387431};\\\", \\\"{x:670,y:698,t:1527030387448};\\\", \\\"{x:691,y:696,t:1527030387464};\\\", \\\"{x:710,y:693,t:1527030387481};\\\", \\\"{x:730,y:688,t:1527030387498};\\\", \\\"{x:762,y:685,t:1527030387514};\\\", \\\"{x:785,y:680,t:1527030387531};\\\", \\\"{x:807,y:678,t:1527030387548};\\\", \\\"{x:824,y:677,t:1527030387565};\\\", \\\"{x:839,y:677,t:1527030387581};\\\", \\\"{x:854,y:679,t:1527030387598};\\\", \\\"{x:868,y:684,t:1527030387615};\\\", \\\"{x:873,y:688,t:1527030387631};\\\", \\\"{x:881,y:692,t:1527030387648};\\\", \\\"{x:891,y:697,t:1527030387665};\\\", \\\"{x:910,y:710,t:1527030387681};\\\", \\\"{x:938,y:726,t:1527030387698};\\\", \\\"{x:956,y:735,t:1527030387715};\\\", \\\"{x:958,y:736,t:1527030388052};\\\", \\\"{x:963,y:737,t:1527030388065};\\\", \\\"{x:972,y:740,t:1527030388082};\\\", \\\"{x:975,y:743,t:1527030388098};\\\", \\\"{x:1025,y:751,t:1527030388116};\\\", \\\"{x:1103,y:762,t:1527030388132};\\\", \\\"{x:1140,y:767,t:1527030388149};\\\", \\\"{x:1186,y:775,t:1527030388165};\\\", \\\"{x:1228,y:782,t:1527030388182};\\\", \\\"{x:1266,y:790,t:1527030388199};\\\", \\\"{x:1300,y:800,t:1527030388216};\\\", \\\"{x:1327,y:809,t:1527030388233};\\\", \\\"{x:1359,y:821,t:1527030388248};\\\", \\\"{x:1379,y:831,t:1527030388266};\\\", \\\"{x:1391,y:840,t:1527030388283};\\\", \\\"{x:1400,y:850,t:1527030388299};\\\", \\\"{x:1410,y:871,t:1527030388316};\\\", \\\"{x:1415,y:880,t:1527030388332};\\\", \\\"{x:1419,y:888,t:1527030388348};\\\", \\\"{x:1420,y:893,t:1527030388366};\\\", \\\"{x:1420,y:897,t:1527030388382};\\\", \\\"{x:1420,y:901,t:1527030388398};\\\", \\\"{x:1419,y:903,t:1527030388416};\\\", \\\"{x:1418,y:907,t:1527030388433};\\\", \\\"{x:1416,y:910,t:1527030388449};\\\", \\\"{x:1414,y:914,t:1527030388466};\\\", \\\"{x:1407,y:917,t:1527030388483};\\\", \\\"{x:1395,y:920,t:1527030388500};\\\", \\\"{x:1386,y:923,t:1527030388515};\\\", \\\"{x:1380,y:925,t:1527030388533};\\\", \\\"{x:1372,y:927,t:1527030388550};\\\", \\\"{x:1363,y:929,t:1527030388565};\\\", \\\"{x:1351,y:930,t:1527030388583};\\\", \\\"{x:1339,y:933,t:1527030388600};\\\", \\\"{x:1328,y:933,t:1527030388616};\\\", \\\"{x:1323,y:933,t:1527030388633};\\\", \\\"{x:1317,y:933,t:1527030388649};\\\", \\\"{x:1313,y:933,t:1527030388665};\\\", \\\"{x:1308,y:932,t:1527030388683};\\\", \\\"{x:1306,y:932,t:1527030388699};\\\", \\\"{x:1305,y:932,t:1527030388715};\\\", \\\"{x:1304,y:932,t:1527030388933};\\\", \\\"{x:1311,y:935,t:1527030388950};\\\", \\\"{x:1320,y:938,t:1527030388966};\\\", \\\"{x:1334,y:943,t:1527030388983};\\\", \\\"{x:1350,y:950,t:1527030388999};\\\", \\\"{x:1368,y:958,t:1527030389016};\\\", \\\"{x:1385,y:967,t:1527030389033};\\\", \\\"{x:1399,y:974,t:1527030389049};\\\", \\\"{x:1408,y:979,t:1527030389067};\\\", \\\"{x:1415,y:983,t:1527030389082};\\\", \\\"{x:1418,y:984,t:1527030389100};\\\", \\\"{x:1419,y:984,t:1527030389116};\\\", \\\"{x:1420,y:984,t:1527030389268};\\\", \\\"{x:1422,y:984,t:1527030389282};\\\", \\\"{x:1429,y:984,t:1527030389299};\\\", \\\"{x:1434,y:984,t:1527030389316};\\\", \\\"{x:1442,y:984,t:1527030389334};\\\", \\\"{x:1452,y:984,t:1527030389349};\\\", \\\"{x:1459,y:984,t:1527030389366};\\\", \\\"{x:1468,y:983,t:1527030389382};\\\", \\\"{x:1474,y:982,t:1527030389400};\\\", \\\"{x:1480,y:982,t:1527030389417};\\\", \\\"{x:1484,y:981,t:1527030389433};\\\", \\\"{x:1488,y:979,t:1527030389449};\\\", \\\"{x:1490,y:977,t:1527030389466};\\\", \\\"{x:1493,y:975,t:1527030389484};\\\", \\\"{x:1494,y:974,t:1527030389500};\\\", \\\"{x:1495,y:973,t:1527030389516};\\\", \\\"{x:1497,y:973,t:1527030389534};\\\", \\\"{x:1499,y:973,t:1527030389549};\\\", \\\"{x:1502,y:973,t:1527030389568};\\\", \\\"{x:1503,y:973,t:1527030389587};\\\", \\\"{x:1506,y:973,t:1527030389600};\\\", \\\"{x:1508,y:973,t:1527030389616};\\\", \\\"{x:1512,y:973,t:1527030389634};\\\", \\\"{x:1517,y:973,t:1527030389650};\\\", \\\"{x:1524,y:973,t:1527030389667};\\\", \\\"{x:1541,y:975,t:1527030389684};\\\", \\\"{x:1555,y:978,t:1527030389699};\\\", \\\"{x:1568,y:980,t:1527030389717};\\\", \\\"{x:1579,y:983,t:1527030389734};\\\", \\\"{x:1589,y:984,t:1527030389750};\\\", \\\"{x:1602,y:988,t:1527030389766};\\\", \\\"{x:1612,y:990,t:1527030389783};\\\", \\\"{x:1621,y:992,t:1527030389799};\\\", \\\"{x:1631,y:992,t:1527030389816};\\\", \\\"{x:1637,y:993,t:1527030389833};\\\", \\\"{x:1641,y:994,t:1527030389849};\\\", \\\"{x:1643,y:995,t:1527030389866};\\\", \\\"{x:1644,y:995,t:1527030390052};\\\", \\\"{x:1642,y:995,t:1527030390084};\\\", \\\"{x:1638,y:995,t:1527030390100};\\\", \\\"{x:1634,y:995,t:1527030390117};\\\", \\\"{x:1628,y:995,t:1527030390133};\\\", \\\"{x:1624,y:995,t:1527030390150};\\\", \\\"{x:1621,y:995,t:1527030390166};\\\", \\\"{x:1617,y:995,t:1527030390183};\\\", \\\"{x:1616,y:994,t:1527030390200};\\\", \\\"{x:1616,y:993,t:1527030390268};\\\", \\\"{x:1616,y:992,t:1527030390284};\\\", \\\"{x:1616,y:991,t:1527030390301};\\\", \\\"{x:1616,y:988,t:1527030390317};\\\", \\\"{x:1618,y:987,t:1527030390333};\\\", \\\"{x:1620,y:987,t:1527030390351};\\\", \\\"{x:1624,y:986,t:1527030390367};\\\", \\\"{x:1627,y:984,t:1527030390383};\\\", \\\"{x:1628,y:983,t:1527030390404};\\\", \\\"{x:1628,y:981,t:1527030390443};\\\", \\\"{x:1628,y:980,t:1527030390459};\\\", \\\"{x:1628,y:979,t:1527030390483};\\\", \\\"{x:1627,y:978,t:1527030390500};\\\", \\\"{x:1626,y:977,t:1527030390517};\\\", \\\"{x:1624,y:974,t:1527030390533};\\\", \\\"{x:1623,y:973,t:1527030390549};\\\", \\\"{x:1622,y:970,t:1527030390567};\\\", \\\"{x:1622,y:967,t:1527030390583};\\\", \\\"{x:1620,y:966,t:1527030390600};\\\", \\\"{x:1619,y:963,t:1527030390617};\\\", \\\"{x:1618,y:960,t:1527030390633};\\\", \\\"{x:1617,y:959,t:1527030390650};\\\", \\\"{x:1616,y:958,t:1527030390667};\\\", \\\"{x:1615,y:957,t:1527030390731};\\\", \\\"{x:1615,y:956,t:1527030390755};\\\", \\\"{x:1614,y:955,t:1527030390770};\\\", \\\"{x:1614,y:954,t:1527030390802};\\\", \\\"{x:1614,y:953,t:1527030390851};\\\", \\\"{x:1614,y:951,t:1527030390866};\\\", \\\"{x:1614,y:949,t:1527030390883};\\\", \\\"{x:1614,y:945,t:1527030390900};\\\", \\\"{x:1613,y:941,t:1527030390917};\\\", \\\"{x:1613,y:937,t:1527030390933};\\\", \\\"{x:1613,y:930,t:1527030390950};\\\", \\\"{x:1612,y:923,t:1527030390967};\\\", \\\"{x:1610,y:915,t:1527030390984};\\\", \\\"{x:1609,y:913,t:1527030391000};\\\", \\\"{x:1609,y:909,t:1527030391017};\\\", \\\"{x:1609,y:906,t:1527030391035};\\\", \\\"{x:1608,y:905,t:1527030391051};\\\", \\\"{x:1608,y:904,t:1527030391066};\\\", \\\"{x:1608,y:903,t:1527030391084};\\\", \\\"{x:1608,y:902,t:1527030391100};\\\", \\\"{x:1608,y:901,t:1527030391117};\\\", \\\"{x:1608,y:900,t:1527030391134};\\\", \\\"{x:1608,y:899,t:1527030391150};\\\", \\\"{x:1608,y:897,t:1527030391167};\\\", \\\"{x:1608,y:896,t:1527030391185};\\\", \\\"{x:1607,y:894,t:1527030391201};\\\", \\\"{x:1607,y:892,t:1527030391217};\\\", \\\"{x:1607,y:887,t:1527030391235};\\\", \\\"{x:1607,y:881,t:1527030391250};\\\", \\\"{x:1607,y:872,t:1527030391267};\\\", \\\"{x:1607,y:864,t:1527030391284};\\\", \\\"{x:1607,y:855,t:1527030391300};\\\", \\\"{x:1607,y:845,t:1527030391317};\\\", \\\"{x:1607,y:835,t:1527030391335};\\\", \\\"{x:1607,y:824,t:1527030391351};\\\", \\\"{x:1607,y:814,t:1527030391368};\\\", \\\"{x:1607,y:804,t:1527030391385};\\\", \\\"{x:1606,y:794,t:1527030391401};\\\", \\\"{x:1605,y:782,t:1527030391417};\\\", \\\"{x:1604,y:765,t:1527030391435};\\\", \\\"{x:1604,y:742,t:1527030391452};\\\", \\\"{x:1604,y:727,t:1527030391467};\\\", \\\"{x:1604,y:717,t:1527030391485};\\\", \\\"{x:1613,y:697,t:1527030391502};\\\", \\\"{x:1615,y:687,t:1527030391518};\\\", \\\"{x:1617,y:683,t:1527030391535};\\\", \\\"{x:1618,y:682,t:1527030391552};\\\", \\\"{x:1618,y:681,t:1527030391787};\\\", \\\"{x:1618,y:679,t:1527030391852};\\\", \\\"{x:1618,y:677,t:1527030391868};\\\", \\\"{x:1618,y:673,t:1527030391884};\\\", \\\"{x:1618,y:670,t:1527030391901};\\\", \\\"{x:1617,y:667,t:1527030391918};\\\", \\\"{x:1616,y:663,t:1527030391935};\\\", \\\"{x:1616,y:659,t:1527030391952};\\\", \\\"{x:1616,y:651,t:1527030391969};\\\", \\\"{x:1615,y:645,t:1527030391985};\\\", \\\"{x:1615,y:639,t:1527030392001};\\\", \\\"{x:1615,y:629,t:1527030392018};\\\", \\\"{x:1615,y:618,t:1527030392035};\\\", \\\"{x:1612,y:610,t:1527030392051};\\\", \\\"{x:1612,y:608,t:1527030392068};\\\", \\\"{x:1612,y:604,t:1527030392085};\\\", \\\"{x:1612,y:598,t:1527030392102};\\\", \\\"{x:1612,y:595,t:1527030392119};\\\", \\\"{x:1612,y:593,t:1527030392135};\\\", \\\"{x:1612,y:591,t:1527030392152};\\\", \\\"{x:1612,y:590,t:1527030392169};\\\", \\\"{x:1612,y:589,t:1527030392188};\\\", \\\"{x:1612,y:587,t:1527030392202};\\\", \\\"{x:1612,y:585,t:1527030392219};\\\", \\\"{x:1612,y:581,t:1527030392235};\\\", \\\"{x:1612,y:576,t:1527030392252};\\\", \\\"{x:1611,y:573,t:1527030392268};\\\", \\\"{x:1610,y:570,t:1527030392285};\\\", \\\"{x:1610,y:568,t:1527030392302};\\\", \\\"{x:1610,y:567,t:1527030392326};\\\", \\\"{x:1610,y:564,t:1527030392351};\\\", \\\"{x:1610,y:561,t:1527030392368};\\\", \\\"{x:1610,y:560,t:1527030392385};\\\", \\\"{x:1610,y:559,t:1527030392401};\\\", \\\"{x:1609,y:558,t:1527030392418};\\\", \\\"{x:1609,y:559,t:1527030392692};\\\", \\\"{x:1609,y:561,t:1527030392702};\\\", \\\"{x:1610,y:562,t:1527030392735};\\\", \\\"{x:1611,y:563,t:1527030392948};\\\", \\\"{x:1611,y:564,t:1527030392956};\\\", \\\"{x:1612,y:564,t:1527030393092};\\\", \\\"{x:1612,y:565,t:1527030394267};\\\", \\\"{x:1612,y:568,t:1527030394275};\\\", \\\"{x:1612,y:573,t:1527030394286};\\\", \\\"{x:1612,y:581,t:1527030394303};\\\", \\\"{x:1614,y:589,t:1527030394319};\\\", \\\"{x:1614,y:595,t:1527030394337};\\\", \\\"{x:1617,y:604,t:1527030394354};\\\", \\\"{x:1618,y:611,t:1527030394370};\\\", \\\"{x:1618,y:621,t:1527030394386};\\\", \\\"{x:1618,y:642,t:1527030394403};\\\", \\\"{x:1619,y:651,t:1527030394419};\\\", \\\"{x:1619,y:667,t:1527030394437};\\\", \\\"{x:1619,y:678,t:1527030394454};\\\", \\\"{x:1619,y:691,t:1527030394470};\\\", \\\"{x:1622,y:703,t:1527030394486};\\\", \\\"{x:1622,y:713,t:1527030394503};\\\", \\\"{x:1626,y:727,t:1527030394520};\\\", \\\"{x:1627,y:739,t:1527030394537};\\\", \\\"{x:1628,y:751,t:1527030394554};\\\", \\\"{x:1630,y:763,t:1527030394570};\\\", \\\"{x:1631,y:772,t:1527030394587};\\\", \\\"{x:1633,y:789,t:1527030394603};\\\", \\\"{x:1633,y:804,t:1527030394620};\\\", \\\"{x:1637,y:822,t:1527030394637};\\\", \\\"{x:1641,y:839,t:1527030394654};\\\", \\\"{x:1642,y:853,t:1527030394670};\\\", \\\"{x:1644,y:867,t:1527030394687};\\\", \\\"{x:1646,y:878,t:1527030394704};\\\", \\\"{x:1648,y:891,t:1527030394719};\\\", \\\"{x:1648,y:906,t:1527030394736};\\\", \\\"{x:1648,y:917,t:1527030394753};\\\", \\\"{x:1648,y:925,t:1527030394770};\\\", \\\"{x:1647,y:929,t:1527030394786};\\\", \\\"{x:1647,y:935,t:1527030394803};\\\", \\\"{x:1646,y:939,t:1527030394820};\\\", \\\"{x:1646,y:943,t:1527030394836};\\\", \\\"{x:1645,y:947,t:1527030394853};\\\", \\\"{x:1642,y:954,t:1527030394870};\\\", \\\"{x:1641,y:961,t:1527030394886};\\\", \\\"{x:1638,y:965,t:1527030394903};\\\", \\\"{x:1638,y:967,t:1527030394920};\\\", \\\"{x:1638,y:969,t:1527030394936};\\\", \\\"{x:1637,y:970,t:1527030394953};\\\", \\\"{x:1636,y:971,t:1527030394970};\\\", \\\"{x:1636,y:972,t:1527030394985};\\\", \\\"{x:1634,y:973,t:1527030395003};\\\", \\\"{x:1634,y:974,t:1527030395020};\\\", \\\"{x:1633,y:975,t:1527030395036};\\\", \\\"{x:1632,y:976,t:1527030395053};\\\", \\\"{x:1630,y:976,t:1527030395070};\\\", \\\"{x:1628,y:976,t:1527030395090};\\\", \\\"{x:1627,y:976,t:1527030395106};\\\", \\\"{x:1626,y:976,t:1527030395120};\\\", \\\"{x:1624,y:976,t:1527030395137};\\\", \\\"{x:1620,y:975,t:1527030395153};\\\", \\\"{x:1616,y:972,t:1527030395170};\\\", \\\"{x:1612,y:969,t:1527030395186};\\\", \\\"{x:1612,y:968,t:1527030395203};\\\", \\\"{x:1612,y:966,t:1527030395220};\\\", \\\"{x:1612,y:965,t:1527030395242};\\\", \\\"{x:1612,y:963,t:1527030395282};\\\", \\\"{x:1612,y:962,t:1527030395355};\\\", \\\"{x:1612,y:958,t:1527030400459};\\\", \\\"{x:1609,y:950,t:1527030400473};\\\", \\\"{x:1588,y:927,t:1527030400490};\\\", \\\"{x:1573,y:916,t:1527030400507};\\\", \\\"{x:1558,y:905,t:1527030400525};\\\", \\\"{x:1551,y:897,t:1527030400540};\\\", \\\"{x:1548,y:892,t:1527030400558};\\\", \\\"{x:1547,y:885,t:1527030400574};\\\", \\\"{x:1545,y:880,t:1527030400590};\\\", \\\"{x:1544,y:871,t:1527030400608};\\\", \\\"{x:1542,y:857,t:1527030400624};\\\", \\\"{x:1539,y:846,t:1527030400640};\\\", \\\"{x:1532,y:833,t:1527030400658};\\\", \\\"{x:1525,y:824,t:1527030400674};\\\", \\\"{x:1523,y:820,t:1527030400691};\\\", \\\"{x:1521,y:819,t:1527030400708};\\\", \\\"{x:1519,y:818,t:1527030400725};\\\", \\\"{x:1517,y:817,t:1527030400741};\\\", \\\"{x:1512,y:817,t:1527030400758};\\\", \\\"{x:1507,y:817,t:1527030400775};\\\", \\\"{x:1500,y:817,t:1527030400790};\\\", \\\"{x:1493,y:818,t:1527030400807};\\\", \\\"{x:1488,y:821,t:1527030400825};\\\", \\\"{x:1487,y:821,t:1527030400840};\\\", \\\"{x:1486,y:822,t:1527030400891};\\\", \\\"{x:1485,y:822,t:1527030400907};\\\", \\\"{x:1485,y:823,t:1527030400971};\\\", \\\"{x:1485,y:824,t:1527030401043};\\\", \\\"{x:1485,y:825,t:1527030401067};\\\", \\\"{x:1485,y:826,t:1527030401084};\\\", \\\"{x:1484,y:827,t:1527030401108};\\\", \\\"{x:1484,y:828,t:1527030401132};\\\", \\\"{x:1483,y:829,t:1527030401156};\\\", \\\"{x:1482,y:831,t:1527030401187};\\\", \\\"{x:1482,y:832,t:1527030401219};\\\", \\\"{x:1482,y:833,t:1527030401308};\\\", \\\"{x:1484,y:833,t:1527030401460};\\\", \\\"{x:1485,y:833,t:1527030401475};\\\", \\\"{x:1486,y:833,t:1527030401493};\\\", \\\"{x:1490,y:833,t:1527030401509};\\\", \\\"{x:1496,y:833,t:1527030401525};\\\", \\\"{x:1502,y:833,t:1527030401542};\\\", \\\"{x:1507,y:833,t:1527030401559};\\\", \\\"{x:1509,y:833,t:1527030401575};\\\", \\\"{x:1511,y:833,t:1527030401592};\\\", \\\"{x:1514,y:833,t:1527030401608};\\\", \\\"{x:1519,y:833,t:1527030401625};\\\", \\\"{x:1522,y:832,t:1527030401642};\\\", \\\"{x:1525,y:831,t:1527030401659};\\\", \\\"{x:1526,y:831,t:1527030401675};\\\", \\\"{x:1528,y:831,t:1527030401716};\\\", \\\"{x:1530,y:831,t:1527030401725};\\\", \\\"{x:1532,y:831,t:1527030401747};\\\", \\\"{x:1533,y:831,t:1527030401760};\\\", \\\"{x:1534,y:831,t:1527030401776};\\\", \\\"{x:1537,y:831,t:1527030401792};\\\", \\\"{x:1542,y:831,t:1527030401809};\\\", \\\"{x:1545,y:831,t:1527030401826};\\\", \\\"{x:1546,y:831,t:1527030401842};\\\", \\\"{x:1547,y:831,t:1527030402228};\\\", \\\"{x:1548,y:831,t:1527030402868};\\\", \\\"{x:1551,y:831,t:1527030402876};\\\", \\\"{x:1569,y:831,t:1527030402893};\\\", \\\"{x:1590,y:828,t:1527030402909};\\\", \\\"{x:1609,y:828,t:1527030402926};\\\", \\\"{x:1624,y:828,t:1527030402943};\\\", \\\"{x:1632,y:828,t:1527030402960};\\\", \\\"{x:1635,y:828,t:1527030402976};\\\", \\\"{x:1636,y:827,t:1527030402993};\\\", \\\"{x:1638,y:826,t:1527030403010};\\\", \\\"{x:1642,y:825,t:1527030403026};\\\", \\\"{x:1647,y:823,t:1527030403044};\\\", \\\"{x:1649,y:823,t:1527030403060};\\\", \\\"{x:1650,y:821,t:1527030403077};\\\", \\\"{x:1650,y:822,t:1527030403212};\\\", \\\"{x:1647,y:823,t:1527030403227};\\\", \\\"{x:1641,y:825,t:1527030403244};\\\", \\\"{x:1637,y:826,t:1527030403260};\\\", \\\"{x:1636,y:826,t:1527030403276};\\\", \\\"{x:1634,y:827,t:1527030403294};\\\", \\\"{x:1633,y:827,t:1527030403310};\\\", \\\"{x:1632,y:827,t:1527030403326};\\\", \\\"{x:1631,y:827,t:1527030403343};\\\", \\\"{x:1629,y:828,t:1527030403360};\\\", \\\"{x:1628,y:828,t:1527030403420};\\\", \\\"{x:1627,y:828,t:1527030403428};\\\", \\\"{x:1626,y:829,t:1527030403444};\\\", \\\"{x:1623,y:830,t:1527030403460};\\\", \\\"{x:1622,y:830,t:1527030403477};\\\", \\\"{x:1620,y:831,t:1527030403493};\\\", \\\"{x:1617,y:831,t:1527030403510};\\\", \\\"{x:1614,y:831,t:1527030403528};\\\", \\\"{x:1613,y:831,t:1527030403544};\\\", \\\"{x:1612,y:831,t:1527030403571};\\\", \\\"{x:1613,y:831,t:1527030403692};\\\", \\\"{x:1612,y:831,t:1527030404539};\\\", \\\"{x:1607,y:831,t:1527030404547};\\\", \\\"{x:1601,y:831,t:1527030404561};\\\", \\\"{x:1578,y:831,t:1527030404577};\\\", \\\"{x:1548,y:831,t:1527030404594};\\\", \\\"{x:1465,y:831,t:1527030404611};\\\", \\\"{x:1382,y:831,t:1527030404627};\\\", \\\"{x:1284,y:815,t:1527030404644};\\\", \\\"{x:1165,y:799,t:1527030404662};\\\", \\\"{x:1040,y:782,t:1527030404677};\\\", \\\"{x:915,y:763,t:1527030404694};\\\", \\\"{x:800,y:751,t:1527030404711};\\\", \\\"{x:694,y:735,t:1527030404727};\\\", \\\"{x:611,y:726,t:1527030404744};\\\", \\\"{x:539,y:715,t:1527030404763};\\\", \\\"{x:501,y:708,t:1527030404777};\\\", \\\"{x:469,y:702,t:1527030404794};\\\", \\\"{x:445,y:694,t:1527030404812};\\\", \\\"{x:442,y:692,t:1527030404829};\\\", \\\"{x:440,y:691,t:1527030404845};\\\", \\\"{x:439,y:687,t:1527030404861};\\\", \\\"{x:439,y:684,t:1527030404879};\\\", \\\"{x:439,y:679,t:1527030404895};\\\", \\\"{x:442,y:674,t:1527030404912};\\\", \\\"{x:447,y:666,t:1527030404929};\\\", \\\"{x:459,y:657,t:1527030404945};\\\", \\\"{x:478,y:645,t:1527030404962};\\\", \\\"{x:511,y:629,t:1527030404980};\\\", \\\"{x:533,y:621,t:1527030404995};\\\", \\\"{x:554,y:612,t:1527030405012};\\\", \\\"{x:569,y:608,t:1527030405028};\\\", \\\"{x:584,y:602,t:1527030405045};\\\", \\\"{x:596,y:595,t:1527030405062};\\\", \\\"{x:603,y:587,t:1527030405079};\\\", \\\"{x:607,y:582,t:1527030405096};\\\", \\\"{x:609,y:575,t:1527030405112};\\\", \\\"{x:611,y:571,t:1527030405129};\\\", \\\"{x:611,y:566,t:1527030405146};\\\", \\\"{x:613,y:565,t:1527030405162};\\\", \\\"{x:611,y:565,t:1527030405203};\\\", \\\"{x:610,y:565,t:1527030405212};\\\", \\\"{x:609,y:571,t:1527030405229};\\\", \\\"{x:609,y:577,t:1527030405245};\\\", \\\"{x:610,y:580,t:1527030405261};\\\", \\\"{x:613,y:582,t:1527030405279};\\\", \\\"{x:614,y:584,t:1527030405296};\\\", \\\"{x:616,y:586,t:1527030405311};\\\", \\\"{x:617,y:586,t:1527030405328};\\\", \\\"{x:617,y:587,t:1527030405643};\\\", \\\"{x:617,y:589,t:1527030405667};\\\", \\\"{x:616,y:591,t:1527030405682};\\\", \\\"{x:615,y:594,t:1527030405696};\\\", \\\"{x:610,y:604,t:1527030405712};\\\", \\\"{x:604,y:615,t:1527030405729};\\\", \\\"{x:598,y:623,t:1527030405746};\\\", \\\"{x:591,y:635,t:1527030405762};\\\", \\\"{x:582,y:645,t:1527030405779};\\\", \\\"{x:573,y:655,t:1527030405796};\\\", \\\"{x:560,y:665,t:1527030405813};\\\", \\\"{x:550,y:669,t:1527030405829};\\\", \\\"{x:545,y:671,t:1527030405846};\\\", \\\"{x:542,y:672,t:1527030405862};\\\", \\\"{x:540,y:673,t:1527030405878};\\\", \\\"{x:538,y:675,t:1527030405896};\\\", \\\"{x:537,y:676,t:1527030405913};\\\", \\\"{x:536,y:676,t:1527030405929};\\\", \\\"{x:535,y:678,t:1527030405947};\\\", \\\"{x:534,y:680,t:1527030405963};\\\", \\\"{x:532,y:684,t:1527030405979};\\\", \\\"{x:530,y:688,t:1527030405996};\\\", \\\"{x:528,y:690,t:1527030406013};\\\", \\\"{x:528,y:695,t:1527030406029};\\\", \\\"{x:528,y:701,t:1527030406046};\\\", \\\"{x:529,y:710,t:1527030406061};\\\", \\\"{x:530,y:717,t:1527030406080};\\\", \\\"{x:531,y:722,t:1527030406096};\\\", \\\"{x:533,y:725,t:1527030406113};\\\", \\\"{x:533,y:728,t:1527030406130};\\\", \\\"{x:533,y:727,t:1527030406340};\\\", \\\"{x:533,y:725,t:1527030406348};\\\", \\\"{x:533,y:724,t:1527030406363};\\\", \\\"{x:533,y:722,t:1527030406379};\\\", \\\"{x:532,y:722,t:1527030406397};\\\", \\\"{x:532,y:721,t:1527030406414};\\\", \\\"{x:531,y:721,t:1527030406444};\\\" ] }, { \\\"rt\\\": 73678, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 370806, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-12 PM-I -J -01 PM-02 PM-O -O -12 PM-12 PM-12 PM-03 PM-04 PM-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:531,y:719,t:1527030408530};\\\", \\\"{x:529,y:702,t:1527030408548};\\\", \\\"{x:529,y:677,t:1527030408565};\\\", \\\"{x:528,y:645,t:1527030408582};\\\", \\\"{x:522,y:618,t:1527030408598};\\\", \\\"{x:517,y:600,t:1527030408615};\\\", \\\"{x:510,y:585,t:1527030408631};\\\", \\\"{x:504,y:572,t:1527030408648};\\\", \\\"{x:500,y:562,t:1527030408665};\\\", \\\"{x:497,y:557,t:1527030408682};\\\", \\\"{x:492,y:548,t:1527030408699};\\\", \\\"{x:489,y:543,t:1527030408715};\\\", \\\"{x:486,y:539,t:1527030408730};\\\", \\\"{x:484,y:538,t:1527030408748};\\\", \\\"{x:481,y:534,t:1527030408764};\\\", \\\"{x:477,y:529,t:1527030408781};\\\", \\\"{x:473,y:525,t:1527030408798};\\\", \\\"{x:469,y:522,t:1527030408815};\\\", \\\"{x:460,y:517,t:1527030408832};\\\", \\\"{x:455,y:512,t:1527030408848};\\\", \\\"{x:452,y:509,t:1527030408865};\\\", \\\"{x:451,y:507,t:1527030409307};\\\", \\\"{x:453,y:503,t:1527030409315};\\\", \\\"{x:453,y:501,t:1527030409332};\\\", \\\"{x:455,y:498,t:1527030409348};\\\", \\\"{x:457,y:495,t:1527030409365};\\\", \\\"{x:459,y:490,t:1527030409382};\\\", \\\"{x:461,y:487,t:1527030409398};\\\", \\\"{x:465,y:484,t:1527030409414};\\\", \\\"{x:468,y:480,t:1527030409432};\\\", \\\"{x:472,y:477,t:1527030409448};\\\", \\\"{x:477,y:475,t:1527030409465};\\\", \\\"{x:483,y:473,t:1527030409482};\\\", \\\"{x:488,y:470,t:1527030409499};\\\", \\\"{x:501,y:469,t:1527030409515};\\\", \\\"{x:508,y:468,t:1527030409532};\\\", \\\"{x:518,y:467,t:1527030409548};\\\", \\\"{x:531,y:466,t:1527030409565};\\\", \\\"{x:538,y:464,t:1527030409582};\\\", \\\"{x:540,y:464,t:1527030409598};\\\", \\\"{x:543,y:464,t:1527030409615};\\\", \\\"{x:544,y:464,t:1527030409788};\\\", \\\"{x:546,y:464,t:1527030409798};\\\", \\\"{x:553,y:464,t:1527030409815};\\\", \\\"{x:567,y:464,t:1527030409833};\\\", \\\"{x:590,y:464,t:1527030409849};\\\", \\\"{x:616,y:467,t:1527030409865};\\\", \\\"{x:645,y:472,t:1527030409882};\\\", \\\"{x:674,y:477,t:1527030409899};\\\", \\\"{x:706,y:482,t:1527030409915};\\\", \\\"{x:715,y:483,t:1527030409932};\\\", \\\"{x:717,y:484,t:1527030409948};\\\", \\\"{x:714,y:484,t:1527030410188};\\\", \\\"{x:706,y:484,t:1527030410198};\\\", \\\"{x:689,y:484,t:1527030410216};\\\", \\\"{x:673,y:484,t:1527030410233};\\\", \\\"{x:659,y:484,t:1527030410249};\\\", \\\"{x:651,y:484,t:1527030410264};\\\", \\\"{x:649,y:484,t:1527030410282};\\\", \\\"{x:646,y:484,t:1527030410635};\\\", \\\"{x:642,y:484,t:1527030410649};\\\", \\\"{x:627,y:484,t:1527030410665};\\\", \\\"{x:609,y:487,t:1527030410682};\\\", \\\"{x:572,y:493,t:1527030410699};\\\", \\\"{x:546,y:493,t:1527030410714};\\\", \\\"{x:526,y:494,t:1527030410732};\\\", \\\"{x:509,y:494,t:1527030410749};\\\", \\\"{x:499,y:495,t:1527030410765};\\\", \\\"{x:490,y:497,t:1527030410782};\\\", \\\"{x:487,y:497,t:1527030410799};\\\", \\\"{x:483,y:498,t:1527030410815};\\\", \\\"{x:481,y:499,t:1527030410832};\\\", \\\"{x:480,y:500,t:1527030410851};\\\", \\\"{x:479,y:501,t:1527030410875};\\\", \\\"{x:481,y:501,t:1527030410984};\\\", \\\"{x:485,y:501,t:1527030410991};\\\", \\\"{x:491,y:501,t:1527030411003};\\\", \\\"{x:508,y:501,t:1527030411019};\\\", \\\"{x:525,y:501,t:1527030411036};\\\", \\\"{x:544,y:501,t:1527030411053};\\\", \\\"{x:554,y:501,t:1527030411069};\\\", \\\"{x:555,y:501,t:1527030411086};\\\", \\\"{x:556,y:502,t:1527030411104};\\\", \\\"{x:557,y:502,t:1527030411159};\\\", \\\"{x:563,y:504,t:1527030411176};\\\", \\\"{x:569,y:506,t:1527030411186};\\\", \\\"{x:586,y:510,t:1527030411203};\\\", \\\"{x:590,y:510,t:1527030411220};\\\", \\\"{x:591,y:510,t:1527030411236};\\\", \\\"{x:594,y:511,t:1527030411511};\\\", \\\"{x:595,y:511,t:1527030411600};\\\", \\\"{x:597,y:511,t:1527030411616};\\\", \\\"{x:598,y:511,t:1527030411624};\\\", \\\"{x:598,y:510,t:1527030411655};\\\", \\\"{x:599,y:510,t:1527030411670};\\\", \\\"{x:600,y:509,t:1527030411686};\\\", \\\"{x:601,y:508,t:1527030411719};\\\", \\\"{x:601,y:506,t:1527030411744};\\\", \\\"{x:603,y:506,t:1527030411759};\\\", \\\"{x:605,y:504,t:1527030411775};\\\", \\\"{x:607,y:504,t:1527030411786};\\\", \\\"{x:612,y:503,t:1527030411803};\\\", \\\"{x:618,y:503,t:1527030411820};\\\", \\\"{x:620,y:503,t:1527030411836};\\\", \\\"{x:621,y:502,t:1527030411854};\\\", \\\"{x:622,y:502,t:1527030411903};\\\", \\\"{x:625,y:500,t:1527030411921};\\\", \\\"{x:626,y:500,t:1527030411936};\\\", \\\"{x:629,y:499,t:1527030411953};\\\", \\\"{x:632,y:499,t:1527030411969};\\\", \\\"{x:634,y:499,t:1527030411986};\\\", \\\"{x:635,y:497,t:1527030412003};\\\", \\\"{x:637,y:497,t:1527030412031};\\\", \\\"{x:638,y:497,t:1527030412078};\\\", \\\"{x:639,y:497,t:1527030412094};\\\", \\\"{x:641,y:497,t:1527030412102};\\\", \\\"{x:642,y:497,t:1527030412120};\\\", \\\"{x:644,y:497,t:1527030412136};\\\", \\\"{x:645,y:497,t:1527030412175};\\\", \\\"{x:646,y:497,t:1527030412199};\\\", \\\"{x:647,y:497,t:1527030412214};\\\", \\\"{x:648,y:497,t:1527030412223};\\\", \\\"{x:649,y:497,t:1527030412303};\\\", \\\"{x:651,y:497,t:1527030412321};\\\", \\\"{x:652,y:497,t:1527030412367};\\\", \\\"{x:654,y:497,t:1527030412567};\\\", \\\"{x:658,y:500,t:1527030412575};\\\", \\\"{x:661,y:501,t:1527030412586};\\\", \\\"{x:671,y:506,t:1527030412604};\\\", \\\"{x:689,y:515,t:1527030412620};\\\", \\\"{x:707,y:524,t:1527030412637};\\\", \\\"{x:729,y:534,t:1527030412653};\\\", \\\"{x:746,y:543,t:1527030412670};\\\", \\\"{x:757,y:549,t:1527030412688};\\\", \\\"{x:758,y:550,t:1527030412704};\\\", \\\"{x:758,y:551,t:1527030412734};\\\", \\\"{x:758,y:554,t:1527030412742};\\\", \\\"{x:758,y:555,t:1527030412755};\\\", \\\"{x:758,y:562,t:1527030412772};\\\", \\\"{x:757,y:572,t:1527030412789};\\\", \\\"{x:751,y:576,t:1527030412805};\\\", \\\"{x:750,y:576,t:1527030412822};\\\", \\\"{x:750,y:577,t:1527030413327};\\\", \\\"{x:750,y:581,t:1527030413339};\\\", \\\"{x:750,y:589,t:1527030413358};\\\", \\\"{x:750,y:595,t:1527030413372};\\\", \\\"{x:750,y:599,t:1527030413390};\\\", \\\"{x:750,y:604,t:1527030413406};\\\", \\\"{x:750,y:612,t:1527030413422};\\\", \\\"{x:750,y:615,t:1527030413438};\\\", \\\"{x:750,y:618,t:1527030413455};\\\", \\\"{x:750,y:621,t:1527030413472};\\\", \\\"{x:750,y:622,t:1527030413488};\\\", \\\"{x:750,y:624,t:1527030413506};\\\", \\\"{x:750,y:625,t:1527030413523};\\\", \\\"{x:751,y:627,t:1527030413540};\\\", \\\"{x:751,y:631,t:1527030413556};\\\", \\\"{x:752,y:634,t:1527030413572};\\\", \\\"{x:755,y:642,t:1527030413589};\\\", \\\"{x:757,y:650,t:1527030413606};\\\", \\\"{x:761,y:665,t:1527030413623};\\\", \\\"{x:765,y:675,t:1527030413638};\\\", \\\"{x:770,y:690,t:1527030413656};\\\", \\\"{x:774,y:701,t:1527030413673};\\\", \\\"{x:779,y:714,t:1527030413690};\\\", \\\"{x:783,y:722,t:1527030413706};\\\", \\\"{x:784,y:732,t:1527030413722};\\\", \\\"{x:785,y:738,t:1527030413740};\\\", \\\"{x:785,y:740,t:1527030413756};\\\", \\\"{x:785,y:741,t:1527030413855};\\\", \\\"{x:787,y:741,t:1527030413952};\\\", \\\"{x:790,y:744,t:1527030414383};\\\", \\\"{x:796,y:747,t:1527030414391};\\\", \\\"{x:800,y:750,t:1527030414405};\\\", \\\"{x:814,y:755,t:1527030414423};\\\", \\\"{x:824,y:760,t:1527030414439};\\\", \\\"{x:840,y:765,t:1527030414455};\\\", \\\"{x:856,y:772,t:1527030414473};\\\", \\\"{x:877,y:777,t:1527030414489};\\\", \\\"{x:901,y:783,t:1527030414505};\\\", \\\"{x:942,y:789,t:1527030414523};\\\", \\\"{x:984,y:796,t:1527030414539};\\\", \\\"{x:1039,y:808,t:1527030414555};\\\", \\\"{x:1088,y:812,t:1527030414573};\\\", \\\"{x:1138,y:820,t:1527030414589};\\\", \\\"{x:1191,y:833,t:1527030414605};\\\", \\\"{x:1284,y:853,t:1527030414624};\\\", \\\"{x:1344,y:866,t:1527030414639};\\\", \\\"{x:1399,y:883,t:1527030414655};\\\", \\\"{x:1459,y:893,t:1527030414673};\\\", \\\"{x:1504,y:902,t:1527030414689};\\\", \\\"{x:1540,y:908,t:1527030414706};\\\", \\\"{x:1575,y:919,t:1527030414723};\\\", \\\"{x:1603,y:926,t:1527030414740};\\\", \\\"{x:1626,y:933,t:1527030414756};\\\", \\\"{x:1644,y:938,t:1527030414773};\\\", \\\"{x:1657,y:942,t:1527030414790};\\\", \\\"{x:1664,y:945,t:1527030414805};\\\", \\\"{x:1665,y:946,t:1527030414824};\\\", \\\"{x:1666,y:946,t:1527030414847};\\\", \\\"{x:1666,y:948,t:1527030414871};\\\", \\\"{x:1665,y:950,t:1527030414888};\\\", \\\"{x:1663,y:951,t:1527030414895};\\\", \\\"{x:1660,y:952,t:1527030414906};\\\", \\\"{x:1656,y:954,t:1527030414923};\\\", \\\"{x:1650,y:957,t:1527030414940};\\\", \\\"{x:1644,y:958,t:1527030414956};\\\", \\\"{x:1633,y:961,t:1527030414973};\\\", \\\"{x:1621,y:961,t:1527030414990};\\\", \\\"{x:1603,y:961,t:1527030415005};\\\", \\\"{x:1580,y:961,t:1527030415023};\\\", \\\"{x:1566,y:961,t:1527030415039};\\\", \\\"{x:1549,y:961,t:1527030415056};\\\", \\\"{x:1534,y:961,t:1527030415073};\\\", \\\"{x:1523,y:961,t:1527030415090};\\\", \\\"{x:1513,y:961,t:1527030415106};\\\", \\\"{x:1505,y:961,t:1527030415123};\\\", \\\"{x:1491,y:963,t:1527030415140};\\\", \\\"{x:1475,y:966,t:1527030415156};\\\", \\\"{x:1464,y:966,t:1527030415173};\\\", \\\"{x:1454,y:967,t:1527030415190};\\\", \\\"{x:1449,y:968,t:1527030415206};\\\", \\\"{x:1440,y:972,t:1527030415224};\\\", \\\"{x:1435,y:974,t:1527030415239};\\\", \\\"{x:1429,y:975,t:1527030415255};\\\", \\\"{x:1425,y:976,t:1527030415272};\\\", \\\"{x:1420,y:978,t:1527030415289};\\\", \\\"{x:1414,y:979,t:1527030415305};\\\", \\\"{x:1409,y:981,t:1527030415322};\\\", \\\"{x:1405,y:983,t:1527030415339};\\\", \\\"{x:1401,y:983,t:1527030415355};\\\", \\\"{x:1398,y:985,t:1527030415372};\\\", \\\"{x:1397,y:985,t:1527030415389};\\\", \\\"{x:1396,y:985,t:1527030415463};\\\", \\\"{x:1395,y:986,t:1527030415560};\\\", \\\"{x:1394,y:987,t:1527030415575};\\\", \\\"{x:1393,y:987,t:1527030415589};\\\", \\\"{x:1387,y:987,t:1527030415606};\\\", \\\"{x:1377,y:987,t:1527030415623};\\\", \\\"{x:1368,y:987,t:1527030415639};\\\", \\\"{x:1356,y:984,t:1527030415656};\\\", \\\"{x:1350,y:983,t:1527030415672};\\\", \\\"{x:1346,y:981,t:1527030415688};\\\", \\\"{x:1346,y:980,t:1527030415719};\\\", \\\"{x:1346,y:978,t:1527030415735};\\\", \\\"{x:1346,y:977,t:1527030415743};\\\", \\\"{x:1346,y:975,t:1527030415758};\\\", \\\"{x:1346,y:974,t:1527030415772};\\\", \\\"{x:1346,y:973,t:1527030415790};\\\", \\\"{x:1347,y:971,t:1527030415805};\\\", \\\"{x:1347,y:969,t:1527030415830};\\\", \\\"{x:1347,y:968,t:1527030415839};\\\", \\\"{x:1347,y:967,t:1527030415855};\\\", \\\"{x:1347,y:964,t:1527030415872};\\\", \\\"{x:1347,y:958,t:1527030415888};\\\", \\\"{x:1347,y:953,t:1527030415905};\\\", \\\"{x:1347,y:946,t:1527030415923};\\\", \\\"{x:1344,y:935,t:1527030415939};\\\", \\\"{x:1343,y:921,t:1527030415956};\\\", \\\"{x:1340,y:905,t:1527030415973};\\\", \\\"{x:1340,y:890,t:1527030415989};\\\", \\\"{x:1340,y:874,t:1527030416005};\\\", \\\"{x:1340,y:840,t:1527030416023};\\\", \\\"{x:1344,y:824,t:1527030416039};\\\", \\\"{x:1353,y:779,t:1527030416055};\\\", \\\"{x:1365,y:747,t:1527030416072};\\\", \\\"{x:1372,y:721,t:1527030416088};\\\", \\\"{x:1382,y:687,t:1527030416106};\\\", \\\"{x:1392,y:658,t:1527030416122};\\\", \\\"{x:1402,y:626,t:1527030416139};\\\", \\\"{x:1412,y:595,t:1527030416155};\\\", \\\"{x:1420,y:568,t:1527030416172};\\\", \\\"{x:1428,y:541,t:1527030416188};\\\", \\\"{x:1434,y:520,t:1527030416205};\\\", \\\"{x:1439,y:500,t:1527030416222};\\\", \\\"{x:1440,y:496,t:1527030416238};\\\", \\\"{x:1443,y:485,t:1527030416255};\\\", \\\"{x:1443,y:480,t:1527030416272};\\\", \\\"{x:1443,y:477,t:1527030416288};\\\", \\\"{x:1444,y:476,t:1527030416306};\\\", \\\"{x:1444,y:474,t:1527030416375};\\\", \\\"{x:1444,y:473,t:1527030416389};\\\", \\\"{x:1439,y:471,t:1527030416406};\\\", \\\"{x:1418,y:467,t:1527030416425};\\\", \\\"{x:1407,y:466,t:1527030416439};\\\", \\\"{x:1367,y:462,t:1527030416455};\\\", \\\"{x:1344,y:461,t:1527030416472};\\\", \\\"{x:1328,y:463,t:1527030416488};\\\", \\\"{x:1321,y:464,t:1527030416506};\\\", \\\"{x:1313,y:467,t:1527030416522};\\\", \\\"{x:1308,y:469,t:1527030416539};\\\", \\\"{x:1305,y:470,t:1527030416556};\\\", \\\"{x:1302,y:473,t:1527030416595};\\\", \\\"{x:1300,y:474,t:1527030416614};\\\", \\\"{x:1300,y:475,t:1527030416622};\\\", \\\"{x:1300,y:477,t:1527030416638};\\\", \\\"{x:1300,y:481,t:1527030416656};\\\", \\\"{x:1300,y:484,t:1527030416672};\\\", \\\"{x:1300,y:485,t:1527030416688};\\\", \\\"{x:1300,y:488,t:1527030416705};\\\", \\\"{x:1301,y:493,t:1527030416721};\\\", \\\"{x:1303,y:495,t:1527030416738};\\\", \\\"{x:1305,y:498,t:1527030416756};\\\", \\\"{x:1306,y:499,t:1527030416783};\\\", \\\"{x:1307,y:499,t:1527030416807};\\\", \\\"{x:1308,y:499,t:1527030416823};\\\", \\\"{x:1309,y:499,t:1527030416848};\\\", \\\"{x:1311,y:499,t:1527030416872};\\\", \\\"{x:1313,y:499,t:1527030416888};\\\", \\\"{x:1314,y:499,t:1527030416905};\\\", \\\"{x:1315,y:499,t:1527030417038};\\\", \\\"{x:1316,y:498,t:1527030419967};\\\", \\\"{x:1320,y:498,t:1527030419984};\\\", \\\"{x:1322,y:498,t:1527030419992};\\\", \\\"{x:1328,y:498,t:1527030420005};\\\", \\\"{x:1338,y:498,t:1527030420022};\\\", \\\"{x:1347,y:498,t:1527030420038};\\\", \\\"{x:1353,y:498,t:1527030420055};\\\", \\\"{x:1354,y:498,t:1527030420072};\\\", \\\"{x:1355,y:498,t:1527030420088};\\\", \\\"{x:1356,y:497,t:1527030420111};\\\", \\\"{x:1359,y:496,t:1527030420122};\\\", \\\"{x:1362,y:496,t:1527030420138};\\\", \\\"{x:1369,y:495,t:1527030420155};\\\", \\\"{x:1374,y:495,t:1527030420171};\\\", \\\"{x:1376,y:495,t:1527030420187};\\\", \\\"{x:1377,y:495,t:1527030420204};\\\", \\\"{x:1378,y:495,t:1527030420221};\\\", \\\"{x:1379,y:494,t:1527030420237};\\\", \\\"{x:1380,y:494,t:1527030420254};\\\", \\\"{x:1382,y:494,t:1527030420270};\\\", \\\"{x:1383,y:493,t:1527030420294};\\\", \\\"{x:1384,y:493,t:1527030420368};\\\", \\\"{x:1385,y:493,t:1527030420391};\\\", \\\"{x:1387,y:494,t:1527030420567};\\\", \\\"{x:1389,y:494,t:1527030420575};\\\", \\\"{x:1391,y:494,t:1527030420588};\\\", \\\"{x:1395,y:494,t:1527030420605};\\\", \\\"{x:1401,y:494,t:1527030420622};\\\", \\\"{x:1407,y:494,t:1527030420638};\\\", \\\"{x:1416,y:494,t:1527030420654};\\\", \\\"{x:1424,y:494,t:1527030420671};\\\", \\\"{x:1427,y:494,t:1527030420687};\\\", \\\"{x:1428,y:494,t:1527030420704};\\\", \\\"{x:1430,y:494,t:1527030420720};\\\", \\\"{x:1431,y:494,t:1527030420743};\\\", \\\"{x:1433,y:494,t:1527030420767};\\\", \\\"{x:1434,y:494,t:1527030420791};\\\", \\\"{x:1436,y:494,t:1527030420805};\\\", \\\"{x:1438,y:494,t:1527030420820};\\\", \\\"{x:1440,y:494,t:1527030420838};\\\", \\\"{x:1441,y:494,t:1527030420855};\\\", \\\"{x:1442,y:494,t:1527030421087};\\\", \\\"{x:1443,y:494,t:1527030421105};\\\", \\\"{x:1444,y:495,t:1527030421127};\\\", \\\"{x:1446,y:495,t:1527030421175};\\\", \\\"{x:1448,y:496,t:1527030421206};\\\", \\\"{x:1449,y:496,t:1527030421223};\\\", \\\"{x:1449,y:497,t:1527030421237};\\\", \\\"{x:1451,y:497,t:1527030421278};\\\", \\\"{x:1452,y:498,t:1527030421310};\\\", \\\"{x:1454,y:499,t:1527030421320};\\\", \\\"{x:1455,y:499,t:1527030421337};\\\", \\\"{x:1456,y:499,t:1527030421354};\\\", \\\"{x:1458,y:499,t:1527030421370};\\\", \\\"{x:1460,y:499,t:1527030421387};\\\", \\\"{x:1461,y:499,t:1527030421405};\\\", \\\"{x:1462,y:499,t:1527030421430};\\\", \\\"{x:1464,y:499,t:1527030421439};\\\", \\\"{x:1465,y:499,t:1527030421454};\\\", \\\"{x:1466,y:499,t:1527030421470};\\\", \\\"{x:1468,y:499,t:1527030421487};\\\", \\\"{x:1470,y:499,t:1527030421503};\\\", \\\"{x:1471,y:499,t:1527030421521};\\\", \\\"{x:1473,y:499,t:1527030421538};\\\", \\\"{x:1476,y:499,t:1527030421555};\\\", \\\"{x:1478,y:499,t:1527030421571};\\\", \\\"{x:1483,y:499,t:1527030421587};\\\", \\\"{x:1488,y:499,t:1527030421605};\\\", \\\"{x:1492,y:499,t:1527030421620};\\\", \\\"{x:1494,y:499,t:1527030421638};\\\", \\\"{x:1495,y:500,t:1527030421655};\\\", \\\"{x:1497,y:500,t:1527030421695};\\\", \\\"{x:1498,y:500,t:1527030421719};\\\", \\\"{x:1500,y:500,t:1527030421743};\\\", \\\"{x:1501,y:500,t:1527030421754};\\\", \\\"{x:1503,y:500,t:1527030421771};\\\", \\\"{x:1504,y:500,t:1527030421888};\\\", \\\"{x:1506,y:500,t:1527030421935};\\\", \\\"{x:1507,y:500,t:1527030422000};\\\", \\\"{x:1509,y:500,t:1527030422064};\\\", \\\"{x:1510,y:499,t:1527030422079};\\\", \\\"{x:1512,y:498,t:1527030422225};\\\", \\\"{x:1513,y:498,t:1527030422344};\\\", \\\"{x:1515,y:498,t:1527030423991};\\\", \\\"{x:1516,y:498,t:1527030424004};\\\", \\\"{x:1517,y:498,t:1527030424047};\\\", \\\"{x:1518,y:498,t:1527030424071};\\\", \\\"{x:1519,y:498,t:1527030424095};\\\", \\\"{x:1520,y:498,t:1527030424111};\\\", \\\"{x:1522,y:497,t:1527030424121};\\\", \\\"{x:1523,y:497,t:1527030424151};\\\", \\\"{x:1524,y:497,t:1527030424159};\\\", \\\"{x:1525,y:497,t:1527030424171};\\\", \\\"{x:1526,y:497,t:1527030424187};\\\", \\\"{x:1527,y:496,t:1527030424205};\\\", \\\"{x:1528,y:496,t:1527030424221};\\\", \\\"{x:1531,y:496,t:1527030424237};\\\", \\\"{x:1534,y:495,t:1527030424254};\\\", \\\"{x:1542,y:494,t:1527030424270};\\\", \\\"{x:1543,y:494,t:1527030424287};\\\", \\\"{x:1544,y:494,t:1527030429943};\\\", \\\"{x:1544,y:496,t:1527030429952};\\\", \\\"{x:1544,y:498,t:1527030429969};\\\", \\\"{x:1544,y:499,t:1527030429987};\\\", \\\"{x:1544,y:500,t:1527030430003};\\\", \\\"{x:1544,y:501,t:1527030430019};\\\", \\\"{x:1544,y:502,t:1527030430063};\\\", \\\"{x:1544,y:503,t:1527030430072};\\\", \\\"{x:1544,y:504,t:1527030430087};\\\", \\\"{x:1544,y:505,t:1527030430103};\\\", \\\"{x:1544,y:507,t:1527030430120};\\\", \\\"{x:1544,y:508,t:1527030430136};\\\", \\\"{x:1544,y:510,t:1527030430153};\\\", \\\"{x:1544,y:512,t:1527030430170};\\\", \\\"{x:1544,y:514,t:1527030430186};\\\", \\\"{x:1544,y:517,t:1527030430202};\\\", \\\"{x:1543,y:519,t:1527030430219};\\\", \\\"{x:1543,y:520,t:1527030430236};\\\", \\\"{x:1543,y:523,t:1527030430252};\\\", \\\"{x:1543,y:525,t:1527030430270};\\\", \\\"{x:1543,y:527,t:1527030430287};\\\", \\\"{x:1543,y:529,t:1527030430302};\\\", \\\"{x:1542,y:531,t:1527030430319};\\\", \\\"{x:1542,y:533,t:1527030430336};\\\", \\\"{x:1542,y:534,t:1527030430352};\\\", \\\"{x:1542,y:536,t:1527030430369};\\\", \\\"{x:1542,y:537,t:1527030430386};\\\", \\\"{x:1542,y:538,t:1527030430402};\\\", \\\"{x:1541,y:541,t:1527030430420};\\\", \\\"{x:1541,y:544,t:1527030430436};\\\", \\\"{x:1541,y:547,t:1527030430453};\\\", \\\"{x:1541,y:548,t:1527030430469};\\\", \\\"{x:1541,y:550,t:1527030430487};\\\", \\\"{x:1541,y:553,t:1527030430502};\\\", \\\"{x:1541,y:554,t:1527030430519};\\\", \\\"{x:1541,y:556,t:1527030430536};\\\", \\\"{x:1540,y:557,t:1527030430553};\\\", \\\"{x:1540,y:559,t:1527030430569};\\\", \\\"{x:1540,y:560,t:1527030430599};\\\", \\\"{x:1540,y:561,t:1527030430615};\\\", \\\"{x:1540,y:563,t:1527030430631};\\\", \\\"{x:1540,y:564,t:1527030430654};\\\", \\\"{x:1540,y:565,t:1527030430670};\\\", \\\"{x:1540,y:566,t:1527030430685};\\\", \\\"{x:1540,y:567,t:1527030430702};\\\", \\\"{x:1540,y:569,t:1527030430719};\\\", \\\"{x:1540,y:570,t:1527030430734};\\\", \\\"{x:1540,y:571,t:1527030430752};\\\", \\\"{x:1540,y:572,t:1527030430769};\\\", \\\"{x:1540,y:573,t:1527030430791};\\\", \\\"{x:1540,y:574,t:1527030430806};\\\", \\\"{x:1540,y:575,t:1527030430820};\\\", \\\"{x:1540,y:576,t:1527030430835};\\\", \\\"{x:1540,y:578,t:1527030430852};\\\", \\\"{x:1540,y:580,t:1527030430869};\\\", \\\"{x:1541,y:582,t:1527030430885};\\\", \\\"{x:1543,y:586,t:1527030430902};\\\", \\\"{x:1544,y:589,t:1527030430919};\\\", \\\"{x:1545,y:591,t:1527030430935};\\\", \\\"{x:1547,y:594,t:1527030430952};\\\", \\\"{x:1548,y:596,t:1527030430969};\\\", \\\"{x:1548,y:598,t:1527030430985};\\\", \\\"{x:1549,y:599,t:1527030431003};\\\", \\\"{x:1550,y:601,t:1527030431019};\\\", \\\"{x:1550,y:602,t:1527030431036};\\\", \\\"{x:1550,y:604,t:1527030431055};\\\", \\\"{x:1550,y:605,t:1527030431072};\\\", \\\"{x:1551,y:605,t:1527030431085};\\\", \\\"{x:1551,y:607,t:1527030431103};\\\", \\\"{x:1551,y:608,t:1527030431127};\\\", \\\"{x:1551,y:610,t:1527030431135};\\\", \\\"{x:1551,y:612,t:1527030431153};\\\", \\\"{x:1551,y:614,t:1527030431170};\\\", \\\"{x:1551,y:616,t:1527030431186};\\\", \\\"{x:1551,y:617,t:1527030431203};\\\", \\\"{x:1551,y:620,t:1527030431220};\\\", \\\"{x:1551,y:621,t:1527030431235};\\\", \\\"{x:1551,y:624,t:1527030431252};\\\", \\\"{x:1551,y:626,t:1527030431269};\\\", \\\"{x:1551,y:627,t:1527030431286};\\\", \\\"{x:1551,y:629,t:1527030431302};\\\", \\\"{x:1551,y:633,t:1527030431319};\\\", \\\"{x:1551,y:634,t:1527030431336};\\\", \\\"{x:1551,y:636,t:1527030431352};\\\", \\\"{x:1551,y:637,t:1527030431370};\\\", \\\"{x:1551,y:639,t:1527030431386};\\\", \\\"{x:1551,y:641,t:1527030431403};\\\", \\\"{x:1551,y:642,t:1527030431420};\\\", \\\"{x:1551,y:644,t:1527030431435};\\\", \\\"{x:1551,y:645,t:1527030431453};\\\", \\\"{x:1551,y:647,t:1527030431470};\\\", \\\"{x:1551,y:649,t:1527030431486};\\\", \\\"{x:1551,y:652,t:1527030431503};\\\", \\\"{x:1550,y:655,t:1527030431519};\\\", \\\"{x:1550,y:658,t:1527030431536};\\\", \\\"{x:1549,y:661,t:1527030431552};\\\", \\\"{x:1549,y:665,t:1527030431569};\\\", \\\"{x:1549,y:669,t:1527030431586};\\\", \\\"{x:1547,y:672,t:1527030431602};\\\", \\\"{x:1547,y:675,t:1527030431619};\\\", \\\"{x:1547,y:676,t:1527030431671};\\\", \\\"{x:1547,y:677,t:1527030431791};\\\", \\\"{x:1547,y:678,t:1527030431803};\\\", \\\"{x:1547,y:679,t:1527030431824};\\\", \\\"{x:1547,y:681,t:1527030431847};\\\", \\\"{x:1547,y:682,t:1527030431879};\\\", \\\"{x:1547,y:684,t:1527030431911};\\\", \\\"{x:1547,y:685,t:1527030431927};\\\", \\\"{x:1547,y:686,t:1527030431943};\\\", \\\"{x:1547,y:687,t:1527030431952};\\\", \\\"{x:1547,y:688,t:1527030431975};\\\", \\\"{x:1547,y:689,t:1527030431986};\\\", \\\"{x:1548,y:690,t:1527030432003};\\\", \\\"{x:1548,y:691,t:1527030432019};\\\", \\\"{x:1548,y:692,t:1527030432035};\\\", \\\"{x:1548,y:693,t:1527030432052};\\\", \\\"{x:1548,y:694,t:1527030432068};\\\", \\\"{x:1548,y:695,t:1527030432085};\\\", \\\"{x:1549,y:696,t:1527030432101};\\\", \\\"{x:1549,y:697,t:1527030432118};\\\", \\\"{x:1550,y:698,t:1527030432135};\\\", \\\"{x:1550,y:699,t:1527030432367};\\\", \\\"{x:1550,y:700,t:1527030432391};\\\", \\\"{x:1550,y:701,t:1527030432403};\\\", \\\"{x:1550,y:702,t:1527030432424};\\\", \\\"{x:1550,y:703,t:1527030432448};\\\", \\\"{x:1550,y:704,t:1527030432455};\\\", \\\"{x:1550,y:705,t:1527030432468};\\\", \\\"{x:1550,y:707,t:1527030432486};\\\", \\\"{x:1550,y:709,t:1527030432503};\\\", \\\"{x:1550,y:711,t:1527030432518};\\\", \\\"{x:1550,y:714,t:1527030432535};\\\", \\\"{x:1550,y:716,t:1527030432553};\\\", \\\"{x:1550,y:717,t:1527030432568};\\\", \\\"{x:1550,y:718,t:1527030432591};\\\", \\\"{x:1550,y:719,t:1527030432640};\\\", \\\"{x:1550,y:720,t:1527030432653};\\\", \\\"{x:1550,y:721,t:1527030432669};\\\", \\\"{x:1550,y:722,t:1527030432687};\\\", \\\"{x:1550,y:723,t:1527030432703};\\\", \\\"{x:1550,y:724,t:1527030432719};\\\", \\\"{x:1550,y:726,t:1527030432735};\\\", \\\"{x:1550,y:728,t:1527030432752};\\\", \\\"{x:1550,y:730,t:1527030432768};\\\", \\\"{x:1550,y:731,t:1527030432785};\\\", \\\"{x:1550,y:732,t:1527030432802};\\\", \\\"{x:1550,y:734,t:1527030432818};\\\", \\\"{x:1550,y:736,t:1527030432838};\\\", \\\"{x:1550,y:737,t:1527030432852};\\\", \\\"{x:1550,y:738,t:1527030432868};\\\", \\\"{x:1550,y:739,t:1527030432885};\\\", \\\"{x:1550,y:740,t:1527030432902};\\\", \\\"{x:1550,y:742,t:1527030432918};\\\", \\\"{x:1550,y:743,t:1527030432935};\\\", \\\"{x:1550,y:744,t:1527030432966};\\\", \\\"{x:1549,y:745,t:1527030432983};\\\", \\\"{x:1549,y:746,t:1527030433031};\\\", \\\"{x:1549,y:747,t:1527030433096};\\\", \\\"{x:1549,y:748,t:1527030433127};\\\", \\\"{x:1549,y:749,t:1527030433151};\\\", \\\"{x:1549,y:750,t:1527030433208};\\\", \\\"{x:1549,y:751,t:1527030433231};\\\", \\\"{x:1549,y:752,t:1527030433255};\\\", \\\"{x:1549,y:753,t:1527030433295};\\\", \\\"{x:1549,y:754,t:1527030433343};\\\", \\\"{x:1549,y:755,t:1527030433359};\\\", \\\"{x:1549,y:756,t:1527030433391};\\\", \\\"{x:1549,y:757,t:1527030433407};\\\", \\\"{x:1549,y:758,t:1527030433424};\\\", \\\"{x:1549,y:759,t:1527030433463};\\\", \\\"{x:1549,y:760,t:1527030433480};\\\", \\\"{x:1549,y:761,t:1527030433503};\\\", \\\"{x:1549,y:762,t:1527030433527};\\\", \\\"{x:1549,y:763,t:1527030434682};\\\", \\\"{x:1549,y:764,t:1527030434695};\\\", \\\"{x:1549,y:765,t:1527030434702};\\\", \\\"{x:1550,y:766,t:1527030434726};\\\", \\\"{x:1550,y:762,t:1527030435750};\\\", \\\"{x:1548,y:746,t:1527030435767};\\\", \\\"{x:1543,y:730,t:1527030435784};\\\", \\\"{x:1536,y:708,t:1527030435801};\\\", \\\"{x:1526,y:687,t:1527030435818};\\\", \\\"{x:1516,y:665,t:1527030435834};\\\", \\\"{x:1506,y:646,t:1527030435851};\\\", \\\"{x:1492,y:616,t:1527030435868};\\\", \\\"{x:1483,y:595,t:1527030435884};\\\", \\\"{x:1472,y:578,t:1527030435902};\\\", \\\"{x:1462,y:560,t:1527030435918};\\\", \\\"{x:1446,y:536,t:1527030435935};\\\", \\\"{x:1438,y:526,t:1527030435951};\\\", \\\"{x:1433,y:518,t:1527030435967};\\\", \\\"{x:1428,y:512,t:1527030435984};\\\", \\\"{x:1423,y:503,t:1527030436002};\\\", \\\"{x:1419,y:497,t:1527030436018};\\\", \\\"{x:1416,y:490,t:1527030436034};\\\", \\\"{x:1412,y:485,t:1527030436052};\\\", \\\"{x:1411,y:481,t:1527030436068};\\\", \\\"{x:1410,y:477,t:1527030436085};\\\", \\\"{x:1409,y:471,t:1527030436102};\\\", \\\"{x:1408,y:466,t:1527030436118};\\\", \\\"{x:1407,y:458,t:1527030436135};\\\", \\\"{x:1405,y:453,t:1527030436151};\\\", \\\"{x:1405,y:448,t:1527030436168};\\\", \\\"{x:1404,y:444,t:1527030436185};\\\", \\\"{x:1403,y:439,t:1527030436201};\\\", \\\"{x:1403,y:436,t:1527030436217};\\\", \\\"{x:1403,y:432,t:1527030436234};\\\", \\\"{x:1403,y:430,t:1527030436252};\\\", \\\"{x:1403,y:429,t:1527030436268};\\\", \\\"{x:1403,y:428,t:1527030436285};\\\", \\\"{x:1403,y:427,t:1527030436351};\\\", \\\"{x:1404,y:426,t:1527030436375};\\\", \\\"{x:1406,y:426,t:1527030436424};\\\", \\\"{x:1407,y:426,t:1527030436435};\\\", \\\"{x:1408,y:426,t:1527030436452};\\\", \\\"{x:1410,y:427,t:1527030436469};\\\", \\\"{x:1411,y:427,t:1527030436484};\\\", \\\"{x:1412,y:428,t:1527030436503};\\\", \\\"{x:1413,y:428,t:1527030436518};\\\", \\\"{x:1414,y:429,t:1527030436534};\\\", \\\"{x:1415,y:429,t:1527030436567};\\\", \\\"{x:1415,y:430,t:1527030436584};\\\", \\\"{x:1416,y:430,t:1527030436639};\\\", \\\"{x:1417,y:431,t:1527030436663};\\\", \\\"{x:1418,y:431,t:1527030436751};\\\", \\\"{x:1419,y:431,t:1527030436863};\\\", \\\"{x:1419,y:430,t:1527030436894};\\\", \\\"{x:1419,y:429,t:1527030436919};\\\", \\\"{x:1419,y:428,t:1527030437167};\\\", \\\"{x:1417,y:428,t:1527030437199};\\\", \\\"{x:1415,y:428,t:1527030437231};\\\", \\\"{x:1414,y:428,t:1527030437263};\\\", \\\"{x:1413,y:429,t:1527030437278};\\\", \\\"{x:1412,y:429,t:1527030437303};\\\", \\\"{x:1412,y:430,t:1527030437317};\\\", \\\"{x:1411,y:430,t:1527030437351};\\\", \\\"{x:1410,y:430,t:1527030437368};\\\", \\\"{x:1410,y:431,t:1527030437399};\\\", \\\"{x:1410,y:432,t:1527030437424};\\\", \\\"{x:1410,y:433,t:1527030437463};\\\", \\\"{x:1410,y:434,t:1527030437488};\\\", \\\"{x:1410,y:435,t:1527030437512};\\\", \\\"{x:1410,y:437,t:1527030437527};\\\", \\\"{x:1411,y:439,t:1527030437551};\\\", \\\"{x:1411,y:441,t:1527030437567};\\\", \\\"{x:1413,y:445,t:1527030437585};\\\", \\\"{x:1414,y:448,t:1527030437601};\\\", \\\"{x:1415,y:453,t:1527030437618};\\\", \\\"{x:1417,y:459,t:1527030437635};\\\", \\\"{x:1418,y:462,t:1527030437651};\\\", \\\"{x:1418,y:466,t:1527030437668};\\\", \\\"{x:1418,y:469,t:1527030437685};\\\", \\\"{x:1418,y:470,t:1527030437701};\\\", \\\"{x:1419,y:475,t:1527030437718};\\\", \\\"{x:1419,y:478,t:1527030437735};\\\", \\\"{x:1421,y:480,t:1527030437751};\\\", \\\"{x:1421,y:483,t:1527030437767};\\\", \\\"{x:1421,y:484,t:1527030437784};\\\", \\\"{x:1421,y:486,t:1527030437801};\\\", \\\"{x:1421,y:490,t:1527030437818};\\\", \\\"{x:1421,y:491,t:1527030437834};\\\", \\\"{x:1421,y:494,t:1527030437851};\\\", \\\"{x:1422,y:496,t:1527030437867};\\\", \\\"{x:1422,y:499,t:1527030437884};\\\", \\\"{x:1423,y:500,t:1527030437900};\\\", \\\"{x:1423,y:502,t:1527030437917};\\\", \\\"{x:1424,y:507,t:1527030437934};\\\", \\\"{x:1424,y:509,t:1527030437950};\\\", \\\"{x:1424,y:512,t:1527030437967};\\\", \\\"{x:1425,y:516,t:1527030437984};\\\", \\\"{x:1425,y:521,t:1527030438000};\\\", \\\"{x:1425,y:527,t:1527030438017};\\\", \\\"{x:1425,y:534,t:1527030438035};\\\", \\\"{x:1425,y:539,t:1527030438050};\\\", \\\"{x:1425,y:542,t:1527030438067};\\\", \\\"{x:1425,y:546,t:1527030438084};\\\", \\\"{x:1425,y:549,t:1527030438100};\\\", \\\"{x:1426,y:552,t:1527030438117};\\\", \\\"{x:1426,y:555,t:1527030438134};\\\", \\\"{x:1426,y:558,t:1527030438150};\\\", \\\"{x:1426,y:560,t:1527030438167};\\\", \\\"{x:1426,y:561,t:1527030438183};\\\", \\\"{x:1426,y:563,t:1527030438200};\\\", \\\"{x:1426,y:565,t:1527030438217};\\\", \\\"{x:1426,y:566,t:1527030438238};\\\", \\\"{x:1426,y:567,t:1527030438250};\\\", \\\"{x:1426,y:568,t:1527030438267};\\\", \\\"{x:1426,y:569,t:1527030438284};\\\", \\\"{x:1426,y:571,t:1527030438300};\\\", \\\"{x:1425,y:572,t:1527030438317};\\\", \\\"{x:1424,y:575,t:1527030438333};\\\", \\\"{x:1424,y:579,t:1527030438350};\\\", \\\"{x:1423,y:581,t:1527030438368};\\\", \\\"{x:1422,y:585,t:1527030438383};\\\", \\\"{x:1422,y:587,t:1527030438400};\\\", \\\"{x:1422,y:589,t:1527030438417};\\\", \\\"{x:1422,y:591,t:1527030438434};\\\", \\\"{x:1422,y:593,t:1527030438451};\\\", \\\"{x:1422,y:595,t:1527030438468};\\\", \\\"{x:1421,y:596,t:1527030438484};\\\", \\\"{x:1421,y:597,t:1527030438501};\\\", \\\"{x:1421,y:599,t:1527030438518};\\\", \\\"{x:1420,y:601,t:1527030438534};\\\", \\\"{x:1420,y:603,t:1527030438551};\\\", \\\"{x:1419,y:606,t:1527030438567};\\\", \\\"{x:1419,y:607,t:1527030438583};\\\", \\\"{x:1418,y:609,t:1527030438600};\\\", \\\"{x:1417,y:613,t:1527030438618};\\\", \\\"{x:1416,y:615,t:1527030438633};\\\", \\\"{x:1416,y:616,t:1527030438650};\\\", \\\"{x:1416,y:618,t:1527030438668};\\\", \\\"{x:1415,y:618,t:1527030438684};\\\", \\\"{x:1415,y:622,t:1527030438701};\\\", \\\"{x:1414,y:624,t:1527030438718};\\\", \\\"{x:1414,y:628,t:1527030438734};\\\", \\\"{x:1413,y:632,t:1527030438751};\\\", \\\"{x:1413,y:634,t:1527030438767};\\\", \\\"{x:1413,y:636,t:1527030438783};\\\", \\\"{x:1412,y:637,t:1527030438801};\\\", \\\"{x:1412,y:639,t:1527030438817};\\\", \\\"{x:1412,y:641,t:1527030438833};\\\", \\\"{x:1412,y:643,t:1527030438850};\\\", \\\"{x:1412,y:645,t:1527030438868};\\\", \\\"{x:1412,y:648,t:1527030438884};\\\", \\\"{x:1412,y:651,t:1527030438901};\\\", \\\"{x:1412,y:655,t:1527030438918};\\\", \\\"{x:1413,y:658,t:1527030438934};\\\", \\\"{x:1415,y:663,t:1527030438951};\\\", \\\"{x:1415,y:665,t:1527030438967};\\\", \\\"{x:1415,y:666,t:1527030438983};\\\", \\\"{x:1415,y:667,t:1527030439000};\\\", \\\"{x:1415,y:668,t:1527030439017};\\\", \\\"{x:1415,y:669,t:1527030439038};\\\", \\\"{x:1415,y:671,t:1527030439050};\\\", \\\"{x:1415,y:672,t:1527030439067};\\\", \\\"{x:1416,y:674,t:1527030439083};\\\", \\\"{x:1416,y:676,t:1527030439100};\\\", \\\"{x:1416,y:677,t:1527030439118};\\\", \\\"{x:1416,y:679,t:1527030439134};\\\", \\\"{x:1416,y:681,t:1527030439150};\\\", \\\"{x:1416,y:683,t:1527030439167};\\\", \\\"{x:1416,y:684,t:1527030439184};\\\", \\\"{x:1416,y:686,t:1527030439201};\\\", \\\"{x:1416,y:689,t:1527030439218};\\\", \\\"{x:1416,y:692,t:1527030439234};\\\", \\\"{x:1416,y:694,t:1527030439251};\\\", \\\"{x:1416,y:696,t:1527030439268};\\\", \\\"{x:1416,y:698,t:1527030439284};\\\", \\\"{x:1416,y:699,t:1527030439301};\\\", \\\"{x:1416,y:701,t:1527030439318};\\\", \\\"{x:1416,y:703,t:1527030439334};\\\", \\\"{x:1416,y:709,t:1527030439351};\\\", \\\"{x:1416,y:712,t:1527030439366};\\\", \\\"{x:1416,y:716,t:1527030439384};\\\", \\\"{x:1416,y:723,t:1527030439401};\\\", \\\"{x:1416,y:727,t:1527030439418};\\\", \\\"{x:1416,y:731,t:1527030439434};\\\", \\\"{x:1416,y:732,t:1527030439451};\\\", \\\"{x:1416,y:734,t:1527030439466};\\\", \\\"{x:1416,y:735,t:1527030439483};\\\", \\\"{x:1416,y:737,t:1527030439501};\\\", \\\"{x:1415,y:742,t:1527030439516};\\\", \\\"{x:1415,y:746,t:1527030439534};\\\", \\\"{x:1414,y:750,t:1527030439551};\\\", \\\"{x:1413,y:755,t:1527030439567};\\\", \\\"{x:1413,y:759,t:1527030439584};\\\", \\\"{x:1411,y:763,t:1527030439601};\\\", \\\"{x:1411,y:767,t:1527030439617};\\\", \\\"{x:1410,y:773,t:1527030439634};\\\", \\\"{x:1410,y:774,t:1527030439650};\\\", \\\"{x:1409,y:779,t:1527030439666};\\\", \\\"{x:1409,y:781,t:1527030439683};\\\", \\\"{x:1409,y:785,t:1527030439700};\\\", \\\"{x:1409,y:787,t:1527030439716};\\\", \\\"{x:1409,y:789,t:1527030439733};\\\", \\\"{x:1409,y:793,t:1527030439750};\\\", \\\"{x:1409,y:794,t:1527030439774};\\\", \\\"{x:1409,y:796,t:1527030439784};\\\", \\\"{x:1409,y:797,t:1527030439800};\\\", \\\"{x:1409,y:799,t:1527030439816};\\\", \\\"{x:1409,y:800,t:1527030439834};\\\", \\\"{x:1409,y:801,t:1527030439851};\\\", \\\"{x:1409,y:802,t:1527030439866};\\\", \\\"{x:1409,y:803,t:1527030439884};\\\", \\\"{x:1410,y:806,t:1527030439901};\\\", \\\"{x:1410,y:807,t:1527030439935};\\\", \\\"{x:1410,y:809,t:1527030439951};\\\", \\\"{x:1410,y:811,t:1527030439967};\\\", \\\"{x:1411,y:813,t:1527030439984};\\\", \\\"{x:1411,y:815,t:1527030440001};\\\", \\\"{x:1412,y:816,t:1527030440016};\\\", \\\"{x:1412,y:819,t:1527030440033};\\\", \\\"{x:1412,y:820,t:1527030440055};\\\", \\\"{x:1412,y:821,t:1527030440067};\\\", \\\"{x:1413,y:822,t:1527030440084};\\\", \\\"{x:1413,y:824,t:1527030440100};\\\", \\\"{x:1413,y:825,t:1527030440127};\\\", \\\"{x:1413,y:827,t:1527030440143};\\\", \\\"{x:1414,y:827,t:1527030440152};\\\", \\\"{x:1414,y:828,t:1527030440175};\\\", \\\"{x:1414,y:830,t:1527030440207};\\\", \\\"{x:1415,y:830,t:1527030440217};\\\", \\\"{x:1415,y:833,t:1527030440234};\\\", \\\"{x:1415,y:834,t:1527030440255};\\\", \\\"{x:1415,y:836,t:1527030440267};\\\", \\\"{x:1415,y:838,t:1527030440283};\\\", \\\"{x:1417,y:842,t:1527030440300};\\\", \\\"{x:1417,y:846,t:1527030440316};\\\", \\\"{x:1417,y:848,t:1527030440333};\\\", \\\"{x:1418,y:852,t:1527030440350};\\\", \\\"{x:1418,y:855,t:1527030440366};\\\", \\\"{x:1419,y:858,t:1527030440383};\\\", \\\"{x:1420,y:861,t:1527030440400};\\\", \\\"{x:1420,y:866,t:1527030440416};\\\", \\\"{x:1420,y:869,t:1527030440434};\\\", \\\"{x:1420,y:872,t:1527030440450};\\\", \\\"{x:1420,y:876,t:1527030440467};\\\", \\\"{x:1420,y:879,t:1527030440483};\\\", \\\"{x:1420,y:883,t:1527030440500};\\\", \\\"{x:1420,y:886,t:1527030440517};\\\", \\\"{x:1420,y:889,t:1527030440534};\\\", \\\"{x:1420,y:894,t:1527030440551};\\\", \\\"{x:1421,y:896,t:1527030440568};\\\", \\\"{x:1421,y:900,t:1527030440584};\\\", \\\"{x:1421,y:903,t:1527030440601};\\\", \\\"{x:1421,y:909,t:1527030440617};\\\", \\\"{x:1421,y:915,t:1527030440633};\\\", \\\"{x:1421,y:920,t:1527030440651};\\\", \\\"{x:1421,y:924,t:1527030440666};\\\", \\\"{x:1421,y:928,t:1527030440683};\\\", \\\"{x:1421,y:930,t:1527030440700};\\\", \\\"{x:1421,y:932,t:1527030440716};\\\", \\\"{x:1421,y:935,t:1527030440733};\\\", \\\"{x:1421,y:939,t:1527030440750};\\\", \\\"{x:1421,y:941,t:1527030440775};\\\", \\\"{x:1421,y:942,t:1527030440784};\\\", \\\"{x:1421,y:943,t:1527030440800};\\\", \\\"{x:1422,y:945,t:1527030440817};\\\", \\\"{x:1422,y:946,t:1527030440833};\\\", \\\"{x:1422,y:947,t:1527030440855};\\\", \\\"{x:1422,y:948,t:1527030440879};\\\", \\\"{x:1422,y:949,t:1527030440903};\\\", \\\"{x:1422,y:950,t:1527030440916};\\\", \\\"{x:1421,y:951,t:1527030440934};\\\", \\\"{x:1421,y:952,t:1527030440951};\\\", \\\"{x:1420,y:953,t:1527030440967};\\\", \\\"{x:1420,y:954,t:1527030440984};\\\", \\\"{x:1418,y:956,t:1527030441000};\\\", \\\"{x:1417,y:958,t:1527030441016};\\\", \\\"{x:1416,y:960,t:1527030441034};\\\", \\\"{x:1413,y:964,t:1527030441050};\\\", \\\"{x:1412,y:965,t:1527030441068};\\\", \\\"{x:1410,y:968,t:1527030441084};\\\", \\\"{x:1409,y:969,t:1527030441100};\\\", \\\"{x:1407,y:969,t:1527030441117};\\\", \\\"{x:1406,y:971,t:1527030441133};\\\", \\\"{x:1406,y:970,t:1527030441751};\\\", \\\"{x:1406,y:969,t:1527030441807};\\\", \\\"{x:1408,y:969,t:1527030442279};\\\", \\\"{x:1411,y:969,t:1527030442287};\\\", \\\"{x:1414,y:969,t:1527030442299};\\\", \\\"{x:1425,y:969,t:1527030442317};\\\", \\\"{x:1443,y:969,t:1527030442333};\\\", \\\"{x:1458,y:971,t:1527030442349};\\\", \\\"{x:1467,y:973,t:1527030442366};\\\", \\\"{x:1470,y:974,t:1527030442382};\\\", \\\"{x:1471,y:974,t:1527030442438};\\\", \\\"{x:1472,y:974,t:1527030442542};\\\", \\\"{x:1474,y:973,t:1527030442550};\\\", \\\"{x:1474,y:971,t:1527030442566};\\\", \\\"{x:1476,y:968,t:1527030442582};\\\", \\\"{x:1478,y:966,t:1527030442600};\\\", \\\"{x:1480,y:963,t:1527030442617};\\\", \\\"{x:1483,y:960,t:1527030442633};\\\", \\\"{x:1488,y:959,t:1527030442649};\\\", \\\"{x:1489,y:957,t:1527030442666};\\\", \\\"{x:1490,y:956,t:1527030442683};\\\", \\\"{x:1489,y:957,t:1527030442855};\\\", \\\"{x:1488,y:958,t:1527030442871};\\\", \\\"{x:1485,y:959,t:1527030442887};\\\", \\\"{x:1485,y:960,t:1527030442911};\\\", \\\"{x:1484,y:961,t:1527030442952};\\\", \\\"{x:1484,y:962,t:1527030442967};\\\", \\\"{x:1483,y:963,t:1527030442983};\\\", \\\"{x:1483,y:964,t:1527030443024};\\\", \\\"{x:1482,y:965,t:1527030443040};\\\", \\\"{x:1482,y:964,t:1527030443352};\\\", \\\"{x:1482,y:963,t:1527030443366};\\\", \\\"{x:1482,y:962,t:1527030443383};\\\", \\\"{x:1482,y:960,t:1527030443400};\\\", \\\"{x:1482,y:959,t:1527030443464};\\\", \\\"{x:1481,y:958,t:1527030443792};\\\", \\\"{x:1478,y:958,t:1527030444759};\\\", \\\"{x:1473,y:953,t:1527030444768};\\\", \\\"{x:1449,y:918,t:1527030444783};\\\", \\\"{x:1406,y:859,t:1527030444799};\\\", \\\"{x:1341,y:780,t:1527030444816};\\\", \\\"{x:1288,y:699,t:1527030444833};\\\", \\\"{x:1252,y:609,t:1527030444849};\\\", \\\"{x:1225,y:541,t:1527030444866};\\\", \\\"{x:1215,y:494,t:1527030444883};\\\", \\\"{x:1210,y:462,t:1527030444899};\\\", \\\"{x:1210,y:437,t:1527030444916};\\\", \\\"{x:1213,y:420,t:1527030444933};\\\", \\\"{x:1221,y:409,t:1527030444949};\\\", \\\"{x:1231,y:400,t:1527030444966};\\\", \\\"{x:1241,y:396,t:1527030444983};\\\", \\\"{x:1248,y:395,t:1527030444999};\\\", \\\"{x:1256,y:394,t:1527030445016};\\\", \\\"{x:1266,y:394,t:1527030445033};\\\", \\\"{x:1280,y:394,t:1527030445049};\\\", \\\"{x:1297,y:403,t:1527030445066};\\\", \\\"{x:1314,y:413,t:1527030445083};\\\", \\\"{x:1326,y:423,t:1527030445099};\\\", \\\"{x:1339,y:438,t:1527030445116};\\\", \\\"{x:1348,y:452,t:1527030445134};\\\", \\\"{x:1348,y:463,t:1527030445149};\\\", \\\"{x:1348,y:475,t:1527030445166};\\\", \\\"{x:1344,y:487,t:1527030445182};\\\", \\\"{x:1340,y:492,t:1527030445199};\\\", \\\"{x:1336,y:494,t:1527030445216};\\\", \\\"{x:1334,y:494,t:1527030445233};\\\", \\\"{x:1333,y:494,t:1527030445263};\\\", \\\"{x:1331,y:495,t:1527030445287};\\\", \\\"{x:1331,y:496,t:1527030445299};\\\", \\\"{x:1330,y:496,t:1527030445327};\\\", \\\"{x:1329,y:496,t:1527030445335};\\\", \\\"{x:1327,y:496,t:1527030445349};\\\", \\\"{x:1323,y:498,t:1527030445366};\\\", \\\"{x:1317,y:502,t:1527030445383};\\\", \\\"{x:1314,y:503,t:1527030445399};\\\", \\\"{x:1312,y:505,t:1527030445416};\\\", \\\"{x:1310,y:506,t:1527030445433};\\\", \\\"{x:1309,y:507,t:1527030445449};\\\", \\\"{x:1307,y:509,t:1527030445466};\\\", \\\"{x:1307,y:511,t:1527030445484};\\\", \\\"{x:1306,y:513,t:1527030445498};\\\", \\\"{x:1306,y:515,t:1527030445517};\\\", \\\"{x:1306,y:519,t:1527030445533};\\\", \\\"{x:1306,y:522,t:1527030445549};\\\", \\\"{x:1306,y:525,t:1527030445566};\\\", \\\"{x:1306,y:529,t:1527030445583};\\\", \\\"{x:1306,y:532,t:1527030445599};\\\", \\\"{x:1307,y:535,t:1527030445616};\\\", \\\"{x:1307,y:539,t:1527030445634};\\\", \\\"{x:1307,y:542,t:1527030445649};\\\", \\\"{x:1307,y:546,t:1527030445666};\\\", \\\"{x:1307,y:549,t:1527030445683};\\\", \\\"{x:1307,y:552,t:1527030445699};\\\", \\\"{x:1307,y:556,t:1527030445715};\\\", \\\"{x:1308,y:558,t:1527030445733};\\\", \\\"{x:1308,y:563,t:1527030445749};\\\", \\\"{x:1308,y:565,t:1527030445765};\\\", \\\"{x:1308,y:567,t:1527030445782};\\\", \\\"{x:1308,y:570,t:1527030445798};\\\", \\\"{x:1310,y:573,t:1527030445815};\\\", \\\"{x:1311,y:576,t:1527030445831};\\\", \\\"{x:1311,y:579,t:1527030445848};\\\", \\\"{x:1311,y:582,t:1527030445866};\\\", \\\"{x:1311,y:584,t:1527030445882};\\\", \\\"{x:1311,y:587,t:1527030445899};\\\", \\\"{x:1312,y:590,t:1527030445916};\\\", \\\"{x:1312,y:592,t:1527030445932};\\\", \\\"{x:1312,y:596,t:1527030445949};\\\", \\\"{x:1312,y:599,t:1527030445966};\\\", \\\"{x:1312,y:601,t:1527030445982};\\\", \\\"{x:1312,y:607,t:1527030445999};\\\", \\\"{x:1312,y:610,t:1527030446016};\\\", \\\"{x:1312,y:612,t:1527030446032};\\\", \\\"{x:1312,y:614,t:1527030446049};\\\", \\\"{x:1312,y:617,t:1527030446066};\\\", \\\"{x:1312,y:620,t:1527030446081};\\\", \\\"{x:1312,y:623,t:1527030446099};\\\", \\\"{x:1312,y:626,t:1527030446117};\\\", \\\"{x:1312,y:629,t:1527030446132};\\\", \\\"{x:1312,y:633,t:1527030446149};\\\", \\\"{x:1312,y:637,t:1527030446167};\\\", \\\"{x:1312,y:641,t:1527030446182};\\\", \\\"{x:1312,y:644,t:1527030446199};\\\", \\\"{x:1312,y:645,t:1527030446225};\\\", \\\"{x:1312,y:646,t:1527030446232};\\\", \\\"{x:1312,y:647,t:1527030446249};\\\", \\\"{x:1312,y:649,t:1527030446266};\\\", \\\"{x:1312,y:653,t:1527030446282};\\\", \\\"{x:1312,y:655,t:1527030446299};\\\", \\\"{x:1312,y:657,t:1527030446316};\\\", \\\"{x:1312,y:659,t:1527030446332};\\\", \\\"{x:1311,y:663,t:1527030446349};\\\", \\\"{x:1311,y:665,t:1527030446367};\\\", \\\"{x:1311,y:668,t:1527030446382};\\\", \\\"{x:1310,y:673,t:1527030446398};\\\", \\\"{x:1309,y:676,t:1527030446416};\\\", \\\"{x:1309,y:680,t:1527030446432};\\\", \\\"{x:1309,y:685,t:1527030446449};\\\", \\\"{x:1309,y:689,t:1527030446466};\\\", \\\"{x:1307,y:693,t:1527030446482};\\\", \\\"{x:1307,y:698,t:1527030446499};\\\", \\\"{x:1306,y:703,t:1527030446516};\\\", \\\"{x:1306,y:706,t:1527030446532};\\\", \\\"{x:1306,y:710,t:1527030446548};\\\", \\\"{x:1305,y:713,t:1527030446565};\\\", \\\"{x:1305,y:715,t:1527030446581};\\\", \\\"{x:1305,y:718,t:1527030446598};\\\", \\\"{x:1305,y:720,t:1527030446615};\\\", \\\"{x:1305,y:721,t:1527030446632};\\\", \\\"{x:1305,y:723,t:1527030446648};\\\", \\\"{x:1305,y:724,t:1527030446665};\\\", \\\"{x:1305,y:726,t:1527030446682};\\\", \\\"{x:1305,y:729,t:1527030446698};\\\", \\\"{x:1305,y:732,t:1527030446716};\\\", \\\"{x:1306,y:734,t:1527030446732};\\\", \\\"{x:1306,y:735,t:1527030446749};\\\", \\\"{x:1307,y:737,t:1527030446766};\\\", \\\"{x:1307,y:740,t:1527030446782};\\\", \\\"{x:1308,y:742,t:1527030446799};\\\", \\\"{x:1309,y:744,t:1527030446816};\\\", \\\"{x:1309,y:745,t:1527030446839};\\\", \\\"{x:1309,y:746,t:1527030446854};\\\", \\\"{x:1309,y:748,t:1527030446887};\\\", \\\"{x:1310,y:749,t:1527030446899};\\\", \\\"{x:1310,y:751,t:1527030446916};\\\", \\\"{x:1310,y:752,t:1527030446932};\\\", \\\"{x:1310,y:755,t:1527030446950};\\\", \\\"{x:1310,y:758,t:1527030446966};\\\", \\\"{x:1311,y:760,t:1527030446983};\\\", \\\"{x:1311,y:764,t:1527030446998};\\\", \\\"{x:1312,y:768,t:1527030447016};\\\", \\\"{x:1313,y:769,t:1527030447032};\\\", \\\"{x:1313,y:771,t:1527030447049};\\\", \\\"{x:1313,y:774,t:1527030447065};\\\", \\\"{x:1313,y:777,t:1527030447082};\\\", \\\"{x:1313,y:779,t:1527030447099};\\\", \\\"{x:1313,y:781,t:1527030447115};\\\", \\\"{x:1313,y:783,t:1527030447132};\\\", \\\"{x:1313,y:784,t:1527030447150};\\\", \\\"{x:1313,y:787,t:1527030447166};\\\", \\\"{x:1313,y:790,t:1527030447182};\\\", \\\"{x:1314,y:795,t:1527030447199};\\\", \\\"{x:1314,y:798,t:1527030447216};\\\", \\\"{x:1314,y:801,t:1527030447232};\\\", \\\"{x:1314,y:804,t:1527030447249};\\\", \\\"{x:1314,y:807,t:1527030447265};\\\", \\\"{x:1314,y:808,t:1527030447282};\\\", \\\"{x:1314,y:810,t:1527030447299};\\\", \\\"{x:1314,y:812,t:1527030447315};\\\", \\\"{x:1314,y:813,t:1527030447332};\\\", \\\"{x:1314,y:816,t:1527030447350};\\\", \\\"{x:1314,y:819,t:1527030447366};\\\", \\\"{x:1315,y:822,t:1527030447382};\\\", \\\"{x:1315,y:829,t:1527030447399};\\\", \\\"{x:1315,y:831,t:1527030447415};\\\", \\\"{x:1315,y:833,t:1527030447432};\\\", \\\"{x:1315,y:837,t:1527030447449};\\\", \\\"{x:1315,y:838,t:1527030447465};\\\", \\\"{x:1315,y:842,t:1527030447480};\\\", \\\"{x:1315,y:844,t:1527030447499};\\\", \\\"{x:1315,y:846,t:1527030447515};\\\", \\\"{x:1315,y:848,t:1527030447532};\\\", \\\"{x:1315,y:849,t:1527030447549};\\\", \\\"{x:1315,y:850,t:1527030447565};\\\", \\\"{x:1315,y:852,t:1527030447582};\\\", \\\"{x:1315,y:854,t:1527030447598};\\\", \\\"{x:1315,y:855,t:1527030447621};\\\", \\\"{x:1315,y:856,t:1527030447632};\\\", \\\"{x:1315,y:857,t:1527030447649};\\\", \\\"{x:1315,y:858,t:1527030447666};\\\", \\\"{x:1315,y:859,t:1527030447678};\\\", \\\"{x:1315,y:859,t:1527030447682};\\\", \\\"{x:1315,y:862,t:1527030447700};\\\", \\\"{x:1315,y:863,t:1527030447718};\\\", \\\"{x:1314,y:865,t:1527030447734};\\\", \\\"{x:1313,y:867,t:1527030447758};\\\", \\\"{x:1312,y:868,t:1527030447774};\\\", \\\"{x:1312,y:869,t:1527030447784};\\\", \\\"{x:1310,y:871,t:1527030447800};\\\", \\\"{x:1310,y:874,t:1527030447816};\\\", \\\"{x:1310,y:875,t:1527030447834};\\\", \\\"{x:1309,y:876,t:1527030447850};\\\", \\\"{x:1308,y:879,t:1527030447867};\\\", \\\"{x:1308,y:880,t:1527030447884};\\\", \\\"{x:1308,y:881,t:1527030447900};\\\", \\\"{x:1307,y:882,t:1527030447917};\\\", \\\"{x:1307,y:884,t:1527030447934};\\\", \\\"{x:1307,y:885,t:1527030447951};\\\", \\\"{x:1307,y:886,t:1527030447967};\\\", \\\"{x:1307,y:887,t:1527030447984};\\\", \\\"{x:1307,y:888,t:1527030448000};\\\", \\\"{x:1307,y:889,t:1527030448016};\\\", \\\"{x:1307,y:890,t:1527030448034};\\\", \\\"{x:1307,y:892,t:1527030448049};\\\", \\\"{x:1307,y:894,t:1527030448067};\\\", \\\"{x:1307,y:896,t:1527030448084};\\\", \\\"{x:1308,y:897,t:1527030448100};\\\", \\\"{x:1308,y:899,t:1527030448116};\\\", \\\"{x:1309,y:901,t:1527030448134};\\\", \\\"{x:1309,y:902,t:1527030448150};\\\", \\\"{x:1310,y:905,t:1527030448167};\\\", \\\"{x:1311,y:907,t:1527030448184};\\\", \\\"{x:1311,y:908,t:1527030448201};\\\", \\\"{x:1311,y:911,t:1527030448217};\\\", \\\"{x:1312,y:911,t:1527030448234};\\\", \\\"{x:1312,y:914,t:1527030448251};\\\", \\\"{x:1313,y:918,t:1527030448267};\\\", \\\"{x:1313,y:924,t:1527030448284};\\\", \\\"{x:1315,y:932,t:1527030448301};\\\", \\\"{x:1316,y:937,t:1527030448318};\\\", \\\"{x:1317,y:939,t:1527030448334};\\\", \\\"{x:1317,y:940,t:1527030448351};\\\", \\\"{x:1317,y:941,t:1527030448367};\\\", \\\"{x:1318,y:943,t:1527030448384};\\\", \\\"{x:1318,y:944,t:1527030448401};\\\", \\\"{x:1318,y:945,t:1527030448431};\\\", \\\"{x:1318,y:946,t:1527030448439};\\\", \\\"{x:1318,y:947,t:1527030448452};\\\", \\\"{x:1318,y:948,t:1527030448527};\\\", \\\"{x:1318,y:949,t:1527030448543};\\\", \\\"{x:1318,y:950,t:1527030448551};\\\", \\\"{x:1318,y:951,t:1527030448583};\\\", \\\"{x:1318,y:952,t:1527030448602};\\\", \\\"{x:1318,y:953,t:1527030448617};\\\", \\\"{x:1318,y:954,t:1527030448634};\\\", \\\"{x:1317,y:956,t:1527030448651};\\\", \\\"{x:1317,y:958,t:1527030448668};\\\", \\\"{x:1317,y:959,t:1527030449568};\\\", \\\"{x:1317,y:963,t:1527030449586};\\\", \\\"{x:1317,y:965,t:1527030449603};\\\", \\\"{x:1317,y:966,t:1527030449618};\\\", \\\"{x:1317,y:967,t:1527030449635};\\\", \\\"{x:1317,y:968,t:1527030449655};\\\", \\\"{x:1317,y:969,t:1527030449668};\\\", \\\"{x:1317,y:970,t:1527030449685};\\\", \\\"{x:1317,y:972,t:1527030449703};\\\", \\\"{x:1317,y:973,t:1527030449719};\\\", \\\"{x:1317,y:974,t:1527030449735};\\\", \\\"{x:1316,y:975,t:1527030449855};\\\", \\\"{x:1314,y:975,t:1527030449871};\\\", \\\"{x:1314,y:974,t:1527030449992};\\\", \\\"{x:1314,y:973,t:1527030450246};\\\", \\\"{x:1314,y:972,t:1527030450254};\\\", \\\"{x:1314,y:971,t:1527030450269};\\\", \\\"{x:1314,y:970,t:1527030450284};\\\", \\\"{x:1314,y:969,t:1527030450302};\\\", \\\"{x:1315,y:968,t:1527030450319};\\\", \\\"{x:1316,y:967,t:1527030450335};\\\", \\\"{x:1318,y:966,t:1527030450439};\\\", \\\"{x:1320,y:966,t:1527030450452};\\\", \\\"{x:1324,y:966,t:1527030450470};\\\", \\\"{x:1330,y:966,t:1527030450486};\\\", \\\"{x:1337,y:966,t:1527030450502};\\\", \\\"{x:1350,y:966,t:1527030450519};\\\", \\\"{x:1357,y:967,t:1527030450536};\\\", \\\"{x:1359,y:967,t:1527030450552};\\\", \\\"{x:1361,y:967,t:1527030450569};\\\", \\\"{x:1359,y:968,t:1527030450734};\\\", \\\"{x:1358,y:969,t:1527030450742};\\\", \\\"{x:1357,y:969,t:1527030450751};\\\", \\\"{x:1352,y:969,t:1527030450768};\\\", \\\"{x:1350,y:969,t:1527030450786};\\\", \\\"{x:1347,y:969,t:1527030450801};\\\", \\\"{x:1345,y:969,t:1527030450830};\\\", \\\"{x:1344,y:969,t:1527030450912};\\\", \\\"{x:1344,y:968,t:1527030450999};\\\", \\\"{x:1345,y:968,t:1527030451015};\\\", \\\"{x:1347,y:968,t:1527030451024};\\\", \\\"{x:1350,y:968,t:1527030451037};\\\", \\\"{x:1354,y:968,t:1527030451053};\\\", \\\"{x:1363,y:968,t:1527030451070};\\\", \\\"{x:1367,y:969,t:1527030451086};\\\", \\\"{x:1376,y:970,t:1527030451103};\\\", \\\"{x:1378,y:970,t:1527030451119};\\\", \\\"{x:1380,y:971,t:1527030451143};\\\", \\\"{x:1381,y:971,t:1527030451199};\\\", \\\"{x:1382,y:971,t:1527030451215};\\\", \\\"{x:1383,y:971,t:1527030451231};\\\", \\\"{x:1384,y:971,t:1527030451239};\\\", \\\"{x:1385,y:971,t:1527030451271};\\\", \\\"{x:1385,y:969,t:1527030451447};\\\", \\\"{x:1385,y:968,t:1527030451454};\\\", \\\"{x:1385,y:967,t:1527030451471};\\\", \\\"{x:1385,y:966,t:1527030451519};\\\", \\\"{x:1385,y:965,t:1527030451559};\\\", \\\"{x:1385,y:966,t:1527030451951};\\\", \\\"{x:1385,y:967,t:1527030452016};\\\", \\\"{x:1384,y:968,t:1527030452047};\\\", \\\"{x:1383,y:968,t:1527030452072};\\\", \\\"{x:1381,y:968,t:1527030452087};\\\", \\\"{x:1379,y:968,t:1527030452103};\\\", \\\"{x:1377,y:970,t:1527030452120};\\\", \\\"{x:1372,y:971,t:1527030452137};\\\", \\\"{x:1371,y:971,t:1527030452154};\\\", \\\"{x:1368,y:971,t:1527030452171};\\\", \\\"{x:1366,y:971,t:1527030452207};\\\", \\\"{x:1365,y:971,t:1527030452225};\\\", \\\"{x:1364,y:971,t:1527030452367};\\\", \\\"{x:1363,y:971,t:1527030452383};\\\", \\\"{x:1361,y:970,t:1527030452415};\\\", \\\"{x:1359,y:969,t:1527030452488};\\\", \\\"{x:1359,y:968,t:1527030452519};\\\", \\\"{x:1357,y:967,t:1527030452538};\\\", \\\"{x:1355,y:967,t:1527030452554};\\\", \\\"{x:1354,y:967,t:1527030452570};\\\", \\\"{x:1352,y:967,t:1527030452588};\\\", \\\"{x:1351,y:967,t:1527030452604};\\\", \\\"{x:1350,y:967,t:1527030452620};\\\", \\\"{x:1348,y:967,t:1527030452638};\\\", \\\"{x:1345,y:967,t:1527030452655};\\\", \\\"{x:1344,y:967,t:1527030452670};\\\", \\\"{x:1341,y:967,t:1527030452687};\\\", \\\"{x:1341,y:966,t:1527030452767};\\\", \\\"{x:1342,y:965,t:1527030452815};\\\", \\\"{x:1343,y:965,t:1527030452927};\\\", \\\"{x:1343,y:964,t:1527030452976};\\\", \\\"{x:1344,y:964,t:1527030452988};\\\", \\\"{x:1344,y:963,t:1527030453004};\\\", \\\"{x:1345,y:963,t:1527030453062};\\\", \\\"{x:1346,y:963,t:1527030453070};\\\", \\\"{x:1351,y:963,t:1527030453086};\\\", \\\"{x:1354,y:963,t:1527030453104};\\\", \\\"{x:1358,y:963,t:1527030453121};\\\", \\\"{x:1359,y:963,t:1527030453137};\\\", \\\"{x:1361,y:963,t:1527030453153};\\\", \\\"{x:1362,y:963,t:1527030453171};\\\", \\\"{x:1366,y:965,t:1527030453187};\\\", \\\"{x:1367,y:965,t:1527030453204};\\\", \\\"{x:1369,y:965,t:1527030453230};\\\", \\\"{x:1371,y:965,t:1527030453247};\\\", \\\"{x:1372,y:965,t:1527030453335};\\\", \\\"{x:1373,y:966,t:1527030453343};\\\", \\\"{x:1374,y:966,t:1527030453359};\\\", \\\"{x:1375,y:966,t:1527030453424};\\\", \\\"{x:1377,y:966,t:1527030453535};\\\", \\\"{x:1378,y:966,t:1527030453567};\\\", \\\"{x:1380,y:966,t:1527030453687};\\\", \\\"{x:1382,y:966,t:1527030453704};\\\", \\\"{x:1383,y:966,t:1527030453722};\\\", \\\"{x:1385,y:965,t:1527030453739};\\\", \\\"{x:1387,y:965,t:1527030453754};\\\", \\\"{x:1391,y:965,t:1527030453771};\\\", \\\"{x:1394,y:964,t:1527030453791};\\\", \\\"{x:1397,y:963,t:1527030453805};\\\", \\\"{x:1400,y:962,t:1527030453822};\\\", \\\"{x:1401,y:962,t:1527030453839};\\\", \\\"{x:1403,y:962,t:1527030453999};\\\", \\\"{x:1404,y:962,t:1527030454007};\\\", \\\"{x:1405,y:962,t:1527030454021};\\\", \\\"{x:1407,y:962,t:1527030454038};\\\", \\\"{x:1409,y:961,t:1527030454055};\\\", \\\"{x:1411,y:961,t:1527030454071};\\\", \\\"{x:1412,y:961,t:1527030454246};\\\", \\\"{x:1415,y:961,t:1527030454559};\\\", \\\"{x:1416,y:961,t:1527030454573};\\\", \\\"{x:1422,y:960,t:1527030454589};\\\", \\\"{x:1430,y:959,t:1527030454605};\\\", \\\"{x:1438,y:959,t:1527030454623};\\\", \\\"{x:1443,y:959,t:1527030454639};\\\", \\\"{x:1447,y:960,t:1527030454656};\\\", \\\"{x:1450,y:961,t:1527030454672};\\\", \\\"{x:1453,y:962,t:1527030454688};\\\", \\\"{x:1454,y:962,t:1527030454711};\\\", \\\"{x:1455,y:962,t:1527030454723};\\\", \\\"{x:1456,y:962,t:1527030454739};\\\", \\\"{x:1458,y:962,t:1527030454756};\\\", \\\"{x:1459,y:962,t:1527030454773};\\\", \\\"{x:1461,y:964,t:1527030454789};\\\", \\\"{x:1462,y:964,t:1527030454806};\\\", \\\"{x:1465,y:964,t:1527030454822};\\\", \\\"{x:1466,y:964,t:1527030454840};\\\", \\\"{x:1468,y:965,t:1527030454856};\\\", \\\"{x:1470,y:965,t:1527030454935};\\\", \\\"{x:1472,y:965,t:1527030455151};\\\", \\\"{x:1473,y:965,t:1527030455159};\\\", \\\"{x:1475,y:965,t:1527030455175};\\\", \\\"{x:1476,y:965,t:1527030455190};\\\", \\\"{x:1479,y:965,t:1527030455206};\\\", \\\"{x:1486,y:965,t:1527030455222};\\\", \\\"{x:1489,y:965,t:1527030455239};\\\", \\\"{x:1492,y:965,t:1527030455257};\\\", \\\"{x:1493,y:965,t:1527030455273};\\\", \\\"{x:1499,y:965,t:1527030455289};\\\", \\\"{x:1505,y:966,t:1527030455306};\\\", \\\"{x:1509,y:966,t:1527030455322};\\\", \\\"{x:1514,y:966,t:1527030455340};\\\", \\\"{x:1520,y:967,t:1527030455357};\\\", \\\"{x:1523,y:968,t:1527030455372};\\\", \\\"{x:1525,y:968,t:1527030455390};\\\", \\\"{x:1529,y:969,t:1527030455407};\\\", \\\"{x:1530,y:969,t:1527030455527};\\\", \\\"{x:1532,y:969,t:1527030455550};\\\", \\\"{x:1533,y:969,t:1527030455567};\\\", \\\"{x:1535,y:968,t:1527030455583};\\\", \\\"{x:1536,y:968,t:1527030455591};\\\", \\\"{x:1538,y:968,t:1527030455606};\\\", \\\"{x:1540,y:968,t:1527030455622};\\\", \\\"{x:1543,y:968,t:1527030455639};\\\", \\\"{x:1546,y:968,t:1527030455656};\\\", \\\"{x:1547,y:968,t:1527030455679};\\\", \\\"{x:1548,y:968,t:1527030455695};\\\", \\\"{x:1549,y:967,t:1527030455743};\\\", \\\"{x:1549,y:966,t:1527030455839};\\\", \\\"{x:1549,y:965,t:1527030455862};\\\", \\\"{x:1549,y:964,t:1527030455951};\\\", \\\"{x:1548,y:964,t:1527030463294};\\\", \\\"{x:1526,y:953,t:1527030463312};\\\", \\\"{x:1473,y:932,t:1527030463329};\\\", \\\"{x:1402,y:901,t:1527030463344};\\\", \\\"{x:1309,y:867,t:1527030463362};\\\", \\\"{x:1228,y:841,t:1527030463379};\\\", \\\"{x:1150,y:816,t:1527030463396};\\\", \\\"{x:1078,y:787,t:1527030463412};\\\", \\\"{x:1013,y:762,t:1527030463429};\\\", \\\"{x:960,y:739,t:1527030463446};\\\", \\\"{x:929,y:724,t:1527030463462};\\\", \\\"{x:895,y:706,t:1527030463478};\\\", \\\"{x:877,y:697,t:1527030463495};\\\", \\\"{x:869,y:690,t:1527030463511};\\\", \\\"{x:859,y:682,t:1527030463529};\\\", \\\"{x:849,y:673,t:1527030463546};\\\", \\\"{x:839,y:662,t:1527030463562};\\\", \\\"{x:828,y:649,t:1527030463579};\\\", \\\"{x:817,y:637,t:1527030463595};\\\", \\\"{x:803,y:625,t:1527030463613};\\\", \\\"{x:788,y:614,t:1527030463628};\\\", \\\"{x:774,y:606,t:1527030463646};\\\", \\\"{x:755,y:596,t:1527030463662};\\\", \\\"{x:739,y:587,t:1527030463680};\\\", \\\"{x:725,y:582,t:1527030463695};\\\", \\\"{x:713,y:580,t:1527030463713};\\\", \\\"{x:701,y:578,t:1527030463729};\\\", \\\"{x:691,y:577,t:1527030463745};\\\", \\\"{x:684,y:576,t:1527030463762};\\\", \\\"{x:679,y:576,t:1527030463779};\\\", \\\"{x:675,y:576,t:1527030463796};\\\", \\\"{x:671,y:576,t:1527030463812};\\\", \\\"{x:669,y:576,t:1527030463829};\\\", \\\"{x:668,y:576,t:1527030463895};\\\", \\\"{x:668,y:577,t:1527030463926};\\\", \\\"{x:668,y:578,t:1527030463950};\\\", \\\"{x:668,y:579,t:1527030463974};\\\", \\\"{x:667,y:579,t:1527030463991};\\\", \\\"{x:666,y:579,t:1527030463998};\\\", \\\"{x:665,y:579,t:1527030464024};\\\", \\\"{x:662,y:580,t:1527030464037};\\\", \\\"{x:661,y:580,t:1527030464053};\\\", \\\"{x:660,y:581,t:1527030464063};\\\", \\\"{x:657,y:581,t:1527030464080};\\\", \\\"{x:653,y:583,t:1527030464097};\\\", \\\"{x:648,y:584,t:1527030464113};\\\", \\\"{x:643,y:585,t:1527030464129};\\\", \\\"{x:639,y:588,t:1527030464146};\\\", \\\"{x:635,y:590,t:1527030464164};\\\", \\\"{x:633,y:593,t:1527030464181};\\\", \\\"{x:631,y:595,t:1527030464196};\\\", \\\"{x:629,y:595,t:1527030464212};\\\", \\\"{x:629,y:596,t:1527030464229};\\\", \\\"{x:627,y:597,t:1527030464245};\\\", \\\"{x:625,y:598,t:1527030464262};\\\", \\\"{x:624,y:598,t:1527030464342};\\\", \\\"{x:624,y:597,t:1527030464399};\\\", \\\"{x:624,y:596,t:1527030464414};\\\", \\\"{x:624,y:595,t:1527030464430};\\\", \\\"{x:625,y:591,t:1527030464446};\\\", \\\"{x:625,y:590,t:1527030464464};\\\", \\\"{x:627,y:590,t:1527030464480};\\\", \\\"{x:627,y:589,t:1527030464550};\\\", \\\"{x:627,y:588,t:1527030464567};\\\", \\\"{x:627,y:587,t:1527030464605};\\\", \\\"{x:627,y:586,t:1527030464622};\\\", \\\"{x:626,y:585,t:1527030464638};\\\", \\\"{x:626,y:584,t:1527030464654};\\\", \\\"{x:625,y:584,t:1527030464670};\\\", \\\"{x:625,y:583,t:1527030464680};\\\", \\\"{x:623,y:582,t:1527030464697};\\\", \\\"{x:621,y:582,t:1527030464713};\\\", \\\"{x:619,y:580,t:1527030464730};\\\", \\\"{x:617,y:578,t:1527030464746};\\\", \\\"{x:615,y:576,t:1527030464763};\\\", \\\"{x:614,y:576,t:1527030464782};\\\", \\\"{x:613,y:576,t:1527030464806};\\\", \\\"{x:613,y:575,t:1527030464814};\\\", \\\"{x:611,y:575,t:1527030464838};\\\", \\\"{x:610,y:574,t:1527030464846};\\\", \\\"{x:609,y:573,t:1527030464870};\\\", \\\"{x:608,y:572,t:1527030464903};\\\", \\\"{x:608,y:571,t:1527030464982};\\\", \\\"{x:608,y:570,t:1527030464997};\\\", \\\"{x:608,y:569,t:1527030465014};\\\", \\\"{x:609,y:566,t:1527030465031};\\\", \\\"{x:609,y:565,t:1527030465047};\\\", \\\"{x:611,y:564,t:1527030465064};\\\", \\\"{x:611,y:563,t:1527030465081};\\\", \\\"{x:613,y:564,t:1527030465110};\\\", \\\"{x:616,y:567,t:1527030465119};\\\", \\\"{x:618,y:569,t:1527030465131};\\\", \\\"{x:620,y:575,t:1527030465149};\\\", \\\"{x:621,y:580,t:1527030465163};\\\", \\\"{x:621,y:584,t:1527030465182};\\\", \\\"{x:621,y:589,t:1527030465198};\\\", \\\"{x:621,y:590,t:1527030465213};\\\", \\\"{x:621,y:593,t:1527030465230};\\\", \\\"{x:621,y:595,t:1527030465254};\\\", \\\"{x:621,y:596,t:1527030465263};\\\", \\\"{x:621,y:599,t:1527030465281};\\\", \\\"{x:621,y:602,t:1527030465297};\\\", \\\"{x:621,y:605,t:1527030465313};\\\", \\\"{x:621,y:606,t:1527030465330};\\\", \\\"{x:621,y:607,t:1527030465366};\\\", \\\"{x:621,y:608,t:1527030465381};\\\", \\\"{x:620,y:609,t:1527030465405};\\\", \\\"{x:620,y:610,t:1527030465430};\\\", \\\"{x:619,y:610,t:1527030465447};\\\", \\\"{x:618,y:610,t:1527030465463};\\\", \\\"{x:618,y:611,t:1527030465790};\\\", \\\"{x:620,y:611,t:1527030465797};\\\", \\\"{x:629,y:616,t:1527030465813};\\\", \\\"{x:658,y:623,t:1527030465831};\\\", \\\"{x:709,y:639,t:1527030465848};\\\", \\\"{x:781,y:659,t:1527030465864};\\\", \\\"{x:880,y:687,t:1527030465880};\\\", \\\"{x:991,y:717,t:1527030465898};\\\", \\\"{x:1113,y:753,t:1527030465914};\\\", \\\"{x:1227,y:793,t:1527030465932};\\\", \\\"{x:1332,y:823,t:1527030465947};\\\", \\\"{x:1406,y:849,t:1527030465965};\\\", \\\"{x:1472,y:866,t:1527030465982};\\\", \\\"{x:1515,y:887,t:1527030465998};\\\", \\\"{x:1548,y:904,t:1527030466014};\\\", \\\"{x:1553,y:907,t:1527030466031};\\\", \\\"{x:1556,y:912,t:1527030466048};\\\", \\\"{x:1560,y:918,t:1527030466064};\\\", \\\"{x:1567,y:930,t:1527030466082};\\\", \\\"{x:1572,y:936,t:1527030466097};\\\", \\\"{x:1574,y:940,t:1527030466115};\\\", \\\"{x:1577,y:944,t:1527030466132};\\\", \\\"{x:1581,y:949,t:1527030466148};\\\", \\\"{x:1586,y:956,t:1527030466165};\\\", \\\"{x:1594,y:964,t:1527030466183};\\\", \\\"{x:1598,y:969,t:1527030466198};\\\", \\\"{x:1599,y:971,t:1527030466214};\\\", \\\"{x:1599,y:972,t:1527030466247};\\\", \\\"{x:1599,y:973,t:1527030466265};\\\", \\\"{x:1597,y:975,t:1527030466282};\\\", \\\"{x:1595,y:976,t:1527030466297};\\\", \\\"{x:1587,y:976,t:1527030466315};\\\", \\\"{x:1578,y:977,t:1527030466332};\\\", \\\"{x:1572,y:979,t:1527030466348};\\\", \\\"{x:1566,y:979,t:1527030466365};\\\", \\\"{x:1561,y:979,t:1527030466382};\\\", \\\"{x:1556,y:979,t:1527030466399};\\\", \\\"{x:1550,y:978,t:1527030466415};\\\", \\\"{x:1546,y:978,t:1527030466432};\\\", \\\"{x:1541,y:978,t:1527030466449};\\\", \\\"{x:1539,y:976,t:1527030466465};\\\", \\\"{x:1538,y:976,t:1527030466486};\\\", \\\"{x:1538,y:975,t:1527030466518};\\\", \\\"{x:1538,y:974,t:1527030466532};\\\", \\\"{x:1538,y:973,t:1527030466549};\\\", \\\"{x:1538,y:972,t:1527030466565};\\\", \\\"{x:1538,y:971,t:1527030466581};\\\", \\\"{x:1538,y:970,t:1527030466599};\\\", \\\"{x:1538,y:969,t:1527030466615};\\\", \\\"{x:1538,y:968,t:1527030466632};\\\", \\\"{x:1538,y:967,t:1527030466649};\\\", \\\"{x:1538,y:966,t:1527030466664};\\\", \\\"{x:1538,y:964,t:1527030466687};\\\", \\\"{x:1538,y:963,t:1527030466703};\\\", \\\"{x:1538,y:962,t:1527030466719};\\\", \\\"{x:1538,y:961,t:1527030466815};\\\", \\\"{x:1538,y:960,t:1527030466839};\\\", \\\"{x:1538,y:959,t:1527030466871};\\\", \\\"{x:1539,y:959,t:1527030466895};\\\", \\\"{x:1540,y:959,t:1527030466951};\\\", \\\"{x:1542,y:959,t:1527030466983};\\\", \\\"{x:1543,y:959,t:1527030466999};\\\", \\\"{x:1545,y:959,t:1527030467055};\\\", \\\"{x:1547,y:959,t:1527030467072};\\\", \\\"{x:1549,y:959,t:1527030467082};\\\", \\\"{x:1552,y:959,t:1527030467099};\\\", \\\"{x:1553,y:959,t:1527030467116};\\\", \\\"{x:1555,y:959,t:1527030467132};\\\", \\\"{x:1557,y:959,t:1527030467149};\\\", \\\"{x:1557,y:960,t:1527030467447};\\\", \\\"{x:1557,y:961,t:1527030467455};\\\", \\\"{x:1556,y:961,t:1527030472523};\\\", \\\"{x:1555,y:961,t:1527030472546};\\\", \\\"{x:1554,y:961,t:1527030472579};\\\", \\\"{x:1553,y:961,t:1527030472602};\\\", \\\"{x:1552,y:961,t:1527030472683};\\\", \\\"{x:1551,y:961,t:1527030472706};\\\", \\\"{x:1550,y:961,t:1527030472724};\\\", \\\"{x:1549,y:962,t:1527030472746};\\\", \\\"{x:1548,y:962,t:1527030472771};\\\", \\\"{x:1547,y:962,t:1527030472779};\\\", \\\"{x:1546,y:962,t:1527030472795};\\\", \\\"{x:1546,y:963,t:1527030472808};\\\", \\\"{x:1545,y:963,t:1527030472898};\\\", \\\"{x:1544,y:963,t:1527030474035};\\\", \\\"{x:1545,y:962,t:1527030477163};\\\", \\\"{x:1547,y:961,t:1527030477178};\\\", \\\"{x:1548,y:961,t:1527030477195};\\\", \\\"{x:1549,y:960,t:1527030477723};\\\", \\\"{x:1549,y:959,t:1527030477746};\\\", \\\"{x:1548,y:958,t:1527030477762};\\\", \\\"{x:1548,y:959,t:1527030478515};\\\", \\\"{x:1548,y:960,t:1527030478528};\\\", \\\"{x:1548,y:961,t:1527030478554};\\\", \\\"{x:1548,y:962,t:1527030478578};\\\", \\\"{x:1548,y:963,t:1527030478595};\\\", \\\"{x:1539,y:962,t:1527030480953};\\\", \\\"{x:1525,y:962,t:1527030480963};\\\", \\\"{x:1470,y:962,t:1527030480979};\\\", \\\"{x:1382,y:953,t:1527030480996};\\\", \\\"{x:1281,y:937,t:1527030481014};\\\", \\\"{x:1169,y:910,t:1527030481029};\\\", \\\"{x:1068,y:890,t:1527030481047};\\\", \\\"{x:971,y:865,t:1527030481064};\\\", \\\"{x:880,y:841,t:1527030481080};\\\", \\\"{x:804,y:823,t:1527030481096};\\\", \\\"{x:752,y:812,t:1527030481113};\\\", \\\"{x:727,y:808,t:1527030481129};\\\", \\\"{x:709,y:804,t:1527030481146};\\\", \\\"{x:690,y:801,t:1527030481163};\\\", \\\"{x:675,y:797,t:1527030481180};\\\", \\\"{x:652,y:792,t:1527030481196};\\\", \\\"{x:630,y:785,t:1527030481213};\\\", \\\"{x:608,y:779,t:1527030481230};\\\", \\\"{x:600,y:775,t:1527030481247};\\\", \\\"{x:589,y:771,t:1527030481263};\\\", \\\"{x:580,y:769,t:1527030481280};\\\", \\\"{x:571,y:765,t:1527030481297};\\\", \\\"{x:564,y:761,t:1527030481314};\\\", \\\"{x:560,y:758,t:1527030481331};\\\", \\\"{x:556,y:755,t:1527030481347};\\\", \\\"{x:552,y:749,t:1527030481365};\\\", \\\"{x:552,y:743,t:1527030481380};\\\", \\\"{x:548,y:737,t:1527030481396};\\\", \\\"{x:547,y:734,t:1527030481412};\\\", \\\"{x:544,y:728,t:1527030481429};\\\", \\\"{x:540,y:722,t:1527030481446};\\\", \\\"{x:539,y:721,t:1527030481462};\\\", \\\"{x:537,y:719,t:1527030481480};\\\", \\\"{x:537,y:718,t:1527030481496};\\\", \\\"{x:537,y:719,t:1527030481842};\\\", \\\"{x:537,y:720,t:1527030481849};\\\", \\\"{x:536,y:722,t:1527030481863};\\\", \\\"{x:536,y:723,t:1527030481880};\\\", \\\"{x:535,y:725,t:1527030481898};\\\", \\\"{x:534,y:726,t:1527030481914};\\\", \\\"{x:534,y:727,t:1527030482074};\\\", \\\"{x:536,y:727,t:1527030482081};\\\", \\\"{x:539,y:727,t:1527030482098};\\\", \\\"{x:543,y:727,t:1527030482114};\\\", \\\"{x:548,y:727,t:1527030482130};\\\", \\\"{x:556,y:727,t:1527030482148};\\\", \\\"{x:565,y:727,t:1527030482165};\\\", \\\"{x:571,y:727,t:1527030482181};\\\", \\\"{x:574,y:727,t:1527030482198};\\\", \\\"{x:576,y:727,t:1527030482214};\\\", \\\"{x:578,y:727,t:1527030482231};\\\", \\\"{x:579,y:727,t:1527030482247};\\\", \\\"{x:579,y:728,t:1527030482265};\\\" ] }, { \\\"rt\\\": 8442, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 380864, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:579,y:726,t:1527030484010};\\\", \\\"{x:579,y:718,t:1527030484018};\\\", \\\"{x:579,y:712,t:1527030484032};\\\", \\\"{x:580,y:706,t:1527030484049};\\\", \\\"{x:587,y:691,t:1527030484065};\\\", \\\"{x:599,y:679,t:1527030484082};\\\", \\\"{x:613,y:670,t:1527030484099};\\\", \\\"{x:635,y:666,t:1527030484117};\\\", \\\"{x:658,y:666,t:1527030484133};\\\", \\\"{x:687,y:666,t:1527030484149};\\\", \\\"{x:715,y:666,t:1527030484166};\\\", \\\"{x:741,y:667,t:1527030484183};\\\", \\\"{x:757,y:669,t:1527030484199};\\\", \\\"{x:766,y:673,t:1527030484216};\\\", \\\"{x:769,y:674,t:1527030484234};\\\", \\\"{x:770,y:675,t:1527030484249};\\\", \\\"{x:771,y:678,t:1527030484266};\\\", \\\"{x:770,y:679,t:1527030484298};\\\", \\\"{x:767,y:679,t:1527030484316};\\\", \\\"{x:775,y:681,t:1527030484778};\\\", \\\"{x:784,y:681,t:1527030484786};\\\", \\\"{x:803,y:681,t:1527030484801};\\\", \\\"{x:834,y:691,t:1527030484817};\\\", \\\"{x:870,y:699,t:1527030484833};\\\", \\\"{x:928,y:714,t:1527030484850};\\\", \\\"{x:974,y:725,t:1527030484866};\\\", \\\"{x:1022,y:732,t:1527030484884};\\\", \\\"{x:1081,y:741,t:1527030484900};\\\", \\\"{x:1158,y:753,t:1527030484927};\\\", \\\"{x:1180,y:757,t:1527030484933};\\\", \\\"{x:1244,y:775,t:1527030484950};\\\", \\\"{x:1308,y:785,t:1527030484966};\\\", \\\"{x:1357,y:794,t:1527030484982};\\\", \\\"{x:1403,y:805,t:1527030485000};\\\", \\\"{x:1450,y:817,t:1527030485015};\\\", \\\"{x:1484,y:827,t:1527030485033};\\\", \\\"{x:1520,y:837,t:1527030485050};\\\", \\\"{x:1537,y:843,t:1527030485066};\\\", \\\"{x:1552,y:848,t:1527030485082};\\\", \\\"{x:1557,y:850,t:1527030485100};\\\", \\\"{x:1560,y:853,t:1527030485116};\\\", \\\"{x:1561,y:853,t:1527030485132};\\\", \\\"{x:1563,y:855,t:1527030485150};\\\", \\\"{x:1563,y:856,t:1527030485167};\\\", \\\"{x:1563,y:861,t:1527030485183};\\\", \\\"{x:1563,y:866,t:1527030485200};\\\", \\\"{x:1563,y:870,t:1527030485216};\\\", \\\"{x:1563,y:874,t:1527030485233};\\\", \\\"{x:1560,y:879,t:1527030485250};\\\", \\\"{x:1556,y:882,t:1527030485268};\\\", \\\"{x:1552,y:886,t:1527030485284};\\\", \\\"{x:1545,y:889,t:1527030485300};\\\", \\\"{x:1540,y:890,t:1527030485317};\\\", \\\"{x:1534,y:893,t:1527030485333};\\\", \\\"{x:1530,y:894,t:1527030485350};\\\", \\\"{x:1527,y:894,t:1527030485368};\\\", \\\"{x:1526,y:894,t:1527030485383};\\\", \\\"{x:1525,y:895,t:1527030485401};\\\", \\\"{x:1525,y:894,t:1527030485602};\\\", \\\"{x:1525,y:893,t:1527030485617};\\\", \\\"{x:1525,y:892,t:1527030485633};\\\", \\\"{x:1525,y:890,t:1527030485650};\\\", \\\"{x:1525,y:889,t:1527030485668};\\\", \\\"{x:1527,y:886,t:1527030485684};\\\", \\\"{x:1528,y:884,t:1527030485700};\\\", \\\"{x:1531,y:879,t:1527030485717};\\\", \\\"{x:1533,y:876,t:1527030485735};\\\", \\\"{x:1537,y:873,t:1527030485750};\\\", \\\"{x:1538,y:869,t:1527030485768};\\\", \\\"{x:1542,y:866,t:1527030485785};\\\", \\\"{x:1546,y:862,t:1527030485800};\\\", \\\"{x:1553,y:856,t:1527030485816};\\\", \\\"{x:1560,y:850,t:1527030485833};\\\", \\\"{x:1566,y:844,t:1527030485849};\\\", \\\"{x:1573,y:838,t:1527030485867};\\\", \\\"{x:1583,y:830,t:1527030485884};\\\", \\\"{x:1592,y:820,t:1527030485899};\\\", \\\"{x:1602,y:807,t:1527030485917};\\\", \\\"{x:1612,y:792,t:1527030485934};\\\", \\\"{x:1624,y:775,t:1527030485950};\\\", \\\"{x:1634,y:752,t:1527030485966};\\\", \\\"{x:1640,y:732,t:1527030485984};\\\", \\\"{x:1644,y:714,t:1527030486000};\\\", \\\"{x:1644,y:700,t:1527030486017};\\\", \\\"{x:1640,y:683,t:1527030486033};\\\", \\\"{x:1633,y:674,t:1527030486050};\\\", \\\"{x:1625,y:665,t:1527030486067};\\\", \\\"{x:1617,y:658,t:1527030486084};\\\", \\\"{x:1607,y:651,t:1527030486100};\\\", \\\"{x:1597,y:643,t:1527030486117};\\\", \\\"{x:1587,y:640,t:1527030486134};\\\", \\\"{x:1570,y:633,t:1527030486151};\\\", \\\"{x:1547,y:627,t:1527030486168};\\\", \\\"{x:1526,y:621,t:1527030486184};\\\", \\\"{x:1507,y:616,t:1527030486200};\\\", \\\"{x:1489,y:614,t:1527030486217};\\\", \\\"{x:1467,y:611,t:1527030486233};\\\", \\\"{x:1452,y:609,t:1527030486251};\\\", \\\"{x:1439,y:606,t:1527030486267};\\\", \\\"{x:1428,y:605,t:1527030486284};\\\", \\\"{x:1418,y:605,t:1527030486301};\\\", \\\"{x:1413,y:605,t:1527030486318};\\\", \\\"{x:1403,y:604,t:1527030486334};\\\", \\\"{x:1391,y:601,t:1527030486352};\\\", \\\"{x:1377,y:598,t:1527030486367};\\\", \\\"{x:1361,y:594,t:1527030486385};\\\", \\\"{x:1347,y:590,t:1527030486401};\\\", \\\"{x:1333,y:588,t:1527030486417};\\\", \\\"{x:1309,y:583,t:1527030486434};\\\", \\\"{x:1294,y:578,t:1527030486452};\\\", \\\"{x:1280,y:573,t:1527030486468};\\\", \\\"{x:1272,y:570,t:1527030486484};\\\", \\\"{x:1265,y:566,t:1527030486502};\\\", \\\"{x:1260,y:562,t:1527030486517};\\\", \\\"{x:1256,y:560,t:1527030486535};\\\", \\\"{x:1254,y:557,t:1527030486551};\\\", \\\"{x:1254,y:555,t:1527030486570};\\\", \\\"{x:1254,y:554,t:1527030486586};\\\", \\\"{x:1254,y:552,t:1527030486602};\\\", \\\"{x:1254,y:551,t:1527030486618};\\\", \\\"{x:1255,y:551,t:1527030486634};\\\", \\\"{x:1256,y:551,t:1527030486652};\\\", \\\"{x:1258,y:550,t:1527030486668};\\\", \\\"{x:1263,y:549,t:1527030486684};\\\", \\\"{x:1270,y:548,t:1527030486701};\\\", \\\"{x:1275,y:548,t:1527030486719};\\\", \\\"{x:1279,y:548,t:1527030486735};\\\", \\\"{x:1282,y:548,t:1527030486751};\\\", \\\"{x:1283,y:548,t:1527030486769};\\\", \\\"{x:1286,y:548,t:1527030486785};\\\", \\\"{x:1288,y:549,t:1527030486801};\\\", \\\"{x:1290,y:551,t:1527030486819};\\\", \\\"{x:1291,y:552,t:1527030486834};\\\", \\\"{x:1293,y:553,t:1527030486851};\\\", \\\"{x:1293,y:554,t:1527030486869};\\\", \\\"{x:1294,y:554,t:1527030486884};\\\", \\\"{x:1294,y:555,t:1527030486938};\\\", \\\"{x:1294,y:556,t:1527030486951};\\\", \\\"{x:1294,y:557,t:1527030486978};\\\", \\\"{x:1294,y:558,t:1527030487002};\\\", \\\"{x:1294,y:559,t:1527030487018};\\\", \\\"{x:1294,y:560,t:1527030487035};\\\", \\\"{x:1293,y:561,t:1527030487052};\\\", \\\"{x:1289,y:562,t:1527030487068};\\\", \\\"{x:1286,y:562,t:1527030487085};\\\", \\\"{x:1281,y:563,t:1527030487101};\\\", \\\"{x:1279,y:563,t:1527030487119};\\\", \\\"{x:1275,y:563,t:1527030487135};\\\", \\\"{x:1274,y:563,t:1527030487153};\\\", \\\"{x:1273,y:563,t:1527030487169};\\\", \\\"{x:1272,y:563,t:1527030487185};\\\", \\\"{x:1271,y:563,t:1527030487226};\\\", \\\"{x:1272,y:562,t:1527030487675};\\\", \\\"{x:1275,y:562,t:1527030487685};\\\", \\\"{x:1287,y:562,t:1527030487703};\\\", \\\"{x:1307,y:562,t:1527030487718};\\\", \\\"{x:1327,y:562,t:1527030487736};\\\", \\\"{x:1357,y:562,t:1527030487753};\\\", \\\"{x:1383,y:562,t:1527030487768};\\\", \\\"{x:1402,y:562,t:1527030487786};\\\", \\\"{x:1427,y:559,t:1527030487802};\\\", \\\"{x:1433,y:559,t:1527030487818};\\\", \\\"{x:1438,y:558,t:1527030487835};\\\", \\\"{x:1438,y:559,t:1527030487978};\\\", \\\"{x:1438,y:560,t:1527030487985};\\\", \\\"{x:1438,y:565,t:1527030488002};\\\", \\\"{x:1434,y:569,t:1527030488017};\\\", \\\"{x:1423,y:576,t:1527030488035};\\\", \\\"{x:1404,y:581,t:1527030488052};\\\", \\\"{x:1357,y:589,t:1527030488069};\\\", \\\"{x:1289,y:592,t:1527030488085};\\\", \\\"{x:1202,y:598,t:1527030488102};\\\", \\\"{x:1107,y:599,t:1527030488119};\\\", \\\"{x:991,y:599,t:1527030488135};\\\", \\\"{x:885,y:599,t:1527030488152};\\\", \\\"{x:796,y:599,t:1527030488169};\\\", \\\"{x:730,y:599,t:1527030488185};\\\", \\\"{x:675,y:606,t:1527030488203};\\\", \\\"{x:658,y:612,t:1527030488219};\\\", \\\"{x:648,y:618,t:1527030488234};\\\", \\\"{x:642,y:626,t:1527030488251};\\\", \\\"{x:637,y:641,t:1527030488268};\\\", \\\"{x:631,y:653,t:1527030488285};\\\", \\\"{x:624,y:667,t:1527030488301};\\\", \\\"{x:618,y:686,t:1527030488319};\\\", \\\"{x:611,y:697,t:1527030488336};\\\", \\\"{x:602,y:702,t:1527030488351};\\\", \\\"{x:601,y:704,t:1527030488369};\\\", \\\"{x:608,y:704,t:1527030488674};\\\", \\\"{x:621,y:707,t:1527030488686};\\\", \\\"{x:646,y:712,t:1527030488704};\\\", \\\"{x:662,y:714,t:1527030488719};\\\", \\\"{x:675,y:716,t:1527030488736};\\\", \\\"{x:699,y:719,t:1527030488753};\\\", \\\"{x:709,y:722,t:1527030488770};\\\", \\\"{x:733,y:731,t:1527030488786};\\\", \\\"{x:756,y:738,t:1527030488803};\\\", \\\"{x:781,y:747,t:1527030488819};\\\", \\\"{x:806,y:758,t:1527030488836};\\\", \\\"{x:830,y:768,t:1527030488853};\\\", \\\"{x:853,y:779,t:1527030488869};\\\", \\\"{x:870,y:787,t:1527030488886};\\\", \\\"{x:878,y:796,t:1527030488903};\\\", \\\"{x:879,y:798,t:1527030488919};\\\", \\\"{x:879,y:799,t:1527030488936};\\\", \\\"{x:877,y:803,t:1527030488954};\\\", \\\"{x:875,y:804,t:1527030488970};\\\", \\\"{x:869,y:805,t:1527030488986};\\\", \\\"{x:866,y:805,t:1527030489004};\\\", \\\"{x:859,y:805,t:1527030489019};\\\", \\\"{x:849,y:805,t:1527030489036};\\\", \\\"{x:835,y:803,t:1527030489053};\\\", \\\"{x:824,y:798,t:1527030489069};\\\", \\\"{x:817,y:796,t:1527030489086};\\\", \\\"{x:813,y:792,t:1527030489103};\\\", \\\"{x:812,y:789,t:1527030489120};\\\", \\\"{x:809,y:781,t:1527030489136};\\\", \\\"{x:807,y:763,t:1527030489153};\\\", \\\"{x:806,y:750,t:1527030489169};\\\", \\\"{x:803,y:734,t:1527030489185};\\\", \\\"{x:799,y:724,t:1527030489203};\\\", \\\"{x:797,y:721,t:1527030489220};\\\", \\\"{x:791,y:717,t:1527030489236};\\\", \\\"{x:791,y:716,t:1527030489253};\\\", \\\"{x:781,y:707,t:1527030489271};\\\", \\\"{x:771,y:698,t:1527030489286};\\\", \\\"{x:766,y:694,t:1527030489303};\\\", \\\"{x:754,y:688,t:1527030489320};\\\", \\\"{x:750,y:683,t:1527030489337};\\\", \\\"{x:744,y:679,t:1527030489353};\\\", \\\"{x:744,y:674,t:1527030489369};\\\", \\\"{x:736,y:666,t:1527030489386};\\\", \\\"{x:731,y:659,t:1527030489404};\\\", \\\"{x:726,y:648,t:1527030489421};\\\", \\\"{x:721,y:632,t:1527030489436};\\\", \\\"{x:715,y:619,t:1527030489454};\\\", \\\"{x:707,y:604,t:1527030489470};\\\", \\\"{x:698,y:591,t:1527030489487};\\\", \\\"{x:687,y:574,t:1527030489504};\\\", \\\"{x:677,y:559,t:1527030489521};\\\", \\\"{x:663,y:539,t:1527030489538};\\\", \\\"{x:656,y:527,t:1527030489553};\\\", \\\"{x:648,y:517,t:1527030489570};\\\", \\\"{x:644,y:508,t:1527030489587};\\\", \\\"{x:638,y:497,t:1527030489603};\\\", \\\"{x:632,y:489,t:1527030489620};\\\", \\\"{x:628,y:484,t:1527030489637};\\\", \\\"{x:626,y:482,t:1527030489652};\\\", \\\"{x:624,y:479,t:1527030489669};\\\", \\\"{x:623,y:477,t:1527030489687};\\\", \\\"{x:622,y:477,t:1527030489703};\\\", \\\"{x:619,y:475,t:1527030489719};\\\", \\\"{x:618,y:475,t:1527030489769};\\\", \\\"{x:618,y:479,t:1527030489787};\\\", \\\"{x:618,y:482,t:1527030489803};\\\", \\\"{x:619,y:486,t:1527030489820};\\\", \\\"{x:621,y:489,t:1527030489838};\\\", \\\"{x:621,y:492,t:1527030489854};\\\", \\\"{x:621,y:494,t:1527030489870};\\\", \\\"{x:620,y:497,t:1527030489887};\\\", \\\"{x:617,y:503,t:1527030489904};\\\", \\\"{x:610,y:510,t:1527030489920};\\\", \\\"{x:607,y:512,t:1527030489937};\\\", \\\"{x:607,y:513,t:1527030489953};\\\", \\\"{x:607,y:512,t:1527030490225};\\\", \\\"{x:608,y:511,t:1527030490237};\\\", \\\"{x:615,y:508,t:1527030490253};\\\", \\\"{x:624,y:507,t:1527030490271};\\\", \\\"{x:631,y:506,t:1527030490287};\\\", \\\"{x:645,y:506,t:1527030490304};\\\", \\\"{x:671,y:506,t:1527030490321};\\\", \\\"{x:690,y:510,t:1527030490337};\\\", \\\"{x:717,y:517,t:1527030490354};\\\", \\\"{x:745,y:527,t:1527030490371};\\\", \\\"{x:773,y:534,t:1527030490387};\\\", \\\"{x:796,y:540,t:1527030490404};\\\", \\\"{x:816,y:546,t:1527030490421};\\\", \\\"{x:819,y:548,t:1527030490436};\\\", \\\"{x:825,y:553,t:1527030490454};\\\", \\\"{x:827,y:553,t:1527030490471};\\\", \\\"{x:827,y:552,t:1527030490594};\\\", \\\"{x:827,y:550,t:1527030490619};\\\", \\\"{x:827,y:549,t:1527030490681};\\\", \\\"{x:828,y:549,t:1527030490713};\\\", \\\"{x:829,y:549,t:1527030490721};\\\", \\\"{x:834,y:548,t:1527030490737};\\\", \\\"{x:835,y:547,t:1527030490753};\\\", \\\"{x:836,y:546,t:1527030490771};\\\", \\\"{x:837,y:546,t:1527030490787};\\\", \\\"{x:837,y:545,t:1527030490825};\\\", \\\"{x:837,y:544,t:1527030490841};\\\", \\\"{x:837,y:543,t:1527030490854};\\\", \\\"{x:837,y:540,t:1527030490871};\\\", \\\"{x:837,y:539,t:1527030491105};\\\", \\\"{x:829,y:542,t:1527030491121};\\\", \\\"{x:809,y:554,t:1527030491138};\\\", \\\"{x:776,y:575,t:1527030491155};\\\", \\\"{x:735,y:598,t:1527030491171};\\\", \\\"{x:688,y:618,t:1527030491189};\\\", \\\"{x:649,y:637,t:1527030491206};\\\", \\\"{x:605,y:662,t:1527030491221};\\\", \\\"{x:571,y:678,t:1527030491238};\\\", \\\"{x:544,y:690,t:1527030491254};\\\", \\\"{x:526,y:698,t:1527030491271};\\\", \\\"{x:508,y:707,t:1527030491288};\\\", \\\"{x:493,y:716,t:1527030491304};\\\", \\\"{x:476,y:727,t:1527030491322};\\\", \\\"{x:472,y:731,t:1527030491338};\\\", \\\"{x:471,y:732,t:1527030491506};\\\", \\\"{x:471,y:733,t:1527030491522};\\\", \\\"{x:473,y:734,t:1527030491538};\\\", \\\"{x:474,y:734,t:1527030491556};\\\", \\\"{x:476,y:735,t:1527030491578};\\\", \\\"{x:477,y:736,t:1527030491881};\\\", \\\"{x:478,y:736,t:1527030491897};\\\", \\\"{x:481,y:737,t:1527030491905};\\\", \\\"{x:494,y:741,t:1527030491921};\\\", \\\"{x:499,y:743,t:1527030491938};\\\", \\\"{x:500,y:743,t:1527030492546};\\\", \\\"{x:505,y:743,t:1527030492555};\\\", \\\"{x:516,y:743,t:1527030492572};\\\", \\\"{x:527,y:743,t:1527030492589};\\\", \\\"{x:530,y:743,t:1527030492606};\\\", \\\"{x:534,y:743,t:1527030492622};\\\", \\\"{x:541,y:743,t:1527030492639};\\\", \\\"{x:549,y:746,t:1527030492656};\\\", \\\"{x:558,y:748,t:1527030492672};\\\", \\\"{x:583,y:752,t:1527030492690};\\\", \\\"{x:609,y:757,t:1527030492706};\\\", \\\"{x:640,y:764,t:1527030492722};\\\", \\\"{x:683,y:776,t:1527030492747};\\\", \\\"{x:694,y:781,t:1527030492756};\\\", \\\"{x:720,y:787,t:1527030492772};\\\", \\\"{x:739,y:797,t:1527030492788};\\\", \\\"{x:752,y:804,t:1527030492806};\\\", \\\"{x:769,y:812,t:1527030492821};\\\" ] }, { \\\"rt\\\": 20761, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 402904, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:809,y:842,t:1527030493002};\\\", \\\"{x:809,y:843,t:1527030493570};\\\", \\\"{x:808,y:843,t:1527030493585};\\\", \\\"{x:806,y:842,t:1527030493593};\\\", \\\"{x:804,y:840,t:1527030493606};\\\", \\\"{x:799,y:839,t:1527030493624};\\\", \\\"{x:795,y:835,t:1527030493640};\\\", \\\"{x:790,y:834,t:1527030493656};\\\", \\\"{x:788,y:833,t:1527030493673};\\\", \\\"{x:787,y:832,t:1527030493690};\\\", \\\"{x:784,y:833,t:1527030493850};\\\", \\\"{x:783,y:833,t:1527030493882};\\\", \\\"{x:782,y:833,t:1527030494202};\\\", \\\"{x:782,y:834,t:1527030494210};\\\", \\\"{x:782,y:833,t:1527030494570};\\\", \\\"{x:783,y:831,t:1527030494577};\\\", \\\"{x:784,y:831,t:1527030494594};\\\", \\\"{x:786,y:829,t:1527030494609};\\\", \\\"{x:786,y:828,t:1527030494714};\\\", \\\"{x:786,y:827,t:1527030494730};\\\", \\\"{x:786,y:825,t:1527030494742};\\\", \\\"{x:786,y:823,t:1527030494762};\\\", \\\"{x:787,y:823,t:1527030494810};\\\", \\\"{x:787,y:822,t:1527030496299};\\\", \\\"{x:788,y:820,t:1527030496450};\\\", \\\"{x:789,y:820,t:1527030496562};\\\", \\\"{x:791,y:818,t:1527030496586};\\\", \\\"{x:792,y:818,t:1527030496643};\\\", \\\"{x:795,y:816,t:1527030498138};\\\", \\\"{x:798,y:816,t:1527030498145};\\\", \\\"{x:800,y:816,t:1527030498161};\\\", \\\"{x:802,y:815,t:1527030498177};\\\", \\\"{x:807,y:813,t:1527030498193};\\\", \\\"{x:809,y:812,t:1527030498210};\\\", \\\"{x:812,y:811,t:1527030498226};\\\", \\\"{x:816,y:811,t:1527030498244};\\\", \\\"{x:823,y:808,t:1527030498261};\\\", \\\"{x:829,y:807,t:1527030498278};\\\", \\\"{x:842,y:804,t:1527030498293};\\\", \\\"{x:862,y:802,t:1527030498311};\\\", \\\"{x:881,y:797,t:1527030498328};\\\", \\\"{x:907,y:794,t:1527030498344};\\\", \\\"{x:930,y:792,t:1527030498361};\\\", \\\"{x:977,y:788,t:1527030498377};\\\", \\\"{x:1010,y:787,t:1527030498394};\\\", \\\"{x:1048,y:786,t:1527030498411};\\\", \\\"{x:1084,y:782,t:1527030498428};\\\", \\\"{x:1135,y:772,t:1527030498444};\\\", \\\"{x:1193,y:766,t:1527030498461};\\\", \\\"{x:1255,y:757,t:1527030498478};\\\", \\\"{x:1304,y:753,t:1527030498494};\\\", \\\"{x:1351,y:747,t:1527030498511};\\\", \\\"{x:1405,y:731,t:1527030498528};\\\", \\\"{x:1444,y:720,t:1527030498544};\\\", \\\"{x:1471,y:714,t:1527030498561};\\\", \\\"{x:1510,y:707,t:1527030498578};\\\", \\\"{x:1523,y:703,t:1527030498594};\\\", \\\"{x:1532,y:702,t:1527030498611};\\\", \\\"{x:1544,y:698,t:1527030498628};\\\", \\\"{x:1557,y:695,t:1527030498644};\\\", \\\"{x:1566,y:691,t:1527030498661};\\\", \\\"{x:1573,y:687,t:1527030498678};\\\", \\\"{x:1574,y:685,t:1527030498694};\\\", \\\"{x:1575,y:677,t:1527030498711};\\\", \\\"{x:1578,y:659,t:1527030498728};\\\", \\\"{x:1578,y:640,t:1527030498744};\\\", \\\"{x:1577,y:630,t:1527030498763};\\\", \\\"{x:1568,y:618,t:1527030498777};\\\", \\\"{x:1555,y:606,t:1527030498794};\\\", \\\"{x:1538,y:595,t:1527030498811};\\\", \\\"{x:1524,y:587,t:1527030498828};\\\", \\\"{x:1508,y:576,t:1527030498845};\\\", \\\"{x:1497,y:569,t:1527030498860};\\\", \\\"{x:1491,y:567,t:1527030498877};\\\", \\\"{x:1487,y:565,t:1527030498894};\\\", \\\"{x:1482,y:565,t:1527030498911};\\\", \\\"{x:1477,y:564,t:1527030498928};\\\", \\\"{x:1473,y:564,t:1527030498945};\\\", \\\"{x:1464,y:564,t:1527030498960};\\\", \\\"{x:1448,y:567,t:1527030498978};\\\", \\\"{x:1434,y:572,t:1527030498995};\\\", \\\"{x:1423,y:580,t:1527030499011};\\\", \\\"{x:1413,y:585,t:1527030499027};\\\", \\\"{x:1407,y:590,t:1527030499045};\\\", \\\"{x:1405,y:592,t:1527030499061};\\\", \\\"{x:1405,y:593,t:1527030499082};\\\", \\\"{x:1405,y:595,t:1527030499106};\\\", \\\"{x:1405,y:596,t:1527030499122};\\\", \\\"{x:1406,y:597,t:1527030499130};\\\", \\\"{x:1408,y:597,t:1527030499145};\\\", \\\"{x:1411,y:599,t:1527030499161};\\\", \\\"{x:1417,y:599,t:1527030499178};\\\", \\\"{x:1428,y:599,t:1527030499195};\\\", \\\"{x:1442,y:599,t:1527030499211};\\\", \\\"{x:1455,y:599,t:1527030499227};\\\", \\\"{x:1471,y:598,t:1527030499245};\\\", \\\"{x:1488,y:596,t:1527030499262};\\\", \\\"{x:1504,y:593,t:1527030499278};\\\", \\\"{x:1513,y:592,t:1527030499295};\\\", \\\"{x:1525,y:587,t:1527030499312};\\\", \\\"{x:1532,y:584,t:1527030499328};\\\", \\\"{x:1535,y:582,t:1527030499345};\\\", \\\"{x:1538,y:578,t:1527030499361};\\\", \\\"{x:1539,y:574,t:1527030499378};\\\", \\\"{x:1542,y:570,t:1527030499395};\\\", \\\"{x:1545,y:565,t:1527030499412};\\\", \\\"{x:1545,y:563,t:1527030499429};\\\", \\\"{x:1546,y:562,t:1527030499446};\\\", \\\"{x:1546,y:560,t:1527030499466};\\\", \\\"{x:1543,y:560,t:1527030499707};\\\", \\\"{x:1528,y:560,t:1527030499714};\\\", \\\"{x:1510,y:563,t:1527030499730};\\\", \\\"{x:1480,y:571,t:1527030499745};\\\", \\\"{x:1447,y:578,t:1527030499762};\\\", \\\"{x:1428,y:580,t:1527030499779};\\\", \\\"{x:1406,y:581,t:1527030499795};\\\", \\\"{x:1388,y:585,t:1527030499812};\\\", \\\"{x:1380,y:588,t:1527030499829};\\\", \\\"{x:1377,y:590,t:1527030499845};\\\", \\\"{x:1376,y:591,t:1527030499862};\\\", \\\"{x:1375,y:594,t:1527030499879};\\\", \\\"{x:1372,y:599,t:1527030499895};\\\", \\\"{x:1370,y:606,t:1527030499912};\\\", \\\"{x:1367,y:612,t:1527030499928};\\\", \\\"{x:1367,y:615,t:1527030499945};\\\", \\\"{x:1366,y:620,t:1527030499961};\\\", \\\"{x:1366,y:623,t:1527030499979};\\\", \\\"{x:1366,y:628,t:1527030499995};\\\", \\\"{x:1366,y:632,t:1527030500012};\\\", \\\"{x:1366,y:636,t:1527030500029};\\\", \\\"{x:1366,y:639,t:1527030500046};\\\", \\\"{x:1366,y:641,t:1527030500062};\\\", \\\"{x:1364,y:643,t:1527030500080};\\\", \\\"{x:1364,y:646,t:1527030500096};\\\", \\\"{x:1362,y:647,t:1527030500112};\\\", \\\"{x:1360,y:648,t:1527030500129};\\\", \\\"{x:1358,y:650,t:1527030500146};\\\", \\\"{x:1356,y:651,t:1527030500162};\\\", \\\"{x:1355,y:651,t:1527030500179};\\\", \\\"{x:1354,y:652,t:1527030500196};\\\", \\\"{x:1353,y:653,t:1527030500226};\\\", \\\"{x:1354,y:653,t:1527030500306};\\\", \\\"{x:1357,y:653,t:1527030500313};\\\", \\\"{x:1360,y:653,t:1527030500330};\\\", \\\"{x:1367,y:653,t:1527030500346};\\\", \\\"{x:1371,y:653,t:1527030500362};\\\", \\\"{x:1374,y:653,t:1527030500379};\\\", \\\"{x:1376,y:653,t:1527030500396};\\\", \\\"{x:1378,y:653,t:1527030500412};\\\", \\\"{x:1379,y:652,t:1527030500429};\\\", \\\"{x:1380,y:651,t:1527030500474};\\\", \\\"{x:1382,y:650,t:1527030500482};\\\", \\\"{x:1383,y:649,t:1527030500496};\\\", \\\"{x:1385,y:648,t:1527030500513};\\\", \\\"{x:1390,y:646,t:1527030500529};\\\", \\\"{x:1398,y:644,t:1527030500545};\\\", \\\"{x:1404,y:641,t:1527030500564};\\\", \\\"{x:1409,y:638,t:1527030500579};\\\", \\\"{x:1410,y:637,t:1527030500596};\\\", \\\"{x:1412,y:636,t:1527030500613};\\\", \\\"{x:1415,y:635,t:1527030500629};\\\", \\\"{x:1419,y:634,t:1527030500645};\\\", \\\"{x:1423,y:632,t:1527030500663};\\\", \\\"{x:1427,y:630,t:1527030500678};\\\", \\\"{x:1428,y:630,t:1527030500721};\\\", \\\"{x:1430,y:630,t:1527030500753};\\\", \\\"{x:1430,y:631,t:1527030501115};\\\", \\\"{x:1430,y:632,t:1527030501178};\\\", \\\"{x:1430,y:633,t:1527030501210};\\\", \\\"{x:1431,y:633,t:1527030501250};\\\", \\\"{x:1431,y:634,t:1527030501266};\\\", \\\"{x:1432,y:634,t:1527030501281};\\\", \\\"{x:1433,y:634,t:1527030501297};\\\", \\\"{x:1434,y:635,t:1527030501330};\\\", \\\"{x:1434,y:636,t:1527030501346};\\\", \\\"{x:1434,y:639,t:1527030501363};\\\", \\\"{x:1434,y:641,t:1527030501380};\\\", \\\"{x:1432,y:645,t:1527030501396};\\\", \\\"{x:1426,y:648,t:1527030501414};\\\", \\\"{x:1419,y:652,t:1527030501430};\\\", \\\"{x:1412,y:657,t:1527030501446};\\\", \\\"{x:1404,y:661,t:1527030501463};\\\", \\\"{x:1398,y:664,t:1527030501480};\\\", \\\"{x:1390,y:669,t:1527030501499};\\\", \\\"{x:1389,y:671,t:1527030501513};\\\", \\\"{x:1384,y:675,t:1527030501529};\\\", \\\"{x:1380,y:677,t:1527030501547};\\\", \\\"{x:1379,y:679,t:1527030501563};\\\", \\\"{x:1377,y:682,t:1527030501580};\\\", \\\"{x:1377,y:684,t:1527030501597};\\\", \\\"{x:1375,y:687,t:1527030501613};\\\", \\\"{x:1375,y:688,t:1527030501630};\\\", \\\"{x:1375,y:689,t:1527030501647};\\\", \\\"{x:1373,y:692,t:1527030501663};\\\", \\\"{x:1373,y:694,t:1527030501680};\\\", \\\"{x:1372,y:696,t:1527030501697};\\\", \\\"{x:1370,y:699,t:1527030501713};\\\", \\\"{x:1369,y:702,t:1527030501730};\\\", \\\"{x:1368,y:704,t:1527030501747};\\\", \\\"{x:1367,y:706,t:1527030501763};\\\", \\\"{x:1366,y:708,t:1527030501780};\\\", \\\"{x:1364,y:711,t:1527030501797};\\\", \\\"{x:1363,y:712,t:1527030501814};\\\", \\\"{x:1362,y:714,t:1527030501830};\\\", \\\"{x:1362,y:715,t:1527030501850};\\\", \\\"{x:1362,y:716,t:1527030501864};\\\", \\\"{x:1362,y:717,t:1527030501881};\\\", \\\"{x:1361,y:717,t:1527030501914};\\\", \\\"{x:1359,y:717,t:1527030501970};\\\", \\\"{x:1358,y:717,t:1527030501986};\\\", \\\"{x:1356,y:717,t:1527030502002};\\\", \\\"{x:1356,y:716,t:1527030502014};\\\", \\\"{x:1353,y:713,t:1527030502030};\\\", \\\"{x:1352,y:710,t:1527030502047};\\\", \\\"{x:1350,y:708,t:1527030502065};\\\", \\\"{x:1349,y:707,t:1527030502081};\\\", \\\"{x:1347,y:704,t:1527030502097};\\\", \\\"{x:1347,y:703,t:1527030502146};\\\", \\\"{x:1347,y:702,t:1527030502164};\\\", \\\"{x:1347,y:701,t:1527030502181};\\\", \\\"{x:1347,y:700,t:1527030502218};\\\", \\\"{x:1347,y:699,t:1527030502233};\\\", \\\"{x:1347,y:698,t:1527030502248};\\\", \\\"{x:1347,y:697,t:1527030502264};\\\", \\\"{x:1347,y:696,t:1527030502281};\\\", \\\"{x:1347,y:695,t:1527030502297};\\\", \\\"{x:1347,y:693,t:1527030502314};\\\", \\\"{x:1347,y:692,t:1527030502337};\\\", \\\"{x:1347,y:691,t:1527030502355};\\\", \\\"{x:1347,y:690,t:1527030502364};\\\", \\\"{x:1348,y:690,t:1527030503931};\\\", \\\"{x:1349,y:690,t:1527030503987};\\\", \\\"{x:1351,y:690,t:1527030504035};\\\", \\\"{x:1352,y:690,t:1527030504107};\\\", \\\"{x:1353,y:691,t:1527030504130};\\\", \\\"{x:1353,y:692,t:1527030504146};\\\", \\\"{x:1353,y:693,t:1527030504154};\\\", \\\"{x:1354,y:693,t:1527030504170};\\\", \\\"{x:1354,y:694,t:1527030504182};\\\", \\\"{x:1354,y:695,t:1527030504200};\\\", \\\"{x:1355,y:696,t:1527030504216};\\\", \\\"{x:1356,y:696,t:1527030504232};\\\", \\\"{x:1356,y:697,t:1527030504249};\\\", \\\"{x:1357,y:699,t:1527030504266};\\\", \\\"{x:1358,y:704,t:1527030504282};\\\", \\\"{x:1361,y:708,t:1527030504299};\\\", \\\"{x:1362,y:713,t:1527030504315};\\\", \\\"{x:1364,y:716,t:1527030504333};\\\", \\\"{x:1364,y:718,t:1527030504349};\\\", \\\"{x:1364,y:719,t:1527030504365};\\\", \\\"{x:1364,y:721,t:1527030504382};\\\", \\\"{x:1364,y:723,t:1527030504400};\\\", \\\"{x:1364,y:725,t:1527030504416};\\\", \\\"{x:1364,y:728,t:1527030504433};\\\", \\\"{x:1364,y:732,t:1527030504449};\\\", \\\"{x:1364,y:736,t:1527030504465};\\\", \\\"{x:1364,y:738,t:1527030504482};\\\", \\\"{x:1364,y:739,t:1527030504538};\\\", \\\"{x:1364,y:740,t:1527030504562};\\\", \\\"{x:1364,y:741,t:1527030504570};\\\", \\\"{x:1364,y:742,t:1527030504582};\\\", \\\"{x:1364,y:744,t:1527030504599};\\\", \\\"{x:1364,y:745,t:1527030504617};\\\", \\\"{x:1364,y:747,t:1527030504634};\\\", \\\"{x:1364,y:748,t:1527030504682};\\\", \\\"{x:1364,y:749,t:1527030504699};\\\", \\\"{x:1364,y:750,t:1527030504716};\\\", \\\"{x:1364,y:751,t:1527030504733};\\\", \\\"{x:1364,y:753,t:1527030504749};\\\", \\\"{x:1364,y:755,t:1527030504766};\\\", \\\"{x:1364,y:756,t:1527030504786};\\\", \\\"{x:1363,y:757,t:1527030504802};\\\", \\\"{x:1363,y:758,t:1527030504818};\\\", \\\"{x:1363,y:760,t:1527030504834};\\\", \\\"{x:1362,y:761,t:1527030504866};\\\", \\\"{x:1361,y:763,t:1527030504883};\\\", \\\"{x:1360,y:763,t:1527030504906};\\\", \\\"{x:1360,y:764,t:1527030504917};\\\", \\\"{x:1360,y:765,t:1527030504938};\\\", \\\"{x:1359,y:766,t:1527030504949};\\\", \\\"{x:1359,y:764,t:1527030506842};\\\", \\\"{x:1358,y:763,t:1527030507218};\\\", \\\"{x:1358,y:761,t:1527030507275};\\\", \\\"{x:1357,y:761,t:1527030507290};\\\", \\\"{x:1356,y:759,t:1527030507345};\\\", \\\"{x:1356,y:758,t:1527030507377};\\\", \\\"{x:1356,y:756,t:1527030507401};\\\", \\\"{x:1354,y:753,t:1527030507417};\\\", \\\"{x:1354,y:749,t:1527030507435};\\\", \\\"{x:1353,y:742,t:1527030507450};\\\", \\\"{x:1352,y:734,t:1527030507468};\\\", \\\"{x:1350,y:727,t:1527030507485};\\\", \\\"{x:1348,y:715,t:1527030507501};\\\", \\\"{x:1348,y:707,t:1527030507518};\\\", \\\"{x:1348,y:703,t:1527030507535};\\\", \\\"{x:1348,y:699,t:1527030507551};\\\", \\\"{x:1348,y:697,t:1527030507568};\\\", \\\"{x:1347,y:696,t:1527030507642};\\\", \\\"{x:1345,y:697,t:1527030507651};\\\", \\\"{x:1342,y:705,t:1527030507669};\\\", \\\"{x:1341,y:714,t:1527030507686};\\\", \\\"{x:1340,y:724,t:1527030507701};\\\", \\\"{x:1339,y:735,t:1527030507719};\\\", \\\"{x:1337,y:744,t:1527030507736};\\\", \\\"{x:1336,y:751,t:1527030507752};\\\", \\\"{x:1335,y:756,t:1527030507768};\\\", \\\"{x:1331,y:763,t:1527030507786};\\\", \\\"{x:1329,y:765,t:1527030507802};\\\", \\\"{x:1313,y:773,t:1527030507819};\\\", \\\"{x:1299,y:776,t:1527030507836};\\\", \\\"{x:1272,y:777,t:1527030507852};\\\", \\\"{x:1242,y:777,t:1527030507869};\\\", \\\"{x:1206,y:777,t:1527030507886};\\\", \\\"{x:1156,y:777,t:1527030507901};\\\", \\\"{x:1097,y:777,t:1527030507919};\\\", \\\"{x:1036,y:777,t:1527030507936};\\\", \\\"{x:972,y:777,t:1527030507953};\\\", \\\"{x:916,y:776,t:1527030507968};\\\", \\\"{x:860,y:767,t:1527030507986};\\\", \\\"{x:829,y:763,t:1527030508001};\\\", \\\"{x:800,y:759,t:1527030508018};\\\", \\\"{x:771,y:749,t:1527030508036};\\\", \\\"{x:738,y:740,t:1527030508052};\\\", \\\"{x:701,y:729,t:1527030508068};\\\", \\\"{x:663,y:719,t:1527030508085};\\\", \\\"{x:630,y:708,t:1527030508102};\\\", \\\"{x:605,y:701,t:1527030508118};\\\", \\\"{x:580,y:692,t:1527030508135};\\\", \\\"{x:563,y:684,t:1527030508152};\\\", \\\"{x:555,y:677,t:1527030508168};\\\", \\\"{x:552,y:673,t:1527030508186};\\\", \\\"{x:552,y:670,t:1527030508202};\\\", \\\"{x:552,y:667,t:1527030508218};\\\", \\\"{x:552,y:662,t:1527030508236};\\\", \\\"{x:552,y:652,t:1527030508252};\\\", \\\"{x:552,y:644,t:1527030508268};\\\", \\\"{x:552,y:635,t:1527030508286};\\\", \\\"{x:554,y:623,t:1527030508304};\\\", \\\"{x:556,y:616,t:1527030508318};\\\", \\\"{x:558,y:610,t:1527030508335};\\\", \\\"{x:560,y:606,t:1527030508351};\\\", \\\"{x:563,y:601,t:1527030508367};\\\", \\\"{x:572,y:583,t:1527030508385};\\\", \\\"{x:576,y:571,t:1527030508402};\\\", \\\"{x:577,y:564,t:1527030508418};\\\", \\\"{x:578,y:556,t:1527030508435};\\\", \\\"{x:578,y:551,t:1527030508452};\\\", \\\"{x:578,y:545,t:1527030508469};\\\", \\\"{x:581,y:540,t:1527030508484};\\\", \\\"{x:581,y:532,t:1527030508501};\\\", \\\"{x:582,y:525,t:1527030508519};\\\", \\\"{x:584,y:523,t:1527030508535};\\\", \\\"{x:584,y:521,t:1527030508552};\\\", \\\"{x:584,y:522,t:1527030508625};\\\", \\\"{x:584,y:525,t:1527030508636};\\\", \\\"{x:584,y:536,t:1527030508652};\\\", \\\"{x:577,y:550,t:1527030508668};\\\", \\\"{x:567,y:566,t:1527030508685};\\\", \\\"{x:555,y:580,t:1527030508702};\\\", \\\"{x:542,y:592,t:1527030508719};\\\", \\\"{x:527,y:598,t:1527030508735};\\\", \\\"{x:510,y:599,t:1527030508751};\\\", \\\"{x:493,y:599,t:1527030508769};\\\", \\\"{x:488,y:598,t:1527030508785};\\\", \\\"{x:485,y:597,t:1527030508802};\\\", \\\"{x:482,y:596,t:1527030508819};\\\", \\\"{x:478,y:594,t:1527030508836};\\\", \\\"{x:467,y:589,t:1527030508854};\\\", \\\"{x:458,y:582,t:1527030508869};\\\", \\\"{x:454,y:579,t:1527030508885};\\\", \\\"{x:451,y:576,t:1527030508902};\\\", \\\"{x:449,y:572,t:1527030508919};\\\", \\\"{x:449,y:571,t:1527030508936};\\\", \\\"{x:447,y:571,t:1527030509217};\\\", \\\"{x:446,y:571,t:1527030509226};\\\", \\\"{x:444,y:570,t:1527030509236};\\\", \\\"{x:443,y:569,t:1527030509252};\\\", \\\"{x:441,y:569,t:1527030509269};\\\", \\\"{x:431,y:569,t:1527030509286};\\\", \\\"{x:414,y:571,t:1527030509303};\\\", \\\"{x:388,y:575,t:1527030509319};\\\", \\\"{x:351,y:577,t:1527030509336};\\\", \\\"{x:303,y:577,t:1527030509352};\\\", \\\"{x:206,y:577,t:1527030509369};\\\", \\\"{x:159,y:574,t:1527030509386};\\\", \\\"{x:132,y:567,t:1527030509403};\\\", \\\"{x:113,y:562,t:1527030509419};\\\", \\\"{x:102,y:559,t:1527030509436};\\\", \\\"{x:101,y:558,t:1527030509453};\\\", \\\"{x:100,y:557,t:1527030509472};\\\", \\\"{x:100,y:555,t:1527030509497};\\\", \\\"{x:101,y:554,t:1527030509505};\\\", \\\"{x:102,y:553,t:1527030509519};\\\", \\\"{x:103,y:550,t:1527030509535};\\\", \\\"{x:108,y:547,t:1527030509552};\\\", \\\"{x:130,y:540,t:1527030509569};\\\", \\\"{x:141,y:536,t:1527030509586};\\\", \\\"{x:149,y:533,t:1527030509602};\\\", \\\"{x:155,y:533,t:1527030509619};\\\", \\\"{x:156,y:533,t:1527030509636};\\\", \\\"{x:157,y:533,t:1527030509657};\\\", \\\"{x:158,y:533,t:1527030509673};\\\", \\\"{x:159,y:533,t:1527030509686};\\\", \\\"{x:163,y:533,t:1527030509703};\\\", \\\"{x:166,y:532,t:1527030509720};\\\", \\\"{x:168,y:532,t:1527030509977};\\\", \\\"{x:171,y:532,t:1527030509986};\\\", \\\"{x:184,y:532,t:1527030510003};\\\", \\\"{x:202,y:534,t:1527030510020};\\\", \\\"{x:225,y:535,t:1527030510036};\\\", \\\"{x:259,y:535,t:1527030510053};\\\", \\\"{x:311,y:541,t:1527030510070};\\\", \\\"{x:381,y:550,t:1527030510086};\\\", \\\"{x:469,y:561,t:1527030510104};\\\", \\\"{x:547,y:572,t:1527030510120};\\\", \\\"{x:603,y:580,t:1527030510136};\\\", \\\"{x:646,y:586,t:1527030510153};\\\", \\\"{x:671,y:591,t:1527030510170};\\\", \\\"{x:686,y:592,t:1527030510185};\\\", \\\"{x:691,y:592,t:1527030510203};\\\", \\\"{x:692,y:592,t:1527030510225};\\\", \\\"{x:685,y:594,t:1527030510339};\\\", \\\"{x:665,y:596,t:1527030510352};\\\", \\\"{x:638,y:601,t:1527030510370};\\\", \\\"{x:599,y:608,t:1527030510387};\\\", \\\"{x:564,y:620,t:1527030510403};\\\", \\\"{x:523,y:627,t:1527030510419};\\\", \\\"{x:477,y:633,t:1527030510437};\\\", \\\"{x:440,y:643,t:1527030510453};\\\", \\\"{x:409,y:649,t:1527030510470};\\\", \\\"{x:393,y:657,t:1527030510487};\\\", \\\"{x:367,y:658,t:1527030510503};\\\", \\\"{x:345,y:661,t:1527030510520};\\\", \\\"{x:323,y:664,t:1527030510537};\\\", \\\"{x:319,y:664,t:1527030510552};\\\", \\\"{x:314,y:664,t:1527030510570};\\\", \\\"{x:308,y:662,t:1527030510587};\\\", \\\"{x:303,y:661,t:1527030510604};\\\", \\\"{x:302,y:661,t:1527030510620};\\\", \\\"{x:301,y:660,t:1527030510641};\\\", \\\"{x:301,y:659,t:1527030510665};\\\", \\\"{x:301,y:658,t:1527030510673};\\\", \\\"{x:301,y:656,t:1527030510689};\\\", \\\"{x:301,y:653,t:1527030510704};\\\", \\\"{x:305,y:649,t:1527030510720};\\\", \\\"{x:322,y:637,t:1527030510739};\\\", \\\"{x:343,y:627,t:1527030510755};\\\", \\\"{x:372,y:615,t:1527030510770};\\\", \\\"{x:404,y:600,t:1527030510787};\\\", \\\"{x:427,y:584,t:1527030510804};\\\", \\\"{x:442,y:573,t:1527030510820};\\\", \\\"{x:454,y:562,t:1527030510837};\\\", \\\"{x:462,y:556,t:1527030510853};\\\", \\\"{x:466,y:551,t:1527030510870};\\\", \\\"{x:470,y:547,t:1527030510887};\\\", \\\"{x:471,y:544,t:1527030510904};\\\", \\\"{x:473,y:539,t:1527030510920};\\\", \\\"{x:475,y:532,t:1527030510937};\\\", \\\"{x:477,y:529,t:1527030510954};\\\", \\\"{x:480,y:527,t:1527030510969};\\\", \\\"{x:489,y:524,t:1527030510987};\\\", \\\"{x:496,y:524,t:1527030511004};\\\", \\\"{x:510,y:523,t:1527030511020};\\\", \\\"{x:535,y:523,t:1527030511037};\\\", \\\"{x:570,y:523,t:1527030511054};\\\", \\\"{x:642,y:523,t:1527030511070};\\\", \\\"{x:724,y:526,t:1527030511090};\\\", \\\"{x:802,y:528,t:1527030511104};\\\", \\\"{x:897,y:528,t:1527030511120};\\\", \\\"{x:937,y:528,t:1527030511137};\\\", \\\"{x:955,y:528,t:1527030511154};\\\", \\\"{x:961,y:528,t:1527030511170};\\\", \\\"{x:962,y:528,t:1527030511201};\\\", \\\"{x:962,y:527,t:1527030511208};\\\", \\\"{x:961,y:527,t:1527030511221};\\\", \\\"{x:961,y:526,t:1527030511237};\\\", \\\"{x:958,y:526,t:1527030511253};\\\", \\\"{x:954,y:526,t:1527030511271};\\\", \\\"{x:946,y:529,t:1527030511288};\\\", \\\"{x:935,y:535,t:1527030511304};\\\", \\\"{x:912,y:546,t:1527030511320};\\\", \\\"{x:896,y:553,t:1527030511337};\\\", \\\"{x:891,y:554,t:1527030511354};\\\", \\\"{x:887,y:554,t:1527030511370};\\\", \\\"{x:882,y:553,t:1527030511387};\\\", \\\"{x:878,y:550,t:1527030511404};\\\", \\\"{x:872,y:546,t:1527030511421};\\\", \\\"{x:868,y:541,t:1527030511439};\\\", \\\"{x:862,y:533,t:1527030511454};\\\", \\\"{x:854,y:527,t:1527030511471};\\\", \\\"{x:845,y:515,t:1527030511488};\\\", \\\"{x:841,y:508,t:1527030511504};\\\", \\\"{x:835,y:500,t:1527030511520};\\\", \\\"{x:835,y:496,t:1527030511536};\\\", \\\"{x:835,y:495,t:1527030511553};\\\", \\\"{x:835,y:494,t:1527030511571};\\\", \\\"{x:835,y:493,t:1527030511601};\\\", \\\"{x:835,y:492,t:1527030511609};\\\", \\\"{x:835,y:491,t:1527030511621};\\\", \\\"{x:835,y:490,t:1527030511638};\\\", \\\"{x:835,y:488,t:1527030511654};\\\", \\\"{x:834,y:488,t:1527030511849};\\\", \\\"{x:831,y:488,t:1527030511857};\\\", \\\"{x:824,y:498,t:1527030511871};\\\", \\\"{x:805,y:524,t:1527030511889};\\\", \\\"{x:763,y:579,t:1527030511905};\\\", \\\"{x:689,y:647,t:1527030511921};\\\", \\\"{x:652,y:674,t:1527030511938};\\\", \\\"{x:626,y:692,t:1527030511954};\\\", \\\"{x:609,y:704,t:1527030511971};\\\", \\\"{x:598,y:710,t:1527030511988};\\\", \\\"{x:595,y:711,t:1527030512004};\\\", \\\"{x:592,y:714,t:1527030512021};\\\", \\\"{x:588,y:716,t:1527030512038};\\\", \\\"{x:582,y:717,t:1527030512055};\\\", \\\"{x:574,y:720,t:1527030512071};\\\", \\\"{x:564,y:723,t:1527030512089};\\\", \\\"{x:545,y:728,t:1527030512106};\\\", \\\"{x:513,y:737,t:1527030512121};\\\", \\\"{x:503,y:738,t:1527030512138};\\\", \\\"{x:502,y:738,t:1527030512155};\\\", \\\"{x:508,y:726,t:1527030512171};\\\", \\\"{x:543,y:699,t:1527030512189};\\\", \\\"{x:597,y:659,t:1527030512205};\\\", \\\"{x:669,y:609,t:1527030512222};\\\", \\\"{x:745,y:555,t:1527030512238};\\\", \\\"{x:836,y:499,t:1527030512255};\\\", \\\"{x:892,y:461,t:1527030512271};\\\", \\\"{x:920,y:444,t:1527030512288};\\\", \\\"{x:934,y:434,t:1527030512305};\\\", \\\"{x:934,y:431,t:1527030512321};\\\", \\\"{x:934,y:430,t:1527030512338};\\\", \\\"{x:934,y:429,t:1527030512369};\\\", \\\"{x:933,y:429,t:1527030512385};\\\", \\\"{x:932,y:429,t:1527030512393};\\\", \\\"{x:931,y:429,t:1527030512417};\\\", \\\"{x:930,y:430,t:1527030512442};\\\", \\\"{x:928,y:431,t:1527030512455};\\\", \\\"{x:921,y:435,t:1527030512472};\\\", \\\"{x:910,y:443,t:1527030512488};\\\", \\\"{x:881,y:466,t:1527030512506};\\\", \\\"{x:861,y:480,t:1527030512521};\\\", \\\"{x:843,y:492,t:1527030512539};\\\", \\\"{x:836,y:497,t:1527030512555};\\\", \\\"{x:833,y:500,t:1527030512571};\\\", \\\"{x:834,y:500,t:1527030512609};\\\", \\\"{x:835,y:500,t:1527030512622};\\\", \\\"{x:842,y:498,t:1527030512638};\\\", \\\"{x:847,y:495,t:1527030512655};\\\", \\\"{x:850,y:494,t:1527030512672};\\\", \\\"{x:849,y:494,t:1527030512849};\\\", \\\"{x:848,y:494,t:1527030512870};\\\", \\\"{x:847,y:494,t:1527030512888};\\\", \\\"{x:846,y:494,t:1527030512921};\\\", \\\"{x:844,y:494,t:1527030512929};\\\", \\\"{x:842,y:495,t:1527030512953};\\\", \\\"{x:841,y:495,t:1527030512961};\\\", \\\"{x:839,y:496,t:1527030512972};\\\", \\\"{x:837,y:498,t:1527030512989};\\\", \\\"{x:834,y:499,t:1527030513005};\\\", \\\"{x:832,y:500,t:1527030513022};\\\", \\\"{x:828,y:504,t:1527030513194};\\\", \\\"{x:824,y:508,t:1527030513207};\\\", \\\"{x:803,y:529,t:1527030513222};\\\", \\\"{x:767,y:568,t:1527030513239};\\\", \\\"{x:718,y:605,t:1527030513255};\\\", \\\"{x:681,y:634,t:1527030513272};\\\", \\\"{x:630,y:666,t:1527030513289};\\\", \\\"{x:614,y:675,t:1527030513304};\\\", \\\"{x:609,y:678,t:1527030513322};\\\", \\\"{x:607,y:679,t:1527030513339};\\\", \\\"{x:606,y:680,t:1527030513368};\\\", \\\"{x:606,y:681,t:1527030513393};\\\", \\\"{x:606,y:683,t:1527030513405};\\\", \\\"{x:605,y:687,t:1527030513422};\\\", \\\"{x:601,y:694,t:1527030513439};\\\", \\\"{x:592,y:704,t:1527030513455};\\\", \\\"{x:586,y:711,t:1527030513472};\\\", \\\"{x:571,y:722,t:1527030513490};\\\", \\\"{x:558,y:730,t:1527030513507};\\\", \\\"{x:546,y:735,t:1527030513521};\\\", \\\"{x:536,y:738,t:1527030513539};\\\", \\\"{x:530,y:738,t:1527030513554};\\\", \\\"{x:527,y:740,t:1527030513572};\\\" ] }, { \\\"rt\\\": 29901, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 434016, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-B -B -F -F -F -E -G -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:461,y:698,t:1527030515432};\\\", \\\"{x:422,y:681,t:1527030515441};\\\", \\\"{x:403,y:669,t:1527030515457};\\\", \\\"{x:396,y:662,t:1527030515474};\\\", \\\"{x:391,y:657,t:1527030515490};\\\", \\\"{x:385,y:643,t:1527030515507};\\\", \\\"{x:375,y:619,t:1527030515524};\\\", \\\"{x:361,y:581,t:1527030515540};\\\", \\\"{x:344,y:532,t:1527030515558};\\\", \\\"{x:321,y:487,t:1527030515575};\\\", \\\"{x:303,y:455,t:1527030515592};\\\", \\\"{x:296,y:436,t:1527030515607};\\\", \\\"{x:293,y:427,t:1527030515624};\\\", \\\"{x:293,y:424,t:1527030515640};\\\", \\\"{x:293,y:422,t:1527030515657};\\\", \\\"{x:293,y:421,t:1527030515674};\\\", \\\"{x:292,y:419,t:1527030515690};\\\", \\\"{x:292,y:418,t:1527030515707};\\\", \\\"{x:296,y:418,t:1527030515785};\\\", \\\"{x:300,y:423,t:1527030515794};\\\", \\\"{x:303,y:427,t:1527030515808};\\\", \\\"{x:312,y:437,t:1527030515823};\\\", \\\"{x:320,y:448,t:1527030515841};\\\", \\\"{x:326,y:455,t:1527030515857};\\\", \\\"{x:331,y:460,t:1527030515873};\\\", \\\"{x:333,y:462,t:1527030515890};\\\", \\\"{x:335,y:463,t:1527030515906};\\\", \\\"{x:337,y:464,t:1527030515924};\\\", \\\"{x:339,y:464,t:1527030515939};\\\", \\\"{x:340,y:464,t:1527030515969};\\\", \\\"{x:342,y:465,t:1527030515985};\\\", \\\"{x:343,y:466,t:1527030515993};\\\", \\\"{x:345,y:466,t:1527030516009};\\\", \\\"{x:346,y:466,t:1527030516023};\\\", \\\"{x:349,y:466,t:1527030516040};\\\", \\\"{x:353,y:466,t:1527030516057};\\\", \\\"{x:356,y:466,t:1527030516072};\\\", \\\"{x:360,y:466,t:1527030516090};\\\", \\\"{x:361,y:466,t:1527030516106};\\\", \\\"{x:362,y:466,t:1527030516122};\\\", \\\"{x:363,y:466,t:1527030516162};\\\", \\\"{x:364,y:465,t:1527030516178};\\\", \\\"{x:365,y:465,t:1527030516201};\\\", \\\"{x:367,y:465,t:1527030516218};\\\", \\\"{x:369,y:465,t:1527030516233};\\\", \\\"{x:371,y:463,t:1527030516249};\\\", \\\"{x:372,y:463,t:1527030516258};\\\", \\\"{x:375,y:463,t:1527030516273};\\\", \\\"{x:386,y:461,t:1527030516289};\\\", \\\"{x:397,y:459,t:1527030516305};\\\", \\\"{x:413,y:457,t:1527030516323};\\\", \\\"{x:435,y:457,t:1527030516339};\\\", \\\"{x:448,y:457,t:1527030516356};\\\", \\\"{x:457,y:457,t:1527030516372};\\\", \\\"{x:467,y:457,t:1527030516388};\\\", \\\"{x:477,y:459,t:1527030516406};\\\", \\\"{x:483,y:460,t:1527030516422};\\\", \\\"{x:484,y:460,t:1527030516439};\\\", \\\"{x:485,y:460,t:1527030516456};\\\", \\\"{x:487,y:461,t:1527030516472};\\\", \\\"{x:489,y:462,t:1527030516489};\\\", \\\"{x:502,y:464,t:1527030516505};\\\", \\\"{x:507,y:466,t:1527030516521};\\\", \\\"{x:511,y:467,t:1527030516538};\\\", \\\"{x:511,y:468,t:1527030516555};\\\", \\\"{x:512,y:468,t:1527030516954};\\\", \\\"{x:513,y:468,t:1527030517505};\\\", \\\"{x:515,y:470,t:1527030517521};\\\", \\\"{x:522,y:470,t:1527030517535};\\\", \\\"{x:533,y:471,t:1527030517552};\\\", \\\"{x:538,y:471,t:1527030517568};\\\", \\\"{x:542,y:471,t:1527030517585};\\\", \\\"{x:543,y:471,t:1527030517602};\\\", \\\"{x:544,y:471,t:1527030517762};\\\", \\\"{x:545,y:471,t:1527030517770};\\\", \\\"{x:546,y:471,t:1527030517785};\\\", \\\"{x:556,y:471,t:1527030517801};\\\", \\\"{x:569,y:471,t:1527030517819};\\\", \\\"{x:586,y:471,t:1527030517834};\\\", \\\"{x:607,y:471,t:1527030517852};\\\", \\\"{x:625,y:474,t:1527030517867};\\\", \\\"{x:639,y:476,t:1527030517884};\\\", \\\"{x:647,y:478,t:1527030517901};\\\", \\\"{x:648,y:478,t:1527030517917};\\\", \\\"{x:648,y:479,t:1527030517934};\\\", \\\"{x:649,y:480,t:1527030517952};\\\", \\\"{x:650,y:481,t:1527030517968};\\\", \\\"{x:650,y:482,t:1527030517985};\\\", \\\"{x:651,y:482,t:1527030518289};\\\", \\\"{x:651,y:483,t:1527030518305};\\\", \\\"{x:653,y:483,t:1527030518354};\\\", \\\"{x:656,y:483,t:1527030518366};\\\", \\\"{x:666,y:485,t:1527030518384};\\\", \\\"{x:677,y:485,t:1527030518399};\\\", \\\"{x:693,y:487,t:1527030518418};\\\", \\\"{x:715,y:492,t:1527030518432};\\\", \\\"{x:721,y:493,t:1527030518449};\\\", \\\"{x:722,y:494,t:1527030518466};\\\", \\\"{x:723,y:495,t:1527030518625};\\\", \\\"{x:723,y:497,t:1527030518649};\\\", \\\"{x:723,y:498,t:1527030518674};\\\", \\\"{x:723,y:500,t:1527030518681};\\\", \\\"{x:723,y:501,t:1527030518697};\\\", \\\"{x:723,y:502,t:1527030518737};\\\", \\\"{x:723,y:503,t:1527030518768};\\\", \\\"{x:724,y:504,t:1527030518777};\\\", \\\"{x:726,y:505,t:1527030518801};\\\", \\\"{x:727,y:505,t:1527030518811};\\\", \\\"{x:733,y:506,t:1527030518826};\\\", \\\"{x:741,y:507,t:1527030518844};\\\", \\\"{x:750,y:508,t:1527030518860};\\\", \\\"{x:754,y:509,t:1527030518877};\\\", \\\"{x:758,y:510,t:1527030518894};\\\", \\\"{x:759,y:510,t:1527030518910};\\\", \\\"{x:760,y:510,t:1527030518930};\\\", \\\"{x:761,y:510,t:1527030518946};\\\", \\\"{x:754,y:505,t:1527030519170};\\\", \\\"{x:748,y:501,t:1527030519177};\\\", \\\"{x:740,y:495,t:1527030519194};\\\", \\\"{x:729,y:488,t:1527030519211};\\\", \\\"{x:719,y:483,t:1527030519228};\\\", \\\"{x:715,y:481,t:1527030519244};\\\", \\\"{x:715,y:480,t:1527030519289};\\\", \\\"{x:716,y:479,t:1527030519330};\\\", \\\"{x:718,y:478,t:1527030519344};\\\", \\\"{x:723,y:478,t:1527030519361};\\\", \\\"{x:742,y:478,t:1527030519378};\\\", \\\"{x:761,y:478,t:1527030519393};\\\", \\\"{x:777,y:478,t:1527030519410};\\\", \\\"{x:793,y:478,t:1527030519427};\\\", \\\"{x:806,y:478,t:1527030519444};\\\", \\\"{x:817,y:478,t:1527030519460};\\\", \\\"{x:826,y:478,t:1527030519478};\\\", \\\"{x:835,y:480,t:1527030519494};\\\", \\\"{x:846,y:482,t:1527030519510};\\\", \\\"{x:862,y:487,t:1527030519528};\\\", \\\"{x:881,y:492,t:1527030519544};\\\", \\\"{x:907,y:503,t:1527030519561};\\\", \\\"{x:971,y:533,t:1527030519579};\\\", \\\"{x:1030,y:563,t:1527030519594};\\\", \\\"{x:1095,y:613,t:1527030519611};\\\", \\\"{x:1171,y:654,t:1527030519627};\\\", \\\"{x:1244,y:710,t:1527030519644};\\\", \\\"{x:1319,y:758,t:1527030519660};\\\", \\\"{x:1398,y:807,t:1527030519677};\\\", \\\"{x:1462,y:846,t:1527030519695};\\\", \\\"{x:1531,y:891,t:1527030519710};\\\", \\\"{x:1592,y:929,t:1527030519728};\\\", \\\"{x:1631,y:958,t:1527030519744};\\\", \\\"{x:1671,y:985,t:1527030519761};\\\", \\\"{x:1700,y:1004,t:1527030519777};\\\", \\\"{x:1710,y:1011,t:1527030519794};\\\", \\\"{x:1712,y:1014,t:1527030519810};\\\", \\\"{x:1713,y:1015,t:1527030519827};\\\", \\\"{x:1713,y:1016,t:1527030519850};\\\", \\\"{x:1713,y:1017,t:1527030519860};\\\", \\\"{x:1715,y:1021,t:1527030519878};\\\", \\\"{x:1717,y:1023,t:1527030519895};\\\", \\\"{x:1721,y:1023,t:1527030519911};\\\", \\\"{x:1722,y:1023,t:1527030519928};\\\", \\\"{x:1720,y:1022,t:1527030520354};\\\", \\\"{x:1720,y:1021,t:1527030520361};\\\", \\\"{x:1717,y:1021,t:1527030520377};\\\", \\\"{x:1712,y:1017,t:1527030520395};\\\", \\\"{x:1707,y:1014,t:1527030520411};\\\", \\\"{x:1694,y:1009,t:1527030520427};\\\", \\\"{x:1680,y:1004,t:1527030520444};\\\", \\\"{x:1662,y:997,t:1527030520461};\\\", \\\"{x:1645,y:989,t:1527030520479};\\\", \\\"{x:1628,y:981,t:1527030520495};\\\", \\\"{x:1612,y:975,t:1527030520511};\\\", \\\"{x:1600,y:970,t:1527030520527};\\\", \\\"{x:1594,y:967,t:1527030520546};\\\", \\\"{x:1593,y:966,t:1527030520561};\\\", \\\"{x:1593,y:965,t:1527030520578};\\\", \\\"{x:1592,y:964,t:1527030520640};\\\", \\\"{x:1591,y:964,t:1527030520664};\\\", \\\"{x:1591,y:963,t:1527030520897};\\\", \\\"{x:1590,y:962,t:1527030520912};\\\", \\\"{x:1588,y:960,t:1527030520929};\\\", \\\"{x:1585,y:959,t:1527030520945};\\\", \\\"{x:1576,y:957,t:1527030520961};\\\", \\\"{x:1568,y:954,t:1527030520979};\\\", \\\"{x:1559,y:951,t:1527030520995};\\\", \\\"{x:1551,y:951,t:1527030521012};\\\", \\\"{x:1545,y:950,t:1527030521029};\\\", \\\"{x:1542,y:949,t:1527030521046};\\\", \\\"{x:1538,y:948,t:1527030521062};\\\", \\\"{x:1536,y:948,t:1527030521078};\\\", \\\"{x:1535,y:948,t:1527030521096};\\\", \\\"{x:1533,y:948,t:1527030521112};\\\", \\\"{x:1532,y:948,t:1527030521129};\\\", \\\"{x:1531,y:948,t:1527030521570};\\\", \\\"{x:1530,y:949,t:1527030521579};\\\", \\\"{x:1527,y:949,t:1527030521597};\\\", \\\"{x:1523,y:949,t:1527030521613};\\\", \\\"{x:1519,y:949,t:1527030521629};\\\", \\\"{x:1515,y:947,t:1527030521646};\\\", \\\"{x:1508,y:940,t:1527030521663};\\\", \\\"{x:1493,y:922,t:1527030521679};\\\", \\\"{x:1478,y:901,t:1527030521696};\\\", \\\"{x:1463,y:879,t:1527030521713};\\\", \\\"{x:1444,y:851,t:1527030521729};\\\", \\\"{x:1425,y:804,t:1527030521746};\\\", \\\"{x:1416,y:776,t:1527030521763};\\\", \\\"{x:1411,y:755,t:1527030521779};\\\", \\\"{x:1409,y:738,t:1527030521797};\\\", \\\"{x:1408,y:720,t:1527030521813};\\\", \\\"{x:1408,y:711,t:1527030521829};\\\", \\\"{x:1408,y:700,t:1527030521846};\\\", \\\"{x:1407,y:687,t:1527030521863};\\\", \\\"{x:1399,y:677,t:1527030521879};\\\", \\\"{x:1392,y:666,t:1527030521896};\\\", \\\"{x:1384,y:657,t:1527030521913};\\\", \\\"{x:1374,y:648,t:1527030521930};\\\", \\\"{x:1364,y:642,t:1527030521946};\\\", \\\"{x:1356,y:637,t:1527030521963};\\\", \\\"{x:1345,y:631,t:1527030521980};\\\", \\\"{x:1335,y:627,t:1527030521997};\\\", \\\"{x:1325,y:623,t:1527030522013};\\\", \\\"{x:1319,y:619,t:1527030522030};\\\", \\\"{x:1312,y:616,t:1527030522046};\\\", \\\"{x:1309,y:614,t:1527030522063};\\\", \\\"{x:1303,y:610,t:1527030522080};\\\", \\\"{x:1295,y:605,t:1527030522096};\\\", \\\"{x:1291,y:602,t:1527030522112};\\\", \\\"{x:1274,y:590,t:1527030522129};\\\", \\\"{x:1260,y:583,t:1527030522146};\\\", \\\"{x:1239,y:578,t:1527030522163};\\\", \\\"{x:1218,y:571,t:1527030522180};\\\", \\\"{x:1191,y:564,t:1527030522197};\\\", \\\"{x:1163,y:561,t:1527030522213};\\\", \\\"{x:1130,y:556,t:1527030522230};\\\", \\\"{x:1106,y:554,t:1527030522246};\\\", \\\"{x:1089,y:550,t:1527030522263};\\\", \\\"{x:1074,y:549,t:1527030522280};\\\", \\\"{x:1068,y:549,t:1527030522296};\\\", \\\"{x:1066,y:549,t:1527030522313};\\\", \\\"{x:1066,y:551,t:1527030522329};\\\", \\\"{x:1067,y:552,t:1527030522346};\\\", \\\"{x:1068,y:553,t:1527030522363};\\\", \\\"{x:1071,y:555,t:1527030522380};\\\", \\\"{x:1074,y:555,t:1527030522396};\\\", \\\"{x:1080,y:555,t:1527030522413};\\\", \\\"{x:1086,y:555,t:1527030522430};\\\", \\\"{x:1091,y:555,t:1527030522447};\\\", \\\"{x:1099,y:549,t:1527030522463};\\\", \\\"{x:1108,y:540,t:1527030522480};\\\", \\\"{x:1112,y:534,t:1527030522497};\\\", \\\"{x:1113,y:529,t:1527030522513};\\\", \\\"{x:1113,y:523,t:1527030522530};\\\", \\\"{x:1113,y:521,t:1527030522547};\\\", \\\"{x:1111,y:519,t:1527030522563};\\\", \\\"{x:1110,y:518,t:1527030522580};\\\", \\\"{x:1110,y:516,t:1527030522597};\\\", \\\"{x:1109,y:516,t:1527030522613};\\\", \\\"{x:1109,y:514,t:1527030522630};\\\", \\\"{x:1109,y:513,t:1527030522647};\\\", \\\"{x:1109,y:512,t:1527030522690};\\\", \\\"{x:1109,y:511,t:1527030522697};\\\", \\\"{x:1110,y:509,t:1527030522713};\\\", \\\"{x:1112,y:506,t:1527030522730};\\\", \\\"{x:1113,y:505,t:1527030522747};\\\", \\\"{x:1114,y:503,t:1527030522763};\\\", \\\"{x:1114,y:502,t:1527030522786};\\\", \\\"{x:1114,y:500,t:1527030522802};\\\", \\\"{x:1114,y:499,t:1527030522842};\\\", \\\"{x:1115,y:499,t:1527030523266};\\\", \\\"{x:1118,y:498,t:1527030523280};\\\", \\\"{x:1124,y:497,t:1527030523297};\\\", \\\"{x:1137,y:496,t:1527030523313};\\\", \\\"{x:1145,y:496,t:1527030523331};\\\", \\\"{x:1154,y:496,t:1527030523347};\\\", \\\"{x:1160,y:495,t:1527030523365};\\\", \\\"{x:1166,y:495,t:1527030523381};\\\", \\\"{x:1172,y:495,t:1527030523397};\\\", \\\"{x:1177,y:495,t:1527030523414};\\\", \\\"{x:1178,y:495,t:1527030523431};\\\", \\\"{x:1182,y:495,t:1527030523447};\\\", \\\"{x:1186,y:495,t:1527030523464};\\\", \\\"{x:1191,y:495,t:1527030523481};\\\", \\\"{x:1193,y:495,t:1527030523497};\\\", \\\"{x:1197,y:495,t:1527030523514};\\\", \\\"{x:1200,y:495,t:1527030523531};\\\", \\\"{x:1202,y:495,t:1527030523552};\\\", \\\"{x:1215,y:495,t:1527030523591};\\\", \\\"{x:1217,y:495,t:1527030523596};\\\", \\\"{x:1223,y:495,t:1527030523614};\\\", \\\"{x:1227,y:495,t:1527030523631};\\\", \\\"{x:1230,y:495,t:1527030523646};\\\", \\\"{x:1232,y:495,t:1527030523663};\\\", \\\"{x:1235,y:495,t:1527030523681};\\\", \\\"{x:1239,y:495,t:1527030523697};\\\", \\\"{x:1244,y:495,t:1527030523714};\\\", \\\"{x:1252,y:495,t:1527030523730};\\\", \\\"{x:1259,y:496,t:1527030523747};\\\", \\\"{x:1265,y:496,t:1527030523764};\\\", \\\"{x:1268,y:497,t:1527030523780};\\\", \\\"{x:1270,y:497,t:1527030523796};\\\", \\\"{x:1271,y:498,t:1527030523814};\\\", \\\"{x:1273,y:498,t:1527030523857};\\\", \\\"{x:1274,y:498,t:1527030523872};\\\", \\\"{x:1274,y:499,t:1527030523889};\\\", \\\"{x:1276,y:499,t:1527030523905};\\\", \\\"{x:1277,y:499,t:1527030523937};\\\", \\\"{x:1278,y:499,t:1527030523969};\\\", \\\"{x:1279,y:499,t:1527030523985};\\\", \\\"{x:1280,y:499,t:1527030523998};\\\", \\\"{x:1283,y:499,t:1527030524014};\\\", \\\"{x:1285,y:500,t:1527030524031};\\\", \\\"{x:1287,y:501,t:1527030524048};\\\", \\\"{x:1290,y:502,t:1527030524064};\\\", \\\"{x:1293,y:503,t:1527030524082};\\\", \\\"{x:1297,y:504,t:1527030524097};\\\", \\\"{x:1302,y:505,t:1527030524114};\\\", \\\"{x:1306,y:507,t:1527030524131};\\\", \\\"{x:1308,y:507,t:1527030524148};\\\", \\\"{x:1309,y:508,t:1527030524491};\\\", \\\"{x:1309,y:510,t:1527030524546};\\\", \\\"{x:1301,y:511,t:1527030524554};\\\", \\\"{x:1291,y:512,t:1527030524565};\\\", \\\"{x:1268,y:519,t:1527030524581};\\\", \\\"{x:1240,y:527,t:1527030524598};\\\", \\\"{x:1206,y:541,t:1527030524614};\\\", \\\"{x:1182,y:554,t:1527030524630};\\\", \\\"{x:1161,y:570,t:1527030524647};\\\", \\\"{x:1148,y:583,t:1527030524664};\\\", \\\"{x:1144,y:591,t:1527030524680};\\\", \\\"{x:1142,y:595,t:1527030524698};\\\", \\\"{x:1142,y:598,t:1527030524714};\\\", \\\"{x:1143,y:600,t:1527030524731};\\\", \\\"{x:1143,y:605,t:1527030524747};\\\", \\\"{x:1147,y:609,t:1527030524765};\\\", \\\"{x:1152,y:612,t:1527030524782};\\\", \\\"{x:1157,y:615,t:1527030524798};\\\", \\\"{x:1172,y:620,t:1527030524815};\\\", \\\"{x:1189,y:624,t:1527030524831};\\\", \\\"{x:1207,y:630,t:1527030524848};\\\", \\\"{x:1233,y:637,t:1527030524865};\\\", \\\"{x:1246,y:646,t:1527030524881};\\\", \\\"{x:1252,y:650,t:1527030524897};\\\", \\\"{x:1253,y:656,t:1527030524915};\\\", \\\"{x:1253,y:660,t:1527030524932};\\\", \\\"{x:1248,y:669,t:1527030524948};\\\", \\\"{x:1240,y:679,t:1527030524965};\\\", \\\"{x:1232,y:686,t:1527030524982};\\\", \\\"{x:1221,y:698,t:1527030524998};\\\", \\\"{x:1207,y:707,t:1527030525015};\\\", \\\"{x:1201,y:712,t:1527030525032};\\\", \\\"{x:1199,y:714,t:1527030525048};\\\", \\\"{x:1198,y:717,t:1527030525065};\\\", \\\"{x:1197,y:718,t:1527030525082};\\\", \\\"{x:1197,y:719,t:1527030525098};\\\", \\\"{x:1197,y:720,t:1527030525115};\\\", \\\"{x:1197,y:722,t:1527030525145};\\\", \\\"{x:1197,y:723,t:1527030525153};\\\", \\\"{x:1197,y:724,t:1527030525169};\\\", \\\"{x:1197,y:727,t:1527030525182};\\\", \\\"{x:1199,y:732,t:1527030525198};\\\", \\\"{x:1201,y:735,t:1527030525215};\\\", \\\"{x:1203,y:739,t:1527030525232};\\\", \\\"{x:1204,y:744,t:1527030525248};\\\", \\\"{x:1205,y:749,t:1527030525266};\\\", \\\"{x:1207,y:754,t:1527030525281};\\\", \\\"{x:1209,y:756,t:1527030525299};\\\", \\\"{x:1210,y:757,t:1527030525315};\\\", \\\"{x:1211,y:759,t:1527030525332};\\\", \\\"{x:1213,y:761,t:1527030525349};\\\", \\\"{x:1218,y:764,t:1527030525365};\\\", \\\"{x:1227,y:768,t:1527030525381};\\\", \\\"{x:1240,y:770,t:1527030525398};\\\", \\\"{x:1256,y:773,t:1527030525414};\\\", \\\"{x:1276,y:775,t:1527030525431};\\\", \\\"{x:1297,y:776,t:1527030525448};\\\", \\\"{x:1302,y:776,t:1527030525464};\\\", \\\"{x:1303,y:776,t:1527030525497};\\\", \\\"{x:1304,y:776,t:1527030525505};\\\", \\\"{x:1305,y:774,t:1527030525521};\\\", \\\"{x:1306,y:772,t:1527030525532};\\\", \\\"{x:1307,y:769,t:1527030525549};\\\", \\\"{x:1309,y:765,t:1527030525565};\\\", \\\"{x:1310,y:764,t:1527030525582};\\\", \\\"{x:1311,y:763,t:1527030525714};\\\", \\\"{x:1312,y:763,t:1527030525722};\\\", \\\"{x:1314,y:763,t:1527030525732};\\\", \\\"{x:1319,y:761,t:1527030525749};\\\", \\\"{x:1325,y:760,t:1527030525767};\\\", \\\"{x:1332,y:759,t:1527030525782};\\\", \\\"{x:1336,y:759,t:1527030525799};\\\", \\\"{x:1337,y:759,t:1527030525816};\\\", \\\"{x:1338,y:759,t:1527030525832};\\\", \\\"{x:1340,y:759,t:1527030525849};\\\", \\\"{x:1342,y:759,t:1527030525866};\\\", \\\"{x:1343,y:759,t:1527030525882};\\\", \\\"{x:1344,y:759,t:1527030525902};\\\", \\\"{x:1345,y:759,t:1527030525932};\\\", \\\"{x:1345,y:758,t:1527030529930};\\\", \\\"{x:1345,y:757,t:1527030529938};\\\", \\\"{x:1346,y:757,t:1527030529952};\\\", \\\"{x:1346,y:755,t:1527030529968};\\\", \\\"{x:1346,y:753,t:1527030529986};\\\", \\\"{x:1347,y:753,t:1527030530009};\\\", \\\"{x:1347,y:752,t:1527030530018};\\\", \\\"{x:1347,y:751,t:1527030530049};\\\", \\\"{x:1347,y:750,t:1527030530057};\\\", \\\"{x:1347,y:749,t:1527030530081};\\\", \\\"{x:1347,y:748,t:1527030530105};\\\", \\\"{x:1347,y:747,t:1527030530121};\\\", \\\"{x:1347,y:745,t:1527030530135};\\\", \\\"{x:1346,y:745,t:1527030530152};\\\", \\\"{x:1346,y:742,t:1527030530170};\\\", \\\"{x:1345,y:740,t:1527030530185};\\\", \\\"{x:1345,y:739,t:1527030530202};\\\", \\\"{x:1345,y:738,t:1527030530219};\\\", \\\"{x:1345,y:737,t:1527030530235};\\\", \\\"{x:1344,y:735,t:1527030530252};\\\", \\\"{x:1344,y:734,t:1527030530269};\\\", \\\"{x:1344,y:733,t:1527030530286};\\\", \\\"{x:1344,y:730,t:1527030530303};\\\", \\\"{x:1344,y:729,t:1527030530319};\\\", \\\"{x:1344,y:728,t:1527030530335};\\\", \\\"{x:1343,y:726,t:1527030530352};\\\", \\\"{x:1343,y:725,t:1527030530369};\\\", \\\"{x:1343,y:724,t:1527030530384};\\\", \\\"{x:1343,y:723,t:1527030530409};\\\", \\\"{x:1343,y:722,t:1527030530425};\\\", \\\"{x:1343,y:721,t:1527030530440};\\\", \\\"{x:1343,y:720,t:1527030530452};\\\", \\\"{x:1343,y:719,t:1527030530469};\\\", \\\"{x:1343,y:717,t:1527030530485};\\\", \\\"{x:1343,y:716,t:1527030530502};\\\", \\\"{x:1343,y:714,t:1527030530519};\\\", \\\"{x:1343,y:712,t:1527030530535};\\\", \\\"{x:1343,y:711,t:1527030530552};\\\", \\\"{x:1343,y:710,t:1527030530569};\\\", \\\"{x:1343,y:708,t:1527030530585};\\\", \\\"{x:1343,y:707,t:1527030530603};\\\", \\\"{x:1343,y:705,t:1527030530619};\\\", \\\"{x:1343,y:704,t:1527030530636};\\\", \\\"{x:1343,y:703,t:1527030530652};\\\", \\\"{x:1344,y:702,t:1527030530669};\\\", \\\"{x:1344,y:701,t:1527030530714};\\\", \\\"{x:1344,y:700,t:1527030530736};\\\", \\\"{x:1344,y:699,t:1527030530754};\\\", \\\"{x:1345,y:699,t:1527030530769};\\\", \\\"{x:1345,y:698,t:1527030532324};\\\", \\\"{x:1345,y:697,t:1527030532339};\\\", \\\"{x:1345,y:696,t:1527030532604};\\\", \\\"{x:1345,y:695,t:1527030532628};\\\", \\\"{x:1345,y:694,t:1527030532644};\\\", \\\"{x:1345,y:693,t:1527030532676};\\\", \\\"{x:1346,y:693,t:1527030533460};\\\", \\\"{x:1347,y:693,t:1527030533474};\\\", \\\"{x:1352,y:692,t:1527030533492};\\\", \\\"{x:1361,y:691,t:1527030533508};\\\", \\\"{x:1370,y:689,t:1527030533524};\\\", \\\"{x:1373,y:689,t:1527030533541};\\\", \\\"{x:1375,y:689,t:1527030533557};\\\", \\\"{x:1376,y:689,t:1527030533574};\\\", \\\"{x:1377,y:689,t:1527030533628};\\\", \\\"{x:1378,y:689,t:1527030533641};\\\", \\\"{x:1382,y:689,t:1527030533657};\\\", \\\"{x:1385,y:689,t:1527030533674};\\\", \\\"{x:1392,y:689,t:1527030533691};\\\", \\\"{x:1403,y:688,t:1527030533707};\\\", \\\"{x:1413,y:689,t:1527030533724};\\\", \\\"{x:1417,y:690,t:1527030533741};\\\", \\\"{x:1424,y:691,t:1527030533757};\\\", \\\"{x:1425,y:691,t:1527030533812};\\\", \\\"{x:1426,y:691,t:1527030533876};\\\", \\\"{x:1426,y:692,t:1527030533908};\\\", \\\"{x:1427,y:692,t:1527030534028};\\\", \\\"{x:1428,y:692,t:1527030534041};\\\", \\\"{x:1432,y:692,t:1527030534058};\\\", \\\"{x:1437,y:692,t:1527030534074};\\\", \\\"{x:1441,y:692,t:1527030534091};\\\", \\\"{x:1457,y:692,t:1527030534108};\\\", \\\"{x:1460,y:692,t:1527030534124};\\\", \\\"{x:1461,y:692,t:1527030534142};\\\", \\\"{x:1462,y:692,t:1527030534158};\\\", \\\"{x:1463,y:692,t:1527030534174};\\\", \\\"{x:1464,y:692,t:1527030534192};\\\", \\\"{x:1465,y:692,t:1527030534208};\\\", \\\"{x:1466,y:692,t:1527030534224};\\\", \\\"{x:1467,y:692,t:1527030534242};\\\", \\\"{x:1468,y:692,t:1527030534324};\\\", \\\"{x:1469,y:692,t:1527030534364};\\\", \\\"{x:1470,y:692,t:1527030534374};\\\", \\\"{x:1471,y:692,t:1527030534391};\\\", \\\"{x:1474,y:692,t:1527030534408};\\\", \\\"{x:1477,y:692,t:1527030534425};\\\", \\\"{x:1482,y:692,t:1527030534441};\\\", \\\"{x:1488,y:692,t:1527030534458};\\\", \\\"{x:1493,y:692,t:1527030534474};\\\", \\\"{x:1494,y:692,t:1527030534491};\\\", \\\"{x:1495,y:692,t:1527030534508};\\\", \\\"{x:1496,y:693,t:1527030534604};\\\", \\\"{x:1496,y:696,t:1527030534645};\\\", \\\"{x:1494,y:697,t:1527030534668};\\\", \\\"{x:1492,y:698,t:1527030534684};\\\", \\\"{x:1491,y:699,t:1527030534692};\\\", \\\"{x:1488,y:701,t:1527030534708};\\\", \\\"{x:1483,y:703,t:1527030534725};\\\", \\\"{x:1482,y:703,t:1527030534741};\\\", \\\"{x:1480,y:703,t:1527030534758};\\\", \\\"{x:1479,y:703,t:1527030534775};\\\", \\\"{x:1480,y:703,t:1527030534923};\\\", \\\"{x:1483,y:703,t:1527030534931};\\\", \\\"{x:1486,y:703,t:1527030534942};\\\", \\\"{x:1491,y:703,t:1527030534958};\\\", \\\"{x:1497,y:703,t:1527030534975};\\\", \\\"{x:1498,y:703,t:1527030534991};\\\", \\\"{x:1500,y:703,t:1527030535007};\\\", \\\"{x:1501,y:703,t:1527030535025};\\\", \\\"{x:1503,y:703,t:1527030535042};\\\", \\\"{x:1505,y:703,t:1527030535058};\\\", \\\"{x:1508,y:703,t:1527030535075};\\\", \\\"{x:1512,y:703,t:1527030535092};\\\", \\\"{x:1514,y:703,t:1527030535109};\\\", \\\"{x:1516,y:703,t:1527030535126};\\\", \\\"{x:1517,y:703,t:1527030535142};\\\", \\\"{x:1518,y:703,t:1527030535164};\\\", \\\"{x:1520,y:703,t:1527030535180};\\\", \\\"{x:1522,y:703,t:1527030535196};\\\", \\\"{x:1524,y:703,t:1527030535220};\\\", \\\"{x:1525,y:703,t:1527030535236};\\\", \\\"{x:1526,y:703,t:1527030535244};\\\", \\\"{x:1527,y:702,t:1527030535260};\\\", \\\"{x:1529,y:702,t:1527030535276};\\\", \\\"{x:1531,y:701,t:1527030535292};\\\", \\\"{x:1532,y:700,t:1527030535309};\\\", \\\"{x:1533,y:699,t:1527030535348};\\\", \\\"{x:1530,y:699,t:1527030535756};\\\", \\\"{x:1518,y:702,t:1527030535764};\\\", \\\"{x:1504,y:703,t:1527030535776};\\\", \\\"{x:1468,y:707,t:1527030535792};\\\", \\\"{x:1436,y:707,t:1527030535809};\\\", \\\"{x:1405,y:707,t:1527030535826};\\\", \\\"{x:1383,y:707,t:1527030535842};\\\", \\\"{x:1369,y:706,t:1527030535860};\\\", \\\"{x:1363,y:705,t:1527030535876};\\\", \\\"{x:1361,y:705,t:1527030535892};\\\", \\\"{x:1361,y:704,t:1527030535910};\\\", \\\"{x:1360,y:704,t:1527030536005};\\\", \\\"{x:1359,y:703,t:1527030536036};\\\", \\\"{x:1358,y:703,t:1527030536044};\\\", \\\"{x:1356,y:703,t:1527030536059};\\\", \\\"{x:1349,y:701,t:1527030536076};\\\", \\\"{x:1338,y:699,t:1527030536093};\\\", \\\"{x:1326,y:698,t:1527030536109};\\\", \\\"{x:1319,y:697,t:1527030536126};\\\", \\\"{x:1317,y:695,t:1527030536142};\\\", \\\"{x:1316,y:695,t:1527030536160};\\\", \\\"{x:1316,y:694,t:1527030536196};\\\", \\\"{x:1316,y:693,t:1527030536211};\\\", \\\"{x:1316,y:692,t:1527030536236};\\\", \\\"{x:1317,y:691,t:1527030536252};\\\", \\\"{x:1318,y:691,t:1527030536259};\\\", \\\"{x:1322,y:691,t:1527030536277};\\\", \\\"{x:1328,y:689,t:1527030536294};\\\", \\\"{x:1333,y:688,t:1527030536309};\\\", \\\"{x:1339,y:687,t:1527030536327};\\\", \\\"{x:1343,y:687,t:1527030536343};\\\", \\\"{x:1347,y:687,t:1527030536359};\\\", \\\"{x:1348,y:687,t:1527030536376};\\\", \\\"{x:1350,y:687,t:1527030536394};\\\", \\\"{x:1351,y:687,t:1527030536409};\\\", \\\"{x:1351,y:685,t:1527030536501};\\\", \\\"{x:1348,y:676,t:1527030536509};\\\", \\\"{x:1337,y:656,t:1527030536526};\\\", \\\"{x:1322,y:634,t:1527030536543};\\\", \\\"{x:1310,y:620,t:1527030536559};\\\", \\\"{x:1300,y:605,t:1527030536577};\\\", \\\"{x:1294,y:593,t:1527030536594};\\\", \\\"{x:1290,y:586,t:1527030536609};\\\", \\\"{x:1290,y:582,t:1527030536626};\\\", \\\"{x:1290,y:581,t:1527030536651};\\\", \\\"{x:1289,y:580,t:1527030536660};\\\", \\\"{x:1289,y:579,t:1527030536676};\\\", \\\"{x:1289,y:578,t:1527030536707};\\\", \\\"{x:1288,y:575,t:1527030536727};\\\", \\\"{x:1287,y:574,t:1527030536748};\\\", \\\"{x:1287,y:573,t:1527030536760};\\\", \\\"{x:1282,y:568,t:1527030536777};\\\", \\\"{x:1279,y:564,t:1527030536793};\\\", \\\"{x:1273,y:560,t:1527030536811};\\\", \\\"{x:1271,y:559,t:1527030536826};\\\", \\\"{x:1269,y:558,t:1527030536843};\\\", \\\"{x:1269,y:557,t:1527030536956};\\\", \\\"{x:1271,y:557,t:1527030537268};\\\", \\\"{x:1275,y:557,t:1527030537277};\\\", \\\"{x:1285,y:557,t:1527030537294};\\\", \\\"{x:1294,y:557,t:1527030537310};\\\", \\\"{x:1298,y:557,t:1527030537328};\\\", \\\"{x:1310,y:558,t:1527030537343};\\\", \\\"{x:1319,y:559,t:1527030537361};\\\", \\\"{x:1327,y:561,t:1527030537378};\\\", \\\"{x:1337,y:561,t:1527030537393};\\\", \\\"{x:1345,y:561,t:1527030537410};\\\", \\\"{x:1348,y:561,t:1527030537427};\\\", \\\"{x:1349,y:561,t:1527030537444};\\\", \\\"{x:1352,y:561,t:1527030537757};\\\", \\\"{x:1353,y:561,t:1527030537764};\\\", \\\"{x:1356,y:561,t:1527030537777};\\\", \\\"{x:1364,y:561,t:1527030537794};\\\", \\\"{x:1373,y:563,t:1527030537810};\\\", \\\"{x:1381,y:563,t:1527030537826};\\\", \\\"{x:1388,y:565,t:1527030537843};\\\", \\\"{x:1391,y:565,t:1527030537860};\\\", \\\"{x:1393,y:565,t:1527030537876};\\\", \\\"{x:1395,y:565,t:1527030537894};\\\", \\\"{x:1397,y:565,t:1527030537910};\\\", \\\"{x:1399,y:565,t:1527030537927};\\\", \\\"{x:1400,y:565,t:1527030537944};\\\", \\\"{x:1401,y:565,t:1527030537964};\\\", \\\"{x:1402,y:565,t:1527030538020};\\\", \\\"{x:1403,y:565,t:1527030538084};\\\", \\\"{x:1404,y:565,t:1527030538095};\\\", \\\"{x:1406,y:565,t:1527030538110};\\\", \\\"{x:1408,y:565,t:1527030538128};\\\", \\\"{x:1410,y:565,t:1527030538144};\\\", \\\"{x:1413,y:565,t:1527030538160};\\\", \\\"{x:1414,y:565,t:1527030538177};\\\", \\\"{x:1416,y:565,t:1527030538194};\\\", \\\"{x:1416,y:564,t:1527030538211};\\\", \\\"{x:1417,y:564,t:1527030538260};\\\", \\\"{x:1419,y:564,t:1527030538278};\\\", \\\"{x:1423,y:564,t:1527030538296};\\\", \\\"{x:1427,y:564,t:1527030538311};\\\", \\\"{x:1432,y:564,t:1527030538327};\\\", \\\"{x:1439,y:564,t:1527030538344};\\\", \\\"{x:1448,y:567,t:1527030538362};\\\", \\\"{x:1456,y:568,t:1527030538378};\\\", \\\"{x:1461,y:568,t:1527030538394};\\\", \\\"{x:1464,y:568,t:1527030538411};\\\", \\\"{x:1465,y:568,t:1527030538468};\\\", \\\"{x:1466,y:568,t:1527030538596};\\\", \\\"{x:1467,y:568,t:1527030538611};\\\", \\\"{x:1471,y:568,t:1527030538627};\\\", \\\"{x:1472,y:568,t:1527030538645};\\\", \\\"{x:1473,y:568,t:1527030538708};\\\", \\\"{x:1474,y:568,t:1527030538772};\\\", \\\"{x:1475,y:568,t:1527030538788};\\\", \\\"{x:1476,y:568,t:1527030538796};\\\", \\\"{x:1477,y:568,t:1527030538820};\\\", \\\"{x:1479,y:567,t:1527030539413};\\\", \\\"{x:1484,y:566,t:1527030539428};\\\", \\\"{x:1490,y:564,t:1527030539445};\\\", \\\"{x:1487,y:564,t:1527030539509};\\\", \\\"{x:1481,y:564,t:1527030539516};\\\", \\\"{x:1470,y:566,t:1527030539529};\\\", \\\"{x:1435,y:573,t:1527030539545};\\\", \\\"{x:1394,y:583,t:1527030539561};\\\", \\\"{x:1336,y:591,t:1527030539578};\\\", \\\"{x:1304,y:591,t:1527030539596};\\\", \\\"{x:1272,y:591,t:1527030539612};\\\", \\\"{x:1261,y:589,t:1527030539628};\\\", \\\"{x:1256,y:587,t:1527030539645};\\\", \\\"{x:1257,y:585,t:1527030539709};\\\", \\\"{x:1257,y:584,t:1527030539724};\\\", \\\"{x:1258,y:583,t:1527030539732};\\\", \\\"{x:1260,y:582,t:1527030539745};\\\", \\\"{x:1261,y:580,t:1527030539762};\\\", \\\"{x:1262,y:579,t:1527030539779};\\\", \\\"{x:1263,y:579,t:1527030539795};\\\", \\\"{x:1264,y:578,t:1527030539812};\\\", \\\"{x:1265,y:577,t:1527030539852};\\\", \\\"{x:1265,y:575,t:1527030539868};\\\", \\\"{x:1265,y:574,t:1527030539878};\\\", \\\"{x:1267,y:573,t:1527030539895};\\\", \\\"{x:1267,y:571,t:1527030539912};\\\", \\\"{x:1269,y:570,t:1527030539928};\\\", \\\"{x:1270,y:570,t:1527030539946};\\\", \\\"{x:1270,y:569,t:1527030539963};\\\", \\\"{x:1271,y:568,t:1527030540028};\\\", \\\"{x:1272,y:566,t:1527030540869};\\\", \\\"{x:1273,y:566,t:1527030540955};\\\", \\\"{x:1273,y:565,t:1527030540995};\\\", \\\"{x:1275,y:565,t:1527030541123};\\\", \\\"{x:1276,y:564,t:1527030541196};\\\", \\\"{x:1274,y:564,t:1527030541941};\\\", \\\"{x:1264,y:564,t:1527030541947};\\\", \\\"{x:1238,y:564,t:1527030541963};\\\", \\\"{x:1208,y:564,t:1527030541979};\\\", \\\"{x:1178,y:561,t:1527030541996};\\\", \\\"{x:1139,y:560,t:1527030542013};\\\", \\\"{x:1102,y:558,t:1527030542031};\\\", \\\"{x:1065,y:558,t:1527030542047};\\\", \\\"{x:1037,y:558,t:1527030542063};\\\", \\\"{x:1009,y:558,t:1527030542081};\\\", \\\"{x:978,y:558,t:1527030542097};\\\", \\\"{x:937,y:560,t:1527030542114};\\\", \\\"{x:909,y:564,t:1527030542131};\\\", \\\"{x:870,y:566,t:1527030542146};\\\", \\\"{x:843,y:566,t:1527030542163};\\\", \\\"{x:819,y:565,t:1527030542181};\\\", \\\"{x:775,y:557,t:1527030542198};\\\", \\\"{x:714,y:549,t:1527030542216};\\\", \\\"{x:658,y:540,t:1527030542231};\\\", \\\"{x:591,y:532,t:1527030542247};\\\", \\\"{x:522,y:523,t:1527030542265};\\\", \\\"{x:451,y:509,t:1527030542281};\\\", \\\"{x:398,y:501,t:1527030542298};\\\", \\\"{x:345,y:494,t:1527030542315};\\\", \\\"{x:325,y:492,t:1527030542331};\\\", \\\"{x:318,y:492,t:1527030542348};\\\", \\\"{x:315,y:490,t:1527030542365};\\\", \\\"{x:320,y:489,t:1527030542411};\\\", \\\"{x:327,y:488,t:1527030542419};\\\", \\\"{x:338,y:488,t:1527030542430};\\\", \\\"{x:368,y:488,t:1527030542448};\\\", \\\"{x:410,y:488,t:1527030542464};\\\", \\\"{x:469,y:488,t:1527030542481};\\\", \\\"{x:517,y:488,t:1527030542499};\\\", \\\"{x:551,y:494,t:1527030542514};\\\", \\\"{x:569,y:495,t:1527030542531};\\\", \\\"{x:571,y:495,t:1527030542548};\\\", \\\"{x:573,y:495,t:1527030542635};\\\", \\\"{x:574,y:495,t:1527030542647};\\\", \\\"{x:577,y:495,t:1527030542665};\\\", \\\"{x:578,y:495,t:1527030542682};\\\", \\\"{x:579,y:496,t:1527030542698};\\\", \\\"{x:579,y:497,t:1527030542715};\\\", \\\"{x:580,y:498,t:1527030542812};\\\", \\\"{x:581,y:498,t:1527030542828};\\\", \\\"{x:585,y:500,t:1527030542843};\\\", \\\"{x:587,y:500,t:1527030542860};\\\", \\\"{x:588,y:500,t:1527030542875};\\\", \\\"{x:590,y:500,t:1527030542892};\\\", \\\"{x:591,y:500,t:1527030542948};\\\", \\\"{x:591,y:501,t:1527030542979};\\\", \\\"{x:591,y:502,t:1527030543164};\\\", \\\"{x:591,y:504,t:1527030543171};\\\", \\\"{x:591,y:509,t:1527030543182};\\\", \\\"{x:588,y:518,t:1527030543199};\\\", \\\"{x:584,y:531,t:1527030543217};\\\", \\\"{x:580,y:548,t:1527030543232};\\\", \\\"{x:577,y:563,t:1527030543249};\\\", \\\"{x:574,y:582,t:1527030543265};\\\", \\\"{x:572,y:598,t:1527030543282};\\\", \\\"{x:568,y:611,t:1527030543299};\\\", \\\"{x:563,y:636,t:1527030543316};\\\", \\\"{x:562,y:653,t:1527030543332};\\\", \\\"{x:558,y:665,t:1527030543349};\\\", \\\"{x:557,y:670,t:1527030543364};\\\", \\\"{x:557,y:674,t:1527030543382};\\\", \\\"{x:557,y:675,t:1527030543403};\\\", \\\"{x:559,y:675,t:1527030543415};\\\", \\\"{x:565,y:667,t:1527030543432};\\\", \\\"{x:575,y:652,t:1527030543448};\\\", \\\"{x:587,y:619,t:1527030543467};\\\", \\\"{x:599,y:574,t:1527030543482};\\\", \\\"{x:605,y:534,t:1527030543499};\\\", \\\"{x:605,y:521,t:1527030543515};\\\", \\\"{x:605,y:516,t:1527030543532};\\\", \\\"{x:602,y:510,t:1527030543549};\\\", \\\"{x:602,y:509,t:1527030543566};\\\", \\\"{x:601,y:508,t:1527030543581};\\\", \\\"{x:600,y:507,t:1527030543599};\\\", \\\"{x:600,y:506,t:1527030543659};\\\", \\\"{x:600,y:505,t:1527030543683};\\\", \\\"{x:599,y:505,t:1527030543866};\\\", \\\"{x:586,y:520,t:1527030543883};\\\", \\\"{x:573,y:535,t:1527030543899};\\\", \\\"{x:561,y:554,t:1527030543916};\\\", \\\"{x:543,y:578,t:1527030543932};\\\", \\\"{x:536,y:594,t:1527030543949};\\\", \\\"{x:532,y:606,t:1527030543966};\\\", \\\"{x:529,y:620,t:1527030543983};\\\", \\\"{x:529,y:630,t:1527030543999};\\\", \\\"{x:528,y:641,t:1527030544016};\\\", \\\"{x:528,y:651,t:1527030544033};\\\", \\\"{x:528,y:661,t:1527030544048};\\\", \\\"{x:528,y:669,t:1527030544066};\\\", \\\"{x:528,y:683,t:1527030544083};\\\", \\\"{x:528,y:689,t:1527030544100};\\\", \\\"{x:526,y:698,t:1527030544116};\\\", \\\"{x:524,y:703,t:1527030544133};\\\", \\\"{x:522,y:704,t:1527030544150};\\\", \\\"{x:521,y:704,t:1527030544340};\\\", \\\"{x:521,y:705,t:1527030544452};\\\", \\\"{x:521,y:708,t:1527030544467};\\\", \\\"{x:521,y:710,t:1527030544484};\\\", \\\"{x:521,y:712,t:1527030544501};\\\", \\\"{x:521,y:713,t:1527030544518};\\\", \\\"{x:521,y:714,t:1527030544535};\\\", \\\"{x:521,y:715,t:1527030544564};\\\", \\\"{x:521,y:716,t:1527030544580};\\\", \\\"{x:521,y:718,t:1527030544588};\\\", \\\"{x:521,y:721,t:1527030544605};\\\", \\\"{x:521,y:723,t:1527030544618};\\\", \\\"{x:522,y:726,t:1527030544633};\\\", \\\"{x:522,y:728,t:1527030544650};\\\", \\\"{x:522,y:729,t:1527030544666};\\\", \\\"{x:522,y:731,t:1527030544707};\\\", \\\"{x:522,y:732,t:1527030545244};\\\", \\\"{x:523,y:733,t:1527030545251};\\\", \\\"{x:529,y:736,t:1527030545268};\\\", \\\"{x:538,y:740,t:1527030545283};\\\", \\\"{x:551,y:745,t:1527030545300};\\\", \\\"{x:566,y:753,t:1527030545317};\\\", \\\"{x:578,y:758,t:1527030545334};\\\", \\\"{x:595,y:765,t:1527030545350};\\\", \\\"{x:614,y:773,t:1527030545368};\\\", \\\"{x:632,y:778,t:1527030545385};\\\", \\\"{x:650,y:784,t:1527030545399};\\\", \\\"{x:676,y:789,t:1527030545417};\\\", \\\"{x:719,y:801,t:1527030545434};\\\", \\\"{x:748,y:804,t:1527030545450};\\\", \\\"{x:807,y:814,t:1527030545466};\\\", \\\"{x:845,y:815,t:1527030545484};\\\", \\\"{x:850,y:817,t:1527030545500};\\\" ] }, { \\\"rt\\\": 19099, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 454371, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -B -J -J -I -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:697,y:735,t:1527030546614};\\\", \\\"{x:667,y:717,t:1527030546619};\\\", \\\"{x:599,y:678,t:1527030546635};\\\", \\\"{x:551,y:643,t:1527030546651};\\\", \\\"{x:490,y:608,t:1527030546668};\\\", \\\"{x:430,y:573,t:1527030546685};\\\", \\\"{x:403,y:556,t:1527030546701};\\\", \\\"{x:382,y:542,t:1527030546719};\\\", \\\"{x:375,y:537,t:1527030546734};\\\", \\\"{x:369,y:533,t:1527030546751};\\\", \\\"{x:367,y:532,t:1527030546768};\\\", \\\"{x:367,y:531,t:1527030546785};\\\", \\\"{x:366,y:531,t:1527030546800};\\\", \\\"{x:365,y:527,t:1527030546817};\\\", \\\"{x:362,y:520,t:1527030546835};\\\", \\\"{x:361,y:514,t:1527030546852};\\\", \\\"{x:360,y:508,t:1527030546868};\\\", \\\"{x:360,y:502,t:1527030546885};\\\", \\\"{x:360,y:495,t:1527030546901};\\\", \\\"{x:362,y:490,t:1527030546918};\\\", \\\"{x:366,y:484,t:1527030546936};\\\", \\\"{x:369,y:481,t:1527030546951};\\\", \\\"{x:372,y:478,t:1527030546968};\\\", \\\"{x:376,y:476,t:1527030546985};\\\", \\\"{x:382,y:473,t:1527030547002};\\\", \\\"{x:392,y:472,t:1527030547018};\\\", \\\"{x:405,y:472,t:1527030547035};\\\", \\\"{x:416,y:472,t:1527030547052};\\\", \\\"{x:430,y:472,t:1527030547069};\\\", \\\"{x:443,y:474,t:1527030547085};\\\", \\\"{x:455,y:475,t:1527030547101};\\\", \\\"{x:470,y:478,t:1527030547119};\\\", \\\"{x:484,y:480,t:1527030547136};\\\", \\\"{x:499,y:482,t:1527030547152};\\\", \\\"{x:509,y:484,t:1527030547168};\\\", \\\"{x:514,y:484,t:1527030547185};\\\", \\\"{x:517,y:484,t:1527030547203};\\\", \\\"{x:521,y:484,t:1527030547219};\\\", \\\"{x:532,y:483,t:1527030547236};\\\", \\\"{x:541,y:481,t:1527030547252};\\\", \\\"{x:551,y:477,t:1527030547268};\\\", \\\"{x:551,y:476,t:1527030547292};\\\", \\\"{x:552,y:476,t:1527030547364};\\\", \\\"{x:553,y:476,t:1527030547844};\\\", \\\"{x:554,y:476,t:1527030547853};\\\", \\\"{x:555,y:476,t:1527030547876};\\\", \\\"{x:557,y:476,t:1527030547891};\\\", \\\"{x:558,y:476,t:1527030547908};\\\", \\\"{x:558,y:475,t:1527030547920};\\\", \\\"{x:560,y:474,t:1527030547936};\\\", \\\"{x:561,y:474,t:1527030547952};\\\", \\\"{x:563,y:473,t:1527030547969};\\\", \\\"{x:565,y:472,t:1527030547987};\\\", \\\"{x:567,y:470,t:1527030548002};\\\", \\\"{x:574,y:467,t:1527030548020};\\\", \\\"{x:576,y:466,t:1527030548036};\\\", \\\"{x:580,y:464,t:1527030548053};\\\", \\\"{x:586,y:463,t:1527030548070};\\\", \\\"{x:588,y:463,t:1527030548086};\\\", \\\"{x:590,y:463,t:1527030548102};\\\", \\\"{x:591,y:463,t:1527030548120};\\\", \\\"{x:594,y:463,t:1527030548136};\\\", \\\"{x:595,y:462,t:1527030548152};\\\", \\\"{x:596,y:462,t:1527030548169};\\\", \\\"{x:598,y:462,t:1527030548187};\\\", \\\"{x:601,y:462,t:1527030548202};\\\", \\\"{x:606,y:462,t:1527030548219};\\\", \\\"{x:610,y:462,t:1527030548237};\\\", \\\"{x:612,y:462,t:1527030548254};\\\", \\\"{x:615,y:462,t:1527030548269};\\\", \\\"{x:619,y:462,t:1527030548286};\\\", \\\"{x:621,y:462,t:1527030548303};\\\", \\\"{x:622,y:462,t:1527030548319};\\\", \\\"{x:623,y:462,t:1527030548340};\\\", \\\"{x:624,y:462,t:1527030548388};\\\", \\\"{x:626,y:462,t:1527030548420};\\\", \\\"{x:629,y:464,t:1527030548437};\\\", \\\"{x:632,y:465,t:1527030548454};\\\", \\\"{x:635,y:465,t:1527030548469};\\\", \\\"{x:640,y:465,t:1527030548486};\\\", \\\"{x:649,y:467,t:1527030548504};\\\", \\\"{x:666,y:469,t:1527030548520};\\\", \\\"{x:688,y:473,t:1527030548537};\\\", \\\"{x:713,y:476,t:1527030548553};\\\", \\\"{x:751,y:481,t:1527030548570};\\\", \\\"{x:789,y:489,t:1527030548588};\\\", \\\"{x:846,y:496,t:1527030548603};\\\", \\\"{x:926,y:510,t:1527030548636};\\\", \\\"{x:956,y:516,t:1527030548653};\\\", \\\"{x:985,y:520,t:1527030548670};\\\", \\\"{x:1011,y:524,t:1527030548686};\\\", \\\"{x:1039,y:527,t:1527030548703};\\\", \\\"{x:1068,y:531,t:1527030548719};\\\", \\\"{x:1094,y:536,t:1527030548736};\\\", \\\"{x:1122,y:539,t:1527030548753};\\\", \\\"{x:1153,y:544,t:1527030548769};\\\", \\\"{x:1184,y:549,t:1527030548786};\\\", \\\"{x:1247,y:557,t:1527030548803};\\\", \\\"{x:1286,y:563,t:1527030548821};\\\", \\\"{x:1325,y:568,t:1527030548837};\\\", \\\"{x:1362,y:574,t:1527030548853};\\\", \\\"{x:1397,y:581,t:1527030548870};\\\", \\\"{x:1426,y:584,t:1527030548886};\\\", \\\"{x:1448,y:589,t:1527030548903};\\\", \\\"{x:1466,y:595,t:1527030548921};\\\", \\\"{x:1477,y:600,t:1527030548937};\\\", \\\"{x:1485,y:604,t:1527030548953};\\\", \\\"{x:1486,y:606,t:1527030548970};\\\", \\\"{x:1486,y:607,t:1527030548986};\\\", \\\"{x:1486,y:608,t:1527030549356};\\\", \\\"{x:1485,y:610,t:1527030549371};\\\", \\\"{x:1483,y:614,t:1527030549387};\\\", \\\"{x:1480,y:621,t:1527030549404};\\\", \\\"{x:1477,y:625,t:1527030549421};\\\", \\\"{x:1476,y:627,t:1527030549438};\\\", \\\"{x:1476,y:628,t:1527030549453};\\\", \\\"{x:1475,y:629,t:1527030549484};\\\", \\\"{x:1474,y:629,t:1527030549500};\\\", \\\"{x:1473,y:630,t:1527030549508};\\\", \\\"{x:1473,y:632,t:1527030549524};\\\", \\\"{x:1473,y:634,t:1527030549540};\\\", \\\"{x:1471,y:636,t:1527030549554};\\\", \\\"{x:1471,y:639,t:1527030549570};\\\", \\\"{x:1471,y:646,t:1527030549587};\\\", \\\"{x:1471,y:649,t:1527030549603};\\\", \\\"{x:1471,y:651,t:1527030549620};\\\", \\\"{x:1471,y:653,t:1527030549637};\\\", \\\"{x:1471,y:654,t:1527030549653};\\\", \\\"{x:1471,y:656,t:1527030549671};\\\", \\\"{x:1472,y:660,t:1527030549688};\\\", \\\"{x:1475,y:664,t:1527030549704};\\\", \\\"{x:1478,y:669,t:1527030549721};\\\", \\\"{x:1482,y:672,t:1527030549738};\\\", \\\"{x:1486,y:676,t:1527030549754};\\\", \\\"{x:1493,y:679,t:1527030549771};\\\", \\\"{x:1498,y:682,t:1527030549788};\\\", \\\"{x:1498,y:684,t:1527030549861};\\\", \\\"{x:1498,y:686,t:1527030549871};\\\", \\\"{x:1495,y:689,t:1527030549888};\\\", \\\"{x:1489,y:693,t:1527030549905};\\\", \\\"{x:1478,y:700,t:1527030549920};\\\", \\\"{x:1466,y:704,t:1527030549938};\\\", \\\"{x:1454,y:710,t:1527030549955};\\\", \\\"{x:1441,y:714,t:1527030549971};\\\", \\\"{x:1427,y:718,t:1527030549987};\\\", \\\"{x:1423,y:719,t:1527030550005};\\\", \\\"{x:1421,y:721,t:1527030550020};\\\", \\\"{x:1419,y:721,t:1527030550038};\\\", \\\"{x:1418,y:722,t:1527030550054};\\\", \\\"{x:1416,y:722,t:1527030550070};\\\", \\\"{x:1416,y:724,t:1527030550088};\\\", \\\"{x:1413,y:725,t:1527030550105};\\\", \\\"{x:1411,y:726,t:1527030550124};\\\", \\\"{x:1409,y:727,t:1527030550138};\\\", \\\"{x:1405,y:729,t:1527030550155};\\\", \\\"{x:1397,y:734,t:1527030550171};\\\", \\\"{x:1383,y:741,t:1527030550188};\\\", \\\"{x:1375,y:743,t:1527030550205};\\\", \\\"{x:1369,y:747,t:1527030550220};\\\", \\\"{x:1361,y:751,t:1527030550238};\\\", \\\"{x:1354,y:756,t:1527030550255};\\\", \\\"{x:1348,y:762,t:1527030550272};\\\", \\\"{x:1342,y:767,t:1527030550289};\\\", \\\"{x:1332,y:773,t:1527030550305};\\\", \\\"{x:1325,y:779,t:1527030550321};\\\", \\\"{x:1316,y:786,t:1527030550338};\\\", \\\"{x:1310,y:790,t:1527030550355};\\\", \\\"{x:1299,y:797,t:1527030550372};\\\", \\\"{x:1294,y:801,t:1527030550388};\\\", \\\"{x:1288,y:803,t:1527030550404};\\\", \\\"{x:1280,y:807,t:1527030550422};\\\", \\\"{x:1273,y:808,t:1527030550438};\\\", \\\"{x:1265,y:809,t:1527030550455};\\\", \\\"{x:1255,y:813,t:1527030550472};\\\", \\\"{x:1244,y:814,t:1527030550488};\\\", \\\"{x:1231,y:816,t:1527030550505};\\\", \\\"{x:1218,y:817,t:1527030550521};\\\", \\\"{x:1202,y:818,t:1527030550538};\\\", \\\"{x:1196,y:818,t:1527030550555};\\\", \\\"{x:1191,y:818,t:1527030550572};\\\", \\\"{x:1190,y:818,t:1527030550596};\\\", \\\"{x:1189,y:819,t:1527030550612};\\\", \\\"{x:1189,y:820,t:1527030550621};\\\", \\\"{x:1188,y:821,t:1527030550637};\\\", \\\"{x:1188,y:822,t:1527030550654};\\\", \\\"{x:1189,y:824,t:1527030550671};\\\", \\\"{x:1191,y:825,t:1527030550706};\\\", \\\"{x:1192,y:826,t:1527030550763};\\\", \\\"{x:1193,y:826,t:1527030550771};\\\", \\\"{x:1194,y:826,t:1527030550789};\\\", \\\"{x:1196,y:826,t:1527030550805};\\\", \\\"{x:1198,y:826,t:1527030550821};\\\", \\\"{x:1201,y:826,t:1527030550838};\\\", \\\"{x:1204,y:826,t:1527030550854};\\\", \\\"{x:1205,y:827,t:1527030550872};\\\", \\\"{x:1207,y:827,t:1527030550889};\\\", \\\"{x:1209,y:827,t:1527030550905};\\\", \\\"{x:1211,y:827,t:1527030550922};\\\", \\\"{x:1213,y:827,t:1527030550938};\\\", \\\"{x:1214,y:827,t:1527030550954};\\\", \\\"{x:1217,y:827,t:1527030550971};\\\", \\\"{x:1219,y:827,t:1527030551028};\\\", \\\"{x:1218,y:827,t:1527030551156};\\\", \\\"{x:1216,y:827,t:1527030551171};\\\", \\\"{x:1213,y:823,t:1527030551189};\\\", \\\"{x:1212,y:819,t:1527030551205};\\\", \\\"{x:1208,y:814,t:1527030551223};\\\", \\\"{x:1206,y:809,t:1527030551239};\\\", \\\"{x:1204,y:807,t:1527030551255};\\\", \\\"{x:1202,y:803,t:1527030551272};\\\", \\\"{x:1198,y:798,t:1527030551289};\\\", \\\"{x:1197,y:797,t:1527030551306};\\\", \\\"{x:1195,y:794,t:1527030551322};\\\", \\\"{x:1194,y:792,t:1527030551339};\\\", \\\"{x:1192,y:788,t:1527030551356};\\\", \\\"{x:1191,y:785,t:1527030551372};\\\", \\\"{x:1190,y:782,t:1527030551389};\\\", \\\"{x:1189,y:779,t:1527030551405};\\\", \\\"{x:1187,y:775,t:1527030551422};\\\", \\\"{x:1186,y:773,t:1527030551438};\\\", \\\"{x:1186,y:772,t:1527030551455};\\\", \\\"{x:1186,y:771,t:1527030551476};\\\", \\\"{x:1186,y:770,t:1527030551489};\\\", \\\"{x:1185,y:769,t:1527030551506};\\\", \\\"{x:1184,y:768,t:1527030551523};\\\", \\\"{x:1183,y:766,t:1527030551538};\\\", \\\"{x:1182,y:765,t:1527030551579};\\\", \\\"{x:1182,y:764,t:1527030551596};\\\", \\\"{x:1181,y:764,t:1527030551605};\\\", \\\"{x:1180,y:763,t:1527030551621};\\\", \\\"{x:1179,y:761,t:1527030551652};\\\", \\\"{x:1178,y:761,t:1527030551675};\\\", \\\"{x:1177,y:760,t:1527030551724};\\\", \\\"{x:1177,y:762,t:1527030553820};\\\", \\\"{x:1178,y:762,t:1527030554516};\\\", \\\"{x:1179,y:762,t:1527030554524};\\\", \\\"{x:1187,y:762,t:1527030554542};\\\", \\\"{x:1193,y:761,t:1527030554558};\\\", \\\"{x:1198,y:761,t:1527030554574};\\\", \\\"{x:1202,y:761,t:1527030554591};\\\", \\\"{x:1205,y:761,t:1527030554608};\\\", \\\"{x:1207,y:761,t:1527030554624};\\\", \\\"{x:1211,y:761,t:1527030554641};\\\", \\\"{x:1213,y:761,t:1527030554658};\\\", \\\"{x:1216,y:761,t:1527030554675};\\\", \\\"{x:1222,y:761,t:1527030554691};\\\", \\\"{x:1228,y:761,t:1527030554707};\\\", \\\"{x:1230,y:761,t:1527030554725};\\\", \\\"{x:1231,y:761,t:1527030554741};\\\", \\\"{x:1232,y:761,t:1527030554758};\\\", \\\"{x:1233,y:761,t:1527030554775};\\\", \\\"{x:1236,y:760,t:1527030554791};\\\", \\\"{x:1239,y:760,t:1527030554808};\\\", \\\"{x:1242,y:759,t:1527030554825};\\\", \\\"{x:1244,y:759,t:1527030554841};\\\", \\\"{x:1246,y:759,t:1527030554858};\\\", \\\"{x:1248,y:759,t:1527030554884};\\\", \\\"{x:1250,y:759,t:1527030555083};\\\", \\\"{x:1252,y:759,t:1527030555091};\\\", \\\"{x:1262,y:759,t:1527030555108};\\\", \\\"{x:1276,y:760,t:1527030555125};\\\", \\\"{x:1286,y:762,t:1527030555141};\\\", \\\"{x:1295,y:764,t:1527030555157};\\\", \\\"{x:1305,y:766,t:1527030555174};\\\", \\\"{x:1311,y:766,t:1527030555192};\\\", \\\"{x:1314,y:767,t:1527030555208};\\\", \\\"{x:1315,y:767,t:1527030555225};\\\", \\\"{x:1316,y:767,t:1527030555475};\\\", \\\"{x:1318,y:767,t:1527030555499};\\\", \\\"{x:1319,y:767,t:1527030555508};\\\", \\\"{x:1320,y:767,t:1527030555525};\\\", \\\"{x:1323,y:766,t:1527030555542};\\\", \\\"{x:1328,y:766,t:1527030555558};\\\", \\\"{x:1333,y:765,t:1527030555574};\\\", \\\"{x:1336,y:765,t:1527030555592};\\\", \\\"{x:1337,y:765,t:1527030555609};\\\", \\\"{x:1342,y:765,t:1527030555625};\\\", \\\"{x:1347,y:764,t:1527030555642};\\\", \\\"{x:1352,y:761,t:1527030555658};\\\", \\\"{x:1354,y:761,t:1527030556075};\\\", \\\"{x:1357,y:761,t:1527030556091};\\\", \\\"{x:1360,y:761,t:1527030556108};\\\", \\\"{x:1361,y:761,t:1527030556125};\\\", \\\"{x:1362,y:761,t:1527030556141};\\\", \\\"{x:1364,y:760,t:1527030556159};\\\", \\\"{x:1365,y:760,t:1527030556187};\\\", \\\"{x:1366,y:760,t:1527030556356};\\\", \\\"{x:1367,y:760,t:1527030556371};\\\", \\\"{x:1369,y:759,t:1527030556387};\\\", \\\"{x:1369,y:758,t:1527030556395};\\\", \\\"{x:1370,y:758,t:1527030556411};\\\", \\\"{x:1371,y:758,t:1527030556427};\\\", \\\"{x:1372,y:758,t:1527030556588};\\\", \\\"{x:1373,y:758,t:1527030556596};\\\", \\\"{x:1374,y:758,t:1527030556644};\\\", \\\"{x:1374,y:759,t:1527030556667};\\\", \\\"{x:1374,y:760,t:1527030556676};\\\", \\\"{x:1375,y:760,t:1527030556692};\\\", \\\"{x:1376,y:761,t:1527030556731};\\\", \\\"{x:1376,y:763,t:1527030556763};\\\", \\\"{x:1376,y:764,t:1527030556819};\\\", \\\"{x:1377,y:765,t:1527030556827};\\\", \\\"{x:1377,y:764,t:1527030559852};\\\", \\\"{x:1377,y:763,t:1527030559876};\\\", \\\"{x:1377,y:762,t:1527030561085};\\\", \\\"{x:1377,y:761,t:1527030561452};\\\", \\\"{x:1372,y:761,t:1527030561464};\\\", \\\"{x:1356,y:761,t:1527030561479};\\\", \\\"{x:1327,y:761,t:1527030561496};\\\", \\\"{x:1289,y:761,t:1527030561513};\\\", \\\"{x:1250,y:761,t:1527030561530};\\\", \\\"{x:1200,y:756,t:1527030561546};\\\", \\\"{x:1146,y:749,t:1527030561563};\\\", \\\"{x:1067,y:738,t:1527030561580};\\\", \\\"{x:1010,y:728,t:1527030561596};\\\", \\\"{x:962,y:719,t:1527030561614};\\\", \\\"{x:918,y:710,t:1527030561629};\\\", \\\"{x:888,y:701,t:1527030561646};\\\", \\\"{x:843,y:687,t:1527030561663};\\\", \\\"{x:777,y:672,t:1527030561679};\\\", \\\"{x:731,y:661,t:1527030561697};\\\", \\\"{x:678,y:647,t:1527030561713};\\\", \\\"{x:634,y:643,t:1527030561729};\\\", \\\"{x:603,y:633,t:1527030561746};\\\", \\\"{x:561,y:620,t:1527030561765};\\\", \\\"{x:546,y:615,t:1527030561780};\\\", \\\"{x:541,y:612,t:1527030561795};\\\", \\\"{x:538,y:610,t:1527030561812};\\\", \\\"{x:535,y:607,t:1527030561829};\\\", \\\"{x:530,y:603,t:1527030561847};\\\", \\\"{x:527,y:599,t:1527030561864};\\\", \\\"{x:523,y:591,t:1527030561880};\\\", \\\"{x:520,y:583,t:1527030561897};\\\", \\\"{x:517,y:579,t:1527030561914};\\\", \\\"{x:514,y:573,t:1527030561929};\\\", \\\"{x:508,y:566,t:1527030561946};\\\", \\\"{x:505,y:563,t:1527030561963};\\\", \\\"{x:503,y:559,t:1527030561981};\\\", \\\"{x:502,y:558,t:1527030561997};\\\", \\\"{x:502,y:556,t:1527030562014};\\\", \\\"{x:502,y:554,t:1527030562030};\\\", \\\"{x:502,y:550,t:1527030562047};\\\", \\\"{x:500,y:546,t:1527030562064};\\\", \\\"{x:499,y:546,t:1527030562251};\\\", \\\"{x:498,y:545,t:1527030562265};\\\", \\\"{x:497,y:545,t:1527030562281};\\\", \\\"{x:495,y:542,t:1527030562297};\\\", \\\"{x:494,y:542,t:1527030562315};\\\", \\\"{x:493,y:540,t:1527030562331};\\\", \\\"{x:492,y:539,t:1527030562363};\\\", \\\"{x:491,y:536,t:1527030562382};\\\", \\\"{x:487,y:533,t:1527030562397};\\\", \\\"{x:484,y:531,t:1527030562414};\\\", \\\"{x:479,y:527,t:1527030562431};\\\", \\\"{x:477,y:525,t:1527030562447};\\\", \\\"{x:477,y:523,t:1527030562465};\\\", \\\"{x:475,y:521,t:1527030562481};\\\", \\\"{x:475,y:520,t:1527030562507};\\\", \\\"{x:475,y:519,t:1527030562514};\\\", \\\"{x:474,y:518,t:1527030562538};\\\", \\\"{x:473,y:516,t:1527030562547};\\\", \\\"{x:473,y:515,t:1527030562564};\\\", \\\"{x:472,y:514,t:1527030562581};\\\", \\\"{x:470,y:512,t:1527030562598};\\\", \\\"{x:468,y:510,t:1527030562614};\\\", \\\"{x:467,y:509,t:1527030562630};\\\", \\\"{x:465,y:509,t:1527030562648};\\\", \\\"{x:463,y:508,t:1527030562663};\\\", \\\"{x:462,y:508,t:1527030562681};\\\", \\\"{x:461,y:507,t:1527030562698};\\\", \\\"{x:458,y:506,t:1527030562714};\\\", \\\"{x:455,y:505,t:1527030562732};\\\", \\\"{x:453,y:505,t:1527030562747};\\\", \\\"{x:451,y:505,t:1527030562764};\\\", \\\"{x:446,y:505,t:1527030562781};\\\", \\\"{x:440,y:503,t:1527030562798};\\\", \\\"{x:433,y:502,t:1527030562814};\\\", \\\"{x:427,y:501,t:1527030562831};\\\", \\\"{x:422,y:501,t:1527030562848};\\\", \\\"{x:420,y:501,t:1527030562864};\\\", \\\"{x:419,y:501,t:1527030562881};\\\", \\\"{x:416,y:501,t:1527030562898};\\\", \\\"{x:415,y:501,t:1527030562933};\\\", \\\"{x:413,y:501,t:1527030562948};\\\", \\\"{x:412,y:501,t:1527030562964};\\\", \\\"{x:409,y:501,t:1527030562980};\\\", \\\"{x:406,y:501,t:1527030562997};\\\", \\\"{x:403,y:501,t:1527030563014};\\\", \\\"{x:400,y:501,t:1527030563031};\\\", \\\"{x:397,y:501,t:1527030563047};\\\", \\\"{x:396,y:501,t:1527030563065};\\\", \\\"{x:395,y:500,t:1527030563081};\\\", \\\"{x:393,y:500,t:1527030563098};\\\", \\\"{x:391,y:499,t:1527030563114};\\\", \\\"{x:387,y:498,t:1527030563131};\\\", \\\"{x:386,y:498,t:1527030563148};\\\", \\\"{x:385,y:498,t:1527030563165};\\\", \\\"{x:383,y:497,t:1527030563212};\\\", \\\"{x:382,y:496,t:1527030563508};\\\", \\\"{x:381,y:496,t:1527030563524};\\\", \\\"{x:380,y:497,t:1527030563532};\\\", \\\"{x:378,y:499,t:1527030563548};\\\", \\\"{x:377,y:501,t:1527030563565};\\\", \\\"{x:376,y:503,t:1527030563582};\\\", \\\"{x:375,y:505,t:1527030563599};\\\", \\\"{x:374,y:510,t:1527030563615};\\\", \\\"{x:372,y:515,t:1527030563631};\\\", \\\"{x:368,y:521,t:1527030563648};\\\", \\\"{x:367,y:524,t:1527030563665};\\\", \\\"{x:361,y:530,t:1527030563682};\\\", \\\"{x:355,y:538,t:1527030563697};\\\", \\\"{x:348,y:544,t:1527030563715};\\\", \\\"{x:346,y:545,t:1527030563731};\\\", \\\"{x:344,y:546,t:1527030563747};\\\", \\\"{x:340,y:549,t:1527030563765};\\\", \\\"{x:337,y:552,t:1527030563782};\\\", \\\"{x:334,y:554,t:1527030563797};\\\", \\\"{x:332,y:554,t:1527030563815};\\\", \\\"{x:331,y:554,t:1527030563832};\\\", \\\"{x:329,y:554,t:1527030563849};\\\", \\\"{x:327,y:554,t:1527030563865};\\\", \\\"{x:325,y:554,t:1527030563883};\\\", \\\"{x:322,y:554,t:1527030563898};\\\", \\\"{x:312,y:557,t:1527030563917};\\\", \\\"{x:306,y:557,t:1527030563932};\\\", \\\"{x:295,y:557,t:1527030563949};\\\", \\\"{x:286,y:557,t:1527030563966};\\\", \\\"{x:275,y:557,t:1527030563982};\\\", \\\"{x:260,y:557,t:1527030563999};\\\", \\\"{x:241,y:557,t:1527030564016};\\\", \\\"{x:219,y:557,t:1527030564032};\\\", \\\"{x:208,y:555,t:1527030564052};\\\", \\\"{x:205,y:553,t:1527030564066};\\\", \\\"{x:198,y:547,t:1527030564082};\\\", \\\"{x:188,y:542,t:1527030564099};\\\", \\\"{x:182,y:536,t:1527030564114};\\\", \\\"{x:176,y:529,t:1527030564131};\\\", \\\"{x:172,y:521,t:1527030564149};\\\", \\\"{x:170,y:519,t:1527030564164};\\\", \\\"{x:168,y:516,t:1527030564182};\\\", \\\"{x:168,y:514,t:1527030564198};\\\", \\\"{x:168,y:513,t:1527030564259};\\\", \\\"{x:168,y:512,t:1527030564283};\\\", \\\"{x:168,y:510,t:1527030564307};\\\", \\\"{x:167,y:510,t:1527030564323};\\\", \\\"{x:170,y:510,t:1527030564539};\\\", \\\"{x:173,y:514,t:1527030564549};\\\", \\\"{x:183,y:526,t:1527030564566};\\\", \\\"{x:199,y:543,t:1527030564581};\\\", \\\"{x:212,y:557,t:1527030564599};\\\", \\\"{x:232,y:574,t:1527030564616};\\\", \\\"{x:249,y:591,t:1527030564632};\\\", \\\"{x:268,y:607,t:1527030564650};\\\", \\\"{x:297,y:627,t:1527030564667};\\\", \\\"{x:343,y:667,t:1527030564683};\\\", \\\"{x:383,y:695,t:1527030564699};\\\", \\\"{x:420,y:721,t:1527030564716};\\\", \\\"{x:456,y:748,t:1527030564732};\\\", \\\"{x:492,y:769,t:1527030564750};\\\", \\\"{x:529,y:788,t:1527030564766};\\\", \\\"{x:555,y:798,t:1527030564782};\\\", \\\"{x:572,y:803,t:1527030564798};\\\", \\\"{x:583,y:806,t:1527030564816};\\\", \\\"{x:587,y:807,t:1527030564833};\\\", \\\"{x:588,y:806,t:1527030564859};\\\", \\\"{x:588,y:804,t:1527030564867};\\\", \\\"{x:588,y:799,t:1527030564884};\\\", \\\"{x:584,y:792,t:1527030564899};\\\", \\\"{x:581,y:787,t:1527030564916};\\\", \\\"{x:579,y:782,t:1527030564934};\\\", \\\"{x:578,y:775,t:1527030564949};\\\", \\\"{x:575,y:763,t:1527030564966};\\\", \\\"{x:572,y:751,t:1527030564983};\\\", \\\"{x:564,y:743,t:1527030565001};\\\", \\\"{x:558,y:738,t:1527030565016};\\\", \\\"{x:549,y:733,t:1527030565032};\\\", \\\"{x:541,y:728,t:1527030565049};\\\", \\\"{x:535,y:727,t:1527030565066};\\\", \\\"{x:535,y:726,t:1527030565082};\\\" ] }, { \\\"rt\\\": 35194, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 490783, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -F -F -F -F -Z -O -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:718,t:1527030566931};\\\", \\\"{x:536,y:703,t:1527030566946};\\\", \\\"{x:538,y:690,t:1527030566950};\\\", \\\"{x:539,y:659,t:1527030566966};\\\", \\\"{x:539,y:635,t:1527030566983};\\\", \\\"{x:539,y:616,t:1527030567001};\\\", \\\"{x:537,y:600,t:1527030567017};\\\", \\\"{x:534,y:579,t:1527030567035};\\\", \\\"{x:531,y:546,t:1527030567051};\\\", \\\"{x:528,y:531,t:1527030567068};\\\", \\\"{x:527,y:522,t:1527030567085};\\\", \\\"{x:527,y:515,t:1527030567101};\\\", \\\"{x:527,y:508,t:1527030567118};\\\", \\\"{x:527,y:503,t:1527030567133};\\\", \\\"{x:527,y:501,t:1527030567151};\\\", \\\"{x:527,y:500,t:1527030567168};\\\", \\\"{x:527,y:499,t:1527030567185};\\\", \\\"{x:527,y:497,t:1527030567200};\\\", \\\"{x:527,y:494,t:1527030567218};\\\", \\\"{x:527,y:486,t:1527030567235};\\\", \\\"{x:528,y:482,t:1527030567250};\\\", \\\"{x:532,y:475,t:1527030567268};\\\", \\\"{x:538,y:469,t:1527030567285};\\\", \\\"{x:542,y:464,t:1527030567301};\\\", \\\"{x:552,y:456,t:1527030567317};\\\", \\\"{x:564,y:450,t:1527030567335};\\\", \\\"{x:573,y:446,t:1527030567351};\\\", \\\"{x:579,y:444,t:1527030567368};\\\", \\\"{x:586,y:442,t:1527030567385};\\\", \\\"{x:596,y:440,t:1527030567402};\\\", \\\"{x:606,y:440,t:1527030567418};\\\", \\\"{x:618,y:440,t:1527030567435};\\\", \\\"{x:627,y:440,t:1527030567451};\\\", \\\"{x:639,y:444,t:1527030567468};\\\", \\\"{x:657,y:455,t:1527030567485};\\\", \\\"{x:673,y:465,t:1527030567502};\\\", \\\"{x:689,y:479,t:1527030567519};\\\", \\\"{x:702,y:498,t:1527030567536};\\\", \\\"{x:721,y:525,t:1527030567553};\\\", \\\"{x:729,y:541,t:1527030567569};\\\", \\\"{x:733,y:553,t:1527030567585};\\\", \\\"{x:736,y:562,t:1527030567601};\\\", \\\"{x:736,y:571,t:1527030567618};\\\", \\\"{x:736,y:597,t:1527030567635};\\\", \\\"{x:743,y:628,t:1527030567652};\\\", \\\"{x:754,y:660,t:1527030567669};\\\", \\\"{x:776,y:691,t:1527030567685};\\\", \\\"{x:781,y:711,t:1527030567701};\\\", \\\"{x:781,y:718,t:1527030567718};\\\", \\\"{x:783,y:719,t:1527030568179};\\\", \\\"{x:785,y:719,t:1527030568195};\\\", \\\"{x:789,y:719,t:1527030568203};\\\", \\\"{x:800,y:719,t:1527030568220};\\\", \\\"{x:816,y:715,t:1527030568237};\\\", \\\"{x:831,y:710,t:1527030568253};\\\", \\\"{x:851,y:709,t:1527030568270};\\\", \\\"{x:883,y:707,t:1527030568287};\\\", \\\"{x:925,y:707,t:1527030568304};\\\", \\\"{x:967,y:707,t:1527030568320};\\\", \\\"{x:1020,y:707,t:1527030568338};\\\", \\\"{x:1084,y:707,t:1527030568354};\\\", \\\"{x:1143,y:707,t:1527030568370};\\\", \\\"{x:1232,y:707,t:1527030568387};\\\", \\\"{x:1301,y:707,t:1527030568405};\\\", \\\"{x:1363,y:707,t:1527030568421};\\\", \\\"{x:1408,y:708,t:1527030568438};\\\", \\\"{x:1450,y:713,t:1527030568456};\\\", \\\"{x:1483,y:716,t:1527030568472};\\\", \\\"{x:1515,y:717,t:1527030568487};\\\", \\\"{x:1548,y:719,t:1527030568505};\\\", \\\"{x:1569,y:719,t:1527030568521};\\\", \\\"{x:1588,y:719,t:1527030568538};\\\", \\\"{x:1600,y:719,t:1527030568555};\\\", \\\"{x:1604,y:719,t:1527030568572};\\\", \\\"{x:1605,y:718,t:1527030568589};\\\", \\\"{x:1605,y:717,t:1527030568620};\\\", \\\"{x:1605,y:716,t:1527030568636};\\\", \\\"{x:1605,y:714,t:1527030568644};\\\", \\\"{x:1605,y:713,t:1527030568656};\\\", \\\"{x:1605,y:709,t:1527030568672};\\\", \\\"{x:1603,y:703,t:1527030568689};\\\", \\\"{x:1596,y:689,t:1527030568706};\\\", \\\"{x:1584,y:668,t:1527030568722};\\\", \\\"{x:1568,y:652,t:1527030568739};\\\", \\\"{x:1553,y:635,t:1527030568756};\\\", \\\"{x:1546,y:628,t:1527030568772};\\\", \\\"{x:1544,y:621,t:1527030568789};\\\", \\\"{x:1540,y:609,t:1527030568806};\\\", \\\"{x:1540,y:593,t:1527030568823};\\\", \\\"{x:1540,y:582,t:1527030568839};\\\", \\\"{x:1540,y:567,t:1527030568856};\\\", \\\"{x:1542,y:555,t:1527030568872};\\\", \\\"{x:1548,y:545,t:1527030568890};\\\", \\\"{x:1555,y:536,t:1527030568906};\\\", \\\"{x:1565,y:530,t:1527030568923};\\\", \\\"{x:1573,y:525,t:1527030568939};\\\", \\\"{x:1574,y:525,t:1527030568957};\\\", \\\"{x:1577,y:525,t:1527030568972};\\\", \\\"{x:1579,y:525,t:1527030568990};\\\", \\\"{x:1582,y:526,t:1527030569007};\\\", \\\"{x:1588,y:540,t:1527030569023};\\\", \\\"{x:1595,y:557,t:1527030569039};\\\", \\\"{x:1602,y:581,t:1527030569057};\\\", \\\"{x:1608,y:602,t:1527030569074};\\\", \\\"{x:1616,y:618,t:1527030569090};\\\", \\\"{x:1619,y:627,t:1527030569107};\\\", \\\"{x:1622,y:635,t:1527030569124};\\\", \\\"{x:1622,y:639,t:1527030569140};\\\", \\\"{x:1622,y:647,t:1527030569156};\\\", \\\"{x:1624,y:654,t:1527030569173};\\\", \\\"{x:1626,y:664,t:1527030569191};\\\", \\\"{x:1627,y:672,t:1527030569207};\\\", \\\"{x:1627,y:675,t:1527030569224};\\\", \\\"{x:1629,y:679,t:1527030569241};\\\", \\\"{x:1630,y:682,t:1527030569258};\\\", \\\"{x:1630,y:683,t:1527030569274};\\\", \\\"{x:1630,y:686,t:1527030569291};\\\", \\\"{x:1632,y:691,t:1527030569307};\\\", \\\"{x:1632,y:693,t:1527030569323};\\\", \\\"{x:1632,y:695,t:1527030569341};\\\", \\\"{x:1632,y:697,t:1527030569357};\\\", \\\"{x:1632,y:699,t:1527030569375};\\\", \\\"{x:1632,y:701,t:1527030569391};\\\", \\\"{x:1632,y:702,t:1527030569408};\\\", \\\"{x:1632,y:704,t:1527030569425};\\\", \\\"{x:1632,y:707,t:1527030569440};\\\", \\\"{x:1631,y:709,t:1527030569458};\\\", \\\"{x:1627,y:715,t:1527030569475};\\\", \\\"{x:1624,y:718,t:1527030569492};\\\", \\\"{x:1621,y:720,t:1527030569507};\\\", \\\"{x:1620,y:720,t:1527030569556};\\\", \\\"{x:1618,y:720,t:1527030569604};\\\", \\\"{x:1616,y:720,t:1527030569620};\\\", \\\"{x:1615,y:720,t:1527030569635};\\\", \\\"{x:1613,y:720,t:1527030569644};\\\", \\\"{x:1612,y:720,t:1527030569659};\\\", \\\"{x:1604,y:720,t:1527030569676};\\\", \\\"{x:1590,y:719,t:1527030569692};\\\", \\\"{x:1576,y:718,t:1527030569708};\\\", \\\"{x:1563,y:718,t:1527030569726};\\\", \\\"{x:1550,y:718,t:1527030569742};\\\", \\\"{x:1534,y:718,t:1527030569759};\\\", \\\"{x:1520,y:718,t:1527030569775};\\\", \\\"{x:1511,y:719,t:1527030569792};\\\", \\\"{x:1497,y:724,t:1527030569809};\\\", \\\"{x:1486,y:727,t:1527030569826};\\\", \\\"{x:1476,y:732,t:1527030569843};\\\", \\\"{x:1461,y:739,t:1527030569859};\\\", \\\"{x:1448,y:747,t:1527030569876};\\\", \\\"{x:1444,y:751,t:1527030569893};\\\", \\\"{x:1442,y:753,t:1527030569910};\\\", \\\"{x:1441,y:757,t:1527030569926};\\\", \\\"{x:1439,y:763,t:1527030569943};\\\", \\\"{x:1436,y:769,t:1527030569960};\\\", \\\"{x:1434,y:774,t:1527030569977};\\\", \\\"{x:1433,y:776,t:1527030569993};\\\", \\\"{x:1432,y:780,t:1527030570009};\\\", \\\"{x:1432,y:782,t:1527030570027};\\\", \\\"{x:1432,y:786,t:1527030570043};\\\", \\\"{x:1432,y:789,t:1527030570059};\\\", \\\"{x:1430,y:792,t:1527030570077};\\\", \\\"{x:1424,y:793,t:1527030570094};\\\", \\\"{x:1416,y:793,t:1527030570109};\\\", \\\"{x:1407,y:791,t:1527030570126};\\\", \\\"{x:1393,y:785,t:1527030570144};\\\", \\\"{x:1379,y:775,t:1527030570160};\\\", \\\"{x:1364,y:766,t:1527030570177};\\\", \\\"{x:1352,y:757,t:1527030570194};\\\", \\\"{x:1347,y:751,t:1527030570211};\\\", \\\"{x:1346,y:749,t:1527030570227};\\\", \\\"{x:1346,y:748,t:1527030570243};\\\", \\\"{x:1346,y:746,t:1527030570260};\\\", \\\"{x:1345,y:741,t:1527030570279};\\\", \\\"{x:1344,y:739,t:1527030570294};\\\", \\\"{x:1344,y:737,t:1527030570310};\\\", \\\"{x:1344,y:733,t:1527030570328};\\\", \\\"{x:1344,y:727,t:1527030570344};\\\", \\\"{x:1344,y:724,t:1527030570361};\\\", \\\"{x:1344,y:719,t:1527030570378};\\\", \\\"{x:1344,y:716,t:1527030570395};\\\", \\\"{x:1346,y:713,t:1527030570411};\\\", \\\"{x:1347,y:708,t:1527030570427};\\\", \\\"{x:1347,y:705,t:1527030570444};\\\", \\\"{x:1347,y:703,t:1527030570460};\\\", \\\"{x:1347,y:702,t:1527030570478};\\\", \\\"{x:1347,y:699,t:1527030570494};\\\", \\\"{x:1347,y:696,t:1527030570512};\\\", \\\"{x:1347,y:694,t:1527030570527};\\\", \\\"{x:1347,y:693,t:1527030570544};\\\", \\\"{x:1347,y:692,t:1527030570563};\\\", \\\"{x:1347,y:691,t:1527030570580};\\\", \\\"{x:1347,y:692,t:1527030570893};\\\", \\\"{x:1347,y:693,t:1527030571148};\\\", \\\"{x:1354,y:693,t:1527030571164};\\\", \\\"{x:1365,y:693,t:1527030571180};\\\", \\\"{x:1378,y:693,t:1527030571196};\\\", \\\"{x:1389,y:693,t:1527030571214};\\\", \\\"{x:1400,y:693,t:1527030571231};\\\", \\\"{x:1407,y:693,t:1527030571247};\\\", \\\"{x:1411,y:693,t:1527030571263};\\\", \\\"{x:1412,y:693,t:1527030571324};\\\", \\\"{x:1413,y:693,t:1527030571684};\\\", \\\"{x:1414,y:695,t:1527030571707};\\\", \\\"{x:1414,y:696,t:1527030571740};\\\", \\\"{x:1414,y:697,t:1527030572099};\\\", \\\"{x:1411,y:698,t:1527030572117};\\\", \\\"{x:1406,y:698,t:1527030572133};\\\", \\\"{x:1401,y:698,t:1527030572150};\\\", \\\"{x:1397,y:698,t:1527030572166};\\\", \\\"{x:1392,y:698,t:1527030572183};\\\", \\\"{x:1388,y:698,t:1527030572200};\\\", \\\"{x:1383,y:698,t:1527030572216};\\\", \\\"{x:1376,y:698,t:1527030572234};\\\", \\\"{x:1369,y:698,t:1527030572250};\\\", \\\"{x:1364,y:697,t:1527030572267};\\\", \\\"{x:1358,y:695,t:1527030572284};\\\", \\\"{x:1356,y:694,t:1527030572301};\\\", \\\"{x:1355,y:694,t:1527030572317};\\\", \\\"{x:1354,y:694,t:1527030572388};\\\", \\\"{x:1352,y:694,t:1527030572401};\\\", \\\"{x:1351,y:694,t:1527030572418};\\\", \\\"{x:1350,y:694,t:1527030572548};\\\", \\\"{x:1351,y:694,t:1527030572659};\\\", \\\"{x:1353,y:693,t:1527030572669};\\\", \\\"{x:1360,y:693,t:1527030572685};\\\", \\\"{x:1368,y:693,t:1527030572702};\\\", \\\"{x:1378,y:693,t:1527030572718};\\\", \\\"{x:1389,y:693,t:1527030572736};\\\", \\\"{x:1400,y:693,t:1527030572752};\\\", \\\"{x:1407,y:693,t:1527030572769};\\\", \\\"{x:1410,y:693,t:1527030572786};\\\", \\\"{x:1412,y:693,t:1527030572802};\\\", \\\"{x:1415,y:693,t:1527030572818};\\\", \\\"{x:1415,y:692,t:1527030572835};\\\", \\\"{x:1416,y:692,t:1527030572900};\\\", \\\"{x:1417,y:692,t:1527030572931};\\\", \\\"{x:1418,y:692,t:1527030573053};\\\", \\\"{x:1420,y:692,t:1527030573069};\\\", \\\"{x:1425,y:692,t:1527030573087};\\\", \\\"{x:1436,y:692,t:1527030573103};\\\", \\\"{x:1441,y:692,t:1527030573119};\\\", \\\"{x:1448,y:691,t:1527030573137};\\\", \\\"{x:1453,y:691,t:1527030573153};\\\", \\\"{x:1459,y:691,t:1527030573170};\\\", \\\"{x:1464,y:691,t:1527030573187};\\\", \\\"{x:1466,y:691,t:1527030573204};\\\", \\\"{x:1467,y:691,t:1527030573220};\\\", \\\"{x:1468,y:691,t:1527030573237};\\\", \\\"{x:1470,y:691,t:1527030573254};\\\", \\\"{x:1471,y:691,t:1527030573271};\\\", \\\"{x:1473,y:691,t:1527030573286};\\\", \\\"{x:1475,y:691,t:1527030573428};\\\", \\\"{x:1476,y:692,t:1527030573443};\\\", \\\"{x:1477,y:693,t:1527030573455};\\\", \\\"{x:1479,y:693,t:1527030573471};\\\", \\\"{x:1480,y:694,t:1527030573488};\\\", \\\"{x:1483,y:696,t:1527030573505};\\\", \\\"{x:1491,y:699,t:1527030573521};\\\", \\\"{x:1499,y:700,t:1527030573538};\\\", \\\"{x:1501,y:700,t:1527030573555};\\\", \\\"{x:1504,y:701,t:1527030573572};\\\", \\\"{x:1507,y:701,t:1527030573588};\\\", \\\"{x:1508,y:701,t:1527030573636};\\\", \\\"{x:1508,y:700,t:1527030573652};\\\", \\\"{x:1509,y:700,t:1527030573684};\\\", \\\"{x:1510,y:700,t:1527030573691};\\\", \\\"{x:1511,y:700,t:1527030573748};\\\", \\\"{x:1512,y:699,t:1527030573788};\\\", \\\"{x:1513,y:699,t:1527030573806};\\\", \\\"{x:1514,y:699,t:1527030573836};\\\", \\\"{x:1516,y:699,t:1527030573851};\\\", \\\"{x:1517,y:699,t:1527030573859};\\\", \\\"{x:1519,y:699,t:1527030573876};\\\", \\\"{x:1520,y:698,t:1527030573889};\\\", \\\"{x:1522,y:698,t:1527030573906};\\\", \\\"{x:1527,y:698,t:1527030573923};\\\", \\\"{x:1529,y:698,t:1527030573939};\\\", \\\"{x:1534,y:698,t:1527030573956};\\\", \\\"{x:1537,y:698,t:1527030573973};\\\", \\\"{x:1538,y:697,t:1527030573990};\\\", \\\"{x:1539,y:697,t:1527030574006};\\\", \\\"{x:1540,y:697,t:1527030574023};\\\", \\\"{x:1541,y:697,t:1527030574132};\\\", \\\"{x:1542,y:697,t:1527030574187};\\\", \\\"{x:1544,y:696,t:1527030574226};\\\", \\\"{x:1547,y:695,t:1527030574239};\\\", \\\"{x:1548,y:695,t:1527030574256};\\\", \\\"{x:1550,y:695,t:1527030574274};\\\", \\\"{x:1552,y:695,t:1527030574290};\\\", \\\"{x:1553,y:695,t:1527030574307};\\\", \\\"{x:1555,y:695,t:1527030574323};\\\", \\\"{x:1558,y:695,t:1527030574340};\\\", \\\"{x:1562,y:695,t:1527030574358};\\\", \\\"{x:1571,y:695,t:1527030574373};\\\", \\\"{x:1580,y:695,t:1527030574390};\\\", \\\"{x:1590,y:695,t:1527030574407};\\\", \\\"{x:1597,y:695,t:1527030574423};\\\", \\\"{x:1603,y:695,t:1527030574440};\\\", \\\"{x:1607,y:695,t:1527030574458};\\\", \\\"{x:1609,y:695,t:1527030574475};\\\", \\\"{x:1611,y:695,t:1527030574490};\\\", \\\"{x:1612,y:694,t:1527030574563};\\\", \\\"{x:1613,y:694,t:1527030574575};\\\", \\\"{x:1613,y:697,t:1527030580091};\\\", \\\"{x:1613,y:699,t:1527030580098};\\\", \\\"{x:1613,y:700,t:1527030580110};\\\", \\\"{x:1613,y:702,t:1527030580126};\\\", \\\"{x:1613,y:703,t:1527030580143};\\\", \\\"{x:1612,y:704,t:1527030580159};\\\", \\\"{x:1610,y:706,t:1527030580828};\\\", \\\"{x:1610,y:708,t:1527030580846};\\\", \\\"{x:1607,y:711,t:1527030580864};\\\", \\\"{x:1603,y:718,t:1527030580879};\\\", \\\"{x:1599,y:723,t:1527030580896};\\\", \\\"{x:1593,y:731,t:1527030580912};\\\", \\\"{x:1583,y:737,t:1527030580930};\\\", \\\"{x:1577,y:739,t:1527030580946};\\\", \\\"{x:1572,y:742,t:1527030580962};\\\", \\\"{x:1567,y:747,t:1527030580980};\\\", \\\"{x:1564,y:749,t:1527030580996};\\\", \\\"{x:1564,y:750,t:1527030581013};\\\", \\\"{x:1563,y:750,t:1527030581029};\\\", \\\"{x:1562,y:752,t:1527030581046};\\\", \\\"{x:1560,y:752,t:1527030581064};\\\", \\\"{x:1558,y:752,t:1527030581080};\\\", \\\"{x:1556,y:752,t:1527030581097};\\\", \\\"{x:1553,y:752,t:1527030581114};\\\", \\\"{x:1550,y:753,t:1527030581130};\\\", \\\"{x:1546,y:755,t:1527030581146};\\\", \\\"{x:1539,y:757,t:1527030581163};\\\", \\\"{x:1534,y:757,t:1527030581180};\\\", \\\"{x:1529,y:757,t:1527030581197};\\\", \\\"{x:1522,y:758,t:1527030581213};\\\", \\\"{x:1519,y:758,t:1527030581231};\\\", \\\"{x:1515,y:758,t:1527030581248};\\\", \\\"{x:1513,y:759,t:1527030581263};\\\", \\\"{x:1516,y:759,t:1527030581932};\\\", \\\"{x:1525,y:759,t:1527030581950};\\\", \\\"{x:1534,y:759,t:1527030581966};\\\", \\\"{x:1539,y:759,t:1527030581982};\\\", \\\"{x:1543,y:759,t:1527030581999};\\\", \\\"{x:1544,y:759,t:1527030582020};\\\", \\\"{x:1545,y:759,t:1527030582034};\\\", \\\"{x:1548,y:759,t:1527030582049};\\\", \\\"{x:1553,y:759,t:1527030582067};\\\", \\\"{x:1559,y:759,t:1527030582084};\\\", \\\"{x:1565,y:759,t:1527030582100};\\\", \\\"{x:1569,y:759,t:1527030582116};\\\", \\\"{x:1574,y:759,t:1527030582133};\\\", \\\"{x:1576,y:759,t:1527030582150};\\\", \\\"{x:1580,y:759,t:1527030582166};\\\", \\\"{x:1581,y:759,t:1527030582187};\\\", \\\"{x:1582,y:759,t:1527030582204};\\\", \\\"{x:1583,y:759,t:1527030582219};\\\", \\\"{x:1584,y:759,t:1527030582236};\\\", \\\"{x:1585,y:759,t:1527030582251};\\\", \\\"{x:1586,y:760,t:1527030582268};\\\", \\\"{x:1588,y:760,t:1527030582492};\\\", \\\"{x:1591,y:760,t:1527030582501};\\\", \\\"{x:1596,y:760,t:1527030582518};\\\", \\\"{x:1601,y:760,t:1527030582534};\\\", \\\"{x:1604,y:760,t:1527030582551};\\\", \\\"{x:1611,y:760,t:1527030582568};\\\", \\\"{x:1614,y:760,t:1527030582585};\\\", \\\"{x:1618,y:760,t:1527030582601};\\\", \\\"{x:1622,y:760,t:1527030582618};\\\", \\\"{x:1628,y:760,t:1527030582636};\\\", \\\"{x:1629,y:760,t:1527030582652};\\\", \\\"{x:1631,y:760,t:1527030582668};\\\", \\\"{x:1632,y:760,t:1527030582828};\\\", \\\"{x:1634,y:760,t:1527030582860};\\\", \\\"{x:1634,y:759,t:1527030582876};\\\", \\\"{x:1635,y:759,t:1527030582899};\\\", \\\"{x:1630,y:759,t:1527030583084};\\\", \\\"{x:1623,y:759,t:1527030583091};\\\", \\\"{x:1615,y:758,t:1527030583103};\\\", \\\"{x:1593,y:754,t:1527030583119};\\\", \\\"{x:1569,y:747,t:1527030583137};\\\", \\\"{x:1553,y:742,t:1527030583154};\\\", \\\"{x:1541,y:736,t:1527030583170};\\\", \\\"{x:1531,y:728,t:1527030583186};\\\", \\\"{x:1520,y:723,t:1527030583203};\\\", \\\"{x:1506,y:720,t:1527030583220};\\\", \\\"{x:1485,y:718,t:1527030583237};\\\", \\\"{x:1467,y:714,t:1527030583253};\\\", \\\"{x:1445,y:711,t:1527030583270};\\\", \\\"{x:1427,y:709,t:1527030583287};\\\", \\\"{x:1418,y:707,t:1527030583303};\\\", \\\"{x:1412,y:706,t:1527030583321};\\\", \\\"{x:1410,y:706,t:1527030583337};\\\", \\\"{x:1409,y:706,t:1527030583379};\\\", \\\"{x:1409,y:705,t:1527030583412};\\\", \\\"{x:1409,y:704,t:1527030583468};\\\", \\\"{x:1409,y:703,t:1527030583475};\\\", \\\"{x:1409,y:702,t:1527030583491};\\\", \\\"{x:1409,y:701,t:1527030583515};\\\", \\\"{x:1409,y:700,t:1527030583531};\\\", \\\"{x:1409,y:699,t:1527030583554};\\\", \\\"{x:1410,y:698,t:1527030583578};\\\", \\\"{x:1411,y:698,t:1527030583603};\\\", \\\"{x:1412,y:695,t:1527030583610};\\\", \\\"{x:1413,y:695,t:1527030583627};\\\", \\\"{x:1415,y:695,t:1527030583638};\\\", \\\"{x:1417,y:695,t:1527030583655};\\\", \\\"{x:1419,y:695,t:1527030583671};\\\", \\\"{x:1422,y:694,t:1527030583688};\\\", \\\"{x:1425,y:694,t:1527030583705};\\\", \\\"{x:1432,y:694,t:1527030583721};\\\", \\\"{x:1438,y:694,t:1527030583738};\\\", \\\"{x:1449,y:694,t:1527030583755};\\\", \\\"{x:1460,y:694,t:1527030583772};\\\", \\\"{x:1467,y:694,t:1527030583788};\\\", \\\"{x:1474,y:694,t:1527030583805};\\\", \\\"{x:1478,y:693,t:1527030583823};\\\", \\\"{x:1482,y:693,t:1527030583838};\\\", \\\"{x:1482,y:692,t:1527030583964};\\\", \\\"{x:1484,y:692,t:1527030583972};\\\", \\\"{x:1484,y:691,t:1527030583990};\\\", \\\"{x:1485,y:691,t:1527030584020};\\\", \\\"{x:1487,y:691,t:1527030584051};\\\", \\\"{x:1488,y:691,t:1527030584067};\\\", \\\"{x:1490,y:691,t:1527030584083};\\\", \\\"{x:1492,y:691,t:1527030584091};\\\", \\\"{x:1494,y:691,t:1527030584106};\\\", \\\"{x:1503,y:691,t:1527030584123};\\\", \\\"{x:1515,y:692,t:1527030584140};\\\", \\\"{x:1526,y:694,t:1527030584156};\\\", \\\"{x:1536,y:695,t:1527030584173};\\\", \\\"{x:1543,y:697,t:1527030584190};\\\", \\\"{x:1546,y:698,t:1527030584206};\\\", \\\"{x:1547,y:698,t:1527030584244};\\\", \\\"{x:1549,y:698,t:1527030584468};\\\", \\\"{x:1550,y:698,t:1527030584476};\\\", \\\"{x:1554,y:698,t:1527030584492};\\\", \\\"{x:1560,y:698,t:1527030584507};\\\", \\\"{x:1567,y:699,t:1527030584524};\\\", \\\"{x:1574,y:699,t:1527030584542};\\\", \\\"{x:1578,y:700,t:1527030584557};\\\", \\\"{x:1583,y:701,t:1527030584574};\\\", \\\"{x:1584,y:701,t:1527030584596};\\\", \\\"{x:1586,y:701,t:1527030584628};\\\", \\\"{x:1588,y:701,t:1527030584642};\\\", \\\"{x:1590,y:701,t:1527030584658};\\\", \\\"{x:1593,y:701,t:1527030584676};\\\", \\\"{x:1594,y:701,t:1527030584691};\\\", \\\"{x:1596,y:701,t:1527030584709};\\\", \\\"{x:1597,y:701,t:1527030584725};\\\", \\\"{x:1599,y:701,t:1527030584915};\\\", \\\"{x:1601,y:701,t:1527030584932};\\\", \\\"{x:1603,y:701,t:1527030584943};\\\", \\\"{x:1605,y:701,t:1527030584960};\\\", \\\"{x:1608,y:700,t:1527030584976};\\\", \\\"{x:1609,y:700,t:1527030584992};\\\", \\\"{x:1609,y:699,t:1527030585180};\\\", \\\"{x:1610,y:698,t:1527030585211};\\\", \\\"{x:1611,y:697,t:1527030585226};\\\", \\\"{x:1611,y:695,t:1527030585243};\\\", \\\"{x:1612,y:695,t:1527030585260};\\\", \\\"{x:1612,y:696,t:1527030590012};\\\", \\\"{x:1612,y:697,t:1527030590027};\\\", \\\"{x:1612,y:698,t:1527030590051};\\\", \\\"{x:1612,y:699,t:1527030590059};\\\", \\\"{x:1613,y:699,t:1527030590075};\\\", \\\"{x:1613,y:700,t:1527030590092};\\\", \\\"{x:1613,y:701,t:1527030590123};\\\", \\\"{x:1613,y:703,t:1527030590180};\\\", \\\"{x:1613,y:704,t:1527030590227};\\\", \\\"{x:1613,y:705,t:1527030591100};\\\", \\\"{x:1612,y:705,t:1527030591164};\\\", \\\"{x:1611,y:705,t:1527030591179};\\\", \\\"{x:1610,y:705,t:1527030591224};\\\", \\\"{x:1609,y:704,t:1527030591234};\\\", \\\"{x:1608,y:704,t:1527030591264};\\\", \\\"{x:1607,y:703,t:1527030591288};\\\", \\\"{x:1606,y:703,t:1527030591311};\\\", \\\"{x:1606,y:701,t:1527030591335};\\\", \\\"{x:1606,y:700,t:1527030591360};\\\", \\\"{x:1606,y:699,t:1527030591376};\\\", \\\"{x:1605,y:697,t:1527030591399};\\\", \\\"{x:1605,y:696,t:1527030591480};\\\", \\\"{x:1607,y:696,t:1527030591680};\\\", \\\"{x:1608,y:696,t:1527030591695};\\\", \\\"{x:1609,y:697,t:1527030591736};\\\", \\\"{x:1610,y:698,t:1527030591768};\\\", \\\"{x:1610,y:700,t:1527030591786};\\\", \\\"{x:1611,y:705,t:1527030591804};\\\", \\\"{x:1611,y:709,t:1527030591820};\\\", \\\"{x:1611,y:715,t:1527030591835};\\\", \\\"{x:1611,y:718,t:1527030591852};\\\", \\\"{x:1611,y:720,t:1527030591870};\\\", \\\"{x:1611,y:722,t:1527030591886};\\\", \\\"{x:1611,y:726,t:1527030591903};\\\", \\\"{x:1611,y:729,t:1527030591920};\\\", \\\"{x:1611,y:733,t:1527030591937};\\\", \\\"{x:1611,y:737,t:1527030591953};\\\", \\\"{x:1611,y:740,t:1527030591970};\\\", \\\"{x:1611,y:744,t:1527030591987};\\\", \\\"{x:1611,y:747,t:1527030592003};\\\", \\\"{x:1611,y:749,t:1527030592020};\\\", \\\"{x:1611,y:750,t:1527030592037};\\\", \\\"{x:1611,y:754,t:1527030592053};\\\", \\\"{x:1612,y:756,t:1527030592069};\\\", \\\"{x:1613,y:761,t:1527030592086};\\\", \\\"{x:1614,y:764,t:1527030592102};\\\", \\\"{x:1615,y:767,t:1527030592119};\\\", \\\"{x:1615,y:770,t:1527030592136};\\\", \\\"{x:1615,y:773,t:1527030592153};\\\", \\\"{x:1617,y:777,t:1527030592170};\\\", \\\"{x:1617,y:779,t:1527030592186};\\\", \\\"{x:1617,y:780,t:1527030592203};\\\", \\\"{x:1617,y:781,t:1527030592220};\\\", \\\"{x:1618,y:783,t:1527030592238};\\\", \\\"{x:1618,y:786,t:1527030592254};\\\", \\\"{x:1618,y:789,t:1527030592271};\\\", \\\"{x:1618,y:791,t:1527030592288};\\\", \\\"{x:1618,y:794,t:1527030592304};\\\", \\\"{x:1618,y:798,t:1527030592320};\\\", \\\"{x:1618,y:801,t:1527030592338};\\\", \\\"{x:1618,y:807,t:1527030592355};\\\", \\\"{x:1618,y:813,t:1527030592371};\\\", \\\"{x:1618,y:818,t:1527030592387};\\\", \\\"{x:1618,y:821,t:1527030592404};\\\", \\\"{x:1618,y:822,t:1527030592421};\\\", \\\"{x:1618,y:824,t:1527030592438};\\\", \\\"{x:1618,y:825,t:1527030592454};\\\", \\\"{x:1618,y:826,t:1527030594031};\\\", \\\"{x:1618,y:827,t:1527030594056};\\\", \\\"{x:1618,y:828,t:1527030596096};\\\", \\\"{x:1617,y:828,t:1527030596215};\\\", \\\"{x:1617,y:827,t:1527030596287};\\\", \\\"{x:1617,y:826,t:1527030596310};\\\", \\\"{x:1617,y:825,t:1527030596335};\\\", \\\"{x:1616,y:825,t:1527030596358};\\\", \\\"{x:1614,y:824,t:1527030597376};\\\", \\\"{x:1612,y:824,t:1527030597388};\\\", \\\"{x:1610,y:824,t:1527030597404};\\\", \\\"{x:1609,y:824,t:1527030597421};\\\", \\\"{x:1609,y:825,t:1527030597904};\\\", \\\"{x:1609,y:826,t:1527030597944};\\\", \\\"{x:1610,y:827,t:1527030598103};\\\", \\\"{x:1606,y:827,t:1527030599024};\\\", \\\"{x:1593,y:827,t:1527030599031};\\\", \\\"{x:1578,y:827,t:1527030599043};\\\", \\\"{x:1530,y:827,t:1527030599060};\\\", \\\"{x:1469,y:827,t:1527030599077};\\\", \\\"{x:1394,y:819,t:1527030599093};\\\", \\\"{x:1316,y:808,t:1527030599110};\\\", \\\"{x:1192,y:789,t:1527030599127};\\\", \\\"{x:1108,y:774,t:1527030599143};\\\", \\\"{x:1022,y:761,t:1527030599160};\\\", \\\"{x:907,y:737,t:1527030599177};\\\", \\\"{x:793,y:722,t:1527030599194};\\\", \\\"{x:699,y:711,t:1527030599210};\\\", \\\"{x:614,y:702,t:1527030599227};\\\", \\\"{x:532,y:698,t:1527030599244};\\\", \\\"{x:487,y:698,t:1527030599260};\\\", \\\"{x:448,y:698,t:1527030599277};\\\", \\\"{x:421,y:698,t:1527030599294};\\\", \\\"{x:399,y:692,t:1527030599309};\\\", \\\"{x:398,y:692,t:1527030599327};\\\", \\\"{x:397,y:692,t:1527030599544};\\\", \\\"{x:397,y:691,t:1527030599624};\\\", \\\"{x:397,y:690,t:1527030599639};\\\", \\\"{x:397,y:689,t:1527030599647};\\\", \\\"{x:397,y:687,t:1527030599663};\\\", \\\"{x:397,y:683,t:1527030599679};\\\", \\\"{x:397,y:680,t:1527030599695};\\\", \\\"{x:396,y:675,t:1527030599712};\\\", \\\"{x:390,y:670,t:1527030599729};\\\", \\\"{x:384,y:666,t:1527030599746};\\\", \\\"{x:378,y:662,t:1527030599761};\\\", \\\"{x:371,y:657,t:1527030599779};\\\", \\\"{x:351,y:644,t:1527030599814};\\\", \\\"{x:348,y:642,t:1527030599831};\\\", \\\"{x:347,y:641,t:1527030599855};\\\", \\\"{x:346,y:639,t:1527030599871};\\\", \\\"{x:344,y:638,t:1527030599882};\\\", \\\"{x:343,y:634,t:1527030599898};\\\", \\\"{x:342,y:631,t:1527030599915};\\\", \\\"{x:342,y:624,t:1527030599932};\\\", \\\"{x:340,y:615,t:1527030599947};\\\", \\\"{x:337,y:603,t:1527030599965};\\\", \\\"{x:329,y:592,t:1527030599983};\\\", \\\"{x:319,y:583,t:1527030599998};\\\", \\\"{x:306,y:575,t:1527030600014};\\\", \\\"{x:296,y:571,t:1527030600031};\\\", \\\"{x:288,y:570,t:1527030600048};\\\", \\\"{x:286,y:569,t:1527030600064};\\\", \\\"{x:285,y:569,t:1527030600081};\\\", \\\"{x:287,y:569,t:1527030600111};\\\", \\\"{x:292,y:569,t:1527030600119};\\\", \\\"{x:297,y:569,t:1527030600132};\\\", \\\"{x:320,y:569,t:1527030600148};\\\", \\\"{x:365,y:569,t:1527030600165};\\\", \\\"{x:451,y:569,t:1527030600181};\\\", \\\"{x:556,y:569,t:1527030600200};\\\", \\\"{x:705,y:578,t:1527030600215};\\\", \\\"{x:801,y:586,t:1527030600232};\\\", \\\"{x:881,y:593,t:1527030600248};\\\", \\\"{x:922,y:597,t:1527030600265};\\\", \\\"{x:946,y:602,t:1527030600281};\\\", \\\"{x:956,y:605,t:1527030600298};\\\", \\\"{x:957,y:605,t:1527030600314};\\\", \\\"{x:955,y:604,t:1527030600399};\\\", \\\"{x:950,y:604,t:1527030600415};\\\", \\\"{x:935,y:604,t:1527030600432};\\\", \\\"{x:917,y:604,t:1527030600447};\\\", \\\"{x:894,y:603,t:1527030600465};\\\", \\\"{x:869,y:600,t:1527030600482};\\\", \\\"{x:848,y:594,t:1527030600498};\\\", \\\"{x:841,y:593,t:1527030600516};\\\", \\\"{x:834,y:589,t:1527030600532};\\\", \\\"{x:825,y:586,t:1527030600549};\\\", \\\"{x:815,y:583,t:1527030600566};\\\", \\\"{x:797,y:580,t:1527030600581};\\\", \\\"{x:756,y:580,t:1527030600598};\\\", \\\"{x:725,y:576,t:1527030600615};\\\", \\\"{x:700,y:576,t:1527030600631};\\\", \\\"{x:676,y:573,t:1527030600648};\\\", \\\"{x:662,y:572,t:1527030600665};\\\", \\\"{x:656,y:571,t:1527030600681};\\\", \\\"{x:654,y:571,t:1527030600698};\\\", \\\"{x:650,y:571,t:1527030600766};\\\", \\\"{x:646,y:571,t:1527030600782};\\\", \\\"{x:637,y:571,t:1527030600799};\\\", \\\"{x:634,y:571,t:1527030600816};\\\", \\\"{x:632,y:571,t:1527030600831};\\\", \\\"{x:630,y:572,t:1527030600849};\\\", \\\"{x:624,y:573,t:1527030600867};\\\", \\\"{x:619,y:575,t:1527030600882};\\\", \\\"{x:613,y:577,t:1527030600899};\\\", \\\"{x:611,y:579,t:1527030600916};\\\", \\\"{x:609,y:579,t:1527030600932};\\\", \\\"{x:608,y:581,t:1527030601158};\\\", \\\"{x:608,y:585,t:1527030601166};\\\", \\\"{x:605,y:592,t:1527030601182};\\\", \\\"{x:593,y:618,t:1527030601199};\\\", \\\"{x:588,y:634,t:1527030601216};\\\", \\\"{x:583,y:650,t:1527030601232};\\\", \\\"{x:575,y:666,t:1527030601248};\\\", \\\"{x:570,y:679,t:1527030601266};\\\", \\\"{x:569,y:688,t:1527030601282};\\\", \\\"{x:569,y:695,t:1527030601298};\\\", \\\"{x:567,y:704,t:1527030601316};\\\", \\\"{x:565,y:711,t:1527030601332};\\\", \\\"{x:561,y:720,t:1527030601348};\\\", \\\"{x:557,y:724,t:1527030601366};\\\", \\\"{x:552,y:727,t:1527030601382};\\\", \\\"{x:550,y:727,t:1527030601399};\\\", \\\"{x:549,y:727,t:1527030601415};\\\", \\\"{x:548,y:727,t:1527030601447};\\\", \\\"{x:547,y:727,t:1527030601455};\\\", \\\"{x:546,y:727,t:1527030601467};\\\", \\\"{x:545,y:727,t:1527030601482};\\\", \\\"{x:544,y:727,t:1527030601500};\\\", \\\"{x:545,y:727,t:1527030602183};\\\", \\\"{x:550,y:727,t:1527030602199};\\\", \\\"{x:560,y:726,t:1527030602217};\\\", \\\"{x:572,y:724,t:1527030602234};\\\", \\\"{x:587,y:722,t:1527030602250};\\\", \\\"{x:602,y:721,t:1527030602267};\\\", \\\"{x:617,y:721,t:1527030602284};\\\", \\\"{x:628,y:721,t:1527030602299};\\\", \\\"{x:637,y:721,t:1527030602317};\\\", \\\"{x:644,y:721,t:1527030602334};\\\", \\\"{x:654,y:725,t:1527030602349};\\\", \\\"{x:678,y:734,t:1527030602367};\\\", \\\"{x:686,y:734,t:1527030602383};\\\", \\\"{x:687,y:734,t:1527030602400};\\\" ] }, { \\\"rt\\\": 10420, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 502412, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-B -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:689,y:734,t:1527030602852};\\\", \\\"{x:690,y:734,t:1527030602966};\\\", \\\"{x:690,y:733,t:1527030602982};\\\", \\\"{x:690,y:732,t:1527030602999};\\\", \\\"{x:687,y:729,t:1527030603239};\\\", \\\"{x:590,y:699,t:1527030603322};\\\", \\\"{x:579,y:690,t:1527030603336};\\\", \\\"{x:570,y:676,t:1527030603350};\\\", \\\"{x:561,y:657,t:1527030603367};\\\", \\\"{x:550,y:630,t:1527030603384};\\\", \\\"{x:544,y:606,t:1527030603400};\\\", \\\"{x:537,y:580,t:1527030603418};\\\", \\\"{x:530,y:556,t:1527030603434};\\\", \\\"{x:521,y:531,t:1527030603451};\\\", \\\"{x:515,y:515,t:1527030603468};\\\", \\\"{x:514,y:508,t:1527030603483};\\\", \\\"{x:514,y:505,t:1527030603500};\\\", \\\"{x:514,y:504,t:1527030603517};\\\", \\\"{x:514,y:502,t:1527030603533};\\\", \\\"{x:517,y:500,t:1527030603550};\\\", \\\"{x:526,y:498,t:1527030603567};\\\", \\\"{x:543,y:498,t:1527030603584};\\\", \\\"{x:566,y:498,t:1527030603600};\\\", \\\"{x:605,y:504,t:1527030603617};\\\", \\\"{x:641,y:517,t:1527030603634};\\\", \\\"{x:711,y:549,t:1527030603650};\\\", \\\"{x:790,y:579,t:1527030603668};\\\", \\\"{x:875,y:616,t:1527030603684};\\\", \\\"{x:965,y:663,t:1527030603701};\\\", \\\"{x:1048,y:702,t:1527030603718};\\\", \\\"{x:1137,y:744,t:1527030603733};\\\", \\\"{x:1244,y:791,t:1527030603750};\\\", \\\"{x:1297,y:816,t:1527030603767};\\\", \\\"{x:1347,y:839,t:1527030603784};\\\", \\\"{x:1382,y:858,t:1527030603801};\\\", \\\"{x:1410,y:871,t:1527030603817};\\\", \\\"{x:1435,y:882,t:1527030603834};\\\", \\\"{x:1461,y:889,t:1527030603851};\\\", \\\"{x:1484,y:895,t:1527030603868};\\\", \\\"{x:1510,y:899,t:1527030603884};\\\", \\\"{x:1533,y:901,t:1527030603901};\\\", \\\"{x:1556,y:904,t:1527030603918};\\\", \\\"{x:1573,y:904,t:1527030603934};\\\", \\\"{x:1578,y:904,t:1527030603951};\\\", \\\"{x:1577,y:903,t:1527030603991};\\\", \\\"{x:1573,y:900,t:1527030604001};\\\", \\\"{x:1565,y:898,t:1527030604018};\\\", \\\"{x:1564,y:897,t:1527030604033};\\\", \\\"{x:1564,y:899,t:1527030604328};\\\", \\\"{x:1563,y:899,t:1527030604335};\\\", \\\"{x:1557,y:899,t:1527030604351};\\\", \\\"{x:1553,y:900,t:1527030604369};\\\", \\\"{x:1547,y:904,t:1527030604384};\\\", \\\"{x:1544,y:905,t:1527030604401};\\\", \\\"{x:1538,y:909,t:1527030604419};\\\", \\\"{x:1532,y:912,t:1527030604434};\\\", \\\"{x:1522,y:915,t:1527030604451};\\\", \\\"{x:1513,y:917,t:1527030604468};\\\", \\\"{x:1503,y:918,t:1527030604484};\\\", \\\"{x:1492,y:922,t:1527030604502};\\\", \\\"{x:1479,y:923,t:1527030604518};\\\", \\\"{x:1462,y:926,t:1527030604535};\\\", \\\"{x:1445,y:930,t:1527030604552};\\\", \\\"{x:1433,y:933,t:1527030604568};\\\", \\\"{x:1426,y:939,t:1527030604584};\\\", \\\"{x:1423,y:941,t:1527030604602};\\\", \\\"{x:1418,y:944,t:1527030604619};\\\", \\\"{x:1410,y:947,t:1527030604634};\\\", \\\"{x:1402,y:950,t:1527030604651};\\\", \\\"{x:1390,y:950,t:1527030604668};\\\", \\\"{x:1382,y:950,t:1527030604684};\\\", \\\"{x:1374,y:951,t:1527030604701};\\\", \\\"{x:1368,y:951,t:1527030604718};\\\", \\\"{x:1362,y:951,t:1527030604734};\\\", \\\"{x:1359,y:951,t:1527030604751};\\\", \\\"{x:1357,y:953,t:1527030604904};\\\", \\\"{x:1356,y:953,t:1527030604918};\\\", \\\"{x:1354,y:955,t:1527030604935};\\\", \\\"{x:1351,y:957,t:1527030604951};\\\", \\\"{x:1347,y:961,t:1527030604969};\\\", \\\"{x:1345,y:963,t:1527030604985};\\\", \\\"{x:1344,y:965,t:1527030605001};\\\", \\\"{x:1344,y:966,t:1527030605019};\\\", \\\"{x:1344,y:967,t:1527030605039};\\\", \\\"{x:1344,y:968,t:1527030605079};\\\", \\\"{x:1343,y:968,t:1527030605088};\\\", \\\"{x:1343,y:969,t:1527030605136};\\\", \\\"{x:1342,y:969,t:1527030605183};\\\", \\\"{x:1342,y:968,t:1527030605192};\\\", \\\"{x:1341,y:966,t:1527030605201};\\\", \\\"{x:1340,y:961,t:1527030605218};\\\", \\\"{x:1340,y:954,t:1527030605234};\\\", \\\"{x:1338,y:948,t:1527030605251};\\\", \\\"{x:1337,y:943,t:1527030605267};\\\", \\\"{x:1337,y:941,t:1527030605284};\\\", \\\"{x:1337,y:939,t:1527030605302};\\\", \\\"{x:1336,y:935,t:1527030605318};\\\", \\\"{x:1336,y:930,t:1527030605334};\\\", \\\"{x:1336,y:913,t:1527030605351};\\\", \\\"{x:1334,y:899,t:1527030605368};\\\", \\\"{x:1333,y:885,t:1527030605385};\\\", \\\"{x:1333,y:873,t:1527030605401};\\\", \\\"{x:1333,y:854,t:1527030605418};\\\", \\\"{x:1333,y:840,t:1527030605435};\\\", \\\"{x:1333,y:829,t:1527030605451};\\\", \\\"{x:1333,y:818,t:1527030605467};\\\", \\\"{x:1333,y:809,t:1527030605484};\\\", \\\"{x:1333,y:804,t:1527030605501};\\\", \\\"{x:1333,y:797,t:1527030605518};\\\", \\\"{x:1333,y:792,t:1527030605533};\\\", \\\"{x:1333,y:782,t:1527030605550};\\\", \\\"{x:1334,y:773,t:1527030605567};\\\", \\\"{x:1335,y:768,t:1527030605584};\\\", \\\"{x:1337,y:763,t:1527030605601};\\\", \\\"{x:1337,y:758,t:1527030605617};\\\", \\\"{x:1338,y:757,t:1527030605634};\\\", \\\"{x:1338,y:756,t:1527030605840};\\\", \\\"{x:1339,y:756,t:1527030605851};\\\", \\\"{x:1340,y:756,t:1527030605868};\\\", \\\"{x:1341,y:756,t:1527030605895};\\\", \\\"{x:1342,y:757,t:1527030605912};\\\", \\\"{x:1343,y:757,t:1527030605926};\\\", \\\"{x:1344,y:757,t:1527030605959};\\\", \\\"{x:1345,y:758,t:1527030606090};\\\", \\\"{x:1346,y:758,t:1527030606599};\\\", \\\"{x:1346,y:757,t:1527030606608};\\\", \\\"{x:1347,y:757,t:1527030606623};\\\", \\\"{x:1347,y:756,t:1527030606635};\\\", \\\"{x:1348,y:754,t:1527030606651};\\\", \\\"{x:1350,y:753,t:1527030606667};\\\", \\\"{x:1350,y:751,t:1527030606687};\\\", \\\"{x:1350,y:749,t:1527030606703};\\\", \\\"{x:1350,y:747,t:1527030606717};\\\", \\\"{x:1350,y:741,t:1527030606735};\\\", \\\"{x:1350,y:733,t:1527030606751};\\\", \\\"{x:1350,y:728,t:1527030606767};\\\", \\\"{x:1350,y:726,t:1527030606784};\\\", \\\"{x:1350,y:723,t:1527030606801};\\\", \\\"{x:1350,y:721,t:1527030606817};\\\", \\\"{x:1350,y:718,t:1527030606835};\\\", \\\"{x:1350,y:715,t:1527030606852};\\\", \\\"{x:1350,y:712,t:1527030606867};\\\", \\\"{x:1350,y:711,t:1527030606884};\\\", \\\"{x:1350,y:709,t:1527030606903};\\\", \\\"{x:1350,y:708,t:1527030606919};\\\", \\\"{x:1350,y:707,t:1527030606935};\\\", \\\"{x:1350,y:706,t:1527030606952};\\\", \\\"{x:1350,y:705,t:1527030606991};\\\", \\\"{x:1350,y:704,t:1527030607007};\\\", \\\"{x:1350,y:703,t:1527030607023};\\\", \\\"{x:1350,y:706,t:1527030607143};\\\", \\\"{x:1350,y:710,t:1527030607151};\\\", \\\"{x:1352,y:720,t:1527030607167};\\\", \\\"{x:1354,y:731,t:1527030607185};\\\", \\\"{x:1354,y:739,t:1527030607202};\\\", \\\"{x:1355,y:745,t:1527030607218};\\\", \\\"{x:1356,y:751,t:1527030607235};\\\", \\\"{x:1356,y:757,t:1527030607252};\\\", \\\"{x:1356,y:760,t:1527030607267};\\\", \\\"{x:1356,y:763,t:1527030607284};\\\", \\\"{x:1358,y:766,t:1527030607301};\\\", \\\"{x:1358,y:767,t:1527030607327};\\\", \\\"{x:1358,y:768,t:1527030607352};\\\", \\\"{x:1356,y:768,t:1527030607664};\\\", \\\"{x:1350,y:767,t:1527030607673};\\\", \\\"{x:1340,y:764,t:1527030607684};\\\", \\\"{x:1316,y:759,t:1527030607701};\\\", \\\"{x:1271,y:751,t:1527030607716};\\\", \\\"{x:1210,y:742,t:1527030607734};\\\", \\\"{x:1162,y:735,t:1527030607750};\\\", \\\"{x:1088,y:724,t:1527030607767};\\\", \\\"{x:1028,y:714,t:1527030607783};\\\", \\\"{x:977,y:705,t:1527030607800};\\\", \\\"{x:930,y:699,t:1527030607816};\\\", \\\"{x:874,y:691,t:1527030607834};\\\", \\\"{x:799,y:680,t:1527030607850};\\\", \\\"{x:740,y:672,t:1527030607867};\\\", \\\"{x:709,y:668,t:1527030607884};\\\", \\\"{x:684,y:665,t:1527030607900};\\\", \\\"{x:675,y:662,t:1527030607917};\\\", \\\"{x:675,y:661,t:1527030607935};\\\", \\\"{x:674,y:661,t:1527030608159};\\\", \\\"{x:668,y:658,t:1527030608167};\\\", \\\"{x:661,y:655,t:1527030608184};\\\", \\\"{x:653,y:653,t:1527030608200};\\\", \\\"{x:646,y:649,t:1527030608218};\\\", \\\"{x:638,y:643,t:1527030608234};\\\", \\\"{x:627,y:635,t:1527030608250};\\\", \\\"{x:617,y:628,t:1527030608268};\\\", \\\"{x:598,y:615,t:1527030608283};\\\", \\\"{x:572,y:601,t:1527030608300};\\\", \\\"{x:535,y:582,t:1527030608314};\\\", \\\"{x:502,y:569,t:1527030608331};\\\", \\\"{x:483,y:562,t:1527030608348};\\\", \\\"{x:470,y:556,t:1527030608364};\\\", \\\"{x:459,y:554,t:1527030608388};\\\", \\\"{x:449,y:553,t:1527030608404};\\\", \\\"{x:438,y:550,t:1527030608421};\\\", \\\"{x:430,y:548,t:1527030608437};\\\", \\\"{x:423,y:547,t:1527030608454};\\\", \\\"{x:416,y:544,t:1527030608472};\\\", \\\"{x:410,y:543,t:1527030608488};\\\", \\\"{x:402,y:543,t:1527030608505};\\\", \\\"{x:392,y:541,t:1527030608520};\\\", \\\"{x:387,y:540,t:1527030608538};\\\", \\\"{x:383,y:539,t:1527030608554};\\\", \\\"{x:379,y:536,t:1527030608571};\\\", \\\"{x:374,y:533,t:1527030608588};\\\", \\\"{x:366,y:531,t:1527030608606};\\\", \\\"{x:359,y:528,t:1527030608621};\\\", \\\"{x:343,y:527,t:1527030608638};\\\", \\\"{x:333,y:527,t:1527030608654};\\\", \\\"{x:328,y:527,t:1527030608671};\\\", \\\"{x:327,y:527,t:1527030608687};\\\", \\\"{x:323,y:528,t:1527030608705};\\\", \\\"{x:320,y:530,t:1527030608721};\\\", \\\"{x:317,y:532,t:1527030608738};\\\", \\\"{x:312,y:533,t:1527030608754};\\\", \\\"{x:309,y:533,t:1527030608772};\\\", \\\"{x:301,y:532,t:1527030608788};\\\", \\\"{x:299,y:531,t:1527030608805};\\\", \\\"{x:298,y:531,t:1527030608822};\\\", \\\"{x:296,y:530,t:1527030608837};\\\", \\\"{x:294,y:527,t:1527030608855};\\\", \\\"{x:290,y:522,t:1527030608873};\\\", \\\"{x:288,y:519,t:1527030609031};\\\", \\\"{x:282,y:518,t:1527030609039};\\\", \\\"{x:259,y:515,t:1527030609055};\\\", \\\"{x:238,y:512,t:1527030609072};\\\", \\\"{x:226,y:510,t:1527030609087};\\\", \\\"{x:219,y:510,t:1527030609105};\\\", \\\"{x:214,y:510,t:1527030609122};\\\", \\\"{x:210,y:510,t:1527030609139};\\\", \\\"{x:206,y:513,t:1527030609156};\\\", \\\"{x:202,y:515,t:1527030609173};\\\", \\\"{x:192,y:518,t:1527030609190};\\\", \\\"{x:182,y:519,t:1527030609205};\\\", \\\"{x:173,y:520,t:1527030609223};\\\", \\\"{x:169,y:523,t:1527030609239};\\\", \\\"{x:167,y:524,t:1527030609256};\\\", \\\"{x:166,y:526,t:1527030609281};\\\", \\\"{x:166,y:527,t:1527030609289};\\\", \\\"{x:166,y:530,t:1527030609305};\\\", \\\"{x:165,y:534,t:1527030609322};\\\", \\\"{x:163,y:538,t:1527030609339};\\\", \\\"{x:163,y:540,t:1527030609355};\\\", \\\"{x:162,y:540,t:1527030609372};\\\", \\\"{x:161,y:542,t:1527030609388};\\\", \\\"{x:160,y:542,t:1527030609406};\\\", \\\"{x:159,y:542,t:1527030609438};\\\", \\\"{x:162,y:542,t:1527030609669};\\\", \\\"{x:171,y:542,t:1527030609678};\\\", \\\"{x:186,y:542,t:1527030609688};\\\", \\\"{x:231,y:542,t:1527030609706};\\\", \\\"{x:298,y:542,t:1527030609722};\\\", \\\"{x:370,y:542,t:1527030609739};\\\", \\\"{x:457,y:544,t:1527030609756};\\\", \\\"{x:552,y:560,t:1527030609772};\\\", \\\"{x:627,y:569,t:1527030609789};\\\", \\\"{x:682,y:577,t:1527030609806};\\\", \\\"{x:717,y:581,t:1527030609822};\\\", \\\"{x:733,y:584,t:1527030609840};\\\", \\\"{x:734,y:584,t:1527030609856};\\\", \\\"{x:729,y:584,t:1527030609911};\\\", \\\"{x:726,y:584,t:1527030609922};\\\", \\\"{x:715,y:582,t:1527030609939};\\\", \\\"{x:705,y:581,t:1527030609956};\\\", \\\"{x:693,y:577,t:1527030609972};\\\", \\\"{x:688,y:576,t:1527030609989};\\\", \\\"{x:683,y:574,t:1527030610006};\\\", \\\"{x:678,y:574,t:1527030610022};\\\", \\\"{x:674,y:573,t:1527030610039};\\\", \\\"{x:670,y:573,t:1527030610056};\\\", \\\"{x:662,y:573,t:1527030610073};\\\", \\\"{x:654,y:573,t:1527030610089};\\\", \\\"{x:638,y:573,t:1527030610107};\\\", \\\"{x:623,y:573,t:1527030610121};\\\", \\\"{x:603,y:573,t:1527030610139};\\\", \\\"{x:586,y:573,t:1527030610156};\\\", \\\"{x:577,y:573,t:1527030610173};\\\", \\\"{x:571,y:573,t:1527030610188};\\\", \\\"{x:569,y:573,t:1527030610206};\\\", \\\"{x:558,y:573,t:1527030610222};\\\", \\\"{x:541,y:573,t:1527030610238};\\\", \\\"{x:518,y:573,t:1527030610256};\\\", \\\"{x:499,y:573,t:1527030610273};\\\", \\\"{x:488,y:573,t:1527030610290};\\\", \\\"{x:475,y:572,t:1527030610306};\\\", \\\"{x:463,y:572,t:1527030610323};\\\", \\\"{x:454,y:575,t:1527030610339};\\\", \\\"{x:444,y:577,t:1527030610356};\\\", \\\"{x:433,y:579,t:1527030610373};\\\", \\\"{x:427,y:579,t:1527030610389};\\\", \\\"{x:426,y:579,t:1527030610407};\\\", \\\"{x:425,y:579,t:1527030610423};\\\", \\\"{x:425,y:580,t:1527030610486};\\\", \\\"{x:425,y:581,t:1527030610502};\\\", \\\"{x:425,y:582,t:1527030610511};\\\", \\\"{x:424,y:583,t:1527030610526};\\\", \\\"{x:428,y:583,t:1527030610623};\\\", \\\"{x:444,y:577,t:1527030610640};\\\", \\\"{x:469,y:570,t:1527030610656};\\\", \\\"{x:514,y:563,t:1527030610675};\\\", \\\"{x:576,y:551,t:1527030610690};\\\", \\\"{x:648,y:535,t:1527030610706};\\\", \\\"{x:712,y:525,t:1527030610723};\\\", \\\"{x:747,y:521,t:1527030610740};\\\", \\\"{x:758,y:521,t:1527030610757};\\\", \\\"{x:760,y:521,t:1527030610773};\\\", \\\"{x:760,y:520,t:1527030610789};\\\", \\\"{x:761,y:520,t:1527030610854};\\\", \\\"{x:762,y:520,t:1527030610863};\\\", \\\"{x:762,y:521,t:1527030610873};\\\", \\\"{x:768,y:522,t:1527030610890};\\\", \\\"{x:779,y:522,t:1527030610907};\\\", \\\"{x:799,y:522,t:1527030610923};\\\", \\\"{x:829,y:523,t:1527030610940};\\\", \\\"{x:859,y:523,t:1527030610957};\\\", \\\"{x:886,y:523,t:1527030610973};\\\", \\\"{x:917,y:523,t:1527030610991};\\\", \\\"{x:944,y:523,t:1527030611007};\\\", \\\"{x:948,y:523,t:1527030611024};\\\", \\\"{x:947,y:523,t:1527030611072};\\\", \\\"{x:943,y:525,t:1527030611092};\\\", \\\"{x:936,y:529,t:1527030611108};\\\", \\\"{x:921,y:534,t:1527030611123};\\\", \\\"{x:900,y:540,t:1527030611139};\\\", \\\"{x:881,y:541,t:1527030611157};\\\", \\\"{x:867,y:541,t:1527030611173};\\\", \\\"{x:860,y:539,t:1527030611190};\\\", \\\"{x:855,y:536,t:1527030611206};\\\", \\\"{x:852,y:531,t:1527030611222};\\\", \\\"{x:846,y:523,t:1527030611241};\\\", \\\"{x:838,y:514,t:1527030611257};\\\", \\\"{x:834,y:510,t:1527030611273};\\\", \\\"{x:829,y:507,t:1527030611289};\\\", \\\"{x:827,y:506,t:1527030611306};\\\", \\\"{x:827,y:505,t:1527030611375};\\\", \\\"{x:827,y:504,t:1527030611399};\\\", \\\"{x:828,y:503,t:1527030611415};\\\", \\\"{x:829,y:503,t:1527030611424};\\\", \\\"{x:830,y:503,t:1527030611440};\\\", \\\"{x:832,y:502,t:1527030611457};\\\", \\\"{x:834,y:502,t:1527030611479};\\\", \\\"{x:835,y:502,t:1527030611494};\\\", \\\"{x:836,y:502,t:1527030611519};\\\", \\\"{x:837,y:502,t:1527030611527};\\\", \\\"{x:838,y:502,t:1527030611542};\\\", \\\"{x:839,y:502,t:1527030612015};\\\", \\\"{x:839,y:503,t:1527030612025};\\\", \\\"{x:838,y:507,t:1527030612041};\\\", \\\"{x:834,y:513,t:1527030612057};\\\", \\\"{x:830,y:518,t:1527030612075};\\\", \\\"{x:825,y:524,t:1527030612091};\\\", \\\"{x:819,y:529,t:1527030612107};\\\", \\\"{x:813,y:535,t:1527030612124};\\\", \\\"{x:805,y:543,t:1527030612141};\\\", \\\"{x:796,y:552,t:1527030612158};\\\", \\\"{x:788,y:559,t:1527030612174};\\\", \\\"{x:777,y:567,t:1527030612192};\\\", \\\"{x:765,y:579,t:1527030612207};\\\", \\\"{x:751,y:591,t:1527030612224};\\\", \\\"{x:736,y:602,t:1527030612242};\\\", \\\"{x:719,y:619,t:1527030612258};\\\", \\\"{x:701,y:636,t:1527030612274};\\\", \\\"{x:682,y:651,t:1527030612291};\\\", \\\"{x:666,y:664,t:1527030612308};\\\", \\\"{x:650,y:678,t:1527030612324};\\\", \\\"{x:632,y:693,t:1527030612341};\\\", \\\"{x:614,y:706,t:1527030612358};\\\", \\\"{x:600,y:718,t:1527030612374};\\\", \\\"{x:592,y:724,t:1527030612391};\\\", \\\"{x:587,y:726,t:1527030612409};\\\", \\\"{x:584,y:727,t:1527030612424};\\\", \\\"{x:578,y:727,t:1527030612442};\\\", \\\"{x:570,y:729,t:1527030612459};\\\", \\\"{x:565,y:731,t:1527030612475};\\\", \\\"{x:560,y:731,t:1527030612493};\\\", \\\"{x:559,y:731,t:1527030612508};\\\", \\\"{x:558,y:731,t:1527030612535};\\\", \\\"{x:555,y:731,t:1527030612679};\\\", \\\"{x:554,y:731,t:1527030612691};\\\", \\\"{x:549,y:731,t:1527030612707};\\\", \\\"{x:542,y:731,t:1527030612724};\\\", \\\"{x:539,y:731,t:1527030612740};\\\", \\\"{x:533,y:731,t:1527030612758};\\\", \\\"{x:528,y:731,t:1527030612774};\\\", \\\"{x:525,y:731,t:1527030612790};\\\", \\\"{x:526,y:731,t:1527030614176};\\\", \\\"{x:539,y:731,t:1527030614192};\\\", \\\"{x:551,y:731,t:1527030614209};\\\", \\\"{x:569,y:731,t:1527030614226};\\\", \\\"{x:590,y:731,t:1527030614243};\\\", \\\"{x:613,y:731,t:1527030614260};\\\", \\\"{x:638,y:731,t:1527030614277};\\\", \\\"{x:672,y:731,t:1527030614297};\\\", \\\"{x:682,y:734,t:1527030614309};\\\", \\\"{x:694,y:735,t:1527030614326};\\\", \\\"{x:696,y:735,t:1527030614342};\\\" ] }, { \\\"rt\\\": 9577, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 513265, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -C -D -D -N -C -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:713,y:743,t:1527030614550};\\\", \\\"{x:714,y:743,t:1527030614593};\\\", \\\"{x:713,y:741,t:1527030615126};\\\", \\\"{x:706,y:727,t:1527030615143};\\\", \\\"{x:703,y:712,t:1527030615161};\\\", \\\"{x:697,y:693,t:1527030615176};\\\", \\\"{x:694,y:675,t:1527030615194};\\\", \\\"{x:693,y:661,t:1527030615211};\\\", \\\"{x:690,y:652,t:1527030615227};\\\", \\\"{x:690,y:650,t:1527030615244};\\\", \\\"{x:690,y:647,t:1527030615261};\\\", \\\"{x:690,y:643,t:1527030615277};\\\", \\\"{x:690,y:640,t:1527030615294};\\\", \\\"{x:691,y:638,t:1527030615311};\\\", \\\"{x:691,y:636,t:1527030615326};\\\", \\\"{x:693,y:633,t:1527030615366};\\\", \\\"{x:694,y:632,t:1527030615377};\\\", \\\"{x:696,y:630,t:1527030615393};\\\", \\\"{x:697,y:630,t:1527030615502};\\\", \\\"{x:699,y:630,t:1527030615510};\\\", \\\"{x:701,y:630,t:1527030615527};\\\", \\\"{x:701,y:631,t:1527030615831};\\\", \\\"{x:708,y:632,t:1527030615846};\\\", \\\"{x:721,y:635,t:1527030615860};\\\", \\\"{x:725,y:636,t:1527030615877};\\\", \\\"{x:735,y:643,t:1527030615894};\\\", \\\"{x:748,y:649,t:1527030615910};\\\", \\\"{x:768,y:657,t:1527030615927};\\\", \\\"{x:801,y:673,t:1527030615944};\\\", \\\"{x:862,y:699,t:1527030615960};\\\", \\\"{x:943,y:728,t:1527030615977};\\\", \\\"{x:1033,y:759,t:1527030615994};\\\", \\\"{x:1116,y:784,t:1527030616011};\\\", \\\"{x:1191,y:804,t:1527030616027};\\\", \\\"{x:1249,y:821,t:1527030616044};\\\", \\\"{x:1289,y:833,t:1527030616061};\\\", \\\"{x:1314,y:840,t:1527030616077};\\\", \\\"{x:1334,y:845,t:1527030616094};\\\", \\\"{x:1341,y:845,t:1527030616110};\\\", \\\"{x:1346,y:846,t:1527030616128};\\\", \\\"{x:1348,y:846,t:1527030616144};\\\", \\\"{x:1352,y:846,t:1527030616160};\\\", \\\"{x:1355,y:846,t:1527030616177};\\\", \\\"{x:1360,y:846,t:1527030616194};\\\", \\\"{x:1367,y:846,t:1527030616211};\\\", \\\"{x:1377,y:846,t:1527030616228};\\\", \\\"{x:1385,y:846,t:1527030616245};\\\", \\\"{x:1389,y:846,t:1527030616261};\\\", \\\"{x:1390,y:846,t:1527030616287};\\\", \\\"{x:1389,y:845,t:1527030616294};\\\", \\\"{x:1377,y:840,t:1527030616310};\\\", \\\"{x:1360,y:834,t:1527030616327};\\\", \\\"{x:1340,y:829,t:1527030616344};\\\", \\\"{x:1319,y:826,t:1527030616361};\\\", \\\"{x:1296,y:823,t:1527030616378};\\\", \\\"{x:1272,y:823,t:1527030616394};\\\", \\\"{x:1252,y:820,t:1527030616412};\\\", \\\"{x:1238,y:818,t:1527030616427};\\\", \\\"{x:1225,y:815,t:1527030616445};\\\", \\\"{x:1215,y:815,t:1527030616461};\\\", \\\"{x:1213,y:815,t:1527030616477};\\\", \\\"{x:1215,y:815,t:1527030616559};\\\", \\\"{x:1218,y:816,t:1527030616568};\\\", \\\"{x:1224,y:819,t:1527030616578};\\\", \\\"{x:1240,y:824,t:1527030616595};\\\", \\\"{x:1261,y:828,t:1527030616612};\\\", \\\"{x:1281,y:835,t:1527030616628};\\\", \\\"{x:1300,y:842,t:1527030616644};\\\", \\\"{x:1319,y:847,t:1527030616661};\\\", \\\"{x:1336,y:851,t:1527030616677};\\\", \\\"{x:1351,y:856,t:1527030616695};\\\", \\\"{x:1359,y:858,t:1527030616711};\\\", \\\"{x:1365,y:860,t:1527030616728};\\\", \\\"{x:1366,y:860,t:1527030616745};\\\", \\\"{x:1367,y:861,t:1527030616782};\\\", \\\"{x:1367,y:862,t:1527030616830};\\\", \\\"{x:1367,y:863,t:1527030616844};\\\", \\\"{x:1370,y:865,t:1527030616861};\\\", \\\"{x:1373,y:867,t:1527030616878};\\\", \\\"{x:1374,y:867,t:1527030616895};\\\", \\\"{x:1375,y:868,t:1527030616911};\\\", \\\"{x:1375,y:870,t:1527030616935};\\\", \\\"{x:1375,y:872,t:1527030616959};\\\", \\\"{x:1377,y:873,t:1527030616967};\\\", \\\"{x:1377,y:874,t:1527030616984};\\\", \\\"{x:1378,y:875,t:1527030616995};\\\", \\\"{x:1379,y:876,t:1527030617011};\\\", \\\"{x:1380,y:876,t:1527030617029};\\\", \\\"{x:1383,y:876,t:1527030617044};\\\", \\\"{x:1384,y:873,t:1527030617062};\\\", \\\"{x:1384,y:854,t:1527030617079};\\\", \\\"{x:1384,y:839,t:1527030617095};\\\", \\\"{x:1382,y:818,t:1527030617112};\\\", \\\"{x:1372,y:792,t:1527030617129};\\\", \\\"{x:1363,y:769,t:1527030617144};\\\", \\\"{x:1353,y:748,t:1527030617162};\\\", \\\"{x:1344,y:730,t:1527030617179};\\\", \\\"{x:1337,y:717,t:1527030617195};\\\", \\\"{x:1330,y:700,t:1527030617212};\\\", \\\"{x:1326,y:685,t:1527030617229};\\\", \\\"{x:1322,y:675,t:1527030617246};\\\", \\\"{x:1320,y:664,t:1527030617262};\\\", \\\"{x:1317,y:647,t:1527030617279};\\\", \\\"{x:1313,y:637,t:1527030617295};\\\", \\\"{x:1311,y:630,t:1527030617312};\\\", \\\"{x:1309,y:627,t:1527030617329};\\\", \\\"{x:1309,y:626,t:1527030617346};\\\", \\\"{x:1308,y:625,t:1527030617362};\\\", \\\"{x:1308,y:623,t:1527030617379};\\\", \\\"{x:1308,y:620,t:1527030617396};\\\", \\\"{x:1309,y:617,t:1527030617412};\\\", \\\"{x:1314,y:615,t:1527030617429};\\\", \\\"{x:1323,y:611,t:1527030617445};\\\", \\\"{x:1330,y:610,t:1527030617461};\\\", \\\"{x:1358,y:610,t:1527030617479};\\\", \\\"{x:1375,y:610,t:1527030617495};\\\", \\\"{x:1393,y:611,t:1527030617511};\\\", \\\"{x:1414,y:616,t:1527030617529};\\\", \\\"{x:1428,y:621,t:1527030617546};\\\", \\\"{x:1435,y:626,t:1527030617562};\\\", \\\"{x:1437,y:627,t:1527030617579};\\\", \\\"{x:1439,y:629,t:1527030617596};\\\", \\\"{x:1442,y:630,t:1527030617614};\\\", \\\"{x:1446,y:633,t:1527030617628};\\\", \\\"{x:1453,y:639,t:1527030617646};\\\", \\\"{x:1461,y:643,t:1527030617661};\\\", \\\"{x:1477,y:651,t:1527030617678};\\\", \\\"{x:1488,y:658,t:1527030617695};\\\", \\\"{x:1504,y:668,t:1527030617713};\\\", \\\"{x:1519,y:677,t:1527030617728};\\\", \\\"{x:1534,y:685,t:1527030617745};\\\", \\\"{x:1550,y:694,t:1527030617762};\\\", \\\"{x:1557,y:699,t:1527030617778};\\\", \\\"{x:1565,y:704,t:1527030617795};\\\", \\\"{x:1567,y:705,t:1527030617813};\\\", \\\"{x:1569,y:709,t:1527030617829};\\\", \\\"{x:1573,y:714,t:1527030617845};\\\", \\\"{x:1587,y:728,t:1527030617863};\\\", \\\"{x:1599,y:735,t:1527030617879};\\\", \\\"{x:1613,y:740,t:1527030617896};\\\", \\\"{x:1625,y:743,t:1527030617913};\\\", \\\"{x:1634,y:745,t:1527030617929};\\\", \\\"{x:1639,y:747,t:1527030617946};\\\", \\\"{x:1642,y:748,t:1527030617963};\\\", \\\"{x:1646,y:749,t:1527030617979};\\\", \\\"{x:1655,y:753,t:1527030617996};\\\", \\\"{x:1664,y:754,t:1527030618013};\\\", \\\"{x:1675,y:758,t:1527030618029};\\\", \\\"{x:1689,y:759,t:1527030618046};\\\", \\\"{x:1701,y:762,t:1527030618063};\\\", \\\"{x:1705,y:763,t:1527030618079};\\\", \\\"{x:1708,y:765,t:1527030618096};\\\", \\\"{x:1713,y:769,t:1527030618113};\\\", \\\"{x:1718,y:774,t:1527030618129};\\\", \\\"{x:1725,y:783,t:1527030618146};\\\", \\\"{x:1731,y:790,t:1527030618163};\\\", \\\"{x:1736,y:798,t:1527030618179};\\\", \\\"{x:1739,y:803,t:1527030618196};\\\", \\\"{x:1741,y:807,t:1527030618213};\\\", \\\"{x:1743,y:813,t:1527030618230};\\\", \\\"{x:1745,y:820,t:1527030618245};\\\", \\\"{x:1746,y:826,t:1527030618264};\\\", \\\"{x:1747,y:828,t:1527030618279};\\\", \\\"{x:1748,y:829,t:1527030618296};\\\", \\\"{x:1747,y:830,t:1527030618313};\\\", \\\"{x:1747,y:831,t:1527030618330};\\\", \\\"{x:1741,y:832,t:1527030618347};\\\", \\\"{x:1736,y:832,t:1527030618363};\\\", \\\"{x:1729,y:832,t:1527030618379};\\\", \\\"{x:1721,y:832,t:1527030618396};\\\", \\\"{x:1715,y:832,t:1527030618413};\\\", \\\"{x:1708,y:832,t:1527030618430};\\\", \\\"{x:1699,y:828,t:1527030618446};\\\", \\\"{x:1684,y:821,t:1527030618464};\\\", \\\"{x:1675,y:813,t:1527030618480};\\\", \\\"{x:1663,y:805,t:1527030618496};\\\", \\\"{x:1654,y:798,t:1527030618513};\\\", \\\"{x:1649,y:792,t:1527030618530};\\\", \\\"{x:1646,y:786,t:1527030618546};\\\", \\\"{x:1643,y:773,t:1527030618563};\\\", \\\"{x:1636,y:761,t:1527030618580};\\\", \\\"{x:1634,y:752,t:1527030618596};\\\", \\\"{x:1629,y:742,t:1527030618613};\\\", \\\"{x:1620,y:728,t:1527030618630};\\\", \\\"{x:1610,y:713,t:1527030618646};\\\", \\\"{x:1586,y:674,t:1527030618663};\\\", \\\"{x:1567,y:648,t:1527030618680};\\\", \\\"{x:1547,y:624,t:1527030618698};\\\", \\\"{x:1531,y:606,t:1527030618713};\\\", \\\"{x:1520,y:595,t:1527030618730};\\\", \\\"{x:1508,y:582,t:1527030618747};\\\", \\\"{x:1498,y:569,t:1527030618763};\\\", \\\"{x:1490,y:560,t:1527030618780};\\\", \\\"{x:1481,y:550,t:1527030618797};\\\", \\\"{x:1477,y:546,t:1527030618813};\\\", \\\"{x:1472,y:543,t:1527030618829};\\\", \\\"{x:1468,y:539,t:1527030618847};\\\", \\\"{x:1466,y:538,t:1527030618863};\\\", \\\"{x:1465,y:537,t:1527030618895};\\\", \\\"{x:1465,y:536,t:1527030618919};\\\", \\\"{x:1464,y:534,t:1527030618935};\\\", \\\"{x:1464,y:533,t:1527030618947};\\\", \\\"{x:1462,y:531,t:1527030618963};\\\", \\\"{x:1462,y:530,t:1527030618980};\\\", \\\"{x:1461,y:529,t:1527030618996};\\\", \\\"{x:1459,y:528,t:1527030619013};\\\", \\\"{x:1459,y:526,t:1527030619039};\\\", \\\"{x:1459,y:524,t:1527030619127};\\\", \\\"{x:1459,y:523,t:1527030619135};\\\", \\\"{x:1460,y:522,t:1527030619147};\\\", \\\"{x:1462,y:519,t:1527030619164};\\\", \\\"{x:1467,y:519,t:1527030619180};\\\", \\\"{x:1472,y:516,t:1527030619197};\\\", \\\"{x:1478,y:515,t:1527030619214};\\\", \\\"{x:1485,y:515,t:1527030619230};\\\", \\\"{x:1494,y:515,t:1527030619247};\\\", \\\"{x:1500,y:515,t:1527030619264};\\\", \\\"{x:1504,y:515,t:1527030619279};\\\", \\\"{x:1507,y:515,t:1527030619298};\\\", \\\"{x:1512,y:515,t:1527030619314};\\\", \\\"{x:1514,y:516,t:1527030619330};\\\", \\\"{x:1516,y:517,t:1527030619347};\\\", \\\"{x:1517,y:518,t:1527030619384};\\\", \\\"{x:1518,y:518,t:1527030619407};\\\", \\\"{x:1519,y:519,t:1527030619415};\\\", \\\"{x:1519,y:520,t:1527030619430};\\\", \\\"{x:1522,y:522,t:1527030619447};\\\", \\\"{x:1525,y:524,t:1527030619464};\\\", \\\"{x:1525,y:525,t:1527030619480};\\\", \\\"{x:1526,y:527,t:1527030619498};\\\", \\\"{x:1526,y:528,t:1527030619514};\\\", \\\"{x:1526,y:532,t:1527030619530};\\\", \\\"{x:1526,y:534,t:1527030619547};\\\", \\\"{x:1526,y:539,t:1527030619564};\\\", \\\"{x:1525,y:542,t:1527030619580};\\\", \\\"{x:1518,y:552,t:1527030619597};\\\", \\\"{x:1509,y:562,t:1527030619614};\\\", \\\"{x:1497,y:573,t:1527030619630};\\\", \\\"{x:1473,y:591,t:1527030619647};\\\", \\\"{x:1459,y:601,t:1527030619664};\\\", \\\"{x:1449,y:613,t:1527030619680};\\\", \\\"{x:1442,y:624,t:1527030619698};\\\", \\\"{x:1435,y:632,t:1527030619714};\\\", \\\"{x:1430,y:642,t:1527030619731};\\\", \\\"{x:1427,y:649,t:1527030619747};\\\", \\\"{x:1425,y:654,t:1527030619764};\\\", \\\"{x:1425,y:655,t:1527030619781};\\\", \\\"{x:1424,y:658,t:1527030619797};\\\", \\\"{x:1423,y:660,t:1527030619814};\\\", \\\"{x:1423,y:665,t:1527030619831};\\\", \\\"{x:1423,y:669,t:1527030619847};\\\", \\\"{x:1421,y:675,t:1527030619864};\\\", \\\"{x:1418,y:682,t:1527030619881};\\\", \\\"{x:1415,y:690,t:1527030619898};\\\", \\\"{x:1411,y:698,t:1527030619914};\\\", \\\"{x:1410,y:703,t:1527030619931};\\\", \\\"{x:1404,y:712,t:1527030619947};\\\", \\\"{x:1400,y:717,t:1527030619964};\\\", \\\"{x:1398,y:719,t:1527030619981};\\\", \\\"{x:1396,y:719,t:1527030620023};\\\", \\\"{x:1394,y:720,t:1527030620031};\\\", \\\"{x:1391,y:720,t:1527030620047};\\\", \\\"{x:1384,y:719,t:1527030620064};\\\", \\\"{x:1372,y:715,t:1527030620081};\\\", \\\"{x:1365,y:712,t:1527030620099};\\\", \\\"{x:1360,y:709,t:1527030620114};\\\", \\\"{x:1353,y:707,t:1527030620132};\\\", \\\"{x:1348,y:705,t:1527030620147};\\\", \\\"{x:1346,y:704,t:1527030620164};\\\", \\\"{x:1346,y:702,t:1527030620181};\\\", \\\"{x:1346,y:701,t:1527030620214};\\\", \\\"{x:1346,y:699,t:1527030620231};\\\", \\\"{x:1346,y:698,t:1527030620263};\\\", \\\"{x:1347,y:697,t:1527030620281};\\\", \\\"{x:1348,y:696,t:1527030620298};\\\", \\\"{x:1350,y:697,t:1527030620488};\\\", \\\"{x:1350,y:699,t:1527030620498};\\\", \\\"{x:1350,y:704,t:1527030620515};\\\", \\\"{x:1351,y:708,t:1527030620531};\\\", \\\"{x:1352,y:711,t:1527030620548};\\\", \\\"{x:1353,y:714,t:1527030620565};\\\", \\\"{x:1353,y:717,t:1527030620581};\\\", \\\"{x:1353,y:720,t:1527030620598};\\\", \\\"{x:1350,y:728,t:1527030620615};\\\", \\\"{x:1343,y:735,t:1527030620630};\\\", \\\"{x:1333,y:745,t:1527030620648};\\\", \\\"{x:1322,y:750,t:1527030620665};\\\", \\\"{x:1302,y:756,t:1527030620681};\\\", \\\"{x:1277,y:761,t:1527030620698};\\\", \\\"{x:1247,y:761,t:1527030620715};\\\", \\\"{x:1207,y:765,t:1527030620731};\\\", \\\"{x:1153,y:767,t:1527030620748};\\\", \\\"{x:1064,y:767,t:1527030620765};\\\", \\\"{x:958,y:762,t:1527030620781};\\\", \\\"{x:855,y:746,t:1527030620797};\\\", \\\"{x:736,y:727,t:1527030620814};\\\", \\\"{x:666,y:715,t:1527030620831};\\\", \\\"{x:604,y:705,t:1527030620848};\\\", \\\"{x:564,y:692,t:1527030620865};\\\", \\\"{x:537,y:685,t:1527030620881};\\\", \\\"{x:519,y:680,t:1527030620897};\\\", \\\"{x:516,y:677,t:1527030620914};\\\", \\\"{x:516,y:673,t:1527030620930};\\\", \\\"{x:515,y:669,t:1527030620947};\\\", \\\"{x:514,y:669,t:1527030621223};\\\", \\\"{x:514,y:668,t:1527030621231};\\\", \\\"{x:514,y:664,t:1527030621248};\\\", \\\"{x:514,y:661,t:1527030621265};\\\", \\\"{x:514,y:657,t:1527030621282};\\\", \\\"{x:514,y:651,t:1527030621298};\\\", \\\"{x:512,y:644,t:1527030621314};\\\", \\\"{x:509,y:631,t:1527030621332};\\\", \\\"{x:505,y:617,t:1527030621347};\\\", \\\"{x:501,y:605,t:1527030621364};\\\", \\\"{x:497,y:596,t:1527030621382};\\\", \\\"{x:495,y:583,t:1527030621398};\\\", \\\"{x:494,y:576,t:1527030621414};\\\", \\\"{x:493,y:572,t:1527030621431};\\\", \\\"{x:492,y:569,t:1527030621448};\\\", \\\"{x:489,y:567,t:1527030621464};\\\", \\\"{x:488,y:564,t:1527030621481};\\\", \\\"{x:485,y:561,t:1527030621499};\\\", \\\"{x:485,y:560,t:1527030621518};\\\", \\\"{x:484,y:560,t:1527030621532};\\\", \\\"{x:483,y:558,t:1527030621548};\\\", \\\"{x:482,y:556,t:1527030621566};\\\", \\\"{x:479,y:554,t:1527030621584};\\\", \\\"{x:478,y:554,t:1527030621598};\\\", \\\"{x:477,y:553,t:1527030621622};\\\", \\\"{x:476,y:553,t:1527030621638};\\\", \\\"{x:473,y:553,t:1527030621654};\\\", \\\"{x:472,y:553,t:1527030621665};\\\", \\\"{x:469,y:553,t:1527030621682};\\\", \\\"{x:463,y:553,t:1527030621698};\\\", \\\"{x:456,y:554,t:1527030621716};\\\", \\\"{x:449,y:554,t:1527030621732};\\\", \\\"{x:443,y:555,t:1527030621749};\\\", \\\"{x:433,y:556,t:1527030621767};\\\", \\\"{x:426,y:558,t:1527030621781};\\\", \\\"{x:413,y:558,t:1527030621798};\\\", \\\"{x:407,y:559,t:1527030621815};\\\", \\\"{x:400,y:559,t:1527030621831};\\\", \\\"{x:397,y:560,t:1527030621848};\\\", \\\"{x:392,y:560,t:1527030621865};\\\", \\\"{x:386,y:562,t:1527030621881};\\\", \\\"{x:377,y:563,t:1527030621899};\\\", \\\"{x:366,y:563,t:1527030621915};\\\", \\\"{x:351,y:563,t:1527030621931};\\\", \\\"{x:335,y:563,t:1527030621949};\\\", \\\"{x:316,y:563,t:1527030621965};\\\", \\\"{x:295,y:563,t:1527030621982};\\\", \\\"{x:264,y:566,t:1527030622001};\\\", \\\"{x:245,y:569,t:1527030622016};\\\", \\\"{x:231,y:573,t:1527030622033};\\\", \\\"{x:222,y:578,t:1527030622048};\\\", \\\"{x:209,y:584,t:1527030622066};\\\", \\\"{x:199,y:590,t:1527030622082};\\\", \\\"{x:193,y:593,t:1527030622099};\\\", \\\"{x:188,y:597,t:1527030622116};\\\", \\\"{x:187,y:597,t:1527030622132};\\\", \\\"{x:186,y:597,t:1527030622148};\\\", \\\"{x:185,y:597,t:1527030622166};\\\", \\\"{x:184,y:597,t:1527030622183};\\\", \\\"{x:183,y:591,t:1527030622200};\\\", \\\"{x:183,y:585,t:1527030622215};\\\", \\\"{x:183,y:577,t:1527030622232};\\\", \\\"{x:183,y:572,t:1527030622249};\\\", \\\"{x:181,y:563,t:1527030622265};\\\", \\\"{x:181,y:560,t:1527030622283};\\\", \\\"{x:181,y:556,t:1527030622298};\\\", \\\"{x:181,y:553,t:1527030622316};\\\", \\\"{x:180,y:550,t:1527030622333};\\\", \\\"{x:177,y:546,t:1527030622348};\\\", \\\"{x:177,y:544,t:1527030622366};\\\", \\\"{x:173,y:539,t:1527030622382};\\\", \\\"{x:169,y:538,t:1527030622398};\\\", \\\"{x:166,y:537,t:1527030622416};\\\", \\\"{x:164,y:535,t:1527030622432};\\\", \\\"{x:163,y:535,t:1527030622450};\\\", \\\"{x:162,y:535,t:1527030622465};\\\", \\\"{x:161,y:535,t:1527030622483};\\\", \\\"{x:159,y:534,t:1527030622499};\\\", \\\"{x:158,y:534,t:1527030622750};\\\", \\\"{x:162,y:535,t:1527030622765};\\\", \\\"{x:211,y:543,t:1527030622782};\\\", \\\"{x:266,y:554,t:1527030622800};\\\", \\\"{x:315,y:573,t:1527030622816};\\\", \\\"{x:356,y:591,t:1527030622832};\\\", \\\"{x:383,y:605,t:1527030622850};\\\", \\\"{x:412,y:620,t:1527030622866};\\\", \\\"{x:429,y:629,t:1527030622882};\\\", \\\"{x:439,y:638,t:1527030622899};\\\", \\\"{x:448,y:644,t:1527030622917};\\\", \\\"{x:459,y:656,t:1527030622932};\\\", \\\"{x:465,y:668,t:1527030622949};\\\", \\\"{x:476,y:683,t:1527030622966};\\\", \\\"{x:487,y:701,t:1527030622983};\\\", \\\"{x:494,y:713,t:1527030623000};\\\", \\\"{x:496,y:721,t:1527030623017};\\\", \\\"{x:498,y:724,t:1527030623032};\\\", \\\"{x:498,y:725,t:1527030623050};\\\", \\\"{x:498,y:727,t:1527030623067};\\\", \\\"{x:498,y:728,t:1527030623102};\\\", \\\"{x:498,y:729,t:1527030623116};\\\", \\\"{x:498,y:730,t:1527030623132};\\\", \\\"{x:499,y:732,t:1527030623150};\\\", \\\"{x:501,y:734,t:1527030624646};\\\", \\\"{x:502,y:734,t:1527030624663};\\\", \\\"{x:503,y:735,t:1527030624671};\\\", \\\"{x:504,y:735,t:1527030624684};\\\", \\\"{x:505,y:735,t:1527030624701};\\\", \\\"{x:507,y:736,t:1527030624718};\\\", \\\"{x:513,y:738,t:1527030624735};\\\", \\\"{x:522,y:739,t:1527030624750};\\\", \\\"{x:540,y:745,t:1527030624768};\\\", \\\"{x:559,y:749,t:1527030624784};\\\", \\\"{x:582,y:757,t:1527030624800};\\\", \\\"{x:603,y:764,t:1527030624818};\\\", \\\"{x:626,y:767,t:1527030624834};\\\", \\\"{x:638,y:767,t:1527030624851};\\\", \\\"{x:639,y:767,t:1527030624868};\\\" ] }, { \\\"rt\\\": 24572, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 539195, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -F -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:661,y:758,t:1527030625482};\\\", \\\"{x:661,y:756,t:1527030625517};\\\", \\\"{x:660,y:755,t:1527030625638};\\\", \\\"{x:659,y:754,t:1527030625654};\\\", \\\"{x:657,y:754,t:1527030625670};\\\", \\\"{x:655,y:753,t:1527030625684};\\\", \\\"{x:649,y:751,t:1527030625702};\\\", \\\"{x:642,y:747,t:1527030625718};\\\", \\\"{x:638,y:746,t:1527030625734};\\\", \\\"{x:633,y:744,t:1527030625752};\\\", \\\"{x:626,y:742,t:1527030625768};\\\", \\\"{x:622,y:740,t:1527030625785};\\\", \\\"{x:615,y:737,t:1527030625802};\\\", \\\"{x:610,y:735,t:1527030625819};\\\", \\\"{x:604,y:733,t:1527030625835};\\\", \\\"{x:602,y:731,t:1527030625852};\\\", \\\"{x:600,y:731,t:1527030625869};\\\", \\\"{x:597,y:729,t:1527030625885};\\\", \\\"{x:595,y:728,t:1527030625902};\\\", \\\"{x:594,y:728,t:1527030625919};\\\", \\\"{x:593,y:727,t:1527030625935};\\\", \\\"{x:593,y:726,t:1527030625952};\\\", \\\"{x:593,y:723,t:1527030625969};\\\", \\\"{x:593,y:721,t:1527030625985};\\\", \\\"{x:626,y:714,t:1527030626044};\\\", \\\"{x:634,y:714,t:1527030626052};\\\", \\\"{x:659,y:715,t:1527030626068};\\\", \\\"{x:689,y:723,t:1527030626085};\\\", \\\"{x:725,y:738,t:1527030626102};\\\", \\\"{x:760,y:754,t:1527030626118};\\\", \\\"{x:769,y:762,t:1527030626136};\\\", \\\"{x:772,y:766,t:1527030626151};\\\", \\\"{x:772,y:767,t:1527030626206};\\\", \\\"{x:774,y:766,t:1527030627391};\\\", \\\"{x:776,y:765,t:1527030627403};\\\", \\\"{x:783,y:762,t:1527030627420};\\\", \\\"{x:784,y:762,t:1527030627437};\\\", \\\"{x:784,y:761,t:1527030627455};\\\", \\\"{x:785,y:761,t:1527030627478};\\\", \\\"{x:786,y:760,t:1527030627487};\\\", \\\"{x:788,y:757,t:1527030627502};\\\", \\\"{x:788,y:754,t:1527030627520};\\\", \\\"{x:789,y:753,t:1527030627537};\\\", \\\"{x:790,y:750,t:1527030627553};\\\", \\\"{x:791,y:748,t:1527030627570};\\\", \\\"{x:792,y:747,t:1527030627587};\\\", \\\"{x:792,y:746,t:1527030627603};\\\", \\\"{x:792,y:745,t:1527030627620};\\\", \\\"{x:792,y:744,t:1527030627637};\\\", \\\"{x:792,y:742,t:1527030627653};\\\", \\\"{x:793,y:740,t:1527030627671};\\\", \\\"{x:798,y:732,t:1527030627687};\\\", \\\"{x:800,y:730,t:1527030627703};\\\", \\\"{x:803,y:728,t:1527030628055};\\\", \\\"{x:807,y:726,t:1527030628070};\\\", \\\"{x:831,y:716,t:1527030628087};\\\", \\\"{x:846,y:709,t:1527030628104};\\\", \\\"{x:863,y:705,t:1527030628119};\\\", \\\"{x:885,y:698,t:1527030628136};\\\", \\\"{x:907,y:694,t:1527030628154};\\\", \\\"{x:940,y:689,t:1527030628170};\\\", \\\"{x:976,y:685,t:1527030628186};\\\", \\\"{x:1029,y:679,t:1527030628204};\\\", \\\"{x:1079,y:679,t:1527030628220};\\\", \\\"{x:1138,y:677,t:1527030628237};\\\", \\\"{x:1201,y:674,t:1527030628254};\\\", \\\"{x:1273,y:674,t:1527030628269};\\\", \\\"{x:1404,y:672,t:1527030628286};\\\", \\\"{x:1476,y:672,t:1527030628304};\\\", \\\"{x:1557,y:670,t:1527030628320};\\\", \\\"{x:1632,y:670,t:1527030628337};\\\", \\\"{x:1699,y:670,t:1527030628354};\\\", \\\"{x:1734,y:670,t:1527030628371};\\\", \\\"{x:1751,y:670,t:1527030628388};\\\", \\\"{x:1767,y:670,t:1527030628405};\\\", \\\"{x:1780,y:670,t:1527030628422};\\\", \\\"{x:1785,y:671,t:1527030628437};\\\", \\\"{x:1785,y:672,t:1527030628479};\\\", \\\"{x:1784,y:675,t:1527030628502};\\\", \\\"{x:1781,y:676,t:1527030628510};\\\", \\\"{x:1779,y:678,t:1527030628521};\\\", \\\"{x:1769,y:684,t:1527030628537};\\\", \\\"{x:1757,y:690,t:1527030628554};\\\", \\\"{x:1738,y:697,t:1527030628571};\\\", \\\"{x:1721,y:705,t:1527030628587};\\\", \\\"{x:1709,y:708,t:1527030628604};\\\", \\\"{x:1705,y:710,t:1527030628622};\\\", \\\"{x:1701,y:711,t:1527030628637};\\\", \\\"{x:1700,y:713,t:1527030628655};\\\", \\\"{x:1699,y:715,t:1527030628679};\\\", \\\"{x:1699,y:716,t:1527030628687};\\\", \\\"{x:1698,y:721,t:1527030628704};\\\", \\\"{x:1698,y:728,t:1527030628721};\\\", \\\"{x:1697,y:737,t:1527030628738};\\\", \\\"{x:1696,y:744,t:1527030628754};\\\", \\\"{x:1695,y:750,t:1527030628771};\\\", \\\"{x:1695,y:755,t:1527030628788};\\\", \\\"{x:1695,y:760,t:1527030628804};\\\", \\\"{x:1695,y:766,t:1527030628821};\\\", \\\"{x:1695,y:770,t:1527030628838};\\\", \\\"{x:1695,y:773,t:1527030628855};\\\", \\\"{x:1695,y:778,t:1527030628871};\\\", \\\"{x:1695,y:781,t:1527030628888};\\\", \\\"{x:1695,y:784,t:1527030628904};\\\", \\\"{x:1695,y:785,t:1527030628921};\\\", \\\"{x:1696,y:786,t:1527030628938};\\\", \\\"{x:1696,y:788,t:1527030628954};\\\", \\\"{x:1696,y:791,t:1527030628971};\\\", \\\"{x:1697,y:793,t:1527030628989};\\\", \\\"{x:1698,y:795,t:1527030629005};\\\", \\\"{x:1698,y:796,t:1527030629021};\\\", \\\"{x:1698,y:797,t:1527030629039};\\\", \\\"{x:1698,y:798,t:1527030629055};\\\", \\\"{x:1698,y:795,t:1527030629191};\\\", \\\"{x:1693,y:792,t:1527030629205};\\\", \\\"{x:1686,y:786,t:1527030629222};\\\", \\\"{x:1678,y:779,t:1527030629239};\\\", \\\"{x:1674,y:774,t:1527030629255};\\\", \\\"{x:1671,y:771,t:1527030629271};\\\", \\\"{x:1668,y:767,t:1527030629288};\\\", \\\"{x:1666,y:763,t:1527030629305};\\\", \\\"{x:1663,y:759,t:1527030629321};\\\", \\\"{x:1662,y:757,t:1527030629338};\\\", \\\"{x:1659,y:753,t:1527030629357};\\\", \\\"{x:1658,y:748,t:1527030629371};\\\", \\\"{x:1654,y:740,t:1527030629388};\\\", \\\"{x:1647,y:729,t:1527030629405};\\\", \\\"{x:1641,y:721,t:1527030629421};\\\", \\\"{x:1635,y:715,t:1527030629438};\\\", \\\"{x:1628,y:708,t:1527030629455};\\\", \\\"{x:1626,y:706,t:1527030629471};\\\", \\\"{x:1622,y:700,t:1527030629488};\\\", \\\"{x:1621,y:697,t:1527030629505};\\\", \\\"{x:1617,y:693,t:1527030629524};\\\", \\\"{x:1615,y:693,t:1527030629537};\\\", \\\"{x:1615,y:692,t:1527030629622};\\\", \\\"{x:1613,y:691,t:1527030633767};\\\", \\\"{x:1611,y:691,t:1527030633774};\\\", \\\"{x:1608,y:691,t:1527030633791};\\\", \\\"{x:1607,y:691,t:1527030633808};\\\", \\\"{x:1605,y:691,t:1527030634031};\\\", \\\"{x:1601,y:691,t:1527030634042};\\\", \\\"{x:1582,y:692,t:1527030634059};\\\", \\\"{x:1546,y:692,t:1527030634075};\\\", \\\"{x:1495,y:692,t:1527030634092};\\\", \\\"{x:1435,y:697,t:1527030634108};\\\", \\\"{x:1379,y:697,t:1527030634124};\\\", \\\"{x:1345,y:697,t:1527030634142};\\\", \\\"{x:1284,y:697,t:1527030634160};\\\", \\\"{x:1234,y:697,t:1527030634175};\\\", \\\"{x:1190,y:695,t:1527030634191};\\\", \\\"{x:1152,y:691,t:1527030634209};\\\", \\\"{x:1112,y:684,t:1527030634226};\\\", \\\"{x:1084,y:669,t:1527030634242};\\\", \\\"{x:1072,y:660,t:1527030634259};\\\", \\\"{x:1071,y:660,t:1527030634275};\\\", \\\"{x:1070,y:660,t:1527030634455};\\\", \\\"{x:1064,y:658,t:1527030634504};\\\", \\\"{x:1049,y:652,t:1527030634511};\\\", \\\"{x:1038,y:647,t:1527030634526};\\\", \\\"{x:1012,y:637,t:1527030634542};\\\", \\\"{x:954,y:619,t:1527030634558};\\\", \\\"{x:904,y:605,t:1527030634576};\\\", \\\"{x:851,y:593,t:1527030634593};\\\", \\\"{x:796,y:580,t:1527030634608};\\\", \\\"{x:738,y:565,t:1527030634625};\\\", \\\"{x:691,y:553,t:1527030634642};\\\", \\\"{x:650,y:543,t:1527030634659};\\\", \\\"{x:625,y:531,t:1527030634675};\\\", \\\"{x:596,y:524,t:1527030634692};\\\", \\\"{x:572,y:515,t:1527030634709};\\\", \\\"{x:534,y:505,t:1527030634726};\\\", \\\"{x:513,y:502,t:1527030634742};\\\", \\\"{x:496,y:499,t:1527030634759};\\\", \\\"{x:487,y:498,t:1527030634775};\\\", \\\"{x:486,y:497,t:1527030634792};\\\", \\\"{x:484,y:497,t:1527030634809};\\\", \\\"{x:481,y:497,t:1527030634824};\\\", \\\"{x:479,y:498,t:1527030634842};\\\", \\\"{x:477,y:503,t:1527030634859};\\\", \\\"{x:472,y:511,t:1527030634875};\\\", \\\"{x:464,y:517,t:1527030634892};\\\", \\\"{x:454,y:525,t:1527030634909};\\\", \\\"{x:446,y:531,t:1527030634925};\\\", \\\"{x:437,y:543,t:1527030634942};\\\", \\\"{x:430,y:552,t:1527030634959};\\\", \\\"{x:423,y:562,t:1527030634976};\\\", \\\"{x:410,y:576,t:1527030634993};\\\", \\\"{x:395,y:585,t:1527030635009};\\\", \\\"{x:384,y:592,t:1527030635026};\\\", \\\"{x:367,y:598,t:1527030635042};\\\", \\\"{x:358,y:602,t:1527030635059};\\\", \\\"{x:335,y:611,t:1527030635076};\\\", \\\"{x:310,y:619,t:1527030635092};\\\", \\\"{x:290,y:622,t:1527030635108};\\\", \\\"{x:258,y:624,t:1527030635126};\\\", \\\"{x:236,y:626,t:1527030635141};\\\", \\\"{x:225,y:626,t:1527030635159};\\\", \\\"{x:217,y:626,t:1527030635176};\\\", \\\"{x:214,y:626,t:1527030635191};\\\", \\\"{x:211,y:625,t:1527030635209};\\\", \\\"{x:209,y:624,t:1527030635225};\\\", \\\"{x:207,y:623,t:1527030635242};\\\", \\\"{x:205,y:621,t:1527030635258};\\\", \\\"{x:202,y:619,t:1527030635275};\\\", \\\"{x:194,y:613,t:1527030635292};\\\", \\\"{x:188,y:607,t:1527030635309};\\\", \\\"{x:183,y:605,t:1527030635325};\\\", \\\"{x:183,y:604,t:1527030635343};\\\", \\\"{x:183,y:602,t:1527030635359};\\\", \\\"{x:185,y:600,t:1527030635376};\\\", \\\"{x:201,y:595,t:1527030635393};\\\", \\\"{x:230,y:589,t:1527030635409};\\\", \\\"{x:286,y:581,t:1527030635426};\\\", \\\"{x:379,y:575,t:1527030635443};\\\", \\\"{x:493,y:573,t:1527030635459};\\\", \\\"{x:587,y:573,t:1527030635477};\\\", \\\"{x:665,y:573,t:1527030635493};\\\", \\\"{x:734,y:573,t:1527030635509};\\\", \\\"{x:779,y:577,t:1527030635526};\\\", \\\"{x:785,y:577,t:1527030635543};\\\", \\\"{x:786,y:577,t:1527030635574};\\\", \\\"{x:787,y:577,t:1527030635589};\\\", \\\"{x:788,y:576,t:1527030635598};\\\", \\\"{x:789,y:575,t:1527030635609};\\\", \\\"{x:794,y:572,t:1527030635626};\\\", \\\"{x:799,y:567,t:1527030635643};\\\", \\\"{x:802,y:564,t:1527030635659};\\\", \\\"{x:806,y:561,t:1527030635676};\\\", \\\"{x:807,y:560,t:1527030635693};\\\", \\\"{x:811,y:557,t:1527030635709};\\\", \\\"{x:825,y:543,t:1527030635726};\\\", \\\"{x:835,y:532,t:1527030635743};\\\", \\\"{x:841,y:526,t:1527030635759};\\\", \\\"{x:843,y:523,t:1527030635777};\\\", \\\"{x:844,y:521,t:1527030635792};\\\", \\\"{x:845,y:519,t:1527030635821};\\\", \\\"{x:845,y:518,t:1527030635838};\\\", \\\"{x:845,y:516,t:1527030635846};\\\", \\\"{x:845,y:515,t:1527030635861};\\\", \\\"{x:845,y:514,t:1527030635875};\\\", \\\"{x:845,y:511,t:1527030635893};\\\", \\\"{x:845,y:510,t:1527030635909};\\\", \\\"{x:845,y:509,t:1527030635926};\\\", \\\"{x:845,y:508,t:1527030635943};\\\", \\\"{x:845,y:507,t:1527030635960};\\\", \\\"{x:845,y:506,t:1527030635976};\\\", \\\"{x:844,y:505,t:1527030635993};\\\", \\\"{x:844,y:504,t:1527030636246};\\\", \\\"{x:850,y:504,t:1527030636260};\\\", \\\"{x:878,y:509,t:1527030636277};\\\", \\\"{x:935,y:518,t:1527030636293};\\\", \\\"{x:1066,y:543,t:1527030636310};\\\", \\\"{x:1172,y:567,t:1527030636327};\\\", \\\"{x:1277,y:595,t:1527030636343};\\\", \\\"{x:1372,y:623,t:1527030636360};\\\", \\\"{x:1464,y:652,t:1527030636377};\\\", \\\"{x:1533,y:672,t:1527030636394};\\\", \\\"{x:1564,y:685,t:1527030636410};\\\", \\\"{x:1584,y:695,t:1527030636427};\\\", \\\"{x:1599,y:702,t:1527030636443};\\\", \\\"{x:1609,y:709,t:1527030636461};\\\", \\\"{x:1616,y:714,t:1527030636478};\\\", \\\"{x:1620,y:718,t:1527030636494};\\\", \\\"{x:1634,y:722,t:1527030636511};\\\", \\\"{x:1645,y:725,t:1527030636528};\\\", \\\"{x:1650,y:727,t:1527030636544};\\\", \\\"{x:1651,y:727,t:1527030636561};\\\", \\\"{x:1652,y:727,t:1527030636583};\\\", \\\"{x:1653,y:727,t:1527030636639};\\\", \\\"{x:1653,y:726,t:1527030636647};\\\", \\\"{x:1653,y:724,t:1527030636663};\\\", \\\"{x:1652,y:723,t:1527030636678};\\\", \\\"{x:1648,y:716,t:1527030636695};\\\", \\\"{x:1644,y:711,t:1527030636711};\\\", \\\"{x:1642,y:708,t:1527030636728};\\\", \\\"{x:1640,y:705,t:1527030636745};\\\", \\\"{x:1638,y:703,t:1527030636761};\\\", \\\"{x:1638,y:702,t:1527030636777};\\\", \\\"{x:1637,y:702,t:1527030636795};\\\", \\\"{x:1636,y:701,t:1527030636811};\\\", \\\"{x:1635,y:699,t:1527030636827};\\\", \\\"{x:1633,y:698,t:1527030636844};\\\", \\\"{x:1631,y:698,t:1527030636860};\\\", \\\"{x:1629,y:697,t:1527030636877};\\\", \\\"{x:1626,y:696,t:1527030636895};\\\", \\\"{x:1622,y:695,t:1527030636911};\\\", \\\"{x:1619,y:694,t:1527030636928};\\\", \\\"{x:1615,y:694,t:1527030636945};\\\", \\\"{x:1613,y:693,t:1527030636960};\\\", \\\"{x:1612,y:692,t:1527030636977};\\\", \\\"{x:1614,y:693,t:1527030644255};\\\", \\\"{x:1615,y:695,t:1527030644266};\\\", \\\"{x:1616,y:699,t:1527030644283};\\\", \\\"{x:1616,y:700,t:1527030644300};\\\", \\\"{x:1618,y:702,t:1527030644318};\\\", \\\"{x:1618,y:703,t:1527030644591};\\\", \\\"{x:1618,y:704,t:1527030644623};\\\", \\\"{x:1618,y:705,t:1527030644712};\\\", \\\"{x:1617,y:705,t:1527030644759};\\\", \\\"{x:1617,y:704,t:1527030644775};\\\", \\\"{x:1617,y:703,t:1527030644790};\\\", \\\"{x:1617,y:702,t:1527030644855};\\\", \\\"{x:1616,y:701,t:1527030644879};\\\", \\\"{x:1615,y:700,t:1527030644900};\\\", \\\"{x:1614,y:699,t:1527030644926};\\\", \\\"{x:1614,y:698,t:1527030644983};\\\", \\\"{x:1611,y:698,t:1527030648175};\\\", \\\"{x:1601,y:698,t:1527030648187};\\\", \\\"{x:1579,y:700,t:1527030648203};\\\", \\\"{x:1555,y:702,t:1527030648219};\\\", \\\"{x:1516,y:702,t:1527030648237};\\\", \\\"{x:1474,y:702,t:1527030648253};\\\", \\\"{x:1424,y:702,t:1527030648270};\\\", \\\"{x:1302,y:702,t:1527030648287};\\\", \\\"{x:1210,y:702,t:1527030648303};\\\", \\\"{x:1116,y:702,t:1527030648319};\\\", \\\"{x:1019,y:702,t:1527030648336};\\\", \\\"{x:905,y:702,t:1527030648353};\\\", \\\"{x:825,y:702,t:1527030648369};\\\", \\\"{x:777,y:702,t:1527030648386};\\\", \\\"{x:740,y:704,t:1527030648403};\\\", \\\"{x:716,y:708,t:1527030648419};\\\", \\\"{x:687,y:714,t:1527030648436};\\\", \\\"{x:672,y:714,t:1527030648453};\\\", \\\"{x:670,y:714,t:1527030648719};\\\", \\\"{x:669,y:712,t:1527030648736};\\\", \\\"{x:664,y:709,t:1527030648753};\\\", \\\"{x:657,y:704,t:1527030648770};\\\", \\\"{x:653,y:701,t:1527030648786};\\\", \\\"{x:651,y:696,t:1527030648804};\\\", \\\"{x:645,y:687,t:1527030648820};\\\", \\\"{x:639,y:676,t:1527030648836};\\\", \\\"{x:633,y:661,t:1527030648854};\\\", \\\"{x:629,y:645,t:1527030648870};\\\", \\\"{x:623,y:621,t:1527030648887};\\\", \\\"{x:618,y:601,t:1527030648903};\\\", \\\"{x:616,y:586,t:1527030648920};\\\", \\\"{x:611,y:564,t:1527030648954};\\\", \\\"{x:607,y:557,t:1527030648971};\\\", \\\"{x:605,y:552,t:1527030648987};\\\", \\\"{x:604,y:551,t:1527030649004};\\\", \\\"{x:604,y:550,t:1527030649020};\\\", \\\"{x:604,y:549,t:1527030649094};\\\", \\\"{x:602,y:549,t:1527030649103};\\\", \\\"{x:600,y:553,t:1527030649122};\\\", \\\"{x:600,y:555,t:1527030649137};\\\", \\\"{x:600,y:559,t:1527030649154};\\\", \\\"{x:600,y:562,t:1527030649171};\\\", \\\"{x:600,y:563,t:1527030649190};\\\", \\\"{x:600,y:565,t:1527030649213};\\\", \\\"{x:602,y:567,t:1527030649230};\\\", \\\"{x:604,y:569,t:1527030649246};\\\", \\\"{x:606,y:570,t:1527030649253};\\\", \\\"{x:608,y:572,t:1527030649270};\\\", \\\"{x:610,y:574,t:1527030649287};\\\", \\\"{x:611,y:576,t:1527030649304};\\\", \\\"{x:611,y:577,t:1527030649525};\\\", \\\"{x:609,y:578,t:1527030649536};\\\", \\\"{x:597,y:586,t:1527030649554};\\\", \\\"{x:577,y:603,t:1527030649571};\\\", \\\"{x:553,y:624,t:1527030649588};\\\", \\\"{x:523,y:650,t:1527030649603};\\\", \\\"{x:498,y:669,t:1527030649621};\\\", \\\"{x:488,y:677,t:1527030649638};\\\", \\\"{x:488,y:679,t:1527030649653};\\\", \\\"{x:488,y:683,t:1527030649671};\\\", \\\"{x:487,y:687,t:1527030649687};\\\", \\\"{x:483,y:695,t:1527030649703};\\\", \\\"{x:478,y:702,t:1527030649721};\\\", \\\"{x:475,y:706,t:1527030649738};\\\", \\\"{x:473,y:709,t:1527030649754};\\\", \\\"{x:470,y:713,t:1527030649771};\\\", \\\"{x:467,y:717,t:1527030649788};\\\", \\\"{x:465,y:723,t:1527030649805};\\\", \\\"{x:464,y:725,t:1527030649821};\\\", \\\"{x:463,y:729,t:1527030649837};\\\", \\\"{x:462,y:733,t:1527030649855};\\\", \\\"{x:462,y:736,t:1527030649871};\\\", \\\"{x:462,y:738,t:1527030649888};\\\", \\\"{x:462,y:739,t:1527030650150};\\\", \\\"{x:463,y:739,t:1527030650214};\\\", \\\"{x:464,y:739,t:1527030650238};\\\", \\\"{x:468,y:739,t:1527030650254};\\\", \\\"{x:475,y:738,t:1527030650271};\\\", \\\"{x:492,y:737,t:1527030650288};\\\", \\\"{x:514,y:737,t:1527030650305};\\\", \\\"{x:544,y:737,t:1527030650321};\\\", \\\"{x:583,y:737,t:1527030650338};\\\", \\\"{x:628,y:737,t:1527030650355};\\\", \\\"{x:673,y:737,t:1527030650371};\\\", \\\"{x:704,y:737,t:1527030650388};\\\", \\\"{x:732,y:737,t:1527030650405};\\\", \\\"{x:747,y:737,t:1527030650421};\\\", \\\"{x:763,y:737,t:1527030650438};\\\", \\\"{x:769,y:737,t:1527030650454};\\\", \\\"{x:771,y:737,t:1527030650471};\\\", \\\"{x:772,y:737,t:1527030650488};\\\", \\\"{x:773,y:736,t:1527030650504};\\\" ] }, { \\\"rt\\\": 36779, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 577260, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:769,y:736,t:1527030651865};\\\", \\\"{x:765,y:736,t:1527030651876};\\\", \\\"{x:756,y:736,t:1527030651892};\\\", \\\"{x:748,y:736,t:1527030651909};\\\", \\\"{x:738,y:736,t:1527030651926};\\\", \\\"{x:728,y:736,t:1527030651942};\\\", \\\"{x:719,y:736,t:1527030651959};\\\", \\\"{x:706,y:736,t:1527030651976};\\\", \\\"{x:692,y:736,t:1527030651992};\\\", \\\"{x:669,y:729,t:1527030652010};\\\", \\\"{x:653,y:725,t:1527030652026};\\\", \\\"{x:638,y:718,t:1527030652042};\\\", \\\"{x:621,y:709,t:1527030652059};\\\", \\\"{x:599,y:696,t:1527030652077};\\\", \\\"{x:586,y:681,t:1527030652093};\\\", \\\"{x:576,y:666,t:1527030652109};\\\", \\\"{x:570,y:656,t:1527030652126};\\\", \\\"{x:565,y:650,t:1527030652142};\\\", \\\"{x:559,y:646,t:1527030652159};\\\", \\\"{x:556,y:643,t:1527030652176};\\\", \\\"{x:556,y:641,t:1527030652426};\\\", \\\"{x:557,y:641,t:1527030652474};\\\", \\\"{x:559,y:641,t:1527030652482};\\\", \\\"{x:560,y:641,t:1527030652493};\\\", \\\"{x:562,y:640,t:1527030652509};\\\", \\\"{x:567,y:637,t:1527030652526};\\\", \\\"{x:576,y:633,t:1527030652544};\\\", \\\"{x:583,y:630,t:1527030652561};\\\", \\\"{x:595,y:625,t:1527030652576};\\\", \\\"{x:628,y:616,t:1527030652593};\\\", \\\"{x:657,y:609,t:1527030652610};\\\", \\\"{x:679,y:604,t:1527030652626};\\\", \\\"{x:701,y:598,t:1527030652643};\\\", \\\"{x:725,y:595,t:1527030652660};\\\", \\\"{x:750,y:593,t:1527030652676};\\\", \\\"{x:769,y:593,t:1527030652693};\\\", \\\"{x:790,y:594,t:1527030652710};\\\", \\\"{x:812,y:597,t:1527030652726};\\\", \\\"{x:840,y:601,t:1527030652743};\\\", \\\"{x:869,y:606,t:1527030652759};\\\", \\\"{x:898,y:606,t:1527030652776};\\\", \\\"{x:980,y:614,t:1527030652793};\\\", \\\"{x:1058,y:615,t:1527030652810};\\\", \\\"{x:1151,y:621,t:1527030652826};\\\", \\\"{x:1227,y:625,t:1527030652843};\\\", \\\"{x:1280,y:632,t:1527030652860};\\\", \\\"{x:1328,y:640,t:1527030652876};\\\", \\\"{x:1364,y:647,t:1527030652893};\\\", \\\"{x:1386,y:656,t:1527030652911};\\\", \\\"{x:1408,y:668,t:1527030652927};\\\", \\\"{x:1422,y:678,t:1527030652944};\\\", \\\"{x:1430,y:685,t:1527030652961};\\\", \\\"{x:1433,y:688,t:1527030652977};\\\", \\\"{x:1437,y:691,t:1527030652992};\\\", \\\"{x:1437,y:693,t:1527030653009};\\\", \\\"{x:1439,y:694,t:1527030653027};\\\", \\\"{x:1440,y:695,t:1527030653043};\\\", \\\"{x:1445,y:704,t:1527030653354};\\\", \\\"{x:1452,y:717,t:1527030653362};\\\", \\\"{x:1472,y:745,t:1527030653377};\\\", \\\"{x:1485,y:768,t:1527030653394};\\\", \\\"{x:1490,y:776,t:1527030653411};\\\", \\\"{x:1491,y:778,t:1527030653428};\\\", \\\"{x:1491,y:779,t:1527030653444};\\\", \\\"{x:1493,y:779,t:1527030653666};\\\", \\\"{x:1496,y:780,t:1527030653677};\\\", \\\"{x:1504,y:793,t:1527030653695};\\\", \\\"{x:1523,y:815,t:1527030653710};\\\", \\\"{x:1540,y:837,t:1527030653728};\\\", \\\"{x:1556,y:859,t:1527030653745};\\\", \\\"{x:1571,y:880,t:1527030653760};\\\", \\\"{x:1586,y:902,t:1527030653778};\\\", \\\"{x:1590,y:912,t:1527030653795};\\\", \\\"{x:1592,y:920,t:1527030653810};\\\", \\\"{x:1594,y:928,t:1527030653827};\\\", \\\"{x:1595,y:933,t:1527030653845};\\\", \\\"{x:1595,y:939,t:1527030653861};\\\", \\\"{x:1595,y:940,t:1527030653878};\\\", \\\"{x:1595,y:942,t:1527030653895};\\\", \\\"{x:1595,y:947,t:1527030653911};\\\", \\\"{x:1595,y:951,t:1527030653928};\\\", \\\"{x:1595,y:954,t:1527030653944};\\\", \\\"{x:1595,y:957,t:1527030653961};\\\", \\\"{x:1594,y:958,t:1527030653977};\\\", \\\"{x:1593,y:958,t:1527030653994};\\\", \\\"{x:1591,y:959,t:1527030654010};\\\", \\\"{x:1587,y:960,t:1527030654027};\\\", \\\"{x:1583,y:960,t:1527030654044};\\\", \\\"{x:1576,y:960,t:1527030654061};\\\", \\\"{x:1572,y:960,t:1527030654077};\\\", \\\"{x:1569,y:960,t:1527030654094};\\\", \\\"{x:1567,y:960,t:1527030654111};\\\", \\\"{x:1566,y:961,t:1527030654127};\\\", \\\"{x:1562,y:961,t:1527030654144};\\\", \\\"{x:1550,y:964,t:1527030654161};\\\", \\\"{x:1540,y:965,t:1527030654177};\\\", \\\"{x:1530,y:966,t:1527030654195};\\\", \\\"{x:1521,y:967,t:1527030654212};\\\", \\\"{x:1515,y:967,t:1527030654228};\\\", \\\"{x:1512,y:967,t:1527030654244};\\\", \\\"{x:1514,y:967,t:1527030654313};\\\", \\\"{x:1515,y:966,t:1527030654328};\\\", \\\"{x:1517,y:965,t:1527030654344};\\\", \\\"{x:1518,y:965,t:1527030654385};\\\", \\\"{x:1518,y:964,t:1527030654408};\\\", \\\"{x:1519,y:963,t:1527030654416};\\\", \\\"{x:1520,y:962,t:1527030654428};\\\", \\\"{x:1522,y:960,t:1527030654444};\\\", \\\"{x:1523,y:959,t:1527030654461};\\\", \\\"{x:1528,y:956,t:1527030654478};\\\", \\\"{x:1531,y:955,t:1527030654494};\\\", \\\"{x:1535,y:953,t:1527030654512};\\\", \\\"{x:1537,y:953,t:1527030654529};\\\", \\\"{x:1541,y:953,t:1527030654544};\\\", \\\"{x:1545,y:953,t:1527030654561};\\\", \\\"{x:1548,y:953,t:1527030654578};\\\", \\\"{x:1549,y:953,t:1527030654594};\\\", \\\"{x:1551,y:953,t:1527030654611};\\\", \\\"{x:1552,y:954,t:1527030654629};\\\", \\\"{x:1555,y:956,t:1527030654645};\\\", \\\"{x:1556,y:956,t:1527030654661};\\\", \\\"{x:1558,y:956,t:1527030654678};\\\", \\\"{x:1557,y:955,t:1527030654786};\\\", \\\"{x:1556,y:954,t:1527030654795};\\\", \\\"{x:1553,y:948,t:1527030654811};\\\", \\\"{x:1550,y:943,t:1527030654828};\\\", \\\"{x:1549,y:939,t:1527030654845};\\\", \\\"{x:1547,y:937,t:1527030654862};\\\", \\\"{x:1547,y:935,t:1527030654879};\\\", \\\"{x:1547,y:929,t:1527030654895};\\\", \\\"{x:1547,y:921,t:1527030654911};\\\", \\\"{x:1547,y:911,t:1527030654928};\\\", \\\"{x:1547,y:902,t:1527030654945};\\\", \\\"{x:1547,y:898,t:1527030654961};\\\", \\\"{x:1547,y:896,t:1527030654979};\\\", \\\"{x:1547,y:893,t:1527030654996};\\\", \\\"{x:1547,y:888,t:1527030655012};\\\", \\\"{x:1547,y:883,t:1527030655029};\\\", \\\"{x:1547,y:881,t:1527030655046};\\\", \\\"{x:1547,y:879,t:1527030655061};\\\", \\\"{x:1547,y:876,t:1527030655079};\\\", \\\"{x:1547,y:869,t:1527030655095};\\\", \\\"{x:1546,y:864,t:1527030655112};\\\", \\\"{x:1545,y:857,t:1527030655129};\\\", \\\"{x:1544,y:851,t:1527030655146};\\\", \\\"{x:1544,y:850,t:1527030655161};\\\", \\\"{x:1544,y:847,t:1527030655178};\\\", \\\"{x:1543,y:845,t:1527030655195};\\\", \\\"{x:1543,y:844,t:1527030655212};\\\", \\\"{x:1543,y:841,t:1527030655229};\\\", \\\"{x:1543,y:838,t:1527030655246};\\\", \\\"{x:1543,y:837,t:1527030655263};\\\", \\\"{x:1543,y:834,t:1527030655278};\\\", \\\"{x:1543,y:832,t:1527030655296};\\\", \\\"{x:1543,y:831,t:1527030655313};\\\", \\\"{x:1543,y:829,t:1527030655328};\\\", \\\"{x:1543,y:828,t:1527030655346};\\\", \\\"{x:1543,y:827,t:1527030655442};\\\", \\\"{x:1543,y:825,t:1527030656954};\\\", \\\"{x:1543,y:822,t:1527030656964};\\\", \\\"{x:1543,y:817,t:1527030656981};\\\", \\\"{x:1543,y:812,t:1527030656997};\\\", \\\"{x:1543,y:810,t:1527030657013};\\\", \\\"{x:1543,y:807,t:1527030657030};\\\", \\\"{x:1542,y:805,t:1527030657046};\\\", \\\"{x:1542,y:803,t:1527030657063};\\\", \\\"{x:1541,y:795,t:1527030657080};\\\", \\\"{x:1540,y:793,t:1527030657096};\\\", \\\"{x:1540,y:791,t:1527030657113};\\\", \\\"{x:1539,y:788,t:1527030657130};\\\", \\\"{x:1539,y:787,t:1527030657146};\\\", \\\"{x:1539,y:786,t:1527030657163};\\\", \\\"{x:1539,y:784,t:1527030657185};\\\", \\\"{x:1539,y:783,t:1527030657201};\\\", \\\"{x:1538,y:782,t:1527030657214};\\\", \\\"{x:1538,y:781,t:1527030657231};\\\", \\\"{x:1538,y:779,t:1527030657246};\\\", \\\"{x:1537,y:776,t:1527030657263};\\\", \\\"{x:1537,y:774,t:1527030657281};\\\", \\\"{x:1537,y:772,t:1527030657297};\\\", \\\"{x:1537,y:769,t:1527030657313};\\\", \\\"{x:1537,y:768,t:1527030657330};\\\", \\\"{x:1537,y:767,t:1527030657347};\\\", \\\"{x:1537,y:766,t:1527030657364};\\\", \\\"{x:1537,y:765,t:1527030657381};\\\", \\\"{x:1537,y:764,t:1527030657397};\\\", \\\"{x:1537,y:763,t:1527030657414};\\\", \\\"{x:1537,y:762,t:1527030657431};\\\", \\\"{x:1537,y:761,t:1527030657447};\\\", \\\"{x:1535,y:759,t:1527030659258};\\\", \\\"{x:1535,y:758,t:1527030659273};\\\", \\\"{x:1535,y:757,t:1527030659281};\\\", \\\"{x:1533,y:754,t:1527030659298};\\\", \\\"{x:1533,y:752,t:1527030659322};\\\", \\\"{x:1533,y:751,t:1527030659418};\\\", \\\"{x:1533,y:749,t:1527030659433};\\\", \\\"{x:1533,y:748,t:1527030659450};\\\", \\\"{x:1533,y:746,t:1527030659466};\\\", \\\"{x:1533,y:744,t:1527030659481};\\\", \\\"{x:1533,y:742,t:1527030659499};\\\", \\\"{x:1533,y:738,t:1527030659516};\\\", \\\"{x:1533,y:736,t:1527030659537};\\\", \\\"{x:1533,y:734,t:1527030659549};\\\", \\\"{x:1534,y:732,t:1527030659566};\\\", \\\"{x:1535,y:728,t:1527030659583};\\\", \\\"{x:1535,y:726,t:1527030659599};\\\", \\\"{x:1536,y:724,t:1527030659616};\\\", \\\"{x:1537,y:722,t:1527030659634};\\\", \\\"{x:1537,y:721,t:1527030659649};\\\", \\\"{x:1537,y:718,t:1527030659666};\\\", \\\"{x:1538,y:717,t:1527030659682};\\\", \\\"{x:1540,y:714,t:1527030659698};\\\", \\\"{x:1541,y:711,t:1527030659715};\\\", \\\"{x:1545,y:705,t:1527030659733};\\\", \\\"{x:1546,y:703,t:1527030659748};\\\", \\\"{x:1547,y:699,t:1527030659766};\\\", \\\"{x:1549,y:697,t:1527030659783};\\\", \\\"{x:1549,y:695,t:1527030659799};\\\", \\\"{x:1549,y:694,t:1527030659816};\\\", \\\"{x:1550,y:692,t:1527030659866};\\\", \\\"{x:1550,y:693,t:1527030660122};\\\", \\\"{x:1549,y:694,t:1527030660138};\\\", \\\"{x:1548,y:694,t:1527030660154};\\\", \\\"{x:1548,y:695,t:1527030660274};\\\", \\\"{x:1548,y:696,t:1527030660291};\\\", \\\"{x:1548,y:697,t:1527030660321};\\\", \\\"{x:1548,y:698,t:1527030662737};\\\", \\\"{x:1548,y:699,t:1527030666443};\\\", \\\"{x:1549,y:700,t:1527030666455};\\\", \\\"{x:1551,y:705,t:1527030666472};\\\", \\\"{x:1552,y:709,t:1527030666488};\\\", \\\"{x:1552,y:712,t:1527030666504};\\\", \\\"{x:1553,y:714,t:1527030666521};\\\", \\\"{x:1553,y:715,t:1527030666537};\\\", \\\"{x:1554,y:718,t:1527030666554};\\\", \\\"{x:1555,y:722,t:1527030666570};\\\", \\\"{x:1556,y:727,t:1527030666587};\\\", \\\"{x:1556,y:731,t:1527030666604};\\\", \\\"{x:1557,y:736,t:1527030666620};\\\", \\\"{x:1558,y:738,t:1527030666637};\\\", \\\"{x:1558,y:739,t:1527030666653};\\\", \\\"{x:1558,y:740,t:1527030666670};\\\", \\\"{x:1558,y:741,t:1527030666688};\\\", \\\"{x:1558,y:743,t:1527030666703};\\\", \\\"{x:1558,y:744,t:1527030666729};\\\", \\\"{x:1558,y:745,t:1527030666745};\\\", \\\"{x:1558,y:746,t:1527030666754};\\\", \\\"{x:1558,y:747,t:1527030666794};\\\", \\\"{x:1558,y:749,t:1527030666825};\\\", \\\"{x:1558,y:750,t:1527030666849};\\\", \\\"{x:1557,y:752,t:1527030666881};\\\", \\\"{x:1555,y:753,t:1527030666897};\\\", \\\"{x:1555,y:754,t:1527030666904};\\\", \\\"{x:1554,y:754,t:1527030666921};\\\", \\\"{x:1552,y:755,t:1527030666938};\\\", \\\"{x:1551,y:756,t:1527030666962};\\\", \\\"{x:1549,y:757,t:1527030666978};\\\", \\\"{x:1548,y:758,t:1527030667026};\\\", \\\"{x:1547,y:758,t:1527030667039};\\\", \\\"{x:1547,y:759,t:1527030667442};\\\", \\\"{x:1547,y:761,t:1527030667482};\\\", \\\"{x:1547,y:762,t:1527030667530};\\\", \\\"{x:1548,y:762,t:1527030667539};\\\", \\\"{x:1548,y:764,t:1527030667626};\\\", \\\"{x:1549,y:764,t:1527030671770};\\\", \\\"{x:1548,y:764,t:1527030671777};\\\", \\\"{x:1542,y:764,t:1527030671793};\\\", \\\"{x:1520,y:764,t:1527030671810};\\\", \\\"{x:1477,y:761,t:1527030671825};\\\", \\\"{x:1448,y:757,t:1527030671842};\\\", \\\"{x:1421,y:752,t:1527030671858};\\\", \\\"{x:1386,y:751,t:1527030671875};\\\", \\\"{x:1339,y:751,t:1527030671891};\\\", \\\"{x:1270,y:746,t:1527030671909};\\\", \\\"{x:1201,y:746,t:1527030671925};\\\", \\\"{x:1125,y:745,t:1527030671942};\\\", \\\"{x:1070,y:738,t:1527030671958};\\\", \\\"{x:1025,y:731,t:1527030671975};\\\", \\\"{x:979,y:724,t:1527030671992};\\\", \\\"{x:937,y:716,t:1527030672008};\\\", \\\"{x:882,y:709,t:1527030672025};\\\", \\\"{x:839,y:702,t:1527030672042};\\\", \\\"{x:794,y:694,t:1527030672058};\\\", \\\"{x:740,y:684,t:1527030672075};\\\", \\\"{x:692,y:677,t:1527030672092};\\\", \\\"{x:652,y:670,t:1527030672109};\\\", \\\"{x:625,y:666,t:1527030672125};\\\", \\\"{x:594,y:662,t:1527030672142};\\\", \\\"{x:562,y:656,t:1527030672159};\\\", \\\"{x:537,y:653,t:1527030672175};\\\", \\\"{x:527,y:650,t:1527030672192};\\\", \\\"{x:526,y:649,t:1527030672210};\\\", \\\"{x:526,y:647,t:1527030672249};\\\", \\\"{x:526,y:646,t:1527030672265};\\\", \\\"{x:526,y:644,t:1527030672275};\\\", \\\"{x:526,y:640,t:1527030672292};\\\", \\\"{x:526,y:637,t:1527030672309};\\\", \\\"{x:526,y:634,t:1527030672325};\\\", \\\"{x:526,y:631,t:1527030672343};\\\", \\\"{x:526,y:626,t:1527030672359};\\\", \\\"{x:524,y:621,t:1527030672375};\\\", \\\"{x:519,y:614,t:1527030672391};\\\", \\\"{x:495,y:601,t:1527030672409};\\\", \\\"{x:442,y:581,t:1527030672426};\\\", \\\"{x:355,y:562,t:1527030672442};\\\", \\\"{x:324,y:555,t:1527030672459};\\\", \\\"{x:319,y:551,t:1527030672476};\\\", \\\"{x:314,y:551,t:1527030672746};\\\", \\\"{x:310,y:551,t:1527030672759};\\\", \\\"{x:301,y:552,t:1527030672776};\\\", \\\"{x:295,y:554,t:1527030672792};\\\", \\\"{x:286,y:556,t:1527030672811};\\\", \\\"{x:280,y:560,t:1527030672825};\\\", \\\"{x:267,y:561,t:1527030672841};\\\", \\\"{x:251,y:563,t:1527030672860};\\\", \\\"{x:228,y:563,t:1527030672876};\\\", \\\"{x:202,y:564,t:1527030672892};\\\", \\\"{x:179,y:564,t:1527030672909};\\\", \\\"{x:164,y:564,t:1527030672926};\\\", \\\"{x:156,y:562,t:1527030672944};\\\", \\\"{x:156,y:561,t:1527030672968};\\\", \\\"{x:156,y:560,t:1527030672977};\\\", \\\"{x:156,y:559,t:1527030672992};\\\", \\\"{x:156,y:558,t:1527030673009};\\\", \\\"{x:156,y:557,t:1527030673033};\\\", \\\"{x:156,y:556,t:1527030673043};\\\", \\\"{x:155,y:554,t:1527030673059};\\\", \\\"{x:155,y:553,t:1527030673076};\\\", \\\"{x:155,y:551,t:1527030673093};\\\", \\\"{x:155,y:548,t:1527030673108};\\\", \\\"{x:156,y:545,t:1527030673126};\\\", \\\"{x:157,y:543,t:1527030673142};\\\", \\\"{x:158,y:543,t:1527030673240};\\\", \\\"{x:156,y:543,t:1527030673370};\\\", \\\"{x:155,y:543,t:1527030673377};\\\", \\\"{x:149,y:543,t:1527030673393};\\\", \\\"{x:144,y:544,t:1527030673410};\\\", \\\"{x:142,y:544,t:1527030673426};\\\", \\\"{x:140,y:544,t:1527030673442};\\\", \\\"{x:139,y:544,t:1527030673481};\\\", \\\"{x:140,y:544,t:1527030674049};\\\", \\\"{x:142,y:544,t:1527030674060};\\\", \\\"{x:145,y:544,t:1527030674077};\\\", \\\"{x:147,y:544,t:1527030674094};\\\", \\\"{x:148,y:544,t:1527030674110};\\\", \\\"{x:149,y:544,t:1527030674129};\\\", \\\"{x:150,y:544,t:1527030674144};\\\", \\\"{x:154,y:544,t:1527030674553};\\\", \\\"{x:156,y:544,t:1527030674561};\\\", \\\"{x:164,y:544,t:1527030674578};\\\", \\\"{x:180,y:544,t:1527030674594};\\\", \\\"{x:208,y:544,t:1527030674610};\\\", \\\"{x:247,y:544,t:1527030674626};\\\", \\\"{x:306,y:544,t:1527030674644};\\\", \\\"{x:384,y:544,t:1527030674660};\\\", \\\"{x:472,y:544,t:1527030674678};\\\", \\\"{x:561,y:556,t:1527030674695};\\\", \\\"{x:667,y:570,t:1527030674711};\\\", \\\"{x:761,y:582,t:1527030674728};\\\", \\\"{x:853,y:597,t:1527030674744};\\\", \\\"{x:993,y:616,t:1527030674760};\\\", \\\"{x:1063,y:628,t:1527030674777};\\\", \\\"{x:1120,y:639,t:1527030674794};\\\", \\\"{x:1164,y:648,t:1527030674811};\\\", \\\"{x:1190,y:653,t:1527030674827};\\\", \\\"{x:1217,y:656,t:1527030674844};\\\", \\\"{x:1242,y:661,t:1527030674862};\\\", \\\"{x:1259,y:666,t:1527030674877};\\\", \\\"{x:1276,y:671,t:1527030674895};\\\", \\\"{x:1292,y:677,t:1527030674912};\\\", \\\"{x:1313,y:681,t:1527030674927};\\\", \\\"{x:1334,y:687,t:1527030674945};\\\", \\\"{x:1368,y:697,t:1527030674961};\\\", \\\"{x:1386,y:703,t:1527030674978};\\\", \\\"{x:1393,y:705,t:1527030674994};\\\", \\\"{x:1399,y:708,t:1527030675012};\\\", \\\"{x:1407,y:712,t:1527030675028};\\\", \\\"{x:1413,y:715,t:1527030675045};\\\", \\\"{x:1423,y:721,t:1527030675061};\\\", \\\"{x:1437,y:728,t:1527030675077};\\\", \\\"{x:1450,y:735,t:1527030675095};\\\", \\\"{x:1472,y:742,t:1527030675111};\\\", \\\"{x:1489,y:746,t:1527030675127};\\\", \\\"{x:1509,y:750,t:1527030675144};\\\", \\\"{x:1533,y:755,t:1527030675162};\\\", \\\"{x:1542,y:758,t:1527030675178};\\\", \\\"{x:1544,y:758,t:1527030675194};\\\", \\\"{x:1545,y:759,t:1527030675250};\\\", \\\"{x:1545,y:760,t:1527030675261};\\\", \\\"{x:1547,y:761,t:1527030675279};\\\", \\\"{x:1548,y:762,t:1527030675294};\\\", \\\"{x:1549,y:763,t:1527030675312};\\\", \\\"{x:1549,y:764,t:1527030675346};\\\", \\\"{x:1549,y:765,t:1527030675361};\\\", \\\"{x:1547,y:767,t:1527030675378};\\\", \\\"{x:1542,y:767,t:1527030675395};\\\", \\\"{x:1538,y:768,t:1527030675412};\\\", \\\"{x:1536,y:768,t:1527030675429};\\\", \\\"{x:1534,y:768,t:1527030675444};\\\", \\\"{x:1531,y:768,t:1527030675461};\\\", \\\"{x:1530,y:768,t:1527030675754};\\\", \\\"{x:1528,y:768,t:1527030675794};\\\", \\\"{x:1527,y:769,t:1527030675818};\\\", \\\"{x:1526,y:770,t:1527030675828};\\\", \\\"{x:1525,y:780,t:1527030675845};\\\", \\\"{x:1521,y:792,t:1527030675862};\\\", \\\"{x:1518,y:802,t:1527030675879};\\\", \\\"{x:1517,y:816,t:1527030675896};\\\", \\\"{x:1514,y:834,t:1527030675912};\\\", \\\"{x:1514,y:856,t:1527030675928};\\\", \\\"{x:1514,y:885,t:1527030675946};\\\", \\\"{x:1514,y:898,t:1527030675962};\\\", \\\"{x:1514,y:908,t:1527030675979};\\\", \\\"{x:1514,y:911,t:1527030675996};\\\", \\\"{x:1514,y:912,t:1527030676034};\\\", \\\"{x:1514,y:913,t:1527030676074};\\\", \\\"{x:1514,y:914,t:1527030676091};\\\", \\\"{x:1515,y:915,t:1527030676106};\\\", \\\"{x:1516,y:917,t:1527030676114};\\\", \\\"{x:1517,y:918,t:1527030676129};\\\", \\\"{x:1521,y:923,t:1527030676145};\\\", \\\"{x:1523,y:925,t:1527030676162};\\\", \\\"{x:1528,y:928,t:1527030676179};\\\", \\\"{x:1536,y:932,t:1527030676195};\\\", \\\"{x:1545,y:935,t:1527030676212};\\\", \\\"{x:1552,y:937,t:1527030676229};\\\", \\\"{x:1557,y:938,t:1527030676246};\\\", \\\"{x:1561,y:938,t:1527030676261};\\\", \\\"{x:1562,y:938,t:1527030676279};\\\", \\\"{x:1562,y:936,t:1527030676306};\\\", \\\"{x:1562,y:931,t:1527030676313};\\\", \\\"{x:1560,y:924,t:1527030676328};\\\", \\\"{x:1554,y:902,t:1527030676346};\\\", \\\"{x:1550,y:892,t:1527030676362};\\\", \\\"{x:1548,y:882,t:1527030676378};\\\", \\\"{x:1545,y:867,t:1527030676395};\\\", \\\"{x:1544,y:855,t:1527030676413};\\\", \\\"{x:1542,y:844,t:1527030676429};\\\", \\\"{x:1539,y:833,t:1527030676446};\\\", \\\"{x:1539,y:824,t:1527030676463};\\\", \\\"{x:1539,y:819,t:1527030676478};\\\", \\\"{x:1539,y:815,t:1527030676495};\\\", \\\"{x:1539,y:813,t:1527030676513};\\\", \\\"{x:1540,y:810,t:1527030676529};\\\", \\\"{x:1540,y:807,t:1527030676545};\\\", \\\"{x:1541,y:804,t:1527030676563};\\\", \\\"{x:1542,y:802,t:1527030676578};\\\", \\\"{x:1543,y:800,t:1527030676595};\\\", \\\"{x:1543,y:799,t:1527030676613};\\\", \\\"{x:1543,y:798,t:1527030676629};\\\", \\\"{x:1543,y:797,t:1527030676645};\\\", \\\"{x:1544,y:795,t:1527030676662};\\\", \\\"{x:1544,y:793,t:1527030676678};\\\", \\\"{x:1544,y:792,t:1527030676696};\\\", \\\"{x:1544,y:790,t:1527030676713};\\\", \\\"{x:1544,y:788,t:1527030676729};\\\", \\\"{x:1544,y:785,t:1527030676745};\\\", \\\"{x:1544,y:783,t:1527030676762};\\\", \\\"{x:1544,y:780,t:1527030676778};\\\", \\\"{x:1544,y:779,t:1527030676796};\\\", \\\"{x:1544,y:776,t:1527030676813};\\\", \\\"{x:1544,y:775,t:1527030676833};\\\", \\\"{x:1544,y:774,t:1527030676846};\\\", \\\"{x:1544,y:773,t:1527030676863};\\\", \\\"{x:1544,y:771,t:1527030676880};\\\", \\\"{x:1544,y:769,t:1527030676896};\\\", \\\"{x:1544,y:767,t:1527030676912};\\\", \\\"{x:1544,y:766,t:1527030676937};\\\", \\\"{x:1544,y:765,t:1527030676970};\\\", \\\"{x:1544,y:764,t:1527030677002};\\\", \\\"{x:1544,y:763,t:1527030677131};\\\", \\\"{x:1544,y:762,t:1527030677146};\\\", \\\"{x:1544,y:761,t:1527030677177};\\\", \\\"{x:1545,y:760,t:1527030677194};\\\", \\\"{x:1545,y:759,t:1527030682242};\\\", \\\"{x:1545,y:758,t:1527030682250};\\\", \\\"{x:1545,y:755,t:1527030682265};\\\", \\\"{x:1545,y:752,t:1527030682283};\\\", \\\"{x:1545,y:751,t:1527030682299};\\\", \\\"{x:1545,y:749,t:1527030682316};\\\", \\\"{x:1545,y:747,t:1527030682333};\\\", \\\"{x:1545,y:745,t:1527030682350};\\\", \\\"{x:1545,y:742,t:1527030682366};\\\", \\\"{x:1545,y:740,t:1527030682386};\\\", \\\"{x:1545,y:738,t:1527030682401};\\\", \\\"{x:1545,y:736,t:1527030682416};\\\", \\\"{x:1545,y:734,t:1527030682433};\\\", \\\"{x:1545,y:731,t:1527030682449};\\\", \\\"{x:1545,y:729,t:1527030682466};\\\", \\\"{x:1546,y:728,t:1527030682483};\\\", \\\"{x:1547,y:723,t:1527030682500};\\\", \\\"{x:1548,y:717,t:1527030682516};\\\", \\\"{x:1549,y:714,t:1527030682533};\\\", \\\"{x:1549,y:712,t:1527030682550};\\\", \\\"{x:1549,y:710,t:1527030682566};\\\", \\\"{x:1550,y:708,t:1527030682583};\\\", \\\"{x:1550,y:707,t:1527030682600};\\\", \\\"{x:1550,y:705,t:1527030682705};\\\", \\\"{x:1550,y:704,t:1527030682722};\\\", \\\"{x:1549,y:703,t:1527030682733};\\\", \\\"{x:1549,y:702,t:1527030682750};\\\", \\\"{x:1549,y:701,t:1527030682767};\\\", \\\"{x:1548,y:699,t:1527030682783};\\\", \\\"{x:1548,y:698,t:1527030682800};\\\", \\\"{x:1547,y:697,t:1527030682817};\\\", \\\"{x:1547,y:696,t:1527030682833};\\\", \\\"{x:1546,y:694,t:1527030682891};\\\", \\\"{x:1545,y:694,t:1527030682978};\\\", \\\"{x:1544,y:694,t:1527030683018};\\\", \\\"{x:1543,y:693,t:1527030683033};\\\", \\\"{x:1542,y:692,t:1527030683594};\\\", \\\"{x:1543,y:692,t:1527030683930};\\\", \\\"{x:1544,y:692,t:1527030683953};\\\", \\\"{x:1545,y:692,t:1527030684018};\\\", \\\"{x:1546,y:692,t:1527030684082};\\\", \\\"{x:1547,y:692,t:1527030684097};\\\", \\\"{x:1547,y:693,t:1527030684282};\\\", \\\"{x:1547,y:694,t:1527030684322};\\\", \\\"{x:1547,y:695,t:1527030684361};\\\", \\\"{x:1547,y:696,t:1527030684409};\\\", \\\"{x:1547,y:697,t:1527030684426};\\\", \\\"{x:1547,y:698,t:1527030684514};\\\", \\\"{x:1547,y:696,t:1527030684786};\\\", \\\"{x:1547,y:694,t:1527030684801};\\\", \\\"{x:1547,y:693,t:1527030684818};\\\", \\\"{x:1547,y:692,t:1527030684835};\\\", \\\"{x:1547,y:691,t:1527030684851};\\\", \\\"{x:1547,y:689,t:1527030684868};\\\", \\\"{x:1547,y:688,t:1527030684885};\\\", \\\"{x:1547,y:686,t:1527030684901};\\\", \\\"{x:1546,y:683,t:1527030684918};\\\", \\\"{x:1546,y:680,t:1527030684935};\\\", \\\"{x:1546,y:679,t:1527030684951};\\\", \\\"{x:1546,y:676,t:1527030684968};\\\", \\\"{x:1545,y:672,t:1527030684985};\\\", \\\"{x:1544,y:667,t:1527030685001};\\\", \\\"{x:1543,y:662,t:1527030685018};\\\", \\\"{x:1543,y:659,t:1527030685035};\\\", \\\"{x:1543,y:657,t:1527030685058};\\\", \\\"{x:1543,y:656,t:1527030685068};\\\", \\\"{x:1542,y:655,t:1527030685085};\\\", \\\"{x:1541,y:652,t:1527030685101};\\\", \\\"{x:1541,y:651,t:1527030685122};\\\", \\\"{x:1541,y:650,t:1527030685146};\\\", \\\"{x:1541,y:649,t:1527030685162};\\\", \\\"{x:1541,y:648,t:1527030685169};\\\", \\\"{x:1540,y:647,t:1527030685186};\\\", \\\"{x:1540,y:646,t:1527030685210};\\\", \\\"{x:1539,y:645,t:1527030685225};\\\", \\\"{x:1539,y:644,t:1527030685235};\\\", \\\"{x:1539,y:643,t:1527030685252};\\\", \\\"{x:1539,y:641,t:1527030685268};\\\", \\\"{x:1539,y:640,t:1527030685285};\\\", \\\"{x:1539,y:639,t:1527030685302};\\\", \\\"{x:1539,y:637,t:1527030685318};\\\", \\\"{x:1538,y:636,t:1527030685335};\\\", \\\"{x:1537,y:634,t:1527030685352};\\\", \\\"{x:1537,y:633,t:1527030685393};\\\", \\\"{x:1537,y:632,t:1527030685450};\\\", \\\"{x:1537,y:631,t:1527030685704};\\\", \\\"{x:1537,y:630,t:1527030685777};\\\", \\\"{x:1539,y:628,t:1527030686697};\\\", \\\"{x:1539,y:631,t:1527030686712};\\\", \\\"{x:1539,y:634,t:1527030686721};\\\", \\\"{x:1539,y:635,t:1527030686736};\\\", \\\"{x:1539,y:640,t:1527030686753};\\\", \\\"{x:1540,y:642,t:1527030686768};\\\", \\\"{x:1541,y:645,t:1527030686785};\\\", \\\"{x:1541,y:648,t:1527030686803};\\\", \\\"{x:1541,y:651,t:1527030686819};\\\", \\\"{x:1541,y:654,t:1527030686836};\\\", \\\"{x:1544,y:659,t:1527030686853};\\\", \\\"{x:1545,y:663,t:1527030686869};\\\", \\\"{x:1547,y:669,t:1527030686886};\\\", \\\"{x:1548,y:674,t:1527030686903};\\\", \\\"{x:1552,y:682,t:1527030686919};\\\", \\\"{x:1553,y:688,t:1527030686936};\\\", \\\"{x:1556,y:695,t:1527030686953};\\\", \\\"{x:1559,y:701,t:1527030686969};\\\", \\\"{x:1559,y:705,t:1527030686986};\\\", \\\"{x:1561,y:709,t:1527030687003};\\\", \\\"{x:1562,y:713,t:1527030687019};\\\", \\\"{x:1563,y:716,t:1527030687036};\\\", \\\"{x:1563,y:717,t:1527030687053};\\\", \\\"{x:1564,y:719,t:1527030687069};\\\", \\\"{x:1564,y:722,t:1527030687086};\\\", \\\"{x:1564,y:723,t:1527030687103};\\\", \\\"{x:1565,y:724,t:1527030687119};\\\", \\\"{x:1566,y:725,t:1527030687136};\\\", \\\"{x:1566,y:727,t:1527030687154};\\\", \\\"{x:1566,y:729,t:1527030687169};\\\", \\\"{x:1567,y:730,t:1527030687186};\\\", \\\"{x:1567,y:732,t:1527030687203};\\\", \\\"{x:1567,y:736,t:1527030687219};\\\", \\\"{x:1567,y:738,t:1527030687236};\\\", \\\"{x:1567,y:739,t:1527030687253};\\\", \\\"{x:1567,y:742,t:1527030687269};\\\", \\\"{x:1567,y:746,t:1527030687286};\\\", \\\"{x:1567,y:751,t:1527030687303};\\\", \\\"{x:1567,y:755,t:1527030687320};\\\", \\\"{x:1567,y:759,t:1527030687336};\\\", \\\"{x:1559,y:770,t:1527030687354};\\\", \\\"{x:1538,y:779,t:1527030687369};\\\", \\\"{x:1510,y:789,t:1527030687386};\\\", \\\"{x:1464,y:796,t:1527030687404};\\\", \\\"{x:1391,y:799,t:1527030687421};\\\", \\\"{x:1313,y:799,t:1527030687436};\\\", \\\"{x:1231,y:797,t:1527030687453};\\\", \\\"{x:1145,y:786,t:1527030687470};\\\", \\\"{x:1035,y:776,t:1527030687486};\\\", \\\"{x:926,y:768,t:1527030687503};\\\", \\\"{x:834,y:768,t:1527030687520};\\\", \\\"{x:767,y:768,t:1527030687536};\\\", \\\"{x:708,y:768,t:1527030687553};\\\", \\\"{x:673,y:769,t:1527030687569};\\\", \\\"{x:642,y:773,t:1527030687586};\\\", \\\"{x:617,y:776,t:1527030687603};\\\", \\\"{x:591,y:778,t:1527030687620};\\\", \\\"{x:565,y:781,t:1527030687636};\\\", \\\"{x:542,y:781,t:1527030687653};\\\", \\\"{x:515,y:781,t:1527030687670};\\\", \\\"{x:489,y:778,t:1527030687685};\\\", \\\"{x:468,y:771,t:1527030687702};\\\", \\\"{x:460,y:767,t:1527030687720};\\\", \\\"{x:460,y:765,t:1527030687736};\\\", \\\"{x:462,y:760,t:1527030687753};\\\", \\\"{x:471,y:756,t:1527030687770};\\\", \\\"{x:485,y:756,t:1527030687786};\\\", \\\"{x:493,y:756,t:1527030687803};\\\", \\\"{x:500,y:756,t:1527030687820};\\\", \\\"{x:508,y:754,t:1527030687838};\\\", \\\"{x:509,y:754,t:1527030687852};\\\", \\\"{x:510,y:753,t:1527030687869};\\\", \\\"{x:511,y:753,t:1527030687887};\\\", \\\"{x:513,y:752,t:1527030687920};\\\", \\\"{x:513,y:751,t:1527030687952};\\\", \\\"{x:514,y:751,t:1527030687969};\\\" ] }, { \\\"rt\\\": 30710, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 609259, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -01 PM-X -X -A -A \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:750,t:1527030690001};\\\", \\\"{x:514,y:748,t:1527030690009};\\\", \\\"{x:516,y:746,t:1527030690022};\\\", \\\"{x:517,y:740,t:1527030690039};\\\", \\\"{x:518,y:736,t:1527030690056};\\\", \\\"{x:523,y:729,t:1527030690073};\\\", \\\"{x:529,y:723,t:1527030690090};\\\", \\\"{x:534,y:719,t:1527030690105};\\\", \\\"{x:545,y:714,t:1527030690123};\\\", \\\"{x:558,y:710,t:1527030690140};\\\", \\\"{x:579,y:706,t:1527030690156};\\\", \\\"{x:604,y:705,t:1527030690173};\\\", \\\"{x:637,y:705,t:1527030690190};\\\", \\\"{x:667,y:705,t:1527030690205};\\\", \\\"{x:699,y:705,t:1527030690223};\\\", \\\"{x:733,y:714,t:1527030690240};\\\", \\\"{x:773,y:727,t:1527030690256};\\\", \\\"{x:822,y:746,t:1527030690273};\\\", \\\"{x:841,y:759,t:1527030690290};\\\", \\\"{x:850,y:773,t:1527030690307};\\\", \\\"{x:859,y:790,t:1527030690322};\\\", \\\"{x:868,y:807,t:1527030690340};\\\", \\\"{x:875,y:823,t:1527030690357};\\\", \\\"{x:882,y:832,t:1527030690373};\\\", \\\"{x:887,y:832,t:1527030690390};\\\", \\\"{x:890,y:832,t:1527030690407};\\\", \\\"{x:890,y:833,t:1527030690786};\\\", \\\"{x:891,y:833,t:1527030690793};\\\", \\\"{x:893,y:833,t:1527030690806};\\\", \\\"{x:897,y:835,t:1527030690824};\\\", \\\"{x:899,y:836,t:1527030690840};\\\", \\\"{x:900,y:836,t:1527030690922};\\\", \\\"{x:902,y:836,t:1527030690953};\\\", \\\"{x:904,y:836,t:1527030690961};\\\", \\\"{x:905,y:835,t:1527030690977};\\\", \\\"{x:906,y:835,t:1527030690990};\\\", \\\"{x:906,y:834,t:1527030691007};\\\", \\\"{x:908,y:834,t:1527030691024};\\\", \\\"{x:911,y:831,t:1527030691039};\\\", \\\"{x:918,y:828,t:1527030691058};\\\", \\\"{x:926,y:826,t:1527030691074};\\\", \\\"{x:935,y:823,t:1527030691090};\\\", \\\"{x:947,y:821,t:1527030691107};\\\", \\\"{x:960,y:818,t:1527030691124};\\\", \\\"{x:974,y:817,t:1527030691140};\\\", \\\"{x:985,y:817,t:1527030691157};\\\", \\\"{x:999,y:816,t:1527030691174};\\\", \\\"{x:1011,y:816,t:1527030691190};\\\", \\\"{x:1034,y:816,t:1527030691207};\\\", \\\"{x:1057,y:816,t:1527030691224};\\\", \\\"{x:1080,y:816,t:1527030691240};\\\", \\\"{x:1110,y:816,t:1527030691256};\\\", \\\"{x:1138,y:818,t:1527030691274};\\\", \\\"{x:1172,y:822,t:1527030691291};\\\", \\\"{x:1209,y:827,t:1527030691307};\\\", \\\"{x:1237,y:833,t:1527030691324};\\\", \\\"{x:1273,y:839,t:1527030691341};\\\", \\\"{x:1310,y:844,t:1527030691356};\\\", \\\"{x:1347,y:852,t:1527030691374};\\\", \\\"{x:1377,y:858,t:1527030691390};\\\", \\\"{x:1404,y:863,t:1527030691407};\\\", \\\"{x:1424,y:865,t:1527030691424};\\\", \\\"{x:1453,y:868,t:1527030691441};\\\", \\\"{x:1458,y:869,t:1527030691456};\\\", \\\"{x:1470,y:872,t:1527030691474};\\\", \\\"{x:1475,y:873,t:1527030691491};\\\", \\\"{x:1479,y:873,t:1527030691507};\\\", \\\"{x:1481,y:874,t:1527030691524};\\\", \\\"{x:1482,y:874,t:1527030691541};\\\", \\\"{x:1484,y:874,t:1527030691558};\\\", \\\"{x:1485,y:874,t:1527030691585};\\\", \\\"{x:1486,y:875,t:1527030691593};\\\", \\\"{x:1487,y:876,t:1527030691607};\\\", \\\"{x:1491,y:877,t:1527030691624};\\\", \\\"{x:1499,y:880,t:1527030691641};\\\", \\\"{x:1505,y:881,t:1527030691657};\\\", \\\"{x:1511,y:882,t:1527030691674};\\\", \\\"{x:1515,y:882,t:1527030691691};\\\", \\\"{x:1515,y:884,t:1527030691954};\\\", \\\"{x:1515,y:888,t:1527030691961};\\\", \\\"{x:1514,y:892,t:1527030691974};\\\", \\\"{x:1510,y:900,t:1527030691992};\\\", \\\"{x:1505,y:909,t:1527030692009};\\\", \\\"{x:1498,y:920,t:1527030692025};\\\", \\\"{x:1483,y:936,t:1527030692041};\\\", \\\"{x:1473,y:949,t:1527030692058};\\\", \\\"{x:1465,y:962,t:1527030692075};\\\", \\\"{x:1458,y:976,t:1527030692091};\\\", \\\"{x:1449,y:989,t:1527030692108};\\\", \\\"{x:1443,y:1002,t:1527030692124};\\\", \\\"{x:1433,y:1013,t:1527030692141};\\\", \\\"{x:1428,y:1020,t:1527030692158};\\\", \\\"{x:1423,y:1025,t:1527030692175};\\\", \\\"{x:1419,y:1028,t:1527030692191};\\\", \\\"{x:1417,y:1029,t:1527030692208};\\\", \\\"{x:1414,y:1031,t:1527030692225};\\\", \\\"{x:1410,y:1032,t:1527030692241};\\\", \\\"{x:1406,y:1033,t:1527030692258};\\\", \\\"{x:1403,y:1033,t:1527030692275};\\\", \\\"{x:1403,y:1032,t:1527030692361};\\\", \\\"{x:1403,y:1029,t:1527030692375};\\\", \\\"{x:1407,y:1023,t:1527030692392};\\\", \\\"{x:1413,y:1015,t:1527030692408};\\\", \\\"{x:1421,y:1005,t:1527030692426};\\\", \\\"{x:1425,y:1000,t:1527030692442};\\\", \\\"{x:1426,y:998,t:1527030692458};\\\", \\\"{x:1429,y:995,t:1527030692475};\\\", \\\"{x:1429,y:993,t:1527030692491};\\\", \\\"{x:1429,y:992,t:1527030692508};\\\", \\\"{x:1429,y:990,t:1527030692525};\\\", \\\"{x:1430,y:988,t:1527030692541};\\\", \\\"{x:1430,y:985,t:1527030692558};\\\", \\\"{x:1431,y:982,t:1527030692575};\\\", \\\"{x:1433,y:981,t:1527030692591};\\\", \\\"{x:1434,y:979,t:1527030692608};\\\", \\\"{x:1440,y:974,t:1527030692626};\\\", \\\"{x:1445,y:971,t:1527030692642};\\\", \\\"{x:1448,y:969,t:1527030692658};\\\", \\\"{x:1448,y:968,t:1527030692689};\\\", \\\"{x:1448,y:967,t:1527030692738};\\\", \\\"{x:1445,y:967,t:1527030692745};\\\", \\\"{x:1441,y:967,t:1527030692758};\\\", \\\"{x:1423,y:967,t:1527030692776};\\\", \\\"{x:1409,y:967,t:1527030692792};\\\", \\\"{x:1400,y:967,t:1527030692808};\\\", \\\"{x:1388,y:967,t:1527030692826};\\\", \\\"{x:1386,y:967,t:1527030692843};\\\", \\\"{x:1387,y:967,t:1527030692913};\\\", \\\"{x:1388,y:967,t:1527030692925};\\\", \\\"{x:1395,y:967,t:1527030692943};\\\", \\\"{x:1406,y:967,t:1527030692958};\\\", \\\"{x:1417,y:967,t:1527030692976};\\\", \\\"{x:1428,y:967,t:1527030692992};\\\", \\\"{x:1440,y:967,t:1527030693009};\\\", \\\"{x:1453,y:964,t:1527030693026};\\\", \\\"{x:1458,y:963,t:1527030693043};\\\", \\\"{x:1462,y:962,t:1527030693059};\\\", \\\"{x:1465,y:962,t:1527030693075};\\\", \\\"{x:1467,y:961,t:1527030693092};\\\", \\\"{x:1468,y:961,t:1527030693129};\\\", \\\"{x:1469,y:961,t:1527030693142};\\\", \\\"{x:1471,y:961,t:1527030693159};\\\", \\\"{x:1475,y:961,t:1527030693176};\\\", \\\"{x:1478,y:961,t:1527030693193};\\\", \\\"{x:1481,y:960,t:1527030693210};\\\", \\\"{x:1482,y:960,t:1527030693258};\\\", \\\"{x:1484,y:960,t:1527030693273};\\\", \\\"{x:1485,y:960,t:1527030693298};\\\", \\\"{x:1487,y:960,t:1527030693313};\\\", \\\"{x:1488,y:960,t:1527030693330};\\\", \\\"{x:1489,y:960,t:1527030693361};\\\", \\\"{x:1488,y:960,t:1527030693577};\\\", \\\"{x:1487,y:960,t:1527030693592};\\\", \\\"{x:1483,y:960,t:1527030693610};\\\", \\\"{x:1483,y:958,t:1527030693978};\\\", \\\"{x:1483,y:957,t:1527030694017};\\\", \\\"{x:1483,y:955,t:1527030694033};\\\", \\\"{x:1483,y:954,t:1527030694048};\\\", \\\"{x:1483,y:953,t:1527030694064};\\\", \\\"{x:1483,y:951,t:1527030694076};\\\", \\\"{x:1483,y:949,t:1527030694093};\\\", \\\"{x:1483,y:946,t:1527030694109};\\\", \\\"{x:1483,y:942,t:1527030694126};\\\", \\\"{x:1481,y:939,t:1527030694142};\\\", \\\"{x:1481,y:936,t:1527030694159};\\\", \\\"{x:1480,y:932,t:1527030694176};\\\", \\\"{x:1480,y:929,t:1527030694193};\\\", \\\"{x:1479,y:926,t:1527030694209};\\\", \\\"{x:1479,y:925,t:1527030694226};\\\", \\\"{x:1479,y:921,t:1527030694242};\\\", \\\"{x:1479,y:918,t:1527030694258};\\\", \\\"{x:1477,y:916,t:1527030694276};\\\", \\\"{x:1477,y:914,t:1527030694293};\\\", \\\"{x:1477,y:911,t:1527030694309};\\\", \\\"{x:1477,y:909,t:1527030694326};\\\", \\\"{x:1477,y:908,t:1527030694343};\\\", \\\"{x:1477,y:907,t:1527030694359};\\\", \\\"{x:1477,y:906,t:1527030694376};\\\", \\\"{x:1477,y:904,t:1527030694392};\\\", \\\"{x:1477,y:902,t:1527030694409};\\\", \\\"{x:1477,y:901,t:1527030694426};\\\", \\\"{x:1477,y:900,t:1527030694443};\\\", \\\"{x:1477,y:899,t:1527030694459};\\\", \\\"{x:1477,y:898,t:1527030694505};\\\", \\\"{x:1477,y:896,t:1527030694618};\\\", \\\"{x:1478,y:895,t:1527030694627};\\\", \\\"{x:1478,y:893,t:1527030695697};\\\", \\\"{x:1478,y:892,t:1527030695710};\\\", \\\"{x:1478,y:888,t:1527030695728};\\\", \\\"{x:1478,y:887,t:1527030695744};\\\", \\\"{x:1478,y:885,t:1527030695760};\\\", \\\"{x:1478,y:882,t:1527030695777};\\\", \\\"{x:1478,y:873,t:1527030695794};\\\", \\\"{x:1478,y:865,t:1527030695811};\\\", \\\"{x:1478,y:862,t:1527030695827};\\\", \\\"{x:1478,y:859,t:1527030695844};\\\", \\\"{x:1478,y:856,t:1527030695860};\\\", \\\"{x:1478,y:853,t:1527030695878};\\\", \\\"{x:1478,y:852,t:1527030695897};\\\", \\\"{x:1478,y:850,t:1527030695913};\\\", \\\"{x:1478,y:849,t:1527030695930};\\\", \\\"{x:1478,y:847,t:1527030695945};\\\", \\\"{x:1478,y:846,t:1527030695961};\\\", \\\"{x:1478,y:844,t:1527030695978};\\\", \\\"{x:1478,y:843,t:1527030696001};\\\", \\\"{x:1478,y:841,t:1527030696011};\\\", \\\"{x:1478,y:840,t:1527030696028};\\\", \\\"{x:1478,y:838,t:1527030696044};\\\", \\\"{x:1478,y:836,t:1527030696062};\\\", \\\"{x:1478,y:835,t:1527030696077};\\\", \\\"{x:1478,y:834,t:1527030696095};\\\", \\\"{x:1478,y:833,t:1527030696162};\\\", \\\"{x:1478,y:831,t:1527030697322};\\\", \\\"{x:1477,y:829,t:1527030697329};\\\", \\\"{x:1477,y:827,t:1527030697345};\\\", \\\"{x:1476,y:823,t:1527030697363};\\\", \\\"{x:1476,y:822,t:1527030697378};\\\", \\\"{x:1476,y:820,t:1527030697395};\\\", \\\"{x:1475,y:816,t:1527030697412};\\\", \\\"{x:1474,y:814,t:1527030697429};\\\", \\\"{x:1474,y:811,t:1527030697445};\\\", \\\"{x:1473,y:810,t:1527030697462};\\\", \\\"{x:1473,y:808,t:1527030697478};\\\", \\\"{x:1472,y:805,t:1527030697495};\\\", \\\"{x:1472,y:804,t:1527030697513};\\\", \\\"{x:1471,y:803,t:1527030697529};\\\", \\\"{x:1471,y:800,t:1527030697546};\\\", \\\"{x:1471,y:798,t:1527030697562};\\\", \\\"{x:1471,y:796,t:1527030697579};\\\", \\\"{x:1471,y:794,t:1527030697595};\\\", \\\"{x:1472,y:790,t:1527030697612};\\\", \\\"{x:1474,y:787,t:1527030697628};\\\", \\\"{x:1474,y:785,t:1527030697650};\\\", \\\"{x:1474,y:784,t:1527030697663};\\\", \\\"{x:1475,y:782,t:1527030697679};\\\", \\\"{x:1476,y:780,t:1527030697696};\\\", \\\"{x:1477,y:774,t:1527030697713};\\\", \\\"{x:1479,y:771,t:1527030697729};\\\", \\\"{x:1479,y:767,t:1527030697746};\\\", \\\"{x:1479,y:766,t:1527030697763};\\\", \\\"{x:1481,y:765,t:1527030697778};\\\", \\\"{x:1481,y:764,t:1527030697810};\\\", \\\"{x:1481,y:763,t:1527030697897};\\\", \\\"{x:1481,y:762,t:1527030697921};\\\", \\\"{x:1481,y:761,t:1527030698050};\\\", \\\"{x:1481,y:760,t:1527030698130};\\\", \\\"{x:1481,y:759,t:1527030698146};\\\", \\\"{x:1479,y:757,t:1527030703282};\\\", \\\"{x:1479,y:756,t:1527030703386};\\\", \\\"{x:1478,y:755,t:1527030703400};\\\", \\\"{x:1478,y:754,t:1527030703417};\\\", \\\"{x:1478,y:753,t:1527030703434};\\\", \\\"{x:1478,y:751,t:1527030703450};\\\", \\\"{x:1478,y:750,t:1527030703467};\\\", \\\"{x:1478,y:748,t:1527030703483};\\\", \\\"{x:1478,y:746,t:1527030703500};\\\", \\\"{x:1478,y:745,t:1527030703516};\\\", \\\"{x:1478,y:743,t:1527030703537};\\\", \\\"{x:1478,y:742,t:1527030703553};\\\", \\\"{x:1478,y:739,t:1527030703569};\\\", \\\"{x:1478,y:737,t:1527030703586};\\\", \\\"{x:1478,y:736,t:1527030703599};\\\", \\\"{x:1478,y:732,t:1527030703617};\\\", \\\"{x:1478,y:727,t:1527030703633};\\\", \\\"{x:1478,y:722,t:1527030703650};\\\", \\\"{x:1478,y:719,t:1527030703667};\\\", \\\"{x:1478,y:715,t:1527030703683};\\\", \\\"{x:1478,y:713,t:1527030703699};\\\", \\\"{x:1478,y:712,t:1527030703717};\\\", \\\"{x:1478,y:711,t:1527030703733};\\\", \\\"{x:1478,y:710,t:1527030703750};\\\", \\\"{x:1478,y:709,t:1527030703767};\\\", \\\"{x:1478,y:707,t:1527030703785};\\\", \\\"{x:1478,y:706,t:1527030703801};\\\", \\\"{x:1477,y:705,t:1527030703826};\\\", \\\"{x:1477,y:704,t:1527030703840};\\\", \\\"{x:1477,y:703,t:1527030703850};\\\", \\\"{x:1477,y:702,t:1527030703867};\\\", \\\"{x:1477,y:701,t:1527030703884};\\\", \\\"{x:1477,y:700,t:1527030703899};\\\", \\\"{x:1477,y:699,t:1527030703917};\\\", \\\"{x:1477,y:698,t:1527030703934};\\\", \\\"{x:1477,y:697,t:1527030703953};\\\", \\\"{x:1477,y:696,t:1527030703969};\\\", \\\"{x:1477,y:694,t:1527030703986};\\\", \\\"{x:1477,y:693,t:1527030704025};\\\", \\\"{x:1478,y:692,t:1527030710082};\\\", \\\"{x:1478,y:691,t:1527030710089};\\\", \\\"{x:1478,y:689,t:1527030710105};\\\", \\\"{x:1478,y:688,t:1527030710121};\\\", \\\"{x:1478,y:687,t:1527030710145};\\\", \\\"{x:1478,y:686,t:1527030710193};\\\", \\\"{x:1478,y:685,t:1527030710225};\\\", \\\"{x:1478,y:684,t:1527030710257};\\\", \\\"{x:1478,y:683,t:1527030710273};\\\", \\\"{x:1478,y:682,t:1527030710288};\\\", \\\"{x:1477,y:679,t:1527030710305};\\\", \\\"{x:1477,y:677,t:1527030710321};\\\", \\\"{x:1476,y:674,t:1527030710338};\\\", \\\"{x:1475,y:672,t:1527030710355};\\\", \\\"{x:1474,y:669,t:1527030710371};\\\", \\\"{x:1474,y:667,t:1527030710389};\\\", \\\"{x:1474,y:666,t:1527030710406};\\\", \\\"{x:1472,y:664,t:1527030710422};\\\", \\\"{x:1472,y:663,t:1527030710438};\\\", \\\"{x:1472,y:662,t:1527030710514};\\\", \\\"{x:1472,y:661,t:1527030710521};\\\", \\\"{x:1472,y:660,t:1527030710608};\\\", \\\"{x:1472,y:659,t:1527030710632};\\\", \\\"{x:1472,y:658,t:1527030710640};\\\", \\\"{x:1472,y:657,t:1527030710655};\\\", \\\"{x:1472,y:653,t:1527030710672};\\\", \\\"{x:1472,y:647,t:1527030710688};\\\", \\\"{x:1472,y:639,t:1527030710704};\\\", \\\"{x:1472,y:635,t:1527030710722};\\\", \\\"{x:1472,y:631,t:1527030710737};\\\", \\\"{x:1472,y:625,t:1527030710754};\\\", \\\"{x:1472,y:619,t:1527030710772};\\\", \\\"{x:1472,y:615,t:1527030710788};\\\", \\\"{x:1472,y:611,t:1527030710805};\\\", \\\"{x:1472,y:609,t:1527030710822};\\\", \\\"{x:1472,y:606,t:1527030710837};\\\", \\\"{x:1472,y:604,t:1527030710854};\\\", \\\"{x:1472,y:600,t:1527030710871};\\\", \\\"{x:1472,y:598,t:1527030710888};\\\", \\\"{x:1472,y:593,t:1527030710905};\\\", \\\"{x:1472,y:592,t:1527030710922};\\\", \\\"{x:1473,y:590,t:1527030710939};\\\", \\\"{x:1473,y:589,t:1527030710956};\\\", \\\"{x:1473,y:587,t:1527030710972};\\\", \\\"{x:1473,y:585,t:1527030710989};\\\", \\\"{x:1473,y:583,t:1527030711005};\\\", \\\"{x:1473,y:581,t:1527030711022};\\\", \\\"{x:1475,y:580,t:1527030711039};\\\", \\\"{x:1475,y:578,t:1527030711055};\\\", \\\"{x:1475,y:576,t:1527030711072};\\\", \\\"{x:1475,y:574,t:1527030711088};\\\", \\\"{x:1475,y:571,t:1527030711105};\\\", \\\"{x:1476,y:570,t:1527030711121};\\\", \\\"{x:1476,y:567,t:1527030711139};\\\", \\\"{x:1477,y:565,t:1527030711155};\\\", \\\"{x:1477,y:564,t:1527030711172};\\\", \\\"{x:1477,y:563,t:1527030711189};\\\", \\\"{x:1478,y:562,t:1527030711205};\\\", \\\"{x:1478,y:561,t:1527030711222};\\\", \\\"{x:1478,y:559,t:1527030711239};\\\", \\\"{x:1478,y:558,t:1527030711255};\\\", \\\"{x:1479,y:557,t:1527030711272};\\\", \\\"{x:1480,y:557,t:1527030711573};\\\", \\\"{x:1481,y:558,t:1527030711596};\\\", \\\"{x:1481,y:559,t:1527030711644};\\\", \\\"{x:1481,y:560,t:1527030711701};\\\", \\\"{x:1481,y:561,t:1527030711716};\\\", \\\"{x:1481,y:562,t:1527030711756};\\\", \\\"{x:1481,y:563,t:1527030711780};\\\", \\\"{x:1481,y:564,t:1527030711811};\\\", \\\"{x:1481,y:565,t:1527030713308};\\\", \\\"{x:1481,y:566,t:1527030713315};\\\", \\\"{x:1481,y:567,t:1527030713327};\\\", \\\"{x:1469,y:567,t:1527030713685};\\\", \\\"{x:1441,y:567,t:1527030713693};\\\", \\\"{x:1371,y:567,t:1527030713710};\\\", \\\"{x:1271,y:567,t:1527030713727};\\\", \\\"{x:1166,y:567,t:1527030713743};\\\", \\\"{x:1050,y:567,t:1527030713760};\\\", \\\"{x:947,y:567,t:1527030713779};\\\", \\\"{x:866,y:567,t:1527030713793};\\\", \\\"{x:786,y:567,t:1527030713809};\\\", \\\"{x:697,y:567,t:1527030713828};\\\", \\\"{x:657,y:567,t:1527030713844};\\\", \\\"{x:629,y:567,t:1527030713862};\\\", \\\"{x:610,y:567,t:1527030713877};\\\", \\\"{x:596,y:566,t:1527030713894};\\\", \\\"{x:576,y:561,t:1527030713911};\\\", \\\"{x:553,y:559,t:1527030713927};\\\", \\\"{x:525,y:556,t:1527030713944};\\\", \\\"{x:501,y:556,t:1527030713962};\\\", \\\"{x:481,y:556,t:1527030713978};\\\", \\\"{x:467,y:556,t:1527030713994};\\\", \\\"{x:456,y:556,t:1527030714011};\\\", \\\"{x:449,y:556,t:1527030714027};\\\", \\\"{x:439,y:556,t:1527030714045};\\\", \\\"{x:418,y:556,t:1527030714062};\\\", \\\"{x:396,y:558,t:1527030714078};\\\", \\\"{x:363,y:563,t:1527030714095};\\\", \\\"{x:326,y:568,t:1527030714111};\\\", \\\"{x:284,y:568,t:1527030714127};\\\", \\\"{x:250,y:569,t:1527030714145};\\\", \\\"{x:219,y:569,t:1527030714161};\\\", \\\"{x:189,y:572,t:1527030714178};\\\", \\\"{x:162,y:576,t:1527030714194};\\\", \\\"{x:146,y:580,t:1527030714211};\\\", \\\"{x:144,y:580,t:1527030714229};\\\", \\\"{x:143,y:580,t:1527030714291};\\\", \\\"{x:143,y:581,t:1527030714356};\\\", \\\"{x:143,y:582,t:1527030714363};\\\", \\\"{x:143,y:583,t:1527030714377};\\\", \\\"{x:145,y:583,t:1527030714404};\\\", \\\"{x:146,y:584,t:1527030714411};\\\", \\\"{x:155,y:588,t:1527030714429};\\\", \\\"{x:176,y:592,t:1527030714446};\\\", \\\"{x:210,y:592,t:1527030714463};\\\", \\\"{x:269,y:592,t:1527030714479};\\\", \\\"{x:336,y:592,t:1527030714495};\\\", \\\"{x:413,y:592,t:1527030714511};\\\", \\\"{x:494,y:592,t:1527030714528};\\\", \\\"{x:566,y:592,t:1527030714545};\\\", \\\"{x:636,y:592,t:1527030714562};\\\", \\\"{x:690,y:590,t:1527030714579};\\\", \\\"{x:738,y:583,t:1527030714595};\\\", \\\"{x:781,y:576,t:1527030714612};\\\", \\\"{x:802,y:571,t:1527030714628};\\\", \\\"{x:814,y:567,t:1527030714645};\\\", \\\"{x:820,y:565,t:1527030714661};\\\", \\\"{x:821,y:563,t:1527030714678};\\\", \\\"{x:822,y:563,t:1527030714695};\\\", \\\"{x:822,y:559,t:1527030714712};\\\", \\\"{x:822,y:553,t:1527030714728};\\\", \\\"{x:816,y:547,t:1527030714744};\\\", \\\"{x:801,y:538,t:1527030714762};\\\", \\\"{x:776,y:531,t:1527030714780};\\\", \\\"{x:738,y:519,t:1527030714795};\\\", \\\"{x:715,y:513,t:1527030714812};\\\", \\\"{x:696,y:507,t:1527030714828};\\\", \\\"{x:690,y:505,t:1527030714846};\\\", \\\"{x:689,y:505,t:1527030714863};\\\", \\\"{x:688,y:505,t:1527030714878};\\\", \\\"{x:687,y:504,t:1527030714896};\\\", \\\"{x:686,y:504,t:1527030714912};\\\", \\\"{x:679,y:503,t:1527030714929};\\\", \\\"{x:671,y:503,t:1527030714946};\\\", \\\"{x:661,y:503,t:1527030714963};\\\", \\\"{x:644,y:503,t:1527030714980};\\\", \\\"{x:637,y:503,t:1527030714995};\\\", \\\"{x:629,y:503,t:1527030715013};\\\", \\\"{x:624,y:503,t:1527030715029};\\\", \\\"{x:614,y:506,t:1527030715047};\\\", \\\"{x:608,y:507,t:1527030715063};\\\", \\\"{x:604,y:507,t:1527030715078};\\\", \\\"{x:603,y:507,t:1527030715095};\\\", \\\"{x:602,y:507,t:1527030715188};\\\", \\\"{x:602,y:508,t:1527030715396};\\\", \\\"{x:602,y:508,t:1527030715472};\\\", \\\"{x:600,y:509,t:1527030715507};\\\", \\\"{x:594,y:510,t:1527030715515};\\\", \\\"{x:585,y:512,t:1527030715530};\\\", \\\"{x:551,y:522,t:1527030715545};\\\", \\\"{x:498,y:532,t:1527030715563};\\\", \\\"{x:418,y:544,t:1527030715579};\\\", \\\"{x:380,y:547,t:1527030715596};\\\", \\\"{x:364,y:551,t:1527030715613};\\\", \\\"{x:358,y:553,t:1527030715628};\\\", \\\"{x:356,y:554,t:1527030715645};\\\", \\\"{x:354,y:556,t:1527030715663};\\\", \\\"{x:351,y:559,t:1527030715679};\\\", \\\"{x:344,y:564,t:1527030715695};\\\", \\\"{x:330,y:569,t:1527030715713};\\\", \\\"{x:310,y:574,t:1527030715730};\\\", \\\"{x:291,y:576,t:1527030715745};\\\", \\\"{x:276,y:578,t:1527030715764};\\\", \\\"{x:266,y:580,t:1527030715780};\\\", \\\"{x:264,y:580,t:1527030715795};\\\", \\\"{x:262,y:580,t:1527030715843};\\\", \\\"{x:262,y:581,t:1527030715860};\\\", \\\"{x:262,y:582,t:1527030715867};\\\", \\\"{x:261,y:583,t:1527030715880};\\\", \\\"{x:260,y:584,t:1527030715895};\\\", \\\"{x:260,y:585,t:1527030715915};\\\", \\\"{x:260,y:586,t:1527030715929};\\\", \\\"{x:264,y:588,t:1527030715947};\\\", \\\"{x:282,y:588,t:1527030715964};\\\", \\\"{x:338,y:588,t:1527030715979};\\\", \\\"{x:421,y:588,t:1527030715996};\\\", \\\"{x:510,y:588,t:1527030716013};\\\", \\\"{x:583,y:588,t:1527030716029};\\\", \\\"{x:647,y:589,t:1527030716046};\\\", \\\"{x:700,y:589,t:1527030716063};\\\", \\\"{x:751,y:589,t:1527030716080};\\\", \\\"{x:774,y:589,t:1527030716097};\\\", \\\"{x:789,y:589,t:1527030716113};\\\", \\\"{x:800,y:589,t:1527030716130};\\\", \\\"{x:805,y:589,t:1527030716147};\\\", \\\"{x:815,y:588,t:1527030716163};\\\", \\\"{x:834,y:584,t:1527030716180};\\\", \\\"{x:849,y:582,t:1527030716197};\\\", \\\"{x:864,y:579,t:1527030716213};\\\", \\\"{x:880,y:577,t:1527030716230};\\\", \\\"{x:894,y:573,t:1527030716248};\\\", \\\"{x:899,y:571,t:1527030716263};\\\", \\\"{x:900,y:571,t:1527030716280};\\\", \\\"{x:901,y:570,t:1527030716300};\\\", \\\"{x:902,y:570,t:1527030716313};\\\", \\\"{x:902,y:568,t:1527030716331};\\\", \\\"{x:902,y:563,t:1527030716346};\\\", \\\"{x:898,y:546,t:1527030716362};\\\", \\\"{x:888,y:534,t:1527030716380};\\\", \\\"{x:877,y:526,t:1527030716397};\\\", \\\"{x:865,y:520,t:1527030716413};\\\", \\\"{x:850,y:517,t:1527030716430};\\\", \\\"{x:835,y:511,t:1527030716447};\\\", \\\"{x:825,y:509,t:1527030716464};\\\", \\\"{x:818,y:507,t:1527030716479};\\\", \\\"{x:816,y:506,t:1527030716496};\\\", \\\"{x:817,y:507,t:1527030716612};\\\", \\\"{x:818,y:508,t:1527030716619};\\\", \\\"{x:822,y:510,t:1527030716630};\\\", \\\"{x:824,y:512,t:1527030716647};\\\", \\\"{x:827,y:513,t:1527030716665};\\\", \\\"{x:829,y:514,t:1527030716680};\\\", \\\"{x:830,y:515,t:1527030716697};\\\", \\\"{x:832,y:515,t:1527030716714};\\\", \\\"{x:834,y:515,t:1527030716730};\\\", \\\"{x:835,y:515,t:1527030716747};\\\", \\\"{x:836,y:515,t:1527030716764};\\\", \\\"{x:837,y:515,t:1527030717852};\\\", \\\"{x:840,y:515,t:1527030717867};\\\", \\\"{x:845,y:515,t:1527030717881};\\\", \\\"{x:859,y:515,t:1527030717899};\\\", \\\"{x:879,y:515,t:1527030717915};\\\", \\\"{x:908,y:515,t:1527030717931};\\\", \\\"{x:952,y:512,t:1527030717949};\\\", \\\"{x:983,y:511,t:1527030717965};\\\", \\\"{x:1018,y:504,t:1527030717982};\\\", \\\"{x:1054,y:500,t:1527030717998};\\\", \\\"{x:1080,y:498,t:1527030718015};\\\", \\\"{x:1109,y:488,t:1527030718032};\\\", \\\"{x:1130,y:482,t:1527030718049};\\\", \\\"{x:1151,y:476,t:1527030718065};\\\", \\\"{x:1163,y:471,t:1527030718083};\\\", \\\"{x:1170,y:466,t:1527030718098};\\\", \\\"{x:1175,y:462,t:1527030718115};\\\", \\\"{x:1187,y:453,t:1527030718132};\\\", \\\"{x:1201,y:445,t:1527030718148};\\\", \\\"{x:1219,y:437,t:1527030718165};\\\", \\\"{x:1246,y:428,t:1527030718183};\\\", \\\"{x:1274,y:422,t:1527030718198};\\\", \\\"{x:1305,y:420,t:1527030718215};\\\", \\\"{x:1347,y:416,t:1527030718232};\\\", \\\"{x:1383,y:416,t:1527030718248};\\\", \\\"{x:1415,y:416,t:1527030718265};\\\", \\\"{x:1439,y:416,t:1527030718282};\\\", \\\"{x:1457,y:416,t:1527030718299};\\\", \\\"{x:1471,y:416,t:1527030718315};\\\", \\\"{x:1478,y:416,t:1527030718332};\\\", \\\"{x:1479,y:416,t:1527030718349};\\\", \\\"{x:1479,y:419,t:1527030718500};\\\", \\\"{x:1477,y:422,t:1527030718515};\\\", \\\"{x:1470,y:427,t:1527030718532};\\\", \\\"{x:1465,y:430,t:1527030718550};\\\", \\\"{x:1460,y:431,t:1527030718565};\\\", \\\"{x:1454,y:434,t:1527030718583};\\\", \\\"{x:1450,y:434,t:1527030718599};\\\", \\\"{x:1445,y:435,t:1527030718616};\\\", \\\"{x:1444,y:435,t:1527030718632};\\\", \\\"{x:1443,y:435,t:1527030718652};\\\", \\\"{x:1441,y:435,t:1527030718684};\\\", \\\"{x:1440,y:435,t:1527030718699};\\\", \\\"{x:1434,y:435,t:1527030718716};\\\", \\\"{x:1429,y:435,t:1527030718732};\\\", \\\"{x:1425,y:435,t:1527030718750};\\\", \\\"{x:1421,y:435,t:1527030718766};\\\", \\\"{x:1418,y:435,t:1527030718783};\\\", \\\"{x:1415,y:435,t:1527030718800};\\\", \\\"{x:1412,y:435,t:1527030718816};\\\", \\\"{x:1410,y:435,t:1527030718833};\\\", \\\"{x:1409,y:436,t:1527030718849};\\\", \\\"{x:1406,y:437,t:1527030719204};\\\", \\\"{x:1399,y:438,t:1527030719217};\\\", \\\"{x:1378,y:444,t:1527030719234};\\\", \\\"{x:1346,y:451,t:1527030719249};\\\", \\\"{x:1280,y:478,t:1527030719267};\\\", \\\"{x:1211,y:507,t:1527030719283};\\\", \\\"{x:1119,y:547,t:1527030719300};\\\", \\\"{x:1067,y:569,t:1527030719316};\\\", \\\"{x:1020,y:589,t:1527030719333};\\\", \\\"{x:975,y:611,t:1527030719351};\\\", \\\"{x:927,y:633,t:1527030719368};\\\", \\\"{x:885,y:653,t:1527030719385};\\\", \\\"{x:846,y:672,t:1527030719398};\\\", \\\"{x:801,y:695,t:1527030719416};\\\", \\\"{x:759,y:723,t:1527030719432};\\\", \\\"{x:716,y:746,t:1527030719448};\\\", \\\"{x:679,y:764,t:1527030719466};\\\", \\\"{x:643,y:779,t:1527030719482};\\\", \\\"{x:605,y:793,t:1527030719498};\\\", \\\"{x:585,y:801,t:1527030719515};\\\", \\\"{x:570,y:805,t:1527030719533};\\\", \\\"{x:558,y:807,t:1527030719548};\\\", \\\"{x:547,y:809,t:1527030719566};\\\", \\\"{x:538,y:810,t:1527030719584};\\\", \\\"{x:529,y:812,t:1527030719599};\\\", \\\"{x:521,y:813,t:1527030719616};\\\", \\\"{x:507,y:814,t:1527030719633};\\\", \\\"{x:499,y:815,t:1527030719649};\\\", \\\"{x:494,y:816,t:1527030719666};\\\", \\\"{x:490,y:816,t:1527030719683};\\\", \\\"{x:488,y:816,t:1527030719699};\\\", \\\"{x:481,y:814,t:1527030719716};\\\", \\\"{x:474,y:810,t:1527030719734};\\\", \\\"{x:472,y:806,t:1527030719749};\\\", \\\"{x:472,y:803,t:1527030719766};\\\", \\\"{x:472,y:796,t:1527030719783};\\\", \\\"{x:476,y:788,t:1527030719799};\\\", \\\"{x:488,y:778,t:1527030719817};\\\", \\\"{x:498,y:770,t:1527030719833};\\\", \\\"{x:507,y:764,t:1527030719850};\\\", \\\"{x:515,y:760,t:1527030719866};\\\", \\\"{x:523,y:756,t:1527030719883};\\\", \\\"{x:523,y:755,t:1527030719899};\\\", \\\"{x:524,y:755,t:1527030719923};\\\", \\\"{x:524,y:754,t:1527030719933};\\\", \\\"{x:525,y:752,t:1527030719956};\\\", \\\"{x:526,y:752,t:1527030719966};\\\", \\\"{x:526,y:751,t:1527030720555};\\\" ] }, { \\\"rt\\\": 40614, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 651145, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"you look at the x axis and the you look at the points that correspond to the 12pm tick by creating an imaginary vertical line\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 4340, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"usa\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 656489, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 11190, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 668700, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 6977, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 676761, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"2KONX\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"2KONX\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 110, dom: 634, initialDom: 731",
  "javascriptErrors": []
}