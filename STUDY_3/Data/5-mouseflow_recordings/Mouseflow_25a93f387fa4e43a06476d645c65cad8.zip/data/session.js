var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "25a93f387fa4e43a06476d645c65cad8",
  "created": "2018-05-22T13:15:38.2688136-07:00",
  "lastActivity": "2018-05-22T13:15:41.7438136-07:00",
  "pageViews": [
    {
      "id": "05223860cb35f99a5e969fbef3cb3bf6797735a5",
      "startTime": "2018-05-22T13:15:38.2688136-07:00",
      "endTime": "2018-05-22T13:15:41.7438136-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 3475,
      "engagementTime": 3475,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 3475,
  "engagementTime": 3475,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=H2N27",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6e81af2c2bee404322b54ff83271cc02",
  "gdpr": false
}