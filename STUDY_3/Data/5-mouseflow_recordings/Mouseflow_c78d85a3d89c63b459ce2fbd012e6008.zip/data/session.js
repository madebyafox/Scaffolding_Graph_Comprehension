var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c78d85a3d89c63b459ce2fbd012e6008",
  "created": "2018-05-14T13:10:28.5670368-07:00",
  "lastActivity": "2018-05-14T13:11:34.2840368-07:00",
  "pageViews": [
    {
      "id": "0514283296ab00188afe2bc88389502168cc130b",
      "startTime": "2018-05-14T13:10:28.5670368-07:00",
      "endTime": "2018-05-14T13:11:34.2840368-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 65717,
      "engagementTime": 61388,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 65717,
  "engagementTime": 61388,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CKRHQ",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8fe021dceca0e2bd7566a079e3e34046",
  "gdpr": false
}