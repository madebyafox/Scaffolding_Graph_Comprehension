var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b256e2f5110273c58a6db8fc973dd290",
  "created": "2018-05-29T16:16:05.6129247-07:00",
  "lastActivity": "2018-05-29T16:16:12.5569247-07:00",
  "pageViews": [
    {
      "id": "05290568b41a12a8d096e0f6d534de8fe8f08dcb",
      "startTime": "2018-05-29T16:16:05.6129247-07:00",
      "endTime": "2018-05-29T16:16:12.5569247-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 6944,
      "engagementTime": 6770,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 6944,
  "engagementTime": 6770,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=0CR6Z",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "60348814b32c925443f50992c6da0b74",
  "gdpr": false
}