var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "35ae63e810c80c6a73ee58e75e04158a",
  "created": "2018-05-18T11:17:24.146548-07:00",
  "lastActivity": "2018-05-18T11:18:33.282548-07:00",
  "pageViews": [
    {
      "id": "05182412898f61686daf8e9cabe822d275a6407a",
      "startTime": "2018-05-18T11:17:24.146548-07:00",
      "endTime": "2018-05-18T11:18:33.282548-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 69136,
      "engagementTime": 55164,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 69136,
  "engagementTime": 55164,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=OY8PV",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "53335aecefdfe703245ebb2a65747f64",
  "gdpr": false
}