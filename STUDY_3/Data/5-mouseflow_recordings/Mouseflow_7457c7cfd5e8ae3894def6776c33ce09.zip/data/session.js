var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7457c7cfd5e8ae3894def6776c33ce09",
  "created": "2018-05-22T10:18:43.4974026-07:00",
  "lastActivity": "2018-05-22T10:19:03.2554026-07:00",
  "pageViews": [
    {
      "id": "0522438545c70a82a337b56fcd16fca458946183",
      "startTime": "2018-05-22T10:18:43.4974026-07:00",
      "endTime": "2018-05-22T10:19:03.2554026-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 19758,
      "engagementTime": 19758,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 19758,
  "engagementTime": 19758,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=808YR",
    "CONDITION=121",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0f4672735fcd810c3c0952bcae5ff3ad",
  "gdpr": false
}