var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "82b1ba063055ab94f3fabaf3a0469442",
  "created": "2018-05-25T10:14:17.43123-07:00",
  "lastActivity": "2018-05-25T10:15:28.3168497-07:00",
  "pageViews": [
    {
      "id": "0525178448c044a467c894811c15d20dd290d639",
      "startTime": "2018-05-25T10:14:17.5115557-07:00",
      "endTime": "2018-05-25T10:15:28.3168497-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 71083,
      "engagementTime": 55142,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 71083,
  "engagementTime": 55142,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b2860d84fd68eead12ea1e43b40c6ae5",
  "gdpr": false
}