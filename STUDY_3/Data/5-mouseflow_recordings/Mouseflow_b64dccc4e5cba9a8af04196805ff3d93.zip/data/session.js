var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b64dccc4e5cba9a8af04196805ff3d93",
  "created": "2018-05-18T11:11:44.7110243-07:00",
  "lastActivity": "2018-05-18T11:12:00.046838-07:00",
  "pageViews": [
    {
      "id": "05184484902004eb18256b06aee2decce2886c59",
      "startTime": "2018-05-18T11:11:44.738838-07:00",
      "endTime": "2018-05-18T11:12:00.046838-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 15308,
      "engagementTime": 14859,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15308,
  "engagementTime": 14859,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8U980",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "80d63ccc3e0ae51a5bdbc27f8cd75af9",
  "gdpr": false
}