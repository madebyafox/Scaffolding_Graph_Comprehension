var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "46c1dd56d4322773b8957b7275a68c0d",
  "created": "2018-05-18T11:17:53.9106276-07:00",
  "lastActivity": "2018-05-18T11:20:09.0656276-07:00",
  "pageViews": [
    {
      "id": "05185320f178f3c41e5602ce36e2716074f5bceb",
      "startTime": "2018-05-18T11:17:53.9106276-07:00",
      "endTime": "2018-05-18T11:20:09.0656276-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 135155,
      "engagementTime": 103292,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 135155,
  "engagementTime": 103292,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.49",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TCH5L",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "198cfce4c9aa4ce60ef053f30b54a108",
  "gdpr": false
}