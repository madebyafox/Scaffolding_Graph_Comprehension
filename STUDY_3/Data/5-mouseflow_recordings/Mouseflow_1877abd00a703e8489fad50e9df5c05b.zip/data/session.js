var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1877abd00a703e8489fad50e9df5c05b",
  "created": "2018-05-18T11:14:47.3713948-07:00",
  "lastActivity": "2018-05-18T11:15:06.4933948-07:00",
  "pageViews": [
    {
      "id": "05184791140046c69fe0e0bfc2c1cce29faa975b",
      "startTime": "2018-05-18T11:14:47.3713948-07:00",
      "endTime": "2018-05-18T11:15:06.4933948-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 19122,
      "engagementTime": 19066,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 19122,
  "engagementTime": 19066,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.45",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=N8G60",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f77663bbafdb39a30e3fade0ba33f18a",
  "gdpr": false
}