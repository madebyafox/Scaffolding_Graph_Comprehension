var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "750770ba1f21690682878397464191ab",
  "created": "2018-05-29T15:03:21.3421679-07:00",
  "lastActivity": "2018-05-29T15:07:23.7072418-07:00",
  "pageViews": [
    {
      "id": "05292102828d100583a4f6503faacc52bfade3cc",
      "startTime": "2018-05-29T15:03:21.3421679-07:00",
      "endTime": "2018-05-29T15:07:23.7072418-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 242702,
      "engagementTime": 52837,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 242702,
  "engagementTime": 52837,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0ce7d756c7d8d71459519b8596bc7af5",
  "gdpr": false
}