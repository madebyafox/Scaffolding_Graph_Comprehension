var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05224402cff73884fe52cefb8b6ecee648a69f7c"] = {
  "startTime": "2018-05-22T23:00:43.951996Z",
  "websitePageUrl": "/",
  "visitTime": 58724,
  "engagementTime": 37075,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "a4da9f0e8a838d5068e98958cce36bc3",
    "created": "2018-05-22T23:00:43.951996+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "aac220e87384a98d4282f49857d019a3",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/a4da9f0e8a838d5068e98958cce36bc3/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 365,
      "e": 365,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 1378,
      "y": 776
    },
    {
      "t": 2202,
      "e": 2202,
      "ty": 2,
      "x": 1331,
      "y": 801
    },
    {
      "t": 2252,
      "e": 2252,
      "ty": 41,
      "x": 49069,
      "y": 55581,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 1221,
      "y": 842
    },
    {
      "t": 2402,
      "e": 2402,
      "ty": 2,
      "x": 1216,
      "y": 843
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 46775,
      "y": 57056,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5402,
      "e": 5402,
      "ty": 2,
      "x": 1205,
      "y": 841
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1185,
      "y": 837
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 41,
      "x": 45082,
      "y": 56564,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5616,
      "e": 5616,
      "ty": 3,
      "x": 1185,
      "y": 837,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5744,
      "e": 5744,
      "ty": 4,
      "x": 45082,
      "y": 56564,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5744,
      "e": 5744,
      "ty": 5,
      "x": 1185,
      "y": 837,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7804,
      "e": 7804,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 1,
      "x": 0,
      "y": 10
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 8752,
      "e": 8752,
      "ty": 41,
      "x": 40395,
      "y": 51113,
      "ta": "html > body"
    },
    {
      "t": 8803,
      "e": 8803,
      "ty": 2,
      "x": 1179,
      "y": 845
    },
    {
      "t": 8901,
      "e": 8901,
      "ty": 2,
      "x": 1123,
      "y": 825
    },
    {
      "t": 8952,
      "e": 8952,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 2,
      "x": 925,
      "y": 761
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 31070,
      "y": 53111,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 9100,
      "e": 9100,
      "ty": 2,
      "x": 902,
      "y": 536
    },
    {
      "t": 9200,
      "e": 9200,
      "ty": 2,
      "x": 1052,
      "y": 327
    },
    {
      "t": 9251,
      "e": 9251,
      "ty": 41,
      "x": 40122,
      "y": 50711,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 9300,
      "e": 9300,
      "ty": 2,
      "x": 1120,
      "y": 313
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 41,
      "x": 40663,
      "y": 50711,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 9601,
      "e": 9601,
      "ty": 2,
      "x": 1129,
      "y": 313
    },
    {
      "t": 9701,
      "e": 9701,
      "ty": 2,
      "x": 1317,
      "y": 427
    },
    {
      "t": 9751,
      "e": 9751,
      "ty": 41,
      "x": 50404,
      "y": 20284,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 9801,
      "e": 9801,
      "ty": 2,
      "x": 1318,
      "y": 428
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10100,
      "e": 10100,
      "ty": 2,
      "x": 1299,
      "y": 503
    },
    {
      "t": 10201,
      "e": 10201,
      "ty": 2,
      "x": 1105,
      "y": 869
    },
    {
      "t": 10228,
      "e": 10228,
      "ty": 6,
      "x": 1014,
      "y": 993,
      "ta": "#start"
    },
    {
      "t": 10243,
      "e": 10243,
      "ty": 7,
      "x": 970,
      "y": 1048,
      "ta": "#start"
    },
    {
      "t": 10251,
      "e": 10251,
      "ty": 41,
      "x": 37682,
      "y": 43027,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 10263,
      "e": 10263,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 10300,
      "e": 10300,
      "ty": 2,
      "x": 935,
      "y": 1096
    },
    {
      "t": 10500,
      "e": 10500,
      "ty": 2,
      "x": 831,
      "y": 1068
    },
    {
      "t": 10500,
      "e": 10500,
      "ty": 41,
      "x": 28342,
      "y": 64500,
      "ta": "> div.masterdiv"
    },
    {
      "t": 10600,
      "e": 10600,
      "ty": 2,
      "x": 797,
      "y": 954
    },
    {
      "t": 10701,
      "e": 10701,
      "ty": 2,
      "x": 790,
      "y": 879
    },
    {
      "t": 10751,
      "e": 10751,
      "ty": 41,
      "x": 24674,
      "y": 47456,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 10800,
      "e": 10800,
      "ty": 2,
      "x": 803,
      "y": 872
    },
    {
      "t": 10900,
      "e": 10900,
      "ty": 2,
      "x": 827,
      "y": 875
    },
    {
      "t": 11000,
      "e": 11000,
      "ty": 2,
      "x": 828,
      "y": 876
    },
    {
      "t": 11002,
      "e": 11002,
      "ty": 41,
      "x": 5157,
      "y": 62556,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 11200,
      "e": 11200,
      "ty": 2,
      "x": 824,
      "y": 875
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 41,
      "x": 4317,
      "y": 59577,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 11312,
      "e": 11312,
      "ty": 3,
      "x": 824,
      "y": 875,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 11432,
      "e": 11432,
      "ty": 4,
      "x": 4317,
      "y": 59577,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 11433,
      "e": 11433,
      "ty": 5,
      "x": 824,
      "y": 875,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 11434,
      "e": 11434,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 11441,
      "e": 11441,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 11751,
      "e": 11751,
      "ty": 41,
      "x": 28659,
      "y": 59503,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 11801,
      "e": 11801,
      "ty": 2,
      "x": 951,
      "y": 944
    },
    {
      "t": 11844,
      "e": 11844,
      "ty": 6,
      "x": 999,
      "y": 982,
      "ta": "#start"
    },
    {
      "t": 11901,
      "e": 11901,
      "ty": 2,
      "x": 1006,
      "y": 996
    },
    {
      "t": 12000,
      "e": 12000,
      "ty": 2,
      "x": 1005,
      "y": 1007
    },
    {
      "t": 12001,
      "e": 12001,
      "ty": 41,
      "x": 52154,
      "y": 57252,
      "ta": "#start"
    },
    {
      "t": 12101,
      "e": 12101,
      "ty": 2,
      "x": 1002,
      "y": 1009
    },
    {
      "t": 12200,
      "e": 12200,
      "ty": 2,
      "x": 1002,
      "y": 1007
    },
    {
      "t": 12251,
      "e": 12251,
      "ty": 41,
      "x": 50516,
      "y": 53397,
      "ta": "#start"
    },
    {
      "t": 12300,
      "e": 12300,
      "ty": 2,
      "x": 1002,
      "y": 1005
    },
    {
      "t": 12401,
      "e": 12401,
      "ty": 2,
      "x": 1002,
      "y": 1004
    },
    {
      "t": 12501,
      "e": 12501,
      "ty": 41,
      "x": 50516,
      "y": 51470,
      "ta": "#start"
    },
    {
      "t": 12545,
      "e": 12545,
      "ty": 7,
      "x": 987,
      "y": 1012,
      "ta": "#start"
    },
    {
      "t": 12600,
      "e": 12600,
      "ty": 2,
      "x": 914,
      "y": 1038
    },
    {
      "t": 12701,
      "e": 12701,
      "ty": 2,
      "x": 768,
      "y": 1002
    },
    {
      "t": 12751,
      "e": 12751,
      "ty": 41,
      "x": 25070,
      "y": 59206,
      "ta": "> div.masterdiv"
    },
    {
      "t": 12801,
      "e": 12801,
      "ty": 2,
      "x": 734,
      "y": 976
    },
    {
      "t": 12900,
      "e": 12900,
      "ty": 2,
      "x": 733,
      "y": 973
    },
    {
      "t": 13001,
      "e": 13001,
      "ty": 41,
      "x": 21624,
      "y": 65208,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 13400,
      "e": 13400,
      "ty": 2,
      "x": 955,
      "y": 916
    },
    {
      "t": 13501,
      "e": 13501,
      "ty": 2,
      "x": 1678,
      "y": 906
    },
    {
      "t": 13501,
      "e": 13501,
      "ty": 41,
      "x": 57511,
      "y": 54642,
      "ta": "> div.masterdiv"
    },
    {
      "t": 13600,
      "e": 13600,
      "ty": 2,
      "x": 1781,
      "y": 881
    },
    {
      "t": 13751,
      "e": 13751,
      "ty": 41,
      "x": 61058,
      "y": 53121,
      "ta": "> div.masterdiv"
    },
    {
      "t": 16401,
      "e": 16401,
      "ty": 2,
      "x": 1774,
      "y": 881
    },
    {
      "t": 16501,
      "e": 16501,
      "ty": 2,
      "x": 1768,
      "y": 881
    },
    {
      "t": 16501,
      "e": 16501,
      "ty": 41,
      "x": 60610,
      "y": 53121,
      "ta": "> div.masterdiv"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 26601,
      "e": 21501,
      "ty": 2,
      "x": 1865,
      "y": 868
    },
    {
      "t": 26702,
      "e": 21602,
      "ty": 2,
      "x": 1919,
      "y": 840
    },
    {
      "t": 26802,
      "e": 21702,
      "ty": 2,
      "x": 1919,
      "y": 831
    },
    {
      "t": 27201,
      "e": 22101,
      "ty": 2,
      "x": 1919,
      "y": 830
    },
    {
      "t": 34501,
      "e": 27101,
      "ty": 2,
      "x": 1919,
      "y": 829
    },
    {
      "t": 34560,
      "e": 27160,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 34601,
      "e": 27201,
      "ty": 2,
      "x": 1919,
      "y": 129
    },
    {
      "t": 37801,
      "e": 30401,
      "ty": 2,
      "x": 218,
      "y": 43
    },
    {
      "t": 37901,
      "e": 30501,
      "ty": 2,
      "x": 302,
      "y": 219
    },
    {
      "t": 38000,
      "e": 30600,
      "ty": 2,
      "x": 497,
      "y": 379
    },
    {
      "t": 38001,
      "e": 30601,
      "ty": 41,
      "x": 10013,
      "y": 7541,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 38101,
      "e": 30701,
      "ty": 2,
      "x": 558,
      "y": 401
    },
    {
      "t": 38201,
      "e": 30801,
      "ty": 2,
      "x": 700,
      "y": 428
    },
    {
      "t": 38251,
      "e": 30851,
      "ty": 41,
      "x": 20886,
      "y": 21324,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 38300,
      "e": 30900,
      "ty": 2,
      "x": 718,
      "y": 432
    },
    {
      "t": 38401,
      "e": 31001,
      "ty": 2,
      "x": 627,
      "y": 396
    },
    {
      "t": 38501,
      "e": 31101,
      "ty": 2,
      "x": 395,
      "y": 358
    },
    {
      "t": 38501,
      "e": 31101,
      "ty": 41,
      "x": 4995,
      "y": 2080,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 38601,
      "e": 31201,
      "ty": 2,
      "x": 27,
      "y": 315
    },
    {
      "t": 38701,
      "e": 31301,
      "ty": 2,
      "x": 0,
      "y": 315
    },
    {
      "t": 38752,
      "e": 31352,
      "ty": 41,
      "x": 0,
      "y": 19167,
      "ta": "html"
    },
    {
      "t": 40001,
      "e": 32601,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 58001,
      "e": 36352,
      "ty": 2,
      "x": 0,
      "y": 137
    },
    {
      "t": 58001,
      "e": 36352,
      "ty": 41,
      "x": 0,
      "y": 8336,
      "ta": "html"
    },
    {
      "t": 58047,
      "e": 36398,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 58100,
      "e": 36451,
      "ty": 2,
      "x": 0,
      "y": 30
    },
    {
      "t": 58251,
      "e": 36602,
      "ty": 41,
      "x": 0,
      "y": 1825,
      "ta": "html"
    },
    {
      "t": 58724,
      "e": 37075,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 178, dom: 362, initialDom: 367",
  "javascriptErrors": []
}