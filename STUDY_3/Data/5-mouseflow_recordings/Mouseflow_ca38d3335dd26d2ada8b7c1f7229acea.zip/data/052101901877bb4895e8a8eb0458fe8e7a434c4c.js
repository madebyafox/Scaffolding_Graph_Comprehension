var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052101901877bb4895e8a8eb0458fe8e7a434c4c"] = {
  "startTime": "2018-05-21T19:18:00.8271498Z",
  "websitePageUrl": "/16",
  "visitTime": 184306,
  "engagementTime": 167773,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "ca38d3335dd26d2ada8b7c1f7229acea",
    "created": "2018-05-21T19:18:00.8271498+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=CK5DF",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "a2e35000e9b682866472ad256cc9ddc4",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/ca38d3335dd26d2ada8b7c1f7229acea/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 305,
      "e": 305,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1182,
      "e": 1182,
      "ty": 6,
      "x": 455,
      "y": 662,
      "ta": "#strategyButton"
    },
    {
      "t": 1198,
      "e": 1198,
      "ty": 7,
      "x": 438,
      "y": 628,
      "ta": "#strategyButton"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 438,
      "y": 628
    },
    {
      "t": 1216,
      "e": 1216,
      "ty": 6,
      "x": 412,
      "y": 590,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1248,
      "e": 1248,
      "ty": 7,
      "x": 343,
      "y": 497,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 27642,
      "y": 5302,
      "ta": "#.strategy > p"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 249,
      "y": 419
    },
    {
      "t": 1402,
      "e": 1402,
      "ty": 2,
      "x": 247,
      "y": 420
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 248,
      "y": 420
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 16963,
      "y": 22823,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 255,
      "y": 425
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 19548,
      "y": 23599,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 278,
      "y": 436
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 310,
      "y": 469
    },
    {
      "t": 2469,
      "e": 2469,
      "ty": 6,
      "x": 347,
      "y": 529,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 364,
      "y": 559
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 30002,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 390,
      "y": 587
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 34386,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 409,
      "y": 578
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 417,
      "y": 574
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 418,
      "y": 574
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 36073,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3083,
      "e": 3083,
      "ty": 3,
      "x": 418,
      "y": 574,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3085,
      "e": 3085,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3258,
      "e": 3258,
      "ty": 4,
      "x": 36073,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3258,
      "e": 3258,
      "ty": 5,
      "x": 418,
      "y": 574,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 7,
      "x": 737,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3603,
      "e": 3603,
      "ty": 2,
      "x": 737,
      "y": 601
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 1408,
      "y": 782
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 53486,
      "y": 49921,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 1623,
      "y": 869
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 1732,
      "y": 932
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 1727,
      "y": 947
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 60088,
      "y": 57440,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 1717,
      "y": 956
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 1708,
      "y": 959
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 63774,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 1686,
      "y": 966
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 1664,
      "y": 965
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 1585,
      "y": 928
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 41,
      "x": 56304,
      "y": 56582,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1339,
      "y": 860
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 1204,
      "y": 839
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 29386,
      "y": 50207,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1203,
      "y": 839
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1197,
      "y": 840
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1189,
      "y": 842
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 28329,
      "y": 50494,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 1187,
      "y": 843
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1184,
      "y": 846
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 1183,
      "y": 846
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 27976,
      "y": 50709,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6752,
      "e": 6752,
      "ty": 41,
      "x": 27976,
      "y": 50923,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1182,
      "y": 860
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1182,
      "y": 879
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 1184,
      "y": 900
    },
    {
      "t": 7002,
      "e": 7002,
      "ty": 41,
      "x": 21930,
      "y": 52792,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[13] > circle"
    },
    {
      "t": 7102,
      "e": 7102,
      "ty": 2,
      "x": 1184,
      "y": 904
    },
    {
      "t": 7252,
      "e": 7252,
      "ty": 41,
      "x": 28047,
      "y": 54863,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7401,
      "e": 7401,
      "ty": 2,
      "x": 1194,
      "y": 965
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1195,
      "y": 986
    },
    {
      "t": 7502,
      "e": 7502,
      "ty": 41,
      "x": 28822,
      "y": 60736,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 1188,
      "y": 997
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 1186,
      "y": 997
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 28188,
      "y": 61524,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 1185,
      "y": 997
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 2,
      "x": 1181,
      "y": 996
    },
    {
      "t": 8002,
      "e": 8002,
      "ty": 41,
      "x": 27835,
      "y": 61452,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 1178,
      "y": 994
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 1176,
      "y": 993
    },
    {
      "t": 8252,
      "e": 8252,
      "ty": 41,
      "x": 27483,
      "y": 61094,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8301,
      "e": 8301,
      "ty": 2,
      "x": 1176,
      "y": 991
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 1176,
      "y": 990
    },
    {
      "t": 8502,
      "e": 8502,
      "ty": 41,
      "x": 27483,
      "y": 61022,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 1176,
      "y": 984
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 1180,
      "y": 978
    },
    {
      "t": 8752,
      "e": 8752,
      "ty": 41,
      "x": 27765,
      "y": 60091,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8852,
      "e": 8852,
      "ty": 2,
      "x": 1180,
      "y": 976
    },
    {
      "t": 8901,
      "e": 8901,
      "ty": 2,
      "x": 1180,
      "y": 975
    },
    {
      "t": 9002,
      "e": 9002,
      "ty": 41,
      "x": 27765,
      "y": 59948,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9251,
      "e": 9251,
      "ty": 41,
      "x": 27694,
      "y": 59733,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9301,
      "e": 9301,
      "ty": 2,
      "x": 1178,
      "y": 970
    },
    {
      "t": 9401,
      "e": 9401,
      "ty": 2,
      "x": 1176,
      "y": 966
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 41,
      "x": 27483,
      "y": 59303,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9802,
      "e": 9802,
      "ty": 2,
      "x": 1173,
      "y": 966
    },
    {
      "t": 9901,
      "e": 9901,
      "ty": 2,
      "x": 1170,
      "y": 966
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10003,
      "e": 10003,
      "ty": 41,
      "x": 27060,
      "y": 59303,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10201,
      "e": 10201,
      "ty": 2,
      "x": 1167,
      "y": 966
    },
    {
      "t": 10252,
      "e": 10252,
      "ty": 41,
      "x": 26778,
      "y": 59375,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10301,
      "e": 10301,
      "ty": 2,
      "x": 1161,
      "y": 968
    },
    {
      "t": 10402,
      "e": 10402,
      "ty": 2,
      "x": 1159,
      "y": 969
    },
    {
      "t": 10502,
      "e": 10502,
      "ty": 41,
      "x": 42230,
      "y": 255,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 2,
      "x": 1191,
      "y": 945
    },
    {
      "t": 11502,
      "e": 11502,
      "ty": 41,
      "x": 28540,
      "y": 57799,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12601,
      "e": 12601,
      "ty": 2,
      "x": 1191,
      "y": 944
    },
    {
      "t": 12701,
      "e": 12701,
      "ty": 2,
      "x": 1190,
      "y": 944
    },
    {
      "t": 12752,
      "e": 12752,
      "ty": 41,
      "x": 28470,
      "y": 57728,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12902,
      "e": 12902,
      "ty": 2,
      "x": 1188,
      "y": 944
    },
    {
      "t": 13002,
      "e": 13002,
      "ty": 41,
      "x": 28329,
      "y": 57728,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 13101,
      "e": 13101,
      "ty": 2,
      "x": 1185,
      "y": 944
    },
    {
      "t": 13201,
      "e": 13201,
      "ty": 2,
      "x": 1184,
      "y": 944
    },
    {
      "t": 13252,
      "e": 13252,
      "ty": 41,
      "x": 28047,
      "y": 57728,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 13302,
      "e": 13302,
      "ty": 2,
      "x": 1181,
      "y": 944
    },
    {
      "t": 13401,
      "e": 13401,
      "ty": 2,
      "x": 1165,
      "y": 952
    },
    {
      "t": 13501,
      "e": 13501,
      "ty": 2,
      "x": 1159,
      "y": 954
    },
    {
      "t": 13502,
      "e": 13502,
      "ty": 41,
      "x": 26285,
      "y": 58444,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 13601,
      "e": 13601,
      "ty": 2,
      "x": 1146,
      "y": 960
    },
    {
      "t": 13752,
      "e": 13752,
      "ty": 41,
      "x": 25369,
      "y": 58874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 14302,
      "e": 14302,
      "ty": 2,
      "x": 1147,
      "y": 967
    },
    {
      "t": 14401,
      "e": 14401,
      "ty": 2,
      "x": 1155,
      "y": 973
    },
    {
      "t": 14502,
      "e": 14502,
      "ty": 41,
      "x": 35750,
      "y": 16639,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 15402,
      "e": 15402,
      "ty": 2,
      "x": 1148,
      "y": 953
    },
    {
      "t": 15501,
      "e": 15501,
      "ty": 2,
      "x": 1146,
      "y": 949
    },
    {
      "t": 15502,
      "e": 15502,
      "ty": 41,
      "x": 62265,
      "y": 62094,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[18]"
    },
    {
      "t": 17002,
      "e": 17002,
      "ty": 2,
      "x": 1132,
      "y": 861
    },
    {
      "t": 17002,
      "e": 17002,
      "ty": 41,
      "x": 24382,
      "y": 51783,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17102,
      "e": 17102,
      "ty": 2,
      "x": 1127,
      "y": 801
    },
    {
      "t": 17201,
      "e": 17201,
      "ty": 2,
      "x": 1135,
      "y": 767
    },
    {
      "t": 17252,
      "e": 17252,
      "ty": 41,
      "x": 24594,
      "y": 44979,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17301,
      "e": 17301,
      "ty": 2,
      "x": 1135,
      "y": 766
    },
    {
      "t": 17500,
      "e": 17500,
      "ty": 2,
      "x": 1151,
      "y": 773
    },
    {
      "t": 17501,
      "e": 17501,
      "ty": 41,
      "x": 25721,
      "y": 45480,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17601,
      "e": 17601,
      "ty": 2,
      "x": 1494,
      "y": 859
    },
    {
      "t": 17700,
      "e": 17700,
      "ty": 2,
      "x": 1611,
      "y": 829
    },
    {
      "t": 17752,
      "e": 17752,
      "ty": 41,
      "x": 59546,
      "y": 48846,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17801,
      "e": 17801,
      "ty": 2,
      "x": 1636,
      "y": 819
    },
    {
      "t": 18001,
      "e": 18001,
      "ty": 41,
      "x": 59898,
      "y": 48775,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 29136,
      "e": 23001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 29635,
      "e": 23500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 29668,
      "e": 23533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 29700,
      "e": 23565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 29719,
      "e": 23584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 30142,
      "e": 24007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 30326,
      "e": 24191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 30327,
      "e": 24192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30390,
      "e": 24255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "R"
    },
    {
      "t": 30462,
      "e": 24327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30462,
      "e": 24327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30534,
      "e": 24399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Re"
    },
    {
      "t": 30678,
      "e": 24543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30679,
      "e": 24544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30718,
      "e": 24583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Rea"
    },
    {
      "t": 30886,
      "e": 24751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 30887,
      "e": 24752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30894,
      "e": 24759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read"
    },
    {
      "t": 31003,
      "e": 24868,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read"
    },
    {
      "t": 31095,
      "e": 24960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31167,
      "e": 25032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31167,
      "e": 25032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31389,
      "e": 25254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31815,
      "e": 25680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31815,
      "e": 25680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31910,
      "e": 25775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32198,
      "e": 26063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32286,
      "e": 26151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read "
    },
    {
      "t": 32798,
      "e": 26663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32800,
      "e": 26665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32878,
      "e": 26743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32926,
      "e": 26791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32926,
      "e": 26791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32999,
      "e": 26864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 33014,
      "e": 26879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33014,
      "e": 26879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33110,
      "e": 26975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 33152,
      "e": 27017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33152,
      "e": 27017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33261,
      "e": 27126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33479,
      "e": 27344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 33479,
      "e": 27344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33603,
      "e": 27468,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x"
    },
    {
      "t": 33622,
      "e": 27487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 33655,
      "e": 27520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33655,
      "e": 27520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33775,
      "e": 27640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33855,
      "e": 27720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 33855,
      "e": 27720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33942,
      "e": 27807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 34334,
      "e": 28199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 34335,
      "e": 28200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34469,
      "e": 28334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 34606,
      "e": 28471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34607,
      "e": 28472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34709,
      "e": 28574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 34758,
      "e": 28623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 34758,
      "e": 28623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34951,
      "e": 28816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 35783,
      "e": 29648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 35784,
      "e": 29649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35911,
      "e": 29776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35912,
      "e": 29777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35941,
      "e": 29806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 36046,
      "e": 29911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36150,
      "e": 30015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36151,
      "e": 30016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36270,
      "e": 30135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 36407,
      "e": 30272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36407,
      "e": 30272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36542,
      "e": 30407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 36903,
      "e": 30768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 36903,
      "e": 30768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37046,
      "e": 30911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 37118,
      "e": 30983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37120,
      "e": 30985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37182,
      "e": 31047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 37190,
      "e": 31055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 37191,
      "e": 31056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37350,
      "e": 31215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 37471,
      "e": 31336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37471,
      "e": 31336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37602,
      "e": 31467,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indica"
    },
    {
      "t": 37751,
      "e": 31616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37751,
      "e": 31616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37822,
      "e": 31687,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 37878,
      "e": 31743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37879,
      "e": 31744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37966,
      "e": 31831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 38038,
      "e": 31903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38190,
      "e": 32055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 38190,
      "e": 32055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38366,
      "e": 32231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 38415,
      "e": 32280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38415,
      "e": 32280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38526,
      "e": 32391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38838,
      "e": 32703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38840,
      "e": 32705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39003,
      "e": 32868,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated s"
    },
    {
      "t": 39022,
      "e": 32887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39030,
      "e": 32895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39030,
      "e": 32895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39134,
      "e": 32999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39279,
      "e": 33144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39280,
      "e": 33145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39383,
      "e": 33248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 39384,
      "e": 33249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39461,
      "e": 33326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 39493,
      "e": 33358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39614,
      "e": 33479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39615,
      "e": 33480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39726,
      "e": 33591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39766,
      "e": 33631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39768,
      "e": 33633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39862,
      "e": 33727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39862,
      "e": 33727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39870,
      "e": 33735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 39950,
      "e": 33815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40001,
      "e": 33866,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40007,
      "e": 33872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40007,
      "e": 33872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40061,
      "e": 33926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 40061,
      "e": 33926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40070,
      "e": 33935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 40166,
      "e": 34031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40166,
      "e": 34031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40174,
      "e": 34039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40269,
      "e": 34134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40310,
      "e": 34175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40310,
      "e": 34175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40375,
      "e": 34240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40399,
      "e": 34264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40399,
      "e": 34264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40470,
      "e": 34335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40477,
      "e": 34342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 40478,
      "e": 34343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40542,
      "e": 34407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40542,
      "e": 34407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40614,
      "e": 34479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 40646,
      "e": 34511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40767,
      "e": 34632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40767,
      "e": 34632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40854,
      "e": 34719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40894,
      "e": 34759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40894,
      "e": 34759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40982,
      "e": 34847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 41159,
      "e": 35024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 41159,
      "e": 35024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41245,
      "e": 35110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 41261,
      "e": 35126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41261,
      "e": 35126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41357,
      "e": 35222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 42095,
      "e": 35960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 42096,
      "e": 35961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42158,
      "e": 36023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 42390,
      "e": 36255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42392,
      "e": 36257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42470,
      "e": 36335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44601,
      "e": 38466,
      "ty": 2,
      "x": 1486,
      "y": 845
    },
    {
      "t": 44701,
      "e": 38566,
      "ty": 2,
      "x": 960,
      "y": 882
    },
    {
      "t": 44752,
      "e": 38617,
      "ty": 41,
      "x": 12262,
      "y": 53287,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 44900,
      "e": 38765,
      "ty": 2,
      "x": 943,
      "y": 831
    },
    {
      "t": 44952,
      "e": 38817,
      "ty": 6,
      "x": 599,
      "y": 600,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44985,
      "e": 38850,
      "ty": 7,
      "x": 358,
      "y": 462,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45001,
      "e": 38866,
      "ty": 2,
      "x": 358,
      "y": 462
    },
    {
      "t": 45001,
      "e": 38866,
      "ty": 41,
      "x": 29328,
      "y": 25150,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 45101,
      "e": 38966,
      "ty": 2,
      "x": 0,
      "y": 227
    },
    {
      "t": 45201,
      "e": 39066,
      "ty": 2,
      "x": 39,
      "y": 275
    },
    {
      "t": 45251,
      "e": 39116,
      "ty": 41,
      "x": 2687,
      "y": 21604,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 45301,
      "e": 39166,
      "ty": 2,
      "x": 152,
      "y": 435
    },
    {
      "t": 45401,
      "e": 39266,
      "ty": 2,
      "x": 160,
      "y": 443
    },
    {
      "t": 45501,
      "e": 39366,
      "ty": 2,
      "x": 231,
      "y": 479
    },
    {
      "t": 45501,
      "e": 39366,
      "ty": 41,
      "x": 15052,
      "y": 793,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 45600,
      "e": 39465,
      "ty": 2,
      "x": 342,
      "y": 520
    },
    {
      "t": 45601,
      "e": 39466,
      "ty": 6,
      "x": 348,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45700,
      "e": 39565,
      "ty": 2,
      "x": 353,
      "y": 522
    },
    {
      "t": 45751,
      "e": 39616,
      "ty": 41,
      "x": 28766,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46509,
      "e": 40374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 46734,
      "e": 40599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 46736,
      "e": 40601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46814,
      "e": 40679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||W"
    },
    {
      "t": 46894,
      "e": 40759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47143,
      "e": 41008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47213,
      "e": 41078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. "
    },
    {
      "t": 47623,
      "e": 41488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 47758,
      "e": 41623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 47759,
      "e": 41624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47829,
      "e": 41694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||U"
    },
    {
      "t": 47838,
      "e": 41703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47942,
      "e": 41807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 47942,
      "e": 41807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48054,
      "e": 41919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48054,
      "e": 41919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48118,
      "e": 41983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 48190,
      "e": 42055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48317,
      "e": 42182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 48319,
      "e": 42184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48413,
      "e": 42278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48414,
      "e": 42279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48454,
      "e": 42319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 48567,
      "e": 42432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 48567,
      "e": 42432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48581,
      "e": 42446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 48694,
      "e": 42559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48694,
      "e": 42559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48798,
      "e": 42663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 48846,
      "e": 42711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 48847,
      "e": 42712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48878,
      "e": 42743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 48966,
      "e": 42831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49079,
      "e": 42944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 49079,
      "e": 42944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49203,
      "e": 43068,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reac"
    },
    {
      "t": 49221,
      "e": 43086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 49238,
      "e": 43103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 49238,
      "e": 43103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49342,
      "e": 43207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 49431,
      "e": 43296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 49432,
      "e": 43297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49525,
      "e": 43390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 49646,
      "e": 43511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 49647,
      "e": 43512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49759,
      "e": 43624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 49790,
      "e": 43655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 49792,
      "e": 43657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49902,
      "e": 43767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49902,
      "e": 43767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49910,
      "e": 43775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g "
    },
    {
      "t": 50001,
      "e": 43866,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50014,
      "e": 43879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50062,
      "e": 43927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50062,
      "e": 43927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50117,
      "e": 43982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 50158,
      "e": 44023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 50158,
      "e": 44023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50238,
      "e": 44103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 50446,
      "e": 44311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 50447,
      "e": 44312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50510,
      "e": 44375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 50670,
      "e": 44535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50671,
      "e": 44536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50765,
      "e": 44630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51318,
      "e": 45183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51366,
      "e": 45231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching thr"
    },
    {
      "t": 51535,
      "e": 45400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51598,
      "e": 45463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching th"
    },
    {
      "t": 52174,
      "e": 46039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52175,
      "e": 46040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52286,
      "e": 46151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 52301,
      "e": 46166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52302,
      "e": 46167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52390,
      "e": 46255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52662,
      "e": 46527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 52663,
      "e": 46528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52798,
      "e": 46663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 52798,
      "e": 46663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52885,
      "e": 46750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52885,
      "e": 46750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52893,
      "e": 46758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12 "
    },
    {
      "t": 52958,
      "e": 46823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52990,
      "e": 46855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53102,
      "e": 46967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 53103,
      "e": 46968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53182,
      "e": 47047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 53462,
      "e": 47327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 53463,
      "e": 47328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53581,
      "e": 47446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 53597,
      "e": 47462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53598,
      "e": 47463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53742,
      "e": 47607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54385,
      "e": 48250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 54386,
      "e": 48251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54445,
      "e": 48310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 54654,
      "e": 48519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54655,
      "e": 48520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54782,
      "e": 48647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 55047,
      "e": 48912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 55047,
      "e": 48912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55133,
      "e": 48998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 55205,
      "e": 49070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 55206,
      "e": 49071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55262,
      "e": 49127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 55286,
      "e": 49151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55287,
      "e": 49152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55389,
      "e": 49254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 55389,
      "e": 49254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55453,
      "e": 49318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 55510,
      "e": 49375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55558,
      "e": 49423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 55559,
      "e": 49424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55621,
      "e": 49486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 58267,
      "e": 52132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58268,
      "e": 52133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58388,
      "e": 52253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59999,
      "e": 53864,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60435,
      "e": 54300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 60436,
      "e": 54301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60571,
      "e": 54436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 60571,
      "e": 54436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60643,
      "e": 54508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 60795,
      "e": 54660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 60796,
      "e": 54661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60850,
      "e": 54715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 60971,
      "e": 54836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 60971,
      "e": 54836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61059,
      "e": 54924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 61163,
      "e": 55028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61835,
      "e": 55700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61836,
      "e": 55701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62001,
      "e": 55866,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read "
    },
    {
      "t": 62051,
      "e": 55916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 62635,
      "e": 56500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 62636,
      "e": 56501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62738,
      "e": 56603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 62907,
      "e": 56772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 62908,
      "e": 56773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63011,
      "e": 56876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 63011,
      "e": 56876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63066,
      "e": 56931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 63123,
      "e": 56988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63267,
      "e": 57132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 63268,
      "e": 57133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63387,
      "e": 57252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 63707,
      "e": 57572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 63708,
      "e": 57573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63819,
      "e": 57684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 63819,
      "e": 57684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63851,
      "e": 57716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ic"
    },
    {
      "t": 63963,
      "e": 57828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64011,
      "e": 57876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 64012,
      "e": 57877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64179,
      "e": 58044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 64219,
      "e": 58084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 64220,
      "e": 58085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64276,
      "e": 58141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 64364,
      "e": 58229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 64364,
      "e": 58229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64490,
      "e": 58355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 64723,
      "e": 58588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 64724,
      "e": 58589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64859,
      "e": 58724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 66027,
      "e": 59892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 66028,
      "e": 59893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66122,
      "e": 59987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 66339,
      "e": 60204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66340,
      "e": 60205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66410,
      "e": 60275,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66595,
      "e": 60460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 66763,
      "e": 60628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66763,
      "e": 60628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66811,
      "e": 60676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 66850,
      "e": 60715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66891,
      "e": 60756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 66891,
      "e": 60756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66955,
      "e": 60820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 67003,
      "e": 60868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 67004,
      "e": 60869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67115,
      "e": 60980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 67147,
      "e": 61012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67147,
      "e": 61012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67251,
      "e": 61116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67299,
      "e": 61164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 67300,
      "e": 61165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67427,
      "e": 61292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 67467,
      "e": 61332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 67467,
      "e": 61332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67531,
      "e": 61396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 67595,
      "e": 61460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 67597,
      "e": 61462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67667,
      "e": 61532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 67823,
      "e": 61688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 67824,
      "e": 61689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67922,
      "e": 61787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67923,
      "e": 61788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67954,
      "e": 61819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 68067,
      "e": 61932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68131,
      "e": 61996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68131,
      "e": 61996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68235,
      "e": 62100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 68242,
      "e": 62107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 68242,
      "e": 62107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68314,
      "e": 62179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 68338,
      "e": 62203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 68338,
      "e": 62203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68418,
      "e": 62283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68419,
      "e": 62284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68490,
      "e": 62355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 68515,
      "e": 62380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68515,
      "e": 62380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68523,
      "e": 62388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68667,
      "e": 62532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68684,
      "e": 62549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 68684,
      "e": 62549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68800,
      "e": 62665,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that f"
    },
    {
      "t": 68835,
      "e": 62700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 68851,
      "e": 62716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 68851,
      "e": 62716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68979,
      "e": 62844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 69035,
      "e": 62900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 69036,
      "e": 62901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69083,
      "e": 62948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 69172,
      "e": 62949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 69174,
      "e": 62951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69298,
      "e": 63075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 69467,
      "e": 63244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69467,
      "e": 63244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69580,
      "e": 63357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70035,
      "e": 63812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 70036,
      "e": 63813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70131,
      "e": 63908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 70291,
      "e": 64068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 70292,
      "e": 64069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70354,
      "e": 64131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70354,
      "e": 64131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70419,
      "e": 64196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 70507,
      "e": 64284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70556,
      "e": 64333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70557,
      "e": 64334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70634,
      "e": 64411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 70675,
      "e": 64452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 70675,
      "e": 64452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70739,
      "e": 64516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 70843,
      "e": 64620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 70844,
      "e": 64621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70914,
      "e": 64691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 70986,
      "e": 64763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 70987,
      "e": 64764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71140,
      "e": 64917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71140,
      "e": 64917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71170,
      "e": 64947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 71307,
      "e": 65084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72443,
      "e": 66220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 72444,
      "e": 66221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72587,
      "e": 66364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 72699,
      "e": 66476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 72700,
      "e": 66477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72771,
      "e": 66548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 72923,
      "e": 66700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 72924,
      "e": 66701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73002,
      "e": 66779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 73043,
      "e": 66820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 73043,
      "e": 66820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73163,
      "e": 66940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73164,
      "e": 66941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73171,
      "e": 66948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 73291,
      "e": 67068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73346,
      "e": 67123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73347,
      "e": 67124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73515,
      "e": 67292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 73515,
      "e": 67292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73562,
      "e": 67339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 73603,
      "e": 67380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 73603,
      "e": 67380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73698,
      "e": 67475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 73715,
      "e": 67492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73715,
      "e": 67492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73763,
      "e": 67540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73827,
      "e": 67604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73859,
      "e": 67636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73860,
      "e": 67637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73947,
      "e": 67724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 73947,
      "e": 67724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 73947,
      "e": 67724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74003,
      "e": 67780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 74083,
      "e": 67860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 74083,
      "e": 67860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74171,
      "e": 67948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 74203,
      "e": 67980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 74204,
      "e": 67981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74362,
      "e": 68139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 74363,
      "e": 68140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74411,
      "e": 68188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 74491,
      "e": 68268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74492,
      "e": 68269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74498,
      "e": 68275,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74600,
      "e": 68377,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those "
    },
    {
      "t": 74651,
      "e": 68428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74658,
      "e": 68435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 74659,
      "e": 68436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74801,
      "e": 68578,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those s"
    },
    {
      "t": 74827,
      "e": 68604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 74828,
      "e": 68605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74851,
      "e": 68628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 74947,
      "e": 68724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 75011,
      "e": 68788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 75012,
      "e": 68789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75107,
      "e": 68884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 75107,
      "e": 68884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75203,
      "e": 68980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 75234,
      "e": 69011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 75395,
      "e": 69172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 75396,
      "e": 69173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75397,
      "e": 69174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 75398,
      "e": 69175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75443,
      "e": 69220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rt"
    },
    {
      "t": 75451,
      "e": 69228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 75525,
      "e": 69302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 75526,
      "e": 69303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75595,
      "e": 69304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 75955,
      "e": 69664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76003,
      "e": 69712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starrt"
    },
    {
      "t": 76107,
      "e": 69816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76155,
      "e": 69864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starr"
    },
    {
      "t": 76259,
      "e": 69968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76331,
      "e": 70040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those star"
    },
    {
      "t": 76539,
      "e": 70248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 76540,
      "e": 70249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76642,
      "e": 70351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 76682,
      "e": 70391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 76682,
      "e": 70391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76771,
      "e": 70480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 76915,
      "e": 70624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 76915,
      "e": 70624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77002,
      "e": 70711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 77051,
      "e": 70760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 77051,
      "e": 70760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77171,
      "e": 70880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 77180,
      "e": 70889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77180,
      "e": 70889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77282,
      "e": 70991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77314,
      "e": 71023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 77315,
      "e": 71024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77443,
      "e": 71152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 77444,
      "e": 71153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77539,
      "e": 71248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 77587,
      "e": 71296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 77595,
      "e": 71304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77595,
      "e": 71304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77739,
      "e": 71448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 78019,
      "e": 71728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 78020,
      "e": 71729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78155,
      "e": 71864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 78156,
      "e": 71865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78227,
      "e": 71936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 78299,
      "e": 72008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 78300,
      "e": 72009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 78300,
      "e": 72009,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78403,
      "e": 72112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 78515,
      "e": 72224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 78515,
      "e": 72224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78627,
      "e": 72336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 78787,
      "e": 72496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 78789,
      "e": 72498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78866,
      "e": 72575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 79450,
      "e": 73159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 79451,
      "e": 73160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79507,
      "e": 73216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 79699,
      "e": 73408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 79700,
      "e": 73409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79762,
      "e": 73471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 79899,
      "e": 73608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 80075,
      "e": 73784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 80077,
      "e": 73786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80123,
      "e": 73832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 80163,
      "e": 73872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80171,
      "e": 73880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 80172,
      "e": 73881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80242,
      "e": 73951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 80275,
      "e": 73984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 80275,
      "e": 73984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80371,
      "e": 74080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 80387,
      "e": 74096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 80387,
      "e": 74096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80474,
      "e": 74183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80475,
      "e": 74184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80490,
      "e": 74199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 80600,
      "e": 74199,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They "
    },
    {
      "t": 80603,
      "e": 74202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80931,
      "e": 74530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 80932,
      "e": 74531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81019,
      "e": 74618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 81099,
      "e": 74698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 81099,
      "e": 74698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81154,
      "e": 74753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 81218,
      "e": 74817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 81218,
      "e": 74817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81323,
      "e": 74922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 81371,
      "e": 74970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 81372,
      "e": 74971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81466,
      "e": 75065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 81563,
      "e": 75162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 81563,
      "e": 75162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81707,
      "e": 75306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 82115,
      "e": 75714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 82115,
      "e": 75714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82179,
      "e": 75778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 82219,
      "e": 75818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 82219,
      "e": 75818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82290,
      "e": 75889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 82346,
      "e": 75945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 82346,
      "e": 75945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82451,
      "e": 76050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 82452,
      "e": 76051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82474,
      "e": 76073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a "
    },
    {
      "t": 82554,
      "e": 76153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 82618,
      "e": 76217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 82618,
      "e": 76217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82683,
      "e": 76282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 82755,
      "e": 76354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 82756,
      "e": 76355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82810,
      "e": 76409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 82955,
      "e": 76554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 82956,
      "e": 76555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83019,
      "e": 76618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 83059,
      "e": 76658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 83059,
      "e": 76658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83139,
      "e": 76738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 83227,
      "e": 76826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 83228,
      "e": 76827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83387,
      "e": 76986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 84507,
      "e": 78106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 84509,
      "e": 78108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84562,
      "e": 78161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 84698,
      "e": 78297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 84699,
      "e": 78298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84800,
      "e": 78399,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time in"
    },
    {
      "t": 84810,
      "e": 78409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 84827,
      "e": 78426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 84827,
      "e": 78426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84939,
      "e": 78538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 84947,
      "e": 78546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 84947,
      "e": 78546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85018,
      "e": 78617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 85042,
      "e": 78641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 85042,
      "e": 78641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85195,
      "e": 78794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 85490,
      "e": 79089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 85491,
      "e": 79090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85601,
      "e": 79200,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indica"
    },
    {
      "t": 85692,
      "e": 79201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 85694,
      "e": 79203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85794,
      "e": 79303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 85858,
      "e": 79367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 85858,
      "e": 79367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85972,
      "e": 79481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 86010,
      "e": 79519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 86163,
      "e": 79672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 86163,
      "e": 79672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86171,
      "e": 79680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 86171,
      "e": 79680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86211,
      "e": 79720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ed"
    },
    {
      "t": 86291,
      "e": 79800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 87131,
      "e": 80640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 87170,
      "e": 80679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicatee"
    },
    {
      "t": 87250,
      "e": 80759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 87298,
      "e": 80807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicate"
    },
    {
      "t": 87401,
      "e": 80910,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicate"
    },
    {
      "t": 87459,
      "e": 80968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 87460,
      "e": 80969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87570,
      "e": 81079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 87684,
      "e": 81193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 87684,
      "e": 81193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87800,
      "e": 81309,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicated "
    },
    {
      "t": 87811,
      "e": 81320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 87907,
      "e": 81416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 87909,
      "e": 81418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88011,
      "e": 81520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 88011,
      "e": 81520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88042,
      "e": 81551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||by"
    },
    {
      "t": 88139,
      "e": 81648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 88140,
      "e": 81649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88186,
      "e": 81695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 88298,
      "e": 81807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 88355,
      "e": 81864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 88355,
      "e": 81864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88442,
      "e": 81951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 88483,
      "e": 81992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 88483,
      "e": 81992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88570,
      "e": 82079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 88570,
      "e": 82079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 88570,
      "e": 82079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88715,
      "e": 82224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 88731,
      "e": 82240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 88732,
      "e": 82241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88835,
      "e": 82344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89547,
      "e": 83056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 89547,
      "e": 83056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89658,
      "e": 83167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89659,
      "e": 83168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89690,
      "e": 83199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 89800,
      "e": 83309,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y "
    },
    {
      "t": 89819,
      "e": 83328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 90027,
      "e": 83536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 90028,
      "e": 83537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90138,
      "e": 83647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 90363,
      "e": 83872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 90364,
      "e": 83873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90491,
      "e": 84000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 90531,
      "e": 84040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 90532,
      "e": 84041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90603,
      "e": 84112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 90651,
      "e": 84160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 90652,
      "e": 84161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90801,
      "e": 84310,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis"
    },
    {
      "t": 90802,
      "e": 84311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 90875,
      "e": 84384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 90876,
      "e": 84385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91001,
      "e": 84510,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis,"
    },
    {
      "t": 91004,
      "e": 84513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 91005,
      "e": 84514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91018,
      "e": 84527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 91155,
      "e": 84664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 91523,
      "e": 85032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 91524,
      "e": 85033,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91610,
      "e": 85119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 91610,
      "e": 85119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91666,
      "e": 85175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 91699,
      "e": 85208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 91723,
      "e": 85232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 91724,
      "e": 85233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91842,
      "e": 85351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 91858,
      "e": 85367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 91859,
      "e": 85368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91955,
      "e": 85464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 91956,
      "e": 85465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92003,
      "e": 85512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ch"
    },
    {
      "t": 92067,
      "e": 85576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 92069,
      "e": 85578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92099,
      "e": 85608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 92201,
      "e": 85609,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which "
    },
    {
      "t": 92275,
      "e": 85683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 92882,
      "e": 86290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 92882,
      "e": 86290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92979,
      "e": 86387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 92979,
      "e": 86387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93091,
      "e": 86499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 93131,
      "e": 86539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 93131,
      "e": 86539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93163,
      "e": 86571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 93251,
      "e": 86659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93282,
      "e": 86690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 93283,
      "e": 86691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93400,
      "e": 86808,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which read"
    },
    {
      "t": 93419,
      "e": 86827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 93419,
      "e": 86827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93450,
      "e": 86858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 93601,
      "e": 87009,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads"
    },
    {
      "t": 93603,
      "e": 87011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93691,
      "e": 87099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 93691,
      "e": 87099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93800,
      "e": 87208,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads "
    },
    {
      "t": 93811,
      "e": 87209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 94250,
      "e": 87648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 94251,
      "e": 87649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94395,
      "e": 87793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 94412,
      "e": 87810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 94412,
      "e": 87810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94483,
      "e": 87881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 94506,
      "e": 87904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 94506,
      "e": 87904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94659,
      "e": 88057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 94660,
      "e": 88058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94690,
      "e": 88088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ra"
    },
    {
      "t": 94800,
      "e": 88198,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads dura"
    },
    {
      "t": 94810,
      "e": 88208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 94811,
      "e": 88209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94899,
      "e": 88297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 94900,
      "e": 88298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94930,
      "e": 88328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 94978,
      "e": 88376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 95026,
      "e": 88424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 95026,
      "e": 88424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95093,
      "e": 88491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 95163,
      "e": 88561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 95307,
      "e": 88705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 95307,
      "e": 88705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95435,
      "e": 88833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 96515,
      "e": 89913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 96516,
      "e": 89914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96643,
      "e": 90041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 96835,
      "e": 90233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 96898,
      "e": 90296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 96900,
      "e": 90298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96986,
      "e": 90384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||("
    },
    {
      "t": 97067,
      "e": 90465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 97410,
      "e": 90808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 97410,
      "e": 90808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97490,
      "e": 90888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 97601,
      "e": 90999,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads duration (i"
    },
    {
      "t": 97603,
      "e": 91001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 97604,
      "e": 91002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97674,
      "e": 91072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 97675,
      "e": 91073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97722,
      "e": 91120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 97778,
      "e": 91176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 97875,
      "e": 91273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 97875,
      "e": 91273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97939,
      "e": 91337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 98034,
      "e": 91432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 98035,
      "e": 91433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98130,
      "e": 91528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 98211,
      "e": 91609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 98211,
      "e": 91609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98283,
      "e": 91681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 98323,
      "e": 91721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 98324,
      "e": 91722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98402,
      "e": 91800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 98514,
      "e": 91912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 98515,
      "e": 91913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98691,
      "e": 92089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 99003,
      "e": 92401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 99155,
      "e": 92553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 99157,
      "e": 92555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99218,
      "e": 92616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||)"
    },
    {
      "t": 99266,
      "e": 92664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 99739,
      "e": 93137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 99739,
      "e": 93137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99826,
      "e": 93224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 99999,
      "e": 93397,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 105497,
      "e": 98224,
      "ty": 2,
      "x": 340,
      "y": 528
    },
    {
      "t": 105498,
      "e": 98225,
      "ty": 41,
      "x": 27305,
      "y": 4260,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105598,
      "e": 98325,
      "ty": 2,
      "x": 430,
      "y": 594
    },
    {
      "t": 105599,
      "e": 98326,
      "ty": 7,
      "x": 568,
      "y": 631,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105698,
      "e": 98425,
      "ty": 2,
      "x": 1179,
      "y": 726
    },
    {
      "t": 105748,
      "e": 98475,
      "ty": 41,
      "x": 27694,
      "y": 42114,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 106198,
      "e": 98925,
      "ty": 2,
      "x": 1165,
      "y": 732
    },
    {
      "t": 106249,
      "e": 98976,
      "ty": 41,
      "x": 17970,
      "y": 41541,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 106298,
      "e": 99025,
      "ty": 2,
      "x": 857,
      "y": 668
    },
    {
      "t": 106383,
      "e": 99110,
      "ty": 6,
      "x": 462,
      "y": 595,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106398,
      "e": 99125,
      "ty": 2,
      "x": 462,
      "y": 595
    },
    {
      "t": 106498,
      "e": 99225,
      "ty": 2,
      "x": 355,
      "y": 574
    },
    {
      "t": 106498,
      "e": 99225,
      "ty": 41,
      "x": 28991,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106598,
      "e": 99325,
      "ty": 2,
      "x": 347,
      "y": 573
    },
    {
      "t": 106748,
      "e": 99475,
      "ty": 41,
      "x": 28091,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106997,
      "e": 99724,
      "ty": 2,
      "x": 379,
      "y": 574
    },
    {
      "t": 106998,
      "e": 99725,
      "ty": 41,
      "x": 31689,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107098,
      "e": 99825,
      "ty": 2,
      "x": 635,
      "y": 580
    },
    {
      "t": 107198,
      "e": 99925,
      "ty": 2,
      "x": 644,
      "y": 580
    },
    {
      "t": 107248,
      "e": 99975,
      "ty": 41,
      "x": 61477,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107397,
      "e": 100124,
      "ty": 2,
      "x": 613,
      "y": 580
    },
    {
      "t": 107498,
      "e": 100225,
      "ty": 2,
      "x": 535,
      "y": 569
    },
    {
      "t": 107499,
      "e": 100226,
      "ty": 41,
      "x": 49225,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107598,
      "e": 100325,
      "ty": 2,
      "x": 494,
      "y": 569
    },
    {
      "t": 107698,
      "e": 100425,
      "ty": 2,
      "x": 383,
      "y": 558
    },
    {
      "t": 107748,
      "e": 100475,
      "ty": 41,
      "x": 25056,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107797,
      "e": 100524,
      "ty": 2,
      "x": 305,
      "y": 535
    },
    {
      "t": 107898,
      "e": 100625,
      "ty": 2,
      "x": 306,
      "y": 529
    },
    {
      "t": 107998,
      "e": 100725,
      "ty": 2,
      "x": 306,
      "y": 527
    },
    {
      "t": 107998,
      "e": 100725,
      "ty": 41,
      "x": 23483,
      "y": 3451,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108398,
      "e": 101125,
      "ty": 2,
      "x": 278,
      "y": 543
    },
    {
      "t": 108497,
      "e": 101224,
      "ty": 2,
      "x": 264,
      "y": 553
    },
    {
      "t": 108499,
      "e": 101226,
      "ty": 41,
      "x": 18761,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108598,
      "e": 101325,
      "ty": 2,
      "x": 263,
      "y": 553
    },
    {
      "t": 108748,
      "e": 101475,
      "ty": 41,
      "x": 18649,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108998,
      "e": 101725,
      "ty": 2,
      "x": 268,
      "y": 553
    },
    {
      "t": 108998,
      "e": 101725,
      "ty": 41,
      "x": 19211,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109098,
      "e": 101825,
      "ty": 2,
      "x": 465,
      "y": 553
    },
    {
      "t": 109198,
      "e": 101925,
      "ty": 2,
      "x": 493,
      "y": 553
    },
    {
      "t": 109248,
      "e": 101975,
      "ty": 41,
      "x": 44503,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109485,
      "e": 102212,
      "ty": 7,
      "x": 726,
      "y": 583,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109498,
      "e": 102225,
      "ty": 2,
      "x": 726,
      "y": 583
    },
    {
      "t": 109498,
      "e": 102225,
      "ty": 41,
      "x": 2634,
      "y": 31595,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 109598,
      "e": 102325,
      "ty": 2,
      "x": 1307,
      "y": 611
    },
    {
      "t": 109698,
      "e": 102425,
      "ty": 2,
      "x": 1390,
      "y": 609
    },
    {
      "t": 109749,
      "e": 102476,
      "ty": 41,
      "x": 49904,
      "y": 15541,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[11]"
    },
    {
      "t": 109798,
      "e": 102525,
      "ty": 2,
      "x": 1397,
      "y": 607
    },
    {
      "t": 109898,
      "e": 102625,
      "ty": 2,
      "x": 1311,
      "y": 680
    },
    {
      "t": 109998,
      "e": 102725,
      "ty": 2,
      "x": 784,
      "y": 935
    },
    {
      "t": 109999,
      "e": 102726,
      "ty": 41,
      "x": 5963,
      "y": 56588,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 110098,
      "e": 102825,
      "ty": 2,
      "x": 596,
      "y": 907
    },
    {
      "t": 110198,
      "e": 102925,
      "ty": 2,
      "x": 547,
      "y": 725
    },
    {
      "t": 110248,
      "e": 102975,
      "ty": 41,
      "x": 51810,
      "y": 39276,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 110298,
      "e": 103025,
      "ty": 2,
      "x": 558,
      "y": 717
    },
    {
      "t": 110798,
      "e": 103525,
      "ty": 2,
      "x": 559,
      "y": 717
    },
    {
      "t": 110898,
      "e": 103625,
      "ty": 2,
      "x": 551,
      "y": 702
    },
    {
      "t": 110997,
      "e": 103724,
      "ty": 2,
      "x": 486,
      "y": 654
    },
    {
      "t": 110998,
      "e": 103725,
      "ty": 41,
      "x": 43716,
      "y": 35786,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 111098,
      "e": 103825,
      "ty": 2,
      "x": 404,
      "y": 611
    },
    {
      "t": 111103,
      "e": 103830,
      "ty": 6,
      "x": 377,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111198,
      "e": 103925,
      "ty": 2,
      "x": 295,
      "y": 573
    },
    {
      "t": 111248,
      "e": 103975,
      "ty": 41,
      "x": 18761,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111299,
      "e": 104026,
      "ty": 2,
      "x": 239,
      "y": 545
    },
    {
      "t": 111399,
      "e": 104126,
      "ty": 2,
      "x": 181,
      "y": 540
    },
    {
      "t": 111498,
      "e": 104225,
      "ty": 2,
      "x": 150,
      "y": 540
    },
    {
      "t": 111498,
      "e": 104225,
      "ty": 41,
      "x": 5947,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111598,
      "e": 104325,
      "ty": 2,
      "x": 148,
      "y": 541
    },
    {
      "t": 111749,
      "e": 104476,
      "ty": 41,
      "x": 5497,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111798,
      "e": 104525,
      "ty": 2,
      "x": 146,
      "y": 542
    },
    {
      "t": 111898,
      "e": 104625,
      "ty": 2,
      "x": 145,
      "y": 543
    },
    {
      "t": 111998,
      "e": 104725,
      "ty": 41,
      "x": 5385,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112099,
      "e": 104826,
      "ty": 2,
      "x": 140,
      "y": 546
    },
    {
      "t": 112240,
      "e": 104967,
      "ty": 3,
      "x": 140,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112248,
      "e": 104975,
      "ty": 41,
      "x": 4823,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112366,
      "e": 105093,
      "ty": 4,
      "x": 4823,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112366,
      "e": 105093,
      "ty": 5,
      "x": 140,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113090,
      "e": 105817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 113591,
      "e": 106318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 113623,
      "e": 106350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 113655,
      "e": 106382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 113688,
      "e": 106415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 113721,
      "e": 106448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 113754,
      "e": 106481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 113787,
      "e": 106514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 113810,
      "e": 106537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 114051,
      "e": 106778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 114131,
      "e": 106858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 114283,
      "e": 107010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 114347,
      "e": 107074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 114714,
      "e": 107441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 114716,
      "e": 107443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114858,
      "e": 107585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically . The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads duration (in hours)."
    },
    {
      "t": 115011,
      "e": 107738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 115011,
      "e": 107738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115084,
      "e": 107739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically u. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads duration (in hours)."
    },
    {
      "t": 115200,
      "e": 107855,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically u. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads duration (in hours)."
    },
    {
      "t": 115234,
      "e": 107889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 115235,
      "e": 107890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115315,
      "e": 107970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically up. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads duration (in hours)."
    },
    {
      "t": 115619,
      "e": 108274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 115621,
      "e": 108276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115731,
      "e": 108386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 115731,
      "e": 108386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115811,
      "e": 108386,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically upwa. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads duration (in hours)."
    },
    {
      "t": 115850,
      "e": 108425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 115851,
      "e": 108426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115899,
      "e": 108474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically upwar. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads duration (in hours)."
    },
    {
      "t": 115922,
      "e": 108497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 116043,
      "e": 108618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 116043,
      "e": 108618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116171,
      "e": 108746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically upward. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads duration (in hours)."
    },
    {
      "t": 116996,
      "e": 109571,
      "ty": 2,
      "x": 172,
      "y": 564
    },
    {
      "t": 116996,
      "e": 109571,
      "ty": 41,
      "x": 8420,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117097,
      "e": 109672,
      "ty": 2,
      "x": 201,
      "y": 594
    },
    {
      "t": 117246,
      "e": 109821,
      "ty": 41,
      "x": 11680,
      "y": 57659,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118897,
      "e": 111472,
      "ty": 2,
      "x": 322,
      "y": 559
    },
    {
      "t": 118996,
      "e": 111571,
      "ty": 2,
      "x": 407,
      "y": 550
    },
    {
      "t": 118996,
      "e": 111571,
      "ty": 41,
      "x": 34836,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119096,
      "e": 111671,
      "ty": 2,
      "x": 505,
      "y": 562
    },
    {
      "t": 119191,
      "e": 111766,
      "ty": 7,
      "x": 696,
      "y": 593,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119195,
      "e": 111770,
      "ty": 2,
      "x": 696,
      "y": 593
    },
    {
      "t": 119247,
      "e": 111822,
      "ty": 41,
      "x": 4701,
      "y": 32589,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 119297,
      "e": 111872,
      "ty": 2,
      "x": 786,
      "y": 601
    },
    {
      "t": 119497,
      "e": 112072,
      "ty": 41,
      "x": 1,
      "y": 33161,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 120096,
      "e": 112671,
      "ty": 2,
      "x": 680,
      "y": 643
    },
    {
      "t": 120196,
      "e": 112771,
      "ty": 2,
      "x": 695,
      "y": 869
    },
    {
      "t": 120247,
      "e": 112822,
      "ty": 41,
      "x": 4643,
      "y": 62339,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 120296,
      "e": 112871,
      "ty": 2,
      "x": 846,
      "y": 1128
    },
    {
      "t": 120397,
      "e": 112972,
      "ty": 2,
      "x": 907,
      "y": 1146
    },
    {
      "t": 120497,
      "e": 113072,
      "ty": 2,
      "x": 907,
      "y": 1145
    },
    {
      "t": 120497,
      "e": 113072,
      "ty": 41,
      "x": 30959,
      "y": 62986,
      "ta": "> div.stimulus"
    },
    {
      "t": 120696,
      "e": 113271,
      "ty": 2,
      "x": 915,
      "y": 1145
    },
    {
      "t": 120747,
      "e": 113322,
      "ty": 41,
      "x": 32199,
      "y": 62765,
      "ta": "> div.stimulus"
    },
    {
      "t": 120796,
      "e": 113371,
      "ty": 2,
      "x": 963,
      "y": 1139
    },
    {
      "t": 120897,
      "e": 113472,
      "ty": 2,
      "x": 726,
      "y": 998
    },
    {
      "t": 120997,
      "e": 113572,
      "ty": 2,
      "x": 325,
      "y": 830
    },
    {
      "t": 120997,
      "e": 113572,
      "ty": 41,
      "x": 25618,
      "y": 45536,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 121096,
      "e": 113671,
      "ty": 2,
      "x": 314,
      "y": 782
    },
    {
      "t": 121196,
      "e": 113771,
      "ty": 2,
      "x": 336,
      "y": 736
    },
    {
      "t": 121247,
      "e": 113822,
      "ty": 41,
      "x": 19382,
      "y": 61776,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 121296,
      "e": 113871,
      "ty": 2,
      "x": 377,
      "y": 701
    },
    {
      "t": 121326,
      "e": 113901,
      "ty": 6,
      "x": 388,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 121397,
      "e": 113902,
      "ty": 2,
      "x": 393,
      "y": 673
    },
    {
      "t": 121496,
      "e": 114001,
      "ty": 41,
      "x": 29712,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 121550,
      "e": 114055,
      "ty": 3,
      "x": 393,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 121551,
      "e": 114056,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically upward. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads duration (in hours)."
    },
    {
      "t": 121551,
      "e": 114056,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121551,
      "e": 114056,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 121628,
      "e": 114133,
      "ty": 4,
      "x": 29712,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 121637,
      "e": 114142,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 121638,
      "e": 114143,
      "ty": 5,
      "x": 393,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 121648,
      "e": 114153,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 122646,
      "e": 115151,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 123496,
      "e": 116001,
      "ty": 2,
      "x": 847,
      "y": 591
    },
    {
      "t": 123497,
      "e": 116002,
      "ty": 41,
      "x": 8435,
      "y": 5637,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 123512,
      "e": 116017,
      "ty": 6,
      "x": 1020,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 123527,
      "e": 116032,
      "ty": 7,
      "x": 1156,
      "y": 539,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 123595,
      "e": 116100,
      "ty": 2,
      "x": 1356,
      "y": 534
    },
    {
      "t": 123695,
      "e": 116200,
      "ty": 2,
      "x": 1357,
      "y": 521
    },
    {
      "t": 123747,
      "e": 116252,
      "ty": 41,
      "x": 45733,
      "y": 28252,
      "ta": "html > body"
    },
    {
      "t": 123796,
      "e": 116301,
      "ty": 2,
      "x": 1214,
      "y": 518
    },
    {
      "t": 123897,
      "e": 116402,
      "ty": 2,
      "x": 1074,
      "y": 518
    },
    {
      "t": 123996,
      "e": 116501,
      "ty": 2,
      "x": 1068,
      "y": 521
    },
    {
      "t": 123997,
      "e": 116502,
      "ty": 41,
      "x": 56234,
      "y": 30426,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 124095,
      "e": 116600,
      "ty": 2,
      "x": 1061,
      "y": 547
    },
    {
      "t": 124145,
      "e": 116650,
      "ty": 6,
      "x": 1061,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 124195,
      "e": 116700,
      "ty": 2,
      "x": 1061,
      "y": 556
    },
    {
      "t": 124246,
      "e": 116751,
      "ty": 41,
      "x": 54720,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 124453,
      "e": 116958,
      "ty": 3,
      "x": 1061,
      "y": 556,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 124455,
      "e": 116960,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 124564,
      "e": 117069,
      "ty": 4,
      "x": 54720,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 124564,
      "e": 117069,
      "ty": 5,
      "x": 1061,
      "y": 556,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126233,
      "e": 118738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 126233,
      "e": 118738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126344,
      "e": 118849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 126401,
      "e": 118906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 126402,
      "e": 118907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126480,
      "e": 118985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 126597,
      "e": 119102,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 127246,
      "e": 119751,
      "ty": 41,
      "x": 54720,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127281,
      "e": 119786,
      "ty": 7,
      "x": 1061,
      "y": 581,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127296,
      "e": 119801,
      "ty": 2,
      "x": 1061,
      "y": 581
    },
    {
      "t": 127396,
      "e": 119901,
      "ty": 2,
      "x": 1068,
      "y": 623
    },
    {
      "t": 127496,
      "e": 120001,
      "ty": 2,
      "x": 1072,
      "y": 639
    },
    {
      "t": 127496,
      "e": 120001,
      "ty": 41,
      "x": 57099,
      "y": 39461,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 127533,
      "e": 120038,
      "ty": 6,
      "x": 1076,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 127596,
      "e": 120101,
      "ty": 2,
      "x": 1077,
      "y": 648
    },
    {
      "t": 127696,
      "e": 120201,
      "ty": 2,
      "x": 1104,
      "y": 662
    },
    {
      "t": 127731,
      "e": 120236,
      "ty": 7,
      "x": 1112,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 127746,
      "e": 120251,
      "ty": 41,
      "x": 38019,
      "y": 36451,
      "ta": "html > body"
    },
    {
      "t": 127796,
      "e": 120301,
      "ty": 2,
      "x": 1114,
      "y": 669
    },
    {
      "t": 127996,
      "e": 120501,
      "ty": 2,
      "x": 1114,
      "y": 666
    },
    {
      "t": 127996,
      "e": 120501,
      "ty": 41,
      "x": 38088,
      "y": 36451,
      "ta": "html > body"
    },
    {
      "t": 128095,
      "e": 120600,
      "ty": 2,
      "x": 1113,
      "y": 661
    },
    {
      "t": 128246,
      "e": 120751,
      "ty": 41,
      "x": 38053,
      "y": 35288,
      "ta": "html > body"
    },
    {
      "t": 128296,
      "e": 120801,
      "ty": 2,
      "x": 1108,
      "y": 594
    },
    {
      "t": 128315,
      "e": 120820,
      "ty": 6,
      "x": 1108,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128364,
      "e": 120869,
      "ty": 7,
      "x": 1108,
      "y": 552,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128396,
      "e": 120901,
      "ty": 2,
      "x": 1108,
      "y": 551
    },
    {
      "t": 128496,
      "e": 121001,
      "ty": 41,
      "x": 64886,
      "y": 42985,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 128565,
      "e": 121070,
      "ty": 6,
      "x": 1108,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128595,
      "e": 121100,
      "ty": 2,
      "x": 1108,
      "y": 558
    },
    {
      "t": 128696,
      "e": 121201,
      "ty": 2,
      "x": 1107,
      "y": 562
    },
    {
      "t": 128746,
      "e": 121251,
      "ty": 41,
      "x": 64669,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128861,
      "e": 121366,
      "ty": 3,
      "x": 1107,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128973,
      "e": 121478,
      "ty": 4,
      "x": 64669,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128973,
      "e": 121478,
      "ty": 5,
      "x": 1107,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129096,
      "e": 121601,
      "ty": 2,
      "x": 1107,
      "y": 566
    },
    {
      "t": 129099,
      "e": 121604,
      "ty": 7,
      "x": 1119,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129195,
      "e": 121700,
      "ty": 2,
      "x": 1285,
      "y": 621
    },
    {
      "t": 129246,
      "e": 121751,
      "ty": 41,
      "x": 45423,
      "y": 34567,
      "ta": "html > body"
    },
    {
      "t": 129296,
      "e": 121801,
      "ty": 2,
      "x": 1327,
      "y": 632
    },
    {
      "t": 129452,
      "e": 121957,
      "ty": 3,
      "x": 1327,
      "y": 632,
      "ta": "html > body"
    },
    {
      "t": 129452,
      "e": 121957,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 129452,
      "e": 121957,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129492,
      "e": 121997,
      "ty": 4,
      "x": 45423,
      "y": 34567,
      "ta": "html > body"
    },
    {
      "t": 129492,
      "e": 121997,
      "ty": 5,
      "x": 1327,
      "y": 632,
      "ta": "html > body"
    },
    {
      "t": 129595,
      "e": 122100,
      "ty": 2,
      "x": 1328,
      "y": 633
    },
    {
      "t": 129695,
      "e": 122200,
      "ty": 2,
      "x": 1195,
      "y": 638
    },
    {
      "t": 129746,
      "e": 122251,
      "ty": 41,
      "x": 39293,
      "y": 35398,
      "ta": "html > body"
    },
    {
      "t": 129796,
      "e": 122301,
      "ty": 2,
      "x": 1143,
      "y": 653
    },
    {
      "t": 129896,
      "e": 122401,
      "ty": 2,
      "x": 1139,
      "y": 662
    },
    {
      "t": 129996,
      "e": 122501,
      "ty": 2,
      "x": 1114,
      "y": 666
    },
    {
      "t": 129996,
      "e": 122501,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 129999,
      "e": 122504,
      "ty": 41,
      "x": 38088,
      "y": 36451,
      "ta": "html > body"
    },
    {
      "t": 130096,
      "e": 122601,
      "ty": 2,
      "x": 1111,
      "y": 666
    },
    {
      "t": 130247,
      "e": 122752,
      "ty": 41,
      "x": 37984,
      "y": 36451,
      "ta": "html > body"
    },
    {
      "t": 130437,
      "e": 122942,
      "ty": 3,
      "x": 1111,
      "y": 666,
      "ta": "html > body"
    },
    {
      "t": 130516,
      "e": 123021,
      "ty": 4,
      "x": 37984,
      "y": 36451,
      "ta": "html > body"
    },
    {
      "t": 130517,
      "e": 123022,
      "ty": 5,
      "x": 1111,
      "y": 666,
      "ta": "html > body"
    },
    {
      "t": 131046,
      "e": 123551,
      "ty": 6,
      "x": 1109,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131096,
      "e": 123601,
      "ty": 2,
      "x": 1105,
      "y": 661
    },
    {
      "t": 131196,
      "e": 123701,
      "ty": 2,
      "x": 1100,
      "y": 659
    },
    {
      "t": 131237,
      "e": 123742,
      "ty": 3,
      "x": 1100,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131246,
      "e": 123751,
      "ty": 41,
      "x": 63155,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131333,
      "e": 123838,
      "ty": 4,
      "x": 63155,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131334,
      "e": 123839,
      "ty": 5,
      "x": 1100,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131496,
      "e": 124001,
      "ty": 2,
      "x": 1076,
      "y": 659
    },
    {
      "t": 131497,
      "e": 124002,
      "ty": 41,
      "x": 57964,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131596,
      "e": 124101,
      "ty": 2,
      "x": 1008,
      "y": 649
    },
    {
      "t": 131746,
      "e": 124251,
      "ty": 41,
      "x": 43257,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131796,
      "e": 124301,
      "ty": 2,
      "x": 1007,
      "y": 649
    },
    {
      "t": 131896,
      "e": 124401,
      "ty": 2,
      "x": 1008,
      "y": 654
    },
    {
      "t": 131957,
      "e": 124462,
      "ty": 3,
      "x": 1008,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131958,
      "e": 124463,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131996,
      "e": 124501,
      "ty": 41,
      "x": 43257,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132093,
      "e": 124598,
      "ty": 4,
      "x": 43257,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132093,
      "e": 124598,
      "ty": 5,
      "x": 1008,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132785,
      "e": 125290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 132921,
      "e": 125426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 132921,
      "e": 125426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133008,
      "e": 125513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 133008,
      "e": 125513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 133176,
      "e": 125681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 133177,
      "e": 125682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133280,
      "e": 125785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 133360,
      "e": 125865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 133360,
      "e": 125865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133464,
      "e": 125969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 133489,
      "e": 125994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 133490,
      "e": 125995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133592,
      "e": 126097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 133592,
      "e": 126097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133648,
      "e": 126153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 133745,
      "e": 126250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 133880,
      "e": 126385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 133882,
      "e": 126387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133968,
      "e": 126473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 133968,
      "e": 126473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134040,
      "e": 126545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d "
    },
    {
      "t": 134137,
      "e": 126642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 134160,
      "e": 126665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 134281,
      "e": 126786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 134281,
      "e": 126786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134320,
      "e": 126825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 134473,
      "e": 126978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 134473,
      "e": 126978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134503,
      "e": 127008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 134600,
      "e": 127105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 134801,
      "e": 127306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 134801,
      "e": 127306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134904,
      "e": 127409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 134904,
      "e": 127409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134960,
      "e": 127465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 135017,
      "e": 127522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 135017,
      "e": 127522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 135080,
      "e": 127585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 135129,
      "e": 127634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 135129,
      "e": 127634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 135192,
      "e": 127697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 135353,
      "e": 127858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 135596,
      "e": 128101,
      "ty": 2,
      "x": 999,
      "y": 650
    },
    {
      "t": 135697,
      "e": 128202,
      "ty": 2,
      "x": 992,
      "y": 656
    },
    {
      "t": 135738,
      "e": 128243,
      "ty": 7,
      "x": 988,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 135746,
      "e": 128251,
      "ty": 41,
      "x": 38931,
      "y": 59897,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 135796,
      "e": 128301,
      "ty": 2,
      "x": 984,
      "y": 673
    },
    {
      "t": 135805,
      "e": 128310,
      "ty": 6,
      "x": 981,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 135897,
      "e": 128402,
      "ty": 2,
      "x": 978,
      "y": 686
    },
    {
      "t": 135997,
      "e": 128502,
      "ty": 2,
      "x": 977,
      "y": 701
    },
    {
      "t": 135997,
      "e": 128502,
      "ty": 41,
      "x": 41786,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136221,
      "e": 128726,
      "ty": 3,
      "x": 977,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136222,
      "e": 128727,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 136223,
      "e": 128728,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 136224,
      "e": 128729,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136316,
      "e": 128821,
      "ty": 4,
      "x": 41786,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136316,
      "e": 128821,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136317,
      "e": 128822,
      "ty": 5,
      "x": 977,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136317,
      "e": 128822,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 137338,
      "e": 129843,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 137995,
      "e": 130500,
      "ty": 2,
      "x": 866,
      "y": 645
    },
    {
      "t": 137996,
      "e": 130501,
      "ty": 41,
      "x": 10579,
      "y": 8124,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 138096,
      "e": 130601,
      "ty": 2,
      "x": 628,
      "y": 147
    },
    {
      "t": 138196,
      "e": 130701,
      "ty": 2,
      "x": 633,
      "y": 88
    },
    {
      "t": 138247,
      "e": 130752,
      "ty": 41,
      "x": 21833,
      "y": 4431,
      "ta": "html > body"
    },
    {
      "t": 138297,
      "e": 130802,
      "ty": 2,
      "x": 676,
      "y": 103
    },
    {
      "t": 138396,
      "e": 130901,
      "ty": 2,
      "x": 781,
      "y": 204
    },
    {
      "t": 138496,
      "e": 131001,
      "ty": 2,
      "x": 786,
      "y": 208
    },
    {
      "t": 138497,
      "e": 131002,
      "ty": 41,
      "x": 26792,
      "y": 11079,
      "ta": "html > body"
    },
    {
      "t": 138696,
      "e": 131201,
      "ty": 2,
      "x": 789,
      "y": 220
    },
    {
      "t": 138747,
      "e": 131252,
      "ty": 41,
      "x": 26895,
      "y": 11910,
      "ta": "html > body"
    },
    {
      "t": 138796,
      "e": 131301,
      "ty": 2,
      "x": 791,
      "y": 227
    },
    {
      "t": 138896,
      "e": 131401,
      "ty": 2,
      "x": 803,
      "y": 232
    },
    {
      "t": 138997,
      "e": 131502,
      "ty": 2,
      "x": 812,
      "y": 235
    },
    {
      "t": 138997,
      "e": 131502,
      "ty": 41,
      "x": 27687,
      "y": 12575,
      "ta": "html > body"
    },
    {
      "t": 139096,
      "e": 131601,
      "ty": 2,
      "x": 817,
      "y": 240
    },
    {
      "t": 139196,
      "e": 131701,
      "ty": 2,
      "x": 819,
      "y": 240
    },
    {
      "t": 139247,
      "e": 131752,
      "ty": 41,
      "x": 27963,
      "y": 12852,
      "ta": "html > body"
    },
    {
      "t": 139297,
      "e": 131802,
      "ty": 2,
      "x": 825,
      "y": 242
    },
    {
      "t": 139307,
      "e": 131812,
      "ty": 6,
      "x": 826,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 139396,
      "e": 131901,
      "ty": 2,
      "x": 827,
      "y": 243
    },
    {
      "t": 139497,
      "e": 132002,
      "ty": 41,
      "x": 2914,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 139709,
      "e": 132214,
      "ty": 3,
      "x": 827,
      "y": 243,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 139710,
      "e": 132215,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 139804,
      "e": 132309,
      "ty": 4,
      "x": 2914,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 139804,
      "e": 132309,
      "ty": 5,
      "x": 827,
      "y": 243,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 139804,
      "e": 132309,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 139997,
      "e": 132502,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140246,
      "e": 132751,
      "ty": 41,
      "x": 7955,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 140258,
      "e": 132763,
      "ty": 7,
      "x": 828,
      "y": 254,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 140296,
      "e": 132801,
      "ty": 2,
      "x": 840,
      "y": 303
    },
    {
      "t": 140396,
      "e": 132901,
      "ty": 2,
      "x": 866,
      "y": 381
    },
    {
      "t": 140497,
      "e": 133002,
      "ty": 2,
      "x": 862,
      "y": 406
    },
    {
      "t": 140497,
      "e": 133002,
      "ty": 41,
      "x": 47500,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 140596,
      "e": 133101,
      "ty": 2,
      "x": 853,
      "y": 413
    },
    {
      "t": 140696,
      "e": 133201,
      "ty": 2,
      "x": 844,
      "y": 418
    },
    {
      "t": 140746,
      "e": 133251,
      "ty": 41,
      "x": 26429,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 140997,
      "e": 133502,
      "ty": 3,
      "x": 844,
      "y": 418,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 140998,
      "e": 133503,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 141092,
      "e": 133597,
      "ty": 4,
      "x": 26429,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 141092,
      "e": 133597,
      "ty": 5,
      "x": 844,
      "y": 418,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 141092,
      "e": 133597,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 141093,
      "e": 133598,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 143246,
      "e": 135751,
      "ty": 41,
      "x": 28771,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 143297,
      "e": 135802,
      "ty": 2,
      "x": 850,
      "y": 418
    },
    {
      "t": 143497,
      "e": 136002,
      "ty": 41,
      "x": 33453,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 144496,
      "e": 137001,
      "ty": 2,
      "x": 850,
      "y": 419
    },
    {
      "t": 144497,
      "e": 137002,
      "ty": 41,
      "x": 33453,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 144896,
      "e": 137401,
      "ty": 2,
      "x": 842,
      "y": 415
    },
    {
      "t": 144996,
      "e": 137501,
      "ty": 41,
      "x": 24088,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 145088,
      "e": 137593,
      "ty": 6,
      "x": 838,
      "y": 416,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 145096,
      "e": 137601,
      "ty": 2,
      "x": 837,
      "y": 416
    },
    {
      "t": 145128,
      "e": 137633,
      "ty": 7,
      "x": 834,
      "y": 422,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 145196,
      "e": 137701,
      "ty": 2,
      "x": 820,
      "y": 445
    },
    {
      "t": 145247,
      "e": 137752,
      "ty": 41,
      "x": 27584,
      "y": 24928,
      "ta": "html > body"
    },
    {
      "t": 145295,
      "e": 137800,
      "ty": 2,
      "x": 802,
      "y": 472
    },
    {
      "t": 145396,
      "e": 137901,
      "ty": 2,
      "x": 772,
      "y": 530
    },
    {
      "t": 145496,
      "e": 138001,
      "ty": 2,
      "x": 695,
      "y": 597
    },
    {
      "t": 145496,
      "e": 138001,
      "ty": 41,
      "x": 23658,
      "y": 32629,
      "ta": "html > body"
    },
    {
      "t": 145596,
      "e": 138101,
      "ty": 2,
      "x": 625,
      "y": 620
    },
    {
      "t": 145695,
      "e": 138200,
      "ty": 2,
      "x": 619,
      "y": 621
    },
    {
      "t": 145746,
      "e": 138251,
      "ty": 41,
      "x": 21041,
      "y": 33958,
      "ta": "html > body"
    },
    {
      "t": 146596,
      "e": 139101,
      "ty": 2,
      "x": 690,
      "y": 664
    },
    {
      "t": 146695,
      "e": 139200,
      "ty": 2,
      "x": 951,
      "y": 725
    },
    {
      "t": 146746,
      "e": 139251,
      "ty": 41,
      "x": 37291,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 146796,
      "e": 139301,
      "ty": 2,
      "x": 971,
      "y": 725
    },
    {
      "t": 146996,
      "e": 139501,
      "ty": 41,
      "x": 37542,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 147246,
      "e": 139751,
      "ty": 41,
      "x": 30989,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 147296,
      "e": 139801,
      "ty": 2,
      "x": 928,
      "y": 712
    },
    {
      "t": 147396,
      "e": 139901,
      "ty": 2,
      "x": 910,
      "y": 704
    },
    {
      "t": 147496,
      "e": 140001,
      "ty": 2,
      "x": 894,
      "y": 697
    },
    {
      "t": 147496,
      "e": 140001,
      "ty": 41,
      "x": 18288,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 147595,
      "e": 140100,
      "ty": 2,
      "x": 850,
      "y": 686
    },
    {
      "t": 147696,
      "e": 140201,
      "ty": 2,
      "x": 847,
      "y": 695
    },
    {
      "t": 147746,
      "e": 140251,
      "ty": 41,
      "x": 6445,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 147795,
      "e": 140300,
      "ty": 2,
      "x": 847,
      "y": 709
    },
    {
      "t": 147896,
      "e": 140401,
      "ty": 2,
      "x": 844,
      "y": 721
    },
    {
      "t": 147995,
      "e": 140500,
      "ty": 2,
      "x": 838,
      "y": 737
    },
    {
      "t": 147996,
      "e": 140501,
      "ty": 41,
      "x": 4160,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 148096,
      "e": 140601,
      "ty": 2,
      "x": 836,
      "y": 744
    },
    {
      "t": 148246,
      "e": 140751,
      "ty": 41,
      "x": 3459,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 148396,
      "e": 140901,
      "ty": 2,
      "x": 831,
      "y": 740
    },
    {
      "t": 148496,
      "e": 141001,
      "ty": 2,
      "x": 830,
      "y": 738
    },
    {
      "t": 148496,
      "e": 141001,
      "ty": 41,
      "x": 2152,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 148590,
      "e": 141095,
      "ty": 3,
      "x": 830,
      "y": 738,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 148591,
      "e": 141096,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 148676,
      "e": 141181,
      "ty": 4,
      "x": 2152,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 148676,
      "e": 141181,
      "ty": 5,
      "x": 830,
      "y": 738,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 148677,
      "e": 141182,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 148677,
      "e": 141182,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 149095,
      "e": 141600,
      "ty": 2,
      "x": 830,
      "y": 741
    },
    {
      "t": 149196,
      "e": 141701,
      "ty": 2,
      "x": 830,
      "y": 748
    },
    {
      "t": 149246,
      "e": 141751,
      "ty": 41,
      "x": 3579,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 149261,
      "e": 141752,
      "ty": 6,
      "x": 830,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 149295,
      "e": 141786,
      "ty": 2,
      "x": 830,
      "y": 753
    },
    {
      "t": 149396,
      "e": 141887,
      "ty": 2,
      "x": 830,
      "y": 759
    },
    {
      "t": 149476,
      "e": 141967,
      "ty": 3,
      "x": 830,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 149478,
      "e": 141969,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 149479,
      "e": 141970,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 149496,
      "e": 141987,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 149555,
      "e": 142046,
      "ty": 4,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 149556,
      "e": 142047,
      "ty": 5,
      "x": 830,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 149556,
      "e": 142047,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf",
      "v": "Natural Sciences"
    },
    {
      "t": 149949,
      "e": 142440,
      "ty": 7,
      "x": 830,
      "y": 810,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 149950,
      "e": 142441,
      "ty": 6,
      "x": 830,
      "y": 810,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 149965,
      "e": 142456,
      "ty": 7,
      "x": 830,
      "y": 890,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 149996,
      "e": 142487,
      "ty": 2,
      "x": 835,
      "y": 969
    },
    {
      "t": 149996,
      "e": 142487,
      "ty": 41,
      "x": 10983,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 149999,
      "e": 142490,
      "ty": 6,
      "x": 843,
      "y": 1017,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 150015,
      "e": 142506,
      "ty": 7,
      "x": 850,
      "y": 1045,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 150096,
      "e": 142587,
      "ty": 2,
      "x": 855,
      "y": 1072
    },
    {
      "t": 150196,
      "e": 142687,
      "ty": 2,
      "x": 850,
      "y": 1073
    },
    {
      "t": 150246,
      "e": 142737,
      "ty": 41,
      "x": 28514,
      "y": 58665,
      "ta": "html > body"
    },
    {
      "t": 150296,
      "e": 142787,
      "ty": 2,
      "x": 825,
      "y": 1057
    },
    {
      "t": 150396,
      "e": 142887,
      "ty": 2,
      "x": 815,
      "y": 1016
    },
    {
      "t": 150495,
      "e": 142986,
      "ty": 2,
      "x": 815,
      "y": 993
    },
    {
      "t": 150496,
      "e": 142987,
      "ty": 41,
      "x": 27791,
      "y": 54566,
      "ta": "html > body"
    },
    {
      "t": 150596,
      "e": 143087,
      "ty": 2,
      "x": 822,
      "y": 965
    },
    {
      "t": 150696,
      "e": 143187,
      "ty": 2,
      "x": 824,
      "y": 940
    },
    {
      "t": 150716,
      "e": 143207,
      "ty": 6,
      "x": 826,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 150746,
      "e": 143237,
      "ty": 41,
      "x": 0,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 150796,
      "e": 143287,
      "ty": 2,
      "x": 826,
      "y": 934
    },
    {
      "t": 150896,
      "e": 143387,
      "ty": 2,
      "x": 827,
      "y": 940
    },
    {
      "t": 150900,
      "e": 143391,
      "ty": 7,
      "x": 828,
      "y": 944,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 150996,
      "e": 143487,
      "ty": 2,
      "x": 830,
      "y": 949
    },
    {
      "t": 150996,
      "e": 143487,
      "ty": 41,
      "x": 2035,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 151096,
      "e": 143587,
      "ty": 2,
      "x": 830,
      "y": 953
    },
    {
      "t": 151167,
      "e": 143658,
      "ty": 6,
      "x": 830,
      "y": 958,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 151195,
      "e": 143686,
      "ty": 2,
      "x": 830,
      "y": 959
    },
    {
      "t": 151246,
      "e": 143737,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 151296,
      "e": 143787,
      "ty": 2,
      "x": 830,
      "y": 963
    },
    {
      "t": 151645,
      "e": 144136,
      "ty": 3,
      "x": 830,
      "y": 963,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 151646,
      "e": 144137,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 151647,
      "e": 144138,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 151787,
      "e": 144278,
      "ty": 4,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 151788,
      "e": 144279,
      "ty": 5,
      "x": 830,
      "y": 963,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 151789,
      "e": 144280,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 151909,
      "e": 144400,
      "ty": 7,
      "x": 831,
      "y": 969,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 151950,
      "e": 144441,
      "ty": 6,
      "x": 837,
      "y": 995,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 151967,
      "e": 144458,
      "ty": 7,
      "x": 841,
      "y": 1005,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 151967,
      "e": 144458,
      "ty": 6,
      "x": 841,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 151996,
      "e": 144487,
      "ty": 2,
      "x": 846,
      "y": 1017
    },
    {
      "t": 151996,
      "e": 144487,
      "ty": 41,
      "x": 8544,
      "y": 23830,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 152096,
      "e": 144587,
      "ty": 2,
      "x": 858,
      "y": 1033
    },
    {
      "t": 152246,
      "e": 144737,
      "ty": 41,
      "x": 14728,
      "y": 55605,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 152696,
      "e": 145187,
      "ty": 2,
      "x": 860,
      "y": 1033
    },
    {
      "t": 152746,
      "e": 145237,
      "ty": 41,
      "x": 17305,
      "y": 53619,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 152796,
      "e": 145287,
      "ty": 2,
      "x": 863,
      "y": 1032
    },
    {
      "t": 153195,
      "e": 145686,
      "ty": 2,
      "x": 866,
      "y": 1027
    },
    {
      "t": 153247,
      "e": 145738,
      "ty": 41,
      "x": 21944,
      "y": 39718,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 153295,
      "e": 145786,
      "ty": 2,
      "x": 875,
      "y": 1023
    },
    {
      "t": 153496,
      "e": 145987,
      "ty": 41,
      "x": 23490,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 154534,
      "e": 145988,
      "ty": 3,
      "x": 875,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 154536,
      "e": 145990,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 154536,
      "e": 145990,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 154604,
      "e": 146058,
      "ty": 4,
      "x": 23490,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 154604,
      "e": 146058,
      "ty": 5,
      "x": 875,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 154605,
      "e": 146059,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 154606,
      "e": 146060,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 154608,
      "e": 146062,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 155946,
      "e": 147400,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 159997,
      "e": 151060,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 165397,
      "e": 151060,
      "ty": 2,
      "x": 878,
      "y": 1021
    },
    {
      "t": 165497,
      "e": 151160,
      "ty": 41,
      "x": 28757,
      "y": 61955,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 165997,
      "e": 151660,
      "ty": 2,
      "x": 893,
      "y": 1016
    },
    {
      "t": 165997,
      "e": 151660,
      "ty": 41,
      "x": 29495,
      "y": 61609,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 166096,
      "e": 151759,
      "ty": 2,
      "x": 900,
      "y": 1014
    },
    {
      "t": 166246,
      "e": 151909,
      "ty": 41,
      "x": 29840,
      "y": 61471,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 166295,
      "e": 151958,
      "ty": 2,
      "x": 898,
      "y": 1011
    },
    {
      "t": 166396,
      "e": 152059,
      "ty": 2,
      "x": 896,
      "y": 1007
    },
    {
      "t": 166496,
      "e": 152159,
      "ty": 41,
      "x": 29643,
      "y": 60986,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 167096,
      "e": 152759,
      "ty": 2,
      "x": 891,
      "y": 902
    },
    {
      "t": 167196,
      "e": 152859,
      "ty": 2,
      "x": 948,
      "y": 813
    },
    {
      "t": 167246,
      "e": 152909,
      "ty": 41,
      "x": 32201,
      "y": 16987,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 168246,
      "e": 153909,
      "ty": 41,
      "x": 31660,
      "y": 9965,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 168296,
      "e": 153959,
      "ty": 2,
      "x": 902,
      "y": 798
    },
    {
      "t": 168396,
      "e": 154059,
      "ty": 2,
      "x": 742,
      "y": 744
    },
    {
      "t": 168495,
      "e": 154158,
      "ty": 2,
      "x": 639,
      "y": 709
    },
    {
      "t": 168495,
      "e": 154158,
      "ty": 41,
      "x": 16999,
      "y": 23707,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 168596,
      "e": 154259,
      "ty": 2,
      "x": 651,
      "y": 709
    },
    {
      "t": 168695,
      "e": 154358,
      "ty": 2,
      "x": 771,
      "y": 723
    },
    {
      "t": 168746,
      "e": 154409,
      "ty": 41,
      "x": 24084,
      "y": 29558,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 168795,
      "e": 154458,
      "ty": 2,
      "x": 785,
      "y": 717
    },
    {
      "t": 168895,
      "e": 154558,
      "ty": 2,
      "x": 788,
      "y": 714
    },
    {
      "t": 168996,
      "e": 154659,
      "ty": 41,
      "x": 24330,
      "y": 26632,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 169196,
      "e": 154859,
      "ty": 2,
      "x": 809,
      "y": 713
    },
    {
      "t": 169246,
      "e": 154909,
      "ty": 41,
      "x": 31660,
      "y": 26047,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 169296,
      "e": 154959,
      "ty": 2,
      "x": 1038,
      "y": 711
    },
    {
      "t": 169396,
      "e": 155059,
      "ty": 2,
      "x": 1069,
      "y": 709
    },
    {
      "t": 169496,
      "e": 155159,
      "ty": 2,
      "x": 1169,
      "y": 709
    },
    {
      "t": 169496,
      "e": 155159,
      "ty": 41,
      "x": 43074,
      "y": 23707,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 169596,
      "e": 155259,
      "ty": 2,
      "x": 1248,
      "y": 709
    },
    {
      "t": 169696,
      "e": 155359,
      "ty": 2,
      "x": 1288,
      "y": 706
    },
    {
      "t": 169746,
      "e": 155409,
      "ty": 41,
      "x": 49027,
      "y": 21951,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 169796,
      "e": 155459,
      "ty": 2,
      "x": 1290,
      "y": 706
    },
    {
      "t": 170246,
      "e": 155909,
      "ty": 41,
      "x": 48977,
      "y": 21951,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 170296,
      "e": 155959,
      "ty": 2,
      "x": 1186,
      "y": 723
    },
    {
      "t": 170396,
      "e": 156059,
      "ty": 2,
      "x": 1001,
      "y": 747
    },
    {
      "t": 170496,
      "e": 156159,
      "ty": 41,
      "x": 34809,
      "y": 45942,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 172696,
      "e": 158359,
      "ty": 2,
      "x": 1000,
      "y": 748
    },
    {
      "t": 172746,
      "e": 158409,
      "ty": 41,
      "x": 35202,
      "y": 45357,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 172796,
      "e": 158459,
      "ty": 2,
      "x": 1016,
      "y": 742
    },
    {
      "t": 172895,
      "e": 158558,
      "ty": 2,
      "x": 1025,
      "y": 738
    },
    {
      "t": 172996,
      "e": 158659,
      "ty": 2,
      "x": 1027,
      "y": 737
    },
    {
      "t": 172997,
      "e": 158660,
      "ty": 41,
      "x": 36088,
      "y": 40090,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 179994,
      "e": 163660,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 180193,
      "e": 163660,
      "ty": 2,
      "x": 987,
      "y": 859
    },
    {
      "t": 180244,
      "e": 163711,
      "ty": 41,
      "x": 33726,
      "y": 57177,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 180293,
      "e": 163760,
      "ty": 2,
      "x": 981,
      "y": 1012
    },
    {
      "t": 180383,
      "e": 163850,
      "ty": 6,
      "x": 989,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 180393,
      "e": 163860,
      "ty": 2,
      "x": 989,
      "y": 1073
    },
    {
      "t": 180493,
      "e": 163960,
      "ty": 2,
      "x": 984,
      "y": 1089
    },
    {
      "t": 180494,
      "e": 163961,
      "ty": 41,
      "x": 40686,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 180594,
      "e": 164061,
      "ty": 2,
      "x": 982,
      "y": 1093
    },
    {
      "t": 180743,
      "e": 164210,
      "ty": 41,
      "x": 39594,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 181890,
      "e": 165357,
      "ty": 3,
      "x": 982,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 181892,
      "e": 165359,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 182081,
      "e": 165548,
      "ty": 4,
      "x": 39594,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 182082,
      "e": 165549,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 182083,
      "e": 165550,
      "ty": 5,
      "x": 982,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 182083,
      "e": 165550,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 183114,
      "e": 166581,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 184306,
      "e": 167773,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 116561, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 116568, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 7715, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 125618, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 14185, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"CHARLIE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 140810, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 14520, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 156412, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 12719, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 170133, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 26179, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 197687, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-0-08 AM-09 AM-10 AM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:996,y:1080,t:1526929853215};\\\", \\\"{x:1027,y:1067,t:1526929853233};\\\", \\\"{x:1087,y:1045,t:1526929853250};\\\", \\\"{x:1119,y:1034,t:1526929853265};\\\", \\\"{x:1133,y:1027,t:1526929853282};\\\", \\\"{x:1138,y:1025,t:1526929853299};\\\", \\\"{x:1145,y:1021,t:1526929853315};\\\", \\\"{x:1151,y:1019,t:1526929853332};\\\", \\\"{x:1161,y:1013,t:1526929853348};\\\", \\\"{x:1183,y:987,t:1526929853365};\\\", \\\"{x:1202,y:960,t:1526929853382};\\\", \\\"{x:1233,y:913,t:1526929853398};\\\", \\\"{x:1262,y:857,t:1526929853415};\\\", \\\"{x:1301,y:783,t:1526929853433};\\\", \\\"{x:1346,y:687,t:1526929853449};\\\", \\\"{x:1388,y:567,t:1526929853466};\\\", \\\"{x:1442,y:437,t:1526929853482};\\\", \\\"{x:1495,y:313,t:1526929853499};\\\", \\\"{x:1549,y:189,t:1526929853516};\\\", \\\"{x:1581,y:89,t:1526929853533};\\\", \\\"{x:1620,y:0,t:1526929853549};\\\", \\\"{x:1631,y:0,t:1526929853566};\\\", \\\"{x:1637,y:0,t:1526929853583};\\\", \\\"{x:1640,y:0,t:1526929853600};\\\", \\\"{x:1638,y:3,t:1526929853654};\\\", \\\"{x:1632,y:5,t:1526929853666};\\\", \\\"{x:1625,y:6,t:1526929853683};\\\", \\\"{x:1618,y:9,t:1526929853700};\\\", \\\"{x:1610,y:13,t:1526929853716};\\\", \\\"{x:1606,y:14,t:1526929853733};\\\", \\\"{x:1605,y:14,t:1526929853750};\\\", \\\"{x:1603,y:14,t:1526929853861};\\\", \\\"{x:1599,y:17,t:1526929853869};\\\", \\\"{x:1590,y:21,t:1526929853883};\\\", \\\"{x:1561,y:38,t:1526929853900};\\\", \\\"{x:1501,y:73,t:1526929853916};\\\", \\\"{x:1413,y:123,t:1526929853933};\\\", \\\"{x:1251,y:244,t:1526929853949};\\\", \\\"{x:1133,y:343,t:1526929853967};\\\", \\\"{x:1024,y:435,t:1526929853984};\\\", \\\"{x:924,y:529,t:1526929854001};\\\", \\\"{x:836,y:618,t:1526929854016};\\\", \\\"{x:777,y:689,t:1526929854032};\\\", \\\"{x:741,y:740,t:1526929854050};\\\", \\\"{x:723,y:777,t:1526929854065};\\\", \\\"{x:716,y:802,t:1526929854082};\\\", \\\"{x:715,y:824,t:1526929854100};\\\", \\\"{x:715,y:841,t:1526929854115};\\\", \\\"{x:715,y:857,t:1526929854133};\\\", \\\"{x:714,y:859,t:1526929854150};\\\", \\\"{x:714,y:860,t:1526929854662};\\\", \\\"{x:714,y:861,t:1526929854702};\\\", \\\"{x:716,y:866,t:1526929854718};\\\", \\\"{x:719,y:869,t:1526929854734};\\\", \\\"{x:726,y:873,t:1526929854750};\\\", \\\"{x:738,y:880,t:1526929854767};\\\", \\\"{x:748,y:885,t:1526929854784};\\\", \\\"{x:765,y:892,t:1526929854800};\\\", \\\"{x:784,y:900,t:1526929854817};\\\", \\\"{x:801,y:907,t:1526929854834};\\\", \\\"{x:814,y:914,t:1526929854851};\\\", \\\"{x:834,y:922,t:1526929854866};\\\", \\\"{x:855,y:925,t:1526929854884};\\\", \\\"{x:875,y:931,t:1526929854900};\\\", \\\"{x:896,y:936,t:1526929854917};\\\", \\\"{x:925,y:942,t:1526929854934};\\\", \\\"{x:939,y:946,t:1526929854950};\\\", \\\"{x:951,y:949,t:1526929854967};\\\", \\\"{x:966,y:950,t:1526929854984};\\\", \\\"{x:979,y:952,t:1526929855000};\\\", \\\"{x:992,y:955,t:1526929855018};\\\", \\\"{x:1006,y:957,t:1526929855034};\\\", \\\"{x:1023,y:961,t:1526929855052};\\\", \\\"{x:1044,y:965,t:1526929855067};\\\", \\\"{x:1061,y:967,t:1526929855084};\\\", \\\"{x:1077,y:970,t:1526929855101};\\\", \\\"{x:1091,y:972,t:1526929855118};\\\", \\\"{x:1107,y:973,t:1526929855134};\\\", \\\"{x:1118,y:974,t:1526929855151};\\\", \\\"{x:1130,y:976,t:1526929855168};\\\", \\\"{x:1137,y:976,t:1526929855184};\\\", \\\"{x:1146,y:979,t:1526929855200};\\\", \\\"{x:1152,y:979,t:1526929855218};\\\", \\\"{x:1160,y:980,t:1526929855234};\\\", \\\"{x:1167,y:980,t:1526929855251};\\\", \\\"{x:1173,y:981,t:1526929855268};\\\", \\\"{x:1177,y:981,t:1526929855284};\\\", \\\"{x:1181,y:981,t:1526929855301};\\\", \\\"{x:1183,y:981,t:1526929855317};\\\", \\\"{x:1184,y:981,t:1526929855358};\\\", \\\"{x:1185,y:981,t:1526929855382};\\\", \\\"{x:1186,y:981,t:1526929855390};\\\", \\\"{x:1187,y:981,t:1526929855401};\\\", \\\"{x:1190,y:981,t:1526929855417};\\\", \\\"{x:1195,y:981,t:1526929855435};\\\", \\\"{x:1201,y:981,t:1526929855451};\\\", \\\"{x:1205,y:981,t:1526929855467};\\\", \\\"{x:1211,y:981,t:1526929855484};\\\", \\\"{x:1216,y:981,t:1526929855501};\\\", \\\"{x:1219,y:981,t:1526929855517};\\\", \\\"{x:1225,y:980,t:1526929855534};\\\", \\\"{x:1228,y:980,t:1526929855551};\\\", \\\"{x:1230,y:979,t:1526929855567};\\\", \\\"{x:1234,y:979,t:1526929855585};\\\", \\\"{x:1240,y:977,t:1526929855602};\\\", \\\"{x:1245,y:976,t:1526929855617};\\\", \\\"{x:1249,y:976,t:1526929855634};\\\", \\\"{x:1252,y:974,t:1526929855653};\\\", \\\"{x:1257,y:973,t:1526929855668};\\\", \\\"{x:1261,y:972,t:1526929855684};\\\", \\\"{x:1265,y:971,t:1526929855702};\\\", \\\"{x:1270,y:969,t:1526929855718};\\\", \\\"{x:1271,y:969,t:1526929855734};\\\", \\\"{x:1273,y:968,t:1526929855752};\\\", \\\"{x:1274,y:968,t:1526929855767};\\\", \\\"{x:1275,y:968,t:1526929855784};\\\", \\\"{x:1276,y:968,t:1526929855805};\\\", \\\"{x:1277,y:967,t:1526929855818};\\\", \\\"{x:1277,y:966,t:1526929855834};\\\", \\\"{x:1278,y:965,t:1526929855852};\\\", \\\"{x:1279,y:965,t:1526929855868};\\\", \\\"{x:1279,y:963,t:1526929855885};\\\", \\\"{x:1280,y:963,t:1526929855902};\\\", \\\"{x:1280,y:962,t:1526929855926};\\\", \\\"{x:1281,y:961,t:1526929855958};\\\", \\\"{x:1282,y:961,t:1526929855981};\\\", \\\"{x:1281,y:961,t:1526929856969};\\\", \\\"{x:1277,y:961,t:1526929856977};\\\", \\\"{x:1272,y:961,t:1526929856988};\\\", \\\"{x:1263,y:961,t:1526929857004};\\\", \\\"{x:1208,y:951,t:1526929857021};\\\", \\\"{x:1092,y:937,t:1526929857039};\\\", \\\"{x:955,y:924,t:1526929857055};\\\", \\\"{x:758,y:882,t:1526929857072};\\\", \\\"{x:618,y:832,t:1526929857087};\\\", \\\"{x:489,y:775,t:1526929857104};\\\", \\\"{x:385,y:722,t:1526929857120};\\\", \\\"{x:309,y:678,t:1526929857137};\\\", \\\"{x:266,y:646,t:1526929857155};\\\", \\\"{x:241,y:628,t:1526929857170};\\\", \\\"{x:228,y:617,t:1526929857188};\\\", \\\"{x:221,y:606,t:1526929857204};\\\", \\\"{x:217,y:596,t:1526929857221};\\\", \\\"{x:214,y:585,t:1526929857238};\\\", \\\"{x:214,y:575,t:1526929857255};\\\", \\\"{x:214,y:569,t:1526929857272};\\\", \\\"{x:214,y:565,t:1526929857288};\\\", \\\"{x:221,y:560,t:1526929857305};\\\", \\\"{x:237,y:558,t:1526929857321};\\\", \\\"{x:257,y:555,t:1526929857338};\\\", \\\"{x:286,y:553,t:1526929857356};\\\", \\\"{x:319,y:547,t:1526929857372};\\\", \\\"{x:363,y:537,t:1526929857389};\\\", \\\"{x:389,y:530,t:1526929857406};\\\", \\\"{x:402,y:527,t:1526929857421};\\\", \\\"{x:407,y:524,t:1526929857438};\\\", \\\"{x:408,y:524,t:1526929857456};\\\", \\\"{x:408,y:523,t:1526929857568};\\\", \\\"{x:407,y:523,t:1526929857576};\\\", \\\"{x:407,y:522,t:1526929857589};\\\", \\\"{x:404,y:521,t:1526929857605};\\\", \\\"{x:400,y:521,t:1526929857621};\\\", \\\"{x:396,y:519,t:1526929857638};\\\", \\\"{x:391,y:519,t:1526929857656};\\\", \\\"{x:388,y:518,t:1526929857672};\\\", \\\"{x:384,y:517,t:1526929857688};\\\", \\\"{x:381,y:517,t:1526929857705};\\\", \\\"{x:381,y:516,t:1526929857722};\\\", \\\"{x:381,y:517,t:1526929858463};\\\", \\\"{x:381,y:518,t:1526929858472};\\\", \\\"{x:381,y:520,t:1526929858489};\\\", \\\"{x:382,y:524,t:1526929858506};\\\", \\\"{x:389,y:533,t:1526929858523};\\\", \\\"{x:396,y:541,t:1526929858540};\\\", \\\"{x:404,y:548,t:1526929858557};\\\", \\\"{x:416,y:565,t:1526929858572};\\\", \\\"{x:429,y:583,t:1526929858590};\\\", \\\"{x:442,y:602,t:1526929858606};\\\", \\\"{x:453,y:618,t:1526929858623};\\\", \\\"{x:467,y:642,t:1526929858640};\\\", \\\"{x:472,y:652,t:1526929858657};\\\", \\\"{x:479,y:664,t:1526929858673};\\\", \\\"{x:487,y:678,t:1526929858690};\\\", \\\"{x:496,y:693,t:1526929858707};\\\", \\\"{x:500,y:701,t:1526929858723};\\\", \\\"{x:504,y:705,t:1526929858739};\\\", \\\"{x:506,y:708,t:1526929858756};\\\", \\\"{x:508,y:710,t:1526929858772};\\\", \\\"{x:511,y:712,t:1526929858789};\\\", \\\"{x:515,y:718,t:1526929858806};\\\", \\\"{x:519,y:722,t:1526929858823};\\\", \\\"{x:524,y:729,t:1526929858840};\\\", \\\"{x:526,y:732,t:1526929858856};\\\", \\\"{x:527,y:733,t:1526929858874};\\\", \\\"{x:528,y:733,t:1526929858928};\\\", \\\"{x:529,y:733,t:1526929858960};\\\", \\\"{x:529,y:734,t:1526929858973};\\\", \\\"{x:531,y:734,t:1526929859008};\\\", \\\"{x:532,y:734,t:1526929859032};\\\", \\\"{x:534,y:734,t:1526929859048};\\\", \\\"{x:535,y:733,t:1526929859064};\\\", \\\"{x:535,y:732,t:1526929859088};\\\", \\\"{x:536,y:731,t:1526929859184};\\\", \\\"{x:536,y:729,t:1526929867528};\\\", \\\"{x:536,y:728,t:1526929867536};\\\", \\\"{x:536,y:726,t:1526929867549};\\\", \\\"{x:536,y:725,t:1526929867568};\\\", \\\"{x:536,y:724,t:1526929867582};\\\", \\\"{x:537,y:723,t:1526929867608};\\\", \\\"{x:537,y:722,t:1526929867641};\\\", \\\"{x:537,y:720,t:1526929867649};\\\", \\\"{x:535,y:717,t:1526929867666};\\\", \\\"{x:528,y:711,t:1526929867682};\\\", \\\"{x:515,y:706,t:1526929867699};\\\", \\\"{x:496,y:700,t:1526929867717};\\\", \\\"{x:479,y:693,t:1526929867732};\\\", \\\"{x:463,y:687,t:1526929867748};\\\", \\\"{x:449,y:683,t:1526929867763};\\\", \\\"{x:442,y:680,t:1526929867779};\\\", \\\"{x:439,y:679,t:1526929867796};\\\", \\\"{x:436,y:678,t:1526929867814};\\\", \\\"{x:437,y:678,t:1526929868080};\\\", \\\"{x:441,y:680,t:1526929868097};\\\", \\\"{x:443,y:681,t:1526929868114};\\\", \\\"{x:448,y:684,t:1526929868131};\\\", \\\"{x:454,y:688,t:1526929868148};\\\", \\\"{x:461,y:692,t:1526929868164};\\\", \\\"{x:470,y:697,t:1526929868181};\\\", \\\"{x:474,y:701,t:1526929868199};\\\", \\\"{x:479,y:705,t:1526929868214};\\\", \\\"{x:483,y:708,t:1526929868232};\\\", \\\"{x:485,y:708,t:1526929868248};\\\", \\\"{x:485,y:709,t:1526929868264};\\\", \\\"{x:486,y:709,t:1526929868319};\\\", \\\"{x:486,y:710,t:1526929868776};\\\", \\\"{x:487,y:712,t:1526929873832};\\\", \\\"{x:489,y:712,t:1526929873840};\\\", \\\"{x:491,y:715,t:1526929873854};\\\", \\\"{x:493,y:715,t:1526929873888};\\\", \\\"{x:494,y:716,t:1526929873903};\\\" ] }, { \\\"rt\\\": 17067, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 216003, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:718,t:1526929877368};\\\", \\\"{x:513,y:725,t:1526929877387};\\\", \\\"{x:534,y:731,t:1526929877402};\\\", \\\"{x:569,y:743,t:1526929877421};\\\", \\\"{x:622,y:759,t:1526929877436};\\\", \\\"{x:698,y:783,t:1526929877455};\\\", \\\"{x:759,y:799,t:1526929877470};\\\", \\\"{x:818,y:816,t:1526929877488};\\\", \\\"{x:856,y:824,t:1526929877505};\\\", \\\"{x:894,y:834,t:1526929877521};\\\", \\\"{x:921,y:841,t:1526929877538};\\\", \\\"{x:947,y:846,t:1526929877555};\\\", \\\"{x:970,y:852,t:1526929877571};\\\", \\\"{x:998,y:858,t:1526929877588};\\\", \\\"{x:1031,y:863,t:1526929877605};\\\", \\\"{x:1058,y:866,t:1526929877621};\\\", \\\"{x:1082,y:871,t:1526929877638};\\\", \\\"{x:1121,y:876,t:1526929877655};\\\", \\\"{x:1145,y:880,t:1526929877671};\\\", \\\"{x:1164,y:880,t:1526929877688};\\\", \\\"{x:1187,y:880,t:1526929877705};\\\", \\\"{x:1209,y:881,t:1526929877721};\\\", \\\"{x:1229,y:882,t:1526929877738};\\\", \\\"{x:1237,y:884,t:1526929877755};\\\", \\\"{x:1238,y:884,t:1526929877771};\\\", \\\"{x:1240,y:884,t:1526929880929};\\\", \\\"{x:1242,y:883,t:1526929880942};\\\", \\\"{x:1247,y:871,t:1526929880958};\\\", \\\"{x:1257,y:852,t:1526929880975};\\\", \\\"{x:1274,y:818,t:1526929880992};\\\", \\\"{x:1285,y:792,t:1526929881008};\\\", \\\"{x:1294,y:772,t:1526929881025};\\\", \\\"{x:1305,y:743,t:1526929881042};\\\", \\\"{x:1319,y:710,t:1526929881058};\\\", \\\"{x:1339,y:665,t:1526929881074};\\\", \\\"{x:1358,y:619,t:1526929881091};\\\", \\\"{x:1382,y:568,t:1526929881108};\\\", \\\"{x:1403,y:521,t:1526929881125};\\\", \\\"{x:1428,y:475,t:1526929881141};\\\", \\\"{x:1450,y:442,t:1526929881158};\\\", \\\"{x:1468,y:420,t:1526929881175};\\\", \\\"{x:1494,y:392,t:1526929881192};\\\", \\\"{x:1516,y:376,t:1526929881208};\\\", \\\"{x:1540,y:363,t:1526929881225};\\\", \\\"{x:1562,y:349,t:1526929881242};\\\", \\\"{x:1581,y:338,t:1526929881258};\\\", \\\"{x:1595,y:330,t:1526929881275};\\\", \\\"{x:1613,y:323,t:1526929881292};\\\", \\\"{x:1627,y:319,t:1526929881308};\\\", \\\"{x:1636,y:317,t:1526929881325};\\\", \\\"{x:1637,y:317,t:1526929881342};\\\", \\\"{x:1636,y:320,t:1526929881505};\\\", \\\"{x:1632,y:326,t:1526929881512};\\\", \\\"{x:1628,y:331,t:1526929881525};\\\", \\\"{x:1624,y:338,t:1526929881542};\\\", \\\"{x:1617,y:346,t:1526929881559};\\\", \\\"{x:1610,y:355,t:1526929881575};\\\", \\\"{x:1596,y:371,t:1526929881591};\\\", \\\"{x:1584,y:380,t:1526929881609};\\\", \\\"{x:1575,y:386,t:1526929881625};\\\", \\\"{x:1566,y:392,t:1526929881642};\\\", \\\"{x:1556,y:396,t:1526929881659};\\\", \\\"{x:1551,y:399,t:1526929881675};\\\", \\\"{x:1547,y:403,t:1526929881692};\\\", \\\"{x:1544,y:406,t:1526929881709};\\\", \\\"{x:1543,y:407,t:1526929881725};\\\", \\\"{x:1543,y:409,t:1526929881752};\\\", \\\"{x:1543,y:410,t:1526929881768};\\\", \\\"{x:1543,y:411,t:1526929881776};\\\", \\\"{x:1544,y:415,t:1526929881792};\\\", \\\"{x:1547,y:417,t:1526929881808};\\\", \\\"{x:1552,y:420,t:1526929881826};\\\", \\\"{x:1558,y:421,t:1526929881842};\\\", \\\"{x:1561,y:423,t:1526929881859};\\\", \\\"{x:1562,y:424,t:1526929881876};\\\", \\\"{x:1564,y:424,t:1526929881892};\\\", \\\"{x:1566,y:426,t:1526929881909};\\\", \\\"{x:1567,y:426,t:1526929881926};\\\", \\\"{x:1572,y:427,t:1526929881942};\\\", \\\"{x:1575,y:427,t:1526929881959};\\\", \\\"{x:1585,y:429,t:1526929881976};\\\", \\\"{x:1591,y:429,t:1526929881992};\\\", \\\"{x:1596,y:429,t:1526929882009};\\\", \\\"{x:1597,y:429,t:1526929882026};\\\", \\\"{x:1598,y:429,t:1526929882042};\\\", \\\"{x:1598,y:430,t:1526929882480};\\\", \\\"{x:1599,y:430,t:1526929882512};\\\", \\\"{x:1599,y:431,t:1526929882526};\\\", \\\"{x:1601,y:432,t:1526929882543};\\\", \\\"{x:1602,y:433,t:1526929882559};\\\", \\\"{x:1607,y:434,t:1526929882576};\\\", \\\"{x:1608,y:435,t:1526929882607};\\\", \\\"{x:1609,y:436,t:1526929882680};\\\", \\\"{x:1609,y:437,t:1526929882695};\\\", \\\"{x:1610,y:437,t:1526929882710};\\\", \\\"{x:1611,y:438,t:1526929882725};\\\", \\\"{x:1611,y:439,t:1526929882760};\\\", \\\"{x:1612,y:440,t:1526929882775};\\\", \\\"{x:1613,y:440,t:1526929882792};\\\", \\\"{x:1614,y:442,t:1526929882810};\\\", \\\"{x:1615,y:443,t:1526929882826};\\\", \\\"{x:1616,y:443,t:1526929882843};\\\", \\\"{x:1617,y:443,t:1526929882871};\\\", \\\"{x:1618,y:444,t:1526929882896};\\\", \\\"{x:1618,y:445,t:1526929883128};\\\", \\\"{x:1619,y:445,t:1526929883192};\\\", \\\"{x:1619,y:447,t:1526929883312};\\\", \\\"{x:1619,y:449,t:1526929883327};\\\", \\\"{x:1621,y:459,t:1526929883343};\\\", \\\"{x:1621,y:488,t:1526929883360};\\\", \\\"{x:1622,y:515,t:1526929883377};\\\", \\\"{x:1624,y:545,t:1526929883392};\\\", \\\"{x:1626,y:588,t:1526929883409};\\\", \\\"{x:1626,y:636,t:1526929883427};\\\", \\\"{x:1626,y:683,t:1526929883443};\\\", \\\"{x:1627,y:742,t:1526929883459};\\\", \\\"{x:1627,y:787,t:1526929883476};\\\", \\\"{x:1627,y:815,t:1526929883493};\\\", \\\"{x:1627,y:837,t:1526929883510};\\\", \\\"{x:1627,y:853,t:1526929883527};\\\", \\\"{x:1627,y:860,t:1526929883543};\\\", \\\"{x:1627,y:866,t:1526929883559};\\\", \\\"{x:1626,y:868,t:1526929883577};\\\", \\\"{x:1625,y:871,t:1526929883593};\\\", \\\"{x:1625,y:873,t:1526929884039};\\\", \\\"{x:1623,y:877,t:1526929884047};\\\", \\\"{x:1623,y:879,t:1526929884061};\\\", \\\"{x:1621,y:891,t:1526929884076};\\\", \\\"{x:1619,y:898,t:1526929884093};\\\", \\\"{x:1617,y:905,t:1526929884111};\\\", \\\"{x:1616,y:911,t:1526929884126};\\\", \\\"{x:1616,y:920,t:1526929884143};\\\", \\\"{x:1616,y:924,t:1526929884160};\\\", \\\"{x:1615,y:928,t:1526929884177};\\\", \\\"{x:1615,y:932,t:1526929884194};\\\", \\\"{x:1615,y:935,t:1526929884211};\\\", \\\"{x:1615,y:938,t:1526929884226};\\\", \\\"{x:1615,y:940,t:1526929884244};\\\", \\\"{x:1615,y:944,t:1526929884261};\\\", \\\"{x:1615,y:946,t:1526929884277};\\\", \\\"{x:1615,y:949,t:1526929884293};\\\", \\\"{x:1615,y:950,t:1526929884311};\\\", \\\"{x:1616,y:951,t:1526929884327};\\\", \\\"{x:1616,y:952,t:1526929884344};\\\", \\\"{x:1617,y:953,t:1526929884425};\\\", \\\"{x:1617,y:952,t:1526929884712};\\\", \\\"{x:1618,y:946,t:1526929884728};\\\", \\\"{x:1621,y:939,t:1526929884744};\\\", \\\"{x:1623,y:930,t:1526929884761};\\\", \\\"{x:1625,y:922,t:1526929884778};\\\", \\\"{x:1626,y:913,t:1526929884794};\\\", \\\"{x:1627,y:903,t:1526929884811};\\\", \\\"{x:1630,y:894,t:1526929884828};\\\", \\\"{x:1630,y:886,t:1526929884844};\\\", \\\"{x:1630,y:871,t:1526929884861};\\\", \\\"{x:1630,y:849,t:1526929884878};\\\", \\\"{x:1628,y:823,t:1526929884894};\\\", \\\"{x:1626,y:798,t:1526929884911};\\\", \\\"{x:1618,y:761,t:1526929884928};\\\", \\\"{x:1613,y:732,t:1526929884945};\\\", \\\"{x:1607,y:704,t:1526929884961};\\\", \\\"{x:1603,y:681,t:1526929884978};\\\", \\\"{x:1596,y:657,t:1526929884995};\\\", \\\"{x:1589,y:633,t:1526929885011};\\\", \\\"{x:1585,y:613,t:1526929885028};\\\", \\\"{x:1583,y:592,t:1526929885045};\\\", \\\"{x:1580,y:578,t:1526929885061};\\\", \\\"{x:1578,y:566,t:1526929885079};\\\", \\\"{x:1576,y:553,t:1526929885095};\\\", \\\"{x:1575,y:541,t:1526929885112};\\\", \\\"{x:1574,y:529,t:1526929885128};\\\", \\\"{x:1574,y:524,t:1526929885145};\\\", \\\"{x:1574,y:518,t:1526929885161};\\\", \\\"{x:1574,y:517,t:1526929885178};\\\", \\\"{x:1574,y:510,t:1526929885195};\\\", \\\"{x:1576,y:507,t:1526929885211};\\\", \\\"{x:1578,y:501,t:1526929885229};\\\", \\\"{x:1581,y:494,t:1526929885245};\\\", \\\"{x:1584,y:488,t:1526929885262};\\\", \\\"{x:1587,y:482,t:1526929885278};\\\", \\\"{x:1591,y:479,t:1526929885295};\\\", \\\"{x:1594,y:476,t:1526929885311};\\\", \\\"{x:1599,y:470,t:1526929885328};\\\", \\\"{x:1603,y:468,t:1526929885345};\\\", \\\"{x:1604,y:468,t:1526929885408};\\\", \\\"{x:1605,y:468,t:1526929885416};\\\", \\\"{x:1607,y:468,t:1526929885428};\\\", \\\"{x:1612,y:474,t:1526929885445};\\\", \\\"{x:1616,y:482,t:1526929885462};\\\", \\\"{x:1620,y:494,t:1526929885478};\\\", \\\"{x:1624,y:504,t:1526929885495};\\\", \\\"{x:1626,y:518,t:1526929885512};\\\", \\\"{x:1626,y:525,t:1526929885528};\\\", \\\"{x:1627,y:528,t:1526929885545};\\\", \\\"{x:1627,y:531,t:1526929885562};\\\", \\\"{x:1627,y:535,t:1526929885578};\\\", \\\"{x:1627,y:537,t:1526929885595};\\\", \\\"{x:1627,y:538,t:1526929885611};\\\", \\\"{x:1627,y:539,t:1526929885629};\\\", \\\"{x:1627,y:540,t:1526929885664};\\\", \\\"{x:1627,y:541,t:1526929885696};\\\", \\\"{x:1627,y:542,t:1526929885719};\\\", \\\"{x:1626,y:543,t:1526929885919};\\\", \\\"{x:1626,y:544,t:1526929885928};\\\", \\\"{x:1624,y:548,t:1526929885944};\\\", \\\"{x:1623,y:550,t:1526929885962};\\\", \\\"{x:1623,y:552,t:1526929885979};\\\", \\\"{x:1622,y:553,t:1526929885995};\\\", \\\"{x:1622,y:554,t:1526929886240};\\\", \\\"{x:1622,y:555,t:1526929886248};\\\", \\\"{x:1622,y:556,t:1526929886264};\\\", \\\"{x:1622,y:557,t:1526929886280};\\\", \\\"{x:1622,y:558,t:1526929886296};\\\", \\\"{x:1622,y:559,t:1526929886480};\\\", \\\"{x:1622,y:560,t:1526929886496};\\\", \\\"{x:1622,y:561,t:1526929886512};\\\", \\\"{x:1622,y:562,t:1526929886560};\\\", \\\"{x:1622,y:563,t:1526929887081};\\\", \\\"{x:1622,y:564,t:1526929887097};\\\", \\\"{x:1621,y:564,t:1526929887114};\\\", \\\"{x:1620,y:564,t:1526929887132};\\\", \\\"{x:1619,y:565,t:1526929887163};\\\", \\\"{x:1618,y:565,t:1526929887180};\\\", \\\"{x:1615,y:565,t:1526929887552};\\\", \\\"{x:1609,y:573,t:1526929887564};\\\", \\\"{x:1587,y:597,t:1526929887580};\\\", \\\"{x:1557,y:621,t:1526929887597};\\\", \\\"{x:1502,y:654,t:1526929887612};\\\", \\\"{x:1424,y:690,t:1526929887629};\\\", \\\"{x:1326,y:728,t:1526929887647};\\\", \\\"{x:1215,y:759,t:1526929887663};\\\", \\\"{x:1046,y:791,t:1526929887679};\\\", \\\"{x:933,y:804,t:1526929887697};\\\", \\\"{x:814,y:804,t:1526929887713};\\\", \\\"{x:700,y:804,t:1526929887730};\\\", \\\"{x:595,y:793,t:1526929887747};\\\", \\\"{x:516,y:776,t:1526929887762};\\\", \\\"{x:463,y:762,t:1526929887780};\\\", \\\"{x:425,y:754,t:1526929887797};\\\", \\\"{x:406,y:743,t:1526929887813};\\\", \\\"{x:390,y:731,t:1526929887829};\\\", \\\"{x:361,y:710,t:1526929887848};\\\", \\\"{x:350,y:703,t:1526929887863};\\\", \\\"{x:324,y:683,t:1526929887879};\\\", \\\"{x:306,y:671,t:1526929887897};\\\", \\\"{x:287,y:651,t:1526929887913};\\\", \\\"{x:266,y:635,t:1526929887932};\\\", \\\"{x:250,y:626,t:1526929887947};\\\", \\\"{x:237,y:620,t:1526929887963};\\\", \\\"{x:228,y:615,t:1526929887980};\\\", \\\"{x:226,y:613,t:1526929887996};\\\", \\\"{x:223,y:610,t:1526929888014};\\\", \\\"{x:223,y:607,t:1526929888029};\\\", \\\"{x:223,y:606,t:1526929888046};\\\", \\\"{x:224,y:606,t:1526929888256};\\\", \\\"{x:227,y:605,t:1526929888264};\\\", \\\"{x:245,y:605,t:1526929888280};\\\", \\\"{x:268,y:605,t:1526929888297};\\\", \\\"{x:292,y:605,t:1526929888316};\\\", \\\"{x:304,y:605,t:1526929888330};\\\", \\\"{x:306,y:605,t:1526929888346};\\\", \\\"{x:306,y:607,t:1526929888363};\\\", \\\"{x:300,y:612,t:1526929888380};\\\", \\\"{x:275,y:621,t:1526929888398};\\\", \\\"{x:247,y:627,t:1526929888414};\\\", \\\"{x:221,y:629,t:1526929888430};\\\", \\\"{x:195,y:634,t:1526929888447};\\\", \\\"{x:187,y:634,t:1526929888463};\\\", \\\"{x:185,y:636,t:1526929888481};\\\", \\\"{x:185,y:637,t:1526929889127};\\\", \\\"{x:185,y:640,t:1526929889135};\\\", \\\"{x:187,y:642,t:1526929889148};\\\", \\\"{x:202,y:647,t:1526929889165};\\\", \\\"{x:223,y:656,t:1526929889181};\\\", \\\"{x:252,y:671,t:1526929889198};\\\", \\\"{x:289,y:686,t:1526929889215};\\\", \\\"{x:349,y:698,t:1526929889231};\\\", \\\"{x:376,y:703,t:1526929889247};\\\", \\\"{x:401,y:704,t:1526929889265};\\\", \\\"{x:420,y:704,t:1526929889280};\\\", \\\"{x:439,y:707,t:1526929889297};\\\", \\\"{x:451,y:707,t:1526929889315};\\\", \\\"{x:458,y:706,t:1526929889330};\\\", \\\"{x:461,y:706,t:1526929889348};\\\", \\\"{x:466,y:705,t:1526929889365};\\\", \\\"{x:467,y:704,t:1526929889380};\\\", \\\"{x:468,y:704,t:1526929889397};\\\", \\\"{x:469,y:704,t:1526929889416};\\\", \\\"{x:471,y:704,t:1526929889432};\\\", \\\"{x:475,y:704,t:1526929889450};\\\", \\\"{x:480,y:704,t:1526929889465};\\\", \\\"{x:486,y:704,t:1526929889481};\\\", \\\"{x:488,y:704,t:1526929889498};\\\", \\\"{x:489,y:704,t:1526929889728};\\\", \\\"{x:490,y:704,t:1526929889736};\\\", \\\"{x:490,y:706,t:1526929889748};\\\", \\\"{x:490,y:708,t:1526929889765};\\\", \\\"{x:491,y:711,t:1526929889782};\\\" ] }, { \\\"rt\\\": 17658, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 234883, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -Z -12 PM-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:714,t:1526929895975};\\\", \\\"{x:498,y:718,t:1526929895984};\\\", \\\"{x:511,y:731,t:1526929896001};\\\", \\\"{x:534,y:745,t:1526929896017};\\\", \\\"{x:575,y:762,t:1526929896034};\\\", \\\"{x:645,y:782,t:1526929896053};\\\", \\\"{x:757,y:811,t:1526929896070};\\\", \\\"{x:1013,y:846,t:1526929896087};\\\", \\\"{x:1227,y:860,t:1526929896103};\\\", \\\"{x:1454,y:860,t:1526929896120};\\\", \\\"{x:1650,y:865,t:1526929896136};\\\", \\\"{x:1711,y:867,t:1526929896153};\\\", \\\"{x:1713,y:865,t:1526929896170};\\\", \\\"{x:1715,y:865,t:1526929896187};\\\", \\\"{x:1713,y:865,t:1526929897392};\\\", \\\"{x:1710,y:867,t:1526929897406};\\\", \\\"{x:1701,y:870,t:1526929897422};\\\", \\\"{x:1689,y:872,t:1526929897439};\\\", \\\"{x:1669,y:878,t:1526929897456};\\\", \\\"{x:1649,y:884,t:1526929897472};\\\", \\\"{x:1623,y:892,t:1526929897488};\\\", \\\"{x:1600,y:895,t:1526929897506};\\\", \\\"{x:1561,y:895,t:1526929897523};\\\", \\\"{x:1495,y:895,t:1526929897539};\\\", \\\"{x:1414,y:895,t:1526929897556};\\\", \\\"{x:1317,y:895,t:1526929897572};\\\", \\\"{x:1225,y:895,t:1526929897589};\\\", \\\"{x:1172,y:895,t:1526929897606};\\\", \\\"{x:1144,y:895,t:1526929897623};\\\", \\\"{x:1129,y:895,t:1526929897639};\\\", \\\"{x:1127,y:895,t:1526929897656};\\\", \\\"{x:1126,y:895,t:1526929897760};\\\", \\\"{x:1127,y:893,t:1526929897773};\\\", \\\"{x:1132,y:892,t:1526929897788};\\\", \\\"{x:1140,y:887,t:1526929897806};\\\", \\\"{x:1148,y:884,t:1526929897822};\\\", \\\"{x:1157,y:880,t:1526929897838};\\\", \\\"{x:1163,y:879,t:1526929897855};\\\", \\\"{x:1166,y:877,t:1526929897873};\\\", \\\"{x:1167,y:877,t:1526929897895};\\\", \\\"{x:1169,y:876,t:1526929897912};\\\", \\\"{x:1170,y:875,t:1526929897923};\\\", \\\"{x:1171,y:874,t:1526929897940};\\\", \\\"{x:1172,y:873,t:1526929897955};\\\", \\\"{x:1176,y:870,t:1526929897972};\\\", \\\"{x:1179,y:866,t:1526929897989};\\\", \\\"{x:1181,y:863,t:1526929898005};\\\", \\\"{x:1184,y:861,t:1526929898022};\\\", \\\"{x:1189,y:853,t:1526929898039};\\\", \\\"{x:1190,y:850,t:1526929898055};\\\", \\\"{x:1192,y:848,t:1526929898072};\\\", \\\"{x:1195,y:842,t:1526929898089};\\\", \\\"{x:1200,y:836,t:1526929898105};\\\", \\\"{x:1203,y:831,t:1526929898123};\\\", \\\"{x:1207,y:828,t:1526929898139};\\\", \\\"{x:1210,y:826,t:1526929898158};\\\", \\\"{x:1211,y:824,t:1526929898172};\\\", \\\"{x:1214,y:822,t:1526929898189};\\\", \\\"{x:1220,y:818,t:1526929898206};\\\", \\\"{x:1226,y:811,t:1526929898222};\\\", \\\"{x:1227,y:811,t:1526929898239};\\\", \\\"{x:1228,y:811,t:1526929898512};\\\", \\\"{x:1228,y:812,t:1526929898523};\\\", \\\"{x:1228,y:816,t:1526929898540};\\\", \\\"{x:1228,y:818,t:1526929898557};\\\", \\\"{x:1227,y:822,t:1526929898573};\\\", \\\"{x:1225,y:827,t:1526929898590};\\\", \\\"{x:1225,y:828,t:1526929898608};\\\", \\\"{x:1224,y:830,t:1526929898896};\\\", \\\"{x:1223,y:831,t:1526929898907};\\\", \\\"{x:1223,y:833,t:1526929898923};\\\", \\\"{x:1222,y:836,t:1526929898941};\\\", \\\"{x:1221,y:837,t:1526929898956};\\\", \\\"{x:1221,y:838,t:1526929898973};\\\", \\\"{x:1221,y:839,t:1526929898991};\\\", \\\"{x:1221,y:842,t:1526929899006};\\\", \\\"{x:1219,y:843,t:1526929899024};\\\", \\\"{x:1219,y:844,t:1526929899632};\\\", \\\"{x:1219,y:846,t:1526929899641};\\\", \\\"{x:1219,y:848,t:1526929899657};\\\", \\\"{x:1218,y:849,t:1526929899674};\\\", \\\"{x:1218,y:851,t:1526929899691};\\\", \\\"{x:1217,y:853,t:1526929899707};\\\", \\\"{x:1217,y:852,t:1526929900008};\\\", \\\"{x:1217,y:851,t:1526929900032};\\\", \\\"{x:1217,y:850,t:1526929900041};\\\", \\\"{x:1218,y:849,t:1526929900059};\\\", \\\"{x:1218,y:848,t:1526929900075};\\\", \\\"{x:1218,y:847,t:1526929900091};\\\", \\\"{x:1218,y:846,t:1526929900108};\\\", \\\"{x:1218,y:845,t:1526929902280};\\\", \\\"{x:1218,y:843,t:1526929902294};\\\", \\\"{x:1218,y:842,t:1526929902311};\\\", \\\"{x:1218,y:840,t:1526929902328};\\\", \\\"{x:1218,y:839,t:1526929902344};\\\", \\\"{x:1218,y:838,t:1526929902465};\\\", \\\"{x:1219,y:838,t:1526929904159};\\\", \\\"{x:1220,y:839,t:1526929904183};\\\", \\\"{x:1220,y:840,t:1526929904215};\\\", \\\"{x:1220,y:839,t:1526929905624};\\\", \\\"{x:1220,y:838,t:1526929905639};\\\", \\\"{x:1220,y:837,t:1526929905712};\\\", \\\"{x:1222,y:837,t:1526929907080};\\\", \\\"{x:1223,y:837,t:1526929907087};\\\", \\\"{x:1227,y:837,t:1526929907099};\\\", \\\"{x:1237,y:840,t:1526929907116};\\\", \\\"{x:1249,y:845,t:1526929907134};\\\", \\\"{x:1260,y:848,t:1526929907149};\\\", \\\"{x:1271,y:852,t:1526929907166};\\\", \\\"{x:1288,y:858,t:1526929907183};\\\", \\\"{x:1325,y:868,t:1526929907199};\\\", \\\"{x:1349,y:874,t:1526929907216};\\\", \\\"{x:1380,y:879,t:1526929907233};\\\", \\\"{x:1400,y:882,t:1526929907249};\\\", \\\"{x:1411,y:885,t:1526929907266};\\\", \\\"{x:1415,y:885,t:1526929907283};\\\", \\\"{x:1411,y:885,t:1526929907408};\\\", \\\"{x:1406,y:886,t:1526929907416};\\\", \\\"{x:1394,y:887,t:1526929907433};\\\", \\\"{x:1379,y:890,t:1526929907450};\\\", \\\"{x:1365,y:892,t:1526929907466};\\\", \\\"{x:1358,y:896,t:1526929907484};\\\", \\\"{x:1354,y:899,t:1526929907500};\\\", \\\"{x:1352,y:899,t:1526929907517};\\\", \\\"{x:1352,y:902,t:1526929907551};\\\", \\\"{x:1352,y:904,t:1526929907566};\\\", \\\"{x:1352,y:907,t:1526929907583};\\\", \\\"{x:1352,y:908,t:1526929907599};\\\", \\\"{x:1352,y:909,t:1526929907616};\\\", \\\"{x:1352,y:910,t:1526929908000};\\\", \\\"{x:1352,y:915,t:1526929908018};\\\", \\\"{x:1352,y:923,t:1526929908034};\\\", \\\"{x:1353,y:932,t:1526929908050};\\\", \\\"{x:1354,y:939,t:1526929908067};\\\", \\\"{x:1354,y:946,t:1526929908084};\\\", \\\"{x:1354,y:951,t:1526929908100};\\\", \\\"{x:1354,y:966,t:1526929908117};\\\", \\\"{x:1353,y:978,t:1526929908135};\\\", \\\"{x:1352,y:983,t:1526929908150};\\\", \\\"{x:1350,y:987,t:1526929908168};\\\", \\\"{x:1349,y:991,t:1526929908184};\\\", \\\"{x:1349,y:990,t:1526929908471};\\\", \\\"{x:1349,y:988,t:1526929908483};\\\", \\\"{x:1349,y:986,t:1526929908503};\\\", \\\"{x:1349,y:984,t:1526929908519};\\\", \\\"{x:1349,y:983,t:1526929908535};\\\", \\\"{x:1349,y:979,t:1526929908550};\\\", \\\"{x:1349,y:978,t:1526929908567};\\\", \\\"{x:1349,y:976,t:1526929908584};\\\", \\\"{x:1349,y:975,t:1526929908607};\\\", \\\"{x:1345,y:975,t:1526929908991};\\\", \\\"{x:1335,y:971,t:1526929909000};\\\", \\\"{x:1309,y:967,t:1526929909018};\\\", \\\"{x:1276,y:959,t:1526929909034};\\\", \\\"{x:1219,y:954,t:1526929909051};\\\", \\\"{x:1143,y:942,t:1526929909068};\\\", \\\"{x:1060,y:930,t:1526929909085};\\\", \\\"{x:990,y:920,t:1526929909101};\\\", \\\"{x:923,y:910,t:1526929909118};\\\", \\\"{x:822,y:889,t:1526929909134};\\\", \\\"{x:766,y:881,t:1526929909151};\\\", \\\"{x:714,y:869,t:1526929909167};\\\", \\\"{x:667,y:857,t:1526929909185};\\\", \\\"{x:632,y:850,t:1526929909201};\\\", \\\"{x:594,y:840,t:1526929909217};\\\", \\\"{x:568,y:830,t:1526929909234};\\\", \\\"{x:545,y:820,t:1526929909251};\\\", \\\"{x:523,y:810,t:1526929909268};\\\", \\\"{x:512,y:799,t:1526929909285};\\\", \\\"{x:509,y:794,t:1526929909302};\\\", \\\"{x:509,y:790,t:1526929909318};\\\", \\\"{x:511,y:778,t:1526929909335};\\\", \\\"{x:521,y:769,t:1526929909351};\\\", \\\"{x:532,y:761,t:1526929909368};\\\", \\\"{x:550,y:752,t:1526929909385};\\\", \\\"{x:571,y:744,t:1526929909402};\\\", \\\"{x:607,y:732,t:1526929909418};\\\", \\\"{x:649,y:721,t:1526929909435};\\\", \\\"{x:681,y:718,t:1526929909452};\\\", \\\"{x:715,y:713,t:1526929909468};\\\", \\\"{x:759,y:703,t:1526929909485};\\\", \\\"{x:780,y:699,t:1526929909502};\\\", \\\"{x:792,y:695,t:1526929909518};\\\", \\\"{x:799,y:692,t:1526929909535};\\\", \\\"{x:799,y:691,t:1526929909591};\\\", \\\"{x:799,y:689,t:1526929909602};\\\", \\\"{x:790,y:683,t:1526929909619};\\\", \\\"{x:776,y:676,t:1526929909634};\\\", \\\"{x:749,y:671,t:1526929909652};\\\", \\\"{x:693,y:661,t:1526929909669};\\\", \\\"{x:629,y:652,t:1526929909685};\\\", \\\"{x:542,y:639,t:1526929909703};\\\", \\\"{x:421,y:621,t:1526929909720};\\\", \\\"{x:372,y:616,t:1526929909735};\\\", \\\"{x:336,y:608,t:1526929909765};\\\", \\\"{x:330,y:608,t:1526929909780};\\\", \\\"{x:329,y:608,t:1526929909797};\\\", \\\"{x:328,y:608,t:1526929909822};\\\", \\\"{x:327,y:608,t:1526929909830};\\\", \\\"{x:318,y:608,t:1526929909847};\\\", \\\"{x:299,y:608,t:1526929909864};\\\", \\\"{x:276,y:608,t:1526929909882};\\\", \\\"{x:241,y:608,t:1526929909899};\\\", \\\"{x:210,y:602,t:1526929909914};\\\", \\\"{x:175,y:599,t:1526929909932};\\\", \\\"{x:147,y:594,t:1526929909948};\\\", \\\"{x:128,y:591,t:1526929909964};\\\", \\\"{x:119,y:591,t:1526929909982};\\\", \\\"{x:115,y:591,t:1526929909997};\\\", \\\"{x:118,y:591,t:1526929910168};\\\", \\\"{x:121,y:591,t:1526929910182};\\\", \\\"{x:127,y:593,t:1526929910200};\\\", \\\"{x:135,y:595,t:1526929910215};\\\", \\\"{x:143,y:598,t:1526929910231};\\\", \\\"{x:147,y:599,t:1526929910249};\\\", \\\"{x:153,y:600,t:1526929910264};\\\", \\\"{x:158,y:601,t:1526929910281};\\\", \\\"{x:159,y:601,t:1526929910298};\\\", \\\"{x:161,y:599,t:1526929910367};\\\", \\\"{x:161,y:596,t:1526929910381};\\\", \\\"{x:163,y:587,t:1526929910399};\\\", \\\"{x:165,y:580,t:1526929910415};\\\", \\\"{x:166,y:575,t:1526929910432};\\\", \\\"{x:166,y:571,t:1526929910450};\\\", \\\"{x:166,y:569,t:1526929910466};\\\", \\\"{x:166,y:568,t:1526929910481};\\\", \\\"{x:166,y:565,t:1526929910498};\\\", \\\"{x:166,y:564,t:1526929910516};\\\", \\\"{x:166,y:563,t:1526929910532};\\\", \\\"{x:166,y:562,t:1526929910608};\\\", \\\"{x:170,y:570,t:1526929910975};\\\", \\\"{x:178,y:582,t:1526929910983};\\\", \\\"{x:205,y:613,t:1526929910999};\\\", \\\"{x:241,y:662,t:1526929911015};\\\", \\\"{x:293,y:701,t:1526929911032};\\\", \\\"{x:357,y:731,t:1526929911049};\\\", \\\"{x:414,y:755,t:1526929911065};\\\", \\\"{x:443,y:764,t:1526929911083};\\\", \\\"{x:459,y:768,t:1526929911098};\\\", \\\"{x:470,y:769,t:1526929911116};\\\", \\\"{x:475,y:771,t:1526929911133};\\\", \\\"{x:478,y:771,t:1526929911149};\\\", \\\"{x:480,y:771,t:1526929911166};\\\", \\\"{x:485,y:770,t:1526929911184};\\\", \\\"{x:487,y:768,t:1526929911199};\\\", \\\"{x:490,y:767,t:1526929911216};\\\", \\\"{x:496,y:764,t:1526929911233};\\\", \\\"{x:499,y:763,t:1526929911248};\\\", \\\"{x:501,y:762,t:1526929911266};\\\", \\\"{x:502,y:761,t:1526929911282};\\\", \\\"{x:504,y:760,t:1526929911299};\\\", \\\"{x:507,y:757,t:1526929911316};\\\", \\\"{x:510,y:752,t:1526929911333};\\\", \\\"{x:512,y:748,t:1526929911349};\\\", \\\"{x:515,y:741,t:1526929911366};\\\", \\\"{x:518,y:732,t:1526929911384};\\\", \\\"{x:518,y:726,t:1526929911399};\\\", \\\"{x:519,y:722,t:1526929911416};\\\", \\\"{x:519,y:717,t:1526929911431};\\\", \\\"{x:519,y:713,t:1526929911448};\\\", \\\"{x:519,y:710,t:1526929911466};\\\", \\\"{x:520,y:709,t:1526929911482};\\\" ] }, { \\\"rt\\\": 26778, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 262880, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -U -04 PM-U -K -K -12 PM-A -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:708,t:1526929914104};\\\", \\\"{x:543,y:718,t:1526929914119};\\\", \\\"{x:572,y:730,t:1526929914137};\\\", \\\"{x:615,y:745,t:1526929914152};\\\", \\\"{x:665,y:757,t:1526929914167};\\\", \\\"{x:730,y:773,t:1526929914184};\\\", \\\"{x:800,y:781,t:1526929914202};\\\", \\\"{x:862,y:791,t:1526929914218};\\\", \\\"{x:944,y:799,t:1526929914234};\\\", \\\"{x:1015,y:804,t:1526929914252};\\\", \\\"{x:1071,y:806,t:1526929914269};\\\", \\\"{x:1150,y:809,t:1526929914285};\\\", \\\"{x:1235,y:817,t:1526929914302};\\\", \\\"{x:1349,y:826,t:1526929914319};\\\", \\\"{x:1406,y:822,t:1526929914335};\\\", \\\"{x:1457,y:814,t:1526929914352};\\\", \\\"{x:1473,y:810,t:1526929914369};\\\", \\\"{x:1476,y:808,t:1526929914385};\\\", \\\"{x:1476,y:809,t:1526929915024};\\\", \\\"{x:1476,y:814,t:1526929915037};\\\", \\\"{x:1476,y:830,t:1526929915056};\\\", \\\"{x:1477,y:843,t:1526929915069};\\\", \\\"{x:1479,y:851,t:1526929915086};\\\", \\\"{x:1483,y:863,t:1526929915103};\\\", \\\"{x:1483,y:869,t:1526929915118};\\\", \\\"{x:1486,y:875,t:1526929915136};\\\", \\\"{x:1491,y:889,t:1526929915152};\\\", \\\"{x:1494,y:903,t:1526929915168};\\\", \\\"{x:1498,y:919,t:1526929915186};\\\", \\\"{x:1503,y:936,t:1526929915202};\\\", \\\"{x:1506,y:955,t:1526929915218};\\\", \\\"{x:1507,y:977,t:1526929915236};\\\", \\\"{x:1508,y:999,t:1526929915253};\\\", \\\"{x:1508,y:1013,t:1526929915269};\\\", \\\"{x:1508,y:1023,t:1526929915286};\\\", \\\"{x:1508,y:1041,t:1526929915303};\\\", \\\"{x:1508,y:1045,t:1526929915320};\\\", \\\"{x:1508,y:1048,t:1526929915336};\\\", \\\"{x:1509,y:1049,t:1526929915353};\\\", \\\"{x:1509,y:1050,t:1526929915370};\\\", \\\"{x:1510,y:1050,t:1526929915456};\\\", \\\"{x:1511,y:1050,t:1526929915471};\\\", \\\"{x:1518,y:1048,t:1526929915487};\\\", \\\"{x:1526,y:1045,t:1526929915503};\\\", \\\"{x:1531,y:1042,t:1526929915520};\\\", \\\"{x:1536,y:1038,t:1526929915536};\\\", \\\"{x:1538,y:1037,t:1526929915553};\\\", \\\"{x:1540,y:1036,t:1526929915570};\\\", \\\"{x:1541,y:1035,t:1526929915586};\\\", \\\"{x:1543,y:1033,t:1526929915603};\\\", \\\"{x:1544,y:1032,t:1526929915621};\\\", \\\"{x:1547,y:1030,t:1526929915637};\\\", \\\"{x:1550,y:1029,t:1526929915654};\\\", \\\"{x:1553,y:1027,t:1526929915670};\\\", \\\"{x:1557,y:1025,t:1526929915688};\\\", \\\"{x:1561,y:1023,t:1526929915703};\\\", \\\"{x:1570,y:1020,t:1526929915719};\\\", \\\"{x:1575,y:1018,t:1526929915736};\\\", \\\"{x:1585,y:1015,t:1526929915753};\\\", \\\"{x:1592,y:1012,t:1526929915769};\\\", \\\"{x:1599,y:1009,t:1526929915787};\\\", \\\"{x:1607,y:1006,t:1526929915803};\\\", \\\"{x:1615,y:1004,t:1526929915820};\\\", \\\"{x:1622,y:1000,t:1526929915837};\\\", \\\"{x:1628,y:997,t:1526929915853};\\\", \\\"{x:1632,y:996,t:1526929915870};\\\", \\\"{x:1635,y:994,t:1526929915887};\\\", \\\"{x:1636,y:993,t:1526929915960};\\\", \\\"{x:1637,y:992,t:1526929916040};\\\", \\\"{x:1637,y:991,t:1526929916054};\\\", \\\"{x:1637,y:989,t:1526929916296};\\\", \\\"{x:1637,y:987,t:1526929916304};\\\", \\\"{x:1636,y:985,t:1526929916321};\\\", \\\"{x:1634,y:983,t:1526929916338};\\\", \\\"{x:1632,y:980,t:1526929916355};\\\", \\\"{x:1628,y:976,t:1526929916371};\\\", \\\"{x:1626,y:972,t:1526929916388};\\\", \\\"{x:1626,y:970,t:1526929916404};\\\", \\\"{x:1625,y:968,t:1526929916423};\\\", \\\"{x:1624,y:967,t:1526929916436};\\\", \\\"{x:1624,y:965,t:1526929916457};\\\", \\\"{x:1622,y:964,t:1526929916474};\\\", \\\"{x:1622,y:963,t:1526929917147};\\\", \\\"{x:1620,y:963,t:1526929917158};\\\", \\\"{x:1615,y:965,t:1526929917175};\\\", \\\"{x:1607,y:965,t:1526929917192};\\\", \\\"{x:1590,y:965,t:1526929917209};\\\", \\\"{x:1570,y:965,t:1526929917225};\\\", \\\"{x:1549,y:965,t:1526929917243};\\\", \\\"{x:1523,y:965,t:1526929917259};\\\", \\\"{x:1510,y:965,t:1526929917274};\\\", \\\"{x:1500,y:965,t:1526929917292};\\\", \\\"{x:1496,y:965,t:1526929917309};\\\", \\\"{x:1495,y:965,t:1526929917564};\\\", \\\"{x:1494,y:965,t:1526929917575};\\\", \\\"{x:1490,y:965,t:1526929917592};\\\", \\\"{x:1486,y:965,t:1526929917609};\\\", \\\"{x:1481,y:965,t:1526929917626};\\\", \\\"{x:1477,y:965,t:1526929917642};\\\", \\\"{x:1476,y:965,t:1526929917659};\\\", \\\"{x:1475,y:965,t:1526929918691};\\\", \\\"{x:1475,y:964,t:1526929918699};\\\", \\\"{x:1477,y:952,t:1526929918710};\\\", \\\"{x:1497,y:914,t:1526929918727};\\\", \\\"{x:1525,y:876,t:1526929918744};\\\", \\\"{x:1547,y:847,t:1526929918760};\\\", \\\"{x:1557,y:828,t:1526929918777};\\\", \\\"{x:1559,y:818,t:1526929918794};\\\", \\\"{x:1561,y:811,t:1526929918810};\\\", \\\"{x:1562,y:803,t:1526929918827};\\\", \\\"{x:1562,y:800,t:1526929918843};\\\", \\\"{x:1562,y:797,t:1526929918861};\\\", \\\"{x:1562,y:795,t:1526929918883};\\\", \\\"{x:1562,y:793,t:1526929918948};\\\", \\\"{x:1561,y:793,t:1526929918960};\\\", \\\"{x:1554,y:793,t:1526929918977};\\\", \\\"{x:1540,y:793,t:1526929918994};\\\", \\\"{x:1523,y:796,t:1526929919010};\\\", \\\"{x:1506,y:797,t:1526929919027};\\\", \\\"{x:1501,y:800,t:1526929919044};\\\", \\\"{x:1498,y:801,t:1526929919059};\\\", \\\"{x:1494,y:803,t:1526929919077};\\\", \\\"{x:1490,y:805,t:1526929919093};\\\", \\\"{x:1488,y:806,t:1526929919110};\\\", \\\"{x:1487,y:807,t:1526929919127};\\\", \\\"{x:1486,y:807,t:1526929919163};\\\", \\\"{x:1485,y:807,t:1526929919203};\\\", \\\"{x:1483,y:809,t:1526929919211};\\\", \\\"{x:1483,y:811,t:1526929919227};\\\", \\\"{x:1479,y:816,t:1526929919244};\\\", \\\"{x:1476,y:821,t:1526929919260};\\\", \\\"{x:1474,y:824,t:1526929919278};\\\", \\\"{x:1471,y:828,t:1526929919293};\\\", \\\"{x:1471,y:829,t:1526929919311};\\\", \\\"{x:1471,y:831,t:1526929919327};\\\", \\\"{x:1470,y:832,t:1526929919346};\\\", \\\"{x:1469,y:832,t:1526929919378};\\\", \\\"{x:1469,y:834,t:1526929919875};\\\", \\\"{x:1471,y:835,t:1526929919883};\\\", \\\"{x:1474,y:836,t:1526929919894};\\\", \\\"{x:1476,y:837,t:1526929919911};\\\", \\\"{x:1480,y:839,t:1526929919928};\\\", \\\"{x:1484,y:840,t:1526929919944};\\\", \\\"{x:1485,y:841,t:1526929919961};\\\", \\\"{x:1486,y:842,t:1526929919978};\\\", \\\"{x:1484,y:844,t:1526929920772};\\\", \\\"{x:1480,y:846,t:1526929920779};\\\", \\\"{x:1468,y:847,t:1526929920795};\\\", \\\"{x:1438,y:847,t:1526929920812};\\\", \\\"{x:1387,y:845,t:1526929920829};\\\", \\\"{x:1314,y:834,t:1526929920845};\\\", \\\"{x:1231,y:821,t:1526929920863};\\\", \\\"{x:1136,y:808,t:1526929920879};\\\", \\\"{x:1041,y:788,t:1526929920895};\\\", \\\"{x:951,y:757,t:1526929920913};\\\", \\\"{x:867,y:728,t:1526929920929};\\\", \\\"{x:813,y:710,t:1526929920946};\\\", \\\"{x:786,y:698,t:1526929920962};\\\", \\\"{x:771,y:687,t:1526929920979};\\\", \\\"{x:768,y:684,t:1526929920995};\\\", \\\"{x:767,y:684,t:1526929921012};\\\", \\\"{x:767,y:682,t:1526929921030};\\\", \\\"{x:763,y:681,t:1526929921045};\\\", \\\"{x:756,y:677,t:1526929921062};\\\", \\\"{x:744,y:672,t:1526929921080};\\\", \\\"{x:733,y:668,t:1526929921096};\\\", \\\"{x:720,y:665,t:1526929921113};\\\", \\\"{x:706,y:662,t:1526929921129};\\\", \\\"{x:689,y:658,t:1526929921146};\\\", \\\"{x:671,y:656,t:1526929921162};\\\", \\\"{x:635,y:649,t:1526929921180};\\\", \\\"{x:600,y:644,t:1526929921196};\\\", \\\"{x:563,y:639,t:1526929921212};\\\", \\\"{x:531,y:635,t:1526929921228};\\\", \\\"{x:502,y:631,t:1526929921243};\\\", \\\"{x:477,y:627,t:1526929921261};\\\", \\\"{x:458,y:625,t:1526929921278};\\\", \\\"{x:442,y:622,t:1526929921293};\\\", \\\"{x:432,y:620,t:1526929921311};\\\", \\\"{x:428,y:619,t:1526929921328};\\\", \\\"{x:427,y:618,t:1526929921394};\\\", \\\"{x:434,y:613,t:1526929921410};\\\", \\\"{x:456,y:612,t:1526929921429};\\\", \\\"{x:484,y:608,t:1526929921444};\\\", \\\"{x:512,y:608,t:1526929921462};\\\", \\\"{x:537,y:608,t:1526929921478};\\\", \\\"{x:556,y:608,t:1526929921495};\\\", \\\"{x:561,y:608,t:1526929921511};\\\", \\\"{x:562,y:608,t:1526929921528};\\\", \\\"{x:564,y:608,t:1526929921634};\\\", \\\"{x:566,y:608,t:1526929921645};\\\", \\\"{x:572,y:608,t:1526929921662};\\\", \\\"{x:586,y:608,t:1526929921677};\\\", \\\"{x:601,y:608,t:1526929921695};\\\", \\\"{x:615,y:608,t:1526929921712};\\\", \\\"{x:625,y:608,t:1526929921728};\\\", \\\"{x:632,y:608,t:1526929921744};\\\", \\\"{x:635,y:607,t:1526929921761};\\\", \\\"{x:636,y:607,t:1526929922451};\\\", \\\"{x:641,y:607,t:1526929922462};\\\", \\\"{x:662,y:617,t:1526929922479};\\\", \\\"{x:693,y:631,t:1526929922497};\\\", \\\"{x:759,y:658,t:1526929922512};\\\", \\\"{x:838,y:686,t:1526929922529};\\\", \\\"{x:921,y:720,t:1526929922545};\\\", \\\"{x:996,y:746,t:1526929922563};\\\", \\\"{x:1083,y:773,t:1526929922579};\\\", \\\"{x:1116,y:792,t:1526929922595};\\\", \\\"{x:1140,y:804,t:1526929922612};\\\", \\\"{x:1169,y:819,t:1526929922629};\\\", \\\"{x:1197,y:837,t:1526929922646};\\\", \\\"{x:1216,y:846,t:1526929922662};\\\", \\\"{x:1238,y:851,t:1526929922679};\\\", \\\"{x:1265,y:857,t:1526929922696};\\\", \\\"{x:1292,y:863,t:1526929922713};\\\", \\\"{x:1316,y:865,t:1526929922730};\\\", \\\"{x:1338,y:865,t:1526929922746};\\\", \\\"{x:1358,y:866,t:1526929922763};\\\", \\\"{x:1382,y:869,t:1526929922779};\\\", \\\"{x:1392,y:869,t:1526929922797};\\\", \\\"{x:1399,y:869,t:1526929922812};\\\", \\\"{x:1401,y:869,t:1526929922829};\\\", \\\"{x:1403,y:869,t:1526929922846};\\\", \\\"{x:1404,y:868,t:1526929922861};\\\", \\\"{x:1408,y:865,t:1526929922879};\\\", \\\"{x:1410,y:864,t:1526929922896};\\\", \\\"{x:1412,y:862,t:1526929922913};\\\", \\\"{x:1414,y:861,t:1526929922929};\\\", \\\"{x:1417,y:858,t:1526929922945};\\\", \\\"{x:1420,y:854,t:1526929922962};\\\", \\\"{x:1423,y:852,t:1526929922979};\\\", \\\"{x:1427,y:849,t:1526929922996};\\\", \\\"{x:1432,y:845,t:1526929923013};\\\", \\\"{x:1436,y:843,t:1526929923029};\\\", \\\"{x:1443,y:841,t:1526929923046};\\\", \\\"{x:1447,y:839,t:1526929923063};\\\", \\\"{x:1449,y:839,t:1526929923080};\\\", \\\"{x:1450,y:839,t:1526929923096};\\\", \\\"{x:1453,y:839,t:1526929923113};\\\", \\\"{x:1456,y:837,t:1526929923129};\\\", \\\"{x:1458,y:837,t:1526929923146};\\\", \\\"{x:1460,y:837,t:1526929923163};\\\", \\\"{x:1461,y:837,t:1526929923179};\\\", \\\"{x:1461,y:836,t:1526929923339};\\\", \\\"{x:1461,y:833,t:1526929923347};\\\", \\\"{x:1452,y:827,t:1526929923363};\\\", \\\"{x:1443,y:820,t:1526929923379};\\\", \\\"{x:1426,y:811,t:1526929923396};\\\", \\\"{x:1415,y:804,t:1526929923413};\\\", \\\"{x:1411,y:802,t:1526929923429};\\\", \\\"{x:1407,y:799,t:1526929923446};\\\", \\\"{x:1404,y:798,t:1526929923463};\\\", \\\"{x:1402,y:798,t:1526929923668};\\\", \\\"{x:1399,y:798,t:1526929923681};\\\", \\\"{x:1396,y:807,t:1526929923697};\\\", \\\"{x:1390,y:820,t:1526929923714};\\\", \\\"{x:1383,y:836,t:1526929923731};\\\", \\\"{x:1378,y:859,t:1526929923747};\\\", \\\"{x:1376,y:869,t:1526929923763};\\\", \\\"{x:1375,y:874,t:1526929923781};\\\", \\\"{x:1375,y:876,t:1526929923798};\\\", \\\"{x:1375,y:877,t:1526929923814};\\\", \\\"{x:1375,y:879,t:1526929923830};\\\", \\\"{x:1376,y:879,t:1526929923963};\\\", \\\"{x:1376,y:877,t:1526929923980};\\\", \\\"{x:1377,y:873,t:1526929923997};\\\", \\\"{x:1378,y:870,t:1526929924013};\\\", \\\"{x:1378,y:869,t:1526929924029};\\\", \\\"{x:1379,y:867,t:1526929924047};\\\", \\\"{x:1381,y:870,t:1526929924155};\\\", \\\"{x:1381,y:875,t:1526929924164};\\\", \\\"{x:1383,y:883,t:1526929924180};\\\", \\\"{x:1383,y:888,t:1526929924197};\\\", \\\"{x:1384,y:892,t:1526929924214};\\\", \\\"{x:1385,y:898,t:1526929924230};\\\", \\\"{x:1386,y:904,t:1526929924248};\\\", \\\"{x:1387,y:910,t:1526929924264};\\\", \\\"{x:1388,y:913,t:1526929924280};\\\", \\\"{x:1389,y:917,t:1526929924297};\\\", \\\"{x:1390,y:918,t:1526929924315};\\\", \\\"{x:1391,y:920,t:1526929924331};\\\", \\\"{x:1391,y:917,t:1526929924508};\\\", \\\"{x:1391,y:914,t:1526929924516};\\\", \\\"{x:1391,y:909,t:1526929924530};\\\", \\\"{x:1390,y:891,t:1526929924547};\\\", \\\"{x:1388,y:881,t:1526929924564};\\\", \\\"{x:1388,y:873,t:1526929924580};\\\", \\\"{x:1386,y:865,t:1526929924598};\\\", \\\"{x:1385,y:857,t:1526929924614};\\\", \\\"{x:1384,y:845,t:1526929924630};\\\", \\\"{x:1383,y:838,t:1526929924648};\\\", \\\"{x:1381,y:830,t:1526929924665};\\\", \\\"{x:1381,y:824,t:1526929924681};\\\", \\\"{x:1381,y:817,t:1526929924698};\\\", \\\"{x:1381,y:810,t:1526929924714};\\\", \\\"{x:1381,y:801,t:1526929924731};\\\", \\\"{x:1381,y:797,t:1526929924748};\\\", \\\"{x:1381,y:794,t:1526929924765};\\\", \\\"{x:1381,y:790,t:1526929924782};\\\", \\\"{x:1381,y:787,t:1526929924797};\\\", \\\"{x:1381,y:786,t:1526929924814};\\\", \\\"{x:1381,y:785,t:1526929924832};\\\", \\\"{x:1381,y:784,t:1526929924848};\\\", \\\"{x:1381,y:783,t:1526929924884};\\\", \\\"{x:1381,y:782,t:1526929924907};\\\", \\\"{x:1381,y:781,t:1526929924923};\\\", \\\"{x:1381,y:780,t:1526929924955};\\\", \\\"{x:1381,y:779,t:1526929924965};\\\", \\\"{x:1381,y:778,t:1526929924981};\\\", \\\"{x:1381,y:777,t:1526929924999};\\\", \\\"{x:1381,y:776,t:1526929925014};\\\", \\\"{x:1381,y:775,t:1526929925031};\\\", \\\"{x:1381,y:773,t:1526929925048};\\\", \\\"{x:1381,y:772,t:1526929925064};\\\", \\\"{x:1381,y:771,t:1526929926716};\\\", \\\"{x:1397,y:764,t:1526929926733};\\\", \\\"{x:1427,y:751,t:1526929926750};\\\", \\\"{x:1452,y:743,t:1526929926767};\\\", \\\"{x:1464,y:739,t:1526929926783};\\\", \\\"{x:1472,y:735,t:1526929926800};\\\", \\\"{x:1475,y:732,t:1526929926818};\\\", \\\"{x:1477,y:731,t:1526929926833};\\\", \\\"{x:1481,y:724,t:1526929926850};\\\", \\\"{x:1484,y:715,t:1526929926867};\\\", \\\"{x:1485,y:711,t:1526929926883};\\\", \\\"{x:1486,y:704,t:1526929926900};\\\", \\\"{x:1487,y:702,t:1526929926916};\\\", \\\"{x:1489,y:697,t:1526929926932};\\\", \\\"{x:1490,y:694,t:1526929926949};\\\", \\\"{x:1493,y:688,t:1526929926966};\\\", \\\"{x:1494,y:679,t:1526929926983};\\\", \\\"{x:1495,y:673,t:1526929926999};\\\", \\\"{x:1496,y:666,t:1526929927018};\\\", \\\"{x:1497,y:657,t:1526929927034};\\\", \\\"{x:1498,y:650,t:1526929927049};\\\", \\\"{x:1500,y:644,t:1526929927066};\\\", \\\"{x:1502,y:639,t:1526929927083};\\\", \\\"{x:1504,y:635,t:1526929927099};\\\", \\\"{x:1506,y:631,t:1526929927116};\\\", \\\"{x:1510,y:626,t:1526929927134};\\\", \\\"{x:1512,y:623,t:1526929927151};\\\", \\\"{x:1512,y:621,t:1526929927166};\\\", \\\"{x:1515,y:619,t:1526929927183};\\\", \\\"{x:1515,y:618,t:1526929927199};\\\", \\\"{x:1516,y:617,t:1526929927227};\\\", \\\"{x:1518,y:618,t:1526929927435};\\\", \\\"{x:1519,y:618,t:1526929927450};\\\", \\\"{x:1522,y:622,t:1526929927466};\\\", \\\"{x:1524,y:626,t:1526929927484};\\\", \\\"{x:1525,y:628,t:1526929927501};\\\", \\\"{x:1526,y:629,t:1526929927517};\\\", \\\"{x:1526,y:630,t:1526929927534};\\\", \\\"{x:1527,y:632,t:1526929927551};\\\", \\\"{x:1527,y:634,t:1526929927579};\\\", \\\"{x:1528,y:634,t:1526929927603};\\\", \\\"{x:1527,y:636,t:1526929928131};\\\", \\\"{x:1526,y:640,t:1526929928139};\\\", \\\"{x:1524,y:643,t:1526929928151};\\\", \\\"{x:1523,y:648,t:1526929928168};\\\", \\\"{x:1519,y:659,t:1526929928184};\\\", \\\"{x:1518,y:669,t:1526929928201};\\\", \\\"{x:1517,y:683,t:1526929928218};\\\", \\\"{x:1514,y:697,t:1526929928233};\\\", \\\"{x:1511,y:725,t:1526929928251};\\\", \\\"{x:1508,y:748,t:1526929928267};\\\", \\\"{x:1508,y:773,t:1526929928285};\\\", \\\"{x:1508,y:799,t:1526929928301};\\\", \\\"{x:1508,y:820,t:1526929928317};\\\", \\\"{x:1509,y:837,t:1526929928335};\\\", \\\"{x:1513,y:850,t:1526929928351};\\\", \\\"{x:1515,y:857,t:1526929928368};\\\", \\\"{x:1517,y:862,t:1526929928384};\\\", \\\"{x:1518,y:867,t:1526929928400};\\\", \\\"{x:1519,y:872,t:1526929928418};\\\", \\\"{x:1520,y:889,t:1526929928435};\\\", \\\"{x:1520,y:899,t:1526929928451};\\\", \\\"{x:1520,y:909,t:1526929928467};\\\", \\\"{x:1521,y:916,t:1526929928484};\\\", \\\"{x:1521,y:920,t:1526929928501};\\\", \\\"{x:1522,y:924,t:1526929928518};\\\", \\\"{x:1522,y:929,t:1526929928535};\\\", \\\"{x:1522,y:931,t:1526929928550};\\\", \\\"{x:1523,y:934,t:1526929928568};\\\", \\\"{x:1523,y:937,t:1526929928585};\\\", \\\"{x:1523,y:941,t:1526929928600};\\\", \\\"{x:1523,y:944,t:1526929928618};\\\", \\\"{x:1523,y:948,t:1526929928635};\\\", \\\"{x:1523,y:949,t:1526929928652};\\\", \\\"{x:1523,y:950,t:1526929928675};\\\", \\\"{x:1523,y:951,t:1526929928811};\\\", \\\"{x:1523,y:953,t:1526929928819};\\\", \\\"{x:1523,y:957,t:1526929928835};\\\", \\\"{x:1523,y:958,t:1526929928859};\\\", \\\"{x:1523,y:960,t:1526929928868};\\\", \\\"{x:1523,y:961,t:1526929928885};\\\", \\\"{x:1523,y:962,t:1526929928923};\\\", \\\"{x:1522,y:963,t:1526929928935};\\\", \\\"{x:1521,y:964,t:1526929929123};\\\", \\\"{x:1519,y:964,t:1526929929135};\\\", \\\"{x:1517,y:965,t:1526929929163};\\\", \\\"{x:1516,y:965,t:1526929929179};\\\", \\\"{x:1514,y:966,t:1526929929187};\\\", \\\"{x:1513,y:967,t:1526929929211};\\\", \\\"{x:1512,y:967,t:1526929930348};\\\", \\\"{x:1510,y:967,t:1526929930362};\\\", \\\"{x:1509,y:967,t:1526929930370};\\\", \\\"{x:1507,y:968,t:1526929930386};\\\", \\\"{x:1502,y:968,t:1526929930404};\\\", \\\"{x:1497,y:968,t:1526929930419};\\\", \\\"{x:1488,y:968,t:1526929930435};\\\", \\\"{x:1475,y:966,t:1526929930452};\\\", \\\"{x:1460,y:964,t:1526929930470};\\\", \\\"{x:1442,y:960,t:1526929930486};\\\", \\\"{x:1432,y:959,t:1526929930502};\\\", \\\"{x:1424,y:958,t:1526929930519};\\\", \\\"{x:1422,y:957,t:1526929930535};\\\", \\\"{x:1419,y:957,t:1526929931540};\\\", \\\"{x:1418,y:957,t:1526929931554};\\\", \\\"{x:1417,y:957,t:1526929931570};\\\", \\\"{x:1416,y:957,t:1526929931604};\\\", \\\"{x:1415,y:957,t:1526929931621};\\\", \\\"{x:1414,y:959,t:1526929931659};\\\", \\\"{x:1413,y:959,t:1526929931675};\\\", \\\"{x:1412,y:960,t:1526929931707};\\\", \\\"{x:1411,y:960,t:1526929931739};\\\", \\\"{x:1410,y:960,t:1526929931753};\\\", \\\"{x:1409,y:960,t:1526929931770};\\\", \\\"{x:1407,y:962,t:1526929931787};\\\", \\\"{x:1406,y:962,t:1526929931804};\\\", \\\"{x:1404,y:963,t:1526929931821};\\\", \\\"{x:1403,y:963,t:1526929931851};\\\", \\\"{x:1402,y:964,t:1526929931859};\\\", \\\"{x:1403,y:964,t:1526929932723};\\\", \\\"{x:1404,y:964,t:1526929932739};\\\", \\\"{x:1405,y:963,t:1526929932755};\\\", \\\"{x:1407,y:963,t:1526929932771};\\\", \\\"{x:1411,y:961,t:1526929932789};\\\", \\\"{x:1426,y:961,t:1526929932805};\\\", \\\"{x:1446,y:961,t:1526929932822};\\\", \\\"{x:1463,y:961,t:1526929932838};\\\", \\\"{x:1475,y:961,t:1526929932855};\\\", \\\"{x:1485,y:960,t:1526929932872};\\\", \\\"{x:1486,y:960,t:1526929932888};\\\", \\\"{x:1480,y:962,t:1526929933066};\\\", \\\"{x:1476,y:963,t:1526929933074};\\\", \\\"{x:1472,y:963,t:1526929933087};\\\", \\\"{x:1461,y:964,t:1526929933104};\\\", \\\"{x:1454,y:964,t:1526929933121};\\\", \\\"{x:1451,y:964,t:1526929933137};\\\", \\\"{x:1450,y:964,t:1526929933154};\\\", \\\"{x:1448,y:964,t:1526929933172};\\\", \\\"{x:1447,y:959,t:1526929933316};\\\", \\\"{x:1445,y:948,t:1526929933323};\\\", \\\"{x:1441,y:925,t:1526929933339};\\\", \\\"{x:1437,y:903,t:1526929933355};\\\", \\\"{x:1430,y:880,t:1526929933371};\\\", \\\"{x:1423,y:857,t:1526929933389};\\\", \\\"{x:1420,y:840,t:1526929933405};\\\", \\\"{x:1417,y:822,t:1526929933422};\\\", \\\"{x:1414,y:798,t:1526929933439};\\\", \\\"{x:1414,y:771,t:1526929933455};\\\", \\\"{x:1414,y:744,t:1526929933472};\\\", \\\"{x:1414,y:714,t:1526929933489};\\\", \\\"{x:1411,y:694,t:1526929933505};\\\", \\\"{x:1409,y:673,t:1526929933522};\\\", \\\"{x:1407,y:652,t:1526929933539};\\\", \\\"{x:1404,y:639,t:1526929933555};\\\", \\\"{x:1403,y:632,t:1526929933571};\\\", \\\"{x:1402,y:624,t:1526929933588};\\\", \\\"{x:1402,y:620,t:1526929933604};\\\", \\\"{x:1402,y:614,t:1526929933621};\\\", \\\"{x:1402,y:609,t:1526929933639};\\\", \\\"{x:1402,y:605,t:1526929933654};\\\", \\\"{x:1402,y:601,t:1526929933671};\\\", \\\"{x:1403,y:596,t:1526929933689};\\\", \\\"{x:1403,y:592,t:1526929933705};\\\", \\\"{x:1405,y:590,t:1526929933721};\\\", \\\"{x:1406,y:588,t:1526929933738};\\\", \\\"{x:1406,y:587,t:1526929933756};\\\", \\\"{x:1407,y:587,t:1526929933772};\\\", \\\"{x:1407,y:586,t:1526929933788};\\\", \\\"{x:1408,y:584,t:1526929933806};\\\", \\\"{x:1409,y:583,t:1526929933822};\\\", \\\"{x:1409,y:582,t:1526929933838};\\\", \\\"{x:1410,y:581,t:1526929933855};\\\", \\\"{x:1410,y:583,t:1526929934643};\\\", \\\"{x:1410,y:590,t:1526929934656};\\\", \\\"{x:1410,y:603,t:1526929934673};\\\", \\\"{x:1410,y:606,t:1526929934690};\\\", \\\"{x:1410,y:608,t:1526929934706};\\\", \\\"{x:1412,y:614,t:1526929935443};\\\", \\\"{x:1417,y:625,t:1526929935457};\\\", \\\"{x:1425,y:652,t:1526929935475};\\\", \\\"{x:1431,y:676,t:1526929935490};\\\", \\\"{x:1436,y:710,t:1526929935507};\\\", \\\"{x:1436,y:732,t:1526929935524};\\\", \\\"{x:1436,y:748,t:1526929935540};\\\", \\\"{x:1436,y:762,t:1526929935557};\\\", \\\"{x:1436,y:773,t:1526929935574};\\\", \\\"{x:1436,y:781,t:1526929935590};\\\", \\\"{x:1436,y:787,t:1526929935607};\\\", \\\"{x:1436,y:791,t:1526929935625};\\\", \\\"{x:1436,y:792,t:1526929935640};\\\", \\\"{x:1436,y:794,t:1526929935657};\\\", \\\"{x:1436,y:795,t:1526929935939};\\\", \\\"{x:1436,y:796,t:1526929935947};\\\", \\\"{x:1434,y:796,t:1526929935963};\\\", \\\"{x:1432,y:796,t:1526929935979};\\\", \\\"{x:1431,y:796,t:1526929936003};\\\", \\\"{x:1430,y:796,t:1526929936228};\\\", \\\"{x:1429,y:796,t:1526929936241};\\\", \\\"{x:1427,y:796,t:1526929936258};\\\", \\\"{x:1424,y:794,t:1526929936275};\\\", \\\"{x:1420,y:791,t:1526929936291};\\\", \\\"{x:1416,y:789,t:1526929936307};\\\", \\\"{x:1408,y:785,t:1526929936324};\\\", \\\"{x:1403,y:783,t:1526929936341};\\\", \\\"{x:1397,y:781,t:1526929936358};\\\", \\\"{x:1391,y:780,t:1526929936374};\\\", \\\"{x:1383,y:780,t:1526929936391};\\\", \\\"{x:1380,y:779,t:1526929936408};\\\", \\\"{x:1377,y:779,t:1526929936424};\\\", \\\"{x:1373,y:779,t:1526929936442};\\\", \\\"{x:1372,y:779,t:1526929936467};\\\", \\\"{x:1370,y:779,t:1526929936475};\\\", \\\"{x:1367,y:779,t:1526929936491};\\\", \\\"{x:1361,y:783,t:1526929936508};\\\", \\\"{x:1358,y:786,t:1526929936525};\\\", \\\"{x:1356,y:798,t:1526929936541};\\\", \\\"{x:1353,y:812,t:1526929936558};\\\", \\\"{x:1353,y:831,t:1526929936575};\\\", \\\"{x:1353,y:847,t:1526929936591};\\\", \\\"{x:1354,y:865,t:1526929936608};\\\", \\\"{x:1356,y:882,t:1526929936625};\\\", \\\"{x:1361,y:904,t:1526929936641};\\\", \\\"{x:1364,y:922,t:1526929936658};\\\", \\\"{x:1366,y:942,t:1526929936675};\\\", \\\"{x:1369,y:956,t:1526929936691};\\\", \\\"{x:1371,y:968,t:1526929936708};\\\", \\\"{x:1372,y:977,t:1526929936725};\\\", \\\"{x:1373,y:981,t:1526929936741};\\\", \\\"{x:1373,y:982,t:1526929936875};\\\", \\\"{x:1372,y:982,t:1526929936898};\\\", \\\"{x:1370,y:982,t:1526929936908};\\\", \\\"{x:1368,y:980,t:1526929936925};\\\", \\\"{x:1365,y:979,t:1526929936942};\\\", \\\"{x:1363,y:977,t:1526929936958};\\\", \\\"{x:1362,y:976,t:1526929936975};\\\", \\\"{x:1359,y:973,t:1526929936992};\\\", \\\"{x:1356,y:969,t:1526929937008};\\\", \\\"{x:1352,y:964,t:1526929937026};\\\", \\\"{x:1351,y:962,t:1526929937042};\\\", \\\"{x:1350,y:962,t:1526929937067};\\\", \\\"{x:1350,y:960,t:1526929937083};\\\", \\\"{x:1350,y:958,t:1526929937092};\\\", \\\"{x:1348,y:953,t:1526929937109};\\\", \\\"{x:1347,y:949,t:1526929937125};\\\", \\\"{x:1347,y:945,t:1526929937142};\\\", \\\"{x:1346,y:941,t:1526929937158};\\\", \\\"{x:1346,y:938,t:1526929937175};\\\", \\\"{x:1346,y:933,t:1526929937192};\\\", \\\"{x:1345,y:927,t:1526929937208};\\\", \\\"{x:1345,y:924,t:1526929937225};\\\", \\\"{x:1345,y:920,t:1526929937242};\\\", \\\"{x:1345,y:918,t:1526929937258};\\\", \\\"{x:1345,y:915,t:1526929937274};\\\", \\\"{x:1345,y:913,t:1526929937292};\\\", \\\"{x:1345,y:910,t:1526929937308};\\\", \\\"{x:1345,y:907,t:1526929937325};\\\", \\\"{x:1345,y:906,t:1526929937342};\\\", \\\"{x:1345,y:904,t:1526929937359};\\\", \\\"{x:1341,y:899,t:1526929938011};\\\", \\\"{x:1336,y:895,t:1526929938026};\\\", \\\"{x:1326,y:884,t:1526929938042};\\\", \\\"{x:1321,y:877,t:1526929938059};\\\", \\\"{x:1319,y:874,t:1526929938076};\\\", \\\"{x:1317,y:872,t:1526929938092};\\\", \\\"{x:1317,y:871,t:1526929938109};\\\", \\\"{x:1317,y:870,t:1526929938127};\\\", \\\"{x:1316,y:869,t:1526929938147};\\\", \\\"{x:1316,y:868,t:1526929938163};\\\", \\\"{x:1315,y:868,t:1526929938176};\\\", \\\"{x:1314,y:867,t:1526929938193};\\\", \\\"{x:1313,y:865,t:1526929938210};\\\", \\\"{x:1312,y:865,t:1526929938227};\\\", \\\"{x:1312,y:863,t:1526929938340};\\\", \\\"{x:1312,y:862,t:1526929938355};\\\", \\\"{x:1312,y:861,t:1526929938371};\\\", \\\"{x:1311,y:859,t:1526929938379};\\\", \\\"{x:1310,y:858,t:1526929938395};\\\", \\\"{x:1309,y:857,t:1526929938410};\\\", \\\"{x:1308,y:856,t:1526929938426};\\\", \\\"{x:1305,y:853,t:1526929938444};\\\", \\\"{x:1304,y:851,t:1526929938459};\\\", \\\"{x:1303,y:851,t:1526929938476};\\\", \\\"{x:1302,y:849,t:1526929938493};\\\", \\\"{x:1302,y:847,t:1526929938509};\\\", \\\"{x:1301,y:846,t:1526929938530};\\\", \\\"{x:1301,y:844,t:1526929938563};\\\", \\\"{x:1300,y:842,t:1526929938579};\\\", \\\"{x:1299,y:840,t:1526929938603};\\\", \\\"{x:1298,y:839,t:1526929938644};\\\", \\\"{x:1298,y:838,t:1526929938683};\\\", \\\"{x:1298,y:837,t:1526929938715};\\\", \\\"{x:1298,y:836,t:1526929938755};\\\", \\\"{x:1292,y:834,t:1526929939123};\\\", \\\"{x:1281,y:830,t:1526929939132};\\\", \\\"{x:1263,y:825,t:1526929939145};\\\", \\\"{x:1216,y:819,t:1526929939160};\\\", \\\"{x:1146,y:809,t:1526929939178};\\\", \\\"{x:1049,y:797,t:1526929939193};\\\", \\\"{x:946,y:781,t:1526929939210};\\\", \\\"{x:790,y:759,t:1526929939226};\\\", \\\"{x:692,y:744,t:1526929939243};\\\", \\\"{x:611,y:731,t:1526929939260};\\\", \\\"{x:544,y:722,t:1526929939278};\\\", \\\"{x:500,y:716,t:1526929939294};\\\", \\\"{x:472,y:710,t:1526929939310};\\\", \\\"{x:451,y:705,t:1526929939325};\\\", \\\"{x:440,y:703,t:1526929939343};\\\", \\\"{x:431,y:699,t:1526929939359};\\\", \\\"{x:426,y:697,t:1526929939375};\\\", \\\"{x:423,y:695,t:1526929939393};\\\", \\\"{x:421,y:693,t:1526929939410};\\\", \\\"{x:423,y:692,t:1526929939507};\\\", \\\"{x:425,y:691,t:1526929939514};\\\", \\\"{x:426,y:691,t:1526929939526};\\\", \\\"{x:436,y:691,t:1526929939542};\\\", \\\"{x:452,y:696,t:1526929939560};\\\", \\\"{x:470,y:702,t:1526929939577};\\\", \\\"{x:487,y:708,t:1526929939593};\\\", \\\"{x:503,y:712,t:1526929939609};\\\", \\\"{x:518,y:716,t:1526929939626};\\\", \\\"{x:520,y:716,t:1526929939643};\\\" ] }, { \\\"rt\\\": 66932, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 331090, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 PM-08 PM-O -12 PM-12 PM-U -F -08 AM-02 PM-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:715,t:1526929942011};\\\", \\\"{x:522,y:706,t:1526929942023};\\\", \\\"{x:522,y:692,t:1526929942030};\\\", \\\"{x:523,y:655,t:1526929942045};\\\", \\\"{x:523,y:599,t:1526929942062};\\\", \\\"{x:517,y:546,t:1526929942078};\\\", \\\"{x:510,y:520,t:1526929942095};\\\", \\\"{x:505,y:503,t:1526929942112};\\\", \\\"{x:503,y:496,t:1526929942128};\\\", \\\"{x:502,y:491,t:1526929942145};\\\", \\\"{x:502,y:487,t:1526929942161};\\\", \\\"{x:502,y:484,t:1526929942177};\\\", \\\"{x:502,y:487,t:1526929943218};\\\", \\\"{x:502,y:489,t:1526929943229};\\\", \\\"{x:502,y:495,t:1526929943246};\\\", \\\"{x:502,y:497,t:1526929943263};\\\", \\\"{x:502,y:498,t:1526929943280};\\\", \\\"{x:502,y:499,t:1526929943298};\\\", \\\"{x:503,y:502,t:1526929943939};\\\", \\\"{x:511,y:505,t:1526929943947};\\\", \\\"{x:548,y:525,t:1526929943965};\\\", \\\"{x:665,y:587,t:1526929943981};\\\", \\\"{x:830,y:657,t:1526929943997};\\\", \\\"{x:1030,y:732,t:1526929944013};\\\", \\\"{x:1251,y:795,t:1526929944030};\\\", \\\"{x:1469,y:861,t:1526929944046};\\\", \\\"{x:1662,y:914,t:1526929944063};\\\", \\\"{x:1814,y:953,t:1526929944080};\\\", \\\"{x:1896,y:974,t:1526929944096};\\\", \\\"{x:1919,y:978,t:1526929944114};\\\", \\\"{x:1917,y:978,t:1526929944178};\\\", \\\"{x:1914,y:977,t:1526929944196};\\\", \\\"{x:1912,y:977,t:1526929944213};\\\", \\\"{x:1906,y:974,t:1526929944229};\\\", \\\"{x:1897,y:970,t:1526929944246};\\\", \\\"{x:1884,y:965,t:1526929944264};\\\", \\\"{x:1871,y:961,t:1526929944280};\\\", \\\"{x:1858,y:958,t:1526929944298};\\\", \\\"{x:1842,y:952,t:1526929944313};\\\", \\\"{x:1799,y:938,t:1526929944331};\\\", \\\"{x:1762,y:927,t:1526929944346};\\\", \\\"{x:1712,y:913,t:1526929944363};\\\", \\\"{x:1660,y:900,t:1526929944380};\\\", \\\"{x:1614,y:883,t:1526929944397};\\\", \\\"{x:1593,y:869,t:1526929944414};\\\", \\\"{x:1589,y:865,t:1526929944430};\\\", \\\"{x:1593,y:854,t:1526929944447};\\\", \\\"{x:1611,y:837,t:1526929944464};\\\", \\\"{x:1659,y:813,t:1526929944481};\\\", \\\"{x:1666,y:812,t:1526929944497};\\\", \\\"{x:1665,y:812,t:1526929945267};\\\", \\\"{x:1662,y:812,t:1526929945281};\\\", \\\"{x:1661,y:812,t:1526929945297};\\\", \\\"{x:1658,y:812,t:1526929945315};\\\", \\\"{x:1655,y:812,t:1526929945331};\\\", \\\"{x:1653,y:813,t:1526929945347};\\\", \\\"{x:1652,y:813,t:1526929945715};\\\", \\\"{x:1650,y:813,t:1526929945739};\\\", \\\"{x:1649,y:813,t:1526929945779};\\\", \\\"{x:1646,y:813,t:1526929945803};\\\", \\\"{x:1642,y:811,t:1526929945819};\\\", \\\"{x:1638,y:809,t:1526929945831};\\\", \\\"{x:1629,y:804,t:1526929945848};\\\", \\\"{x:1611,y:793,t:1526929945864};\\\", \\\"{x:1581,y:772,t:1526929945881};\\\", \\\"{x:1511,y:723,t:1526929945899};\\\", \\\"{x:1447,y:680,t:1526929945914};\\\", \\\"{x:1401,y:652,t:1526929945931};\\\", \\\"{x:1367,y:628,t:1526929945949};\\\", \\\"{x:1352,y:612,t:1526929945965};\\\", \\\"{x:1338,y:594,t:1526929945981};\\\", \\\"{x:1334,y:582,t:1526929945998};\\\", \\\"{x:1334,y:569,t:1526929946016};\\\", \\\"{x:1334,y:563,t:1526929946031};\\\", \\\"{x:1334,y:559,t:1526929946049};\\\", \\\"{x:1334,y:555,t:1526929946065};\\\", \\\"{x:1334,y:552,t:1526929946081};\\\", \\\"{x:1334,y:547,t:1526929946099};\\\", \\\"{x:1333,y:545,t:1526929946115};\\\", \\\"{x:1332,y:543,t:1526929946132};\\\", \\\"{x:1332,y:542,t:1526929946148};\\\", \\\"{x:1331,y:541,t:1526929946166};\\\", \\\"{x:1330,y:540,t:1526929946187};\\\", \\\"{x:1330,y:539,t:1526929946203};\\\", \\\"{x:1328,y:538,t:1526929946215};\\\", \\\"{x:1328,y:537,t:1526929946231};\\\", \\\"{x:1326,y:536,t:1526929946248};\\\", \\\"{x:1326,y:535,t:1526929946265};\\\", \\\"{x:1326,y:534,t:1526929946290};\\\", \\\"{x:1326,y:533,t:1526929946322};\\\", \\\"{x:1326,y:532,t:1526929946331};\\\", \\\"{x:1326,y:531,t:1526929946348};\\\", \\\"{x:1325,y:530,t:1526929946365};\\\", \\\"{x:1325,y:529,t:1526929946382};\\\", \\\"{x:1325,y:528,t:1526929946755};\\\", \\\"{x:1325,y:526,t:1526929946765};\\\", \\\"{x:1325,y:523,t:1526929946782};\\\", \\\"{x:1325,y:521,t:1526929946799};\\\", \\\"{x:1323,y:520,t:1526929946815};\\\", \\\"{x:1323,y:516,t:1526929946832};\\\", \\\"{x:1323,y:515,t:1526929946850};\\\", \\\"{x:1322,y:515,t:1526929946867};\\\", \\\"{x:1322,y:514,t:1526929946882};\\\", \\\"{x:1321,y:512,t:1526929946930};\\\", \\\"{x:1321,y:510,t:1526929949564};\\\", \\\"{x:1321,y:509,t:1526929949579};\\\", \\\"{x:1321,y:508,t:1526929949587};\\\", \\\"{x:1320,y:510,t:1526929949827};\\\", \\\"{x:1320,y:513,t:1526929949835};\\\", \\\"{x:1319,y:515,t:1526929949852};\\\", \\\"{x:1319,y:517,t:1526929949868};\\\", \\\"{x:1318,y:519,t:1526929949884};\\\", \\\"{x:1318,y:520,t:1526929949902};\\\", \\\"{x:1318,y:522,t:1526929949917};\\\", \\\"{x:1318,y:523,t:1526929949935};\\\", \\\"{x:1317,y:523,t:1526929949952};\\\", \\\"{x:1317,y:526,t:1526929950051};\\\", \\\"{x:1317,y:528,t:1526929950069};\\\", \\\"{x:1317,y:530,t:1526929950085};\\\", \\\"{x:1317,y:532,t:1526929950102};\\\", \\\"{x:1317,y:535,t:1526929950119};\\\", \\\"{x:1317,y:538,t:1526929950135};\\\", \\\"{x:1317,y:540,t:1526929950151};\\\", \\\"{x:1317,y:546,t:1526929950168};\\\", \\\"{x:1317,y:554,t:1526929950185};\\\", \\\"{x:1317,y:559,t:1526929950201};\\\", \\\"{x:1318,y:576,t:1526929950219};\\\", \\\"{x:1318,y:585,t:1526929950234};\\\", \\\"{x:1318,y:595,t:1526929950251};\\\", \\\"{x:1318,y:603,t:1526929950268};\\\", \\\"{x:1319,y:613,t:1526929950284};\\\", \\\"{x:1319,y:627,t:1526929950302};\\\", \\\"{x:1319,y:636,t:1526929950319};\\\", \\\"{x:1319,y:643,t:1526929950335};\\\", \\\"{x:1319,y:647,t:1526929950351};\\\", \\\"{x:1319,y:655,t:1526929950369};\\\", \\\"{x:1319,y:662,t:1526929950386};\\\", \\\"{x:1319,y:670,t:1526929950401};\\\", \\\"{x:1317,y:685,t:1526929950418};\\\", \\\"{x:1316,y:697,t:1526929950434};\\\", \\\"{x:1314,y:704,t:1526929950451};\\\", \\\"{x:1313,y:711,t:1526929950469};\\\", \\\"{x:1313,y:715,t:1526929950485};\\\", \\\"{x:1313,y:723,t:1526929950502};\\\", \\\"{x:1313,y:731,t:1526929950518};\\\", \\\"{x:1313,y:741,t:1526929950536};\\\", \\\"{x:1314,y:750,t:1526929950552};\\\", \\\"{x:1314,y:756,t:1526929950569};\\\", \\\"{x:1315,y:764,t:1526929950586};\\\", \\\"{x:1316,y:772,t:1526929950602};\\\", \\\"{x:1317,y:782,t:1526929950619};\\\", \\\"{x:1319,y:790,t:1526929950635};\\\", \\\"{x:1320,y:801,t:1526929950652};\\\", \\\"{x:1320,y:812,t:1526929950669};\\\", \\\"{x:1320,y:818,t:1526929950686};\\\", \\\"{x:1322,y:823,t:1526929950702};\\\", \\\"{x:1322,y:826,t:1526929950718};\\\", \\\"{x:1323,y:832,t:1526929950736};\\\", \\\"{x:1324,y:837,t:1526929950752};\\\", \\\"{x:1324,y:839,t:1526929950769};\\\", \\\"{x:1324,y:841,t:1526929950786};\\\", \\\"{x:1324,y:847,t:1526929950802};\\\", \\\"{x:1324,y:854,t:1526929950819};\\\", \\\"{x:1324,y:862,t:1526929950836};\\\", \\\"{x:1324,y:867,t:1526929950853};\\\", \\\"{x:1324,y:873,t:1526929950869};\\\", \\\"{x:1324,y:881,t:1526929950886};\\\", \\\"{x:1324,y:886,t:1526929950903};\\\", \\\"{x:1324,y:889,t:1526929950919};\\\", \\\"{x:1324,y:894,t:1526929950936};\\\", \\\"{x:1322,y:902,t:1526929950953};\\\", \\\"{x:1322,y:909,t:1526929950968};\\\", \\\"{x:1322,y:916,t:1526929950986};\\\", \\\"{x:1322,y:926,t:1526929951003};\\\", \\\"{x:1322,y:927,t:1526929951018};\\\", \\\"{x:1322,y:929,t:1526929951035};\\\", \\\"{x:1322,y:931,t:1526929951052};\\\", \\\"{x:1322,y:935,t:1526929951068};\\\", \\\"{x:1322,y:936,t:1526929951085};\\\", \\\"{x:1322,y:938,t:1526929951102};\\\", \\\"{x:1322,y:940,t:1526929951118};\\\", \\\"{x:1322,y:942,t:1526929951135};\\\", \\\"{x:1323,y:944,t:1526929951152};\\\", \\\"{x:1323,y:945,t:1526929951168};\\\", \\\"{x:1324,y:948,t:1526929951186};\\\", \\\"{x:1324,y:950,t:1526929951210};\\\", \\\"{x:1324,y:951,t:1526929951218};\\\", \\\"{x:1324,y:954,t:1526929951235};\\\", \\\"{x:1324,y:960,t:1526929951252};\\\", \\\"{x:1324,y:965,t:1526929951269};\\\", \\\"{x:1324,y:968,t:1526929951286};\\\", \\\"{x:1324,y:969,t:1526929951302};\\\", \\\"{x:1324,y:971,t:1526929951320};\\\", \\\"{x:1324,y:972,t:1526929951531};\\\", \\\"{x:1322,y:972,t:1526929952131};\\\", \\\"{x:1319,y:972,t:1526929952138};\\\", \\\"{x:1315,y:972,t:1526929952153};\\\", \\\"{x:1312,y:972,t:1526929952169};\\\", \\\"{x:1309,y:971,t:1526929952186};\\\", \\\"{x:1309,y:969,t:1526929952523};\\\", \\\"{x:1309,y:968,t:1526929952537};\\\", \\\"{x:1311,y:966,t:1526929952554};\\\", \\\"{x:1313,y:965,t:1526929952571};\\\", \\\"{x:1313,y:963,t:1526929952587};\\\", \\\"{x:1314,y:963,t:1526929952604};\\\", \\\"{x:1315,y:962,t:1526929952621};\\\", \\\"{x:1315,y:961,t:1526929957139};\\\", \\\"{x:1318,y:960,t:1526929957147};\\\", \\\"{x:1319,y:959,t:1526929957157};\\\", \\\"{x:1320,y:959,t:1526929957178};\\\", \\\"{x:1321,y:959,t:1526929957218};\\\", \\\"{x:1322,y:958,t:1526929957227};\\\", \\\"{x:1323,y:958,t:1526929957283};\\\", \\\"{x:1323,y:959,t:1526929960812};\\\", \\\"{x:1322,y:959,t:1526929960835};\\\", \\\"{x:1321,y:960,t:1526929960844};\\\", \\\"{x:1320,y:960,t:1526929960861};\\\", \\\"{x:1318,y:960,t:1526929960877};\\\", \\\"{x:1317,y:961,t:1526929960893};\\\", \\\"{x:1315,y:962,t:1526929960911};\\\", \\\"{x:1313,y:963,t:1526929961027};\\\", \\\"{x:1312,y:963,t:1526929961074};\\\", \\\"{x:1310,y:964,t:1526929961107};\\\", \\\"{x:1310,y:965,t:1526929961130};\\\", \\\"{x:1311,y:965,t:1526929961851};\\\", \\\"{x:1313,y:964,t:1526929961867};\\\", \\\"{x:1314,y:964,t:1526929961883};\\\", \\\"{x:1315,y:964,t:1526929961899};\\\", \\\"{x:1316,y:964,t:1526929972740};\\\", \\\"{x:1319,y:964,t:1526929972753};\\\", \\\"{x:1324,y:975,t:1526929972771};\\\", \\\"{x:1328,y:983,t:1526929972787};\\\", \\\"{x:1328,y:984,t:1526929972803};\\\", \\\"{x:1328,y:986,t:1526929972820};\\\", \\\"{x:1328,y:985,t:1526929973242};\\\", \\\"{x:1327,y:984,t:1526929973258};\\\", \\\"{x:1326,y:983,t:1526929973270};\\\", \\\"{x:1324,y:982,t:1526929973286};\\\", \\\"{x:1321,y:980,t:1526929973304};\\\", \\\"{x:1321,y:979,t:1526929973321};\\\", \\\"{x:1320,y:977,t:1526929973337};\\\", \\\"{x:1318,y:975,t:1526929973354};\\\", \\\"{x:1318,y:974,t:1526929973370};\\\", \\\"{x:1317,y:973,t:1526929973387};\\\", \\\"{x:1316,y:970,t:1526929973404};\\\", \\\"{x:1316,y:968,t:1526929978301};\\\", \\\"{x:1318,y:966,t:1526929978311};\\\", \\\"{x:1321,y:966,t:1526929978326};\\\", \\\"{x:1324,y:963,t:1526929978344};\\\", \\\"{x:1328,y:963,t:1526929978636};\\\", \\\"{x:1334,y:966,t:1526929978644};\\\", \\\"{x:1357,y:978,t:1526929978661};\\\", \\\"{x:1388,y:988,t:1526929978676};\\\", \\\"{x:1421,y:996,t:1526929978693};\\\", \\\"{x:1449,y:1000,t:1526929978711};\\\", \\\"{x:1482,y:1005,t:1526929978727};\\\", \\\"{x:1500,y:1005,t:1526929978743};\\\", \\\"{x:1509,y:1005,t:1526929978760};\\\", \\\"{x:1512,y:1005,t:1526929978777};\\\", \\\"{x:1513,y:1005,t:1526929979092};\\\", \\\"{x:1513,y:1003,t:1526929979100};\\\", \\\"{x:1513,y:1000,t:1526929979110};\\\", \\\"{x:1512,y:994,t:1526929979128};\\\", \\\"{x:1512,y:989,t:1526929979144};\\\", \\\"{x:1511,y:983,t:1526929979160};\\\", \\\"{x:1511,y:977,t:1526929979177};\\\", \\\"{x:1508,y:971,t:1526929979194};\\\", \\\"{x:1505,y:964,t:1526929979210};\\\", \\\"{x:1504,y:959,t:1526929979227};\\\", \\\"{x:1502,y:950,t:1526929979245};\\\", \\\"{x:1500,y:945,t:1526929979261};\\\", \\\"{x:1499,y:940,t:1526929979277};\\\", \\\"{x:1497,y:936,t:1526929979294};\\\", \\\"{x:1496,y:930,t:1526929979310};\\\", \\\"{x:1492,y:924,t:1526929979328};\\\", \\\"{x:1492,y:920,t:1526929979345};\\\", \\\"{x:1492,y:917,t:1526929979360};\\\", \\\"{x:1491,y:914,t:1526929979377};\\\", \\\"{x:1491,y:912,t:1526929979394};\\\", \\\"{x:1491,y:911,t:1526929979412};\\\", \\\"{x:1491,y:908,t:1526929979427};\\\", \\\"{x:1491,y:907,t:1526929979445};\\\", \\\"{x:1490,y:906,t:1526929979470};\\\", \\\"{x:1490,y:905,t:1526929979814};\\\", \\\"{x:1490,y:899,t:1526929979829};\\\", \\\"{x:1492,y:878,t:1526929979845};\\\", \\\"{x:1492,y:867,t:1526929979861};\\\", \\\"{x:1492,y:859,t:1526929979878};\\\", \\\"{x:1492,y:853,t:1526929979895};\\\", \\\"{x:1492,y:845,t:1526929979911};\\\", \\\"{x:1488,y:832,t:1526929979928};\\\", \\\"{x:1484,y:821,t:1526929979945};\\\", \\\"{x:1482,y:813,t:1526929979961};\\\", \\\"{x:1479,y:808,t:1526929979979};\\\", \\\"{x:1476,y:802,t:1526929979995};\\\", \\\"{x:1476,y:800,t:1526929980012};\\\", \\\"{x:1476,y:798,t:1526929980028};\\\", \\\"{x:1476,y:797,t:1526929980054};\\\", \\\"{x:1476,y:799,t:1526929980542};\\\", \\\"{x:1476,y:800,t:1526929980550};\\\", \\\"{x:1478,y:802,t:1526929980562};\\\", \\\"{x:1482,y:806,t:1526929980579};\\\", \\\"{x:1485,y:810,t:1526929980596};\\\", \\\"{x:1487,y:811,t:1526929980613};\\\", \\\"{x:1487,y:812,t:1526929980628};\\\", \\\"{x:1488,y:814,t:1526929980645};\\\", \\\"{x:1491,y:817,t:1526929980661};\\\", \\\"{x:1492,y:818,t:1526929980678};\\\", \\\"{x:1494,y:820,t:1526929980695};\\\", \\\"{x:1494,y:822,t:1526929980711};\\\", \\\"{x:1495,y:823,t:1526929980729};\\\", \\\"{x:1496,y:823,t:1526929980745};\\\", \\\"{x:1496,y:824,t:1526929980957};\\\", \\\"{x:1496,y:825,t:1526929980966};\\\", \\\"{x:1494,y:826,t:1526929980979};\\\", \\\"{x:1490,y:830,t:1526929980997};\\\", \\\"{x:1487,y:834,t:1526929981012};\\\", \\\"{x:1481,y:840,t:1526929981029};\\\", \\\"{x:1478,y:842,t:1526929981046};\\\", \\\"{x:1476,y:844,t:1526929981063};\\\", \\\"{x:1474,y:845,t:1526929981078};\\\", \\\"{x:1472,y:846,t:1526929981096};\\\", \\\"{x:1471,y:847,t:1526929981113};\\\", \\\"{x:1471,y:846,t:1526929981446};\\\", \\\"{x:1471,y:845,t:1526929981463};\\\", \\\"{x:1472,y:844,t:1526929981480};\\\", \\\"{x:1472,y:843,t:1526929981496};\\\", \\\"{x:1472,y:841,t:1526929981606};\\\", \\\"{x:1470,y:840,t:1526929981613};\\\", \\\"{x:1455,y:834,t:1526929981629};\\\", \\\"{x:1439,y:829,t:1526929981646};\\\", \\\"{x:1418,y:823,t:1526929981663};\\\", \\\"{x:1396,y:815,t:1526929981679};\\\", \\\"{x:1375,y:810,t:1526929981696};\\\", \\\"{x:1363,y:805,t:1526929981712};\\\", \\\"{x:1356,y:802,t:1526929981729};\\\", \\\"{x:1355,y:801,t:1526929981746};\\\", \\\"{x:1354,y:800,t:1526929981762};\\\", \\\"{x:1357,y:800,t:1526929981909};\\\", \\\"{x:1359,y:801,t:1526929981916};\\\", \\\"{x:1362,y:805,t:1526929981929};\\\", \\\"{x:1367,y:809,t:1526929981946};\\\", \\\"{x:1378,y:826,t:1526929981962};\\\", \\\"{x:1386,y:841,t:1526929981979};\\\", \\\"{x:1395,y:855,t:1526929981996};\\\", \\\"{x:1397,y:861,t:1526929982012};\\\", \\\"{x:1397,y:864,t:1526929982030};\\\", \\\"{x:1398,y:866,t:1526929982046};\\\", \\\"{x:1398,y:868,t:1526929982062};\\\", \\\"{x:1399,y:868,t:1526929982469};\\\", \\\"{x:1399,y:866,t:1526929982480};\\\", \\\"{x:1401,y:859,t:1526929982496};\\\", \\\"{x:1402,y:854,t:1526929982514};\\\", \\\"{x:1403,y:850,t:1526929982529};\\\", \\\"{x:1405,y:846,t:1526929982547};\\\", \\\"{x:1406,y:841,t:1526929982563};\\\", \\\"{x:1410,y:833,t:1526929982580};\\\", \\\"{x:1410,y:828,t:1526929982596};\\\", \\\"{x:1410,y:825,t:1526929982613};\\\", \\\"{x:1410,y:821,t:1526929982630};\\\", \\\"{x:1410,y:818,t:1526929982646};\\\", \\\"{x:1410,y:817,t:1526929982663};\\\", \\\"{x:1410,y:814,t:1526929982681};\\\", \\\"{x:1410,y:812,t:1526929982697};\\\", \\\"{x:1408,y:808,t:1526929982713};\\\", \\\"{x:1405,y:804,t:1526929982731};\\\", \\\"{x:1402,y:798,t:1526929982746};\\\", \\\"{x:1399,y:795,t:1526929982763};\\\", \\\"{x:1391,y:788,t:1526929982780};\\\", \\\"{x:1387,y:786,t:1526929982796};\\\", \\\"{x:1380,y:781,t:1526929982814};\\\", \\\"{x:1374,y:777,t:1526929982831};\\\", \\\"{x:1371,y:775,t:1526929982847};\\\", \\\"{x:1370,y:779,t:1526929982932};\\\", \\\"{x:1370,y:787,t:1526929982946};\\\", \\\"{x:1370,y:812,t:1526929982964};\\\", \\\"{x:1369,y:858,t:1526929982981};\\\", \\\"{x:1369,y:891,t:1526929982997};\\\", \\\"{x:1369,y:917,t:1526929983013};\\\", \\\"{x:1368,y:937,t:1526929983032};\\\", \\\"{x:1368,y:948,t:1526929983047};\\\", \\\"{x:1368,y:954,t:1526929983063};\\\", \\\"{x:1368,y:957,t:1526929983080};\\\", \\\"{x:1369,y:961,t:1526929983096};\\\", \\\"{x:1369,y:965,t:1526929983114};\\\", \\\"{x:1371,y:971,t:1526929983131};\\\", \\\"{x:1373,y:974,t:1526929983148};\\\", \\\"{x:1374,y:975,t:1526929983164};\\\", \\\"{x:1375,y:978,t:1526929983181};\\\", \\\"{x:1376,y:979,t:1526929983205};\\\", \\\"{x:1377,y:979,t:1526929983357};\\\", \\\"{x:1379,y:979,t:1526929983382};\\\", \\\"{x:1379,y:977,t:1526929983398};\\\", \\\"{x:1380,y:976,t:1526929983414};\\\", \\\"{x:1381,y:974,t:1526929983431};\\\", \\\"{x:1382,y:972,t:1526929983453};\\\", \\\"{x:1382,y:971,t:1526929983526};\\\", \\\"{x:1383,y:970,t:1526929983541};\\\", \\\"{x:1383,y:969,t:1526929983614};\\\", \\\"{x:1383,y:968,t:1526929983637};\\\", \\\"{x:1383,y:967,t:1526929983653};\\\", \\\"{x:1383,y:964,t:1526929984502};\\\", \\\"{x:1384,y:958,t:1526929984515};\\\", \\\"{x:1388,y:945,t:1526929984532};\\\", \\\"{x:1394,y:922,t:1526929984550};\\\", \\\"{x:1398,y:905,t:1526929984565};\\\", \\\"{x:1399,y:890,t:1526929984582};\\\", \\\"{x:1402,y:877,t:1526929984599};\\\", \\\"{x:1404,y:863,t:1526929984616};\\\", \\\"{x:1408,y:852,t:1526929984632};\\\", \\\"{x:1411,y:842,t:1526929984649};\\\", \\\"{x:1412,y:832,t:1526929984666};\\\", \\\"{x:1414,y:820,t:1526929984682};\\\", \\\"{x:1416,y:814,t:1526929984700};\\\", \\\"{x:1418,y:807,t:1526929984716};\\\", \\\"{x:1418,y:800,t:1526929984732};\\\", \\\"{x:1417,y:795,t:1526929984750};\\\", \\\"{x:1417,y:793,t:1526929984765};\\\", \\\"{x:1415,y:790,t:1526929984783};\\\", \\\"{x:1413,y:787,t:1526929984799};\\\", \\\"{x:1411,y:784,t:1526929984815};\\\", \\\"{x:1406,y:781,t:1526929984831};\\\", \\\"{x:1397,y:779,t:1526929984849};\\\", \\\"{x:1389,y:777,t:1526929984864};\\\", \\\"{x:1381,y:777,t:1526929984882};\\\", \\\"{x:1378,y:777,t:1526929984898};\\\", \\\"{x:1377,y:777,t:1526929984915};\\\", \\\"{x:1377,y:776,t:1526929985366};\\\", \\\"{x:1377,y:774,t:1526929985383};\\\", \\\"{x:1377,y:773,t:1526929985399};\\\", \\\"{x:1378,y:772,t:1526929985416};\\\", \\\"{x:1379,y:771,t:1526929985433};\\\", \\\"{x:1380,y:770,t:1526929985453};\\\", \\\"{x:1380,y:769,t:1526929985466};\\\", \\\"{x:1381,y:769,t:1526929985485};\\\", \\\"{x:1381,y:768,t:1526929985515};\\\", \\\"{x:1382,y:767,t:1526929985532};\\\", \\\"{x:1383,y:766,t:1526929985548};\\\", \\\"{x:1383,y:765,t:1526929985621};\\\", \\\"{x:1383,y:764,t:1526929992910};\\\", \\\"{x:1378,y:764,t:1526929992921};\\\", \\\"{x:1350,y:764,t:1526929992940};\\\", \\\"{x:1303,y:764,t:1526929992956};\\\", \\\"{x:1237,y:759,t:1526929992973};\\\", \\\"{x:1148,y:745,t:1526929992988};\\\", \\\"{x:1032,y:712,t:1526929993005};\\\", \\\"{x:948,y:687,t:1526929993023};\\\", \\\"{x:877,y:660,t:1526929993039};\\\", \\\"{x:805,y:627,t:1526929993055};\\\", \\\"{x:736,y:596,t:1526929993074};\\\", \\\"{x:654,y:563,t:1526929993088};\\\", \\\"{x:577,y:535,t:1526929993105};\\\", \\\"{x:508,y:516,t:1526929993117};\\\", \\\"{x:439,y:498,t:1526929993134};\\\", \\\"{x:364,y:487,t:1526929993156};\\\", \\\"{x:276,y:474,t:1526929993172};\\\", \\\"{x:224,y:471,t:1526929993189};\\\", \\\"{x:188,y:471,t:1526929993206};\\\", \\\"{x:158,y:471,t:1526929993223};\\\", \\\"{x:135,y:471,t:1526929993240};\\\", \\\"{x:122,y:471,t:1526929993256};\\\", \\\"{x:120,y:471,t:1526929993273};\\\", \\\"{x:117,y:472,t:1526929993290};\\\", \\\"{x:117,y:481,t:1526929993305};\\\", \\\"{x:117,y:500,t:1526929993323};\\\", \\\"{x:123,y:522,t:1526929993341};\\\", \\\"{x:127,y:541,t:1526929993356};\\\", \\\"{x:139,y:563,t:1526929993373};\\\", \\\"{x:158,y:583,t:1526929993389};\\\", \\\"{x:180,y:602,t:1526929993407};\\\", \\\"{x:205,y:617,t:1526929993423};\\\", \\\"{x:229,y:629,t:1526929993441};\\\", \\\"{x:250,y:638,t:1526929993456};\\\", \\\"{x:258,y:641,t:1526929993473};\\\", \\\"{x:259,y:641,t:1526929993489};\\\", \\\"{x:260,y:641,t:1526929993597};\\\", \\\"{x:262,y:641,t:1526929993606};\\\", \\\"{x:265,y:639,t:1526929993623};\\\", \\\"{x:269,y:636,t:1526929993640};\\\", \\\"{x:277,y:633,t:1526929993657};\\\", \\\"{x:289,y:628,t:1526929993673};\\\", \\\"{x:304,y:623,t:1526929993691};\\\", \\\"{x:325,y:618,t:1526929993706};\\\", \\\"{x:345,y:615,t:1526929993723};\\\", \\\"{x:357,y:611,t:1526929993739};\\\", \\\"{x:369,y:607,t:1526929993757};\\\", \\\"{x:371,y:606,t:1526929993772};\\\", \\\"{x:372,y:606,t:1526929993789};\\\", \\\"{x:373,y:605,t:1526929993821};\\\", \\\"{x:373,y:604,t:1526929993828};\\\", \\\"{x:374,y:604,t:1526929993840};\\\", \\\"{x:376,y:603,t:1526929993857};\\\", \\\"{x:377,y:601,t:1526929993873};\\\", \\\"{x:377,y:600,t:1526929993917};\\\", \\\"{x:377,y:599,t:1526929993925};\\\", \\\"{x:377,y:598,t:1526929993941};\\\", \\\"{x:377,y:594,t:1526929993956};\\\", \\\"{x:377,y:591,t:1526929993974};\\\", \\\"{x:377,y:587,t:1526929993990};\\\", \\\"{x:377,y:584,t:1526929994007};\\\", \\\"{x:378,y:580,t:1526929994022};\\\", \\\"{x:378,y:577,t:1526929994040};\\\", \\\"{x:380,y:575,t:1526929994057};\\\", \\\"{x:380,y:573,t:1526929994073};\\\", \\\"{x:380,y:571,t:1526929994090};\\\", \\\"{x:381,y:570,t:1526929994107};\\\", \\\"{x:382,y:569,t:1526929994123};\\\", \\\"{x:383,y:568,t:1526929994493};\\\", \\\"{x:410,y:584,t:1526929994508};\\\", \\\"{x:505,y:658,t:1526929994525};\\\", \\\"{x:708,y:803,t:1526929994541};\\\", \\\"{x:880,y:899,t:1526929994557};\\\", \\\"{x:1065,y:980,t:1526929994574};\\\", \\\"{x:1231,y:1036,t:1526929994591};\\\", \\\"{x:1361,y:1071,t:1526929994607};\\\", \\\"{x:1440,y:1087,t:1526929994624};\\\", \\\"{x:1467,y:1091,t:1526929994641};\\\", \\\"{x:1475,y:1091,t:1526929994657};\\\", \\\"{x:1476,y:1090,t:1526929994709};\\\", \\\"{x:1477,y:1088,t:1526929994725};\\\", \\\"{x:1477,y:1086,t:1526929994741};\\\", \\\"{x:1477,y:1083,t:1526929994757};\\\", \\\"{x:1478,y:1080,t:1526929994774};\\\", \\\"{x:1480,y:1078,t:1526929994791};\\\", \\\"{x:1481,y:1072,t:1526929994807};\\\", \\\"{x:1485,y:1062,t:1526929994824};\\\", \\\"{x:1486,y:1049,t:1526929994842};\\\", \\\"{x:1488,y:1035,t:1526929994857};\\\", \\\"{x:1488,y:1021,t:1526929994875};\\\", \\\"{x:1488,y:1005,t:1526929994892};\\\", \\\"{x:1486,y:992,t:1526929994908};\\\", \\\"{x:1481,y:976,t:1526929994925};\\\", \\\"{x:1472,y:957,t:1526929994942};\\\", \\\"{x:1466,y:949,t:1526929994957};\\\", \\\"{x:1457,y:939,t:1526929994974};\\\", \\\"{x:1447,y:930,t:1526929994992};\\\", \\\"{x:1436,y:920,t:1526929995008};\\\", \\\"{x:1427,y:912,t:1526929995024};\\\", \\\"{x:1427,y:911,t:1526929995041};\\\", \\\"{x:1425,y:911,t:1526929995934};\\\", \\\"{x:1425,y:912,t:1526929995941};\\\", \\\"{x:1424,y:918,t:1526929995958};\\\", \\\"{x:1421,y:920,t:1526929995974};\\\", \\\"{x:1416,y:928,t:1526929995991};\\\", \\\"{x:1413,y:933,t:1526929996008};\\\", \\\"{x:1410,y:937,t:1526929996025};\\\", \\\"{x:1407,y:941,t:1526929996042};\\\", \\\"{x:1404,y:944,t:1526929996059};\\\", \\\"{x:1397,y:951,t:1526929996075};\\\", \\\"{x:1392,y:955,t:1526929996092};\\\", \\\"{x:1388,y:958,t:1526929996108};\\\", \\\"{x:1386,y:961,t:1526929996125};\\\", \\\"{x:1385,y:962,t:1526929996142};\\\", \\\"{x:1385,y:963,t:1526929996159};\\\", \\\"{x:1382,y:966,t:1526929996176};\\\", \\\"{x:1380,y:968,t:1526929996192};\\\", \\\"{x:1375,y:970,t:1526929996208};\\\", \\\"{x:1371,y:971,t:1526929996226};\\\", \\\"{x:1368,y:972,t:1526929996242};\\\", \\\"{x:1366,y:972,t:1526929996259};\\\", \\\"{x:1365,y:972,t:1526929996477};\\\", \\\"{x:1364,y:972,t:1526929996517};\\\", \\\"{x:1363,y:971,t:1526929996533};\\\", \\\"{x:1362,y:971,t:1526929996565};\\\", \\\"{x:1361,y:970,t:1526929996581};\\\", \\\"{x:1359,y:969,t:1526929996597};\\\", \\\"{x:1358,y:969,t:1526929996609};\\\", \\\"{x:1357,y:969,t:1526929996626};\\\", \\\"{x:1355,y:969,t:1526929996642};\\\", \\\"{x:1354,y:969,t:1526929996677};\\\", \\\"{x:1352,y:969,t:1526929996691};\\\", \\\"{x:1351,y:969,t:1526929996709};\\\", \\\"{x:1347,y:969,t:1526929996725};\\\", \\\"{x:1345,y:969,t:1526929996742};\\\", \\\"{x:1343,y:969,t:1526929996773};\\\", \\\"{x:1342,y:968,t:1526929996926};\\\", \\\"{x:1349,y:965,t:1526929996942};\\\", \\\"{x:1371,y:957,t:1526929996959};\\\", \\\"{x:1396,y:950,t:1526929996976};\\\", \\\"{x:1421,y:945,t:1526929996992};\\\", \\\"{x:1441,y:940,t:1526929997009};\\\", \\\"{x:1458,y:937,t:1526929997026};\\\", \\\"{x:1465,y:934,t:1526929997043};\\\", \\\"{x:1470,y:930,t:1526929997059};\\\", \\\"{x:1472,y:929,t:1526929997075};\\\", \\\"{x:1476,y:928,t:1526929997093};\\\", \\\"{x:1477,y:927,t:1526929997109};\\\", \\\"{x:1483,y:924,t:1526929997126};\\\", \\\"{x:1488,y:922,t:1526929997142};\\\", \\\"{x:1496,y:922,t:1526929997159};\\\", \\\"{x:1501,y:918,t:1526929997176};\\\", \\\"{x:1504,y:917,t:1526929997193};\\\", \\\"{x:1504,y:918,t:1526929997285};\\\", \\\"{x:1504,y:919,t:1526929997293};\\\", \\\"{x:1504,y:922,t:1526929997309};\\\", \\\"{x:1504,y:930,t:1526929997326};\\\", \\\"{x:1504,y:937,t:1526929997343};\\\", \\\"{x:1501,y:945,t:1526929997359};\\\", \\\"{x:1498,y:949,t:1526929997375};\\\", \\\"{x:1498,y:951,t:1526929997393};\\\", \\\"{x:1498,y:955,t:1526929997409};\\\", \\\"{x:1498,y:956,t:1526929997425};\\\", \\\"{x:1498,y:958,t:1526929997442};\\\", \\\"{x:1498,y:960,t:1526929997458};\\\", \\\"{x:1497,y:961,t:1526929997709};\\\", \\\"{x:1495,y:960,t:1526929998021};\\\", \\\"{x:1495,y:958,t:1526929998029};\\\", \\\"{x:1495,y:957,t:1526929998043};\\\", \\\"{x:1495,y:951,t:1526929998060};\\\", \\\"{x:1495,y:944,t:1526929998075};\\\", \\\"{x:1496,y:934,t:1526929998094};\\\", \\\"{x:1496,y:930,t:1526929998109};\\\", \\\"{x:1496,y:929,t:1526929998125};\\\", \\\"{x:1496,y:926,t:1526929998142};\\\", \\\"{x:1496,y:922,t:1526929998160};\\\", \\\"{x:1496,y:917,t:1526929998176};\\\", \\\"{x:1497,y:911,t:1526929998193};\\\", \\\"{x:1498,y:905,t:1526929998210};\\\", \\\"{x:1500,y:896,t:1526929998225};\\\", \\\"{x:1500,y:890,t:1526929998243};\\\", \\\"{x:1500,y:884,t:1526929998259};\\\", \\\"{x:1500,y:878,t:1526929998275};\\\", \\\"{x:1499,y:866,t:1526929998292};\\\", \\\"{x:1497,y:858,t:1526929998309};\\\", \\\"{x:1495,y:851,t:1526929998325};\\\", \\\"{x:1493,y:845,t:1526929998342};\\\", \\\"{x:1493,y:843,t:1526929998359};\\\", \\\"{x:1493,y:840,t:1526929998376};\\\", \\\"{x:1492,y:839,t:1526929998392};\\\", \\\"{x:1492,y:838,t:1526929998410};\\\", \\\"{x:1492,y:837,t:1526929998425};\\\", \\\"{x:1492,y:836,t:1526929998442};\\\", \\\"{x:1492,y:835,t:1526929998581};\\\", \\\"{x:1490,y:835,t:1526929998622};\\\", \\\"{x:1489,y:835,t:1526929998702};\\\", \\\"{x:1487,y:836,t:1526929998710};\\\", \\\"{x:1485,y:836,t:1526929998727};\\\", \\\"{x:1483,y:836,t:1526929998773};\\\", \\\"{x:1483,y:837,t:1526929998781};\\\", \\\"{x:1481,y:838,t:1526929998797};\\\", \\\"{x:1478,y:840,t:1526929998810};\\\", \\\"{x:1476,y:840,t:1526929998827};\\\", \\\"{x:1473,y:841,t:1526929998844};\\\", \\\"{x:1471,y:843,t:1526929998860};\\\", \\\"{x:1470,y:843,t:1526929998877};\\\", \\\"{x:1469,y:846,t:1526929999165};\\\", \\\"{x:1469,y:847,t:1526929999177};\\\", \\\"{x:1468,y:855,t:1526929999193};\\\", \\\"{x:1462,y:874,t:1526929999210};\\\", \\\"{x:1457,y:887,t:1526929999226};\\\", \\\"{x:1454,y:896,t:1526929999242};\\\", \\\"{x:1446,y:910,t:1526929999259};\\\", \\\"{x:1442,y:921,t:1526929999276};\\\", \\\"{x:1439,y:928,t:1526929999292};\\\", \\\"{x:1439,y:932,t:1526929999309};\\\", \\\"{x:1437,y:935,t:1526929999326};\\\", \\\"{x:1436,y:940,t:1526929999343};\\\", \\\"{x:1435,y:942,t:1526929999359};\\\", \\\"{x:1434,y:943,t:1526929999377};\\\", \\\"{x:1434,y:945,t:1526929999392};\\\", \\\"{x:1434,y:946,t:1526929999410};\\\", \\\"{x:1432,y:946,t:1526929999517};\\\", \\\"{x:1430,y:944,t:1526929999527};\\\", \\\"{x:1421,y:932,t:1526929999544};\\\", \\\"{x:1405,y:916,t:1526929999560};\\\", \\\"{x:1387,y:897,t:1526929999577};\\\", \\\"{x:1375,y:880,t:1526929999594};\\\", \\\"{x:1363,y:863,t:1526929999609};\\\", \\\"{x:1360,y:848,t:1526929999627};\\\", \\\"{x:1360,y:839,t:1526929999644};\\\", \\\"{x:1361,y:832,t:1526929999660};\\\", \\\"{x:1366,y:824,t:1526929999677};\\\", \\\"{x:1369,y:819,t:1526929999693};\\\", \\\"{x:1374,y:811,t:1526929999710};\\\", \\\"{x:1379,y:801,t:1526929999727};\\\", \\\"{x:1383,y:796,t:1526929999744};\\\", \\\"{x:1384,y:792,t:1526929999760};\\\", \\\"{x:1386,y:788,t:1526929999777};\\\", \\\"{x:1386,y:785,t:1526929999794};\\\", \\\"{x:1388,y:782,t:1526929999810};\\\", \\\"{x:1391,y:777,t:1526929999827};\\\", \\\"{x:1393,y:774,t:1526929999844};\\\", \\\"{x:1394,y:772,t:1526929999860};\\\", \\\"{x:1397,y:766,t:1526929999877};\\\", \\\"{x:1398,y:763,t:1526929999894};\\\", \\\"{x:1398,y:761,t:1526929999917};\\\", \\\"{x:1398,y:757,t:1526929999927};\\\", \\\"{x:1398,y:753,t:1526929999944};\\\", \\\"{x:1398,y:746,t:1526929999960};\\\", \\\"{x:1398,y:741,t:1526929999977};\\\", \\\"{x:1398,y:732,t:1526929999994};\\\", \\\"{x:1397,y:720,t:1526930000010};\\\", \\\"{x:1396,y:707,t:1526930000027};\\\", \\\"{x:1396,y:692,t:1526930000044};\\\", \\\"{x:1396,y:670,t:1526930000060};\\\", \\\"{x:1397,y:641,t:1526930000077};\\\", \\\"{x:1398,y:627,t:1526930000093};\\\", \\\"{x:1400,y:611,t:1526930000110};\\\", \\\"{x:1400,y:600,t:1526930000127};\\\", \\\"{x:1398,y:590,t:1526930000144};\\\", \\\"{x:1398,y:584,t:1526930000160};\\\", \\\"{x:1398,y:582,t:1526930000177};\\\", \\\"{x:1398,y:581,t:1526930000229};\\\", \\\"{x:1400,y:581,t:1526930000293};\\\", \\\"{x:1412,y:591,t:1526930000310};\\\", \\\"{x:1426,y:612,t:1526930000327};\\\", \\\"{x:1430,y:638,t:1526930000344};\\\", \\\"{x:1434,y:678,t:1526930000360};\\\", \\\"{x:1431,y:719,t:1526930000377};\\\", \\\"{x:1413,y:763,t:1526930000394};\\\", \\\"{x:1405,y:781,t:1526930000410};\\\", \\\"{x:1400,y:793,t:1526930000427};\\\", \\\"{x:1396,y:799,t:1526930000444};\\\", \\\"{x:1395,y:807,t:1526930000461};\\\", \\\"{x:1394,y:811,t:1526930000477};\\\", \\\"{x:1393,y:814,t:1526930000493};\\\", \\\"{x:1390,y:819,t:1526930000511};\\\", \\\"{x:1389,y:823,t:1526930000527};\\\", \\\"{x:1387,y:838,t:1526930000544};\\\", \\\"{x:1383,y:856,t:1526930000561};\\\", \\\"{x:1380,y:873,t:1526930000577};\\\", \\\"{x:1378,y:882,t:1526930000594};\\\", \\\"{x:1375,y:888,t:1526930000610};\\\", \\\"{x:1373,y:894,t:1526930000627};\\\", \\\"{x:1373,y:902,t:1526930000644};\\\", \\\"{x:1375,y:917,t:1526930000661};\\\", \\\"{x:1377,y:930,t:1526930000677};\\\", \\\"{x:1380,y:942,t:1526930000693};\\\", \\\"{x:1381,y:947,t:1526930000711};\\\", \\\"{x:1381,y:949,t:1526930000727};\\\", \\\"{x:1382,y:949,t:1526930000789};\\\", \\\"{x:1384,y:949,t:1526930000797};\\\", \\\"{x:1389,y:946,t:1526930000813};\\\", \\\"{x:1394,y:929,t:1526930000827};\\\", \\\"{x:1402,y:896,t:1526930000844};\\\", \\\"{x:1423,y:808,t:1526930000862};\\\", \\\"{x:1437,y:748,t:1526930000878};\\\", \\\"{x:1446,y:696,t:1526930000896};\\\", \\\"{x:1450,y:663,t:1526930000911};\\\", \\\"{x:1458,y:639,t:1526930000927};\\\", \\\"{x:1465,y:618,t:1526930000944};\\\", \\\"{x:1467,y:601,t:1526930000961};\\\", \\\"{x:1471,y:585,t:1526930000977};\\\", \\\"{x:1474,y:570,t:1526930000994};\\\", \\\"{x:1475,y:562,t:1526930001013};\\\", \\\"{x:1475,y:560,t:1526930001027};\\\", \\\"{x:1475,y:558,t:1526930001044};\\\", \\\"{x:1475,y:556,t:1526930001069};\\\", \\\"{x:1474,y:556,t:1526930001133};\\\", \\\"{x:1473,y:556,t:1526930001148};\\\", \\\"{x:1472,y:556,t:1526930001165};\\\", \\\"{x:1471,y:556,t:1526930001176};\\\", \\\"{x:1468,y:557,t:1526930001193};\\\", \\\"{x:1465,y:559,t:1526930001211};\\\", \\\"{x:1456,y:563,t:1526930001227};\\\", \\\"{x:1445,y:565,t:1526930001244};\\\", \\\"{x:1436,y:571,t:1526930001260};\\\", \\\"{x:1434,y:572,t:1526930001276};\\\", \\\"{x:1433,y:573,t:1526930001293};\\\", \\\"{x:1432,y:574,t:1526930001845};\\\", \\\"{x:1431,y:574,t:1526930001893};\\\", \\\"{x:1430,y:574,t:1526930001911};\\\", \\\"{x:1423,y:574,t:1526930001941};\\\", \\\"{x:1418,y:574,t:1526930001949};\\\", \\\"{x:1415,y:574,t:1526930001961};\\\", \\\"{x:1414,y:575,t:1526930002525};\\\", \\\"{x:1414,y:577,t:1526930002533};\\\", \\\"{x:1414,y:579,t:1526930002545};\\\", \\\"{x:1414,y:587,t:1526930002561};\\\", \\\"{x:1412,y:595,t:1526930002577};\\\", \\\"{x:1411,y:600,t:1526930002595};\\\", \\\"{x:1409,y:603,t:1526930002612};\\\", \\\"{x:1407,y:608,t:1526930002628};\\\", \\\"{x:1405,y:615,t:1526930002645};\\\", \\\"{x:1400,y:615,t:1526930002661};\\\", \\\"{x:1393,y:615,t:1526930002678};\\\", \\\"{x:1391,y:615,t:1526930003293};\\\", \\\"{x:1388,y:615,t:1526930003309};\\\", \\\"{x:1386,y:616,t:1526930003317};\\\", \\\"{x:1383,y:618,t:1526930003328};\\\", \\\"{x:1379,y:619,t:1526930003345};\\\", \\\"{x:1377,y:621,t:1526930003362};\\\", \\\"{x:1373,y:621,t:1526930003379};\\\", \\\"{x:1358,y:626,t:1526930003395};\\\", \\\"{x:1346,y:630,t:1526930003413};\\\", \\\"{x:1338,y:633,t:1526930003429};\\\", \\\"{x:1329,y:636,t:1526930003445};\\\", \\\"{x:1323,y:637,t:1526930003462};\\\", \\\"{x:1321,y:639,t:1526930003478};\\\", \\\"{x:1318,y:640,t:1526930003495};\\\", \\\"{x:1314,y:640,t:1526930003512};\\\", \\\"{x:1311,y:640,t:1526930003528};\\\", \\\"{x:1309,y:640,t:1526930003545};\\\", \\\"{x:1306,y:642,t:1526930003562};\\\", \\\"{x:1305,y:642,t:1526930005445};\\\", \\\"{x:1305,y:641,t:1526930005485};\\\", \\\"{x:1305,y:640,t:1526930005496};\\\", \\\"{x:1305,y:639,t:1526930005513};\\\", \\\"{x:1305,y:638,t:1526930006478};\\\", \\\"{x:1305,y:640,t:1526930006925};\\\", \\\"{x:1305,y:643,t:1526930007405};\\\", \\\"{x:1304,y:645,t:1526930007413};\\\", \\\"{x:1297,y:648,t:1526930007431};\\\", \\\"{x:1275,y:657,t:1526930007447};\\\", \\\"{x:1248,y:669,t:1526930007463};\\\", \\\"{x:1175,y:689,t:1526930007480};\\\", \\\"{x:1058,y:731,t:1526930007498};\\\", \\\"{x:916,y:783,t:1526930007513};\\\", \\\"{x:751,y:819,t:1526930007530};\\\", \\\"{x:631,y:844,t:1526930007547};\\\", \\\"{x:514,y:862,t:1526930007563};\\\", \\\"{x:444,y:864,t:1526930007580};\\\", \\\"{x:388,y:864,t:1526930007597};\\\", \\\"{x:372,y:860,t:1526930007613};\\\", \\\"{x:361,y:857,t:1526930007629};\\\", \\\"{x:355,y:856,t:1526930007647};\\\", \\\"{x:351,y:853,t:1526930007663};\\\", \\\"{x:349,y:848,t:1526930007680};\\\", \\\"{x:347,y:842,t:1526930007697};\\\", \\\"{x:346,y:836,t:1526930007713};\\\", \\\"{x:348,y:821,t:1526930007730};\\\", \\\"{x:358,y:799,t:1526930007747};\\\", \\\"{x:370,y:779,t:1526930007763};\\\", \\\"{x:387,y:760,t:1526930007780};\\\", \\\"{x:422,y:744,t:1526930007797};\\\", \\\"{x:437,y:739,t:1526930007814};\\\", \\\"{x:454,y:735,t:1526930007831};\\\", \\\"{x:470,y:732,t:1526930007847};\\\", \\\"{x:474,y:732,t:1526930007862};\\\", \\\"{x:475,y:732,t:1526930007900};\\\", \\\"{x:476,y:732,t:1526930007932};\\\" ] }, { \\\"rt\\\": 13424, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 346113, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:470,y:733,t:1526930011750};\\\", \\\"{x:468,y:735,t:1526930011757};\\\", \\\"{x:464,y:741,t:1526930011773};\\\", \\\"{x:463,y:742,t:1526930011790};\\\", \\\"{x:463,y:743,t:1526930011807};\\\", \\\"{x:463,y:744,t:1526930011926};\\\", \\\"{x:464,y:744,t:1526930011940};\\\", \\\"{x:467,y:743,t:1526930011957};\\\", \\\"{x:468,y:743,t:1526930011974};\\\", \\\"{x:469,y:741,t:1526930011990};\\\", \\\"{x:472,y:738,t:1526930012007};\\\", \\\"{x:475,y:735,t:1526930012024};\\\", \\\"{x:477,y:734,t:1526930012040};\\\", \\\"{x:478,y:733,t:1526930012061};\\\", \\\"{x:477,y:733,t:1526930012925};\\\", \\\"{x:476,y:733,t:1526930012981};\\\", \\\"{x:475,y:733,t:1526930012992};\\\", \\\"{x:474,y:734,t:1526930013008};\\\", \\\"{x:470,y:738,t:1526930013025};\\\", \\\"{x:463,y:739,t:1526930013042};\\\", \\\"{x:459,y:741,t:1526930013058};\\\", \\\"{x:458,y:742,t:1526930013076};\\\", \\\"{x:456,y:742,t:1526930013092};\\\", \\\"{x:455,y:742,t:1526930013245};\\\", \\\"{x:452,y:742,t:1526930013258};\\\", \\\"{x:443,y:742,t:1526930013276};\\\", \\\"{x:430,y:742,t:1526930013292};\\\", \\\"{x:422,y:738,t:1526930013308};\\\", \\\"{x:417,y:734,t:1526930013320};\\\", \\\"{x:402,y:723,t:1526930013336};\\\", \\\"{x:387,y:712,t:1526930013354};\\\", \\\"{x:373,y:699,t:1526930013370};\\\", \\\"{x:362,y:688,t:1526930013387};\\\", \\\"{x:348,y:675,t:1526930013404};\\\", \\\"{x:337,y:665,t:1526930013420};\\\", \\\"{x:327,y:655,t:1526930013436};\\\", \\\"{x:322,y:648,t:1526930013456};\\\", \\\"{x:314,y:637,t:1526930013474};\\\", \\\"{x:311,y:633,t:1526930013490};\\\", \\\"{x:310,y:633,t:1526930013506};\\\", \\\"{x:310,y:631,t:1526930013524};\\\", \\\"{x:310,y:629,t:1526930013539};\\\", \\\"{x:311,y:627,t:1526930013580};\\\", \\\"{x:315,y:625,t:1526930013590};\\\", \\\"{x:319,y:624,t:1526930013606};\\\", \\\"{x:327,y:622,t:1526930013622};\\\", \\\"{x:333,y:622,t:1526930013640};\\\", \\\"{x:338,y:621,t:1526930013656};\\\", \\\"{x:343,y:620,t:1526930013673};\\\", \\\"{x:348,y:619,t:1526930013690};\\\", \\\"{x:352,y:618,t:1526930013706};\\\", \\\"{x:354,y:616,t:1526930013724};\\\", \\\"{x:355,y:616,t:1526930013741};\\\", \\\"{x:355,y:615,t:1526930013773};\\\", \\\"{x:357,y:613,t:1526930013790};\\\", \\\"{x:359,y:609,t:1526930013806};\\\", \\\"{x:362,y:604,t:1526930013823};\\\", \\\"{x:363,y:600,t:1526930013841};\\\", \\\"{x:364,y:597,t:1526930013856};\\\", \\\"{x:364,y:595,t:1526930013873};\\\", \\\"{x:364,y:593,t:1526930013890};\\\", \\\"{x:364,y:592,t:1526930013907};\\\", \\\"{x:360,y:587,t:1526930013923};\\\", \\\"{x:345,y:583,t:1526930013939};\\\", \\\"{x:318,y:581,t:1526930013956};\\\", \\\"{x:293,y:579,t:1526930013973};\\\", \\\"{x:261,y:578,t:1526930013991};\\\", \\\"{x:238,y:576,t:1526930014007};\\\", \\\"{x:218,y:576,t:1526930014023};\\\", \\\"{x:201,y:576,t:1526930014040};\\\", \\\"{x:191,y:576,t:1526930014057};\\\", \\\"{x:185,y:576,t:1526930014073};\\\", \\\"{x:184,y:576,t:1526930014090};\\\", \\\"{x:183,y:576,t:1526930014196};\\\", \\\"{x:183,y:578,t:1526930014221};\\\", \\\"{x:183,y:580,t:1526930014228};\\\", \\\"{x:183,y:581,t:1526930014240};\\\", \\\"{x:183,y:589,t:1526930014257};\\\", \\\"{x:183,y:598,t:1526930014275};\\\", \\\"{x:184,y:605,t:1526930014291};\\\", \\\"{x:186,y:607,t:1526930014307};\\\", \\\"{x:186,y:608,t:1526930014324};\\\", \\\"{x:187,y:614,t:1526930014340};\\\", \\\"{x:204,y:625,t:1526930014357};\\\", \\\"{x:221,y:634,t:1526930014376};\\\", \\\"{x:241,y:643,t:1526930014391};\\\", \\\"{x:274,y:650,t:1526930014408};\\\", \\\"{x:331,y:660,t:1526930014424};\\\", \\\"{x:388,y:665,t:1526930014440};\\\", \\\"{x:450,y:666,t:1526930014457};\\\", \\\"{x:508,y:666,t:1526930014475};\\\", \\\"{x:559,y:666,t:1526930014491};\\\", \\\"{x:595,y:662,t:1526930014507};\\\", \\\"{x:630,y:651,t:1526930014524};\\\", \\\"{x:640,y:646,t:1526930014540};\\\", \\\"{x:663,y:636,t:1526930014557};\\\", \\\"{x:672,y:631,t:1526930014575};\\\", \\\"{x:680,y:626,t:1526930014590};\\\", \\\"{x:684,y:622,t:1526930014607};\\\", \\\"{x:687,y:619,t:1526930014624};\\\", \\\"{x:697,y:617,t:1526930014641};\\\", \\\"{x:708,y:615,t:1526930014657};\\\", \\\"{x:721,y:610,t:1526930014674};\\\", \\\"{x:733,y:604,t:1526930014692};\\\", \\\"{x:744,y:595,t:1526930014708};\\\", \\\"{x:749,y:593,t:1526930014725};\\\", \\\"{x:751,y:591,t:1526930014740};\\\", \\\"{x:751,y:589,t:1526930014757};\\\", \\\"{x:751,y:587,t:1526930014774};\\\", \\\"{x:752,y:586,t:1526930014805};\\\", \\\"{x:752,y:585,t:1526930014812};\\\", \\\"{x:752,y:584,t:1526930014828};\\\", \\\"{x:752,y:583,t:1526930014841};\\\", \\\"{x:754,y:579,t:1526930014857};\\\", \\\"{x:755,y:577,t:1526930014873};\\\", \\\"{x:758,y:572,t:1526930014891};\\\", \\\"{x:767,y:565,t:1526930014906};\\\", \\\"{x:796,y:559,t:1526930014924};\\\", \\\"{x:838,y:548,t:1526930014941};\\\", \\\"{x:871,y:540,t:1526930014959};\\\", \\\"{x:895,y:533,t:1526930014974};\\\", \\\"{x:907,y:528,t:1526930014991};\\\", \\\"{x:909,y:527,t:1526930015007};\\\", \\\"{x:909,y:525,t:1526930015024};\\\", \\\"{x:910,y:523,t:1526930015042};\\\", \\\"{x:909,y:519,t:1526930015057};\\\", \\\"{x:900,y:513,t:1526930015075};\\\", \\\"{x:880,y:507,t:1526930015091};\\\", \\\"{x:853,y:503,t:1526930015108};\\\", \\\"{x:787,y:494,t:1526930015124};\\\", \\\"{x:750,y:493,t:1526930015141};\\\", \\\"{x:728,y:493,t:1526930015157};\\\", \\\"{x:722,y:493,t:1526930015176};\\\", \\\"{x:720,y:493,t:1526930015191};\\\", \\\"{x:719,y:493,t:1526930015237};\\\", \\\"{x:719,y:494,t:1526930015253};\\\", \\\"{x:719,y:495,t:1526930015268};\\\", \\\"{x:719,y:497,t:1526930015277};\\\", \\\"{x:719,y:500,t:1526930015291};\\\", \\\"{x:719,y:503,t:1526930015307};\\\", \\\"{x:719,y:506,t:1526930015324};\\\", \\\"{x:718,y:514,t:1526930015341};\\\", \\\"{x:715,y:521,t:1526930015358};\\\", \\\"{x:711,y:526,t:1526930015374};\\\", \\\"{x:703,y:532,t:1526930015391};\\\", \\\"{x:697,y:533,t:1526930015408};\\\", \\\"{x:681,y:536,t:1526930015425};\\\", \\\"{x:663,y:542,t:1526930015441};\\\", \\\"{x:637,y:548,t:1526930015458};\\\", \\\"{x:608,y:550,t:1526930015475};\\\", \\\"{x:570,y:551,t:1526930015491};\\\", \\\"{x:543,y:554,t:1526930015508};\\\", \\\"{x:539,y:554,t:1526930015524};\\\", \\\"{x:537,y:555,t:1526930015541};\\\", \\\"{x:536,y:557,t:1526930015621};\\\", \\\"{x:544,y:558,t:1526930015640};\\\", \\\"{x:557,y:556,t:1526930015658};\\\", \\\"{x:571,y:549,t:1526930015675};\\\", \\\"{x:580,y:541,t:1526930015691};\\\", \\\"{x:587,y:534,t:1526930015708};\\\", \\\"{x:588,y:531,t:1526930015724};\\\", \\\"{x:589,y:530,t:1526930015741};\\\", \\\"{x:589,y:528,t:1526930015764};\\\", \\\"{x:589,y:527,t:1526930015775};\\\", \\\"{x:589,y:524,t:1526930015791};\\\", \\\"{x:589,y:521,t:1526930015808};\\\", \\\"{x:589,y:517,t:1526930015826};\\\", \\\"{x:589,y:516,t:1526930015925};\\\", \\\"{x:589,y:514,t:1526930015942};\\\", \\\"{x:589,y:512,t:1526930015958};\\\", \\\"{x:590,y:511,t:1526930015988};\\\", \\\"{x:591,y:510,t:1526930016004};\\\", \\\"{x:591,y:509,t:1526930016020};\\\", \\\"{x:591,y:508,t:1526930016028};\\\", \\\"{x:592,y:507,t:1526930016042};\\\", \\\"{x:592,y:504,t:1526930016058};\\\", \\\"{x:593,y:501,t:1526930016075};\\\", \\\"{x:594,y:499,t:1526930016092};\\\", \\\"{x:594,y:497,t:1526930016108};\\\", \\\"{x:595,y:496,t:1526930016125};\\\", \\\"{x:598,y:499,t:1526930016637};\\\", \\\"{x:603,y:504,t:1526930016645};\\\", \\\"{x:611,y:508,t:1526930016659};\\\", \\\"{x:628,y:517,t:1526930016676};\\\", \\\"{x:656,y:527,t:1526930016694};\\\", \\\"{x:675,y:533,t:1526930016709};\\\", \\\"{x:689,y:537,t:1526930016726};\\\", \\\"{x:705,y:541,t:1526930016742};\\\", \\\"{x:727,y:545,t:1526930016759};\\\", \\\"{x:746,y:550,t:1526930016775};\\\", \\\"{x:758,y:551,t:1526930016792};\\\", \\\"{x:767,y:551,t:1526930016809};\\\", \\\"{x:768,y:551,t:1526930016826};\\\", \\\"{x:770,y:551,t:1526930016989};\\\", \\\"{x:772,y:551,t:1526930016997};\\\", \\\"{x:773,y:551,t:1526930017021};\\\", \\\"{x:774,y:551,t:1526930017077};\\\", \\\"{x:772,y:548,t:1526930017094};\\\", \\\"{x:758,y:543,t:1526930017111};\\\", \\\"{x:741,y:536,t:1526930017126};\\\", \\\"{x:720,y:531,t:1526930017145};\\\", \\\"{x:697,y:525,t:1526930017160};\\\", \\\"{x:682,y:521,t:1526930017176};\\\", \\\"{x:677,y:520,t:1526930017193};\\\", \\\"{x:675,y:520,t:1526930017209};\\\", \\\"{x:674,y:517,t:1526930017276};\\\", \\\"{x:668,y:516,t:1526930017292};\\\", \\\"{x:662,y:513,t:1526930017309};\\\", \\\"{x:649,y:510,t:1526930017326};\\\", \\\"{x:631,y:505,t:1526930017343};\\\", \\\"{x:616,y:501,t:1526930017360};\\\", \\\"{x:606,y:499,t:1526930017376};\\\", \\\"{x:603,y:497,t:1526930017393};\\\", \\\"{x:602,y:497,t:1526930017409};\\\", \\\"{x:605,y:497,t:1526930017780};\\\", \\\"{x:616,y:500,t:1526930017793};\\\", \\\"{x:649,y:514,t:1526930017811};\\\", \\\"{x:717,y:536,t:1526930017826};\\\", \\\"{x:807,y:557,t:1526930017843};\\\", \\\"{x:882,y:572,t:1526930017860};\\\", \\\"{x:909,y:574,t:1526930017876};\\\", \\\"{x:917,y:575,t:1526930017893};\\\", \\\"{x:918,y:576,t:1526930017910};\\\", \\\"{x:915,y:573,t:1526930018013};\\\", \\\"{x:913,y:573,t:1526930018026};\\\", \\\"{x:905,y:569,t:1526930018043};\\\", \\\"{x:895,y:567,t:1526930018060};\\\", \\\"{x:876,y:561,t:1526930018078};\\\", \\\"{x:860,y:559,t:1526930018093};\\\", \\\"{x:850,y:558,t:1526930018110};\\\", \\\"{x:841,y:556,t:1526930018127};\\\", \\\"{x:831,y:552,t:1526930018143};\\\", \\\"{x:824,y:552,t:1526930018160};\\\", \\\"{x:821,y:552,t:1526930018177};\\\", \\\"{x:820,y:551,t:1526930018193};\\\", \\\"{x:820,y:550,t:1526930018268};\\\", \\\"{x:820,y:548,t:1526930018334};\\\", \\\"{x:820,y:547,t:1526930018365};\\\", \\\"{x:820,y:546,t:1526930018377};\\\", \\\"{x:820,y:545,t:1526930018397};\\\", \\\"{x:820,y:544,t:1526930018410};\\\", \\\"{x:821,y:542,t:1526930018427};\\\", \\\"{x:821,y:541,t:1526930018485};\\\", \\\"{x:822,y:541,t:1526930018637};\\\", \\\"{x:823,y:541,t:1526930020502};\\\", \\\"{x:823,y:542,t:1526930020516};\\\", \\\"{x:823,y:543,t:1526930020527};\\\", \\\"{x:822,y:545,t:1526930020543};\\\", \\\"{x:820,y:549,t:1526930020560};\\\", \\\"{x:818,y:554,t:1526930020576};\\\", \\\"{x:814,y:562,t:1526930020595};\\\", \\\"{x:809,y:577,t:1526930020611};\\\", \\\"{x:798,y:592,t:1526930020627};\\\", \\\"{x:782,y:626,t:1526930020645};\\\", \\\"{x:767,y:649,t:1526930020662};\\\", \\\"{x:752,y:670,t:1526930020679};\\\", \\\"{x:736,y:694,t:1526930020695};\\\", \\\"{x:719,y:713,t:1526930020712};\\\", \\\"{x:705,y:729,t:1526930020729};\\\", \\\"{x:689,y:748,t:1526930020745};\\\", \\\"{x:671,y:771,t:1526930020762};\\\", \\\"{x:655,y:790,t:1526930020779};\\\", \\\"{x:644,y:801,t:1526930020796};\\\", \\\"{x:634,y:809,t:1526930020812};\\\", \\\"{x:631,y:812,t:1526930020829};\\\", \\\"{x:629,y:813,t:1526930020845};\\\", \\\"{x:627,y:813,t:1526930020918};\\\", \\\"{x:625,y:812,t:1526930020930};\\\", \\\"{x:622,y:806,t:1526930020945};\\\", \\\"{x:621,y:803,t:1526930020963};\\\", \\\"{x:619,y:797,t:1526930020980};\\\", \\\"{x:617,y:788,t:1526930020996};\\\", \\\"{x:615,y:776,t:1526930021013};\\\", \\\"{x:613,y:768,t:1526930021029};\\\", \\\"{x:610,y:762,t:1526930021046};\\\", \\\"{x:609,y:759,t:1526930021062};\\\", \\\"{x:604,y:753,t:1526930021080};\\\", \\\"{x:600,y:750,t:1526930021096};\\\", \\\"{x:593,y:745,t:1526930021113};\\\", \\\"{x:583,y:741,t:1526930021130};\\\", \\\"{x:573,y:739,t:1526930021146};\\\", \\\"{x:567,y:737,t:1526930021163};\\\", \\\"{x:562,y:736,t:1526930021181};\\\", \\\"{x:559,y:736,t:1526930021196};\\\", \\\"{x:558,y:736,t:1526930021228};\\\", \\\"{x:559,y:734,t:1526930021236};\\\", \\\"{x:560,y:734,t:1526930021245};\\\", \\\"{x:567,y:731,t:1526930021263};\\\", \\\"{x:578,y:725,t:1526930021279};\\\", \\\"{x:604,y:711,t:1526930021296};\\\", \\\"{x:643,y:689,t:1526930021312};\\\", \\\"{x:698,y:657,t:1526930021329};\\\", \\\"{x:738,y:634,t:1526930021346};\\\", \\\"{x:780,y:608,t:1526930021363};\\\", \\\"{x:809,y:592,t:1526930021381};\\\", \\\"{x:833,y:578,t:1526930021396};\\\", \\\"{x:841,y:571,t:1526930021412};\\\", \\\"{x:845,y:565,t:1526930021430};\\\", \\\"{x:847,y:563,t:1526930021446};\\\", \\\"{x:851,y:557,t:1526930021464};\\\", \\\"{x:854,y:551,t:1526930021480};\\\", \\\"{x:857,y:545,t:1526930021497};\\\", \\\"{x:860,y:540,t:1526930021512};\\\", \\\"{x:862,y:536,t:1526930021529};\\\", \\\"{x:862,y:534,t:1526930021546};\\\", \\\"{x:862,y:530,t:1526930021562};\\\", \\\"{x:864,y:528,t:1526930021579};\\\", \\\"{x:864,y:527,t:1526930021717};\\\", \\\"{x:862,y:527,t:1526930021730};\\\", \\\"{x:857,y:528,t:1526930021747};\\\", \\\"{x:854,y:529,t:1526930021762};\\\", \\\"{x:851,y:531,t:1526930021780};\\\", \\\"{x:849,y:533,t:1526930022349};\\\", \\\"{x:845,y:535,t:1526930022364};\\\", \\\"{x:816,y:546,t:1526930022382};\\\", \\\"{x:788,y:552,t:1526930022397};\\\", \\\"{x:752,y:558,t:1526930022414};\\\", \\\"{x:726,y:565,t:1526930022430};\\\", \\\"{x:693,y:574,t:1526930022447};\\\", \\\"{x:670,y:585,t:1526930022463};\\\", \\\"{x:651,y:600,t:1526930022481};\\\", \\\"{x:632,y:622,t:1526930022498};\\\", \\\"{x:617,y:646,t:1526930022513};\\\", \\\"{x:605,y:672,t:1526930022530};\\\", \\\"{x:596,y:696,t:1526930022548};\\\", \\\"{x:584,y:716,t:1526930022564};\\\", \\\"{x:576,y:729,t:1526930022580};\\\", \\\"{x:575,y:732,t:1526930022598};\\\", \\\"{x:574,y:735,t:1526930022613};\\\", \\\"{x:573,y:736,t:1526930022630};\\\", \\\"{x:572,y:737,t:1526930022805};\\\", \\\"{x:571,y:737,t:1526930022814};\\\", \\\"{x:569,y:737,t:1526930022831};\\\", \\\"{x:565,y:737,t:1526930022848};\\\", \\\"{x:561,y:737,t:1526930022868};\\\", \\\"{x:557,y:737,t:1526930022880};\\\", \\\"{x:553,y:737,t:1526930022897};\\\", \\\"{x:549,y:737,t:1526930022913};\\\", \\\"{x:547,y:737,t:1526930022930};\\\", \\\"{x:542,y:737,t:1526930022947};\\\", \\\"{x:537,y:735,t:1526930022963};\\\", \\\"{x:531,y:735,t:1526930022980};\\\", \\\"{x:529,y:735,t:1526930022996};\\\" ] }, { \\\"rt\\\": 24354, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 371681, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -J -I -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:732,t:1526930025820};\\\", \\\"{x:528,y:711,t:1526930025836};\\\", \\\"{x:521,y:666,t:1526930025848};\\\", \\\"{x:509,y:616,t:1526930025865};\\\", \\\"{x:500,y:590,t:1526930025884};\\\", \\\"{x:495,y:576,t:1526930025900};\\\", \\\"{x:494,y:569,t:1526930025916};\\\", \\\"{x:494,y:568,t:1526930025940};\\\", \\\"{x:494,y:567,t:1526930026789};\\\", \\\"{x:494,y:565,t:1526930026802};\\\", \\\"{x:494,y:560,t:1526930026820};\\\", \\\"{x:495,y:554,t:1526930026835};\\\", \\\"{x:497,y:549,t:1526930026850};\\\", \\\"{x:497,y:541,t:1526930026868};\\\", \\\"{x:497,y:535,t:1526930026884};\\\", \\\"{x:498,y:531,t:1526930026900};\\\", \\\"{x:498,y:528,t:1526930026917};\\\", \\\"{x:499,y:522,t:1526930026935};\\\", \\\"{x:499,y:516,t:1526930026951};\\\", \\\"{x:499,y:512,t:1526930026967};\\\", \\\"{x:499,y:508,t:1526930026983};\\\", \\\"{x:497,y:503,t:1526930027002};\\\", \\\"{x:494,y:497,t:1526930027017};\\\", \\\"{x:492,y:494,t:1526930027033};\\\", \\\"{x:491,y:493,t:1526930027050};\\\", \\\"{x:490,y:492,t:1526930027067};\\\", \\\"{x:490,y:490,t:1526930027085};\\\", \\\"{x:489,y:490,t:1526930027101};\\\", \\\"{x:489,y:489,t:1526930027118};\\\", \\\"{x:487,y:488,t:1526930027134};\\\", \\\"{x:485,y:487,t:1526930027151};\\\", \\\"{x:482,y:486,t:1526930027169};\\\", \\\"{x:479,y:485,t:1526930027184};\\\", \\\"{x:476,y:483,t:1526930027201};\\\", \\\"{x:474,y:483,t:1526930027218};\\\", \\\"{x:473,y:483,t:1526930027235};\\\", \\\"{x:472,y:482,t:1526930027251};\\\", \\\"{x:471,y:482,t:1526930027268};\\\", \\\"{x:470,y:480,t:1526930027284};\\\", \\\"{x:469,y:479,t:1526930027301};\\\", \\\"{x:468,y:476,t:1526930027318};\\\", \\\"{x:467,y:476,t:1526930027334};\\\", \\\"{x:467,y:474,t:1526930027350};\\\", \\\"{x:466,y:473,t:1526930027368};\\\", \\\"{x:466,y:471,t:1526930027389};\\\", \\\"{x:471,y:470,t:1526930027693};\\\", \\\"{x:479,y:470,t:1526930027702};\\\", \\\"{x:493,y:469,t:1526930027718};\\\", \\\"{x:511,y:467,t:1526930027735};\\\", \\\"{x:531,y:465,t:1526930027752};\\\", \\\"{x:543,y:463,t:1526930027769};\\\", \\\"{x:552,y:459,t:1526930027785};\\\", \\\"{x:555,y:459,t:1526930027802};\\\", \\\"{x:556,y:458,t:1526930027818};\\\", \\\"{x:558,y:457,t:1526930027837};\\\", \\\"{x:559,y:456,t:1526930027853};\\\", \\\"{x:560,y:456,t:1526930027868};\\\", \\\"{x:561,y:455,t:1526930027917};\\\", \\\"{x:565,y:455,t:1526930028229};\\\", \\\"{x:581,y:458,t:1526930028236};\\\", \\\"{x:599,y:466,t:1526930028251};\\\", \\\"{x:724,y:502,t:1526930028269};\\\", \\\"{x:835,y:539,t:1526930028286};\\\", \\\"{x:963,y:582,t:1526930028302};\\\", \\\"{x:1085,y:620,t:1526930028318};\\\", \\\"{x:1191,y:652,t:1526930028334};\\\", \\\"{x:1278,y:681,t:1526930028351};\\\", \\\"{x:1334,y:700,t:1526930028369};\\\", \\\"{x:1365,y:711,t:1526930028385};\\\", \\\"{x:1381,y:717,t:1526930028402};\\\", \\\"{x:1383,y:719,t:1526930028418};\\\", \\\"{x:1382,y:720,t:1526930028542};\\\", \\\"{x:1381,y:720,t:1526930028552};\\\", \\\"{x:1372,y:725,t:1526930028569};\\\", \\\"{x:1363,y:734,t:1526930028586};\\\", \\\"{x:1350,y:748,t:1526930028602};\\\", \\\"{x:1337,y:764,t:1526930028620};\\\", \\\"{x:1321,y:793,t:1526930028636};\\\", \\\"{x:1318,y:800,t:1526930028652};\\\", \\\"{x:1308,y:826,t:1526930028669};\\\", \\\"{x:1303,y:839,t:1526930028685};\\\", \\\"{x:1302,y:845,t:1526930028701};\\\", \\\"{x:1302,y:846,t:1526930028719};\\\", \\\"{x:1301,y:847,t:1526930029045};\\\", \\\"{x:1299,y:847,t:1526930029093};\\\", \\\"{x:1298,y:846,t:1526930029103};\\\", \\\"{x:1296,y:844,t:1526930029118};\\\", \\\"{x:1290,y:842,t:1526930029136};\\\", \\\"{x:1285,y:840,t:1526930029153};\\\", \\\"{x:1278,y:839,t:1526930029169};\\\", \\\"{x:1272,y:837,t:1526930029187};\\\", \\\"{x:1269,y:836,t:1526930029203};\\\", \\\"{x:1266,y:835,t:1526930029219};\\\", \\\"{x:1263,y:835,t:1526930029236};\\\", \\\"{x:1262,y:835,t:1526930029293};\\\", \\\"{x:1260,y:834,t:1526930029517};\\\", \\\"{x:1258,y:832,t:1526930030493};\\\", \\\"{x:1251,y:830,t:1526930030504};\\\", \\\"{x:1240,y:826,t:1526930030521};\\\", \\\"{x:1226,y:822,t:1526930030537};\\\", \\\"{x:1210,y:819,t:1526930030554};\\\", \\\"{x:1201,y:817,t:1526930030571};\\\", \\\"{x:1189,y:816,t:1526930030587};\\\", \\\"{x:1180,y:813,t:1526930030604};\\\", \\\"{x:1173,y:813,t:1526930030620};\\\", \\\"{x:1171,y:813,t:1526930030637};\\\", \\\"{x:1168,y:812,t:1526930030654};\\\", \\\"{x:1167,y:812,t:1526930030671};\\\", \\\"{x:1165,y:811,t:1526930030687};\\\", \\\"{x:1164,y:811,t:1526930030704};\\\", \\\"{x:1163,y:809,t:1526930030721};\\\", \\\"{x:1163,y:808,t:1526930030765};\\\", \\\"{x:1163,y:806,t:1526930030773};\\\", \\\"{x:1163,y:803,t:1526930030787};\\\", \\\"{x:1164,y:799,t:1526930030805};\\\", \\\"{x:1168,y:795,t:1526930030821};\\\", \\\"{x:1170,y:792,t:1526930030837};\\\", \\\"{x:1173,y:788,t:1526930030854};\\\", \\\"{x:1175,y:786,t:1526930030871};\\\", \\\"{x:1175,y:783,t:1526930030888};\\\", \\\"{x:1177,y:781,t:1526930030904};\\\", \\\"{x:1179,y:778,t:1526930030922};\\\", \\\"{x:1179,y:775,t:1526930030937};\\\", \\\"{x:1181,y:770,t:1526930030954};\\\", \\\"{x:1181,y:768,t:1526930030974};\\\", \\\"{x:1182,y:767,t:1526930030987};\\\", \\\"{x:1182,y:765,t:1526930031003};\\\", \\\"{x:1181,y:764,t:1526930031140};\\\", \\\"{x:1180,y:764,t:1526930031173};\\\", \\\"{x:1183,y:764,t:1526930031781};\\\", \\\"{x:1187,y:764,t:1526930031790};\\\", \\\"{x:1192,y:764,t:1526930031805};\\\", \\\"{x:1196,y:766,t:1526930031822};\\\", \\\"{x:1202,y:766,t:1526930031838};\\\", \\\"{x:1209,y:767,t:1526930031855};\\\", \\\"{x:1214,y:768,t:1526930031872};\\\", \\\"{x:1219,y:768,t:1526930031888};\\\", \\\"{x:1222,y:768,t:1526930031906};\\\", \\\"{x:1225,y:769,t:1526930031922};\\\", \\\"{x:1226,y:769,t:1526930031938};\\\", \\\"{x:1227,y:769,t:1526930031956};\\\", \\\"{x:1229,y:769,t:1526930031972};\\\", \\\"{x:1238,y:769,t:1526930031989};\\\", \\\"{x:1245,y:769,t:1526930032005};\\\", \\\"{x:1252,y:769,t:1526930032022};\\\", \\\"{x:1255,y:769,t:1526930032039};\\\", \\\"{x:1257,y:768,t:1526930032055};\\\", \\\"{x:1259,y:768,t:1526930032072};\\\", \\\"{x:1261,y:767,t:1526930032088};\\\", \\\"{x:1262,y:767,t:1526930032109};\\\", \\\"{x:1261,y:767,t:1526930032901};\\\", \\\"{x:1259,y:767,t:1526930032909};\\\", \\\"{x:1257,y:767,t:1526930032923};\\\", \\\"{x:1251,y:767,t:1526930032939};\\\", \\\"{x:1245,y:767,t:1526930032956};\\\", \\\"{x:1241,y:767,t:1526930032973};\\\", \\\"{x:1239,y:767,t:1526930032996};\\\", \\\"{x:1238,y:767,t:1526930033036};\\\", \\\"{x:1237,y:768,t:1526930033068};\\\", \\\"{x:1236,y:770,t:1526930033076};\\\", \\\"{x:1235,y:772,t:1526930033088};\\\", \\\"{x:1233,y:785,t:1526930033106};\\\", \\\"{x:1233,y:810,t:1526930033122};\\\", \\\"{x:1233,y:840,t:1526930033139};\\\", \\\"{x:1236,y:888,t:1526930033157};\\\", \\\"{x:1238,y:909,t:1526930033172};\\\", \\\"{x:1241,y:924,t:1526930033189};\\\", \\\"{x:1243,y:932,t:1526930033206};\\\", \\\"{x:1243,y:936,t:1526930033222};\\\", \\\"{x:1245,y:937,t:1526930033239};\\\", \\\"{x:1246,y:937,t:1526930033389};\\\", \\\"{x:1249,y:936,t:1526930033406};\\\", \\\"{x:1253,y:933,t:1526930033424};\\\", \\\"{x:1258,y:930,t:1526930033439};\\\", \\\"{x:1263,y:926,t:1526930033456};\\\", \\\"{x:1270,y:918,t:1526930033473};\\\", \\\"{x:1278,y:906,t:1526930033490};\\\", \\\"{x:1286,y:894,t:1526930033506};\\\", \\\"{x:1296,y:879,t:1526930033523};\\\", \\\"{x:1307,y:862,t:1526930033540};\\\", \\\"{x:1327,y:837,t:1526930033557};\\\", \\\"{x:1335,y:825,t:1526930033572};\\\", \\\"{x:1343,y:813,t:1526930033589};\\\", \\\"{x:1349,y:805,t:1526930033606};\\\", \\\"{x:1358,y:793,t:1526930033624};\\\", \\\"{x:1362,y:787,t:1526930033640};\\\", \\\"{x:1366,y:780,t:1526930033657};\\\", \\\"{x:1368,y:777,t:1526930033674};\\\", \\\"{x:1370,y:774,t:1526930033690};\\\", \\\"{x:1370,y:771,t:1526930033707};\\\", \\\"{x:1371,y:771,t:1526930033724};\\\", \\\"{x:1371,y:769,t:1526930033892};\\\", \\\"{x:1371,y:768,t:1526930033908};\\\", \\\"{x:1371,y:764,t:1526930033922};\\\", \\\"{x:1364,y:758,t:1526930033939};\\\", \\\"{x:1349,y:748,t:1526930033956};\\\", \\\"{x:1344,y:743,t:1526930033973};\\\", \\\"{x:1342,y:741,t:1526930033990};\\\", \\\"{x:1341,y:741,t:1526930034012};\\\", \\\"{x:1341,y:740,t:1526930034023};\\\", \\\"{x:1341,y:738,t:1526930034040};\\\", \\\"{x:1341,y:734,t:1526930034056};\\\", \\\"{x:1340,y:732,t:1526930034073};\\\", \\\"{x:1340,y:728,t:1526930034090};\\\", \\\"{x:1340,y:725,t:1526930034106};\\\", \\\"{x:1340,y:723,t:1526930034123};\\\", \\\"{x:1340,y:721,t:1526930034140};\\\", \\\"{x:1340,y:720,t:1526930034156};\\\", \\\"{x:1340,y:719,t:1526930034173};\\\", \\\"{x:1340,y:717,t:1526930034190};\\\", \\\"{x:1340,y:716,t:1526930034207};\\\", \\\"{x:1340,y:715,t:1526930034229};\\\", \\\"{x:1340,y:714,t:1526930034260};\\\", \\\"{x:1340,y:713,t:1526930034277};\\\", \\\"{x:1340,y:712,t:1526930034317};\\\", \\\"{x:1340,y:711,t:1526930034332};\\\", \\\"{x:1341,y:710,t:1526930034357};\\\", \\\"{x:1341,y:709,t:1526930034421};\\\", \\\"{x:1341,y:708,t:1526930034437};\\\", \\\"{x:1341,y:706,t:1526930034798};\\\", \\\"{x:1341,y:704,t:1526930034808};\\\", \\\"{x:1342,y:703,t:1526930034824};\\\", \\\"{x:1342,y:701,t:1526930034840};\\\", \\\"{x:1342,y:700,t:1526930034857};\\\", \\\"{x:1342,y:699,t:1526930034917};\\\", \\\"{x:1343,y:698,t:1526930034949};\\\", \\\"{x:1343,y:699,t:1526930037656};\\\", \\\"{x:1343,y:700,t:1526930037664};\\\", \\\"{x:1343,y:704,t:1526930037681};\\\", \\\"{x:1343,y:710,t:1526930037696};\\\", \\\"{x:1341,y:713,t:1526930037713};\\\", \\\"{x:1341,y:715,t:1526930037730};\\\", \\\"{x:1341,y:718,t:1526930037747};\\\", \\\"{x:1340,y:721,t:1526930040841};\\\", \\\"{x:1339,y:723,t:1526930040849};\\\", \\\"{x:1335,y:725,t:1526930040866};\\\", \\\"{x:1334,y:725,t:1526930040883};\\\", \\\"{x:1331,y:726,t:1526930040899};\\\", \\\"{x:1329,y:728,t:1526930040916};\\\", \\\"{x:1327,y:728,t:1526930040933};\\\", \\\"{x:1326,y:728,t:1526930040960};\\\", \\\"{x:1324,y:728,t:1526930040968};\\\", \\\"{x:1321,y:728,t:1526930040982};\\\", \\\"{x:1309,y:727,t:1526930040999};\\\", \\\"{x:1268,y:716,t:1526930041017};\\\", \\\"{x:1231,y:707,t:1526930041033};\\\", \\\"{x:1187,y:695,t:1526930041050};\\\", \\\"{x:1151,y:686,t:1526930041066};\\\", \\\"{x:1114,y:675,t:1526930041082};\\\", \\\"{x:1078,y:666,t:1526930041099};\\\", \\\"{x:1031,y:652,t:1526930041116};\\\", \\\"{x:986,y:639,t:1526930041132};\\\", \\\"{x:940,y:624,t:1526930041150};\\\", \\\"{x:882,y:607,t:1526930041166};\\\", \\\"{x:828,y:591,t:1526930041182};\\\", \\\"{x:780,y:575,t:1526930041198};\\\", \\\"{x:696,y:556,t:1526930041215};\\\", \\\"{x:646,y:543,t:1526930041233};\\\", \\\"{x:619,y:538,t:1526930041249};\\\", \\\"{x:599,y:536,t:1526930041265};\\\", \\\"{x:572,y:532,t:1526930041283};\\\", \\\"{x:550,y:529,t:1526930041298};\\\", \\\"{x:527,y:524,t:1526930041316};\\\", \\\"{x:498,y:516,t:1526930041333};\\\", \\\"{x:467,y:512,t:1526930041350};\\\", \\\"{x:439,y:507,t:1526930041366};\\\", \\\"{x:412,y:504,t:1526930041383};\\\", \\\"{x:380,y:502,t:1526930041400};\\\", \\\"{x:369,y:500,t:1526930041416};\\\", \\\"{x:365,y:499,t:1526930041432};\\\", \\\"{x:366,y:501,t:1526930041528};\\\", \\\"{x:370,y:502,t:1526930041536};\\\", \\\"{x:380,y:505,t:1526930041551};\\\", \\\"{x:402,y:509,t:1526930041565};\\\", \\\"{x:433,y:513,t:1526930041583};\\\", \\\"{x:491,y:521,t:1526930041599};\\\", \\\"{x:534,y:522,t:1526930041615};\\\", \\\"{x:561,y:523,t:1526930041632};\\\", \\\"{x:575,y:523,t:1526930041650};\\\", \\\"{x:583,y:523,t:1526930041665};\\\", \\\"{x:584,y:523,t:1526930041683};\\\", \\\"{x:585,y:523,t:1526930041719};\\\", \\\"{x:588,y:522,t:1526930041733};\\\", \\\"{x:589,y:521,t:1526930041750};\\\", \\\"{x:594,y:520,t:1526930041766};\\\", \\\"{x:600,y:517,t:1526930041784};\\\", \\\"{x:617,y:514,t:1526930041799};\\\", \\\"{x:632,y:512,t:1526930041817};\\\", \\\"{x:654,y:511,t:1526930041833};\\\", \\\"{x:672,y:507,t:1526930041849};\\\", \\\"{x:692,y:506,t:1526930041866};\\\", \\\"{x:704,y:505,t:1526930041882};\\\", \\\"{x:717,y:503,t:1526930041900};\\\", \\\"{x:724,y:503,t:1526930041917};\\\", \\\"{x:729,y:503,t:1526930041933};\\\", \\\"{x:736,y:503,t:1526930041949};\\\", \\\"{x:744,y:503,t:1526930041967};\\\", \\\"{x:758,y:503,t:1526930041983};\\\", \\\"{x:781,y:503,t:1526930041999};\\\", \\\"{x:790,y:503,t:1526930042017};\\\", \\\"{x:796,y:503,t:1526930042033};\\\", \\\"{x:798,y:503,t:1526930042050};\\\", \\\"{x:800,y:502,t:1526930042192};\\\", \\\"{x:801,y:502,t:1526930042216};\\\", \\\"{x:804,y:501,t:1526930042234};\\\", \\\"{x:806,y:500,t:1526930042250};\\\", \\\"{x:811,y:499,t:1526930042267};\\\", \\\"{x:820,y:499,t:1526930042284};\\\", \\\"{x:828,y:498,t:1526930042301};\\\", \\\"{x:834,y:498,t:1526930042317};\\\", \\\"{x:835,y:498,t:1526930042334};\\\", \\\"{x:835,y:499,t:1526930042824};\\\", \\\"{x:829,y:500,t:1526930042833};\\\", \\\"{x:809,y:512,t:1526930042851};\\\", \\\"{x:782,y:527,t:1526930042867};\\\", \\\"{x:718,y:546,t:1526930042885};\\\", \\\"{x:643,y:559,t:1526930042901};\\\", \\\"{x:567,y:571,t:1526930042917};\\\", \\\"{x:506,y:580,t:1526930042934};\\\", \\\"{x:454,y:589,t:1526930042951};\\\", \\\"{x:422,y:596,t:1526930042968};\\\", \\\"{x:402,y:607,t:1526930042985};\\\", \\\"{x:394,y:611,t:1526930043001};\\\", \\\"{x:386,y:617,t:1526930043017};\\\", \\\"{x:379,y:623,t:1526930043034};\\\", \\\"{x:366,y:629,t:1526930043051};\\\", \\\"{x:344,y:637,t:1526930043067};\\\", \\\"{x:327,y:644,t:1526930043084};\\\", \\\"{x:307,y:650,t:1526930043101};\\\", \\\"{x:292,y:653,t:1526930043118};\\\", \\\"{x:279,y:655,t:1526930043133};\\\", \\\"{x:272,y:656,t:1526930043152};\\\", \\\"{x:265,y:656,t:1526930043167};\\\", \\\"{x:260,y:656,t:1526930043184};\\\", \\\"{x:253,y:656,t:1526930043201};\\\", \\\"{x:245,y:656,t:1526930043217};\\\", \\\"{x:241,y:655,t:1526930043234};\\\", \\\"{x:234,y:652,t:1526930043251};\\\", \\\"{x:232,y:651,t:1526930043267};\\\", \\\"{x:230,y:649,t:1526930043284};\\\", \\\"{x:230,y:648,t:1526930043300};\\\", \\\"{x:230,y:645,t:1526930043318};\\\", \\\"{x:230,y:641,t:1526930043334};\\\", \\\"{x:230,y:635,t:1526930043352};\\\", \\\"{x:229,y:631,t:1526930043368};\\\", \\\"{x:226,y:623,t:1526930043384};\\\", \\\"{x:218,y:613,t:1526930043401};\\\", \\\"{x:196,y:594,t:1526930043418};\\\", \\\"{x:171,y:579,t:1526930043435};\\\", \\\"{x:145,y:570,t:1526930043451};\\\", \\\"{x:122,y:560,t:1526930043467};\\\", \\\"{x:114,y:558,t:1526930043485};\\\", \\\"{x:112,y:555,t:1526930043501};\\\", \\\"{x:112,y:554,t:1526930043519};\\\", \\\"{x:112,y:553,t:1526930043535};\\\", \\\"{x:112,y:552,t:1526930043551};\\\", \\\"{x:114,y:550,t:1526930043568};\\\", \\\"{x:117,y:548,t:1526930043585};\\\", \\\"{x:123,y:546,t:1526930043600};\\\", \\\"{x:134,y:543,t:1526930043617};\\\", \\\"{x:144,y:543,t:1526930043635};\\\", \\\"{x:151,y:543,t:1526930043651};\\\", \\\"{x:155,y:543,t:1526930043668};\\\", \\\"{x:157,y:543,t:1526930043684};\\\", \\\"{x:158,y:542,t:1526930043701};\\\", \\\"{x:160,y:542,t:1526930044313};\\\", \\\"{x:168,y:547,t:1526930044320};\\\", \\\"{x:178,y:553,t:1526930044336};\\\", \\\"{x:210,y:575,t:1526930044353};\\\", \\\"{x:251,y:599,t:1526930044369};\\\", \\\"{x:332,y:640,t:1526930044385};\\\", \\\"{x:434,y:685,t:1526930044402};\\\", \\\"{x:572,y:728,t:1526930044418};\\\", \\\"{x:741,y:773,t:1526930044434};\\\", \\\"{x:929,y:803,t:1526930044451};\\\", \\\"{x:1131,y:837,t:1526930044469};\\\", \\\"{x:1330,y:860,t:1526930044485};\\\", \\\"{x:1490,y:880,t:1526930044502};\\\", \\\"{x:1618,y:888,t:1526930044519};\\\", \\\"{x:1694,y:890,t:1526930044535};\\\", \\\"{x:1716,y:888,t:1526930044551};\\\", \\\"{x:1716,y:886,t:1526930045239};\\\", \\\"{x:1711,y:882,t:1526930045252};\\\", \\\"{x:1704,y:877,t:1526930045269};\\\", \\\"{x:1692,y:869,t:1526930045286};\\\", \\\"{x:1682,y:862,t:1526930045302};\\\", \\\"{x:1678,y:858,t:1526930045319};\\\", \\\"{x:1674,y:847,t:1526930045336};\\\", \\\"{x:1671,y:837,t:1526930045354};\\\", \\\"{x:1671,y:822,t:1526930045369};\\\", \\\"{x:1669,y:801,t:1526930045386};\\\", \\\"{x:1669,y:778,t:1526930045403};\\\", \\\"{x:1666,y:757,t:1526930045419};\\\", \\\"{x:1658,y:738,t:1526930045436};\\\", \\\"{x:1649,y:719,t:1526930045453};\\\", \\\"{x:1639,y:703,t:1526930045469};\\\", \\\"{x:1632,y:689,t:1526930045486};\\\", \\\"{x:1622,y:678,t:1526930045503};\\\", \\\"{x:1612,y:668,t:1526930045519};\\\", \\\"{x:1589,y:653,t:1526930045536};\\\", \\\"{x:1580,y:647,t:1526930045553};\\\", \\\"{x:1573,y:644,t:1526930045570};\\\", \\\"{x:1569,y:641,t:1526930045586};\\\", \\\"{x:1567,y:640,t:1526930045603};\\\", \\\"{x:1565,y:640,t:1526930045688};\\\", \\\"{x:1562,y:641,t:1526930046423};\\\", \\\"{x:1560,y:642,t:1526930046437};\\\", \\\"{x:1552,y:646,t:1526930046453};\\\", \\\"{x:1541,y:652,t:1526930046470};\\\", \\\"{x:1531,y:658,t:1526930046487};\\\", \\\"{x:1527,y:661,t:1526930046503};\\\", \\\"{x:1522,y:669,t:1526930046520};\\\", \\\"{x:1520,y:673,t:1526930046537};\\\", \\\"{x:1519,y:677,t:1526930046553};\\\", \\\"{x:1519,y:680,t:1526930046570};\\\", \\\"{x:1519,y:684,t:1526930046587};\\\", \\\"{x:1518,y:687,t:1526930046603};\\\", \\\"{x:1517,y:687,t:1526930046620};\\\", \\\"{x:1517,y:689,t:1526930046637};\\\", \\\"{x:1516,y:690,t:1526930047185};\\\", \\\"{x:1514,y:694,t:1526930047192};\\\", \\\"{x:1511,y:695,t:1526930047204};\\\", \\\"{x:1495,y:707,t:1526930047221};\\\", \\\"{x:1478,y:722,t:1526930047237};\\\", \\\"{x:1455,y:733,t:1526930047254};\\\", \\\"{x:1432,y:742,t:1526930047270};\\\", \\\"{x:1403,y:754,t:1526930047287};\\\", \\\"{x:1369,y:769,t:1526930047304};\\\", \\\"{x:1353,y:777,t:1526930047321};\\\", \\\"{x:1337,y:784,t:1526930047337};\\\", \\\"{x:1317,y:793,t:1526930047354};\\\", \\\"{x:1301,y:800,t:1526930047371};\\\", \\\"{x:1284,y:809,t:1526930047387};\\\", \\\"{x:1268,y:816,t:1526930047404};\\\", \\\"{x:1256,y:821,t:1526930047421};\\\", \\\"{x:1244,y:827,t:1526930047437};\\\", \\\"{x:1231,y:836,t:1526930047454};\\\", \\\"{x:1221,y:842,t:1526930047471};\\\", \\\"{x:1208,y:848,t:1526930047488};\\\", \\\"{x:1203,y:853,t:1526930047504};\\\", \\\"{x:1200,y:855,t:1526930047522};\\\", \\\"{x:1197,y:856,t:1526930047537};\\\", \\\"{x:1196,y:857,t:1526930047560};\\\", \\\"{x:1194,y:857,t:1526930047576};\\\", \\\"{x:1191,y:857,t:1526930047587};\\\", \\\"{x:1185,y:857,t:1526930047605};\\\", \\\"{x:1174,y:857,t:1526930047622};\\\", \\\"{x:1157,y:854,t:1526930047638};\\\", \\\"{x:1133,y:847,t:1526930047654};\\\", \\\"{x:1093,y:833,t:1526930047672};\\\", \\\"{x:1051,y:822,t:1526930047688};\\\", \\\"{x:980,y:804,t:1526930047704};\\\", \\\"{x:935,y:792,t:1526930047721};\\\", \\\"{x:910,y:784,t:1526930047738};\\\", \\\"{x:892,y:778,t:1526930047754};\\\", \\\"{x:877,y:772,t:1526930047771};\\\", \\\"{x:864,y:766,t:1526930047788};\\\", \\\"{x:852,y:761,t:1526930047805};\\\", \\\"{x:841,y:756,t:1526930047821};\\\", \\\"{x:824,y:746,t:1526930047840};\\\", \\\"{x:821,y:744,t:1526930047854};\\\", \\\"{x:815,y:741,t:1526930047871};\\\", \\\"{x:803,y:737,t:1526930047888};\\\", \\\"{x:795,y:735,t:1526930047904};\\\", \\\"{x:787,y:733,t:1526930047921};\\\", \\\"{x:773,y:728,t:1526930047939};\\\", \\\"{x:759,y:725,t:1526930047955};\\\", \\\"{x:736,y:720,t:1526930047971};\\\", \\\"{x:716,y:717,t:1526930047988};\\\", \\\"{x:685,y:712,t:1526930048005};\\\", \\\"{x:656,y:709,t:1526930048022};\\\", \\\"{x:631,y:709,t:1526930048038};\\\", \\\"{x:608,y:709,t:1526930048054};\\\", \\\"{x:587,y:709,t:1526930048071};\\\", \\\"{x:561,y:709,t:1526930048088};\\\", \\\"{x:550,y:709,t:1526930048104};\\\", \\\"{x:544,y:709,t:1526930048122};\\\", \\\"{x:540,y:710,t:1526930048138};\\\", \\\"{x:539,y:711,t:1526930048160};\\\", \\\"{x:537,y:711,t:1526930048192};\\\", \\\"{x:536,y:714,t:1526930048204};\\\", \\\"{x:532,y:720,t:1526930048223};\\\", \\\"{x:530,y:727,t:1526930048238};\\\", \\\"{x:527,y:730,t:1526930048255};\\\", \\\"{x:525,y:733,t:1526930048272};\\\", \\\"{x:525,y:734,t:1526930048288};\\\", \\\"{x:525,y:737,t:1526930048305};\\\", \\\"{x:524,y:739,t:1526930048322};\\\", \\\"{x:524,y:741,t:1526930048339};\\\", \\\"{x:524,y:743,t:1526930048355};\\\", \\\"{x:523,y:744,t:1526930048372};\\\" ] }, { \\\"rt\\\": 51774, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 424758, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -B -B -B -X -E -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:738,t:1526930051016};\\\", \\\"{x:513,y:712,t:1526930051026};\\\", \\\"{x:494,y:643,t:1526930051040};\\\", \\\"{x:483,y:565,t:1526930051058};\\\", \\\"{x:483,y:509,t:1526930051074};\\\", \\\"{x:483,y:475,t:1526930051090};\\\", \\\"{x:486,y:455,t:1526930051107};\\\", \\\"{x:492,y:440,t:1526930051124};\\\", \\\"{x:500,y:428,t:1526930051141};\\\", \\\"{x:506,y:417,t:1526930051157};\\\", \\\"{x:513,y:407,t:1526930051174};\\\", \\\"{x:518,y:398,t:1526930051191};\\\", \\\"{x:518,y:396,t:1526930051207};\\\", \\\"{x:518,y:394,t:1526930051224};\\\", \\\"{x:519,y:394,t:1526930051312};\\\", \\\"{x:519,y:397,t:1526930051324};\\\", \\\"{x:519,y:410,t:1526930051341};\\\", \\\"{x:520,y:426,t:1526930051359};\\\", \\\"{x:521,y:446,t:1526930051374};\\\", \\\"{x:522,y:464,t:1526930051392};\\\", \\\"{x:522,y:471,t:1526930051408};\\\", \\\"{x:522,y:475,t:1526930051424};\\\", \\\"{x:522,y:478,t:1526930051441};\\\", \\\"{x:522,y:479,t:1526930051458};\\\", \\\"{x:523,y:479,t:1526930051937};\\\", \\\"{x:530,y:479,t:1526930051944};\\\", \\\"{x:558,y:479,t:1526930051960};\\\", \\\"{x:602,y:479,t:1526930051976};\\\", \\\"{x:665,y:486,t:1526930051993};\\\", \\\"{x:754,y:498,t:1526930052011};\\\", \\\"{x:843,y:513,t:1526930052027};\\\", \\\"{x:927,y:526,t:1526930052042};\\\", \\\"{x:1007,y:535,t:1526930052059};\\\", \\\"{x:1085,y:535,t:1526930052074};\\\", \\\"{x:1099,y:535,t:1526930052091};\\\", \\\"{x:1097,y:535,t:1526930052681};\\\", \\\"{x:1096,y:534,t:1526930052692};\\\", \\\"{x:1090,y:534,t:1526930052708};\\\", \\\"{x:1084,y:534,t:1526930052725};\\\", \\\"{x:1082,y:533,t:1526930052743};\\\", \\\"{x:1079,y:532,t:1526930052759};\\\", \\\"{x:1076,y:532,t:1526930052776};\\\", \\\"{x:1075,y:532,t:1526930052792};\\\", \\\"{x:1072,y:532,t:1526930052809};\\\", \\\"{x:1068,y:532,t:1526930052825};\\\", \\\"{x:1065,y:532,t:1526930052843};\\\", \\\"{x:1060,y:532,t:1526930052859};\\\", \\\"{x:1051,y:530,t:1526930052876};\\\", \\\"{x:1044,y:529,t:1526930052892};\\\", \\\"{x:1036,y:529,t:1526930052910};\\\", \\\"{x:1021,y:527,t:1526930052926};\\\", \\\"{x:1002,y:524,t:1526930052943};\\\", \\\"{x:978,y:519,t:1526930052959};\\\", \\\"{x:932,y:513,t:1526930052977};\\\", \\\"{x:889,y:506,t:1526930052992};\\\", \\\"{x:848,y:502,t:1526930053009};\\\", \\\"{x:800,y:494,t:1526930053024};\\\", \\\"{x:763,y:489,t:1526930053042};\\\", \\\"{x:721,y:483,t:1526930053060};\\\", \\\"{x:692,y:478,t:1526930053075};\\\", \\\"{x:665,y:475,t:1526930053092};\\\", \\\"{x:641,y:470,t:1526930053109};\\\", \\\"{x:622,y:469,t:1526930053125};\\\", \\\"{x:608,y:466,t:1526930053143};\\\", \\\"{x:592,y:465,t:1526930053159};\\\", \\\"{x:585,y:465,t:1526930053175};\\\", \\\"{x:581,y:465,t:1526930053192};\\\", \\\"{x:577,y:465,t:1526930053208};\\\", \\\"{x:576,y:465,t:1526930053225};\\\", \\\"{x:577,y:467,t:1526930053329};\\\", \\\"{x:582,y:470,t:1526930053343};\\\", \\\"{x:600,y:477,t:1526930053359};\\\", \\\"{x:664,y:496,t:1526930053377};\\\", \\\"{x:727,y:511,t:1526930053393};\\\", \\\"{x:812,y:532,t:1526930053410};\\\", \\\"{x:916,y:554,t:1526930053427};\\\", \\\"{x:1018,y:578,t:1526930053443};\\\", \\\"{x:1123,y:604,t:1526930053459};\\\", \\\"{x:1233,y:633,t:1526930053476};\\\", \\\"{x:1328,y:652,t:1526930053492};\\\", \\\"{x:1404,y:674,t:1526930053509};\\\", \\\"{x:1459,y:689,t:1526930053526};\\\", \\\"{x:1501,y:696,t:1526930053543};\\\", \\\"{x:1510,y:700,t:1526930053560};\\\", \\\"{x:1508,y:700,t:1526930053672};\\\", \\\"{x:1502,y:699,t:1526930053680};\\\", \\\"{x:1495,y:694,t:1526930053694};\\\", \\\"{x:1472,y:689,t:1526930053711};\\\", \\\"{x:1436,y:679,t:1526930053727};\\\", \\\"{x:1369,y:660,t:1526930053744};\\\", \\\"{x:1328,y:650,t:1526930053760};\\\", \\\"{x:1274,y:639,t:1526930053776};\\\", \\\"{x:1224,y:633,t:1526930053794};\\\", \\\"{x:1192,y:628,t:1526930053811};\\\", \\\"{x:1164,y:623,t:1526930053829};\\\", \\\"{x:1139,y:620,t:1526930053843};\\\", \\\"{x:1121,y:617,t:1526930053861};\\\", \\\"{x:1102,y:612,t:1526930053877};\\\", \\\"{x:1089,y:608,t:1526930053894};\\\", \\\"{x:1086,y:607,t:1526930053911};\\\", \\\"{x:1082,y:603,t:1526930053928};\\\", \\\"{x:1082,y:598,t:1526930053943};\\\", \\\"{x:1081,y:591,t:1526930053961};\\\", \\\"{x:1079,y:582,t:1526930053977};\\\", \\\"{x:1079,y:574,t:1526930053994};\\\", \\\"{x:1079,y:564,t:1526930054011};\\\", \\\"{x:1081,y:552,t:1526930054027};\\\", \\\"{x:1086,y:542,t:1526930054045};\\\", \\\"{x:1091,y:533,t:1526930054062};\\\", \\\"{x:1094,y:530,t:1526930054078};\\\", \\\"{x:1096,y:524,t:1526930054094};\\\", \\\"{x:1098,y:518,t:1526930054112};\\\", \\\"{x:1101,y:514,t:1526930054128};\\\", \\\"{x:1104,y:510,t:1526930054145};\\\", \\\"{x:1105,y:508,t:1526930054161};\\\", \\\"{x:1106,y:507,t:1526930054179};\\\", \\\"{x:1109,y:505,t:1526930054194};\\\", \\\"{x:1114,y:502,t:1526930054211};\\\", \\\"{x:1121,y:498,t:1526930054229};\\\", \\\"{x:1127,y:496,t:1526930054245};\\\", \\\"{x:1134,y:492,t:1526930054262};\\\", \\\"{x:1139,y:492,t:1526930054279};\\\", \\\"{x:1142,y:491,t:1526930054295};\\\", \\\"{x:1146,y:490,t:1526930054312};\\\", \\\"{x:1147,y:490,t:1526930054329};\\\", \\\"{x:1149,y:490,t:1526930054346};\\\", \\\"{x:1154,y:492,t:1526930054362};\\\", \\\"{x:1161,y:499,t:1526930054379};\\\", \\\"{x:1170,y:506,t:1526930054396};\\\", \\\"{x:1177,y:512,t:1526930054411};\\\", \\\"{x:1182,y:516,t:1526930054430};\\\", \\\"{x:1187,y:519,t:1526930054446};\\\", \\\"{x:1191,y:522,t:1526930054462};\\\", \\\"{x:1196,y:524,t:1526930054479};\\\", \\\"{x:1201,y:526,t:1526930054496};\\\", \\\"{x:1207,y:527,t:1526930054512};\\\", \\\"{x:1219,y:531,t:1526930054529};\\\", \\\"{x:1228,y:534,t:1526930054546};\\\", \\\"{x:1236,y:537,t:1526930054563};\\\", \\\"{x:1239,y:538,t:1526930054580};\\\", \\\"{x:1242,y:539,t:1526930054596};\\\", \\\"{x:1243,y:540,t:1526930054640};\\\", \\\"{x:1246,y:540,t:1526930054648};\\\", \\\"{x:1248,y:543,t:1526930054663};\\\", \\\"{x:1251,y:546,t:1526930054680};\\\", \\\"{x:1252,y:547,t:1526930054696};\\\", \\\"{x:1253,y:548,t:1526930054713};\\\", \\\"{x:1253,y:549,t:1526930054729};\\\", \\\"{x:1254,y:549,t:1526930056793};\\\", \\\"{x:1256,y:549,t:1526930056802};\\\", \\\"{x:1261,y:546,t:1526930056819};\\\", \\\"{x:1268,y:544,t:1526930056836};\\\", \\\"{x:1276,y:542,t:1526930056852};\\\", \\\"{x:1282,y:542,t:1526930056869};\\\", \\\"{x:1285,y:543,t:1526930056885};\\\", \\\"{x:1286,y:545,t:1526930056991};\\\", \\\"{x:1286,y:547,t:1526930057008};\\\", \\\"{x:1286,y:549,t:1526930057019};\\\", \\\"{x:1288,y:552,t:1526930057036};\\\", \\\"{x:1288,y:554,t:1526930057052};\\\", \\\"{x:1288,y:555,t:1526930057070};\\\", \\\"{x:1288,y:556,t:1526930057086};\\\", \\\"{x:1288,y:557,t:1526930057104};\\\", \\\"{x:1288,y:558,t:1526930057232};\\\", \\\"{x:1287,y:559,t:1526930057280};\\\", \\\"{x:1286,y:560,t:1526930057307};\\\", \\\"{x:1285,y:560,t:1526930057359};\\\", \\\"{x:1283,y:560,t:1526930057370};\\\", \\\"{x:1282,y:561,t:1526930057387};\\\", \\\"{x:1280,y:562,t:1526930057404};\\\", \\\"{x:1279,y:562,t:1526930060137};\\\", \\\"{x:1279,y:566,t:1526930060145};\\\", \\\"{x:1277,y:593,t:1526930060163};\\\", \\\"{x:1277,y:646,t:1526930060178};\\\", \\\"{x:1277,y:688,t:1526930060195};\\\", \\\"{x:1277,y:715,t:1526930060213};\\\", \\\"{x:1277,y:739,t:1526930060228};\\\", \\\"{x:1277,y:760,t:1526930060245};\\\", \\\"{x:1280,y:777,t:1526930060262};\\\", \\\"{x:1285,y:791,t:1526930060279};\\\", \\\"{x:1288,y:800,t:1526930060295};\\\", \\\"{x:1289,y:803,t:1526930060311};\\\", \\\"{x:1292,y:799,t:1526930060415};\\\", \\\"{x:1294,y:796,t:1526930060428};\\\", \\\"{x:1302,y:786,t:1526930060446};\\\", \\\"{x:1307,y:778,t:1526930060462};\\\", \\\"{x:1311,y:773,t:1526930060479};\\\", \\\"{x:1314,y:768,t:1526930060496};\\\", \\\"{x:1316,y:767,t:1526930060512};\\\", \\\"{x:1317,y:765,t:1526930060529};\\\", \\\"{x:1318,y:764,t:1526930060546};\\\", \\\"{x:1319,y:764,t:1526930060616};\\\", \\\"{x:1320,y:764,t:1526930060705};\\\", \\\"{x:1321,y:764,t:1526930060720};\\\", \\\"{x:1322,y:763,t:1526930060737};\\\", \\\"{x:1323,y:762,t:1526930060752};\\\", \\\"{x:1324,y:762,t:1526930060763};\\\", \\\"{x:1330,y:760,t:1526930060781};\\\", \\\"{x:1333,y:760,t:1526930060797};\\\", \\\"{x:1337,y:759,t:1526930060813};\\\", \\\"{x:1339,y:758,t:1526930060830};\\\", \\\"{x:1340,y:758,t:1526930060846};\\\", \\\"{x:1341,y:758,t:1526930061008};\\\", \\\"{x:1342,y:759,t:1526930061016};\\\", \\\"{x:1342,y:761,t:1526930061031};\\\", \\\"{x:1344,y:762,t:1526930061048};\\\", \\\"{x:1344,y:764,t:1526930061064};\\\", \\\"{x:1344,y:765,t:1526930061080};\\\", \\\"{x:1345,y:766,t:1526930061137};\\\", \\\"{x:1345,y:765,t:1526930062352};\\\", \\\"{x:1347,y:763,t:1526930062368};\\\", \\\"{x:1349,y:757,t:1526930062385};\\\", \\\"{x:1349,y:755,t:1526930062401};\\\", \\\"{x:1349,y:753,t:1526930062419};\\\", \\\"{x:1351,y:752,t:1526930062457};\\\", \\\"{x:1351,y:753,t:1526930062745};\\\", \\\"{x:1351,y:755,t:1526930062752};\\\", \\\"{x:1351,y:758,t:1526930062769};\\\", \\\"{x:1352,y:760,t:1526930062786};\\\", \\\"{x:1353,y:761,t:1526930062802};\\\", \\\"{x:1353,y:762,t:1526930063233};\\\", \\\"{x:1353,y:764,t:1526930073689};\\\", \\\"{x:1356,y:772,t:1526930073699};\\\", \\\"{x:1374,y:788,t:1526930073716};\\\", \\\"{x:1394,y:803,t:1526930073733};\\\", \\\"{x:1413,y:814,t:1526930073749};\\\", \\\"{x:1428,y:821,t:1526930073766};\\\", \\\"{x:1441,y:829,t:1526930073783};\\\", \\\"{x:1450,y:833,t:1526930073799};\\\", \\\"{x:1455,y:834,t:1526930073816};\\\", \\\"{x:1463,y:838,t:1526930073833};\\\", \\\"{x:1468,y:842,t:1526930073850};\\\", \\\"{x:1477,y:846,t:1526930073866};\\\", \\\"{x:1487,y:851,t:1526930073882};\\\", \\\"{x:1496,y:853,t:1526930073899};\\\", \\\"{x:1501,y:853,t:1526930073916};\\\", \\\"{x:1502,y:853,t:1526930073932};\\\", \\\"{x:1503,y:853,t:1526930074000};\\\", \\\"{x:1503,y:851,t:1526930074016};\\\", \\\"{x:1503,y:849,t:1526930074033};\\\", \\\"{x:1503,y:848,t:1526930074049};\\\", \\\"{x:1503,y:846,t:1526930074066};\\\", \\\"{x:1501,y:842,t:1526930074084};\\\", \\\"{x:1497,y:838,t:1526930074099};\\\", \\\"{x:1493,y:836,t:1526930074116};\\\", \\\"{x:1488,y:833,t:1526930074134};\\\", \\\"{x:1483,y:833,t:1526930074151};\\\", \\\"{x:1480,y:831,t:1526930074167};\\\", \\\"{x:1477,y:831,t:1526930074183};\\\", \\\"{x:1473,y:830,t:1526930076369};\\\", \\\"{x:1468,y:827,t:1526930076376};\\\", \\\"{x:1465,y:826,t:1526930076390};\\\", \\\"{x:1452,y:822,t:1526930076406};\\\", \\\"{x:1435,y:820,t:1526930076423};\\\", \\\"{x:1428,y:818,t:1526930076440};\\\", \\\"{x:1425,y:817,t:1526930076456};\\\", \\\"{x:1417,y:814,t:1526930076474};\\\", \\\"{x:1414,y:814,t:1526930076489};\\\", \\\"{x:1410,y:812,t:1526930076506};\\\", \\\"{x:1401,y:808,t:1526930076524};\\\", \\\"{x:1390,y:803,t:1526930076540};\\\", \\\"{x:1380,y:799,t:1526930076557};\\\", \\\"{x:1373,y:796,t:1526930076574};\\\", \\\"{x:1369,y:794,t:1526930076590};\\\", \\\"{x:1364,y:792,t:1526930076607};\\\", \\\"{x:1360,y:790,t:1526930076624};\\\", \\\"{x:1356,y:787,t:1526930076641};\\\", \\\"{x:1354,y:785,t:1526930076657};\\\", \\\"{x:1353,y:783,t:1526930076674};\\\", \\\"{x:1352,y:783,t:1526930076691};\\\", \\\"{x:1351,y:782,t:1526930076708};\\\", \\\"{x:1350,y:780,t:1526930076724};\\\", \\\"{x:1349,y:780,t:1526930076741};\\\", \\\"{x:1349,y:779,t:1526930076758};\\\", \\\"{x:1348,y:778,t:1526930076783};\\\", \\\"{x:1348,y:777,t:1526930076816};\\\", \\\"{x:1348,y:776,t:1526930077032};\\\", \\\"{x:1348,y:775,t:1526930077042};\\\", \\\"{x:1346,y:770,t:1526930077058};\\\", \\\"{x:1342,y:766,t:1526930077075};\\\", \\\"{x:1336,y:760,t:1526930077092};\\\", \\\"{x:1329,y:755,t:1526930077109};\\\", \\\"{x:1323,y:750,t:1526930077125};\\\", \\\"{x:1318,y:744,t:1526930077142};\\\", \\\"{x:1315,y:738,t:1526930077159};\\\", \\\"{x:1312,y:729,t:1526930077176};\\\", \\\"{x:1310,y:720,t:1526930077192};\\\", \\\"{x:1308,y:708,t:1526930077209};\\\", \\\"{x:1307,y:700,t:1526930077226};\\\", \\\"{x:1306,y:688,t:1526930077242};\\\", \\\"{x:1303,y:679,t:1526930077259};\\\", \\\"{x:1301,y:669,t:1526930077276};\\\", \\\"{x:1299,y:657,t:1526930077293};\\\", \\\"{x:1297,y:646,t:1526930077309};\\\", \\\"{x:1296,y:639,t:1526930077326};\\\", \\\"{x:1294,y:629,t:1526930077343};\\\", \\\"{x:1293,y:621,t:1526930077359};\\\", \\\"{x:1290,y:605,t:1526930077375};\\\", \\\"{x:1288,y:596,t:1526930077393};\\\", \\\"{x:1284,y:586,t:1526930077410};\\\", \\\"{x:1283,y:581,t:1526930077426};\\\", \\\"{x:1280,y:576,t:1526930077443};\\\", \\\"{x:1277,y:569,t:1526930077460};\\\", \\\"{x:1276,y:566,t:1526930077477};\\\", \\\"{x:1276,y:565,t:1526930077493};\\\", \\\"{x:1275,y:563,t:1526930077509};\\\", \\\"{x:1275,y:562,t:1526930077528};\\\", \\\"{x:1274,y:560,t:1526930077544};\\\", \\\"{x:1273,y:560,t:1526930083872};\\\", \\\"{x:1271,y:560,t:1526930083880};\\\", \\\"{x:1266,y:561,t:1526930083895};\\\", \\\"{x:1254,y:564,t:1526930083911};\\\", \\\"{x:1232,y:568,t:1526930083927};\\\", \\\"{x:1192,y:571,t:1526930083944};\\\", \\\"{x:1168,y:573,t:1526930083961};\\\", \\\"{x:1138,y:573,t:1526930083977};\\\", \\\"{x:1111,y:573,t:1526930083995};\\\", \\\"{x:1079,y:573,t:1526930084012};\\\", \\\"{x:1051,y:573,t:1526930084030};\\\", \\\"{x:1025,y:573,t:1526930084044};\\\", \\\"{x:1000,y:573,t:1526930084062};\\\", \\\"{x:978,y:573,t:1526930084079};\\\", \\\"{x:960,y:573,t:1526930084094};\\\", \\\"{x:951,y:573,t:1526930084111};\\\", \\\"{x:947,y:573,t:1526930084128};\\\", \\\"{x:943,y:573,t:1526930084199};\\\", \\\"{x:938,y:573,t:1526930084213};\\\", \\\"{x:917,y:573,t:1526930084230};\\\", \\\"{x:880,y:566,t:1526930084246};\\\", \\\"{x:824,y:558,t:1526930084263};\\\", \\\"{x:711,y:542,t:1526930084280};\\\", \\\"{x:642,y:531,t:1526930084301};\\\", \\\"{x:589,y:523,t:1526930084318};\\\", \\\"{x:561,y:521,t:1526930084335};\\\", \\\"{x:546,y:517,t:1526930084351};\\\", \\\"{x:546,y:516,t:1526930084448};\\\", \\\"{x:547,y:513,t:1526930084455};\\\", \\\"{x:548,y:513,t:1526930084468};\\\", \\\"{x:554,y:510,t:1526930084484};\\\", \\\"{x:559,y:507,t:1526930084501};\\\", \\\"{x:566,y:505,t:1526930084518};\\\", \\\"{x:571,y:503,t:1526930084534};\\\", \\\"{x:577,y:502,t:1526930084551};\\\", \\\"{x:582,y:500,t:1526930084568};\\\", \\\"{x:586,y:499,t:1526930084584};\\\", \\\"{x:592,y:497,t:1526930084601};\\\", \\\"{x:597,y:496,t:1526930084617};\\\", \\\"{x:599,y:495,t:1526930084639};\\\", \\\"{x:600,y:495,t:1526930086471};\\\", \\\"{x:603,y:495,t:1526930086480};\\\", \\\"{x:605,y:495,t:1526930086496};\\\", \\\"{x:607,y:495,t:1526930086520};\\\", \\\"{x:614,y:504,t:1526930087552};\\\", \\\"{x:627,y:526,t:1526930087559};\\\", \\\"{x:650,y:557,t:1526930087572};\\\", \\\"{x:708,y:618,t:1526930087588};\\\", \\\"{x:769,y:670,t:1526930087605};\\\", \\\"{x:811,y:701,t:1526930087621};\\\", \\\"{x:856,y:732,t:1526930087637};\\\", \\\"{x:897,y:756,t:1526930087654};\\\", \\\"{x:977,y:803,t:1526930087671};\\\", \\\"{x:1034,y:827,t:1526930087687};\\\", \\\"{x:1077,y:842,t:1526930087704};\\\", \\\"{x:1111,y:850,t:1526930087721};\\\", \\\"{x:1137,y:855,t:1526930087737};\\\", \\\"{x:1149,y:857,t:1526930087754};\\\", \\\"{x:1153,y:857,t:1526930087771};\\\", \\\"{x:1154,y:857,t:1526930087896};\\\", \\\"{x:1155,y:857,t:1526930087904};\\\", \\\"{x:1158,y:857,t:1526930087921};\\\", \\\"{x:1162,y:854,t:1526930087939};\\\", \\\"{x:1168,y:852,t:1526930087955};\\\", \\\"{x:1173,y:849,t:1526930087971};\\\", \\\"{x:1181,y:847,t:1526930087988};\\\", \\\"{x:1195,y:845,t:1526930088004};\\\", \\\"{x:1213,y:843,t:1526930088022};\\\", \\\"{x:1234,y:842,t:1526930088039};\\\", \\\"{x:1259,y:842,t:1526930088055};\\\", \\\"{x:1300,y:841,t:1526930088072};\\\", \\\"{x:1323,y:839,t:1526930088088};\\\", \\\"{x:1339,y:839,t:1526930088105};\\\", \\\"{x:1347,y:838,t:1526930088121};\\\", \\\"{x:1355,y:837,t:1526930088138};\\\", \\\"{x:1359,y:836,t:1526930088155};\\\", \\\"{x:1362,y:835,t:1526930088172};\\\", \\\"{x:1363,y:835,t:1526930088188};\\\", \\\"{x:1364,y:835,t:1526930088205};\\\", \\\"{x:1365,y:834,t:1526930088223};\\\", \\\"{x:1365,y:833,t:1526930088288};\\\", \\\"{x:1366,y:833,t:1526930088329};\\\", \\\"{x:1366,y:832,t:1526930088338};\\\", \\\"{x:1366,y:830,t:1526930088355};\\\", \\\"{x:1367,y:827,t:1526930088372};\\\", \\\"{x:1367,y:826,t:1526930088388};\\\", \\\"{x:1367,y:824,t:1526930088406};\\\", \\\"{x:1367,y:823,t:1526930088421};\\\", \\\"{x:1367,y:821,t:1526930088438};\\\", \\\"{x:1368,y:820,t:1526930088456};\\\", \\\"{x:1368,y:818,t:1526930088472};\\\", \\\"{x:1368,y:817,t:1526930088488};\\\", \\\"{x:1368,y:816,t:1526930088506};\\\", \\\"{x:1369,y:814,t:1526930088522};\\\", \\\"{x:1369,y:813,t:1526930088568};\\\", \\\"{x:1369,y:812,t:1526930088600};\\\", \\\"{x:1370,y:811,t:1526930088616};\\\", \\\"{x:1370,y:810,t:1526930088647};\\\", \\\"{x:1370,y:809,t:1526930088656};\\\", \\\"{x:1370,y:808,t:1526930088671};\\\", \\\"{x:1372,y:804,t:1526930088688};\\\", \\\"{x:1373,y:799,t:1526930088705};\\\", \\\"{x:1376,y:794,t:1526930088721};\\\", \\\"{x:1378,y:791,t:1526930088739};\\\", \\\"{x:1381,y:786,t:1526930088755};\\\", \\\"{x:1382,y:786,t:1526930088773};\\\", \\\"{x:1383,y:783,t:1526930088788};\\\", \\\"{x:1384,y:780,t:1526930088806};\\\", \\\"{x:1385,y:780,t:1526930088822};\\\", \\\"{x:1386,y:777,t:1526930088838};\\\", \\\"{x:1387,y:777,t:1526930088856};\\\", \\\"{x:1387,y:776,t:1526930088872};\\\", \\\"{x:1387,y:775,t:1526930088888};\\\", \\\"{x:1387,y:774,t:1526930088906};\\\", \\\"{x:1385,y:775,t:1526930089143};\\\", \\\"{x:1380,y:777,t:1526930089155};\\\", \\\"{x:1374,y:779,t:1526930089172};\\\", \\\"{x:1372,y:781,t:1526930089188};\\\", \\\"{x:1371,y:781,t:1526930089205};\\\", \\\"{x:1369,y:781,t:1526930089223};\\\", \\\"{x:1368,y:781,t:1526930089255};\\\", \\\"{x:1366,y:781,t:1526930089272};\\\", \\\"{x:1364,y:781,t:1526930089289};\\\", \\\"{x:1362,y:780,t:1526930089305};\\\", \\\"{x:1361,y:779,t:1526930089323};\\\", \\\"{x:1360,y:778,t:1526930089343};\\\", \\\"{x:1359,y:778,t:1526930089355};\\\", \\\"{x:1358,y:776,t:1526930089373};\\\", \\\"{x:1357,y:774,t:1526930089390};\\\", \\\"{x:1354,y:771,t:1526930089405};\\\", \\\"{x:1353,y:768,t:1526930089422};\\\", \\\"{x:1351,y:766,t:1526930089440};\\\", \\\"{x:1350,y:766,t:1526930089455};\\\", \\\"{x:1349,y:765,t:1526930089472};\\\", \\\"{x:1348,y:765,t:1526930089488};\\\", \\\"{x:1347,y:765,t:1526930089505};\\\", \\\"{x:1345,y:764,t:1526930089522};\\\", \\\"{x:1344,y:764,t:1526930089543};\\\", \\\"{x:1343,y:763,t:1526930089567};\\\", \\\"{x:1343,y:766,t:1526930099944};\\\", \\\"{x:1350,y:771,t:1526930099952};\\\", \\\"{x:1357,y:776,t:1526930099964};\\\", \\\"{x:1378,y:789,t:1526930099980};\\\", \\\"{x:1405,y:803,t:1526930099998};\\\", \\\"{x:1430,y:815,t:1526930100014};\\\", \\\"{x:1451,y:824,t:1526930100031};\\\", \\\"{x:1474,y:835,t:1526930100048};\\\", \\\"{x:1485,y:838,t:1526930100064};\\\", \\\"{x:1489,y:840,t:1526930100081};\\\", \\\"{x:1490,y:840,t:1526930100097};\\\", \\\"{x:1493,y:843,t:1526930100114};\\\", \\\"{x:1494,y:843,t:1526930100130};\\\", \\\"{x:1496,y:843,t:1526930100148};\\\", \\\"{x:1496,y:844,t:1526930100164};\\\", \\\"{x:1488,y:844,t:1526930100744};\\\", \\\"{x:1469,y:844,t:1526930100752};\\\", \\\"{x:1450,y:844,t:1526930100765};\\\", \\\"{x:1383,y:844,t:1526930100782};\\\", \\\"{x:1286,y:844,t:1526930100798};\\\", \\\"{x:1178,y:844,t:1526930100815};\\\", \\\"{x:1018,y:833,t:1526930100832};\\\", \\\"{x:923,y:820,t:1526930100848};\\\", \\\"{x:864,y:810,t:1526930100864};\\\", \\\"{x:819,y:804,t:1526930100882};\\\", \\\"{x:795,y:802,t:1526930100898};\\\", \\\"{x:779,y:799,t:1526930100914};\\\", \\\"{x:770,y:797,t:1526930100932};\\\", \\\"{x:760,y:796,t:1526930100947};\\\", \\\"{x:746,y:794,t:1526930100965};\\\", \\\"{x:723,y:791,t:1526930100982};\\\", \\\"{x:692,y:787,t:1526930100998};\\\", \\\"{x:647,y:780,t:1526930101014};\\\", \\\"{x:592,y:772,t:1526930101031};\\\", \\\"{x:560,y:767,t:1526930101047};\\\", \\\"{x:534,y:765,t:1526930101065};\\\", \\\"{x:513,y:760,t:1526930101081};\\\", \\\"{x:505,y:760,t:1526930101098};\\\", \\\"{x:502,y:758,t:1526930101115};\\\", \\\"{x:501,y:757,t:1526930101184};\\\", \\\"{x:500,y:756,t:1526930101199};\\\", \\\"{x:498,y:753,t:1526930101217};\\\", \\\"{x:497,y:750,t:1526930101231};\\\", \\\"{x:497,y:747,t:1526930101248};\\\", \\\"{x:497,y:746,t:1526930101262};\\\", \\\"{x:501,y:740,t:1526930101279};\\\", \\\"{x:504,y:736,t:1526930101295};\\\", \\\"{x:508,y:732,t:1526930101312};\\\", \\\"{x:513,y:729,t:1526930101329};\\\", \\\"{x:514,y:728,t:1526930101345};\\\", \\\"{x:515,y:727,t:1526930101362};\\\", \\\"{x:516,y:726,t:1526930101382};\\\", \\\"{x:517,y:725,t:1526930101415};\\\", \\\"{x:518,y:724,t:1526930101431};\\\", \\\"{x:519,y:724,t:1526930101471};\\\" ] }, { \\\"rt\\\": 27711, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 453718, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -J -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:719,t:1526930106097};\\\", \\\"{x:524,y:708,t:1526930106120};\\\", \\\"{x:552,y:698,t:1526930106136};\\\", \\\"{x:576,y:691,t:1526930106152};\\\", \\\"{x:576,y:684,t:1526930107048};\\\", \\\"{x:575,y:678,t:1526930107055};\\\", \\\"{x:574,y:674,t:1526930107070};\\\", \\\"{x:570,y:654,t:1526930107087};\\\", \\\"{x:567,y:641,t:1526930107103};\\\", \\\"{x:566,y:634,t:1526930107119};\\\", \\\"{x:565,y:625,t:1526930107138};\\\", \\\"{x:565,y:618,t:1526930107152};\\\", \\\"{x:563,y:609,t:1526930107169};\\\", \\\"{x:562,y:599,t:1526930107187};\\\", \\\"{x:560,y:584,t:1526930107203};\\\", \\\"{x:557,y:564,t:1526930107219};\\\", \\\"{x:555,y:549,t:1526930107237};\\\", \\\"{x:551,y:534,t:1526930107253};\\\", \\\"{x:550,y:525,t:1526930107269};\\\", \\\"{x:547,y:512,t:1526930107287};\\\", \\\"{x:545,y:501,t:1526930107303};\\\", \\\"{x:542,y:487,t:1526930107320};\\\", \\\"{x:542,y:479,t:1526930107337};\\\", \\\"{x:542,y:471,t:1526930107353};\\\", \\\"{x:542,y:467,t:1526930107370};\\\", \\\"{x:542,y:464,t:1526930107386};\\\", \\\"{x:542,y:463,t:1526930107403};\\\", \\\"{x:542,y:461,t:1526930107420};\\\", \\\"{x:542,y:460,t:1526930107437};\\\", \\\"{x:542,y:457,t:1526930107454};\\\", \\\"{x:542,y:456,t:1526930107470};\\\", \\\"{x:557,y:456,t:1526930107487};\\\", \\\"{x:619,y:477,t:1526930107504};\\\", \\\"{x:729,y:522,t:1526930107520};\\\", \\\"{x:869,y:572,t:1526930107538};\\\", \\\"{x:1003,y:620,t:1526930107554};\\\", \\\"{x:1146,y:661,t:1526930107571};\\\", \\\"{x:1296,y:708,t:1526930107586};\\\", \\\"{x:1415,y:741,t:1526930107603};\\\", \\\"{x:1518,y:761,t:1526930107621};\\\", \\\"{x:1592,y:775,t:1526930107637};\\\", \\\"{x:1613,y:777,t:1526930107653};\\\", \\\"{x:1629,y:777,t:1526930107671};\\\", \\\"{x:1630,y:777,t:1526930107686};\\\", \\\"{x:1628,y:777,t:1526930107792};\\\", \\\"{x:1617,y:777,t:1526930107804};\\\", \\\"{x:1576,y:771,t:1526930107821};\\\", \\\"{x:1522,y:763,t:1526930107836};\\\", \\\"{x:1465,y:752,t:1526930107854};\\\", \\\"{x:1365,y:750,t:1526930107871};\\\", \\\"{x:1302,y:754,t:1526930107887};\\\", \\\"{x:1253,y:763,t:1526930107904};\\\", \\\"{x:1227,y:768,t:1526930107921};\\\", \\\"{x:1221,y:769,t:1526930107937};\\\", \\\"{x:1218,y:770,t:1526930107954};\\\", \\\"{x:1218,y:774,t:1526930108264};\\\", \\\"{x:1218,y:780,t:1526930108272};\\\", \\\"{x:1218,y:790,t:1526930108287};\\\", \\\"{x:1218,y:796,t:1526930108304};\\\", \\\"{x:1218,y:801,t:1526930108321};\\\", \\\"{x:1218,y:807,t:1526930108338};\\\", \\\"{x:1218,y:810,t:1526930108354};\\\", \\\"{x:1218,y:811,t:1526930108371};\\\", \\\"{x:1218,y:812,t:1526930108389};\\\", \\\"{x:1217,y:813,t:1526930108405};\\\", \\\"{x:1217,y:814,t:1526930108544};\\\", \\\"{x:1217,y:815,t:1526930108555};\\\", \\\"{x:1217,y:819,t:1526930108571};\\\", \\\"{x:1217,y:822,t:1526930108588};\\\", \\\"{x:1218,y:824,t:1526930108605};\\\", \\\"{x:1219,y:826,t:1526930108622};\\\", \\\"{x:1219,y:827,t:1526930108638};\\\", \\\"{x:1220,y:829,t:1526930109839};\\\", \\\"{x:1221,y:833,t:1526930109855};\\\", \\\"{x:1222,y:836,t:1526930109872};\\\", \\\"{x:1222,y:838,t:1526930109888};\\\", \\\"{x:1222,y:839,t:1526930109906};\\\", \\\"{x:1222,y:840,t:1526930110063};\\\", \\\"{x:1221,y:840,t:1526930110072};\\\", \\\"{x:1218,y:840,t:1526930110089};\\\", \\\"{x:1213,y:840,t:1526930110106};\\\", \\\"{x:1208,y:840,t:1526930110123};\\\", \\\"{x:1205,y:840,t:1526930110139};\\\", \\\"{x:1203,y:840,t:1526930110156};\\\", \\\"{x:1200,y:840,t:1526930110174};\\\", \\\"{x:1199,y:840,t:1526930110471};\\\", \\\"{x:1199,y:839,t:1526930110479};\\\", \\\"{x:1199,y:838,t:1526930113672};\\\", \\\"{x:1200,y:838,t:1526930113680};\\\", \\\"{x:1201,y:838,t:1526930113692};\\\", \\\"{x:1205,y:836,t:1526930113709};\\\", \\\"{x:1206,y:835,t:1526930113724};\\\", \\\"{x:1207,y:835,t:1526930113741};\\\", \\\"{x:1209,y:834,t:1526930113758};\\\", \\\"{x:1210,y:834,t:1526930113815};\\\", \\\"{x:1211,y:833,t:1526930113839};\\\", \\\"{x:1212,y:833,t:1526930113859};\\\", \\\"{x:1213,y:833,t:1526930113903};\\\", \\\"{x:1214,y:833,t:1526930113943};\\\", \\\"{x:1215,y:833,t:1526930113959};\\\", \\\"{x:1216,y:833,t:1526930115832};\\\", \\\"{x:1216,y:831,t:1526930115844};\\\", \\\"{x:1216,y:826,t:1526930115861};\\\", \\\"{x:1215,y:823,t:1526930115879};\\\", \\\"{x:1215,y:819,t:1526930115894};\\\", \\\"{x:1215,y:813,t:1526930115910};\\\", \\\"{x:1215,y:808,t:1526930115927};\\\", \\\"{x:1215,y:804,t:1526930115944};\\\", \\\"{x:1213,y:800,t:1526930115961};\\\", \\\"{x:1213,y:797,t:1526930115977};\\\", \\\"{x:1212,y:793,t:1526930115994};\\\", \\\"{x:1212,y:792,t:1526930116011};\\\", \\\"{x:1211,y:789,t:1526930116027};\\\", \\\"{x:1210,y:787,t:1526930116044};\\\", \\\"{x:1209,y:787,t:1526930116062};\\\", \\\"{x:1209,y:786,t:1526930116077};\\\", \\\"{x:1208,y:784,t:1526930116094};\\\", \\\"{x:1207,y:783,t:1526930116119};\\\", \\\"{x:1206,y:782,t:1526930116144};\\\", \\\"{x:1206,y:781,t:1526930116161};\\\", \\\"{x:1205,y:780,t:1526930116184};\\\", \\\"{x:1204,y:780,t:1526930116195};\\\", \\\"{x:1204,y:779,t:1526930116211};\\\", \\\"{x:1203,y:779,t:1526930116228};\\\", \\\"{x:1201,y:779,t:1526930116245};\\\", \\\"{x:1199,y:777,t:1526930116261};\\\", \\\"{x:1197,y:777,t:1526930116278};\\\", \\\"{x:1195,y:776,t:1526930116294};\\\", \\\"{x:1192,y:774,t:1526930116311};\\\", \\\"{x:1190,y:774,t:1526930116328};\\\", \\\"{x:1187,y:772,t:1526930116344};\\\", \\\"{x:1184,y:771,t:1526930116362};\\\", \\\"{x:1175,y:768,t:1526930116378};\\\", \\\"{x:1165,y:765,t:1526930116394};\\\", \\\"{x:1151,y:761,t:1526930116411};\\\", \\\"{x:1135,y:759,t:1526930116429};\\\", \\\"{x:1117,y:753,t:1526930116444};\\\", \\\"{x:1092,y:745,t:1526930116461};\\\", \\\"{x:1063,y:737,t:1526930116478};\\\", \\\"{x:1018,y:724,t:1526930116494};\\\", \\\"{x:913,y:696,t:1526930116511};\\\", \\\"{x:817,y:672,t:1526930116529};\\\", \\\"{x:721,y:654,t:1526930116544};\\\", \\\"{x:634,y:635,t:1526930116561};\\\", \\\"{x:544,y:616,t:1526930116579};\\\", \\\"{x:464,y:598,t:1526930116596};\\\", \\\"{x:408,y:579,t:1526930116611};\\\", \\\"{x:313,y:554,t:1526930116644};\\\", \\\"{x:286,y:548,t:1526930116661};\\\", \\\"{x:261,y:541,t:1526930116677};\\\", \\\"{x:241,y:536,t:1526930116693};\\\", \\\"{x:213,y:528,t:1526930116710};\\\", \\\"{x:198,y:524,t:1526930116727};\\\", \\\"{x:185,y:521,t:1526930116743};\\\", \\\"{x:178,y:520,t:1526930116761};\\\", \\\"{x:173,y:519,t:1526930116777};\\\", \\\"{x:168,y:518,t:1526930116793};\\\", \\\"{x:168,y:519,t:1526930117055};\\\", \\\"{x:168,y:521,t:1526930117071};\\\", \\\"{x:168,y:522,t:1526930117079};\\\", \\\"{x:169,y:522,t:1526930117094};\\\", \\\"{x:171,y:527,t:1526930117112};\\\", \\\"{x:172,y:529,t:1526930117126};\\\", \\\"{x:175,y:532,t:1526930117145};\\\", \\\"{x:175,y:533,t:1526930117161};\\\", \\\"{x:176,y:533,t:1526930117178};\\\", \\\"{x:175,y:534,t:1526930117303};\\\", \\\"{x:175,y:535,t:1526930117312};\\\", \\\"{x:173,y:537,t:1526930117328};\\\", \\\"{x:173,y:538,t:1526930117345};\\\", \\\"{x:172,y:539,t:1526930117367};\\\", \\\"{x:172,y:537,t:1526930117455};\\\", \\\"{x:171,y:535,t:1526930117463};\\\", \\\"{x:171,y:529,t:1526930117479};\\\", \\\"{x:171,y:524,t:1526930117496};\\\", \\\"{x:171,y:521,t:1526930117512};\\\", \\\"{x:171,y:517,t:1526930117528};\\\", \\\"{x:171,y:513,t:1526930117545};\\\", \\\"{x:171,y:512,t:1526930117562};\\\", \\\"{x:171,y:511,t:1526930117578};\\\", \\\"{x:171,y:510,t:1526930117594};\\\", \\\"{x:170,y:509,t:1526930117614};\\\", \\\"{x:173,y:515,t:1526930117999};\\\", \\\"{x:185,y:534,t:1526930118013};\\\", \\\"{x:225,y:588,t:1526930118030};\\\", \\\"{x:269,y:645,t:1526930118046};\\\", \\\"{x:321,y:715,t:1526930118062};\\\", \\\"{x:384,y:785,t:1526930118078};\\\", \\\"{x:403,y:797,t:1526930118094};\\\", \\\"{x:411,y:802,t:1526930118112};\\\", \\\"{x:413,y:802,t:1526930118129};\\\", \\\"{x:414,y:802,t:1526930118215};\\\", \\\"{x:416,y:801,t:1526930118229};\\\", \\\"{x:417,y:798,t:1526930118245};\\\", \\\"{x:421,y:791,t:1526930118262};\\\", \\\"{x:429,y:776,t:1526930118279};\\\", \\\"{x:437,y:766,t:1526930118296};\\\", \\\"{x:442,y:760,t:1526930118313};\\\", \\\"{x:446,y:757,t:1526930118330};\\\", \\\"{x:447,y:755,t:1526930118345};\\\", \\\"{x:450,y:753,t:1526930118364};\\\", \\\"{x:453,y:750,t:1526930118379};\\\", \\\"{x:454,y:750,t:1526930118396};\\\", \\\"{x:455,y:750,t:1526930118413};\\\", \\\"{x:456,y:749,t:1526930118429};\\\", \\\"{x:458,y:749,t:1526930118454};\\\", \\\"{x:459,y:748,t:1526930118478};\\\", \\\"{x:460,y:747,t:1526930118487};\\\", \\\"{x:461,y:747,t:1526930118502};\\\", \\\"{x:463,y:746,t:1526930118513};\\\", \\\"{x:466,y:743,t:1526930118530};\\\", \\\"{x:471,y:740,t:1526930118546};\\\", \\\"{x:476,y:738,t:1526930118563};\\\", \\\"{x:479,y:735,t:1526930118580};\\\", \\\"{x:481,y:733,t:1526930118597};\\\", \\\"{x:482,y:732,t:1526930118613};\\\" ] }, { \\\"rt\\\": 17773, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 472702, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -F -B -B -F -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:739,t:1526930133966};\\\", \\\"{x:512,y:747,t:1526930133975};\\\", \\\"{x:549,y:764,t:1526930133992};\\\", \\\"{x:592,y:778,t:1526930134009};\\\", \\\"{x:631,y:790,t:1526930134025};\\\", \\\"{x:672,y:798,t:1526930134042};\\\", \\\"{x:709,y:806,t:1526930134059};\\\", \\\"{x:738,y:815,t:1526930134074};\\\", \\\"{x:769,y:821,t:1526930134091};\\\", \\\"{x:801,y:827,t:1526930134109};\\\", \\\"{x:837,y:835,t:1526930134124};\\\", \\\"{x:867,y:841,t:1526930134142};\\\", \\\"{x:922,y:853,t:1526930134158};\\\", \\\"{x:953,y:857,t:1526930134175};\\\", \\\"{x:975,y:861,t:1526930134191};\\\", \\\"{x:1000,y:865,t:1526930134209};\\\", \\\"{x:1019,y:866,t:1526930134225};\\\", \\\"{x:1033,y:866,t:1526930134242};\\\", \\\"{x:1039,y:866,t:1526930134259};\\\", \\\"{x:1042,y:866,t:1526930134275};\\\", \\\"{x:1044,y:866,t:1526930134358};\\\", \\\"{x:1047,y:866,t:1526930134376};\\\", \\\"{x:1059,y:862,t:1526930134392};\\\", \\\"{x:1071,y:861,t:1526930134409};\\\", \\\"{x:1089,y:859,t:1526930134426};\\\", \\\"{x:1109,y:855,t:1526930134442};\\\", \\\"{x:1126,y:853,t:1526930134458};\\\", \\\"{x:1137,y:851,t:1526930134476};\\\", \\\"{x:1146,y:849,t:1526930134492};\\\", \\\"{x:1156,y:846,t:1526930134509};\\\", \\\"{x:1160,y:846,t:1526930134527};\\\", \\\"{x:1163,y:844,t:1526930134542};\\\", \\\"{x:1168,y:841,t:1526930134559};\\\", \\\"{x:1173,y:839,t:1526930134576};\\\", \\\"{x:1179,y:835,t:1526930134592};\\\", \\\"{x:1186,y:831,t:1526930134609};\\\", \\\"{x:1194,y:826,t:1526930134626};\\\", \\\"{x:1202,y:822,t:1526930134642};\\\", \\\"{x:1213,y:816,t:1526930134659};\\\", \\\"{x:1220,y:810,t:1526930134676};\\\", \\\"{x:1230,y:805,t:1526930134691};\\\", \\\"{x:1238,y:800,t:1526930134709};\\\", \\\"{x:1248,y:794,t:1526930134726};\\\", \\\"{x:1251,y:791,t:1526930134742};\\\", \\\"{x:1260,y:785,t:1526930134759};\\\", \\\"{x:1265,y:781,t:1526930134776};\\\", \\\"{x:1272,y:775,t:1526930134792};\\\", \\\"{x:1278,y:771,t:1526930134809};\\\", \\\"{x:1284,y:766,t:1526930134826};\\\", \\\"{x:1290,y:760,t:1526930134843};\\\", \\\"{x:1296,y:755,t:1526930134859};\\\", \\\"{x:1302,y:750,t:1526930134876};\\\", \\\"{x:1306,y:746,t:1526930134894};\\\", \\\"{x:1310,y:744,t:1526930134910};\\\", \\\"{x:1313,y:741,t:1526930134927};\\\", \\\"{x:1319,y:736,t:1526930134943};\\\", \\\"{x:1325,y:731,t:1526930134959};\\\", \\\"{x:1327,y:729,t:1526930134976};\\\", \\\"{x:1331,y:727,t:1526930134993};\\\", \\\"{x:1334,y:724,t:1526930135010};\\\", \\\"{x:1337,y:722,t:1526930135027};\\\", \\\"{x:1340,y:720,t:1526930135044};\\\", \\\"{x:1340,y:718,t:1526930135059};\\\", \\\"{x:1343,y:717,t:1526930135076};\\\", \\\"{x:1346,y:714,t:1526930135093};\\\", \\\"{x:1347,y:713,t:1526930135110};\\\", \\\"{x:1351,y:710,t:1526930135126};\\\", \\\"{x:1354,y:708,t:1526930135144};\\\", \\\"{x:1354,y:707,t:1526930135160};\\\", \\\"{x:1356,y:705,t:1526930135176};\\\", \\\"{x:1357,y:705,t:1526930135193};\\\", \\\"{x:1357,y:704,t:1526930135210};\\\", \\\"{x:1358,y:702,t:1526930135227};\\\", \\\"{x:1358,y:701,t:1526930135247};\\\", \\\"{x:1359,y:700,t:1526930135260};\\\", \\\"{x:1359,y:699,t:1526930135399};\\\", \\\"{x:1356,y:699,t:1526930135410};\\\", \\\"{x:1351,y:699,t:1526930135429};\\\", \\\"{x:1344,y:699,t:1526930135443};\\\", \\\"{x:1340,y:699,t:1526930135460};\\\", \\\"{x:1334,y:699,t:1526930135475};\\\", \\\"{x:1333,y:699,t:1526930135493};\\\", \\\"{x:1332,y:699,t:1526930135510};\\\", \\\"{x:1331,y:699,t:1526930135550};\\\", \\\"{x:1330,y:700,t:1526930136031};\\\", \\\"{x:1330,y:701,t:1526930136043};\\\", \\\"{x:1330,y:702,t:1526930136071};\\\", \\\"{x:1330,y:703,t:1526930136096};\\\", \\\"{x:1330,y:704,t:1526930136207};\\\", \\\"{x:1330,y:705,t:1526930136231};\\\", \\\"{x:1330,y:706,t:1526930136263};\\\", \\\"{x:1330,y:708,t:1526930136277};\\\", \\\"{x:1330,y:710,t:1526930136294};\\\", \\\"{x:1330,y:714,t:1526930136311};\\\", \\\"{x:1330,y:718,t:1526930136327};\\\", \\\"{x:1330,y:723,t:1526930136344};\\\", \\\"{x:1330,y:728,t:1526930136361};\\\", \\\"{x:1330,y:734,t:1526930136378};\\\", \\\"{x:1330,y:745,t:1526930136394};\\\", \\\"{x:1330,y:760,t:1526930136410};\\\", \\\"{x:1330,y:778,t:1526930136427};\\\", \\\"{x:1330,y:792,t:1526930136445};\\\", \\\"{x:1330,y:800,t:1526930136461};\\\", \\\"{x:1330,y:806,t:1526930136478};\\\", \\\"{x:1330,y:812,t:1526930136494};\\\", \\\"{x:1330,y:816,t:1526930136510};\\\", \\\"{x:1330,y:824,t:1526930136528};\\\", \\\"{x:1330,y:830,t:1526930136545};\\\", \\\"{x:1330,y:835,t:1526930136561};\\\", \\\"{x:1330,y:839,t:1526930136577};\\\", \\\"{x:1330,y:843,t:1526930136594};\\\", \\\"{x:1330,y:846,t:1526930136611};\\\", \\\"{x:1330,y:850,t:1526930136627};\\\", \\\"{x:1330,y:853,t:1526930136645};\\\", \\\"{x:1330,y:858,t:1526930136661};\\\", \\\"{x:1330,y:865,t:1526930136677};\\\", \\\"{x:1331,y:870,t:1526930136695};\\\", \\\"{x:1331,y:877,t:1526930136711};\\\", \\\"{x:1333,y:882,t:1526930136727};\\\", \\\"{x:1335,y:885,t:1526930136744};\\\", \\\"{x:1337,y:889,t:1526930136762};\\\", \\\"{x:1339,y:895,t:1526930136778};\\\", \\\"{x:1341,y:898,t:1526930136794};\\\", \\\"{x:1342,y:903,t:1526930136811};\\\", \\\"{x:1343,y:907,t:1526930136828};\\\", \\\"{x:1343,y:911,t:1526930136844};\\\", \\\"{x:1346,y:919,t:1526930136862};\\\", \\\"{x:1348,y:925,t:1526930136878};\\\", \\\"{x:1350,y:932,t:1526930136895};\\\", \\\"{x:1352,y:939,t:1526930136912};\\\", \\\"{x:1353,y:942,t:1526930136928};\\\", \\\"{x:1354,y:945,t:1526930136944};\\\", \\\"{x:1354,y:948,t:1526930136961};\\\", \\\"{x:1354,y:949,t:1526930136978};\\\", \\\"{x:1354,y:950,t:1526930137040};\\\", \\\"{x:1354,y:951,t:1526930137047};\\\", \\\"{x:1354,y:952,t:1526930137061};\\\", \\\"{x:1354,y:953,t:1526930137078};\\\", \\\"{x:1354,y:956,t:1526930137094};\\\", \\\"{x:1354,y:958,t:1526930137111};\\\", \\\"{x:1354,y:959,t:1526930137174};\\\", \\\"{x:1354,y:960,t:1526930137191};\\\", \\\"{x:1354,y:961,t:1526930137223};\\\", \\\"{x:1354,y:962,t:1526930137288};\\\", \\\"{x:1354,y:963,t:1526930137303};\\\", \\\"{x:1353,y:965,t:1526930137335};\\\", \\\"{x:1352,y:965,t:1526930137359};\\\", \\\"{x:1352,y:966,t:1526930137367};\\\", \\\"{x:1352,y:967,t:1526930137378};\\\", \\\"{x:1351,y:967,t:1526930137394};\\\", \\\"{x:1349,y:968,t:1526930137441};\\\", \\\"{x:1348,y:968,t:1526930137480};\\\", \\\"{x:1353,y:966,t:1526930142632};\\\", \\\"{x:1361,y:956,t:1526930142648};\\\", \\\"{x:1368,y:946,t:1526930142665};\\\", \\\"{x:1379,y:933,t:1526930142683};\\\", \\\"{x:1389,y:921,t:1526930142698};\\\", \\\"{x:1398,y:911,t:1526930142715};\\\", \\\"{x:1399,y:906,t:1526930142732};\\\", \\\"{x:1402,y:897,t:1526930142749};\\\", \\\"{x:1404,y:888,t:1526930142766};\\\", \\\"{x:1404,y:875,t:1526930142783};\\\", \\\"{x:1404,y:868,t:1526930142799};\\\", \\\"{x:1399,y:855,t:1526930142816};\\\", \\\"{x:1389,y:837,t:1526930142833};\\\", \\\"{x:1372,y:814,t:1526930142850};\\\", \\\"{x:1357,y:791,t:1526930142866};\\\", \\\"{x:1343,y:772,t:1526930142883};\\\", \\\"{x:1337,y:757,t:1526930142899};\\\", \\\"{x:1335,y:751,t:1526930142916};\\\", \\\"{x:1333,y:744,t:1526930142932};\\\", \\\"{x:1332,y:738,t:1526930142950};\\\", \\\"{x:1330,y:733,t:1526930142966};\\\", \\\"{x:1330,y:727,t:1526930142983};\\\", \\\"{x:1331,y:723,t:1526930142999};\\\", \\\"{x:1331,y:722,t:1526930143016};\\\", \\\"{x:1334,y:719,t:1526930143033};\\\", \\\"{x:1334,y:718,t:1526930143055};\\\", \\\"{x:1336,y:720,t:1526930143264};\\\", \\\"{x:1338,y:726,t:1526930143271};\\\", \\\"{x:1338,y:729,t:1526930143282};\\\", \\\"{x:1340,y:740,t:1526930143299};\\\", \\\"{x:1340,y:747,t:1526930143317};\\\", \\\"{x:1340,y:751,t:1526930143333};\\\", \\\"{x:1340,y:755,t:1526930143350};\\\", \\\"{x:1340,y:757,t:1526930143367};\\\", \\\"{x:1340,y:758,t:1526930143383};\\\", \\\"{x:1341,y:761,t:1526930143600};\\\", \\\"{x:1343,y:764,t:1526930143617};\\\", \\\"{x:1344,y:768,t:1526930143635};\\\", \\\"{x:1347,y:774,t:1526930143650};\\\", \\\"{x:1349,y:778,t:1526930143667};\\\", \\\"{x:1351,y:780,t:1526930143684};\\\", \\\"{x:1352,y:781,t:1526930143700};\\\", \\\"{x:1352,y:779,t:1526930143976};\\\", \\\"{x:1352,y:776,t:1526930143983};\\\", \\\"{x:1353,y:769,t:1526930144000};\\\", \\\"{x:1353,y:761,t:1526930144017};\\\", \\\"{x:1353,y:753,t:1526930144035};\\\", \\\"{x:1353,y:745,t:1526930144049};\\\", \\\"{x:1353,y:739,t:1526930144066};\\\", \\\"{x:1353,y:733,t:1526930144083};\\\", \\\"{x:1352,y:728,t:1526930144100};\\\", \\\"{x:1350,y:724,t:1526930144116};\\\", \\\"{x:1349,y:720,t:1526930144134};\\\", \\\"{x:1348,y:717,t:1526930144150};\\\", \\\"{x:1348,y:716,t:1526930144166};\\\", \\\"{x:1347,y:714,t:1526930144183};\\\", \\\"{x:1347,y:713,t:1526930144206};\\\", \\\"{x:1346,y:713,t:1526930144216};\\\", \\\"{x:1346,y:712,t:1526930144271};\\\", \\\"{x:1346,y:711,t:1526930144283};\\\", \\\"{x:1346,y:710,t:1526930144301};\\\", \\\"{x:1346,y:708,t:1526930144316};\\\", \\\"{x:1346,y:706,t:1526930144333};\\\", \\\"{x:1346,y:703,t:1526930144350};\\\", \\\"{x:1346,y:701,t:1526930144366};\\\", \\\"{x:1346,y:700,t:1526930144383};\\\", \\\"{x:1347,y:698,t:1526930144400};\\\", \\\"{x:1348,y:697,t:1526930144417};\\\", \\\"{x:1349,y:696,t:1526930144433};\\\", \\\"{x:1350,y:696,t:1526930144568};\\\", \\\"{x:1357,y:702,t:1526930144585};\\\", \\\"{x:1366,y:708,t:1526930144601};\\\", \\\"{x:1374,y:714,t:1526930144617};\\\", \\\"{x:1385,y:722,t:1526930144634};\\\", \\\"{x:1399,y:731,t:1526930144650};\\\", \\\"{x:1413,y:741,t:1526930144667};\\\", \\\"{x:1423,y:751,t:1526930144684};\\\", \\\"{x:1434,y:762,t:1526930144701};\\\", \\\"{x:1446,y:776,t:1526930144718};\\\", \\\"{x:1458,y:790,t:1526930144734};\\\", \\\"{x:1470,y:804,t:1526930144751};\\\", \\\"{x:1473,y:809,t:1526930144767};\\\", \\\"{x:1475,y:811,t:1526930144783};\\\", \\\"{x:1475,y:812,t:1526930145064};\\\", \\\"{x:1476,y:817,t:1526930145071};\\\", \\\"{x:1478,y:820,t:1526930145084};\\\", \\\"{x:1479,y:824,t:1526930145101};\\\", \\\"{x:1479,y:826,t:1526930145118};\\\", \\\"{x:1480,y:828,t:1526930145376};\\\", \\\"{x:1481,y:830,t:1526930145385};\\\", \\\"{x:1481,y:833,t:1526930145400};\\\", \\\"{x:1481,y:834,t:1526930145418};\\\", \\\"{x:1481,y:835,t:1526930146391};\\\", \\\"{x:1481,y:836,t:1526930146403};\\\", \\\"{x:1478,y:837,t:1526930146419};\\\", \\\"{x:1470,y:837,t:1526930146436};\\\", \\\"{x:1454,y:834,t:1526930146452};\\\", \\\"{x:1423,y:824,t:1526930146469};\\\", \\\"{x:1362,y:807,t:1526930146486};\\\", \\\"{x:1265,y:779,t:1526930146502};\\\", \\\"{x:1080,y:731,t:1526930146519};\\\", \\\"{x:934,y:689,t:1526930146535};\\\", \\\"{x:786,y:659,t:1526930146552};\\\", \\\"{x:656,y:638,t:1526930146568};\\\", \\\"{x:551,y:610,t:1526930146587};\\\", \\\"{x:480,y:597,t:1526930146601};\\\", \\\"{x:449,y:590,t:1526930146619};\\\", \\\"{x:443,y:590,t:1526930146636};\\\", \\\"{x:445,y:590,t:1526930146694};\\\", \\\"{x:447,y:590,t:1526930146702};\\\", \\\"{x:453,y:588,t:1526930146718};\\\", \\\"{x:464,y:587,t:1526930146735};\\\", \\\"{x:482,y:586,t:1526930146753};\\\", \\\"{x:504,y:586,t:1526930146769};\\\", \\\"{x:523,y:586,t:1526930146785};\\\", \\\"{x:544,y:586,t:1526930146802};\\\", \\\"{x:572,y:586,t:1526930146819};\\\", \\\"{x:595,y:586,t:1526930146835};\\\", \\\"{x:620,y:586,t:1526930146853};\\\", \\\"{x:645,y:586,t:1526930146870};\\\", \\\"{x:671,y:586,t:1526930146886};\\\", \\\"{x:705,y:587,t:1526930146902};\\\", \\\"{x:725,y:590,t:1526930146921};\\\", \\\"{x:741,y:590,t:1526930146936};\\\", \\\"{x:752,y:590,t:1526930146953};\\\", \\\"{x:763,y:590,t:1526930146968};\\\", \\\"{x:767,y:590,t:1526930146986};\\\", \\\"{x:772,y:590,t:1526930147002};\\\", \\\"{x:776,y:588,t:1526930147019};\\\", \\\"{x:779,y:587,t:1526930147036};\\\", \\\"{x:782,y:584,t:1526930147052};\\\", \\\"{x:786,y:581,t:1526930147068};\\\", \\\"{x:789,y:579,t:1526930147086};\\\", \\\"{x:791,y:575,t:1526930147103};\\\", \\\"{x:791,y:574,t:1526930147142};\\\", \\\"{x:791,y:572,t:1526930147151};\\\", \\\"{x:788,y:568,t:1526930147169};\\\", \\\"{x:780,y:565,t:1526930147186};\\\", \\\"{x:770,y:563,t:1526930147202};\\\", \\\"{x:758,y:565,t:1526930147219};\\\", \\\"{x:743,y:573,t:1526930147236};\\\", \\\"{x:725,y:579,t:1526930147251};\\\", \\\"{x:713,y:587,t:1526930147270};\\\", \\\"{x:701,y:593,t:1526930147285};\\\", \\\"{x:687,y:604,t:1526930147304};\\\", \\\"{x:683,y:608,t:1526930147320};\\\", \\\"{x:677,y:612,t:1526930147336};\\\", \\\"{x:674,y:614,t:1526930147352};\\\", \\\"{x:671,y:617,t:1526930147369};\\\", \\\"{x:669,y:619,t:1526930147386};\\\", \\\"{x:668,y:620,t:1526930147402};\\\", \\\"{x:667,y:620,t:1526930147419};\\\", \\\"{x:664,y:620,t:1526930147436};\\\", \\\"{x:662,y:620,t:1526930147452};\\\", \\\"{x:659,y:620,t:1526930147470};\\\", \\\"{x:654,y:620,t:1526930147486};\\\", \\\"{x:651,y:619,t:1526930147503};\\\", \\\"{x:647,y:619,t:1526930147519};\\\", \\\"{x:643,y:617,t:1526930147537};\\\", \\\"{x:639,y:616,t:1526930147552};\\\", \\\"{x:636,y:615,t:1526930147569};\\\", \\\"{x:633,y:614,t:1526930147586};\\\", \\\"{x:630,y:612,t:1526930147603};\\\", \\\"{x:628,y:611,t:1526930147619};\\\", \\\"{x:625,y:610,t:1526930147636};\\\", \\\"{x:624,y:607,t:1526930147653};\\\", \\\"{x:618,y:601,t:1526930147670};\\\", \\\"{x:615,y:596,t:1526930147687};\\\", \\\"{x:614,y:593,t:1526930147704};\\\", \\\"{x:611,y:589,t:1526930147720};\\\", \\\"{x:608,y:584,t:1526930147736};\\\", \\\"{x:607,y:581,t:1526930147753};\\\", \\\"{x:606,y:577,t:1526930147769};\\\", \\\"{x:605,y:575,t:1526930147786};\\\", \\\"{x:604,y:573,t:1526930147803};\\\", \\\"{x:604,y:572,t:1526930147830};\\\", \\\"{x:603,y:574,t:1526930148631};\\\", \\\"{x:600,y:581,t:1526930148639};\\\", \\\"{x:598,y:590,t:1526930148655};\\\", \\\"{x:586,y:618,t:1526930148670};\\\", \\\"{x:576,y:641,t:1526930148688};\\\", \\\"{x:570,y:657,t:1526930148703};\\\", \\\"{x:564,y:671,t:1526930148720};\\\", \\\"{x:556,y:685,t:1526930148737};\\\", \\\"{x:551,y:696,t:1526930148753};\\\", \\\"{x:549,y:702,t:1526930148770};\\\", \\\"{x:545,y:709,t:1526930148787};\\\", \\\"{x:541,y:715,t:1526930148804};\\\", \\\"{x:538,y:719,t:1526930148820};\\\", \\\"{x:534,y:726,t:1526930148838};\\\", \\\"{x:530,y:732,t:1526930148854};\\\", \\\"{x:527,y:736,t:1526930148870};\\\", \\\"{x:526,y:739,t:1526930148888};\\\", \\\"{x:525,y:739,t:1526930148919};\\\" ] }, { \\\"rt\\\": 12324, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 486337, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-11 AM-12 PM-12 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:742,t:1526930151999};\\\", \\\"{x:531,y:746,t:1526930152006};\\\", \\\"{x:539,y:753,t:1526930152021};\\\", \\\"{x:552,y:762,t:1526930152040};\\\", \\\"{x:562,y:767,t:1526930152056};\\\", \\\"{x:575,y:773,t:1526930152073};\\\", \\\"{x:594,y:778,t:1526930152090};\\\", \\\"{x:629,y:792,t:1526930152107};\\\", \\\"{x:676,y:804,t:1526930152124};\\\", \\\"{x:721,y:811,t:1526930152140};\\\", \\\"{x:759,y:813,t:1526930152157};\\\", \\\"{x:792,y:813,t:1526930152174};\\\", \\\"{x:827,y:811,t:1526930152191};\\\", \\\"{x:835,y:809,t:1526930152207};\\\", \\\"{x:838,y:807,t:1526930152224};\\\", \\\"{x:839,y:807,t:1526930152303};\\\", \\\"{x:843,y:807,t:1526930153199};\\\", \\\"{x:862,y:813,t:1526930153208};\\\", \\\"{x:900,y:828,t:1526930153225};\\\", \\\"{x:937,y:845,t:1526930153242};\\\", \\\"{x:975,y:867,t:1526930153258};\\\", \\\"{x:1014,y:893,t:1526930153276};\\\", \\\"{x:1050,y:915,t:1526930153292};\\\", \\\"{x:1089,y:930,t:1526930153308};\\\", \\\"{x:1132,y:945,t:1526930153326};\\\", \\\"{x:1162,y:956,t:1526930153342};\\\", \\\"{x:1203,y:972,t:1526930153358};\\\", \\\"{x:1272,y:997,t:1526930153375};\\\", \\\"{x:1316,y:1009,t:1526930153392};\\\", \\\"{x:1351,y:1015,t:1526930153408};\\\", \\\"{x:1374,y:1017,t:1526930153425};\\\", \\\"{x:1398,y:1024,t:1526930153442};\\\", \\\"{x:1426,y:1032,t:1526930153459};\\\", \\\"{x:1451,y:1039,t:1526930153475};\\\", \\\"{x:1471,y:1045,t:1526930153492};\\\", \\\"{x:1486,y:1047,t:1526930153508};\\\", \\\"{x:1493,y:1048,t:1526930153524};\\\", \\\"{x:1494,y:1048,t:1526930153541};\\\", \\\"{x:1491,y:1048,t:1526930153582};\\\", \\\"{x:1481,y:1041,t:1526930153591};\\\", \\\"{x:1446,y:1026,t:1526930153609};\\\", \\\"{x:1413,y:1012,t:1526930153624};\\\", \\\"{x:1375,y:998,t:1526930153641};\\\", \\\"{x:1337,y:988,t:1526930153659};\\\", \\\"{x:1298,y:978,t:1526930153675};\\\", \\\"{x:1261,y:969,t:1526930153692};\\\", \\\"{x:1246,y:965,t:1526930153708};\\\", \\\"{x:1242,y:964,t:1526930153725};\\\", \\\"{x:1246,y:964,t:1526930153904};\\\", \\\"{x:1253,y:965,t:1526930153911};\\\", \\\"{x:1263,y:966,t:1526930153925};\\\", \\\"{x:1286,y:969,t:1526930153942};\\\", \\\"{x:1319,y:972,t:1526930153959};\\\", \\\"{x:1333,y:973,t:1526930153975};\\\", \\\"{x:1337,y:974,t:1526930153992};\\\", \\\"{x:1338,y:974,t:1526930154009};\\\", \\\"{x:1338,y:973,t:1526930154055};\\\", \\\"{x:1338,y:972,t:1526930154071};\\\", \\\"{x:1338,y:970,t:1526930154078};\\\", \\\"{x:1338,y:969,t:1526930154092};\\\", \\\"{x:1336,y:966,t:1526930154110};\\\", \\\"{x:1335,y:962,t:1526930154126};\\\", \\\"{x:1333,y:957,t:1526930154142};\\\", \\\"{x:1332,y:955,t:1526930154160};\\\", \\\"{x:1332,y:953,t:1526930154177};\\\", \\\"{x:1332,y:952,t:1526930154194};\\\", \\\"{x:1332,y:949,t:1526930154210};\\\", \\\"{x:1332,y:947,t:1526930154227};\\\", \\\"{x:1332,y:945,t:1526930154243};\\\", \\\"{x:1332,y:942,t:1526930154259};\\\", \\\"{x:1332,y:940,t:1526930154276};\\\", \\\"{x:1332,y:939,t:1526930154391};\\\", \\\"{x:1333,y:939,t:1526930154398};\\\", \\\"{x:1334,y:942,t:1526930154409};\\\", \\\"{x:1336,y:947,t:1526930154426};\\\", \\\"{x:1337,y:949,t:1526930154443};\\\", \\\"{x:1338,y:952,t:1526930154460};\\\", \\\"{x:1339,y:955,t:1526930154476};\\\", \\\"{x:1341,y:958,t:1526930154493};\\\", \\\"{x:1343,y:962,t:1526930154510};\\\", \\\"{x:1344,y:963,t:1526930154527};\\\", \\\"{x:1346,y:966,t:1526930154543};\\\", \\\"{x:1347,y:968,t:1526930154560};\\\", \\\"{x:1348,y:969,t:1526930154584};\\\", \\\"{x:1349,y:969,t:1526930154593};\\\", \\\"{x:1350,y:968,t:1526930154744};\\\", \\\"{x:1350,y:965,t:1526930154760};\\\", \\\"{x:1351,y:962,t:1526930154778};\\\", \\\"{x:1351,y:960,t:1526930154793};\\\", \\\"{x:1353,y:957,t:1526930154815};\\\", \\\"{x:1353,y:956,t:1526930154831};\\\", \\\"{x:1353,y:955,t:1526930154843};\\\", \\\"{x:1353,y:953,t:1526930154861};\\\", \\\"{x:1353,y:952,t:1526930154877};\\\", \\\"{x:1353,y:951,t:1526930154894};\\\", \\\"{x:1353,y:950,t:1526930154910};\\\", \\\"{x:1353,y:948,t:1526930154927};\\\", \\\"{x:1354,y:947,t:1526930154944};\\\", \\\"{x:1354,y:945,t:1526930154960};\\\", \\\"{x:1354,y:942,t:1526930154978};\\\", \\\"{x:1354,y:939,t:1526930154993};\\\", \\\"{x:1354,y:938,t:1526930155011};\\\", \\\"{x:1354,y:932,t:1526930155027};\\\", \\\"{x:1354,y:929,t:1526930155043};\\\", \\\"{x:1354,y:924,t:1526930155061};\\\", \\\"{x:1354,y:921,t:1526930155078};\\\", \\\"{x:1354,y:917,t:1526930155094};\\\", \\\"{x:1353,y:910,t:1526930155111};\\\", \\\"{x:1352,y:907,t:1526930155127};\\\", \\\"{x:1352,y:903,t:1526930155145};\\\", \\\"{x:1349,y:898,t:1526930155161};\\\", \\\"{x:1349,y:895,t:1526930155177};\\\", \\\"{x:1349,y:890,t:1526930155194};\\\", \\\"{x:1348,y:885,t:1526930155210};\\\", \\\"{x:1348,y:879,t:1526930155227};\\\", \\\"{x:1348,y:872,t:1526930155244};\\\", \\\"{x:1348,y:857,t:1526930155260};\\\", \\\"{x:1348,y:843,t:1526930155278};\\\", \\\"{x:1347,y:827,t:1526930155294};\\\", \\\"{x:1345,y:813,t:1526930155310};\\\", \\\"{x:1342,y:797,t:1526930155327};\\\", \\\"{x:1342,y:791,t:1526930155344};\\\", \\\"{x:1342,y:788,t:1526930155361};\\\", \\\"{x:1342,y:783,t:1526930155377};\\\", \\\"{x:1340,y:778,t:1526930155394};\\\", \\\"{x:1340,y:776,t:1526930155411};\\\", \\\"{x:1340,y:774,t:1526930155427};\\\", \\\"{x:1340,y:772,t:1526930155444};\\\", \\\"{x:1340,y:770,t:1526930155463};\\\", \\\"{x:1340,y:769,t:1526930155566};\\\", \\\"{x:1341,y:769,t:1526930155688};\\\", \\\"{x:1341,y:767,t:1526930155694};\\\", \\\"{x:1343,y:766,t:1526930155721};\\\", \\\"{x:1343,y:765,t:1526930155862};\\\", \\\"{x:1344,y:764,t:1526930155878};\\\", \\\"{x:1344,y:762,t:1526930155903};\\\", \\\"{x:1345,y:762,t:1526930155927};\\\", \\\"{x:1346,y:762,t:1526930155951};\\\", \\\"{x:1346,y:761,t:1526930155999};\\\", \\\"{x:1347,y:760,t:1526930156079};\\\", \\\"{x:1348,y:760,t:1526930156111};\\\", \\\"{x:1348,y:759,t:1526930156128};\\\", \\\"{x:1349,y:758,t:1526930156223};\\\", \\\"{x:1348,y:758,t:1526930156671};\\\", \\\"{x:1343,y:758,t:1526930156680};\\\", \\\"{x:1322,y:760,t:1526930156696};\\\", \\\"{x:1291,y:760,t:1526930156712};\\\", \\\"{x:1242,y:758,t:1526930156730};\\\", \\\"{x:1180,y:748,t:1526930156745};\\\", \\\"{x:1099,y:733,t:1526930156762};\\\", \\\"{x:1007,y:720,t:1526930156779};\\\", \\\"{x:926,y:707,t:1526930156796};\\\", \\\"{x:865,y:699,t:1526930156813};\\\", \\\"{x:833,y:698,t:1526930156826};\\\", \\\"{x:814,y:698,t:1526930156842};\\\", \\\"{x:796,y:696,t:1526930156860};\\\", \\\"{x:791,y:694,t:1526930156876};\\\", \\\"{x:787,y:694,t:1526930156892};\\\", \\\"{x:778,y:693,t:1526930156909};\\\", \\\"{x:762,y:686,t:1526930156927};\\\", \\\"{x:734,y:679,t:1526930156942};\\\", \\\"{x:697,y:674,t:1526930156959};\\\", \\\"{x:653,y:664,t:1526930156976};\\\", \\\"{x:610,y:654,t:1526930156993};\\\", \\\"{x:577,y:649,t:1526930157009};\\\", \\\"{x:540,y:644,t:1526930157026};\\\", \\\"{x:499,y:638,t:1526930157043};\\\", \\\"{x:475,y:631,t:1526930157061};\\\", \\\"{x:451,y:624,t:1526930157075};\\\", \\\"{x:429,y:618,t:1526930157092};\\\", \\\"{x:400,y:612,t:1526930157107};\\\", \\\"{x:368,y:606,t:1526930157124};\\\", \\\"{x:327,y:596,t:1526930157141};\\\", \\\"{x:289,y:592,t:1526930157158};\\\", \\\"{x:261,y:586,t:1526930157175};\\\", \\\"{x:243,y:583,t:1526930157191};\\\", \\\"{x:234,y:583,t:1526930157208};\\\", \\\"{x:233,y:582,t:1526930157225};\\\", \\\"{x:231,y:582,t:1526930157347};\\\", \\\"{x:229,y:581,t:1526930157358};\\\", \\\"{x:224,y:580,t:1526930157375};\\\", \\\"{x:220,y:578,t:1526930157391};\\\", \\\"{x:216,y:578,t:1526930157407};\\\", \\\"{x:214,y:576,t:1526930157425};\\\", \\\"{x:211,y:575,t:1526930157441};\\\", \\\"{x:207,y:573,t:1526930157459};\\\", \\\"{x:204,y:572,t:1526930157475};\\\", \\\"{x:197,y:567,t:1526930157492};\\\", \\\"{x:192,y:564,t:1526930157508};\\\", \\\"{x:182,y:554,t:1526930157527};\\\", \\\"{x:173,y:548,t:1526930157541};\\\", \\\"{x:162,y:538,t:1526930157558};\\\", \\\"{x:153,y:531,t:1526930157575};\\\", \\\"{x:148,y:527,t:1526930157591};\\\", \\\"{x:145,y:523,t:1526930157608};\\\", \\\"{x:144,y:522,t:1526930157625};\\\", \\\"{x:144,y:521,t:1526930157642};\\\", \\\"{x:143,y:520,t:1526930157658};\\\", \\\"{x:144,y:522,t:1526930157828};\\\", \\\"{x:147,y:527,t:1526930157843};\\\", \\\"{x:151,y:534,t:1526930157858};\\\", \\\"{x:157,y:542,t:1526930157875};\\\", \\\"{x:160,y:545,t:1526930157891};\\\", \\\"{x:162,y:548,t:1526930157908};\\\", \\\"{x:163,y:548,t:1526930157925};\\\", \\\"{x:163,y:549,t:1526930157955};\\\", \\\"{x:166,y:549,t:1526930158861};\\\", \\\"{x:179,y:549,t:1526930158876};\\\", \\\"{x:201,y:553,t:1526930158894};\\\", \\\"{x:222,y:555,t:1526930158909};\\\", \\\"{x:253,y:560,t:1526930158926};\\\", \\\"{x:296,y:567,t:1526930158942};\\\", \\\"{x:348,y:573,t:1526930158959};\\\", \\\"{x:404,y:581,t:1526930158976};\\\", \\\"{x:448,y:584,t:1526930158993};\\\", \\\"{x:489,y:588,t:1526930159009};\\\", \\\"{x:524,y:590,t:1526930159026};\\\", \\\"{x:559,y:590,t:1526930159043};\\\", \\\"{x:576,y:590,t:1526930159058};\\\", \\\"{x:591,y:590,t:1526930159076};\\\", \\\"{x:603,y:587,t:1526930159093};\\\", \\\"{x:612,y:586,t:1526930159109};\\\", \\\"{x:620,y:581,t:1526930159126};\\\", \\\"{x:628,y:577,t:1526930159143};\\\", \\\"{x:635,y:573,t:1526930159158};\\\", \\\"{x:640,y:570,t:1526930159176};\\\", \\\"{x:655,y:565,t:1526930159193};\\\", \\\"{x:664,y:560,t:1526930159210};\\\", \\\"{x:672,y:558,t:1526930159226};\\\", \\\"{x:687,y:551,t:1526930159244};\\\", \\\"{x:697,y:546,t:1526930159260};\\\", \\\"{x:713,y:543,t:1526930159276};\\\", \\\"{x:731,y:538,t:1526930159294};\\\", \\\"{x:751,y:533,t:1526930159310};\\\", \\\"{x:766,y:530,t:1526930159326};\\\", \\\"{x:785,y:525,t:1526930159342};\\\", \\\"{x:795,y:522,t:1526930159361};\\\", \\\"{x:804,y:519,t:1526930159376};\\\", \\\"{x:812,y:517,t:1526930159395};\\\", \\\"{x:816,y:515,t:1526930159410};\\\", \\\"{x:818,y:515,t:1526930159426};\\\", \\\"{x:820,y:514,t:1526930159443};\\\", \\\"{x:821,y:513,t:1526930159467};\\\", \\\"{x:817,y:518,t:1526930160133};\\\", \\\"{x:810,y:523,t:1526930160143};\\\", \\\"{x:795,y:538,t:1526930160162};\\\", \\\"{x:780,y:550,t:1526930160177};\\\", \\\"{x:763,y:564,t:1526930160195};\\\", \\\"{x:744,y:578,t:1526930160211};\\\", \\\"{x:716,y:599,t:1526930160229};\\\", \\\"{x:700,y:612,t:1526930160245};\\\", \\\"{x:686,y:625,t:1526930160260};\\\", \\\"{x:669,y:636,t:1526930160277};\\\", \\\"{x:653,y:648,t:1526930160294};\\\", \\\"{x:638,y:658,t:1526930160310};\\\", \\\"{x:628,y:666,t:1526930160327};\\\", \\\"{x:615,y:675,t:1526930160344};\\\", \\\"{x:607,y:682,t:1526930160359};\\\", \\\"{x:599,y:688,t:1526930160377};\\\", \\\"{x:590,y:694,t:1526930160394};\\\", \\\"{x:584,y:698,t:1526930160410};\\\", \\\"{x:575,y:704,t:1526930160427};\\\", \\\"{x:571,y:706,t:1526930160444};\\\", \\\"{x:567,y:709,t:1526930160460};\\\", \\\"{x:566,y:710,t:1526930160477};\\\", \\\"{x:563,y:711,t:1526930160494};\\\", \\\"{x:560,y:713,t:1526930160510};\\\", \\\"{x:556,y:715,t:1526930160527};\\\", \\\"{x:553,y:717,t:1526930160544};\\\", \\\"{x:551,y:717,t:1526930160561};\\\", \\\"{x:549,y:719,t:1526930160577};\\\", \\\"{x:546,y:720,t:1526930160595};\\\", \\\"{x:545,y:719,t:1526930160749};\\\", \\\"{x:553,y:712,t:1526930160761};\\\", \\\"{x:571,y:696,t:1526930160776};\\\", \\\"{x:590,y:679,t:1526930160794};\\\", \\\"{x:627,y:653,t:1526930160811};\\\", \\\"{x:645,y:639,t:1526930160827};\\\", \\\"{x:660,y:625,t:1526930160844};\\\", \\\"{x:670,y:612,t:1526930160860};\\\", \\\"{x:676,y:604,t:1526930160877};\\\", \\\"{x:686,y:593,t:1526930160894};\\\", \\\"{x:695,y:583,t:1526930160911};\\\", \\\"{x:705,y:575,t:1526930160927};\\\", \\\"{x:716,y:567,t:1526930160944};\\\", \\\"{x:730,y:558,t:1526930160962};\\\", \\\"{x:743,y:551,t:1526930160979};\\\", \\\"{x:751,y:547,t:1526930160994};\\\", \\\"{x:759,y:543,t:1526930161011};\\\", \\\"{x:766,y:540,t:1526930161028};\\\", \\\"{x:775,y:539,t:1526930161043};\\\", \\\"{x:779,y:538,t:1526930161061};\\\", \\\"{x:784,y:536,t:1526930161077};\\\", \\\"{x:790,y:535,t:1526930161094};\\\", \\\"{x:800,y:534,t:1526930161111};\\\", \\\"{x:806,y:532,t:1526930161128};\\\", \\\"{x:811,y:530,t:1526930161144};\\\", \\\"{x:812,y:529,t:1526930161161};\\\", \\\"{x:815,y:528,t:1526930161178};\\\", \\\"{x:820,y:524,t:1526930161195};\\\", \\\"{x:824,y:521,t:1526930161211};\\\", \\\"{x:827,y:517,t:1526930161228};\\\", \\\"{x:830,y:515,t:1526930161244};\\\", \\\"{x:833,y:511,t:1526930161261};\\\", \\\"{x:835,y:510,t:1526930161278};\\\", \\\"{x:836,y:508,t:1526930161294};\\\", \\\"{x:837,y:507,t:1526930161311};\\\", \\\"{x:837,y:505,t:1526930161328};\\\", \\\"{x:839,y:504,t:1526930161345};\\\", \\\"{x:840,y:502,t:1526930161364};\\\", \\\"{x:841,y:501,t:1526930161378};\\\", \\\"{x:838,y:502,t:1526930161755};\\\", \\\"{x:830,y:508,t:1526930161763};\\\", \\\"{x:823,y:512,t:1526930161778};\\\", \\\"{x:789,y:529,t:1526930161796};\\\", \\\"{x:752,y:550,t:1526930161811};\\\", \\\"{x:712,y:571,t:1526930161828};\\\", \\\"{x:677,y:589,t:1526930161845};\\\", \\\"{x:648,y:604,t:1526930161862};\\\", \\\"{x:627,y:615,t:1526930161879};\\\", \\\"{x:617,y:621,t:1526930161895};\\\", \\\"{x:610,y:625,t:1526930161911};\\\", \\\"{x:607,y:628,t:1526930161928};\\\", \\\"{x:604,y:631,t:1526930161945};\\\", \\\"{x:602,y:636,t:1526930161961};\\\", \\\"{x:600,y:641,t:1526930161978};\\\", \\\"{x:597,y:649,t:1526930161995};\\\", \\\"{x:596,y:657,t:1526930162012};\\\", \\\"{x:591,y:666,t:1526930162028};\\\", \\\"{x:590,y:688,t:1526930162045};\\\", \\\"{x:588,y:696,t:1526930162063};\\\", \\\"{x:587,y:701,t:1526930162078};\\\", \\\"{x:584,y:707,t:1526930162095};\\\", \\\"{x:583,y:711,t:1526930162113};\\\", \\\"{x:581,y:716,t:1526930162128};\\\", \\\"{x:581,y:717,t:1526930162284};\\\", \\\"{x:580,y:718,t:1526930162296};\\\", \\\"{x:580,y:719,t:1526930162313};\\\", \\\"{x:579,y:719,t:1526930162332};\\\", \\\"{x:578,y:719,t:1526930162345};\\\", \\\"{x:575,y:720,t:1526930162362};\\\", \\\"{x:572,y:722,t:1526930162378};\\\", \\\"{x:566,y:725,t:1526930162395};\\\", \\\"{x:561,y:728,t:1526930162413};\\\", \\\"{x:557,y:731,t:1526930162429};\\\", \\\"{x:555,y:733,t:1526930162445};\\\", \\\"{x:553,y:734,t:1526930162462};\\\", \\\"{x:552,y:734,t:1526930162479};\\\", \\\"{x:552,y:736,t:1526930162500};\\\", \\\"{x:551,y:736,t:1526930162524};\\\" ] }, { \\\"rt\\\": 16469, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 504109, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -B -B -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:551,y:737,t:1526930165884};\\\", \\\"{x:559,y:737,t:1526930165899};\\\", \\\"{x:592,y:740,t:1526930165921};\\\", \\\"{x:626,y:742,t:1526930165932};\\\", \\\"{x:676,y:743,t:1526930165948};\\\", \\\"{x:735,y:745,t:1526930165965};\\\", \\\"{x:789,y:745,t:1526930165981};\\\", \\\"{x:839,y:745,t:1526930165998};\\\", \\\"{x:878,y:745,t:1526930166015};\\\", \\\"{x:910,y:745,t:1526930166031};\\\", \\\"{x:935,y:746,t:1526930166048};\\\", \\\"{x:956,y:750,t:1526930166065};\\\", \\\"{x:981,y:754,t:1526930166082};\\\", \\\"{x:1002,y:758,t:1526930166098};\\\", \\\"{x:1044,y:764,t:1526930166115};\\\", \\\"{x:1085,y:774,t:1526930166131};\\\", \\\"{x:1128,y:782,t:1526930166148};\\\", \\\"{x:1165,y:788,t:1526930166165};\\\", \\\"{x:1202,y:794,t:1526930166182};\\\", \\\"{x:1233,y:800,t:1526930166199};\\\", \\\"{x:1260,y:805,t:1526930166215};\\\", \\\"{x:1281,y:807,t:1526930166231};\\\", \\\"{x:1296,y:810,t:1526930166248};\\\", \\\"{x:1309,y:810,t:1526930166266};\\\", \\\"{x:1321,y:810,t:1526930166282};\\\", \\\"{x:1331,y:806,t:1526930166299};\\\", \\\"{x:1343,y:800,t:1526930166316};\\\", \\\"{x:1349,y:797,t:1526930166332};\\\", \\\"{x:1354,y:792,t:1526930166349};\\\", \\\"{x:1357,y:786,t:1526930166366};\\\", \\\"{x:1362,y:777,t:1526930166383};\\\", \\\"{x:1363,y:767,t:1526930166398};\\\", \\\"{x:1364,y:757,t:1526930166415};\\\", \\\"{x:1364,y:746,t:1526930166432};\\\", \\\"{x:1364,y:733,t:1526930166449};\\\", \\\"{x:1364,y:725,t:1526930166466};\\\", \\\"{x:1364,y:719,t:1526930166483};\\\", \\\"{x:1364,y:715,t:1526930166499};\\\", \\\"{x:1364,y:713,t:1526930166516};\\\", \\\"{x:1364,y:712,t:1526930166533};\\\", \\\"{x:1364,y:711,t:1526930166564};\\\", \\\"{x:1364,y:709,t:1526930166580};\\\", \\\"{x:1364,y:708,t:1526930166596};\\\", \\\"{x:1364,y:707,t:1526930166620};\\\", \\\"{x:1364,y:705,t:1526930166635};\\\", \\\"{x:1363,y:705,t:1526930166749};\\\", \\\"{x:1362,y:704,t:1526930166766};\\\", \\\"{x:1361,y:704,t:1526930166783};\\\", \\\"{x:1359,y:704,t:1526930166799};\\\", \\\"{x:1357,y:704,t:1526930166815};\\\", \\\"{x:1355,y:704,t:1526930166833};\\\", \\\"{x:1352,y:702,t:1526930166849};\\\", \\\"{x:1349,y:701,t:1526930166868};\\\", \\\"{x:1347,y:701,t:1526930166906};\\\", \\\"{x:1346,y:701,t:1526930166931};\\\", \\\"{x:1344,y:701,t:1526930166946};\\\", \\\"{x:1344,y:702,t:1526930168270};\\\", \\\"{x:1344,y:704,t:1526930168284};\\\", \\\"{x:1344,y:705,t:1526930168300};\\\", \\\"{x:1344,y:707,t:1526930169899};\\\", \\\"{x:1344,y:708,t:1526930169906};\\\", \\\"{x:1344,y:710,t:1526930169917};\\\", \\\"{x:1344,y:714,t:1526930169935};\\\", \\\"{x:1344,y:715,t:1526930169951};\\\", \\\"{x:1344,y:717,t:1526930169967};\\\", \\\"{x:1344,y:718,t:1526930169984};\\\", \\\"{x:1344,y:719,t:1526930170001};\\\", \\\"{x:1344,y:720,t:1526930170732};\\\", \\\"{x:1345,y:722,t:1526930170739};\\\", \\\"{x:1345,y:724,t:1526930170752};\\\", \\\"{x:1345,y:728,t:1526930170769};\\\", \\\"{x:1346,y:731,t:1526930170785};\\\", \\\"{x:1347,y:734,t:1526930170802};\\\", \\\"{x:1347,y:735,t:1526930170819};\\\", \\\"{x:1348,y:739,t:1526930170835};\\\", \\\"{x:1349,y:743,t:1526930170851};\\\", \\\"{x:1350,y:745,t:1526930170869};\\\", \\\"{x:1350,y:748,t:1526930170885};\\\", \\\"{x:1350,y:749,t:1526930170902};\\\", \\\"{x:1351,y:752,t:1526930170919};\\\", \\\"{x:1352,y:754,t:1526930170935};\\\", \\\"{x:1353,y:756,t:1526930170952};\\\", \\\"{x:1353,y:757,t:1526930170970};\\\", \\\"{x:1353,y:758,t:1526930170985};\\\", \\\"{x:1353,y:759,t:1526930171002};\\\", \\\"{x:1353,y:760,t:1526930171019};\\\", \\\"{x:1353,y:762,t:1526930171061};\\\", \\\"{x:1353,y:763,t:1526930171388};\\\", \\\"{x:1353,y:764,t:1526930171402};\\\", \\\"{x:1353,y:766,t:1526930171420};\\\", \\\"{x:1353,y:768,t:1526930171436};\\\", \\\"{x:1353,y:769,t:1526930171452};\\\", \\\"{x:1353,y:770,t:1526930171469};\\\", \\\"{x:1353,y:771,t:1526930171486};\\\", \\\"{x:1353,y:773,t:1526930171502};\\\", \\\"{x:1353,y:774,t:1526930171519};\\\", \\\"{x:1353,y:775,t:1526930171539};\\\", \\\"{x:1353,y:776,t:1526930171563};\\\", \\\"{x:1351,y:777,t:1526930171780};\\\", \\\"{x:1350,y:777,t:1526930171796};\\\", \\\"{x:1347,y:777,t:1526930171804};\\\", \\\"{x:1343,y:777,t:1526930171819};\\\", \\\"{x:1314,y:775,t:1526930171835};\\\", \\\"{x:1282,y:768,t:1526930171853};\\\", \\\"{x:1206,y:756,t:1526930171869};\\\", \\\"{x:1119,y:739,t:1526930171886};\\\", \\\"{x:1044,y:728,t:1526930171904};\\\", \\\"{x:976,y:716,t:1526930171919};\\\", \\\"{x:920,y:708,t:1526930171936};\\\", \\\"{x:877,y:699,t:1526930171953};\\\", \\\"{x:848,y:691,t:1526930171969};\\\", \\\"{x:829,y:685,t:1526930171987};\\\", \\\"{x:813,y:680,t:1526930172003};\\\", \\\"{x:812,y:680,t:1526930172019};\\\", \\\"{x:810,y:678,t:1526930172036};\\\", \\\"{x:809,y:676,t:1526930172083};\\\", \\\"{x:809,y:675,t:1526930172092};\\\", \\\"{x:809,y:671,t:1526930172103};\\\", \\\"{x:810,y:662,t:1526930172119};\\\", \\\"{x:816,y:650,t:1526930172136};\\\", \\\"{x:821,y:638,t:1526930172153};\\\", \\\"{x:827,y:622,t:1526930172171};\\\", \\\"{x:830,y:604,t:1526930172186};\\\", \\\"{x:832,y:591,t:1526930172203};\\\", \\\"{x:832,y:576,t:1526930172219};\\\", \\\"{x:832,y:569,t:1526930172237};\\\", \\\"{x:832,y:565,t:1526930172254};\\\", \\\"{x:829,y:558,t:1526930172271};\\\", \\\"{x:825,y:554,t:1526930172287};\\\", \\\"{x:816,y:548,t:1526930172304};\\\", \\\"{x:801,y:543,t:1526930172320};\\\", \\\"{x:778,y:537,t:1526930172337};\\\", \\\"{x:738,y:534,t:1526930172353};\\\", \\\"{x:680,y:526,t:1526930172371};\\\", \\\"{x:573,y:521,t:1526930172386};\\\", \\\"{x:500,y:521,t:1526930172404};\\\", \\\"{x:442,y:521,t:1526930172421};\\\", \\\"{x:410,y:521,t:1526930172436};\\\", \\\"{x:384,y:521,t:1526930172453};\\\", \\\"{x:369,y:521,t:1526930172469};\\\", \\\"{x:363,y:523,t:1526930172486};\\\", \\\"{x:359,y:526,t:1526930172504};\\\", \\\"{x:355,y:530,t:1526930172519};\\\", \\\"{x:347,y:537,t:1526930172538};\\\", \\\"{x:339,y:542,t:1526930172553};\\\", \\\"{x:321,y:550,t:1526930172570};\\\", \\\"{x:293,y:558,t:1526930172588};\\\", \\\"{x:278,y:563,t:1526930172605};\\\", \\\"{x:270,y:571,t:1526930172621};\\\", \\\"{x:261,y:575,t:1526930172637};\\\", \\\"{x:254,y:579,t:1526930172653};\\\", \\\"{x:249,y:580,t:1526930172671};\\\", \\\"{x:246,y:582,t:1526930172687};\\\", \\\"{x:241,y:583,t:1526930172703};\\\", \\\"{x:235,y:586,t:1526930172720};\\\", \\\"{x:229,y:587,t:1526930172738};\\\", \\\"{x:223,y:588,t:1526930172753};\\\", \\\"{x:216,y:591,t:1526930172771};\\\", \\\"{x:208,y:591,t:1526930172787};\\\", \\\"{x:199,y:594,t:1526930172805};\\\", \\\"{x:192,y:595,t:1526930172821};\\\", \\\"{x:188,y:596,t:1526930172838};\\\", \\\"{x:184,y:596,t:1526930172855};\\\", \\\"{x:181,y:598,t:1526930172870};\\\", \\\"{x:177,y:599,t:1526930172887};\\\", \\\"{x:174,y:599,t:1526930172905};\\\", \\\"{x:169,y:601,t:1526930172922};\\\", \\\"{x:167,y:603,t:1526930172938};\\\", \\\"{x:164,y:604,t:1526930172954};\\\", \\\"{x:162,y:606,t:1526930172970};\\\", \\\"{x:161,y:607,t:1526930172987};\\\", \\\"{x:160,y:608,t:1526930173004};\\\", \\\"{x:159,y:609,t:1526930173020};\\\", \\\"{x:159,y:611,t:1526930173060};\\\", \\\"{x:159,y:609,t:1526930173476};\\\", \\\"{x:159,y:607,t:1526930173488};\\\", \\\"{x:159,y:599,t:1526930173507};\\\", \\\"{x:159,y:591,t:1526930173521};\\\", \\\"{x:159,y:582,t:1526930173537};\\\", \\\"{x:159,y:575,t:1526930173554};\\\", \\\"{x:160,y:565,t:1526930173571};\\\", \\\"{x:160,y:560,t:1526930173588};\\\", \\\"{x:160,y:555,t:1526930173605};\\\", \\\"{x:160,y:551,t:1526930173622};\\\", \\\"{x:160,y:547,t:1526930173637};\\\", \\\"{x:160,y:545,t:1526930173655};\\\", \\\"{x:160,y:543,t:1526930173672};\\\", \\\"{x:160,y:541,t:1526930173687};\\\", \\\"{x:159,y:539,t:1526930173704};\\\", \\\"{x:162,y:543,t:1526930174219};\\\", \\\"{x:174,y:550,t:1526930174227};\\\", \\\"{x:184,y:557,t:1526930174239};\\\", \\\"{x:217,y:571,t:1526930174255};\\\", \\\"{x:266,y:590,t:1526930174271};\\\", \\\"{x:331,y:613,t:1526930174289};\\\", \\\"{x:403,y:635,t:1526930174306};\\\", \\\"{x:464,y:652,t:1526930174322};\\\", \\\"{x:548,y:676,t:1526930174339};\\\", \\\"{x:589,y:686,t:1526930174354};\\\", \\\"{x:626,y:697,t:1526930174372};\\\", \\\"{x:648,y:700,t:1526930174389};\\\", \\\"{x:666,y:709,t:1526930174406};\\\", \\\"{x:687,y:715,t:1526930174422};\\\", \\\"{x:706,y:720,t:1526930174438};\\\", \\\"{x:722,y:724,t:1526930174456};\\\", \\\"{x:745,y:729,t:1526930174472};\\\", \\\"{x:773,y:732,t:1526930174488};\\\", \\\"{x:807,y:737,t:1526930174506};\\\", \\\"{x:844,y:740,t:1526930174522};\\\", \\\"{x:889,y:746,t:1526930174539};\\\", \\\"{x:913,y:746,t:1526930174555};\\\", \\\"{x:933,y:749,t:1526930174572};\\\", \\\"{x:945,y:750,t:1526930174588};\\\", \\\"{x:954,y:750,t:1526930174606};\\\", \\\"{x:961,y:752,t:1526930174622};\\\", \\\"{x:966,y:753,t:1526930174639};\\\", \\\"{x:967,y:753,t:1526930174656};\\\", \\\"{x:968,y:753,t:1526930174672};\\\", \\\"{x:968,y:752,t:1526930174908};\\\", \\\"{x:969,y:752,t:1526930174948};\\\", \\\"{x:972,y:752,t:1526930174955};\\\", \\\"{x:975,y:752,t:1526930174973};\\\", \\\"{x:980,y:752,t:1526930174989};\\\", \\\"{x:989,y:752,t:1526930175007};\\\", \\\"{x:1004,y:752,t:1526930175023};\\\", \\\"{x:1023,y:752,t:1526930175039};\\\", \\\"{x:1047,y:752,t:1526930175056};\\\", \\\"{x:1078,y:760,t:1526930175073};\\\", \\\"{x:1118,y:767,t:1526930175089};\\\", \\\"{x:1153,y:775,t:1526930175106};\\\", \\\"{x:1201,y:781,t:1526930175123};\\\", \\\"{x:1254,y:789,t:1526930175140};\\\", \\\"{x:1280,y:793,t:1526930175156};\\\", \\\"{x:1298,y:795,t:1526930175173};\\\", \\\"{x:1312,y:795,t:1526930175191};\\\", \\\"{x:1321,y:796,t:1526930175206};\\\", \\\"{x:1328,y:796,t:1526930175223};\\\", \\\"{x:1338,y:796,t:1526930175240};\\\", \\\"{x:1349,y:796,t:1526930175257};\\\", \\\"{x:1363,y:796,t:1526930175273};\\\", \\\"{x:1376,y:796,t:1526930175290};\\\", \\\"{x:1386,y:796,t:1526930175306};\\\", \\\"{x:1393,y:796,t:1526930175324};\\\", \\\"{x:1393,y:795,t:1526930175340};\\\", \\\"{x:1394,y:795,t:1526930175364};\\\", \\\"{x:1394,y:793,t:1526930175508};\\\", \\\"{x:1391,y:790,t:1526930175524};\\\", \\\"{x:1384,y:785,t:1526930175539};\\\", \\\"{x:1377,y:782,t:1526930175556};\\\", \\\"{x:1369,y:778,t:1526930175573};\\\", \\\"{x:1365,y:777,t:1526930175590};\\\", \\\"{x:1363,y:777,t:1526930175606};\\\", \\\"{x:1362,y:775,t:1526930175623};\\\", \\\"{x:1361,y:775,t:1526930175644};\\\", \\\"{x:1360,y:774,t:1526930175716};\\\", \\\"{x:1359,y:774,t:1526930175732};\\\", \\\"{x:1359,y:773,t:1526930175740};\\\", \\\"{x:1359,y:772,t:1526930175758};\\\", \\\"{x:1358,y:771,t:1526930175787};\\\", \\\"{x:1357,y:771,t:1526930175836};\\\", \\\"{x:1357,y:770,t:1526930175851};\\\", \\\"{x:1356,y:769,t:1526930175875};\\\", \\\"{x:1355,y:768,t:1526930175892};\\\", \\\"{x:1354,y:768,t:1526930175908};\\\", \\\"{x:1352,y:767,t:1526930175932};\\\", \\\"{x:1351,y:767,t:1526930175957};\\\", \\\"{x:1351,y:766,t:1526930175973};\\\", \\\"{x:1349,y:766,t:1526930175990};\\\", \\\"{x:1348,y:766,t:1526930176007};\\\", \\\"{x:1347,y:766,t:1526930176036};\\\", \\\"{x:1346,y:766,t:1526930176060};\\\", \\\"{x:1345,y:768,t:1526930176099};\\\", \\\"{x:1345,y:772,t:1526930176109};\\\", \\\"{x:1345,y:778,t:1526930176123};\\\", \\\"{x:1345,y:784,t:1526930176140};\\\", \\\"{x:1345,y:793,t:1526930176157};\\\", \\\"{x:1345,y:800,t:1526930176175};\\\", \\\"{x:1345,y:804,t:1526930176190};\\\", \\\"{x:1345,y:809,t:1526930176207};\\\", \\\"{x:1345,y:813,t:1526930176224};\\\", \\\"{x:1345,y:818,t:1526930176240};\\\", \\\"{x:1345,y:823,t:1526930176257};\\\", \\\"{x:1345,y:826,t:1526930176275};\\\", \\\"{x:1345,y:830,t:1526930176291};\\\", \\\"{x:1345,y:832,t:1526930176308};\\\", \\\"{x:1345,y:834,t:1526930176324};\\\", \\\"{x:1345,y:837,t:1526930176341};\\\", \\\"{x:1345,y:840,t:1526930176357};\\\", \\\"{x:1345,y:844,t:1526930176374};\\\", \\\"{x:1345,y:852,t:1526930176390};\\\", \\\"{x:1345,y:858,t:1526930176407};\\\", \\\"{x:1345,y:862,t:1526930176425};\\\", \\\"{x:1345,y:869,t:1526930176441};\\\", \\\"{x:1345,y:878,t:1526930176457};\\\", \\\"{x:1345,y:887,t:1526930176475};\\\", \\\"{x:1345,y:898,t:1526930176491};\\\", \\\"{x:1346,y:909,t:1526930176507};\\\", \\\"{x:1346,y:919,t:1526930176524};\\\", \\\"{x:1347,y:923,t:1526930176541};\\\", \\\"{x:1347,y:928,t:1526930176557};\\\", \\\"{x:1349,y:936,t:1526930176574};\\\", \\\"{x:1349,y:941,t:1526930176592};\\\", \\\"{x:1350,y:947,t:1526930176608};\\\", \\\"{x:1352,y:954,t:1526930176625};\\\", \\\"{x:1352,y:959,t:1526930176641};\\\", \\\"{x:1353,y:961,t:1526930176657};\\\", \\\"{x:1354,y:962,t:1526930176674};\\\", \\\"{x:1354,y:964,t:1526930176692};\\\", \\\"{x:1354,y:961,t:1526930177541};\\\", \\\"{x:1351,y:951,t:1526930177559};\\\", \\\"{x:1348,y:942,t:1526930177575};\\\", \\\"{x:1348,y:932,t:1526930177591};\\\", \\\"{x:1343,y:919,t:1526930177608};\\\", \\\"{x:1339,y:907,t:1526930177625};\\\", \\\"{x:1338,y:898,t:1526930177642};\\\", \\\"{x:1335,y:890,t:1526930177659};\\\", \\\"{x:1332,y:877,t:1526930177676};\\\", \\\"{x:1332,y:873,t:1526930177691};\\\", \\\"{x:1331,y:867,t:1526930177708};\\\", \\\"{x:1330,y:863,t:1526930177725};\\\", \\\"{x:1329,y:857,t:1526930177742};\\\", \\\"{x:1329,y:851,t:1526930177758};\\\", \\\"{x:1329,y:847,t:1526930177775};\\\", \\\"{x:1329,y:843,t:1526930177792};\\\", \\\"{x:1329,y:840,t:1526930177808};\\\", \\\"{x:1329,y:837,t:1526930177825};\\\", \\\"{x:1329,y:834,t:1526930177842};\\\", \\\"{x:1330,y:829,t:1526930177859};\\\", \\\"{x:1332,y:822,t:1526930177875};\\\", \\\"{x:1333,y:818,t:1526930177892};\\\", \\\"{x:1335,y:813,t:1526930177908};\\\", \\\"{x:1336,y:809,t:1526930177925};\\\", \\\"{x:1337,y:803,t:1526930177943};\\\", \\\"{x:1338,y:800,t:1526930177959};\\\", \\\"{x:1338,y:796,t:1526930177975};\\\", \\\"{x:1339,y:793,t:1526930177992};\\\", \\\"{x:1340,y:789,t:1526930178008};\\\", \\\"{x:1340,y:786,t:1526930178026};\\\", \\\"{x:1340,y:783,t:1526930178042};\\\", \\\"{x:1341,y:780,t:1526930178059};\\\", \\\"{x:1342,y:776,t:1526930178076};\\\", \\\"{x:1342,y:774,t:1526930178092};\\\", \\\"{x:1343,y:772,t:1526930178109};\\\", \\\"{x:1343,y:771,t:1526930178131};\\\", \\\"{x:1343,y:770,t:1526930178142};\\\", \\\"{x:1343,y:769,t:1526930178159};\\\", \\\"{x:1343,y:768,t:1526930178176};\\\", \\\"{x:1344,y:767,t:1526930178193};\\\", \\\"{x:1344,y:766,t:1526930178209};\\\", \\\"{x:1345,y:766,t:1526930178228};\\\", \\\"{x:1345,y:765,t:1526930178261};\\\", \\\"{x:1342,y:765,t:1526930180093};\\\", \\\"{x:1324,y:765,t:1526930180111};\\\", \\\"{x:1300,y:765,t:1526930180128};\\\", \\\"{x:1275,y:765,t:1526930180143};\\\", \\\"{x:1253,y:765,t:1526930180160};\\\", \\\"{x:1234,y:765,t:1526930180177};\\\", \\\"{x:1222,y:765,t:1526930180194};\\\", \\\"{x:1208,y:765,t:1526930180211};\\\", \\\"{x:1184,y:767,t:1526930180228};\\\", \\\"{x:1162,y:770,t:1526930180244};\\\", \\\"{x:1135,y:770,t:1526930180261};\\\", \\\"{x:1104,y:770,t:1526930180278};\\\", \\\"{x:1072,y:770,t:1526930180293};\\\", \\\"{x:1032,y:770,t:1526930180311};\\\", \\\"{x:996,y:770,t:1526930180327};\\\", \\\"{x:966,y:770,t:1526930180344};\\\", \\\"{x:940,y:770,t:1526930180360};\\\", \\\"{x:924,y:772,t:1526930180377};\\\", \\\"{x:908,y:772,t:1526930180393};\\\", \\\"{x:893,y:772,t:1526930180410};\\\", \\\"{x:873,y:772,t:1526930180427};\\\", \\\"{x:855,y:772,t:1526930180444};\\\", \\\"{x:834,y:772,t:1526930180461};\\\", \\\"{x:809,y:772,t:1526930180477};\\\", \\\"{x:775,y:772,t:1526930180494};\\\", \\\"{x:728,y:772,t:1526930180510};\\\", \\\"{x:686,y:772,t:1526930180528};\\\", \\\"{x:644,y:772,t:1526930180544};\\\", \\\"{x:614,y:772,t:1526930180561};\\\", \\\"{x:589,y:772,t:1526930180577};\\\", \\\"{x:569,y:772,t:1526930180594};\\\", \\\"{x:559,y:772,t:1526930180611};\\\", \\\"{x:554,y:772,t:1526930180627};\\\", \\\"{x:553,y:769,t:1526930180747};\\\", \\\"{x:552,y:765,t:1526930180760};\\\", \\\"{x:549,y:759,t:1526930180778};\\\", \\\"{x:547,y:753,t:1526930180795};\\\", \\\"{x:544,y:748,t:1526930180810};\\\", \\\"{x:544,y:742,t:1526930180826};\\\", \\\"{x:543,y:742,t:1526930180837};\\\", \\\"{x:542,y:740,t:1526930180855};\\\", \\\"{x:542,y:739,t:1526930180871};\\\", \\\"{x:542,y:738,t:1526930180888};\\\" ] }, { \\\"rt\\\": 28841, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 534232, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -X -X -B -O -Z -04 PM-F -F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:739,t:1526930183603};\\\", \\\"{x:558,y:743,t:1526930183612};\\\", \\\"{x:597,y:755,t:1526930183634};\\\", \\\"{x:652,y:768,t:1526930183645};\\\", \\\"{x:727,y:779,t:1526930183662};\\\", \\\"{x:810,y:792,t:1526930183680};\\\", \\\"{x:891,y:803,t:1526930183696};\\\", \\\"{x:971,y:822,t:1526930183713};\\\", \\\"{x:1054,y:833,t:1526930183730};\\\", \\\"{x:1132,y:844,t:1526930183746};\\\", \\\"{x:1223,y:857,t:1526930183763};\\\", \\\"{x:1284,y:865,t:1526930183780};\\\", \\\"{x:1363,y:881,t:1526930183796};\\\", \\\"{x:1432,y:890,t:1526930183813};\\\", \\\"{x:1484,y:899,t:1526930183831};\\\", \\\"{x:1516,y:902,t:1526930183846};\\\", \\\"{x:1543,y:902,t:1526930183863};\\\", \\\"{x:1564,y:902,t:1526930183880};\\\", \\\"{x:1572,y:902,t:1526930183897};\\\", \\\"{x:1576,y:902,t:1526930183913};\\\", \\\"{x:1576,y:901,t:1526930185989};\\\", \\\"{x:1576,y:900,t:1526930185999};\\\", \\\"{x:1576,y:898,t:1526930186015};\\\", \\\"{x:1576,y:895,t:1526930186032};\\\", \\\"{x:1576,y:890,t:1526930186049};\\\", \\\"{x:1577,y:885,t:1526930186066};\\\", \\\"{x:1580,y:878,t:1526930186083};\\\", \\\"{x:1583,y:873,t:1526930186099};\\\", \\\"{x:1590,y:858,t:1526930186115};\\\", \\\"{x:1591,y:846,t:1526930186133};\\\", \\\"{x:1593,y:832,t:1526930186149};\\\", \\\"{x:1593,y:817,t:1526930186166};\\\", \\\"{x:1593,y:802,t:1526930186183};\\\", \\\"{x:1593,y:784,t:1526930186199};\\\", \\\"{x:1593,y:770,t:1526930186215};\\\", \\\"{x:1593,y:756,t:1526930186233};\\\", \\\"{x:1593,y:744,t:1526930186249};\\\", \\\"{x:1595,y:731,t:1526930186265};\\\", \\\"{x:1597,y:721,t:1526930186282};\\\", \\\"{x:1599,y:709,t:1526930186299};\\\", \\\"{x:1602,y:701,t:1526930186315};\\\", \\\"{x:1604,y:695,t:1526930186332};\\\", \\\"{x:1606,y:690,t:1526930186349};\\\", \\\"{x:1608,y:684,t:1526930186366};\\\", \\\"{x:1610,y:682,t:1526930186383};\\\", \\\"{x:1613,y:679,t:1526930186400};\\\", \\\"{x:1616,y:677,t:1526930186417};\\\", \\\"{x:1618,y:675,t:1526930186432};\\\", \\\"{x:1620,y:674,t:1526930186449};\\\", \\\"{x:1621,y:674,t:1526930186588};\\\", \\\"{x:1622,y:675,t:1526930186600};\\\", \\\"{x:1622,y:681,t:1526930186617};\\\", \\\"{x:1622,y:684,t:1526930186633};\\\", \\\"{x:1622,y:685,t:1526930186649};\\\", \\\"{x:1622,y:687,t:1526930186667};\\\", \\\"{x:1622,y:689,t:1526930186740};\\\", \\\"{x:1621,y:691,t:1526930186892};\\\", \\\"{x:1619,y:691,t:1526930186899};\\\", \\\"{x:1616,y:693,t:1526930186919};\\\", \\\"{x:1613,y:695,t:1526930186933};\\\", \\\"{x:1610,y:696,t:1526930186949};\\\", \\\"{x:1609,y:699,t:1526930186966};\\\", \\\"{x:1607,y:702,t:1526930186983};\\\", \\\"{x:1606,y:705,t:1526930187000};\\\", \\\"{x:1606,y:708,t:1526930187016};\\\", \\\"{x:1606,y:710,t:1526930187033};\\\", \\\"{x:1605,y:711,t:1526930187049};\\\", \\\"{x:1605,y:713,t:1526930187066};\\\", \\\"{x:1605,y:714,t:1526930187083};\\\", \\\"{x:1605,y:716,t:1526930187100};\\\", \\\"{x:1605,y:718,t:1526930187117};\\\", \\\"{x:1605,y:720,t:1526930187139};\\\", \\\"{x:1605,y:721,t:1526930187163};\\\", \\\"{x:1605,y:723,t:1526930187170};\\\", \\\"{x:1607,y:725,t:1526930187183};\\\", \\\"{x:1609,y:729,t:1526930187200};\\\", \\\"{x:1610,y:731,t:1526930187216};\\\", \\\"{x:1612,y:733,t:1526930187233};\\\", \\\"{x:1613,y:738,t:1526930187250};\\\", \\\"{x:1617,y:748,t:1526930187266};\\\", \\\"{x:1620,y:756,t:1526930187283};\\\", \\\"{x:1622,y:765,t:1526930187300};\\\", \\\"{x:1626,y:779,t:1526930187316};\\\", \\\"{x:1629,y:787,t:1526930187334};\\\", \\\"{x:1630,y:792,t:1526930187350};\\\", \\\"{x:1631,y:806,t:1526930187366};\\\", \\\"{x:1635,y:817,t:1526930187383};\\\", \\\"{x:1636,y:823,t:1526930187400};\\\", \\\"{x:1638,y:829,t:1526930187416};\\\", \\\"{x:1639,y:835,t:1526930187433};\\\", \\\"{x:1639,y:840,t:1526930187451};\\\", \\\"{x:1640,y:846,t:1526930187467};\\\", \\\"{x:1640,y:848,t:1526930187483};\\\", \\\"{x:1640,y:849,t:1526930187501};\\\", \\\"{x:1640,y:850,t:1526930187523};\\\", \\\"{x:1640,y:851,t:1526930187588};\\\", \\\"{x:1640,y:853,t:1526930187601};\\\", \\\"{x:1640,y:854,t:1526930187627};\\\", \\\"{x:1639,y:856,t:1526930187652};\\\", \\\"{x:1638,y:856,t:1526930187684};\\\", \\\"{x:1637,y:856,t:1526930187708};\\\", \\\"{x:1636,y:856,t:1526930187740};\\\", \\\"{x:1634,y:856,t:1526930187795};\\\", \\\"{x:1631,y:853,t:1526930187803};\\\", \\\"{x:1629,y:844,t:1526930187818};\\\", \\\"{x:1625,y:830,t:1526930187835};\\\", \\\"{x:1619,y:811,t:1526930187851};\\\", \\\"{x:1613,y:796,t:1526930187868};\\\", \\\"{x:1610,y:787,t:1526930187885};\\\", \\\"{x:1607,y:779,t:1526930187901};\\\", \\\"{x:1606,y:773,t:1526930187918};\\\", \\\"{x:1603,y:766,t:1526930187935};\\\", \\\"{x:1603,y:765,t:1526930187951};\\\", \\\"{x:1603,y:763,t:1526930187968};\\\", \\\"{x:1603,y:762,t:1526930187985};\\\", \\\"{x:1602,y:762,t:1526930188001};\\\", \\\"{x:1602,y:760,t:1526930188035};\\\", \\\"{x:1602,y:763,t:1526930188340};\\\", \\\"{x:1602,y:764,t:1526930188352};\\\", \\\"{x:1602,y:770,t:1526930188368};\\\", \\\"{x:1604,y:778,t:1526930188385};\\\", \\\"{x:1604,y:783,t:1526930188402};\\\", \\\"{x:1606,y:787,t:1526930188419};\\\", \\\"{x:1606,y:790,t:1526930188434};\\\", \\\"{x:1608,y:794,t:1526930188451};\\\", \\\"{x:1608,y:798,t:1526930188468};\\\", \\\"{x:1608,y:800,t:1526930188484};\\\", \\\"{x:1609,y:802,t:1526930188502};\\\", \\\"{x:1609,y:806,t:1526930188518};\\\", \\\"{x:1610,y:808,t:1526930188534};\\\", \\\"{x:1611,y:810,t:1526930188551};\\\", \\\"{x:1611,y:812,t:1526930188568};\\\", \\\"{x:1612,y:814,t:1526930188584};\\\", \\\"{x:1613,y:816,t:1526930188601};\\\", \\\"{x:1614,y:819,t:1526930188618};\\\", \\\"{x:1614,y:820,t:1526930188635};\\\", \\\"{x:1615,y:822,t:1526930188651};\\\", \\\"{x:1615,y:823,t:1526930188669};\\\", \\\"{x:1615,y:825,t:1526930188684};\\\", \\\"{x:1615,y:826,t:1526930188702};\\\", \\\"{x:1616,y:828,t:1526930188719};\\\", \\\"{x:1616,y:831,t:1526930188735};\\\", \\\"{x:1616,y:833,t:1526930188752};\\\", \\\"{x:1617,y:833,t:1526930188769};\\\", \\\"{x:1617,y:835,t:1526930188787};\\\", \\\"{x:1618,y:838,t:1526930188801};\\\", \\\"{x:1618,y:840,t:1526930188819};\\\", \\\"{x:1618,y:844,t:1526930188835};\\\", \\\"{x:1619,y:850,t:1526930188851};\\\", \\\"{x:1621,y:856,t:1526930188869};\\\", \\\"{x:1622,y:859,t:1526930188886};\\\", \\\"{x:1622,y:864,t:1526930188901};\\\", \\\"{x:1622,y:868,t:1526930188919};\\\", \\\"{x:1623,y:872,t:1526930188936};\\\", \\\"{x:1625,y:877,t:1526930188952};\\\", \\\"{x:1625,y:881,t:1526930188969};\\\", \\\"{x:1625,y:884,t:1526930188986};\\\", \\\"{x:1625,y:890,t:1526930189002};\\\", \\\"{x:1625,y:894,t:1526930189019};\\\", \\\"{x:1625,y:901,t:1526930189036};\\\", \\\"{x:1625,y:904,t:1526930189052};\\\", \\\"{x:1625,y:905,t:1526930189069};\\\", \\\"{x:1625,y:906,t:1526930189085};\\\", \\\"{x:1624,y:908,t:1526930189164};\\\", \\\"{x:1623,y:910,t:1526930189172};\\\", \\\"{x:1623,y:912,t:1526930189186};\\\", \\\"{x:1621,y:916,t:1526930189203};\\\", \\\"{x:1621,y:918,t:1526930189219};\\\", \\\"{x:1618,y:922,t:1526930189235};\\\", \\\"{x:1618,y:925,t:1526930189252};\\\", \\\"{x:1618,y:928,t:1526930189268};\\\", \\\"{x:1618,y:929,t:1526930189285};\\\", \\\"{x:1617,y:931,t:1526930189302};\\\", \\\"{x:1617,y:933,t:1526930189319};\\\", \\\"{x:1617,y:934,t:1526930189335};\\\", \\\"{x:1617,y:935,t:1526930189355};\\\", \\\"{x:1615,y:936,t:1526930189371};\\\", \\\"{x:1615,y:937,t:1526930189387};\\\", \\\"{x:1613,y:937,t:1526930190180};\\\", \\\"{x:1612,y:937,t:1526930190188};\\\", \\\"{x:1611,y:937,t:1526930190204};\\\", \\\"{x:1609,y:936,t:1526930190227};\\\", \\\"{x:1607,y:935,t:1526930190244};\\\", \\\"{x:1607,y:934,t:1526930190254};\\\", \\\"{x:1604,y:931,t:1526930190270};\\\", \\\"{x:1601,y:926,t:1526930190287};\\\", \\\"{x:1599,y:922,t:1526930190304};\\\", \\\"{x:1591,y:911,t:1526930190320};\\\", \\\"{x:1579,y:897,t:1526930190337};\\\", \\\"{x:1564,y:881,t:1526930190353};\\\", \\\"{x:1546,y:865,t:1526930190370};\\\", \\\"{x:1531,y:851,t:1526930190387};\\\", \\\"{x:1510,y:835,t:1526930190404};\\\", \\\"{x:1506,y:831,t:1526930190420};\\\", \\\"{x:1502,y:829,t:1526930190437};\\\", \\\"{x:1500,y:828,t:1526930190454};\\\", \\\"{x:1499,y:828,t:1526930190471};\\\", \\\"{x:1497,y:828,t:1526930190487};\\\", \\\"{x:1494,y:828,t:1526930190504};\\\", \\\"{x:1489,y:829,t:1526930190520};\\\", \\\"{x:1487,y:830,t:1526930190537};\\\", \\\"{x:1485,y:832,t:1526930190554};\\\", \\\"{x:1485,y:835,t:1526930190572};\\\", \\\"{x:1484,y:840,t:1526930190587};\\\", \\\"{x:1484,y:842,t:1526930190603};\\\", \\\"{x:1484,y:843,t:1526930190621};\\\", \\\"{x:1483,y:844,t:1526930190644};\\\", \\\"{x:1483,y:842,t:1526930190884};\\\", \\\"{x:1483,y:840,t:1526930190908};\\\", \\\"{x:1483,y:839,t:1526930190923};\\\", \\\"{x:1482,y:837,t:1526930190956};\\\", \\\"{x:1482,y:836,t:1526930190988};\\\", \\\"{x:1475,y:831,t:1526930192052};\\\", \\\"{x:1447,y:823,t:1526930192059};\\\", \\\"{x:1389,y:808,t:1526930192072};\\\", \\\"{x:1262,y:791,t:1526930192089};\\\", \\\"{x:1084,y:760,t:1526930192106};\\\", \\\"{x:941,y:708,t:1526930192122};\\\", \\\"{x:925,y:671,t:1526930192139};\\\", \\\"{x:922,y:668,t:1526930192156};\\\", \\\"{x:922,y:667,t:1526930192196};\\\", \\\"{x:919,y:664,t:1526930192206};\\\", \\\"{x:915,y:659,t:1526930192222};\\\", \\\"{x:910,y:652,t:1526930192238};\\\", \\\"{x:906,y:648,t:1526930192256};\\\", \\\"{x:905,y:643,t:1526930192271};\\\", \\\"{x:905,y:641,t:1526930192288};\\\", \\\"{x:905,y:639,t:1526930192306};\\\", \\\"{x:908,y:636,t:1526930192321};\\\", \\\"{x:907,y:636,t:1526930192820};\\\", \\\"{x:895,y:633,t:1526930192827};\\\", \\\"{x:882,y:630,t:1526930192840};\\\", \\\"{x:863,y:629,t:1526930192855};\\\", \\\"{x:854,y:629,t:1526930192873};\\\", \\\"{x:852,y:629,t:1526930192887};\\\", \\\"{x:851,y:629,t:1526930192903};\\\", \\\"{x:847,y:628,t:1526930192921};\\\", \\\"{x:839,y:627,t:1526930192936};\\\", \\\"{x:821,y:622,t:1526930192954};\\\", \\\"{x:779,y:615,t:1526930192970};\\\", \\\"{x:737,y:610,t:1526930192986};\\\", \\\"{x:702,y:607,t:1526930193004};\\\", \\\"{x:671,y:606,t:1526930193021};\\\", \\\"{x:649,y:604,t:1526930193037};\\\", \\\"{x:635,y:604,t:1526930193054};\\\", \\\"{x:630,y:603,t:1526930193071};\\\", \\\"{x:626,y:601,t:1526930193088};\\\", \\\"{x:624,y:600,t:1526930193105};\\\", \\\"{x:622,y:599,t:1526930193120};\\\", \\\"{x:619,y:596,t:1526930193137};\\\", \\\"{x:612,y:591,t:1526930193155};\\\", \\\"{x:607,y:588,t:1526930193171};\\\", \\\"{x:606,y:588,t:1526930193188};\\\", \\\"{x:605,y:589,t:1526930193699};\\\", \\\"{x:612,y:597,t:1526930193707};\\\", \\\"{x:624,y:606,t:1526930193721};\\\", \\\"{x:667,y:638,t:1526930193738};\\\", \\\"{x:824,y:714,t:1526930193754};\\\", \\\"{x:981,y:777,t:1526930193770};\\\", \\\"{x:1155,y:831,t:1526930193788};\\\", \\\"{x:1337,y:886,t:1526930193805};\\\", \\\"{x:1510,y:920,t:1526930193822};\\\", \\\"{x:1651,y:939,t:1526930193838};\\\", \\\"{x:1751,y:952,t:1526930193855};\\\", \\\"{x:1820,y:960,t:1526930193871};\\\", \\\"{x:1847,y:960,t:1526930193887};\\\", \\\"{x:1864,y:958,t:1526930193905};\\\", \\\"{x:1866,y:958,t:1526930193921};\\\", \\\"{x:1866,y:957,t:1526930193947};\\\", \\\"{x:1866,y:956,t:1526930193955};\\\", \\\"{x:1866,y:951,t:1526930193971};\\\", \\\"{x:1866,y:944,t:1526930193988};\\\", \\\"{x:1860,y:926,t:1526930194005};\\\", \\\"{x:1845,y:905,t:1526930194022};\\\", \\\"{x:1822,y:885,t:1526930194038};\\\", \\\"{x:1782,y:862,t:1526930194054};\\\", \\\"{x:1719,y:838,t:1526930194072};\\\", \\\"{x:1648,y:812,t:1526930194088};\\\", \\\"{x:1591,y:801,t:1526930194105};\\\", \\\"{x:1557,y:795,t:1526930194122};\\\", \\\"{x:1534,y:792,t:1526930194139};\\\", \\\"{x:1531,y:791,t:1526930194155};\\\", \\\"{x:1529,y:791,t:1526930194172};\\\", \\\"{x:1527,y:791,t:1526930194260};\\\", \\\"{x:1525,y:792,t:1526930194273};\\\", \\\"{x:1521,y:800,t:1526930194289};\\\", \\\"{x:1519,y:804,t:1526930194305};\\\", \\\"{x:1517,y:807,t:1526930194322};\\\", \\\"{x:1517,y:809,t:1526930194339};\\\", \\\"{x:1517,y:810,t:1526930194354};\\\", \\\"{x:1516,y:810,t:1526930194404};\\\", \\\"{x:1515,y:811,t:1526930194420};\\\", \\\"{x:1513,y:812,t:1526930194460};\\\", \\\"{x:1512,y:812,t:1526930194472};\\\", \\\"{x:1510,y:813,t:1526930194489};\\\", \\\"{x:1504,y:815,t:1526930194505};\\\", \\\"{x:1497,y:818,t:1526930194521};\\\", \\\"{x:1489,y:821,t:1526930194539};\\\", \\\"{x:1482,y:823,t:1526930194555};\\\", \\\"{x:1474,y:828,t:1526930194573};\\\", \\\"{x:1466,y:832,t:1526930194589};\\\", \\\"{x:1455,y:840,t:1526930194606};\\\", \\\"{x:1445,y:849,t:1526930194622};\\\", \\\"{x:1432,y:862,t:1526930194639};\\\", \\\"{x:1421,y:875,t:1526930194656};\\\", \\\"{x:1411,y:886,t:1526930194672};\\\", \\\"{x:1403,y:897,t:1526930194689};\\\", \\\"{x:1395,y:907,t:1526930194706};\\\", \\\"{x:1392,y:911,t:1526930194722};\\\", \\\"{x:1387,y:915,t:1526930194740};\\\", \\\"{x:1383,y:917,t:1526930194756};\\\", \\\"{x:1381,y:919,t:1526930194772};\\\", \\\"{x:1381,y:918,t:1526930195068};\\\", \\\"{x:1381,y:917,t:1526930195075};\\\", \\\"{x:1381,y:914,t:1526930195089};\\\", \\\"{x:1384,y:910,t:1526930195106};\\\", \\\"{x:1387,y:907,t:1526930195124};\\\", \\\"{x:1389,y:905,t:1526930195139};\\\", \\\"{x:1393,y:902,t:1526930195156};\\\", \\\"{x:1398,y:898,t:1526930195173};\\\", \\\"{x:1403,y:894,t:1526930195189};\\\", \\\"{x:1407,y:891,t:1526930195206};\\\", \\\"{x:1411,y:887,t:1526930195223};\\\", \\\"{x:1418,y:883,t:1526930195239};\\\", \\\"{x:1425,y:878,t:1526930195256};\\\", \\\"{x:1434,y:874,t:1526930195273};\\\", \\\"{x:1438,y:871,t:1526930195290};\\\", \\\"{x:1442,y:869,t:1526930195306};\\\", \\\"{x:1446,y:866,t:1526930195323};\\\", \\\"{x:1449,y:864,t:1526930195340};\\\", \\\"{x:1451,y:863,t:1526930195356};\\\", \\\"{x:1453,y:862,t:1526930195373};\\\", \\\"{x:1456,y:860,t:1526930195389};\\\", \\\"{x:1459,y:857,t:1526930195406};\\\", \\\"{x:1466,y:855,t:1526930195423};\\\", \\\"{x:1475,y:849,t:1526930195440};\\\", \\\"{x:1485,y:844,t:1526930195456};\\\", \\\"{x:1492,y:838,t:1526930195473};\\\", \\\"{x:1496,y:836,t:1526930195489};\\\", \\\"{x:1498,y:834,t:1526930195507};\\\", \\\"{x:1502,y:830,t:1526930195524};\\\", \\\"{x:1504,y:826,t:1526930195539};\\\", \\\"{x:1506,y:823,t:1526930195556};\\\", \\\"{x:1508,y:819,t:1526930195573};\\\", \\\"{x:1508,y:817,t:1526930195591};\\\", \\\"{x:1510,y:813,t:1526930195606};\\\", \\\"{x:1511,y:810,t:1526930195623};\\\", \\\"{x:1512,y:806,t:1526930195640};\\\", \\\"{x:1513,y:803,t:1526930195656};\\\", \\\"{x:1514,y:799,t:1526930195673};\\\", \\\"{x:1515,y:796,t:1526930195691};\\\", \\\"{x:1516,y:795,t:1526930195707};\\\", \\\"{x:1516,y:793,t:1526930195723};\\\", \\\"{x:1516,y:792,t:1526930195739};\\\", \\\"{x:1516,y:790,t:1526930195757};\\\", \\\"{x:1516,y:789,t:1526930195773};\\\", \\\"{x:1516,y:787,t:1526930195790};\\\", \\\"{x:1516,y:786,t:1526930195811};\\\", \\\"{x:1516,y:785,t:1526930195835};\\\", \\\"{x:1516,y:784,t:1526930196148};\\\", \\\"{x:1516,y:783,t:1526930197268};\\\", \\\"{x:1516,y:781,t:1526930197276};\\\", \\\"{x:1516,y:780,t:1526930197291};\\\", \\\"{x:1516,y:779,t:1526930197380};\\\", \\\"{x:1516,y:778,t:1526930199204};\\\", \\\"{x:1514,y:778,t:1526930199212};\\\", \\\"{x:1511,y:779,t:1526930199226};\\\", \\\"{x:1488,y:783,t:1526930199242};\\\", \\\"{x:1467,y:783,t:1526930199259};\\\", \\\"{x:1450,y:785,t:1526930199276};\\\", \\\"{x:1439,y:785,t:1526930199292};\\\", \\\"{x:1427,y:785,t:1526930199309};\\\", \\\"{x:1419,y:785,t:1526930199325};\\\", \\\"{x:1411,y:785,t:1526930199343};\\\", \\\"{x:1405,y:787,t:1526930199360};\\\", \\\"{x:1398,y:787,t:1526930199376};\\\", \\\"{x:1390,y:788,t:1526930199393};\\\", \\\"{x:1387,y:788,t:1526930199410};\\\", \\\"{x:1385,y:788,t:1526930199426};\\\", \\\"{x:1384,y:788,t:1526930199443};\\\", \\\"{x:1382,y:788,t:1526930199483};\\\", \\\"{x:1380,y:788,t:1526930199493};\\\", \\\"{x:1377,y:788,t:1526930199511};\\\", \\\"{x:1371,y:787,t:1526930199526};\\\", \\\"{x:1366,y:785,t:1526930199544};\\\", \\\"{x:1361,y:783,t:1526930199561};\\\", \\\"{x:1356,y:782,t:1526930199576};\\\", \\\"{x:1355,y:782,t:1526930199594};\\\", \\\"{x:1354,y:781,t:1526930199610};\\\", \\\"{x:1353,y:780,t:1526930199796};\\\", \\\"{x:1353,y:779,t:1526930199810};\\\", \\\"{x:1353,y:777,t:1526930199828};\\\", \\\"{x:1353,y:775,t:1526930199843};\\\", \\\"{x:1353,y:774,t:1526930199868};\\\", \\\"{x:1353,y:773,t:1526930199878};\\\", \\\"{x:1353,y:772,t:1526930199893};\\\", \\\"{x:1353,y:771,t:1526930199911};\\\", \\\"{x:1353,y:770,t:1526930199927};\\\", \\\"{x:1353,y:768,t:1526930199972};\\\", \\\"{x:1353,y:767,t:1526930200003};\\\", \\\"{x:1352,y:766,t:1526930200060};\\\", \\\"{x:1352,y:765,t:1526930200107};\\\", \\\"{x:1351,y:765,t:1526930200987};\\\", \\\"{x:1350,y:765,t:1526930201043};\\\", \\\"{x:1354,y:765,t:1526930202093};\\\", \\\"{x:1363,y:765,t:1526930202100};\\\", \\\"{x:1369,y:765,t:1526930202112};\\\", \\\"{x:1393,y:764,t:1526930202129};\\\", \\\"{x:1413,y:764,t:1526930202146};\\\", \\\"{x:1435,y:764,t:1526930202163};\\\", \\\"{x:1450,y:764,t:1526930202178};\\\", \\\"{x:1473,y:762,t:1526930202196};\\\", \\\"{x:1488,y:757,t:1526930202212};\\\", \\\"{x:1498,y:756,t:1526930202229};\\\", \\\"{x:1514,y:752,t:1526930202245};\\\", \\\"{x:1526,y:747,t:1526930202263};\\\", \\\"{x:1535,y:744,t:1526930202279};\\\", \\\"{x:1544,y:742,t:1526930202294};\\\", \\\"{x:1555,y:738,t:1526930202312};\\\", \\\"{x:1566,y:735,t:1526930202329};\\\", \\\"{x:1573,y:731,t:1526930202345};\\\", \\\"{x:1576,y:729,t:1526930202362};\\\", \\\"{x:1582,y:725,t:1526930202379};\\\", \\\"{x:1586,y:722,t:1526930202394};\\\", \\\"{x:1590,y:719,t:1526930202412};\\\", \\\"{x:1595,y:717,t:1526930202429};\\\", \\\"{x:1598,y:715,t:1526930202445};\\\", \\\"{x:1603,y:712,t:1526930202462};\\\", \\\"{x:1605,y:711,t:1526930202479};\\\", \\\"{x:1605,y:710,t:1526930202596};\\\", \\\"{x:1607,y:710,t:1526930204076};\\\", \\\"{x:1610,y:707,t:1526930204084};\\\", \\\"{x:1611,y:705,t:1526930204097};\\\", \\\"{x:1613,y:703,t:1526930204114};\\\", \\\"{x:1614,y:702,t:1526930204131};\\\", \\\"{x:1614,y:701,t:1526930204148};\\\", \\\"{x:1615,y:702,t:1526930204395};\\\", \\\"{x:1615,y:705,t:1526930204403};\\\", \\\"{x:1615,y:708,t:1526930204414};\\\", \\\"{x:1615,y:713,t:1526930204431};\\\", \\\"{x:1616,y:721,t:1526930204448};\\\", \\\"{x:1616,y:725,t:1526930204465};\\\", \\\"{x:1616,y:731,t:1526930204480};\\\", \\\"{x:1616,y:738,t:1526930204498};\\\", \\\"{x:1616,y:748,t:1526930204514};\\\", \\\"{x:1616,y:756,t:1526930204531};\\\", \\\"{x:1619,y:770,t:1526930204548};\\\", \\\"{x:1620,y:775,t:1526930204565};\\\", \\\"{x:1621,y:781,t:1526930204580};\\\", \\\"{x:1623,y:789,t:1526930204598};\\\", \\\"{x:1623,y:795,t:1526930204614};\\\", \\\"{x:1624,y:801,t:1526930204631};\\\", \\\"{x:1625,y:807,t:1526930204647};\\\", \\\"{x:1625,y:810,t:1526930204664};\\\", \\\"{x:1625,y:812,t:1526930204681};\\\", \\\"{x:1625,y:813,t:1526930204698};\\\", \\\"{x:1625,y:814,t:1526930204715};\\\", \\\"{x:1625,y:815,t:1526930204730};\\\", \\\"{x:1625,y:816,t:1526930204820};\\\", \\\"{x:1625,y:817,t:1526930204835};\\\", \\\"{x:1625,y:818,t:1526930204848};\\\", \\\"{x:1625,y:819,t:1526930204864};\\\", \\\"{x:1625,y:821,t:1526930204882};\\\", \\\"{x:1625,y:822,t:1526930204897};\\\", \\\"{x:1623,y:824,t:1526930204915};\\\", \\\"{x:1623,y:825,t:1526930204931};\\\", \\\"{x:1621,y:827,t:1526930204948};\\\", \\\"{x:1621,y:828,t:1526930204965};\\\", \\\"{x:1620,y:831,t:1526930204981};\\\", \\\"{x:1619,y:832,t:1526930204998};\\\", \\\"{x:1619,y:835,t:1526930205015};\\\", \\\"{x:1619,y:838,t:1526930205032};\\\", \\\"{x:1617,y:842,t:1526930205048};\\\", \\\"{x:1617,y:846,t:1526930205064};\\\", \\\"{x:1615,y:852,t:1526930205081};\\\", \\\"{x:1613,y:858,t:1526930205098};\\\", \\\"{x:1612,y:867,t:1526930205115};\\\", \\\"{x:1611,y:882,t:1526930205131};\\\", \\\"{x:1609,y:891,t:1526930205148};\\\", \\\"{x:1608,y:900,t:1526930205165};\\\", \\\"{x:1607,y:911,t:1526930205181};\\\", \\\"{x:1607,y:927,t:1526930205199};\\\", \\\"{x:1607,y:942,t:1526930205214};\\\", \\\"{x:1607,y:955,t:1526930205232};\\\", \\\"{x:1607,y:967,t:1526930205248};\\\", \\\"{x:1607,y:978,t:1526930205265};\\\", \\\"{x:1607,y:986,t:1526930205283};\\\", \\\"{x:1607,y:992,t:1526930205299};\\\", \\\"{x:1607,y:998,t:1526930205314};\\\", \\\"{x:1607,y:1005,t:1526930205331};\\\", \\\"{x:1607,y:1009,t:1526930205349};\\\", \\\"{x:1607,y:1010,t:1526930205364};\\\", \\\"{x:1602,y:1010,t:1526930205460};\\\", \\\"{x:1587,y:1005,t:1526930205468};\\\", \\\"{x:1564,y:994,t:1526930205482};\\\", \\\"{x:1503,y:968,t:1526930205499};\\\", \\\"{x:1423,y:935,t:1526930205515};\\\", \\\"{x:1317,y:892,t:1526930205532};\\\", \\\"{x:1275,y:872,t:1526930205549};\\\", \\\"{x:1258,y:865,t:1526930205566};\\\", \\\"{x:1253,y:861,t:1526930205581};\\\", \\\"{x:1252,y:857,t:1526930205599};\\\", \\\"{x:1252,y:851,t:1526930205615};\\\", \\\"{x:1252,y:842,t:1526930205633};\\\", \\\"{x:1252,y:834,t:1526930205649};\\\", \\\"{x:1252,y:829,t:1526930205665};\\\", \\\"{x:1254,y:823,t:1526930205681};\\\", \\\"{x:1256,y:818,t:1526930205699};\\\", \\\"{x:1262,y:806,t:1526930205715};\\\", \\\"{x:1268,y:798,t:1526930205731};\\\", \\\"{x:1275,y:789,t:1526930205749};\\\", \\\"{x:1286,y:775,t:1526930205765};\\\", \\\"{x:1295,y:763,t:1526930205782};\\\", \\\"{x:1304,y:752,t:1526930205799};\\\", \\\"{x:1309,y:744,t:1526930205816};\\\", \\\"{x:1316,y:735,t:1526930205832};\\\", \\\"{x:1319,y:730,t:1526930205848};\\\", \\\"{x:1323,y:725,t:1526930205865};\\\", \\\"{x:1325,y:719,t:1526930205881};\\\", \\\"{x:1329,y:713,t:1526930205898};\\\", \\\"{x:1333,y:705,t:1526930205914};\\\", \\\"{x:1333,y:702,t:1526930205931};\\\", \\\"{x:1335,y:700,t:1526930205948};\\\", \\\"{x:1336,y:699,t:1526930205965};\\\", \\\"{x:1338,y:698,t:1526930205982};\\\", \\\"{x:1339,y:696,t:1526930205998};\\\", \\\"{x:1339,y:695,t:1526930206016};\\\", \\\"{x:1341,y:693,t:1526930206032};\\\", \\\"{x:1345,y:693,t:1526930206048};\\\", \\\"{x:1347,y:692,t:1526930206065};\\\", \\\"{x:1349,y:691,t:1526930206082};\\\", \\\"{x:1350,y:691,t:1526930206652};\\\", \\\"{x:1351,y:691,t:1526930206667};\\\", \\\"{x:1351,y:692,t:1526930206683};\\\", \\\"{x:1351,y:694,t:1526930206700};\\\", \\\"{x:1351,y:697,t:1526930207075};\\\", \\\"{x:1351,y:701,t:1526930207083};\\\", \\\"{x:1351,y:709,t:1526930207100};\\\", \\\"{x:1351,y:714,t:1526930207117};\\\", \\\"{x:1351,y:717,t:1526930207132};\\\", \\\"{x:1351,y:719,t:1526930207149};\\\", \\\"{x:1351,y:720,t:1526930207412};\\\", \\\"{x:1353,y:725,t:1526930207420};\\\", \\\"{x:1353,y:727,t:1526930207434};\\\", \\\"{x:1355,y:731,t:1526930207450};\\\", \\\"{x:1355,y:736,t:1526930207467};\\\", \\\"{x:1356,y:744,t:1526930207483};\\\", \\\"{x:1357,y:749,t:1526930207500};\\\", \\\"{x:1357,y:751,t:1526930207517};\\\", \\\"{x:1357,y:752,t:1526930207534};\\\", \\\"{x:1357,y:753,t:1526930207549};\\\", \\\"{x:1357,y:754,t:1526930207652};\\\", \\\"{x:1356,y:754,t:1526930207667};\\\", \\\"{x:1331,y:758,t:1526930207684};\\\", \\\"{x:1282,y:758,t:1526930207701};\\\", \\\"{x:1202,y:754,t:1526930207717};\\\", \\\"{x:1081,y:739,t:1526930207734};\\\", \\\"{x:951,y:720,t:1526930207751};\\\", \\\"{x:815,y:699,t:1526930207766};\\\", \\\"{x:689,y:676,t:1526930207784};\\\", \\\"{x:596,y:657,t:1526930207800};\\\", \\\"{x:552,y:644,t:1526930207816};\\\", \\\"{x:536,y:644,t:1526930207833};\\\", \\\"{x:531,y:645,t:1526930207850};\\\", \\\"{x:530,y:645,t:1526930207947};\\\", \\\"{x:525,y:645,t:1526930207955};\\\", \\\"{x:519,y:645,t:1526930207967};\\\", \\\"{x:510,y:642,t:1526930207983};\\\", \\\"{x:491,y:632,t:1526930208001};\\\", \\\"{x:464,y:621,t:1526930208019};\\\", \\\"{x:428,y:601,t:1526930208033};\\\", \\\"{x:398,y:585,t:1526930208050};\\\", \\\"{x:366,y:567,t:1526930208063};\\\", \\\"{x:342,y:557,t:1526930208079};\\\", \\\"{x:327,y:548,t:1526930208095};\\\", \\\"{x:310,y:540,t:1526930208116};\\\", \\\"{x:303,y:537,t:1526930208133};\\\", \\\"{x:297,y:535,t:1526930208150};\\\", \\\"{x:284,y:532,t:1526930208166};\\\", \\\"{x:266,y:531,t:1526930208184};\\\", \\\"{x:234,y:526,t:1526930208201};\\\", \\\"{x:199,y:519,t:1526930208217};\\\", \\\"{x:176,y:518,t:1526930208233};\\\", \\\"{x:151,y:518,t:1526930208250};\\\", \\\"{x:138,y:518,t:1526930208266};\\\", \\\"{x:136,y:518,t:1526930208355};\\\", \\\"{x:136,y:520,t:1526930208371};\\\", \\\"{x:136,y:522,t:1526930208383};\\\", \\\"{x:136,y:527,t:1526930208401};\\\", \\\"{x:141,y:537,t:1526930208416};\\\", \\\"{x:146,y:544,t:1526930208433};\\\", \\\"{x:153,y:554,t:1526930208451};\\\", \\\"{x:159,y:562,t:1526930208467};\\\", \\\"{x:168,y:575,t:1526930208484};\\\", \\\"{x:170,y:578,t:1526930208500};\\\", \\\"{x:171,y:580,t:1526930208516};\\\", \\\"{x:171,y:582,t:1526930208533};\\\", \\\"{x:172,y:583,t:1526930208550};\\\", \\\"{x:172,y:584,t:1526930208566};\\\", \\\"{x:172,y:585,t:1526930208586};\\\", \\\"{x:172,y:586,t:1526930208602};\\\", \\\"{x:172,y:587,t:1526930208616};\\\", \\\"{x:172,y:588,t:1526930208651};\\\", \\\"{x:171,y:588,t:1526930208795};\\\", \\\"{x:169,y:588,t:1526930208812};\\\", \\\"{x:168,y:586,t:1526930208828};\\\", \\\"{x:168,y:584,t:1526930208835};\\\", \\\"{x:168,y:579,t:1526930208850};\\\", \\\"{x:168,y:571,t:1526930208866};\\\", \\\"{x:168,y:562,t:1526930208883};\\\", \\\"{x:172,y:558,t:1526930208900};\\\", \\\"{x:176,y:554,t:1526930208918};\\\", \\\"{x:182,y:551,t:1526930208933};\\\", \\\"{x:198,y:545,t:1526930208950};\\\", \\\"{x:213,y:543,t:1526930208967};\\\", \\\"{x:235,y:541,t:1526930208984};\\\", \\\"{x:266,y:540,t:1526930209000};\\\", \\\"{x:297,y:540,t:1526930209018};\\\", \\\"{x:364,y:540,t:1526930209034};\\\", \\\"{x:387,y:540,t:1526930209050};\\\", \\\"{x:457,y:540,t:1526930209067};\\\", \\\"{x:510,y:540,t:1526930209085};\\\", \\\"{x:557,y:540,t:1526930209100};\\\", \\\"{x:600,y:538,t:1526930209118};\\\", \\\"{x:639,y:533,t:1526930209134};\\\", \\\"{x:668,y:528,t:1526930209150};\\\", \\\"{x:702,y:518,t:1526930209168};\\\", \\\"{x:729,y:512,t:1526930209185};\\\", \\\"{x:750,y:506,t:1526930209200};\\\", \\\"{x:768,y:501,t:1526930209217};\\\", \\\"{x:780,y:498,t:1526930209233};\\\", \\\"{x:785,y:498,t:1526930209250};\\\", \\\"{x:789,y:497,t:1526930209267};\\\", \\\"{x:792,y:497,t:1526930209283};\\\", \\\"{x:793,y:496,t:1526930209300};\\\", \\\"{x:795,y:496,t:1526930209396};\\\", \\\"{x:798,y:496,t:1526930209404};\\\", \\\"{x:800,y:497,t:1526930209418};\\\", \\\"{x:806,y:501,t:1526930209434};\\\", \\\"{x:822,y:508,t:1526930209451};\\\", \\\"{x:838,y:511,t:1526930209468};\\\", \\\"{x:853,y:514,t:1526930209484};\\\", \\\"{x:865,y:515,t:1526930209502};\\\", \\\"{x:873,y:515,t:1526930209518};\\\", \\\"{x:876,y:515,t:1526930209535};\\\", \\\"{x:877,y:515,t:1526930209636};\\\", \\\"{x:877,y:514,t:1526930209667};\\\", \\\"{x:875,y:512,t:1526930209691};\\\", \\\"{x:875,y:511,t:1526930209701};\\\", \\\"{x:868,y:508,t:1526930209717};\\\", \\\"{x:863,y:506,t:1526930209736};\\\", \\\"{x:856,y:505,t:1526930209751};\\\", \\\"{x:851,y:503,t:1526930209767};\\\", \\\"{x:848,y:502,t:1526930209784};\\\", \\\"{x:847,y:502,t:1526930209801};\\\", \\\"{x:846,y:502,t:1526930209818};\\\", \\\"{x:843,y:502,t:1526930210187};\\\", \\\"{x:840,y:505,t:1526930210201};\\\", \\\"{x:806,y:554,t:1526930210220};\\\", \\\"{x:779,y:590,t:1526930210235};\\\", \\\"{x:676,y:735,t:1526930210252};\\\", \\\"{x:610,y:850,t:1526930210268};\\\", \\\"{x:545,y:927,t:1526930210284};\\\", \\\"{x:496,y:975,t:1526930210301};\\\", \\\"{x:460,y:1007,t:1526930210318};\\\", \\\"{x:437,y:1024,t:1526930210334};\\\", \\\"{x:424,y:1029,t:1526930210351};\\\", \\\"{x:419,y:1031,t:1526930210368};\\\", \\\"{x:419,y:1032,t:1526930210385};\\\", \\\"{x:416,y:1031,t:1526930210401};\\\", \\\"{x:410,y:1023,t:1526930210419};\\\", \\\"{x:403,y:1012,t:1526930210435};\\\", \\\"{x:391,y:997,t:1526930210452};\\\", \\\"{x:381,y:979,t:1526930210468};\\\", \\\"{x:374,y:966,t:1526930210485};\\\", \\\"{x:371,y:959,t:1526930210501};\\\", \\\"{x:371,y:954,t:1526930210519};\\\", \\\"{x:371,y:952,t:1526930210535};\\\", \\\"{x:371,y:947,t:1526930210551};\\\", \\\"{x:372,y:942,t:1526930210569};\\\", \\\"{x:380,y:931,t:1526930210586};\\\", \\\"{x:393,y:917,t:1526930210601};\\\", \\\"{x:418,y:893,t:1526930210619};\\\", \\\"{x:439,y:878,t:1526930210635};\\\", \\\"{x:452,y:871,t:1526930210651};\\\", \\\"{x:470,y:863,t:1526930210668};\\\", \\\"{x:486,y:855,t:1526930210685};\\\", \\\"{x:497,y:847,t:1526930210702};\\\", \\\"{x:503,y:840,t:1526930210719};\\\", \\\"{x:507,y:834,t:1526930210736};\\\", \\\"{x:510,y:830,t:1526930210752};\\\", \\\"{x:513,y:827,t:1526930210768};\\\", \\\"{x:515,y:822,t:1526930210785};\\\", \\\"{x:516,y:818,t:1526930210801};\\\", \\\"{x:519,y:808,t:1526930210819};\\\", \\\"{x:520,y:803,t:1526930210835};\\\", \\\"{x:520,y:798,t:1526930210851};\\\", \\\"{x:520,y:796,t:1526930210868};\\\", \\\"{x:521,y:790,t:1526930210885};\\\", \\\"{x:523,y:784,t:1526930210903};\\\", \\\"{x:524,y:778,t:1526930210918};\\\", \\\"{x:524,y:773,t:1526930210935};\\\", \\\"{x:524,y:766,t:1526930210952};\\\", \\\"{x:524,y:758,t:1526930210969};\\\", \\\"{x:524,y:754,t:1526930210987};\\\", \\\"{x:526,y:750,t:1526930211002};\\\" ] }, { \\\"rt\\\": 32284, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 567798, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-01 PM-M -X -O -E -11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:759,t:1526930214453};\\\", \\\"{x:547,y:792,t:1526930214473};\\\", \\\"{x:565,y:818,t:1526930214489};\\\", \\\"{x:592,y:845,t:1526930214504};\\\", \\\"{x:615,y:861,t:1526930214521};\\\", \\\"{x:635,y:873,t:1526930214537};\\\", \\\"{x:674,y:888,t:1526930214554};\\\", \\\"{x:701,y:898,t:1526930214572};\\\", \\\"{x:725,y:906,t:1526930214587};\\\", \\\"{x:751,y:909,t:1526930214605};\\\", \\\"{x:776,y:914,t:1526930214621};\\\", \\\"{x:798,y:914,t:1526930214638};\\\", \\\"{x:820,y:914,t:1526930214654};\\\", \\\"{x:839,y:914,t:1526930214672};\\\", \\\"{x:858,y:914,t:1526930214687};\\\", \\\"{x:876,y:914,t:1526930214705};\\\", \\\"{x:890,y:912,t:1526930214722};\\\", \\\"{x:897,y:911,t:1526930214737};\\\", \\\"{x:906,y:908,t:1526930214755};\\\", \\\"{x:910,y:906,t:1526930214771};\\\", \\\"{x:913,y:904,t:1526930214788};\\\", \\\"{x:919,y:903,t:1526930214805};\\\", \\\"{x:926,y:901,t:1526930214821};\\\", \\\"{x:941,y:898,t:1526930214838};\\\", \\\"{x:955,y:896,t:1526930214855};\\\", \\\"{x:969,y:895,t:1526930214872};\\\", \\\"{x:981,y:895,t:1526930214889};\\\", \\\"{x:997,y:895,t:1526930214905};\\\", \\\"{x:1018,y:896,t:1526930214922};\\\", \\\"{x:1050,y:904,t:1526930214939};\\\", \\\"{x:1075,y:912,t:1526930214955};\\\", \\\"{x:1100,y:918,t:1526930214972};\\\", \\\"{x:1119,y:925,t:1526930214989};\\\", \\\"{x:1136,y:931,t:1526930215005};\\\", \\\"{x:1149,y:937,t:1526930215022};\\\", \\\"{x:1156,y:941,t:1526930215039};\\\", \\\"{x:1168,y:949,t:1526930215055};\\\", \\\"{x:1175,y:954,t:1526930215072};\\\", \\\"{x:1185,y:960,t:1526930215089};\\\", \\\"{x:1194,y:963,t:1526930215106};\\\", \\\"{x:1196,y:963,t:1526930215122};\\\", \\\"{x:1198,y:963,t:1526930215139};\\\", \\\"{x:1200,y:963,t:1526930215156};\\\", \\\"{x:1207,y:964,t:1526930215172};\\\", \\\"{x:1209,y:964,t:1526930215189};\\\", \\\"{x:1214,y:964,t:1526930215205};\\\", \\\"{x:1218,y:964,t:1526930215223};\\\", \\\"{x:1221,y:964,t:1526930215239};\\\", \\\"{x:1224,y:964,t:1526930215255};\\\", \\\"{x:1228,y:964,t:1526930215273};\\\", \\\"{x:1234,y:964,t:1526930215289};\\\", \\\"{x:1244,y:964,t:1526930215305};\\\", \\\"{x:1253,y:964,t:1526930215322};\\\", \\\"{x:1258,y:964,t:1526930215339};\\\", \\\"{x:1266,y:964,t:1526930215356};\\\", \\\"{x:1268,y:964,t:1526930215372};\\\", \\\"{x:1269,y:965,t:1526930215389};\\\", \\\"{x:1270,y:967,t:1526930215405};\\\", \\\"{x:1270,y:968,t:1526930215444};\\\", \\\"{x:1270,y:969,t:1526930215456};\\\", \\\"{x:1270,y:970,t:1526930215472};\\\", \\\"{x:1271,y:970,t:1526930217041};\\\", \\\"{x:1272,y:970,t:1526930217053};\\\", \\\"{x:1279,y:968,t:1526930217072};\\\", \\\"{x:1284,y:964,t:1526930217088};\\\", \\\"{x:1290,y:960,t:1526930217104};\\\", \\\"{x:1297,y:957,t:1526930217120};\\\", \\\"{x:1303,y:952,t:1526930217138};\\\", \\\"{x:1309,y:949,t:1526930217153};\\\", \\\"{x:1314,y:944,t:1526930217170};\\\", \\\"{x:1323,y:935,t:1526930217187};\\\", \\\"{x:1328,y:929,t:1526930217203};\\\", \\\"{x:1333,y:920,t:1526930217219};\\\", \\\"{x:1340,y:910,t:1526930217237};\\\", \\\"{x:1348,y:895,t:1526930217254};\\\", \\\"{x:1356,y:878,t:1526930217270};\\\", \\\"{x:1363,y:863,t:1526930217287};\\\", \\\"{x:1377,y:845,t:1526930217304};\\\", \\\"{x:1385,y:834,t:1526930217320};\\\", \\\"{x:1392,y:826,t:1526930217338};\\\", \\\"{x:1400,y:819,t:1526930217355};\\\", \\\"{x:1405,y:815,t:1526930217370};\\\", \\\"{x:1414,y:809,t:1526930217387};\\\", \\\"{x:1418,y:805,t:1526930217404};\\\", \\\"{x:1427,y:801,t:1526930217421};\\\", \\\"{x:1434,y:796,t:1526930217437};\\\", \\\"{x:1440,y:794,t:1526930217455};\\\", \\\"{x:1445,y:791,t:1526930217471};\\\", \\\"{x:1449,y:788,t:1526930217488};\\\", \\\"{x:1455,y:784,t:1526930217505};\\\", \\\"{x:1458,y:784,t:1526930217520};\\\", \\\"{x:1459,y:782,t:1526930217538};\\\", \\\"{x:1460,y:782,t:1526930217554};\\\", \\\"{x:1463,y:780,t:1526930217571};\\\", \\\"{x:1467,y:777,t:1526930217587};\\\", \\\"{x:1468,y:777,t:1526930217604};\\\", \\\"{x:1470,y:777,t:1526930217621};\\\", \\\"{x:1473,y:774,t:1526930217637};\\\", \\\"{x:1477,y:773,t:1526930217655};\\\", \\\"{x:1480,y:772,t:1526930217670};\\\", \\\"{x:1483,y:771,t:1526930217687};\\\", \\\"{x:1486,y:770,t:1526930217705};\\\", \\\"{x:1489,y:770,t:1526930217721};\\\", \\\"{x:1492,y:770,t:1526930217738};\\\", \\\"{x:1497,y:770,t:1526930217754};\\\", \\\"{x:1506,y:770,t:1526930217770};\\\", \\\"{x:1512,y:770,t:1526930217787};\\\", \\\"{x:1516,y:770,t:1526930217804};\\\", \\\"{x:1519,y:770,t:1526930217822};\\\", \\\"{x:1522,y:770,t:1526930217837};\\\", \\\"{x:1525,y:770,t:1526930217855};\\\", \\\"{x:1529,y:770,t:1526930217872};\\\", \\\"{x:1530,y:770,t:1526930217888};\\\", \\\"{x:1534,y:770,t:1526930217905};\\\", \\\"{x:1536,y:769,t:1526930217922};\\\", \\\"{x:1538,y:769,t:1526930217937};\\\", \\\"{x:1539,y:768,t:1526930217955};\\\", \\\"{x:1540,y:768,t:1526930218033};\\\", \\\"{x:1541,y:768,t:1526930218040};\\\", \\\"{x:1543,y:768,t:1526930218054};\\\", \\\"{x:1547,y:768,t:1526930218072};\\\", \\\"{x:1552,y:768,t:1526930218087};\\\", \\\"{x:1554,y:768,t:1526930218105};\\\", \\\"{x:1555,y:768,t:1526930218121};\\\", \\\"{x:1556,y:768,t:1526930218137};\\\", \\\"{x:1555,y:770,t:1526930218377};\\\", \\\"{x:1553,y:772,t:1526930218389};\\\", \\\"{x:1548,y:773,t:1526930218404};\\\", \\\"{x:1543,y:775,t:1526930218422};\\\", \\\"{x:1538,y:777,t:1526930218439};\\\", \\\"{x:1537,y:778,t:1526930218455};\\\", \\\"{x:1534,y:779,t:1526930218489};\\\", \\\"{x:1532,y:781,t:1526930218633};\\\", \\\"{x:1532,y:782,t:1526930218641};\\\", \\\"{x:1530,y:785,t:1526930218655};\\\", \\\"{x:1529,y:789,t:1526930218672};\\\", \\\"{x:1527,y:795,t:1526930218688};\\\", \\\"{x:1525,y:800,t:1526930218705};\\\", \\\"{x:1524,y:805,t:1526930218722};\\\", \\\"{x:1522,y:810,t:1526930218739};\\\", \\\"{x:1522,y:816,t:1526930218755};\\\", \\\"{x:1521,y:820,t:1526930218772};\\\", \\\"{x:1519,y:825,t:1526930218789};\\\", \\\"{x:1518,y:829,t:1526930218804};\\\", \\\"{x:1518,y:832,t:1526930218822};\\\", \\\"{x:1518,y:834,t:1526930218839};\\\", \\\"{x:1517,y:837,t:1526930218855};\\\", \\\"{x:1517,y:838,t:1526930218872};\\\", \\\"{x:1517,y:845,t:1526930218888};\\\", \\\"{x:1517,y:850,t:1526930218905};\\\", \\\"{x:1517,y:855,t:1526930218922};\\\", \\\"{x:1517,y:860,t:1526930218939};\\\", \\\"{x:1517,y:866,t:1526930218955};\\\", \\\"{x:1517,y:873,t:1526930218972};\\\", \\\"{x:1517,y:880,t:1526930218989};\\\", \\\"{x:1517,y:883,t:1526930219006};\\\", \\\"{x:1518,y:888,t:1526930219022};\\\", \\\"{x:1520,y:892,t:1526930219039};\\\", \\\"{x:1521,y:895,t:1526930219055};\\\", \\\"{x:1521,y:899,t:1526930219072};\\\", \\\"{x:1523,y:905,t:1526930219089};\\\", \\\"{x:1524,y:908,t:1526930219105};\\\", \\\"{x:1524,y:909,t:1526930219122};\\\", \\\"{x:1525,y:911,t:1526930219138};\\\", \\\"{x:1525,y:912,t:1526930219156};\\\", \\\"{x:1525,y:914,t:1526930219172};\\\", \\\"{x:1526,y:917,t:1526930219189};\\\", \\\"{x:1526,y:921,t:1526930219205};\\\", \\\"{x:1526,y:924,t:1526930219221};\\\", \\\"{x:1527,y:928,t:1526930219239};\\\", \\\"{x:1528,y:930,t:1526930219256};\\\", \\\"{x:1528,y:933,t:1526930219271};\\\", \\\"{x:1528,y:938,t:1526930219287};\\\", \\\"{x:1528,y:941,t:1526930219305};\\\", \\\"{x:1528,y:945,t:1526930219321};\\\", \\\"{x:1526,y:950,t:1526930219338};\\\", \\\"{x:1526,y:952,t:1526930219355};\\\", \\\"{x:1524,y:955,t:1526930219371};\\\", \\\"{x:1524,y:956,t:1526930219388};\\\", \\\"{x:1523,y:957,t:1526930219405};\\\", \\\"{x:1522,y:958,t:1526930219545};\\\", \\\"{x:1521,y:958,t:1526930219556};\\\", \\\"{x:1506,y:959,t:1526930219572};\\\", \\\"{x:1491,y:961,t:1526930219589};\\\", \\\"{x:1475,y:963,t:1526930219606};\\\", \\\"{x:1462,y:965,t:1526930219623};\\\", \\\"{x:1454,y:966,t:1526930219639};\\\", \\\"{x:1451,y:966,t:1526930219656};\\\", \\\"{x:1448,y:967,t:1526930219673};\\\", \\\"{x:1447,y:967,t:1526930219729};\\\", \\\"{x:1447,y:968,t:1526930219738};\\\", \\\"{x:1444,y:969,t:1526930219755};\\\", \\\"{x:1438,y:969,t:1526930219772};\\\", \\\"{x:1434,y:969,t:1526930219788};\\\", \\\"{x:1431,y:969,t:1526930219805};\\\", \\\"{x:1430,y:969,t:1526930219822};\\\", \\\"{x:1428,y:969,t:1526930219864};\\\", \\\"{x:1427,y:970,t:1526930219872};\\\", \\\"{x:1426,y:970,t:1526930219888};\\\", \\\"{x:1424,y:971,t:1526930219929};\\\", \\\"{x:1423,y:971,t:1526930219945};\\\", \\\"{x:1420,y:971,t:1526930219955};\\\", \\\"{x:1417,y:971,t:1526930219973};\\\", \\\"{x:1410,y:971,t:1526930219989};\\\", \\\"{x:1399,y:971,t:1526930220006};\\\", \\\"{x:1391,y:971,t:1526930220023};\\\", \\\"{x:1377,y:970,t:1526930220038};\\\", \\\"{x:1365,y:968,t:1526930220056};\\\", \\\"{x:1356,y:967,t:1526930220073};\\\", \\\"{x:1356,y:966,t:1526930220089};\\\", \\\"{x:1355,y:966,t:1526930220105};\\\", \\\"{x:1354,y:965,t:1526930220129};\\\", \\\"{x:1354,y:964,t:1526930220153};\\\", \\\"{x:1354,y:963,t:1526930220161};\\\", \\\"{x:1354,y:961,t:1526930220175};\\\", \\\"{x:1354,y:960,t:1526930220188};\\\", \\\"{x:1354,y:958,t:1526930220205};\\\", \\\"{x:1354,y:956,t:1526930220222};\\\", \\\"{x:1354,y:955,t:1526930220239};\\\", \\\"{x:1354,y:953,t:1526930220255};\\\", \\\"{x:1354,y:949,t:1526930220272};\\\", \\\"{x:1356,y:944,t:1526930220289};\\\", \\\"{x:1358,y:940,t:1526930220305};\\\", \\\"{x:1360,y:933,t:1526930220323};\\\", \\\"{x:1361,y:928,t:1526930220340};\\\", \\\"{x:1363,y:919,t:1526930220355};\\\", \\\"{x:1364,y:912,t:1526930220373};\\\", \\\"{x:1365,y:905,t:1526930220389};\\\", \\\"{x:1366,y:896,t:1526930220406};\\\", \\\"{x:1368,y:890,t:1526930220423};\\\", \\\"{x:1368,y:884,t:1526930220439};\\\", \\\"{x:1368,y:880,t:1526930220455};\\\", \\\"{x:1369,y:875,t:1526930220472};\\\", \\\"{x:1370,y:872,t:1526930220489};\\\", \\\"{x:1370,y:870,t:1526930220519};\\\", \\\"{x:1372,y:870,t:1526930220642};\\\", \\\"{x:1374,y:871,t:1526930220655};\\\", \\\"{x:1380,y:876,t:1526930220672};\\\", \\\"{x:1384,y:879,t:1526930220690};\\\", \\\"{x:1388,y:881,t:1526930220707};\\\", \\\"{x:1389,y:881,t:1526930220723};\\\", \\\"{x:1390,y:882,t:1526930220745};\\\", \\\"{x:1392,y:882,t:1526930220849};\\\", \\\"{x:1394,y:882,t:1526930220857};\\\", \\\"{x:1400,y:880,t:1526930220873};\\\", \\\"{x:1406,y:874,t:1526930220889};\\\", \\\"{x:1414,y:870,t:1526930220906};\\\", \\\"{x:1422,y:865,t:1526930220923};\\\", \\\"{x:1429,y:857,t:1526930220940};\\\", \\\"{x:1436,y:849,t:1526930220957};\\\", \\\"{x:1439,y:844,t:1526930220973};\\\", \\\"{x:1443,y:836,t:1526930220990};\\\", \\\"{x:1445,y:833,t:1526930221007};\\\", \\\"{x:1447,y:831,t:1526930221023};\\\", \\\"{x:1448,y:831,t:1526930221040};\\\", \\\"{x:1449,y:829,t:1526930221057};\\\", \\\"{x:1450,y:829,t:1526930221073};\\\", \\\"{x:1451,y:828,t:1526930221090};\\\", \\\"{x:1452,y:828,t:1526930221107};\\\", \\\"{x:1454,y:828,t:1526930221177};\\\", \\\"{x:1455,y:826,t:1526930221190};\\\", \\\"{x:1458,y:826,t:1526930221207};\\\", \\\"{x:1461,y:826,t:1526930221223};\\\", \\\"{x:1464,y:826,t:1526930221240};\\\", \\\"{x:1468,y:826,t:1526930221256};\\\", \\\"{x:1469,y:826,t:1526930221281};\\\", \\\"{x:1470,y:826,t:1526930221296};\\\", \\\"{x:1471,y:826,t:1526930221307};\\\", \\\"{x:1473,y:827,t:1526930221353};\\\", \\\"{x:1474,y:827,t:1526930221376};\\\", \\\"{x:1474,y:828,t:1526930221390};\\\", \\\"{x:1475,y:828,t:1526930221407};\\\", \\\"{x:1475,y:829,t:1526930221424};\\\", \\\"{x:1477,y:829,t:1526930221443};\\\", \\\"{x:1479,y:829,t:1526930221457};\\\", \\\"{x:1481,y:830,t:1526930221474};\\\", \\\"{x:1483,y:830,t:1526930221489};\\\", \\\"{x:1485,y:832,t:1526930221506};\\\", \\\"{x:1487,y:832,t:1526930221525};\\\", \\\"{x:1488,y:832,t:1526930221985};\\\", \\\"{x:1488,y:833,t:1526930221993};\\\", \\\"{x:1485,y:835,t:1526930222007};\\\", \\\"{x:1480,y:837,t:1526930222024};\\\", \\\"{x:1476,y:840,t:1526930222041};\\\", \\\"{x:1474,y:840,t:1526930222057};\\\", \\\"{x:1475,y:840,t:1526930222697};\\\", \\\"{x:1477,y:840,t:1526930222707};\\\", \\\"{x:1479,y:839,t:1526930222724};\\\", \\\"{x:1483,y:837,t:1526930223185};\\\", \\\"{x:1485,y:836,t:1526930223193};\\\", \\\"{x:1486,y:835,t:1526930223208};\\\", \\\"{x:1494,y:831,t:1526930223224};\\\", \\\"{x:1499,y:828,t:1526930223241};\\\", \\\"{x:1505,y:826,t:1526930223258};\\\", \\\"{x:1510,y:824,t:1526930223274};\\\", \\\"{x:1514,y:823,t:1526930223291};\\\", \\\"{x:1515,y:822,t:1526930223308};\\\", \\\"{x:1516,y:821,t:1526930223777};\\\", \\\"{x:1516,y:819,t:1526930223792};\\\", \\\"{x:1516,y:817,t:1526930223808};\\\", \\\"{x:1514,y:813,t:1526930223825};\\\", \\\"{x:1514,y:811,t:1526930223842};\\\", \\\"{x:1514,y:809,t:1526930223858};\\\", \\\"{x:1512,y:807,t:1526930223874};\\\", \\\"{x:1512,y:806,t:1526930223892};\\\", \\\"{x:1512,y:804,t:1526930223908};\\\", \\\"{x:1511,y:802,t:1526930223925};\\\", \\\"{x:1510,y:800,t:1526930223942};\\\", \\\"{x:1510,y:799,t:1526930223968};\\\", \\\"{x:1510,y:798,t:1526930223977};\\\", \\\"{x:1510,y:797,t:1526930223992};\\\", \\\"{x:1510,y:796,t:1526930224008};\\\", \\\"{x:1510,y:795,t:1526930224024};\\\", \\\"{x:1509,y:794,t:1526930224042};\\\", \\\"{x:1508,y:792,t:1526930224058};\\\", \\\"{x:1508,y:791,t:1526930224074};\\\", \\\"{x:1508,y:789,t:1526930224092};\\\", \\\"{x:1508,y:787,t:1526930224108};\\\", \\\"{x:1510,y:782,t:1526930224125};\\\", \\\"{x:1511,y:780,t:1526930224141};\\\", \\\"{x:1511,y:779,t:1526930224158};\\\", \\\"{x:1511,y:777,t:1526930224175};\\\", \\\"{x:1511,y:776,t:1526930224192};\\\", \\\"{x:1511,y:775,t:1526930224208};\\\", \\\"{x:1511,y:773,t:1526930224225};\\\", \\\"{x:1511,y:772,t:1526930224242};\\\", \\\"{x:1511,y:770,t:1526930224260};\\\", \\\"{x:1511,y:769,t:1526930224280};\\\", \\\"{x:1511,y:768,t:1526930224292};\\\", \\\"{x:1511,y:767,t:1526930224310};\\\", \\\"{x:1511,y:766,t:1526930224368};\\\", \\\"{x:1510,y:766,t:1526930228361};\\\", \\\"{x:1503,y:768,t:1526930228379};\\\", \\\"{x:1496,y:768,t:1526930228394};\\\", \\\"{x:1482,y:768,t:1526930228411};\\\", \\\"{x:1465,y:763,t:1526930228428};\\\", \\\"{x:1448,y:756,t:1526930228444};\\\", \\\"{x:1426,y:742,t:1526930228461};\\\", \\\"{x:1400,y:729,t:1526930228477};\\\", \\\"{x:1380,y:716,t:1526930228494};\\\", \\\"{x:1354,y:705,t:1526930228510};\\\", \\\"{x:1327,y:689,t:1526930228528};\\\", \\\"{x:1307,y:678,t:1526930228544};\\\", \\\"{x:1285,y:666,t:1526930228560};\\\", \\\"{x:1269,y:655,t:1526930228578};\\\", \\\"{x:1260,y:650,t:1526930228593};\\\", \\\"{x:1257,y:648,t:1526930228611};\\\", \\\"{x:1255,y:646,t:1526930228628};\\\", \\\"{x:1255,y:644,t:1526930228644};\\\", \\\"{x:1255,y:643,t:1526930228713};\\\", \\\"{x:1255,y:640,t:1526930228728};\\\", \\\"{x:1255,y:637,t:1526930228745};\\\", \\\"{x:1257,y:632,t:1526930228761};\\\", \\\"{x:1261,y:628,t:1526930228778};\\\", \\\"{x:1264,y:622,t:1526930228794};\\\", \\\"{x:1268,y:618,t:1526930228811};\\\", \\\"{x:1273,y:613,t:1526930228828};\\\", \\\"{x:1277,y:607,t:1526930228844};\\\", \\\"{x:1280,y:604,t:1526930228861};\\\", \\\"{x:1283,y:600,t:1526930228878};\\\", \\\"{x:1286,y:598,t:1526930228895};\\\", \\\"{x:1286,y:595,t:1526930228911};\\\", \\\"{x:1288,y:591,t:1526930228929};\\\", \\\"{x:1288,y:590,t:1526930228993};\\\", \\\"{x:1288,y:589,t:1526930229008};\\\", \\\"{x:1288,y:588,t:1526930229033};\\\", \\\"{x:1288,y:587,t:1526930229056};\\\", \\\"{x:1288,y:586,t:1526930229064};\\\", \\\"{x:1288,y:585,t:1526930229079};\\\", \\\"{x:1288,y:584,t:1526930229097};\\\", \\\"{x:1288,y:583,t:1526930229112};\\\", \\\"{x:1286,y:580,t:1526930229129};\\\", \\\"{x:1285,y:577,t:1526930229144};\\\", \\\"{x:1282,y:573,t:1526930229161};\\\", \\\"{x:1282,y:572,t:1526930229179};\\\", \\\"{x:1281,y:569,t:1526930229196};\\\", \\\"{x:1280,y:568,t:1526930229211};\\\", \\\"{x:1279,y:567,t:1526930229228};\\\", \\\"{x:1279,y:566,t:1526930229256};\\\", \\\"{x:1278,y:566,t:1526930229265};\\\", \\\"{x:1278,y:568,t:1526930230232};\\\", \\\"{x:1278,y:572,t:1526930230245};\\\", \\\"{x:1278,y:579,t:1526930230262};\\\", \\\"{x:1278,y:585,t:1526930230279};\\\", \\\"{x:1278,y:590,t:1526930230295};\\\", \\\"{x:1278,y:598,t:1526930230311};\\\", \\\"{x:1278,y:603,t:1526930230328};\\\", \\\"{x:1278,y:608,t:1526930230344};\\\", \\\"{x:1278,y:616,t:1526930230362};\\\", \\\"{x:1278,y:626,t:1526930230379};\\\", \\\"{x:1278,y:636,t:1526930230395};\\\", \\\"{x:1278,y:646,t:1526930230412};\\\", \\\"{x:1278,y:657,t:1526930230429};\\\", \\\"{x:1278,y:667,t:1526930230445};\\\", \\\"{x:1278,y:678,t:1526930230463};\\\", \\\"{x:1278,y:693,t:1526930230479};\\\", \\\"{x:1279,y:710,t:1526930230495};\\\", \\\"{x:1280,y:729,t:1526930230513};\\\", \\\"{x:1280,y:740,t:1526930230528};\\\", \\\"{x:1280,y:753,t:1526930230545};\\\", \\\"{x:1280,y:760,t:1526930230562};\\\", \\\"{x:1280,y:765,t:1526930230579};\\\", \\\"{x:1280,y:772,t:1526930230596};\\\", \\\"{x:1281,y:777,t:1526930230612};\\\", \\\"{x:1282,y:783,t:1526930230629};\\\", \\\"{x:1282,y:788,t:1526930230646};\\\", \\\"{x:1284,y:792,t:1526930230662};\\\", \\\"{x:1284,y:796,t:1526930230679};\\\", \\\"{x:1285,y:803,t:1526930230697};\\\", \\\"{x:1285,y:806,t:1526930230713};\\\", \\\"{x:1286,y:808,t:1526930230729};\\\", \\\"{x:1286,y:811,t:1526930230746};\\\", \\\"{x:1287,y:816,t:1526930230762};\\\", \\\"{x:1287,y:821,t:1526930230779};\\\", \\\"{x:1287,y:826,t:1526930230797};\\\", \\\"{x:1287,y:831,t:1526930230812};\\\", \\\"{x:1287,y:836,t:1526930230829};\\\", \\\"{x:1287,y:840,t:1526930230846};\\\", \\\"{x:1288,y:844,t:1526930230862};\\\", \\\"{x:1289,y:851,t:1526930230880};\\\", \\\"{x:1289,y:857,t:1526930230896};\\\", \\\"{x:1289,y:859,t:1526930230913};\\\", \\\"{x:1289,y:862,t:1526930230930};\\\", \\\"{x:1290,y:869,t:1526930230946};\\\", \\\"{x:1290,y:874,t:1526930230963};\\\", \\\"{x:1290,y:882,t:1526930230979};\\\", \\\"{x:1290,y:888,t:1526930230996};\\\", \\\"{x:1290,y:892,t:1526930231012};\\\", \\\"{x:1290,y:895,t:1526930231029};\\\", \\\"{x:1290,y:899,t:1526930231046};\\\", \\\"{x:1290,y:901,t:1526930231062};\\\", \\\"{x:1290,y:905,t:1526930231079};\\\", \\\"{x:1290,y:909,t:1526930231096};\\\", \\\"{x:1289,y:914,t:1526930231113};\\\", \\\"{x:1288,y:917,t:1526930231129};\\\", \\\"{x:1288,y:920,t:1526930231146};\\\", \\\"{x:1288,y:922,t:1526930231162};\\\", \\\"{x:1287,y:924,t:1526930231179};\\\", \\\"{x:1287,y:926,t:1526930231196};\\\", \\\"{x:1287,y:927,t:1526930231213};\\\", \\\"{x:1287,y:929,t:1526930231230};\\\", \\\"{x:1287,y:933,t:1526930231247};\\\", \\\"{x:1287,y:935,t:1526930231263};\\\", \\\"{x:1285,y:937,t:1526930231279};\\\", \\\"{x:1284,y:940,t:1526930231296};\\\", \\\"{x:1284,y:942,t:1526930231321};\\\", \\\"{x:1284,y:943,t:1526930231336};\\\", \\\"{x:1284,y:945,t:1526930231347};\\\", \\\"{x:1284,y:946,t:1526930231364};\\\", \\\"{x:1283,y:948,t:1526930231380};\\\", \\\"{x:1283,y:949,t:1526930231396};\\\", \\\"{x:1283,y:951,t:1526930231413};\\\", \\\"{x:1283,y:952,t:1526930231433};\\\", \\\"{x:1282,y:953,t:1526930231447};\\\", \\\"{x:1282,y:954,t:1526930231464};\\\", \\\"{x:1282,y:956,t:1526930231480};\\\", \\\"{x:1282,y:958,t:1526930231496};\\\", \\\"{x:1282,y:962,t:1526930231512};\\\", \\\"{x:1281,y:965,t:1526930231529};\\\", \\\"{x:1281,y:968,t:1526930231546};\\\", \\\"{x:1281,y:969,t:1526930231563};\\\", \\\"{x:1281,y:970,t:1526930231578};\\\", \\\"{x:1281,y:971,t:1526930239025};\\\", \\\"{x:1290,y:970,t:1526930239035};\\\", \\\"{x:1322,y:959,t:1526930239051};\\\", \\\"{x:1341,y:955,t:1526930239068};\\\", \\\"{x:1356,y:950,t:1526930239084};\\\", \\\"{x:1364,y:949,t:1526930239101};\\\", \\\"{x:1371,y:948,t:1526930239118};\\\", \\\"{x:1374,y:947,t:1526930239135};\\\", \\\"{x:1372,y:947,t:1526930239513};\\\", \\\"{x:1370,y:949,t:1526930239528};\\\", \\\"{x:1368,y:951,t:1526930239553};\\\", \\\"{x:1367,y:951,t:1526930239568};\\\", \\\"{x:1367,y:952,t:1526930239584};\\\", \\\"{x:1366,y:952,t:1526930239601};\\\", \\\"{x:1365,y:953,t:1526930239617};\\\", \\\"{x:1363,y:955,t:1526930239634};\\\", \\\"{x:1362,y:956,t:1526930239652};\\\", \\\"{x:1360,y:957,t:1526930239667};\\\", \\\"{x:1358,y:958,t:1526930239684};\\\", \\\"{x:1357,y:959,t:1526930239702};\\\", \\\"{x:1356,y:959,t:1526930239729};\\\", \\\"{x:1355,y:959,t:1526930239889};\\\", \\\"{x:1354,y:957,t:1526930239901};\\\", \\\"{x:1352,y:949,t:1526930239917};\\\", \\\"{x:1350,y:942,t:1526930239935};\\\", \\\"{x:1350,y:936,t:1526930239953};\\\", \\\"{x:1350,y:931,t:1526930239968};\\\", \\\"{x:1350,y:926,t:1526930239984};\\\", \\\"{x:1350,y:920,t:1526930240002};\\\", \\\"{x:1350,y:915,t:1526930240019};\\\", \\\"{x:1350,y:910,t:1526930240035};\\\", \\\"{x:1350,y:905,t:1526930240051};\\\", \\\"{x:1350,y:901,t:1526930240069};\\\", \\\"{x:1350,y:896,t:1526930240085};\\\", \\\"{x:1350,y:893,t:1526930240102};\\\", \\\"{x:1350,y:890,t:1526930240119};\\\", \\\"{x:1350,y:886,t:1526930240134};\\\", \\\"{x:1350,y:875,t:1526930240152};\\\", \\\"{x:1348,y:865,t:1526930240168};\\\", \\\"{x:1347,y:857,t:1526930240185};\\\", \\\"{x:1346,y:851,t:1526930240202};\\\", \\\"{x:1346,y:846,t:1526930240219};\\\", \\\"{x:1346,y:840,t:1526930240234};\\\", \\\"{x:1346,y:832,t:1526930240252};\\\", \\\"{x:1347,y:820,t:1526930240269};\\\", \\\"{x:1347,y:810,t:1526930240284};\\\", \\\"{x:1347,y:803,t:1526930240302};\\\", \\\"{x:1347,y:800,t:1526930240318};\\\", \\\"{x:1348,y:798,t:1526930240334};\\\", \\\"{x:1348,y:796,t:1526930240352};\\\", \\\"{x:1349,y:794,t:1526930240368};\\\", \\\"{x:1350,y:791,t:1526930240385};\\\", \\\"{x:1351,y:789,t:1526930240402};\\\", \\\"{x:1352,y:786,t:1526930240418};\\\", \\\"{x:1352,y:783,t:1526930240434};\\\", \\\"{x:1352,y:781,t:1526930240451};\\\", \\\"{x:1352,y:778,t:1526930240469};\\\", \\\"{x:1354,y:774,t:1526930240485};\\\", \\\"{x:1354,y:772,t:1526930240502};\\\", \\\"{x:1354,y:770,t:1526930240518};\\\", \\\"{x:1342,y:770,t:1526930240641};\\\", \\\"{x:1306,y:761,t:1526930240651};\\\", \\\"{x:1186,y:736,t:1526930240669};\\\", \\\"{x:1025,y:707,t:1526930240686};\\\", \\\"{x:858,y:681,t:1526930240702};\\\", \\\"{x:683,y:670,t:1526930240719};\\\", \\\"{x:487,y:670,t:1526930240735};\\\", \\\"{x:324,y:663,t:1526930240755};\\\", \\\"{x:322,y:664,t:1526930241344};\\\", \\\"{x:324,y:659,t:1526930241360};\\\", \\\"{x:312,y:659,t:1526930241375};\\\", \\\"{x:298,y:658,t:1526930241391};\\\", \\\"{x:291,y:657,t:1526930241408};\\\", \\\"{x:289,y:656,t:1526930241424};\\\", \\\"{x:287,y:655,t:1526930241441};\\\", \\\"{x:285,y:654,t:1526930241458};\\\", \\\"{x:282,y:651,t:1526930241475};\\\", \\\"{x:272,y:648,t:1526930241493};\\\", \\\"{x:257,y:639,t:1526930241508};\\\", \\\"{x:246,y:631,t:1526930241525};\\\", \\\"{x:233,y:622,t:1526930241541};\\\", \\\"{x:218,y:611,t:1526930241558};\\\", \\\"{x:208,y:603,t:1526930241574};\\\", \\\"{x:196,y:593,t:1526930241592};\\\", \\\"{x:174,y:576,t:1526930241607};\\\", \\\"{x:163,y:565,t:1526930241624};\\\", \\\"{x:153,y:553,t:1526930241642};\\\", \\\"{x:143,y:545,t:1526930241658};\\\", \\\"{x:134,y:539,t:1526930241674};\\\", \\\"{x:130,y:536,t:1526930241691};\\\", \\\"{x:130,y:535,t:1526930241784};\\\", \\\"{x:131,y:535,t:1526930242121};\\\", \\\"{x:132,y:535,t:1526930242152};\\\", \\\"{x:135,y:535,t:1526930242793};\\\", \\\"{x:136,y:535,t:1526930242810};\\\", \\\"{x:138,y:535,t:1526930242840};\\\", \\\"{x:139,y:535,t:1526930242856};\\\", \\\"{x:140,y:535,t:1526930242880};\\\", \\\"{x:141,y:535,t:1526930242913};\\\", \\\"{x:142,y:535,t:1526930243169};\\\", \\\"{x:142,y:535,t:1526930243201};\\\", \\\"{x:143,y:535,t:1526930243481};\\\", \\\"{x:144,y:536,t:1526930243560};\\\", \\\"{x:144,y:537,t:1526930243584};\\\", \\\"{x:145,y:537,t:1526930243593};\\\", \\\"{x:146,y:537,t:1526930243609};\\\", \\\"{x:150,y:539,t:1526930243627};\\\", \\\"{x:151,y:539,t:1526930243644};\\\", \\\"{x:152,y:540,t:1526930243659};\\\", \\\"{x:153,y:541,t:1526930244096};\\\", \\\"{x:159,y:549,t:1526930244110};\\\", \\\"{x:177,y:566,t:1526930244128};\\\", \\\"{x:193,y:578,t:1526930244144};\\\", \\\"{x:222,y:592,t:1526930244159};\\\", \\\"{x:247,y:601,t:1526930244177};\\\", \\\"{x:277,y:614,t:1526930244195};\\\", \\\"{x:307,y:627,t:1526930244211};\\\", \\\"{x:333,y:639,t:1526930244228};\\\", \\\"{x:353,y:649,t:1526930244243};\\\", \\\"{x:371,y:655,t:1526930244260};\\\", \\\"{x:388,y:664,t:1526930244277};\\\", \\\"{x:410,y:676,t:1526930244293};\\\", \\\"{x:420,y:682,t:1526930244310};\\\", \\\"{x:430,y:687,t:1526930244327};\\\", \\\"{x:436,y:691,t:1526930244343};\\\", \\\"{x:438,y:692,t:1526930244360};\\\", \\\"{x:439,y:693,t:1526930244378};\\\", \\\"{x:440,y:694,t:1526930244393};\\\", \\\"{x:441,y:695,t:1526930244411};\\\", \\\"{x:446,y:701,t:1526930244428};\\\", \\\"{x:453,y:710,t:1526930244443};\\\", \\\"{x:459,y:716,t:1526930244460};\\\", \\\"{x:467,y:722,t:1526930244478};\\\", \\\"{x:473,y:727,t:1526930244493};\\\", \\\"{x:479,y:731,t:1526930244510};\\\", \\\"{x:481,y:732,t:1526930244527};\\\", \\\"{x:483,y:734,t:1526930244544};\\\", \\\"{x:485,y:735,t:1526930244560};\\\" ] }, { \\\"rt\\\": 33899, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 602970, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:487,y:735,t:1526930246928};\\\", \\\"{x:493,y:735,t:1526930246936};\\\", \\\"{x:500,y:735,t:1526930246946};\\\", \\\"{x:520,y:735,t:1526930246963};\\\", \\\"{x:547,y:738,t:1526930246979};\\\", \\\"{x:585,y:747,t:1526930246997};\\\", \\\"{x:623,y:756,t:1526930247013};\\\", \\\"{x:647,y:764,t:1526930247030};\\\", \\\"{x:654,y:768,t:1526930247045};\\\", \\\"{x:656,y:768,t:1526930248041};\\\", \\\"{x:658,y:758,t:1526930248048};\\\", \\\"{x:662,y:731,t:1526930248064};\\\", \\\"{x:667,y:706,t:1526930248080};\\\", \\\"{x:669,y:685,t:1526930248097};\\\", \\\"{x:672,y:663,t:1526930248114};\\\", \\\"{x:674,y:641,t:1526930248131};\\\", \\\"{x:678,y:622,t:1526930248146};\\\", \\\"{x:680,y:602,t:1526930248164};\\\", \\\"{x:680,y:582,t:1526930248179};\\\", \\\"{x:680,y:562,t:1526930248196};\\\", \\\"{x:680,y:549,t:1526930248213};\\\", \\\"{x:682,y:542,t:1526930248229};\\\", \\\"{x:683,y:533,t:1526930248247};\\\", \\\"{x:688,y:518,t:1526930248264};\\\", \\\"{x:689,y:512,t:1526930248280};\\\", \\\"{x:692,y:503,t:1526930248296};\\\", \\\"{x:697,y:495,t:1526930248314};\\\", \\\"{x:701,y:488,t:1526930248331};\\\", \\\"{x:705,y:481,t:1526930248347};\\\", \\\"{x:710,y:476,t:1526930248363};\\\", \\\"{x:714,y:471,t:1526930248381};\\\", \\\"{x:719,y:465,t:1526930248397};\\\", \\\"{x:727,y:460,t:1526930248414};\\\", \\\"{x:735,y:454,t:1526930248430};\\\", \\\"{x:752,y:446,t:1526930248447};\\\", \\\"{x:765,y:440,t:1526930248464};\\\", \\\"{x:778,y:435,t:1526930248481};\\\", \\\"{x:795,y:429,t:1526930248498};\\\", \\\"{x:812,y:425,t:1526930248514};\\\", \\\"{x:825,y:420,t:1526930248530};\\\", \\\"{x:840,y:414,t:1526930248547};\\\", \\\"{x:853,y:412,t:1526930248565};\\\", \\\"{x:869,y:407,t:1526930248580};\\\", \\\"{x:894,y:401,t:1526930248597};\\\", \\\"{x:913,y:399,t:1526930248615};\\\", \\\"{x:951,y:398,t:1526930248632};\\\", \\\"{x:984,y:398,t:1526930248649};\\\", \\\"{x:1028,y:405,t:1526930248665};\\\", \\\"{x:1054,y:412,t:1526930248682};\\\", \\\"{x:1080,y:420,t:1526930248699};\\\", \\\"{x:1107,y:429,t:1526930248715};\\\", \\\"{x:1137,y:439,t:1526930248732};\\\", \\\"{x:1176,y:455,t:1526930248748};\\\", \\\"{x:1216,y:469,t:1526930248765};\\\", \\\"{x:1247,y:478,t:1526930248782};\\\", \\\"{x:1274,y:487,t:1526930248799};\\\", \\\"{x:1312,y:502,t:1526930248817};\\\", \\\"{x:1337,y:516,t:1526930248833};\\\", \\\"{x:1358,y:529,t:1526930248849};\\\", \\\"{x:1375,y:542,t:1526930248866};\\\", \\\"{x:1395,y:553,t:1526930248882};\\\", \\\"{x:1415,y:563,t:1526930248902};\\\", \\\"{x:1432,y:573,t:1526930248917};\\\", \\\"{x:1448,y:583,t:1526930248933};\\\", \\\"{x:1461,y:592,t:1526930248948};\\\", \\\"{x:1471,y:599,t:1526930248966};\\\", \\\"{x:1480,y:603,t:1526930248983};\\\", \\\"{x:1484,y:605,t:1526930248999};\\\", \\\"{x:1486,y:607,t:1526930249015};\\\", \\\"{x:1490,y:611,t:1526930249033};\\\", \\\"{x:1494,y:616,t:1526930249050};\\\", \\\"{x:1499,y:622,t:1526930249066};\\\", \\\"{x:1504,y:627,t:1526930249083};\\\", \\\"{x:1505,y:627,t:1526930249100};\\\", \\\"{x:1505,y:628,t:1526930249792};\\\", \\\"{x:1505,y:629,t:1526930249849};\\\", \\\"{x:1505,y:630,t:1526930249865};\\\", \\\"{x:1503,y:632,t:1526930250577};\\\", \\\"{x:1498,y:636,t:1526930250588};\\\", \\\"{x:1489,y:641,t:1526930250606};\\\", \\\"{x:1478,y:648,t:1526930250622};\\\", \\\"{x:1462,y:655,t:1526930250638};\\\", \\\"{x:1440,y:661,t:1526930250656};\\\", \\\"{x:1405,y:665,t:1526930250673};\\\", \\\"{x:1382,y:665,t:1526930250688};\\\", \\\"{x:1363,y:666,t:1526930250705};\\\", \\\"{x:1345,y:668,t:1526930250722};\\\", \\\"{x:1326,y:672,t:1526930250739};\\\", \\\"{x:1309,y:677,t:1526930250755};\\\", \\\"{x:1292,y:683,t:1526930250772};\\\", \\\"{x:1280,y:689,t:1526930250789};\\\", \\\"{x:1268,y:696,t:1526930250807};\\\", \\\"{x:1259,y:705,t:1526930250822};\\\", \\\"{x:1247,y:723,t:1526930250840};\\\", \\\"{x:1236,y:747,t:1526930250856};\\\", \\\"{x:1231,y:767,t:1526930250872};\\\", \\\"{x:1227,y:783,t:1526930250889};\\\", \\\"{x:1227,y:792,t:1526930250906};\\\", \\\"{x:1227,y:799,t:1526930250923};\\\", \\\"{x:1227,y:806,t:1526930250939};\\\", \\\"{x:1227,y:810,t:1526930250956};\\\", \\\"{x:1228,y:811,t:1526930250973};\\\", \\\"{x:1229,y:813,t:1526930250990};\\\", \\\"{x:1231,y:815,t:1526930251753};\\\", \\\"{x:1246,y:816,t:1526930251760};\\\", \\\"{x:1302,y:829,t:1526930251776};\\\", \\\"{x:1387,y:850,t:1526930251792};\\\", \\\"{x:1477,y:869,t:1526930251809};\\\", \\\"{x:1561,y:880,t:1526930251826};\\\", \\\"{x:1618,y:891,t:1526930251842};\\\", \\\"{x:1646,y:894,t:1526930251859};\\\", \\\"{x:1659,y:897,t:1526930251877};\\\", \\\"{x:1662,y:897,t:1526930251893};\\\", \\\"{x:1661,y:897,t:1526930252073};\\\", \\\"{x:1656,y:896,t:1526930252080};\\\", \\\"{x:1647,y:893,t:1526930252093};\\\", \\\"{x:1629,y:885,t:1526930252110};\\\", \\\"{x:1603,y:876,t:1526930252128};\\\", \\\"{x:1565,y:868,t:1526930252145};\\\", \\\"{x:1554,y:867,t:1526930252161};\\\", \\\"{x:1552,y:867,t:1526930252177};\\\", \\\"{x:1550,y:867,t:1526930252208};\\\", \\\"{x:1549,y:867,t:1526930252249};\\\", \\\"{x:1548,y:867,t:1526930252261};\\\", \\\"{x:1547,y:867,t:1526930252277};\\\", \\\"{x:1543,y:867,t:1526930252680};\\\", \\\"{x:1537,y:867,t:1526930252695};\\\", \\\"{x:1520,y:867,t:1526930252712};\\\", \\\"{x:1508,y:867,t:1526930252729};\\\", \\\"{x:1492,y:861,t:1526930252746};\\\", \\\"{x:1471,y:856,t:1526930252763};\\\", \\\"{x:1461,y:853,t:1526930252779};\\\", \\\"{x:1457,y:851,t:1526930252796};\\\", \\\"{x:1456,y:851,t:1526930252812};\\\", \\\"{x:1455,y:851,t:1526930252848};\\\", \\\"{x:1454,y:850,t:1526930253305};\\\", \\\"{x:1454,y:853,t:1526930253328};\\\", \\\"{x:1454,y:859,t:1526930253337};\\\", \\\"{x:1454,y:867,t:1526930253348};\\\", \\\"{x:1454,y:882,t:1526930253364};\\\", \\\"{x:1454,y:899,t:1526930253382};\\\", \\\"{x:1454,y:917,t:1526930253399};\\\", \\\"{x:1454,y:929,t:1526930253414};\\\", \\\"{x:1457,y:942,t:1526930253431};\\\", \\\"{x:1461,y:950,t:1526930253448};\\\", \\\"{x:1462,y:951,t:1526930253481};\\\", \\\"{x:1463,y:952,t:1526930253761};\\\", \\\"{x:1463,y:953,t:1526930253769};\\\", \\\"{x:1463,y:955,t:1526930253783};\\\", \\\"{x:1465,y:957,t:1526930253799};\\\", \\\"{x:1468,y:958,t:1526930253816};\\\", \\\"{x:1470,y:959,t:1526930253833};\\\", \\\"{x:1471,y:959,t:1526930253903};\\\", \\\"{x:1472,y:959,t:1526930253916};\\\", \\\"{x:1475,y:959,t:1526930253933};\\\", \\\"{x:1478,y:959,t:1526930253950};\\\", \\\"{x:1479,y:958,t:1526930253965};\\\", \\\"{x:1480,y:958,t:1526930254023};\\\", \\\"{x:1479,y:958,t:1526930261224};\\\", \\\"{x:1466,y:957,t:1526930261242};\\\", \\\"{x:1454,y:956,t:1526930261259};\\\", \\\"{x:1439,y:956,t:1526930261275};\\\", \\\"{x:1426,y:959,t:1526930261292};\\\", \\\"{x:1418,y:959,t:1526930261308};\\\", \\\"{x:1413,y:959,t:1526930261325};\\\", \\\"{x:1411,y:959,t:1526930261342};\\\", \\\"{x:1410,y:959,t:1526930261360};\\\", \\\"{x:1408,y:960,t:1526930261376};\\\", \\\"{x:1406,y:961,t:1526930261392};\\\", \\\"{x:1396,y:962,t:1526930261408};\\\", \\\"{x:1391,y:962,t:1526930261425};\\\", \\\"{x:1386,y:963,t:1526930261442};\\\", \\\"{x:1384,y:963,t:1526930261458};\\\", \\\"{x:1382,y:964,t:1526930261475};\\\", \\\"{x:1381,y:964,t:1526930261492};\\\", \\\"{x:1380,y:965,t:1526930261527};\\\", \\\"{x:1378,y:965,t:1526930261542};\\\", \\\"{x:1377,y:965,t:1526930261559};\\\", \\\"{x:1371,y:965,t:1526930261576};\\\", \\\"{x:1366,y:965,t:1526930261592};\\\", \\\"{x:1363,y:965,t:1526930261609};\\\", \\\"{x:1362,y:965,t:1526930261705};\\\", \\\"{x:1361,y:965,t:1526930261928};\\\", \\\"{x:1359,y:965,t:1526930261968};\\\", \\\"{x:1358,y:965,t:1526930262384};\\\", \\\"{x:1357,y:965,t:1526930262396};\\\", \\\"{x:1354,y:964,t:1526930262413};\\\", \\\"{x:1350,y:963,t:1526930262429};\\\", \\\"{x:1348,y:962,t:1526930262445};\\\", \\\"{x:1347,y:962,t:1526930262464};\\\", \\\"{x:1347,y:961,t:1526930262480};\\\", \\\"{x:1347,y:957,t:1526930264545};\\\", \\\"{x:1347,y:940,t:1526930264552};\\\", \\\"{x:1347,y:910,t:1526930264570};\\\", \\\"{x:1347,y:884,t:1526930264587};\\\", \\\"{x:1350,y:861,t:1526930264603};\\\", \\\"{x:1353,y:835,t:1526930264620};\\\", \\\"{x:1355,y:809,t:1526930264636};\\\", \\\"{x:1355,y:783,t:1526930264653};\\\", \\\"{x:1353,y:760,t:1526930264671};\\\", \\\"{x:1351,y:739,t:1526930264687};\\\", \\\"{x:1348,y:714,t:1526930264704};\\\", \\\"{x:1347,y:700,t:1526930264722};\\\", \\\"{x:1346,y:689,t:1526930264737};\\\", \\\"{x:1346,y:685,t:1526930264753};\\\", \\\"{x:1345,y:684,t:1526930264771};\\\", \\\"{x:1345,y:682,t:1526930264787};\\\", \\\"{x:1345,y:681,t:1526930264804};\\\", \\\"{x:1345,y:680,t:1526930264864};\\\", \\\"{x:1343,y:680,t:1526930264905};\\\", \\\"{x:1329,y:684,t:1526930264922};\\\", \\\"{x:1304,y:688,t:1526930264938};\\\", \\\"{x:1268,y:690,t:1526930264954};\\\", \\\"{x:1215,y:690,t:1526930264971};\\\", \\\"{x:1132,y:690,t:1526930264988};\\\", \\\"{x:1022,y:684,t:1526930265005};\\\", \\\"{x:903,y:666,t:1526930265021};\\\", \\\"{x:782,y:652,t:1526930265037};\\\", \\\"{x:662,y:633,t:1526930265056};\\\", \\\"{x:471,y:614,t:1526930265071};\\\", \\\"{x:360,y:600,t:1526930265088};\\\", \\\"{x:162,y:594,t:1526930265128};\\\", \\\"{x:134,y:594,t:1526930265145};\\\", \\\"{x:118,y:594,t:1526930265160};\\\", \\\"{x:114,y:594,t:1526930265177};\\\", \\\"{x:116,y:594,t:1526930265368};\\\", \\\"{x:118,y:594,t:1526930265378};\\\", \\\"{x:127,y:594,t:1526930265394};\\\", \\\"{x:140,y:594,t:1526930265410};\\\", \\\"{x:148,y:594,t:1526930265428};\\\", \\\"{x:157,y:594,t:1526930265443};\\\", \\\"{x:161,y:594,t:1526930265461};\\\", \\\"{x:162,y:594,t:1526930265477};\\\", \\\"{x:164,y:594,t:1526930265784};\\\", \\\"{x:167,y:594,t:1526930265794};\\\", \\\"{x:186,y:594,t:1526930265812};\\\", \\\"{x:228,y:594,t:1526930265828};\\\", \\\"{x:311,y:594,t:1526930265845};\\\", \\\"{x:408,y:594,t:1526930265861};\\\", \\\"{x:513,y:594,t:1526930265879};\\\", \\\"{x:622,y:597,t:1526930265895};\\\", \\\"{x:760,y:607,t:1526930265911};\\\", \\\"{x:834,y:614,t:1526930265928};\\\", \\\"{x:877,y:615,t:1526930265944};\\\", \\\"{x:900,y:616,t:1526930265961};\\\", \\\"{x:911,y:616,t:1526930265977};\\\", \\\"{x:917,y:616,t:1526930265994};\\\", \\\"{x:921,y:616,t:1526930266011};\\\", \\\"{x:928,y:616,t:1526930266028};\\\", \\\"{x:935,y:615,t:1526930266044};\\\", \\\"{x:943,y:614,t:1526930266061};\\\", \\\"{x:950,y:611,t:1526930266078};\\\", \\\"{x:953,y:610,t:1526930266094};\\\", \\\"{x:954,y:609,t:1526930266111};\\\", \\\"{x:954,y:608,t:1526930266151};\\\", \\\"{x:954,y:606,t:1526930266162};\\\", \\\"{x:952,y:597,t:1526930266178};\\\", \\\"{x:948,y:589,t:1526930266195};\\\", \\\"{x:940,y:581,t:1526930266210};\\\", \\\"{x:931,y:574,t:1526930266229};\\\", \\\"{x:920,y:566,t:1526930266245};\\\", \\\"{x:909,y:559,t:1526930266261};\\\", \\\"{x:900,y:552,t:1526930266278};\\\", \\\"{x:894,y:546,t:1526930266294};\\\", \\\"{x:891,y:542,t:1526930266311};\\\", \\\"{x:889,y:539,t:1526930266328};\\\", \\\"{x:889,y:535,t:1526930266345};\\\", \\\"{x:886,y:531,t:1526930266362};\\\", \\\"{x:884,y:528,t:1526930266378};\\\", \\\"{x:883,y:526,t:1526930266395};\\\", \\\"{x:880,y:523,t:1526930266412};\\\", \\\"{x:879,y:521,t:1526930266428};\\\", \\\"{x:874,y:520,t:1526930266445};\\\", \\\"{x:869,y:517,t:1526930266462};\\\", \\\"{x:860,y:514,t:1526930266480};\\\", \\\"{x:845,y:509,t:1526930266496};\\\", \\\"{x:841,y:508,t:1526930266512};\\\", \\\"{x:841,y:509,t:1526930267039};\\\", \\\"{x:849,y:517,t:1526930267048};\\\", \\\"{x:862,y:528,t:1526930267063};\\\", \\\"{x:901,y:556,t:1526930267079};\\\", \\\"{x:987,y:598,t:1526930267096};\\\", \\\"{x:1077,y:634,t:1526930267113};\\\", \\\"{x:1169,y:663,t:1526930267129};\\\", \\\"{x:1266,y:693,t:1526930267145};\\\", \\\"{x:1352,y:716,t:1526930267163};\\\", \\\"{x:1429,y:736,t:1526930267180};\\\", \\\"{x:1470,y:746,t:1526930267196};\\\", \\\"{x:1491,y:749,t:1526930267212};\\\", \\\"{x:1495,y:749,t:1526930267230};\\\", \\\"{x:1497,y:749,t:1526930267246};\\\", \\\"{x:1498,y:748,t:1526930267361};\\\", \\\"{x:1494,y:743,t:1526930267368};\\\", \\\"{x:1486,y:738,t:1526930267380};\\\", \\\"{x:1468,y:730,t:1526930267395};\\\", \\\"{x:1444,y:721,t:1526930267413};\\\", \\\"{x:1423,y:718,t:1526930267430};\\\", \\\"{x:1402,y:715,t:1526930267446};\\\", \\\"{x:1383,y:714,t:1526930267462};\\\", \\\"{x:1372,y:714,t:1526930267480};\\\", \\\"{x:1371,y:713,t:1526930267495};\\\", \\\"{x:1371,y:712,t:1526930267769};\\\", \\\"{x:1370,y:710,t:1526930267780};\\\", \\\"{x:1370,y:709,t:1526930267797};\\\", \\\"{x:1370,y:708,t:1526930267813};\\\", \\\"{x:1370,y:707,t:1526930267830};\\\", \\\"{x:1368,y:706,t:1526930267847};\\\", \\\"{x:1368,y:705,t:1526930267862};\\\", \\\"{x:1364,y:700,t:1526930267880};\\\", \\\"{x:1361,y:697,t:1526930267896};\\\", \\\"{x:1356,y:694,t:1526930267913};\\\", \\\"{x:1352,y:690,t:1526930267930};\\\", \\\"{x:1345,y:686,t:1526930267947};\\\", \\\"{x:1337,y:681,t:1526930267963};\\\", \\\"{x:1325,y:674,t:1526930267980};\\\", \\\"{x:1310,y:664,t:1526930267997};\\\", \\\"{x:1291,y:654,t:1526930268013};\\\", \\\"{x:1275,y:645,t:1526930268030};\\\", \\\"{x:1261,y:635,t:1526930268047};\\\", \\\"{x:1250,y:625,t:1526930268063};\\\", \\\"{x:1236,y:612,t:1526930268081};\\\", \\\"{x:1229,y:604,t:1526930268097};\\\", \\\"{x:1226,y:600,t:1526930268114};\\\", \\\"{x:1226,y:598,t:1526930268130};\\\", \\\"{x:1226,y:597,t:1526930268147};\\\", \\\"{x:1227,y:596,t:1526930268265};\\\", \\\"{x:1229,y:595,t:1526930268280};\\\", \\\"{x:1231,y:593,t:1526930268297};\\\", \\\"{x:1235,y:590,t:1526930268314};\\\", \\\"{x:1240,y:586,t:1526930268330};\\\", \\\"{x:1242,y:585,t:1526930268347};\\\", \\\"{x:1245,y:583,t:1526930268364};\\\", \\\"{x:1246,y:582,t:1526930268380};\\\", \\\"{x:1248,y:581,t:1526930268397};\\\", \\\"{x:1248,y:580,t:1526930268414};\\\", \\\"{x:1249,y:579,t:1526930268431};\\\", \\\"{x:1251,y:579,t:1526930268447};\\\", \\\"{x:1253,y:578,t:1526930268464};\\\", \\\"{x:1255,y:577,t:1526930268480};\\\", \\\"{x:1258,y:576,t:1526930268497};\\\", \\\"{x:1262,y:575,t:1526930268514};\\\", \\\"{x:1265,y:575,t:1526930268530};\\\", \\\"{x:1269,y:574,t:1526930268547};\\\", \\\"{x:1271,y:574,t:1526930268564};\\\", \\\"{x:1275,y:573,t:1526930268580};\\\", \\\"{x:1277,y:573,t:1526930268597};\\\", \\\"{x:1278,y:573,t:1526930268614};\\\", \\\"{x:1279,y:573,t:1526930268631};\\\", \\\"{x:1281,y:572,t:1526930268665};\\\", \\\"{x:1282,y:573,t:1526930268817};\\\", \\\"{x:1282,y:578,t:1526930268831};\\\", \\\"{x:1281,y:611,t:1526930268848};\\\", \\\"{x:1278,y:639,t:1526930268864};\\\", \\\"{x:1274,y:668,t:1526930268881};\\\", \\\"{x:1269,y:693,t:1526930268897};\\\", \\\"{x:1265,y:715,t:1526930268914};\\\", \\\"{x:1263,y:732,t:1526930268931};\\\", \\\"{x:1262,y:746,t:1526930268948};\\\", \\\"{x:1262,y:754,t:1526930268964};\\\", \\\"{x:1262,y:768,t:1526930268981};\\\", \\\"{x:1262,y:784,t:1526930268998};\\\", \\\"{x:1262,y:795,t:1526930269014};\\\", \\\"{x:1264,y:806,t:1526930269031};\\\", \\\"{x:1265,y:822,t:1526930269048};\\\", \\\"{x:1269,y:831,t:1526930269064};\\\", \\\"{x:1271,y:840,t:1526930269081};\\\", \\\"{x:1274,y:847,t:1526930269098};\\\", \\\"{x:1277,y:857,t:1526930269114};\\\", \\\"{x:1279,y:869,t:1526930269131};\\\", \\\"{x:1282,y:881,t:1526930269148};\\\", \\\"{x:1283,y:891,t:1526930269164};\\\", \\\"{x:1283,y:904,t:1526930269181};\\\", \\\"{x:1283,y:917,t:1526930269198};\\\", \\\"{x:1283,y:927,t:1526930269216};\\\", \\\"{x:1282,y:934,t:1526930269232};\\\", \\\"{x:1282,y:938,t:1526930269248};\\\", \\\"{x:1281,y:939,t:1526930269264};\\\", \\\"{x:1281,y:941,t:1526930269281};\\\", \\\"{x:1281,y:942,t:1526930269304};\\\", \\\"{x:1281,y:943,t:1526930269337};\\\", \\\"{x:1273,y:948,t:1526930277693};\\\", \\\"{x:1248,y:952,t:1526930277702};\\\", \\\"{x:1162,y:952,t:1526930277718};\\\", \\\"{x:1024,y:918,t:1526930277735};\\\", \\\"{x:878,y:879,t:1526930277752};\\\", \\\"{x:683,y:805,t:1526930277768};\\\", \\\"{x:468,y:710,t:1526930277786};\\\", \\\"{x:238,y:620,t:1526930277804};\\\", \\\"{x:59,y:547,t:1526930277818};\\\", \\\"{x:0,y:487,t:1526930277852};\\\", \\\"{x:0,y:486,t:1526930277865};\\\", \\\"{x:1,y:484,t:1526930278037};\\\", \\\"{x:16,y:484,t:1526930278050};\\\", \\\"{x:47,y:483,t:1526930278067};\\\", \\\"{x:87,y:480,t:1526930278082};\\\", \\\"{x:146,y:480,t:1526930278099};\\\", \\\"{x:204,y:480,t:1526930278116};\\\", \\\"{x:271,y:480,t:1526930278132};\\\", \\\"{x:378,y:477,t:1526930278150};\\\", \\\"{x:465,y:471,t:1526930278167};\\\", \\\"{x:553,y:465,t:1526930278183};\\\", \\\"{x:617,y:465,t:1526930278199};\\\", \\\"{x:649,y:465,t:1526930278216};\\\", \\\"{x:672,y:465,t:1526930278234};\\\", \\\"{x:690,y:465,t:1526930278250};\\\", \\\"{x:702,y:465,t:1526930278267};\\\", \\\"{x:707,y:465,t:1526930278283};\\\", \\\"{x:708,y:465,t:1526930278300};\\\", \\\"{x:709,y:466,t:1526930278333};\\\", \\\"{x:707,y:480,t:1526930278351};\\\", \\\"{x:709,y:501,t:1526930278369};\\\", \\\"{x:713,y:516,t:1526930278383};\\\", \\\"{x:717,y:526,t:1526930278403};\\\", \\\"{x:717,y:527,t:1526930278470};\\\", \\\"{x:714,y:527,t:1526930278493};\\\", \\\"{x:711,y:527,t:1526930278502};\\\", \\\"{x:705,y:527,t:1526930278520};\\\", \\\"{x:695,y:527,t:1526930278535};\\\", \\\"{x:684,y:525,t:1526930278552};\\\", \\\"{x:674,y:524,t:1526930278568};\\\", \\\"{x:660,y:523,t:1526930278585};\\\", \\\"{x:644,y:520,t:1526930278602};\\\", \\\"{x:634,y:518,t:1526930278619};\\\", \\\"{x:630,y:518,t:1526930278636};\\\", \\\"{x:626,y:517,t:1526930278652};\\\", \\\"{x:625,y:515,t:1526930279117};\\\", \\\"{x:623,y:518,t:1526930279125};\\\", \\\"{x:619,y:529,t:1526930279136};\\\", \\\"{x:614,y:550,t:1526930279153};\\\", \\\"{x:606,y:574,t:1526930279169};\\\", \\\"{x:597,y:604,t:1526930279186};\\\", \\\"{x:578,y:646,t:1526930279202};\\\", \\\"{x:561,y:683,t:1526930279219};\\\", \\\"{x:548,y:713,t:1526930279236};\\\", \\\"{x:525,y:754,t:1526930279253};\\\", \\\"{x:511,y:773,t:1526930279269};\\\", \\\"{x:501,y:786,t:1526930279286};\\\", \\\"{x:493,y:795,t:1526930279302};\\\", \\\"{x:485,y:805,t:1526930279319};\\\", \\\"{x:479,y:812,t:1526930279336};\\\", \\\"{x:478,y:813,t:1526930279353};\\\", \\\"{x:477,y:813,t:1526930279369};\\\", \\\"{x:477,y:812,t:1526930279557};\\\", \\\"{x:477,y:807,t:1526930279569};\\\", \\\"{x:477,y:798,t:1526930279586};\\\", \\\"{x:479,y:791,t:1526930279603};\\\", \\\"{x:481,y:786,t:1526930279620};\\\", \\\"{x:481,y:784,t:1526930279636};\\\", \\\"{x:482,y:780,t:1526930279653};\\\", \\\"{x:482,y:778,t:1526930279669};\\\", \\\"{x:482,y:777,t:1526930279686};\\\", \\\"{x:482,y:776,t:1526930279704};\\\", \\\"{x:482,y:774,t:1526930279719};\\\", \\\"{x:482,y:773,t:1526930279741};\\\", \\\"{x:482,y:772,t:1526930279753};\\\", \\\"{x:482,y:770,t:1526930279770};\\\", \\\"{x:482,y:768,t:1526930279788};\\\", \\\"{x:482,y:767,t:1526930279803};\\\", \\\"{x:481,y:766,t:1526930279828};\\\", \\\"{x:481,y:765,t:1526930279844};\\\", \\\"{x:481,y:764,t:1526930279860};\\\" ] }, { \\\"rt\\\": 121326, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 725627, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Read the x axis, indicated start and end time. Upon reaching the 12 pm marker, read vertically upward. The dots that fall on this line are those starting at 12 pm. They end at a time indicated by the y axis, which reads duration (in hours).\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 13671, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 740305, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 17270, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Natural Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 758595, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 26143, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 786072, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"CK5DF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"CK5DF\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 317, dom: 745, initialDom: 1245",
  "javascriptErrors": []
}