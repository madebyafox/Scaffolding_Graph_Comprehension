var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "07febaeac462abffea898d4f595bcdd3",
  "created": "2018-06-01T11:14:36.0330286-07:00",
  "lastActivity": "2018-06-01T11:15:41.8293931-07:00",
  "pageViews": [
    {
      "id": "060136841ec66e3d4c76096ba5dd868dadc39e97",
      "startTime": "2018-06-01T11:14:36.1450192-07:00",
      "endTime": "2018-06-01T11:15:41.8293931-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 65928,
      "engagementTime": 65656,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 65928,
  "engagementTime": 65656,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=1HR1L",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e6e38c692d4a896477a8a2396582658d",
  "gdpr": false
}