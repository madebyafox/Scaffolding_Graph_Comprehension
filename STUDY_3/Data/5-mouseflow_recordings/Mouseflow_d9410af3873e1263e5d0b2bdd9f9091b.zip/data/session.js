var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d9410af3873e1263e5d0b2bdd9f9091b",
  "created": "2018-05-29T15:11:47.9346095-07:00",
  "lastActivity": "2018-05-29T15:11:53.9786822-07:00",
  "pageViews": [
    {
      "id": "05294767bf5f34cfe173f0e3a421eeb0d1d0cb24",
      "startTime": "2018-05-29T15:11:48.0177591-07:00",
      "endTime": "2018-05-29T15:11:53.9786822-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 6028,
      "engagementTime": 6028,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 6028,
  "engagementTime": 6028,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=4LZ8B",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "cbbff72c9c52cba61e607b9a73a93ce8",
  "gdpr": false
}