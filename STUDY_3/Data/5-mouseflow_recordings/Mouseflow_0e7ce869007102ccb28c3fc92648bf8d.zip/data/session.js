var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0e7ce869007102ccb28c3fc92648bf8d",
  "created": "2018-05-21T12:15:45.0157888-07:00",
  "lastActivity": "2018-05-21T12:15:56.0901493-07:00",
  "pageViews": [
    {
      "id": "0521458601a7d465d56e8bce7cd226f92538436c",
      "startTime": "2018-05-21T12:15:45.463768-07:00",
      "endTime": "2018-05-21T12:15:56.0901493-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 10822,
      "engagementTime": 10822,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10822,
  "engagementTime": 10822,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=A9CZD",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "442c72072b54b47e0fb859c82385e620",
  "gdpr": false
}