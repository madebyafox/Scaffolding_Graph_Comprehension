var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "30e1426d656a5eaaef9372e2b2b231bd",
  "created": "2018-05-25T10:10:26.1982604-07:00",
  "lastActivity": "2018-05-25T10:10:43.1232604-07:00",
  "pageViews": [
    {
      "id": "05252695182cbf17f458e6571a2a13fb3cf11157",
      "startTime": "2018-05-25T10:10:26.1982604-07:00",
      "endTime": "2018-05-25T10:10:43.1232604-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 16925,
      "engagementTime": 16925,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 16925,
  "engagementTime": 16925,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CE2FW",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9ee2dd5a80e70d008c8d47d75ea3529b",
  "gdpr": false
}