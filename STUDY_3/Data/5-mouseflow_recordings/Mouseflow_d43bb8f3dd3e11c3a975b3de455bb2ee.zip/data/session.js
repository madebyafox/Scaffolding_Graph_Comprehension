var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d43bb8f3dd3e11c3a975b3de455bb2ee",
  "created": "2018-05-25T10:14:29.1981487-07:00",
  "lastActivity": "2018-05-25T10:15:30.5081487-07:00",
  "pageViews": [
    {
      "id": "052529368b4699e2e7b69308b9b7bf760bef4ad0",
      "startTime": "2018-05-25T10:14:29.1981487-07:00",
      "endTime": "2018-05-25T10:15:30.5081487-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 61310,
      "engagementTime": 44608,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 61310,
  "engagementTime": 44608,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=5QCE3",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a1c369749495be51708e0ad6ee63ed28",
  "gdpr": false
}