var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0e8ef032b9325ce4b4dadbbbdd96e0f3",
  "created": "2018-05-22T14:19:55.731403-07:00",
  "lastActivity": "2018-05-22T14:20:03.149403-07:00",
  "pageViews": [
    {
      "id": "052255899506a7025307e74ed0c0b6d259795d94",
      "startTime": "2018-05-22T14:19:55.731403-07:00",
      "endTime": "2018-05-22T14:20:03.149403-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 7418,
      "engagementTime": 7417,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 7418,
  "engagementTime": 7417,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G443Q",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "73b4cf1d0386147efdb9fa479ed2548e",
  "gdpr": false
}