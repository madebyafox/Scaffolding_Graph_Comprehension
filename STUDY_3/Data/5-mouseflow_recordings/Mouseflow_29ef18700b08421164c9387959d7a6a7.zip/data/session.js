var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "29ef18700b08421164c9387959d7a6a7",
  "created": "2018-05-29T10:11:56.7936166-07:00",
  "lastActivity": "2018-05-29T10:15:21.8366166-07:00",
  "pageViews": [
    {
      "id": "05295716c67d7f9d04ddf0481b55dd1a4f503ad4",
      "startTime": "2018-05-29T10:11:56.7936166-07:00",
      "endTime": "2018-05-29T10:15:21.8366166-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 205043,
      "engagementTime": 131372,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 205043,
  "engagementTime": 131372,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TGOML",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6b86013cc521a6cbcc78e7de8762763d",
  "gdpr": false
}