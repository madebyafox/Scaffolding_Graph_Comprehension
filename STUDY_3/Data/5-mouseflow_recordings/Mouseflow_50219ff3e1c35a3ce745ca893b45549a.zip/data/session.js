var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "50219ff3e1c35a3ce745ca893b45549a",
  "created": "2018-06-02T21:23:42.0274379-07:00",
  "lastActivity": "2018-06-02T21:23:55.0802429-07:00",
  "pageViews": [
    {
      "id": "0602420560980d4ff8d852474ef5929bc947cb5a",
      "startTime": "2018-06-02T21:23:42.0274379-07:00",
      "endTime": "2018-06-02T21:23:55.0802429-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 13490,
      "engagementTime": 13490,
      "scroll": 98.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13490,
  "engagementTime": 13490,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "San Diego",
  "isp": "Time Warner Cable",
  "ip": "66.75.255.252",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "macOS",
  "osVersion": "10.12 Sierra",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1680x1050",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2073,
  "lat": 32.8594,
  "visitorId": "33cbfce19841ee809d4f3cf0c546c343",
  "gdpr": false
}