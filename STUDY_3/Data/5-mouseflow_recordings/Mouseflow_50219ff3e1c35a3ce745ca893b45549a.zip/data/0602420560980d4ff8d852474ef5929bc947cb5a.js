var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0602420560980d4ff8d852474ef5929bc947cb5a"] = {
  "startTime": "2018-06-03T04:23:42.0274379Z",
  "websitePageUrl": "/",
  "visitTime": 13490,
  "engagementTime": 13490,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1866,
  "viewportHeight": 1028,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "50219ff3e1c35a3ce745ca893b45549a",
    "created": "2018-06-03T04:23:42.0274379+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "San Diego",
    "isp": "Time Warner Cable",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "macOS",
    "osVersion": "10.12 Sierra",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1680x1050",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8594,
    "lat": 32.8594,
    "visitorId": "33cbfce19841ee809d4f3cf0c546c343",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/50219ff3e1c35a3ce745ca893b45549a/play"
  },
  "events": [
    {
      "t": 16,
      "e": 16,
      "ty": 14,
      "x": 0,
      "y": 1044
    },
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1866,
      "y": 1028
    },
    {
      "t": 1319,
      "e": 1319,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 1980,
      "e": 1980,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 2154,
      "e": 2154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": ""
    },
    {
      "t": 2194,
      "e": 2194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "32"
    },
    {
      "t": 2194,
      "e": 2194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 2345,
      "e": 2345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": ""
    },
    {
      "t": 2347,
      "e": 2347,
      "ty": 5,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 2347,
      "e": 2347,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 2593,
      "e": 2593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "9"
    },
    {
      "t": 2594,
      "e": 2594,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 2594,
      "e": 2594,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 2769,
      "e": 2769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#start",
      "v": ""
    },
    {
      "t": 3185,
      "e": 3185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#start",
      "v": "13"
    },
    {
      "t": 3186,
      "e": 3186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 3187,
      "e": 3187,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 3188,
      "e": 3188,
      "ty": 5,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 3189,
      "e": 3189,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 4191,
      "e": 4191,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 4626,
      "e": 4626,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 4866,
      "e": 4866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "32"
    },
    {
      "t": 4866,
      "e": 4866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 4945,
      "e": 4945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": " "
    },
    {
      "t": 5417,
      "e": 5417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 5529,
      "e": 5529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 5553,
      "e": 5553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 5553,
      "e": 5553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 5633,
      "e": 5633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 5634,
      "e": 5634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 5681,
      "e": 5681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "te"
    },
    {
      "t": 5737,
      "e": 5737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "te"
    },
    {
      "t": 5850,
      "e": 5850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 5850,
      "e": 5850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 5897,
      "e": 5897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 5898,
      "e": 5898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 5985,
      "e": 5985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "test"
    },
    {
      "t": 6050,
      "e": 6050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 6138,
      "e": 6138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 6138,
      "e": 6138,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "test"
    },
    {
      "t": 6138,
      "e": 6138,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 6139,
      "e": 6139,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 6282,
      "e": 6282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 7498,
      "e": 7498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 7499,
      "e": 7499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 7584,
      "e": 7584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 7649,
      "e": 7649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 7650,
      "e": 7650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 7736,
      "e": 7736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 7794,
      "e": 7794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 7794,
      "e": 7794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 7905,
      "e": 7905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 8146,
      "e": 8146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 8147,
      "e": 8147,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 8147,
      "e": 8147,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 8147,
      "e": 8147,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 8289,
      "e": 8289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next",
      "v": ""
    },
    {
      "t": 8426,
      "e": 8426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next",
      "v": "13"
    },
    {
      "t": 8426,
      "e": 8426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 8427,
      "e": 8427,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 8427,
      "e": 8427,
      "ty": 5,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 8427,
      "e": 8427,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 9550,
      "e": 9550,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10410,
      "e": 10410,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 10521,
      "e": 10521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#start",
      "v": ""
    },
    {
      "t": 10705,
      "e": 10705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#start",
      "v": "13"
    },
    {
      "t": 10705,
      "e": 10705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 10705,
      "e": 10705,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 10707,
      "e": 10707,
      "ty": 5,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 10707,
      "e": 10707,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 11710,
      "e": 11710,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 12482,
      "e": 12482,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 13490,
      "e": 13490,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":56,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":57,\"previousSibling\":{\"id\":56},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \",\"previousSibling\":{\"id\":57},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":59,\"textContent\":\" \",\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":59},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":61,\"textContent\":\" \",\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":56}},{\"nodeType\":8,\"id\":62,\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"previousSibling\":{\"id\":62},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":56}},{\"nodeType\":8,\"id\":65,\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":66,\"textContent\":\" \",\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":67,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":56}},{\"nodeType\":8,\"id\":68,\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":69,\"textContent\":\" \",\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":72,\"textContent\":\" \",\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":74,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":73},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":75,\"textContent\":\" \",\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":76,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":74}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":80,\"textContent\":\" \",\"parentNode\":{\"id\":78}},{\"nodeType\":1,\"id\":81,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":80},\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":82,\"textContent\":\" \",\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":78}},{\"nodeType\":1,\"id\":83,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"previousSibling\":{\"id\":83},\"parentNode\":{\"id\":78}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":78}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":78}},{\"nodeType\":8,\"id\":89,\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":78}},{\"nodeType\":1,\"id\":91,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":93,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":81}},{\"nodeType\":3,\"id\":94,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":83}},{\"nodeType\":3,\"id\":95,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":96,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":97,\"textContent\":\" \",\"parentNode\":{\"id\":91}},{\"nodeType\":1,\"id\":98,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":97},\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":99,\"textContent\":\" \",\"previousSibling\":{\"id\":98},\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":100,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":98}},{\"nodeType\":1,\"id\":101,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":100},\"parentNode\":{\"id\":98}},{\"nodeType\":3,\"id\":102,\"textContent\":\" \",\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":98}},{\"nodeType\":1,\"id\":103,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":98}},{\"nodeType\":3,\"id\":104,\"textContent\":\" \",\"previousSibling\":{\"id\":103},\"parentNode\":{\"id\":98}},{\"nodeType\":3,\"id\":105,\"textContent\":\" \",\"parentNode\":{\"id\":67}},{\"nodeType\":1,\"id\":106,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":67}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \",\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":67}},{\"nodeType\":3,\"id\":108,\"textContent\":\"START\",\"parentNode\":{\"id\":106}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":59},{\"id\":60},{\"id\":70},{\"id\":71},{\"id\":73},{\"id\":74},{\"id\":76},{\"id\":75},{\"id\":72},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":81},{\"id\":93},{\"id\":82},{\"id\":83},{\"id\":94},{\"id\":84},{\"id\":85},{\"id\":95},{\"id\":86},{\"id\":87},{\"id\":96},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":97},{\"id\":98},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":99},{\"id\":92},{\"id\":79},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":105},{\"id\":106},{\"id\":108},{\"id\":107},{\"id\":68},{\"id\":69},{\"id\":57},{\"id\":58}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":109,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":110,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":111,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":112,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":111},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":113,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":109}},{\"nodeType\":3,\"id\":114,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":113}},{\"nodeType\":1,\"id\":115,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":110}},{\"nodeType\":1,\"id\":116,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":110}},{\"nodeType\":3,\"id\":117,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":118,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":111}},{\"nodeType\":1,\"id\":119,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":118},\"parentNode\":{\"id\":111}},{\"nodeType\":3,\"id\":120,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":118}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":112}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":109},{\"id\":113},{\"id\":114},{\"id\":110},{\"id\":115},{\"id\":117},{\"id\":116},{\"id\":111},{\"id\":118},{\"id\":120},{\"id\":119},{\"id\":112},{\"id\":121}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":122,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \",\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":124,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":123},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":125,\"previousSibling\":{\"id\":124},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":126,\"textContent\":\" \",\"previousSibling\":{\"id\":125},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":128,\"textContent\":\" \",\"parentNode\":{\"id\":124}},{\"nodeType\":1,\"id\":129,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":124}},{\"nodeType\":8,\"id\":130,\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":124}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \",\"previousSibling\":{\"id\":130},\"parentNode\":{\"id\":124}},{\"nodeType\":1,\"id\":132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":131},\"parentNode\":{\"id\":124}},{\"nodeType\":3,\"id\":133,\"textContent\":\" \",\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":124}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":124}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":124}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":124}},{\"nodeType\":8,\"id\":137,\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":124}},{\"nodeType\":3,\"id\":138,\"textContent\":\" \",\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":124}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"parentNode\":{\"id\":129}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":129}},{\"nodeType\":3,\"id\":141,\"textContent\":\" \",\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":129}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":143,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":142},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":144,\"textContent\":\" \",\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":145,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":143}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":132}},{\"nodeType\":1,\"id\":147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":132}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":132}},{\"nodeType\":8,\"id\":149,\"previousSibling\":{\"id\":148},\"parentNode\":{\"id\":132}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"previousSibling\":{\"id\":149},\"parentNode\":{\"id\":132}},{\"nodeType\":3,\"id\":151,\"textContent\":\" \",\"parentNode\":{\"id\":147}},{\"nodeType\":1,\"id\":152,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":147}},{\"nodeType\":1,\"id\":153,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":147}},{\"nodeType\":1,\"id\":155,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":154},\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":156,\"textContent\":\" \",\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":147}},{\"nodeType\":1,\"id\":157,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":147}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":161,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":152}},{\"nodeType\":1,\"id\":162,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":152}},{\"nodeType\":3,\"id\":163,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":152}},{\"nodeType\":3,\"id\":164,\"textContent\":\"all\",\"parentNode\":{\"id\":162}},{\"nodeType\":3,\"id\":165,\"textContent\":\" \",\"parentNode\":{\"id\":153}},{\"nodeType\":1,\"id\":166,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":153}},{\"nodeType\":1,\"id\":167,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":168,\"textContent\":\" \",\"previousSibling\":{\"id\":167},\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":169,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":168},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":170,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":170},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":177,\"textContent\":\" \",\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":178,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":167}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \",\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":180,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":167}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"previousSibling\":{\"id\":180},\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":182,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":178}},{\"nodeType\":3,\"id\":183,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":180}},{\"nodeType\":3,\"id\":184,\"textContent\":\" \",\"parentNode\":{\"id\":169}},{\"nodeType\":1,\"id\":185,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":169}},{\"nodeType\":3,\"id\":186,\"textContent\":\" \",\"previousSibling\":{\"id\":185},\"parentNode\":{\"id\":169}},{\"nodeType\":1,\"id\":187,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":185}},{\"nodeType\":3,\"id\":188,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":187}},{\"nodeType\":3,\"id\":189,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":190,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":191,\"textContent\":\" \",\"previousSibling\":{\"id\":190},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":192,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":191},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"previousSibling\":{\"id\":192},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":194,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":190}},{\"nodeType\":3,\"id\":195,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":192}},{\"nodeType\":3,\"id\":196,\"textContent\":\" \",\"parentNode\":{\"id\":175}},{\"nodeType\":1,\"id\":197,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":198,\"textContent\":\" \",\"previousSibling\":{\"id\":197},\"parentNode\":{\"id\":175}},{\"nodeType\":1,\"id\":199,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":197}},{\"nodeType\":3,\"id\":200,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":199}},{\"nodeType\":1,\"id\":201,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":155}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":155}},{\"nodeType\":3,\"id\":203,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\" \\t\",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":204},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":207,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":206},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":207},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":213,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":214,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":205}},{\"nodeType\":1,\"id\":215,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":217,\"textContent\":\"carefully\",\"parentNode\":{\"id\":215}},{\"nodeType\":1,\"id\":218,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":207}},{\"nodeType\":3,\"id\":219,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":207}},{\"nodeType\":1,\"id\":220,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":220},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":224,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":225,\"textContent\":\" \\t\",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":226,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":225},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":227,\"textContent\":\" \",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":228,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":226}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":122},{\"id\":127},{\"id\":123},{\"id\":124},{\"id\":128},{\"id\":129},{\"id\":139},{\"id\":140},{\"id\":142},{\"id\":143},{\"id\":145},{\"id\":144},{\"id\":141},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":146},{\"id\":147},{\"id\":151},{\"id\":152},{\"id\":161},{\"id\":162},{\"id\":164},{\"id\":163},{\"id\":153},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":177},{\"id\":178},{\"id\":182},{\"id\":179},{\"id\":180},{\"id\":183},{\"id\":181},{\"id\":168},{\"id\":169},{\"id\":184},{\"id\":185},{\"id\":187},{\"id\":188},{\"id\":186},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":189},{\"id\":190},{\"id\":194},{\"id\":191},{\"id\":192},{\"id\":195},{\"id\":193},{\"id\":174},{\"id\":175},{\"id\":196},{\"id\":197},{\"id\":199},{\"id\":200},{\"id\":198},{\"id\":176},{\"id\":154},{\"id\":155},{\"id\":201},{\"id\":203},{\"id\":202},{\"id\":156},{\"id\":157},{\"id\":204},{\"id\":205},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":217},{\"id\":216},{\"id\":206},{\"id\":207},{\"id\":218},{\"id\":219},{\"id\":208},{\"id\":209},{\"id\":220},{\"id\":221},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":158},{\"id\":159},{\"id\":224},{\"id\":160},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":225},{\"id\":226},{\"id\":228},{\"id\":227},{\"id\":137},{\"id\":138},{\"id\":125},{\"id\":126}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":229,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":230,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":231,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":229},{\"id\":230},{\"id\":231}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\",\"cz-shortcut-listen\":\"true\"}}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 383, dom: 791, initialDom: 912",
  "javascriptErrors": []
}