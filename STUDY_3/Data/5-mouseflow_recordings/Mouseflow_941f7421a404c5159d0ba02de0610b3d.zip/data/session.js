var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "941f7421a404c5159d0ba02de0610b3d",
  "created": "2018-05-25T11:15:21.3393734-07:00",
  "lastActivity": "2018-05-25T11:15:34.4244874-07:00",
  "pageViews": [
    {
      "id": "052521685cde7de05d31f4e235c65494d36e9748",
      "startTime": "2018-05-25T11:15:21.4196624-07:00",
      "endTime": "2018-05-25T11:15:34.4244874-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 13169,
      "engagementTime": 13169,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13169,
  "engagementTime": 13169,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=K8DJ0",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b43b9887a6a45c4a9aefbbae0890becf",
  "gdpr": false
}