var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "70d0c97335405e0dbe9aa332d99cb48f",
  "created": "2018-05-15T14:09:28.0427302-07:00",
  "lastActivity": "2018-05-15T14:10:12.4547302-07:00",
  "pageViews": [
    {
      "id": "0515285549a81021316bb5a4f92ca131f416d8e5",
      "startTime": "2018-05-15T14:09:28.0427302-07:00",
      "endTime": "2018-05-15T14:10:12.4547302-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 44412,
      "engagementTime": 36262,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 44412,
  "engagementTime": 36262,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=XX1TE",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "dfd2558dd5c33c2d6e5a6fb6afa65793",
  "gdpr": false
}