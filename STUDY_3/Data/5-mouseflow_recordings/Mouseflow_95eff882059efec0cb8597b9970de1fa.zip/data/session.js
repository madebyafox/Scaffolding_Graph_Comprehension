var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "95eff882059efec0cb8597b9970de1fa",
  "created": "2018-05-19T13:19:15.8377892-07:00",
  "lastActivity": "2018-05-19T13:19:32.6635413-07:00",
  "pageViews": [
    {
      "id": "051915981fce3d6e978717a5058eabdbfe491dcb",
      "startTime": "2018-05-19T13:19:15.8377892-07:00",
      "endTime": "2018-05-19T13:19:32.6635413-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 16976,
      "engagementTime": 16970,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 16976,
  "engagementTime": 16970,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0",
  "browser": "Firefox",
  "browserVersion": "59.0",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=7VQV2",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": true,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c8054871301148a2e56fe99b4b6273c4",
  "gdpr": false
}