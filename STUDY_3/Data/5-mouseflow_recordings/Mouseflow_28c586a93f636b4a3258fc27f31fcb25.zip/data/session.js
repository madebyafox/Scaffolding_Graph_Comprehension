var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "28c586a93f636b4a3258fc27f31fcb25",
  "created": "2018-05-29T14:09:56.5870067-07:00",
  "lastActivity": "2018-05-29T14:11:32.8800067-07:00",
  "pageViews": [
    {
      "id": "0529557943e427ff823f633e8a13721a875289ed",
      "startTime": "2018-05-29T14:09:56.5870067-07:00",
      "endTime": "2018-05-29T14:11:32.8800067-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 96293,
      "engagementTime": 96223,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 96293,
  "engagementTime": 96223,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=8TCFP",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f38ff4e44d1179124c0c7ecc8ac3e9d4",
  "gdpr": false
}