var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "287bdc57e8db40c19a24ee1b63d06d07",
  "created": "2018-05-31T12:06:27.7233162-07:00",
  "lastActivity": "2018-05-31T12:06:42.0499474-07:00",
  "pageViews": [
    {
      "id": "053128156d6c5f680419782de0fea8265b28a945",
      "startTime": "2018-05-31T12:06:28.0671769-07:00",
      "endTime": "2018-05-31T12:06:42.0499474-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 14273,
      "engagementTime": 14223,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 14273,
  "engagementTime": 14223,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=XQ4O8",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f5e895a6de2b3d742753cd2ddff1792a",
  "gdpr": false
}