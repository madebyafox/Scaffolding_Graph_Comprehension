var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8b19683e591c13aa6c5999bfb535a3b5",
  "created": "2018-05-29T12:12:30.5880927-07:00",
  "lastActivity": "2018-05-29T12:12:56.8659103-07:00",
  "pageViews": [
    {
      "id": "05293030060cb57a8e5436e0bebdcde3672ebf29",
      "startTime": "2018-05-29T12:12:30.7672363-07:00",
      "endTime": "2018-05-29T12:12:56.8659103-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 26204,
      "engagementTime": 26204,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 26204,
  "engagementTime": 26204,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MD6NK",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d9c685ca75d9de8e8f1a58589e048638",
  "gdpr": false
}