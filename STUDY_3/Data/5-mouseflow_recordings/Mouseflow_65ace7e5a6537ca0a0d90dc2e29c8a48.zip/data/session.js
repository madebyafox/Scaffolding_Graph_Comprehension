var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "65ace7e5a6537ca0a0d90dc2e29c8a48",
  "created": "2018-05-15T17:05:07.5852359-07:00",
  "lastActivity": "2018-05-15T17:07:13.991321-07:00",
  "pageViews": [
    {
      "id": "05150787fee8c8a366187b28e4c4f3ae39030c52",
      "startTime": "2018-05-15T17:05:07.9176658-07:00",
      "endTime": "2018-05-15T17:07:13.991321-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 126187,
      "engagementTime": 89271,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 126187,
  "engagementTime": 89271,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c0d0b86711064c0f85826ae24cc4c6d1",
  "gdpr": false
}