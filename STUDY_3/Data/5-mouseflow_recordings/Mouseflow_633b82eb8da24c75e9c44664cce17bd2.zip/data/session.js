var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "633b82eb8da24c75e9c44664cce17bd2",
  "created": "2018-06-04T13:26:59.8855867-07:00",
  "lastActivity": "2018-06-04T13:27:46.8023404-07:00",
  "pageViews": [
    {
      "id": "060400558d427f3ce13ec3199f84bc0386d8a144",
      "startTime": "2018-06-04T13:26:59.9780777-07:00",
      "endTime": "2018-06-04T13:27:46.8023404-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 46916,
      "engagementTime": 42058,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 46916,
  "engagementTime": 42058,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=VVH1B",
    "CONDITION=211"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a392555ab259c45749e2313c38a78866",
  "gdpr": false
}