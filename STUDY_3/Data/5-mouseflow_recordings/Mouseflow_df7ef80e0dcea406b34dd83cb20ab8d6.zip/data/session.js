var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "df7ef80e0dcea406b34dd83cb20ab8d6",
  "created": "2018-06-04T12:21:54.6522083-07:00",
  "lastActivity": "2018-06-04T12:22:13.1382083-07:00",
  "pageViews": [
    {
      "id": "0604552192dc0d617ffaf13518d6978353f9118d",
      "startTime": "2018-06-04T12:21:54.6522083-07:00",
      "endTime": "2018-06-04T12:22:13.1382083-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 18486,
      "engagementTime": 18461,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 18486,
  "engagementTime": 18461,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G27Q3",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "21148bd3154913e00cde18c3f3ed1d53",
  "gdpr": false
}