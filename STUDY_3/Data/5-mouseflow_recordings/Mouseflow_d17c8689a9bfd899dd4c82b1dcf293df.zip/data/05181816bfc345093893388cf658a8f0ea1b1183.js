var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05181816bfc345093893388cf658a8f0ea1b1183"] = {
  "startTime": "2018-05-18T18:08:19.1084971Z",
  "websitePageUrl": "/",
  "visitTime": 148766,
  "engagementTime": 47160,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "d17c8689a9bfd899dd4c82b1dcf293df",
    "created": "2018-05-18T18:08:18.5479521+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "6e23c278cc752ad2e8a4762d232208f0",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d17c8689a9bfd899dd4c82b1dcf293df/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 293,
      "e": 293,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 400,
      "e": 400,
      "ty": 2,
      "x": 1206,
      "y": 292
    },
    {
      "t": 500,
      "e": 500,
      "ty": 2,
      "x": 601,
      "y": 932
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 13188,
      "y": 64347,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 509,
      "e": 509,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 600,
      "e": 600,
      "ty": 2,
      "x": 502,
      "y": 1052
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 17012,
      "y": 63526,
      "ta": "html > body"
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 154,
      "y": 1060
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 152,
      "y": 1054
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 4959,
      "y": 63648,
      "ta": "html > body"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 151,
      "y": 1053
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 4924,
      "y": 63587,
      "ta": "html > body"
    },
    {
      "t": 10000,
      "e": 6251,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20396,
      "e": 6251,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 24842,
      "e": 10697,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 24901,
      "e": 10756,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 24901,
      "e": 10756,
      "ty": 2,
      "x": 386,
      "y": 18
    },
    {
      "t": 25000,
      "e": 10855,
      "ty": 41,
      "x": 13017,
      "y": 553,
      "ta": "html > body"
    },
    {
      "t": 26101,
      "e": 11956,
      "ty": 2,
      "x": 388,
      "y": 177
    },
    {
      "t": 26201,
      "e": 12056,
      "ty": 2,
      "x": 471,
      "y": 632
    },
    {
      "t": 26251,
      "e": 12106,
      "ty": 41,
      "x": 4723,
      "y": 38952,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 26301,
      "e": 12156,
      "ty": 2,
      "x": 426,
      "y": 698
    },
    {
      "t": 26501,
      "e": 12356,
      "ty": 41,
      "x": 3631,
      "y": 40836,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 30000,
      "e": 15855,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 114754,
      "e": 17356,
      "ty": 41,
      "x": 7849,
      "y": 40264,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 114804,
      "e": 17406,
      "ty": 2,
      "x": 513,
      "y": 837
    },
    {
      "t": 114904,
      "e": 17506,
      "ty": 2,
      "x": 529,
      "y": 912
    },
    {
      "t": 115004,
      "e": 17606,
      "ty": 2,
      "x": 848,
      "y": 901
    },
    {
      "t": 115005,
      "e": 17607,
      "ty": 41,
      "x": 27282,
      "y": 62120,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 115104,
      "e": 17706,
      "ty": 2,
      "x": 879,
      "y": 888
    },
    {
      "t": 115204,
      "e": 17806,
      "ty": 2,
      "x": 864,
      "y": 910
    },
    {
      "t": 115255,
      "e": 17857,
      "ty": 41,
      "x": 27134,
      "y": 58790,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 115304,
      "e": 17906,
      "ty": 2,
      "x": 843,
      "y": 932
    },
    {
      "t": 115404,
      "e": 18006,
      "ty": 2,
      "x": 838,
      "y": 933
    },
    {
      "t": 115504,
      "e": 18106,
      "ty": 2,
      "x": 834,
      "y": 931
    },
    {
      "t": 115504,
      "e": 18106,
      "ty": 41,
      "x": 26593,
      "y": 58790,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 115604,
      "e": 18206,
      "ty": 2,
      "x": 825,
      "y": 923
    },
    {
      "t": 115704,
      "e": 18306,
      "ty": 2,
      "x": 821,
      "y": 921
    },
    {
      "t": 115753,
      "e": 18355,
      "ty": 3,
      "x": 821,
      "y": 921,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 115755,
      "e": 18357,
      "ty": 41,
      "x": 57547,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 115855,
      "e": 18457,
      "ty": 4,
      "x": 57547,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 115855,
      "e": 18457,
      "ty": 5,
      "x": 821,
      "y": 921,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 115856,
      "e": 18458,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 115860,
      "e": 18462,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 116004,
      "e": 18606,
      "ty": 2,
      "x": 986,
      "y": 1122
    },
    {
      "t": 116005,
      "e": 18607,
      "ty": 41,
      "x": 45172,
      "y": 27318,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 116204,
      "e": 18806,
      "ty": 2,
      "x": 986,
      "y": 1113
    },
    {
      "t": 116254,
      "e": 18856,
      "ty": 41,
      "x": 41778,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 116304,
      "e": 18906,
      "ty": 2,
      "x": 985,
      "y": 1099
    },
    {
      "t": 116404,
      "e": 19006,
      "ty": 2,
      "x": 985,
      "y": 1094
    },
    {
      "t": 116423,
      "e": 19025,
      "ty": 3,
      "x": 985,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 116424,
      "e": 19026,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 116425,
      "e": 19027,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 116504,
      "e": 19106,
      "ty": 41,
      "x": 41232,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 116512,
      "e": 19114,
      "ty": 4,
      "x": 41232,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 116515,
      "e": 19117,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 116517,
      "e": 19119,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 116517,
      "e": 19119,
      "ty": 5,
      "x": 985,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 116804,
      "e": 19406,
      "ty": 2,
      "x": 985,
      "y": 1093
    },
    {
      "t": 117004,
      "e": 19606,
      "ty": 41,
      "x": 33645,
      "y": 60106,
      "ta": "html > body"
    },
    {
      "t": 117525,
      "e": 20127,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 118255,
      "e": 20857,
      "ty": 41,
      "x": 33611,
      "y": 59995,
      "ta": "html > body"
    },
    {
      "t": 118305,
      "e": 20907,
      "ty": 2,
      "x": 968,
      "y": 1039
    },
    {
      "t": 118404,
      "e": 21006,
      "ty": 2,
      "x": 794,
      "y": 398
    },
    {
      "t": 118504,
      "e": 21106,
      "ty": 2,
      "x": 796,
      "y": 303
    },
    {
      "t": 118505,
      "e": 21107,
      "ty": 41,
      "x": 27136,
      "y": 16342,
      "ta": "html > body"
    },
    {
      "t": 118604,
      "e": 21206,
      "ty": 2,
      "x": 857,
      "y": 383
    },
    {
      "t": 118755,
      "e": 21357,
      "ty": 41,
      "x": 29237,
      "y": 20773,
      "ta": "html > body"
    },
    {
      "t": 118904,
      "e": 21506,
      "ty": 2,
      "x": 877,
      "y": 396
    },
    {
      "t": 119004,
      "e": 21606,
      "ty": 2,
      "x": 923,
      "y": 475
    },
    {
      "t": 119005,
      "e": 21607,
      "ty": 41,
      "x": 28071,
      "y": 17407,
      "ta": "#jspsych-survey-text-preamble"
    },
    {
      "t": 119104,
      "e": 21706,
      "ty": 2,
      "x": 931,
      "y": 483
    },
    {
      "t": 119205,
      "e": 21807,
      "ty": 2,
      "x": 931,
      "y": 487
    },
    {
      "t": 119254,
      "e": 21856,
      "ty": 41,
      "x": 23791,
      "y": 33824,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 119304,
      "e": 21906,
      "ty": 2,
      "x": 918,
      "y": 658
    },
    {
      "t": 119306,
      "e": 21908,
      "ty": 6,
      "x": 917,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 119322,
      "e": 21924,
      "ty": 7,
      "x": 915,
      "y": 707,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 119338,
      "e": 21940,
      "ty": 6,
      "x": 915,
      "y": 728,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 119356,
      "e": 21958,
      "ty": 7,
      "x": 915,
      "y": 746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 119405,
      "e": 22007,
      "ty": 2,
      "x": 915,
      "y": 772
    },
    {
      "t": 119508,
      "e": 22110,
      "ty": 2,
      "x": 915,
      "y": 776
    },
    {
      "t": 119508,
      "e": 22110,
      "ty": 41,
      "x": 31235,
      "y": 42545,
      "ta": "html > body"
    },
    {
      "t": 119543,
      "e": 22145,
      "ty": 6,
      "x": 916,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 119560,
      "e": 22162,
      "ty": 7,
      "x": 916,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 119607,
      "e": 22209,
      "ty": 2,
      "x": 929,
      "y": 648
    },
    {
      "t": 119708,
      "e": 22310,
      "ty": 2,
      "x": 931,
      "y": 617
    },
    {
      "t": 119758,
      "e": 22360,
      "ty": 41,
      "x": 26603,
      "y": 1409,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 119908,
      "e": 22510,
      "ty": 2,
      "x": 931,
      "y": 616
    },
    {
      "t": 119943,
      "e": 22545,
      "ty": 6,
      "x": 934,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120008,
      "e": 22610,
      "ty": 2,
      "x": 936,
      "y": 596
    },
    {
      "t": 120008,
      "e": 22610,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120008,
      "e": 22610,
      "ty": 41,
      "x": 27684,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120108,
      "e": 22710,
      "ty": 2,
      "x": 937,
      "y": 594
    },
    {
      "t": 120130,
      "e": 22732,
      "ty": 3,
      "x": 937,
      "y": 594,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120131,
      "e": 22733,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120258,
      "e": 22860,
      "ty": 41,
      "x": 27901,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120266,
      "e": 22868,
      "ty": 4,
      "x": 27901,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120268,
      "e": 22870,
      "ty": 5,
      "x": 937,
      "y": 594,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120823,
      "e": 23425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 121167,
      "e": 23769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 121168,
      "e": 23770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 121286,
      "e": 23888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "M"
    },
    {
      "t": 121335,
      "e": 23937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 121335,
      "e": 23937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 121471,
      "e": 24073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ME"
    },
    {
      "t": 121863,
      "e": 24465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 121864,
      "e": 24466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 121942,
      "e": 24544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MEN"
    },
    {
      "t": 121990,
      "e": 24592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MEN"
    },
    {
      "t": 122595,
      "e": 25197,
      "ty": 7,
      "x": 939,
      "y": 609,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 122608,
      "e": 25210,
      "ty": 2,
      "x": 939,
      "y": 609
    },
    {
      "t": 122708,
      "e": 25310,
      "ty": 2,
      "x": 915,
      "y": 660
    },
    {
      "t": 122728,
      "e": 25330,
      "ty": 6,
      "x": 906,
      "y": 689,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 122758,
      "e": 25360,
      "ty": 41,
      "x": 20979,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 122807,
      "e": 25409,
      "ty": 2,
      "x": 904,
      "y": 695
    },
    {
      "t": 122908,
      "e": 25510,
      "ty": 2,
      "x": 903,
      "y": 695
    },
    {
      "t": 123009,
      "e": 25611,
      "ty": 41,
      "x": 20547,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 123068,
      "e": 25670,
      "ty": 3,
      "x": 903,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 123069,
      "e": 25671,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MEN"
    },
    {
      "t": 123070,
      "e": 25672,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 123070,
      "e": 25672,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 123186,
      "e": 25788,
      "ty": 4,
      "x": 20547,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 123186,
      "e": 25788,
      "ty": 5,
      "x": 903,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 123694,
      "e": 26296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 123694,
      "e": 26296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 123782,
      "e": 26384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 123870,
      "e": 26472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 123872,
      "e": 26474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 123957,
      "e": 26559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 124079,
      "e": 26681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 124080,
      "e": 26682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 124168,
      "e": 26770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 124219,
      "e": 26821,
      "ty": 7,
      "x": 904,
      "y": 702,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 124230,
      "e": 26832,
      "ty": 6,
      "x": 913,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124258,
      "e": 26860,
      "ty": 41,
      "x": 12925,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124308,
      "e": 26910,
      "ty": 2,
      "x": 955,
      "y": 739
    },
    {
      "t": 124313,
      "e": 26915,
      "ty": 7,
      "x": 963,
      "y": 744,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124408,
      "e": 27010,
      "ty": 2,
      "x": 976,
      "y": 753
    },
    {
      "t": 124463,
      "e": 27065,
      "ty": 6,
      "x": 985,
      "y": 734,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124508,
      "e": 27110,
      "ty": 2,
      "x": 989,
      "y": 725
    },
    {
      "t": 124509,
      "e": 27111,
      "ty": 41,
      "x": 47971,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124608,
      "e": 27210,
      "ty": 2,
      "x": 989,
      "y": 723
    },
    {
      "t": 124634,
      "e": 27236,
      "ty": 3,
      "x": 989,
      "y": 723,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124634,
      "e": 27236,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 124634,
      "e": 27236,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 124635,
      "e": 27237,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124754,
      "e": 27356,
      "ty": 4,
      "x": 47971,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124756,
      "e": 27358,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124757,
      "e": 27359,
      "ty": 5,
      "x": 989,
      "y": 723,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 124759,
      "e": 27361,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 124760,
      "e": 27362,
      "ty": 41,
      "x": 33783,
      "y": 39609,
      "ta": "html > body"
    },
    {
      "t": 125760,
      "e": 28362,
      "ty": 41,
      "x": 33817,
      "y": 39553,
      "ta": "html > body"
    },
    {
      "t": 125808,
      "e": 28410,
      "ty": 2,
      "x": 991,
      "y": 722
    },
    {
      "t": 125861,
      "e": 28463,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 125891,
      "e": 28493,
      "ty": 6,
      "x": 991,
      "y": 722,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 126009,
      "e": 28611,
      "ty": 41,
      "x": 33386,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 126381,
      "e": 28983,
      "ty": 7,
      "x": 983,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 126382,
      "e": 28984,
      "ty": 6,
      "x": 983,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 126408,
      "e": 29010,
      "ty": 2,
      "x": 973,
      "y": 731
    },
    {
      "t": 126499,
      "e": 29101,
      "ty": 7,
      "x": 747,
      "y": 716,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 126499,
      "e": 29101,
      "ty": 6,
      "x": 747,
      "y": 716,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 126508,
      "e": 29110,
      "ty": 2,
      "x": 747,
      "y": 716
    },
    {
      "t": 126509,
      "e": 29111,
      "ty": 41,
      "x": 21024,
      "y": 39825,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 126514,
      "e": 29116,
      "ty": 7,
      "x": 628,
      "y": 685,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 126515,
      "e": 29117,
      "ty": 6,
      "x": 628,
      "y": 685,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 126531,
      "e": 29133,
      "ty": 7,
      "x": 528,
      "y": 655,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 126608,
      "e": 29210,
      "ty": 2,
      "x": 402,
      "y": 599
    },
    {
      "t": 126708,
      "e": 29310,
      "ty": 2,
      "x": 382,
      "y": 583
    },
    {
      "t": 126758,
      "e": 29360,
      "ty": 41,
      "x": 5943,
      "y": 51,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td > i"
    },
    {
      "t": 128508,
      "e": 31110,
      "ty": 2,
      "x": 383,
      "y": 585
    },
    {
      "t": 128508,
      "e": 31110,
      "ty": 41,
      "x": 6065,
      "y": 6604,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td > i"
    },
    {
      "t": 128608,
      "e": 31210,
      "ty": 2,
      "x": 383,
      "y": 591
    },
    {
      "t": 128707,
      "e": 31309,
      "ty": 2,
      "x": 384,
      "y": 608
    },
    {
      "t": 128758,
      "e": 31360,
      "ty": 41,
      "x": 4749,
      "y": 36,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 128808,
      "e": 31410,
      "ty": 2,
      "x": 408,
      "y": 670
    },
    {
      "t": 128817,
      "e": 31419,
      "ty": 6,
      "x": 415,
      "y": 684,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 128851,
      "e": 31453,
      "ty": 7,
      "x": 424,
      "y": 704,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 128851,
      "e": 31453,
      "ty": 6,
      "x": 424,
      "y": 704,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 128884,
      "e": 31486,
      "ty": 7,
      "x": 445,
      "y": 732,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 128884,
      "e": 31486,
      "ty": 6,
      "x": 445,
      "y": 732,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 128908,
      "e": 31510,
      "ty": 2,
      "x": 448,
      "y": 739
    },
    {
      "t": 128916,
      "e": 31518,
      "ty": 7,
      "x": 477,
      "y": 764,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 128917,
      "e": 31519,
      "ty": 6,
      "x": 477,
      "y": 764,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 128934,
      "e": 31536,
      "ty": 7,
      "x": 513,
      "y": 793,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 129008,
      "e": 31610,
      "ty": 2,
      "x": 772,
      "y": 935
    },
    {
      "t": 129008,
      "e": 31610,
      "ty": 41,
      "x": 23543,
      "y": 56000,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 129109,
      "e": 31711,
      "ty": 2,
      "x": 1267,
      "y": 1115
    },
    {
      "t": 129209,
      "e": 31811,
      "ty": 2,
      "x": 1336,
      "y": 1156
    },
    {
      "t": 129258,
      "e": 31860,
      "ty": 41,
      "x": 45698,
      "y": 63540,
      "ta": "> div.masterdiv"
    },
    {
      "t": 129308,
      "e": 31910,
      "ty": 2,
      "x": 1239,
      "y": 1122
    },
    {
      "t": 129408,
      "e": 32010,
      "ty": 2,
      "x": 1048,
      "y": 1058
    },
    {
      "t": 129507,
      "e": 32109,
      "ty": 2,
      "x": 1043,
      "y": 1062
    },
    {
      "t": 129508,
      "e": 32110,
      "ty": 41,
      "x": 36875,
      "y": 64794,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 129609,
      "e": 32211,
      "ty": 2,
      "x": 1039,
      "y": 1073
    },
    {
      "t": 129651,
      "e": 32253,
      "ty": 6,
      "x": 1027,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 129708,
      "e": 32253,
      "ty": 2,
      "x": 993,
      "y": 1092
    },
    {
      "t": 129759,
      "e": 32304,
      "ty": 41,
      "x": 30856,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 129808,
      "e": 32353,
      "ty": 2,
      "x": 964,
      "y": 1099
    },
    {
      "t": 130007,
      "e": 32552,
      "ty": 41,
      "x": 29763,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 136900,
      "e": 37552,
      "ty": 3,
      "x": 964,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 136901,
      "e": 37553,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 136994,
      "e": 37646,
      "ty": 4,
      "x": 29763,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 136995,
      "e": 37647,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 136995,
      "e": 37647,
      "ty": 5,
      "x": 964,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 136997,
      "e": 37649,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 137709,
      "e": 38361,
      "ty": 2,
      "x": 916,
      "y": 1057
    },
    {
      "t": 137757,
      "e": 38409,
      "ty": 41,
      "x": 30236,
      "y": 56172,
      "ta": "html > body"
    },
    {
      "t": 137808,
      "e": 38460,
      "ty": 2,
      "x": 880,
      "y": 1013
    },
    {
      "t": 137907,
      "e": 38559,
      "ty": 2,
      "x": 875,
      "y": 1011
    },
    {
      "t": 137997,
      "e": 38649,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 138008,
      "e": 38660,
      "ty": 2,
      "x": 875,
      "y": 1010
    },
    {
      "t": 138008,
      "e": 38660,
      "ty": 41,
      "x": 29857,
      "y": 55508,
      "ta": "html > body"
    },
    {
      "t": 138608,
      "e": 39260,
      "ty": 2,
      "x": 872,
      "y": 1007
    },
    {
      "t": 138708,
      "e": 39360,
      "ty": 2,
      "x": 854,
      "y": 963
    },
    {
      "t": 138758,
      "e": 39410,
      "ty": 41,
      "x": 26189,
      "y": 58119,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 138808,
      "e": 39460,
      "ty": 2,
      "x": 812,
      "y": 866
    },
    {
      "t": 138908,
      "e": 39560,
      "ty": 2,
      "x": 808,
      "y": 854
    },
    {
      "t": 139008,
      "e": 39660,
      "ty": 2,
      "x": 783,
      "y": 837
    },
    {
      "t": 139008,
      "e": 39660,
      "ty": 41,
      "x": 24199,
      "y": 53693,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 139108,
      "e": 39760,
      "ty": 2,
      "x": 781,
      "y": 835
    },
    {
      "t": 139259,
      "e": 39911,
      "ty": 41,
      "x": 24102,
      "y": 53538,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 139408,
      "e": 40060,
      "ty": 2,
      "x": 777,
      "y": 835
    },
    {
      "t": 139508,
      "e": 40160,
      "ty": 41,
      "x": 23908,
      "y": 53538,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 140008,
      "e": 40660,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140907,
      "e": 41559,
      "ty": 2,
      "x": 776,
      "y": 828
    },
    {
      "t": 141007,
      "e": 41659,
      "ty": 2,
      "x": 768,
      "y": 835
    },
    {
      "t": 141007,
      "e": 41659,
      "ty": 41,
      "x": 23471,
      "y": 53538,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 141108,
      "e": 41760,
      "ty": 2,
      "x": 757,
      "y": 877
    },
    {
      "t": 141208,
      "e": 41860,
      "ty": 2,
      "x": 752,
      "y": 900
    },
    {
      "t": 141258,
      "e": 41910,
      "ty": 41,
      "x": 22694,
      "y": 58585,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 141308,
      "e": 41960,
      "ty": 2,
      "x": 739,
      "y": 927
    },
    {
      "t": 141408,
      "e": 42060,
      "ty": 2,
      "x": 737,
      "y": 1020
    },
    {
      "t": 141508,
      "e": 42160,
      "ty": 2,
      "x": 737,
      "y": 1021
    },
    {
      "t": 141508,
      "e": 42160,
      "ty": 41,
      "x": 25105,
      "y": 56117,
      "ta": "html > body"
    },
    {
      "t": 147761,
      "e": 47160,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 148766,
      "e": 47160,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 1959, dom: 2801, initialDom: 2805",
  "javascriptErrors": []
}