var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8a9fa6dcb4f5c6554b8f50070b0f0344",
  "created": "2018-05-19T13:10:13.2961578-07:00",
  "lastActivity": "2018-05-19T13:12:06.4501578-07:00",
  "pageViews": [
    {
      "id": "051913620780f44ab1348270efb4389039c63cf4",
      "startTime": "2018-05-19T13:10:13.2961578-07:00",
      "endTime": "2018-05-19T13:12:06.4501578-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 113154,
      "engagementTime": 83624,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 113154,
  "engagementTime": 83624,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0",
  "browser": "Firefox",
  "browserVersion": "59.0",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": true,
  "starred": true,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "00109864b4690ff87997f831dc2731b3",
  "gdpr": false
}