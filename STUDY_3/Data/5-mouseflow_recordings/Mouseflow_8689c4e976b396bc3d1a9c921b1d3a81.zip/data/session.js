var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8689c4e976b396bc3d1a9c921b1d3a81",
  "created": "2018-05-21T10:11:56.3016133-07:00",
  "lastActivity": "2018-05-21T10:12:06.4826133-07:00",
  "pageViews": [
    {
      "id": "052156535705ac02aa6e16367a26964c60d5e244",
      "startTime": "2018-05-21T10:11:56.3016133-07:00",
      "endTime": "2018-05-21T10:12:06.4826133-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 10181,
      "engagementTime": 10180,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10181,
  "engagementTime": 10180,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=RGJZL",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0199b269be6f84202389e6ef8d38b611",
  "gdpr": false
}