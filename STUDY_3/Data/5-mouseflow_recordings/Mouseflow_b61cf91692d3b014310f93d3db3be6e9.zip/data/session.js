var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b61cf91692d3b014310f93d3db3be6e9",
  "created": "2018-06-01T11:15:23.9475427-07:00",
  "lastActivity": "2018-06-01T11:15:37.6768083-07:00",
  "pageViews": [
    {
      "id": "06012349521e755a85f2725dc0a7a91296d4082a",
      "startTime": "2018-06-01T11:15:23.9475427-07:00",
      "endTime": "2018-06-01T11:15:37.6768083-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 13783,
      "engagementTime": 13683,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13783,
  "engagementTime": 13683,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.47",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=EER58",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9b783b1bec7ee65bea0f42f89554ee13",
  "gdpr": false
}