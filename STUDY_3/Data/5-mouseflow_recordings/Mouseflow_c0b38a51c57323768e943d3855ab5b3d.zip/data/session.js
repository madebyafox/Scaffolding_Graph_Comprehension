var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c0b38a51c57323768e943d3855ab5b3d",
  "created": "2018-06-04T13:17:49.248534-07:00",
  "lastActivity": "2018-06-04T13:18:12.5346295-07:00",
  "pageViews": [
    {
      "id": "060449127f963e245568fffcee078c8b8de8a0bc",
      "startTime": "2018-06-04T13:17:49.2556295-07:00",
      "endTime": "2018-06-04T13:18:12.5346295-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 23279,
      "engagementTime": 23180,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 23279,
  "engagementTime": 23180,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=06217",
    "CONDITION=211",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1edf32fcec3a108727e5f777463c6538",
  "gdpr": false
}