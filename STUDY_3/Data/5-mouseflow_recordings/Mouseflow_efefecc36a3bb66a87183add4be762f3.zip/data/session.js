var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "efefecc36a3bb66a87183add4be762f3",
  "created": "2018-05-29T14:03:03.5443321-07:00",
  "lastActivity": "2018-05-29T14:05:33.1893321-07:00",
  "pageViews": [
    {
      "id": "05290355c99338f1ccbc6c337df6c5e6c65cd9f1",
      "startTime": "2018-05-29T14:03:03.5443321-07:00",
      "endTime": "2018-05-29T14:05:33.1893321-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 149645,
      "engagementTime": 79459,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 149645,
  "engagementTime": 79459,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b7a7ab85fecda0166fff31ae23f83559",
  "gdpr": false
}