var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4b7c33aea4387862c10d086667f449b6",
  "created": "2018-05-24T12:14:23.0769388-07:00",
  "lastActivity": "2018-05-24T12:15:21.5169388-07:00",
  "pageViews": [
    {
      "id": "052423023ca5e912448bb8e05b006a36740bc75a",
      "startTime": "2018-05-24T12:14:23.0769388-07:00",
      "endTime": "2018-05-24T12:15:21.5169388-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 58440,
      "engagementTime": 41042,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 58440,
  "engagementTime": 41042,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=M3NXB",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9dd613eacf94ab8212a6da0d8aceb10f",
  "gdpr": false
}