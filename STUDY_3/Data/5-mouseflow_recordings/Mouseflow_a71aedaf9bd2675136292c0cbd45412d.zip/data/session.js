var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a71aedaf9bd2675136292c0cbd45412d",
  "created": "2018-05-21T12:46:53.0795307-07:00",
  "lastActivity": "2018-05-21T12:47:32.882245-07:00",
  "pageViews": [
    {
      "id": "05215265eb88a9d4f96656d7388497ac2e800a7d",
      "startTime": "2018-05-21T12:46:53.0795307-07:00",
      "endTime": "2018-05-21T12:47:32.882245-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 40888,
      "engagementTime": 25306,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 40888,
  "engagementTime": 25306,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.9.248",
  "lang": "en-us",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/604.5.6 (KHTML, like Gecko) Version/11.0.3 Safari/604.5.6",
  "browser": "Safari",
  "browserVersion": "11.0.3",
  "os": "OS X",
  "osVersion": "10.11 El Capitan",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZYASS",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "03b5935ce44ce9d0f26dbcaec3d50726",
  "gdpr": false
}