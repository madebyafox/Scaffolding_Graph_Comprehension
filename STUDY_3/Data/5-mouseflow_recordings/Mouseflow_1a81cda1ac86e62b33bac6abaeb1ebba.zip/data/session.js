var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1a81cda1ac86e62b33bac6abaeb1ebba",
  "created": "2018-05-16T21:24:15.5438494-07:00",
  "lastActivity": "2018-05-16T21:24:37.8425493-07:00",
  "pageViews": [
    {
      "id": "05161525fe634b658baa11cd4a7c4382146d2273",
      "startTime": "2018-05-16T21:24:15.5910788-07:00",
      "endTime": "2018-05-16T21:24:37.8425493-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 22795,
      "engagementTime": 16648,
      "scroll": 98.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 22795,
  "engagementTime": 16648,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "San Diego",
  "isp": "Time Warner Cable",
  "ip": "66.75.255.252",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "60.0.3112.113",
  "os": "OS X",
  "osVersion": "10.11 El Capitan",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2073,
  "lat": 32.8594,
  "visitorId": "3867b6f05cc335b60b8c440ec1c1ef88",
  "gdpr": false
}