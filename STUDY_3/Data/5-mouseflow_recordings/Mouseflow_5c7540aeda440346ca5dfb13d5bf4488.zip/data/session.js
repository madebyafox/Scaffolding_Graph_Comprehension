var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5c7540aeda440346ca5dfb13d5bf4488",
  "created": "2018-06-04T13:22:14.4768165-07:00",
  "lastActivity": "2018-06-04T13:22:59.7888165-07:00",
  "pageViews": [
    {
      "id": "06041476ae86f75e27cc98b839bce8449fd08afd",
      "startTime": "2018-06-04T13:22:14.4768165-07:00",
      "endTime": "2018-06-04T13:22:59.7888165-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 45312,
      "engagementTime": 30157,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 45312,
  "engagementTime": 30157,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=Z5GWP",
    "CONDITION=211",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4bb88c45d494a2f2b787228b05bdde2c",
  "gdpr": false
}