var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f5cf40ea6fe6e9c762bff5818e3bcdb2",
  "created": "2018-06-01T11:17:23.2432661-07:00",
  "lastActivity": "2018-06-01T11:17:27.2012661-07:00",
  "pageViews": [
    {
      "id": "060123042efa301d3e52c70b45066e3c62038d30",
      "startTime": "2018-06-01T11:17:23.2432661-07:00",
      "endTime": "2018-06-01T11:17:27.2012661-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 3958,
      "engagementTime": 3958,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 3958,
  "engagementTime": 3958,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CKY5H",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a7e7bfd63625ad4fa6b66649816ebd9f",
  "gdpr": false
}