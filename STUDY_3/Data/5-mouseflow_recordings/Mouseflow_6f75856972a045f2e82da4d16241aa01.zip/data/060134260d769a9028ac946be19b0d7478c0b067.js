var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060134260d769a9028ac946be19b0d7478c0b067"] = {
  "startTime": "2018-06-01T18:06:34.1504698Z",
  "websitePageUrl": "/",
  "visitTime": 170998,
  "engagementTime": 52937,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "6f75856972a045f2e82da4d16241aa01",
    "created": "2018-06-01T18:06:34.0869451+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "863fcabc492a06cd7470fac9f306f263",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/6f75856972a045f2e82da4d16241aa01/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 394,
      "e": 394,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 422,
      "y": 339
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 30473,
      "y": 17694,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 600,
      "e": 600,
      "ty": 2,
      "x": 423,
      "y": 336
    },
    {
      "t": 700,
      "e": 700,
      "ty": 2,
      "x": 427,
      "y": 332
    },
    {
      "t": 750,
      "e": 750,
      "ty": 41,
      "x": 30801,
      "y": 16547,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 428,
      "y": 312
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 430,
      "y": 305
    },
    {
      "t": 1009,
      "e": 1009,
      "ty": 41,
      "x": 30910,
      "y": 14909,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2168,
      "e": 2168,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 501,
      "y": 161
    },
    {
      "t": 2406,
      "e": 2406,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 2503,
      "e": 2503,
      "ty": 2,
      "x": 543,
      "y": 41
    },
    {
      "t": 2503,
      "e": 2503,
      "ty": 41,
      "x": 38444,
      "y": 2099,
      "ta": "html > body"
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 1032,
      "y": 17
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 1018,
      "y": 107
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 993,
      "y": 233
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 41,
      "x": 34597,
      "y": 7085,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 928,
      "y": 456
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 928,
      "y": 505
    },
    {
      "t": 4250,
      "e": 4250,
      "ty": 41,
      "x": 31921,
      "y": 30924,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 964,
      "y": 543
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 965,
      "y": 546
    },
    {
      "t": 4508,
      "e": 4508,
      "ty": 41,
      "x": 33067,
      "y": 32726,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 946,
      "y": 552
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 41,
      "x": 32030,
      "y": 33218,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 931,
      "y": 555
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 925,
      "y": 560
    },
    {
      "t": 5250,
      "e": 5250,
      "ty": 41,
      "x": 30228,
      "y": 34938,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 911,
      "y": 575
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 910,
      "y": 577
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 2,
      "x": 908,
      "y": 578
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 41,
      "x": 29954,
      "y": 35347,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6100,
      "e": 6100,
      "ty": 2,
      "x": 907,
      "y": 578
    },
    {
      "t": 6258,
      "e": 6258,
      "ty": 41,
      "x": 29900,
      "y": 35347,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 15301,
      "e": 11258,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 15301,
      "e": 11258,
      "ty": 2,
      "x": 907,
      "y": 644
    },
    {
      "t": 15501,
      "e": 11458,
      "ty": 41,
      "x": 29900,
      "y": 36412,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 30001,
      "e": 16458,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 122215,
      "e": 16458,
      "ty": 2,
      "x": 900,
      "y": 671
    },
    {
      "t": 122265,
      "e": 16508,
      "ty": 41,
      "x": 26544,
      "y": 64606,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 122315,
      "e": 16558,
      "ty": 2,
      "x": 802,
      "y": 892
    },
    {
      "t": 122414,
      "e": 16657,
      "ty": 2,
      "x": 761,
      "y": 925
    },
    {
      "t": 122515,
      "e": 16758,
      "ty": 2,
      "x": 777,
      "y": 910
    },
    {
      "t": 122515,
      "e": 16758,
      "ty": 41,
      "x": 23789,
      "y": 11334,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 122614,
      "e": 16857,
      "ty": 2,
      "x": 787,
      "y": 909
    },
    {
      "t": 122714,
      "e": 16957,
      "ty": 2,
      "x": 811,
      "y": 910
    },
    {
      "t": 122765,
      "e": 17008,
      "ty": 41,
      "x": 2427,
      "y": 6004,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 122815,
      "e": 17058,
      "ty": 2,
      "x": 815,
      "y": 911
    },
    {
      "t": 122914,
      "e": 17157,
      "ty": 2,
      "x": 818,
      "y": 917
    },
    {
      "t": 123014,
      "e": 17257,
      "ty": 2,
      "x": 816,
      "y": 922
    },
    {
      "t": 123015,
      "e": 17258,
      "ty": 41,
      "x": 41164,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 123100,
      "e": 17343,
      "ty": 3,
      "x": 810,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 123115,
      "e": 17358,
      "ty": 2,
      "x": 810,
      "y": 922
    },
    {
      "t": 123204,
      "e": 17447,
      "ty": 4,
      "x": 21503,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 123204,
      "e": 17447,
      "ty": 5,
      "x": 810,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 123207,
      "e": 17450,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 123217,
      "e": 17460,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 123264,
      "e": 17507,
      "ty": 41,
      "x": 21503,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 123414,
      "e": 17657,
      "ty": 2,
      "x": 832,
      "y": 950
    },
    {
      "t": 123514,
      "e": 17757,
      "ty": 2,
      "x": 900,
      "y": 1024
    },
    {
      "t": 123515,
      "e": 17758,
      "ty": 41,
      "x": 29840,
      "y": 62163,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 123615,
      "e": 17858,
      "ty": 2,
      "x": 905,
      "y": 1034
    },
    {
      "t": 123714,
      "e": 17957,
      "ty": 2,
      "x": 965,
      "y": 1088
    },
    {
      "t": 123764,
      "e": 18007,
      "ty": 41,
      "x": 30309,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 123814,
      "e": 18057,
      "ty": 2,
      "x": 966,
      "y": 1091
    },
    {
      "t": 123914,
      "e": 18157,
      "ty": 2,
      "x": 982,
      "y": 1132
    },
    {
      "t": 124014,
      "e": 18257,
      "ty": 2,
      "x": 985,
      "y": 1118
    },
    {
      "t": 124015,
      "e": 18258,
      "ty": 41,
      "x": 44704,
      "y": 25102,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 124114,
      "e": 18357,
      "ty": 2,
      "x": 983,
      "y": 1105
    },
    {
      "t": 124215,
      "e": 18458,
      "ty": 2,
      "x": 983,
      "y": 1104
    },
    {
      "t": 124264,
      "e": 18507,
      "ty": 41,
      "x": 40140,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 124316,
      "e": 18559,
      "ty": 3,
      "x": 983,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 124316,
      "e": 18559,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 124317,
      "e": 18560,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 124410,
      "e": 18653,
      "ty": 4,
      "x": 40140,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 124411,
      "e": 18654,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 124413,
      "e": 18656,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 124413,
      "e": 18656,
      "ty": 5,
      "x": 983,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 125420,
      "e": 19663,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 126214,
      "e": 20457,
      "ty": 2,
      "x": 988,
      "y": 1093
    },
    {
      "t": 126265,
      "e": 20508,
      "ty": 41,
      "x": 33783,
      "y": 52738,
      "ta": "html > body"
    },
    {
      "t": 126301,
      "e": 20544,
      "ty": 6,
      "x": 955,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 126315,
      "e": 20558,
      "ty": 2,
      "x": 955,
      "y": 721
    },
    {
      "t": 126316,
      "e": 20559,
      "ty": 7,
      "x": 954,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 126316,
      "e": 20559,
      "ty": 6,
      "x": 954,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 126333,
      "e": 20576,
      "ty": 7,
      "x": 951,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 126366,
      "e": 20609,
      "ty": 6,
      "x": 940,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126414,
      "e": 20657,
      "ty": 2,
      "x": 940,
      "y": 588
    },
    {
      "t": 126433,
      "e": 20676,
      "ty": 7,
      "x": 939,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126515,
      "e": 20758,
      "ty": 2,
      "x": 933,
      "y": 546
    },
    {
      "t": 126515,
      "e": 20758,
      "ty": 41,
      "x": 27035,
      "y": 14043,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 126600,
      "e": 20843,
      "ty": 6,
      "x": 905,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126614,
      "e": 20857,
      "ty": 2,
      "x": 905,
      "y": 591
    },
    {
      "t": 126715,
      "e": 20958,
      "ty": 2,
      "x": 903,
      "y": 596
    },
    {
      "t": 126764,
      "e": 21007,
      "ty": 41,
      "x": 20330,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126815,
      "e": 21058,
      "ty": 2,
      "x": 902,
      "y": 596
    },
    {
      "t": 126826,
      "e": 21069,
      "ty": 3,
      "x": 902,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126826,
      "e": 21069,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126930,
      "e": 21173,
      "ty": 4,
      "x": 20330,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126931,
      "e": 21174,
      "ty": 5,
      "x": 902,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129536,
      "e": 23779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 129638,
      "e": 23881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "88"
    },
    {
      "t": 129640,
      "e": 23883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129757,
      "e": 24000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "X"
    },
    {
      "t": 130015,
      "e": 24258,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130030,
      "e": 24273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 130031,
      "e": 24274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 130182,
      "e": 24425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 130183,
      "e": 24426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 130197,
      "e": 24440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRA"
    },
    {
      "t": 130349,
      "e": 24592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 130350,
      "e": 24593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 130431,
      "e": 24674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRAY"
    },
    {
      "t": 130478,
      "e": 24721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 130558,
      "e": 24801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 131215,
      "e": 25458,
      "ty": 2,
      "x": 902,
      "y": 597
    },
    {
      "t": 131237,
      "e": 25480,
      "ty": 7,
      "x": 888,
      "y": 623,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 131265,
      "e": 25508,
      "ty": 41,
      "x": 14923,
      "y": 4681,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 131314,
      "e": 25557,
      "ty": 2,
      "x": 852,
      "y": 672
    },
    {
      "t": 131320,
      "e": 25563,
      "ty": 6,
      "x": 847,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131354,
      "e": 25597,
      "ty": 7,
      "x": 831,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131414,
      "e": 25657,
      "ty": 2,
      "x": 826,
      "y": 713
    },
    {
      "t": 131515,
      "e": 25758,
      "ty": 41,
      "x": 28170,
      "y": 39055,
      "ta": "html > body"
    },
    {
      "t": 131615,
      "e": 25858,
      "ty": 2,
      "x": 826,
      "y": 703
    },
    {
      "t": 131621,
      "e": 25864,
      "ty": 6,
      "x": 827,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131714,
      "e": 25957,
      "ty": 2,
      "x": 828,
      "y": 694
    },
    {
      "t": 131729,
      "e": 25972,
      "ty": 3,
      "x": 828,
      "y": 694,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131731,
      "e": 25974,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRAY"
    },
    {
      "t": 131731,
      "e": 25974,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 131731,
      "e": 25974,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131765,
      "e": 26008,
      "ty": 41,
      "x": 4325,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131890,
      "e": 26133,
      "ty": 4,
      "x": 4325,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131891,
      "e": 26134,
      "ty": 5,
      "x": 828,
      "y": 694,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132502,
      "e": 26745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 132503,
      "e": 26746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132620,
      "e": 26863,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 132622,
      "e": 26865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 133053,
      "e": 27296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 133053,
      "e": 27296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 133174,
      "e": 27417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 134175,
      "e": 28418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 134270,
      "e": 28513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 134422,
      "e": 28665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 134503,
      "e": 28746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 134619,
      "e": 28862,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 134886,
      "e": 29129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 134887,
      "e": 29130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134957,
      "e": 29200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 134957,
      "e": 29200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134998,
      "e": 29241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31"
    },
    {
      "t": 135038,
      "e": 29281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31"
    },
    {
      "t": 135119,
      "e": 29362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 135119,
      "e": 29362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 135198,
      "e": 29441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 135765,
      "e": 30008,
      "ty": 41,
      "x": 6488,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 135815,
      "e": 30058,
      "ty": 2,
      "x": 850,
      "y": 691
    },
    {
      "t": 135915,
      "e": 30158,
      "ty": 2,
      "x": 856,
      "y": 691
    },
    {
      "t": 135990,
      "e": 30233,
      "ty": 7,
      "x": 865,
      "y": 706,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 136015,
      "e": 30258,
      "ty": 2,
      "x": 868,
      "y": 710
    },
    {
      "t": 136015,
      "e": 30258,
      "ty": 41,
      "x": 29616,
      "y": 38888,
      "ta": "html > body"
    },
    {
      "t": 136115,
      "e": 30358,
      "ty": 2,
      "x": 893,
      "y": 728
    },
    {
      "t": 136125,
      "e": 30368,
      "ty": 6,
      "x": 895,
      "y": 729,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136215,
      "e": 30458,
      "ty": 2,
      "x": 907,
      "y": 732
    },
    {
      "t": 136264,
      "e": 30507,
      "ty": 41,
      "x": 9317,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136315,
      "e": 30558,
      "ty": 2,
      "x": 916,
      "y": 730
    },
    {
      "t": 136363,
      "e": 30606,
      "ty": 3,
      "x": 916,
      "y": 730,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136364,
      "e": 30607,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 136365,
      "e": 30608,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 136366,
      "e": 30609,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136442,
      "e": 30685,
      "ty": 4,
      "x": 10348,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136443,
      "e": 30686,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136443,
      "e": 30686,
      "ty": 5,
      "x": 916,
      "y": 730,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 136444,
      "e": 30687,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 136515,
      "e": 30758,
      "ty": 41,
      "x": 31269,
      "y": 39996,
      "ta": "html > body"
    },
    {
      "t": 136915,
      "e": 31158,
      "ty": 2,
      "x": 788,
      "y": 796
    },
    {
      "t": 137015,
      "e": 31258,
      "ty": 2,
      "x": 692,
      "y": 847
    },
    {
      "t": 137015,
      "e": 31258,
      "ty": 41,
      "x": 23555,
      "y": 46478,
      "ta": "html > body"
    },
    {
      "t": 137115,
      "e": 31358,
      "ty": 2,
      "x": 683,
      "y": 850
    },
    {
      "t": 137266,
      "e": 31509,
      "ty": 41,
      "x": 23245,
      "y": 46644,
      "ta": "html > body"
    },
    {
      "t": 137544,
      "e": 31787,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 139515,
      "e": 33758,
      "ty": 2,
      "x": 644,
      "y": 831
    },
    {
      "t": 139516,
      "e": 33759,
      "ty": 41,
      "x": 17245,
      "y": 48798,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 139614,
      "e": 33857,
      "ty": 2,
      "x": 625,
      "y": 814
    },
    {
      "t": 139765,
      "e": 34008,
      "ty": 41,
      "x": 16311,
      "y": 30463,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 140014,
      "e": 34257,
      "ty": 2,
      "x": 625,
      "y": 807
    },
    {
      "t": 140015,
      "e": 34258,
      "ty": 41,
      "x": 16311,
      "y": 14079,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 140015,
      "e": 34258,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140114,
      "e": 34357,
      "ty": 2,
      "x": 625,
      "y": 808
    },
    {
      "t": 140214,
      "e": 34457,
      "ty": 2,
      "x": 625,
      "y": 809
    },
    {
      "t": 140264,
      "e": 34507,
      "ty": 41,
      "x": 16311,
      "y": 18760,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 141914,
      "e": 36157,
      "ty": 2,
      "x": 633,
      "y": 808
    },
    {
      "t": 142015,
      "e": 36258,
      "ty": 2,
      "x": 663,
      "y": 801
    },
    {
      "t": 142015,
      "e": 36258,
      "ty": 41,
      "x": 18180,
      "y": 36,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 142215,
      "e": 36458,
      "ty": 2,
      "x": 666,
      "y": 799
    },
    {
      "t": 142264,
      "e": 36507,
      "ty": 41,
      "x": 18377,
      "y": 60889,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 142314,
      "e": 36557,
      "ty": 2,
      "x": 668,
      "y": 799
    },
    {
      "t": 142515,
      "e": 36758,
      "ty": 41,
      "x": 18426,
      "y": 60889,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 143014,
      "e": 37257,
      "ty": 2,
      "x": 647,
      "y": 785
    },
    {
      "t": 143014,
      "e": 37257,
      "ty": 41,
      "x": 17393,
      "y": 58720,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 143031,
      "e": 37274,
      "ty": 6,
      "x": 641,
      "y": 780,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 143114,
      "e": 37357,
      "ty": 2,
      "x": 633,
      "y": 771
    },
    {
      "t": 143214,
      "e": 37457,
      "ty": 2,
      "x": 631,
      "y": 758
    },
    {
      "t": 143265,
      "e": 37508,
      "ty": 41,
      "x": 15147,
      "y": 4717,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 143314,
      "e": 37557,
      "ty": 2,
      "x": 631,
      "y": 757
    },
    {
      "t": 143414,
      "e": 37657,
      "ty": 2,
      "x": 625,
      "y": 756
    },
    {
      "t": 143515,
      "e": 37758,
      "ty": 41,
      "x": 14843,
      "y": 2377,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 147114,
      "e": 41357,
      "ty": 2,
      "x": 631,
      "y": 782
    },
    {
      "t": 147117,
      "e": 41360,
      "ty": 7,
      "x": 635,
      "y": 790,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 147215,
      "e": 41458,
      "ty": 2,
      "x": 663,
      "y": 834
    },
    {
      "t": 147265,
      "e": 41508,
      "ty": 41,
      "x": 18869,
      "y": 51014,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 147314,
      "e": 41557,
      "ty": 2,
      "x": 695,
      "y": 910
    },
    {
      "t": 147415,
      "e": 41658,
      "ty": 2,
      "x": 739,
      "y": 967
    },
    {
      "t": 147515,
      "e": 41758,
      "ty": 2,
      "x": 835,
      "y": 1014
    },
    {
      "t": 147515,
      "e": 41758,
      "ty": 41,
      "x": 26642,
      "y": 61471,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 147614,
      "e": 41857,
      "ty": 2,
      "x": 869,
      "y": 1032
    },
    {
      "t": 147684,
      "e": 41927,
      "ty": 6,
      "x": 933,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 147715,
      "e": 41958,
      "ty": 2,
      "x": 939,
      "y": 1079
    },
    {
      "t": 147765,
      "e": 42008,
      "ty": 41,
      "x": 19933,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 147814,
      "e": 42057,
      "ty": 2,
      "x": 952,
      "y": 1085
    },
    {
      "t": 147914,
      "e": 42157,
      "ty": 2,
      "x": 968,
      "y": 1101
    },
    {
      "t": 148014,
      "e": 42257,
      "ty": 2,
      "x": 974,
      "y": 1105
    },
    {
      "t": 148015,
      "e": 42258,
      "ty": 41,
      "x": 35225,
      "y": 62282,
      "ta": "#start"
    },
    {
      "t": 148114,
      "e": 42357,
      "ty": 2,
      "x": 974,
      "y": 1106
    },
    {
      "t": 148264,
      "e": 42507,
      "ty": 41,
      "x": 35225,
      "y": 64209,
      "ta": "#start"
    },
    {
      "t": 148739,
      "e": 42982,
      "ty": 3,
      "x": 974,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 148740,
      "e": 42983,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 148809,
      "e": 43052,
      "ty": 4,
      "x": 35225,
      "y": 64209,
      "ta": "#start"
    },
    {
      "t": 148810,
      "e": 43053,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 148810,
      "e": 43053,
      "ty": 5,
      "x": 974,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 148812,
      "e": 43055,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 149814,
      "e": 44057,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 150015,
      "e": 44258,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 166114,
      "e": 48053,
      "ty": 2,
      "x": 970,
      "y": 1100
    },
    {
      "t": 166214,
      "e": 48153,
      "ty": 2,
      "x": 970,
      "y": 1099
    },
    {
      "t": 166265,
      "e": 48204,
      "ty": 41,
      "x": 33129,
      "y": 60438,
      "ta": "html > body"
    },
    {
      "t": 168307,
      "e": 50246,
      "ty": 3,
      "x": 970,
      "y": 1099,
      "ta": "html > body"
    },
    {
      "t": 168442,
      "e": 50381,
      "ty": 4,
      "x": 33129,
      "y": 60438,
      "ta": "html > body"
    },
    {
      "t": 168442,
      "e": 50381,
      "ty": 5,
      "x": 970,
      "y": 1099,
      "ta": "html > body"
    },
    {
      "t": 169414,
      "e": 51353,
      "ty": 2,
      "x": 955,
      "y": 1098
    },
    {
      "t": 169515,
      "e": 51454,
      "ty": 41,
      "x": 32612,
      "y": 60383,
      "ta": "html > body"
    },
    {
      "t": 169991,
      "e": 51930,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 170998,
      "e": 52937,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 86, dom: 611, initialDom: 615",
  "javascriptErrors": []
}