var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "50d4283e87166ef781ad0b00ee149a91",
  "created": "2018-05-25T11:14:02.0636228-07:00",
  "lastActivity": "2018-05-25T11:14:18.2886228-07:00",
  "pageViews": [
    {
      "id": "05250271b3b79460056d4b300a599f21faf1c44a",
      "startTime": "2018-05-25T11:14:02.0636228-07:00",
      "endTime": "2018-05-25T11:14:18.2886228-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 16225,
      "engagementTime": 16225,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 16225,
  "engagementTime": 16225,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FK2HU",
    "CONDITION=114",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "eb8920d981d053792b74625c5ff3db0c",
  "gdpr": false
}