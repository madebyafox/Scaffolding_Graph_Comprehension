var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052436955c93e30a04819001c87fa7039ef2c186"] = {
  "startTime": "2018-05-24T19:03:36.208199Z",
  "websitePageUrl": "/",
  "visitTime": 89678,
  "engagementTime": 62296,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "8c925c517ed9b8fcf76cca4d677c256b",
    "created": "2018-05-24T19:03:36.1132015+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "daabe3400f5170349d71ee695dc3efd8",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/8c925c517ed9b8fcf76cca4d677c256b/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 271,
      "e": 271,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 815,
      "y": 257
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 24875,
      "y": 9052,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 716,
      "y": 384
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 764,
      "y": 507
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 24439,
      "y": 32153,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 817,
      "y": 547
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 24985,
      "y": 32808,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10000,
      "e": 6501,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 21101,
      "e": 6501,
      "ty": 2,
      "x": 831,
      "y": 82
    },
    {
      "t": 21251,
      "e": 6651,
      "ty": 41,
      "x": 28342,
      "y": 4502,
      "ta": "html > body"
    },
    {
      "t": 21601,
      "e": 7001,
      "ty": 2,
      "x": 882,
      "y": 106
    },
    {
      "t": 21701,
      "e": 7101,
      "ty": 2,
      "x": 1184,
      "y": 171
    },
    {
      "t": 21751,
      "e": 7151,
      "ty": 41,
      "x": 46338,
      "y": 2007,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 21800,
      "e": 7200,
      "ty": 2,
      "x": 1208,
      "y": 171
    },
    {
      "t": 22701,
      "e": 8101,
      "ty": 2,
      "x": 1205,
      "y": 173
    },
    {
      "t": 22751,
      "e": 8151,
      "ty": 41,
      "x": 46174,
      "y": 2170,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 23251,
      "e": 8651,
      "ty": 41,
      "x": 45956,
      "y": 2252,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 23301,
      "e": 8701,
      "ty": 2,
      "x": 1194,
      "y": 176
    },
    {
      "t": 23400,
      "e": 8800,
      "ty": 2,
      "x": 1192,
      "y": 176
    },
    {
      "t": 23501,
      "e": 8901,
      "ty": 41,
      "x": 45464,
      "y": 2416,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 24901,
      "e": 10301,
      "ty": 2,
      "x": 1183,
      "y": 180
    },
    {
      "t": 25001,
      "e": 10401,
      "ty": 2,
      "x": 1179,
      "y": 182
    },
    {
      "t": 25001,
      "e": 10401,
      "ty": 41,
      "x": 44754,
      "y": 2908,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 26201,
      "e": 11601,
      "ty": 2,
      "x": 1148,
      "y": 192
    },
    {
      "t": 26251,
      "e": 11651,
      "ty": 41,
      "x": 42297,
      "y": 5038,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 26301,
      "e": 11701,
      "ty": 2,
      "x": 1090,
      "y": 300
    },
    {
      "t": 26401,
      "e": 11801,
      "ty": 2,
      "x": 1019,
      "y": 627
    },
    {
      "t": 26501,
      "e": 11901,
      "ty": 2,
      "x": 1025,
      "y": 654
    },
    {
      "t": 26501,
      "e": 11901,
      "ty": 41,
      "x": 36344,
      "y": 41573,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 26579,
      "e": 11979,
      "ty": 3,
      "x": 1025,
      "y": 654,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 26712,
      "e": 12112,
      "ty": 4,
      "x": 36344,
      "y": 41573,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 26712,
      "e": 12112,
      "ty": 5,
      "x": 1025,
      "y": 654,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 26901,
      "e": 12301,
      "ty": 2,
      "x": 1025,
      "y": 649
    },
    {
      "t": 27001,
      "e": 12401,
      "ty": 2,
      "x": 1022,
      "y": 641
    },
    {
      "t": 27001,
      "e": 12401,
      "ty": 41,
      "x": 36180,
      "y": 40508,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 27101,
      "e": 12501,
      "ty": 2,
      "x": 1022,
      "y": 638
    },
    {
      "t": 27200,
      "e": 12600,
      "ty": 2,
      "x": 1019,
      "y": 631
    },
    {
      "t": 27251,
      "e": 12651,
      "ty": 41,
      "x": 36016,
      "y": 39607,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 27301,
      "e": 12701,
      "ty": 2,
      "x": 1019,
      "y": 630
    },
    {
      "t": 30001,
      "e": 15401,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 32401,
      "e": 17701,
      "ty": 2,
      "x": 1018,
      "y": 629
    },
    {
      "t": 32501,
      "e": 17801,
      "ty": 41,
      "x": 35962,
      "y": 39525,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 40000,
      "e": 22801,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 43606,
      "e": 22801,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 43700,
      "e": 22801,
      "ty": 1,
      "x": 0,
      "y": 10
    },
    {
      "t": 43800,
      "e": 22901,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 44694,
      "e": 23795,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 46201,
      "e": 25302,
      "ty": 2,
      "x": 1004,
      "y": 829
    },
    {
      "t": 46251,
      "e": 25352,
      "ty": 41,
      "x": 36924,
      "y": 60669,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 46301,
      "e": 25402,
      "ty": 2,
      "x": 1048,
      "y": 851
    },
    {
      "t": 46400,
      "e": 25501,
      "ty": 2,
      "x": 963,
      "y": 881
    },
    {
      "t": 46501,
      "e": 25602,
      "ty": 2,
      "x": 847,
      "y": 921
    },
    {
      "t": 46501,
      "e": 25602,
      "ty": 41,
      "x": 27232,
      "y": 61252,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 46601,
      "e": 25702,
      "ty": 2,
      "x": 848,
      "y": 899
    },
    {
      "t": 46700,
      "e": 25801,
      "ty": 2,
      "x": 849,
      "y": 861
    },
    {
      "t": 46751,
      "e": 25852,
      "ty": 41,
      "x": 9566,
      "y": 17873,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 46801,
      "e": 25902,
      "ty": 2,
      "x": 845,
      "y": 861
    },
    {
      "t": 46900,
      "e": 26001,
      "ty": 2,
      "x": 835,
      "y": 866
    },
    {
      "t": 47001,
      "e": 26102,
      "ty": 2,
      "x": 821,
      "y": 869
    },
    {
      "t": 47001,
      "e": 26102,
      "ty": 41,
      "x": 57547,
      "y": 36044,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 47153,
      "e": 26254,
      "ty": 3,
      "x": 821,
      "y": 869,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 47249,
      "e": 26350,
      "ty": 4,
      "x": 57547,
      "y": 36044,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 47250,
      "e": 26351,
      "ty": 5,
      "x": 821,
      "y": 869,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 47252,
      "e": 26353,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 47263,
      "e": 26364,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 48701,
      "e": 27802,
      "ty": 2,
      "x": 840,
      "y": 883
    },
    {
      "t": 48751,
      "e": 27852,
      "ty": 41,
      "x": 29643,
      "y": 60872,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 48801,
      "e": 27902,
      "ty": 2,
      "x": 937,
      "y": 932
    },
    {
      "t": 48901,
      "e": 28002,
      "ty": 2,
      "x": 960,
      "y": 949
    },
    {
      "t": 49001,
      "e": 28102,
      "ty": 2,
      "x": 966,
      "y": 954
    },
    {
      "t": 49001,
      "e": 28102,
      "ty": 41,
      "x": 33087,
      "y": 63762,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 49101,
      "e": 28202,
      "ty": 2,
      "x": 969,
      "y": 974
    },
    {
      "t": 49129,
      "e": 28230,
      "ty": 6,
      "x": 969,
      "y": 980,
      "ta": "#start"
    },
    {
      "t": 49201,
      "e": 28302,
      "ty": 2,
      "x": 970,
      "y": 999
    },
    {
      "t": 49251,
      "e": 28352,
      "ty": 41,
      "x": 33040,
      "y": 47615,
      "ta": "#start"
    },
    {
      "t": 49301,
      "e": 28402,
      "ty": 2,
      "x": 970,
      "y": 1002
    },
    {
      "t": 49601,
      "e": 28702,
      "ty": 2,
      "x": 970,
      "y": 999
    },
    {
      "t": 49701,
      "e": 28802,
      "ty": 2,
      "x": 967,
      "y": 994
    },
    {
      "t": 49751,
      "e": 28852,
      "ty": 41,
      "x": 31402,
      "y": 30267,
      "ta": "#start"
    },
    {
      "t": 49801,
      "e": 28902,
      "ty": 2,
      "x": 967,
      "y": 993
    },
    {
      "t": 50001,
      "e": 29102,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 52601,
      "e": 31702,
      "ty": 3,
      "x": 967,
      "y": 993,
      "ta": "#start"
    },
    {
      "t": 52603,
      "e": 31704,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 52604,
      "e": 31705,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 52751,
      "e": 31852,
      "ty": 4,
      "x": 31402,
      "y": 30267,
      "ta": "#start"
    },
    {
      "t": 52753,
      "e": 31854,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 52753,
      "e": 31854,
      "ty": 5,
      "x": 967,
      "y": 993,
      "ta": "#start"
    },
    {
      "t": 52754,
      "e": 31855,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 53764,
      "e": 32865,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 54400,
      "e": 33501,
      "ty": 2,
      "x": 1077,
      "y": 680
    },
    {
      "t": 54434,
      "e": 33535,
      "ty": 6,
      "x": 1100,
      "y": 548,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54451,
      "e": 33552,
      "ty": 7,
      "x": 1110,
      "y": 516,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54501,
      "e": 33602,
      "ty": 2,
      "x": 1115,
      "y": 504
    },
    {
      "t": 54501,
      "e": 33602,
      "ty": 41,
      "x": 38122,
      "y": 30181,
      "ta": "html > body"
    },
    {
      "t": 54600,
      "e": 33701,
      "ty": 2,
      "x": 1096,
      "y": 501
    },
    {
      "t": 54701,
      "e": 33802,
      "ty": 6,
      "x": 992,
      "y": 535,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54702,
      "e": 33803,
      "ty": 2,
      "x": 992,
      "y": 535
    },
    {
      "t": 54751,
      "e": 33852,
      "ty": 41,
      "x": 35254,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54767,
      "e": 33868,
      "ty": 7,
      "x": 966,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54801,
      "e": 33902,
      "ty": 2,
      "x": 962,
      "y": 565
    },
    {
      "t": 55001,
      "e": 34102,
      "ty": 2,
      "x": 962,
      "y": 560
    },
    {
      "t": 55001,
      "e": 34102,
      "ty": 41,
      "x": 33308,
      "y": 64125,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 55035,
      "e": 34136,
      "ty": 6,
      "x": 962,
      "y": 550,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55101,
      "e": 34202,
      "ty": 2,
      "x": 962,
      "y": 544
    },
    {
      "t": 55251,
      "e": 34352,
      "ty": 41,
      "x": 33308,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55256,
      "e": 34357,
      "ty": 3,
      "x": 962,
      "y": 544,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55257,
      "e": 34358,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55391,
      "e": 34492,
      "ty": 4,
      "x": 33308,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55392,
      "e": 34493,
      "ty": 5,
      "x": 962,
      "y": 544,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58058,
      "e": 37159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 58251,
      "e": 37352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 59098,
      "e": 38199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 59314,
      "e": 38415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 59315,
      "e": 38416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59422,
      "e": 38523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "K"
    },
    {
      "t": 59735,
      "e": 38836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "K"
    },
    {
      "t": 60004,
      "e": 39105,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60158,
      "e": 39259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 60158,
      "e": 39259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60253,
      "e": 39354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Ki"
    },
    {
      "t": 60438,
      "e": 39539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 60439,
      "e": 39540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60533,
      "e": 39634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Kil"
    },
    {
      "t": 60686,
      "e": 39787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 60687,
      "e": 39788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60765,
      "e": 39866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Kilo"
    },
    {
      "t": 61494,
      "e": 40595,
      "ty": 7,
      "x": 958,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61504,
      "e": 40605,
      "ty": 2,
      "x": 958,
      "y": 558
    },
    {
      "t": 61504,
      "e": 40605,
      "ty": 41,
      "x": 32443,
      "y": 62716,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 61604,
      "e": 40705,
      "ty": 2,
      "x": 938,
      "y": 622
    },
    {
      "t": 61644,
      "e": 40745,
      "ty": 6,
      "x": 937,
      "y": 626,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61705,
      "e": 40806,
      "ty": 2,
      "x": 937,
      "y": 628
    },
    {
      "t": 61755,
      "e": 40856,
      "ty": 41,
      "x": 27901,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61805,
      "e": 40906,
      "ty": 2,
      "x": 937,
      "y": 633
    },
    {
      "t": 62004,
      "e": 41105,
      "ty": 41,
      "x": 27901,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62044,
      "e": 41145,
      "ty": 3,
      "x": 937,
      "y": 633,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62044,
      "e": 41145,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Kilo"
    },
    {
      "t": 62044,
      "e": 41145,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 62044,
      "e": 41145,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62147,
      "e": 41248,
      "ty": 4,
      "x": 27901,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62147,
      "e": 41248,
      "ty": 5,
      "x": 937,
      "y": 633,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63846,
      "e": 42947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 63847,
      "e": 42948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63981,
      "e": 43082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 64061,
      "e": 43162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 64062,
      "e": 43163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64133,
      "e": 43234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 64590,
      "e": 43691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "99"
    },
    {
      "t": 64591,
      "e": 43692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64662,
      "e": 43763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 65997,
      "e": 45098,
      "ty": 7,
      "x": 944,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66004,
      "e": 45105,
      "ty": 2,
      "x": 944,
      "y": 648
    },
    {
      "t": 66005,
      "e": 45106,
      "ty": 41,
      "x": 29415,
      "y": 60602,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 66031,
      "e": 45132,
      "ty": 6,
      "x": 947,
      "y": 656,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66105,
      "e": 45206,
      "ty": 2,
      "x": 948,
      "y": 659
    },
    {
      "t": 66204,
      "e": 45305,
      "ty": 2,
      "x": 953,
      "y": 666
    },
    {
      "t": 66254,
      "e": 45355,
      "ty": 41,
      "x": 29417,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66281,
      "e": 45382,
      "ty": 7,
      "x": 955,
      "y": 690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66305,
      "e": 45406,
      "ty": 2,
      "x": 957,
      "y": 703
    },
    {
      "t": 66404,
      "e": 45505,
      "ty": 2,
      "x": 958,
      "y": 713
    },
    {
      "t": 66504,
      "e": 45605,
      "ty": 2,
      "x": 960,
      "y": 698
    },
    {
      "t": 66505,
      "e": 45606,
      "ty": 41,
      "x": 32784,
      "y": 41986,
      "ta": "html > body"
    },
    {
      "t": 66605,
      "e": 45706,
      "ty": 2,
      "x": 960,
      "y": 691
    },
    {
      "t": 66704,
      "e": 45805,
      "ty": 2,
      "x": 965,
      "y": 689
    },
    {
      "t": 66716,
      "e": 45817,
      "ty": 6,
      "x": 968,
      "y": 686,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66754,
      "e": 45855,
      "ty": 41,
      "x": 40756,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66804,
      "e": 45905,
      "ty": 2,
      "x": 976,
      "y": 671
    },
    {
      "t": 66905,
      "e": 46006,
      "ty": 2,
      "x": 976,
      "y": 669
    },
    {
      "t": 67005,
      "e": 46106,
      "ty": 41,
      "x": 41271,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69669,
      "e": 48770,
      "ty": 3,
      "x": 976,
      "y": 669,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69670,
      "e": 48771,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 69671,
      "e": 48772,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69672,
      "e": 48773,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69803,
      "e": 48904,
      "ty": 4,
      "x": 41271,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69805,
      "e": 48906,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69806,
      "e": 48907,
      "ty": 5,
      "x": 976,
      "y": 669,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69806,
      "e": 48907,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 70004,
      "e": 49105,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70907,
      "e": 50008,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 70936,
      "e": 50037,
      "ty": 6,
      "x": 976,
      "y": 669,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 72386,
      "e": 51487,
      "ty": 7,
      "x": 973,
      "y": 675,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 72386,
      "e": 51487,
      "ty": 6,
      "x": 973,
      "y": 675,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 72404,
      "e": 51505,
      "ty": 2,
      "x": 972,
      "y": 676
    },
    {
      "t": 72505,
      "e": 51606,
      "ty": 2,
      "x": 965,
      "y": 684
    },
    {
      "t": 72505,
      "e": 51606,
      "ty": 41,
      "x": 32069,
      "y": 23405,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 72553,
      "e": 51654,
      "ty": 7,
      "x": 957,
      "y": 708,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 72554,
      "e": 51655,
      "ty": 6,
      "x": 957,
      "y": 708,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 72604,
      "e": 51705,
      "ty": 7,
      "x": 952,
      "y": 737,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 72604,
      "e": 51705,
      "ty": 2,
      "x": 952,
      "y": 737
    },
    {
      "t": 72705,
      "e": 51806,
      "ty": 2,
      "x": 968,
      "y": 832
    },
    {
      "t": 72755,
      "e": 51856,
      "ty": 41,
      "x": 33234,
      "y": 54635,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 72805,
      "e": 51906,
      "ty": 2,
      "x": 969,
      "y": 834
    },
    {
      "t": 74755,
      "e": 53856,
      "ty": 41,
      "x": 32890,
      "y": 55396,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 74804,
      "e": 53905,
      "ty": 2,
      "x": 955,
      "y": 878
    },
    {
      "t": 74905,
      "e": 54006,
      "ty": 2,
      "x": 960,
      "y": 917
    },
    {
      "t": 75005,
      "e": 54106,
      "ty": 2,
      "x": 968,
      "y": 953
    },
    {
      "t": 75005,
      "e": 54106,
      "ty": 41,
      "x": 33185,
      "y": 63686,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 75104,
      "e": 54205,
      "ty": 2,
      "x": 968,
      "y": 969
    },
    {
      "t": 75205,
      "e": 54306,
      "ty": 2,
      "x": 968,
      "y": 973
    },
    {
      "t": 75255,
      "e": 54356,
      "ty": 41,
      "x": 33185,
      "y": 65360,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 75305,
      "e": 54406,
      "ty": 2,
      "x": 968,
      "y": 976
    },
    {
      "t": 75309,
      "e": 54410,
      "ty": 6,
      "x": 968,
      "y": 978,
      "ta": "#start"
    },
    {
      "t": 75405,
      "e": 54506,
      "ty": 2,
      "x": 964,
      "y": 987
    },
    {
      "t": 75505,
      "e": 54606,
      "ty": 2,
      "x": 961,
      "y": 994
    },
    {
      "t": 75505,
      "e": 54606,
      "ty": 41,
      "x": 28125,
      "y": 32195,
      "ta": "#start"
    },
    {
      "t": 75652,
      "e": 54753,
      "ty": 3,
      "x": 961,
      "y": 994,
      "ta": "#start"
    },
    {
      "t": 75653,
      "e": 54754,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 75771,
      "e": 54872,
      "ty": 4,
      "x": 28125,
      "y": 32195,
      "ta": "#start"
    },
    {
      "t": 75772,
      "e": 54873,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 75772,
      "e": 54873,
      "ty": 5,
      "x": 961,
      "y": 994,
      "ta": "#start"
    },
    {
      "t": 75773,
      "e": 54874,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 76775,
      "e": 55876,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 80005,
      "e": 59106,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 87255,
      "e": 59873,
      "ty": 41,
      "x": 32027,
      "y": 59328,
      "ta": "html > body"
    },
    {
      "t": 87304,
      "e": 59922,
      "ty": 2,
      "x": 933,
      "y": 978
    },
    {
      "t": 87504,
      "e": 60122,
      "ty": 41,
      "x": 23388,
      "y": 55002,
      "ta": "> p"
    },
    {
      "t": 87904,
      "e": 60522,
      "ty": 2,
      "x": 933,
      "y": 972
    },
    {
      "t": 88004,
      "e": 60622,
      "ty": 2,
      "x": 933,
      "y": 971
    },
    {
      "t": 88004,
      "e": 60622,
      "ty": 41,
      "x": 23388,
      "y": 38618,
      "ta": "> p"
    },
    {
      "t": 88254,
      "e": 60872,
      "ty": 41,
      "x": 23034,
      "y": 31597,
      "ta": "> p"
    },
    {
      "t": 88304,
      "e": 60922,
      "ty": 2,
      "x": 926,
      "y": 965
    },
    {
      "t": 88404,
      "e": 61022,
      "ty": 2,
      "x": 923,
      "y": 964
    },
    {
      "t": 88504,
      "e": 61122,
      "ty": 2,
      "x": 897,
      "y": 946
    },
    {
      "t": 88504,
      "e": 61122,
      "ty": 41,
      "x": 30615,
      "y": 57076,
      "ta": "html > body"
    },
    {
      "t": 88604,
      "e": 61222,
      "ty": 2,
      "x": 884,
      "y": 929
    },
    {
      "t": 88674,
      "e": 61292,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 88754,
      "e": 61372,
      "ty": 41,
      "x": 30167,
      "y": 56042,
      "ta": "html > body"
    },
    {
      "t": 89678,
      "e": 62296,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 139, dom: 750, initialDom: 753",
  "javascriptErrors": []
}