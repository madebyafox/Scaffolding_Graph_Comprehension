var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05223668748883fa446a609ab74207ce051eb47f"] = {
  "startTime": "2018-05-22T23:03:36.2432204Z",
  "websitePageUrl": "/",
  "visitTime": 12695,
  "engagementTime": 13800,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [],
  "session": {
    "id": "16a3c5abdb0fdad5dae6ad3d786cd3c7",
    "created": "2018-05-22T23:03:36.2432204+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "9740fa28b3d49bbe4287caa184f01d18",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/16a3c5abdb0fdad5dae6ad3d786cd3c7/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 200,
      "e": 200,
      "ty": 2,
      "x": 498,
      "y": 13
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 36072,
      "y": 1272,
      "ta": "html > body"
    },
    {
      "t": 300,
      "e": 300,
      "ty": 2,
      "x": 518,
      "y": 42
    },
    {
      "t": 323,
      "e": 323,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 400,
      "e": 400,
      "ty": 2,
      "x": 573,
      "y": 135
    },
    {
      "t": 500,
      "e": 500,
      "ty": 2,
      "x": 608,
      "y": 253
    },
    {
      "t": 500,
      "e": 500,
      "ty": 41,
      "x": 40631,
      "y": 10649,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 600,
      "e": 600,
      "ty": 2,
      "x": 610,
      "y": 353
    },
    {
      "t": 700,
      "e": 700,
      "ty": 2,
      "x": 595,
      "y": 508
    },
    {
      "t": 750,
      "e": 750,
      "ty": 41,
      "x": 39157,
      "y": 35880,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 577,
      "y": 586
    },
    {
      "t": 909,
      "e": 909,
      "ty": 2,
      "x": 575,
      "y": 592
    },
    {
      "t": 1009,
      "e": 1009,
      "ty": 41,
      "x": 38829,
      "y": 38419,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1587,
      "e": 1587,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 711,
      "y": 87
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 50516,
      "y": 5026,
      "ta": "html > body"
    },
    {
      "t": 2608,
      "e": 2608,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 3626,
      "e": 3626,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 1,
      "x": 0,
      "y": 5
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 4712,
      "e": 4712,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 10006,
      "e": 8800,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 12695,
      "e": 13800,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 90, dom: 217, initialDom: 222",
  "javascriptErrors": []
}