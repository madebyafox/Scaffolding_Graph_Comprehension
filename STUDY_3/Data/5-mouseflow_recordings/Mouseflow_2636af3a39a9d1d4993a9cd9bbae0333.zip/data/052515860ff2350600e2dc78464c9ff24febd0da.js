var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052515860ff2350600e2dc78464c9ff24febd0da"] = {
  "startTime": "2018-05-25T18:14:15.8697175Z",
  "websitePageUrl": "/16",
  "visitTime": 73255,
  "engagementTime": 72381,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "2636af3a39a9d1d4993a9cd9bbae0333",
    "created": "2018-05-25T18:14:15.7269246+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=4P01U",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "e0103a64fa3b76cf177bb70dff1bf3d6",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/2636af3a39a9d1d4993a9cd9bbae0333/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 189,
      "e": 189,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 189,
      "e": 189,
      "ty": 2,
      "x": 1125,
      "y": 630
    },
    {
      "t": 201,
      "e": 201,
      "ty": 2,
      "x": 1091,
      "y": 630
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 212,
      "y": 35238,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 301,
      "e": 301,
      "ty": 2,
      "x": 429,
      "y": 630
    },
    {
      "t": 401,
      "e": 401,
      "ty": 2,
      "x": 258,
      "y": 616
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 18087,
      "y": 62934,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 19886,
      "y": 62480,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 276,
      "y": 610
    },
    {
      "t": 831,
      "e": 831,
      "ty": 6,
      "x": 277,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 280,
      "y": 584
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 20560,
      "y": 49568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1008,
      "e": 1008,
      "ty": 3,
      "x": 281,
      "y": 583,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1008,
      "e": 1008,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 282,
      "y": 582
    },
    {
      "t": 1111,
      "e": 1111,
      "ty": 4,
      "x": 20785,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1111,
      "e": 1111,
      "ty": 5,
      "x": 282,
      "y": 582,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 20785,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 360,
      "y": 587
    },
    {
      "t": 1348,
      "e": 1348,
      "ty": 7,
      "x": 559,
      "y": 616,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 696,
      "y": 643
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 699,
      "y": 649
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 1085,
      "y": 36282,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 699,
      "y": 651
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 699,
      "y": 653
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 698,
      "y": 653
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 1027,
      "y": 36566,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 696,
      "y": 653
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 912,
      "y": 36566,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 692,
      "y": 655
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 690,
      "y": 655
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 568,
      "y": 36708,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 7873,
      "e": 7502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7976,
      "e": 7605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7976,
      "e": 7605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8055,
      "e": 7684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "O"
    },
    {
      "t": 8086,
      "e": 7715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "O"
    },
    {
      "t": 8143,
      "e": 7772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 8143,
      "e": 7772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8239,
      "e": 7868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ok"
    },
    {
      "t": 8311,
      "e": 7940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 8312,
      "e": 7941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8366,
      "e": 7995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Okk"
    },
    {
      "t": 8503,
      "e": 8132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8503,
      "e": 8132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8582,
      "e": 8211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Okk "
    },
    {
      "t": 8919,
      "e": 8548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8975,
      "e": 8604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Okk"
    },
    {
      "t": 9112,
      "e": 8741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9150,
      "e": 8779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ok"
    },
    {
      "t": 9231,
      "e": 8860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9278,
      "e": 8907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "O"
    },
    {
      "t": 9351,
      "e": 8980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9391,
      "e": 9020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 9463,
      "e": 9092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9535,
      "e": 9164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 9623,
      "e": 9252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9727,
      "e": 9356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 9728,
      "e": 9357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9791,
      "e": 9420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 9798,
      "e": 9427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 9895,
      "e": 9524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9896,
      "e": 9525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9959,
      "e": 9588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 10005,
      "e": 9634,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10015,
      "e": 9644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10016,
      "e": 9645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10102,
      "e": 9731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 10102,
      "e": 9731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10110,
      "e": 9739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 10191,
      "e": 9820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10303,
      "e": 9932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10304,
      "e": 9933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10351,
      "e": 9980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10407,
      "e": 10036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10407,
      "e": 10036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10487,
      "e": 10116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10487,
      "e": 10116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10488,
      "e": 10117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 10488,
      "e": 10117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10503,
      "e": 10132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||aty"
    },
    {
      "t": 10527,
      "e": 10156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10535,
      "e": 10164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10896,
      "e": 10525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10958,
      "e": 10587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at"
    },
    {
      "t": 11223,
      "e": 10852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11224,
      "e": 10853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11302,
      "e": 10931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11343,
      "e": 10972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 11343,
      "e": 10972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11438,
      "e": 11067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 11471,
      "e": 11100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11471,
      "e": 11100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11544,
      "e": 11173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11544,
      "e": 11173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11607,
      "e": 11236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 11632,
      "e": 11261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 11632,
      "e": 11261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11664,
      "e": 11293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 11704,
      "e": 11333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11705,
      "e": 11334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11735,
      "e": 11364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 11783,
      "e": 11412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11912,
      "e": 11541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11912,
      "e": 11541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11975,
      "e": 11604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12703,
      "e": 12332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 12704,
      "e": 12333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12806,
      "e": 12435,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which s"
    },
    {
      "t": 12807,
      "e": 12436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 12814,
      "e": 12443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12816,
      "e": 12445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12871,
      "e": 12500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12871,
      "e": 12500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12943,
      "e": 12572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 12983,
      "e": 12612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13007,
      "e": 12636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 13008,
      "e": 12637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13095,
      "e": 12724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 13102,
      "e": 12731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13103,
      "e": 12732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13159,
      "e": 12788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13847,
      "e": 13476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13848,
      "e": 13477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13943,
      "e": 13572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14279,
      "e": 13908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14280,
      "e": 13909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14367,
      "e": 13996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14367,
      "e": 13996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14390,
      "e": 14019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 14447,
      "e": 14076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14448,
      "e": 14077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14463,
      "e": 14092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 14535,
      "e": 14164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14600,
      "e": 14229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14601,
      "e": 14230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14679,
      "e": 14308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 14702,
      "e": 14331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14703,
      "e": 14332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14766,
      "e": 14395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14975,
      "e": 14604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14976,
      "e": 14605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15055,
      "e": 14684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 15528,
      "e": 15157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15598,
      "e": 15227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which shift start"
    },
    {
      "t": 15623,
      "e": 15252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15686,
      "e": 15315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which shift star"
    },
    {
      "t": 15759,
      "e": 15388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15799,
      "e": 15428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which shift sta"
    },
    {
      "t": 15888,
      "e": 15517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15927,
      "e": 15556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which shift st"
    },
    {
      "t": 15998,
      "e": 15627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16047,
      "e": 15676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which shift s"
    },
    {
      "t": 16111,
      "e": 15740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16167,
      "e": 15796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which shift "
    },
    {
      "t": 17479,
      "e": 17108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17551,
      "e": 17180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which shift"
    },
    {
      "t": 18440,
      "e": 18069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18441,
      "e": 18070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18535,
      "e": 18164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 18559,
      "e": 18188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18559,
      "e": 18188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18630,
      "e": 18259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18655,
      "e": 18284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18655,
      "e": 18284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18734,
      "e": 18363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 18823,
      "e": 18452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18824,
      "e": 18453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18895,
      "e": 18524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 18974,
      "e": 18603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18975,
      "e": 18604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19055,
      "e": 18684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19071,
      "e": 18700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19071,
      "e": 18700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19134,
      "e": 18763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20005,
      "e": 19634,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20616,
      "e": 20245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20806,
      "e": 20435,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which shifts are"
    },
    {
      "t": 21114,
      "e": 20743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21147,
      "e": 20776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21181,
      "e": 20810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21212,
      "e": 20841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21246,
      "e": 20875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21278,
      "e": 20907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21312,
      "e": 20941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21345,
      "e": 20974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21378,
      "e": 21007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21410,
      "e": 21039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21444,
      "e": 21073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21471,
      "e": 21100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which"
    },
    {
      "t": 21607,
      "e": 21236,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which"
    },
    {
      "t": 21951,
      "e": 21580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21952,
      "e": 21581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22031,
      "e": 21660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22168,
      "e": 21797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22168,
      "e": 21797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22239,
      "e": 21868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 22239,
      "e": 21868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22246,
      "e": 21875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ev"
    },
    {
      "t": 22319,
      "e": 21948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22343,
      "e": 21972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22343,
      "e": 21972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22431,
      "e": 22060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 22440,
      "e": 22069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22441,
      "e": 22070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22519,
      "e": 22148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 22631,
      "e": 22260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22631,
      "e": 22260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22703,
      "e": 22332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22760,
      "e": 22389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22760,
      "e": 22389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22838,
      "e": 22467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 22838,
      "e": 22467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22838,
      "e": 22467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22919,
      "e": 22548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23031,
      "e": 22660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23032,
      "e": 22661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23118,
      "e": 22747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23119,
      "e": 22748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23174,
      "e": 22803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 23207,
      "e": 22836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23439,
      "e": 23068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23487,
      "e": 23116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events o"
    },
    {
      "t": 23544,
      "e": 23173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23559,
      "e": 23188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23560,
      "e": 23189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23615,
      "e": 23244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events a"
    },
    {
      "t": 23647,
      "e": 23276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23719,
      "e": 23348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 23719,
      "e": 23348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23782,
      "e": 23411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 23855,
      "e": 23484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23855,
      "e": 23484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23887,
      "e": 23516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23888,
      "e": 23517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23934,
      "e": 23563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 23958,
      "e": 23587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24063,
      "e": 23692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24064,
      "e": 23693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24150,
      "e": 23779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24151,
      "e": 23780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24190,
      "e": 23819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 24239,
      "e": 23868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24344,
      "e": 23973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24344,
      "e": 23973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24391,
      "e": 24020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24511,
      "e": 24140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24511,
      "e": 24140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24583,
      "e": 24212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24672,
      "e": 24301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24672,
      "e": 24301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24743,
      "e": 24372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 24774,
      "e": 24403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24774,
      "e": 24403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24847,
      "e": 24476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 24855,
      "e": 24484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24856,
      "e": 24485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24919,
      "e": 24548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25935,
      "e": 25564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 25936,
      "e": 25565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26022,
      "e": 25651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 26207,
      "e": 25836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26208,
      "e": 25837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26286,
      "e": 25915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26399,
      "e": 26028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26399,
      "e": 26028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26471,
      "e": 26100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26615,
      "e": 26244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 26615,
      "e": 26244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26710,
      "e": 26339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 26864,
      "e": 26493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26864,
      "e": 26493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26926,
      "e": 26555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 26935,
      "e": 26564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26935,
      "e": 26564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27007,
      "e": 26636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27440,
      "e": 27069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27440,
      "e": 27069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27558,
      "e": 27187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28263,
      "e": 27892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28266,
      "e": 27895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28359,
      "e": 27988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28359,
      "e": 27988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28422,
      "e": 28051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 28455,
      "e": 28084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28559,
      "e": 28188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28560,
      "e": 28189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28622,
      "e": 28251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28760,
      "e": 28389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28760,
      "e": 28389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28775,
      "e": 28404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 28775,
      "e": 28404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28822,
      "e": 28451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ty"
    },
    {
      "t": 28830,
      "e": 28459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29223,
      "e": 28852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29312,
      "e": 28853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis on t"
    },
    {
      "t": 29743,
      "e": 29284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29743,
      "e": 29284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29823,
      "e": 29364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 29927,
      "e": 29468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29928,
      "e": 29469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30014,
      "e": 29555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30488,
      "e": 30029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30543,
      "e": 30084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis on th"
    },
    {
      "t": 30695,
      "e": 30236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30767,
      "e": 30308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis on t"
    },
    {
      "t": 30822,
      "e": 30363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30927,
      "e": 30468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis on "
    },
    {
      "t": 31175,
      "e": 30716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31231,
      "e": 30772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis on"
    },
    {
      "t": 31334,
      "e": 30875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31591,
      "e": 31132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis o"
    },
    {
      "t": 31943,
      "e": 31484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32008,
      "e": 31549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis "
    },
    {
      "t": 32063,
      "e": 31604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 32064,
      "e": 31605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32158,
      "e": 31699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 32190,
      "e": 31731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32190,
      "e": 31731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32311,
      "e": 31852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 32311,
      "e": 31852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32335,
      "e": 31876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||or"
    },
    {
      "t": 32399,
      "e": 31940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32455,
      "e": 31996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 32457,
      "e": 31998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32534,
      "e": 32075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 32615,
      "e": 32156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32615,
      "e": 32156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32719,
      "e": 32260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32807,
      "e": 32348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32808,
      "e": 32349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32903,
      "e": 32444,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 32918,
      "e": 32459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 32919,
      "e": 32460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32974,
      "e": 32515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 33095,
      "e": 32636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33096,
      "e": 32637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33207,
      "e": 32748,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis correspo"
    },
    {
      "t": 33207,
      "e": 32748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33207,
      "e": 32748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33246,
      "e": 32787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 33311,
      "e": 32852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33488,
      "e": 33029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 33488,
      "e": 33029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33566,
      "e": 33107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 33678,
      "e": 33219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33679,
      "e": 33220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33751,
      "e": 33292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 33767,
      "e": 33308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33768,
      "e": 33309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33830,
      "e": 33371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34023,
      "e": 33564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34024,
      "e": 33565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34110,
      "e": 33651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34111,
      "e": 33652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34126,
      "e": 33667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 34222,
      "e": 33763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34311,
      "e": 33852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34312,
      "e": 33853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34375,
      "e": 33916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34487,
      "e": 34028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34487,
      "e": 34028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34559,
      "e": 34100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34639,
      "e": 34180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34640,
      "e": 34181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34719,
      "e": 34260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 34742,
      "e": 34283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34742,
      "e": 34283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34806,
      "e": 34347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34823,
      "e": 34364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34823,
      "e": 34364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34895,
      "e": 34436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35006,
      "e": 34547,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis corresponds to the "
    },
    {
      "t": 35367,
      "e": 34908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 35368,
      "e": 34909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35470,
      "e": 34909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 35502,
      "e": 34941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 35502,
      "e": 34941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35599,
      "e": 35038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 35839,
      "e": 35278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 35840,
      "e": 35279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35919,
      "e": 35358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 36014,
      "e": 35453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 36015,
      "e": 35454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36087,
      "e": 35526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 36207,
      "e": 35646,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis corresponds to the 12pm"
    },
    {
      "t": 36215,
      "e": 35654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36216,
      "e": 35655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36286,
      "e": 35725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36405,
      "e": 35844,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis corresponds to the 12pm "
    },
    {
      "t": 39520,
      "e": 38959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 39521,
      "e": 38960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39615,
      "e": 39054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 39719,
      "e": 39158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39719,
      "e": 39158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39814,
      "e": 39253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39878,
      "e": 39317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39879,
      "e": 39318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39991,
      "e": 39430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 39999,
      "e": 39438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 39999,
      "e": 39438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40088,
      "e": 39527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40088,
      "e": 39527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40095,
      "e": 39534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||xi"
    },
    {
      "t": 40158,
      "e": 39597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40447,
      "e": 39886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40447,
      "e": 39886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40534,
      "e": 39973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 40943,
      "e": 40382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40944,
      "e": 40383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41030,
      "e": 40469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41208,
      "e": 40647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 41209,
      "e": 40648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41210,
      "e": 40649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 41211,
      "e": 40650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41270,
      "e": 40709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||cv"
    },
    {
      "t": 41279,
      "e": 40718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41326,
      "e": 40765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41326,
      "e": 40765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41366,
      "e": 40805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 41591,
      "e": 41030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41647,
      "e": 41086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis corresponds to the 12pm x axis cv"
    },
    {
      "t": 41726,
      "e": 41165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41799,
      "e": 41238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis corresponds to the 12pm x axis c"
    },
    {
      "t": 42063,
      "e": 41502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42118,
      "e": 41557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis corresponds to the 12pm x axis "
    },
    {
      "t": 42159,
      "e": 41598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 42159,
      "e": 41598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42239,
      "e": 41678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42239,
      "e": 41678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42270,
      "e": 41709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||va"
    },
    {
      "t": 42302,
      "e": 41741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 42303,
      "e": 41742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42342,
      "e": 41781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 42511,
      "e": 41950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44423,
      "e": 43862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 44424,
      "e": 43863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44512,
      "e": 43951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 44519,
      "e": 43958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44520,
      "e": 43959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44574,
      "e": 44013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44799,
      "e": 44238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 44800,
      "e": 44239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44918,
      "e": 44357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 45505,
      "e": 44944,
      "ty": 2,
      "x": 687,
      "y": 648
    },
    {
      "t": 45505,
      "e": 44944,
      "ty": 41,
      "x": 396,
      "y": 36211,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 45506,
      "e": 44945,
      "ty": 6,
      "x": 664,
      "y": 599,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45604,
      "e": 45043,
      "ty": 2,
      "x": 565,
      "y": 573
    },
    {
      "t": 45705,
      "e": 45144,
      "ty": 2,
      "x": 490,
      "y": 600
    },
    {
      "t": 45705,
      "e": 45144,
      "ty": 7,
      "x": 490,
      "y": 609,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45754,
      "e": 45193,
      "ty": 41,
      "x": 43042,
      "y": 34900,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 45772,
      "e": 45211,
      "ty": 6,
      "x": 452,
      "y": 664,
      "ta": "#strategyButton"
    },
    {
      "t": 45804,
      "e": 45243,
      "ty": 2,
      "x": 441,
      "y": 672
    },
    {
      "t": 45904,
      "e": 45343,
      "ty": 2,
      "x": 439,
      "y": 673
    },
    {
      "t": 45972,
      "e": 45411,
      "ty": 3,
      "x": 439,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 45974,
      "e": 45412,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at which events are on the y axis corresponds to the 12pm x axis value."
    },
    {
      "t": 45976,
      "e": 45414,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45977,
      "e": 45415,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 46004,
      "e": 45442,
      "ty": 41,
      "x": 54834,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 46050,
      "e": 45488,
      "ty": 4,
      "x": 54834,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 46061,
      "e": 45499,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 46062,
      "e": 45500,
      "ty": 5,
      "x": 439,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 46067,
      "e": 45505,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 46505,
      "e": 45943,
      "ty": 2,
      "x": 489,
      "y": 686
    },
    {
      "t": 46505,
      "e": 45943,
      "ty": 41,
      "x": 16564,
      "y": 37559,
      "ta": "html > body"
    },
    {
      "t": 47067,
      "e": 46505,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 47104,
      "e": 46542,
      "ty": 2,
      "x": 489,
      "y": 687
    },
    {
      "t": 47204,
      "e": 46642,
      "ty": 2,
      "x": 490,
      "y": 690
    },
    {
      "t": 47255,
      "e": 46693,
      "ty": 41,
      "x": 16598,
      "y": 37780,
      "ta": "html > body"
    },
    {
      "t": 47404,
      "e": 46842,
      "ty": 2,
      "x": 489,
      "y": 685
    },
    {
      "t": 47504,
      "e": 46942,
      "ty": 2,
      "x": 515,
      "y": 676
    },
    {
      "t": 47505,
      "e": 46943,
      "ty": 41,
      "x": 17459,
      "y": 37005,
      "ta": "html > body"
    },
    {
      "t": 47604,
      "e": 47042,
      "ty": 2,
      "x": 884,
      "y": 598
    },
    {
      "t": 47691,
      "e": 47129,
      "ty": 6,
      "x": 962,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47704,
      "e": 47142,
      "ty": 2,
      "x": 962,
      "y": 571
    },
    {
      "t": 47754,
      "e": 47192,
      "ty": 41,
      "x": 33740,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47804,
      "e": 47242,
      "ty": 2,
      "x": 964,
      "y": 563
    },
    {
      "t": 47851,
      "e": 47289,
      "ty": 3,
      "x": 964,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47852,
      "e": 47290,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47954,
      "e": 47392,
      "ty": 4,
      "x": 33740,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47954,
      "e": 47392,
      "ty": 5,
      "x": 964,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48807,
      "e": 48245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 48807,
      "e": 48245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48894,
      "e": 48332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "104"
    },
    {
      "t": 48895,
      "e": 48333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48967,
      "e": 48405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 49031,
      "e": 48469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 49583,
      "e": 49021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 49639,
      "e": 49077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 49695,
      "e": 49133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 49758,
      "e": 49196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 50015,
      "e": 49453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 50015,
      "e": 49453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50094,
      "e": 49532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 50198,
      "e": 49636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 50199,
      "e": 49637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50263,
      "e": 49701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 50693,
      "e": 50131,
      "ty": 7,
      "x": 1005,
      "y": 584,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50705,
      "e": 50143,
      "ty": 2,
      "x": 1005,
      "y": 584
    },
    {
      "t": 50755,
      "e": 50193,
      "ty": 41,
      "x": 43473,
      "y": 4228,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 50804,
      "e": 50242,
      "ty": 2,
      "x": 1015,
      "y": 630
    },
    {
      "t": 50827,
      "e": 50265,
      "ty": 6,
      "x": 1018,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50876,
      "e": 50314,
      "ty": 7,
      "x": 1022,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50905,
      "e": 50343,
      "ty": 2,
      "x": 1022,
      "y": 672
    },
    {
      "t": 51005,
      "e": 50443,
      "ty": 2,
      "x": 1022,
      "y": 676
    },
    {
      "t": 51005,
      "e": 50443,
      "ty": 41,
      "x": 34919,
      "y": 37005,
      "ta": "html > body"
    },
    {
      "t": 51104,
      "e": 50542,
      "ty": 2,
      "x": 1022,
      "y": 672
    },
    {
      "t": 51111,
      "e": 50549,
      "ty": 6,
      "x": 1024,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51162,
      "e": 50600,
      "ty": 3,
      "x": 1024,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51162,
      "e": 50600,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 51162,
      "e": 50600,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51162,
      "e": 50600,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51205,
      "e": 50643,
      "ty": 2,
      "x": 1024,
      "y": 667
    },
    {
      "t": 51255,
      "e": 50693,
      "ty": 41,
      "x": 46718,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51258,
      "e": 50696,
      "ty": 4,
      "x": 46718,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51258,
      "e": 50696,
      "ty": 5,
      "x": 1024,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51543,
      "e": 50981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 51782,
      "e": 51220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 51783,
      "e": 51221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51863,
      "e": 51301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 51878,
      "e": 51316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 52015,
      "e": 51453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 52016,
      "e": 51454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52126,
      "e": 51564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 52126,
      "e": 51564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52150,
      "e": 51588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 52239,
      "e": 51677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 52239,
      "e": 51677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52271,
      "e": 51709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 52327,
      "e": 51765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 52335,
      "e": 51773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 52335,
      "e": 51773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52431,
      "e": 51869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 53060,
      "e": 52498,
      "ty": 7,
      "x": 1024,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53078,
      "e": 52516,
      "ty": 6,
      "x": 1022,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53104,
      "e": 52542,
      "ty": 2,
      "x": 1020,
      "y": 692
    },
    {
      "t": 53205,
      "e": 52643,
      "ty": 2,
      "x": 1017,
      "y": 703
    },
    {
      "t": 53255,
      "e": 52693,
      "ty": 41,
      "x": 61371,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53305,
      "e": 52743,
      "ty": 2,
      "x": 1015,
      "y": 690
    },
    {
      "t": 53332,
      "e": 52770,
      "ty": 3,
      "x": 1015,
      "y": 690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53333,
      "e": 52771,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 53333,
      "e": 52771,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53334,
      "e": 52772,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53403,
      "e": 52841,
      "ty": 4,
      "x": 61371,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53405,
      "e": 52843,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53405,
      "e": 52843,
      "ty": 5,
      "x": 1015,
      "y": 690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53406,
      "e": 52844,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 53505,
      "e": 52943,
      "ty": 41,
      "x": 34678,
      "y": 37780,
      "ta": "html > body"
    },
    {
      "t": 54005,
      "e": 53443,
      "ty": 2,
      "x": 998,
      "y": 666
    },
    {
      "t": 54005,
      "e": 53443,
      "ty": 41,
      "x": 34093,
      "y": 36451,
      "ta": "html > body"
    },
    {
      "t": 54424,
      "e": 53862,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 54505,
      "e": 53943,
      "ty": 2,
      "x": 986,
      "y": 636
    },
    {
      "t": 54505,
      "e": 53943,
      "ty": 41,
      "x": 39058,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 54605,
      "e": 54043,
      "ty": 2,
      "x": 928,
      "y": 548
    },
    {
      "t": 54705,
      "e": 54143,
      "ty": 2,
      "x": 919,
      "y": 545
    },
    {
      "t": 54755,
      "e": 54193,
      "ty": 41,
      "x": 23157,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 54904,
      "e": 54342,
      "ty": 2,
      "x": 940,
      "y": 478
    },
    {
      "t": 55004,
      "e": 54442,
      "ty": 2,
      "x": 945,
      "y": 462
    },
    {
      "t": 55004,
      "e": 54442,
      "ty": 41,
      "x": 29328,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 55205,
      "e": 54442,
      "ty": 2,
      "x": 954,
      "y": 439
    },
    {
      "t": 55255,
      "e": 54492,
      "ty": 41,
      "x": 18885,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 55305,
      "e": 54542,
      "ty": 2,
      "x": 866,
      "y": 308
    },
    {
      "t": 55405,
      "e": 54642,
      "ty": 2,
      "x": 858,
      "y": 297
    },
    {
      "t": 55505,
      "e": 54742,
      "ty": 2,
      "x": 856,
      "y": 293
    },
    {
      "t": 55505,
      "e": 54742,
      "ty": 41,
      "x": 10836,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 55605,
      "e": 54842,
      "ty": 2,
      "x": 854,
      "y": 260
    },
    {
      "t": 55705,
      "e": 54942,
      "ty": 2,
      "x": 855,
      "y": 255
    },
    {
      "t": 55755,
      "e": 54992,
      "ty": 41,
      "x": 28314,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 55805,
      "e": 55042,
      "ty": 2,
      "x": 856,
      "y": 242
    },
    {
      "t": 56004,
      "e": 55241,
      "ty": 2,
      "x": 854,
      "y": 241
    },
    {
      "t": 56004,
      "e": 55241,
      "ty": 41,
      "x": 26677,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 56105,
      "e": 55342,
      "ty": 2,
      "x": 851,
      "y": 241
    },
    {
      "t": 56205,
      "e": 55442,
      "ty": 2,
      "x": 851,
      "y": 261
    },
    {
      "t": 56254,
      "e": 55491,
      "ty": 41,
      "x": 9269,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 56305,
      "e": 55542,
      "ty": 2,
      "x": 851,
      "y": 299
    },
    {
      "t": 56405,
      "e": 55642,
      "ty": 2,
      "x": 847,
      "y": 313
    },
    {
      "t": 56504,
      "e": 55741,
      "ty": 2,
      "x": 846,
      "y": 306
    },
    {
      "t": 56505,
      "e": 55742,
      "ty": 41,
      "x": 5832,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 56605,
      "e": 55842,
      "ty": 2,
      "x": 845,
      "y": 293
    },
    {
      "t": 56755,
      "e": 55992,
      "ty": 41,
      "x": 6135,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 56765,
      "e": 56002,
      "ty": 6,
      "x": 839,
      "y": 292,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 56805,
      "e": 56042,
      "ty": 2,
      "x": 838,
      "y": 292
    },
    {
      "t": 56876,
      "e": 56113,
      "ty": 3,
      "x": 838,
      "y": 292,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 56877,
      "e": 56114,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 56946,
      "e": 56183,
      "ty": 4,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 56947,
      "e": 56184,
      "ty": 5,
      "x": 838,
      "y": 292,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 56949,
      "e": 56186,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 57005,
      "e": 56242,
      "ty": 41,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 57282,
      "e": 56519,
      "ty": 7,
      "x": 845,
      "y": 305,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 57305,
      "e": 56542,
      "ty": 2,
      "x": 866,
      "y": 340
    },
    {
      "t": 57404,
      "e": 56641,
      "ty": 2,
      "x": 906,
      "y": 497
    },
    {
      "t": 57505,
      "e": 56742,
      "ty": 2,
      "x": 878,
      "y": 496
    },
    {
      "t": 57505,
      "e": 56742,
      "ty": 41,
      "x": 50781,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 57605,
      "e": 56842,
      "ty": 2,
      "x": 875,
      "y": 487
    },
    {
      "t": 57755,
      "e": 56992,
      "ty": 41,
      "x": 12715,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 57905,
      "e": 57142,
      "ty": 2,
      "x": 873,
      "y": 486
    },
    {
      "t": 58005,
      "e": 57242,
      "ty": 2,
      "x": 872,
      "y": 486
    },
    {
      "t": 58006,
      "e": 57243,
      "ty": 41,
      "x": 12003,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 58105,
      "e": 57342,
      "ty": 2,
      "x": 854,
      "y": 451
    },
    {
      "t": 58204,
      "e": 57441,
      "ty": 2,
      "x": 855,
      "y": 430
    },
    {
      "t": 58255,
      "e": 57492,
      "ty": 41,
      "x": 7968,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 58405,
      "e": 57642,
      "ty": 2,
      "x": 848,
      "y": 436
    },
    {
      "t": 58505,
      "e": 57742,
      "ty": 2,
      "x": 846,
      "y": 427
    },
    {
      "t": 58506,
      "e": 57743,
      "ty": 41,
      "x": 5832,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 58605,
      "e": 57842,
      "ty": 2,
      "x": 853,
      "y": 413
    },
    {
      "t": 58705,
      "e": 57942,
      "ty": 2,
      "x": 902,
      "y": 406
    },
    {
      "t": 58754,
      "e": 57991,
      "ty": 41,
      "x": 27429,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 58805,
      "e": 58042,
      "ty": 2,
      "x": 942,
      "y": 408
    },
    {
      "t": 58905,
      "e": 58142,
      "ty": 2,
      "x": 875,
      "y": 423
    },
    {
      "t": 59005,
      "e": 58242,
      "ty": 2,
      "x": 869,
      "y": 423
    },
    {
      "t": 59006,
      "e": 58243,
      "ty": 41,
      "x": 55694,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 59105,
      "e": 58342,
      "ty": 2,
      "x": 862,
      "y": 435
    },
    {
      "t": 59205,
      "e": 58442,
      "ty": 2,
      "x": 859,
      "y": 442
    },
    {
      "t": 59258,
      "e": 58444,
      "ty": 41,
      "x": 25223,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 59305,
      "e": 58491,
      "ty": 2,
      "x": 850,
      "y": 451
    },
    {
      "t": 59401,
      "e": 58587,
      "ty": 6,
      "x": 829,
      "y": 447,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 59404,
      "e": 58590,
      "ty": 2,
      "x": 829,
      "y": 447
    },
    {
      "t": 59433,
      "e": 58619,
      "ty": 7,
      "x": 824,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 59505,
      "e": 58691,
      "ty": 2,
      "x": 824,
      "y": 434
    },
    {
      "t": 59505,
      "e": 58691,
      "ty": 41,
      "x": 2059,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 59605,
      "e": 58791,
      "ty": 2,
      "x": 860,
      "y": 421
    },
    {
      "t": 59704,
      "e": 58890,
      "ty": 2,
      "x": 867,
      "y": 432
    },
    {
      "t": 59755,
      "e": 58941,
      "ty": 41,
      "x": 36405,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 59805,
      "e": 58991,
      "ty": 2,
      "x": 858,
      "y": 437
    },
    {
      "t": 59905,
      "e": 59091,
      "ty": 2,
      "x": 829,
      "y": 428
    },
    {
      "t": 60005,
      "e": 59191,
      "ty": 2,
      "x": 852,
      "y": 420
    },
    {
      "t": 60006,
      "e": 59192,
      "ty": 41,
      "x": 35794,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 60105,
      "e": 59291,
      "ty": 2,
      "x": 863,
      "y": 435
    },
    {
      "t": 60205,
      "e": 59391,
      "ty": 2,
      "x": 847,
      "y": 444
    },
    {
      "t": 60255,
      "e": 59441,
      "ty": 41,
      "x": 15638,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 60305,
      "e": 59491,
      "ty": 2,
      "x": 840,
      "y": 444
    },
    {
      "t": 60307,
      "e": 59493,
      "ty": 6,
      "x": 839,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60405,
      "e": 59591,
      "ty": 2,
      "x": 838,
      "y": 444
    },
    {
      "t": 60505,
      "e": 59691,
      "ty": 2,
      "x": 836,
      "y": 441
    },
    {
      "t": 60506,
      "e": 59692,
      "ty": 41,
      "x": 48284,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60605,
      "e": 59791,
      "ty": 2,
      "x": 834,
      "y": 443
    },
    {
      "t": 60755,
      "e": 59941,
      "ty": 41,
      "x": 38202,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60804,
      "e": 59990,
      "ty": 3,
      "x": 834,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60806,
      "e": 59992,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 60806,
      "e": 59992,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60875,
      "e": 60061,
      "ty": 4,
      "x": 38202,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60875,
      "e": 60061,
      "ty": 5,
      "x": 834,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60876,
      "e": 60062,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 61002,
      "e": 60188,
      "ty": 7,
      "x": 850,
      "y": 451,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 61005,
      "e": 60191,
      "ty": 2,
      "x": 850,
      "y": 451
    },
    {
      "t": 61005,
      "e": 60191,
      "ty": 41,
      "x": 22826,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 61106,
      "e": 60292,
      "ty": 2,
      "x": 916,
      "y": 575
    },
    {
      "t": 61205,
      "e": 60391,
      "ty": 2,
      "x": 914,
      "y": 730
    },
    {
      "t": 61255,
      "e": 60441,
      "ty": 41,
      "x": 18969,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 61306,
      "e": 60492,
      "ty": 2,
      "x": 879,
      "y": 738
    },
    {
      "t": 61405,
      "e": 60591,
      "ty": 2,
      "x": 863,
      "y": 731
    },
    {
      "t": 61505,
      "e": 60691,
      "ty": 41,
      "x": 10435,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 61705,
      "e": 60891,
      "ty": 2,
      "x": 863,
      "y": 730
    },
    {
      "t": 61755,
      "e": 60941,
      "ty": 41,
      "x": 10435,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 61806,
      "e": 60992,
      "ty": 2,
      "x": 863,
      "y": 727
    },
    {
      "t": 61905,
      "e": 61091,
      "ty": 2,
      "x": 861,
      "y": 722
    },
    {
      "t": 62004,
      "e": 61190,
      "ty": 2,
      "x": 862,
      "y": 710
    },
    {
      "t": 62004,
      "e": 61190,
      "ty": 41,
      "x": 10224,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 62104,
      "e": 61290,
      "ty": 2,
      "x": 890,
      "y": 708
    },
    {
      "t": 62204,
      "e": 61390,
      "ty": 2,
      "x": 922,
      "y": 715
    },
    {
      "t": 62255,
      "e": 61441,
      "ty": 41,
      "x": 25243,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 62304,
      "e": 61490,
      "ty": 2,
      "x": 920,
      "y": 748
    },
    {
      "t": 62405,
      "e": 61591,
      "ty": 2,
      "x": 904,
      "y": 772
    },
    {
      "t": 62504,
      "e": 61690,
      "ty": 2,
      "x": 886,
      "y": 783
    },
    {
      "t": 62505,
      "e": 61691,
      "ty": 41,
      "x": 36152,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 62604,
      "e": 61790,
      "ty": 2,
      "x": 846,
      "y": 792
    },
    {
      "t": 62705,
      "e": 61891,
      "ty": 2,
      "x": 836,
      "y": 803
    },
    {
      "t": 62720,
      "e": 61906,
      "ty": 6,
      "x": 836,
      "y": 808,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 62754,
      "e": 61940,
      "ty": 41,
      "x": 43243,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 62769,
      "e": 61955,
      "ty": 7,
      "x": 835,
      "y": 823,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 62804,
      "e": 61990,
      "ty": 2,
      "x": 833,
      "y": 831
    },
    {
      "t": 62869,
      "e": 62055,
      "ty": 6,
      "x": 832,
      "y": 836,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 62904,
      "e": 62090,
      "ty": 2,
      "x": 832,
      "y": 839
    },
    {
      "t": 63004,
      "e": 62190,
      "ty": 2,
      "x": 832,
      "y": 842
    },
    {
      "t": 63005,
      "e": 62191,
      "ty": 41,
      "x": 28120,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 63171,
      "e": 62357,
      "ty": 7,
      "x": 832,
      "y": 816,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 63172,
      "e": 62358,
      "ty": 6,
      "x": 832,
      "y": 816,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 63188,
      "e": 62374,
      "ty": 7,
      "x": 832,
      "y": 789,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 63188,
      "e": 62374,
      "ty": 6,
      "x": 832,
      "y": 789,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 63203,
      "e": 62389,
      "ty": 7,
      "x": 832,
      "y": 765,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 63204,
      "e": 62390,
      "ty": 2,
      "x": 832,
      "y": 765
    },
    {
      "t": 63237,
      "e": 62423,
      "ty": 6,
      "x": 835,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 63253,
      "e": 62439,
      "ty": 7,
      "x": 836,
      "y": 719,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 63254,
      "e": 62440,
      "ty": 41,
      "x": 3459,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 63269,
      "e": 62455,
      "ty": 6,
      "x": 836,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63286,
      "e": 62472,
      "ty": 7,
      "x": 836,
      "y": 695,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63304,
      "e": 62490,
      "ty": 2,
      "x": 836,
      "y": 691
    },
    {
      "t": 63336,
      "e": 62522,
      "ty": 6,
      "x": 838,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 63386,
      "e": 62572,
      "ty": 7,
      "x": 839,
      "y": 666,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 63404,
      "e": 62590,
      "ty": 2,
      "x": 839,
      "y": 664
    },
    {
      "t": 63505,
      "e": 62691,
      "ty": 2,
      "x": 840,
      "y": 664
    },
    {
      "t": 63505,
      "e": 62691,
      "ty": 41,
      "x": 4409,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 63605,
      "e": 62791,
      "ty": 2,
      "x": 858,
      "y": 669
    },
    {
      "t": 63707,
      "e": 62893,
      "ty": 2,
      "x": 860,
      "y": 676
    },
    {
      "t": 63758,
      "e": 62944,
      "ty": 41,
      "x": 9155,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 63808,
      "e": 62994,
      "ty": 2,
      "x": 855,
      "y": 691
    },
    {
      "t": 63907,
      "e": 63093,
      "ty": 2,
      "x": 834,
      "y": 692
    },
    {
      "t": 64007,
      "e": 63193,
      "ty": 2,
      "x": 831,
      "y": 694
    },
    {
      "t": 64008,
      "e": 63194,
      "ty": 41,
      "x": 2413,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 64024,
      "e": 63210,
      "ty": 6,
      "x": 830,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64108,
      "e": 63294,
      "ty": 2,
      "x": 828,
      "y": 703
    },
    {
      "t": 64258,
      "e": 63444,
      "ty": 41,
      "x": 7955,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64307,
      "e": 63493,
      "ty": 2,
      "x": 830,
      "y": 704
    },
    {
      "t": 64508,
      "e": 63694,
      "ty": 41,
      "x": 18037,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64639,
      "e": 63825,
      "ty": 3,
      "x": 830,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64640,
      "e": 63826,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 64641,
      "e": 63827,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64709,
      "e": 63895,
      "ty": 4,
      "x": 18037,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64709,
      "e": 63895,
      "ty": 5,
      "x": 830,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64710,
      "e": 63896,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 64807,
      "e": 63993,
      "ty": 2,
      "x": 836,
      "y": 704
    },
    {
      "t": 64807,
      "e": 63993,
      "ty": 7,
      "x": 843,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64908,
      "e": 64094,
      "ty": 2,
      "x": 975,
      "y": 724
    },
    {
      "t": 65008,
      "e": 64194,
      "ty": 2,
      "x": 951,
      "y": 824
    },
    {
      "t": 65008,
      "e": 64194,
      "ty": 41,
      "x": 30752,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 65107,
      "e": 64293,
      "ty": 2,
      "x": 859,
      "y": 852
    },
    {
      "t": 65208,
      "e": 64394,
      "ty": 2,
      "x": 854,
      "y": 856
    },
    {
      "t": 65258,
      "e": 64444,
      "ty": 41,
      "x": 7731,
      "y": 52158,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 65307,
      "e": 64493,
      "ty": 2,
      "x": 854,
      "y": 871
    },
    {
      "t": 65408,
      "e": 64594,
      "ty": 2,
      "x": 842,
      "y": 930
    },
    {
      "t": 65409,
      "e": 64595,
      "ty": 6,
      "x": 838,
      "y": 933,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 65442,
      "e": 64628,
      "ty": 7,
      "x": 820,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 65507,
      "e": 64693,
      "ty": 2,
      "x": 813,
      "y": 929
    },
    {
      "t": 65508,
      "e": 64694,
      "ty": 41,
      "x": 27722,
      "y": 51020,
      "ta": "html > body"
    },
    {
      "t": 65807,
      "e": 64993,
      "ty": 2,
      "x": 812,
      "y": 929
    },
    {
      "t": 65907,
      "e": 65093,
      "ty": 2,
      "x": 811,
      "y": 930
    },
    {
      "t": 66007,
      "e": 65193,
      "ty": 2,
      "x": 824,
      "y": 934
    },
    {
      "t": 66008,
      "e": 65194,
      "ty": 41,
      "x": 2815,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 66068,
      "e": 65194,
      "ty": 6,
      "x": 827,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66107,
      "e": 65233,
      "ty": 2,
      "x": 831,
      "y": 935
    },
    {
      "t": 66108,
      "e": 65234,
      "ty": 7,
      "x": 840,
      "y": 937,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66207,
      "e": 65333,
      "ty": 2,
      "x": 848,
      "y": 940
    },
    {
      "t": 66257,
      "e": 65383,
      "ty": 41,
      "x": 29029,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 66408,
      "e": 65534,
      "ty": 2,
      "x": 847,
      "y": 939
    },
    {
      "t": 66507,
      "e": 65633,
      "ty": 2,
      "x": 840,
      "y": 939
    },
    {
      "t": 66508,
      "e": 65634,
      "ty": 41,
      "x": 20291,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 66822,
      "e": 65948,
      "ty": 6,
      "x": 839,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66908,
      "e": 66034,
      "ty": 2,
      "x": 838,
      "y": 939
    },
    {
      "t": 66918,
      "e": 66044,
      "ty": 3,
      "x": 838,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66920,
      "e": 66046,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66920,
      "e": 66046,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67008,
      "e": 66134,
      "ty": 41,
      "x": 58367,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67021,
      "e": 66147,
      "ty": 4,
      "x": 58367,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67021,
      "e": 66147,
      "ty": 5,
      "x": 838,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67022,
      "e": 66148,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 67303,
      "e": 66429,
      "ty": 7,
      "x": 840,
      "y": 944,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67308,
      "e": 66434,
      "ty": 2,
      "x": 840,
      "y": 944
    },
    {
      "t": 67407,
      "e": 66533,
      "ty": 2,
      "x": 894,
      "y": 984
    },
    {
      "t": 67507,
      "e": 66633,
      "ty": 2,
      "x": 897,
      "y": 1001
    },
    {
      "t": 67507,
      "e": 66633,
      "ty": 41,
      "x": 17936,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 67509,
      "e": 66635,
      "ty": 6,
      "x": 897,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67608,
      "e": 66734,
      "ty": 2,
      "x": 897,
      "y": 1019
    },
    {
      "t": 67707,
      "e": 66833,
      "ty": 2,
      "x": 893,
      "y": 1024
    },
    {
      "t": 67757,
      "e": 66883,
      "ty": 41,
      "x": 32767,
      "y": 37732,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67799,
      "e": 66925,
      "ty": 3,
      "x": 893,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67799,
      "e": 66925,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67800,
      "e": 66926,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67869,
      "e": 66995,
      "ty": 4,
      "x": 32767,
      "y": 37732,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67870,
      "e": 66996,
      "ty": 5,
      "x": 893,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67874,
      "e": 67000,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67875,
      "e": 67001,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 67876,
      "e": 67002,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 68258,
      "e": 67384,
      "ty": 41,
      "x": 30339,
      "y": 55009,
      "ta": "html > body"
    },
    {
      "t": 68307,
      "e": 67433,
      "ty": 2,
      "x": 880,
      "y": 663
    },
    {
      "t": 68407,
      "e": 67533,
      "ty": 2,
      "x": 874,
      "y": 279
    },
    {
      "t": 68507,
      "e": 67633,
      "ty": 2,
      "x": 876,
      "y": 278
    },
    {
      "t": 68508,
      "e": 67634,
      "ty": 41,
      "x": 29891,
      "y": 14957,
      "ta": "html > body"
    },
    {
      "t": 68608,
      "e": 67734,
      "ty": 2,
      "x": 884,
      "y": 281
    },
    {
      "t": 68707,
      "e": 67833,
      "ty": 2,
      "x": 937,
      "y": 289
    },
    {
      "t": 68757,
      "e": 67883,
      "ty": 41,
      "x": 31992,
      "y": 15566,
      "ta": "html > body"
    },
    {
      "t": 69222,
      "e": 68348,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 69707,
      "e": 68833,
      "ty": 2,
      "x": 945,
      "y": 323
    },
    {
      "t": 69758,
      "e": 68884,
      "ty": 41,
      "x": 36727,
      "y": 27897,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 69807,
      "e": 68933,
      "ty": 2,
      "x": 1096,
      "y": 773
    },
    {
      "t": 69908,
      "e": 69034,
      "ty": 2,
      "x": 1042,
      "y": 941
    },
    {
      "t": 70008,
      "e": 69134,
      "ty": 2,
      "x": 1004,
      "y": 1018
    },
    {
      "t": 70008,
      "e": 69134,
      "ty": 41,
      "x": 34956,
      "y": 61748,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70107,
      "e": 69233,
      "ty": 2,
      "x": 996,
      "y": 1058
    },
    {
      "t": 70181,
      "e": 69307,
      "ty": 6,
      "x": 986,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 70207,
      "e": 69333,
      "ty": 2,
      "x": 985,
      "y": 1077
    },
    {
      "t": 70258,
      "e": 69384,
      "ty": 41,
      "x": 40686,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 70308,
      "e": 69434,
      "ty": 2,
      "x": 984,
      "y": 1079
    },
    {
      "t": 70407,
      "e": 69533,
      "ty": 2,
      "x": 982,
      "y": 1084
    },
    {
      "t": 70508,
      "e": 69634,
      "ty": 41,
      "x": 39594,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 70703,
      "e": 69829,
      "ty": 3,
      "x": 982,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 70704,
      "e": 69830,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 70854,
      "e": 69980,
      "ty": 4,
      "x": 39594,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 70854,
      "e": 69980,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 70854,
      "e": 69980,
      "ty": 5,
      "x": 982,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 70855,
      "e": 69981,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 71885,
      "e": 71011,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 73208,
      "e": 72334,
      "ty": 2,
      "x": 807,
      "y": 731
    },
    {
      "t": 73255,
      "e": 72381,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 104204, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 104209, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 5669, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 111218, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 8483, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"NOVEMBER\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 120709, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 20083, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 141881, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 11257, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 154142, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 26356, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 181880, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-10 AM-A -A -A -A -A -11 AM-12 PM-11 AM-3-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1543,y:680,t:1527271735637};\\\", \\\"{x:1488,y:662,t:1527271735983};\\\", \\\"{x:1475,y:661,t:1527271735996};\\\", \\\"{x:1427,y:653,t:1527271736012};\\\", \\\"{x:1362,y:641,t:1527271736029};\\\", \\\"{x:1282,y:630,t:1527271736045};\\\", \\\"{x:1196,y:619,t:1527271736062};\\\", \\\"{x:1061,y:602,t:1527271736079};\\\", \\\"{x:979,y:593,t:1527271736096};\\\", \\\"{x:914,y:589,t:1527271736113};\\\", \\\"{x:861,y:589,t:1527271736130};\\\", \\\"{x:821,y:589,t:1527271736146};\\\", \\\"{x:787,y:589,t:1527271736163};\\\", \\\"{x:757,y:589,t:1527271736180};\\\", \\\"{x:720,y:589,t:1527271736197};\\\", \\\"{x:676,y:589,t:1527271736213};\\\", \\\"{x:627,y:586,t:1527271736230};\\\", \\\"{x:574,y:586,t:1527271736246};\\\", \\\"{x:534,y:585,t:1527271736262};\\\", \\\"{x:488,y:579,t:1527271736279};\\\", \\\"{x:471,y:577,t:1527271736296};\\\", \\\"{x:460,y:574,t:1527271736313};\\\", \\\"{x:454,y:573,t:1527271736329};\\\", \\\"{x:450,y:571,t:1527271736346};\\\", \\\"{x:447,y:566,t:1527271736363};\\\", \\\"{x:444,y:562,t:1527271736379};\\\", \\\"{x:444,y:561,t:1527271736752};\\\", \\\"{x:445,y:561,t:1527271736765};\\\", \\\"{x:448,y:560,t:1527271736781};\\\", \\\"{x:457,y:556,t:1527271736797};\\\", \\\"{x:463,y:551,t:1527271736815};\\\", \\\"{x:477,y:539,t:1527271736833};\\\", \\\"{x:488,y:532,t:1527271736847};\\\", \\\"{x:502,y:525,t:1527271736863};\\\", \\\"{x:514,y:518,t:1527271736879};\\\", \\\"{x:526,y:512,t:1527271736896};\\\", \\\"{x:538,y:505,t:1527271736914};\\\", \\\"{x:552,y:498,t:1527271736929};\\\", \\\"{x:567,y:489,t:1527271736947};\\\", \\\"{x:578,y:482,t:1527271736963};\\\", \\\"{x:587,y:477,t:1527271736979};\\\", \\\"{x:592,y:474,t:1527271736997};\\\", \\\"{x:594,y:473,t:1527271737014};\\\", \\\"{x:598,y:471,t:1527271737030};\\\", \\\"{x:602,y:469,t:1527271737047};\\\", \\\"{x:609,y:465,t:1527271737063};\\\", \\\"{x:612,y:464,t:1527271737080};\\\", \\\"{x:614,y:463,t:1527271737097};\\\", \\\"{x:615,y:463,t:1527271737114};\\\", \\\"{x:616,y:462,t:1527271737130};\\\", \\\"{x:617,y:462,t:1527271737352};\\\", \\\"{x:618,y:461,t:1527271737365};\\\", \\\"{x:620,y:460,t:1527271737380};\\\", \\\"{x:623,y:459,t:1527271737398};\\\", \\\"{x:625,y:456,t:1527271737414};\\\", \\\"{x:628,y:455,t:1527271737431};\\\", \\\"{x:630,y:454,t:1527271737447};\\\", \\\"{x:632,y:453,t:1527271737465};\\\", \\\"{x:633,y:452,t:1527271737482};\\\", \\\"{x:635,y:451,t:1527271737497};\\\", \\\"{x:661,y:466,t:1527271741088};\\\", \\\"{x:727,y:506,t:1527271741103};\\\", \\\"{x:869,y:586,t:1527271741119};\\\", \\\"{x:1120,y:727,t:1527271741151};\\\", \\\"{x:1266,y:794,t:1527271741167};\\\", \\\"{x:1345,y:826,t:1527271741184};\\\", \\\"{x:1396,y:852,t:1527271741200};\\\", \\\"{x:1434,y:880,t:1527271741217};\\\", \\\"{x:1448,y:903,t:1527271741234};\\\", \\\"{x:1458,y:930,t:1527271741250};\\\", \\\"{x:1462,y:954,t:1527271741267};\\\", \\\"{x:1462,y:973,t:1527271741284};\\\", \\\"{x:1462,y:985,t:1527271741301};\\\", \\\"{x:1462,y:994,t:1527271741317};\\\", \\\"{x:1462,y:1000,t:1527271741334};\\\", \\\"{x:1459,y:1008,t:1527271741352};\\\", \\\"{x:1449,y:1013,t:1527271741368};\\\", \\\"{x:1427,y:1013,t:1527271741384};\\\", \\\"{x:1399,y:1013,t:1527271741401};\\\", \\\"{x:1361,y:1013,t:1527271741417};\\\", \\\"{x:1324,y:1013,t:1527271741434};\\\", \\\"{x:1293,y:1013,t:1527271741451};\\\", \\\"{x:1267,y:1011,t:1527271741468};\\\", \\\"{x:1247,y:1001,t:1527271741485};\\\", \\\"{x:1229,y:989,t:1527271741502};\\\", \\\"{x:1220,y:979,t:1527271741518};\\\", \\\"{x:1218,y:973,t:1527271741534};\\\", \\\"{x:1217,y:972,t:1527271741552};\\\", \\\"{x:1217,y:971,t:1527271741568};\\\", \\\"{x:1218,y:971,t:1527271741608};\\\", \\\"{x:1220,y:971,t:1527271741632};\\\", \\\"{x:1223,y:970,t:1527271741648};\\\", \\\"{x:1223,y:969,t:1527271741656};\\\", \\\"{x:1224,y:969,t:1527271741667};\\\", \\\"{x:1227,y:969,t:1527271741685};\\\", \\\"{x:1233,y:969,t:1527271741702};\\\", \\\"{x:1238,y:969,t:1527271741718};\\\", \\\"{x:1242,y:969,t:1527271741735};\\\", \\\"{x:1243,y:969,t:1527271741752};\\\", \\\"{x:1245,y:969,t:1527271741944};\\\", \\\"{x:1246,y:965,t:1527271741952};\\\", \\\"{x:1248,y:956,t:1527271741968};\\\", \\\"{x:1251,y:945,t:1527271741985};\\\", \\\"{x:1253,y:940,t:1527271742002};\\\", \\\"{x:1254,y:938,t:1527271742019};\\\", \\\"{x:1255,y:934,t:1527271742035};\\\", \\\"{x:1257,y:931,t:1527271742051};\\\", \\\"{x:1258,y:925,t:1527271742068};\\\", \\\"{x:1260,y:917,t:1527271742085};\\\", \\\"{x:1261,y:909,t:1527271742101};\\\", \\\"{x:1262,y:902,t:1527271742119};\\\", \\\"{x:1263,y:896,t:1527271742135};\\\", \\\"{x:1263,y:885,t:1527271742154};\\\", \\\"{x:1263,y:878,t:1527271742168};\\\", \\\"{x:1263,y:870,t:1527271742185};\\\", \\\"{x:1263,y:865,t:1527271742201};\\\", \\\"{x:1264,y:862,t:1527271742218};\\\", \\\"{x:1265,y:860,t:1527271742235};\\\", \\\"{x:1267,y:856,t:1527271742252};\\\", \\\"{x:1268,y:854,t:1527271742268};\\\", \\\"{x:1269,y:851,t:1527271742286};\\\", \\\"{x:1272,y:847,t:1527271742301};\\\", \\\"{x:1272,y:844,t:1527271742318};\\\", \\\"{x:1273,y:842,t:1527271742336};\\\", \\\"{x:1274,y:839,t:1527271742352};\\\", \\\"{x:1274,y:840,t:1527271742504};\\\", \\\"{x:1274,y:847,t:1527271742519};\\\", \\\"{x:1274,y:869,t:1527271742536};\\\", \\\"{x:1274,y:880,t:1527271742552};\\\", \\\"{x:1274,y:886,t:1527271742569};\\\", \\\"{x:1274,y:889,t:1527271742585};\\\", \\\"{x:1274,y:890,t:1527271742602};\\\", \\\"{x:1274,y:894,t:1527271742618};\\\", \\\"{x:1274,y:899,t:1527271742635};\\\", \\\"{x:1274,y:902,t:1527271742652};\\\", \\\"{x:1271,y:907,t:1527271742669};\\\", \\\"{x:1270,y:907,t:1527271742685};\\\", \\\"{x:1269,y:907,t:1527271742702};\\\", \\\"{x:1268,y:907,t:1527271742718};\\\", \\\"{x:1268,y:908,t:1527271744561};\\\", \\\"{x:1268,y:910,t:1527271744571};\\\", \\\"{x:1270,y:916,t:1527271744587};\\\", \\\"{x:1273,y:923,t:1527271744604};\\\", \\\"{x:1273,y:930,t:1527271744621};\\\", \\\"{x:1271,y:940,t:1527271744637};\\\", \\\"{x:1269,y:946,t:1527271744654};\\\", \\\"{x:1269,y:947,t:1527271744696};\\\", \\\"{x:1269,y:950,t:1527271744708};\\\", \\\"{x:1268,y:954,t:1527271744720};\\\", \\\"{x:1265,y:958,t:1527271744736};\\\", \\\"{x:1265,y:959,t:1527271744753};\\\", \\\"{x:1265,y:960,t:1527271744799};\\\", \\\"{x:1264,y:960,t:1527271744976};\\\", \\\"{x:1263,y:960,t:1527271744992};\\\", \\\"{x:1263,y:961,t:1527271745033};\\\", \\\"{x:1263,y:958,t:1527271745319};\\\", \\\"{x:1263,y:954,t:1527271745327};\\\", \\\"{x:1263,y:946,t:1527271745337};\\\", \\\"{x:1272,y:928,t:1527271745354};\\\", \\\"{x:1278,y:906,t:1527271745370};\\\", \\\"{x:1285,y:874,t:1527271745388};\\\", \\\"{x:1290,y:844,t:1527271745404};\\\", \\\"{x:1292,y:823,t:1527271745420};\\\", \\\"{x:1294,y:814,t:1527271745437};\\\", \\\"{x:1295,y:808,t:1527271745454};\\\", \\\"{x:1296,y:803,t:1527271745471};\\\", \\\"{x:1296,y:798,t:1527271745487};\\\", \\\"{x:1296,y:797,t:1527271745511};\\\", \\\"{x:1296,y:796,t:1527271745520};\\\", \\\"{x:1296,y:795,t:1527271745543};\\\", \\\"{x:1296,y:794,t:1527271745555};\\\", \\\"{x:1296,y:804,t:1527271745625};\\\", \\\"{x:1296,y:819,t:1527271745638};\\\", \\\"{x:1296,y:848,t:1527271745655};\\\", \\\"{x:1296,y:866,t:1527271745671};\\\", \\\"{x:1299,y:872,t:1527271745688};\\\", \\\"{x:1299,y:871,t:1527271745792};\\\", \\\"{x:1299,y:870,t:1527271745805};\\\", \\\"{x:1298,y:867,t:1527271745822};\\\", \\\"{x:1296,y:863,t:1527271745837};\\\", \\\"{x:1295,y:861,t:1527271745855};\\\", \\\"{x:1294,y:860,t:1527271745872};\\\", \\\"{x:1292,y:858,t:1527271745888};\\\", \\\"{x:1292,y:857,t:1527271745905};\\\", \\\"{x:1292,y:856,t:1527271745922};\\\", \\\"{x:1291,y:854,t:1527271745938};\\\", \\\"{x:1290,y:854,t:1527271745960};\\\", \\\"{x:1289,y:853,t:1527271746112};\\\", \\\"{x:1289,y:848,t:1527271746122};\\\", \\\"{x:1288,y:840,t:1527271746138};\\\", \\\"{x:1285,y:829,t:1527271746158};\\\", \\\"{x:1283,y:819,t:1527271746172};\\\", \\\"{x:1280,y:809,t:1527271746188};\\\", \\\"{x:1279,y:804,t:1527271746204};\\\", \\\"{x:1279,y:798,t:1527271746221};\\\", \\\"{x:1278,y:791,t:1527271746238};\\\", \\\"{x:1276,y:782,t:1527271746255};\\\", \\\"{x:1275,y:774,t:1527271746271};\\\", \\\"{x:1275,y:771,t:1527271746288};\\\", \\\"{x:1275,y:769,t:1527271746311};\\\", \\\"{x:1275,y:768,t:1527271746321};\\\", \\\"{x:1275,y:766,t:1527271746338};\\\", \\\"{x:1275,y:762,t:1527271746354};\\\", \\\"{x:1275,y:759,t:1527271746371};\\\", \\\"{x:1275,y:755,t:1527271746389};\\\", \\\"{x:1275,y:753,t:1527271746404};\\\", \\\"{x:1275,y:755,t:1527271746496};\\\", \\\"{x:1275,y:758,t:1527271746505};\\\", \\\"{x:1275,y:765,t:1527271746522};\\\", \\\"{x:1275,y:772,t:1527271746538};\\\", \\\"{x:1275,y:777,t:1527271746555};\\\", \\\"{x:1275,y:778,t:1527271746571};\\\", \\\"{x:1275,y:780,t:1527271746589};\\\", \\\"{x:1275,y:783,t:1527271746604};\\\", \\\"{x:1276,y:789,t:1527271746622};\\\", \\\"{x:1279,y:799,t:1527271746639};\\\", \\\"{x:1279,y:805,t:1527271746656};\\\", \\\"{x:1281,y:820,t:1527271746672};\\\", \\\"{x:1280,y:830,t:1527271746690};\\\", \\\"{x:1272,y:838,t:1527271746707};\\\", \\\"{x:1251,y:843,t:1527271746722};\\\", \\\"{x:1187,y:843,t:1527271746739};\\\", \\\"{x:1079,y:815,t:1527271746756};\\\", \\\"{x:919,y:771,t:1527271746772};\\\", \\\"{x:742,y:719,t:1527271746788};\\\", \\\"{x:565,y:669,t:1527271746805};\\\", \\\"{x:405,y:620,t:1527271746823};\\\", \\\"{x:289,y:587,t:1527271746839};\\\", \\\"{x:191,y:559,t:1527271746856};\\\", \\\"{x:172,y:553,t:1527271746869};\\\", \\\"{x:156,y:549,t:1527271746886};\\\", \\\"{x:148,y:546,t:1527271746905};\\\", \\\"{x:147,y:545,t:1527271746921};\\\", \\\"{x:147,y:544,t:1527271746938};\\\", \\\"{x:147,y:541,t:1527271746956};\\\", \\\"{x:144,y:537,t:1527271746972};\\\", \\\"{x:139,y:532,t:1527271746989};\\\", \\\"{x:132,y:527,t:1527271747005};\\\", \\\"{x:131,y:527,t:1527271747021};\\\", \\\"{x:137,y:522,t:1527271747038};\\\", \\\"{x:175,y:519,t:1527271747055};\\\", \\\"{x:219,y:519,t:1527271747073};\\\", \\\"{x:283,y:519,t:1527271747089};\\\", \\\"{x:339,y:519,t:1527271747106};\\\", \\\"{x:384,y:519,t:1527271747123};\\\", \\\"{x:413,y:519,t:1527271747139};\\\", \\\"{x:419,y:519,t:1527271747155};\\\", \\\"{x:420,y:519,t:1527271747172};\\\", \\\"{x:420,y:518,t:1527271747224};\\\", \\\"{x:415,y:516,t:1527271747240};\\\", \\\"{x:409,y:515,t:1527271747255};\\\", \\\"{x:399,y:514,t:1527271747273};\\\", \\\"{x:391,y:513,t:1527271747288};\\\", \\\"{x:390,y:512,t:1527271747647};\\\", \\\"{x:393,y:512,t:1527271747663};\\\", \\\"{x:398,y:512,t:1527271747672};\\\", \\\"{x:419,y:514,t:1527271747689};\\\", \\\"{x:452,y:519,t:1527271747705};\\\", \\\"{x:494,y:521,t:1527271747722};\\\", \\\"{x:566,y:530,t:1527271747740};\\\", \\\"{x:641,y:538,t:1527271747756};\\\", \\\"{x:719,y:549,t:1527271747773};\\\", \\\"{x:808,y:561,t:1527271747791};\\\", \\\"{x:900,y:576,t:1527271747805};\\\", \\\"{x:1003,y:594,t:1527271747823};\\\", \\\"{x:1122,y:614,t:1527271747839};\\\", \\\"{x:1198,y:627,t:1527271747856};\\\", \\\"{x:1262,y:646,t:1527271747872};\\\", \\\"{x:1315,y:660,t:1527271747889};\\\", \\\"{x:1359,y:680,t:1527271747906};\\\", \\\"{x:1396,y:704,t:1527271747922};\\\", \\\"{x:1431,y:734,t:1527271747940};\\\", \\\"{x:1462,y:774,t:1527271747957};\\\", \\\"{x:1488,y:823,t:1527271747972};\\\", \\\"{x:1503,y:856,t:1527271747989};\\\", \\\"{x:1509,y:872,t:1527271748007};\\\", \\\"{x:1511,y:874,t:1527271748022};\\\", \\\"{x:1511,y:876,t:1527271748039};\\\", \\\"{x:1509,y:880,t:1527271748056};\\\", \\\"{x:1498,y:884,t:1527271748073};\\\", \\\"{x:1486,y:890,t:1527271748090};\\\", \\\"{x:1472,y:896,t:1527271748106};\\\", \\\"{x:1458,y:902,t:1527271748122};\\\", \\\"{x:1445,y:907,t:1527271748140};\\\", \\\"{x:1432,y:912,t:1527271748156};\\\", \\\"{x:1423,y:912,t:1527271748173};\\\", \\\"{x:1419,y:914,t:1527271748190};\\\", \\\"{x:1416,y:915,t:1527271748207};\\\", \\\"{x:1415,y:915,t:1527271748223};\\\", \\\"{x:1412,y:917,t:1527271748240};\\\", \\\"{x:1410,y:919,t:1527271748257};\\\", \\\"{x:1401,y:926,t:1527271748273};\\\", \\\"{x:1383,y:933,t:1527271748290};\\\", \\\"{x:1362,y:939,t:1527271748307};\\\", \\\"{x:1338,y:942,t:1527271748324};\\\", \\\"{x:1316,y:948,t:1527271748340};\\\", \\\"{x:1299,y:949,t:1527271748356};\\\", \\\"{x:1288,y:950,t:1527271748374};\\\", \\\"{x:1285,y:950,t:1527271748390};\\\", \\\"{x:1284,y:950,t:1527271748407};\\\", \\\"{x:1283,y:944,t:1527271748424};\\\", \\\"{x:1282,y:935,t:1527271748439};\\\", \\\"{x:1277,y:925,t:1527271748457};\\\", \\\"{x:1275,y:920,t:1527271748474};\\\", \\\"{x:1274,y:918,t:1527271748490};\\\", \\\"{x:1273,y:916,t:1527271748507};\\\", \\\"{x:1273,y:914,t:1527271748524};\\\", \\\"{x:1272,y:909,t:1527271748540};\\\", \\\"{x:1271,y:900,t:1527271748557};\\\", \\\"{x:1270,y:893,t:1527271748574};\\\", \\\"{x:1270,y:887,t:1527271748591};\\\", \\\"{x:1270,y:883,t:1527271748608};\\\", \\\"{x:1269,y:882,t:1527271748624};\\\", \\\"{x:1269,y:881,t:1527271749088};\\\", \\\"{x:1269,y:876,t:1527271749095};\\\", \\\"{x:1269,y:875,t:1527271749108};\\\", \\\"{x:1268,y:875,t:1527271749520};\\\", \\\"{x:1268,y:874,t:1527271749528};\\\", \\\"{x:1268,y:873,t:1527271749592};\\\", \\\"{x:1269,y:867,t:1527271749608};\\\", \\\"{x:1272,y:862,t:1527271749625};\\\", \\\"{x:1273,y:859,t:1527271749641};\\\", \\\"{x:1273,y:858,t:1527271749659};\\\", \\\"{x:1273,y:856,t:1527271749675};\\\", \\\"{x:1273,y:855,t:1527271749691};\\\", \\\"{x:1273,y:853,t:1527271749720};\\\", \\\"{x:1273,y:852,t:1527271749736};\\\", \\\"{x:1273,y:850,t:1527271749744};\\\", \\\"{x:1273,y:849,t:1527271749758};\\\", \\\"{x:1273,y:845,t:1527271749775};\\\", \\\"{x:1273,y:839,t:1527271749792};\\\", \\\"{x:1274,y:837,t:1527271749808};\\\", \\\"{x:1275,y:836,t:1527271749825};\\\", \\\"{x:1277,y:835,t:1527271749842};\\\", \\\"{x:1278,y:834,t:1527271749859};\\\", \\\"{x:1279,y:833,t:1527271749875};\\\", \\\"{x:1279,y:836,t:1527271749985};\\\", \\\"{x:1279,y:840,t:1527271749992};\\\", \\\"{x:1279,y:848,t:1527271750008};\\\", \\\"{x:1279,y:854,t:1527271750025};\\\", \\\"{x:1279,y:861,t:1527271750042};\\\", \\\"{x:1279,y:864,t:1527271750059};\\\", \\\"{x:1279,y:868,t:1527271750075};\\\", \\\"{x:1281,y:871,t:1527271750093};\\\", \\\"{x:1282,y:877,t:1527271750108};\\\", \\\"{x:1282,y:882,t:1527271750125};\\\", \\\"{x:1283,y:885,t:1527271750142};\\\", \\\"{x:1285,y:890,t:1527271750158};\\\", \\\"{x:1286,y:895,t:1527271750175};\\\", \\\"{x:1288,y:901,t:1527271750192};\\\", \\\"{x:1289,y:906,t:1527271750209};\\\", \\\"{x:1290,y:912,t:1527271750225};\\\", \\\"{x:1291,y:918,t:1527271750242};\\\", \\\"{x:1293,y:926,t:1527271750259};\\\", \\\"{x:1293,y:935,t:1527271750275};\\\", \\\"{x:1293,y:944,t:1527271750292};\\\", \\\"{x:1293,y:950,t:1527271750310};\\\", \\\"{x:1293,y:952,t:1527271750325};\\\", \\\"{x:1293,y:954,t:1527271750343};\\\", \\\"{x:1293,y:958,t:1527271750359};\\\", \\\"{x:1293,y:960,t:1527271750375};\\\", \\\"{x:1293,y:963,t:1527271750392};\\\", \\\"{x:1293,y:965,t:1527271750409};\\\", \\\"{x:1293,y:967,t:1527271750425};\\\", \\\"{x:1293,y:969,t:1527271750443};\\\", \\\"{x:1293,y:970,t:1527271750459};\\\", \\\"{x:1293,y:972,t:1527271750475};\\\", \\\"{x:1293,y:973,t:1527271750492};\\\", \\\"{x:1293,y:969,t:1527271750761};\\\", \\\"{x:1295,y:962,t:1527271750776};\\\", \\\"{x:1295,y:961,t:1527271750792};\\\", \\\"{x:1296,y:961,t:1527271751145};\\\", \\\"{x:1298,y:961,t:1527271751159};\\\", \\\"{x:1311,y:961,t:1527271751176};\\\", \\\"{x:1328,y:961,t:1527271751192};\\\", \\\"{x:1348,y:961,t:1527271751209};\\\", \\\"{x:1371,y:961,t:1527271751226};\\\", \\\"{x:1384,y:961,t:1527271751243};\\\", \\\"{x:1398,y:961,t:1527271751259};\\\", \\\"{x:1411,y:961,t:1527271751276};\\\", \\\"{x:1417,y:961,t:1527271751292};\\\", \\\"{x:1421,y:961,t:1527271751309};\\\", \\\"{x:1416,y:961,t:1527271751425};\\\", \\\"{x:1411,y:960,t:1527271751432};\\\", \\\"{x:1407,y:960,t:1527271751443};\\\", \\\"{x:1402,y:958,t:1527271751460};\\\", \\\"{x:1401,y:958,t:1527271751477};\\\", \\\"{x:1400,y:958,t:1527271751496};\\\", \\\"{x:1399,y:958,t:1527271751510};\\\", \\\"{x:1392,y:959,t:1527271751527};\\\", \\\"{x:1373,y:968,t:1527271751544};\\\", \\\"{x:1328,y:976,t:1527271751560};\\\", \\\"{x:1293,y:982,t:1527271751576};\\\", \\\"{x:1268,y:986,t:1527271751593};\\\", \\\"{x:1267,y:986,t:1527271751610};\\\", \\\"{x:1265,y:986,t:1527271751816};\\\", \\\"{x:1257,y:981,t:1527271751826};\\\", \\\"{x:1224,y:950,t:1527271751843};\\\", \\\"{x:1168,y:884,t:1527271751860};\\\", \\\"{x:1108,y:800,t:1527271751876};\\\", \\\"{x:1034,y:707,t:1527271751894};\\\", \\\"{x:976,y:643,t:1527271751911};\\\", \\\"{x:956,y:618,t:1527271751927};\\\", \\\"{x:953,y:616,t:1527271751943};\\\", \\\"{x:958,y:616,t:1527271752080};\\\", \\\"{x:972,y:629,t:1527271752093};\\\", \\\"{x:1013,y:647,t:1527271752110};\\\", \\\"{x:1034,y:649,t:1527271752128};\\\", \\\"{x:1040,y:648,t:1527271752143};\\\", \\\"{x:1049,y:636,t:1527271752160};\\\", \\\"{x:1062,y:613,t:1527271752177};\\\", \\\"{x:1068,y:597,t:1527271752193};\\\", \\\"{x:1069,y:597,t:1527271752210};\\\", \\\"{x:1069,y:598,t:1527271752664};\\\", \\\"{x:1069,y:599,t:1527271752678};\\\", \\\"{x:1069,y:600,t:1527271752694};\\\", \\\"{x:1069,y:601,t:1527271752711};\\\", \\\"{x:1069,y:603,t:1527271752776};\\\", \\\"{x:1064,y:612,t:1527271752794};\\\", \\\"{x:1055,y:642,t:1527271752811};\\\", \\\"{x:1054,y:682,t:1527271752828};\\\", \\\"{x:1054,y:719,t:1527271752844};\\\", \\\"{x:1055,y:742,t:1527271752861};\\\", \\\"{x:1057,y:754,t:1527271752877};\\\", \\\"{x:1061,y:767,t:1527271752895};\\\", \\\"{x:1065,y:780,t:1527271752912};\\\", \\\"{x:1068,y:784,t:1527271752927};\\\", \\\"{x:1069,y:786,t:1527271752944};\\\", \\\"{x:1069,y:787,t:1527271753744};\\\", \\\"{x:1075,y:787,t:1527271753762};\\\", \\\"{x:1086,y:787,t:1527271753778};\\\", \\\"{x:1103,y:783,t:1527271753795};\\\", \\\"{x:1123,y:781,t:1527271753811};\\\", \\\"{x:1150,y:777,t:1527271753829};\\\", \\\"{x:1196,y:777,t:1527271753846};\\\", \\\"{x:1288,y:777,t:1527271753862};\\\", \\\"{x:1387,y:789,t:1527271753878};\\\", \\\"{x:1539,y:811,t:1527271753895};\\\", \\\"{x:1603,y:819,t:1527271753912};\\\", \\\"{x:1646,y:826,t:1527271753927};\\\", \\\"{x:1667,y:836,t:1527271753945};\\\", \\\"{x:1674,y:844,t:1527271753962};\\\", \\\"{x:1674,y:851,t:1527271753978};\\\", \\\"{x:1671,y:862,t:1527271753995};\\\", \\\"{x:1658,y:871,t:1527271754012};\\\", \\\"{x:1639,y:881,t:1527271754028};\\\", \\\"{x:1622,y:886,t:1527271754045};\\\", \\\"{x:1600,y:888,t:1527271754062};\\\", \\\"{x:1577,y:891,t:1527271754078};\\\", \\\"{x:1555,y:891,t:1527271754095};\\\", \\\"{x:1525,y:894,t:1527271754112};\\\", \\\"{x:1510,y:894,t:1527271754128};\\\", \\\"{x:1497,y:894,t:1527271754145};\\\", \\\"{x:1485,y:894,t:1527271754163};\\\", \\\"{x:1472,y:894,t:1527271754178};\\\", \\\"{x:1459,y:894,t:1527271754196};\\\", \\\"{x:1441,y:894,t:1527271754212};\\\", \\\"{x:1422,y:896,t:1527271754228};\\\", \\\"{x:1410,y:897,t:1527271754245};\\\", \\\"{x:1404,y:899,t:1527271754262};\\\", \\\"{x:1400,y:900,t:1527271754278};\\\", \\\"{x:1400,y:898,t:1527271754337};\\\", \\\"{x:1400,y:896,t:1527271754346};\\\", \\\"{x:1400,y:897,t:1527271754945};\\\", \\\"{x:1400,y:899,t:1527271754952};\\\", \\\"{x:1400,y:902,t:1527271754962};\\\", \\\"{x:1397,y:913,t:1527271754979};\\\", \\\"{x:1392,y:929,t:1527271754996};\\\", \\\"{x:1385,y:946,t:1527271755012};\\\", \\\"{x:1374,y:968,t:1527271755029};\\\", \\\"{x:1362,y:988,t:1527271755046};\\\", \\\"{x:1352,y:1005,t:1527271755062};\\\", \\\"{x:1348,y:1017,t:1527271755079};\\\", \\\"{x:1344,y:1036,t:1527271755096};\\\", \\\"{x:1343,y:1047,t:1527271755112};\\\", \\\"{x:1342,y:1057,t:1527271755129};\\\", \\\"{x:1339,y:1070,t:1527271755147};\\\", \\\"{x:1339,y:1075,t:1527271755163};\\\", \\\"{x:1339,y:1078,t:1527271755179};\\\", \\\"{x:1339,y:1079,t:1527271755196};\\\", \\\"{x:1346,y:1082,t:1527271755472};\\\", \\\"{x:1352,y:1082,t:1527271755480};\\\", \\\"{x:1363,y:1082,t:1527271755496};\\\", \\\"{x:1373,y:1081,t:1527271755513};\\\", \\\"{x:1382,y:1079,t:1527271755529};\\\", \\\"{x:1386,y:1077,t:1527271755546};\\\", \\\"{x:1387,y:1077,t:1527271755563};\\\", \\\"{x:1388,y:1076,t:1527271755579};\\\", \\\"{x:1388,y:1074,t:1527271755600};\\\", \\\"{x:1386,y:1073,t:1527271755614};\\\", \\\"{x:1377,y:1072,t:1527271755630};\\\", \\\"{x:1364,y:1066,t:1527271755646};\\\", \\\"{x:1346,y:1061,t:1527271755664};\\\", \\\"{x:1332,y:1056,t:1527271755680};\\\", \\\"{x:1318,y:1053,t:1527271755696};\\\", \\\"{x:1302,y:1052,t:1527271755714};\\\", \\\"{x:1288,y:1048,t:1527271755730};\\\", \\\"{x:1279,y:1045,t:1527271755746};\\\", \\\"{x:1271,y:1039,t:1527271755764};\\\", \\\"{x:1268,y:1034,t:1527271755780};\\\", \\\"{x:1268,y:1019,t:1527271755796};\\\", \\\"{x:1268,y:987,t:1527271755813};\\\", \\\"{x:1268,y:948,t:1527271755831};\\\", \\\"{x:1271,y:924,t:1527271755847};\\\", \\\"{x:1277,y:908,t:1527271755864};\\\", \\\"{x:1280,y:900,t:1527271755880};\\\", \\\"{x:1285,y:892,t:1527271755897};\\\", \\\"{x:1290,y:882,t:1527271755914};\\\", \\\"{x:1295,y:874,t:1527271755930};\\\", \\\"{x:1298,y:870,t:1527271755947};\\\", \\\"{x:1299,y:867,t:1527271755964};\\\", \\\"{x:1299,y:865,t:1527271755981};\\\", \\\"{x:1301,y:862,t:1527271755997};\\\", \\\"{x:1301,y:858,t:1527271756013};\\\", \\\"{x:1301,y:852,t:1527271756030};\\\", \\\"{x:1301,y:849,t:1527271756048};\\\", \\\"{x:1300,y:849,t:1527271756063};\\\", \\\"{x:1300,y:848,t:1527271756096};\\\", \\\"{x:1299,y:847,t:1527271756112};\\\", \\\"{x:1299,y:846,t:1527271756120};\\\", \\\"{x:1299,y:845,t:1527271756136};\\\", \\\"{x:1298,y:844,t:1527271756152};\\\", \\\"{x:1298,y:843,t:1527271756256};\\\", \\\"{x:1297,y:843,t:1527271756263};\\\", \\\"{x:1296,y:841,t:1527271756280};\\\", \\\"{x:1292,y:841,t:1527271756297};\\\", \\\"{x:1291,y:840,t:1527271756313};\\\", \\\"{x:1289,y:839,t:1527271756330};\\\", \\\"{x:1286,y:837,t:1527271756347};\\\", \\\"{x:1282,y:836,t:1527271756362};\\\", \\\"{x:1279,y:835,t:1527271756380};\\\", \\\"{x:1278,y:834,t:1527271756396};\\\", \\\"{x:1290,y:834,t:1527271760427};\\\", \\\"{x:1343,y:834,t:1527271760442};\\\", \\\"{x:1432,y:834,t:1527271760459};\\\", \\\"{x:1543,y:834,t:1527271760477};\\\", \\\"{x:1649,y:851,t:1527271760494};\\\", \\\"{x:1723,y:860,t:1527271760510};\\\", \\\"{x:1771,y:868,t:1527271760527};\\\", \\\"{x:1785,y:871,t:1527271760543};\\\", \\\"{x:1786,y:871,t:1527271760584};\\\", \\\"{x:1779,y:872,t:1527271760593};\\\", \\\"{x:1719,y:874,t:1527271760609};\\\", \\\"{x:1628,y:874,t:1527271760626};\\\", \\\"{x:1525,y:874,t:1527271760643};\\\", \\\"{x:1421,y:853,t:1527271760659};\\\", \\\"{x:1300,y:821,t:1527271760676};\\\", \\\"{x:1180,y:796,t:1527271760693};\\\", \\\"{x:1049,y:773,t:1527271760709};\\\", \\\"{x:910,y:752,t:1527271760726};\\\", \\\"{x:777,y:733,t:1527271760743};\\\", \\\"{x:661,y:717,t:1527271760759};\\\", \\\"{x:513,y:697,t:1527271760776};\\\", \\\"{x:447,y:694,t:1527271760793};\\\", \\\"{x:414,y:694,t:1527271760810};\\\", \\\"{x:400,y:694,t:1527271760826};\\\", \\\"{x:399,y:695,t:1527271760969};\\\", \\\"{x:405,y:703,t:1527271760976};\\\", \\\"{x:424,y:716,t:1527271760993};\\\", \\\"{x:448,y:726,t:1527271761012};\\\", \\\"{x:470,y:728,t:1527271761026};\\\", \\\"{x:489,y:730,t:1527271761043};\\\", \\\"{x:500,y:730,t:1527271761059};\\\", \\\"{x:507,y:730,t:1527271761076};\\\", \\\"{x:508,y:729,t:1527271761092};\\\", \\\"{x:509,y:726,t:1527271761160};\\\", \\\"{x:509,y:723,t:1527271761176};\\\", \\\"{x:511,y:718,t:1527271761192};\\\", \\\"{x:511,y:717,t:1527271761209};\\\" ] }, { \\\"rt\\\": 10092, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 193227, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -K -D -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:716,t:1527271764544};\\\", \\\"{x:526,y:716,t:1527271764552};\\\", \\\"{x:546,y:718,t:1527271764562};\\\", \\\"{x:604,y:726,t:1527271764579};\\\", \\\"{x:701,y:738,t:1527271764596};\\\", \\\"{x:809,y:754,t:1527271764612};\\\", \\\"{x:921,y:772,t:1527271764629};\\\", \\\"{x:1020,y:783,t:1527271764645};\\\", \\\"{x:1101,y:794,t:1527271764662};\\\", \\\"{x:1160,y:805,t:1527271764679};\\\", \\\"{x:1204,y:810,t:1527271764695};\\\", \\\"{x:1239,y:820,t:1527271764712};\\\", \\\"{x:1247,y:821,t:1527271764729};\\\", \\\"{x:1249,y:822,t:1527271764759};\\\", \\\"{x:1246,y:822,t:1527271764896};\\\", \\\"{x:1218,y:822,t:1527271764912};\\\", \\\"{x:1175,y:822,t:1527271764929};\\\", \\\"{x:1119,y:817,t:1527271764946};\\\", \\\"{x:1039,y:806,t:1527271764962};\\\", \\\"{x:955,y:781,t:1527271764979};\\\", \\\"{x:869,y:756,t:1527271764996};\\\", \\\"{x:792,y:722,t:1527271765012};\\\", \\\"{x:723,y:691,t:1527271765029};\\\", \\\"{x:657,y:665,t:1527271765046};\\\", \\\"{x:597,y:642,t:1527271765062};\\\", \\\"{x:570,y:632,t:1527271765079};\\\", \\\"{x:545,y:621,t:1527271765096};\\\", \\\"{x:543,y:621,t:1527271765112};\\\", \\\"{x:542,y:619,t:1527271765129};\\\", \\\"{x:540,y:612,t:1527271765146};\\\", \\\"{x:539,y:600,t:1527271765162};\\\", \\\"{x:534,y:592,t:1527271765179};\\\", \\\"{x:531,y:591,t:1527271765552};\\\", \\\"{x:530,y:590,t:1527271765563};\\\", \\\"{x:525,y:589,t:1527271765579};\\\", \\\"{x:520,y:586,t:1527271765596};\\\", \\\"{x:516,y:582,t:1527271765613};\\\", \\\"{x:511,y:581,t:1527271765629};\\\", \\\"{x:507,y:577,t:1527271765646};\\\", \\\"{x:501,y:573,t:1527271765664};\\\", \\\"{x:499,y:570,t:1527271765679};\\\", \\\"{x:495,y:564,t:1527271765697};\\\", \\\"{x:492,y:560,t:1527271765713};\\\", \\\"{x:490,y:555,t:1527271765729};\\\", \\\"{x:488,y:551,t:1527271765746};\\\", \\\"{x:485,y:548,t:1527271765763};\\\", \\\"{x:482,y:543,t:1527271765781};\\\", \\\"{x:478,y:539,t:1527271765797};\\\", \\\"{x:473,y:533,t:1527271765814};\\\", \\\"{x:469,y:529,t:1527271765830};\\\", \\\"{x:464,y:524,t:1527271765847};\\\", \\\"{x:461,y:521,t:1527271765863};\\\", \\\"{x:459,y:518,t:1527271765881};\\\", \\\"{x:459,y:517,t:1527271765897};\\\", \\\"{x:459,y:516,t:1527271765913};\\\", \\\"{x:458,y:514,t:1527271765931};\\\", \\\"{x:457,y:514,t:1527271765947};\\\", \\\"{x:456,y:511,t:1527271765963};\\\", \\\"{x:455,y:511,t:1527271765980};\\\", \\\"{x:455,y:509,t:1527271765997};\\\", \\\"{x:455,y:508,t:1527271766013};\\\", \\\"{x:455,y:507,t:1527271766031};\\\", \\\"{x:458,y:504,t:1527271766049};\\\", \\\"{x:466,y:500,t:1527271766063};\\\", \\\"{x:489,y:494,t:1527271766079};\\\", \\\"{x:512,y:490,t:1527271766097};\\\", \\\"{x:538,y:488,t:1527271766113};\\\", \\\"{x:578,y:486,t:1527271766130};\\\", \\\"{x:648,y:486,t:1527271766147};\\\", \\\"{x:734,y:486,t:1527271766163};\\\", \\\"{x:825,y:486,t:1527271766180};\\\", \\\"{x:922,y:486,t:1527271766198};\\\", \\\"{x:1030,y:486,t:1527271766214};\\\", \\\"{x:1145,y:491,t:1527271766231};\\\", \\\"{x:1243,y:506,t:1527271766247};\\\", \\\"{x:1328,y:516,t:1527271766263};\\\", \\\"{x:1428,y:531,t:1527271766280};\\\", \\\"{x:1477,y:544,t:1527271766297};\\\", \\\"{x:1524,y:564,t:1527271766314};\\\", \\\"{x:1557,y:579,t:1527271766330};\\\", \\\"{x:1586,y:590,t:1527271766348};\\\", \\\"{x:1606,y:600,t:1527271766365};\\\", \\\"{x:1617,y:607,t:1527271766381};\\\", \\\"{x:1625,y:616,t:1527271766398};\\\", \\\"{x:1628,y:625,t:1527271766414};\\\", \\\"{x:1629,y:633,t:1527271766431};\\\", \\\"{x:1629,y:642,t:1527271766448};\\\", \\\"{x:1623,y:660,t:1527271766464};\\\", \\\"{x:1613,y:676,t:1527271766481};\\\", \\\"{x:1601,y:696,t:1527271766498};\\\", \\\"{x:1586,y:715,t:1527271766515};\\\", \\\"{x:1573,y:731,t:1527271766530};\\\", \\\"{x:1558,y:744,t:1527271766547};\\\", \\\"{x:1547,y:752,t:1527271766565};\\\", \\\"{x:1532,y:759,t:1527271766580};\\\", \\\"{x:1512,y:765,t:1527271766598};\\\", \\\"{x:1497,y:768,t:1527271766615};\\\", \\\"{x:1479,y:773,t:1527271766631};\\\", \\\"{x:1458,y:778,t:1527271766648};\\\", \\\"{x:1429,y:789,t:1527271766665};\\\", \\\"{x:1412,y:794,t:1527271766681};\\\", \\\"{x:1397,y:798,t:1527271766698};\\\", \\\"{x:1387,y:800,t:1527271766715};\\\", \\\"{x:1378,y:803,t:1527271766732};\\\", \\\"{x:1370,y:804,t:1527271766748};\\\", \\\"{x:1362,y:806,t:1527271766765};\\\", \\\"{x:1358,y:807,t:1527271766781};\\\", \\\"{x:1356,y:808,t:1527271766797};\\\", \\\"{x:1353,y:810,t:1527271766815};\\\", \\\"{x:1352,y:811,t:1527271766832};\\\", \\\"{x:1352,y:814,t:1527271766857};\\\", \\\"{x:1357,y:815,t:1527271766864};\\\", \\\"{x:1376,y:819,t:1527271766881};\\\", \\\"{x:1402,y:821,t:1527271766898};\\\", \\\"{x:1436,y:821,t:1527271766915};\\\", \\\"{x:1478,y:821,t:1527271766932};\\\", \\\"{x:1522,y:818,t:1527271766949};\\\", \\\"{x:1570,y:810,t:1527271766965};\\\", \\\"{x:1617,y:806,t:1527271766982};\\\", \\\"{x:1651,y:799,t:1527271766998};\\\", \\\"{x:1671,y:794,t:1527271767015};\\\", \\\"{x:1680,y:790,t:1527271767032};\\\", \\\"{x:1688,y:784,t:1527271767048};\\\", \\\"{x:1690,y:779,t:1527271767064};\\\", \\\"{x:1693,y:771,t:1527271767082};\\\", \\\"{x:1696,y:765,t:1527271767099};\\\", \\\"{x:1697,y:760,t:1527271767115};\\\", \\\"{x:1698,y:757,t:1527271767132};\\\", \\\"{x:1701,y:754,t:1527271767149};\\\", \\\"{x:1702,y:752,t:1527271767165};\\\", \\\"{x:1703,y:750,t:1527271767182};\\\", \\\"{x:1703,y:749,t:1527271767199};\\\", \\\"{x:1703,y:747,t:1527271767233};\\\", \\\"{x:1702,y:745,t:1527271767249};\\\", \\\"{x:1699,y:744,t:1527271767265};\\\", \\\"{x:1696,y:742,t:1527271767282};\\\", \\\"{x:1693,y:741,t:1527271767299};\\\", \\\"{x:1687,y:740,t:1527271767315};\\\", \\\"{x:1680,y:737,t:1527271767331};\\\", \\\"{x:1667,y:732,t:1527271767349};\\\", \\\"{x:1652,y:726,t:1527271767365};\\\", \\\"{x:1635,y:716,t:1527271767382};\\\", \\\"{x:1613,y:703,t:1527271767399};\\\", \\\"{x:1588,y:687,t:1527271767415};\\\", \\\"{x:1569,y:676,t:1527271767432};\\\", \\\"{x:1544,y:659,t:1527271767449};\\\", \\\"{x:1530,y:649,t:1527271767465};\\\", \\\"{x:1520,y:640,t:1527271767482};\\\", \\\"{x:1515,y:634,t:1527271767501};\\\", \\\"{x:1509,y:624,t:1527271767516};\\\", \\\"{x:1501,y:616,t:1527271767531};\\\", \\\"{x:1495,y:608,t:1527271767548};\\\", \\\"{x:1489,y:601,t:1527271767566};\\\", \\\"{x:1485,y:594,t:1527271767581};\\\", \\\"{x:1481,y:589,t:1527271767598};\\\", \\\"{x:1476,y:582,t:1527271767615};\\\", \\\"{x:1471,y:578,t:1527271767631};\\\", \\\"{x:1468,y:573,t:1527271767648};\\\", \\\"{x:1464,y:565,t:1527271767665};\\\", \\\"{x:1461,y:561,t:1527271767682};\\\", \\\"{x:1458,y:554,t:1527271767698};\\\", \\\"{x:1456,y:547,t:1527271767716};\\\", \\\"{x:1453,y:536,t:1527271767732};\\\", \\\"{x:1452,y:528,t:1527271767748};\\\", \\\"{x:1452,y:522,t:1527271767765};\\\", \\\"{x:1453,y:514,t:1527271767781};\\\", \\\"{x:1454,y:505,t:1527271767799};\\\", \\\"{x:1458,y:496,t:1527271767816};\\\", \\\"{x:1467,y:480,t:1527271767833};\\\", \\\"{x:1476,y:468,t:1527271767849};\\\", \\\"{x:1493,y:456,t:1527271767865};\\\", \\\"{x:1512,y:444,t:1527271767882};\\\", \\\"{x:1535,y:437,t:1527271767899};\\\", \\\"{x:1560,y:432,t:1527271767916};\\\", \\\"{x:1576,y:429,t:1527271767932};\\\", \\\"{x:1588,y:429,t:1527271767949};\\\", \\\"{x:1593,y:428,t:1527271767966};\\\", \\\"{x:1595,y:428,t:1527271767982};\\\", \\\"{x:1598,y:428,t:1527271768185};\\\", \\\"{x:1602,y:428,t:1527271768200};\\\", \\\"{x:1615,y:428,t:1527271768216};\\\", \\\"{x:1622,y:428,t:1527271768234};\\\", \\\"{x:1623,y:428,t:1527271768250};\\\", \\\"{x:1624,y:428,t:1527271768266};\\\", \\\"{x:1625,y:428,t:1527271768283};\\\", \\\"{x:1626,y:428,t:1527271768353};\\\", \\\"{x:1626,y:432,t:1527271768365};\\\", \\\"{x:1628,y:449,t:1527271768382};\\\", \\\"{x:1628,y:464,t:1527271768399};\\\", \\\"{x:1628,y:477,t:1527271768415};\\\", \\\"{x:1628,y:484,t:1527271768432};\\\", \\\"{x:1628,y:487,t:1527271768450};\\\", \\\"{x:1628,y:488,t:1527271768471};\\\", \\\"{x:1628,y:489,t:1527271768488};\\\", \\\"{x:1628,y:491,t:1527271768500};\\\", \\\"{x:1628,y:494,t:1527271768517};\\\", \\\"{x:1627,y:497,t:1527271768532};\\\", \\\"{x:1627,y:501,t:1527271768549};\\\", \\\"{x:1627,y:502,t:1527271768567};\\\", \\\"{x:1627,y:506,t:1527271768582};\\\", \\\"{x:1626,y:512,t:1527271768599};\\\", \\\"{x:1625,y:520,t:1527271768616};\\\", \\\"{x:1625,y:523,t:1527271768633};\\\", \\\"{x:1625,y:528,t:1527271768649};\\\", \\\"{x:1624,y:529,t:1527271768667};\\\", \\\"{x:1624,y:531,t:1527271768682};\\\", \\\"{x:1624,y:533,t:1527271768699};\\\", \\\"{x:1624,y:534,t:1527271768717};\\\", \\\"{x:1624,y:537,t:1527271768733};\\\", \\\"{x:1624,y:539,t:1527271768752};\\\", \\\"{x:1624,y:540,t:1527271768767};\\\", \\\"{x:1624,y:542,t:1527271768783};\\\", \\\"{x:1624,y:543,t:1527271768800};\\\", \\\"{x:1624,y:544,t:1527271768817};\\\", \\\"{x:1624,y:545,t:1527271768849};\\\", \\\"{x:1624,y:547,t:1527271768874};\\\", \\\"{x:1624,y:548,t:1527271768884};\\\", \\\"{x:1623,y:549,t:1527271768900};\\\", \\\"{x:1623,y:550,t:1527271768917};\\\", \\\"{x:1623,y:552,t:1527271769097};\\\", \\\"{x:1623,y:553,t:1527271769105};\\\", \\\"{x:1623,y:554,t:1527271769120};\\\", \\\"{x:1623,y:555,t:1527271769330};\\\", \\\"{x:1623,y:556,t:1527271769336};\\\", \\\"{x:1622,y:557,t:1527271769352};\\\", \\\"{x:1622,y:558,t:1527271769367};\\\", \\\"{x:1621,y:559,t:1527271769457};\\\", \\\"{x:1621,y:560,t:1527271769488};\\\", \\\"{x:1620,y:561,t:1527271769505};\\\", \\\"{x:1620,y:562,t:1527271769545};\\\", \\\"{x:1620,y:563,t:1527271769567};\\\", \\\"{x:1620,y:565,t:1527271769585};\\\", \\\"{x:1620,y:568,t:1527271769601};\\\", \\\"{x:1619,y:570,t:1527271769618};\\\", \\\"{x:1619,y:572,t:1527271769849};\\\", \\\"{x:1619,y:573,t:1527271769856};\\\", \\\"{x:1617,y:575,t:1527271769868};\\\", \\\"{x:1617,y:579,t:1527271769884};\\\", \\\"{x:1616,y:585,t:1527271769901};\\\", \\\"{x:1615,y:590,t:1527271769918};\\\", \\\"{x:1615,y:593,t:1527271769934};\\\", \\\"{x:1614,y:595,t:1527271769951};\\\", \\\"{x:1614,y:596,t:1527271769969};\\\", \\\"{x:1614,y:600,t:1527271769984};\\\", \\\"{x:1614,y:605,t:1527271770001};\\\", \\\"{x:1614,y:610,t:1527271770018};\\\", \\\"{x:1613,y:615,t:1527271770035};\\\", \\\"{x:1613,y:620,t:1527271770051};\\\", \\\"{x:1613,y:622,t:1527271770068};\\\", \\\"{x:1613,y:625,t:1527271770085};\\\", \\\"{x:1613,y:627,t:1527271770101};\\\", \\\"{x:1613,y:628,t:1527271770118};\\\", \\\"{x:1613,y:630,t:1527271770135};\\\", \\\"{x:1613,y:631,t:1527271770151};\\\", \\\"{x:1613,y:633,t:1527271770168};\\\", \\\"{x:1613,y:636,t:1527271770184};\\\", \\\"{x:1613,y:637,t:1527271770201};\\\", \\\"{x:1613,y:640,t:1527271770218};\\\", \\\"{x:1613,y:642,t:1527271770235};\\\", \\\"{x:1613,y:645,t:1527271770251};\\\", \\\"{x:1613,y:649,t:1527271770268};\\\", \\\"{x:1613,y:653,t:1527271770285};\\\", \\\"{x:1613,y:655,t:1527271770302};\\\", \\\"{x:1613,y:659,t:1527271770318};\\\", \\\"{x:1613,y:660,t:1527271770334};\\\", \\\"{x:1613,y:662,t:1527271770352};\\\", \\\"{x:1613,y:663,t:1527271770368};\\\", \\\"{x:1613,y:666,t:1527271770384};\\\", \\\"{x:1613,y:670,t:1527271770401};\\\", \\\"{x:1612,y:672,t:1527271770417};\\\", \\\"{x:1612,y:674,t:1527271770435};\\\", \\\"{x:1612,y:675,t:1527271770452};\\\", \\\"{x:1612,y:676,t:1527271770467};\\\", \\\"{x:1612,y:678,t:1527271770488};\\\", \\\"{x:1612,y:679,t:1527271770552};\\\", \\\"{x:1612,y:681,t:1527271770592};\\\", \\\"{x:1612,y:682,t:1527271770608};\\\", \\\"{x:1611,y:683,t:1527271770618};\\\", \\\"{x:1610,y:685,t:1527271770635};\\\", \\\"{x:1608,y:687,t:1527271770652};\\\", \\\"{x:1607,y:687,t:1527271770668};\\\", \\\"{x:1602,y:687,t:1527271770685};\\\", \\\"{x:1590,y:687,t:1527271770702};\\\", \\\"{x:1572,y:687,t:1527271770719};\\\", \\\"{x:1545,y:683,t:1527271770735};\\\", \\\"{x:1509,y:678,t:1527271770752};\\\", \\\"{x:1435,y:667,t:1527271770768};\\\", \\\"{x:1379,y:659,t:1527271770785};\\\", \\\"{x:1301,y:650,t:1527271770802};\\\", \\\"{x:1226,y:640,t:1527271770819};\\\", \\\"{x:1151,y:627,t:1527271770834};\\\", \\\"{x:1087,y:619,t:1527271770852};\\\", \\\"{x:1013,y:613,t:1527271770868};\\\", \\\"{x:946,y:613,t:1527271770884};\\\", \\\"{x:865,y:613,t:1527271770901};\\\", \\\"{x:804,y:613,t:1527271770918};\\\", \\\"{x:746,y:613,t:1527271770935};\\\", \\\"{x:695,y:613,t:1527271770952};\\\", \\\"{x:640,y:611,t:1527271770969};\\\", \\\"{x:600,y:604,t:1527271770986};\\\", \\\"{x:556,y:600,t:1527271771002};\\\", \\\"{x:535,y:595,t:1527271771015};\\\", \\\"{x:484,y:588,t:1527271771033};\\\", \\\"{x:457,y:584,t:1527271771050};\\\", \\\"{x:433,y:578,t:1527271771068};\\\", \\\"{x:414,y:572,t:1527271771085};\\\", \\\"{x:397,y:568,t:1527271771101};\\\", \\\"{x:383,y:567,t:1527271771118};\\\", \\\"{x:378,y:567,t:1527271771134};\\\", \\\"{x:379,y:567,t:1527271771256};\\\", \\\"{x:379,y:568,t:1527271771268};\\\", \\\"{x:383,y:570,t:1527271771285};\\\", \\\"{x:385,y:570,t:1527271771302};\\\", \\\"{x:386,y:570,t:1527271771318};\\\", \\\"{x:388,y:570,t:1527271771334};\\\", \\\"{x:390,y:564,t:1527271771352};\\\", \\\"{x:392,y:560,t:1527271771368};\\\", \\\"{x:393,y:557,t:1527271771384};\\\", \\\"{x:394,y:556,t:1527271771401};\\\", \\\"{x:395,y:555,t:1527271771448};\\\", \\\"{x:396,y:555,t:1527271771464};\\\", \\\"{x:399,y:555,t:1527271771471};\\\", \\\"{x:402,y:555,t:1527271771485};\\\", \\\"{x:412,y:555,t:1527271771502};\\\", \\\"{x:428,y:555,t:1527271771519};\\\", \\\"{x:452,y:555,t:1527271771535};\\\", \\\"{x:486,y:555,t:1527271771551};\\\", \\\"{x:540,y:556,t:1527271771568};\\\", \\\"{x:611,y:566,t:1527271771585};\\\", \\\"{x:651,y:572,t:1527271771602};\\\", \\\"{x:677,y:574,t:1527271771619};\\\", \\\"{x:694,y:577,t:1527271771635};\\\", \\\"{x:699,y:578,t:1527271771651};\\\", \\\"{x:699,y:579,t:1527271771679};\\\", \\\"{x:699,y:581,t:1527271771695};\\\", \\\"{x:693,y:582,t:1527271771704};\\\", \\\"{x:684,y:584,t:1527271771718};\\\", \\\"{x:664,y:589,t:1527271771734};\\\", \\\"{x:649,y:594,t:1527271771751};\\\", \\\"{x:636,y:599,t:1527271771768};\\\", \\\"{x:630,y:601,t:1527271771784};\\\", \\\"{x:621,y:601,t:1527271771802};\\\", \\\"{x:614,y:601,t:1527271771819};\\\", \\\"{x:611,y:601,t:1527271771835};\\\", \\\"{x:610,y:601,t:1527271771852};\\\", \\\"{x:608,y:601,t:1527271771869};\\\", \\\"{x:607,y:604,t:1527271771885};\\\", \\\"{x:605,y:609,t:1527271771903};\\\", \\\"{x:602,y:614,t:1527271771920};\\\", \\\"{x:600,y:620,t:1527271771936};\\\", \\\"{x:597,y:625,t:1527271771951};\\\", \\\"{x:593,y:633,t:1527271771968};\\\", \\\"{x:590,y:637,t:1527271771986};\\\", \\\"{x:585,y:640,t:1527271772001};\\\", \\\"{x:569,y:642,t:1527271772019};\\\", \\\"{x:544,y:642,t:1527271772035};\\\", \\\"{x:510,y:642,t:1527271772051};\\\", \\\"{x:460,y:642,t:1527271772069};\\\", \\\"{x:401,y:642,t:1527271772086};\\\", \\\"{x:343,y:642,t:1527271772101};\\\", \\\"{x:284,y:642,t:1527271772117};\\\", \\\"{x:238,y:639,t:1527271772136};\\\", \\\"{x:202,y:635,t:1527271772151};\\\", \\\"{x:174,y:630,t:1527271772169};\\\", \\\"{x:165,y:629,t:1527271772186};\\\", \\\"{x:161,y:629,t:1527271772202};\\\", \\\"{x:160,y:629,t:1527271772218};\\\", \\\"{x:159,y:629,t:1527271772235};\\\", \\\"{x:156,y:629,t:1527271772251};\\\", \\\"{x:155,y:629,t:1527271772268};\\\", \\\"{x:153,y:629,t:1527271772285};\\\", \\\"{x:151,y:630,t:1527271772302};\\\", \\\"{x:151,y:631,t:1527271772400};\\\", \\\"{x:152,y:632,t:1527271772418};\\\", \\\"{x:154,y:633,t:1527271772435};\\\", \\\"{x:154,y:634,t:1527271772488};\\\", \\\"{x:154,y:634,t:1527271772573};\\\", \\\"{x:155,y:634,t:1527271772591};\\\", \\\"{x:157,y:634,t:1527271772602};\\\", \\\"{x:171,y:634,t:1527271772619};\\\", \\\"{x:196,y:636,t:1527271772636};\\\", \\\"{x:233,y:641,t:1527271772652};\\\", \\\"{x:283,y:649,t:1527271772669};\\\", \\\"{x:331,y:664,t:1527271772686};\\\", \\\"{x:368,y:677,t:1527271772702};\\\", \\\"{x:394,y:686,t:1527271772719};\\\", \\\"{x:410,y:694,t:1527271772736};\\\", \\\"{x:423,y:701,t:1527271772752};\\\", \\\"{x:425,y:703,t:1527271772769};\\\", \\\"{x:425,y:705,t:1527271772855};\\\", \\\"{x:425,y:707,t:1527271772869};\\\", \\\"{x:426,y:713,t:1527271772885};\\\", \\\"{x:428,y:715,t:1527271772902};\\\", \\\"{x:429,y:713,t:1527271772952};\\\", \\\"{x:431,y:711,t:1527271772970};\\\", \\\"{x:433,y:711,t:1527271773087};\\\", \\\"{x:434,y:710,t:1527271773112};\\\", \\\"{x:439,y:711,t:1527271773152};\\\", \\\"{x:446,y:717,t:1527271773160};\\\", \\\"{x:446,y:717,t:1527271773161};\\\", \\\"{x:452,y:721,t:1527271773170};\\\", \\\"{x:463,y:725,t:1527271773185};\\\", \\\"{x:471,y:727,t:1527271773203};\\\", \\\"{x:479,y:727,t:1527271773753};\\\", \\\"{x:551,y:715,t:1527271773770};\\\", \\\"{x:672,y:700,t:1527271773787};\\\", \\\"{x:813,y:683,t:1527271773803};\\\", \\\"{x:962,y:664,t:1527271773820};\\\", \\\"{x:1109,y:642,t:1527271773837};\\\", \\\"{x:1228,y:628,t:1527271773854};\\\", \\\"{x:1339,y:628,t:1527271773870};\\\", \\\"{x:1414,y:628,t:1527271773887};\\\", \\\"{x:1463,y:627,t:1527271773905};\\\", \\\"{x:1464,y:626,t:1527271773920};\\\", \\\"{x:1465,y:626,t:1527271774353};\\\" ] }, { \\\"rt\\\": 11900, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 206376, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 0.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1464,y:626,t:1527271776609};\\\", \\\"{x:1463,y:626,t:1527271776623};\\\", \\\"{x:1462,y:626,t:1527271776639};\\\", \\\"{x:1461,y:626,t:1527271776665};\\\", \\\"{x:1460,y:626,t:1527271776680};\\\", \\\"{x:1459,y:626,t:1527271776697};\\\", \\\"{x:1458,y:626,t:1527271776712};\\\", \\\"{x:1457,y:626,t:1527271776722};\\\", \\\"{x:1456,y:626,t:1527271776739};\\\", \\\"{x:1455,y:626,t:1527271776873};\\\", \\\"{x:1453,y:626,t:1527271776890};\\\", \\\"{x:1446,y:626,t:1527271776907};\\\", \\\"{x:1440,y:626,t:1527271776922};\\\", \\\"{x:1426,y:626,t:1527271776940};\\\", \\\"{x:1411,y:617,t:1527271776956};\\\", \\\"{x:1402,y:610,t:1527271776973};\\\", \\\"{x:1402,y:609,t:1527271777193};\\\", \\\"{x:1403,y:609,t:1527271777257};\\\", \\\"{x:1404,y:609,t:1527271777273};\\\", \\\"{x:1406,y:609,t:1527271777289};\\\", \\\"{x:1407,y:608,t:1527271777306};\\\", \\\"{x:1407,y:607,t:1527271777323};\\\", \\\"{x:1405,y:607,t:1527271777360};\\\", \\\"{x:1403,y:607,t:1527271777373};\\\", \\\"{x:1397,y:607,t:1527271777389};\\\", \\\"{x:1392,y:607,t:1527271777407};\\\", \\\"{x:1384,y:611,t:1527271777424};\\\", \\\"{x:1377,y:616,t:1527271777440};\\\", \\\"{x:1371,y:623,t:1527271777457};\\\", \\\"{x:1370,y:624,t:1527271777473};\\\", \\\"{x:1368,y:626,t:1527271777490};\\\", \\\"{x:1367,y:627,t:1527271777507};\\\", \\\"{x:1365,y:627,t:1527271777523};\\\", \\\"{x:1362,y:627,t:1527271777540};\\\", \\\"{x:1358,y:627,t:1527271777557};\\\", \\\"{x:1355,y:627,t:1527271777573};\\\", \\\"{x:1352,y:627,t:1527271777590};\\\", \\\"{x:1350,y:627,t:1527271777607};\\\", \\\"{x:1350,y:626,t:1527271777623};\\\", \\\"{x:1351,y:626,t:1527271777641};\\\", \\\"{x:1358,y:627,t:1527271777656};\\\", \\\"{x:1368,y:633,t:1527271777674};\\\", \\\"{x:1375,y:638,t:1527271777690};\\\", \\\"{x:1380,y:643,t:1527271777707};\\\", \\\"{x:1383,y:648,t:1527271777723};\\\", \\\"{x:1387,y:657,t:1527271777740};\\\", \\\"{x:1387,y:667,t:1527271777756};\\\", \\\"{x:1388,y:678,t:1527271777774};\\\", \\\"{x:1391,y:685,t:1527271777791};\\\", \\\"{x:1392,y:692,t:1527271777806};\\\", \\\"{x:1392,y:696,t:1527271777824};\\\", \\\"{x:1392,y:702,t:1527271777841};\\\", \\\"{x:1391,y:708,t:1527271777857};\\\", \\\"{x:1390,y:711,t:1527271777874};\\\", \\\"{x:1388,y:715,t:1527271777891};\\\", \\\"{x:1385,y:718,t:1527271777906};\\\", \\\"{x:1381,y:722,t:1527271777924};\\\", \\\"{x:1375,y:727,t:1527271777940};\\\", \\\"{x:1365,y:732,t:1527271777957};\\\", \\\"{x:1357,y:736,t:1527271777973};\\\", \\\"{x:1351,y:739,t:1527271777991};\\\", \\\"{x:1343,y:742,t:1527271778007};\\\", \\\"{x:1334,y:745,t:1527271778024};\\\", \\\"{x:1323,y:749,t:1527271778040};\\\", \\\"{x:1315,y:752,t:1527271778056};\\\", \\\"{x:1308,y:754,t:1527271778074};\\\", \\\"{x:1300,y:759,t:1527271778091};\\\", \\\"{x:1294,y:761,t:1527271778107};\\\", \\\"{x:1292,y:762,t:1527271778124};\\\", \\\"{x:1290,y:762,t:1527271778140};\\\", \\\"{x:1288,y:764,t:1527271778157};\\\", \\\"{x:1285,y:766,t:1527271778173};\\\", \\\"{x:1281,y:768,t:1527271778190};\\\", \\\"{x:1275,y:770,t:1527271778208};\\\", \\\"{x:1268,y:773,t:1527271778224};\\\", \\\"{x:1261,y:776,t:1527271778241};\\\", \\\"{x:1255,y:779,t:1527271778257};\\\", \\\"{x:1250,y:782,t:1527271778273};\\\", \\\"{x:1245,y:784,t:1527271778291};\\\", \\\"{x:1242,y:786,t:1527271778308};\\\", \\\"{x:1238,y:788,t:1527271778324};\\\", \\\"{x:1236,y:788,t:1527271778340};\\\", \\\"{x:1233,y:783,t:1527271778357};\\\", \\\"{x:1233,y:782,t:1527271778897};\\\", \\\"{x:1233,y:783,t:1527271779281};\\\", \\\"{x:1233,y:784,t:1527271779297};\\\", \\\"{x:1233,y:785,t:1527271779329};\\\", \\\"{x:1232,y:786,t:1527271779465};\\\", \\\"{x:1231,y:788,t:1527271779504};\\\", \\\"{x:1231,y:790,t:1527271779529};\\\", \\\"{x:1230,y:791,t:1527271779541};\\\", \\\"{x:1230,y:794,t:1527271779559};\\\", \\\"{x:1229,y:799,t:1527271779574};\\\", \\\"{x:1229,y:804,t:1527271779591};\\\", \\\"{x:1228,y:809,t:1527271779609};\\\", \\\"{x:1227,y:811,t:1527271779624};\\\", \\\"{x:1227,y:813,t:1527271779641};\\\", \\\"{x:1225,y:816,t:1527271779658};\\\", \\\"{x:1225,y:817,t:1527271779680};\\\", \\\"{x:1225,y:818,t:1527271779691};\\\", \\\"{x:1225,y:820,t:1527271779708};\\\", \\\"{x:1224,y:822,t:1527271779723};\\\", \\\"{x:1224,y:827,t:1527271779741};\\\", \\\"{x:1223,y:829,t:1527271779758};\\\", \\\"{x:1222,y:832,t:1527271779774};\\\", \\\"{x:1222,y:833,t:1527271779791};\\\", \\\"{x:1221,y:834,t:1527271779807};\\\", \\\"{x:1220,y:835,t:1527271780049};\\\", \\\"{x:1219,y:835,t:1527271780059};\\\", \\\"{x:1218,y:835,t:1527271780088};\\\", \\\"{x:1216,y:835,t:1527271780140};\\\", \\\"{x:1215,y:835,t:1527271780208};\\\", \\\"{x:1214,y:834,t:1527271780337};\\\", \\\"{x:1213,y:834,t:1527271780369};\\\", \\\"{x:1212,y:834,t:1527271780409};\\\", \\\"{x:1212,y:833,t:1527271781745};\\\", \\\"{x:1212,y:832,t:1527271781760};\\\", \\\"{x:1223,y:832,t:1527271781778};\\\", \\\"{x:1235,y:832,t:1527271781792};\\\", \\\"{x:1251,y:832,t:1527271781809};\\\", \\\"{x:1271,y:832,t:1527271781826};\\\", \\\"{x:1290,y:835,t:1527271781844};\\\", \\\"{x:1317,y:843,t:1527271781860};\\\", \\\"{x:1338,y:848,t:1527271781876};\\\", \\\"{x:1356,y:854,t:1527271781893};\\\", \\\"{x:1368,y:857,t:1527271781909};\\\", \\\"{x:1375,y:861,t:1527271781926};\\\", \\\"{x:1380,y:868,t:1527271781943};\\\", \\\"{x:1382,y:873,t:1527271781960};\\\", \\\"{x:1382,y:882,t:1527271781977};\\\", \\\"{x:1382,y:886,t:1527271781993};\\\", \\\"{x:1381,y:890,t:1527271782009};\\\", \\\"{x:1381,y:892,t:1527271782027};\\\", \\\"{x:1379,y:893,t:1527271782043};\\\", \\\"{x:1379,y:894,t:1527271782060};\\\", \\\"{x:1376,y:895,t:1527271782077};\\\", \\\"{x:1372,y:896,t:1527271782094};\\\", \\\"{x:1369,y:898,t:1527271782110};\\\", \\\"{x:1365,y:899,t:1527271782126};\\\", \\\"{x:1363,y:901,t:1527271782144};\\\", \\\"{x:1361,y:901,t:1527271782160};\\\", \\\"{x:1360,y:902,t:1527271782208};\\\", \\\"{x:1359,y:902,t:1527271782240};\\\", \\\"{x:1358,y:902,t:1527271782256};\\\", \\\"{x:1357,y:903,t:1527271782272};\\\", \\\"{x:1356,y:903,t:1527271782280};\\\", \\\"{x:1355,y:903,t:1527271782294};\\\", \\\"{x:1351,y:903,t:1527271782310};\\\", \\\"{x:1346,y:903,t:1527271782327};\\\", \\\"{x:1344,y:903,t:1527271782343};\\\", \\\"{x:1341,y:903,t:1527271782361};\\\", \\\"{x:1338,y:901,t:1527271782376};\\\", \\\"{x:1337,y:899,t:1527271782401};\\\", \\\"{x:1337,y:898,t:1527271782424};\\\", \\\"{x:1337,y:897,t:1527271782440};\\\", \\\"{x:1337,y:896,t:1527271782457};\\\", \\\"{x:1336,y:894,t:1527271782472};\\\", \\\"{x:1335,y:894,t:1527271782481};\\\", \\\"{x:1335,y:893,t:1527271782705};\\\", \\\"{x:1335,y:892,t:1527271782720};\\\", \\\"{x:1335,y:890,t:1527271782737};\\\", \\\"{x:1336,y:890,t:1527271782768};\\\", \\\"{x:1336,y:891,t:1527271782945};\\\", \\\"{x:1338,y:892,t:1527271782961};\\\", \\\"{x:1338,y:893,t:1527271782978};\\\", \\\"{x:1339,y:894,t:1527271782994};\\\", \\\"{x:1341,y:895,t:1527271783193};\\\", \\\"{x:1342,y:897,t:1527271783201};\\\", \\\"{x:1343,y:900,t:1527271783228};\\\", \\\"{x:1345,y:902,t:1527271783245};\\\", \\\"{x:1345,y:903,t:1527271783261};\\\", \\\"{x:1344,y:903,t:1527271783409};\\\", \\\"{x:1344,y:902,t:1527271783433};\\\", \\\"{x:1344,y:901,t:1527271783445};\\\", \\\"{x:1344,y:898,t:1527271783460};\\\", \\\"{x:1342,y:896,t:1527271783478};\\\", \\\"{x:1342,y:893,t:1527271783495};\\\", \\\"{x:1342,y:890,t:1527271783510};\\\", \\\"{x:1342,y:883,t:1527271783528};\\\", \\\"{x:1342,y:880,t:1527271783544};\\\", \\\"{x:1342,y:878,t:1527271783560};\\\", \\\"{x:1342,y:877,t:1527271783577};\\\", \\\"{x:1342,y:875,t:1527271783595};\\\", \\\"{x:1342,y:874,t:1527271783611};\\\", \\\"{x:1342,y:872,t:1527271783628};\\\", \\\"{x:1342,y:867,t:1527271783645};\\\", \\\"{x:1342,y:862,t:1527271783660};\\\", \\\"{x:1342,y:856,t:1527271783678};\\\", \\\"{x:1342,y:851,t:1527271783695};\\\", \\\"{x:1342,y:845,t:1527271783711};\\\", \\\"{x:1343,y:840,t:1527271783728};\\\", \\\"{x:1344,y:830,t:1527271783745};\\\", \\\"{x:1347,y:819,t:1527271783761};\\\", \\\"{x:1348,y:807,t:1527271783778};\\\", \\\"{x:1351,y:796,t:1527271783795};\\\", \\\"{x:1351,y:791,t:1527271783811};\\\", \\\"{x:1352,y:787,t:1527271783828};\\\", \\\"{x:1353,y:783,t:1527271783844};\\\", \\\"{x:1355,y:775,t:1527271783861};\\\", \\\"{x:1356,y:766,t:1527271783877};\\\", \\\"{x:1359,y:751,t:1527271783894};\\\", \\\"{x:1360,y:738,t:1527271783912};\\\", \\\"{x:1362,y:726,t:1527271783927};\\\", \\\"{x:1362,y:708,t:1527271783945};\\\", \\\"{x:1364,y:694,t:1527271783962};\\\", \\\"{x:1365,y:676,t:1527271783978};\\\", \\\"{x:1365,y:657,t:1527271783995};\\\", \\\"{x:1365,y:646,t:1527271784012};\\\", \\\"{x:1365,y:637,t:1527271784028};\\\", \\\"{x:1365,y:625,t:1527271784044};\\\", \\\"{x:1365,y:614,t:1527271784062};\\\", \\\"{x:1365,y:599,t:1527271784078};\\\", \\\"{x:1365,y:586,t:1527271784094};\\\", \\\"{x:1365,y:579,t:1527271784112};\\\", \\\"{x:1365,y:571,t:1527271784128};\\\", \\\"{x:1365,y:561,t:1527271784145};\\\", \\\"{x:1365,y:554,t:1527271784162};\\\", \\\"{x:1364,y:546,t:1527271784178};\\\", \\\"{x:1363,y:540,t:1527271784195};\\\", \\\"{x:1359,y:527,t:1527271784212};\\\", \\\"{x:1357,y:519,t:1527271784229};\\\", \\\"{x:1356,y:515,t:1527271784245};\\\", \\\"{x:1355,y:510,t:1527271784262};\\\", \\\"{x:1355,y:506,t:1527271784279};\\\", \\\"{x:1354,y:503,t:1527271784294};\\\", \\\"{x:1352,y:498,t:1527271784312};\\\", \\\"{x:1350,y:490,t:1527271784328};\\\", \\\"{x:1348,y:485,t:1527271784345};\\\", \\\"{x:1348,y:484,t:1527271784361};\\\", \\\"{x:1347,y:479,t:1527271784378};\\\", \\\"{x:1345,y:474,t:1527271784394};\\\", \\\"{x:1344,y:472,t:1527271784411};\\\", \\\"{x:1344,y:470,t:1527271784428};\\\", \\\"{x:1341,y:469,t:1527271784472};\\\", \\\"{x:1337,y:465,t:1527271784479};\\\", \\\"{x:1324,y:460,t:1527271784494};\\\", \\\"{x:1258,y:440,t:1527271784511};\\\", \\\"{x:1076,y:390,t:1527271784527};\\\", \\\"{x:898,y:358,t:1527271784544};\\\", \\\"{x:724,y:354,t:1527271784561};\\\", \\\"{x:552,y:354,t:1527271784578};\\\", \\\"{x:384,y:354,t:1527271784594};\\\", \\\"{x:266,y:361,t:1527271784611};\\\", \\\"{x:206,y:372,t:1527271784628};\\\", \\\"{x:181,y:379,t:1527271784644};\\\", \\\"{x:177,y:384,t:1527271784661};\\\", \\\"{x:175,y:397,t:1527271784678};\\\", \\\"{x:175,y:416,t:1527271784695};\\\", \\\"{x:180,y:434,t:1527271784711};\\\", \\\"{x:194,y:466,t:1527271784728};\\\", \\\"{x:211,y:491,t:1527271784745};\\\", \\\"{x:229,y:519,t:1527271784762};\\\", \\\"{x:246,y:546,t:1527271784779};\\\", \\\"{x:265,y:564,t:1527271784795};\\\", \\\"{x:284,y:571,t:1527271784812};\\\", \\\"{x:303,y:578,t:1527271784829};\\\", \\\"{x:313,y:580,t:1527271784846};\\\", \\\"{x:317,y:583,t:1527271784862};\\\", \\\"{x:318,y:583,t:1527271784879};\\\", \\\"{x:318,y:586,t:1527271784895};\\\", \\\"{x:314,y:589,t:1527271784912};\\\", \\\"{x:304,y:590,t:1527271784929};\\\", \\\"{x:291,y:592,t:1527271784946};\\\", \\\"{x:278,y:595,t:1527271784962};\\\", \\\"{x:264,y:601,t:1527271784980};\\\", \\\"{x:244,y:610,t:1527271784996};\\\", \\\"{x:228,y:616,t:1527271785012};\\\", \\\"{x:214,y:620,t:1527271785030};\\\", \\\"{x:206,y:621,t:1527271785046};\\\", \\\"{x:198,y:622,t:1527271785062};\\\", \\\"{x:193,y:623,t:1527271785079};\\\", \\\"{x:192,y:623,t:1527271785120};\\\", \\\"{x:191,y:623,t:1527271785129};\\\", \\\"{x:187,y:617,t:1527271785147};\\\", \\\"{x:183,y:606,t:1527271785163};\\\", \\\"{x:179,y:597,t:1527271785179};\\\", \\\"{x:177,y:592,t:1527271785196};\\\", \\\"{x:177,y:591,t:1527271785212};\\\", \\\"{x:177,y:590,t:1527271785231};\\\", \\\"{x:177,y:588,t:1527271785246};\\\", \\\"{x:177,y:586,t:1527271785263};\\\", \\\"{x:177,y:584,t:1527271785279};\\\", \\\"{x:177,y:583,t:1527271785296};\\\", \\\"{x:177,y:582,t:1527271785408};\\\", \\\"{x:177,y:581,t:1527271785417};\\\", \\\"{x:177,y:579,t:1527271785429};\\\", \\\"{x:177,y:578,t:1527271785446};\\\", \\\"{x:176,y:575,t:1527271785463};\\\", \\\"{x:176,y:574,t:1527271785480};\\\", \\\"{x:176,y:573,t:1527271785528};\\\", \\\"{x:176,y:572,t:1527271785535};\\\", \\\"{x:176,y:571,t:1527271785545};\\\", \\\"{x:176,y:570,t:1527271785563};\\\", \\\"{x:176,y:569,t:1527271785583};\\\", \\\"{x:176,y:568,t:1527271785885};\\\", \\\"{x:203,y:572,t:1527271785897};\\\", \\\"{x:261,y:587,t:1527271785913};\\\", \\\"{x:333,y:607,t:1527271785930};\\\", \\\"{x:412,y:628,t:1527271785947};\\\", \\\"{x:485,y:651,t:1527271785963};\\\", \\\"{x:542,y:670,t:1527271785980};\\\", \\\"{x:578,y:685,t:1527271785996};\\\", \\\"{x:591,y:694,t:1527271786013};\\\", \\\"{x:597,y:700,t:1527271786030};\\\", \\\"{x:597,y:704,t:1527271786046};\\\", \\\"{x:599,y:706,t:1527271786063};\\\", \\\"{x:601,y:714,t:1527271786080};\\\", \\\"{x:606,y:722,t:1527271786096};\\\", \\\"{x:609,y:727,t:1527271786113};\\\", \\\"{x:611,y:730,t:1527271786130};\\\", \\\"{x:612,y:731,t:1527271786146};\\\", \\\"{x:611,y:730,t:1527271786249};\\\", \\\"{x:609,y:729,t:1527271786263};\\\", \\\"{x:595,y:728,t:1527271786280};\\\", \\\"{x:571,y:724,t:1527271786296};\\\", \\\"{x:541,y:722,t:1527271786316};\\\", \\\"{x:504,y:717,t:1527271786329};\\\", \\\"{x:481,y:711,t:1527271786346};\\\", \\\"{x:473,y:711,t:1527271786363};\\\", \\\"{x:472,y:711,t:1527271786392};\\\" ] }, { \\\"rt\\\": 44066, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 251741, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-05 PM-04 PM-04 PM-04 PM-K -U -U -F -F -F -F -F -H -H -O -O -K -K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:471,y:709,t:1527271788088};\\\", \\\"{x:466,y:704,t:1527271788098};\\\", \\\"{x:444,y:693,t:1527271788116};\\\", \\\"{x:417,y:683,t:1527271788131};\\\", \\\"{x:364,y:669,t:1527271788147};\\\", \\\"{x:311,y:654,t:1527271788165};\\\", \\\"{x:266,y:647,t:1527271788182};\\\", \\\"{x:240,y:642,t:1527271788198};\\\", \\\"{x:230,y:637,t:1527271788215};\\\", \\\"{x:225,y:626,t:1527271788231};\\\", \\\"{x:224,y:615,t:1527271788249};\\\", \\\"{x:224,y:608,t:1527271788266};\\\", \\\"{x:224,y:606,t:1527271788282};\\\", \\\"{x:224,y:605,t:1527271788377};\\\", \\\"{x:224,y:601,t:1527271788785};\\\", \\\"{x:222,y:595,t:1527271788799};\\\", \\\"{x:222,y:577,t:1527271788817};\\\", \\\"{x:217,y:548,t:1527271788833};\\\", \\\"{x:216,y:535,t:1527271788849};\\\", \\\"{x:216,y:527,t:1527271788864};\\\", \\\"{x:216,y:524,t:1527271788882};\\\", \\\"{x:217,y:521,t:1527271788899};\\\", \\\"{x:219,y:520,t:1527271788915};\\\", \\\"{x:220,y:518,t:1527271788932};\\\", \\\"{x:222,y:516,t:1527271788949};\\\", \\\"{x:222,y:515,t:1527271788966};\\\", \\\"{x:223,y:514,t:1527271788982};\\\", \\\"{x:221,y:515,t:1527271789032};\\\", \\\"{x:212,y:526,t:1527271789049};\\\", \\\"{x:201,y:541,t:1527271789067};\\\", \\\"{x:190,y:556,t:1527271789083};\\\", \\\"{x:181,y:566,t:1527271789099};\\\", \\\"{x:178,y:570,t:1527271789116};\\\", \\\"{x:176,y:572,t:1527271789133};\\\", \\\"{x:174,y:572,t:1527271789305};\\\", \\\"{x:174,y:570,t:1527271789315};\\\", \\\"{x:174,y:569,t:1527271789333};\\\", \\\"{x:174,y:568,t:1527271789350};\\\", \\\"{x:173,y:568,t:1527271789415};\\\", \\\"{x:173,y:568,t:1527271789436};\\\", \\\"{x:173,y:566,t:1527271789527};\\\", \\\"{x:176,y:564,t:1527271789535};\\\", \\\"{x:183,y:561,t:1527271789549};\\\", \\\"{x:202,y:552,t:1527271789567};\\\", \\\"{x:228,y:541,t:1527271789584};\\\", \\\"{x:271,y:527,t:1527271789601};\\\", \\\"{x:338,y:507,t:1527271789617};\\\", \\\"{x:370,y:496,t:1527271789633};\\\", \\\"{x:386,y:490,t:1527271789649};\\\", \\\"{x:392,y:487,t:1527271789666};\\\", \\\"{x:393,y:487,t:1527271789703};\\\", \\\"{x:388,y:485,t:1527271789961};\\\", \\\"{x:381,y:481,t:1527271789968};\\\", \\\"{x:373,y:476,t:1527271789983};\\\", \\\"{x:339,y:461,t:1527271790000};\\\", \\\"{x:307,y:448,t:1527271790017};\\\", \\\"{x:288,y:442,t:1527271790035};\\\", \\\"{x:277,y:438,t:1527271790051};\\\", \\\"{x:273,y:436,t:1527271790066};\\\", \\\"{x:272,y:436,t:1527271790084};\\\", \\\"{x:272,y:438,t:1527271792377};\\\", \\\"{x:272,y:442,t:1527271792386};\\\", \\\"{x:273,y:453,t:1527271792402};\\\", \\\"{x:275,y:469,t:1527271792420};\\\", \\\"{x:278,y:484,t:1527271792436};\\\", \\\"{x:281,y:497,t:1527271792453};\\\", \\\"{x:284,y:509,t:1527271792471};\\\", \\\"{x:288,y:521,t:1527271792486};\\\", \\\"{x:290,y:529,t:1527271792503};\\\", \\\"{x:291,y:535,t:1527271792519};\\\", \\\"{x:292,y:537,t:1527271792536};\\\", \\\"{x:293,y:542,t:1527271792553};\\\", \\\"{x:295,y:545,t:1527271792569};\\\", \\\"{x:296,y:546,t:1527271792585};\\\", \\\"{x:296,y:548,t:1527271792889};\\\", \\\"{x:297,y:549,t:1527271792904};\\\", \\\"{x:298,y:550,t:1527271792920};\\\", \\\"{x:299,y:551,t:1527271792936};\\\", \\\"{x:299,y:552,t:1527271792953};\\\", \\\"{x:298,y:556,t:1527271792969};\\\", \\\"{x:296,y:557,t:1527271792986};\\\", \\\"{x:294,y:559,t:1527271793004};\\\", \\\"{x:291,y:561,t:1527271793020};\\\", \\\"{x:289,y:563,t:1527271793037};\\\", \\\"{x:285,y:566,t:1527271793053};\\\", \\\"{x:282,y:568,t:1527271793069};\\\", \\\"{x:281,y:568,t:1527271793086};\\\", \\\"{x:279,y:568,t:1527271793111};\\\", \\\"{x:278,y:568,t:1527271793143};\\\", \\\"{x:277,y:568,t:1527271793159};\\\", \\\"{x:275,y:568,t:1527271793170};\\\", \\\"{x:272,y:569,t:1527271793188};\\\", \\\"{x:266,y:569,t:1527271793203};\\\", \\\"{x:259,y:570,t:1527271793220};\\\", \\\"{x:248,y:570,t:1527271793235};\\\", \\\"{x:235,y:570,t:1527271793252};\\\", \\\"{x:222,y:570,t:1527271793270};\\\", \\\"{x:203,y:570,t:1527271793287};\\\", \\\"{x:186,y:570,t:1527271793303};\\\", \\\"{x:164,y:567,t:1527271793320};\\\", \\\"{x:148,y:563,t:1527271793337};\\\", \\\"{x:141,y:561,t:1527271793352};\\\", \\\"{x:141,y:560,t:1527271793464};\\\", \\\"{x:141,y:559,t:1527271793472};\\\", \\\"{x:144,y:558,t:1527271793486};\\\", \\\"{x:152,y:555,t:1527271793503};\\\", \\\"{x:170,y:552,t:1527271793519};\\\", \\\"{x:185,y:552,t:1527271793537};\\\", \\\"{x:200,y:552,t:1527271793553};\\\", \\\"{x:219,y:552,t:1527271793570};\\\", \\\"{x:242,y:552,t:1527271793586};\\\", \\\"{x:264,y:552,t:1527271793603};\\\", \\\"{x:283,y:552,t:1527271793620};\\\", \\\"{x:298,y:552,t:1527271793636};\\\", \\\"{x:308,y:552,t:1527271793654};\\\", \\\"{x:319,y:552,t:1527271793670};\\\", \\\"{x:331,y:552,t:1527271793686};\\\", \\\"{x:357,y:552,t:1527271793704};\\\", \\\"{x:379,y:552,t:1527271793721};\\\", \\\"{x:401,y:552,t:1527271793737};\\\", \\\"{x:429,y:552,t:1527271793753};\\\", \\\"{x:458,y:552,t:1527271793770};\\\", \\\"{x:486,y:552,t:1527271793786};\\\", \\\"{x:508,y:552,t:1527271793804};\\\", \\\"{x:517,y:552,t:1527271793819};\\\", \\\"{x:518,y:552,t:1527271793837};\\\", \\\"{x:519,y:553,t:1527271793853};\\\", \\\"{x:521,y:560,t:1527271793870};\\\", \\\"{x:522,y:572,t:1527271793886};\\\", \\\"{x:526,y:593,t:1527271793904};\\\", \\\"{x:530,y:609,t:1527271793919};\\\", \\\"{x:535,y:621,t:1527271793939};\\\", \\\"{x:540,y:630,t:1527271793953};\\\", \\\"{x:542,y:634,t:1527271793969};\\\", \\\"{x:542,y:636,t:1527271793986};\\\", \\\"{x:541,y:635,t:1527271794128};\\\", \\\"{x:539,y:635,t:1527271794137};\\\", \\\"{x:528,y:633,t:1527271794154};\\\", \\\"{x:514,y:631,t:1527271794170};\\\", \\\"{x:498,y:631,t:1527271794188};\\\", \\\"{x:477,y:631,t:1527271794203};\\\", \\\"{x:459,y:631,t:1527271794221};\\\", \\\"{x:443,y:637,t:1527271794236};\\\", \\\"{x:429,y:643,t:1527271794254};\\\", \\\"{x:421,y:651,t:1527271794271};\\\", \\\"{x:418,y:659,t:1527271794287};\\\", \\\"{x:417,y:666,t:1527271794303};\\\", \\\"{x:420,y:671,t:1527271794321};\\\", \\\"{x:427,y:681,t:1527271794337};\\\", \\\"{x:438,y:689,t:1527271794354};\\\", \\\"{x:446,y:692,t:1527271794370};\\\", \\\"{x:457,y:697,t:1527271794387};\\\", \\\"{x:472,y:702,t:1527271794405};\\\", \\\"{x:487,y:707,t:1527271794421};\\\", \\\"{x:502,y:711,t:1527271794437};\\\", \\\"{x:514,y:713,t:1527271794454};\\\", \\\"{x:520,y:714,t:1527271794471};\\\", \\\"{x:523,y:714,t:1527271794487};\\\", \\\"{x:524,y:715,t:1527271794567};\\\", \\\"{x:525,y:717,t:1527271794575};\\\", \\\"{x:526,y:719,t:1527271794587};\\\", \\\"{x:528,y:723,t:1527271794603};\\\", \\\"{x:526,y:723,t:1527271794720};\\\", \\\"{x:521,y:721,t:1527271794738};\\\", \\\"{x:516,y:718,t:1527271794754};\\\", \\\"{x:510,y:714,t:1527271794771};\\\", \\\"{x:503,y:709,t:1527271794787};\\\", \\\"{x:494,y:702,t:1527271794803};\\\", \\\"{x:489,y:694,t:1527271794821};\\\", \\\"{x:486,y:684,t:1527271794837};\\\", \\\"{x:485,y:672,t:1527271794854};\\\", \\\"{x:485,y:658,t:1527271794870};\\\", \\\"{x:496,y:638,t:1527271794888};\\\", \\\"{x:508,y:624,t:1527271794905};\\\", \\\"{x:531,y:610,t:1527271794921};\\\", \\\"{x:565,y:592,t:1527271794938};\\\", \\\"{x:628,y:568,t:1527271794955};\\\", \\\"{x:713,y:547,t:1527271794970};\\\", \\\"{x:787,y:533,t:1527271794988};\\\", \\\"{x:851,y:524,t:1527271795003};\\\", \\\"{x:891,y:521,t:1527271795021};\\\", \\\"{x:918,y:521,t:1527271795037};\\\", \\\"{x:933,y:521,t:1527271795054};\\\", \\\"{x:943,y:524,t:1527271795070};\\\", \\\"{x:944,y:525,t:1527271795087};\\\", \\\"{x:944,y:526,t:1527271795264};\\\", \\\"{x:943,y:527,t:1527271795296};\\\", \\\"{x:942,y:527,t:1527271795328};\\\", \\\"{x:941,y:527,t:1527271795352};\\\", \\\"{x:941,y:528,t:1527271795361};\\\", \\\"{x:940,y:528,t:1527271795372};\\\", \\\"{x:938,y:529,t:1527271795389};\\\", \\\"{x:936,y:529,t:1527271795405};\\\", \\\"{x:931,y:530,t:1527271795422};\\\", \\\"{x:929,y:530,t:1527271795439};\\\", \\\"{x:923,y:531,t:1527271795455};\\\", \\\"{x:917,y:531,t:1527271795472};\\\", \\\"{x:911,y:531,t:1527271795489};\\\", \\\"{x:898,y:531,t:1527271795506};\\\", \\\"{x:887,y:531,t:1527271795522};\\\", \\\"{x:873,y:531,t:1527271795539};\\\", \\\"{x:859,y:531,t:1527271795557};\\\", \\\"{x:846,y:531,t:1527271795572};\\\", \\\"{x:826,y:528,t:1527271795586};\\\", \\\"{x:805,y:521,t:1527271795604};\\\", \\\"{x:781,y:514,t:1527271795622};\\\", \\\"{x:760,y:508,t:1527271795637};\\\", \\\"{x:735,y:496,t:1527271795655};\\\", \\\"{x:697,y:479,t:1527271795671};\\\", \\\"{x:677,y:471,t:1527271795688};\\\", \\\"{x:664,y:468,t:1527271795705};\\\", \\\"{x:659,y:466,t:1527271795721};\\\", \\\"{x:658,y:466,t:1527271795738};\\\", \\\"{x:657,y:468,t:1527271795788};\\\", \\\"{x:655,y:472,t:1527271795822};\\\", \\\"{x:654,y:474,t:1527271795839};\\\", \\\"{x:653,y:465,t:1527271796313};\\\", \\\"{x:653,y:458,t:1527271796322};\\\", \\\"{x:655,y:432,t:1527271796339};\\\", \\\"{x:657,y:410,t:1527271796356};\\\", \\\"{x:657,y:392,t:1527271796371};\\\", \\\"{x:657,y:379,t:1527271796389};\\\", \\\"{x:657,y:370,t:1527271796406};\\\", \\\"{x:657,y:369,t:1527271796422};\\\", \\\"{x:657,y:303,t:1527271798918};\\\", \\\"{x:657,y:369,t:1527271800150};\\\", \\\"{x:676,y:385,t:1527271802648};\\\", \\\"{x:720,y:415,t:1527271802663};\\\", \\\"{x:870,y:484,t:1527271802680};\\\", \\\"{x:1066,y:566,t:1527271802696};\\\", \\\"{x:1177,y:597,t:1527271802712};\\\", \\\"{x:1264,y:626,t:1527271802729};\\\", \\\"{x:1322,y:653,t:1527271802746};\\\", \\\"{x:1354,y:666,t:1527271802763};\\\", \\\"{x:1371,y:677,t:1527271802779};\\\", \\\"{x:1377,y:682,t:1527271802796};\\\", \\\"{x:1388,y:698,t:1527271802813};\\\", \\\"{x:1406,y:719,t:1527271802830};\\\", \\\"{x:1425,y:742,t:1527271802847};\\\", \\\"{x:1439,y:764,t:1527271802864};\\\", \\\"{x:1459,y:790,t:1527271802880};\\\", \\\"{x:1521,y:868,t:1527271802896};\\\", \\\"{x:1564,y:917,t:1527271802914};\\\", \\\"{x:1585,y:942,t:1527271802929};\\\", \\\"{x:1591,y:949,t:1527271802947};\\\", \\\"{x:1595,y:955,t:1527271802964};\\\", \\\"{x:1600,y:961,t:1527271802980};\\\", \\\"{x:1605,y:966,t:1527271802996};\\\", \\\"{x:1611,y:972,t:1527271803014};\\\", \\\"{x:1618,y:974,t:1527271803029};\\\", \\\"{x:1623,y:974,t:1527271803046};\\\", \\\"{x:1629,y:974,t:1527271803063};\\\", \\\"{x:1637,y:965,t:1527271803081};\\\", \\\"{x:1647,y:958,t:1527271803096};\\\", \\\"{x:1665,y:945,t:1527271803114};\\\", \\\"{x:1680,y:931,t:1527271803131};\\\", \\\"{x:1696,y:909,t:1527271803147};\\\", \\\"{x:1702,y:895,t:1527271803164};\\\", \\\"{x:1705,y:886,t:1527271803180};\\\", \\\"{x:1705,y:884,t:1527271803196};\\\", \\\"{x:1705,y:883,t:1527271803214};\\\", \\\"{x:1705,y:882,t:1527271803231};\\\", \\\"{x:1703,y:882,t:1527271803246};\\\", \\\"{x:1697,y:885,t:1527271803263};\\\", \\\"{x:1686,y:912,t:1527271803281};\\\", \\\"{x:1681,y:930,t:1527271803297};\\\", \\\"{x:1676,y:942,t:1527271803314};\\\", \\\"{x:1672,y:952,t:1527271803330};\\\", \\\"{x:1672,y:958,t:1527271803347};\\\", \\\"{x:1672,y:960,t:1527271803363};\\\", \\\"{x:1672,y:961,t:1527271803380};\\\", \\\"{x:1673,y:962,t:1527271803457};\\\", \\\"{x:1674,y:963,t:1527271803465};\\\", \\\"{x:1679,y:968,t:1527271803481};\\\", \\\"{x:1685,y:972,t:1527271803497};\\\", \\\"{x:1687,y:974,t:1527271803514};\\\", \\\"{x:1687,y:976,t:1527271803537};\\\", \\\"{x:1687,y:977,t:1527271803568};\\\", \\\"{x:1687,y:978,t:1527271803580};\\\", \\\"{x:1685,y:978,t:1527271803597};\\\", \\\"{x:1679,y:978,t:1527271803614};\\\", \\\"{x:1669,y:980,t:1527271803630};\\\", \\\"{x:1663,y:981,t:1527271803647};\\\", \\\"{x:1652,y:984,t:1527271803665};\\\", \\\"{x:1650,y:985,t:1527271803681};\\\", \\\"{x:1650,y:987,t:1527271803698};\\\", \\\"{x:1661,y:992,t:1527271803715};\\\", \\\"{x:1676,y:993,t:1527271803731};\\\", \\\"{x:1684,y:993,t:1527271803747};\\\", \\\"{x:1689,y:993,t:1527271803764};\\\", \\\"{x:1690,y:993,t:1527271803781};\\\", \\\"{x:1689,y:992,t:1527271803800};\\\", \\\"{x:1685,y:990,t:1527271803814};\\\", \\\"{x:1673,y:989,t:1527271803832};\\\", \\\"{x:1656,y:987,t:1527271803848};\\\", \\\"{x:1632,y:983,t:1527271803864};\\\", \\\"{x:1615,y:980,t:1527271803882};\\\", \\\"{x:1601,y:979,t:1527271803898};\\\", \\\"{x:1591,y:977,t:1527271803915};\\\", \\\"{x:1588,y:977,t:1527271803932};\\\", \\\"{x:1586,y:977,t:1527271803948};\\\", \\\"{x:1587,y:976,t:1527271804017};\\\", \\\"{x:1588,y:976,t:1527271804096};\\\", \\\"{x:1589,y:975,t:1527271804104};\\\", \\\"{x:1591,y:974,t:1527271804114};\\\", \\\"{x:1593,y:973,t:1527271804132};\\\", \\\"{x:1596,y:971,t:1527271804148};\\\", \\\"{x:1599,y:969,t:1527271804165};\\\", \\\"{x:1601,y:968,t:1527271804182};\\\", \\\"{x:1603,y:966,t:1527271804199};\\\", \\\"{x:1604,y:966,t:1527271804216};\\\", \\\"{x:1605,y:965,t:1527271804231};\\\", \\\"{x:1606,y:965,t:1527271804248};\\\", \\\"{x:1607,y:965,t:1527271804265};\\\", \\\"{x:1608,y:965,t:1527271804281};\\\", \\\"{x:1609,y:964,t:1527271804298};\\\", \\\"{x:1610,y:963,t:1527271804416};\\\", \\\"{x:1611,y:962,t:1527271804433};\\\", \\\"{x:1611,y:959,t:1527271804449};\\\", \\\"{x:1611,y:958,t:1527271804465};\\\", \\\"{x:1611,y:956,t:1527271804483};\\\", \\\"{x:1612,y:956,t:1527271804499};\\\", \\\"{x:1612,y:955,t:1527271804515};\\\", \\\"{x:1613,y:953,t:1527271804533};\\\", \\\"{x:1613,y:952,t:1527271804552};\\\", \\\"{x:1614,y:951,t:1527271804566};\\\", \\\"{x:1614,y:953,t:1527271804840};\\\", \\\"{x:1614,y:954,t:1527271804849};\\\", \\\"{x:1614,y:960,t:1527271804867};\\\", \\\"{x:1614,y:963,t:1527271804882};\\\", \\\"{x:1614,y:966,t:1527271804899};\\\", \\\"{x:1614,y:967,t:1527271804916};\\\", \\\"{x:1614,y:969,t:1527271804932};\\\", \\\"{x:1614,y:968,t:1527271805625};\\\", \\\"{x:1614,y:967,t:1527271805633};\\\", \\\"{x:1614,y:961,t:1527271805651};\\\", \\\"{x:1614,y:956,t:1527271805668};\\\", \\\"{x:1614,y:953,t:1527271805684};\\\", \\\"{x:1614,y:949,t:1527271805701};\\\", \\\"{x:1614,y:946,t:1527271805718};\\\", \\\"{x:1614,y:944,t:1527271805733};\\\", \\\"{x:1614,y:942,t:1527271805751};\\\", \\\"{x:1614,y:935,t:1527271806065};\\\", \\\"{x:1614,y:921,t:1527271806072};\\\", \\\"{x:1614,y:910,t:1527271806084};\\\", \\\"{x:1614,y:892,t:1527271806102};\\\", \\\"{x:1614,y:877,t:1527271806118};\\\", \\\"{x:1614,y:865,t:1527271806134};\\\", \\\"{x:1614,y:859,t:1527271806151};\\\", \\\"{x:1614,y:853,t:1527271806167};\\\", \\\"{x:1614,y:851,t:1527271806185};\\\", \\\"{x:1614,y:850,t:1527271806217};\\\", \\\"{x:1614,y:849,t:1527271806241};\\\", \\\"{x:1614,y:847,t:1527271806251};\\\", \\\"{x:1614,y:845,t:1527271806269};\\\", \\\"{x:1615,y:840,t:1527271806286};\\\", \\\"{x:1615,y:837,t:1527271806302};\\\", \\\"{x:1616,y:833,t:1527271806319};\\\", \\\"{x:1618,y:826,t:1527271806335};\\\", \\\"{x:1618,y:823,t:1527271806352};\\\", \\\"{x:1618,y:818,t:1527271806369};\\\", \\\"{x:1618,y:817,t:1527271806385};\\\", \\\"{x:1618,y:816,t:1527271806401};\\\", \\\"{x:1618,y:815,t:1527271806418};\\\", \\\"{x:1618,y:814,t:1527271806435};\\\", \\\"{x:1618,y:811,t:1527271806452};\\\", \\\"{x:1618,y:809,t:1527271806468};\\\", \\\"{x:1618,y:808,t:1527271806486};\\\", \\\"{x:1618,y:806,t:1527271806502};\\\", \\\"{x:1618,y:803,t:1527271806519};\\\", \\\"{x:1618,y:799,t:1527271806537};\\\", \\\"{x:1617,y:798,t:1527271806551};\\\", \\\"{x:1612,y:790,t:1527271806568};\\\", \\\"{x:1610,y:786,t:1527271806585};\\\", \\\"{x:1608,y:783,t:1527271806601};\\\", \\\"{x:1605,y:779,t:1527271806618};\\\", \\\"{x:1602,y:774,t:1527271806635};\\\", \\\"{x:1598,y:768,t:1527271806651};\\\", \\\"{x:1594,y:764,t:1527271806668};\\\", \\\"{x:1591,y:757,t:1527271806685};\\\", \\\"{x:1586,y:750,t:1527271806702};\\\", \\\"{x:1582,y:742,t:1527271806718};\\\", \\\"{x:1575,y:731,t:1527271806735};\\\", \\\"{x:1564,y:717,t:1527271806751};\\\", \\\"{x:1558,y:708,t:1527271806768};\\\", \\\"{x:1549,y:696,t:1527271806785};\\\", \\\"{x:1545,y:689,t:1527271806802};\\\", \\\"{x:1542,y:684,t:1527271806818};\\\", \\\"{x:1538,y:675,t:1527271806836};\\\", \\\"{x:1533,y:669,t:1527271806853};\\\", \\\"{x:1531,y:666,t:1527271806869};\\\", \\\"{x:1530,y:663,t:1527271806886};\\\", \\\"{x:1527,y:658,t:1527271806902};\\\", \\\"{x:1523,y:653,t:1527271806919};\\\", \\\"{x:1518,y:646,t:1527271806937};\\\", \\\"{x:1516,y:644,t:1527271806952};\\\", \\\"{x:1514,y:641,t:1527271806970};\\\", \\\"{x:1512,y:639,t:1527271806986};\\\", \\\"{x:1511,y:637,t:1527271807002};\\\", \\\"{x:1509,y:635,t:1527271807020};\\\", \\\"{x:1509,y:633,t:1527271807040};\\\", \\\"{x:1508,y:632,t:1527271807056};\\\", \\\"{x:1508,y:633,t:1527271807297};\\\", \\\"{x:1508,y:634,t:1527271807328};\\\", \\\"{x:1508,y:635,t:1527271807392};\\\", \\\"{x:1508,y:636,t:1527271807404};\\\", \\\"{x:1508,y:637,t:1527271807420};\\\", \\\"{x:1508,y:639,t:1527271807513};\\\", \\\"{x:1508,y:640,t:1527271807520};\\\", \\\"{x:1508,y:641,t:1527271807539};\\\", \\\"{x:1508,y:644,t:1527271807553};\\\", \\\"{x:1508,y:646,t:1527271807575};\\\", \\\"{x:1508,y:648,t:1527271807586};\\\", \\\"{x:1508,y:651,t:1527271807603};\\\", \\\"{x:1509,y:655,t:1527271807620};\\\", \\\"{x:1510,y:658,t:1527271807636};\\\", \\\"{x:1511,y:661,t:1527271807653};\\\", \\\"{x:1511,y:664,t:1527271807670};\\\", \\\"{x:1511,y:665,t:1527271807686};\\\", \\\"{x:1513,y:668,t:1527271807703};\\\", \\\"{x:1514,y:672,t:1527271807719};\\\", \\\"{x:1515,y:676,t:1527271807737};\\\", \\\"{x:1517,y:682,t:1527271807753};\\\", \\\"{x:1517,y:683,t:1527271807770};\\\", \\\"{x:1518,y:686,t:1527271807787};\\\", \\\"{x:1518,y:688,t:1527271807816};\\\", \\\"{x:1518,y:689,t:1527271807840};\\\", \\\"{x:1518,y:690,t:1527271807855};\\\", \\\"{x:1518,y:692,t:1527271807871};\\\", \\\"{x:1520,y:696,t:1527271807888};\\\", \\\"{x:1520,y:699,t:1527271807904};\\\", \\\"{x:1520,y:705,t:1527271807921};\\\", \\\"{x:1520,y:709,t:1527271807938};\\\", \\\"{x:1520,y:712,t:1527271807954};\\\", \\\"{x:1520,y:716,t:1527271807970};\\\", \\\"{x:1520,y:719,t:1527271807987};\\\", \\\"{x:1520,y:724,t:1527271808004};\\\", \\\"{x:1521,y:727,t:1527271808020};\\\", \\\"{x:1521,y:731,t:1527271808037};\\\", \\\"{x:1521,y:733,t:1527271808054};\\\", \\\"{x:1521,y:734,t:1527271808071};\\\", \\\"{x:1521,y:736,t:1527271808087};\\\", \\\"{x:1521,y:737,t:1527271808104};\\\", \\\"{x:1521,y:739,t:1527271808121};\\\", \\\"{x:1521,y:741,t:1527271808138};\\\", \\\"{x:1521,y:742,t:1527271808155};\\\", \\\"{x:1521,y:745,t:1527271808170};\\\", \\\"{x:1521,y:746,t:1527271808188};\\\", \\\"{x:1521,y:747,t:1527271808205};\\\", \\\"{x:1521,y:748,t:1527271808224};\\\", \\\"{x:1521,y:749,t:1527271808238};\\\", \\\"{x:1521,y:750,t:1527271808256};\\\", \\\"{x:1521,y:751,t:1527271808272};\\\", \\\"{x:1521,y:752,t:1527271808287};\\\", \\\"{x:1522,y:755,t:1527271808305};\\\", \\\"{x:1522,y:756,t:1527271808321};\\\", \\\"{x:1522,y:758,t:1527271808338};\\\", \\\"{x:1522,y:759,t:1527271808355};\\\", \\\"{x:1523,y:762,t:1527271808371};\\\", \\\"{x:1523,y:764,t:1527271808388};\\\", \\\"{x:1523,y:765,t:1527271808404};\\\", \\\"{x:1523,y:767,t:1527271808422};\\\", \\\"{x:1523,y:769,t:1527271808438};\\\", \\\"{x:1523,y:770,t:1527271808455};\\\", \\\"{x:1523,y:772,t:1527271808471};\\\", \\\"{x:1524,y:775,t:1527271808489};\\\", \\\"{x:1524,y:777,t:1527271808505};\\\", \\\"{x:1524,y:778,t:1527271808522};\\\", \\\"{x:1524,y:780,t:1527271808539};\\\", \\\"{x:1524,y:782,t:1527271808554};\\\", \\\"{x:1525,y:786,t:1527271808572};\\\", \\\"{x:1525,y:790,t:1527271808588};\\\", \\\"{x:1525,y:791,t:1527271808604};\\\", \\\"{x:1525,y:794,t:1527271808621};\\\", \\\"{x:1525,y:796,t:1527271808638};\\\", \\\"{x:1525,y:797,t:1527271808654};\\\", \\\"{x:1525,y:799,t:1527271808672};\\\", \\\"{x:1525,y:802,t:1527271808688};\\\", \\\"{x:1525,y:804,t:1527271808705};\\\", \\\"{x:1525,y:806,t:1527271808721};\\\", \\\"{x:1525,y:807,t:1527271808744};\\\", \\\"{x:1525,y:802,t:1527271808880};\\\", \\\"{x:1525,y:790,t:1527271808889};\\\", \\\"{x:1525,y:767,t:1527271808905};\\\", \\\"{x:1525,y:741,t:1527271808923};\\\", \\\"{x:1525,y:714,t:1527271808939};\\\", \\\"{x:1525,y:687,t:1527271808955};\\\", \\\"{x:1526,y:669,t:1527271808972};\\\", \\\"{x:1528,y:658,t:1527271808988};\\\", \\\"{x:1528,y:655,t:1527271809006};\\\", \\\"{x:1528,y:652,t:1527271809022};\\\", \\\"{x:1528,y:650,t:1527271809038};\\\", \\\"{x:1528,y:648,t:1527271809055};\\\", \\\"{x:1528,y:645,t:1527271809072};\\\", \\\"{x:1527,y:644,t:1527271809088};\\\", \\\"{x:1527,y:642,t:1527271809105};\\\", \\\"{x:1526,y:641,t:1527271809122};\\\", \\\"{x:1525,y:639,t:1527271809139};\\\", \\\"{x:1524,y:638,t:1527271809160};\\\", \\\"{x:1524,y:637,t:1527271809173};\\\", \\\"{x:1524,y:636,t:1527271809189};\\\", \\\"{x:1523,y:635,t:1527271809206};\\\", \\\"{x:1522,y:635,t:1527271809224};\\\", \\\"{x:1521,y:634,t:1527271809256};\\\", \\\"{x:1520,y:634,t:1527271810584};\\\", \\\"{x:1517,y:634,t:1527271810595};\\\", \\\"{x:1507,y:636,t:1527271810608};\\\", \\\"{x:1492,y:638,t:1527271810624};\\\", \\\"{x:1476,y:638,t:1527271810641};\\\", \\\"{x:1461,y:639,t:1527271810657};\\\", \\\"{x:1454,y:639,t:1527271810675};\\\", \\\"{x:1453,y:639,t:1527271810691};\\\", \\\"{x:1454,y:639,t:1527271810783};\\\", \\\"{x:1457,y:639,t:1527271810791};\\\", \\\"{x:1460,y:639,t:1527271810808};\\\", \\\"{x:1466,y:639,t:1527271810825};\\\", \\\"{x:1471,y:638,t:1527271810841};\\\", \\\"{x:1475,y:637,t:1527271810858};\\\", \\\"{x:1477,y:637,t:1527271810874};\\\", \\\"{x:1478,y:637,t:1527271810952};\\\", \\\"{x:1479,y:636,t:1527271810959};\\\", \\\"{x:1480,y:636,t:1527271810983};\\\", \\\"{x:1481,y:635,t:1527271810991};\\\", \\\"{x:1482,y:635,t:1527271811008};\\\", \\\"{x:1485,y:635,t:1527271811026};\\\", \\\"{x:1487,y:635,t:1527271811056};\\\", \\\"{x:1488,y:635,t:1527271811072};\\\", \\\"{x:1491,y:635,t:1527271811079};\\\", \\\"{x:1492,y:635,t:1527271811092};\\\", \\\"{x:1495,y:635,t:1527271811109};\\\", \\\"{x:1498,y:647,t:1527271811126};\\\", \\\"{x:1504,y:673,t:1527271811142};\\\", \\\"{x:1513,y:716,t:1527271811159};\\\", \\\"{x:1516,y:768,t:1527271811175};\\\", \\\"{x:1516,y:787,t:1527271811191};\\\", \\\"{x:1516,y:794,t:1527271811208};\\\", \\\"{x:1516,y:799,t:1527271811226};\\\", \\\"{x:1516,y:805,t:1527271811242};\\\", \\\"{x:1516,y:814,t:1527271811259};\\\", \\\"{x:1516,y:825,t:1527271811276};\\\", \\\"{x:1516,y:836,t:1527271811293};\\\", \\\"{x:1516,y:846,t:1527271811309};\\\", \\\"{x:1513,y:852,t:1527271811326};\\\", \\\"{x:1513,y:855,t:1527271811343};\\\", \\\"{x:1512,y:856,t:1527271811358};\\\", \\\"{x:1509,y:858,t:1527271811377};\\\", \\\"{x:1502,y:858,t:1527271811392};\\\", \\\"{x:1495,y:858,t:1527271811410};\\\", \\\"{x:1491,y:858,t:1527271811426};\\\", \\\"{x:1482,y:851,t:1527271811443};\\\", \\\"{x:1472,y:843,t:1527271811459};\\\", \\\"{x:1469,y:840,t:1527271811475};\\\", \\\"{x:1468,y:838,t:1527271811493};\\\", \\\"{x:1467,y:836,t:1527271811510};\\\", \\\"{x:1467,y:835,t:1527271811526};\\\", \\\"{x:1467,y:832,t:1527271811543};\\\", \\\"{x:1467,y:829,t:1527271811560};\\\", \\\"{x:1467,y:827,t:1527271811681};\\\", \\\"{x:1467,y:826,t:1527271811712};\\\", \\\"{x:1467,y:825,t:1527271811737};\\\", \\\"{x:1468,y:825,t:1527271811752};\\\", \\\"{x:1469,y:825,t:1527271811769};\\\", \\\"{x:1470,y:824,t:1527271812153};\\\", \\\"{x:1471,y:824,t:1527271812176};\\\", \\\"{x:1472,y:823,t:1527271812194};\\\", \\\"{x:1473,y:823,t:1527271812224};\\\", \\\"{x:1474,y:823,t:1527271812240};\\\", \\\"{x:1476,y:823,t:1527271812264};\\\", \\\"{x:1476,y:824,t:1527271812401};\\\", \\\"{x:1479,y:825,t:1527271812793};\\\", \\\"{x:1486,y:831,t:1527271812812};\\\", \\\"{x:1492,y:836,t:1527271812829};\\\", \\\"{x:1497,y:841,t:1527271812845};\\\", \\\"{x:1502,y:845,t:1527271812861};\\\", \\\"{x:1506,y:847,t:1527271812878};\\\", \\\"{x:1505,y:847,t:1527271813064};\\\", \\\"{x:1502,y:846,t:1527271813079};\\\", \\\"{x:1497,y:844,t:1527271813095};\\\", \\\"{x:1490,y:842,t:1527271813113};\\\", \\\"{x:1488,y:842,t:1527271813128};\\\", \\\"{x:1487,y:842,t:1527271813145};\\\", \\\"{x:1486,y:841,t:1527271813163};\\\", \\\"{x:1484,y:841,t:1527271813807};\\\", \\\"{x:1471,y:840,t:1527271813815};\\\", \\\"{x:1448,y:837,t:1527271813830};\\\", \\\"{x:1364,y:822,t:1527271813845};\\\", \\\"{x:1250,y:808,t:1527271813863};\\\", \\\"{x:1030,y:776,t:1527271813879};\\\", \\\"{x:853,y:749,t:1527271813896};\\\", \\\"{x:684,y:722,t:1527271813912};\\\", \\\"{x:550,y:699,t:1527271813930};\\\", \\\"{x:450,y:669,t:1527271813947};\\\", \\\"{x:367,y:646,t:1527271813963};\\\", \\\"{x:311,y:626,t:1527271813979};\\\", \\\"{x:285,y:614,t:1527271813996};\\\", \\\"{x:279,y:608,t:1527271814020};\\\", \\\"{x:279,y:606,t:1527271814036};\\\", \\\"{x:283,y:602,t:1527271814053};\\\", \\\"{x:284,y:601,t:1527271814071};\\\", \\\"{x:284,y:597,t:1527271814086};\\\", \\\"{x:284,y:595,t:1527271814103};\\\", \\\"{x:284,y:594,t:1527271814120};\\\", \\\"{x:284,y:593,t:1527271814143};\\\", \\\"{x:284,y:592,t:1527271814153};\\\", \\\"{x:286,y:590,t:1527271814170};\\\", \\\"{x:303,y:588,t:1527271814187};\\\", \\\"{x:332,y:585,t:1527271814203};\\\", \\\"{x:376,y:585,t:1527271814221};\\\", \\\"{x:438,y:585,t:1527271814237};\\\", \\\"{x:510,y:585,t:1527271814254};\\\", \\\"{x:569,y:585,t:1527271814270};\\\", \\\"{x:610,y:588,t:1527271814286};\\\", \\\"{x:650,y:593,t:1527271814304};\\\", \\\"{x:661,y:594,t:1527271814320};\\\", \\\"{x:663,y:594,t:1527271814337};\\\", \\\"{x:664,y:595,t:1527271814354};\\\", \\\"{x:664,y:593,t:1527271814455};\\\", \\\"{x:661,y:593,t:1527271814471};\\\", \\\"{x:652,y:593,t:1527271814487};\\\", \\\"{x:638,y:593,t:1527271814503};\\\", \\\"{x:624,y:593,t:1527271814520};\\\", \\\"{x:616,y:592,t:1527271814536};\\\", \\\"{x:613,y:592,t:1527271814553};\\\", \\\"{x:612,y:592,t:1527271814570};\\\", \\\"{x:612,y:593,t:1527271814839};\\\", \\\"{x:606,y:595,t:1527271814854};\\\", \\\"{x:578,y:600,t:1527271814871};\\\", \\\"{x:513,y:610,t:1527271814887};\\\", \\\"{x:462,y:612,t:1527271814904};\\\", \\\"{x:417,y:612,t:1527271814920};\\\", \\\"{x:381,y:612,t:1527271814937};\\\", \\\"{x:351,y:612,t:1527271814954};\\\", \\\"{x:329,y:612,t:1527271814970};\\\", \\\"{x:309,y:612,t:1527271814987};\\\", \\\"{x:293,y:612,t:1527271815003};\\\", \\\"{x:280,y:612,t:1527271815020};\\\", \\\"{x:265,y:612,t:1527271815037};\\\", \\\"{x:246,y:612,t:1527271815054};\\\", \\\"{x:224,y:612,t:1527271815070};\\\", \\\"{x:198,y:612,t:1527271815087};\\\", \\\"{x:182,y:612,t:1527271815104};\\\", \\\"{x:171,y:610,t:1527271815120};\\\", \\\"{x:169,y:609,t:1527271815137};\\\", \\\"{x:168,y:608,t:1527271815154};\\\", \\\"{x:167,y:607,t:1527271815170};\\\", \\\"{x:166,y:607,t:1527271815223};\\\", \\\"{x:164,y:607,t:1527271815237};\\\", \\\"{x:157,y:607,t:1527271815254};\\\", \\\"{x:149,y:605,t:1527271815270};\\\", \\\"{x:138,y:596,t:1527271815287};\\\", \\\"{x:136,y:587,t:1527271815304};\\\", \\\"{x:136,y:583,t:1527271815321};\\\", \\\"{x:136,y:580,t:1527271815338};\\\", \\\"{x:136,y:579,t:1527271815354};\\\", \\\"{x:137,y:578,t:1527271815372};\\\", \\\"{x:138,y:577,t:1527271815512};\\\", \\\"{x:138,y:576,t:1527271815576};\\\", \\\"{x:139,y:575,t:1527271815599};\\\", \\\"{x:140,y:575,t:1527271815631};\\\", \\\"{x:141,y:575,t:1527271815663};\\\", \\\"{x:142,y:574,t:1527271815671};\\\", \\\"{x:143,y:574,t:1527271815696};\\\", \\\"{x:144,y:573,t:1527271815759};\\\", \\\"{x:145,y:572,t:1527271815775};\\\", \\\"{x:146,y:572,t:1527271815800};\\\", \\\"{x:147,y:572,t:1527271815808};\\\", \\\"{x:148,y:572,t:1527271815824};\\\", \\\"{x:149,y:571,t:1527271816137};\\\", \\\"{x:149,y:570,t:1527271816145};\\\", \\\"{x:150,y:569,t:1527271816156};\\\", \\\"{x:150,y:568,t:1527271816191};\\\", \\\"{x:151,y:568,t:1527271816199};\\\", \\\"{x:152,y:568,t:1527271816231};\\\", \\\"{x:153,y:568,t:1527271816272};\\\", \\\"{x:153,y:568,t:1527271816301};\\\", \\\"{x:154,y:568,t:1527271816569};\\\", \\\"{x:161,y:568,t:1527271816576};\\\", \\\"{x:177,y:568,t:1527271816589};\\\", \\\"{x:275,y:573,t:1527271816607};\\\", \\\"{x:422,y:594,t:1527271816624};\\\", \\\"{x:600,y:605,t:1527271816640};\\\", \\\"{x:857,y:605,t:1527271816656};\\\", \\\"{x:1015,y:605,t:1527271816673};\\\", \\\"{x:1142,y:605,t:1527271816688};\\\", \\\"{x:1206,y:605,t:1527271816706};\\\", \\\"{x:1223,y:605,t:1527271816723};\\\", \\\"{x:1234,y:605,t:1527271816738};\\\", \\\"{x:1237,y:605,t:1527271816755};\\\", \\\"{x:1238,y:605,t:1527271816773};\\\", \\\"{x:1239,y:605,t:1527271816788};\\\", \\\"{x:1239,y:607,t:1527271816808};\\\", \\\"{x:1236,y:611,t:1527271816823};\\\", \\\"{x:1227,y:624,t:1527271816839};\\\", \\\"{x:1224,y:650,t:1527271816856};\\\", \\\"{x:1222,y:684,t:1527271816873};\\\", \\\"{x:1222,y:714,t:1527271816889};\\\", \\\"{x:1229,y:745,t:1527271816906};\\\", \\\"{x:1239,y:758,t:1527271816923};\\\", \\\"{x:1240,y:758,t:1527271817264};\\\", \\\"{x:1243,y:758,t:1527271817273};\\\", \\\"{x:1269,y:762,t:1527271817289};\\\", \\\"{x:1303,y:764,t:1527271817306};\\\", \\\"{x:1361,y:771,t:1527271817323};\\\", \\\"{x:1445,y:786,t:1527271817339};\\\", \\\"{x:1537,y:797,t:1527271817356};\\\", \\\"{x:1617,y:808,t:1527271817372};\\\", \\\"{x:1675,y:821,t:1527271817388};\\\", \\\"{x:1711,y:832,t:1527271817406};\\\", \\\"{x:1740,y:841,t:1527271817422};\\\", \\\"{x:1754,y:847,t:1527271817438};\\\", \\\"{x:1758,y:850,t:1527271817455};\\\", \\\"{x:1759,y:851,t:1527271817473};\\\", \\\"{x:1747,y:851,t:1527271817488};\\\", \\\"{x:1728,y:851,t:1527271817505};\\\", \\\"{x:1705,y:851,t:1527271817523};\\\", \\\"{x:1682,y:851,t:1527271817539};\\\", \\\"{x:1658,y:851,t:1527271817555};\\\", \\\"{x:1629,y:851,t:1527271817572};\\\", \\\"{x:1601,y:851,t:1527271817589};\\\", \\\"{x:1579,y:851,t:1527271817606};\\\", \\\"{x:1564,y:851,t:1527271817623};\\\", \\\"{x:1555,y:851,t:1527271817639};\\\", \\\"{x:1543,y:851,t:1527271817656};\\\", \\\"{x:1538,y:851,t:1527271817672};\\\", \\\"{x:1533,y:851,t:1527271817688};\\\", \\\"{x:1527,y:850,t:1527271817706};\\\", \\\"{x:1519,y:850,t:1527271817723};\\\", \\\"{x:1511,y:850,t:1527271817739};\\\", \\\"{x:1503,y:850,t:1527271817755};\\\", \\\"{x:1499,y:849,t:1527271817773};\\\", \\\"{x:1494,y:848,t:1527271817788};\\\", \\\"{x:1489,y:846,t:1527271817805};\\\", \\\"{x:1485,y:845,t:1527271817823};\\\", \\\"{x:1480,y:843,t:1527271817839};\\\", \\\"{x:1469,y:841,t:1527271817855};\\\", \\\"{x:1459,y:837,t:1527271817873};\\\", \\\"{x:1446,y:834,t:1527271817889};\\\", \\\"{x:1430,y:830,t:1527271817906};\\\", \\\"{x:1417,y:826,t:1527271817924};\\\", \\\"{x:1409,y:823,t:1527271817939};\\\", \\\"{x:1405,y:823,t:1527271817956};\\\", \\\"{x:1403,y:821,t:1527271817973};\\\", \\\"{x:1400,y:817,t:1527271817989};\\\", \\\"{x:1399,y:815,t:1527271818006};\\\", \\\"{x:1398,y:812,t:1527271818023};\\\", \\\"{x:1397,y:809,t:1527271818039};\\\", \\\"{x:1397,y:803,t:1527271818056};\\\", \\\"{x:1397,y:799,t:1527271818072};\\\", \\\"{x:1397,y:795,t:1527271818089};\\\", \\\"{x:1397,y:789,t:1527271818106};\\\", \\\"{x:1397,y:784,t:1527271818124};\\\", \\\"{x:1397,y:778,t:1527271818139};\\\", \\\"{x:1397,y:777,t:1527271818156};\\\", \\\"{x:1397,y:775,t:1527271818174};\\\", \\\"{x:1397,y:774,t:1527271818189};\\\", \\\"{x:1396,y:773,t:1527271818206};\\\", \\\"{x:1395,y:773,t:1527271818223};\\\", \\\"{x:1393,y:773,t:1527271818240};\\\", \\\"{x:1390,y:771,t:1527271818257};\\\", \\\"{x:1389,y:771,t:1527271818273};\\\", \\\"{x:1388,y:771,t:1527271818344};\\\", \\\"{x:1387,y:770,t:1527271818376};\\\", \\\"{x:1386,y:769,t:1527271818392};\\\", \\\"{x:1386,y:768,t:1527271818448};\\\", \\\"{x:1385,y:768,t:1527271818464};\\\", \\\"{x:1385,y:769,t:1527271820042};\\\", \\\"{x:1385,y:770,t:1527271820049};\\\", \\\"{x:1385,y:772,t:1527271820065};\\\", \\\"{x:1385,y:774,t:1527271820082};\\\", \\\"{x:1385,y:775,t:1527271820098};\\\", \\\"{x:1385,y:776,t:1527271820115};\\\", \\\"{x:1385,y:777,t:1527271820132};\\\", \\\"{x:1385,y:778,t:1527271820148};\\\", \\\"{x:1385,y:780,t:1527271820165};\\\", \\\"{x:1385,y:781,t:1527271820182};\\\", \\\"{x:1385,y:783,t:1527271820198};\\\", \\\"{x:1386,y:784,t:1527271820215};\\\", \\\"{x:1386,y:786,t:1527271820232};\\\", \\\"{x:1386,y:787,t:1527271820248};\\\", \\\"{x:1386,y:791,t:1527271820264};\\\", \\\"{x:1386,y:795,t:1527271820282};\\\", \\\"{x:1386,y:799,t:1527271820298};\\\", \\\"{x:1386,y:803,t:1527271820315};\\\", \\\"{x:1386,y:806,t:1527271820332};\\\", \\\"{x:1386,y:807,t:1527271820348};\\\", \\\"{x:1386,y:810,t:1527271820365};\\\", \\\"{x:1386,y:812,t:1527271820382};\\\", \\\"{x:1386,y:814,t:1527271820398};\\\", \\\"{x:1386,y:817,t:1527271820415};\\\", \\\"{x:1386,y:822,t:1527271820431};\\\", \\\"{x:1386,y:829,t:1527271820448};\\\", \\\"{x:1386,y:842,t:1527271820465};\\\", \\\"{x:1386,y:849,t:1527271820482};\\\", \\\"{x:1386,y:854,t:1527271820498};\\\", \\\"{x:1386,y:860,t:1527271820516};\\\", \\\"{x:1386,y:867,t:1527271820531};\\\", \\\"{x:1386,y:875,t:1527271820548};\\\", \\\"{x:1386,y:882,t:1527271820566};\\\", \\\"{x:1386,y:889,t:1527271820582};\\\", \\\"{x:1386,y:895,t:1527271820598};\\\", \\\"{x:1387,y:900,t:1527271820615};\\\", \\\"{x:1387,y:904,t:1527271820632};\\\", \\\"{x:1387,y:909,t:1527271820648};\\\", \\\"{x:1389,y:915,t:1527271820665};\\\", \\\"{x:1390,y:920,t:1527271820683};\\\", \\\"{x:1390,y:924,t:1527271820698};\\\", \\\"{x:1390,y:928,t:1527271820716};\\\", \\\"{x:1391,y:931,t:1527271820732};\\\", \\\"{x:1391,y:935,t:1527271820749};\\\", \\\"{x:1391,y:936,t:1527271820770};\\\", \\\"{x:1391,y:934,t:1527271820850};\\\", \\\"{x:1391,y:923,t:1527271820865};\\\", \\\"{x:1391,y:913,t:1527271820882};\\\", \\\"{x:1391,y:900,t:1527271820898};\\\", \\\"{x:1391,y:890,t:1527271820915};\\\", \\\"{x:1391,y:880,t:1527271820933};\\\", \\\"{x:1391,y:866,t:1527271820949};\\\", \\\"{x:1391,y:847,t:1527271820966};\\\", \\\"{x:1388,y:826,t:1527271820982};\\\", \\\"{x:1387,y:814,t:1527271820999};\\\", \\\"{x:1386,y:805,t:1527271821015};\\\", \\\"{x:1384,y:800,t:1527271821031};\\\", \\\"{x:1384,y:796,t:1527271821049};\\\", \\\"{x:1384,y:790,t:1527271821065};\\\", \\\"{x:1384,y:783,t:1527271821082};\\\", \\\"{x:1382,y:775,t:1527271821098};\\\", \\\"{x:1382,y:769,t:1527271821115};\\\", \\\"{x:1380,y:764,t:1527271821132};\\\", \\\"{x:1380,y:762,t:1527271821148};\\\", \\\"{x:1380,y:760,t:1527271821165};\\\", \\\"{x:1380,y:759,t:1527271821182};\\\", \\\"{x:1380,y:757,t:1527271821199};\\\", \\\"{x:1380,y:754,t:1527271821215};\\\", \\\"{x:1380,y:752,t:1527271821231};\\\", \\\"{x:1380,y:751,t:1527271821248};\\\", \\\"{x:1380,y:754,t:1527271821458};\\\", \\\"{x:1380,y:756,t:1527271821465};\\\", \\\"{x:1380,y:758,t:1527271821483};\\\", \\\"{x:1380,y:761,t:1527271821498};\\\", \\\"{x:1380,y:765,t:1527271821515};\\\", \\\"{x:1380,y:770,t:1527271821532};\\\", \\\"{x:1380,y:774,t:1527271821549};\\\", \\\"{x:1380,y:778,t:1527271821565};\\\", \\\"{x:1380,y:782,t:1527271821582};\\\", \\\"{x:1380,y:788,t:1527271821599};\\\", \\\"{x:1380,y:794,t:1527271821616};\\\", \\\"{x:1380,y:806,t:1527271821631};\\\", \\\"{x:1377,y:816,t:1527271821649};\\\", \\\"{x:1373,y:833,t:1527271821665};\\\", \\\"{x:1369,y:839,t:1527271821683};\\\", \\\"{x:1365,y:846,t:1527271821699};\\\", \\\"{x:1362,y:850,t:1527271821716};\\\", \\\"{x:1361,y:853,t:1527271821732};\\\", \\\"{x:1359,y:856,t:1527271821749};\\\", \\\"{x:1359,y:859,t:1527271821766};\\\", \\\"{x:1358,y:859,t:1527271821782};\\\", \\\"{x:1358,y:861,t:1527271821798};\\\", \\\"{x:1357,y:862,t:1527271821815};\\\", \\\"{x:1356,y:866,t:1527271821832};\\\", \\\"{x:1355,y:867,t:1527271821850};\\\", \\\"{x:1355,y:868,t:1527271821865};\\\", \\\"{x:1355,y:869,t:1527271821882};\\\", \\\"{x:1355,y:871,t:1527271821898};\\\", \\\"{x:1354,y:871,t:1527271821915};\\\", \\\"{x:1354,y:872,t:1527271821932};\\\", \\\"{x:1354,y:871,t:1527271822041};\\\", \\\"{x:1354,y:867,t:1527271822049};\\\", \\\"{x:1358,y:853,t:1527271822065};\\\", \\\"{x:1362,y:838,t:1527271822083};\\\", \\\"{x:1367,y:821,t:1527271822099};\\\", \\\"{x:1371,y:805,t:1527271822116};\\\", \\\"{x:1374,y:796,t:1527271822131};\\\", \\\"{x:1376,y:792,t:1527271822148};\\\", \\\"{x:1376,y:789,t:1527271822165};\\\", \\\"{x:1376,y:788,t:1527271822181};\\\", \\\"{x:1377,y:785,t:1527271822198};\\\", \\\"{x:1380,y:777,t:1527271822215};\\\", \\\"{x:1380,y:773,t:1527271822231};\\\", \\\"{x:1382,y:766,t:1527271822248};\\\", \\\"{x:1383,y:762,t:1527271822264};\\\", \\\"{x:1383,y:760,t:1527271822281};\\\", \\\"{x:1383,y:759,t:1527271822298};\\\", \\\"{x:1383,y:757,t:1527271822316};\\\", \\\"{x:1383,y:753,t:1527271822331};\\\", \\\"{x:1383,y:749,t:1527271822348};\\\", \\\"{x:1383,y:742,t:1527271822365};\\\", \\\"{x:1383,y:736,t:1527271822382};\\\", \\\"{x:1383,y:729,t:1527271822398};\\\", \\\"{x:1383,y:718,t:1527271822416};\\\", \\\"{x:1383,y:701,t:1527271822432};\\\", \\\"{x:1383,y:683,t:1527271822448};\\\", \\\"{x:1385,y:655,t:1527271822465};\\\", \\\"{x:1389,y:630,t:1527271822482};\\\", \\\"{x:1392,y:608,t:1527271822498};\\\", \\\"{x:1396,y:593,t:1527271822516};\\\", \\\"{x:1398,y:587,t:1527271822532};\\\", \\\"{x:1399,y:584,t:1527271822549};\\\", \\\"{x:1401,y:580,t:1527271822566};\\\", \\\"{x:1402,y:577,t:1527271822581};\\\", \\\"{x:1405,y:574,t:1527271822598};\\\", \\\"{x:1408,y:570,t:1527271822615};\\\", \\\"{x:1411,y:567,t:1527271822632};\\\", \\\"{x:1414,y:562,t:1527271822649};\\\", \\\"{x:1415,y:560,t:1527271822665};\\\", \\\"{x:1416,y:559,t:1527271822681};\\\", \\\"{x:1417,y:559,t:1527271822698};\\\", \\\"{x:1417,y:558,t:1527271822715};\\\", \\\"{x:1417,y:562,t:1527271823017};\\\", \\\"{x:1417,y:563,t:1527271823031};\\\", \\\"{x:1417,y:565,t:1527271823049};\\\", \\\"{x:1417,y:566,t:1527271823073};\\\", \\\"{x:1417,y:568,t:1527271823090};\\\", \\\"{x:1417,y:569,t:1527271823100};\\\", \\\"{x:1418,y:570,t:1527271823116};\\\", \\\"{x:1418,y:571,t:1527271823132};\\\", \\\"{x:1418,y:570,t:1527271823385};\\\", \\\"{x:1418,y:569,t:1527271823399};\\\", \\\"{x:1418,y:568,t:1527271823416};\\\", \\\"{x:1417,y:568,t:1527271823993};\\\", \\\"{x:1416,y:568,t:1527271824041};\\\", \\\"{x:1415,y:568,t:1527271824057};\\\", \\\"{x:1414,y:570,t:1527271824065};\\\", \\\"{x:1411,y:572,t:1527271824081};\\\", \\\"{x:1405,y:577,t:1527271824098};\\\", \\\"{x:1394,y:585,t:1527271824115};\\\", \\\"{x:1387,y:592,t:1527271824132};\\\", \\\"{x:1376,y:601,t:1527271824148};\\\", \\\"{x:1366,y:608,t:1527271824166};\\\", \\\"{x:1356,y:617,t:1527271824182};\\\", \\\"{x:1346,y:624,t:1527271824198};\\\", \\\"{x:1342,y:629,t:1527271824216};\\\", \\\"{x:1339,y:631,t:1527271824232};\\\", \\\"{x:1336,y:635,t:1527271824248};\\\", \\\"{x:1332,y:639,t:1527271824265};\\\", \\\"{x:1331,y:642,t:1527271824282};\\\", \\\"{x:1328,y:644,t:1527271824299};\\\", \\\"{x:1325,y:646,t:1527271824316};\\\", \\\"{x:1323,y:647,t:1527271824332};\\\", \\\"{x:1322,y:648,t:1527271824349};\\\", \\\"{x:1320,y:648,t:1527271824366};\\\", \\\"{x:1318,y:648,t:1527271824382};\\\", \\\"{x:1317,y:649,t:1527271824399};\\\", \\\"{x:1316,y:649,t:1527271824434};\\\", \\\"{x:1315,y:649,t:1527271824448};\\\", \\\"{x:1313,y:645,t:1527271824465};\\\", \\\"{x:1312,y:642,t:1527271824482};\\\", \\\"{x:1312,y:638,t:1527271824499};\\\", \\\"{x:1311,y:635,t:1527271824516};\\\", \\\"{x:1311,y:633,t:1527271824532};\\\", \\\"{x:1310,y:632,t:1527271824549};\\\", \\\"{x:1309,y:631,t:1527271824849};\\\", \\\"{x:1309,y:632,t:1527271825866};\\\", \\\"{x:1309,y:633,t:1527271826363};\\\", \\\"{x:1310,y:633,t:1527271826378};\\\", \\\"{x:1313,y:633,t:1527271826398};\\\", \\\"{x:1315,y:633,t:1527271826416};\\\", \\\"{x:1319,y:633,t:1527271826431};\\\", \\\"{x:1321,y:633,t:1527271826450};\\\", \\\"{x:1329,y:633,t:1527271826466};\\\", \\\"{x:1335,y:633,t:1527271826482};\\\", \\\"{x:1344,y:633,t:1527271826498};\\\", \\\"{x:1350,y:633,t:1527271826515};\\\", \\\"{x:1355,y:633,t:1527271826532};\\\", \\\"{x:1358,y:633,t:1527271826548};\\\", \\\"{x:1360,y:633,t:1527271826565};\\\", \\\"{x:1362,y:633,t:1527271827122};\\\", \\\"{x:1363,y:632,t:1527271827137};\\\", \\\"{x:1364,y:632,t:1527271827148};\\\", \\\"{x:1367,y:632,t:1527271827166};\\\", \\\"{x:1371,y:631,t:1527271827181};\\\", \\\"{x:1377,y:631,t:1527271827199};\\\", \\\"{x:1381,y:631,t:1527271827216};\\\", \\\"{x:1383,y:629,t:1527271827231};\\\", \\\"{x:1384,y:629,t:1527271827249};\\\", \\\"{x:1385,y:629,t:1527271827482};\\\", \\\"{x:1387,y:629,t:1527271827499};\\\", \\\"{x:1397,y:629,t:1527271827516};\\\", \\\"{x:1414,y:629,t:1527271827532};\\\", \\\"{x:1433,y:629,t:1527271827548};\\\", \\\"{x:1451,y:629,t:1527271827565};\\\", \\\"{x:1460,y:629,t:1527271827582};\\\", \\\"{x:1467,y:629,t:1527271827598};\\\", \\\"{x:1466,y:629,t:1527271827713};\\\", \\\"{x:1464,y:629,t:1527271827721};\\\", \\\"{x:1461,y:629,t:1527271827732};\\\", \\\"{x:1459,y:628,t:1527271827749};\\\", \\\"{x:1458,y:628,t:1527271827765};\\\", \\\"{x:1460,y:628,t:1527271827849};\\\", \\\"{x:1470,y:628,t:1527271827865};\\\", \\\"{x:1486,y:628,t:1527271827882};\\\", \\\"{x:1502,y:628,t:1527271827898};\\\", \\\"{x:1518,y:628,t:1527271827916};\\\", \\\"{x:1528,y:628,t:1527271827932};\\\", \\\"{x:1532,y:628,t:1527271827949};\\\", \\\"{x:1530,y:628,t:1527271828161};\\\", \\\"{x:1529,y:628,t:1527271828177};\\\", \\\"{x:1528,y:628,t:1527271828225};\\\", \\\"{x:1527,y:628,t:1527271828234};\\\", \\\"{x:1522,y:628,t:1527271828249};\\\", \\\"{x:1514,y:628,t:1527271828265};\\\", \\\"{x:1508,y:628,t:1527271828283};\\\", \\\"{x:1503,y:628,t:1527271828299};\\\", \\\"{x:1499,y:628,t:1527271828316};\\\", \\\"{x:1496,y:628,t:1527271828332};\\\", \\\"{x:1495,y:628,t:1527271828505};\\\", \\\"{x:1499,y:629,t:1527271829282};\\\", \\\"{x:1509,y:630,t:1527271829299};\\\", \\\"{x:1520,y:631,t:1527271829316};\\\", \\\"{x:1534,y:633,t:1527271829333};\\\", \\\"{x:1543,y:634,t:1527271829349};\\\", \\\"{x:1549,y:634,t:1527271829366};\\\", \\\"{x:1552,y:634,t:1527271829382};\\\", \\\"{x:1553,y:634,t:1527271829399};\\\", \\\"{x:1554,y:634,t:1527271829529};\\\", \\\"{x:1555,y:634,t:1527271829537};\\\", \\\"{x:1557,y:634,t:1527271829549};\\\", \\\"{x:1560,y:633,t:1527271829566};\\\", \\\"{x:1563,y:633,t:1527271829582};\\\", \\\"{x:1564,y:632,t:1527271829599};\\\", \\\"{x:1567,y:631,t:1527271829618};\\\", \\\"{x:1568,y:631,t:1527271829634};\\\", \\\"{x:1570,y:630,t:1527271829649};\\\", \\\"{x:1579,y:630,t:1527271829665};\\\", \\\"{x:1595,y:630,t:1527271829682};\\\", \\\"{x:1616,y:630,t:1527271829699};\\\", \\\"{x:1635,y:630,t:1527271829716};\\\", \\\"{x:1647,y:630,t:1527271829732};\\\", \\\"{x:1652,y:630,t:1527271829749};\\\", \\\"{x:1648,y:630,t:1527271831178};\\\", \\\"{x:1641,y:632,t:1527271831186};\\\", \\\"{x:1630,y:636,t:1527271831199};\\\", \\\"{x:1600,y:642,t:1527271831216};\\\", \\\"{x:1550,y:648,t:1527271831232};\\\", \\\"{x:1421,y:652,t:1527271831249};\\\", \\\"{x:1315,y:658,t:1527271831265};\\\", \\\"{x:1192,y:660,t:1527271831282};\\\", \\\"{x:1081,y:678,t:1527271831299};\\\", \\\"{x:968,y:692,t:1527271831316};\\\", \\\"{x:873,y:708,t:1527271831331};\\\", \\\"{x:800,y:718,t:1527271831349};\\\", \\\"{x:747,y:726,t:1527271831365};\\\", \\\"{x:715,y:731,t:1527271831381};\\\", \\\"{x:693,y:734,t:1527271831399};\\\", \\\"{x:681,y:736,t:1527271831416};\\\", \\\"{x:671,y:739,t:1527271831432};\\\", \\\"{x:656,y:742,t:1527271831452};\\\", \\\"{x:636,y:742,t:1527271831465};\\\", \\\"{x:608,y:735,t:1527271831482};\\\", \\\"{x:578,y:720,t:1527271831498};\\\", \\\"{x:552,y:705,t:1527271831516};\\\", \\\"{x:536,y:696,t:1527271831531};\\\", \\\"{x:528,y:693,t:1527271831548};\\\", \\\"{x:527,y:693,t:1527271831560};\\\", \\\"{x:526,y:693,t:1527271831592};\\\", \\\"{x:524,y:693,t:1527271831600};\\\", \\\"{x:523,y:694,t:1527271831610};\\\", \\\"{x:522,y:697,t:1527271831628};\\\", \\\"{x:519,y:702,t:1527271831644};\\\", \\\"{x:517,y:707,t:1527271831660};\\\", \\\"{x:516,y:712,t:1527271831678};\\\", \\\"{x:515,y:713,t:1527271831693};\\\", \\\"{x:518,y:713,t:1527271832362};\\\", \\\"{x:532,y:706,t:1527271832377};\\\", \\\"{x:551,y:699,t:1527271832395};\\\", \\\"{x:577,y:689,t:1527271832412};\\\", \\\"{x:601,y:681,t:1527271832428};\\\" ] }, { \\\"rt\\\": 39006, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 291981, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -I -I -I -03 PM-U -U -U -F -03 PM-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:601,y:682,t:1527271833393};\\\", \\\"{x:601,y:681,t:1527271834089};\\\", \\\"{x:601,y:680,t:1527271834097};\\\", \\\"{x:604,y:680,t:1527271834425};\\\", \\\"{x:605,y:680,t:1527271834433};\\\", \\\"{x:606,y:680,t:1527271834446};\\\", \\\"{x:607,y:680,t:1527271834463};\\\", \\\"{x:609,y:680,t:1527271834480};\\\", \\\"{x:611,y:681,t:1527271834496};\\\", \\\"{x:611,y:682,t:1527271834513};\\\", \\\"{x:612,y:682,t:1527271834530};\\\", \\\"{x:613,y:682,t:1527271834577};\\\", \\\"{x:613,y:680,t:1527271834601};\\\", \\\"{x:614,y:678,t:1527271834617};\\\", \\\"{x:614,y:677,t:1527271834629};\\\", \\\"{x:614,y:676,t:1527271834647};\\\", \\\"{x:614,y:673,t:1527271834663};\\\", \\\"{x:614,y:671,t:1527271834679};\\\", \\\"{x:614,y:670,t:1527271834705};\\\", \\\"{x:616,y:669,t:1527271835185};\\\", \\\"{x:619,y:669,t:1527271835197};\\\", \\\"{x:623,y:669,t:1527271835214};\\\", \\\"{x:627,y:669,t:1527271835230};\\\", \\\"{x:628,y:669,t:1527271835247};\\\", \\\"{x:630,y:669,t:1527271835794};\\\", \\\"{x:632,y:670,t:1527271835809};\\\", \\\"{x:636,y:670,t:1527271835817};\\\", \\\"{x:639,y:670,t:1527271835831};\\\", \\\"{x:647,y:670,t:1527271835847};\\\", \\\"{x:658,y:670,t:1527271835863};\\\", \\\"{x:674,y:670,t:1527271835881};\\\", \\\"{x:682,y:669,t:1527271835897};\\\", \\\"{x:697,y:666,t:1527271835914};\\\", \\\"{x:712,y:664,t:1527271835933};\\\", \\\"{x:730,y:663,t:1527271835948};\\\", \\\"{x:749,y:658,t:1527271835963};\\\", \\\"{x:766,y:657,t:1527271835981};\\\", \\\"{x:782,y:654,t:1527271835998};\\\", \\\"{x:791,y:653,t:1527271836013};\\\", \\\"{x:798,y:652,t:1527271836030};\\\", \\\"{x:800,y:651,t:1527271836048};\\\", \\\"{x:801,y:651,t:1527271836064};\\\", \\\"{x:802,y:650,t:1527271838113};\\\", \\\"{x:802,y:649,t:1527271838161};\\\", \\\"{x:803,y:649,t:1527271838169};\\\", \\\"{x:804,y:649,t:1527271838183};\\\", \\\"{x:805,y:648,t:1527271838200};\\\", \\\"{x:806,y:648,t:1527271838216};\\\", \\\"{x:808,y:647,t:1527271838233};\\\", \\\"{x:808,y:646,t:1527271838489};\\\", \\\"{x:809,y:646,t:1527271838501};\\\", \\\"{x:810,y:646,t:1527271838520};\\\", \\\"{x:811,y:646,t:1527271838536};\\\", \\\"{x:812,y:644,t:1527271838552};\\\", \\\"{x:815,y:644,t:1527271838584};\\\", \\\"{x:816,y:644,t:1527271838600};\\\", \\\"{x:821,y:643,t:1527271838615};\\\", \\\"{x:836,y:643,t:1527271838632};\\\", \\\"{x:862,y:643,t:1527271838650};\\\", \\\"{x:913,y:643,t:1527271838666};\\\", \\\"{x:1026,y:650,t:1527271838683};\\\", \\\"{x:1166,y:667,t:1527271838700};\\\", \\\"{x:1318,y:684,t:1527271838716};\\\", \\\"{x:1455,y:693,t:1527271838733};\\\", \\\"{x:1575,y:695,t:1527271838750};\\\", \\\"{x:1684,y:701,t:1527271838767};\\\", \\\"{x:1757,y:702,t:1527271838783};\\\", \\\"{x:1793,y:708,t:1527271838800};\\\", \\\"{x:1812,y:710,t:1527271838816};\\\", \\\"{x:1813,y:710,t:1527271838833};\\\", \\\"{x:1810,y:710,t:1527271838857};\\\", \\\"{x:1803,y:707,t:1527271838867};\\\", \\\"{x:1792,y:702,t:1527271838883};\\\", \\\"{x:1780,y:695,t:1527271838900};\\\", \\\"{x:1770,y:686,t:1527271838917};\\\", \\\"{x:1769,y:684,t:1527271838934};\\\", \\\"{x:1767,y:685,t:1527271839242};\\\", \\\"{x:1765,y:685,t:1527271839257};\\\", \\\"{x:1765,y:686,t:1527271839273};\\\", \\\"{x:1764,y:686,t:1527271839305};\\\", \\\"{x:1763,y:687,t:1527271839318};\\\", \\\"{x:1758,y:689,t:1527271839334};\\\", \\\"{x:1755,y:689,t:1527271839350};\\\", \\\"{x:1749,y:690,t:1527271839367};\\\", \\\"{x:1738,y:694,t:1527271839385};\\\", \\\"{x:1724,y:695,t:1527271839401};\\\", \\\"{x:1688,y:697,t:1527271839417};\\\", \\\"{x:1652,y:704,t:1527271839434};\\\", \\\"{x:1615,y:709,t:1527271839450};\\\", \\\"{x:1577,y:717,t:1527271839468};\\\", \\\"{x:1543,y:728,t:1527271839484};\\\", \\\"{x:1513,y:739,t:1527271839500};\\\", \\\"{x:1492,y:748,t:1527271839518};\\\", \\\"{x:1471,y:757,t:1527271839535};\\\", \\\"{x:1465,y:758,t:1527271839551};\\\", \\\"{x:1465,y:759,t:1527271839969};\\\", \\\"{x:1465,y:758,t:1527271840042};\\\", \\\"{x:1464,y:757,t:1527271840074};\\\", \\\"{x:1464,y:756,t:1527271840089};\\\", \\\"{x:1463,y:754,t:1527271840106};\\\", \\\"{x:1462,y:753,t:1527271840122};\\\", \\\"{x:1461,y:752,t:1527271840137};\\\", \\\"{x:1460,y:751,t:1527271840153};\\\", \\\"{x:1459,y:751,t:1527271840169};\\\", \\\"{x:1458,y:751,t:1527271840184};\\\", \\\"{x:1457,y:750,t:1527271840201};\\\", \\\"{x:1455,y:749,t:1527271840219};\\\", \\\"{x:1454,y:748,t:1527271840234};\\\", \\\"{x:1452,y:746,t:1527271840251};\\\", \\\"{x:1447,y:744,t:1527271840267};\\\", \\\"{x:1445,y:744,t:1527271840284};\\\", \\\"{x:1440,y:743,t:1527271840301};\\\", \\\"{x:1438,y:743,t:1527271840318};\\\", \\\"{x:1434,y:743,t:1527271840334};\\\", \\\"{x:1431,y:741,t:1527271840351};\\\", \\\"{x:1426,y:741,t:1527271840368};\\\", \\\"{x:1421,y:741,t:1527271840384};\\\", \\\"{x:1415,y:741,t:1527271840401};\\\", \\\"{x:1410,y:741,t:1527271840418};\\\", \\\"{x:1409,y:741,t:1527271840434};\\\", \\\"{x:1407,y:741,t:1527271840451};\\\", \\\"{x:1405,y:741,t:1527271840469};\\\", \\\"{x:1404,y:741,t:1527271840484};\\\", \\\"{x:1402,y:741,t:1527271840501};\\\", \\\"{x:1398,y:741,t:1527271840519};\\\", \\\"{x:1394,y:746,t:1527271840535};\\\", \\\"{x:1391,y:748,t:1527271840551};\\\", \\\"{x:1388,y:751,t:1527271840568};\\\", \\\"{x:1386,y:756,t:1527271840585};\\\", \\\"{x:1384,y:761,t:1527271840603};\\\", \\\"{x:1384,y:766,t:1527271840618};\\\", \\\"{x:1384,y:776,t:1527271840636};\\\", \\\"{x:1384,y:791,t:1527271840652};\\\", \\\"{x:1384,y:806,t:1527271840668};\\\", \\\"{x:1384,y:817,t:1527271840685};\\\", \\\"{x:1385,y:830,t:1527271840701};\\\", \\\"{x:1385,y:835,t:1527271840719};\\\", \\\"{x:1385,y:839,t:1527271840735};\\\", \\\"{x:1386,y:840,t:1527271840752};\\\", \\\"{x:1387,y:841,t:1527271840818};\\\", \\\"{x:1403,y:824,t:1527271840835};\\\", \\\"{x:1427,y:790,t:1527271840852};\\\", \\\"{x:1450,y:754,t:1527271840869};\\\", \\\"{x:1469,y:721,t:1527271840885};\\\", \\\"{x:1482,y:695,t:1527271840901};\\\", \\\"{x:1487,y:680,t:1527271840919};\\\", \\\"{x:1487,y:670,t:1527271840935};\\\", \\\"{x:1487,y:665,t:1527271840951};\\\", \\\"{x:1487,y:663,t:1527271840968};\\\", \\\"{x:1487,y:662,t:1527271840993};\\\", \\\"{x:1486,y:662,t:1527271841113};\\\", \\\"{x:1482,y:660,t:1527271841121};\\\", \\\"{x:1479,y:658,t:1527271841135};\\\", \\\"{x:1476,y:652,t:1527271841153};\\\", \\\"{x:1468,y:639,t:1527271841169};\\\", \\\"{x:1458,y:619,t:1527271841185};\\\", \\\"{x:1454,y:610,t:1527271841203};\\\", \\\"{x:1450,y:599,t:1527271841219};\\\", \\\"{x:1449,y:595,t:1527271841236};\\\", \\\"{x:1447,y:592,t:1527271841252};\\\", \\\"{x:1446,y:591,t:1527271841269};\\\", \\\"{x:1445,y:590,t:1527271841285};\\\", \\\"{x:1440,y:589,t:1527271841303};\\\", \\\"{x:1435,y:589,t:1527271841319};\\\", \\\"{x:1428,y:589,t:1527271841335};\\\", \\\"{x:1415,y:589,t:1527271841353};\\\", \\\"{x:1391,y:584,t:1527271841369};\\\", \\\"{x:1373,y:580,t:1527271841386};\\\", \\\"{x:1360,y:578,t:1527271841403};\\\", \\\"{x:1350,y:573,t:1527271841419};\\\", \\\"{x:1344,y:570,t:1527271841436};\\\", \\\"{x:1343,y:569,t:1527271841453};\\\", \\\"{x:1341,y:565,t:1527271841469};\\\", \\\"{x:1340,y:561,t:1527271841485};\\\", \\\"{x:1339,y:557,t:1527271841502};\\\", \\\"{x:1338,y:552,t:1527271841520};\\\", \\\"{x:1338,y:546,t:1527271841535};\\\", \\\"{x:1338,y:542,t:1527271841552};\\\", \\\"{x:1338,y:539,t:1527271841568};\\\", \\\"{x:1338,y:534,t:1527271841586};\\\", \\\"{x:1339,y:529,t:1527271841602};\\\", \\\"{x:1339,y:524,t:1527271841620};\\\", \\\"{x:1339,y:522,t:1527271841636};\\\", \\\"{x:1339,y:521,t:1527271841652};\\\", \\\"{x:1339,y:519,t:1527271841673};\\\", \\\"{x:1339,y:518,t:1527271841689};\\\", \\\"{x:1337,y:517,t:1527271841705};\\\", \\\"{x:1337,y:516,t:1527271841719};\\\", \\\"{x:1335,y:514,t:1527271841736};\\\", \\\"{x:1333,y:514,t:1527271841753};\\\", \\\"{x:1330,y:512,t:1527271841769};\\\", \\\"{x:1329,y:511,t:1527271841786};\\\", \\\"{x:1326,y:508,t:1527271841802};\\\", \\\"{x:1323,y:507,t:1527271841819};\\\", \\\"{x:1321,y:507,t:1527271841836};\\\", \\\"{x:1319,y:504,t:1527271841853};\\\", \\\"{x:1317,y:504,t:1527271841869};\\\", \\\"{x:1317,y:503,t:1527271841886};\\\", \\\"{x:1315,y:503,t:1527271841903};\\\", \\\"{x:1314,y:501,t:1527271842474};\\\", \\\"{x:1313,y:500,t:1527271842486};\\\", \\\"{x:1313,y:498,t:1527271842503};\\\", \\\"{x:1313,y:497,t:1527271842519};\\\", \\\"{x:1312,y:496,t:1527271842537};\\\", \\\"{x:1311,y:496,t:1527271842553};\\\", \\\"{x:1311,y:495,t:1527271843073};\\\", \\\"{x:1313,y:495,t:1527271843086};\\\", \\\"{x:1321,y:495,t:1527271843104};\\\", \\\"{x:1330,y:495,t:1527271843120};\\\", \\\"{x:1339,y:495,t:1527271843137};\\\", \\\"{x:1352,y:495,t:1527271843153};\\\", \\\"{x:1356,y:494,t:1527271843171};\\\", \\\"{x:1358,y:494,t:1527271843187};\\\", \\\"{x:1362,y:494,t:1527271843203};\\\", \\\"{x:1364,y:494,t:1527271843221};\\\", \\\"{x:1366,y:494,t:1527271843237};\\\", \\\"{x:1367,y:494,t:1527271843253};\\\", \\\"{x:1368,y:494,t:1527271843272};\\\", \\\"{x:1369,y:494,t:1527271843466};\\\", \\\"{x:1370,y:494,t:1527271843481};\\\", \\\"{x:1372,y:494,t:1527271843489};\\\", \\\"{x:1375,y:494,t:1527271843504};\\\", \\\"{x:1379,y:494,t:1527271843521};\\\", \\\"{x:1384,y:494,t:1527271843538};\\\", \\\"{x:1388,y:494,t:1527271843553};\\\", \\\"{x:1394,y:494,t:1527271843571};\\\", \\\"{x:1403,y:494,t:1527271843588};\\\", \\\"{x:1409,y:494,t:1527271843604};\\\", \\\"{x:1414,y:494,t:1527271843621};\\\", \\\"{x:1416,y:494,t:1527271843637};\\\", \\\"{x:1418,y:494,t:1527271843655};\\\", \\\"{x:1420,y:494,t:1527271843670};\\\", \\\"{x:1421,y:494,t:1527271843687};\\\", \\\"{x:1422,y:494,t:1527271843705};\\\", \\\"{x:1426,y:494,t:1527271843721};\\\", \\\"{x:1442,y:492,t:1527271843737};\\\", \\\"{x:1449,y:490,t:1527271843754};\\\", \\\"{x:1453,y:489,t:1527271843771};\\\", \\\"{x:1454,y:489,t:1527271843788};\\\", \\\"{x:1457,y:487,t:1527271843954};\\\", \\\"{x:1460,y:487,t:1527271843970};\\\", \\\"{x:1467,y:487,t:1527271843988};\\\", \\\"{x:1473,y:487,t:1527271844004};\\\", \\\"{x:1481,y:489,t:1527271844020};\\\", \\\"{x:1487,y:491,t:1527271844038};\\\", \\\"{x:1489,y:493,t:1527271844054};\\\", \\\"{x:1494,y:494,t:1527271844070};\\\", \\\"{x:1500,y:496,t:1527271844088};\\\", \\\"{x:1506,y:499,t:1527271844105};\\\", \\\"{x:1508,y:499,t:1527271844122};\\\", \\\"{x:1510,y:499,t:1527271844361};\\\", \\\"{x:1513,y:499,t:1527271844371};\\\", \\\"{x:1519,y:499,t:1527271844388};\\\", \\\"{x:1523,y:499,t:1527271844405};\\\", \\\"{x:1528,y:498,t:1527271844422};\\\", \\\"{x:1533,y:498,t:1527271844438};\\\", \\\"{x:1536,y:498,t:1527271844454};\\\", \\\"{x:1538,y:498,t:1527271844472};\\\", \\\"{x:1540,y:498,t:1527271844488};\\\", \\\"{x:1544,y:498,t:1527271844505};\\\", \\\"{x:1546,y:498,t:1527271844522};\\\", \\\"{x:1547,y:498,t:1527271844538};\\\", \\\"{x:1549,y:498,t:1527271844554};\\\", \\\"{x:1550,y:498,t:1527271844577};\\\", \\\"{x:1552,y:498,t:1527271844593};\\\", \\\"{x:1553,y:498,t:1527271844610};\\\", \\\"{x:1555,y:498,t:1527271844622};\\\", \\\"{x:1557,y:498,t:1527271844649};\\\", \\\"{x:1559,y:497,t:1527271844681};\\\", \\\"{x:1561,y:497,t:1527271844697};\\\", \\\"{x:1564,y:495,t:1527271844704};\\\", \\\"{x:1566,y:495,t:1527271844721};\\\", \\\"{x:1569,y:495,t:1527271844738};\\\", \\\"{x:1570,y:495,t:1527271844754};\\\", \\\"{x:1573,y:495,t:1527271844771};\\\", \\\"{x:1579,y:495,t:1527271844788};\\\", \\\"{x:1590,y:495,t:1527271844804};\\\", \\\"{x:1607,y:495,t:1527271844821};\\\", \\\"{x:1631,y:496,t:1527271844838};\\\", \\\"{x:1650,y:497,t:1527271844854};\\\", \\\"{x:1664,y:497,t:1527271844871};\\\", \\\"{x:1666,y:497,t:1527271844888};\\\", \\\"{x:1663,y:498,t:1527271845162};\\\", \\\"{x:1657,y:498,t:1527271845172};\\\", \\\"{x:1642,y:498,t:1527271845188};\\\", \\\"{x:1623,y:498,t:1527271845205};\\\", \\\"{x:1601,y:498,t:1527271845222};\\\", \\\"{x:1578,y:498,t:1527271845239};\\\", \\\"{x:1553,y:498,t:1527271845255};\\\", \\\"{x:1527,y:498,t:1527271845271};\\\", \\\"{x:1491,y:498,t:1527271845289};\\\", \\\"{x:1432,y:498,t:1527271845305};\\\", \\\"{x:1396,y:498,t:1527271845321};\\\", \\\"{x:1364,y:498,t:1527271845339};\\\", \\\"{x:1341,y:498,t:1527271845356};\\\", \\\"{x:1323,y:498,t:1527271845372};\\\", \\\"{x:1312,y:498,t:1527271845389};\\\", \\\"{x:1305,y:498,t:1527271845406};\\\", \\\"{x:1301,y:498,t:1527271845423};\\\", \\\"{x:1298,y:499,t:1527271845439};\\\", \\\"{x:1300,y:499,t:1527271845625};\\\", \\\"{x:1303,y:499,t:1527271845638};\\\", \\\"{x:1308,y:499,t:1527271845655};\\\", \\\"{x:1316,y:499,t:1527271845672};\\\", \\\"{x:1323,y:499,t:1527271845688};\\\", \\\"{x:1327,y:499,t:1527271845705};\\\", \\\"{x:1332,y:499,t:1527271845722};\\\", \\\"{x:1337,y:499,t:1527271845739};\\\", \\\"{x:1341,y:499,t:1527271845755};\\\", \\\"{x:1342,y:499,t:1527271845784};\\\", \\\"{x:1344,y:498,t:1527271845825};\\\", \\\"{x:1345,y:498,t:1527271845838};\\\", \\\"{x:1348,y:498,t:1527271845856};\\\", \\\"{x:1352,y:498,t:1527271845873};\\\", \\\"{x:1356,y:498,t:1527271845889};\\\", \\\"{x:1359,y:498,t:1527271845906};\\\", \\\"{x:1363,y:498,t:1527271845922};\\\", \\\"{x:1367,y:496,t:1527271845939};\\\", \\\"{x:1370,y:496,t:1527271845955};\\\", \\\"{x:1372,y:496,t:1527271845972};\\\", \\\"{x:1373,y:496,t:1527271845990};\\\", \\\"{x:1375,y:496,t:1527271846521};\\\", \\\"{x:1378,y:496,t:1527271846540};\\\", \\\"{x:1382,y:496,t:1527271846556};\\\", \\\"{x:1387,y:496,t:1527271846573};\\\", \\\"{x:1391,y:496,t:1527271846590};\\\", \\\"{x:1400,y:496,t:1527271846606};\\\", \\\"{x:1415,y:496,t:1527271846623};\\\", \\\"{x:1428,y:496,t:1527271846640};\\\", \\\"{x:1444,y:496,t:1527271846657};\\\", \\\"{x:1462,y:496,t:1527271846673};\\\", \\\"{x:1465,y:496,t:1527271846690};\\\", \\\"{x:1466,y:496,t:1527271846707};\\\", \\\"{x:1468,y:496,t:1527271846985};\\\", \\\"{x:1470,y:496,t:1527271846993};\\\", \\\"{x:1473,y:496,t:1527271847007};\\\", \\\"{x:1480,y:496,t:1527271847023};\\\", \\\"{x:1487,y:496,t:1527271847039};\\\", \\\"{x:1492,y:496,t:1527271847057};\\\", \\\"{x:1493,y:496,t:1527271847193};\\\", \\\"{x:1495,y:496,t:1527271847207};\\\", \\\"{x:1507,y:496,t:1527271847224};\\\", \\\"{x:1533,y:496,t:1527271847241};\\\", \\\"{x:1550,y:496,t:1527271847257};\\\", \\\"{x:1563,y:498,t:1527271847274};\\\", \\\"{x:1569,y:498,t:1527271847292};\\\", \\\"{x:1572,y:500,t:1527271847307};\\\", \\\"{x:1573,y:500,t:1527271847329};\\\", \\\"{x:1572,y:501,t:1527271847409};\\\", \\\"{x:1571,y:501,t:1527271847424};\\\", \\\"{x:1564,y:502,t:1527271847441};\\\", \\\"{x:1561,y:502,t:1527271847457};\\\", \\\"{x:1559,y:502,t:1527271847474};\\\", \\\"{x:1558,y:502,t:1527271847521};\\\", \\\"{x:1557,y:502,t:1527271847537};\\\", \\\"{x:1557,y:501,t:1527271847545};\\\", \\\"{x:1557,y:500,t:1527271847561};\\\", \\\"{x:1557,y:499,t:1527271847586};\\\", \\\"{x:1557,y:498,t:1527271847593};\\\", \\\"{x:1556,y:497,t:1527271847607};\\\", \\\"{x:1555,y:496,t:1527271847650};\\\", \\\"{x:1554,y:495,t:1527271847657};\\\", \\\"{x:1554,y:494,t:1527271847673};\\\", \\\"{x:1553,y:493,t:1527271847786};\\\", \\\"{x:1552,y:493,t:1527271847793};\\\", \\\"{x:1551,y:493,t:1527271847809};\\\", \\\"{x:1551,y:494,t:1527271848025};\\\", \\\"{x:1551,y:495,t:1527271849697};\\\", \\\"{x:1551,y:496,t:1527271849709};\\\", \\\"{x:1551,y:498,t:1527271849726};\\\", \\\"{x:1551,y:501,t:1527271849741};\\\", \\\"{x:1551,y:503,t:1527271849759};\\\", \\\"{x:1551,y:504,t:1527271849776};\\\", \\\"{x:1551,y:505,t:1527271849792};\\\", \\\"{x:1552,y:506,t:1527271849809};\\\", \\\"{x:1552,y:507,t:1527271849826};\\\", \\\"{x:1552,y:509,t:1527271849843};\\\", \\\"{x:1552,y:511,t:1527271849859};\\\", \\\"{x:1553,y:513,t:1527271849876};\\\", \\\"{x:1553,y:514,t:1527271849897};\\\", \\\"{x:1553,y:515,t:1527271849909};\\\", \\\"{x:1554,y:516,t:1527271849925};\\\", \\\"{x:1554,y:517,t:1527271849970};\\\", \\\"{x:1554,y:518,t:1527271849993};\\\", \\\"{x:1554,y:519,t:1527271850009};\\\", \\\"{x:1555,y:523,t:1527271850026};\\\", \\\"{x:1555,y:525,t:1527271850043};\\\", \\\"{x:1555,y:527,t:1527271850059};\\\", \\\"{x:1555,y:529,t:1527271850076};\\\", \\\"{x:1556,y:531,t:1527271850093};\\\", \\\"{x:1556,y:534,t:1527271850109};\\\", \\\"{x:1556,y:536,t:1527271850126};\\\", \\\"{x:1556,y:540,t:1527271850142};\\\", \\\"{x:1556,y:543,t:1527271850159};\\\", \\\"{x:1556,y:547,t:1527271850176};\\\", \\\"{x:1556,y:553,t:1527271850193};\\\", \\\"{x:1556,y:556,t:1527271850208};\\\", \\\"{x:1556,y:559,t:1527271850226};\\\", \\\"{x:1556,y:564,t:1527271850243};\\\", \\\"{x:1556,y:568,t:1527271850260};\\\", \\\"{x:1555,y:574,t:1527271850276};\\\", \\\"{x:1554,y:578,t:1527271850293};\\\", \\\"{x:1554,y:581,t:1527271850310};\\\", \\\"{x:1552,y:583,t:1527271850326};\\\", \\\"{x:1551,y:585,t:1527271850343};\\\", \\\"{x:1551,y:586,t:1527271850369};\\\", \\\"{x:1551,y:587,t:1527271850377};\\\", \\\"{x:1551,y:591,t:1527271850393};\\\", \\\"{x:1551,y:593,t:1527271850409};\\\", \\\"{x:1551,y:596,t:1527271850426};\\\", \\\"{x:1550,y:599,t:1527271850443};\\\", \\\"{x:1549,y:603,t:1527271850460};\\\", \\\"{x:1549,y:605,t:1527271850476};\\\", \\\"{x:1549,y:609,t:1527271850493};\\\", \\\"{x:1549,y:613,t:1527271850510};\\\", \\\"{x:1548,y:620,t:1527271850526};\\\", \\\"{x:1548,y:624,t:1527271850543};\\\", \\\"{x:1548,y:630,t:1527271850560};\\\", \\\"{x:1548,y:635,t:1527271850577};\\\", \\\"{x:1548,y:642,t:1527271850593};\\\", \\\"{x:1548,y:651,t:1527271850610};\\\", \\\"{x:1548,y:658,t:1527271850626};\\\", \\\"{x:1548,y:664,t:1527271850643};\\\", \\\"{x:1548,y:670,t:1527271850660};\\\", \\\"{x:1548,y:675,t:1527271850676};\\\", \\\"{x:1548,y:683,t:1527271850693};\\\", \\\"{x:1548,y:689,t:1527271850710};\\\", \\\"{x:1548,y:694,t:1527271850727};\\\", \\\"{x:1547,y:698,t:1527271850743};\\\", \\\"{x:1546,y:702,t:1527271850761};\\\", \\\"{x:1546,y:709,t:1527271850777};\\\", \\\"{x:1544,y:716,t:1527271850793};\\\", \\\"{x:1544,y:723,t:1527271850810};\\\", \\\"{x:1542,y:729,t:1527271850827};\\\", \\\"{x:1540,y:733,t:1527271850843};\\\", \\\"{x:1539,y:739,t:1527271850860};\\\", \\\"{x:1539,y:744,t:1527271850877};\\\", \\\"{x:1539,y:748,t:1527271850893};\\\", \\\"{x:1537,y:752,t:1527271850910};\\\", \\\"{x:1537,y:755,t:1527271850927};\\\", \\\"{x:1537,y:760,t:1527271850943};\\\", \\\"{x:1537,y:764,t:1527271850960};\\\", \\\"{x:1536,y:769,t:1527271850977};\\\", \\\"{x:1536,y:773,t:1527271850993};\\\", \\\"{x:1536,y:776,t:1527271851010};\\\", \\\"{x:1536,y:780,t:1527271851027};\\\", \\\"{x:1536,y:784,t:1527271851043};\\\", \\\"{x:1536,y:790,t:1527271851060};\\\", \\\"{x:1536,y:796,t:1527271851077};\\\", \\\"{x:1536,y:801,t:1527271851093};\\\", \\\"{x:1536,y:807,t:1527271851111};\\\", \\\"{x:1536,y:813,t:1527271851128};\\\", \\\"{x:1536,y:817,t:1527271851144};\\\", \\\"{x:1536,y:822,t:1527271851161};\\\", \\\"{x:1537,y:828,t:1527271851178};\\\", \\\"{x:1537,y:832,t:1527271851193};\\\", \\\"{x:1537,y:835,t:1527271851210};\\\", \\\"{x:1537,y:839,t:1527271851227};\\\", \\\"{x:1537,y:843,t:1527271851244};\\\", \\\"{x:1537,y:849,t:1527271851260};\\\", \\\"{x:1538,y:857,t:1527271851277};\\\", \\\"{x:1540,y:864,t:1527271851294};\\\", \\\"{x:1542,y:871,t:1527271851310};\\\", \\\"{x:1543,y:875,t:1527271851327};\\\", \\\"{x:1544,y:877,t:1527271851344};\\\", \\\"{x:1545,y:880,t:1527271851360};\\\", \\\"{x:1546,y:885,t:1527271851377};\\\", \\\"{x:1548,y:889,t:1527271851394};\\\", \\\"{x:1548,y:893,t:1527271851410};\\\", \\\"{x:1549,y:896,t:1527271851428};\\\", \\\"{x:1550,y:899,t:1527271851445};\\\", \\\"{x:1550,y:901,t:1527271851473};\\\", \\\"{x:1550,y:902,t:1527271851489};\\\", \\\"{x:1550,y:904,t:1527271851497};\\\", \\\"{x:1550,y:906,t:1527271851513};\\\", \\\"{x:1550,y:908,t:1527271851527};\\\", \\\"{x:1550,y:911,t:1527271851544};\\\", \\\"{x:1550,y:915,t:1527271851561};\\\", \\\"{x:1550,y:921,t:1527271851578};\\\", \\\"{x:1550,y:926,t:1527271851594};\\\", \\\"{x:1550,y:929,t:1527271851611};\\\", \\\"{x:1550,y:934,t:1527271851627};\\\", \\\"{x:1550,y:938,t:1527271851644};\\\", \\\"{x:1550,y:941,t:1527271851661};\\\", \\\"{x:1550,y:944,t:1527271851677};\\\", \\\"{x:1550,y:947,t:1527271851694};\\\", \\\"{x:1550,y:950,t:1527271851711};\\\", \\\"{x:1550,y:954,t:1527271851726};\\\", \\\"{x:1550,y:957,t:1527271851744};\\\", \\\"{x:1548,y:961,t:1527271851761};\\\", \\\"{x:1548,y:963,t:1527271851777};\\\", \\\"{x:1548,y:964,t:1527271851795};\\\", \\\"{x:1548,y:965,t:1527271851811};\\\", \\\"{x:1548,y:967,t:1527271851827};\\\", \\\"{x:1547,y:969,t:1527271851845};\\\", \\\"{x:1547,y:970,t:1527271851860};\\\", \\\"{x:1547,y:971,t:1527271851877};\\\", \\\"{x:1547,y:972,t:1527271851894};\\\", \\\"{x:1547,y:973,t:1527271851921};\\\", \\\"{x:1547,y:971,t:1527271853793};\\\", \\\"{x:1547,y:970,t:1527271853808};\\\", \\\"{x:1547,y:969,t:1527271853833};\\\", \\\"{x:1546,y:963,t:1527271854626};\\\", \\\"{x:1544,y:953,t:1527271854633};\\\", \\\"{x:1541,y:942,t:1527271854647};\\\", \\\"{x:1537,y:924,t:1527271854663};\\\", \\\"{x:1532,y:908,t:1527271854680};\\\", \\\"{x:1522,y:884,t:1527271854696};\\\", \\\"{x:1509,y:851,t:1527271854713};\\\", \\\"{x:1503,y:838,t:1527271854730};\\\", \\\"{x:1498,y:831,t:1527271854746};\\\", \\\"{x:1494,y:825,t:1527271854763};\\\", \\\"{x:1491,y:821,t:1527271854781};\\\", \\\"{x:1489,y:818,t:1527271854796};\\\", \\\"{x:1486,y:815,t:1527271854814};\\\", \\\"{x:1483,y:814,t:1527271854830};\\\", \\\"{x:1480,y:813,t:1527271854846};\\\", \\\"{x:1477,y:812,t:1527271854863};\\\", \\\"{x:1474,y:811,t:1527271854880};\\\", \\\"{x:1473,y:811,t:1527271854905};\\\", \\\"{x:1472,y:811,t:1527271854913};\\\", \\\"{x:1471,y:811,t:1527271854930};\\\", \\\"{x:1469,y:812,t:1527271854946};\\\", \\\"{x:1468,y:814,t:1527271854963};\\\", \\\"{x:1468,y:816,t:1527271854980};\\\", \\\"{x:1468,y:817,t:1527271855001};\\\", \\\"{x:1468,y:818,t:1527271855017};\\\", \\\"{x:1468,y:819,t:1527271855030};\\\", \\\"{x:1468,y:821,t:1527271855049};\\\", \\\"{x:1468,y:822,t:1527271855063};\\\", \\\"{x:1469,y:823,t:1527271855080};\\\", \\\"{x:1470,y:825,t:1527271855097};\\\", \\\"{x:1471,y:826,t:1527271855113};\\\", \\\"{x:1473,y:826,t:1527271855433};\\\", \\\"{x:1475,y:826,t:1527271855447};\\\", \\\"{x:1480,y:826,t:1527271855464};\\\", \\\"{x:1487,y:826,t:1527271855481};\\\", \\\"{x:1504,y:826,t:1527271855497};\\\", \\\"{x:1515,y:826,t:1527271855514};\\\", \\\"{x:1533,y:829,t:1527271855531};\\\", \\\"{x:1549,y:830,t:1527271855547};\\\", \\\"{x:1563,y:831,t:1527271855564};\\\", \\\"{x:1572,y:831,t:1527271855580};\\\", \\\"{x:1577,y:831,t:1527271855597};\\\", \\\"{x:1580,y:831,t:1527271855614};\\\", \\\"{x:1581,y:831,t:1527271855649};\\\", \\\"{x:1582,y:831,t:1527271855673};\\\", \\\"{x:1583,y:831,t:1527271855680};\\\", \\\"{x:1586,y:830,t:1527271855697};\\\", \\\"{x:1593,y:830,t:1527271855714};\\\", \\\"{x:1603,y:830,t:1527271855731};\\\", \\\"{x:1608,y:830,t:1527271855747};\\\", \\\"{x:1610,y:830,t:1527271855764};\\\", \\\"{x:1611,y:830,t:1527271855793};\\\", \\\"{x:1612,y:830,t:1527271855809};\\\", \\\"{x:1611,y:830,t:1527271855921};\\\", \\\"{x:1608,y:830,t:1527271855930};\\\", \\\"{x:1593,y:830,t:1527271855948};\\\", \\\"{x:1571,y:830,t:1527271855964};\\\", \\\"{x:1536,y:830,t:1527271855980};\\\", \\\"{x:1477,y:830,t:1527271855998};\\\", \\\"{x:1391,y:830,t:1527271856015};\\\", \\\"{x:1269,y:830,t:1527271856031};\\\", \\\"{x:1124,y:821,t:1527271856048};\\\", \\\"{x:956,y:797,t:1527271856064};\\\", \\\"{x:733,y:764,t:1527271856080};\\\", \\\"{x:599,y:743,t:1527271856097};\\\", \\\"{x:489,y:712,t:1527271856115};\\\", \\\"{x:412,y:680,t:1527271856131};\\\", \\\"{x:372,y:653,t:1527271856148};\\\", \\\"{x:354,y:633,t:1527271856164};\\\", \\\"{x:346,y:616,t:1527271856180};\\\", \\\"{x:340,y:605,t:1527271856197};\\\", \\\"{x:338,y:600,t:1527271856215};\\\", \\\"{x:338,y:596,t:1527271856230};\\\", \\\"{x:338,y:593,t:1527271856248};\\\", \\\"{x:346,y:585,t:1527271856264};\\\", \\\"{x:352,y:580,t:1527271856281};\\\", \\\"{x:363,y:574,t:1527271856298};\\\", \\\"{x:382,y:569,t:1527271856314};\\\", \\\"{x:418,y:569,t:1527271856332};\\\", \\\"{x:474,y:569,t:1527271856348};\\\", \\\"{x:525,y:576,t:1527271856365};\\\", \\\"{x:578,y:584,t:1527271856382};\\\", \\\"{x:617,y:589,t:1527271856398};\\\", \\\"{x:645,y:594,t:1527271856415};\\\", \\\"{x:662,y:599,t:1527271856432};\\\", \\\"{x:669,y:606,t:1527271856447};\\\", \\\"{x:671,y:609,t:1527271856464};\\\", \\\"{x:671,y:610,t:1527271856482};\\\", \\\"{x:671,y:611,t:1527271856497};\\\", \\\"{x:669,y:613,t:1527271856515};\\\", \\\"{x:667,y:613,t:1527271856531};\\\", \\\"{x:665,y:614,t:1527271856548};\\\", \\\"{x:664,y:615,t:1527271856564};\\\", \\\"{x:663,y:615,t:1527271856585};\\\", \\\"{x:661,y:615,t:1527271856597};\\\", \\\"{x:657,y:615,t:1527271856614};\\\", \\\"{x:652,y:615,t:1527271856631};\\\", \\\"{x:649,y:615,t:1527271856648};\\\", \\\"{x:642,y:614,t:1527271856665};\\\", \\\"{x:639,y:614,t:1527271856681};\\\", \\\"{x:638,y:614,t:1527271856873};\\\", \\\"{x:637,y:614,t:1527271856882};\\\", \\\"{x:636,y:614,t:1527271856898};\\\", \\\"{x:635,y:614,t:1527271856937};\\\", \\\"{x:634,y:614,t:1527271856949};\\\", \\\"{x:633,y:614,t:1527271856964};\\\", \\\"{x:632,y:614,t:1527271856982};\\\", \\\"{x:631,y:614,t:1527271856999};\\\", \\\"{x:632,y:613,t:1527271857280};\\\", \\\"{x:637,y:611,t:1527271857288};\\\", \\\"{x:641,y:609,t:1527271857299};\\\", \\\"{x:654,y:608,t:1527271857316};\\\", \\\"{x:680,y:608,t:1527271857331};\\\", \\\"{x:723,y:608,t:1527271857349};\\\", \\\"{x:798,y:608,t:1527271857367};\\\", \\\"{x:887,y:608,t:1527271857382};\\\", \\\"{x:984,y:619,t:1527271857399};\\\", \\\"{x:1095,y:635,t:1527271857416};\\\", \\\"{x:1207,y:655,t:1527271857432};\\\", \\\"{x:1376,y:690,t:1527271857449};\\\", \\\"{x:1454,y:714,t:1527271857466};\\\", \\\"{x:1512,y:740,t:1527271857482};\\\", \\\"{x:1555,y:761,t:1527271857499};\\\", \\\"{x:1573,y:773,t:1527271857516};\\\", \\\"{x:1578,y:780,t:1527271857532};\\\", \\\"{x:1579,y:782,t:1527271857549};\\\", \\\"{x:1579,y:785,t:1527271857566};\\\", \\\"{x:1579,y:788,t:1527271857582};\\\", \\\"{x:1577,y:793,t:1527271857599};\\\", \\\"{x:1569,y:796,t:1527271857616};\\\", \\\"{x:1561,y:797,t:1527271857632};\\\", \\\"{x:1535,y:798,t:1527271857649};\\\", \\\"{x:1510,y:798,t:1527271857666};\\\", \\\"{x:1482,y:798,t:1527271857683};\\\", \\\"{x:1455,y:798,t:1527271857699};\\\", \\\"{x:1428,y:793,t:1527271857716};\\\", \\\"{x:1409,y:790,t:1527271857733};\\\", \\\"{x:1393,y:788,t:1527271857749};\\\", \\\"{x:1379,y:784,t:1527271857766};\\\", \\\"{x:1372,y:781,t:1527271857783};\\\", \\\"{x:1367,y:779,t:1527271857799};\\\", \\\"{x:1366,y:778,t:1527271857857};\\\", \\\"{x:1366,y:777,t:1527271857866};\\\", \\\"{x:1366,y:775,t:1527271857883};\\\", \\\"{x:1366,y:773,t:1527271857899};\\\", \\\"{x:1366,y:771,t:1527271857917};\\\", \\\"{x:1366,y:770,t:1527271858202};\\\", \\\"{x:1367,y:769,t:1527271858217};\\\", \\\"{x:1368,y:769,t:1527271858234};\\\", \\\"{x:1369,y:768,t:1527271858250};\\\", \\\"{x:1370,y:768,t:1527271858441};\\\", \\\"{x:1372,y:767,t:1527271858451};\\\", \\\"{x:1377,y:767,t:1527271858467};\\\", \\\"{x:1388,y:767,t:1527271858484};\\\", \\\"{x:1404,y:767,t:1527271858500};\\\", \\\"{x:1417,y:767,t:1527271858517};\\\", \\\"{x:1424,y:767,t:1527271858533};\\\", \\\"{x:1429,y:767,t:1527271858551};\\\", \\\"{x:1431,y:767,t:1527271858567};\\\", \\\"{x:1433,y:767,t:1527271858583};\\\", \\\"{x:1434,y:767,t:1527271858745};\\\", \\\"{x:1435,y:767,t:1527271858761};\\\", \\\"{x:1435,y:766,t:1527271858769};\\\", \\\"{x:1439,y:765,t:1527271858785};\\\", \\\"{x:1448,y:763,t:1527271858800};\\\", \\\"{x:1475,y:760,t:1527271858818};\\\", \\\"{x:1499,y:760,t:1527271858834};\\\", \\\"{x:1522,y:760,t:1527271858850};\\\", \\\"{x:1538,y:760,t:1527271858867};\\\", \\\"{x:1546,y:760,t:1527271858885};\\\", \\\"{x:1551,y:760,t:1527271859113};\\\", \\\"{x:1555,y:760,t:1527271859120};\\\", \\\"{x:1560,y:760,t:1527271859134};\\\", \\\"{x:1568,y:760,t:1527271859152};\\\", \\\"{x:1574,y:760,t:1527271859168};\\\", \\\"{x:1576,y:760,t:1527271859184};\\\", \\\"{x:1577,y:760,t:1527271859200};\\\", \\\"{x:1578,y:760,t:1527271859344};\\\", \\\"{x:1580,y:761,t:1527271859353};\\\", \\\"{x:1586,y:761,t:1527271859367};\\\", \\\"{x:1597,y:763,t:1527271859384};\\\", \\\"{x:1611,y:764,t:1527271859401};\\\", \\\"{x:1616,y:764,t:1527271859417};\\\", \\\"{x:1617,y:764,t:1527271859434};\\\", \\\"{x:1616,y:764,t:1527271859497};\\\", \\\"{x:1614,y:764,t:1527271859505};\\\", \\\"{x:1612,y:764,t:1527271859521};\\\", \\\"{x:1610,y:765,t:1527271859534};\\\", \\\"{x:1602,y:766,t:1527271859551};\\\", \\\"{x:1592,y:771,t:1527271859568};\\\", \\\"{x:1580,y:780,t:1527271859585};\\\", \\\"{x:1574,y:787,t:1527271859601};\\\", \\\"{x:1571,y:792,t:1527271859618};\\\", \\\"{x:1569,y:795,t:1527271859634};\\\", \\\"{x:1567,y:800,t:1527271859652};\\\", \\\"{x:1566,y:805,t:1527271859668};\\\", \\\"{x:1565,y:814,t:1527271859684};\\\", \\\"{x:1562,y:827,t:1527271859701};\\\", \\\"{x:1560,y:841,t:1527271859718};\\\", \\\"{x:1557,y:860,t:1527271859734};\\\", \\\"{x:1551,y:879,t:1527271859751};\\\", \\\"{x:1546,y:900,t:1527271859768};\\\", \\\"{x:1542,y:913,t:1527271859784};\\\", \\\"{x:1540,y:927,t:1527271859802};\\\", \\\"{x:1540,y:936,t:1527271859818};\\\", \\\"{x:1540,y:940,t:1527271859835};\\\", \\\"{x:1540,y:943,t:1527271859851};\\\", \\\"{x:1540,y:945,t:1527271859869};\\\", \\\"{x:1539,y:947,t:1527271859885};\\\", \\\"{x:1538,y:951,t:1527271859902};\\\", \\\"{x:1538,y:955,t:1527271859918};\\\", \\\"{x:1538,y:962,t:1527271859936};\\\", \\\"{x:1538,y:969,t:1527271859951};\\\", \\\"{x:1538,y:972,t:1527271859968};\\\", \\\"{x:1538,y:973,t:1527271859985};\\\", \\\"{x:1539,y:972,t:1527271860057};\\\", \\\"{x:1541,y:966,t:1527271860069};\\\", \\\"{x:1543,y:956,t:1527271860085};\\\", \\\"{x:1545,y:949,t:1527271860102};\\\", \\\"{x:1546,y:944,t:1527271860118};\\\", \\\"{x:1547,y:939,t:1527271860135};\\\", \\\"{x:1547,y:934,t:1527271860152};\\\", \\\"{x:1547,y:926,t:1527271860169};\\\", \\\"{x:1549,y:916,t:1527271860184};\\\", \\\"{x:1550,y:913,t:1527271860201};\\\", \\\"{x:1550,y:910,t:1527271860218};\\\", \\\"{x:1551,y:908,t:1527271860236};\\\", \\\"{x:1552,y:906,t:1527271860257};\\\", \\\"{x:1553,y:905,t:1527271860269};\\\", \\\"{x:1553,y:902,t:1527271860285};\\\", \\\"{x:1554,y:898,t:1527271860302};\\\", \\\"{x:1556,y:895,t:1527271860318};\\\", \\\"{x:1556,y:894,t:1527271860361};\\\", \\\"{x:1557,y:894,t:1527271860369};\\\", \\\"{x:1560,y:906,t:1527271860385};\\\", \\\"{x:1561,y:921,t:1527271860402};\\\", \\\"{x:1562,y:936,t:1527271860418};\\\", \\\"{x:1562,y:945,t:1527271860435};\\\", \\\"{x:1562,y:953,t:1527271860452};\\\", \\\"{x:1562,y:959,t:1527271860468};\\\", \\\"{x:1562,y:964,t:1527271860486};\\\", \\\"{x:1561,y:970,t:1527271860503};\\\", \\\"{x:1560,y:972,t:1527271860518};\\\", \\\"{x:1558,y:976,t:1527271860536};\\\", \\\"{x:1554,y:983,t:1527271860553};\\\", \\\"{x:1553,y:985,t:1527271860570};\\\", \\\"{x:1552,y:987,t:1527271860585};\\\", \\\"{x:1552,y:988,t:1527271860602};\\\", \\\"{x:1551,y:988,t:1527271860633};\\\", \\\"{x:1550,y:986,t:1527271860648};\\\", \\\"{x:1550,y:977,t:1527271860656};\\\", \\\"{x:1550,y:965,t:1527271860669};\\\", \\\"{x:1550,y:941,t:1527271860685};\\\", \\\"{x:1550,y:914,t:1527271860702};\\\", \\\"{x:1550,y:897,t:1527271860718};\\\", \\\"{x:1551,y:883,t:1527271860735};\\\", \\\"{x:1552,y:874,t:1527271860752};\\\", \\\"{x:1552,y:865,t:1527271860768};\\\", \\\"{x:1552,y:861,t:1527271860785};\\\", \\\"{x:1552,y:859,t:1527271860802};\\\", \\\"{x:1552,y:857,t:1527271860819};\\\", \\\"{x:1552,y:856,t:1527271860835};\\\", \\\"{x:1552,y:854,t:1527271860852};\\\", \\\"{x:1552,y:852,t:1527271860869};\\\", \\\"{x:1552,y:847,t:1527271860885};\\\", \\\"{x:1552,y:842,t:1527271860902};\\\", \\\"{x:1552,y:836,t:1527271860919};\\\", \\\"{x:1552,y:831,t:1527271860935};\\\", \\\"{x:1551,y:828,t:1527271860952};\\\", \\\"{x:1550,y:825,t:1527271860969};\\\", \\\"{x:1550,y:824,t:1527271861065};\\\", \\\"{x:1549,y:822,t:1527271861073};\\\", \\\"{x:1549,y:820,t:1527271861086};\\\", \\\"{x:1549,y:817,t:1527271861102};\\\", \\\"{x:1549,y:814,t:1527271861119};\\\", \\\"{x:1549,y:813,t:1527271861136};\\\", \\\"{x:1549,y:810,t:1527271861152};\\\", \\\"{x:1549,y:807,t:1527271861169};\\\", \\\"{x:1549,y:805,t:1527271861186};\\\", \\\"{x:1549,y:802,t:1527271861202};\\\", \\\"{x:1549,y:801,t:1527271861232};\\\", \\\"{x:1549,y:800,t:1527271861240};\\\", \\\"{x:1549,y:799,t:1527271861257};\\\", \\\"{x:1549,y:797,t:1527271861272};\\\", \\\"{x:1549,y:796,t:1527271861286};\\\", \\\"{x:1549,y:793,t:1527271861302};\\\", \\\"{x:1549,y:788,t:1527271861319};\\\", \\\"{x:1549,y:784,t:1527271861336};\\\", \\\"{x:1549,y:780,t:1527271861352};\\\", \\\"{x:1549,y:768,t:1527271861369};\\\", \\\"{x:1549,y:753,t:1527271861386};\\\", \\\"{x:1549,y:743,t:1527271861403};\\\", \\\"{x:1549,y:734,t:1527271861419};\\\", \\\"{x:1549,y:729,t:1527271861436};\\\", \\\"{x:1549,y:728,t:1527271861453};\\\", \\\"{x:1549,y:725,t:1527271861470};\\\", \\\"{x:1549,y:724,t:1527271861486};\\\", \\\"{x:1549,y:722,t:1527271861503};\\\", \\\"{x:1549,y:719,t:1527271861519};\\\", \\\"{x:1549,y:713,t:1527271861537};\\\", \\\"{x:1549,y:703,t:1527271861553};\\\", \\\"{x:1549,y:699,t:1527271861570};\\\", \\\"{x:1549,y:696,t:1527271861586};\\\", \\\"{x:1549,y:693,t:1527271861604};\\\", \\\"{x:1549,y:692,t:1527271861620};\\\", \\\"{x:1549,y:690,t:1527271861636};\\\", \\\"{x:1549,y:688,t:1527271861653};\\\", \\\"{x:1549,y:686,t:1527271861670};\\\", \\\"{x:1549,y:683,t:1527271861685};\\\", \\\"{x:1550,y:681,t:1527271861702};\\\", \\\"{x:1550,y:679,t:1527271861719};\\\", \\\"{x:1550,y:678,t:1527271861735};\\\", \\\"{x:1550,y:676,t:1527271861752};\\\", \\\"{x:1550,y:674,t:1527271861769};\\\", \\\"{x:1551,y:673,t:1527271861785};\\\", \\\"{x:1551,y:672,t:1527271861803};\\\", \\\"{x:1551,y:671,t:1527271861820};\\\", \\\"{x:1551,y:669,t:1527271861836};\\\", \\\"{x:1551,y:668,t:1527271861853};\\\", \\\"{x:1552,y:667,t:1527271861870};\\\", \\\"{x:1552,y:666,t:1527271861886};\\\", \\\"{x:1552,y:665,t:1527271861903};\\\", \\\"{x:1552,y:664,t:1527271861920};\\\", \\\"{x:1552,y:662,t:1527271861936};\\\", \\\"{x:1552,y:661,t:1527271861953};\\\", \\\"{x:1552,y:658,t:1527271861970};\\\", \\\"{x:1552,y:657,t:1527271861987};\\\", \\\"{x:1552,y:655,t:1527271862003};\\\", \\\"{x:1552,y:653,t:1527271862020};\\\", \\\"{x:1552,y:650,t:1527271862037};\\\", \\\"{x:1552,y:648,t:1527271862054};\\\", \\\"{x:1552,y:646,t:1527271862070};\\\", \\\"{x:1552,y:644,t:1527271862086};\\\", \\\"{x:1552,y:643,t:1527271862104};\\\", \\\"{x:1552,y:641,t:1527271862120};\\\", \\\"{x:1552,y:639,t:1527271862136};\\\", \\\"{x:1552,y:638,t:1527271862154};\\\", \\\"{x:1552,y:637,t:1527271862170};\\\", \\\"{x:1552,y:636,t:1527271862188};\\\", \\\"{x:1552,y:634,t:1527271862204};\\\", \\\"{x:1552,y:632,t:1527271862221};\\\", \\\"{x:1552,y:631,t:1527271862237};\\\", \\\"{x:1552,y:630,t:1527271862253};\\\", \\\"{x:1552,y:628,t:1527271862271};\\\", \\\"{x:1552,y:627,t:1527271862287};\\\", \\\"{x:1552,y:626,t:1527271862304};\\\", \\\"{x:1552,y:625,t:1527271862320};\\\", \\\"{x:1552,y:623,t:1527271862337};\\\", \\\"{x:1552,y:622,t:1527271862354};\\\", \\\"{x:1552,y:621,t:1527271862371};\\\", \\\"{x:1552,y:619,t:1527271862387};\\\", \\\"{x:1552,y:618,t:1527271862403};\\\", \\\"{x:1552,y:617,t:1527271862421};\\\", \\\"{x:1552,y:616,t:1527271862437};\\\", \\\"{x:1551,y:614,t:1527271862457};\\\", \\\"{x:1551,y:615,t:1527271863017};\\\", \\\"{x:1550,y:616,t:1527271863033};\\\", \\\"{x:1550,y:617,t:1527271863184};\\\", \\\"{x:1550,y:619,t:1527271863538};\\\", \\\"{x:1550,y:620,t:1527271863555};\\\", \\\"{x:1549,y:623,t:1527271863572};\\\", \\\"{x:1549,y:626,t:1527271863588};\\\", \\\"{x:1549,y:628,t:1527271863605};\\\", \\\"{x:1549,y:629,t:1527271863633};\\\", \\\"{x:1548,y:630,t:1527271863713};\\\", \\\"{x:1547,y:630,t:1527271865929};\\\", \\\"{x:1547,y:629,t:1527271865940};\\\", \\\"{x:1547,y:628,t:1527271865957};\\\", \\\"{x:1547,y:626,t:1527271865973};\\\", \\\"{x:1547,y:625,t:1527271865993};\\\", \\\"{x:1547,y:624,t:1527271866017};\\\", \\\"{x:1547,y:623,t:1527271866033};\\\", \\\"{x:1547,y:622,t:1527271866097};\\\", \\\"{x:1547,y:621,t:1527271866113};\\\", \\\"{x:1547,y:620,t:1527271866124};\\\", \\\"{x:1547,y:618,t:1527271866141};\\\", \\\"{x:1547,y:613,t:1527271866158};\\\", \\\"{x:1547,y:609,t:1527271866173};\\\", \\\"{x:1547,y:603,t:1527271866191};\\\", \\\"{x:1547,y:598,t:1527271866208};\\\", \\\"{x:1547,y:594,t:1527271866223};\\\", \\\"{x:1547,y:588,t:1527271866241};\\\", \\\"{x:1547,y:584,t:1527271866257};\\\", \\\"{x:1547,y:580,t:1527271866273};\\\", \\\"{x:1547,y:578,t:1527271866292};\\\", \\\"{x:1547,y:576,t:1527271866308};\\\", \\\"{x:1547,y:575,t:1527271866324};\\\", \\\"{x:1547,y:573,t:1527271866341};\\\", \\\"{x:1547,y:572,t:1527271866358};\\\", \\\"{x:1547,y:571,t:1527271866374};\\\", \\\"{x:1547,y:570,t:1527271866401};\\\", \\\"{x:1547,y:569,t:1527271866433};\\\", \\\"{x:1547,y:568,t:1527271866505};\\\", \\\"{x:1547,y:567,t:1527271866513};\\\", \\\"{x:1547,y:566,t:1527271866525};\\\", \\\"{x:1547,y:565,t:1527271866541};\\\", \\\"{x:1547,y:564,t:1527271866557};\\\", \\\"{x:1547,y:562,t:1527271869050};\\\", \\\"{x:1547,y:559,t:1527271869060};\\\", \\\"{x:1547,y:555,t:1527271869076};\\\", \\\"{x:1547,y:549,t:1527271869094};\\\", \\\"{x:1547,y:546,t:1527271869110};\\\", \\\"{x:1547,y:542,t:1527271869127};\\\", \\\"{x:1547,y:541,t:1527271869144};\\\", \\\"{x:1547,y:537,t:1527271869160};\\\", \\\"{x:1547,y:534,t:1527271869176};\\\", \\\"{x:1547,y:531,t:1527271869194};\\\", \\\"{x:1547,y:528,t:1527271869209};\\\", \\\"{x:1547,y:524,t:1527271869227};\\\", \\\"{x:1547,y:519,t:1527271869243};\\\", \\\"{x:1547,y:516,t:1527271869260};\\\", \\\"{x:1547,y:509,t:1527271869276};\\\", \\\"{x:1547,y:503,t:1527271869294};\\\", \\\"{x:1547,y:497,t:1527271869310};\\\", \\\"{x:1547,y:490,t:1527271869327};\\\", \\\"{x:1547,y:485,t:1527271869344};\\\", \\\"{x:1547,y:480,t:1527271869360};\\\", \\\"{x:1547,y:475,t:1527271869376};\\\", \\\"{x:1547,y:470,t:1527271869394};\\\", \\\"{x:1547,y:466,t:1527271869410};\\\", \\\"{x:1546,y:463,t:1527271869427};\\\", \\\"{x:1546,y:460,t:1527271869444};\\\", \\\"{x:1545,y:457,t:1527271869461};\\\", \\\"{x:1545,y:453,t:1527271869476};\\\", \\\"{x:1544,y:451,t:1527271869494};\\\", \\\"{x:1544,y:448,t:1527271869510};\\\", \\\"{x:1543,y:443,t:1527271869527};\\\", \\\"{x:1543,y:440,t:1527271869544};\\\", \\\"{x:1542,y:433,t:1527271869561};\\\", \\\"{x:1542,y:429,t:1527271869577};\\\", \\\"{x:1542,y:428,t:1527271869593};\\\", \\\"{x:1542,y:426,t:1527271869611};\\\", \\\"{x:1542,y:425,t:1527271869633};\\\", \\\"{x:1543,y:425,t:1527271869833};\\\", \\\"{x:1544,y:426,t:1527271869844};\\\", \\\"{x:1546,y:426,t:1527271869861};\\\", \\\"{x:1547,y:426,t:1527271869878};\\\", \\\"{x:1548,y:427,t:1527271869905};\\\", \\\"{x:1548,y:429,t:1527271870728};\\\", \\\"{x:1548,y:433,t:1527271870744};\\\", \\\"{x:1548,y:439,t:1527271870761};\\\", \\\"{x:1548,y:444,t:1527271870778};\\\", \\\"{x:1548,y:448,t:1527271870794};\\\", \\\"{x:1548,y:452,t:1527271870811};\\\", \\\"{x:1548,y:454,t:1527271870827};\\\", \\\"{x:1548,y:458,t:1527271870844};\\\", \\\"{x:1548,y:461,t:1527271870861};\\\", \\\"{x:1548,y:468,t:1527271870878};\\\", \\\"{x:1548,y:476,t:1527271870894};\\\", \\\"{x:1548,y:485,t:1527271870911};\\\", \\\"{x:1548,y:499,t:1527271870928};\\\", \\\"{x:1548,y:509,t:1527271870944};\\\", \\\"{x:1548,y:520,t:1527271870961};\\\", \\\"{x:1548,y:528,t:1527271870978};\\\", \\\"{x:1550,y:540,t:1527271870994};\\\", \\\"{x:1552,y:549,t:1527271871011};\\\", \\\"{x:1554,y:559,t:1527271871028};\\\", \\\"{x:1555,y:564,t:1527271871044};\\\", \\\"{x:1556,y:572,t:1527271871062};\\\", \\\"{x:1557,y:583,t:1527271871078};\\\", \\\"{x:1560,y:593,t:1527271871094};\\\", \\\"{x:1561,y:604,t:1527271871111};\\\", \\\"{x:1562,y:618,t:1527271871129};\\\", \\\"{x:1562,y:627,t:1527271871145};\\\", \\\"{x:1562,y:638,t:1527271871161};\\\", \\\"{x:1562,y:652,t:1527271871178};\\\", \\\"{x:1562,y:667,t:1527271871195};\\\", \\\"{x:1562,y:683,t:1527271871212};\\\", \\\"{x:1562,y:700,t:1527271871228};\\\", \\\"{x:1562,y:718,t:1527271871244};\\\", \\\"{x:1562,y:730,t:1527271871262};\\\", \\\"{x:1562,y:743,t:1527271871279};\\\", \\\"{x:1562,y:756,t:1527271871295};\\\", \\\"{x:1562,y:769,t:1527271871312};\\\", \\\"{x:1562,y:793,t:1527271871328};\\\", \\\"{x:1562,y:817,t:1527271871345};\\\", \\\"{x:1562,y:846,t:1527271871361};\\\", \\\"{x:1562,y:880,t:1527271871379};\\\", \\\"{x:1559,y:912,t:1527271871395};\\\", \\\"{x:1551,y:950,t:1527271871411};\\\", \\\"{x:1527,y:998,t:1527271871428};\\\", \\\"{x:1489,y:1038,t:1527271871446};\\\", \\\"{x:1424,y:1074,t:1527271871461};\\\", \\\"{x:1316,y:1086,t:1527271871478};\\\", \\\"{x:1186,y:1086,t:1527271871496};\\\", \\\"{x:1012,y:1066,t:1527271871511};\\\", \\\"{x:763,y:990,t:1527271871529};\\\", \\\"{x:625,y:949,t:1527271871546};\\\", \\\"{x:527,y:917,t:1527271871562};\\\", \\\"{x:464,y:891,t:1527271871578};\\\", \\\"{x:437,y:876,t:1527271871595};\\\", \\\"{x:427,y:866,t:1527271871612};\\\", \\\"{x:419,y:854,t:1527271871629};\\\", \\\"{x:417,y:849,t:1527271871645};\\\", \\\"{x:412,y:840,t:1527271871662};\\\", \\\"{x:403,y:828,t:1527271871678};\\\", \\\"{x:393,y:810,t:1527271871695};\\\", \\\"{x:381,y:782,t:1527271871711};\\\", \\\"{x:377,y:759,t:1527271871728};\\\", \\\"{x:377,y:748,t:1527271871745};\\\", \\\"{x:388,y:741,t:1527271871762};\\\", \\\"{x:399,y:737,t:1527271871778};\\\", \\\"{x:416,y:734,t:1527271871796};\\\", \\\"{x:431,y:733,t:1527271871812};\\\", \\\"{x:444,y:730,t:1527271871829};\\\", \\\"{x:458,y:729,t:1527271871845};\\\", \\\"{x:465,y:729,t:1527271871862};\\\", \\\"{x:473,y:729,t:1527271871877};\\\", \\\"{x:481,y:729,t:1527271871894};\\\", \\\"{x:487,y:729,t:1527271871910};\\\", \\\"{x:488,y:729,t:1527271871927};\\\", \\\"{x:494,y:729,t:1527271872513};\\\", \\\"{x:510,y:724,t:1527271872528};\\\", \\\"{x:569,y:709,t:1527271872544};\\\", \\\"{x:597,y:708,t:1527271872561};\\\", \\\"{x:631,y:709,t:1527271872578};\\\", \\\"{x:659,y:710,t:1527271872594};\\\", \\\"{x:688,y:710,t:1527271872611};\\\", \\\"{x:721,y:710,t:1527271872628};\\\", \\\"{x:763,y:710,t:1527271872645};\\\", \\\"{x:794,y:710,t:1527271872662};\\\", \\\"{x:814,y:710,t:1527271872679};\\\", \\\"{x:826,y:710,t:1527271872694};\\\", \\\"{x:828,y:709,t:1527271872711};\\\" ] }, { \\\"rt\\\": 9837, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 303109, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:828,y:708,t:1527271873551};\\\", \\\"{x:829,y:706,t:1527271874144};\\\", \\\"{x:831,y:705,t:1527271874152};\\\", \\\"{x:832,y:704,t:1527271874168};\\\", \\\"{x:834,y:703,t:1527271874179};\\\", \\\"{x:835,y:703,t:1527271874195};\\\", \\\"{x:836,y:702,t:1527271874212};\\\", \\\"{x:837,y:702,t:1527271874230};\\\", \\\"{x:838,y:701,t:1527271874245};\\\", \\\"{x:839,y:697,t:1527271874263};\\\", \\\"{x:839,y:691,t:1527271874280};\\\", \\\"{x:843,y:688,t:1527271874792};\\\", \\\"{x:858,y:688,t:1527271874800};\\\", \\\"{x:869,y:688,t:1527271874813};\\\", \\\"{x:894,y:686,t:1527271874830};\\\", \\\"{x:930,y:686,t:1527271874846};\\\", \\\"{x:994,y:686,t:1527271874865};\\\", \\\"{x:1066,y:686,t:1527271874880};\\\", \\\"{x:1177,y:692,t:1527271874897};\\\", \\\"{x:1241,y:700,t:1527271874914};\\\", \\\"{x:1285,y:706,t:1527271874930};\\\", \\\"{x:1310,y:713,t:1527271874947};\\\", \\\"{x:1328,y:724,t:1527271874964};\\\", \\\"{x:1339,y:739,t:1527271874980};\\\", \\\"{x:1342,y:755,t:1527271874997};\\\", \\\"{x:1343,y:778,t:1527271875014};\\\", \\\"{x:1343,y:800,t:1527271875030};\\\", \\\"{x:1343,y:817,t:1527271875047};\\\", \\\"{x:1343,y:831,t:1527271875064};\\\", \\\"{x:1343,y:844,t:1527271875080};\\\", \\\"{x:1343,y:849,t:1527271875097};\\\", \\\"{x:1341,y:850,t:1527271875114};\\\", \\\"{x:1336,y:848,t:1527271875131};\\\", \\\"{x:1336,y:847,t:1527271875609};\\\", \\\"{x:1337,y:847,t:1527271875625};\\\", \\\"{x:1338,y:845,t:1527271875632};\\\", \\\"{x:1338,y:844,t:1527271875649};\\\", \\\"{x:1338,y:841,t:1527271875665};\\\", \\\"{x:1338,y:838,t:1527271875681};\\\", \\\"{x:1338,y:836,t:1527271875698};\\\", \\\"{x:1338,y:835,t:1527271875714};\\\", \\\"{x:1338,y:833,t:1527271875731};\\\", \\\"{x:1338,y:832,t:1527271875748};\\\", \\\"{x:1338,y:827,t:1527271875764};\\\", \\\"{x:1335,y:817,t:1527271875781};\\\", \\\"{x:1329,y:797,t:1527271875798};\\\", \\\"{x:1319,y:760,t:1527271875814};\\\", \\\"{x:1311,y:714,t:1527271875831};\\\", \\\"{x:1305,y:677,t:1527271875848};\\\", \\\"{x:1296,y:641,t:1527271875865};\\\", \\\"{x:1292,y:629,t:1527271875881};\\\", \\\"{x:1291,y:626,t:1527271875898};\\\", \\\"{x:1289,y:623,t:1527271875915};\\\", \\\"{x:1290,y:621,t:1527271875931};\\\", \\\"{x:1291,y:620,t:1527271875993};\\\", \\\"{x:1291,y:619,t:1527271876009};\\\", \\\"{x:1291,y:618,t:1527271876017};\\\", \\\"{x:1289,y:615,t:1527271876031};\\\", \\\"{x:1284,y:609,t:1527271876048};\\\", \\\"{x:1277,y:602,t:1527271876064};\\\", \\\"{x:1269,y:595,t:1527271876081};\\\", \\\"{x:1265,y:591,t:1527271876098};\\\", \\\"{x:1262,y:588,t:1527271876115};\\\", \\\"{x:1258,y:583,t:1527271876131};\\\", \\\"{x:1253,y:578,t:1527271876148};\\\", \\\"{x:1242,y:572,t:1527271876165};\\\", \\\"{x:1229,y:569,t:1527271876181};\\\", \\\"{x:1215,y:568,t:1527271876198};\\\", \\\"{x:1195,y:562,t:1527271876215};\\\", \\\"{x:1173,y:558,t:1527271876231};\\\", \\\"{x:1125,y:552,t:1527271876248};\\\", \\\"{x:1010,y:549,t:1527271876265};\\\", \\\"{x:907,y:549,t:1527271876282};\\\", \\\"{x:793,y:549,t:1527271876298};\\\", \\\"{x:691,y:549,t:1527271876315};\\\", \\\"{x:594,y:549,t:1527271876331};\\\", \\\"{x:491,y:549,t:1527271876347};\\\", \\\"{x:394,y:549,t:1527271876363};\\\", \\\"{x:327,y:549,t:1527271876380};\\\", \\\"{x:285,y:547,t:1527271876397};\\\", \\\"{x:264,y:547,t:1527271876414};\\\", \\\"{x:261,y:547,t:1527271876431};\\\", \\\"{x:261,y:545,t:1527271876544};\\\", \\\"{x:264,y:544,t:1527271876552};\\\", \\\"{x:270,y:540,t:1527271876565};\\\", \\\"{x:284,y:534,t:1527271876583};\\\", \\\"{x:297,y:530,t:1527271876597};\\\", \\\"{x:315,y:528,t:1527271876615};\\\", \\\"{x:338,y:528,t:1527271876631};\\\", \\\"{x:360,y:528,t:1527271876647};\\\", \\\"{x:371,y:528,t:1527271876664};\\\", \\\"{x:373,y:528,t:1527271876682};\\\", \\\"{x:368,y:530,t:1527271876802};\\\", \\\"{x:362,y:532,t:1527271876814};\\\", \\\"{x:332,y:536,t:1527271876831};\\\", \\\"{x:307,y:538,t:1527271876848};\\\", \\\"{x:278,y:542,t:1527271876865};\\\", \\\"{x:251,y:542,t:1527271876882};\\\", \\\"{x:236,y:543,t:1527271876899};\\\", \\\"{x:228,y:543,t:1527271876914};\\\", \\\"{x:227,y:543,t:1527271876932};\\\", \\\"{x:226,y:544,t:1527271876949};\\\", \\\"{x:226,y:546,t:1527271876964};\\\", \\\"{x:226,y:553,t:1527271876982};\\\", \\\"{x:226,y:561,t:1527271876999};\\\", \\\"{x:224,y:572,t:1527271877016};\\\", \\\"{x:222,y:578,t:1527271877032};\\\", \\\"{x:219,y:585,t:1527271877048};\\\", \\\"{x:217,y:587,t:1527271877065};\\\", \\\"{x:215,y:588,t:1527271877081};\\\", \\\"{x:215,y:589,t:1527271877098};\\\", \\\"{x:214,y:590,t:1527271877115};\\\", \\\"{x:212,y:593,t:1527271877131};\\\", \\\"{x:209,y:598,t:1527271877149};\\\", \\\"{x:205,y:603,t:1527271877166};\\\", \\\"{x:199,y:610,t:1527271877181};\\\", \\\"{x:193,y:614,t:1527271877198};\\\", \\\"{x:189,y:617,t:1527271877215};\\\", \\\"{x:186,y:620,t:1527271877231};\\\", \\\"{x:183,y:624,t:1527271877249};\\\", \\\"{x:183,y:626,t:1527271877265};\\\", \\\"{x:183,y:631,t:1527271877281};\\\", \\\"{x:186,y:637,t:1527271877298};\\\", \\\"{x:208,y:647,t:1527271877316};\\\", \\\"{x:248,y:654,t:1527271877331};\\\", \\\"{x:330,y:659,t:1527271877349};\\\", \\\"{x:416,y:659,t:1527271877366};\\\", \\\"{x:516,y:659,t:1527271877382};\\\", \\\"{x:591,y:651,t:1527271877399};\\\", \\\"{x:655,y:643,t:1527271877416};\\\", \\\"{x:701,y:635,t:1527271877431};\\\", \\\"{x:707,y:632,t:1527271877449};\\\", \\\"{x:707,y:631,t:1527271877489};\\\", \\\"{x:706,y:628,t:1527271877498};\\\", \\\"{x:703,y:623,t:1527271877516};\\\", \\\"{x:700,y:615,t:1527271877532};\\\", \\\"{x:700,y:609,t:1527271877549};\\\", \\\"{x:700,y:606,t:1527271877566};\\\", \\\"{x:705,y:599,t:1527271877582};\\\", \\\"{x:712,y:593,t:1527271877599};\\\", \\\"{x:718,y:587,t:1527271877615};\\\", \\\"{x:718,y:586,t:1527271877631};\\\", \\\"{x:718,y:584,t:1527271877649};\\\", \\\"{x:718,y:582,t:1527271877665};\\\", \\\"{x:715,y:579,t:1527271877683};\\\", \\\"{x:707,y:574,t:1527271877699};\\\", \\\"{x:702,y:570,t:1527271877715};\\\", \\\"{x:692,y:562,t:1527271877734};\\\", \\\"{x:686,y:553,t:1527271877749};\\\", \\\"{x:680,y:542,t:1527271877766};\\\", \\\"{x:676,y:536,t:1527271877782};\\\", \\\"{x:670,y:526,t:1527271877798};\\\", \\\"{x:664,y:519,t:1527271877815};\\\", \\\"{x:658,y:512,t:1527271877832};\\\", \\\"{x:656,y:511,t:1527271877849};\\\", \\\"{x:653,y:511,t:1527271877865};\\\", \\\"{x:651,y:510,t:1527271877881};\\\", \\\"{x:647,y:510,t:1527271877898};\\\", \\\"{x:647,y:509,t:1527271877916};\\\", \\\"{x:646,y:508,t:1527271877932};\\\", \\\"{x:643,y:507,t:1527271877949};\\\", \\\"{x:642,y:506,t:1527271877965};\\\", \\\"{x:640,y:505,t:1527271877982};\\\", \\\"{x:640,y:504,t:1527271878223};\\\", \\\"{x:646,y:504,t:1527271878233};\\\", \\\"{x:667,y:506,t:1527271878249};\\\", \\\"{x:692,y:515,t:1527271878266};\\\", \\\"{x:720,y:525,t:1527271878283};\\\", \\\"{x:737,y:531,t:1527271878300};\\\", \\\"{x:751,y:536,t:1527271878315};\\\", \\\"{x:760,y:538,t:1527271878332};\\\", \\\"{x:765,y:541,t:1527271878350};\\\", \\\"{x:768,y:542,t:1527271878367};\\\", \\\"{x:772,y:544,t:1527271878382};\\\", \\\"{x:774,y:545,t:1527271878400};\\\", \\\"{x:780,y:548,t:1527271878416};\\\", \\\"{x:785,y:549,t:1527271878433};\\\", \\\"{x:789,y:549,t:1527271878450};\\\", \\\"{x:793,y:551,t:1527271878467};\\\", \\\"{x:794,y:551,t:1527271878483};\\\", \\\"{x:795,y:551,t:1527271878500};\\\", \\\"{x:796,y:551,t:1527271878516};\\\", \\\"{x:797,y:551,t:1527271878536};\\\", \\\"{x:798,y:551,t:1527271878550};\\\", \\\"{x:803,y:549,t:1527271878567};\\\", \\\"{x:805,y:548,t:1527271878582};\\\", \\\"{x:807,y:547,t:1527271878599};\\\", \\\"{x:809,y:547,t:1527271878617};\\\", \\\"{x:810,y:547,t:1527271878633};\\\", \\\"{x:811,y:546,t:1527271878656};\\\", \\\"{x:812,y:546,t:1527271878667};\\\", \\\"{x:813,y:545,t:1527271878684};\\\", \\\"{x:815,y:545,t:1527271878717};\\\", \\\"{x:815,y:545,t:1527271878776};\\\", \\\"{x:813,y:545,t:1527271878872};\\\", \\\"{x:807,y:551,t:1527271878882};\\\", \\\"{x:789,y:564,t:1527271878900};\\\", \\\"{x:774,y:575,t:1527271878917};\\\", \\\"{x:758,y:584,t:1527271878933};\\\", \\\"{x:743,y:592,t:1527271878949};\\\", \\\"{x:728,y:597,t:1527271878968};\\\", \\\"{x:718,y:603,t:1527271878984};\\\", \\\"{x:705,y:609,t:1527271879000};\\\", \\\"{x:696,y:616,t:1527271879016};\\\", \\\"{x:686,y:626,t:1527271879033};\\\", \\\"{x:674,y:639,t:1527271879050};\\\", \\\"{x:660,y:654,t:1527271879066};\\\", \\\"{x:650,y:667,t:1527271879084};\\\", \\\"{x:646,y:671,t:1527271879100};\\\", \\\"{x:645,y:672,t:1527271879145};\\\", \\\"{x:645,y:670,t:1527271879170};\\\", \\\"{x:648,y:665,t:1527271879178};\\\", \\\"{x:654,y:656,t:1527271879194};\\\", \\\"{x:691,y:625,t:1527271879211};\\\", \\\"{x:775,y:570,t:1527271879227};\\\", \\\"{x:851,y:540,t:1527271879244};\\\", \\\"{x:907,y:523,t:1527271879260};\\\", \\\"{x:936,y:520,t:1527271879276};\\\", \\\"{x:943,y:519,t:1527271879293};\\\", \\\"{x:941,y:519,t:1527271879418};\\\", \\\"{x:938,y:520,t:1527271879427};\\\", \\\"{x:924,y:524,t:1527271879443};\\\", \\\"{x:906,y:529,t:1527271879461};\\\", \\\"{x:885,y:532,t:1527271879477};\\\", \\\"{x:868,y:537,t:1527271879494};\\\", \\\"{x:858,y:540,t:1527271879510};\\\", \\\"{x:852,y:542,t:1527271879526};\\\", \\\"{x:851,y:542,t:1527271879544};\\\", \\\"{x:850,y:542,t:1527271879560};\\\", \\\"{x:849,y:543,t:1527271880050};\\\", \\\"{x:848,y:543,t:1527271880060};\\\", \\\"{x:833,y:559,t:1527271880079};\\\", \\\"{x:808,y:579,t:1527271880095};\\\", \\\"{x:773,y:600,t:1527271880111};\\\", \\\"{x:730,y:623,t:1527271880127};\\\", \\\"{x:692,y:637,t:1527271880145};\\\", \\\"{x:651,y:651,t:1527271880160};\\\", \\\"{x:608,y:666,t:1527271880177};\\\", \\\"{x:588,y:675,t:1527271880193};\\\", \\\"{x:574,y:680,t:1527271880210};\\\", \\\"{x:569,y:683,t:1527271880227};\\\", \\\"{x:564,y:686,t:1527271880243};\\\", \\\"{x:560,y:691,t:1527271880261};\\\", \\\"{x:557,y:699,t:1527271880277};\\\", \\\"{x:552,y:710,t:1527271880293};\\\", \\\"{x:550,y:716,t:1527271880310};\\\", \\\"{x:549,y:721,t:1527271880329};\\\", \\\"{x:549,y:724,t:1527271880344};\\\", \\\"{x:549,y:725,t:1527271880361};\\\", \\\"{x:549,y:726,t:1527271880377};\\\", \\\"{x:549,y:728,t:1527271880491};\\\", \\\"{x:548,y:731,t:1527271880498};\\\", \\\"{x:546,y:735,t:1527271880511};\\\", \\\"{x:543,y:742,t:1527271880528};\\\", \\\"{x:542,y:745,t:1527271880545};\\\", \\\"{x:542,y:746,t:1527271880562};\\\", \\\"{x:541,y:746,t:1527271880643};\\\", \\\"{x:540,y:746,t:1527271881299};\\\", \\\"{x:540,y:747,t:1527271881312};\\\", \\\"{x:539,y:748,t:1527271881338};\\\", \\\"{x:538,y:748,t:1527271881387};\\\" ] }, { \\\"rt\\\": 14047, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 318435, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -F -F -F -F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:748,t:1527271884969};\\\", \\\"{x:537,y:740,t:1527271884986};\\\", \\\"{x:537,y:739,t:1527271884997};\\\", \\\"{x:543,y:737,t:1527271885013};\\\", \\\"{x:573,y:737,t:1527271885031};\\\", \\\"{x:668,y:737,t:1527271885046};\\\", \\\"{x:683,y:734,t:1527271885064};\\\", \\\"{x:684,y:734,t:1527271885586};\\\", \\\"{x:685,y:734,t:1527271885599};\\\", \\\"{x:690,y:734,t:1527271885615};\\\", \\\"{x:696,y:734,t:1527271885632};\\\", \\\"{x:701,y:734,t:1527271885649};\\\", \\\"{x:703,y:734,t:1527271885747};\\\", \\\"{x:705,y:734,t:1527271885754};\\\", \\\"{x:710,y:741,t:1527271885766};\\\", \\\"{x:728,y:759,t:1527271885783};\\\", \\\"{x:750,y:774,t:1527271885799};\\\", \\\"{x:754,y:779,t:1527271885816};\\\", \\\"{x:755,y:785,t:1527271885833};\\\", \\\"{x:759,y:793,t:1527271885849};\\\", \\\"{x:771,y:800,t:1527271885865};\\\", \\\"{x:774,y:800,t:1527271885882};\\\", \\\"{x:775,y:801,t:1527271886291};\\\", \\\"{x:777,y:801,t:1527271886306};\\\", \\\"{x:779,y:801,t:1527271886316};\\\", \\\"{x:780,y:801,t:1527271886333};\\\", \\\"{x:781,y:801,t:1527271886350};\\\", \\\"{x:781,y:800,t:1527271886367};\\\", \\\"{x:781,y:799,t:1527271886386};\\\", \\\"{x:781,y:798,t:1527271886400};\\\", \\\"{x:781,y:797,t:1527271886418};\\\", \\\"{x:781,y:796,t:1527271886434};\\\", \\\"{x:781,y:795,t:1527271886450};\\\", \\\"{x:780,y:795,t:1527271886469};\\\", \\\"{x:779,y:794,t:1527271886483};\\\", \\\"{x:778,y:793,t:1527271886499};\\\", \\\"{x:777,y:793,t:1527271886516};\\\", \\\"{x:776,y:792,t:1527271886533};\\\", \\\"{x:774,y:791,t:1527271886550};\\\", \\\"{x:772,y:790,t:1527271886567};\\\", \\\"{x:768,y:790,t:1527271886583};\\\", \\\"{x:767,y:790,t:1527271886600};\\\", \\\"{x:766,y:789,t:1527271886617};\\\", \\\"{x:765,y:788,t:1527271886634};\\\", \\\"{x:764,y:788,t:1527271886682};\\\", \\\"{x:764,y:787,t:1527271886707};\\\", \\\"{x:763,y:787,t:1527271886730};\\\", \\\"{x:763,y:786,t:1527271886762};\\\", \\\"{x:763,y:785,t:1527271887490};\\\", \\\"{x:763,y:784,t:1527271887746};\\\", \\\"{x:763,y:779,t:1527271887754};\\\", \\\"{x:763,y:777,t:1527271887768};\\\", \\\"{x:763,y:774,t:1527271887785};\\\", \\\"{x:763,y:775,t:1527271888075};\\\", \\\"{x:763,y:776,t:1527271888290};\\\", \\\"{x:767,y:776,t:1527271888577};\\\", \\\"{x:778,y:776,t:1527271888585};\\\", \\\"{x:804,y:776,t:1527271888601};\\\", \\\"{x:845,y:776,t:1527271888619};\\\", \\\"{x:896,y:774,t:1527271888635};\\\", \\\"{x:957,y:766,t:1527271888651};\\\", \\\"{x:1019,y:757,t:1527271888669};\\\", \\\"{x:1104,y:750,t:1527271888686};\\\", \\\"{x:1186,y:742,t:1527271888702};\\\", \\\"{x:1263,y:737,t:1527271888719};\\\", \\\"{x:1332,y:730,t:1527271888736};\\\", \\\"{x:1393,y:729,t:1527271888753};\\\", \\\"{x:1449,y:729,t:1527271888769};\\\", \\\"{x:1511,y:729,t:1527271888786};\\\", \\\"{x:1550,y:729,t:1527271888803};\\\", \\\"{x:1602,y:726,t:1527271888819};\\\", \\\"{x:1661,y:724,t:1527271888836};\\\", \\\"{x:1722,y:717,t:1527271888852};\\\", \\\"{x:1768,y:715,t:1527271888869};\\\", \\\"{x:1797,y:715,t:1527271888886};\\\", \\\"{x:1808,y:714,t:1527271888903};\\\", \\\"{x:1809,y:714,t:1527271888919};\\\", \\\"{x:1803,y:714,t:1527271888946};\\\", \\\"{x:1796,y:714,t:1527271888954};\\\", \\\"{x:1786,y:714,t:1527271888969};\\\", \\\"{x:1742,y:714,t:1527271888986};\\\", \\\"{x:1699,y:714,t:1527271889003};\\\", \\\"{x:1644,y:714,t:1527271889020};\\\", \\\"{x:1574,y:705,t:1527271889036};\\\", \\\"{x:1510,y:705,t:1527271889053};\\\", \\\"{x:1448,y:702,t:1527271889070};\\\", \\\"{x:1397,y:702,t:1527271889086};\\\", \\\"{x:1360,y:702,t:1527271889103};\\\", \\\"{x:1337,y:702,t:1527271889120};\\\", \\\"{x:1320,y:703,t:1527271889136};\\\", \\\"{x:1313,y:706,t:1527271889154};\\\", \\\"{x:1309,y:707,t:1527271889171};\\\", \\\"{x:1308,y:707,t:1527271889186};\\\", \\\"{x:1310,y:708,t:1527271889811};\\\", \\\"{x:1312,y:709,t:1527271889820};\\\", \\\"{x:1314,y:712,t:1527271889837};\\\", \\\"{x:1315,y:716,t:1527271889854};\\\", \\\"{x:1318,y:721,t:1527271889870};\\\", \\\"{x:1320,y:722,t:1527271889888};\\\", \\\"{x:1321,y:723,t:1527271889904};\\\", \\\"{x:1321,y:724,t:1527271889920};\\\", \\\"{x:1321,y:727,t:1527271889937};\\\", \\\"{x:1321,y:734,t:1527271889955};\\\", \\\"{x:1321,y:739,t:1527271889970};\\\", \\\"{x:1320,y:745,t:1527271889988};\\\", \\\"{x:1318,y:751,t:1527271890004};\\\", \\\"{x:1318,y:754,t:1527271890021};\\\", \\\"{x:1317,y:758,t:1527271890037};\\\", \\\"{x:1317,y:761,t:1527271890054};\\\", \\\"{x:1316,y:765,t:1527271890072};\\\", \\\"{x:1316,y:768,t:1527271890088};\\\", \\\"{x:1316,y:770,t:1527271890105};\\\", \\\"{x:1316,y:772,t:1527271890122};\\\", \\\"{x:1316,y:774,t:1527271890137};\\\", \\\"{x:1316,y:778,t:1527271890154};\\\", \\\"{x:1318,y:785,t:1527271890171};\\\", \\\"{x:1322,y:793,t:1527271890188};\\\", \\\"{x:1326,y:800,t:1527271890204};\\\", \\\"{x:1329,y:805,t:1527271890221};\\\", \\\"{x:1332,y:812,t:1527271890238};\\\", \\\"{x:1336,y:820,t:1527271890255};\\\", \\\"{x:1336,y:829,t:1527271890271};\\\", \\\"{x:1338,y:837,t:1527271890288};\\\", \\\"{x:1338,y:845,t:1527271890304};\\\", \\\"{x:1338,y:853,t:1527271890322};\\\", \\\"{x:1335,y:864,t:1527271890339};\\\", \\\"{x:1332,y:872,t:1527271890354};\\\", \\\"{x:1327,y:881,t:1527271890372};\\\", \\\"{x:1325,y:887,t:1527271890388};\\\", \\\"{x:1323,y:892,t:1527271890405};\\\", \\\"{x:1322,y:897,t:1527271890421};\\\", \\\"{x:1321,y:903,t:1527271890438};\\\", \\\"{x:1321,y:907,t:1527271890455};\\\", \\\"{x:1321,y:913,t:1527271890471};\\\", \\\"{x:1320,y:919,t:1527271890488};\\\", \\\"{x:1322,y:924,t:1527271890504};\\\", \\\"{x:1327,y:931,t:1527271890521};\\\", \\\"{x:1337,y:942,t:1527271890539};\\\", \\\"{x:1340,y:946,t:1527271890554};\\\", \\\"{x:1342,y:948,t:1527271890571};\\\", \\\"{x:1343,y:948,t:1527271890588};\\\", \\\"{x:1345,y:948,t:1527271890667};\\\", \\\"{x:1347,y:948,t:1527271890682};\\\", \\\"{x:1349,y:946,t:1527271890697};\\\", \\\"{x:1351,y:943,t:1527271890706};\\\", \\\"{x:1352,y:942,t:1527271890721};\\\", \\\"{x:1358,y:936,t:1527271890737};\\\", \\\"{x:1360,y:933,t:1527271890755};\\\", \\\"{x:1361,y:930,t:1527271890771};\\\", \\\"{x:1361,y:929,t:1527271890788};\\\", \\\"{x:1361,y:927,t:1527271890804};\\\", \\\"{x:1361,y:926,t:1527271890820};\\\", \\\"{x:1361,y:925,t:1527271890838};\\\", \\\"{x:1361,y:922,t:1527271890855};\\\", \\\"{x:1359,y:919,t:1527271890872};\\\", \\\"{x:1358,y:915,t:1527271890888};\\\", \\\"{x:1356,y:908,t:1527271890905};\\\", \\\"{x:1355,y:895,t:1527271890922};\\\", \\\"{x:1354,y:885,t:1527271890938};\\\", \\\"{x:1352,y:877,t:1527271890955};\\\", \\\"{x:1352,y:874,t:1527271890973};\\\", \\\"{x:1351,y:870,t:1527271890988};\\\", \\\"{x:1350,y:868,t:1527271891006};\\\", \\\"{x:1349,y:863,t:1527271891022};\\\", \\\"{x:1346,y:853,t:1527271891038};\\\", \\\"{x:1342,y:841,t:1527271891056};\\\", \\\"{x:1339,y:829,t:1527271891072};\\\", \\\"{x:1337,y:822,t:1527271891089};\\\", \\\"{x:1337,y:819,t:1527271891106};\\\", \\\"{x:1337,y:813,t:1527271891122};\\\", \\\"{x:1337,y:807,t:1527271891138};\\\", \\\"{x:1337,y:804,t:1527271891155};\\\", \\\"{x:1337,y:799,t:1527271891173};\\\", \\\"{x:1338,y:796,t:1527271891190};\\\", \\\"{x:1339,y:792,t:1527271891205};\\\", \\\"{x:1339,y:790,t:1527271891222};\\\", \\\"{x:1340,y:787,t:1527271891239};\\\", \\\"{x:1342,y:785,t:1527271891255};\\\", \\\"{x:1342,y:784,t:1527271891272};\\\", \\\"{x:1343,y:782,t:1527271891289};\\\", \\\"{x:1344,y:779,t:1527271891305};\\\", \\\"{x:1346,y:775,t:1527271891322};\\\", \\\"{x:1347,y:771,t:1527271891340};\\\", \\\"{x:1348,y:769,t:1527271891355};\\\", \\\"{x:1349,y:766,t:1527271891375};\\\", \\\"{x:1349,y:765,t:1527271891404};\\\", \\\"{x:1349,y:764,t:1527271891449};\\\", \\\"{x:1349,y:763,t:1527271891473};\\\", \\\"{x:1349,y:762,t:1527271891489};\\\", \\\"{x:1349,y:761,t:1527271891505};\\\", \\\"{x:1349,y:760,t:1527271891521};\\\", \\\"{x:1350,y:757,t:1527271891539};\\\", \\\"{x:1350,y:754,t:1527271891556};\\\", \\\"{x:1350,y:746,t:1527271891571};\\\", \\\"{x:1350,y:737,t:1527271891589};\\\", \\\"{x:1351,y:728,t:1527271891605};\\\", \\\"{x:1353,y:724,t:1527271891622};\\\", \\\"{x:1354,y:716,t:1527271891639};\\\", \\\"{x:1354,y:709,t:1527271891656};\\\", \\\"{x:1356,y:703,t:1527271891672};\\\", \\\"{x:1357,y:695,t:1527271891689};\\\", \\\"{x:1358,y:688,t:1527271891706};\\\", \\\"{x:1358,y:687,t:1527271891722};\\\", \\\"{x:1358,y:685,t:1527271891739};\\\", \\\"{x:1358,y:686,t:1527271891826};\\\", \\\"{x:1358,y:689,t:1527271891840};\\\", \\\"{x:1358,y:695,t:1527271891857};\\\", \\\"{x:1358,y:700,t:1527271891873};\\\", \\\"{x:1358,y:705,t:1527271891889};\\\", \\\"{x:1360,y:711,t:1527271891906};\\\", \\\"{x:1360,y:715,t:1527271891924};\\\", \\\"{x:1360,y:716,t:1527271891940};\\\", \\\"{x:1360,y:719,t:1527271891956};\\\", \\\"{x:1362,y:723,t:1527271891973};\\\", \\\"{x:1363,y:727,t:1527271891990};\\\", \\\"{x:1364,y:728,t:1527271892006};\\\", \\\"{x:1364,y:730,t:1527271892023};\\\", \\\"{x:1364,y:733,t:1527271892040};\\\", \\\"{x:1364,y:736,t:1527271892056};\\\", \\\"{x:1364,y:738,t:1527271892074};\\\", \\\"{x:1363,y:745,t:1527271892090};\\\", \\\"{x:1361,y:750,t:1527271892106};\\\", \\\"{x:1360,y:752,t:1527271892123};\\\", \\\"{x:1360,y:755,t:1527271892140};\\\", \\\"{x:1359,y:757,t:1527271892156};\\\", \\\"{x:1356,y:761,t:1527271892173};\\\", \\\"{x:1355,y:765,t:1527271892191};\\\", \\\"{x:1353,y:769,t:1527271892206};\\\", \\\"{x:1352,y:772,t:1527271892223};\\\", \\\"{x:1351,y:774,t:1527271892240};\\\", \\\"{x:1351,y:775,t:1527271892256};\\\", \\\"{x:1351,y:776,t:1527271892274};\\\", \\\"{x:1351,y:777,t:1527271892297};\\\", \\\"{x:1351,y:778,t:1527271892306};\\\", \\\"{x:1351,y:779,t:1527271892323};\\\", \\\"{x:1351,y:780,t:1527271892345};\\\", \\\"{x:1351,y:781,t:1527271892361};\\\", \\\"{x:1351,y:782,t:1527271892377};\\\", \\\"{x:1351,y:784,t:1527271892394};\\\", \\\"{x:1351,y:786,t:1527271892407};\\\", \\\"{x:1351,y:789,t:1527271892423};\\\", \\\"{x:1351,y:792,t:1527271892439};\\\", \\\"{x:1351,y:794,t:1527271892457};\\\", \\\"{x:1351,y:795,t:1527271892473};\\\", \\\"{x:1351,y:796,t:1527271892490};\\\", \\\"{x:1351,y:797,t:1527271892507};\\\", \\\"{x:1351,y:798,t:1527271892523};\\\", \\\"{x:1351,y:799,t:1527271892546};\\\", \\\"{x:1351,y:800,t:1527271892562};\\\", \\\"{x:1351,y:801,t:1527271892573};\\\", \\\"{x:1351,y:803,t:1527271892590};\\\", \\\"{x:1351,y:802,t:1527271892691};\\\", \\\"{x:1351,y:793,t:1527271892707};\\\", \\\"{x:1351,y:784,t:1527271892724};\\\", \\\"{x:1351,y:776,t:1527271892741};\\\", \\\"{x:1351,y:772,t:1527271892757};\\\", \\\"{x:1351,y:768,t:1527271892774};\\\", \\\"{x:1351,y:766,t:1527271892791};\\\", \\\"{x:1351,y:765,t:1527271892807};\\\", \\\"{x:1351,y:763,t:1527271892826};\\\", \\\"{x:1351,y:762,t:1527271892842};\\\", \\\"{x:1351,y:759,t:1527271892857};\\\", \\\"{x:1351,y:753,t:1527271892875};\\\", \\\"{x:1351,y:748,t:1527271892891};\\\", \\\"{x:1351,y:743,t:1527271892907};\\\", \\\"{x:1351,y:740,t:1527271892925};\\\", \\\"{x:1351,y:737,t:1527271892942};\\\", \\\"{x:1351,y:734,t:1527271892957};\\\", \\\"{x:1351,y:730,t:1527271892974};\\\", \\\"{x:1351,y:724,t:1527271892991};\\\", \\\"{x:1351,y:719,t:1527271893007};\\\", \\\"{x:1351,y:713,t:1527271893024};\\\", \\\"{x:1351,y:707,t:1527271893042};\\\", \\\"{x:1351,y:705,t:1527271893057};\\\", \\\"{x:1353,y:701,t:1527271893074};\\\", \\\"{x:1353,y:699,t:1527271893091};\\\", \\\"{x:1353,y:697,t:1527271893107};\\\", \\\"{x:1353,y:695,t:1527271893124};\\\", \\\"{x:1354,y:694,t:1527271893142};\\\", \\\"{x:1354,y:695,t:1527271893291};\\\", \\\"{x:1354,y:702,t:1527271893308};\\\", \\\"{x:1354,y:706,t:1527271893325};\\\", \\\"{x:1354,y:709,t:1527271893341};\\\", \\\"{x:1354,y:712,t:1527271893358};\\\", \\\"{x:1356,y:717,t:1527271893375};\\\", \\\"{x:1357,y:719,t:1527271893391};\\\", \\\"{x:1358,y:721,t:1527271893409};\\\", \\\"{x:1358,y:724,t:1527271893425};\\\", \\\"{x:1358,y:726,t:1527271893442};\\\", \\\"{x:1358,y:730,t:1527271893458};\\\", \\\"{x:1358,y:732,t:1527271893475};\\\", \\\"{x:1358,y:735,t:1527271893491};\\\", \\\"{x:1358,y:736,t:1527271893508};\\\", \\\"{x:1358,y:739,t:1527271893525};\\\", \\\"{x:1358,y:743,t:1527271893541};\\\", \\\"{x:1357,y:747,t:1527271893558};\\\", \\\"{x:1357,y:749,t:1527271893575};\\\", \\\"{x:1356,y:753,t:1527271893591};\\\", \\\"{x:1356,y:756,t:1527271893608};\\\", \\\"{x:1356,y:759,t:1527271893625};\\\", \\\"{x:1356,y:761,t:1527271893641};\\\", \\\"{x:1355,y:764,t:1527271893658};\\\", \\\"{x:1355,y:765,t:1527271893675};\\\", \\\"{x:1355,y:766,t:1527271893698};\\\", \\\"{x:1354,y:766,t:1527271893714};\\\", \\\"{x:1354,y:764,t:1527271893786};\\\", \\\"{x:1354,y:757,t:1527271893794};\\\", \\\"{x:1354,y:748,t:1527271893808};\\\", \\\"{x:1353,y:737,t:1527271893825};\\\", \\\"{x:1349,y:718,t:1527271893842};\\\", \\\"{x:1348,y:710,t:1527271893858};\\\", \\\"{x:1348,y:701,t:1527271893875};\\\", \\\"{x:1348,y:694,t:1527271893892};\\\", \\\"{x:1348,y:691,t:1527271893909};\\\", \\\"{x:1348,y:689,t:1527271893925};\\\", \\\"{x:1348,y:687,t:1527271893942};\\\", \\\"{x:1349,y:686,t:1527271893958};\\\", \\\"{x:1349,y:690,t:1527271894034};\\\", \\\"{x:1349,y:694,t:1527271894041};\\\", \\\"{x:1349,y:702,t:1527271894057};\\\", \\\"{x:1349,y:709,t:1527271894075};\\\", \\\"{x:1349,y:713,t:1527271894091};\\\", \\\"{x:1350,y:719,t:1527271894108};\\\", \\\"{x:1350,y:722,t:1527271894124};\\\", \\\"{x:1350,y:726,t:1527271894142};\\\", \\\"{x:1350,y:728,t:1527271894159};\\\", \\\"{x:1350,y:732,t:1527271894175};\\\", \\\"{x:1350,y:735,t:1527271894192};\\\", \\\"{x:1350,y:738,t:1527271894209};\\\", \\\"{x:1350,y:741,t:1527271894225};\\\", \\\"{x:1350,y:745,t:1527271894241};\\\", \\\"{x:1349,y:747,t:1527271894259};\\\", \\\"{x:1349,y:748,t:1527271894275};\\\", \\\"{x:1349,y:751,t:1527271894292};\\\", \\\"{x:1349,y:754,t:1527271894309};\\\", \\\"{x:1348,y:757,t:1527271894324};\\\", \\\"{x:1348,y:758,t:1527271894342};\\\", \\\"{x:1347,y:760,t:1527271894359};\\\", \\\"{x:1347,y:762,t:1527271894375};\\\", \\\"{x:1347,y:765,t:1527271894392};\\\", \\\"{x:1347,y:766,t:1527271894409};\\\", \\\"{x:1347,y:767,t:1527271894425};\\\", \\\"{x:1347,y:768,t:1527271894442};\\\", \\\"{x:1347,y:767,t:1527271894514};\\\", \\\"{x:1347,y:763,t:1527271894527};\\\", \\\"{x:1351,y:747,t:1527271894543};\\\", \\\"{x:1352,y:729,t:1527271894560};\\\", \\\"{x:1354,y:712,t:1527271894576};\\\", \\\"{x:1356,y:700,t:1527271894593};\\\", \\\"{x:1356,y:684,t:1527271894610};\\\", \\\"{x:1356,y:677,t:1527271894626};\\\", \\\"{x:1356,y:674,t:1527271894642};\\\", \\\"{x:1355,y:673,t:1527271894659};\\\", \\\"{x:1352,y:672,t:1527271894677};\\\", \\\"{x:1344,y:671,t:1527271894693};\\\", \\\"{x:1329,y:667,t:1527271894709};\\\", \\\"{x:1294,y:655,t:1527271894726};\\\", \\\"{x:1236,y:640,t:1527271894742};\\\", \\\"{x:1155,y:627,t:1527271894759};\\\", \\\"{x:1043,y:605,t:1527271894776};\\\", \\\"{x:925,y:578,t:1527271894793};\\\", \\\"{x:777,y:547,t:1527271894809};\\\", \\\"{x:561,y:502,t:1527271894827};\\\", \\\"{x:492,y:489,t:1527271894839};\\\", \\\"{x:367,y:468,t:1527271894857};\\\", \\\"{x:287,y:457,t:1527271894873};\\\", \\\"{x:249,y:454,t:1527271894888};\\\", \\\"{x:216,y:454,t:1527271894905};\\\", \\\"{x:208,y:454,t:1527271894923};\\\", \\\"{x:207,y:455,t:1527271894939};\\\", \\\"{x:206,y:455,t:1527271894969};\\\", \\\"{x:208,y:455,t:1527271895082};\\\", \\\"{x:219,y:455,t:1527271895090};\\\", \\\"{x:251,y:455,t:1527271895106};\\\", \\\"{x:277,y:458,t:1527271895124};\\\", \\\"{x:308,y:464,t:1527271895141};\\\", \\\"{x:327,y:466,t:1527271895156};\\\", \\\"{x:347,y:470,t:1527271895173};\\\", \\\"{x:365,y:477,t:1527271895190};\\\", \\\"{x:376,y:482,t:1527271895206};\\\", \\\"{x:387,y:491,t:1527271895224};\\\", \\\"{x:392,y:498,t:1527271895240};\\\", \\\"{x:392,y:502,t:1527271895256};\\\", \\\"{x:392,y:506,t:1527271895273};\\\", \\\"{x:389,y:516,t:1527271895290};\\\", \\\"{x:381,y:526,t:1527271895306};\\\", \\\"{x:375,y:533,t:1527271895323};\\\", \\\"{x:369,y:540,t:1527271895340};\\\", \\\"{x:365,y:544,t:1527271895356};\\\", \\\"{x:361,y:547,t:1527271895372};\\\", \\\"{x:358,y:550,t:1527271895389};\\\", \\\"{x:357,y:550,t:1527271895407};\\\", \\\"{x:356,y:550,t:1527271895423};\\\", \\\"{x:356,y:547,t:1527271895440};\\\", \\\"{x:356,y:546,t:1527271895457};\\\", \\\"{x:354,y:546,t:1527271895705};\\\", \\\"{x:351,y:546,t:1527271895714};\\\", \\\"{x:347,y:546,t:1527271895724};\\\", \\\"{x:333,y:548,t:1527271895740};\\\", \\\"{x:313,y:549,t:1527271895758};\\\", \\\"{x:291,y:550,t:1527271895774};\\\", \\\"{x:277,y:550,t:1527271895790};\\\", \\\"{x:266,y:550,t:1527271895808};\\\", \\\"{x:257,y:550,t:1527271895824};\\\", \\\"{x:253,y:549,t:1527271895839};\\\", \\\"{x:252,y:548,t:1527271895856};\\\", \\\"{x:252,y:547,t:1527271895874};\\\", \\\"{x:253,y:544,t:1527271895889};\\\", \\\"{x:272,y:535,t:1527271895906};\\\", \\\"{x:293,y:529,t:1527271895925};\\\", \\\"{x:315,y:528,t:1527271895939};\\\", \\\"{x:342,y:528,t:1527271895957};\\\", \\\"{x:365,y:528,t:1527271895974};\\\", \\\"{x:380,y:528,t:1527271895990};\\\", \\\"{x:391,y:528,t:1527271896007};\\\", \\\"{x:395,y:528,t:1527271896024};\\\", \\\"{x:396,y:528,t:1527271896042};\\\", \\\"{x:395,y:530,t:1527271896057};\\\", \\\"{x:370,y:534,t:1527271896073};\\\", \\\"{x:346,y:537,t:1527271896090};\\\", \\\"{x:320,y:540,t:1527271896106};\\\", \\\"{x:289,y:540,t:1527271896124};\\\", \\\"{x:252,y:540,t:1527271896141};\\\", \\\"{x:222,y:540,t:1527271896157};\\\", \\\"{x:197,y:540,t:1527271896174};\\\", \\\"{x:181,y:539,t:1527271896190};\\\", \\\"{x:172,y:539,t:1527271896207};\\\", \\\"{x:169,y:538,t:1527271896224};\\\", \\\"{x:169,y:537,t:1527271896410};\\\", \\\"{x:169,y:536,t:1527271896585};\\\", \\\"{x:169,y:535,t:1527271896609};\\\", \\\"{x:171,y:535,t:1527271896625};\\\", \\\"{x:172,y:533,t:1527271896649};\\\", \\\"{x:176,y:532,t:1527271896665};\\\", \\\"{x:181,y:532,t:1527271896681};\\\", \\\"{x:188,y:532,t:1527271896691};\\\", \\\"{x:210,y:532,t:1527271896708};\\\", \\\"{x:243,y:532,t:1527271896723};\\\", \\\"{x:280,y:532,t:1527271896741};\\\", \\\"{x:304,y:532,t:1527271896758};\\\", \\\"{x:317,y:532,t:1527271896774};\\\", \\\"{x:323,y:532,t:1527271896791};\\\", \\\"{x:325,y:533,t:1527271896807};\\\", \\\"{x:327,y:534,t:1527271896823};\\\", \\\"{x:333,y:534,t:1527271896841};\\\", \\\"{x:344,y:534,t:1527271896857};\\\", \\\"{x:369,y:534,t:1527271896873};\\\", \\\"{x:406,y:528,t:1527271896891};\\\", \\\"{x:464,y:522,t:1527271896908};\\\", \\\"{x:530,y:515,t:1527271896925};\\\", \\\"{x:589,y:513,t:1527271896941};\\\", \\\"{x:629,y:512,t:1527271896958};\\\", \\\"{x:659,y:509,t:1527271896974};\\\", \\\"{x:676,y:509,t:1527271896991};\\\", \\\"{x:681,y:509,t:1527271897008};\\\", \\\"{x:684,y:509,t:1527271897025};\\\", \\\"{x:683,y:509,t:1527271897082};\\\", \\\"{x:682,y:509,t:1527271897097};\\\", \\\"{x:684,y:510,t:1527271897154};\\\", \\\"{x:697,y:514,t:1527271897162};\\\", \\\"{x:716,y:517,t:1527271897175};\\\", \\\"{x:768,y:520,t:1527271897192};\\\", \\\"{x:829,y:520,t:1527271897208};\\\", \\\"{x:890,y:520,t:1527271897225};\\\", \\\"{x:925,y:520,t:1527271897241};\\\", \\\"{x:936,y:520,t:1527271897258};\\\", \\\"{x:935,y:520,t:1527271897289};\\\", \\\"{x:933,y:521,t:1527271897297};\\\", \\\"{x:931,y:521,t:1527271897308};\\\", \\\"{x:926,y:521,t:1527271897325};\\\", \\\"{x:923,y:521,t:1527271897341};\\\", \\\"{x:917,y:521,t:1527271897358};\\\", \\\"{x:909,y:521,t:1527271897375};\\\", \\\"{x:897,y:521,t:1527271897391};\\\", \\\"{x:882,y:521,t:1527271897408};\\\", \\\"{x:865,y:519,t:1527271897425};\\\", \\\"{x:852,y:518,t:1527271897441};\\\", \\\"{x:847,y:516,t:1527271897460};\\\", \\\"{x:847,y:515,t:1527271897509};\\\", \\\"{x:846,y:513,t:1527271897527};\\\", \\\"{x:844,y:510,t:1527271897541};\\\", \\\"{x:843,y:509,t:1527271897558};\\\", \\\"{x:840,y:506,t:1527271897575};\\\", \\\"{x:837,y:504,t:1527271897592};\\\", \\\"{x:834,y:503,t:1527271897608};\\\", \\\"{x:833,y:503,t:1527271897817};\\\", \\\"{x:830,y:504,t:1527271897825};\\\", \\\"{x:818,y:517,t:1527271897841};\\\", \\\"{x:794,y:544,t:1527271897859};\\\", \\\"{x:756,y:574,t:1527271897875};\\\", \\\"{x:714,y:602,t:1527271897893};\\\", \\\"{x:687,y:617,t:1527271897909};\\\", \\\"{x:669,y:628,t:1527271897925};\\\", \\\"{x:655,y:639,t:1527271897942};\\\", \\\"{x:646,y:649,t:1527271897959};\\\", \\\"{x:638,y:657,t:1527271897974};\\\", \\\"{x:630,y:667,t:1527271897992};\\\", \\\"{x:621,y:677,t:1527271898009};\\\", \\\"{x:615,y:682,t:1527271898025};\\\", \\\"{x:607,y:686,t:1527271898042};\\\", \\\"{x:598,y:687,t:1527271898059};\\\", \\\"{x:591,y:689,t:1527271898075};\\\", \\\"{x:582,y:689,t:1527271898092};\\\", \\\"{x:574,y:689,t:1527271898109};\\\", \\\"{x:565,y:689,t:1527271898125};\\\", \\\"{x:558,y:689,t:1527271898143};\\\", \\\"{x:550,y:689,t:1527271898159};\\\", \\\"{x:544,y:690,t:1527271898175};\\\", \\\"{x:537,y:691,t:1527271898192};\\\", \\\"{x:526,y:703,t:1527271898209};\\\", \\\"{x:521,y:713,t:1527271898225};\\\", \\\"{x:512,y:736,t:1527271898243};\\\", \\\"{x:510,y:744,t:1527271898259};\\\", \\\"{x:509,y:745,t:1527271898275};\\\" ] }, { \\\"rt\\\": 24438, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 344130, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-G -X -X -X -B -B -B -B -F -F -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:739,t:1527271900337};\\\", \\\"{x:505,y:683,t:1527271900358};\\\", \\\"{x:488,y:554,t:1527271900377};\\\", \\\"{x:482,y:543,t:1527271900394};\\\", \\\"{x:481,y:543,t:1527271900874};\\\", \\\"{x:483,y:543,t:1527271901194};\\\", \\\"{x:487,y:540,t:1527271901211};\\\", \\\"{x:491,y:538,t:1527271901228};\\\", \\\"{x:497,y:535,t:1527271901245};\\\", \\\"{x:502,y:531,t:1527271901263};\\\", \\\"{x:509,y:528,t:1527271901278};\\\", \\\"{x:514,y:528,t:1527271901295};\\\", \\\"{x:515,y:528,t:1527271901312};\\\", \\\"{x:517,y:528,t:1527271901722};\\\", \\\"{x:522,y:529,t:1527271901730};\\\", \\\"{x:540,y:529,t:1527271901746};\\\", \\\"{x:558,y:523,t:1527271901765};\\\", \\\"{x:570,y:518,t:1527271901779};\\\", \\\"{x:586,y:514,t:1527271901797};\\\", \\\"{x:600,y:512,t:1527271901812};\\\", \\\"{x:614,y:508,t:1527271901829};\\\", \\\"{x:633,y:502,t:1527271901845};\\\", \\\"{x:650,y:499,t:1527271901863};\\\", \\\"{x:664,y:495,t:1527271901878};\\\", \\\"{x:670,y:493,t:1527271901895};\\\", \\\"{x:675,y:491,t:1527271901912};\\\", \\\"{x:676,y:490,t:1527271901928};\\\", \\\"{x:678,y:489,t:1527271902186};\\\", \\\"{x:681,y:488,t:1527271902196};\\\", \\\"{x:689,y:487,t:1527271902213};\\\", \\\"{x:701,y:486,t:1527271902231};\\\", \\\"{x:711,y:486,t:1527271902246};\\\", \\\"{x:722,y:486,t:1527271902262};\\\", \\\"{x:727,y:485,t:1527271902279};\\\", \\\"{x:728,y:485,t:1527271902426};\\\", \\\"{x:728,y:486,t:1527271902434};\\\", \\\"{x:726,y:487,t:1527271902447};\\\", \\\"{x:726,y:488,t:1527271902462};\\\", \\\"{x:725,y:488,t:1527271902479};\\\", \\\"{x:725,y:489,t:1527271902496};\\\", \\\"{x:723,y:490,t:1527271902740};\\\", \\\"{x:721,y:493,t:1527271902747};\\\", \\\"{x:719,y:501,t:1527271902762};\\\", \\\"{x:715,y:511,t:1527271902780};\\\", \\\"{x:713,y:519,t:1527271902797};\\\", \\\"{x:710,y:528,t:1527271902813};\\\", \\\"{x:709,y:534,t:1527271902830};\\\", \\\"{x:709,y:537,t:1527271902847};\\\", \\\"{x:709,y:538,t:1527271902862};\\\", \\\"{x:709,y:540,t:1527271902879};\\\", \\\"{x:709,y:543,t:1527271902896};\\\", \\\"{x:709,y:547,t:1527271902912};\\\", \\\"{x:714,y:548,t:1527271902930};\\\", \\\"{x:718,y:547,t:1527271902946};\\\", \\\"{x:719,y:547,t:1527271903162};\\\", \\\"{x:724,y:547,t:1527271903172};\\\", \\\"{x:730,y:546,t:1527271903179};\\\", \\\"{x:746,y:544,t:1527271903196};\\\", \\\"{x:761,y:544,t:1527271903213};\\\", \\\"{x:777,y:544,t:1527271903230};\\\", \\\"{x:794,y:544,t:1527271903246};\\\", \\\"{x:810,y:544,t:1527271903263};\\\", \\\"{x:824,y:544,t:1527271903281};\\\", \\\"{x:836,y:544,t:1527271903296};\\\", \\\"{x:851,y:543,t:1527271903313};\\\", \\\"{x:856,y:543,t:1527271903329};\\\", \\\"{x:859,y:543,t:1527271903347};\\\", \\\"{x:860,y:543,t:1527271903418};\\\", \\\"{x:861,y:543,t:1527271903430};\\\", \\\"{x:864,y:547,t:1527271903447};\\\", \\\"{x:868,y:551,t:1527271903464};\\\", \\\"{x:874,y:555,t:1527271903480};\\\", \\\"{x:883,y:560,t:1527271903497};\\\", \\\"{x:895,y:560,t:1527271903513};\\\", \\\"{x:897,y:559,t:1527271903531};\\\", \\\"{x:899,y:559,t:1527271903746};\\\", \\\"{x:905,y:559,t:1527271903754};\\\", \\\"{x:913,y:560,t:1527271903764};\\\", \\\"{x:937,y:563,t:1527271903782};\\\", \\\"{x:965,y:563,t:1527271903797};\\\", \\\"{x:990,y:563,t:1527271903813};\\\", \\\"{x:1011,y:563,t:1527271903829};\\\", \\\"{x:1037,y:563,t:1527271903846};\\\", \\\"{x:1059,y:560,t:1527271903863};\\\", \\\"{x:1080,y:558,t:1527271903880};\\\", \\\"{x:1098,y:554,t:1527271903896};\\\", \\\"{x:1116,y:550,t:1527271903914};\\\", \\\"{x:1122,y:549,t:1527271903930};\\\", \\\"{x:1128,y:548,t:1527271903947};\\\", \\\"{x:1133,y:546,t:1527271903963};\\\", \\\"{x:1144,y:546,t:1527271903980};\\\", \\\"{x:1160,y:546,t:1527271903997};\\\", \\\"{x:1182,y:546,t:1527271904013};\\\", \\\"{x:1206,y:546,t:1527271904029};\\\", \\\"{x:1234,y:546,t:1527271904046};\\\", \\\"{x:1257,y:546,t:1527271904064};\\\", \\\"{x:1273,y:544,t:1527271904079};\\\", \\\"{x:1286,y:541,t:1527271904096};\\\", \\\"{x:1290,y:540,t:1527271904114};\\\", \\\"{x:1294,y:540,t:1527271904401};\\\", \\\"{x:1296,y:540,t:1527271904412};\\\", \\\"{x:1302,y:541,t:1527271904429};\\\", \\\"{x:1307,y:541,t:1527271904446};\\\", \\\"{x:1312,y:542,t:1527271904462};\\\", \\\"{x:1313,y:542,t:1527271904479};\\\", \\\"{x:1314,y:543,t:1527271904529};\\\", \\\"{x:1315,y:543,t:1527271904666};\\\", \\\"{x:1317,y:543,t:1527271904680};\\\", \\\"{x:1324,y:543,t:1527271904697};\\\", \\\"{x:1333,y:539,t:1527271904713};\\\", \\\"{x:1354,y:530,t:1527271904730};\\\", \\\"{x:1367,y:523,t:1527271904746};\\\", \\\"{x:1381,y:513,t:1527271904763};\\\", \\\"{x:1398,y:496,t:1527271904780};\\\", \\\"{x:1422,y:455,t:1527271904797};\\\", \\\"{x:1441,y:418,t:1527271904812};\\\", \\\"{x:1460,y:383,t:1527271904830};\\\", \\\"{x:1466,y:367,t:1527271904846};\\\", \\\"{x:1467,y:359,t:1527271904863};\\\", \\\"{x:1467,y:357,t:1527271904880};\\\", \\\"{x:1467,y:356,t:1527271904897};\\\", \\\"{x:1467,y:355,t:1527271904913};\\\", \\\"{x:1466,y:353,t:1527271904930};\\\", \\\"{x:1465,y:352,t:1527271904946};\\\", \\\"{x:1464,y:352,t:1527271905130};\\\", \\\"{x:1461,y:353,t:1527271905146};\\\", \\\"{x:1454,y:369,t:1527271905163};\\\", \\\"{x:1452,y:391,t:1527271905180};\\\", \\\"{x:1450,y:411,t:1527271905196};\\\", \\\"{x:1450,y:416,t:1527271905213};\\\", \\\"{x:1450,y:417,t:1527271905230};\\\", \\\"{x:1450,y:419,t:1527271905290};\\\", \\\"{x:1450,y:423,t:1527271905306};\\\", \\\"{x:1450,y:426,t:1527271905313};\\\", \\\"{x:1453,y:434,t:1527271905330};\\\", \\\"{x:1455,y:441,t:1527271905345};\\\", \\\"{x:1458,y:446,t:1527271905363};\\\", \\\"{x:1459,y:452,t:1527271905380};\\\", \\\"{x:1463,y:460,t:1527271905396};\\\", \\\"{x:1464,y:467,t:1527271905413};\\\", \\\"{x:1464,y:476,t:1527271905429};\\\", \\\"{x:1464,y:485,t:1527271905446};\\\", \\\"{x:1461,y:498,t:1527271905463};\\\", \\\"{x:1456,y:510,t:1527271905480};\\\", \\\"{x:1453,y:517,t:1527271905496};\\\", \\\"{x:1448,y:524,t:1527271905513};\\\", \\\"{x:1443,y:530,t:1527271905529};\\\", \\\"{x:1439,y:533,t:1527271905546};\\\", \\\"{x:1435,y:536,t:1527271905563};\\\", \\\"{x:1431,y:540,t:1527271905580};\\\", \\\"{x:1428,y:545,t:1527271905596};\\\", \\\"{x:1425,y:549,t:1527271905613};\\\", \\\"{x:1421,y:555,t:1527271905629};\\\", \\\"{x:1417,y:559,t:1527271905648};\\\", \\\"{x:1411,y:563,t:1527271905662};\\\", \\\"{x:1403,y:567,t:1527271905679};\\\", \\\"{x:1391,y:569,t:1527271905696};\\\", \\\"{x:1372,y:572,t:1527271905713};\\\", \\\"{x:1356,y:572,t:1527271905729};\\\", \\\"{x:1326,y:572,t:1527271905745};\\\", \\\"{x:1304,y:572,t:1527271905763};\\\", \\\"{x:1284,y:572,t:1527271905793};\\\", \\\"{x:1266,y:572,t:1527271905795};\\\", \\\"{x:1250,y:572,t:1527271905812};\\\", \\\"{x:1232,y:572,t:1527271905829};\\\", \\\"{x:1215,y:572,t:1527271905845};\\\", \\\"{x:1199,y:572,t:1527271905863};\\\", \\\"{x:1183,y:572,t:1527271905878};\\\", \\\"{x:1169,y:572,t:1527271905895};\\\", \\\"{x:1155,y:572,t:1527271905912};\\\", \\\"{x:1141,y:572,t:1527271905928};\\\", \\\"{x:1121,y:572,t:1527271905945};\\\", \\\"{x:1104,y:572,t:1527271905962};\\\", \\\"{x:1084,y:572,t:1527271905979};\\\", \\\"{x:1061,y:572,t:1527271905996};\\\", \\\"{x:1040,y:572,t:1527271906012};\\\", \\\"{x:1017,y:572,t:1527271906028};\\\", \\\"{x:998,y:572,t:1527271906045};\\\", \\\"{x:987,y:572,t:1527271906062};\\\", \\\"{x:981,y:572,t:1527271906078};\\\", \\\"{x:979,y:572,t:1527271906095};\\\", \\\"{x:976,y:571,t:1527271906113};\\\", \\\"{x:973,y:569,t:1527271906128};\\\", \\\"{x:963,y:564,t:1527271906145};\\\", \\\"{x:951,y:560,t:1527271906162};\\\", \\\"{x:939,y:555,t:1527271906179};\\\", \\\"{x:930,y:550,t:1527271906195};\\\", \\\"{x:926,y:549,t:1527271906209};\\\", \\\"{x:925,y:548,t:1527271906226};\\\", \\\"{x:935,y:546,t:1527271906242};\\\", \\\"{x:970,y:544,t:1527271906260};\\\", \\\"{x:1038,y:541,t:1527271906277};\\\", \\\"{x:1163,y:541,t:1527271906298};\\\", \\\"{x:1255,y:544,t:1527271906315};\\\", \\\"{x:1345,y:559,t:1527271906333};\\\", \\\"{x:1425,y:570,t:1527271906349};\\\", \\\"{x:1486,y:583,t:1527271906365};\\\", \\\"{x:1525,y:594,t:1527271906383};\\\", \\\"{x:1542,y:603,t:1527271906399};\\\", \\\"{x:1549,y:608,t:1527271906416};\\\", \\\"{x:1550,y:609,t:1527271906433};\\\", \\\"{x:1550,y:612,t:1527271906449};\\\", \\\"{x:1542,y:622,t:1527271906466};\\\", \\\"{x:1534,y:630,t:1527271906483};\\\", \\\"{x:1522,y:640,t:1527271906499};\\\", \\\"{x:1512,y:644,t:1527271906515};\\\", \\\"{x:1503,y:650,t:1527271906533};\\\", \\\"{x:1488,y:655,t:1527271906549};\\\", \\\"{x:1477,y:656,t:1527271906566};\\\", \\\"{x:1463,y:659,t:1527271906582};\\\", \\\"{x:1446,y:660,t:1527271906599};\\\", \\\"{x:1427,y:664,t:1527271906616};\\\", \\\"{x:1414,y:666,t:1527271906632};\\\", \\\"{x:1399,y:673,t:1527271906649};\\\", \\\"{x:1394,y:676,t:1527271906665};\\\", \\\"{x:1391,y:678,t:1527271906682};\\\", \\\"{x:1391,y:679,t:1527271906699};\\\", \\\"{x:1389,y:680,t:1527271906715};\\\", \\\"{x:1389,y:682,t:1527271906733};\\\", \\\"{x:1388,y:685,t:1527271906749};\\\", \\\"{x:1387,y:686,t:1527271906765};\\\", \\\"{x:1387,y:685,t:1527271906802};\\\", \\\"{x:1387,y:683,t:1527271906815};\\\", \\\"{x:1388,y:673,t:1527271906833};\\\", \\\"{x:1396,y:656,t:1527271906849};\\\", \\\"{x:1403,y:640,t:1527271906866};\\\", \\\"{x:1413,y:625,t:1527271906882};\\\", \\\"{x:1414,y:623,t:1527271906899};\\\", \\\"{x:1415,y:622,t:1527271906916};\\\", \\\"{x:1415,y:621,t:1527271906933};\\\", \\\"{x:1415,y:619,t:1527271906950};\\\", \\\"{x:1409,y:617,t:1527271906967};\\\", \\\"{x:1397,y:613,t:1527271906982};\\\", \\\"{x:1383,y:612,t:1527271907000};\\\", \\\"{x:1367,y:609,t:1527271907016};\\\", \\\"{x:1351,y:607,t:1527271907032};\\\", \\\"{x:1330,y:604,t:1527271907049};\\\", \\\"{x:1317,y:601,t:1527271907066};\\\", \\\"{x:1311,y:598,t:1527271907083};\\\", \\\"{x:1310,y:597,t:1527271907099};\\\", \\\"{x:1311,y:595,t:1527271907116};\\\", \\\"{x:1314,y:592,t:1527271907132};\\\", \\\"{x:1320,y:585,t:1527271907150};\\\", \\\"{x:1325,y:578,t:1527271907167};\\\", \\\"{x:1331,y:568,t:1527271907183};\\\", \\\"{x:1333,y:564,t:1527271907199};\\\", \\\"{x:1334,y:562,t:1527271907216};\\\", \\\"{x:1334,y:564,t:1527271907321};\\\", \\\"{x:1334,y:568,t:1527271907333};\\\", \\\"{x:1328,y:580,t:1527271907349};\\\", \\\"{x:1322,y:593,t:1527271907367};\\\", \\\"{x:1316,y:604,t:1527271907384};\\\", \\\"{x:1311,y:613,t:1527271907399};\\\", \\\"{x:1309,y:619,t:1527271907416};\\\", \\\"{x:1305,y:629,t:1527271907434};\\\", \\\"{x:1305,y:634,t:1527271907450};\\\", \\\"{x:1305,y:641,t:1527271907466};\\\", \\\"{x:1304,y:652,t:1527271907484};\\\", \\\"{x:1300,y:664,t:1527271907500};\\\", \\\"{x:1296,y:676,t:1527271907516};\\\", \\\"{x:1294,y:686,t:1527271907534};\\\", \\\"{x:1290,y:696,t:1527271907550};\\\", \\\"{x:1289,y:703,t:1527271907567};\\\", \\\"{x:1289,y:710,t:1527271907584};\\\", \\\"{x:1289,y:715,t:1527271907600};\\\", \\\"{x:1292,y:719,t:1527271907617};\\\", \\\"{x:1301,y:729,t:1527271907634};\\\", \\\"{x:1307,y:736,t:1527271907650};\\\", \\\"{x:1314,y:745,t:1527271907667};\\\", \\\"{x:1319,y:750,t:1527271907684};\\\", \\\"{x:1321,y:751,t:1527271907700};\\\", \\\"{x:1322,y:752,t:1527271907717};\\\", \\\"{x:1322,y:755,t:1527271907734};\\\", \\\"{x:1322,y:756,t:1527271907750};\\\", \\\"{x:1322,y:759,t:1527271907767};\\\", \\\"{x:1322,y:760,t:1527271907784};\\\", \\\"{x:1322,y:762,t:1527271907800};\\\", \\\"{x:1322,y:763,t:1527271907833};\\\", \\\"{x:1321,y:763,t:1527271907866};\\\", \\\"{x:1320,y:763,t:1527271907884};\\\", \\\"{x:1319,y:765,t:1527271907901};\\\", \\\"{x:1318,y:765,t:1527271907917};\\\", \\\"{x:1316,y:765,t:1527271907934};\\\", \\\"{x:1314,y:765,t:1527271907954};\\\", \\\"{x:1312,y:765,t:1527271907967};\\\", \\\"{x:1308,y:764,t:1527271907984};\\\", \\\"{x:1302,y:764,t:1527271908001};\\\", \\\"{x:1298,y:764,t:1527271908017};\\\", \\\"{x:1294,y:764,t:1527271908034};\\\", \\\"{x:1293,y:764,t:1527271908052};\\\", \\\"{x:1292,y:765,t:1527271908130};\\\", \\\"{x:1290,y:766,t:1527271908154};\\\", \\\"{x:1289,y:767,t:1527271908170};\\\", \\\"{x:1288,y:767,t:1527271908184};\\\", \\\"{x:1284,y:768,t:1527271908201};\\\", \\\"{x:1281,y:769,t:1527271908217};\\\", \\\"{x:1280,y:769,t:1527271908233};\\\", \\\"{x:1279,y:769,t:1527271908250};\\\", \\\"{x:1277,y:770,t:1527271908268};\\\", \\\"{x:1276,y:772,t:1527271908283};\\\", \\\"{x:1275,y:772,t:1527271908300};\\\", \\\"{x:1274,y:773,t:1527271908317};\\\", \\\"{x:1273,y:774,t:1527271908337};\\\", \\\"{x:1272,y:775,t:1527271908370};\\\", \\\"{x:1271,y:775,t:1527271908473};\\\", \\\"{x:1270,y:776,t:1527271909594};\\\", \\\"{x:1269,y:778,t:1527271909618};\\\", \\\"{x:1268,y:779,t:1527271909650};\\\", \\\"{x:1268,y:780,t:1527271909674};\\\", \\\"{x:1267,y:780,t:1527271909690};\\\", \\\"{x:1267,y:781,t:1527271909706};\\\", \\\"{x:1267,y:782,t:1527271909722};\\\", \\\"{x:1266,y:782,t:1527271909738};\\\", \\\"{x:1266,y:783,t:1527271909752};\\\", \\\"{x:1264,y:784,t:1527271909769};\\\", \\\"{x:1263,y:786,t:1527271909786};\\\", \\\"{x:1261,y:788,t:1527271909802};\\\", \\\"{x:1261,y:789,t:1527271909819};\\\", \\\"{x:1259,y:790,t:1527271909835};\\\", \\\"{x:1259,y:791,t:1527271909852};\\\", \\\"{x:1258,y:792,t:1527271909869};\\\", \\\"{x:1258,y:793,t:1527271909885};\\\", \\\"{x:1258,y:794,t:1527271909902};\\\", \\\"{x:1256,y:795,t:1527271909919};\\\", \\\"{x:1256,y:797,t:1527271909946};\\\", \\\"{x:1255,y:798,t:1527271910003};\\\", \\\"{x:1255,y:799,t:1527271910026};\\\", \\\"{x:1256,y:799,t:1527271910753};\\\", \\\"{x:1257,y:799,t:1527271910768};\\\", \\\"{x:1266,y:799,t:1527271910786};\\\", \\\"{x:1276,y:799,t:1527271910803};\\\", \\\"{x:1288,y:799,t:1527271910819};\\\", \\\"{x:1296,y:797,t:1527271910835};\\\", \\\"{x:1301,y:797,t:1527271910853};\\\", \\\"{x:1305,y:795,t:1527271910868};\\\", \\\"{x:1309,y:795,t:1527271910886};\\\", \\\"{x:1311,y:795,t:1527271910902};\\\", \\\"{x:1313,y:795,t:1527271910920};\\\", \\\"{x:1317,y:795,t:1527271910936};\\\", \\\"{x:1320,y:794,t:1527271910953};\\\", \\\"{x:1327,y:793,t:1527271910969};\\\", \\\"{x:1330,y:793,t:1527271910986};\\\", \\\"{x:1332,y:792,t:1527271911003};\\\", \\\"{x:1333,y:792,t:1527271911020};\\\", \\\"{x:1334,y:791,t:1527271911036};\\\", \\\"{x:1335,y:789,t:1527271911053};\\\", \\\"{x:1337,y:786,t:1527271911070};\\\", \\\"{x:1338,y:781,t:1527271911086};\\\", \\\"{x:1341,y:777,t:1527271911103};\\\", \\\"{x:1342,y:773,t:1527271911121};\\\", \\\"{x:1342,y:770,t:1527271911137};\\\", \\\"{x:1342,y:769,t:1527271911153};\\\", \\\"{x:1342,y:768,t:1527271911290};\\\", \\\"{x:1342,y:767,t:1527271911314};\\\", \\\"{x:1341,y:767,t:1527271911346};\\\", \\\"{x:1339,y:767,t:1527271911354};\\\", \\\"{x:1333,y:767,t:1527271911370};\\\", \\\"{x:1327,y:767,t:1527271911387};\\\", \\\"{x:1322,y:768,t:1527271911404};\\\", \\\"{x:1316,y:769,t:1527271911420};\\\", \\\"{x:1311,y:771,t:1527271911437};\\\", \\\"{x:1308,y:772,t:1527271911453};\\\", \\\"{x:1307,y:772,t:1527271911470};\\\", \\\"{x:1306,y:773,t:1527271911546};\\\", \\\"{x:1305,y:774,t:1527271911561};\\\", \\\"{x:1304,y:775,t:1527271911585};\\\", \\\"{x:1304,y:776,t:1527271911657};\\\", \\\"{x:1304,y:777,t:1527271911673};\\\", \\\"{x:1304,y:778,t:1527271911687};\\\", \\\"{x:1307,y:786,t:1527271911703};\\\", \\\"{x:1320,y:799,t:1527271911720};\\\", \\\"{x:1337,y:808,t:1527271911737};\\\", \\\"{x:1376,y:817,t:1527271911753};\\\", \\\"{x:1398,y:821,t:1527271911770};\\\", \\\"{x:1420,y:821,t:1527271911787};\\\", \\\"{x:1441,y:823,t:1527271911803};\\\", \\\"{x:1454,y:823,t:1527271911820};\\\", \\\"{x:1462,y:824,t:1527271911837};\\\", \\\"{x:1468,y:825,t:1527271911854};\\\", \\\"{x:1470,y:825,t:1527271911870};\\\", \\\"{x:1471,y:825,t:1527271911905};\\\", \\\"{x:1472,y:825,t:1527271911920};\\\", \\\"{x:1477,y:826,t:1527271911937};\\\", \\\"{x:1486,y:827,t:1527271911953};\\\", \\\"{x:1495,y:828,t:1527271911971};\\\", \\\"{x:1501,y:829,t:1527271911987};\\\", \\\"{x:1505,y:830,t:1527271912005};\\\", \\\"{x:1508,y:831,t:1527271912021};\\\", \\\"{x:1509,y:832,t:1527271912037};\\\", \\\"{x:1512,y:834,t:1527271912054};\\\", \\\"{x:1516,y:838,t:1527271912070};\\\", \\\"{x:1518,y:839,t:1527271912087};\\\", \\\"{x:1520,y:839,t:1527271912104};\\\", \\\"{x:1520,y:838,t:1527271912187};\\\", \\\"{x:1519,y:837,t:1527271912204};\\\", \\\"{x:1515,y:837,t:1527271912221};\\\", \\\"{x:1509,y:836,t:1527271912238};\\\", \\\"{x:1500,y:835,t:1527271912255};\\\", \\\"{x:1489,y:834,t:1527271912272};\\\", \\\"{x:1484,y:834,t:1527271912288};\\\", \\\"{x:1479,y:834,t:1527271912304};\\\", \\\"{x:1477,y:834,t:1527271912321};\\\", \\\"{x:1478,y:834,t:1527271912379};\\\", \\\"{x:1480,y:834,t:1527271912387};\\\", \\\"{x:1484,y:834,t:1527271912404};\\\", \\\"{x:1488,y:834,t:1527271912421};\\\", \\\"{x:1489,y:834,t:1527271912436};\\\", \\\"{x:1490,y:834,t:1527271912454};\\\", \\\"{x:1491,y:834,t:1527271912617};\\\", \\\"{x:1493,y:834,t:1527271912626};\\\", \\\"{x:1494,y:834,t:1527271912641};\\\", \\\"{x:1496,y:834,t:1527271912654};\\\", \\\"{x:1499,y:834,t:1527271912670};\\\", \\\"{x:1500,y:834,t:1527271912688};\\\", \\\"{x:1501,y:834,t:1527271912704};\\\", \\\"{x:1502,y:834,t:1527271912763};\\\", \\\"{x:1503,y:834,t:1527271912771};\\\", \\\"{x:1504,y:834,t:1527271912906};\\\", \\\"{x:1505,y:834,t:1527271912922};\\\", \\\"{x:1504,y:834,t:1527271913002};\\\", \\\"{x:1500,y:834,t:1527271913009};\\\", \\\"{x:1496,y:834,t:1527271913021};\\\", \\\"{x:1485,y:834,t:1527271913039};\\\", \\\"{x:1469,y:834,t:1527271913056};\\\", \\\"{x:1450,y:834,t:1527271913072};\\\", \\\"{x:1431,y:833,t:1527271913088};\\\", \\\"{x:1399,y:829,t:1527271913106};\\\", \\\"{x:1388,y:827,t:1527271913121};\\\", \\\"{x:1361,y:820,t:1527271913138};\\\", \\\"{x:1351,y:816,t:1527271913155};\\\", \\\"{x:1342,y:811,t:1527271913171};\\\", \\\"{x:1339,y:805,t:1527271913188};\\\", \\\"{x:1339,y:801,t:1527271913206};\\\", \\\"{x:1338,y:794,t:1527271913221};\\\", \\\"{x:1338,y:789,t:1527271913238};\\\", \\\"{x:1338,y:782,t:1527271913254};\\\", \\\"{x:1338,y:778,t:1527271913271};\\\", \\\"{x:1338,y:774,t:1527271913288};\\\", \\\"{x:1338,y:772,t:1527271913305};\\\", \\\"{x:1338,y:770,t:1527271913321};\\\", \\\"{x:1343,y:764,t:1527271913337};\\\", \\\"{x:1346,y:759,t:1527271913355};\\\", \\\"{x:1347,y:757,t:1527271913371};\\\", \\\"{x:1347,y:755,t:1527271913387};\\\", \\\"{x:1346,y:755,t:1527271913530};\\\", \\\"{x:1345,y:755,t:1527271913546};\\\", \\\"{x:1343,y:755,t:1527271913555};\\\", \\\"{x:1342,y:759,t:1527271913573};\\\", \\\"{x:1340,y:762,t:1527271913588};\\\", \\\"{x:1340,y:763,t:1527271913706};\\\", \\\"{x:1340,y:767,t:1527271913721};\\\", \\\"{x:1340,y:770,t:1527271913738};\\\", \\\"{x:1340,y:773,t:1527271913755};\\\", \\\"{x:1341,y:774,t:1527271913772};\\\", \\\"{x:1342,y:774,t:1527271913890};\\\", \\\"{x:1343,y:774,t:1527271913914};\\\", \\\"{x:1344,y:774,t:1527271913922};\\\", \\\"{x:1344,y:773,t:1527271913939};\\\", \\\"{x:1345,y:773,t:1527271913956};\\\", \\\"{x:1345,y:772,t:1527271913972};\\\", \\\"{x:1345,y:770,t:1527271914002};\\\", \\\"{x:1346,y:770,t:1527271914026};\\\", \\\"{x:1347,y:768,t:1527271914315};\\\", \\\"{x:1347,y:767,t:1527271915019};\\\", \\\"{x:1348,y:766,t:1527271915033};\\\", \\\"{x:1348,y:765,t:1527271915042};\\\", \\\"{x:1348,y:764,t:1527271915066};\\\", \\\"{x:1348,y:762,t:1527271915082};\\\", \\\"{x:1348,y:761,t:1527271915122};\\\", \\\"{x:1348,y:759,t:1527271915145};\\\", \\\"{x:1348,y:757,t:1527271915157};\\\", \\\"{x:1348,y:755,t:1527271915173};\\\", \\\"{x:1348,y:753,t:1527271915190};\\\", \\\"{x:1348,y:752,t:1527271915206};\\\", \\\"{x:1348,y:751,t:1527271915226};\\\", \\\"{x:1348,y:750,t:1527271915242};\\\", \\\"{x:1348,y:749,t:1527271915256};\\\", \\\"{x:1348,y:748,t:1527271915273};\\\", \\\"{x:1348,y:746,t:1527271915290};\\\", \\\"{x:1348,y:745,t:1527271915306};\\\", \\\"{x:1348,y:744,t:1527271915323};\\\", \\\"{x:1348,y:743,t:1527271915340};\\\", \\\"{x:1348,y:742,t:1527271915357};\\\", \\\"{x:1348,y:740,t:1527271915373};\\\", \\\"{x:1348,y:739,t:1527271915391};\\\", \\\"{x:1348,y:736,t:1527271915407};\\\", \\\"{x:1348,y:732,t:1527271915423};\\\", \\\"{x:1348,y:729,t:1527271915441};\\\", \\\"{x:1348,y:726,t:1527271915457};\\\", \\\"{x:1348,y:724,t:1527271915474};\\\", \\\"{x:1348,y:721,t:1527271915490};\\\", \\\"{x:1348,y:719,t:1527271915507};\\\", \\\"{x:1348,y:716,t:1527271915523};\\\", \\\"{x:1347,y:710,t:1527271915541};\\\", \\\"{x:1346,y:701,t:1527271915556};\\\", \\\"{x:1345,y:693,t:1527271915573};\\\", \\\"{x:1344,y:683,t:1527271915591};\\\", \\\"{x:1341,y:668,t:1527271915607};\\\", \\\"{x:1341,y:653,t:1527271915623};\\\", \\\"{x:1340,y:643,t:1527271915641};\\\", \\\"{x:1337,y:633,t:1527271915657};\\\", \\\"{x:1330,y:618,t:1527271915674};\\\", \\\"{x:1325,y:606,t:1527271915690};\\\", \\\"{x:1321,y:599,t:1527271915706};\\\", \\\"{x:1315,y:592,t:1527271915723};\\\", \\\"{x:1306,y:585,t:1527271915740};\\\", \\\"{x:1296,y:578,t:1527271915757};\\\", \\\"{x:1288,y:574,t:1527271915772};\\\", \\\"{x:1280,y:570,t:1527271915790};\\\", \\\"{x:1276,y:568,t:1527271915806};\\\", \\\"{x:1269,y:565,t:1527271915823};\\\", \\\"{x:1267,y:564,t:1527271915840};\\\", \\\"{x:1264,y:563,t:1527271915857};\\\", \\\"{x:1262,y:562,t:1527271915874};\\\", \\\"{x:1264,y:562,t:1527271916137};\\\", \\\"{x:1266,y:562,t:1527271916161};\\\", \\\"{x:1267,y:562,t:1527271916234};\\\", \\\"{x:1268,y:562,t:1527271916266};\\\", \\\"{x:1270,y:562,t:1527271916514};\\\", \\\"{x:1271,y:562,t:1527271916524};\\\", \\\"{x:1275,y:562,t:1527271916540};\\\", \\\"{x:1282,y:562,t:1527271916557};\\\", \\\"{x:1290,y:562,t:1527271916575};\\\", \\\"{x:1299,y:562,t:1527271916591};\\\", \\\"{x:1304,y:562,t:1527271916606};\\\", \\\"{x:1310,y:562,t:1527271916624};\\\", \\\"{x:1323,y:562,t:1527271916642};\\\", \\\"{x:1327,y:562,t:1527271916657};\\\", \\\"{x:1328,y:562,t:1527271916674};\\\", \\\"{x:1329,y:562,t:1527271916785};\\\", \\\"{x:1330,y:562,t:1527271916793};\\\", \\\"{x:1331,y:562,t:1527271916809};\\\", \\\"{x:1332,y:562,t:1527271916823};\\\", \\\"{x:1342,y:562,t:1527271916841};\\\", \\\"{x:1355,y:562,t:1527271916857};\\\", \\\"{x:1365,y:562,t:1527271916874};\\\", \\\"{x:1370,y:562,t:1527271916890};\\\", \\\"{x:1371,y:562,t:1527271916907};\\\", \\\"{x:1372,y:562,t:1527271916929};\\\", \\\"{x:1374,y:562,t:1527271916978};\\\", \\\"{x:1376,y:562,t:1527271916991};\\\", \\\"{x:1383,y:562,t:1527271917007};\\\", \\\"{x:1390,y:562,t:1527271917024};\\\", \\\"{x:1403,y:562,t:1527271917041};\\\", \\\"{x:1415,y:562,t:1527271917058};\\\", \\\"{x:1420,y:562,t:1527271917075};\\\", \\\"{x:1422,y:562,t:1527271917091};\\\", \\\"{x:1423,y:562,t:1527271917107};\\\", \\\"{x:1427,y:562,t:1527271917290};\\\", \\\"{x:1443,y:562,t:1527271917308};\\\", \\\"{x:1464,y:562,t:1527271917325};\\\", \\\"{x:1484,y:562,t:1527271917341};\\\", \\\"{x:1501,y:562,t:1527271917358};\\\", \\\"{x:1509,y:562,t:1527271917375};\\\", \\\"{x:1510,y:562,t:1527271917391};\\\", \\\"{x:1509,y:562,t:1527271917570};\\\", \\\"{x:1506,y:562,t:1527271917577};\\\", \\\"{x:1502,y:562,t:1527271917591};\\\", \\\"{x:1496,y:562,t:1527271917608};\\\", \\\"{x:1490,y:562,t:1527271917625};\\\", \\\"{x:1491,y:562,t:1527271917698};\\\", \\\"{x:1496,y:562,t:1527271917708};\\\", \\\"{x:1509,y:562,t:1527271917725};\\\", \\\"{x:1520,y:562,t:1527271917741};\\\", \\\"{x:1532,y:562,t:1527271917758};\\\", \\\"{x:1542,y:562,t:1527271917775};\\\", \\\"{x:1551,y:562,t:1527271917792};\\\", \\\"{x:1559,y:562,t:1527271917808};\\\", \\\"{x:1568,y:562,t:1527271917825};\\\", \\\"{x:1570,y:562,t:1527271917841};\\\", \\\"{x:1571,y:562,t:1527271917995};\\\", \\\"{x:1572,y:562,t:1527271918009};\\\", \\\"{x:1577,y:562,t:1527271918026};\\\", \\\"{x:1582,y:562,t:1527271918042};\\\", \\\"{x:1593,y:562,t:1527271918059};\\\", \\\"{x:1603,y:562,t:1527271918075};\\\", \\\"{x:1612,y:562,t:1527271918092};\\\", \\\"{x:1615,y:562,t:1527271918109};\\\", \\\"{x:1617,y:562,t:1527271918234};\\\", \\\"{x:1620,y:562,t:1527271918241};\\\", \\\"{x:1641,y:562,t:1527271918258};\\\", \\\"{x:1676,y:566,t:1527271918275};\\\", \\\"{x:1710,y:566,t:1527271918292};\\\", \\\"{x:1741,y:566,t:1527271918309};\\\", \\\"{x:1761,y:566,t:1527271918326};\\\", \\\"{x:1767,y:566,t:1527271918342};\\\", \\\"{x:1766,y:566,t:1527271918458};\\\", \\\"{x:1759,y:566,t:1527271918475};\\\", \\\"{x:1747,y:566,t:1527271918492};\\\", \\\"{x:1737,y:566,t:1527271918509};\\\", \\\"{x:1732,y:566,t:1527271918525};\\\", \\\"{x:1725,y:566,t:1527271918543};\\\", \\\"{x:1723,y:566,t:1527271918560};\\\", \\\"{x:1722,y:566,t:1527271918576};\\\", \\\"{x:1721,y:566,t:1527271918594};\\\", \\\"{x:1718,y:566,t:1527271918610};\\\", \\\"{x:1714,y:566,t:1527271918626};\\\", \\\"{x:1709,y:566,t:1527271918643};\\\", \\\"{x:1704,y:566,t:1527271918660};\\\", \\\"{x:1696,y:566,t:1527271918675};\\\", \\\"{x:1689,y:566,t:1527271918693};\\\", \\\"{x:1683,y:566,t:1527271918710};\\\", \\\"{x:1679,y:566,t:1527271918726};\\\", \\\"{x:1677,y:566,t:1527271918743};\\\", \\\"{x:1672,y:566,t:1527271921713};\\\", \\\"{x:1663,y:566,t:1527271921728};\\\", \\\"{x:1638,y:566,t:1527271921744};\\\", \\\"{x:1564,y:566,t:1527271921761};\\\", \\\"{x:1475,y:566,t:1527271921778};\\\", \\\"{x:1359,y:566,t:1527271921794};\\\", \\\"{x:1228,y:569,t:1527271921811};\\\", \\\"{x:1081,y:590,t:1527271921829};\\\", \\\"{x:938,y:605,t:1527271921845};\\\", \\\"{x:790,y:616,t:1527271921860};\\\", \\\"{x:659,y:622,t:1527271921879};\\\", \\\"{x:534,y:639,t:1527271921890};\\\", \\\"{x:432,y:653,t:1527271921908};\\\", \\\"{x:379,y:653,t:1527271921923};\\\", \\\"{x:352,y:649,t:1527271921945};\\\", \\\"{x:349,y:644,t:1527271921962};\\\", \\\"{x:348,y:637,t:1527271921978};\\\", \\\"{x:348,y:627,t:1527271921995};\\\", \\\"{x:346,y:623,t:1527271922012};\\\", \\\"{x:345,y:615,t:1527271922027};\\\", \\\"{x:345,y:609,t:1527271922045};\\\", \\\"{x:345,y:603,t:1527271922062};\\\", \\\"{x:345,y:596,t:1527271922078};\\\", \\\"{x:347,y:586,t:1527271922095};\\\", \\\"{x:355,y:575,t:1527271922112};\\\", \\\"{x:367,y:561,t:1527271922129};\\\", \\\"{x:379,y:552,t:1527271922145};\\\", \\\"{x:385,y:544,t:1527271922162};\\\", \\\"{x:388,y:541,t:1527271922178};\\\", \\\"{x:389,y:539,t:1527271922195};\\\", \\\"{x:389,y:538,t:1527271922212};\\\", \\\"{x:389,y:537,t:1527271922257};\\\", \\\"{x:390,y:536,t:1527271922273};\\\", \\\"{x:395,y:535,t:1527271922282};\\\", \\\"{x:403,y:534,t:1527271922295};\\\", \\\"{x:431,y:534,t:1527271922314};\\\", \\\"{x:515,y:528,t:1527271922329};\\\", \\\"{x:593,y:528,t:1527271922346};\\\", \\\"{x:643,y:528,t:1527271922362};\\\", \\\"{x:676,y:524,t:1527271922380};\\\", \\\"{x:689,y:524,t:1527271922396};\\\", \\\"{x:690,y:524,t:1527271922412};\\\", \\\"{x:688,y:524,t:1527271922450};\\\", \\\"{x:687,y:524,t:1527271922462};\\\", \\\"{x:683,y:524,t:1527271922479};\\\", \\\"{x:676,y:523,t:1527271922496};\\\", \\\"{x:666,y:522,t:1527271922513};\\\", \\\"{x:657,y:522,t:1527271922529};\\\", \\\"{x:647,y:522,t:1527271922546};\\\", \\\"{x:642,y:521,t:1527271922564};\\\", \\\"{x:640,y:520,t:1527271922580};\\\", \\\"{x:639,y:519,t:1527271922596};\\\", \\\"{x:639,y:515,t:1527271922615};\\\", \\\"{x:637,y:512,t:1527271922632};\\\", \\\"{x:633,y:509,t:1527271922645};\\\", \\\"{x:626,y:508,t:1527271922662};\\\", \\\"{x:619,y:505,t:1527271922679};\\\", \\\"{x:617,y:505,t:1527271922696};\\\", \\\"{x:616,y:505,t:1527271922712};\\\", \\\"{x:615,y:515,t:1527271922977};\\\", \\\"{x:610,y:541,t:1527271922997};\\\", \\\"{x:598,y:569,t:1527271923014};\\\", \\\"{x:584,y:589,t:1527271923029};\\\", \\\"{x:571,y:607,t:1527271923046};\\\", \\\"{x:563,y:619,t:1527271923062};\\\", \\\"{x:555,y:633,t:1527271923079};\\\", \\\"{x:550,y:645,t:1527271923096};\\\", \\\"{x:539,y:667,t:1527271923113};\\\", \\\"{x:535,y:680,t:1527271923129};\\\", \\\"{x:532,y:694,t:1527271923147};\\\", \\\"{x:527,y:711,t:1527271923163};\\\", \\\"{x:523,y:723,t:1527271923180};\\\", \\\"{x:520,y:727,t:1527271923196};\\\", \\\"{x:519,y:728,t:1527271923213};\\\", \\\"{x:517,y:732,t:1527271923229};\\\", \\\"{x:515,y:736,t:1527271923247};\\\", \\\"{x:512,y:741,t:1527271923263};\\\", \\\"{x:509,y:748,t:1527271923280};\\\", \\\"{x:508,y:750,t:1527271923296};\\\", \\\"{x:507,y:750,t:1527271923313};\\\" ] }, { \\\"rt\\\": 15970, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 361354, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -B -J -I -I -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:749,t:1527271926032};\\\", \\\"{x:506,y:747,t:1527271926048};\\\", \\\"{x:506,y:742,t:1527271926063};\\\", \\\"{x:506,y:732,t:1527271926080};\\\", \\\"{x:509,y:715,t:1527271926097};\\\", \\\"{x:519,y:684,t:1527271926113};\\\", \\\"{x:529,y:663,t:1527271926132};\\\", \\\"{x:536,y:646,t:1527271926148};\\\", \\\"{x:539,y:637,t:1527271926166};\\\", \\\"{x:539,y:638,t:1527271926658};\\\", \\\"{x:541,y:641,t:1527271926706};\\\", \\\"{x:541,y:643,t:1527271926745};\\\", \\\"{x:541,y:644,t:1527271926754};\\\", \\\"{x:541,y:645,t:1527271926767};\\\", \\\"{x:540,y:647,t:1527271926782};\\\", \\\"{x:539,y:647,t:1527271926800};\\\", \\\"{x:544,y:650,t:1527271926938};\\\", \\\"{x:555,y:651,t:1527271926950};\\\", \\\"{x:581,y:652,t:1527271926967};\\\", \\\"{x:595,y:652,t:1527271926983};\\\", \\\"{x:606,y:649,t:1527271927000};\\\", \\\"{x:629,y:643,t:1527271927017};\\\", \\\"{x:668,y:634,t:1527271927034};\\\", \\\"{x:686,y:627,t:1527271927051};\\\", \\\"{x:700,y:617,t:1527271927066};\\\", \\\"{x:701,y:618,t:1527271927321};\\\", \\\"{x:715,y:620,t:1527271927333};\\\", \\\"{x:737,y:622,t:1527271927351};\\\", \\\"{x:767,y:623,t:1527271927367};\\\", \\\"{x:817,y:623,t:1527271927383};\\\", \\\"{x:888,y:612,t:1527271927400};\\\", \\\"{x:954,y:593,t:1527271927418};\\\", \\\"{x:1050,y:550,t:1527271927433};\\\", \\\"{x:1100,y:526,t:1527271927449};\\\", \\\"{x:1129,y:517,t:1527271927466};\\\", \\\"{x:1149,y:513,t:1527271927483};\\\", \\\"{x:1159,y:512,t:1527271927499};\\\", \\\"{x:1161,y:510,t:1527271927516};\\\", \\\"{x:1164,y:510,t:1527271927533};\\\", \\\"{x:1165,y:510,t:1527271927553};\\\", \\\"{x:1166,y:510,t:1527271927566};\\\", \\\"{x:1169,y:510,t:1527271927583};\\\", \\\"{x:1176,y:511,t:1527271927850};\\\", \\\"{x:1191,y:511,t:1527271927867};\\\", \\\"{x:1200,y:511,t:1527271927884};\\\", \\\"{x:1215,y:509,t:1527271927901};\\\", \\\"{x:1238,y:508,t:1527271927917};\\\", \\\"{x:1261,y:508,t:1527271927934};\\\", \\\"{x:1278,y:508,t:1527271927950};\\\", \\\"{x:1293,y:507,t:1527271927967};\\\", \\\"{x:1304,y:506,t:1527271927984};\\\", \\\"{x:1308,y:505,t:1527271928001};\\\", \\\"{x:1309,y:505,t:1527271928017};\\\", \\\"{x:1310,y:505,t:1527271928098};\\\", \\\"{x:1312,y:505,t:1527271928106};\\\", \\\"{x:1315,y:505,t:1527271928122};\\\", \\\"{x:1317,y:505,t:1527271928134};\\\", \\\"{x:1322,y:505,t:1527271928151};\\\", \\\"{x:1326,y:505,t:1527271928168};\\\", \\\"{x:1327,y:505,t:1527271928362};\\\", \\\"{x:1327,y:506,t:1527271928562};\\\", \\\"{x:1327,y:507,t:1527271928570};\\\", \\\"{x:1327,y:508,t:1527271928584};\\\", \\\"{x:1326,y:509,t:1527271928600};\\\", \\\"{x:1325,y:509,t:1527271928616};\\\", \\\"{x:1323,y:509,t:1527271928635};\\\", \\\"{x:1321,y:510,t:1527271928650};\\\", \\\"{x:1318,y:511,t:1527271928667};\\\", \\\"{x:1315,y:512,t:1527271928684};\\\", \\\"{x:1310,y:512,t:1527271928700};\\\", \\\"{x:1307,y:514,t:1527271928717};\\\", \\\"{x:1301,y:515,t:1527271928734};\\\", \\\"{x:1296,y:516,t:1527271928751};\\\", \\\"{x:1291,y:518,t:1527271928768};\\\", \\\"{x:1289,y:519,t:1527271928785};\\\", \\\"{x:1285,y:519,t:1527271928801};\\\", \\\"{x:1283,y:519,t:1527271928817};\\\", \\\"{x:1281,y:519,t:1527271928834};\\\", \\\"{x:1279,y:519,t:1527271928850};\\\", \\\"{x:1278,y:518,t:1527271928867};\\\", \\\"{x:1279,y:518,t:1527271929178};\\\", \\\"{x:1280,y:518,t:1527271929186};\\\", \\\"{x:1281,y:518,t:1527271929201};\\\", \\\"{x:1283,y:518,t:1527271929217};\\\", \\\"{x:1286,y:518,t:1527271929234};\\\", \\\"{x:1288,y:518,t:1527271929252};\\\", \\\"{x:1291,y:518,t:1527271929268};\\\", \\\"{x:1294,y:518,t:1527271929285};\\\", \\\"{x:1297,y:518,t:1527271929301};\\\", \\\"{x:1299,y:518,t:1527271929318};\\\", \\\"{x:1300,y:518,t:1527271929335};\\\", \\\"{x:1301,y:518,t:1527271929352};\\\", \\\"{x:1303,y:514,t:1527271930027};\\\", \\\"{x:1304,y:513,t:1527271930036};\\\", \\\"{x:1304,y:512,t:1527271930057};\\\", \\\"{x:1306,y:512,t:1527271930347};\\\", \\\"{x:1307,y:512,t:1527271930361};\\\", \\\"{x:1309,y:512,t:1527271930378};\\\", \\\"{x:1310,y:512,t:1527271930385};\\\", \\\"{x:1312,y:512,t:1527271930403};\\\", \\\"{x:1314,y:512,t:1527271930419};\\\", \\\"{x:1317,y:512,t:1527271930436};\\\", \\\"{x:1323,y:512,t:1527271930453};\\\", \\\"{x:1328,y:512,t:1527271930469};\\\", \\\"{x:1335,y:512,t:1527271930486};\\\", \\\"{x:1342,y:512,t:1527271930503};\\\", \\\"{x:1350,y:513,t:1527271930519};\\\", \\\"{x:1360,y:513,t:1527271930536};\\\", \\\"{x:1376,y:515,t:1527271930554};\\\", \\\"{x:1383,y:515,t:1527271930569};\\\", \\\"{x:1413,y:521,t:1527271930585};\\\", \\\"{x:1435,y:523,t:1527271930603};\\\", \\\"{x:1458,y:528,t:1527271930619};\\\", \\\"{x:1476,y:533,t:1527271930636};\\\", \\\"{x:1487,y:539,t:1527271930653};\\\", \\\"{x:1493,y:544,t:1527271930669};\\\", \\\"{x:1495,y:552,t:1527271930687};\\\", \\\"{x:1495,y:560,t:1527271930702};\\\", \\\"{x:1494,y:570,t:1527271930719};\\\", \\\"{x:1490,y:578,t:1527271930735};\\\", \\\"{x:1486,y:586,t:1527271930752};\\\", \\\"{x:1481,y:594,t:1527271930769};\\\", \\\"{x:1475,y:600,t:1527271930785};\\\", \\\"{x:1468,y:609,t:1527271930803};\\\", \\\"{x:1459,y:620,t:1527271930819};\\\", \\\"{x:1449,y:633,t:1527271930837};\\\", \\\"{x:1441,y:644,t:1527271930853};\\\", \\\"{x:1437,y:651,t:1527271930870};\\\", \\\"{x:1434,y:656,t:1527271930886};\\\", \\\"{x:1432,y:662,t:1527271930902};\\\", \\\"{x:1430,y:666,t:1527271930920};\\\", \\\"{x:1430,y:671,t:1527271930936};\\\", \\\"{x:1430,y:677,t:1527271930953};\\\", \\\"{x:1430,y:686,t:1527271930969};\\\", \\\"{x:1431,y:692,t:1527271930986};\\\", \\\"{x:1435,y:700,t:1527271931003};\\\", \\\"{x:1440,y:706,t:1527271931020};\\\", \\\"{x:1443,y:710,t:1527271931036};\\\", \\\"{x:1448,y:716,t:1527271931053};\\\", \\\"{x:1452,y:721,t:1527271931070};\\\", \\\"{x:1464,y:728,t:1527271931086};\\\", \\\"{x:1476,y:734,t:1527271931103};\\\", \\\"{x:1482,y:736,t:1527271931120};\\\", \\\"{x:1486,y:739,t:1527271931136};\\\", \\\"{x:1487,y:741,t:1527271931153};\\\", \\\"{x:1486,y:747,t:1527271931169};\\\", \\\"{x:1472,y:751,t:1527271931187};\\\", \\\"{x:1446,y:755,t:1527271931203};\\\", \\\"{x:1418,y:756,t:1527271931221};\\\", \\\"{x:1377,y:756,t:1527271931238};\\\", \\\"{x:1342,y:756,t:1527271931254};\\\", \\\"{x:1318,y:756,t:1527271931270};\\\", \\\"{x:1304,y:756,t:1527271931287};\\\", \\\"{x:1301,y:756,t:1527271931303};\\\", \\\"{x:1309,y:756,t:1527271931345};\\\", \\\"{x:1314,y:756,t:1527271931354};\\\", \\\"{x:1327,y:756,t:1527271931369};\\\", \\\"{x:1335,y:756,t:1527271931387};\\\", \\\"{x:1340,y:756,t:1527271931402};\\\", \\\"{x:1341,y:756,t:1527271931420};\\\", \\\"{x:1342,y:756,t:1527271931618};\\\", \\\"{x:1342,y:758,t:1527271931634};\\\", \\\"{x:1342,y:759,t:1527271931649};\\\", \\\"{x:1342,y:761,t:1527271931705};\\\", \\\"{x:1342,y:762,t:1527271931729};\\\", \\\"{x:1343,y:763,t:1527271931753};\\\", \\\"{x:1344,y:764,t:1527271931770};\\\", \\\"{x:1345,y:765,t:1527271931786};\\\", \\\"{x:1346,y:766,t:1527271932426};\\\", \\\"{x:1346,y:767,t:1527271932441};\\\", \\\"{x:1346,y:768,t:1527271932465};\\\", \\\"{x:1346,y:769,t:1527271932491};\\\", \\\"{x:1344,y:769,t:1527271932529};\\\", \\\"{x:1343,y:769,t:1527271932545};\\\", \\\"{x:1342,y:770,t:1527271932554};\\\", \\\"{x:1336,y:773,t:1527271932572};\\\", \\\"{x:1324,y:781,t:1527271932588};\\\", \\\"{x:1311,y:787,t:1527271932604};\\\", \\\"{x:1298,y:796,t:1527271932622};\\\", \\\"{x:1289,y:800,t:1527271932638};\\\", \\\"{x:1282,y:805,t:1527271932654};\\\", \\\"{x:1275,y:808,t:1527271932671};\\\", \\\"{x:1269,y:811,t:1527271932688};\\\", \\\"{x:1262,y:814,t:1527271932704};\\\", \\\"{x:1256,y:815,t:1527271932721};\\\", \\\"{x:1247,y:818,t:1527271932738};\\\", \\\"{x:1243,y:819,t:1527271932754};\\\", \\\"{x:1242,y:819,t:1527271932771};\\\", \\\"{x:1239,y:821,t:1527271932789};\\\", \\\"{x:1237,y:822,t:1527271932804};\\\", \\\"{x:1234,y:822,t:1527271932821};\\\", \\\"{x:1228,y:822,t:1527271932838};\\\", \\\"{x:1222,y:823,t:1527271932854};\\\", \\\"{x:1216,y:823,t:1527271932871};\\\", \\\"{x:1210,y:823,t:1527271932888};\\\", \\\"{x:1205,y:823,t:1527271932905};\\\", \\\"{x:1202,y:823,t:1527271932922};\\\", \\\"{x:1201,y:823,t:1527271932938};\\\", \\\"{x:1200,y:823,t:1527271933042};\\\", \\\"{x:1199,y:820,t:1527271933058};\\\", \\\"{x:1197,y:811,t:1527271933071};\\\", \\\"{x:1190,y:784,t:1527271933088};\\\", \\\"{x:1182,y:763,t:1527271933106};\\\", \\\"{x:1174,y:750,t:1527271933122};\\\", \\\"{x:1174,y:749,t:1527271933138};\\\", \\\"{x:1173,y:749,t:1527271933314};\\\", \\\"{x:1172,y:749,t:1527271933337};\\\", \\\"{x:1172,y:752,t:1527271933355};\\\", \\\"{x:1172,y:761,t:1527271933371};\\\", \\\"{x:1172,y:767,t:1527271933387};\\\", \\\"{x:1172,y:768,t:1527271933457};\\\", \\\"{x:1174,y:768,t:1527271933754};\\\", \\\"{x:1175,y:768,t:1527271933772};\\\", \\\"{x:1178,y:767,t:1527271933802};\\\", \\\"{x:1179,y:767,t:1527271936849};\\\", \\\"{x:1180,y:767,t:1527271936857};\\\", \\\"{x:1181,y:767,t:1527271936874};\\\", \\\"{x:1183,y:767,t:1527271936904};\\\", \\\"{x:1184,y:767,t:1527271936913};\\\", \\\"{x:1189,y:767,t:1527271936924};\\\", \\\"{x:1199,y:767,t:1527271936941};\\\", \\\"{x:1212,y:767,t:1527271936957};\\\", \\\"{x:1229,y:767,t:1527271936974};\\\", \\\"{x:1248,y:767,t:1527271936990};\\\", \\\"{x:1258,y:767,t:1527271937008};\\\", \\\"{x:1262,y:767,t:1527271937024};\\\", \\\"{x:1264,y:767,t:1527271937041};\\\", \\\"{x:1266,y:766,t:1527271937305};\\\", \\\"{x:1270,y:765,t:1527271937313};\\\", \\\"{x:1273,y:765,t:1527271937325};\\\", \\\"{x:1282,y:763,t:1527271937341};\\\", \\\"{x:1296,y:763,t:1527271937358};\\\", \\\"{x:1311,y:763,t:1527271937374};\\\", \\\"{x:1324,y:763,t:1527271937391};\\\", \\\"{x:1336,y:763,t:1527271937408};\\\", \\\"{x:1339,y:763,t:1527271937425};\\\", \\\"{x:1338,y:763,t:1527271937601};\\\", \\\"{x:1336,y:763,t:1527271937609};\\\", \\\"{x:1332,y:763,t:1527271937625};\\\", \\\"{x:1331,y:763,t:1527271937641};\\\", \\\"{x:1328,y:763,t:1527271937658};\\\", \\\"{x:1325,y:763,t:1527271937675};\\\", \\\"{x:1322,y:763,t:1527271937691};\\\", \\\"{x:1319,y:763,t:1527271937708};\\\", \\\"{x:1318,y:763,t:1527271937761};\\\", \\\"{x:1319,y:763,t:1527271937856};\\\", \\\"{x:1323,y:763,t:1527271937865};\\\", \\\"{x:1327,y:763,t:1527271937874};\\\", \\\"{x:1335,y:763,t:1527271937891};\\\", \\\"{x:1345,y:763,t:1527271937908};\\\", \\\"{x:1356,y:763,t:1527271937924};\\\", \\\"{x:1361,y:763,t:1527271937942};\\\", \\\"{x:1365,y:763,t:1527271937958};\\\", \\\"{x:1366,y:763,t:1527271937974};\\\", \\\"{x:1368,y:763,t:1527271937991};\\\", \\\"{x:1369,y:763,t:1527271938008};\\\", \\\"{x:1370,y:763,t:1527271938024};\\\", \\\"{x:1372,y:762,t:1527271938042};\\\", \\\"{x:1373,y:762,t:1527271938137};\\\", \\\"{x:1374,y:762,t:1527271938169};\\\", \\\"{x:1375,y:762,t:1527271938193};\\\", \\\"{x:1375,y:761,t:1527271938208};\\\", \\\"{x:1377,y:761,t:1527271938225};\\\", \\\"{x:1379,y:761,t:1527271938242};\\\", \\\"{x:1382,y:761,t:1527271938259};\\\", \\\"{x:1384,y:761,t:1527271938275};\\\", \\\"{x:1385,y:761,t:1527271938292};\\\", \\\"{x:1383,y:761,t:1527271938369};\\\", \\\"{x:1381,y:761,t:1527271938376};\\\", \\\"{x:1376,y:761,t:1527271938392};\\\", \\\"{x:1354,y:761,t:1527271938409};\\\", \\\"{x:1325,y:761,t:1527271938425};\\\", \\\"{x:1281,y:761,t:1527271938442};\\\", \\\"{x:1203,y:761,t:1527271938459};\\\", \\\"{x:1117,y:761,t:1527271938475};\\\", \\\"{x:1030,y:746,t:1527271938492};\\\", \\\"{x:943,y:727,t:1527271938508};\\\", \\\"{x:863,y:704,t:1527271938524};\\\", \\\"{x:802,y:687,t:1527271938542};\\\", \\\"{x:768,y:676,t:1527271938559};\\\", \\\"{x:743,y:669,t:1527271938576};\\\", \\\"{x:729,y:668,t:1527271938592};\\\", \\\"{x:712,y:665,t:1527271938609};\\\", \\\"{x:701,y:664,t:1527271938626};\\\", \\\"{x:688,y:661,t:1527271938641};\\\", \\\"{x:673,y:659,t:1527271938659};\\\", \\\"{x:655,y:658,t:1527271938675};\\\", \\\"{x:633,y:656,t:1527271938692};\\\", \\\"{x:607,y:654,t:1527271938709};\\\", \\\"{x:589,y:653,t:1527271938725};\\\", \\\"{x:568,y:650,t:1527271938742};\\\", \\\"{x:549,y:647,t:1527271938759};\\\", \\\"{x:532,y:645,t:1527271938776};\\\", \\\"{x:518,y:643,t:1527271938792};\\\", \\\"{x:497,y:642,t:1527271938809};\\\", \\\"{x:483,y:639,t:1527271938825};\\\", \\\"{x:479,y:639,t:1527271938839};\\\", \\\"{x:465,y:639,t:1527271938857};\\\", \\\"{x:460,y:638,t:1527271938873};\\\", \\\"{x:458,y:636,t:1527271938890};\\\", \\\"{x:457,y:634,t:1527271938909};\\\", \\\"{x:457,y:633,t:1527271938926};\\\", \\\"{x:455,y:633,t:1527271939200};\\\", \\\"{x:448,y:636,t:1527271939217};\\\", \\\"{x:445,y:639,t:1527271939233};\\\", \\\"{x:442,y:640,t:1527271939250};\\\", \\\"{x:442,y:637,t:1527271939312};\\\", \\\"{x:444,y:631,t:1527271939320};\\\", \\\"{x:447,y:622,t:1527271939333};\\\", \\\"{x:448,y:604,t:1527271939350};\\\", \\\"{x:453,y:577,t:1527271939368};\\\", \\\"{x:453,y:555,t:1527271939383};\\\", \\\"{x:452,y:538,t:1527271939400};\\\", \\\"{x:450,y:533,t:1527271939417};\\\", \\\"{x:445,y:531,t:1527271939434};\\\", \\\"{x:435,y:527,t:1527271939450};\\\", \\\"{x:422,y:524,t:1527271939468};\\\", \\\"{x:411,y:523,t:1527271939484};\\\", \\\"{x:397,y:519,t:1527271939500};\\\", \\\"{x:387,y:513,t:1527271939517};\\\", \\\"{x:385,y:511,t:1527271939533};\\\", \\\"{x:383,y:510,t:1527271939550};\\\", \\\"{x:383,y:511,t:1527271939584};\\\", \\\"{x:386,y:528,t:1527271939600};\\\", \\\"{x:388,y:548,t:1527271939617};\\\", \\\"{x:388,y:567,t:1527271939634};\\\", \\\"{x:381,y:578,t:1527271939650};\\\", \\\"{x:371,y:583,t:1527271939668};\\\", \\\"{x:358,y:583,t:1527271939684};\\\", \\\"{x:337,y:581,t:1527271939699};\\\", \\\"{x:311,y:576,t:1527271939717};\\\", \\\"{x:276,y:568,t:1527271939734};\\\", \\\"{x:237,y:562,t:1527271939750};\\\", \\\"{x:208,y:555,t:1527271939767};\\\", \\\"{x:185,y:545,t:1527271939784};\\\", \\\"{x:178,y:540,t:1527271939800};\\\", \\\"{x:177,y:536,t:1527271939817};\\\", \\\"{x:177,y:533,t:1527271939834};\\\", \\\"{x:177,y:530,t:1527271939850};\\\", \\\"{x:178,y:527,t:1527271939868};\\\", \\\"{x:180,y:524,t:1527271939884};\\\", \\\"{x:180,y:523,t:1527271939901};\\\", \\\"{x:180,y:521,t:1527271939917};\\\", \\\"{x:179,y:520,t:1527271939968};\\\", \\\"{x:177,y:520,t:1527271939992};\\\", \\\"{x:174,y:520,t:1527271940001};\\\", \\\"{x:162,y:519,t:1527271940018};\\\", \\\"{x:149,y:513,t:1527271940035};\\\", \\\"{x:146,y:511,t:1527271940051};\\\", \\\"{x:146,y:510,t:1527271940067};\\\", \\\"{x:146,y:509,t:1527271940095};\\\", \\\"{x:146,y:508,t:1527271940104};\\\", \\\"{x:147,y:507,t:1527271940128};\\\", \\\"{x:149,y:506,t:1527271940160};\\\", \\\"{x:151,y:506,t:1527271940232};\\\", \\\"{x:152,y:506,t:1527271940240};\\\", \\\"{x:154,y:505,t:1527271940251};\\\", \\\"{x:154,y:504,t:1527271940267};\\\", \\\"{x:155,y:505,t:1527271940568};\\\", \\\"{x:169,y:509,t:1527271940584};\\\", \\\"{x:196,y:516,t:1527271940601};\\\", \\\"{x:236,y:524,t:1527271940619};\\\", \\\"{x:295,y:543,t:1527271940634};\\\", \\\"{x:363,y:568,t:1527271940652};\\\", \\\"{x:424,y:596,t:1527271940669};\\\", \\\"{x:481,y:629,t:1527271940684};\\\", \\\"{x:514,y:654,t:1527271940701};\\\", \\\"{x:527,y:670,t:1527271940718};\\\", \\\"{x:532,y:682,t:1527271940736};\\\", \\\"{x:533,y:688,t:1527271940751};\\\", \\\"{x:533,y:693,t:1527271940768};\\\", \\\"{x:529,y:701,t:1527271940785};\\\", \\\"{x:528,y:708,t:1527271940801};\\\", \\\"{x:524,y:718,t:1527271940818};\\\", \\\"{x:520,y:727,t:1527271940836};\\\", \\\"{x:517,y:732,t:1527271940852};\\\", \\\"{x:512,y:735,t:1527271940868};\\\", \\\"{x:509,y:737,t:1527271940885};\\\", \\\"{x:505,y:737,t:1527271940902};\\\", \\\"{x:504,y:737,t:1527271940918};\\\", \\\"{x:502,y:739,t:1527271940935};\\\" ] }, { \\\"rt\\\": 24133, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 386706, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -Z -Z -Z -G -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:735,t:1527271943368};\\\", \\\"{x:505,y:697,t:1527271943385};\\\", \\\"{x:526,y:654,t:1527271943405};\\\", \\\"{x:569,y:613,t:1527271943421};\\\", \\\"{x:616,y:582,t:1527271943437};\\\", \\\"{x:654,y:560,t:1527271943453};\\\", \\\"{x:678,y:546,t:1527271943471};\\\", \\\"{x:698,y:535,t:1527271943487};\\\", \\\"{x:720,y:522,t:1527271943503};\\\", \\\"{x:731,y:514,t:1527271943520};\\\", \\\"{x:739,y:508,t:1527271943537};\\\", \\\"{x:744,y:499,t:1527271943553};\\\", \\\"{x:745,y:499,t:1527271943792};\\\", \\\"{x:747,y:499,t:1527271943805};\\\", \\\"{x:755,y:500,t:1527271943821};\\\", \\\"{x:765,y:499,t:1527271943837};\\\", \\\"{x:784,y:495,t:1527271943854};\\\", \\\"{x:799,y:492,t:1527271943871};\\\", \\\"{x:820,y:488,t:1527271943887};\\\", \\\"{x:868,y:488,t:1527271943904};\\\", \\\"{x:895,y:488,t:1527271943921};\\\", \\\"{x:918,y:488,t:1527271943939};\\\", \\\"{x:936,y:489,t:1527271943954};\\\", \\\"{x:947,y:491,t:1527271943972};\\\", \\\"{x:958,y:492,t:1527271943988};\\\", \\\"{x:970,y:494,t:1527271944004};\\\", \\\"{x:987,y:499,t:1527271944020};\\\", \\\"{x:1020,y:505,t:1527271944037};\\\", \\\"{x:1068,y:513,t:1527271944054};\\\", \\\"{x:1122,y:516,t:1527271944070};\\\", \\\"{x:1178,y:516,t:1527271944087};\\\", \\\"{x:1292,y:516,t:1527271944104};\\\", \\\"{x:1368,y:521,t:1527271944120};\\\", \\\"{x:1435,y:532,t:1527271944138};\\\", \\\"{x:1492,y:541,t:1527271944154};\\\", \\\"{x:1534,y:555,t:1527271944170};\\\", \\\"{x:1556,y:560,t:1527271944188};\\\", \\\"{x:1568,y:564,t:1527271944204};\\\", \\\"{x:1569,y:564,t:1527271944220};\\\", \\\"{x:1570,y:564,t:1527271944240};\\\", \\\"{x:1566,y:561,t:1527271944254};\\\", \\\"{x:1563,y:561,t:1527271944553};\\\", \\\"{x:1558,y:565,t:1527271944561};\\\", \\\"{x:1554,y:568,t:1527271944571};\\\", \\\"{x:1545,y:575,t:1527271944587};\\\", \\\"{x:1531,y:581,t:1527271944605};\\\", \\\"{x:1515,y:591,t:1527271944622};\\\", \\\"{x:1496,y:602,t:1527271944638};\\\", \\\"{x:1477,y:614,t:1527271944655};\\\", \\\"{x:1457,y:625,t:1527271944672};\\\", \\\"{x:1438,y:636,t:1527271944689};\\\", \\\"{x:1397,y:655,t:1527271944704};\\\", \\\"{x:1373,y:666,t:1527271944722};\\\", \\\"{x:1348,y:677,t:1527271944738};\\\", \\\"{x:1325,y:686,t:1527271944755};\\\", \\\"{x:1313,y:691,t:1527271944772};\\\", \\\"{x:1307,y:694,t:1527271944788};\\\", \\\"{x:1305,y:695,t:1527271944805};\\\", \\\"{x:1304,y:695,t:1527271944821};\\\", \\\"{x:1304,y:696,t:1527271944922};\\\", \\\"{x:1306,y:700,t:1527271944940};\\\", \\\"{x:1312,y:706,t:1527271944955};\\\", \\\"{x:1317,y:709,t:1527271944972};\\\", \\\"{x:1321,y:709,t:1527271944989};\\\", \\\"{x:1324,y:709,t:1527271945005};\\\", \\\"{x:1326,y:709,t:1527271945022};\\\", \\\"{x:1327,y:709,t:1527271945040};\\\", \\\"{x:1328,y:707,t:1527271945089};\\\", \\\"{x:1328,y:706,t:1527271945105};\\\", \\\"{x:1328,y:705,t:1527271945122};\\\", \\\"{x:1329,y:704,t:1527271945139};\\\", \\\"{x:1329,y:703,t:1527271945155};\\\", \\\"{x:1329,y:702,t:1527271945185};\\\", \\\"{x:1329,y:701,t:1527271945193};\\\", \\\"{x:1329,y:700,t:1527271945208};\\\", \\\"{x:1330,y:700,t:1527271945222};\\\", \\\"{x:1330,y:699,t:1527271945239};\\\", \\\"{x:1331,y:699,t:1527271945255};\\\", \\\"{x:1333,y:698,t:1527271945272};\\\", \\\"{x:1335,y:697,t:1527271945289};\\\", \\\"{x:1336,y:697,t:1527271945313};\\\", \\\"{x:1338,y:697,t:1527271945329};\\\", \\\"{x:1340,y:697,t:1527271945433};\\\", \\\"{x:1341,y:697,t:1527271945440};\\\", \\\"{x:1342,y:698,t:1527271945456};\\\", \\\"{x:1343,y:698,t:1527271945471};\\\", \\\"{x:1345,y:698,t:1527271945488};\\\", \\\"{x:1346,y:698,t:1527271945544};\\\", \\\"{x:1347,y:696,t:1527271945559};\\\", \\\"{x:1347,y:695,t:1527271945572};\\\", \\\"{x:1348,y:691,t:1527271945589};\\\", \\\"{x:1348,y:692,t:1527271945978};\\\", \\\"{x:1348,y:693,t:1527271946009};\\\", \\\"{x:1348,y:695,t:1527271947089};\\\", \\\"{x:1359,y:698,t:1527271947108};\\\", \\\"{x:1374,y:698,t:1527271947123};\\\", \\\"{x:1395,y:698,t:1527271947140};\\\", \\\"{x:1418,y:698,t:1527271947157};\\\", \\\"{x:1438,y:698,t:1527271947174};\\\", \\\"{x:1451,y:698,t:1527271947190};\\\", \\\"{x:1454,y:698,t:1527271947207};\\\", \\\"{x:1453,y:698,t:1527271947305};\\\", \\\"{x:1450,y:698,t:1527271947313};\\\", \\\"{x:1447,y:697,t:1527271947323};\\\", \\\"{x:1440,y:695,t:1527271947340};\\\", \\\"{x:1435,y:694,t:1527271947356};\\\", \\\"{x:1429,y:693,t:1527271947373};\\\", \\\"{x:1428,y:693,t:1527271947390};\\\", \\\"{x:1431,y:693,t:1527271947432};\\\", \\\"{x:1434,y:693,t:1527271947440};\\\", \\\"{x:1442,y:694,t:1527271947456};\\\", \\\"{x:1453,y:697,t:1527271947473};\\\", \\\"{x:1459,y:697,t:1527271947490};\\\", \\\"{x:1463,y:697,t:1527271947506};\\\", \\\"{x:1464,y:697,t:1527271947523};\\\", \\\"{x:1465,y:698,t:1527271947551};\\\", \\\"{x:1467,y:698,t:1527271947567};\\\", \\\"{x:1468,y:698,t:1527271947576};\\\", \\\"{x:1469,y:698,t:1527271947589};\\\", \\\"{x:1472,y:699,t:1527271947606};\\\", \\\"{x:1473,y:699,t:1527271947623};\\\", \\\"{x:1474,y:699,t:1527271947744};\\\", \\\"{x:1475,y:699,t:1527271947756};\\\", \\\"{x:1478,y:699,t:1527271947773};\\\", \\\"{x:1483,y:699,t:1527271947790};\\\", \\\"{x:1497,y:699,t:1527271947807};\\\", \\\"{x:1514,y:699,t:1527271947824};\\\", \\\"{x:1536,y:699,t:1527271947839};\\\", \\\"{x:1542,y:699,t:1527271947856};\\\", \\\"{x:1543,y:699,t:1527271947873};\\\", \\\"{x:1544,y:699,t:1527271948065};\\\", \\\"{x:1547,y:699,t:1527271948074};\\\", \\\"{x:1560,y:699,t:1527271948092};\\\", \\\"{x:1580,y:699,t:1527271948107};\\\", \\\"{x:1601,y:699,t:1527271948124};\\\", \\\"{x:1621,y:699,t:1527271948141};\\\", \\\"{x:1631,y:699,t:1527271948158};\\\", \\\"{x:1635,y:699,t:1527271948174};\\\", \\\"{x:1635,y:698,t:1527271948225};\\\", \\\"{x:1638,y:698,t:1527271948241};\\\", \\\"{x:1640,y:698,t:1527271948258};\\\", \\\"{x:1637,y:698,t:1527271948361};\\\", \\\"{x:1632,y:699,t:1527271948374};\\\", \\\"{x:1625,y:701,t:1527271948392};\\\", \\\"{x:1621,y:701,t:1527271948408};\\\", \\\"{x:1620,y:701,t:1527271948433};\\\", \\\"{x:1620,y:700,t:1527271948593};\\\", \\\"{x:1620,y:698,t:1527271948609};\\\", \\\"{x:1621,y:697,t:1527271948626};\\\", \\\"{x:1619,y:697,t:1527271949490};\\\", \\\"{x:1614,y:698,t:1527271949508};\\\", \\\"{x:1611,y:700,t:1527271949525};\\\", \\\"{x:1610,y:700,t:1527271949542};\\\", \\\"{x:1609,y:700,t:1527271949730};\\\", \\\"{x:1609,y:699,t:1527271949865};\\\", \\\"{x:1609,y:698,t:1527271950049};\\\", \\\"{x:1610,y:697,t:1527271950073};\\\", \\\"{x:1610,y:696,t:1527271950129};\\\", \\\"{x:1611,y:695,t:1527271950809};\\\", \\\"{x:1608,y:692,t:1527271956664};\\\", \\\"{x:1573,y:685,t:1527271956680};\\\", \\\"{x:1514,y:675,t:1527271956697};\\\", \\\"{x:1463,y:667,t:1527271956713};\\\", \\\"{x:1439,y:664,t:1527271956730};\\\", \\\"{x:1425,y:662,t:1527271956747};\\\", \\\"{x:1420,y:660,t:1527271956763};\\\", \\\"{x:1419,y:660,t:1527271956832};\\\", \\\"{x:1414,y:655,t:1527271956847};\\\", \\\"{x:1390,y:635,t:1527271956864};\\\", \\\"{x:1368,y:615,t:1527271956880};\\\", \\\"{x:1340,y:593,t:1527271956897};\\\", \\\"{x:1329,y:582,t:1527271956914};\\\", \\\"{x:1323,y:575,t:1527271956930};\\\", \\\"{x:1319,y:567,t:1527271956947};\\\", \\\"{x:1317,y:559,t:1527271956964};\\\", \\\"{x:1316,y:552,t:1527271956980};\\\", \\\"{x:1315,y:546,t:1527271956997};\\\", \\\"{x:1312,y:542,t:1527271957015};\\\", \\\"{x:1311,y:542,t:1527271957064};\\\", \\\"{x:1309,y:542,t:1527271957080};\\\", \\\"{x:1309,y:543,t:1527271957097};\\\", \\\"{x:1309,y:544,t:1527271957115};\\\", \\\"{x:1321,y:549,t:1527271957130};\\\", \\\"{x:1342,y:552,t:1527271957148};\\\", \\\"{x:1368,y:556,t:1527271957165};\\\", \\\"{x:1388,y:556,t:1527271957180};\\\", \\\"{x:1409,y:556,t:1527271957197};\\\", \\\"{x:1415,y:558,t:1527271957215};\\\", \\\"{x:1416,y:558,t:1527271957230};\\\", \\\"{x:1417,y:559,t:1527271957249};\\\", \\\"{x:1419,y:559,t:1527271957418};\\\", \\\"{x:1422,y:559,t:1527271957432};\\\", \\\"{x:1429,y:559,t:1527271957448};\\\", \\\"{x:1438,y:559,t:1527271957465};\\\", \\\"{x:1443,y:559,t:1527271957481};\\\", \\\"{x:1447,y:559,t:1527271957497};\\\", \\\"{x:1450,y:559,t:1527271957514};\\\", \\\"{x:1454,y:558,t:1527271957531};\\\", \\\"{x:1457,y:558,t:1527271957547};\\\", \\\"{x:1458,y:558,t:1527271957565};\\\", \\\"{x:1459,y:558,t:1527271957582};\\\", \\\"{x:1462,y:558,t:1527271957597};\\\", \\\"{x:1469,y:558,t:1527271957614};\\\", \\\"{x:1474,y:558,t:1527271957631};\\\", \\\"{x:1476,y:558,t:1527271957647};\\\", \\\"{x:1477,y:558,t:1527271957673};\\\", \\\"{x:1479,y:558,t:1527271957762};\\\", \\\"{x:1482,y:558,t:1527271957777};\\\", \\\"{x:1485,y:558,t:1527271957785};\\\", \\\"{x:1490,y:558,t:1527271957799};\\\", \\\"{x:1499,y:558,t:1527271957814};\\\", \\\"{x:1505,y:558,t:1527271957831};\\\", \\\"{x:1507,y:558,t:1527271957849};\\\", \\\"{x:1508,y:558,t:1527271957865};\\\", \\\"{x:1509,y:558,t:1527271957913};\\\", \\\"{x:1511,y:558,t:1527271957921};\\\", \\\"{x:1512,y:558,t:1527271957931};\\\", \\\"{x:1513,y:558,t:1527271957948};\\\", \\\"{x:1514,y:559,t:1527271957969};\\\", \\\"{x:1515,y:559,t:1527271957982};\\\", \\\"{x:1518,y:560,t:1527271957998};\\\", \\\"{x:1519,y:560,t:1527271958017};\\\", \\\"{x:1519,y:561,t:1527271958033};\\\", \\\"{x:1521,y:561,t:1527271958081};\\\", \\\"{x:1522,y:561,t:1527271958121};\\\", \\\"{x:1524,y:561,t:1527271958217};\\\", \\\"{x:1526,y:561,t:1527271958233};\\\", \\\"{x:1527,y:561,t:1527271958248};\\\", \\\"{x:1529,y:562,t:1527271958265};\\\", \\\"{x:1531,y:562,t:1527271958281};\\\", \\\"{x:1535,y:562,t:1527271958299};\\\", \\\"{x:1538,y:562,t:1527271958315};\\\", \\\"{x:1547,y:564,t:1527271958332};\\\", \\\"{x:1557,y:564,t:1527271958348};\\\", \\\"{x:1565,y:564,t:1527271958366};\\\", \\\"{x:1574,y:564,t:1527271958381};\\\", \\\"{x:1579,y:564,t:1527271958398};\\\", \\\"{x:1581,y:564,t:1527271958473};\\\", \\\"{x:1583,y:564,t:1527271958482};\\\", \\\"{x:1587,y:564,t:1527271958499};\\\", \\\"{x:1593,y:564,t:1527271958515};\\\", \\\"{x:1598,y:564,t:1527271958532};\\\", \\\"{x:1599,y:564,t:1527271958549};\\\", \\\"{x:1601,y:564,t:1527271958566};\\\", \\\"{x:1606,y:566,t:1527271958582};\\\", \\\"{x:1615,y:574,t:1527271958599};\\\", \\\"{x:1625,y:589,t:1527271958616};\\\", \\\"{x:1631,y:607,t:1527271958631};\\\", \\\"{x:1639,y:628,t:1527271958649};\\\", \\\"{x:1640,y:634,t:1527271958665};\\\", \\\"{x:1640,y:638,t:1527271958682};\\\", \\\"{x:1640,y:644,t:1527271958699};\\\", \\\"{x:1640,y:651,t:1527271958716};\\\", \\\"{x:1638,y:663,t:1527271958732};\\\", \\\"{x:1634,y:675,t:1527271958748};\\\", \\\"{x:1633,y:682,t:1527271958765};\\\", \\\"{x:1630,y:690,t:1527271958783};\\\", \\\"{x:1626,y:700,t:1527271958799};\\\", \\\"{x:1624,y:705,t:1527271958816};\\\", \\\"{x:1618,y:714,t:1527271958833};\\\", \\\"{x:1617,y:717,t:1527271958848};\\\", \\\"{x:1614,y:720,t:1527271958866};\\\", \\\"{x:1613,y:720,t:1527271958969};\\\", \\\"{x:1611,y:719,t:1527271958983};\\\", \\\"{x:1610,y:716,t:1527271958998};\\\", \\\"{x:1608,y:712,t:1527271959015};\\\", \\\"{x:1607,y:711,t:1527271959033};\\\", \\\"{x:1606,y:709,t:1527271959049};\\\", \\\"{x:1604,y:715,t:1527271962664};\\\", \\\"{x:1601,y:723,t:1527271962672};\\\", \\\"{x:1595,y:733,t:1527271962684};\\\", \\\"{x:1583,y:754,t:1527271962701};\\\", \\\"{x:1565,y:772,t:1527271962719};\\\", \\\"{x:1543,y:792,t:1527271962734};\\\", \\\"{x:1525,y:806,t:1527271962751};\\\", \\\"{x:1518,y:813,t:1527271962768};\\\", \\\"{x:1516,y:817,t:1527271962785};\\\", \\\"{x:1516,y:818,t:1527271962801};\\\", \\\"{x:1516,y:820,t:1527271962819};\\\", \\\"{x:1518,y:822,t:1527271962834};\\\", \\\"{x:1518,y:823,t:1527271962851};\\\", \\\"{x:1522,y:823,t:1527271962914};\\\", \\\"{x:1526,y:823,t:1527271962921};\\\", \\\"{x:1536,y:823,t:1527271962935};\\\", \\\"{x:1555,y:823,t:1527271962952};\\\", \\\"{x:1584,y:822,t:1527271962969};\\\", \\\"{x:1602,y:819,t:1527271962984};\\\", \\\"{x:1614,y:817,t:1527271963002};\\\", \\\"{x:1616,y:817,t:1527271963019};\\\", \\\"{x:1617,y:817,t:1527271963177};\\\", \\\"{x:1618,y:817,t:1527271963185};\\\", \\\"{x:1619,y:817,t:1527271963202};\\\", \\\"{x:1620,y:818,t:1527271963219};\\\", \\\"{x:1622,y:818,t:1527271963257};\\\", \\\"{x:1621,y:818,t:1527271963609};\\\", \\\"{x:1619,y:818,t:1527271963619};\\\", \\\"{x:1615,y:818,t:1527271963636};\\\", \\\"{x:1614,y:818,t:1527271963652};\\\", \\\"{x:1612,y:818,t:1527271963669};\\\", \\\"{x:1611,y:818,t:1527271963761};\\\", \\\"{x:1610,y:818,t:1527271963769};\\\", \\\"{x:1606,y:818,t:1527271963786};\\\", \\\"{x:1600,y:818,t:1527271963803};\\\", \\\"{x:1593,y:818,t:1527271963819};\\\", \\\"{x:1581,y:818,t:1527271963836};\\\", \\\"{x:1567,y:818,t:1527271963853};\\\", \\\"{x:1549,y:815,t:1527271963869};\\\", \\\"{x:1531,y:813,t:1527271963886};\\\", \\\"{x:1511,y:811,t:1527271963903};\\\", \\\"{x:1500,y:811,t:1527271963918};\\\", \\\"{x:1493,y:811,t:1527271963936};\\\", \\\"{x:1490,y:811,t:1527271963953};\\\", \\\"{x:1489,y:811,t:1527271963977};\\\", \\\"{x:1489,y:813,t:1527271964001};\\\", \\\"{x:1489,y:814,t:1527271964016};\\\", \\\"{x:1488,y:818,t:1527271964024};\\\", \\\"{x:1488,y:820,t:1527271964040};\\\", \\\"{x:1486,y:822,t:1527271964053};\\\", \\\"{x:1483,y:825,t:1527271964070};\\\", \\\"{x:1480,y:829,t:1527271964086};\\\", \\\"{x:1476,y:832,t:1527271964102};\\\", \\\"{x:1472,y:834,t:1527271964121};\\\", \\\"{x:1468,y:835,t:1527271964136};\\\", \\\"{x:1459,y:836,t:1527271964153};\\\", \\\"{x:1448,y:836,t:1527271964170};\\\", \\\"{x:1429,y:836,t:1527271964186};\\\", \\\"{x:1402,y:833,t:1527271964203};\\\", \\\"{x:1371,y:829,t:1527271964219};\\\", \\\"{x:1332,y:823,t:1527271964235};\\\", \\\"{x:1296,y:821,t:1527271964253};\\\", \\\"{x:1265,y:816,t:1527271964269};\\\", \\\"{x:1247,y:814,t:1527271964285};\\\", \\\"{x:1244,y:814,t:1527271964303};\\\", \\\"{x:1246,y:814,t:1527271964335};\\\", \\\"{x:1265,y:814,t:1527271964352};\\\", \\\"{x:1299,y:814,t:1527271964369};\\\", \\\"{x:1341,y:818,t:1527271964386};\\\", \\\"{x:1385,y:818,t:1527271964402};\\\", \\\"{x:1419,y:818,t:1527271964419};\\\", \\\"{x:1442,y:818,t:1527271964435};\\\", \\\"{x:1455,y:818,t:1527271964453};\\\", \\\"{x:1456,y:819,t:1527271964497};\\\", \\\"{x:1459,y:820,t:1527271964521};\\\", \\\"{x:1464,y:822,t:1527271964536};\\\", \\\"{x:1469,y:822,t:1527271964553};\\\", \\\"{x:1478,y:823,t:1527271964570};\\\", \\\"{x:1489,y:823,t:1527271964586};\\\", \\\"{x:1497,y:825,t:1527271964602};\\\", \\\"{x:1498,y:825,t:1527271964620};\\\", \\\"{x:1497,y:825,t:1527271964663};\\\", \\\"{x:1496,y:825,t:1527271964679};\\\", \\\"{x:1495,y:825,t:1527271964687};\\\", \\\"{x:1494,y:825,t:1527271964702};\\\", \\\"{x:1493,y:825,t:1527271964736};\\\", \\\"{x:1492,y:825,t:1527271964753};\\\", \\\"{x:1491,y:825,t:1527271964769};\\\", \\\"{x:1486,y:825,t:1527271964787};\\\", \\\"{x:1480,y:825,t:1527271964803};\\\", \\\"{x:1465,y:825,t:1527271964820};\\\", \\\"{x:1443,y:825,t:1527271964836};\\\", \\\"{x:1414,y:825,t:1527271964853};\\\", \\\"{x:1379,y:825,t:1527271964869};\\\", \\\"{x:1329,y:821,t:1527271964887};\\\", \\\"{x:1265,y:812,t:1527271964903};\\\", \\\"{x:1195,y:800,t:1527271964920};\\\", \\\"{x:1102,y:788,t:1527271964936};\\\", \\\"{x:1041,y:780,t:1527271964953};\\\", \\\"{x:998,y:773,t:1527271964969};\\\", \\\"{x:969,y:767,t:1527271964986};\\\", \\\"{x:947,y:762,t:1527271965004};\\\", \\\"{x:928,y:757,t:1527271965020};\\\", \\\"{x:914,y:752,t:1527271965036};\\\", \\\"{x:902,y:748,t:1527271965053};\\\", \\\"{x:889,y:746,t:1527271965070};\\\", \\\"{x:872,y:741,t:1527271965087};\\\", \\\"{x:840,y:731,t:1527271965106};\\\", \\\"{x:829,y:729,t:1527271965120};\\\", \\\"{x:786,y:717,t:1527271965137};\\\", \\\"{x:756,y:708,t:1527271965153};\\\", \\\"{x:720,y:699,t:1527271965170};\\\", \\\"{x:693,y:688,t:1527271965187};\\\", \\\"{x:679,y:683,t:1527271965205};\\\", \\\"{x:673,y:681,t:1527271965220};\\\", \\\"{x:672,y:679,t:1527271965237};\\\", \\\"{x:671,y:678,t:1527271965504};\\\", \\\"{x:660,y:668,t:1527271965520};\\\", \\\"{x:657,y:665,t:1527271965537};\\\", \\\"{x:655,y:664,t:1527271965553};\\\", \\\"{x:637,y:654,t:1527271965570};\\\", \\\"{x:613,y:642,t:1527271965586};\\\", \\\"{x:591,y:631,t:1527271965603};\\\", \\\"{x:582,y:626,t:1527271965621};\\\", \\\"{x:577,y:623,t:1527271965636};\\\", \\\"{x:576,y:621,t:1527271965655};\\\", \\\"{x:576,y:620,t:1527271965680};\\\", \\\"{x:576,y:618,t:1527271965688};\\\", \\\"{x:579,y:614,t:1527271965705};\\\", \\\"{x:582,y:607,t:1527271965722};\\\", \\\"{x:583,y:598,t:1527271965738};\\\", \\\"{x:583,y:591,t:1527271965755};\\\", \\\"{x:584,y:584,t:1527271965772};\\\", \\\"{x:589,y:573,t:1527271965789};\\\", \\\"{x:594,y:569,t:1527271965805};\\\", \\\"{x:598,y:566,t:1527271965822};\\\", \\\"{x:603,y:563,t:1527271965839};\\\", \\\"{x:607,y:561,t:1527271965856};\\\", \\\"{x:609,y:560,t:1527271965912};\\\", \\\"{x:609,y:559,t:1527271965945};\\\", \\\"{x:608,y:559,t:1527271965976};\\\", \\\"{x:606,y:559,t:1527271965990};\\\", \\\"{x:603,y:559,t:1527271966006};\\\", \\\"{x:602,y:559,t:1527271966024};\\\", \\\"{x:602,y:561,t:1527271966039};\\\", \\\"{x:602,y:564,t:1527271966057};\\\", \\\"{x:610,y:577,t:1527271966073};\\\", \\\"{x:613,y:580,t:1527271966089};\\\", \\\"{x:614,y:581,t:1527271966105};\\\", \\\"{x:614,y:582,t:1527271966122};\\\", \\\"{x:614,y:585,t:1527271966432};\\\", \\\"{x:610,y:594,t:1527271966440};\\\", \\\"{x:592,y:628,t:1527271966456};\\\", \\\"{x:570,y:662,t:1527271966472};\\\", \\\"{x:539,y:690,t:1527271966489};\\\", \\\"{x:520,y:703,t:1527271966506};\\\", \\\"{x:510,y:712,t:1527271966522};\\\", \\\"{x:506,y:717,t:1527271966540};\\\", \\\"{x:504,y:722,t:1527271966556};\\\", \\\"{x:504,y:729,t:1527271966574};\\\", \\\"{x:504,y:736,t:1527271966589};\\\", \\\"{x:504,y:742,t:1527271966606};\\\", \\\"{x:504,y:744,t:1527271966623};\\\", \\\"{x:504,y:746,t:1527271966639};\\\", \\\"{x:504,y:743,t:1527271967424};\\\", \\\"{x:505,y:737,t:1527271967440};\\\", \\\"{x:508,y:727,t:1527271967457};\\\", \\\"{x:508,y:714,t:1527271967473};\\\", \\\"{x:508,y:704,t:1527271967491};\\\" ] }, { \\\"rt\\\": 7867, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 395786, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-04 PM-05 PM-06 PM-05 PM-04 PM-03 PM-02 PM-01 PM-12 PM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:704,t:1527271968183};\\\", \\\"{x:510,y:703,t:1527271968192};\\\", \\\"{x:511,y:702,t:1527271968231};\\\", \\\"{x:512,y:701,t:1527271968247};\\\", \\\"{x:514,y:700,t:1527271968257};\\\", \\\"{x:516,y:698,t:1527271968275};\\\", \\\"{x:520,y:695,t:1527271968291};\\\", \\\"{x:527,y:689,t:1527271968307};\\\", \\\"{x:532,y:685,t:1527271968324};\\\", \\\"{x:541,y:678,t:1527271968341};\\\", \\\"{x:554,y:668,t:1527271968357};\\\", \\\"{x:565,y:660,t:1527271968375};\\\", \\\"{x:582,y:648,t:1527271968391};\\\", \\\"{x:583,y:648,t:1527271968408};\\\", \\\"{x:584,y:647,t:1527271968425};\\\", \\\"{x:594,y:648,t:1527271968615};\\\", \\\"{x:610,y:651,t:1527271968624};\\\", \\\"{x:639,y:660,t:1527271968641};\\\", \\\"{x:671,y:666,t:1527271968657};\\\", \\\"{x:697,y:666,t:1527271968675};\\\", \\\"{x:730,y:670,t:1527271968692};\\\", \\\"{x:768,y:679,t:1527271968708};\\\", \\\"{x:804,y:686,t:1527271968724};\\\", \\\"{x:813,y:686,t:1527271968741};\\\", \\\"{x:814,y:687,t:1527271969017};\\\", \\\"{x:834,y:691,t:1527271969025};\\\", \\\"{x:917,y:700,t:1527271969041};\\\", \\\"{x:1020,y:700,t:1527271969059};\\\", \\\"{x:1133,y:700,t:1527271969075};\\\", \\\"{x:1233,y:700,t:1527271969092};\\\", \\\"{x:1336,y:700,t:1527271969109};\\\", \\\"{x:1408,y:702,t:1527271969125};\\\", \\\"{x:1467,y:710,t:1527271969142};\\\", \\\"{x:1508,y:718,t:1527271969159};\\\", \\\"{x:1533,y:734,t:1527271969175};\\\", \\\"{x:1548,y:756,t:1527271969192};\\\", \\\"{x:1556,y:795,t:1527271969209};\\\", \\\"{x:1556,y:821,t:1527271969225};\\\", \\\"{x:1556,y:845,t:1527271969242};\\\", \\\"{x:1546,y:870,t:1527271969259};\\\", \\\"{x:1540,y:894,t:1527271969275};\\\", \\\"{x:1535,y:914,t:1527271969292};\\\", \\\"{x:1531,y:925,t:1527271969309};\\\", \\\"{x:1525,y:940,t:1527271969326};\\\", \\\"{x:1521,y:949,t:1527271969341};\\\", \\\"{x:1515,y:956,t:1527271969359};\\\", \\\"{x:1497,y:968,t:1527271969376};\\\", \\\"{x:1491,y:971,t:1527271969392};\\\", \\\"{x:1480,y:981,t:1527271969409};\\\", \\\"{x:1476,y:985,t:1527271969427};\\\", \\\"{x:1475,y:987,t:1527271969441};\\\", \\\"{x:1475,y:988,t:1527271969459};\\\", \\\"{x:1475,y:989,t:1527271969488};\\\", \\\"{x:1478,y:989,t:1527271969497};\\\", \\\"{x:1482,y:989,t:1527271969509};\\\", \\\"{x:1492,y:989,t:1527271969525};\\\", \\\"{x:1507,y:989,t:1527271969542};\\\", \\\"{x:1527,y:989,t:1527271969558};\\\", \\\"{x:1558,y:989,t:1527271969575};\\\", \\\"{x:1572,y:989,t:1527271969591};\\\", \\\"{x:1585,y:988,t:1527271969608};\\\", \\\"{x:1593,y:987,t:1527271969625};\\\", \\\"{x:1598,y:983,t:1527271969642};\\\", \\\"{x:1604,y:983,t:1527271969659};\\\", \\\"{x:1612,y:980,t:1527271969676};\\\", \\\"{x:1623,y:979,t:1527271969691};\\\", \\\"{x:1629,y:978,t:1527271969709};\\\", \\\"{x:1635,y:978,t:1527271969726};\\\", \\\"{x:1643,y:977,t:1527271969743};\\\", \\\"{x:1652,y:977,t:1527271969759};\\\", \\\"{x:1671,y:977,t:1527271969776};\\\", \\\"{x:1685,y:977,t:1527271969792};\\\", \\\"{x:1700,y:977,t:1527271969809};\\\", \\\"{x:1715,y:977,t:1527271969827};\\\", \\\"{x:1730,y:977,t:1527271969843};\\\", \\\"{x:1739,y:977,t:1527271969858};\\\", \\\"{x:1743,y:977,t:1527271969876};\\\", \\\"{x:1744,y:977,t:1527271969892};\\\", \\\"{x:1744,y:976,t:1527271969912};\\\", \\\"{x:1744,y:975,t:1527271969928};\\\", \\\"{x:1738,y:973,t:1527271969943};\\\", \\\"{x:1721,y:973,t:1527271969960};\\\", \\\"{x:1665,y:973,t:1527271969976};\\\", \\\"{x:1606,y:973,t:1527271969993};\\\", \\\"{x:1545,y:973,t:1527271970009};\\\", \\\"{x:1484,y:973,t:1527271970026};\\\", \\\"{x:1433,y:973,t:1527271970044};\\\", \\\"{x:1391,y:973,t:1527271970059};\\\", \\\"{x:1365,y:973,t:1527271970076};\\\", \\\"{x:1350,y:972,t:1527271970093};\\\", \\\"{x:1341,y:971,t:1527271970109};\\\", \\\"{x:1334,y:969,t:1527271970125};\\\", \\\"{x:1329,y:968,t:1527271970144};\\\", \\\"{x:1320,y:967,t:1527271970159};\\\", \\\"{x:1307,y:966,t:1527271970176};\\\", \\\"{x:1287,y:964,t:1527271970193};\\\", \\\"{x:1267,y:964,t:1527271970210};\\\", \\\"{x:1246,y:964,t:1527271970226};\\\", \\\"{x:1237,y:964,t:1527271970243};\\\", \\\"{x:1234,y:964,t:1527271970260};\\\", \\\"{x:1233,y:964,t:1527271970276};\\\", \\\"{x:1233,y:963,t:1527271970294};\\\", \\\"{x:1236,y:962,t:1527271970310};\\\", \\\"{x:1244,y:960,t:1527271970326};\\\", \\\"{x:1256,y:959,t:1527271970343};\\\", \\\"{x:1288,y:959,t:1527271970361};\\\", \\\"{x:1311,y:959,t:1527271970376};\\\", \\\"{x:1331,y:959,t:1527271970393};\\\", \\\"{x:1347,y:960,t:1527271970409};\\\", \\\"{x:1358,y:960,t:1527271970426};\\\", \\\"{x:1362,y:961,t:1527271970443};\\\", \\\"{x:1366,y:962,t:1527271970459};\\\", \\\"{x:1367,y:963,t:1527271970477};\\\", \\\"{x:1366,y:963,t:1527271970553};\\\", \\\"{x:1364,y:962,t:1527271970561};\\\", \\\"{x:1360,y:961,t:1527271970576};\\\", \\\"{x:1356,y:961,t:1527271970593};\\\", \\\"{x:1352,y:961,t:1527271970610};\\\", \\\"{x:1346,y:961,t:1527271970627};\\\", \\\"{x:1341,y:961,t:1527271970643};\\\", \\\"{x:1339,y:960,t:1527271970660};\\\", \\\"{x:1339,y:961,t:1527271970729};\\\", \\\"{x:1339,y:962,t:1527271970743};\\\", \\\"{x:1339,y:963,t:1527271970761};\\\", \\\"{x:1341,y:956,t:1527271970817};\\\", \\\"{x:1342,y:949,t:1527271970827};\\\", \\\"{x:1345,y:927,t:1527271970843};\\\", \\\"{x:1349,y:896,t:1527271970860};\\\", \\\"{x:1353,y:863,t:1527271970877};\\\", \\\"{x:1355,y:834,t:1527271970893};\\\", \\\"{x:1356,y:811,t:1527271970910};\\\", \\\"{x:1359,y:797,t:1527271970927};\\\", \\\"{x:1359,y:790,t:1527271970943};\\\", \\\"{x:1359,y:788,t:1527271970960};\\\", \\\"{x:1359,y:787,t:1527271970977};\\\", \\\"{x:1359,y:786,t:1527271971009};\\\", \\\"{x:1359,y:785,t:1527271971024};\\\", \\\"{x:1359,y:784,t:1527271971041};\\\", \\\"{x:1359,y:782,t:1527271971049};\\\", \\\"{x:1358,y:781,t:1527271971060};\\\", \\\"{x:1357,y:778,t:1527271971077};\\\", \\\"{x:1356,y:774,t:1527271971094};\\\", \\\"{x:1355,y:770,t:1527271971110};\\\", \\\"{x:1355,y:768,t:1527271971127};\\\", \\\"{x:1355,y:765,t:1527271971144};\\\", \\\"{x:1355,y:762,t:1527271971160};\\\", \\\"{x:1355,y:761,t:1527271971192};\\\", \\\"{x:1355,y:760,t:1527271971208};\\\", \\\"{x:1356,y:759,t:1527271971217};\\\", \\\"{x:1356,y:757,t:1527271971233};\\\", \\\"{x:1356,y:756,t:1527271971244};\\\", \\\"{x:1356,y:754,t:1527271971259};\\\", \\\"{x:1356,y:752,t:1527271971276};\\\", \\\"{x:1356,y:749,t:1527271971293};\\\", \\\"{x:1356,y:746,t:1527271971309};\\\", \\\"{x:1356,y:743,t:1527271971326};\\\", \\\"{x:1356,y:739,t:1527271971343};\\\", \\\"{x:1356,y:738,t:1527271971359};\\\", \\\"{x:1356,y:737,t:1527271971376};\\\", \\\"{x:1356,y:735,t:1527271971393};\\\", \\\"{x:1355,y:734,t:1527271971410};\\\", \\\"{x:1355,y:732,t:1527271971426};\\\", \\\"{x:1355,y:730,t:1527271971444};\\\", \\\"{x:1355,y:727,t:1527271971460};\\\", \\\"{x:1352,y:724,t:1527271971477};\\\", \\\"{x:1352,y:721,t:1527271971494};\\\", \\\"{x:1351,y:718,t:1527271971510};\\\", \\\"{x:1350,y:715,t:1527271971527};\\\", \\\"{x:1349,y:711,t:1527271971544};\\\", \\\"{x:1349,y:710,t:1527271971561};\\\", \\\"{x:1348,y:706,t:1527271971577};\\\", \\\"{x:1347,y:704,t:1527271971594};\\\", \\\"{x:1345,y:702,t:1527271971611};\\\", \\\"{x:1344,y:700,t:1527271971630};\\\", \\\"{x:1339,y:696,t:1527271971645};\\\", \\\"{x:1322,y:693,t:1527271971660};\\\", \\\"{x:1293,y:687,t:1527271971677};\\\", \\\"{x:1247,y:676,t:1527271971694};\\\", \\\"{x:1186,y:659,t:1527271971710};\\\", \\\"{x:1105,y:644,t:1527271971727};\\\", \\\"{x:980,y:608,t:1527271971744};\\\", \\\"{x:894,y:583,t:1527271971761};\\\", \\\"{x:819,y:561,t:1527271971777};\\\", \\\"{x:766,y:547,t:1527271971794};\\\", \\\"{x:721,y:540,t:1527271971811};\\\", \\\"{x:691,y:535,t:1527271971828};\\\", \\\"{x:687,y:534,t:1527271971843};\\\", \\\"{x:686,y:534,t:1527271971879};\\\", \\\"{x:683,y:534,t:1527271971893};\\\", \\\"{x:666,y:541,t:1527271971910};\\\", \\\"{x:664,y:541,t:1527271971927};\\\", \\\"{x:665,y:544,t:1527271972136};\\\", \\\"{x:671,y:546,t:1527271972144};\\\", \\\"{x:688,y:546,t:1527271972161};\\\", \\\"{x:717,y:538,t:1527271972178};\\\", \\\"{x:768,y:537,t:1527271972197};\\\", \\\"{x:826,y:537,t:1527271972212};\\\", \\\"{x:853,y:531,t:1527271972227};\\\", \\\"{x:863,y:527,t:1527271972244};\\\", \\\"{x:864,y:527,t:1527271972336};\\\", \\\"{x:864,y:525,t:1527271972392};\\\", \\\"{x:864,y:523,t:1527271972401};\\\", \\\"{x:860,y:519,t:1527271972410};\\\", \\\"{x:850,y:514,t:1527271972429};\\\", \\\"{x:831,y:506,t:1527271972445};\\\", \\\"{x:817,y:499,t:1527271972460};\\\", \\\"{x:810,y:494,t:1527271972478};\\\", \\\"{x:810,y:493,t:1527271972495};\\\", \\\"{x:811,y:493,t:1527271972736};\\\", \\\"{x:814,y:495,t:1527271972743};\\\", \\\"{x:815,y:495,t:1527271972761};\\\", \\\"{x:816,y:496,t:1527271972778};\\\", \\\"{x:817,y:496,t:1527271972913};\\\", \\\"{x:819,y:496,t:1527271972928};\\\", \\\"{x:821,y:496,t:1527271972945};\\\", \\\"{x:823,y:496,t:1527271972961};\\\", \\\"{x:821,y:496,t:1527271973225};\\\", \\\"{x:819,y:497,t:1527271973232};\\\", \\\"{x:815,y:500,t:1527271973244};\\\", \\\"{x:801,y:507,t:1527271973261};\\\", \\\"{x:788,y:510,t:1527271973277};\\\", \\\"{x:783,y:512,t:1527271973294};\\\", \\\"{x:782,y:512,t:1527271973311};\\\", \\\"{x:785,y:510,t:1527271973327};\\\", \\\"{x:797,y:504,t:1527271973345};\\\", \\\"{x:802,y:502,t:1527271973360};\\\", \\\"{x:805,y:502,t:1527271973568};\\\", \\\"{x:809,y:502,t:1527271973577};\\\", \\\"{x:827,y:505,t:1527271973595};\\\", \\\"{x:835,y:506,t:1527271973600};\\\", \\\"{x:842,y:506,t:1527271973610};\\\", \\\"{x:847,y:507,t:1527271973629};\\\", \\\"{x:848,y:507,t:1527271973647};\\\", \\\"{x:849,y:507,t:1527271973663};\\\", \\\"{x:850,y:507,t:1527271973679};\\\", \\\"{x:849,y:507,t:1527271973832};\\\", \\\"{x:847,y:507,t:1527271973846};\\\", \\\"{x:843,y:507,t:1527271973862};\\\", \\\"{x:839,y:507,t:1527271973879};\\\", \\\"{x:835,y:507,t:1527271974120};\\\", \\\"{x:828,y:507,t:1527271974129};\\\", \\\"{x:808,y:512,t:1527271974146};\\\", \\\"{x:766,y:523,t:1527271974163};\\\", \\\"{x:709,y:533,t:1527271974179};\\\", \\\"{x:642,y:542,t:1527271974196};\\\", \\\"{x:598,y:542,t:1527271974213};\\\", \\\"{x:556,y:542,t:1527271974228};\\\", \\\"{x:511,y:542,t:1527271974245};\\\", \\\"{x:461,y:542,t:1527271974263};\\\", \\\"{x:413,y:542,t:1527271974279};\\\", \\\"{x:351,y:549,t:1527271974296};\\\", \\\"{x:297,y:557,t:1527271974313};\\\", \\\"{x:242,y:565,t:1527271974329};\\\", \\\"{x:199,y:565,t:1527271974345};\\\", \\\"{x:172,y:565,t:1527271974362};\\\", \\\"{x:146,y:565,t:1527271974378};\\\", \\\"{x:129,y:565,t:1527271974396};\\\", \\\"{x:119,y:562,t:1527271974414};\\\", \\\"{x:117,y:560,t:1527271974429};\\\", \\\"{x:117,y:555,t:1527271974446};\\\", \\\"{x:117,y:549,t:1527271974463};\\\", \\\"{x:122,y:543,t:1527271974480};\\\", \\\"{x:127,y:540,t:1527271974495};\\\", \\\"{x:130,y:538,t:1527271974513};\\\", \\\"{x:132,y:537,t:1527271974530};\\\", \\\"{x:136,y:535,t:1527271974546};\\\", \\\"{x:139,y:534,t:1527271974563};\\\", \\\"{x:142,y:534,t:1527271974580};\\\", \\\"{x:144,y:534,t:1527271974595};\\\", \\\"{x:145,y:534,t:1527271974616};\\\", \\\"{x:146,y:534,t:1527271974632};\\\", \\\"{x:148,y:534,t:1527271974646};\\\", \\\"{x:149,y:535,t:1527271974664};\\\", \\\"{x:151,y:537,t:1527271974679};\\\", \\\"{x:152,y:537,t:1527271974695};\\\", \\\"{x:153,y:537,t:1527271974713};\\\", \\\"{x:154,y:537,t:1527271974791};\\\", \\\"{x:155,y:537,t:1527271974813};\\\", \\\"{x:156,y:537,t:1527271974829};\\\", \\\"{x:157,y:537,t:1527271974847};\\\", \\\"{x:157,y:537,t:1527271974897};\\\", \\\"{x:160,y:537,t:1527271974959};\\\", \\\"{x:166,y:537,t:1527271974967};\\\", \\\"{x:176,y:540,t:1527271974980};\\\", \\\"{x:225,y:562,t:1527271974997};\\\", \\\"{x:309,y:595,t:1527271975014};\\\", \\\"{x:406,y:639,t:1527271975030};\\\", \\\"{x:516,y:685,t:1527271975048};\\\", \\\"{x:657,y:741,t:1527271975063};\\\", \\\"{x:716,y:766,t:1527271975079};\\\", \\\"{x:739,y:779,t:1527271975097};\\\", \\\"{x:745,y:784,t:1527271975113};\\\", \\\"{x:745,y:788,t:1527271975130};\\\", \\\"{x:745,y:790,t:1527271975147};\\\", \\\"{x:739,y:794,t:1527271975164};\\\", \\\"{x:726,y:796,t:1527271975180};\\\", \\\"{x:715,y:797,t:1527271975197};\\\", \\\"{x:702,y:799,t:1527271975214};\\\", \\\"{x:685,y:800,t:1527271975230};\\\", \\\"{x:665,y:800,t:1527271975247};\\\", \\\"{x:624,y:797,t:1527271975263};\\\", \\\"{x:588,y:789,t:1527271975280};\\\", \\\"{x:562,y:780,t:1527271975297};\\\", \\\"{x:538,y:770,t:1527271975314};\\\", \\\"{x:515,y:761,t:1527271975330};\\\", \\\"{x:499,y:754,t:1527271975348};\\\", \\\"{x:494,y:752,t:1527271975364};\\\", \\\"{x:492,y:750,t:1527271975681};\\\", \\\"{x:492,y:748,t:1527271975695};\\\", \\\"{x:492,y:742,t:1527271975712};\\\", \\\"{x:492,y:741,t:1527271975736};\\\", \\\"{x:492,y:739,t:1527271975760};\\\", \\\"{x:496,y:739,t:1527271976353};\\\", \\\"{x:508,y:739,t:1527271976364};\\\", \\\"{x:548,y:739,t:1527271976381};\\\", \\\"{x:614,y:739,t:1527271976398};\\\", \\\"{x:693,y:725,t:1527271976414};\\\", \\\"{x:752,y:708,t:1527271976431};\\\", \\\"{x:751,y:708,t:1527271976896};\\\" ] }, { \\\"rt\\\": 5513, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 402492, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:741,y:707,t:1527271977096};\\\", \\\"{x:739,y:706,t:1527271977121};\\\", \\\"{x:738,y:706,t:1527271977186};\\\", \\\"{x:738,y:707,t:1527271977440};\\\", \\\"{x:738,y:709,t:1527271977448};\\\", \\\"{x:738,y:710,t:1527271977471};\\\", \\\"{x:738,y:712,t:1527271977482};\\\", \\\"{x:739,y:714,t:1527271977499};\\\", \\\"{x:740,y:714,t:1527271977562};\\\", \\\"{x:740,y:715,t:1527271977751};\\\", \\\"{x:742,y:716,t:1527271977766};\\\", \\\"{x:746,y:717,t:1527271977781};\\\", \\\"{x:751,y:717,t:1527271977798};\\\", \\\"{x:752,y:717,t:1527271977815};\\\", \\\"{x:756,y:717,t:1527271978073};\\\", \\\"{x:764,y:717,t:1527271978082};\\\", \\\"{x:773,y:717,t:1527271978099};\\\", \\\"{x:779,y:717,t:1527271978116};\\\", \\\"{x:783,y:717,t:1527271978133};\\\", \\\"{x:791,y:716,t:1527271978150};\\\", \\\"{x:803,y:715,t:1527271978166};\\\", \\\"{x:828,y:715,t:1527271978183};\\\", \\\"{x:847,y:715,t:1527271978199};\\\", \\\"{x:893,y:715,t:1527271978216};\\\", \\\"{x:935,y:709,t:1527271978233};\\\", \\\"{x:994,y:701,t:1527271978250};\\\", \\\"{x:1043,y:690,t:1527271978267};\\\", \\\"{x:1085,y:683,t:1527271978284};\\\", \\\"{x:1121,y:675,t:1527271978299};\\\", \\\"{x:1145,y:668,t:1527271978317};\\\", \\\"{x:1164,y:662,t:1527271978333};\\\", \\\"{x:1180,y:656,t:1527271978349};\\\", \\\"{x:1198,y:648,t:1527271978366};\\\", \\\"{x:1219,y:639,t:1527271978383};\\\", \\\"{x:1248,y:627,t:1527271978400};\\\", \\\"{x:1289,y:613,t:1527271978416};\\\", \\\"{x:1325,y:602,t:1527271978434};\\\", \\\"{x:1353,y:595,t:1527271978450};\\\", \\\"{x:1380,y:588,t:1527271978466};\\\", \\\"{x:1400,y:585,t:1527271978483};\\\", \\\"{x:1410,y:583,t:1527271978500};\\\", \\\"{x:1411,y:583,t:1527271978517};\\\", \\\"{x:1412,y:586,t:1527271978552};\\\", \\\"{x:1411,y:596,t:1527271978567};\\\", \\\"{x:1404,y:613,t:1527271978583};\\\", \\\"{x:1396,y:637,t:1527271978601};\\\", \\\"{x:1392,y:649,t:1527271978616};\\\", \\\"{x:1390,y:658,t:1527271978633};\\\", \\\"{x:1386,y:671,t:1527271978651};\\\", \\\"{x:1385,y:681,t:1527271978666};\\\", \\\"{x:1384,y:692,t:1527271978684};\\\", \\\"{x:1381,y:700,t:1527271978700};\\\", \\\"{x:1380,y:708,t:1527271978716};\\\", \\\"{x:1377,y:713,t:1527271978733};\\\", \\\"{x:1376,y:718,t:1527271978750};\\\", \\\"{x:1374,y:721,t:1527271978767};\\\", \\\"{x:1373,y:722,t:1527271978784};\\\", \\\"{x:1372,y:722,t:1527271978800};\\\", \\\"{x:1371,y:723,t:1527271978817};\\\", \\\"{x:1370,y:724,t:1527271978840};\\\", \\\"{x:1368,y:724,t:1527271978856};\\\", \\\"{x:1367,y:725,t:1527271978866};\\\", \\\"{x:1364,y:730,t:1527271978883};\\\", \\\"{x:1360,y:736,t:1527271978901};\\\", \\\"{x:1352,y:750,t:1527271978917};\\\", \\\"{x:1341,y:770,t:1527271978934};\\\", \\\"{x:1334,y:783,t:1527271978950};\\\", \\\"{x:1330,y:790,t:1527271978966};\\\", \\\"{x:1327,y:794,t:1527271978983};\\\", \\\"{x:1310,y:800,t:1527271979001};\\\", \\\"{x:1262,y:801,t:1527271979017};\\\", \\\"{x:1167,y:800,t:1527271979034};\\\", \\\"{x:1029,y:781,t:1527271979050};\\\", \\\"{x:865,y:752,t:1527271979068};\\\", \\\"{x:718,y:726,t:1527271979083};\\\", \\\"{x:576,y:698,t:1527271979100};\\\", \\\"{x:462,y:665,t:1527271979118};\\\", \\\"{x:375,y:634,t:1527271979134};\\\", \\\"{x:328,y:603,t:1527271979150};\\\", \\\"{x:280,y:557,t:1527271979184};\\\", \\\"{x:276,y:546,t:1527271979200};\\\", \\\"{x:276,y:545,t:1527271979216};\\\", \\\"{x:275,y:545,t:1527271979247};\\\", \\\"{x:272,y:545,t:1527271979256};\\\", \\\"{x:264,y:545,t:1527271979267};\\\", \\\"{x:241,y:545,t:1527271979283};\\\", \\\"{x:211,y:545,t:1527271979300};\\\", \\\"{x:183,y:542,t:1527271979317};\\\", \\\"{x:152,y:539,t:1527271979334};\\\", \\\"{x:129,y:539,t:1527271979350};\\\", \\\"{x:117,y:539,t:1527271979367};\\\", \\\"{x:116,y:539,t:1527271979383};\\\", \\\"{x:118,y:539,t:1527271979440};\\\", \\\"{x:118,y:540,t:1527271979465};\\\", \\\"{x:118,y:542,t:1527271979472};\\\", \\\"{x:118,y:545,t:1527271979484};\\\", \\\"{x:118,y:546,t:1527271979500};\\\", \\\"{x:119,y:550,t:1527271979517};\\\", \\\"{x:120,y:551,t:1527271979534};\\\", \\\"{x:121,y:551,t:1527271979549};\\\", \\\"{x:124,y:551,t:1527271979567};\\\", \\\"{x:132,y:546,t:1527271979584};\\\", \\\"{x:137,y:543,t:1527271979600};\\\", \\\"{x:142,y:541,t:1527271979618};\\\", \\\"{x:143,y:540,t:1527271979635};\\\", \\\"{x:146,y:540,t:1527271979651};\\\", \\\"{x:147,y:540,t:1527271979667};\\\", \\\"{x:149,y:539,t:1527271979685};\\\", \\\"{x:151,y:538,t:1527271979700};\\\", \\\"{x:153,y:537,t:1527271979716};\\\", \\\"{x:154,y:536,t:1527271979751};\\\", \\\"{x:155,y:536,t:1527271979855};\\\", \\\"{x:156,y:536,t:1527271979880};\\\", \\\"{x:156,y:536,t:1527271979941};\\\", \\\"{x:158,y:536,t:1527271980008};\\\", \\\"{x:164,y:540,t:1527271980016};\\\", \\\"{x:195,y:566,t:1527271980034};\\\", \\\"{x:238,y:597,t:1527271980052};\\\", \\\"{x:298,y:633,t:1527271980066};\\\", \\\"{x:349,y:657,t:1527271980085};\\\", \\\"{x:409,y:683,t:1527271980102};\\\", \\\"{x:453,y:700,t:1527271980117};\\\", \\\"{x:478,y:710,t:1527271980134};\\\", \\\"{x:494,y:716,t:1527271980151};\\\", \\\"{x:504,y:722,t:1527271980168};\\\", \\\"{x:505,y:726,t:1527271980184};\\\", \\\"{x:505,y:727,t:1527271980201};\\\", \\\"{x:505,y:728,t:1527271980240};\\\", \\\"{x:506,y:730,t:1527271980251};\\\", \\\"{x:509,y:735,t:1527271980268};\\\", \\\"{x:514,y:742,t:1527271980284};\\\", \\\"{x:519,y:747,t:1527271980301};\\\", \\\"{x:521,y:749,t:1527271980318};\\\", \\\"{x:521,y:746,t:1527271980425};\\\", \\\"{x:518,y:740,t:1527271980434};\\\", \\\"{x:515,y:735,t:1527271980451};\\\", \\\"{x:513,y:733,t:1527271980469};\\\" ] }, { \\\"rt\\\": 13800, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 417508, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-O -O -Z -F -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:723,t:1527271983854};\\\", \\\"{x:507,y:723,t:1527271984277};\\\", \\\"{x:506,y:723,t:1527271984288};\\\", \\\"{x:506,y:720,t:1527271984399};\\\", \\\"{x:506,y:712,t:1527271984408};\\\", \\\"{x:505,y:705,t:1527271984421};\\\", \\\"{x:504,y:682,t:1527271984437};\\\", \\\"{x:500,y:636,t:1527271984454};\\\", \\\"{x:499,y:577,t:1527271984471};\\\", \\\"{x:490,y:527,t:1527271984488};\\\", \\\"{x:487,y:506,t:1527271984504};\\\", \\\"{x:482,y:484,t:1527271984521};\\\", \\\"{x:479,y:469,t:1527271984538};\\\", \\\"{x:474,y:460,t:1527271984554};\\\", \\\"{x:473,y:455,t:1527271984571};\\\", \\\"{x:473,y:454,t:1527271984753};\\\", \\\"{x:476,y:454,t:1527271984760};\\\", \\\"{x:481,y:457,t:1527271984771};\\\", \\\"{x:497,y:463,t:1527271984788};\\\", \\\"{x:514,y:468,t:1527271984805};\\\", \\\"{x:541,y:472,t:1527271984822};\\\", \\\"{x:577,y:472,t:1527271984839};\\\", \\\"{x:628,y:472,t:1527271984854};\\\", \\\"{x:684,y:472,t:1527271984871};\\\", \\\"{x:789,y:472,t:1527271984887};\\\", \\\"{x:870,y:472,t:1527271984906};\\\", \\\"{x:934,y:472,t:1527271984921};\\\", \\\"{x:993,y:472,t:1527271984939};\\\", \\\"{x:1035,y:472,t:1527271984955};\\\", \\\"{x:1060,y:472,t:1527271984972};\\\", \\\"{x:1074,y:473,t:1527271984988};\\\", \\\"{x:1077,y:474,t:1527271985006};\\\", \\\"{x:1078,y:474,t:1527271985021};\\\", \\\"{x:1078,y:476,t:1527271985039};\\\", \\\"{x:1076,y:478,t:1527271985056};\\\", \\\"{x:1067,y:490,t:1527271985071};\\\", \\\"{x:1059,y:500,t:1527271985088};\\\", \\\"{x:1051,y:509,t:1527271985107};\\\", \\\"{x:1044,y:517,t:1527271985122};\\\", \\\"{x:1039,y:524,t:1527271985139};\\\", \\\"{x:1030,y:526,t:1527271985155};\\\", \\\"{x:1022,y:526,t:1527271985171};\\\", \\\"{x:1021,y:526,t:1527271985189};\\\", \\\"{x:1024,y:526,t:1527271985440};\\\", \\\"{x:1040,y:531,t:1527271985457};\\\", \\\"{x:1060,y:531,t:1527271985471};\\\", \\\"{x:1081,y:530,t:1527271985488};\\\", \\\"{x:1100,y:530,t:1527271985505};\\\", \\\"{x:1124,y:530,t:1527271985523};\\\", \\\"{x:1147,y:530,t:1527271985538};\\\", \\\"{x:1175,y:530,t:1527271985556};\\\", \\\"{x:1204,y:530,t:1527271985573};\\\", \\\"{x:1230,y:531,t:1527271985588};\\\", \\\"{x:1264,y:535,t:1527271985606};\\\", \\\"{x:1293,y:539,t:1527271985623};\\\", \\\"{x:1321,y:543,t:1527271985639};\\\", \\\"{x:1349,y:549,t:1527271985656};\\\", \\\"{x:1365,y:554,t:1527271985672};\\\", \\\"{x:1371,y:557,t:1527271985688};\\\", \\\"{x:1380,y:565,t:1527271985705};\\\", \\\"{x:1390,y:577,t:1527271985722};\\\", \\\"{x:1406,y:595,t:1527271985739};\\\", \\\"{x:1420,y:612,t:1527271985755};\\\", \\\"{x:1436,y:629,t:1527271985772};\\\", \\\"{x:1454,y:643,t:1527271985789};\\\", \\\"{x:1470,y:653,t:1527271985805};\\\", \\\"{x:1480,y:661,t:1527271985823};\\\", \\\"{x:1486,y:665,t:1527271985838};\\\", \\\"{x:1479,y:665,t:1527271985880};\\\", \\\"{x:1467,y:662,t:1527271985890};\\\", \\\"{x:1441,y:654,t:1527271985905};\\\", \\\"{x:1438,y:653,t:1527271985923};\\\", \\\"{x:1442,y:653,t:1527271986504};\\\", \\\"{x:1446,y:654,t:1527271986512};\\\", \\\"{x:1450,y:655,t:1527271986523};\\\", \\\"{x:1458,y:660,t:1527271986540};\\\", \\\"{x:1464,y:662,t:1527271986557};\\\", \\\"{x:1469,y:666,t:1527271986573};\\\", \\\"{x:1476,y:673,t:1527271986589};\\\", \\\"{x:1484,y:681,t:1527271986606};\\\", \\\"{x:1488,y:686,t:1527271986623};\\\", \\\"{x:1492,y:693,t:1527271986639};\\\", \\\"{x:1494,y:697,t:1527271986656};\\\", \\\"{x:1494,y:700,t:1527271986673};\\\", \\\"{x:1494,y:703,t:1527271986689};\\\", \\\"{x:1494,y:708,t:1527271986706};\\\", \\\"{x:1494,y:712,t:1527271986723};\\\", \\\"{x:1494,y:717,t:1527271986739};\\\", \\\"{x:1495,y:721,t:1527271986757};\\\", \\\"{x:1496,y:722,t:1527271986774};\\\", \\\"{x:1498,y:725,t:1527271986789};\\\", \\\"{x:1501,y:731,t:1527271986806};\\\", \\\"{x:1505,y:740,t:1527271986824};\\\", \\\"{x:1506,y:742,t:1527271986839};\\\", \\\"{x:1511,y:752,t:1527271986856};\\\", \\\"{x:1513,y:755,t:1527271986873};\\\", \\\"{x:1513,y:757,t:1527271986889};\\\", \\\"{x:1513,y:758,t:1527271986908};\\\", \\\"{x:1513,y:760,t:1527271986924};\\\", \\\"{x:1511,y:763,t:1527271986940};\\\", \\\"{x:1507,y:767,t:1527271986957};\\\", \\\"{x:1504,y:769,t:1527271986973};\\\", \\\"{x:1501,y:771,t:1527271986989};\\\", \\\"{x:1500,y:772,t:1527271987007};\\\", \\\"{x:1499,y:772,t:1527271987024};\\\", \\\"{x:1499,y:773,t:1527271987040};\\\", \\\"{x:1499,y:774,t:1527271987056};\\\", \\\"{x:1502,y:776,t:1527271987073};\\\", \\\"{x:1514,y:776,t:1527271987090};\\\", \\\"{x:1529,y:776,t:1527271987106};\\\", \\\"{x:1544,y:775,t:1527271987124};\\\", \\\"{x:1558,y:768,t:1527271987141};\\\", \\\"{x:1569,y:759,t:1527271987156};\\\", \\\"{x:1575,y:753,t:1527271987173};\\\", \\\"{x:1583,y:744,t:1527271987191};\\\", \\\"{x:1586,y:739,t:1527271987207};\\\", \\\"{x:1591,y:727,t:1527271987224};\\\", \\\"{x:1592,y:720,t:1527271987240};\\\", \\\"{x:1593,y:715,t:1527271987257};\\\", \\\"{x:1595,y:709,t:1527271987273};\\\", \\\"{x:1595,y:707,t:1527271987291};\\\", \\\"{x:1595,y:704,t:1527271987307};\\\", \\\"{x:1595,y:703,t:1527271987375};\\\", \\\"{x:1596,y:702,t:1527271987392};\\\", \\\"{x:1597,y:702,t:1527271987407};\\\", \\\"{x:1597,y:701,t:1527271987423};\\\", \\\"{x:1598,y:700,t:1527271987440};\\\", \\\"{x:1601,y:697,t:1527271987457};\\\", \\\"{x:1604,y:696,t:1527271987473};\\\", \\\"{x:1605,y:696,t:1527271987490};\\\", \\\"{x:1606,y:695,t:1527271987507};\\\", \\\"{x:1607,y:694,t:1527271987524};\\\", \\\"{x:1608,y:694,t:1527271987681};\\\", \\\"{x:1609,y:695,t:1527271987729};\\\", \\\"{x:1609,y:696,t:1527271987881};\\\", \\\"{x:1610,y:697,t:1527271987896};\\\", \\\"{x:1611,y:698,t:1527271987912};\\\", \\\"{x:1612,y:700,t:1527271987936};\\\", \\\"{x:1612,y:701,t:1527271987952};\\\", \\\"{x:1613,y:702,t:1527271987985};\\\", \\\"{x:1612,y:702,t:1527271989617};\\\", \\\"{x:1610,y:702,t:1527271989626};\\\", \\\"{x:1592,y:698,t:1527271989642};\\\", \\\"{x:1566,y:695,t:1527271989658};\\\", \\\"{x:1514,y:694,t:1527271989675};\\\", \\\"{x:1441,y:692,t:1527271989691};\\\", \\\"{x:1369,y:692,t:1527271989708};\\\", \\\"{x:1319,y:692,t:1527271989725};\\\", \\\"{x:1279,y:692,t:1527271989743};\\\", \\\"{x:1255,y:692,t:1527271989759};\\\", \\\"{x:1230,y:692,t:1527271989776};\\\", \\\"{x:1224,y:692,t:1527271989791};\\\", \\\"{x:1223,y:692,t:1527271989808};\\\", \\\"{x:1225,y:692,t:1527271989881};\\\", \\\"{x:1227,y:692,t:1527271989893};\\\", \\\"{x:1241,y:692,t:1527271989908};\\\", \\\"{x:1267,y:693,t:1527271989926};\\\", \\\"{x:1298,y:695,t:1527271989943};\\\", \\\"{x:1328,y:695,t:1527271989959};\\\", \\\"{x:1356,y:696,t:1527271989976};\\\", \\\"{x:1358,y:696,t:1527271989993};\\\", \\\"{x:1355,y:696,t:1527271990041};\\\", \\\"{x:1354,y:696,t:1527271990048};\\\", \\\"{x:1351,y:696,t:1527271990060};\\\", \\\"{x:1345,y:696,t:1527271990075};\\\", \\\"{x:1339,y:696,t:1527271990093};\\\", \\\"{x:1334,y:695,t:1527271990109};\\\", \\\"{x:1327,y:695,t:1527271990126};\\\", \\\"{x:1321,y:695,t:1527271990143};\\\", \\\"{x:1316,y:695,t:1527271990159};\\\", \\\"{x:1314,y:695,t:1527271990176};\\\", \\\"{x:1313,y:695,t:1527271990208};\\\", \\\"{x:1315,y:695,t:1527271990280};\\\", \\\"{x:1316,y:695,t:1527271990293};\\\", \\\"{x:1320,y:695,t:1527271990310};\\\", \\\"{x:1327,y:695,t:1527271990326};\\\", \\\"{x:1337,y:695,t:1527271990343};\\\", \\\"{x:1359,y:695,t:1527271990360};\\\", \\\"{x:1376,y:695,t:1527271990376};\\\", \\\"{x:1392,y:695,t:1527271990393};\\\", \\\"{x:1406,y:695,t:1527271990410};\\\", \\\"{x:1416,y:695,t:1527271990427};\\\", \\\"{x:1418,y:695,t:1527271990664};\\\", \\\"{x:1422,y:695,t:1527271990677};\\\", \\\"{x:1434,y:696,t:1527271990693};\\\", \\\"{x:1451,y:699,t:1527271990711};\\\", \\\"{x:1470,y:700,t:1527271990727};\\\", \\\"{x:1485,y:701,t:1527271990743};\\\", \\\"{x:1496,y:701,t:1527271990760};\\\", \\\"{x:1498,y:701,t:1527271990944};\\\", \\\"{x:1504,y:701,t:1527271990959};\\\", \\\"{x:1511,y:701,t:1527271990977};\\\", \\\"{x:1522,y:701,t:1527271990993};\\\", \\\"{x:1534,y:701,t:1527271991010};\\\", \\\"{x:1538,y:701,t:1527271991027};\\\", \\\"{x:1539,y:701,t:1527271991043};\\\", \\\"{x:1542,y:701,t:1527271991209};\\\", \\\"{x:1559,y:701,t:1527271991227};\\\", \\\"{x:1581,y:704,t:1527271991244};\\\", \\\"{x:1605,y:704,t:1527271991259};\\\", \\\"{x:1623,y:704,t:1527271991277};\\\", \\\"{x:1629,y:704,t:1527271991294};\\\", \\\"{x:1630,y:703,t:1527271991311};\\\", \\\"{x:1628,y:703,t:1527271991376};\\\", \\\"{x:1622,y:703,t:1527271991394};\\\", \\\"{x:1614,y:703,t:1527271991409};\\\", \\\"{x:1595,y:703,t:1527271991427};\\\", \\\"{x:1572,y:703,t:1527271991444};\\\", \\\"{x:1542,y:703,t:1527271991459};\\\", \\\"{x:1486,y:703,t:1527271991476};\\\", \\\"{x:1406,y:703,t:1527271991494};\\\", \\\"{x:1282,y:694,t:1527271991510};\\\", \\\"{x:1133,y:677,t:1527271991527};\\\", \\\"{x:896,y:655,t:1527271991544};\\\", \\\"{x:749,y:653,t:1527271991560};\\\", \\\"{x:613,y:651,t:1527271991576};\\\", \\\"{x:489,y:639,t:1527271991594};\\\", \\\"{x:389,y:625,t:1527271991611};\\\", \\\"{x:316,y:613,t:1527271991626};\\\", \\\"{x:274,y:600,t:1527271991644};\\\", \\\"{x:259,y:594,t:1527271991660};\\\", \\\"{x:257,y:592,t:1527271991677};\\\", \\\"{x:257,y:591,t:1527271991693};\\\", \\\"{x:263,y:586,t:1527271991710};\\\", \\\"{x:272,y:576,t:1527271991727};\\\", \\\"{x:276,y:565,t:1527271991744};\\\", \\\"{x:280,y:558,t:1527271991760};\\\", \\\"{x:284,y:555,t:1527271991778};\\\", \\\"{x:289,y:552,t:1527271991794};\\\", \\\"{x:299,y:549,t:1527271991810};\\\", \\\"{x:316,y:548,t:1527271991827};\\\", \\\"{x:342,y:548,t:1527271991844};\\\", \\\"{x:378,y:548,t:1527271991861};\\\", \\\"{x:424,y:549,t:1527271991877};\\\", \\\"{x:471,y:549,t:1527271991893};\\\", \\\"{x:522,y:549,t:1527271991911};\\\", \\\"{x:581,y:554,t:1527271991927};\\\", \\\"{x:617,y:559,t:1527271991944};\\\", \\\"{x:645,y:563,t:1527271991962};\\\", \\\"{x:662,y:564,t:1527271991978};\\\", \\\"{x:666,y:564,t:1527271991993};\\\", \\\"{x:667,y:564,t:1527271992010};\\\", \\\"{x:667,y:563,t:1527271992103};\\\", \\\"{x:667,y:562,t:1527271992112};\\\", \\\"{x:667,y:558,t:1527271992127};\\\", \\\"{x:667,y:553,t:1527271992145};\\\", \\\"{x:664,y:547,t:1527271992161};\\\", \\\"{x:661,y:543,t:1527271992178};\\\", \\\"{x:657,y:542,t:1527271992194};\\\", \\\"{x:659,y:542,t:1527271992264};\\\", \\\"{x:665,y:542,t:1527271992277};\\\", \\\"{x:680,y:542,t:1527271992295};\\\", \\\"{x:703,y:544,t:1527271992311};\\\", \\\"{x:740,y:545,t:1527271992330};\\\", \\\"{x:762,y:545,t:1527271992345};\\\", \\\"{x:777,y:545,t:1527271992361};\\\", \\\"{x:791,y:545,t:1527271992377};\\\", \\\"{x:802,y:545,t:1527271992394};\\\", \\\"{x:816,y:546,t:1527271992411};\\\", \\\"{x:825,y:547,t:1527271992428};\\\", \\\"{x:828,y:547,t:1527271992444};\\\", \\\"{x:829,y:547,t:1527271992461};\\\", \\\"{x:829,y:546,t:1527271992519};\\\", \\\"{x:830,y:545,t:1527271992527};\\\", \\\"{x:830,y:544,t:1527271992544};\\\", \\\"{x:830,y:542,t:1527271992562};\\\", \\\"{x:830,y:537,t:1527271992578};\\\", \\\"{x:830,y:533,t:1527271992594};\\\", \\\"{x:830,y:530,t:1527271992612};\\\", \\\"{x:830,y:528,t:1527271992628};\\\", \\\"{x:830,y:526,t:1527271992644};\\\", \\\"{x:830,y:524,t:1527271992661};\\\", \\\"{x:830,y:523,t:1527271992677};\\\", \\\"{x:830,y:522,t:1527271992751};\\\", \\\"{x:830,y:521,t:1527271992761};\\\", \\\"{x:830,y:520,t:1527271992777};\\\", \\\"{x:830,y:518,t:1527271992800};\\\", \\\"{x:830,y:517,t:1527271992824};\\\", \\\"{x:830,y:516,t:1527271992831};\\\", \\\"{x:830,y:514,t:1527271992844};\\\", \\\"{x:830,y:511,t:1527271992862};\\\", \\\"{x:829,y:509,t:1527271992877};\\\", \\\"{x:829,y:507,t:1527271992894};\\\", \\\"{x:829,y:506,t:1527271993392};\\\", \\\"{x:835,y:507,t:1527271993400};\\\", \\\"{x:846,y:510,t:1527271993412};\\\", \\\"{x:879,y:523,t:1527271993430};\\\", \\\"{x:927,y:538,t:1527271993446};\\\", \\\"{x:1008,y:561,t:1527271993461};\\\", \\\"{x:1095,y:582,t:1527271993479};\\\", \\\"{x:1227,y:612,t:1527271993495};\\\", \\\"{x:1307,y:631,t:1527271993511};\\\", \\\"{x:1374,y:650,t:1527271993529};\\\", \\\"{x:1432,y:668,t:1527271993546};\\\", \\\"{x:1472,y:680,t:1527271993561};\\\", \\\"{x:1506,y:698,t:1527271993579};\\\", \\\"{x:1544,y:712,t:1527271993596};\\\", \\\"{x:1585,y:720,t:1527271993611};\\\", \\\"{x:1589,y:720,t:1527271993628};\\\", \\\"{x:1589,y:721,t:1527271993848};\\\", \\\"{x:1589,y:722,t:1527271993936};\\\", \\\"{x:1585,y:727,t:1527271993946};\\\", \\\"{x:1579,y:735,t:1527271993963};\\\", \\\"{x:1576,y:738,t:1527271993980};\\\", \\\"{x:1571,y:749,t:1527271993996};\\\", \\\"{x:1565,y:761,t:1527271994013};\\\", \\\"{x:1562,y:769,t:1527271994029};\\\", \\\"{x:1557,y:778,t:1527271994046};\\\", \\\"{x:1551,y:788,t:1527271994063};\\\", \\\"{x:1545,y:797,t:1527271994080};\\\", \\\"{x:1535,y:805,t:1527271994096};\\\", \\\"{x:1527,y:811,t:1527271994114};\\\", \\\"{x:1524,y:816,t:1527271994129};\\\", \\\"{x:1520,y:821,t:1527271994146};\\\", \\\"{x:1517,y:824,t:1527271994163};\\\", \\\"{x:1516,y:826,t:1527271994179};\\\", \\\"{x:1514,y:828,t:1527271994195};\\\", \\\"{x:1511,y:830,t:1527271994213};\\\", \\\"{x:1504,y:830,t:1527271994229};\\\", \\\"{x:1498,y:832,t:1527271994246};\\\", \\\"{x:1495,y:833,t:1527271994263};\\\", \\\"{x:1491,y:834,t:1527271994280};\\\", \\\"{x:1490,y:834,t:1527271994304};\\\", \\\"{x:1488,y:834,t:1527271994313};\\\", \\\"{x:1485,y:834,t:1527271994330};\\\", \\\"{x:1481,y:834,t:1527271994346};\\\", \\\"{x:1479,y:834,t:1527271994363};\\\", \\\"{x:1479,y:835,t:1527271994379};\\\", \\\"{x:1482,y:836,t:1527271994441};\\\", \\\"{x:1487,y:836,t:1527271994448};\\\", \\\"{x:1491,y:836,t:1527271994462};\\\", \\\"{x:1508,y:836,t:1527271994479};\\\", \\\"{x:1519,y:836,t:1527271994495};\\\", \\\"{x:1535,y:836,t:1527271994512};\\\", \\\"{x:1553,y:836,t:1527271994530};\\\", \\\"{x:1564,y:836,t:1527271994546};\\\", \\\"{x:1570,y:836,t:1527271994563};\\\", \\\"{x:1572,y:836,t:1527271994580};\\\", \\\"{x:1572,y:837,t:1527271994615};\\\", \\\"{x:1573,y:837,t:1527271994664};\\\", \\\"{x:1574,y:837,t:1527271994688};\\\", \\\"{x:1575,y:837,t:1527271994696};\\\", \\\"{x:1582,y:837,t:1527271994713};\\\", \\\"{x:1596,y:837,t:1527271994730};\\\", \\\"{x:1614,y:837,t:1527271994747};\\\", \\\"{x:1633,y:837,t:1527271994763};\\\", \\\"{x:1650,y:835,t:1527271994779};\\\", \\\"{x:1660,y:832,t:1527271994797};\\\", \\\"{x:1666,y:830,t:1527271994813};\\\", \\\"{x:1667,y:830,t:1527271994832};\\\", \\\"{x:1664,y:830,t:1527271994848};\\\", \\\"{x:1652,y:830,t:1527271994863};\\\", \\\"{x:1543,y:820,t:1527271994881};\\\", \\\"{x:1407,y:799,t:1527271994897};\\\", \\\"{x:1230,y:777,t:1527271994914};\\\", \\\"{x:1048,y:750,t:1527271994930};\\\", \\\"{x:866,y:725,t:1527271994947};\\\", \\\"{x:705,y:701,t:1527271994963};\\\", \\\"{x:591,y:668,t:1527271994980};\\\", \\\"{x:529,y:634,t:1527271994997};\\\", \\\"{x:509,y:618,t:1527271995014};\\\", \\\"{x:506,y:605,t:1527271995030};\\\", \\\"{x:509,y:591,t:1527271995046};\\\", \\\"{x:519,y:577,t:1527271995059};\\\", \\\"{x:523,y:569,t:1527271995075};\\\", \\\"{x:523,y:564,t:1527271995092};\\\", \\\"{x:518,y:556,t:1527271995108};\\\", \\\"{x:493,y:550,t:1527271995124};\\\", \\\"{x:426,y:549,t:1527271995147};\\\", \\\"{x:367,y:549,t:1527271995163};\\\", \\\"{x:314,y:549,t:1527271995181};\\\", \\\"{x:264,y:561,t:1527271995197};\\\", \\\"{x:238,y:572,t:1527271995214};\\\", \\\"{x:222,y:579,t:1527271995230};\\\", \\\"{x:218,y:579,t:1527271995246};\\\", \\\"{x:218,y:580,t:1527271995280};\\\", \\\"{x:218,y:581,t:1527271995287};\\\", \\\"{x:218,y:583,t:1527271995297};\\\", \\\"{x:219,y:584,t:1527271995314};\\\", \\\"{x:219,y:585,t:1527271995335};\\\", \\\"{x:218,y:587,t:1527271995347};\\\", \\\"{x:216,y:588,t:1527271995364};\\\", \\\"{x:212,y:589,t:1527271995380};\\\", \\\"{x:204,y:592,t:1527271995397};\\\", \\\"{x:200,y:593,t:1527271995414};\\\", \\\"{x:195,y:595,t:1527271995432};\\\", \\\"{x:193,y:595,t:1527271995448};\\\", \\\"{x:190,y:596,t:1527271995464};\\\", \\\"{x:188,y:596,t:1527271995480};\\\", \\\"{x:185,y:598,t:1527271995497};\\\", \\\"{x:183,y:601,t:1527271995515};\\\", \\\"{x:180,y:605,t:1527271995531};\\\", \\\"{x:180,y:609,t:1527271995547};\\\", \\\"{x:179,y:614,t:1527271995563};\\\", \\\"{x:178,y:617,t:1527271995581};\\\", \\\"{x:178,y:621,t:1527271995597};\\\", \\\"{x:178,y:623,t:1527271995614};\\\", \\\"{x:177,y:627,t:1527271995631};\\\", \\\"{x:177,y:631,t:1527271995647};\\\", \\\"{x:176,y:634,t:1527271995664};\\\", \\\"{x:175,y:634,t:1527271995680};\\\", \\\"{x:175,y:635,t:1527271995703};\\\", \\\"{x:177,y:635,t:1527271995713};\\\", \\\"{x:185,y:634,t:1527271995730};\\\", \\\"{x:203,y:625,t:1527271995747};\\\", \\\"{x:234,y:613,t:1527271995763};\\\", \\\"{x:302,y:588,t:1527271995782};\\\", \\\"{x:386,y:577,t:1527271995797};\\\", \\\"{x:439,y:569,t:1527271995814};\\\", \\\"{x:494,y:562,t:1527271995831};\\\", \\\"{x:547,y:562,t:1527271995847};\\\", \\\"{x:561,y:561,t:1527271995863};\\\", \\\"{x:566,y:560,t:1527271995880};\\\", \\\"{x:567,y:560,t:1527271995898};\\\", \\\"{x:565,y:560,t:1527271995976};\\\", \\\"{x:563,y:559,t:1527271995984};\\\", \\\"{x:561,y:558,t:1527271995998};\\\", \\\"{x:553,y:550,t:1527271996015};\\\", \\\"{x:546,y:544,t:1527271996030};\\\", \\\"{x:542,y:540,t:1527271996046};\\\", \\\"{x:544,y:539,t:1527271996072};\\\", \\\"{x:550,y:539,t:1527271996080};\\\", \\\"{x:563,y:542,t:1527271996097};\\\", \\\"{x:581,y:544,t:1527271996114};\\\", \\\"{x:599,y:546,t:1527271996129};\\\", \\\"{x:619,y:546,t:1527271996148};\\\", \\\"{x:632,y:546,t:1527271996163};\\\", \\\"{x:635,y:546,t:1527271996180};\\\", \\\"{x:636,y:546,t:1527271996198};\\\", \\\"{x:636,y:545,t:1527271996263};\\\", \\\"{x:636,y:544,t:1527271996281};\\\", \\\"{x:635,y:543,t:1527271996297};\\\", \\\"{x:634,y:543,t:1527271996343};\\\", \\\"{x:634,y:542,t:1527271996384};\\\", \\\"{x:634,y:541,t:1527271996398};\\\", \\\"{x:634,y:537,t:1527271996414};\\\", \\\"{x:633,y:534,t:1527271996431};\\\", \\\"{x:631,y:534,t:1527271996463};\\\", \\\"{x:629,y:534,t:1527271996481};\\\", \\\"{x:626,y:543,t:1527271996498};\\\", \\\"{x:621,y:560,t:1527271996516};\\\", \\\"{x:620,y:576,t:1527271996531};\\\", \\\"{x:619,y:585,t:1527271996548};\\\", \\\"{x:619,y:588,t:1527271996565};\\\", \\\"{x:619,y:589,t:1527271996581};\\\", \\\"{x:619,y:590,t:1527271996598};\\\", \\\"{x:618,y:591,t:1527271996615};\\\", \\\"{x:617,y:592,t:1527271996639};\\\", \\\"{x:616,y:592,t:1527271996775};\\\", \\\"{x:616,y:588,t:1527271996783};\\\", \\\"{x:615,y:582,t:1527271996798};\\\", \\\"{x:614,y:576,t:1527271996815};\\\", \\\"{x:612,y:579,t:1527271997039};\\\", \\\"{x:608,y:587,t:1527271997047};\\\", \\\"{x:601,y:612,t:1527271997065};\\\", \\\"{x:592,y:638,t:1527271997082};\\\", \\\"{x:583,y:658,t:1527271997098};\\\", \\\"{x:573,y:674,t:1527271997114};\\\", \\\"{x:568,y:688,t:1527271997132};\\\", \\\"{x:566,y:693,t:1527271997149};\\\", \\\"{x:564,y:698,t:1527271997164};\\\", \\\"{x:561,y:700,t:1527271997182};\\\", \\\"{x:559,y:703,t:1527271997199};\\\", \\\"{x:558,y:704,t:1527271997215};\\\", \\\"{x:554,y:706,t:1527271997232};\\\", \\\"{x:548,y:708,t:1527271997249};\\\", \\\"{x:543,y:709,t:1527271997265};\\\", \\\"{x:535,y:711,t:1527271997282};\\\", \\\"{x:526,y:712,t:1527271997299};\\\", \\\"{x:521,y:714,t:1527271997315};\\\", \\\"{x:514,y:715,t:1527271997332};\\\", \\\"{x:510,y:718,t:1527271997349};\\\", \\\"{x:507,y:721,t:1527271997367};\\\", \\\"{x:506,y:722,t:1527271997382};\\\", \\\"{x:506,y:723,t:1527271997464};\\\", \\\"{x:505,y:728,t:1527271997482};\\\", \\\"{x:505,y:730,t:1527271997499};\\\", \\\"{x:503,y:731,t:1527271997515};\\\", \\\"{x:501,y:730,t:1527271998048};\\\", \\\"{x:499,y:727,t:1527271998066};\\\", \\\"{x:493,y:716,t:1527271998082};\\\", \\\"{x:485,y:699,t:1527271998098};\\\", \\\"{x:481,y:692,t:1527271998116};\\\", \\\"{x:480,y:686,t:1527271998472};\\\", \\\"{x:480,y:685,t:1527271998487};\\\", \\\"{x:480,y:681,t:1527271998499};\\\", \\\"{x:480,y:673,t:1527271998516};\\\", \\\"{x:477,y:655,t:1527271998533};\\\", \\\"{x:475,y:638,t:1527271998550};\\\", \\\"{x:475,y:627,t:1527271998566};\\\", \\\"{x:473,y:620,t:1527271998583};\\\", \\\"{x:473,y:618,t:1527271998600};\\\", \\\"{x:473,y:617,t:1527271998615};\\\", \\\"{x:474,y:617,t:1527271998759};\\\", \\\"{x:476,y:617,t:1527271998783};\\\" ] }, { \\\"rt\\\": 33167, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 451998, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:620,t:1527271998948};\\\", \\\"{x:495,y:612,t:1527271999313};\\\", \\\"{x:495,y:611,t:1527271999322};\\\", \\\"{x:499,y:609,t:1527271999337};\\\", \\\"{x:509,y:603,t:1527271999353};\\\", \\\"{x:523,y:599,t:1527271999370};\\\", \\\"{x:544,y:591,t:1527271999386};\\\", \\\"{x:574,y:577,t:1527271999402};\\\", \\\"{x:591,y:571,t:1527271999419};\\\", \\\"{x:600,y:569,t:1527271999436};\\\", \\\"{x:602,y:568,t:1527271999453};\\\", \\\"{x:604,y:567,t:1527271999578};\\\", \\\"{x:609,y:567,t:1527271999587};\\\", \\\"{x:647,y:567,t:1527271999604};\\\", \\\"{x:754,y:572,t:1527271999620};\\\", \\\"{x:878,y:585,t:1527271999637};\\\", \\\"{x:990,y:591,t:1527271999654};\\\", \\\"{x:1106,y:591,t:1527271999669};\\\", \\\"{x:1217,y:593,t:1527271999686};\\\", \\\"{x:1314,y:593,t:1527271999704};\\\", \\\"{x:1411,y:602,t:1527271999720};\\\", \\\"{x:1487,y:617,t:1527271999736};\\\", \\\"{x:1535,y:632,t:1527271999754};\\\", \\\"{x:1569,y:650,t:1527271999770};\\\", \\\"{x:1605,y:681,t:1527271999787};\\\", \\\"{x:1623,y:707,t:1527271999804};\\\", \\\"{x:1645,y:738,t:1527271999820};\\\", \\\"{x:1660,y:765,t:1527271999838};\\\", \\\"{x:1674,y:787,t:1527271999854};\\\", \\\"{x:1687,y:805,t:1527271999870};\\\", \\\"{x:1696,y:818,t:1527271999888};\\\", \\\"{x:1702,y:828,t:1527271999904};\\\", \\\"{x:1706,y:841,t:1527271999920};\\\", \\\"{x:1707,y:849,t:1527271999937};\\\", \\\"{x:1707,y:861,t:1527271999954};\\\", \\\"{x:1707,y:879,t:1527271999970};\\\", \\\"{x:1707,y:886,t:1527271999986};\\\", \\\"{x:1707,y:890,t:1527272000005};\\\", \\\"{x:1706,y:895,t:1527272000020};\\\", \\\"{x:1702,y:903,t:1527272000037};\\\", \\\"{x:1697,y:908,t:1527272000054};\\\", \\\"{x:1691,y:915,t:1527272000071};\\\", \\\"{x:1685,y:921,t:1527272000087};\\\", \\\"{x:1677,y:929,t:1527272000104};\\\", \\\"{x:1671,y:933,t:1527272000122};\\\", \\\"{x:1660,y:937,t:1527272000138};\\\", \\\"{x:1651,y:939,t:1527272000155};\\\", \\\"{x:1642,y:942,t:1527272000171};\\\", \\\"{x:1629,y:943,t:1527272000187};\\\", \\\"{x:1618,y:947,t:1527272000204};\\\", \\\"{x:1611,y:949,t:1527272000221};\\\", \\\"{x:1604,y:952,t:1527272000238};\\\", \\\"{x:1603,y:953,t:1527272000254};\\\", \\\"{x:1601,y:954,t:1527272000272};\\\", \\\"{x:1600,y:956,t:1527272000287};\\\", \\\"{x:1597,y:958,t:1527272000305};\\\", \\\"{x:1597,y:960,t:1527272000321};\\\", \\\"{x:1595,y:962,t:1527272000338};\\\", \\\"{x:1594,y:965,t:1527272000355};\\\", \\\"{x:1593,y:969,t:1527272000371};\\\", \\\"{x:1592,y:970,t:1527272000388};\\\", \\\"{x:1590,y:971,t:1527272000405};\\\", \\\"{x:1585,y:971,t:1527272000422};\\\", \\\"{x:1577,y:971,t:1527272000437};\\\", \\\"{x:1569,y:971,t:1527272000454};\\\", \\\"{x:1557,y:971,t:1527272000471};\\\", \\\"{x:1553,y:971,t:1527272000488};\\\", \\\"{x:1550,y:971,t:1527272000504};\\\", \\\"{x:1549,y:970,t:1527272000531};\\\", \\\"{x:1549,y:969,t:1527272000579};\\\", \\\"{x:1549,y:968,t:1527272000748};\\\", \\\"{x:1549,y:967,t:1527272000755};\\\", \\\"{x:1549,y:965,t:1527272000778};\\\", \\\"{x:1550,y:964,t:1527272000794};\\\", \\\"{x:1551,y:962,t:1527272000874};\\\", \\\"{x:1551,y:958,t:1527272001780};\\\", \\\"{x:1551,y:954,t:1527272001790};\\\", \\\"{x:1551,y:949,t:1527272001806};\\\", \\\"{x:1551,y:944,t:1527272001822};\\\", \\\"{x:1551,y:939,t:1527272001840};\\\", \\\"{x:1551,y:938,t:1527272001856};\\\", \\\"{x:1551,y:937,t:1527272001972};\\\", \\\"{x:1551,y:939,t:1527272002051};\\\", \\\"{x:1551,y:942,t:1527272002059};\\\", \\\"{x:1551,y:945,t:1527272002072};\\\", \\\"{x:1551,y:949,t:1527272002089};\\\", \\\"{x:1551,y:953,t:1527272002106};\\\", \\\"{x:1549,y:955,t:1527272002122};\\\", \\\"{x:1549,y:957,t:1527272002139};\\\", \\\"{x:1547,y:959,t:1527272002156};\\\", \\\"{x:1547,y:960,t:1527272002172};\\\", \\\"{x:1546,y:962,t:1527272002188};\\\", \\\"{x:1546,y:966,t:1527272002206};\\\", \\\"{x:1546,y:968,t:1527272002223};\\\", \\\"{x:1544,y:969,t:1527272002240};\\\", \\\"{x:1544,y:967,t:1527272002403};\\\", \\\"{x:1544,y:966,t:1527272002427};\\\", \\\"{x:1544,y:964,t:1527272002532};\\\", \\\"{x:1544,y:963,t:1527272002547};\\\", \\\"{x:1544,y:961,t:1527272002557};\\\", \\\"{x:1544,y:960,t:1527272002573};\\\", \\\"{x:1545,y:959,t:1527272002595};\\\", \\\"{x:1545,y:958,t:1527272002606};\\\", \\\"{x:1545,y:957,t:1527272002623};\\\", \\\"{x:1545,y:955,t:1527272002641};\\\", \\\"{x:1545,y:954,t:1527272002656};\\\", \\\"{x:1546,y:953,t:1527272002672};\\\", \\\"{x:1546,y:952,t:1527272003235};\\\", \\\"{x:1546,y:951,t:1527272003243};\\\", \\\"{x:1546,y:950,t:1527272003257};\\\", \\\"{x:1547,y:947,t:1527272003275};\\\", \\\"{x:1547,y:945,t:1527272003291};\\\", \\\"{x:1548,y:944,t:1527272003307};\\\", \\\"{x:1548,y:940,t:1527272003324};\\\", \\\"{x:1548,y:938,t:1527272003341};\\\", \\\"{x:1548,y:935,t:1527272003357};\\\", \\\"{x:1549,y:932,t:1527272003375};\\\", \\\"{x:1549,y:931,t:1527272003391};\\\", \\\"{x:1549,y:929,t:1527272003408};\\\", \\\"{x:1549,y:927,t:1527272003425};\\\", \\\"{x:1549,y:925,t:1527272003441};\\\", \\\"{x:1550,y:922,t:1527272003457};\\\", \\\"{x:1550,y:921,t:1527272003474};\\\", \\\"{x:1550,y:920,t:1527272003490};\\\", \\\"{x:1550,y:919,t:1527272003507};\\\", \\\"{x:1550,y:918,t:1527272003525};\\\", \\\"{x:1550,y:917,t:1527272003540};\\\", \\\"{x:1550,y:916,t:1527272003557};\\\", \\\"{x:1550,y:913,t:1527272003574};\\\", \\\"{x:1550,y:909,t:1527272003591};\\\", \\\"{x:1550,y:908,t:1527272003607};\\\", \\\"{x:1550,y:905,t:1527272003625};\\\", \\\"{x:1549,y:902,t:1527272003641};\\\", \\\"{x:1549,y:901,t:1527272003657};\\\", \\\"{x:1549,y:900,t:1527272003674};\\\", \\\"{x:1549,y:899,t:1527272003691};\\\", \\\"{x:1549,y:897,t:1527272003787};\\\", \\\"{x:1549,y:896,t:1527272003811};\\\", \\\"{x:1549,y:894,t:1527272003842};\\\", \\\"{x:1549,y:893,t:1527272003866};\\\", \\\"{x:1549,y:891,t:1527272003915};\\\", \\\"{x:1549,y:890,t:1527272003955};\\\", \\\"{x:1549,y:889,t:1527272003971};\\\", \\\"{x:1549,y:888,t:1527272003987};\\\", \\\"{x:1549,y:887,t:1527272004028};\\\", \\\"{x:1549,y:885,t:1527272004059};\\\", \\\"{x:1549,y:884,t:1527272004145};\\\", \\\"{x:1548,y:883,t:1527272004169};\\\", \\\"{x:1547,y:883,t:1527272004178};\\\", \\\"{x:1547,y:882,t:1527272004194};\\\", \\\"{x:1547,y:881,t:1527272004235};\\\", \\\"{x:1547,y:880,t:1527272004282};\\\", \\\"{x:1547,y:879,t:1527272004291};\\\", \\\"{x:1547,y:878,t:1527272004308};\\\", \\\"{x:1548,y:877,t:1527272004325};\\\", \\\"{x:1548,y:876,t:1527272004346};\\\", \\\"{x:1548,y:875,t:1527272004370};\\\", \\\"{x:1548,y:874,t:1527272004379};\\\", \\\"{x:1548,y:873,t:1527272004391};\\\", \\\"{x:1548,y:872,t:1527272004408};\\\", \\\"{x:1548,y:870,t:1527272004425};\\\", \\\"{x:1548,y:869,t:1527272004441};\\\", \\\"{x:1548,y:867,t:1527272004458};\\\", \\\"{x:1548,y:866,t:1527272004475};\\\", \\\"{x:1548,y:864,t:1527272004491};\\\", \\\"{x:1548,y:863,t:1527272004515};\\\", \\\"{x:1548,y:861,t:1527272004538};\\\", \\\"{x:1548,y:860,t:1527272004571};\\\", \\\"{x:1548,y:858,t:1527272004579};\\\", \\\"{x:1548,y:857,t:1527272004603};\\\", \\\"{x:1548,y:855,t:1527272004626};\\\", \\\"{x:1548,y:854,t:1527272004643};\\\", \\\"{x:1548,y:852,t:1527272004658};\\\", \\\"{x:1548,y:850,t:1527272004675};\\\", \\\"{x:1548,y:848,t:1527272004691};\\\", \\\"{x:1548,y:847,t:1527272004709};\\\", \\\"{x:1548,y:846,t:1527272004725};\\\", \\\"{x:1548,y:845,t:1527272004747};\\\", \\\"{x:1548,y:844,t:1527272004759};\\\", \\\"{x:1548,y:843,t:1527272004775};\\\", \\\"{x:1548,y:842,t:1527272004793};\\\", \\\"{x:1548,y:840,t:1527272004808};\\\", \\\"{x:1548,y:839,t:1527272004826};\\\", \\\"{x:1548,y:838,t:1527272004843};\\\", \\\"{x:1548,y:836,t:1527272004859};\\\", \\\"{x:1548,y:835,t:1527272004891};\\\", \\\"{x:1548,y:834,t:1527272004899};\\\", \\\"{x:1548,y:833,t:1527272004923};\\\", \\\"{x:1548,y:832,t:1527272004955};\\\", \\\"{x:1548,y:831,t:1527272004971};\\\", \\\"{x:1548,y:830,t:1527272004987};\\\", \\\"{x:1548,y:829,t:1527272005010};\\\", \\\"{x:1548,y:827,t:1527272005028};\\\", \\\"{x:1548,y:826,t:1527272005051};\\\", \\\"{x:1548,y:825,t:1527272005059};\\\", \\\"{x:1548,y:824,t:1527272005075};\\\", \\\"{x:1548,y:823,t:1527272005092};\\\", \\\"{x:1548,y:821,t:1527272005109};\\\", \\\"{x:1548,y:820,t:1527272005131};\\\", \\\"{x:1548,y:819,t:1527272005143};\\\", \\\"{x:1548,y:815,t:1527272005159};\\\", \\\"{x:1548,y:814,t:1527272005176};\\\", \\\"{x:1548,y:812,t:1527272005193};\\\", \\\"{x:1548,y:811,t:1527272005210};\\\", \\\"{x:1548,y:809,t:1527272005755};\\\", \\\"{x:1548,y:806,t:1527272005763};\\\", \\\"{x:1548,y:801,t:1527272005776};\\\", \\\"{x:1546,y:796,t:1527272005793};\\\", \\\"{x:1545,y:792,t:1527272005809};\\\", \\\"{x:1545,y:788,t:1527272005826};\\\", \\\"{x:1545,y:787,t:1527272005843};\\\", \\\"{x:1545,y:786,t:1527272005859};\\\", \\\"{x:1545,y:785,t:1527272005882};\\\", \\\"{x:1545,y:783,t:1527272005898};\\\", \\\"{x:1545,y:782,t:1527272005914};\\\", \\\"{x:1545,y:780,t:1527272005926};\\\", \\\"{x:1545,y:777,t:1527272005943};\\\", \\\"{x:1545,y:771,t:1527272005959};\\\", \\\"{x:1545,y:768,t:1527272005976};\\\", \\\"{x:1545,y:765,t:1527272005993};\\\", \\\"{x:1545,y:763,t:1527272006009};\\\", \\\"{x:1543,y:761,t:1527272006026};\\\", \\\"{x:1543,y:760,t:1527272006044};\\\", \\\"{x:1543,y:758,t:1527272006060};\\\", \\\"{x:1543,y:757,t:1527272006076};\\\", \\\"{x:1543,y:756,t:1527272006094};\\\", \\\"{x:1543,y:754,t:1527272006109};\\\", \\\"{x:1543,y:753,t:1527272006127};\\\", \\\"{x:1542,y:751,t:1527272006143};\\\", \\\"{x:1542,y:750,t:1527272006160};\\\", \\\"{x:1542,y:748,t:1527272006176};\\\", \\\"{x:1542,y:747,t:1527272006194};\\\", \\\"{x:1542,y:746,t:1527272006210};\\\", \\\"{x:1542,y:744,t:1527272006227};\\\", \\\"{x:1542,y:743,t:1527272006243};\\\", \\\"{x:1542,y:742,t:1527272006261};\\\", \\\"{x:1540,y:740,t:1527272006277};\\\", \\\"{x:1540,y:737,t:1527272006293};\\\", \\\"{x:1540,y:736,t:1527272006315};\\\", \\\"{x:1540,y:735,t:1527272006326};\\\", \\\"{x:1540,y:734,t:1527272006344};\\\", \\\"{x:1540,y:733,t:1527272006379};\\\", \\\"{x:1540,y:732,t:1527272006395};\\\", \\\"{x:1540,y:731,t:1527272006411};\\\", \\\"{x:1540,y:730,t:1527272006459};\\\", \\\"{x:1540,y:729,t:1527272006474};\\\", \\\"{x:1540,y:728,t:1527272006490};\\\", \\\"{x:1540,y:726,t:1527272006498};\\\", \\\"{x:1540,y:725,t:1527272006514};\\\", \\\"{x:1540,y:723,t:1527272006530};\\\", \\\"{x:1540,y:722,t:1527272006546};\\\", \\\"{x:1540,y:720,t:1527272006560};\\\", \\\"{x:1540,y:719,t:1527272006577};\\\", \\\"{x:1540,y:717,t:1527272006593};\\\", \\\"{x:1540,y:714,t:1527272006611};\\\", \\\"{x:1540,y:712,t:1527272006627};\\\", \\\"{x:1540,y:711,t:1527272006643};\\\", \\\"{x:1540,y:710,t:1527272006667};\\\", \\\"{x:1540,y:709,t:1527272006690};\\\", \\\"{x:1540,y:708,t:1527272006698};\\\", \\\"{x:1540,y:706,t:1527272006731};\\\", \\\"{x:1540,y:705,t:1527272006746};\\\", \\\"{x:1540,y:704,t:1527272006763};\\\", \\\"{x:1540,y:703,t:1527272006778};\\\", \\\"{x:1540,y:702,t:1527272006795};\\\", \\\"{x:1540,y:701,t:1527272006810};\\\", \\\"{x:1540,y:700,t:1527272007795};\\\", \\\"{x:1541,y:697,t:1527272007812};\\\", \\\"{x:1541,y:695,t:1527272007828};\\\", \\\"{x:1541,y:694,t:1527272007844};\\\", \\\"{x:1541,y:693,t:1527272008051};\\\", \\\"{x:1541,y:692,t:1527272008062};\\\", \\\"{x:1541,y:691,t:1527272008082};\\\", \\\"{x:1541,y:689,t:1527272008114};\\\", \\\"{x:1541,y:688,t:1527272008138};\\\", \\\"{x:1541,y:686,t:1527272008154};\\\", \\\"{x:1541,y:685,t:1527272008170};\\\", \\\"{x:1541,y:683,t:1527272008187};\\\", \\\"{x:1541,y:682,t:1527272008203};\\\", \\\"{x:1541,y:680,t:1527272008219};\\\", \\\"{x:1541,y:679,t:1527272008234};\\\", \\\"{x:1541,y:677,t:1527272008251};\\\", \\\"{x:1541,y:676,t:1527272008261};\\\", \\\"{x:1541,y:673,t:1527272008279};\\\", \\\"{x:1541,y:670,t:1527272008295};\\\", \\\"{x:1541,y:667,t:1527272008312};\\\", \\\"{x:1541,y:665,t:1527272008328};\\\", \\\"{x:1541,y:663,t:1527272008346};\\\", \\\"{x:1541,y:661,t:1527272008362};\\\", \\\"{x:1541,y:660,t:1527272008378};\\\", \\\"{x:1541,y:657,t:1527272008396};\\\", \\\"{x:1541,y:654,t:1527272008413};\\\", \\\"{x:1541,y:653,t:1527272008429};\\\", \\\"{x:1541,y:651,t:1527272008445};\\\", \\\"{x:1541,y:650,t:1527272008467};\\\", \\\"{x:1541,y:649,t:1527272008482};\\\", \\\"{x:1541,y:648,t:1527272008498};\\\", \\\"{x:1541,y:647,t:1527272008512};\\\", \\\"{x:1541,y:646,t:1527272008528};\\\", \\\"{x:1541,y:643,t:1527272008546};\\\", \\\"{x:1541,y:640,t:1527272008563};\\\", \\\"{x:1541,y:639,t:1527272008579};\\\", \\\"{x:1541,y:636,t:1527272008595};\\\", \\\"{x:1541,y:633,t:1527272008612};\\\", \\\"{x:1541,y:629,t:1527272008629};\\\", \\\"{x:1540,y:627,t:1527272008646};\\\", \\\"{x:1540,y:625,t:1527272008663};\\\", \\\"{x:1540,y:623,t:1527272008679};\\\", \\\"{x:1540,y:622,t:1527272008696};\\\", \\\"{x:1540,y:620,t:1527272008712};\\\", \\\"{x:1540,y:619,t:1527272008730};\\\", \\\"{x:1540,y:614,t:1527272008745};\\\", \\\"{x:1540,y:608,t:1527272008762};\\\", \\\"{x:1540,y:604,t:1527272008779};\\\", \\\"{x:1540,y:601,t:1527272008795};\\\", \\\"{x:1540,y:599,t:1527272008812};\\\", \\\"{x:1540,y:595,t:1527272008830};\\\", \\\"{x:1539,y:592,t:1527272008845};\\\", \\\"{x:1539,y:590,t:1527272008863};\\\", \\\"{x:1538,y:585,t:1527272008879};\\\", \\\"{x:1538,y:583,t:1527272008895};\\\", \\\"{x:1538,y:581,t:1527272008913};\\\", \\\"{x:1537,y:579,t:1527272008929};\\\", \\\"{x:1537,y:578,t:1527272008946};\\\", \\\"{x:1536,y:575,t:1527272008962};\\\", \\\"{x:1536,y:573,t:1527272008979};\\\", \\\"{x:1536,y:571,t:1527272008997};\\\", \\\"{x:1535,y:569,t:1527272009013};\\\", \\\"{x:1535,y:568,t:1527272009030};\\\", \\\"{x:1535,y:566,t:1527272009047};\\\", \\\"{x:1535,y:565,t:1527272009067};\\\", \\\"{x:1535,y:564,t:1527272009083};\\\", \\\"{x:1535,y:563,t:1527272009099};\\\", \\\"{x:1535,y:571,t:1527272013155};\\\", \\\"{x:1535,y:585,t:1527272013167};\\\", \\\"{x:1535,y:623,t:1527272013184};\\\", \\\"{x:1535,y:676,t:1527272013200};\\\", \\\"{x:1535,y:724,t:1527272013217};\\\", \\\"{x:1535,y:755,t:1527272013233};\\\", \\\"{x:1535,y:800,t:1527272013251};\\\", \\\"{x:1535,y:831,t:1527272013267};\\\", \\\"{x:1535,y:856,t:1527272013284};\\\", \\\"{x:1538,y:875,t:1527272013302};\\\", \\\"{x:1543,y:892,t:1527272013317};\\\", \\\"{x:1543,y:902,t:1527272013334};\\\", \\\"{x:1543,y:908,t:1527272013351};\\\", \\\"{x:1544,y:921,t:1527272013367};\\\", \\\"{x:1544,y:934,t:1527272013384};\\\", \\\"{x:1545,y:948,t:1527272013401};\\\", \\\"{x:1547,y:961,t:1527272013417};\\\", \\\"{x:1549,y:970,t:1527272013434};\\\", \\\"{x:1550,y:978,t:1527272013451};\\\", \\\"{x:1550,y:981,t:1527272013466};\\\", \\\"{x:1550,y:985,t:1527272013484};\\\", \\\"{x:1551,y:987,t:1527272013501};\\\", \\\"{x:1551,y:986,t:1527272013643};\\\", \\\"{x:1551,y:983,t:1527272013652};\\\", \\\"{x:1551,y:975,t:1527272013667};\\\", \\\"{x:1551,y:966,t:1527272013684};\\\", \\\"{x:1551,y:958,t:1527272013700};\\\", \\\"{x:1551,y:953,t:1527272013718};\\\", \\\"{x:1551,y:952,t:1527272013733};\\\", \\\"{x:1550,y:951,t:1527272013988};\\\", \\\"{x:1549,y:951,t:1527272014010};\\\", \\\"{x:1548,y:951,t:1527272014019};\\\", \\\"{x:1547,y:952,t:1527272014035};\\\", \\\"{x:1546,y:953,t:1527272014051};\\\", \\\"{x:1546,y:954,t:1527272014068};\\\", \\\"{x:1546,y:955,t:1527272014091};\\\", \\\"{x:1546,y:956,t:1527272014107};\\\", \\\"{x:1546,y:957,t:1527272014118};\\\", \\\"{x:1548,y:959,t:1527272014135};\\\", \\\"{x:1550,y:961,t:1527272014150};\\\", \\\"{x:1550,y:960,t:1527272014867};\\\", \\\"{x:1550,y:959,t:1527272014963};\\\", \\\"{x:1550,y:958,t:1527272014971};\\\", \\\"{x:1550,y:957,t:1527272014985};\\\", \\\"{x:1550,y:956,t:1527272015002};\\\", \\\"{x:1550,y:954,t:1527272015019};\\\", \\\"{x:1550,y:951,t:1527272015035};\\\", \\\"{x:1550,y:949,t:1527272015083};\\\", \\\"{x:1550,y:948,t:1527272015107};\\\", \\\"{x:1550,y:946,t:1527272015123};\\\", \\\"{x:1550,y:945,t:1527272015139};\\\", \\\"{x:1550,y:944,t:1527272015155};\\\", \\\"{x:1550,y:943,t:1527272015169};\\\", \\\"{x:1550,y:942,t:1527272015186};\\\", \\\"{x:1550,y:939,t:1527272015202};\\\", \\\"{x:1550,y:936,t:1527272015219};\\\", \\\"{x:1550,y:934,t:1527272015236};\\\", \\\"{x:1550,y:933,t:1527272015254};\\\", \\\"{x:1550,y:932,t:1527272015269};\\\", \\\"{x:1550,y:930,t:1527272015286};\\\", \\\"{x:1549,y:928,t:1527272015302};\\\", \\\"{x:1549,y:927,t:1527272015319};\\\", \\\"{x:1549,y:926,t:1527272015336};\\\", \\\"{x:1549,y:925,t:1527272015352};\\\", \\\"{x:1549,y:924,t:1527272015369};\\\", \\\"{x:1549,y:923,t:1527272015387};\\\", \\\"{x:1549,y:922,t:1527272015403};\\\", \\\"{x:1549,y:921,t:1527272015419};\\\", \\\"{x:1549,y:920,t:1527272015483};\\\", \\\"{x:1549,y:919,t:1527272015531};\\\", \\\"{x:1549,y:918,t:1527272015563};\\\", \\\"{x:1549,y:917,t:1527272015627};\\\", \\\"{x:1549,y:916,t:1527272015643};\\\", \\\"{x:1549,y:915,t:1527272015653};\\\", \\\"{x:1549,y:914,t:1527272015674};\\\", \\\"{x:1549,y:913,t:1527272015698};\\\", \\\"{x:1549,y:912,t:1527272015722};\\\", \\\"{x:1549,y:911,t:1527272015746};\\\", \\\"{x:1549,y:910,t:1527272015770};\\\", \\\"{x:1549,y:909,t:1527272015785};\\\", \\\"{x:1549,y:913,t:1527272017426};\\\", \\\"{x:1549,y:921,t:1527272017437};\\\", \\\"{x:1551,y:935,t:1527272017454};\\\", \\\"{x:1553,y:948,t:1527272017470};\\\", \\\"{x:1554,y:955,t:1527272017487};\\\", \\\"{x:1555,y:961,t:1527272017504};\\\", \\\"{x:1555,y:963,t:1527272017520};\\\", \\\"{x:1555,y:965,t:1527272017537};\\\", \\\"{x:1555,y:966,t:1527272017554};\\\", \\\"{x:1555,y:964,t:1527272017770};\\\", \\\"{x:1555,y:959,t:1527272017787};\\\", \\\"{x:1555,y:953,t:1527272017804};\\\", \\\"{x:1555,y:947,t:1527272017821};\\\", \\\"{x:1555,y:943,t:1527272017837};\\\", \\\"{x:1555,y:939,t:1527272017855};\\\", \\\"{x:1555,y:937,t:1527272017871};\\\", \\\"{x:1555,y:935,t:1527272017888};\\\", \\\"{x:1555,y:934,t:1527272017904};\\\", \\\"{x:1554,y:931,t:1527272017922};\\\", \\\"{x:1554,y:930,t:1527272017937};\\\", \\\"{x:1554,y:927,t:1527272017954};\\\", \\\"{x:1554,y:925,t:1527272017971};\\\", \\\"{x:1554,y:922,t:1527272017988};\\\", \\\"{x:1554,y:920,t:1527272018005};\\\", \\\"{x:1554,y:918,t:1527272018022};\\\", \\\"{x:1553,y:916,t:1527272018037};\\\", \\\"{x:1553,y:914,t:1527272018055};\\\", \\\"{x:1553,y:912,t:1527272018072};\\\", \\\"{x:1553,y:911,t:1527272018088};\\\", \\\"{x:1553,y:909,t:1527272018105};\\\", \\\"{x:1553,y:907,t:1527272018122};\\\", \\\"{x:1553,y:905,t:1527272018138};\\\", \\\"{x:1553,y:902,t:1527272018155};\\\", \\\"{x:1553,y:900,t:1527272018171};\\\", \\\"{x:1553,y:897,t:1527272018188};\\\", \\\"{x:1553,y:896,t:1527272018205};\\\", \\\"{x:1551,y:894,t:1527272018222};\\\", \\\"{x:1551,y:893,t:1527272018237};\\\", \\\"{x:1551,y:891,t:1527272018254};\\\", \\\"{x:1551,y:890,t:1527272018272};\\\", \\\"{x:1551,y:887,t:1527272018289};\\\", \\\"{x:1551,y:885,t:1527272018304};\\\", \\\"{x:1551,y:881,t:1527272018322};\\\", \\\"{x:1551,y:878,t:1527272018338};\\\", \\\"{x:1550,y:876,t:1527272018355};\\\", \\\"{x:1548,y:873,t:1527272018372};\\\", \\\"{x:1547,y:870,t:1527272018389};\\\", \\\"{x:1546,y:868,t:1527272018405};\\\", \\\"{x:1546,y:866,t:1527272018421};\\\", \\\"{x:1544,y:862,t:1527272018439};\\\", \\\"{x:1544,y:860,t:1527272018455};\\\", \\\"{x:1544,y:857,t:1527272018472};\\\", \\\"{x:1544,y:856,t:1527272018489};\\\", \\\"{x:1544,y:855,t:1527272018522};\\\", \\\"{x:1544,y:854,t:1527272018539};\\\", \\\"{x:1544,y:853,t:1527272018556};\\\", \\\"{x:1544,y:852,t:1527272018619};\\\", \\\"{x:1544,y:851,t:1527272018627};\\\", \\\"{x:1544,y:850,t:1527272018666};\\\", \\\"{x:1544,y:849,t:1527272018722};\\\", \\\"{x:1544,y:848,t:1527272018738};\\\", \\\"{x:1544,y:847,t:1527272018755};\\\", \\\"{x:1544,y:846,t:1527272018772};\\\", \\\"{x:1544,y:845,t:1527272018788};\\\", \\\"{x:1544,y:844,t:1527272018806};\\\", \\\"{x:1544,y:842,t:1527272018822};\\\", \\\"{x:1544,y:841,t:1527272018838};\\\", \\\"{x:1544,y:840,t:1527272018856};\\\", \\\"{x:1544,y:839,t:1527272018875};\\\", \\\"{x:1544,y:838,t:1527272018931};\\\", \\\"{x:1544,y:837,t:1527272018947};\\\", \\\"{x:1544,y:836,t:1527272018962};\\\", \\\"{x:1544,y:835,t:1527272018987};\\\", \\\"{x:1544,y:834,t:1527272018994};\\\", \\\"{x:1544,y:833,t:1527272019011};\\\", \\\"{x:1544,y:832,t:1527272019075};\\\", \\\"{x:1544,y:831,t:1527272019091};\\\", \\\"{x:1544,y:830,t:1527272019123};\\\", \\\"{x:1544,y:829,t:1527272020731};\\\", \\\"{x:1544,y:827,t:1527272020741};\\\", \\\"{x:1544,y:825,t:1527272020759};\\\", \\\"{x:1544,y:822,t:1527272020775};\\\", \\\"{x:1544,y:820,t:1527272020791};\\\", \\\"{x:1545,y:818,t:1527272020808};\\\", \\\"{x:1545,y:817,t:1527272020824};\\\", \\\"{x:1545,y:816,t:1527272020840};\\\", \\\"{x:1545,y:814,t:1527272020857};\\\", \\\"{x:1545,y:812,t:1527272020873};\\\", \\\"{x:1545,y:811,t:1527272020890};\\\", \\\"{x:1545,y:810,t:1527272020908};\\\", \\\"{x:1545,y:808,t:1527272020924};\\\", \\\"{x:1545,y:807,t:1527272020941};\\\", \\\"{x:1545,y:804,t:1527272020958};\\\", \\\"{x:1545,y:803,t:1527272020978};\\\", \\\"{x:1545,y:802,t:1527272020991};\\\", \\\"{x:1545,y:801,t:1527272021008};\\\", \\\"{x:1545,y:800,t:1527272021027};\\\", \\\"{x:1545,y:798,t:1527272021042};\\\", \\\"{x:1545,y:797,t:1527272021066};\\\", \\\"{x:1545,y:796,t:1527272021081};\\\", \\\"{x:1545,y:795,t:1527272021106};\\\", \\\"{x:1545,y:794,t:1527272021146};\\\", \\\"{x:1545,y:793,t:1527272021162};\\\", \\\"{x:1545,y:792,t:1527272021175};\\\", \\\"{x:1545,y:791,t:1527272021203};\\\", \\\"{x:1545,y:790,t:1527272021210};\\\", \\\"{x:1545,y:789,t:1527272021226};\\\", \\\"{x:1545,y:788,t:1527272021250};\\\", \\\"{x:1545,y:787,t:1527272021259};\\\", \\\"{x:1545,y:786,t:1527272021275};\\\", \\\"{x:1545,y:784,t:1527272021291};\\\", \\\"{x:1545,y:783,t:1527272021308};\\\", \\\"{x:1545,y:782,t:1527272021325};\\\", \\\"{x:1545,y:781,t:1527272021341};\\\", \\\"{x:1545,y:780,t:1527272021358};\\\", \\\"{x:1545,y:779,t:1527272021375};\\\", \\\"{x:1545,y:778,t:1527272021391};\\\", \\\"{x:1545,y:777,t:1527272021408};\\\", \\\"{x:1545,y:776,t:1527272021435};\\\", \\\"{x:1545,y:775,t:1527272021451};\\\", \\\"{x:1545,y:774,t:1527272021459};\\\", \\\"{x:1545,y:773,t:1527272021481};\\\", \\\"{x:1545,y:772,t:1527272021492};\\\", \\\"{x:1545,y:771,t:1527272021508};\\\", \\\"{x:1545,y:770,t:1527272021538};\\\", \\\"{x:1545,y:769,t:1527272021546};\\\", \\\"{x:1545,y:768,t:1527272021558};\\\", \\\"{x:1545,y:767,t:1527272021575};\\\", \\\"{x:1545,y:766,t:1527272021591};\\\", \\\"{x:1545,y:765,t:1527272021610};\\\", \\\"{x:1545,y:764,t:1527272022147};\\\", \\\"{x:1545,y:763,t:1527272022160};\\\", \\\"{x:1546,y:758,t:1527272022176};\\\", \\\"{x:1550,y:751,t:1527272022192};\\\", \\\"{x:1551,y:746,t:1527272022210};\\\", \\\"{x:1552,y:744,t:1527272022227};\\\", \\\"{x:1552,y:742,t:1527272022243};\\\", \\\"{x:1553,y:737,t:1527272022259};\\\", \\\"{x:1553,y:736,t:1527272022276};\\\", \\\"{x:1553,y:733,t:1527272022292};\\\", \\\"{x:1553,y:732,t:1527272022315};\\\", \\\"{x:1553,y:731,t:1527272022326};\\\", \\\"{x:1553,y:730,t:1527272022342};\\\", \\\"{x:1553,y:729,t:1527272022363};\\\", \\\"{x:1553,y:728,t:1527272022379};\\\", \\\"{x:1553,y:727,t:1527272022392};\\\", \\\"{x:1553,y:726,t:1527272022410};\\\", \\\"{x:1553,y:724,t:1527272022427};\\\", \\\"{x:1553,y:722,t:1527272022443};\\\", \\\"{x:1553,y:720,t:1527272022460};\\\", \\\"{x:1553,y:717,t:1527272022476};\\\", \\\"{x:1553,y:715,t:1527272022492};\\\", \\\"{x:1553,y:714,t:1527272022510};\\\", \\\"{x:1553,y:710,t:1527272022527};\\\", \\\"{x:1553,y:708,t:1527272022542};\\\", \\\"{x:1553,y:706,t:1527272022559};\\\", \\\"{x:1553,y:705,t:1527272022577};\\\", \\\"{x:1553,y:704,t:1527272022619};\\\", \\\"{x:1553,y:703,t:1527272022634};\\\", \\\"{x:1553,y:702,t:1527272022659};\\\", \\\"{x:1553,y:701,t:1527272022739};\\\", \\\"{x:1552,y:700,t:1527272022747};\\\", \\\"{x:1552,y:699,t:1527272022762};\\\", \\\"{x:1551,y:697,t:1527272022779};\\\", \\\"{x:1551,y:696,t:1527272024787};\\\", \\\"{x:1550,y:694,t:1527272024851};\\\", \\\"{x:1550,y:693,t:1527272024862};\\\", \\\"{x:1549,y:689,t:1527272024878};\\\", \\\"{x:1548,y:686,t:1527272024894};\\\", \\\"{x:1547,y:684,t:1527272024911};\\\", \\\"{x:1547,y:683,t:1527272024928};\\\", \\\"{x:1547,y:682,t:1527272024945};\\\", \\\"{x:1546,y:681,t:1527272024961};\\\", \\\"{x:1546,y:679,t:1527272024978};\\\", \\\"{x:1545,y:678,t:1527272024994};\\\", \\\"{x:1545,y:677,t:1527272025018};\\\", \\\"{x:1545,y:676,t:1527272025050};\\\", \\\"{x:1545,y:675,t:1527272025062};\\\", \\\"{x:1545,y:674,t:1527272025078};\\\", \\\"{x:1544,y:672,t:1527272025095};\\\", \\\"{x:1544,y:671,t:1527272025112};\\\", \\\"{x:1544,y:670,t:1527272025129};\\\", \\\"{x:1544,y:669,t:1527272025145};\\\", \\\"{x:1544,y:667,t:1527272025162};\\\", \\\"{x:1544,y:666,t:1527272025179};\\\", \\\"{x:1544,y:664,t:1527272025195};\\\", \\\"{x:1544,y:662,t:1527272025212};\\\", \\\"{x:1544,y:661,t:1527272025228};\\\", \\\"{x:1544,y:660,t:1527272025245};\\\", \\\"{x:1544,y:658,t:1527272025262};\\\", \\\"{x:1544,y:657,t:1527272025278};\\\", \\\"{x:1544,y:654,t:1527272025295};\\\", \\\"{x:1544,y:652,t:1527272025315};\\\", \\\"{x:1545,y:651,t:1527272025328};\\\", \\\"{x:1545,y:650,t:1527272025371};\\\", \\\"{x:1545,y:649,t:1527272025387};\\\", \\\"{x:1545,y:648,t:1527272025403};\\\", \\\"{x:1545,y:647,t:1527272025427};\\\", \\\"{x:1545,y:646,t:1527272025443};\\\", \\\"{x:1545,y:645,t:1527272025451};\\\", \\\"{x:1545,y:644,t:1527272025483};\\\", \\\"{x:1545,y:643,t:1527272025499};\\\", \\\"{x:1545,y:642,t:1527272025522};\\\", \\\"{x:1545,y:641,t:1527272025643};\\\", \\\"{x:1545,y:640,t:1527272025652};\\\", \\\"{x:1545,y:639,t:1527272025662};\\\", \\\"{x:1545,y:638,t:1527272025697};\\\", \\\"{x:1545,y:637,t:1527272025722};\\\", \\\"{x:1545,y:636,t:1527272025730};\\\", \\\"{x:1545,y:634,t:1527272025746};\\\", \\\"{x:1545,y:633,t:1527272025770};\\\", \\\"{x:1545,y:632,t:1527272025802};\\\", \\\"{x:1545,y:631,t:1527272025818};\\\", \\\"{x:1545,y:630,t:1527272025834};\\\", \\\"{x:1545,y:629,t:1527272025851};\\\", \\\"{x:1545,y:628,t:1527272025862};\\\", \\\"{x:1545,y:627,t:1527272025880};\\\", \\\"{x:1545,y:626,t:1527272025896};\\\", \\\"{x:1545,y:625,t:1527272027243};\\\", \\\"{x:1544,y:622,t:1527272027251};\\\", \\\"{x:1544,y:619,t:1527272027264};\\\", \\\"{x:1542,y:613,t:1527272027280};\\\", \\\"{x:1541,y:607,t:1527272027297};\\\", \\\"{x:1540,y:597,t:1527272027314};\\\", \\\"{x:1540,y:592,t:1527272027330};\\\", \\\"{x:1539,y:589,t:1527272027347};\\\", \\\"{x:1538,y:588,t:1527272027364};\\\", \\\"{x:1538,y:587,t:1527272027380};\\\", \\\"{x:1538,y:586,t:1527272027435};\\\", \\\"{x:1538,y:584,t:1527272027459};\\\", \\\"{x:1539,y:583,t:1527272027475};\\\", \\\"{x:1539,y:581,t:1527272027491};\\\", \\\"{x:1540,y:579,t:1527272027507};\\\", \\\"{x:1541,y:578,t:1527272027531};\\\", \\\"{x:1542,y:577,t:1527272027548};\\\", \\\"{x:1542,y:576,t:1527272027565};\\\", \\\"{x:1543,y:574,t:1527272027581};\\\", \\\"{x:1544,y:573,t:1527272027603};\\\", \\\"{x:1545,y:572,t:1527272027618};\\\", \\\"{x:1545,y:571,t:1527272027635};\\\", \\\"{x:1547,y:570,t:1527272027651};\\\", \\\"{x:1547,y:569,t:1527272027667};\\\", \\\"{x:1547,y:568,t:1527272027682};\\\", \\\"{x:1547,y:567,t:1527272027715};\\\", \\\"{x:1547,y:565,t:1527272027732};\\\", \\\"{x:1547,y:564,t:1527272027748};\\\", \\\"{x:1548,y:563,t:1527272027765};\\\", \\\"{x:1548,y:562,t:1527272027781};\\\", \\\"{x:1547,y:557,t:1527272029892};\\\", \\\"{x:1545,y:552,t:1527272029899};\\\", \\\"{x:1543,y:544,t:1527272029916};\\\", \\\"{x:1543,y:540,t:1527272029933};\\\", \\\"{x:1543,y:535,t:1527272029949};\\\", \\\"{x:1543,y:530,t:1527272029966};\\\", \\\"{x:1543,y:529,t:1527272029983};\\\", \\\"{x:1543,y:527,t:1527272029999};\\\", \\\"{x:1543,y:525,t:1527272030016};\\\", \\\"{x:1543,y:524,t:1527272030033};\\\", \\\"{x:1543,y:520,t:1527272030050};\\\", \\\"{x:1543,y:516,t:1527272030066};\\\", \\\"{x:1543,y:514,t:1527272030083};\\\", \\\"{x:1543,y:511,t:1527272030101};\\\", \\\"{x:1543,y:509,t:1527272030116};\\\", \\\"{x:1543,y:508,t:1527272030134};\\\", \\\"{x:1543,y:506,t:1527272030150};\\\", \\\"{x:1543,y:504,t:1527272030170};\\\", \\\"{x:1543,y:503,t:1527272030187};\\\", \\\"{x:1543,y:502,t:1527272030201};\\\", \\\"{x:1543,y:501,t:1527272030216};\\\", \\\"{x:1543,y:499,t:1527272030234};\\\", \\\"{x:1543,y:497,t:1527272030251};\\\", \\\"{x:1543,y:496,t:1527272030267};\\\", \\\"{x:1543,y:495,t:1527272030468};\\\", \\\"{x:1543,y:493,t:1527272030483};\\\", \\\"{x:1543,y:489,t:1527272030501};\\\", \\\"{x:1543,y:483,t:1527272030518};\\\", \\\"{x:1543,y:478,t:1527272030534};\\\", \\\"{x:1543,y:474,t:1527272030551};\\\", \\\"{x:1543,y:471,t:1527272030567};\\\", \\\"{x:1543,y:470,t:1527272030584};\\\", \\\"{x:1541,y:471,t:1527272030659};\\\", \\\"{x:1536,y:477,t:1527272030668};\\\", \\\"{x:1518,y:500,t:1527272030684};\\\", \\\"{x:1465,y:548,t:1527272030701};\\\", \\\"{x:1389,y:592,t:1527272030718};\\\", \\\"{x:1288,y:628,t:1527272030735};\\\", \\\"{x:1178,y:654,t:1527272030750};\\\", \\\"{x:1037,y:674,t:1527272030768};\\\", \\\"{x:890,y:693,t:1527272030790};\\\", \\\"{x:768,y:712,t:1527272030799};\\\", \\\"{x:657,y:726,t:1527272030817};\\\", \\\"{x:526,y:732,t:1527272030834};\\\", \\\"{x:478,y:733,t:1527272030850};\\\", \\\"{x:456,y:734,t:1527272030867};\\\", \\\"{x:448,y:737,t:1527272030877};\\\", \\\"{x:438,y:742,t:1527272030894};\\\", \\\"{x:430,y:747,t:1527272030910};\\\", \\\"{x:423,y:753,t:1527272030929};\\\", \\\"{x:418,y:761,t:1527272030946};\\\", \\\"{x:417,y:761,t:1527272030962};\\\", \\\"{x:417,y:760,t:1527272031066};\\\", \\\"{x:417,y:757,t:1527272031080};\\\", \\\"{x:418,y:753,t:1527272031097};\\\", \\\"{x:418,y:752,t:1527272031113};\\\", \\\"{x:419,y:752,t:1527272031154};\\\", \\\"{x:420,y:752,t:1527272031163};\\\", \\\"{x:421,y:752,t:1527272031179};\\\", \\\"{x:425,y:752,t:1527272031197};\\\", \\\"{x:431,y:752,t:1527272031214};\\\", \\\"{x:440,y:752,t:1527272031229};\\\", \\\"{x:446,y:752,t:1527272031246};\\\", \\\"{x:450,y:750,t:1527272031265};\\\", \\\"{x:454,y:749,t:1527272031279};\\\", \\\"{x:458,y:746,t:1527272031296};\\\", \\\"{x:462,y:744,t:1527272031313};\\\", \\\"{x:467,y:741,t:1527272031329};\\\", \\\"{x:475,y:738,t:1527272031345};\\\", \\\"{x:478,y:737,t:1527272031363};\\\", \\\"{x:478,y:736,t:1527272031778};\\\", \\\"{x:485,y:736,t:1527272032489};\\\", \\\"{x:496,y:736,t:1527272032497};\\\", \\\"{x:520,y:736,t:1527272032513};\\\", \\\"{x:537,y:742,t:1527272032529};\\\", \\\"{x:541,y:743,t:1527272032547};\\\", \\\"{x:541,y:744,t:1527272032564};\\\", \\\"{x:545,y:744,t:1527272032580};\\\", \\\"{x:595,y:744,t:1527272032597};\\\", \\\"{x:706,y:744,t:1527272032614};\\\", \\\"{x:764,y:760,t:1527272032630};\\\", \\\"{x:822,y:786,t:1527272032647};\\\", \\\"{x:857,y:801,t:1527272032664};\\\", \\\"{x:884,y:819,t:1527272032680};\\\", \\\"{x:902,y:831,t:1527272032698};\\\", \\\"{x:929,y:860,t:1527272032714};\\\", \\\"{x:944,y:879,t:1527272032730};\\\", \\\"{x:948,y:888,t:1527272032747};\\\", \\\"{x:948,y:892,t:1527272032764};\\\", \\\"{x:948,y:893,t:1527272032780};\\\" ] }, { \\\"rt\\\": 21336, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 474603, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -02 PM-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:946,y:892,t:1527272033458};\\\", \\\"{x:942,y:888,t:1527272033466};\\\", \\\"{x:938,y:888,t:1527272033481};\\\", \\\"{x:923,y:884,t:1527272033497};\\\", \\\"{x:918,y:882,t:1527272033514};\\\", \\\"{x:914,y:880,t:1527272033538};\\\", \\\"{x:912,y:880,t:1527272033548};\\\", \\\"{x:911,y:880,t:1527272033564};\\\", \\\"{x:908,y:879,t:1527272033581};\\\", \\\"{x:903,y:879,t:1527272033598};\\\", \\\"{x:896,y:879,t:1527272033615};\\\", \\\"{x:889,y:879,t:1527272033631};\\\", \\\"{x:879,y:876,t:1527272033648};\\\", \\\"{x:874,y:874,t:1527272033665};\\\", \\\"{x:869,y:870,t:1527272033681};\\\", \\\"{x:852,y:844,t:1527272033698};\\\", \\\"{x:829,y:807,t:1527272033715};\\\", \\\"{x:609,y:714,t:1527272033836};\\\", \\\"{x:609,y:716,t:1527272033848};\\\", \\\"{x:613,y:719,t:1527272033865};\\\", \\\"{x:618,y:722,t:1527272033881};\\\", \\\"{x:618,y:723,t:1527272033898};\\\", \\\"{x:619,y:723,t:1527272034442};\\\", \\\"{x:622,y:724,t:1527272034458};\\\", \\\"{x:623,y:724,t:1527272034466};\\\", \\\"{x:636,y:724,t:1527272034482};\\\", \\\"{x:651,y:724,t:1527272034498};\\\", \\\"{x:669,y:727,t:1527272034516};\\\", \\\"{x:688,y:732,t:1527272034533};\\\", \\\"{x:711,y:736,t:1527272034549};\\\", \\\"{x:734,y:741,t:1527272034565};\\\", \\\"{x:759,y:748,t:1527272034583};\\\", \\\"{x:780,y:756,t:1527272034599};\\\", \\\"{x:800,y:766,t:1527272034616};\\\", \\\"{x:813,y:774,t:1527272034632};\\\", \\\"{x:822,y:784,t:1527272034649};\\\", \\\"{x:824,y:792,t:1527272034665};\\\", \\\"{x:824,y:801,t:1527272034682};\\\", \\\"{x:822,y:805,t:1527272034699};\\\", \\\"{x:820,y:810,t:1527272034715};\\\", \\\"{x:815,y:816,t:1527272034733};\\\", \\\"{x:808,y:824,t:1527272034749};\\\", \\\"{x:803,y:830,t:1527272034765};\\\", \\\"{x:801,y:835,t:1527272034783};\\\", \\\"{x:800,y:837,t:1527272034800};\\\", \\\"{x:798,y:839,t:1527272034815};\\\", \\\"{x:797,y:842,t:1527272034832};\\\", \\\"{x:797,y:843,t:1527272034850};\\\", \\\"{x:797,y:845,t:1527272034866};\\\", \\\"{x:795,y:847,t:1527272034883};\\\", \\\"{x:793,y:849,t:1527272034899};\\\", \\\"{x:787,y:849,t:1527272034915};\\\", \\\"{x:784,y:849,t:1527272034933};\\\", \\\"{x:783,y:849,t:1527272034949};\\\", \\\"{x:783,y:850,t:1527272035211};\\\", \\\"{x:784,y:850,t:1527272035218};\\\", \\\"{x:784,y:851,t:1527272035233};\\\", \\\"{x:786,y:852,t:1527272035249};\\\", \\\"{x:787,y:853,t:1527272035266};\\\", \\\"{x:788,y:853,t:1527272035283};\\\", \\\"{x:789,y:853,t:1527272035322};\\\", \\\"{x:797,y:852,t:1527272035914};\\\", \\\"{x:808,y:850,t:1527272035922};\\\", \\\"{x:819,y:849,t:1527272035933};\\\", \\\"{x:841,y:846,t:1527272035950};\\\", \\\"{x:859,y:844,t:1527272035966};\\\", \\\"{x:886,y:842,t:1527272035984};\\\", \\\"{x:909,y:841,t:1527272036000};\\\", \\\"{x:930,y:841,t:1527272036016};\\\", \\\"{x:940,y:841,t:1527272036034};\\\", \\\"{x:947,y:840,t:1527272036050};\\\", \\\"{x:949,y:840,t:1527272036066};\\\", \\\"{x:949,y:839,t:1527272036084};\\\", \\\"{x:950,y:839,t:1527272036100};\\\", \\\"{x:951,y:837,t:1527272036116};\\\", \\\"{x:953,y:832,t:1527272036133};\\\", \\\"{x:954,y:827,t:1527272036151};\\\", \\\"{x:958,y:823,t:1527272036166};\\\", \\\"{x:958,y:822,t:1527272036184};\\\", \\\"{x:961,y:818,t:1527272036435};\\\", \\\"{x:985,y:804,t:1527272036451};\\\", \\\"{x:1001,y:796,t:1527272036468};\\\", \\\"{x:1020,y:787,t:1527272036484};\\\", \\\"{x:1044,y:778,t:1527272036500};\\\", \\\"{x:1081,y:761,t:1527272036518};\\\", \\\"{x:1130,y:733,t:1527272036535};\\\", \\\"{x:1203,y:696,t:1527272036551};\\\", \\\"{x:1279,y:666,t:1527272036568};\\\", \\\"{x:1360,y:630,t:1527272036585};\\\", \\\"{x:1423,y:603,t:1527272036601};\\\", \\\"{x:1473,y:581,t:1527272036618};\\\", \\\"{x:1506,y:568,t:1527272036634};\\\", \\\"{x:1541,y:552,t:1527272036650};\\\", \\\"{x:1562,y:546,t:1527272036668};\\\", \\\"{x:1579,y:541,t:1527272036684};\\\", \\\"{x:1591,y:539,t:1527272036701};\\\", \\\"{x:1606,y:539,t:1527272036718};\\\", \\\"{x:1624,y:539,t:1527272036734};\\\", \\\"{x:1641,y:539,t:1527272036751};\\\", \\\"{x:1652,y:539,t:1527272036768};\\\", \\\"{x:1654,y:539,t:1527272036785};\\\", \\\"{x:1654,y:540,t:1527272036819};\\\", \\\"{x:1650,y:551,t:1527272036835};\\\", \\\"{x:1635,y:567,t:1527272036851};\\\", \\\"{x:1615,y:581,t:1527272036868};\\\", \\\"{x:1596,y:595,t:1527272036885};\\\", \\\"{x:1578,y:606,t:1527272036901};\\\", \\\"{x:1568,y:612,t:1527272036917};\\\", \\\"{x:1561,y:615,t:1527272036935};\\\", \\\"{x:1559,y:618,t:1527272036951};\\\", \\\"{x:1558,y:618,t:1527272036968};\\\", \\\"{x:1557,y:618,t:1527272036985};\\\", \\\"{x:1556,y:619,t:1527272037026};\\\", \\\"{x:1555,y:619,t:1527272037050};\\\", \\\"{x:1554,y:619,t:1527272037057};\\\", \\\"{x:1552,y:620,t:1527272037068};\\\", \\\"{x:1550,y:621,t:1527272037085};\\\", \\\"{x:1547,y:623,t:1527272037100};\\\", \\\"{x:1543,y:625,t:1527272037117};\\\", \\\"{x:1540,y:626,t:1527272037134};\\\", \\\"{x:1536,y:626,t:1527272037151};\\\", \\\"{x:1533,y:628,t:1527272037167};\\\", \\\"{x:1530,y:628,t:1527272037184};\\\", \\\"{x:1527,y:630,t:1527272037202};\\\", \\\"{x:1522,y:633,t:1527272037218};\\\", \\\"{x:1515,y:637,t:1527272037234};\\\", \\\"{x:1512,y:640,t:1527272037251};\\\", \\\"{x:1509,y:645,t:1527272037267};\\\", \\\"{x:1506,y:649,t:1527272037285};\\\", \\\"{x:1504,y:653,t:1527272037301};\\\", \\\"{x:1503,y:655,t:1527272037317};\\\", \\\"{x:1501,y:660,t:1527272037334};\\\", \\\"{x:1500,y:663,t:1527272037351};\\\", \\\"{x:1498,y:666,t:1527272037368};\\\", \\\"{x:1495,y:673,t:1527272037385};\\\", \\\"{x:1491,y:680,t:1527272037402};\\\", \\\"{x:1487,y:688,t:1527272037418};\\\", \\\"{x:1476,y:707,t:1527272037434};\\\", \\\"{x:1459,y:728,t:1527272037451};\\\", \\\"{x:1435,y:750,t:1527272037468};\\\", \\\"{x:1418,y:768,t:1527272037485};\\\", \\\"{x:1406,y:783,t:1527272037502};\\\", \\\"{x:1395,y:796,t:1527272037518};\\\", \\\"{x:1388,y:802,t:1527272037535};\\\", \\\"{x:1386,y:810,t:1527272037551};\\\", \\\"{x:1383,y:818,t:1527272037568};\\\", \\\"{x:1382,y:824,t:1527272037585};\\\", \\\"{x:1381,y:835,t:1527272037602};\\\", \\\"{x:1378,y:845,t:1527272037619};\\\", \\\"{x:1378,y:857,t:1527272037635};\\\", \\\"{x:1378,y:866,t:1527272037652};\\\", \\\"{x:1378,y:870,t:1527272037669};\\\", \\\"{x:1379,y:875,t:1527272037684};\\\", \\\"{x:1379,y:878,t:1527272037701};\\\", \\\"{x:1383,y:885,t:1527272037718};\\\", \\\"{x:1387,y:890,t:1527272037735};\\\", \\\"{x:1397,y:900,t:1527272037751};\\\", \\\"{x:1413,y:910,t:1527272037768};\\\", \\\"{x:1433,y:918,t:1527272037785};\\\", \\\"{x:1451,y:922,t:1527272037802};\\\", \\\"{x:1467,y:924,t:1527272037818};\\\", \\\"{x:1473,y:927,t:1527272037834};\\\", \\\"{x:1476,y:927,t:1527272037852};\\\", \\\"{x:1478,y:929,t:1527272037868};\\\", \\\"{x:1479,y:930,t:1527272037885};\\\", \\\"{x:1481,y:931,t:1527272037901};\\\", \\\"{x:1483,y:932,t:1527272037919};\\\", \\\"{x:1483,y:933,t:1527272037934};\\\", \\\"{x:1484,y:934,t:1527272037951};\\\", \\\"{x:1487,y:936,t:1527272037968};\\\", \\\"{x:1488,y:936,t:1527272037985};\\\", \\\"{x:1489,y:938,t:1527272038001};\\\", \\\"{x:1489,y:940,t:1527272038018};\\\", \\\"{x:1489,y:942,t:1527272038035};\\\", \\\"{x:1489,y:945,t:1527272038052};\\\", \\\"{x:1489,y:948,t:1527272038070};\\\", \\\"{x:1488,y:948,t:1527272038086};\\\", \\\"{x:1488,y:949,t:1527272038139};\\\", \\\"{x:1488,y:951,t:1527272038163};\\\", \\\"{x:1487,y:952,t:1527272038179};\\\", \\\"{x:1486,y:952,t:1527272038187};\\\", \\\"{x:1486,y:954,t:1527272038203};\\\", \\\"{x:1484,y:955,t:1527272038219};\\\", \\\"{x:1483,y:956,t:1527272038236};\\\", \\\"{x:1482,y:957,t:1527272038253};\\\", \\\"{x:1481,y:959,t:1527272038269};\\\", \\\"{x:1480,y:959,t:1527272038287};\\\", \\\"{x:1478,y:961,t:1527272038302};\\\", \\\"{x:1477,y:962,t:1527272038319};\\\", \\\"{x:1477,y:961,t:1527272038538};\\\", \\\"{x:1477,y:959,t:1527272038551};\\\", \\\"{x:1477,y:957,t:1527272038568};\\\", \\\"{x:1478,y:953,t:1527272038585};\\\", \\\"{x:1479,y:950,t:1527272038602};\\\", \\\"{x:1479,y:948,t:1527272038619};\\\", \\\"{x:1479,y:946,t:1527272038635};\\\", \\\"{x:1480,y:946,t:1527272038652};\\\", \\\"{x:1480,y:945,t:1527272038668};\\\", \\\"{x:1480,y:943,t:1527272038686};\\\", \\\"{x:1480,y:942,t:1527272038702};\\\", \\\"{x:1480,y:941,t:1527272038719};\\\", \\\"{x:1480,y:940,t:1527272038736};\\\", \\\"{x:1481,y:938,t:1527272038752};\\\", \\\"{x:1481,y:937,t:1527272038770};\\\", \\\"{x:1481,y:936,t:1527272038785};\\\", \\\"{x:1482,y:935,t:1527272038803};\\\", \\\"{x:1482,y:933,t:1527272038818};\\\", \\\"{x:1482,y:932,t:1527272038836};\\\", \\\"{x:1483,y:930,t:1527272038853};\\\", \\\"{x:1483,y:929,t:1527272038869};\\\", \\\"{x:1484,y:928,t:1527272038885};\\\", \\\"{x:1484,y:927,t:1527272038903};\\\", \\\"{x:1484,y:928,t:1527272039283};\\\", \\\"{x:1484,y:931,t:1527272039291};\\\", \\\"{x:1484,y:933,t:1527272039303};\\\", \\\"{x:1484,y:937,t:1527272039320};\\\", \\\"{x:1484,y:940,t:1527272039336};\\\", \\\"{x:1484,y:943,t:1527272039353};\\\", \\\"{x:1484,y:944,t:1527272039370};\\\", \\\"{x:1484,y:946,t:1527272039386};\\\", \\\"{x:1484,y:947,t:1527272039411};\\\", \\\"{x:1484,y:949,t:1527272039434};\\\", \\\"{x:1484,y:950,t:1527272039459};\\\", \\\"{x:1485,y:952,t:1527272039474};\\\", \\\"{x:1485,y:953,t:1527272039499};\\\", \\\"{x:1485,y:955,t:1527272039507};\\\", \\\"{x:1485,y:956,t:1527272039530};\\\", \\\"{x:1485,y:957,t:1527272039539};\\\", \\\"{x:1485,y:958,t:1527272039552};\\\", \\\"{x:1485,y:959,t:1527272039570};\\\", \\\"{x:1485,y:960,t:1527272039585};\\\", \\\"{x:1485,y:961,t:1527272039603};\\\", \\\"{x:1485,y:962,t:1527272039620};\\\", \\\"{x:1485,y:965,t:1527272039636};\\\", \\\"{x:1485,y:968,t:1527272039652};\\\", \\\"{x:1485,y:969,t:1527272039669};\\\", \\\"{x:1485,y:970,t:1527272039687};\\\", \\\"{x:1485,y:968,t:1527272039827};\\\", \\\"{x:1485,y:965,t:1527272039837};\\\", \\\"{x:1485,y:961,t:1527272039854};\\\", \\\"{x:1485,y:957,t:1527272039870};\\\", \\\"{x:1485,y:950,t:1527272039888};\\\", \\\"{x:1485,y:941,t:1527272039904};\\\", \\\"{x:1485,y:936,t:1527272039920};\\\", \\\"{x:1485,y:930,t:1527272039937};\\\", \\\"{x:1485,y:926,t:1527272039954};\\\", \\\"{x:1485,y:923,t:1527272039970};\\\", \\\"{x:1485,y:921,t:1527272039987};\\\", \\\"{x:1485,y:919,t:1527272040004};\\\", \\\"{x:1484,y:916,t:1527272040020};\\\", \\\"{x:1484,y:913,t:1527272040037};\\\", \\\"{x:1483,y:910,t:1527272040054};\\\", \\\"{x:1483,y:909,t:1527272040070};\\\", \\\"{x:1482,y:907,t:1527272040087};\\\", \\\"{x:1482,y:906,t:1527272040104};\\\", \\\"{x:1482,y:904,t:1527272040120};\\\", \\\"{x:1482,y:903,t:1527272040137};\\\", \\\"{x:1482,y:901,t:1527272040153};\\\", \\\"{x:1482,y:900,t:1527272040170};\\\", \\\"{x:1482,y:898,t:1527272040187};\\\", \\\"{x:1482,y:895,t:1527272040204};\\\", \\\"{x:1482,y:893,t:1527272040220};\\\", \\\"{x:1482,y:890,t:1527272040237};\\\", \\\"{x:1482,y:886,t:1527272040253};\\\", \\\"{x:1482,y:883,t:1527272040270};\\\", \\\"{x:1482,y:880,t:1527272040287};\\\", \\\"{x:1482,y:878,t:1527272040304};\\\", \\\"{x:1482,y:875,t:1527272040321};\\\", \\\"{x:1482,y:871,t:1527272040337};\\\", \\\"{x:1481,y:868,t:1527272040354};\\\", \\\"{x:1481,y:867,t:1527272040371};\\\", \\\"{x:1481,y:865,t:1527272040388};\\\", \\\"{x:1481,y:864,t:1527272040404};\\\", \\\"{x:1481,y:861,t:1527272040421};\\\", \\\"{x:1480,y:860,t:1527272040438};\\\", \\\"{x:1480,y:858,t:1527272040454};\\\", \\\"{x:1480,y:857,t:1527272040471};\\\", \\\"{x:1480,y:855,t:1527272040487};\\\", \\\"{x:1480,y:854,t:1527272040504};\\\", \\\"{x:1480,y:852,t:1527272040521};\\\", \\\"{x:1480,y:851,t:1527272040537};\\\", \\\"{x:1480,y:849,t:1527272040554};\\\", \\\"{x:1479,y:847,t:1527272040571};\\\", \\\"{x:1479,y:845,t:1527272040587};\\\", \\\"{x:1479,y:843,t:1527272040604};\\\", \\\"{x:1479,y:842,t:1527272040621};\\\", \\\"{x:1479,y:840,t:1527272040637};\\\", \\\"{x:1479,y:839,t:1527272040654};\\\", \\\"{x:1479,y:837,t:1527272040698};\\\", \\\"{x:1479,y:836,t:1527272040731};\\\", \\\"{x:1479,y:834,t:1527272040773};\\\", \\\"{x:1479,y:833,t:1527272040818};\\\", \\\"{x:1479,y:831,t:1527272040842};\\\", \\\"{x:1479,y:830,t:1527272040874};\\\", \\\"{x:1479,y:828,t:1527272040897};\\\", \\\"{x:1479,y:827,t:1527272040954};\\\", \\\"{x:1479,y:825,t:1527272041018};\\\", \\\"{x:1479,y:824,t:1527272041067};\\\", \\\"{x:1479,y:822,t:1527272041082};\\\", \\\"{x:1479,y:821,t:1527272041106};\\\", \\\"{x:1479,y:820,t:1527272041121};\\\", \\\"{x:1479,y:818,t:1527272041138};\\\", \\\"{x:1479,y:816,t:1527272041155};\\\", \\\"{x:1480,y:815,t:1527272041171};\\\", \\\"{x:1480,y:814,t:1527272041187};\\\", \\\"{x:1480,y:812,t:1527272041205};\\\", \\\"{x:1481,y:810,t:1527272041222};\\\", \\\"{x:1481,y:809,t:1527272041243};\\\", \\\"{x:1481,y:808,t:1527272041291};\\\", \\\"{x:1481,y:807,t:1527272041307};\\\", \\\"{x:1481,y:806,t:1527272041323};\\\", \\\"{x:1481,y:805,t:1527272041402};\\\", \\\"{x:1481,y:804,t:1527272041410};\\\", \\\"{x:1481,y:803,t:1527272041421};\\\", \\\"{x:1481,y:801,t:1527272041437};\\\", \\\"{x:1481,y:799,t:1527272041455};\\\", \\\"{x:1481,y:798,t:1527272041475};\\\", \\\"{x:1481,y:796,t:1527272041491};\\\", \\\"{x:1481,y:795,t:1527272041507};\\\", \\\"{x:1481,y:794,t:1527272041521};\\\", \\\"{x:1481,y:793,t:1527272041538};\\\", \\\"{x:1481,y:791,t:1527272041555};\\\", \\\"{x:1481,y:790,t:1527272041572};\\\", \\\"{x:1481,y:788,t:1527272041588};\\\", \\\"{x:1481,y:785,t:1527272041606};\\\", \\\"{x:1481,y:784,t:1527272041627};\\\", \\\"{x:1481,y:782,t:1527272041642};\\\", \\\"{x:1481,y:777,t:1527272041711};\\\", \\\"{x:1481,y:776,t:1527272041722};\\\", \\\"{x:1481,y:774,t:1527272041737};\\\", \\\"{x:1481,y:773,t:1527272041754};\\\", \\\"{x:1483,y:772,t:1527272041771};\\\", \\\"{x:1483,y:771,t:1527272041787};\\\", \\\"{x:1483,y:769,t:1527272041804};\\\", \\\"{x:1483,y:768,t:1527272041825};\\\", \\\"{x:1483,y:767,t:1527272041838};\\\", \\\"{x:1483,y:766,t:1527272041865};\\\", \\\"{x:1483,y:765,t:1527272041971};\\\", \\\"{x:1483,y:764,t:1527272042010};\\\", \\\"{x:1483,y:763,t:1527272042099};\\\", \\\"{x:1480,y:763,t:1527272042354};\\\", \\\"{x:1478,y:763,t:1527272042377};\\\", \\\"{x:1477,y:763,t:1527272042393};\\\", \\\"{x:1475,y:763,t:1527272042417};\\\", \\\"{x:1475,y:762,t:1527272042426};\\\", \\\"{x:1474,y:762,t:1527272042449};\\\", \\\"{x:1473,y:762,t:1527272042738};\\\", \\\"{x:1473,y:761,t:1527272042771};\\\", \\\"{x:1473,y:760,t:1527272043347};\\\", \\\"{x:1474,y:761,t:1527272043362};\\\", \\\"{x:1475,y:761,t:1527272043459};\\\", \\\"{x:1477,y:761,t:1527272043475};\\\", \\\"{x:1478,y:761,t:1527272043491};\\\", \\\"{x:1479,y:761,t:1527272043506};\\\", \\\"{x:1479,y:760,t:1527272044531};\\\", \\\"{x:1479,y:759,t:1527272044546};\\\", \\\"{x:1479,y:758,t:1527272044557};\\\", \\\"{x:1479,y:757,t:1527272044573};\\\", \\\"{x:1479,y:756,t:1527272044650};\\\", \\\"{x:1479,y:755,t:1527272044682};\\\", \\\"{x:1479,y:754,t:1527272044771};\\\", \\\"{x:1479,y:753,t:1527272044802};\\\", \\\"{x:1479,y:752,t:1527272044819};\\\", \\\"{x:1479,y:751,t:1527272044827};\\\", \\\"{x:1479,y:750,t:1527272044858};\\\", \\\"{x:1479,y:749,t:1527272044875};\\\", \\\"{x:1479,y:748,t:1527272044891};\\\", \\\"{x:1479,y:745,t:1527272044908};\\\", \\\"{x:1479,y:744,t:1527272044925};\\\", \\\"{x:1479,y:742,t:1527272044941};\\\", \\\"{x:1479,y:741,t:1527272044958};\\\", \\\"{x:1479,y:740,t:1527272044974};\\\", \\\"{x:1479,y:739,t:1527272044991};\\\", \\\"{x:1479,y:738,t:1527272045008};\\\", \\\"{x:1479,y:736,t:1527272045024};\\\", \\\"{x:1480,y:732,t:1527272045042};\\\", \\\"{x:1480,y:729,t:1527272045057};\\\", \\\"{x:1481,y:726,t:1527272045074};\\\", \\\"{x:1481,y:724,t:1527272045098};\\\", \\\"{x:1481,y:723,t:1527272045108};\\\", \\\"{x:1482,y:722,t:1527272045124};\\\", \\\"{x:1482,y:719,t:1527272045141};\\\", \\\"{x:1482,y:717,t:1527272045158};\\\", \\\"{x:1482,y:713,t:1527272045174};\\\", \\\"{x:1482,y:711,t:1527272045191};\\\", \\\"{x:1482,y:709,t:1527272045208};\\\", \\\"{x:1482,y:706,t:1527272045224};\\\", \\\"{x:1482,y:705,t:1527272045243};\\\", \\\"{x:1482,y:704,t:1527272045259};\\\", \\\"{x:1482,y:703,t:1527272045275};\\\", \\\"{x:1482,y:702,t:1527272045291};\\\", \\\"{x:1482,y:700,t:1527272045308};\\\", \\\"{x:1482,y:699,t:1527272045325};\\\", \\\"{x:1481,y:697,t:1527272045341};\\\", \\\"{x:1481,y:696,t:1527272045403};\\\", \\\"{x:1481,y:695,t:1527272045411};\\\", \\\"{x:1481,y:694,t:1527272045425};\\\", \\\"{x:1480,y:693,t:1527272046579};\\\", \\\"{x:1468,y:693,t:1527272046592};\\\", \\\"{x:1425,y:693,t:1527272046609};\\\", \\\"{x:1327,y:693,t:1527272046626};\\\", \\\"{x:1117,y:674,t:1527272046643};\\\", \\\"{x:987,y:657,t:1527272046659};\\\", \\\"{x:871,y:641,t:1527272046677};\\\", \\\"{x:795,y:628,t:1527272046692};\\\", \\\"{x:747,y:613,t:1527272046709};\\\", \\\"{x:729,y:606,t:1527272046726};\\\", \\\"{x:721,y:601,t:1527272046744};\\\", \\\"{x:721,y:600,t:1527272046759};\\\", \\\"{x:721,y:599,t:1527272046775};\\\", \\\"{x:721,y:598,t:1527272046793};\\\", \\\"{x:716,y:596,t:1527272046809};\\\", \\\"{x:688,y:593,t:1527272046825};\\\", \\\"{x:666,y:588,t:1527272046842};\\\", \\\"{x:641,y:579,t:1527272046859};\\\", \\\"{x:620,y:567,t:1527272046877};\\\", \\\"{x:599,y:552,t:1527272046893};\\\", \\\"{x:588,y:543,t:1527272046908};\\\", \\\"{x:583,y:535,t:1527272046927};\\\", \\\"{x:583,y:528,t:1527272046943};\\\", \\\"{x:583,y:523,t:1527272046959};\\\", \\\"{x:588,y:515,t:1527272046976};\\\", \\\"{x:593,y:508,t:1527272046992};\\\", \\\"{x:598,y:501,t:1527272047009};\\\", \\\"{x:602,y:498,t:1527272047027};\\\", \\\"{x:604,y:497,t:1527272047043};\\\", \\\"{x:607,y:497,t:1527272047059};\\\", \\\"{x:612,y:500,t:1527272047076};\\\", \\\"{x:619,y:505,t:1527272047094};\\\", \\\"{x:628,y:509,t:1527272047110};\\\", \\\"{x:638,y:512,t:1527272047126};\\\", \\\"{x:655,y:514,t:1527272047143};\\\", \\\"{x:680,y:517,t:1527272047160};\\\", \\\"{x:711,y:517,t:1527272047176};\\\", \\\"{x:751,y:517,t:1527272047193};\\\", \\\"{x:800,y:517,t:1527272047209};\\\", \\\"{x:825,y:516,t:1527272047225};\\\", \\\"{x:832,y:514,t:1527272047243};\\\", \\\"{x:833,y:514,t:1527272047259};\\\", \\\"{x:834,y:514,t:1527272047387};\\\", \\\"{x:837,y:514,t:1527272047394};\\\", \\\"{x:838,y:514,t:1527272047409};\\\", \\\"{x:841,y:515,t:1527272047426};\\\", \\\"{x:841,y:516,t:1527272047442};\\\", \\\"{x:844,y:516,t:1527272047753};\\\", \\\"{x:849,y:518,t:1527272047762};\\\", \\\"{x:857,y:518,t:1527272047777};\\\", \\\"{x:880,y:521,t:1527272047793};\\\", \\\"{x:947,y:531,t:1527272047810};\\\", \\\"{x:1033,y:542,t:1527272047827};\\\", \\\"{x:1133,y:558,t:1527272047843};\\\", \\\"{x:1238,y:572,t:1527272047860};\\\", \\\"{x:1343,y:598,t:1527272047878};\\\", \\\"{x:1435,y:628,t:1527272047893};\\\", \\\"{x:1504,y:658,t:1527272047910};\\\", \\\"{x:1541,y:683,t:1527272047928};\\\", \\\"{x:1560,y:697,t:1527272047943};\\\", \\\"{x:1564,y:701,t:1527272047961};\\\", \\\"{x:1564,y:703,t:1527272047977};\\\", \\\"{x:1563,y:705,t:1527272047994};\\\", \\\"{x:1561,y:707,t:1527272048010};\\\", \\\"{x:1560,y:708,t:1527272048027};\\\", \\\"{x:1558,y:709,t:1527272048043};\\\", \\\"{x:1558,y:711,t:1527272048061};\\\", \\\"{x:1558,y:712,t:1527272048078};\\\", \\\"{x:1555,y:712,t:1527272048107};\\\", \\\"{x:1552,y:712,t:1527272048115};\\\", \\\"{x:1548,y:712,t:1527272048127};\\\", \\\"{x:1536,y:708,t:1527272048145};\\\", \\\"{x:1519,y:701,t:1527272048160};\\\", \\\"{x:1500,y:697,t:1527272048178};\\\", \\\"{x:1478,y:694,t:1527272048194};\\\", \\\"{x:1469,y:692,t:1527272048210};\\\", \\\"{x:1465,y:691,t:1527272048227};\\\", \\\"{x:1466,y:691,t:1527272048387};\\\", \\\"{x:1467,y:691,t:1527272048394};\\\", \\\"{x:1468,y:691,t:1527272048410};\\\", \\\"{x:1469,y:691,t:1527272048426};\\\", \\\"{x:1473,y:692,t:1527272048444};\\\", \\\"{x:1479,y:693,t:1527272048460};\\\", \\\"{x:1482,y:695,t:1527272048477};\\\", \\\"{x:1486,y:695,t:1527272048494};\\\", \\\"{x:1487,y:695,t:1527272048514};\\\", \\\"{x:1487,y:696,t:1527272048843};\\\", \\\"{x:1487,y:697,t:1527272048851};\\\", \\\"{x:1487,y:698,t:1527272048861};\\\", \\\"{x:1487,y:700,t:1527272048877};\\\", \\\"{x:1486,y:701,t:1527272048963};\\\", \\\"{x:1485,y:701,t:1527272048994};\\\", \\\"{x:1483,y:700,t:1527272049011};\\\", \\\"{x:1482,y:695,t:1527272049028};\\\", \\\"{x:1479,y:687,t:1527272049045};\\\", \\\"{x:1477,y:678,t:1527272049062};\\\", \\\"{x:1474,y:670,t:1527272049078};\\\", \\\"{x:1473,y:664,t:1527272049095};\\\", \\\"{x:1473,y:659,t:1527272049111};\\\", \\\"{x:1471,y:655,t:1527272049129};\\\", \\\"{x:1471,y:652,t:1527272049144};\\\", \\\"{x:1471,y:651,t:1527272049162};\\\", \\\"{x:1471,y:649,t:1527272049178};\\\", \\\"{x:1471,y:647,t:1527272049194};\\\", \\\"{x:1471,y:646,t:1527272049212};\\\", \\\"{x:1471,y:643,t:1527272049228};\\\", \\\"{x:1472,y:641,t:1527272049245};\\\", \\\"{x:1474,y:637,t:1527272049261};\\\", \\\"{x:1475,y:636,t:1527272049278};\\\", \\\"{x:1475,y:634,t:1527272049295};\\\", \\\"{x:1476,y:632,t:1527272049312};\\\", \\\"{x:1477,y:630,t:1527272049329};\\\", \\\"{x:1478,y:629,t:1527272049346};\\\", \\\"{x:1479,y:626,t:1527272049362};\\\", \\\"{x:1480,y:623,t:1527272049378};\\\", \\\"{x:1480,y:620,t:1527272049395};\\\", \\\"{x:1480,y:618,t:1527272049418};\\\", \\\"{x:1480,y:617,t:1527272049442};\\\", \\\"{x:1480,y:615,t:1527272049475};\\\", \\\"{x:1480,y:614,t:1527272049490};\\\", \\\"{x:1480,y:612,t:1527272049515};\\\", \\\"{x:1480,y:611,t:1527272049529};\\\", \\\"{x:1480,y:610,t:1527272049546};\\\", \\\"{x:1480,y:608,t:1527272049562};\\\", \\\"{x:1478,y:604,t:1527272049578};\\\", \\\"{x:1477,y:600,t:1527272049596};\\\", \\\"{x:1477,y:598,t:1527272049611};\\\", \\\"{x:1477,y:597,t:1527272049629};\\\", \\\"{x:1477,y:594,t:1527272049646};\\\", \\\"{x:1477,y:592,t:1527272049661};\\\", \\\"{x:1477,y:590,t:1527272049679};\\\", \\\"{x:1477,y:588,t:1527272049696};\\\", \\\"{x:1477,y:586,t:1527272049715};\\\", \\\"{x:1477,y:585,t:1527272049729};\\\", \\\"{x:1477,y:584,t:1527272049746};\\\", \\\"{x:1477,y:582,t:1527272049762};\\\", \\\"{x:1477,y:581,t:1527272049779};\\\", \\\"{x:1477,y:579,t:1527272049795};\\\", \\\"{x:1477,y:578,t:1527272049812};\\\", \\\"{x:1477,y:577,t:1527272049835};\\\", \\\"{x:1477,y:576,t:1527272049846};\\\", \\\"{x:1477,y:575,t:1527272049862};\\\", \\\"{x:1477,y:572,t:1527272049879};\\\", \\\"{x:1477,y:570,t:1527272049895};\\\", \\\"{x:1477,y:568,t:1527272049912};\\\", \\\"{x:1477,y:566,t:1527272049929};\\\", \\\"{x:1477,y:564,t:1527272049945};\\\", \\\"{x:1477,y:562,t:1527272049962};\\\", \\\"{x:1477,y:560,t:1527272049979};\\\", \\\"{x:1477,y:559,t:1527272050002};\\\", \\\"{x:1472,y:559,t:1527272052050};\\\", \\\"{x:1463,y:559,t:1527272052064};\\\", \\\"{x:1435,y:561,t:1527272052081};\\\", \\\"{x:1403,y:561,t:1527272052097};\\\", \\\"{x:1339,y:561,t:1527272052114};\\\", \\\"{x:1225,y:561,t:1527272052131};\\\", \\\"{x:1156,y:561,t:1527272052150};\\\", \\\"{x:1089,y:561,t:1527272052163};\\\", \\\"{x:1027,y:561,t:1527272052180};\\\", \\\"{x:985,y:561,t:1527272052197};\\\", \\\"{x:947,y:565,t:1527272052215};\\\", \\\"{x:916,y:570,t:1527272052230};\\\", \\\"{x:887,y:571,t:1527272052247};\\\", \\\"{x:856,y:571,t:1527272052263};\\\", \\\"{x:819,y:571,t:1527272052279};\\\", \\\"{x:775,y:571,t:1527272052296};\\\", \\\"{x:722,y:571,t:1527272052313};\\\", \\\"{x:658,y:571,t:1527272052329};\\\", \\\"{x:533,y:571,t:1527272052346};\\\", \\\"{x:449,y:571,t:1527272052363};\\\", \\\"{x:391,y:571,t:1527272052379};\\\", \\\"{x:351,y:571,t:1527272052396};\\\", \\\"{x:327,y:571,t:1527272052413};\\\", \\\"{x:309,y:571,t:1527272052429};\\\", \\\"{x:298,y:571,t:1527272052446};\\\", \\\"{x:288,y:574,t:1527272052463};\\\", \\\"{x:272,y:576,t:1527272052479};\\\", \\\"{x:257,y:579,t:1527272052497};\\\", \\\"{x:239,y:580,t:1527272052513};\\\", \\\"{x:212,y:583,t:1527272052529};\\\", \\\"{x:193,y:583,t:1527272052546};\\\", \\\"{x:173,y:583,t:1527272052563};\\\", \\\"{x:159,y:583,t:1527272052580};\\\", \\\"{x:156,y:583,t:1527272052597};\\\", \\\"{x:154,y:582,t:1527272052615};\\\", \\\"{x:156,y:578,t:1527272052631};\\\", \\\"{x:170,y:571,t:1527272052648};\\\", \\\"{x:199,y:565,t:1527272052665};\\\", \\\"{x:257,y:556,t:1527272052681};\\\", \\\"{x:330,y:555,t:1527272052698};\\\", \\\"{x:452,y:555,t:1527272052714};\\\", \\\"{x:514,y:555,t:1527272052731};\\\", \\\"{x:575,y:553,t:1527272052748};\\\", \\\"{x:614,y:549,t:1527272052765};\\\", \\\"{x:633,y:547,t:1527272052781};\\\", \\\"{x:644,y:545,t:1527272052797};\\\", \\\"{x:645,y:544,t:1527272052814};\\\", \\\"{x:645,y:543,t:1527272052889};\\\", \\\"{x:642,y:543,t:1527272052906};\\\", \\\"{x:638,y:543,t:1527272052914};\\\", \\\"{x:627,y:540,t:1527272052931};\\\", \\\"{x:612,y:536,t:1527272052948};\\\", \\\"{x:609,y:535,t:1527272052964};\\\", \\\"{x:606,y:534,t:1527272052981};\\\", \\\"{x:604,y:532,t:1527272052997};\\\", \\\"{x:604,y:529,t:1527272053014};\\\", \\\"{x:603,y:527,t:1527272053031};\\\", \\\"{x:602,y:525,t:1527272053047};\\\", \\\"{x:601,y:524,t:1527272053064};\\\", \\\"{x:601,y:523,t:1527272053081};\\\", \\\"{x:601,y:522,t:1527272053097};\\\", \\\"{x:601,y:521,t:1527272053214};\\\", \\\"{x:603,y:520,t:1527272053231};\\\", \\\"{x:604,y:519,t:1527272053248};\\\", \\\"{x:604,y:519,t:1527272053317};\\\", \\\"{x:606,y:519,t:1527272053515};\\\", \\\"{x:626,y:519,t:1527272053532};\\\", \\\"{x:684,y:524,t:1527272053550};\\\", \\\"{x:814,y:539,t:1527272053564};\\\", \\\"{x:955,y:539,t:1527272053581};\\\", \\\"{x:1129,y:539,t:1527272053598};\\\", \\\"{x:1298,y:539,t:1527272053614};\\\", \\\"{x:1472,y:539,t:1527272053631};\\\", \\\"{x:1610,y:539,t:1527272053648};\\\", \\\"{x:1698,y:545,t:1527272053665};\\\", \\\"{x:1723,y:549,t:1527272053681};\\\", \\\"{x:1730,y:552,t:1527272053698};\\\", \\\"{x:1730,y:553,t:1527272053737};\\\", \\\"{x:1730,y:554,t:1527272053748};\\\", \\\"{x:1726,y:554,t:1527272053765};\\\", \\\"{x:1720,y:554,t:1527272053781};\\\", \\\"{x:1710,y:554,t:1527272053799};\\\", \\\"{x:1695,y:551,t:1527272053816};\\\", \\\"{x:1665,y:544,t:1527272053831};\\\", \\\"{x:1609,y:528,t:1527272053848};\\\", \\\"{x:1509,y:514,t:1527272053865};\\\", \\\"{x:1336,y:494,t:1527272053882};\\\", \\\"{x:1196,y:479,t:1527272053898};\\\", \\\"{x:1071,y:479,t:1527272053916};\\\", \\\"{x:958,y:479,t:1527272053933};\\\", \\\"{x:860,y:482,t:1527272053948};\\\", \\\"{x:777,y:502,t:1527272053967};\\\", \\\"{x:714,y:529,t:1527272053983};\\\", \\\"{x:650,y:573,t:1527272054000};\\\", \\\"{x:607,y:604,t:1527272054017};\\\", \\\"{x:581,y:625,t:1527272054034};\\\", \\\"{x:560,y:638,t:1527272054047};\\\", \\\"{x:539,y:652,t:1527272054065};\\\", \\\"{x:514,y:666,t:1527272054080};\\\", \\\"{x:475,y:693,t:1527272054098};\\\", \\\"{x:448,y:711,t:1527272054115};\\\", \\\"{x:413,y:731,t:1527272054132};\\\", \\\"{x:371,y:749,t:1527272054148};\\\", \\\"{x:353,y:756,t:1527272054165};\\\", \\\"{x:349,y:756,t:1527272054182};\\\", \\\"{x:346,y:757,t:1527272054198};\\\", \\\"{x:345,y:757,t:1527272054215};\\\", \\\"{x:342,y:758,t:1527272054232};\\\", \\\"{x:339,y:759,t:1527272054248};\\\", \\\"{x:341,y:757,t:1527272054299};\\\", \\\"{x:349,y:753,t:1527272054315};\\\", \\\"{x:363,y:752,t:1527272054333};\\\", \\\"{x:382,y:752,t:1527272054348};\\\", \\\"{x:404,y:752,t:1527272054366};\\\", \\\"{x:422,y:752,t:1527272054382};\\\", \\\"{x:436,y:749,t:1527272054399};\\\", \\\"{x:442,y:748,t:1527272054415};\\\", \\\"{x:445,y:747,t:1527272054434};\\\", \\\"{x:447,y:747,t:1527272054449};\\\", \\\"{x:451,y:747,t:1527272054466};\\\", \\\"{x:454,y:747,t:1527272054482};\\\", \\\"{x:455,y:747,t:1527272054505};\\\", \\\"{x:457,y:747,t:1527272054516};\\\", \\\"{x:459,y:747,t:1527272054532};\\\", \\\"{x:468,y:747,t:1527272055090};\\\", \\\"{x:495,y:747,t:1527272055100};\\\", \\\"{x:609,y:761,t:1527272055116};\\\", \\\"{x:729,y:767,t:1527272055132};\\\", \\\"{x:839,y:767,t:1527272055149};\\\", \\\"{x:937,y:771,t:1527272055167};\\\", \\\"{x:1035,y:775,t:1527272055182};\\\", \\\"{x:1142,y:781,t:1527272055199};\\\", \\\"{x:1235,y:786,t:1527272055216};\\\", \\\"{x:1321,y:786,t:1527272055234};\\\", \\\"{x:1379,y:786,t:1527272055249};\\\", \\\"{x:1391,y:786,t:1527272055266};\\\", \\\"{x:1388,y:782,t:1527272055674};\\\", \\\"{x:1379,y:773,t:1527272055683};\\\", \\\"{x:1366,y:757,t:1527272055701};\\\", \\\"{x:1346,y:735,t:1527272055716};\\\", \\\"{x:1257,y:654,t:1527272055788};\\\", \\\"{x:1251,y:650,t:1527272055800};\\\", \\\"{x:1240,y:644,t:1527272055815};\\\", \\\"{x:1236,y:643,t:1527272055833};\\\", \\\"{x:1230,y:643,t:1527272055849};\\\", \\\"{x:1226,y:641,t:1527272055866};\\\" ] }, { \\\"rt\\\": 45866, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 521721, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look at which events are on the y axis corresponds to the 12pm x axis value.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6336, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 529064, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 13452, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 543534, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 1640, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 546513, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"4P01U\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"4P01U\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 168, dom: 735, initialDom: 803",
  "javascriptErrors": []
}