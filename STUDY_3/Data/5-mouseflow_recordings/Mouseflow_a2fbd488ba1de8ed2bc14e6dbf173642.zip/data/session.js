var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a2fbd488ba1de8ed2bc14e6dbf173642",
  "created": "2018-05-29T16:06:49.2373594-07:00",
  "lastActivity": "2018-05-29T16:08:10.8070449-07:00",
  "pageViews": [
    {
      "id": "0529492590930538194ef1ec3cdca6545a65cc85",
      "startTime": "2018-05-29T16:06:49.3350449-07:00",
      "endTime": "2018-05-29T16:08:10.8070449-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 81472,
      "engagementTime": 70184,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 81472,
  "engagementTime": 70184,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.48",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=SQ6AK",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7b2dab28e9f04d7ee22839af140bb1e6",
  "gdpr": false
}