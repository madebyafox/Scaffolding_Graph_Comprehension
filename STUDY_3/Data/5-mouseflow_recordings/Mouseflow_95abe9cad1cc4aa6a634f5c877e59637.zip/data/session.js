var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "95abe9cad1cc4aa6a634f5c877e59637",
  "created": "2018-05-14T13:08:00.0448408-07:00",
  "lastActivity": "2018-05-14T13:08:35.1423784-07:00",
  "pageViews": [
    {
      "id": "051400813058e323159cab8658444995b0050be0",
      "startTime": "2018-05-14T13:08:00.0823404-07:00",
      "endTime": "2018-05-14T13:08:35.1423784-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 35134,
      "engagementTime": 35134,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 35134,
  "engagementTime": 35134,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=9393C",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c6529d3954c1d986866b86ce9dfeaa14",
  "gdpr": false
}