var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05154702debca0dd65536b01523bf47068b4da2b"] = {
  "startTime": "2018-05-15T21:01:47.8994573Z",
  "websitePageUrl": "/",
  "visitTime": 142496,
  "engagementTime": 62012,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "722999cb067b839fc5ca273ac4b52ea6",
    "created": "2018-05-15T21:01:47.8994573+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "33a5278c4a2f687f03aaacb54745eb87",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/722999cb067b839fc5ca273ac4b52ea6/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 399,
      "e": 399,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 7302,
      "e": 5101,
      "ty": 2,
      "x": 611,
      "y": 53
    },
    {
      "t": 7335,
      "e": 5134,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 7401,
      "e": 5200,
      "ty": 2,
      "x": 898,
      "y": 107
    },
    {
      "t": 7503,
      "e": 5302,
      "ty": 41,
      "x": 63954,
      "y": 6298,
      "ta": "html > body"
    },
    {
      "t": 8401,
      "e": 6200,
      "ty": 2,
      "x": 871,
      "y": 988
    },
    {
      "t": 8501,
      "e": 6300,
      "ty": 2,
      "x": 860,
      "y": 997
    },
    {
      "t": 8502,
      "e": 6301,
      "ty": 41,
      "x": 61223,
      "y": 62926,
      "ta": "html > body"
    },
    {
      "t": 8551,
      "e": 6350,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 8601,
      "e": 6400,
      "ty": 2,
      "x": 882,
      "y": 1043
    },
    {
      "t": 9101,
      "e": 6900,
      "ty": 2,
      "x": 918,
      "y": 1046
    },
    {
      "t": 9103,
      "e": 6902,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 9401,
      "e": 7200,
      "ty": 2,
      "x": 913,
      "y": 1045
    },
    {
      "t": 9501,
      "e": 7300,
      "ty": 2,
      "x": 918,
      "y": 1044
    },
    {
      "t": 9601,
      "e": 7400,
      "ty": 2,
      "x": 919,
      "y": 1044
    },
    {
      "t": 9701,
      "e": 7500,
      "ty": 2,
      "x": 926,
      "y": 1042
    },
    {
      "t": 9896,
      "e": 7695,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 9901,
      "e": 7700,
      "ty": 2,
      "x": 927,
      "y": 1042
    },
    {
      "t": 10002,
      "e": 7801,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10302,
      "e": 8101,
      "ty": 0,
      "x": 935,
      "y": 1047
    },
    {
      "t": 10401,
      "e": 8200,
      "ty": 0,
      "x": 1073,
      "y": 1047
    },
    {
      "t": 10501,
      "e": 8300,
      "ty": 0,
      "x": 1269,
      "y": 1047
    },
    {
      "t": 10601,
      "e": 8400,
      "ty": 0,
      "x": 1440,
      "y": 1047
    },
    {
      "t": 16040,
      "e": 13400,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 16102,
      "e": 13462,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 16102,
      "e": 13462,
      "ty": 2,
      "x": 1458,
      "y": 1145
    },
    {
      "t": 16252,
      "e": 13612,
      "ty": 41,
      "x": 49934,
      "y": 62986,
      "ta": "html > body"
    },
    {
      "t": 20001,
      "e": 17361,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80405,
      "e": 18612,
      "ty": 2,
      "x": 1414,
      "y": 1127
    },
    {
      "t": 80505,
      "e": 18712,
      "ty": 2,
      "x": 1358,
      "y": 1114
    },
    {
      "t": 80506,
      "e": 18713,
      "ty": 41,
      "x": 46490,
      "y": 61269,
      "ta": "> div.masterdiv"
    },
    {
      "t": 80605,
      "e": 18812,
      "ty": 2,
      "x": 1358,
      "y": 1121
    },
    {
      "t": 80755,
      "e": 18962,
      "ty": 41,
      "x": 46490,
      "y": 61657,
      "ta": "> div.masterdiv"
    },
    {
      "t": 81305,
      "e": 19512,
      "ty": 2,
      "x": 1346,
      "y": 1120
    },
    {
      "t": 81405,
      "e": 19612,
      "ty": 2,
      "x": 1309,
      "y": 1097
    },
    {
      "t": 81505,
      "e": 19712,
      "ty": 2,
      "x": 1166,
      "y": 1039
    },
    {
      "t": 81505,
      "e": 19712,
      "ty": 41,
      "x": 42926,
      "y": 63202,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 81605,
      "e": 19812,
      "ty": 2,
      "x": 963,
      "y": 981
    },
    {
      "t": 81705,
      "e": 19912,
      "ty": 2,
      "x": 871,
      "y": 955
    },
    {
      "t": 81755,
      "e": 19962,
      "ty": 41,
      "x": 27528,
      "y": 56762,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 81805,
      "e": 20012,
      "ty": 2,
      "x": 847,
      "y": 943
    },
    {
      "t": 81904,
      "e": 20111,
      "ty": 2,
      "x": 828,
      "y": 924
    },
    {
      "t": 82004,
      "e": 20211,
      "ty": 2,
      "x": 817,
      "y": 910
    },
    {
      "t": 82005,
      "e": 20212,
      "ty": 41,
      "x": 2847,
      "y": 6004,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 82205,
      "e": 20412,
      "ty": 2,
      "x": 814,
      "y": 921
    },
    {
      "t": 82255,
      "e": 20462,
      "ty": 41,
      "x": 34610,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 83289,
      "e": 21496,
      "ty": 3,
      "x": 814,
      "y": 921,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 83457,
      "e": 21664,
      "ty": 4,
      "x": 34610,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 83458,
      "e": 21665,
      "ty": 5,
      "x": 814,
      "y": 921,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 83460,
      "e": 21667,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 83465,
      "e": 21672,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 83755,
      "e": 21962,
      "ty": 41,
      "x": 34610,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 83805,
      "e": 22012,
      "ty": 2,
      "x": 816,
      "y": 931
    },
    {
      "t": 83905,
      "e": 22112,
      "ty": 2,
      "x": 862,
      "y": 1015
    },
    {
      "t": 84004,
      "e": 22211,
      "ty": 2,
      "x": 939,
      "y": 1126
    },
    {
      "t": 84005,
      "e": 22212,
      "ty": 41,
      "x": 23171,
      "y": 29534,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 84105,
      "e": 22312,
      "ty": 2,
      "x": 967,
      "y": 1158
    },
    {
      "t": 84205,
      "e": 22412,
      "ty": 2,
      "x": 972,
      "y": 1146
    },
    {
      "t": 84255,
      "e": 22462,
      "ty": 41,
      "x": 38618,
      "y": 25102,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 84305,
      "e": 22512,
      "ty": 2,
      "x": 965,
      "y": 1097
    },
    {
      "t": 84405,
      "e": 22612,
      "ty": 2,
      "x": 957,
      "y": 1081
    },
    {
      "t": 84505,
      "e": 22712,
      "ty": 41,
      "x": 25940,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 84605,
      "e": 22812,
      "ty": 2,
      "x": 957,
      "y": 1084
    },
    {
      "t": 84755,
      "e": 22962,
      "ty": 41,
      "x": 25940,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 84811,
      "e": 23018,
      "ty": 3,
      "x": 957,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 84812,
      "e": 23019,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 84812,
      "e": 23019,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 84921,
      "e": 23128,
      "ty": 4,
      "x": 25940,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 84922,
      "e": 23129,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 84924,
      "e": 23131,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 84924,
      "e": 23131,
      "ty": 5,
      "x": 957,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 85930,
      "e": 24137,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 87004,
      "e": 25211,
      "ty": 2,
      "x": 965,
      "y": 1071
    },
    {
      "t": 87005,
      "e": 25212,
      "ty": 41,
      "x": 32956,
      "y": 58887,
      "ta": "html > body"
    },
    {
      "t": 87105,
      "e": 25312,
      "ty": 2,
      "x": 981,
      "y": 800
    },
    {
      "t": 87112,
      "e": 25319,
      "ty": 6,
      "x": 973,
      "y": 731,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 87129,
      "e": 25336,
      "ty": 7,
      "x": 955,
      "y": 621,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 87204,
      "e": 25411,
      "ty": 2,
      "x": 904,
      "y": 445
    },
    {
      "t": 87255,
      "e": 25462,
      "ty": 41,
      "x": 30580,
      "y": 23543,
      "ta": "html > body"
    },
    {
      "t": 87304,
      "e": 25511,
      "ty": 2,
      "x": 896,
      "y": 433
    },
    {
      "t": 88254,
      "e": 26461,
      "ty": 41,
      "x": 30546,
      "y": 23543,
      "ta": "html > body"
    },
    {
      "t": 88305,
      "e": 26512,
      "ty": 2,
      "x": 892,
      "y": 441
    },
    {
      "t": 88405,
      "e": 26612,
      "ty": 2,
      "x": 892,
      "y": 474
    },
    {
      "t": 88504,
      "e": 26711,
      "ty": 2,
      "x": 893,
      "y": 525
    },
    {
      "t": 88504,
      "e": 26711,
      "ty": 41,
      "x": 18384,
      "y": 2114,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 88604,
      "e": 26811,
      "ty": 2,
      "x": 903,
      "y": 564
    },
    {
      "t": 88704,
      "e": 26911,
      "ty": 2,
      "x": 907,
      "y": 574
    },
    {
      "t": 88754,
      "e": 26961,
      "ty": 41,
      "x": 21412,
      "y": 38757,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 88804,
      "e": 27011,
      "ty": 2,
      "x": 908,
      "y": 581
    },
    {
      "t": 88882,
      "e": 27089,
      "ty": 6,
      "x": 908,
      "y": 587,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88904,
      "e": 27111,
      "ty": 2,
      "x": 908,
      "y": 588
    },
    {
      "t": 89004,
      "e": 27211,
      "ty": 2,
      "x": 908,
      "y": 591
    },
    {
      "t": 89004,
      "e": 27211,
      "ty": 41,
      "x": 21628,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89104,
      "e": 27311,
      "ty": 2,
      "x": 908,
      "y": 593
    },
    {
      "t": 89204,
      "e": 27411,
      "ty": 2,
      "x": 908,
      "y": 596
    },
    {
      "t": 89254,
      "e": 27461,
      "ty": 41,
      "x": 21628,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89305,
      "e": 27512,
      "ty": 2,
      "x": 908,
      "y": 600
    },
    {
      "t": 89404,
      "e": 27611,
      "ty": 2,
      "x": 908,
      "y": 606
    },
    {
      "t": 89504,
      "e": 27711,
      "ty": 41,
      "x": 21628,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90005,
      "e": 28212,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90504,
      "e": 28711,
      "ty": 2,
      "x": 907,
      "y": 600
    },
    {
      "t": 90504,
      "e": 28711,
      "ty": 41,
      "x": 21412,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93666,
      "e": 31873,
      "ty": 3,
      "x": 907,
      "y": 600,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93666,
      "e": 31873,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93825,
      "e": 32032,
      "ty": 4,
      "x": 21412,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93826,
      "e": 32033,
      "ty": 5,
      "x": 907,
      "y": 600,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98630,
      "e": 36837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "70"
    },
    {
      "t": 98631,
      "e": 36838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98749,
      "e": 36956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "f"
    },
    {
      "t": 98805,
      "e": 37012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 98805,
      "e": 37012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98926,
      "e": 37133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "fi"
    },
    {
      "t": 98957,
      "e": 37164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 98958,
      "e": 37165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99100,
      "e": 37307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "fir"
    },
    {
      "t": 99109,
      "e": 37316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 99109,
      "e": 37316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99210,
      "e": 37417,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "fire"
    },
    {
      "t": 99262,
      "e": 37469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "fire"
    },
    {
      "t": 100005,
      "e": 38212,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100304,
      "e": 38511,
      "ty": 2,
      "x": 905,
      "y": 602
    },
    {
      "t": 100307,
      "e": 38514,
      "ty": 7,
      "x": 903,
      "y": 611,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 100404,
      "e": 38611,
      "ty": 2,
      "x": 901,
      "y": 648
    },
    {
      "t": 100458,
      "e": 38665,
      "ty": 6,
      "x": 899,
      "y": 691,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100473,
      "e": 38680,
      "ty": 7,
      "x": 896,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100504,
      "e": 38711,
      "ty": 2,
      "x": 895,
      "y": 703
    },
    {
      "t": 100505,
      "e": 38712,
      "ty": 41,
      "x": 18816,
      "y": 62011,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 100605,
      "e": 38812,
      "ty": 2,
      "x": 888,
      "y": 715
    },
    {
      "t": 100705,
      "e": 38912,
      "ty": 2,
      "x": 886,
      "y": 717
    },
    {
      "t": 100740,
      "e": 38947,
      "ty": 6,
      "x": 882,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100755,
      "e": 38962,
      "ty": 41,
      "x": 16005,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100804,
      "e": 39011,
      "ty": 2,
      "x": 877,
      "y": 689
    },
    {
      "t": 101005,
      "e": 39212,
      "ty": 41,
      "x": 14923,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 101104,
      "e": 39311,
      "ty": 2,
      "x": 877,
      "y": 688
    },
    {
      "t": 101255,
      "e": 39462,
      "ty": 41,
      "x": 14923,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102242,
      "e": 40449,
      "ty": 3,
      "x": 877,
      "y": 688,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102243,
      "e": 40450,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "fire"
    },
    {
      "t": 102243,
      "e": 40450,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102244,
      "e": 40451,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102401,
      "e": 40608,
      "ty": 4,
      "x": 14923,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102401,
      "e": 40608,
      "ty": 5,
      "x": 877,
      "y": 688,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104134,
      "e": 42341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 104134,
      "e": 42341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104268,
      "e": 42475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 104406,
      "e": 42613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 104406,
      "e": 42613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104501,
      "e": 42708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 104725,
      "e": 42932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 104726,
      "e": 42933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104813,
      "e": 43020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 105405,
      "e": 43612,
      "ty": 2,
      "x": 888,
      "y": 687
    },
    {
      "t": 105445,
      "e": 43652,
      "ty": 7,
      "x": 895,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105477,
      "e": 43684,
      "ty": 6,
      "x": 901,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105505,
      "e": 43712,
      "ty": 2,
      "x": 902,
      "y": 710
    },
    {
      "t": 105505,
      "e": 43712,
      "ty": 41,
      "x": 3132,
      "y": 3971,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105605,
      "e": 43812,
      "ty": 2,
      "x": 906,
      "y": 717
    },
    {
      "t": 105705,
      "e": 43912,
      "ty": 2,
      "x": 906,
      "y": 725
    },
    {
      "t": 105756,
      "e": 43963,
      "ty": 41,
      "x": 5194,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 107009,
      "e": 45216,
      "ty": 3,
      "x": 906,
      "y": 725,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 107010,
      "e": 45217,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 107010,
      "e": 45217,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 107010,
      "e": 45217,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 107146,
      "e": 45353,
      "ty": 4,
      "x": 5194,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 107149,
      "e": 45356,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 107151,
      "e": 45358,
      "ty": 5,
      "x": 906,
      "y": 725,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 107152,
      "e": 45359,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 108239,
      "e": 46446,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 108270,
      "e": 46477,
      "ty": 6,
      "x": 906,
      "y": 725,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 108747,
      "e": 46954,
      "ty": 7,
      "x": 902,
      "y": 731,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 108747,
      "e": 46954,
      "ty": 6,
      "x": 902,
      "y": 731,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 108755,
      "e": 46962,
      "ty": 41,
      "x": 28877,
      "y": 9398,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 108779,
      "e": 46986,
      "ty": 7,
      "x": 882,
      "y": 755,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 108779,
      "e": 46986,
      "ty": 6,
      "x": 882,
      "y": 755,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 108805,
      "e": 47012,
      "ty": 2,
      "x": 868,
      "y": 766
    },
    {
      "t": 108830,
      "e": 47037,
      "ty": 7,
      "x": 839,
      "y": 791,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 108905,
      "e": 47112,
      "ty": 2,
      "x": 721,
      "y": 916
    },
    {
      "t": 109005,
      "e": 47212,
      "ty": 2,
      "x": 541,
      "y": 1080
    },
    {
      "t": 109005,
      "e": 47212,
      "ty": 41,
      "x": 18355,
      "y": 59385,
      "ta": "> div.masterdiv"
    },
    {
      "t": 109105,
      "e": 47312,
      "ty": 2,
      "x": 464,
      "y": 1121
    },
    {
      "t": 109205,
      "e": 47412,
      "ty": 2,
      "x": 462,
      "y": 1085
    },
    {
      "t": 109255,
      "e": 47462,
      "ty": 41,
      "x": 8242,
      "y": 64102,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 109305,
      "e": 47512,
      "ty": 2,
      "x": 461,
      "y": 1043
    },
    {
      "t": 109405,
      "e": 47612,
      "ty": 2,
      "x": 461,
      "y": 1034
    },
    {
      "t": 109505,
      "e": 47712,
      "ty": 41,
      "x": 8242,
      "y": 62855,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 110005,
      "e": 48212,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 123508,
      "e": 52712,
      "ty": 2,
      "x": 481,
      "y": 1022
    },
    {
      "t": 123509,
      "e": 52713,
      "ty": 41,
      "x": 9226,
      "y": 62025,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 123608,
      "e": 52812,
      "ty": 2,
      "x": 648,
      "y": 1008
    },
    {
      "t": 123708,
      "e": 52912,
      "ty": 2,
      "x": 807,
      "y": 996
    },
    {
      "t": 123758,
      "e": 52962,
      "ty": 41,
      "x": 25264,
      "y": 60224,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 124608,
      "e": 53812,
      "ty": 2,
      "x": 807,
      "y": 995
    },
    {
      "t": 124709,
      "e": 53913,
      "ty": 2,
      "x": 807,
      "y": 994
    },
    {
      "t": 124758,
      "e": 53962,
      "ty": 41,
      "x": 25264,
      "y": 60086,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 124808,
      "e": 54012,
      "ty": 2,
      "x": 807,
      "y": 993
    },
    {
      "t": 124908,
      "e": 54112,
      "ty": 2,
      "x": 816,
      "y": 993
    },
    {
      "t": 125008,
      "e": 54212,
      "ty": 2,
      "x": 825,
      "y": 1000
    },
    {
      "t": 125008,
      "e": 54212,
      "ty": 41,
      "x": 26150,
      "y": 60501,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 125108,
      "e": 54312,
      "ty": 2,
      "x": 851,
      "y": 1035
    },
    {
      "t": 125178,
      "e": 54382,
      "ty": 6,
      "x": 925,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 125208,
      "e": 54412,
      "ty": 2,
      "x": 943,
      "y": 1083
    },
    {
      "t": 125258,
      "e": 54462,
      "ty": 41,
      "x": 51608,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 125308,
      "e": 54512,
      "ty": 2,
      "x": 1009,
      "y": 1098
    },
    {
      "t": 125508,
      "e": 54712,
      "ty": 41,
      "x": 54339,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 125606,
      "e": 54810,
      "ty": 3,
      "x": 1009,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 125607,
      "e": 54811,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 125692,
      "e": 54896,
      "ty": 4,
      "x": 54339,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 125695,
      "e": 54899,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 125696,
      "e": 54900,
      "ty": 5,
      "x": 1009,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 125700,
      "e": 54904,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 126700,
      "e": 55904,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 127408,
      "e": 56612,
      "ty": 2,
      "x": 1010,
      "y": 1098
    },
    {
      "t": 127509,
      "e": 56713,
      "ty": 2,
      "x": 1130,
      "y": 1069
    },
    {
      "t": 127509,
      "e": 56713,
      "ty": 41,
      "x": 38639,
      "y": 58776,
      "ta": "html > body"
    },
    {
      "t": 127608,
      "e": 56812,
      "ty": 2,
      "x": 1225,
      "y": 1032
    },
    {
      "t": 127708,
      "e": 56912,
      "ty": 2,
      "x": 1254,
      "y": 1017
    },
    {
      "t": 127757,
      "e": 56961,
      "ty": 41,
      "x": 42943,
      "y": 55895,
      "ta": "html > body"
    },
    {
      "t": 127808,
      "e": 57012,
      "ty": 2,
      "x": 1255,
      "y": 1017
    },
    {
      "t": 130008,
      "e": 59212,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 141492,
      "e": 62012,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 142496,
      "e": 62012,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 210, dom: 1670, initialDom: 1674",
  "javascriptErrors": []
}