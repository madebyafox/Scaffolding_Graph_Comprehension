var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1abe4fd49716107560514972ccc6eb75",
  "created": "2018-05-18T11:14:14.0310605-07:00",
  "lastActivity": "2018-05-18T11:14:32.1616499-07:00",
  "pageViews": [
    {
      "id": "051814026c44728a62cd219731bb6206a04460a9",
      "startTime": "2018-05-18T11:14:14.0310605-07:00",
      "endTime": "2018-05-18T11:14:32.1616499-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 18644,
      "engagementTime": 18627,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 18644,
  "engagementTime": 18627,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G6NOP",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e653aba556fe0ad458b1b3a7dda3c619",
  "gdpr": false
}