var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b6123baf11021e53ea927c97094a2c49",
  "created": "2018-05-29T16:08:21.4075945-07:00",
  "lastActivity": "2018-05-29T16:09:08.8990715-07:00",
  "pageViews": [
    {
      "id": "0529215208f7eb8ccc7e08676a5976513e7e38e5",
      "startTime": "2018-05-29T16:08:21.4075945-07:00",
      "endTime": "2018-05-29T16:09:08.8990715-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 47540,
      "engagementTime": 47087,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 47540,
  "engagementTime": 47087,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=X2QZK",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d8f10ea00774c1c77c8625f593efae5a",
  "gdpr": false
}