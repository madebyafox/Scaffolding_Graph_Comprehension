var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b75fdd85a94f135dcc7f9c15289e0d14",
  "created": "2018-05-22T14:21:11.1729783-07:00",
  "lastActivity": "2018-05-22T14:21:55.2204848-07:00",
  "pageViews": [
    {
      "id": "052211616434596e1c2c6ccc258b4f7386471e49",
      "startTime": "2018-05-22T14:21:11.2044848-07:00",
      "endTime": "2018-05-22T14:21:55.2204848-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 44016,
      "engagementTime": 43615,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 44016,
  "engagementTime": 43615,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G443Q",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2ee9eb668f01d9dbae64a2ddb3397d08",
  "gdpr": false
}