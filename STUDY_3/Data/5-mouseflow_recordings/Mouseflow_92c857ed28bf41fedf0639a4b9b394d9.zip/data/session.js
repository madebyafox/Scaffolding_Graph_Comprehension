var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "92c857ed28bf41fedf0639a4b9b394d9",
  "created": "2018-06-01T11:11:06.4413955-07:00",
  "lastActivity": "2018-06-01T11:12:48.2543955-07:00",
  "pageViews": [
    {
      "id": "060106151eef47f9dafb925649ed58aa4fd6caae",
      "startTime": "2018-06-01T11:11:06.4413955-07:00",
      "endTime": "2018-06-01T11:12:48.2543955-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 101813,
      "engagementTime": 82268,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 101813,
  "engagementTime": 82268,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=5KWEX",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "33cccc98f8f322e786ae237bfd2747c9",
  "gdpr": false
}