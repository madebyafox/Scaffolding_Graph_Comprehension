var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3804f469d582d765cfe84d46f0f251bb",
  "created": "2018-05-25T11:17:18.1691646-07:00",
  "lastActivity": "2018-05-25T11:17:40.4151388-07:00",
  "pageViews": [
    {
      "id": "052518950a54b2aeb9b4d1ecfee44e592ba8422c",
      "startTime": "2018-05-25T11:17:18.3169471-07:00",
      "endTime": "2018-05-25T11:17:40.4151388-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 22224,
      "engagementTime": 17109,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 22224,
  "engagementTime": 17109,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=2WQ0M",
    "CONDITION=114",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "bc2bc85dc976eb22ec9373128896c82d",
  "gdpr": false
}