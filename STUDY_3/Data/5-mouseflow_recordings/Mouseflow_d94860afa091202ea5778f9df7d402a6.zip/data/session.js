var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d94860afa091202ea5778f9df7d402a6",
  "created": "2018-05-22T14:07:26.1311012-07:00",
  "lastActivity": "2018-05-22T14:08:33.4701306-07:00",
  "pageViews": [
    {
      "id": "052226047e3d54edb0d428c11b0ae38d9f14ad9e",
      "startTime": "2018-05-22T14:07:26.2607495-07:00",
      "endTime": "2018-05-22T14:08:33.4701306-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 67550,
      "engagementTime": 47901,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 67550,
  "engagementTime": 47901,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=T5SHZ",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "376351a18fd10e0512e43686c55827a4",
  "gdpr": false
}