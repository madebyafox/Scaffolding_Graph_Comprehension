var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "bf707d65f214f153ccfcc5e7dc0408f5",
  "created": "2018-05-25T10:11:38.1957591-07:00",
  "lastActivity": "2018-05-25T10:12:11.8277591-07:00",
  "pageViews": [
    {
      "id": "052538998b1fa30888e38f86e12893915a3e8c8d",
      "startTime": "2018-05-25T10:11:38.1957591-07:00",
      "endTime": "2018-05-25T10:12:11.8277591-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 33632,
      "engagementTime": 33632,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 33632,
  "engagementTime": 33632,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=AKYQ8",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f8ca323cc82d0570b41654caf859fde5",
  "gdpr": false
}