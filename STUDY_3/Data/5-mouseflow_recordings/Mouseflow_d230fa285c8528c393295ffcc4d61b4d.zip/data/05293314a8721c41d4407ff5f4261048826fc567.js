var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05293314a8721c41d4407ff5f4261048826fc567"] = {
  "startTime": "2018-05-29T21:11:32.5619765Z",
  "websitePageUrl": "/16",
  "visitTime": 57403,
  "engagementTime": 57356,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "d230fa285c8528c393295ffcc4d61b4d",
    "created": "2018-05-29T21:11:32.5619765+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=F92ER",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "8c89a36faa7a9c3894440f8c892b459e",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d230fa285c8528c393295ffcc4d61b4d/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 209,
      "e": 209,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 209,
      "e": 209,
      "ty": 2,
      "x": 547,
      "y": 665
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 50573,
      "y": 36396,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 545,
      "y": 652
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 50236,
      "y": 35288,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 543,
      "y": 643
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 542,
      "y": 638
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 542,
      "y": 634
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 41,
      "x": 50011,
      "y": 34678,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 542,
      "y": 632
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 541,
      "y": 627
    },
    {
      "t": 5750,
      "e": 5750,
      "ty": 41,
      "x": 49787,
      "y": 34124,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5800,
      "e": 5800,
      "ty": 2,
      "x": 540,
      "y": 621
    },
    {
      "t": 5900,
      "e": 5900,
      "ty": 2,
      "x": 539,
      "y": 614
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 538,
      "y": 606
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 41,
      "x": 49562,
      "y": 62323,
      "ta": "#.strategy"
    },
    {
      "t": 6039,
      "e": 6039,
      "ty": 6,
      "x": 538,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6100,
      "e": 6100,
      "ty": 2,
      "x": 537,
      "y": 599
    },
    {
      "t": 6200,
      "e": 6200,
      "ty": 2,
      "x": 537,
      "y": 594
    },
    {
      "t": 6250,
      "e": 6250,
      "ty": 41,
      "x": 49449,
      "y": 56850,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 2,
      "x": 537,
      "y": 593
    },
    {
      "t": 6400,
      "e": 6400,
      "ty": 2,
      "x": 537,
      "y": 592
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 49449,
      "y": 56041,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 537,
      "y": 591
    },
    {
      "t": 6750,
      "e": 6750,
      "ty": 41,
      "x": 49337,
      "y": 55231,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 536,
      "y": 591
    },
    {
      "t": 7308,
      "e": 7308,
      "ty": 3,
      "x": 536,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7309,
      "e": 7309,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7507,
      "e": 7507,
      "ty": 4,
      "x": 49337,
      "y": 55231,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7508,
      "e": 7508,
      "ty": 5,
      "x": 536,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7750,
      "e": 7750,
      "ty": 41,
      "x": 49449,
      "y": 52804,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7800,
      "e": 7800,
      "ty": 2,
      "x": 567,
      "y": 561
    },
    {
      "t": 7857,
      "e": 7857,
      "ty": 7,
      "x": 641,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7900,
      "e": 7900,
      "ty": 2,
      "x": 674,
      "y": 506
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 2,
      "x": 692,
      "y": 499
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 41,
      "x": 683,
      "y": 25631,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 8100,
      "e": 8100,
      "ty": 2,
      "x": 584,
      "y": 423
    },
    {
      "t": 8200,
      "e": 8200,
      "ty": 2,
      "x": 34,
      "y": 79
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 895,
      "y": 3933,
      "ta": "> div.stimulus"
    },
    {
      "t": 9145,
      "e": 9145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9644,
      "e": 9644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9677,
      "e": 9677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9710,
      "e": 9710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9743,
      "e": 9743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9776,
      "e": 9776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9808,
      "e": 9808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9815,
      "e": 9815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 9815,
      "e": 9815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9927,
      "e": 9927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 9966,
      "e": 9966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10062,
      "e": 10062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10063,
      "e": 10063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10150,
      "e": 10150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B "
    },
    {
      "t": 10182,
      "e": 10182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10182,
      "e": 10182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10271,
      "e": 10271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B a"
    },
    {
      "t": 10302,
      "e": 10302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 10302,
      "e": 10302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10375,
      "e": 10375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B an"
    },
    {
      "t": 10439,
      "e": 10439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 10440,
      "e": 10440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10478,
      "e": 10478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 10602,
      "e": 10602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B anf"
    },
    {
      "t": 10646,
      "e": 10646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10647,
      "e": 10647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10751,
      "e": 10751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10870,
      "e": 10870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10992,
      "e": 10992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11176,
      "e": 11176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11246,
      "e": 11246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B anf"
    },
    {
      "t": 11343,
      "e": 11343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11383,
      "e": 11383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B an"
    },
    {
      "t": 11800,
      "e": 11800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11911,
      "e": 11911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B a"
    },
    {
      "t": 12408,
      "e": 12408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 12408,
      "e": 12408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12511,
      "e": 12511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 12511,
      "e": 12511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12518,
      "e": 12518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and"
    },
    {
      "t": 12607,
      "e": 12607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12671,
      "e": 12671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12672,
      "e": 12672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12767,
      "e": 12767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12783,
      "e": 12783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12975,
      "e": 12975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 12976,
      "e": 12976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13087,
      "e": 13087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 13111,
      "e": 13111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13272,
      "e": 13272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13272,
      "e": 13272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13336,
      "e": 13336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13336,
      "e": 13336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13382,
      "e": 13382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| s"
    },
    {
      "t": 13431,
      "e": 13431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13592,
      "e": 13592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13592,
      "e": 13592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13711,
      "e": 13711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13895,
      "e": 13895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13896,
      "e": 13896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13990,
      "e": 13990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 15135,
      "e": 15135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15634,
      "e": 15634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15667,
      "e": 15667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15699,
      "e": 15699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15733,
      "e": 15733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15766,
      "e": 15766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15799,
      "e": 15799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15832,
      "e": 15832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15865,
      "e": 15865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15897,
      "e": 15897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15931,
      "e": 15931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15964,
      "e": 15964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15998,
      "e": 15998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16030,
      "e": 16030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16064,
      "e": 16064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16097,
      "e": 16097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16130,
      "e": 16130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16163,
      "e": 16163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16196,
      "e": 16196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16229,
      "e": 16229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16262,
      "e": 16262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16295,
      "e": 16295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16327,
      "e": 16327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16360,
      "e": 16360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16394,
      "e": 16394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16426,
      "e": 16426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16459,
      "e": 16459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16487,
      "e": 16487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 16526,
      "e": 16526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16711,
      "e": 16711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 16712,
      "e": 16712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16815,
      "e": 16815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 16822,
      "e": 16822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 16943,
      "e": 16943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 16944,
      "e": 16944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17015,
      "e": 17015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Sj"
    },
    {
      "t": 17343,
      "e": 17343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17455,
      "e": 17455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 17638,
      "e": 17638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17638,
      "e": 17638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17751,
      "e": 17751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Sh"
    },
    {
      "t": 17943,
      "e": 17943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17944,
      "e": 17944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17951,
      "e": 17951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17952,
      "e": 17952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17982,
      "e": 17982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shio"
    },
    {
      "t": 18006,
      "e": 18006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18479,
      "e": 18479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18558,
      "e": 18558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shi"
    },
    {
      "t": 19127,
      "e": 19127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 19129,
      "e": 19129,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19215,
      "e": 19215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shif"
    },
    {
      "t": 19344,
      "e": 19344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19344,
      "e": 19344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19423,
      "e": 19423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19552,
      "e": 19552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19552,
      "e": 19552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19663,
      "e": 19663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 19711,
      "e": 19711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19712,
      "e": 19712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19815,
      "e": 19815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20222,
      "e": 20222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20343,
      "e": 20343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 20343,
      "e": 20343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20415,
      "e": 20415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 20431,
      "e": 20431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20863,
      "e": 20863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20864,
      "e": 20864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20934,
      "e": 20934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20934,
      "e": 20934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20934,
      "e": 20934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21015,
      "e": 21015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 21087,
      "e": 21087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21088,
      "e": 21088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21158,
      "e": 21158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21167,
      "e": 21167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 21167,
      "e": 21167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21271,
      "e": 21271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 21368,
      "e": 21368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21368,
      "e": 21368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21431,
      "e": 21431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 21456,
      "e": 21456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21639,
      "e": 21639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 21640,
      "e": 21640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21727,
      "e": 21727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 21752,
      "e": 21752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21863,
      "e": 21863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21864,
      "e": 21864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21928,
      "e": 21928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21928,
      "e": 21928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21959,
      "e": 21959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| s"
    },
    {
      "t": 22039,
      "e": 22039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22175,
      "e": 22175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22176,
      "e": 22176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22271,
      "e": 22271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22272,
      "e": 22272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22273,
      "e": 22273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22391,
      "e": 22391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 22398,
      "e": 22398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22398,
      "e": 22398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22463,
      "e": 22463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 22591,
      "e": 22591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22592,
      "e": 22592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22639,
      "e": 22639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22799,
      "e": 22799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22800,
      "e": 22800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22847,
      "e": 22847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22847,
      "e": 22847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22887,
      "e": 22887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 22926,
      "e": 22926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23031,
      "e": 23031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23031,
      "e": 23031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23102,
      "e": 23102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23203,
      "e": 23203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts B and F start at"
    },
    {
      "t": 23255,
      "e": 23255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23256,
      "e": 23256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23334,
      "e": 23334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23335,
      "e": 23335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 23335,
      "e": 23335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23398,
      "e": 23398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 23671,
      "e": 23671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 23672,
      "e": 23672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23759,
      "e": 23759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 24088,
      "e": 24088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 24088,
      "e": 24088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24191,
      "e": 24191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 24368,
      "e": 24368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 24368,
      "e": 24368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24431,
      "e": 24431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 25101,
      "e": 25101,
      "ty": 2,
      "x": 0,
      "y": 0
    },
    {
      "t": 25251,
      "e": 25251,
      "ty": 41,
      "x": 0,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 25301,
      "e": 25301,
      "ty": 2,
      "x": 0,
      "y": 12
    },
    {
      "t": 25400,
      "e": 25400,
      "ty": 2,
      "x": 0,
      "y": 144
    },
    {
      "t": 25500,
      "e": 25500,
      "ty": 2,
      "x": 0,
      "y": 155
    },
    {
      "t": 25500,
      "e": 25500,
      "ty": 41,
      "x": 0,
      "y": 8586,
      "ta": "html"
    },
    {
      "t": 25600,
      "e": 25600,
      "ty": 2,
      "x": 0,
      "y": 220
    },
    {
      "t": 25700,
      "e": 25700,
      "ty": 2,
      "x": 71,
      "y": 308
    },
    {
      "t": 25750,
      "e": 25750,
      "ty": 41,
      "x": 3136,
      "y": 18170,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 25800,
      "e": 25800,
      "ty": 2,
      "x": 178,
      "y": 352
    },
    {
      "t": 25900,
      "e": 25900,
      "ty": 2,
      "x": 229,
      "y": 395
    },
    {
      "t": 26000,
      "e": 26000,
      "ty": 2,
      "x": 256,
      "y": 456
    },
    {
      "t": 26000,
      "e": 26000,
      "ty": 41,
      "x": 17862,
      "y": 24817,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 26072,
      "e": 26072,
      "ty": 6,
      "x": 287,
      "y": 548,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26100,
      "e": 26100,
      "ty": 2,
      "x": 289,
      "y": 552
    },
    {
      "t": 26200,
      "e": 26200,
      "ty": 2,
      "x": 300,
      "y": 576
    },
    {
      "t": 26251,
      "e": 26251,
      "ty": 41,
      "x": 23258,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26300,
      "e": 26300,
      "ty": 2,
      "x": 306,
      "y": 584
    },
    {
      "t": 26400,
      "e": 26400,
      "ty": 2,
      "x": 345,
      "y": 592
    },
    {
      "t": 26422,
      "e": 26422,
      "ty": 7,
      "x": 365,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26500,
      "e": 26500,
      "ty": 2,
      "x": 398,
      "y": 642
    },
    {
      "t": 26501,
      "e": 26501,
      "ty": 41,
      "x": 37170,
      "y": 13281,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 26523,
      "e": 26523,
      "ty": 6,
      "x": 403,
      "y": 655,
      "ta": "#strategyButton"
    },
    {
      "t": 26600,
      "e": 26600,
      "ty": 2,
      "x": 404,
      "y": 656
    },
    {
      "t": 26740,
      "e": 26740,
      "ty": 3,
      "x": 404,
      "y": 656,
      "ta": "#strategyButton"
    },
    {
      "t": 26741,
      "e": 26741,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts B and F start at 12pm"
    },
    {
      "t": 26743,
      "e": 26743,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26743,
      "e": 26743,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 26750,
      "e": 26750,
      "ty": 41,
      "x": 35719,
      "y": 2439,
      "ta": "#strategyButton"
    },
    {
      "t": 26800,
      "e": 26800,
      "ty": 2,
      "x": 405,
      "y": 658
    },
    {
      "t": 26851,
      "e": 26851,
      "ty": 4,
      "x": 36266,
      "y": 6294,
      "ta": "#strategyButton"
    },
    {
      "t": 26859,
      "e": 26859,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 26860,
      "e": 26860,
      "ty": 5,
      "x": 405,
      "y": 658,
      "ta": "#strategyButton"
    },
    {
      "t": 26865,
      "e": 26865,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 27000,
      "e": 27000,
      "ty": 41,
      "x": 13671,
      "y": 36008,
      "ta": "html > body"
    },
    {
      "t": 27400,
      "e": 27400,
      "ty": 2,
      "x": 399,
      "y": 608
    },
    {
      "t": 27500,
      "e": 27500,
      "ty": 2,
      "x": 362,
      "y": 476
    },
    {
      "t": 27500,
      "e": 27500,
      "ty": 41,
      "x": 12190,
      "y": 25925,
      "ta": "html > body"
    },
    {
      "t": 27600,
      "e": 27600,
      "ty": 2,
      "x": 295,
      "y": 283
    },
    {
      "t": 27700,
      "e": 27700,
      "ty": 2,
      "x": 281,
      "y": 235
    },
    {
      "t": 27750,
      "e": 27750,
      "ty": 41,
      "x": 9401,
      "y": 12519,
      "ta": "html > body"
    },
    {
      "t": 27800,
      "e": 27800,
      "ty": 2,
      "x": 281,
      "y": 234
    },
    {
      "t": 27866,
      "e": 27866,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 27900,
      "e": 27900,
      "ty": 2,
      "x": 281,
      "y": 233
    },
    {
      "t": 28000,
      "e": 28000,
      "ty": 41,
      "x": 9401,
      "y": 12464,
      "ta": "html > body"
    },
    {
      "t": 28600,
      "e": 28600,
      "ty": 2,
      "x": 323,
      "y": 221
    },
    {
      "t": 28700,
      "e": 28700,
      "ty": 2,
      "x": 501,
      "y": 286
    },
    {
      "t": 28750,
      "e": 28750,
      "ty": 41,
      "x": 20593,
      "y": 19499,
      "ta": "html > body"
    },
    {
      "t": 28800,
      "e": 28800,
      "ty": 2,
      "x": 691,
      "y": 425
    },
    {
      "t": 28900,
      "e": 28900,
      "ty": 2,
      "x": 757,
      "y": 497
    },
    {
      "t": 29000,
      "e": 29000,
      "ty": 2,
      "x": 759,
      "y": 499
    },
    {
      "t": 29001,
      "e": 29001,
      "ty": 41,
      "x": 25862,
      "y": 27200,
      "ta": "html > body"
    },
    {
      "t": 29100,
      "e": 29100,
      "ty": 2,
      "x": 830,
      "y": 535
    },
    {
      "t": 29123,
      "e": 29123,
      "ty": 6,
      "x": 875,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29191,
      "e": 29191,
      "ty": 7,
      "x": 905,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29200,
      "e": 29191,
      "ty": 2,
      "x": 905,
      "y": 575
    },
    {
      "t": 29250,
      "e": 29241,
      "ty": 41,
      "x": 20979,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 29363,
      "e": 29354,
      "ty": 3,
      "x": 905,
      "y": 575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 29484,
      "e": 29475,
      "ty": 4,
      "x": 20979,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 29484,
      "e": 29475,
      "ty": 5,
      "x": 905,
      "y": 575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 29660,
      "e": 29651,
      "ty": 6,
      "x": 905,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29700,
      "e": 29691,
      "ty": 2,
      "x": 893,
      "y": 563
    },
    {
      "t": 29751,
      "e": 29742,
      "ty": 41,
      "x": 18384,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29770,
      "e": 29761,
      "ty": 3,
      "x": 893,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29771,
      "e": 29762,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29908,
      "e": 29899,
      "ty": 4,
      "x": 18384,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29908,
      "e": 29899,
      "ty": 5,
      "x": 893,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30100,
      "e": 30091,
      "ty": 2,
      "x": 893,
      "y": 561
    },
    {
      "t": 30109,
      "e": 30100,
      "ty": 7,
      "x": 875,
      "y": 552,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30200,
      "e": 30191,
      "ty": 2,
      "x": 626,
      "y": 477
    },
    {
      "t": 30251,
      "e": 30242,
      "ty": 41,
      "x": 21282,
      "y": 25981,
      "ta": "html > body"
    },
    {
      "t": 30503,
      "e": 30494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 30504,
      "e": 30495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30647,
      "e": 30638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 30790,
      "e": 30781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 30790,
      "e": 30781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30870,
      "e": 30861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 31700,
      "e": 31691,
      "ty": 2,
      "x": 721,
      "y": 477
    },
    {
      "t": 31751,
      "e": 31742,
      "ty": 41,
      "x": 22277,
      "y": 33119,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 31800,
      "e": 31791,
      "ty": 2,
      "x": 1093,
      "y": 645
    },
    {
      "t": 31900,
      "e": 31891,
      "ty": 2,
      "x": 1158,
      "y": 690
    },
    {
      "t": 32000,
      "e": 31991,
      "ty": 2,
      "x": 1158,
      "y": 691
    },
    {
      "t": 32000,
      "e": 31991,
      "ty": 41,
      "x": 39603,
      "y": 37836,
      "ta": "html > body"
    },
    {
      "t": 32100,
      "e": 32091,
      "ty": 2,
      "x": 1100,
      "y": 668
    },
    {
      "t": 32110,
      "e": 32101,
      "ty": 6,
      "x": 1094,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32201,
      "e": 32192,
      "ty": 2,
      "x": 1081,
      "y": 660
    },
    {
      "t": 32250,
      "e": 32241,
      "ty": 41,
      "x": 58613,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32301,
      "e": 32292,
      "ty": 2,
      "x": 1079,
      "y": 659
    },
    {
      "t": 32451,
      "e": 32442,
      "ty": 3,
      "x": 1079,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32452,
      "e": 32443,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 32453,
      "e": 32444,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32453,
      "e": 32444,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32659,
      "e": 32650,
      "ty": 4,
      "x": 58613,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32659,
      "e": 32650,
      "ty": 5,
      "x": 1079,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33319,
      "e": 33310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 33543,
      "e": 33534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 33544,
      "e": 33535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33647,
      "e": 33638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 33751,
      "e": 33742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 34231,
      "e": 34222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 34232,
      "e": 34223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34319,
      "e": 34310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 34447,
      "e": 34438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 34448,
      "e": 34439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34543,
      "e": 34534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 35032,
      "e": 35023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 35032,
      "e": 35023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35087,
      "e": 35078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 35202,
      "e": 35193,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 35671,
      "e": 35662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 35671,
      "e": 35662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35750,
      "e": 35741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 35999,
      "e": 35990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 36047,
      "e": 36038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 36047,
      "e": 36038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36095,
      "e": 36086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 36142,
      "e": 36133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 36223,
      "e": 36214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 36224,
      "e": 36215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36334,
      "e": 36325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 36406,
      "e": 36397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 36407,
      "e": 36398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36486,
      "e": 36477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 36495,
      "e": 36486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 36602,
      "e": 36593,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United "
    },
    {
      "t": 36686,
      "e": 36677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 36686,
      "e": 36677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36766,
      "e": 36757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 36766,
      "e": 36757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 36830,
      "e": 36821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 36830,
      "e": 36821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36911,
      "e": 36902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 36919,
      "e": 36910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 36920,
      "e": 36911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36991,
      "e": 36982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 37038,
      "e": 37029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 37038,
      "e": 37029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37134,
      "e": 37125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 37150,
      "e": 37141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 37151,
      "e": 37142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37222,
      "e": 37213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 37351,
      "e": 37342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 37351,
      "e": 37342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37422,
      "e": 37413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 37831,
      "e": 37822,
      "ty": 7,
      "x": 1030,
      "y": 615,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37900,
      "e": 37891,
      "ty": 2,
      "x": 935,
      "y": 519
    },
    {
      "t": 38001,
      "e": 37992,
      "ty": 2,
      "x": 934,
      "y": 519
    },
    {
      "t": 38001,
      "e": 37992,
      "ty": 41,
      "x": 27252,
      "y": 25745,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 38047,
      "e": 38038,
      "ty": 6,
      "x": 939,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38081,
      "e": 38072,
      "ty": 7,
      "x": 944,
      "y": 593,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38101,
      "e": 38092,
      "ty": 2,
      "x": 946,
      "y": 617
    },
    {
      "t": 38115,
      "e": 38106,
      "ty": 6,
      "x": 952,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38148,
      "e": 38139,
      "ty": 7,
      "x": 961,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38149,
      "e": 38140,
      "ty": 6,
      "x": 961,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 38200,
      "e": 38191,
      "ty": 2,
      "x": 965,
      "y": 693
    },
    {
      "t": 38250,
      "e": 38241,
      "ty": 41,
      "x": 35602,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 38388,
      "e": 38379,
      "ty": 3,
      "x": 965,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 38388,
      "e": 38379,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 38389,
      "e": 38380,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38390,
      "e": 38381,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 38475,
      "e": 38466,
      "ty": 4,
      "x": 35602,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 38475,
      "e": 38466,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 38475,
      "e": 38466,
      "ty": 5,
      "x": 965,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 38475,
      "e": 38466,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 38800,
      "e": 38791,
      "ty": 2,
      "x": 956,
      "y": 674
    },
    {
      "t": 38901,
      "e": 38892,
      "ty": 2,
      "x": 907,
      "y": 619
    },
    {
      "t": 39000,
      "e": 38991,
      "ty": 2,
      "x": 787,
      "y": 562
    },
    {
      "t": 39001,
      "e": 38992,
      "ty": 41,
      "x": 26826,
      "y": 30690,
      "ta": "html > body"
    },
    {
      "t": 39100,
      "e": 39091,
      "ty": 2,
      "x": 772,
      "y": 557
    },
    {
      "t": 39201,
      "e": 39192,
      "ty": 2,
      "x": 763,
      "y": 556
    },
    {
      "t": 39250,
      "e": 39241,
      "ty": 41,
      "x": 25862,
      "y": 30357,
      "ta": "html > body"
    },
    {
      "t": 39300,
      "e": 39291,
      "ty": 2,
      "x": 757,
      "y": 556
    },
    {
      "t": 39401,
      "e": 39392,
      "ty": 2,
      "x": 754,
      "y": 556
    },
    {
      "t": 39498,
      "e": 39489,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 39502,
      "e": 39493,
      "ty": 2,
      "x": 749,
      "y": 556
    },
    {
      "t": 39503,
      "e": 39494,
      "ty": 41,
      "x": 25518,
      "y": 30357,
      "ta": "html > body"
    },
    {
      "t": 39600,
      "e": 39591,
      "ty": 2,
      "x": 748,
      "y": 556
    },
    {
      "t": 39751,
      "e": 39742,
      "ty": 41,
      "x": 25483,
      "y": 30357,
      "ta": "html > body"
    },
    {
      "t": 40000,
      "e": 39991,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40201,
      "e": 40192,
      "ty": 2,
      "x": 751,
      "y": 335
    },
    {
      "t": 40251,
      "e": 40242,
      "ty": 41,
      "x": 27687,
      "y": 5262,
      "ta": "html > body"
    },
    {
      "t": 40301,
      "e": 40292,
      "ty": 2,
      "x": 822,
      "y": 65
    },
    {
      "t": 40501,
      "e": 40492,
      "ty": 2,
      "x": 821,
      "y": 160
    },
    {
      "t": 40501,
      "e": 40492,
      "ty": 41,
      "x": 27997,
      "y": 8420,
      "ta": "html > body"
    },
    {
      "t": 40601,
      "e": 40592,
      "ty": 2,
      "x": 819,
      "y": 180
    },
    {
      "t": 40701,
      "e": 40692,
      "ty": 2,
      "x": 813,
      "y": 202
    },
    {
      "t": 40751,
      "e": 40742,
      "ty": 41,
      "x": 27687,
      "y": 11134,
      "ta": "html > body"
    },
    {
      "t": 40801,
      "e": 40792,
      "ty": 2,
      "x": 811,
      "y": 217
    },
    {
      "t": 40901,
      "e": 40892,
      "ty": 2,
      "x": 813,
      "y": 229
    },
    {
      "t": 41001,
      "e": 40992,
      "ty": 2,
      "x": 820,
      "y": 232
    },
    {
      "t": 41001,
      "e": 40992,
      "ty": 41,
      "x": 27963,
      "y": 12408,
      "ta": "html > body"
    },
    {
      "t": 41067,
      "e": 41058,
      "ty": 6,
      "x": 828,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 41101,
      "e": 41092,
      "ty": 2,
      "x": 829,
      "y": 234
    },
    {
      "t": 41201,
      "e": 41192,
      "ty": 2,
      "x": 831,
      "y": 235
    },
    {
      "t": 41251,
      "e": 41242,
      "ty": 41,
      "x": 28120,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 41301,
      "e": 41292,
      "ty": 2,
      "x": 832,
      "y": 235
    },
    {
      "t": 41996,
      "e": 41987,
      "ty": 3,
      "x": 832,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 41997,
      "e": 41988,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 42131,
      "e": 42122,
      "ty": 4,
      "x": 28120,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 42132,
      "e": 42123,
      "ty": 5,
      "x": 832,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 42132,
      "e": 42123,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 42401,
      "e": 42392,
      "ty": 2,
      "x": 832,
      "y": 237
    },
    {
      "t": 42419,
      "e": 42410,
      "ty": 7,
      "x": 832,
      "y": 254,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 42452,
      "e": 42443,
      "ty": 6,
      "x": 832,
      "y": 290,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 42485,
      "e": 42476,
      "ty": 7,
      "x": 832,
      "y": 306,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 42501,
      "e": 42492,
      "ty": 2,
      "x": 832,
      "y": 306
    },
    {
      "t": 42501,
      "e": 42492,
      "ty": 41,
      "x": 2510,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 42600,
      "e": 42591,
      "ty": 2,
      "x": 833,
      "y": 314
    },
    {
      "t": 42618,
      "e": 42609,
      "ty": 6,
      "x": 833,
      "y": 319,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 42669,
      "e": 42660,
      "ty": 7,
      "x": 833,
      "y": 330,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 42701,
      "e": 42692,
      "ty": 2,
      "x": 833,
      "y": 335
    },
    {
      "t": 42751,
      "e": 42742,
      "ty": 41,
      "x": 2747,
      "y": 14048,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 42801,
      "e": 42792,
      "ty": 2,
      "x": 834,
      "y": 357
    },
    {
      "t": 42901,
      "e": 42892,
      "ty": 2,
      "x": 835,
      "y": 365
    },
    {
      "t": 43002,
      "e": 42993,
      "ty": 41,
      "x": 3222,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 44200,
      "e": 44191,
      "ty": 2,
      "x": 836,
      "y": 365
    },
    {
      "t": 44251,
      "e": 44242,
      "ty": 41,
      "x": 4171,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 44301,
      "e": 44292,
      "ty": 2,
      "x": 841,
      "y": 355
    },
    {
      "t": 44501,
      "e": 44492,
      "ty": 2,
      "x": 842,
      "y": 352
    },
    {
      "t": 44501,
      "e": 44492,
      "ty": 41,
      "x": 4883,
      "y": 14272,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 44801,
      "e": 44792,
      "ty": 2,
      "x": 855,
      "y": 373
    },
    {
      "t": 44901,
      "e": 44892,
      "ty": 2,
      "x": 872,
      "y": 415
    },
    {
      "t": 45000,
      "e": 44991,
      "ty": 2,
      "x": 873,
      "y": 417
    },
    {
      "t": 45001,
      "e": 44992,
      "ty": 41,
      "x": 60377,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 45101,
      "e": 45092,
      "ty": 2,
      "x": 865,
      "y": 420
    },
    {
      "t": 45201,
      "e": 45192,
      "ty": 2,
      "x": 853,
      "y": 416
    },
    {
      "t": 45251,
      "e": 45242,
      "ty": 41,
      "x": 34623,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 45301,
      "e": 45292,
      "ty": 2,
      "x": 849,
      "y": 415
    },
    {
      "t": 45396,
      "e": 45387,
      "ty": 6,
      "x": 839,
      "y": 411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 45401,
      "e": 45392,
      "ty": 2,
      "x": 839,
      "y": 411
    },
    {
      "t": 45501,
      "e": 45492,
      "ty": 2,
      "x": 837,
      "y": 410
    },
    {
      "t": 45501,
      "e": 45492,
      "ty": 41,
      "x": 53325,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 45531,
      "e": 45522,
      "ty": 3,
      "x": 837,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 45533,
      "e": 45524,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 45533,
      "e": 45524,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 45706,
      "e": 45697,
      "ty": 4,
      "x": 53325,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 45707,
      "e": 45698,
      "ty": 5,
      "x": 837,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 45707,
      "e": 45698,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 46100,
      "e": 46091,
      "ty": 2,
      "x": 837,
      "y": 412
    },
    {
      "t": 46108,
      "e": 46099,
      "ty": 7,
      "x": 837,
      "y": 423,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 46123,
      "e": 46101,
      "ty": 6,
      "x": 837,
      "y": 442,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 46139,
      "e": 46117,
      "ty": 7,
      "x": 844,
      "y": 531,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 46200,
      "e": 46178,
      "ty": 2,
      "x": 855,
      "y": 668
    },
    {
      "t": 46251,
      "e": 46229,
      "ty": 41,
      "x": 9720,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 46301,
      "e": 46279,
      "ty": 2,
      "x": 860,
      "y": 695
    },
    {
      "t": 46401,
      "e": 46379,
      "ty": 2,
      "x": 860,
      "y": 697
    },
    {
      "t": 46500,
      "e": 46478,
      "ty": 2,
      "x": 860,
      "y": 699
    },
    {
      "t": 46501,
      "e": 46479,
      "ty": 41,
      "x": 9720,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 46601,
      "e": 46579,
      "ty": 2,
      "x": 853,
      "y": 700
    },
    {
      "t": 46700,
      "e": 46678,
      "ty": 2,
      "x": 846,
      "y": 685
    },
    {
      "t": 46750,
      "e": 46728,
      "ty": 41,
      "x": 5525,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 46801,
      "e": 46779,
      "ty": 2,
      "x": 841,
      "y": 676
    },
    {
      "t": 46901,
      "e": 46879,
      "ty": 2,
      "x": 840,
      "y": 676
    },
    {
      "t": 47000,
      "e": 46978,
      "ty": 41,
      "x": 4988,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 47555,
      "e": 47533,
      "ty": 6,
      "x": 835,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 47600,
      "e": 47578,
      "ty": 2,
      "x": 835,
      "y": 706
    },
    {
      "t": 47623,
      "e": 47601,
      "ty": 7,
      "x": 833,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 47700,
      "e": 47678,
      "ty": 2,
      "x": 833,
      "y": 710
    },
    {
      "t": 47750,
      "e": 47728,
      "ty": 41,
      "x": 2747,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 47800,
      "e": 47778,
      "ty": 2,
      "x": 833,
      "y": 716
    },
    {
      "t": 48000,
      "e": 47978,
      "ty": 41,
      "x": 2747,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 48300,
      "e": 48278,
      "ty": 2,
      "x": 833,
      "y": 714
    },
    {
      "t": 48400,
      "e": 48378,
      "ty": 2,
      "x": 833,
      "y": 711
    },
    {
      "t": 48459,
      "e": 48437,
      "ty": 6,
      "x": 833,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 48500,
      "e": 48478,
      "ty": 2,
      "x": 833,
      "y": 707
    },
    {
      "t": 48501,
      "e": 48479,
      "ty": 41,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 48600,
      "e": 48578,
      "ty": 2,
      "x": 834,
      "y": 705
    },
    {
      "t": 48740,
      "e": 48718,
      "ty": 3,
      "x": 834,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 48741,
      "e": 48719,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 48744,
      "e": 48722,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 48750,
      "e": 48728,
      "ty": 41,
      "x": 38202,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 48891,
      "e": 48869,
      "ty": 4,
      "x": 38202,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 48891,
      "e": 48869,
      "ty": 5,
      "x": 834,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 48891,
      "e": 48869,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 49475,
      "e": 49453,
      "ty": 7,
      "x": 834,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 49500,
      "e": 49478,
      "ty": 2,
      "x": 834,
      "y": 715
    },
    {
      "t": 49500,
      "e": 49478,
      "ty": 41,
      "x": 2985,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 49541,
      "e": 49519,
      "ty": 6,
      "x": 834,
      "y": 725,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 49600,
      "e": 49578,
      "ty": 2,
      "x": 834,
      "y": 735
    },
    {
      "t": 49607,
      "e": 49585,
      "ty": 7,
      "x": 834,
      "y": 740,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 49657,
      "e": 49635,
      "ty": 6,
      "x": 834,
      "y": 756,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 49690,
      "e": 49668,
      "ty": 7,
      "x": 834,
      "y": 765,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 49700,
      "e": 49678,
      "ty": 2,
      "x": 834,
      "y": 765
    },
    {
      "t": 49750,
      "e": 49728,
      "ty": 41,
      "x": 2510,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 49757,
      "e": 49735,
      "ty": 6,
      "x": 832,
      "y": 780,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 49801,
      "e": 49779,
      "ty": 2,
      "x": 831,
      "y": 788
    },
    {
      "t": 49807,
      "e": 49785,
      "ty": 7,
      "x": 831,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 49900,
      "e": 49878,
      "ty": 2,
      "x": 828,
      "y": 806
    },
    {
      "t": 49927,
      "e": 49880,
      "ty": 6,
      "x": 828,
      "y": 808,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 50001,
      "e": 49954,
      "ty": 2,
      "x": 827,
      "y": 814
    },
    {
      "t": 50001,
      "e": 49954,
      "ty": 41,
      "x": 2914,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 50075,
      "e": 50028,
      "ty": 7,
      "x": 825,
      "y": 822,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 50100,
      "e": 50053,
      "ty": 2,
      "x": 825,
      "y": 825
    },
    {
      "t": 50200,
      "e": 50153,
      "ty": 2,
      "x": 822,
      "y": 849
    },
    {
      "t": 50250,
      "e": 50203,
      "ty": 41,
      "x": 27963,
      "y": 47364,
      "ta": "html > body"
    },
    {
      "t": 50300,
      "e": 50253,
      "ty": 2,
      "x": 818,
      "y": 872
    },
    {
      "t": 50400,
      "e": 50353,
      "ty": 2,
      "x": 818,
      "y": 889
    },
    {
      "t": 50500,
      "e": 50453,
      "ty": 2,
      "x": 818,
      "y": 918
    },
    {
      "t": 50501,
      "e": 50454,
      "ty": 41,
      "x": 27894,
      "y": 50411,
      "ta": "html > body"
    },
    {
      "t": 50600,
      "e": 50553,
      "ty": 2,
      "x": 818,
      "y": 921
    },
    {
      "t": 50700,
      "e": 50653,
      "ty": 2,
      "x": 818,
      "y": 928
    },
    {
      "t": 50750,
      "e": 50703,
      "ty": 41,
      "x": 27928,
      "y": 52073,
      "ta": "html > body"
    },
    {
      "t": 50800,
      "e": 50753,
      "ty": 2,
      "x": 822,
      "y": 964
    },
    {
      "t": 51000,
      "e": 50953,
      "ty": 2,
      "x": 825,
      "y": 959
    },
    {
      "t": 51000,
      "e": 50953,
      "ty": 41,
      "x": 2894,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 51009,
      "e": 50962,
      "ty": 6,
      "x": 827,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 51026,
      "e": 50979,
      "ty": 7,
      "x": 829,
      "y": 951,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 51100,
      "e": 51053,
      "ty": 2,
      "x": 830,
      "y": 945
    },
    {
      "t": 51251,
      "e": 51204,
      "ty": 41,
      "x": 2035,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 51377,
      "e": 51330,
      "ty": 6,
      "x": 830,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 51401,
      "e": 51354,
      "ty": 2,
      "x": 830,
      "y": 938
    },
    {
      "t": 51492,
      "e": 51445,
      "ty": 3,
      "x": 830,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 51493,
      "e": 51446,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51494,
      "e": 51447,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 51501,
      "e": 51454,
      "ty": 2,
      "x": 830,
      "y": 934
    },
    {
      "t": 51501,
      "e": 51454,
      "ty": 41,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 51611,
      "e": 51564,
      "ty": 4,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 51611,
      "e": 51564,
      "ty": 5,
      "x": 830,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 51611,
      "e": 51564,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 51800,
      "e": 51753,
      "ty": 2,
      "x": 833,
      "y": 937
    },
    {
      "t": 51810,
      "e": 51763,
      "ty": 7,
      "x": 835,
      "y": 946,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 51900,
      "e": 51853,
      "ty": 2,
      "x": 849,
      "y": 992
    },
    {
      "t": 51993,
      "e": 51946,
      "ty": 6,
      "x": 855,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52001,
      "e": 51954,
      "ty": 2,
      "x": 855,
      "y": 1007
    },
    {
      "t": 52001,
      "e": 51954,
      "ty": 41,
      "x": 13182,
      "y": 3971,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52100,
      "e": 52053,
      "ty": 2,
      "x": 855,
      "y": 1008
    },
    {
      "t": 52250,
      "e": 52203,
      "ty": 41,
      "x": 15244,
      "y": 15887,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52301,
      "e": 52254,
      "ty": 2,
      "x": 859,
      "y": 1013
    },
    {
      "t": 52332,
      "e": 52285,
      "ty": 3,
      "x": 859,
      "y": 1013,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52333,
      "e": 52286,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 52334,
      "e": 52287,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52459,
      "e": 52412,
      "ty": 4,
      "x": 15244,
      "y": 15887,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52459,
      "e": 52412,
      "ty": 5,
      "x": 859,
      "y": 1013,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52461,
      "e": 52414,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52462,
      "e": 52415,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 52463,
      "e": 52416,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 52750,
      "e": 52703,
      "ty": 41,
      "x": 29444,
      "y": 54954,
      "ta": "html > body"
    },
    {
      "t": 52801,
      "e": 52754,
      "ty": 2,
      "x": 865,
      "y": 961
    },
    {
      "t": 52900,
      "e": 52853,
      "ty": 2,
      "x": 855,
      "y": 873
    },
    {
      "t": 53000,
      "e": 52953,
      "ty": 2,
      "x": 802,
      "y": 787
    },
    {
      "t": 53001,
      "e": 52954,
      "ty": 41,
      "x": 27343,
      "y": 43154,
      "ta": "html > body"
    },
    {
      "t": 53100,
      "e": 53053,
      "ty": 2,
      "x": 789,
      "y": 776
    },
    {
      "t": 53200,
      "e": 53153,
      "ty": 2,
      "x": 785,
      "y": 773
    },
    {
      "t": 53250,
      "e": 53203,
      "ty": 41,
      "x": 26723,
      "y": 42378,
      "ta": "html > body"
    },
    {
      "t": 53300,
      "e": 53253,
      "ty": 2,
      "x": 783,
      "y": 772
    },
    {
      "t": 53401,
      "e": 53354,
      "ty": 2,
      "x": 782,
      "y": 770
    },
    {
      "t": 53500,
      "e": 53453,
      "ty": 41,
      "x": 26654,
      "y": 42212,
      "ta": "html > body"
    },
    {
      "t": 53550,
      "e": 53503,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 54401,
      "e": 54354,
      "ty": 2,
      "x": 785,
      "y": 774
    },
    {
      "t": 54501,
      "e": 54454,
      "ty": 2,
      "x": 853,
      "y": 941
    },
    {
      "t": 54501,
      "e": 54454,
      "ty": 41,
      "x": 27528,
      "y": 56415,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 54600,
      "e": 54553,
      "ty": 2,
      "x": 885,
      "y": 1003
    },
    {
      "t": 54701,
      "e": 54654,
      "ty": 2,
      "x": 915,
      "y": 1049
    },
    {
      "t": 54751,
      "e": 54704,
      "ty": 41,
      "x": 31021,
      "y": 64656,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 54779,
      "e": 54732,
      "ty": 6,
      "x": 935,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 54800,
      "e": 54753,
      "ty": 2,
      "x": 940,
      "y": 1081
    },
    {
      "t": 54900,
      "e": 54853,
      "ty": 2,
      "x": 958,
      "y": 1104
    },
    {
      "t": 55000,
      "e": 54953,
      "ty": 2,
      "x": 959,
      "y": 1106
    },
    {
      "t": 55001,
      "e": 54954,
      "ty": 41,
      "x": 27033,
      "y": 64209,
      "ta": "#start"
    },
    {
      "t": 55060,
      "e": 55013,
      "ty": 3,
      "x": 959,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 55060,
      "e": 55013,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 55243,
      "e": 55196,
      "ty": 4,
      "x": 27033,
      "y": 64209,
      "ta": "#start"
    },
    {
      "t": 55244,
      "e": 55197,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 55246,
      "e": 55199,
      "ty": 5,
      "x": 959,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 55247,
      "e": 55200,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 56282,
      "e": 56235,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 57403,
      "e": 57356,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 120098, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 120105, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 5485, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 126928, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 7092, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"romeo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 135023, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 3626, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 139735, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9362, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 150099, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 41217, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 192711, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1019,y:738,t:1527627906515};\\\", \\\"{x:1024,y:740,t:1527627906522};\\\", \\\"{x:1035,y:741,t:1527627906536};\\\", \\\"{x:1069,y:747,t:1527627906549};\\\", \\\"{x:1093,y:752,t:1527627906566};\\\", \\\"{x:1120,y:758,t:1527627906583};\\\", \\\"{x:1145,y:765,t:1527627906599};\\\", \\\"{x:1182,y:777,t:1527627906616};\\\", \\\"{x:1232,y:791,t:1527627906633};\\\", \\\"{x:1258,y:797,t:1527627906649};\\\", \\\"{x:1286,y:805,t:1527627906666};\\\", \\\"{x:1316,y:811,t:1527627906683};\\\", \\\"{x:1341,y:819,t:1527627906699};\\\", \\\"{x:1359,y:822,t:1527627906716};\\\", \\\"{x:1375,y:826,t:1527627906734};\\\", \\\"{x:1389,y:830,t:1527627906751};\\\", \\\"{x:1395,y:831,t:1527627906766};\\\", \\\"{x:1397,y:832,t:1527627906783};\\\", \\\"{x:1399,y:833,t:1527627906809};\\\", \\\"{x:1400,y:834,t:1527627907763};\\\", \\\"{x:1400,y:836,t:1527627907866};\\\", \\\"{x:1400,y:838,t:1527627907881};\\\", \\\"{x:1399,y:840,t:1527627907890};\\\", \\\"{x:1399,y:841,t:1527627907901};\\\", \\\"{x:1398,y:842,t:1527627907918};\\\", \\\"{x:1396,y:845,t:1527627907935};\\\", \\\"{x:1395,y:848,t:1527627907950};\\\", \\\"{x:1394,y:849,t:1527627907967};\\\", \\\"{x:1393,y:850,t:1527627907984};\\\", \\\"{x:1392,y:850,t:1527627908000};\\\", \\\"{x:1391,y:852,t:1527627908041};\\\", \\\"{x:1390,y:853,t:1527627908081};\\\", \\\"{x:1390,y:854,t:1527627908097};\\\", \\\"{x:1389,y:854,t:1527627908105};\\\", \\\"{x:1389,y:855,t:1527627908121};\\\", \\\"{x:1387,y:856,t:1527627908137};\\\", \\\"{x:1387,y:857,t:1527627908150};\\\", \\\"{x:1386,y:857,t:1527627908167};\\\", \\\"{x:1385,y:859,t:1527627908184};\\\", \\\"{x:1384,y:860,t:1527627908201};\\\", \\\"{x:1383,y:862,t:1527627908217};\\\", \\\"{x:1382,y:863,t:1527627908234};\\\", \\\"{x:1381,y:863,t:1527627908251};\\\", \\\"{x:1380,y:865,t:1527627908268};\\\", \\\"{x:1379,y:866,t:1527627908289};\\\", \\\"{x:1378,y:867,t:1527627908313};\\\", \\\"{x:1378,y:868,t:1527627908329};\\\", \\\"{x:1377,y:868,t:1527627908345};\\\", \\\"{x:1376,y:870,t:1527627908361};\\\", \\\"{x:1375,y:871,t:1527627908377};\\\", \\\"{x:1374,y:871,t:1527627908393};\\\", \\\"{x:1374,y:872,t:1527627908409};\\\", \\\"{x:1373,y:873,t:1527627908417};\\\", \\\"{x:1373,y:874,t:1527627908434};\\\", \\\"{x:1372,y:876,t:1527627908451};\\\", \\\"{x:1370,y:878,t:1527627908468};\\\", \\\"{x:1369,y:879,t:1527627908489};\\\", \\\"{x:1368,y:880,t:1527627908506};\\\", \\\"{x:1368,y:881,t:1527627908518};\\\", \\\"{x:1367,y:882,t:1527627908535};\\\", \\\"{x:1366,y:883,t:1527627908552};\\\", \\\"{x:1364,y:884,t:1527627908567};\\\", \\\"{x:1362,y:885,t:1527627908584};\\\", \\\"{x:1361,y:887,t:1527627908601};\\\", \\\"{x:1360,y:888,t:1527627908618};\\\", \\\"{x:1359,y:888,t:1527627908634};\\\", \\\"{x:1357,y:890,t:1527627908651};\\\", \\\"{x:1356,y:890,t:1527627908673};\\\", \\\"{x:1356,y:891,t:1527627908685};\\\", \\\"{x:1354,y:893,t:1527627908701};\\\", \\\"{x:1353,y:894,t:1527627908720};\\\", \\\"{x:1350,y:896,t:1527627908734};\\\", \\\"{x:1348,y:898,t:1527627908751};\\\", \\\"{x:1346,y:900,t:1527627908768};\\\", \\\"{x:1344,y:900,t:1527627908784};\\\", \\\"{x:1342,y:901,t:1527627908801};\\\", \\\"{x:1340,y:903,t:1527627908818};\\\", \\\"{x:1335,y:904,t:1527627908834};\\\", \\\"{x:1332,y:907,t:1527627908851};\\\", \\\"{x:1331,y:908,t:1527627908868};\\\", \\\"{x:1329,y:910,t:1527627908884};\\\", \\\"{x:1328,y:910,t:1527627908902};\\\", \\\"{x:1328,y:911,t:1527627908918};\\\", \\\"{x:1326,y:912,t:1527627908935};\\\", \\\"{x:1324,y:913,t:1527627908951};\\\", \\\"{x:1322,y:914,t:1527627908969};\\\", \\\"{x:1321,y:916,t:1527627908984};\\\", \\\"{x:1319,y:917,t:1527627909001};\\\", \\\"{x:1316,y:920,t:1527627909019};\\\", \\\"{x:1314,y:922,t:1527627909034};\\\", \\\"{x:1312,y:924,t:1527627909052};\\\", \\\"{x:1308,y:928,t:1527627909068};\\\", \\\"{x:1304,y:932,t:1527627909084};\\\", \\\"{x:1300,y:935,t:1527627909102};\\\", \\\"{x:1295,y:939,t:1527627909119};\\\", \\\"{x:1288,y:943,t:1527627909135};\\\", \\\"{x:1282,y:946,t:1527627909152};\\\", \\\"{x:1278,y:949,t:1527627909169};\\\", \\\"{x:1272,y:953,t:1527627909185};\\\", \\\"{x:1269,y:954,t:1527627909202};\\\", \\\"{x:1269,y:955,t:1527627909218};\\\", \\\"{x:1267,y:956,t:1527627909236};\\\", \\\"{x:1265,y:957,t:1527627909251};\\\", \\\"{x:1264,y:958,t:1527627909269};\\\", \\\"{x:1263,y:958,t:1527627909286};\\\", \\\"{x:1262,y:959,t:1527627909314};\\\", \\\"{x:1261,y:960,t:1527627909354};\\\", \\\"{x:1260,y:960,t:1527627909386};\\\", \\\"{x:1260,y:961,t:1527627909402};\\\", \\\"{x:1259,y:961,t:1527627909426};\\\", \\\"{x:1258,y:962,t:1527627909450};\\\", \\\"{x:1257,y:962,t:1527627909466};\\\", \\\"{x:1257,y:963,t:1527627909473};\\\", \\\"{x:1256,y:964,t:1527627909489};\\\", \\\"{x:1255,y:964,t:1527627909506};\\\", \\\"{x:1255,y:965,t:1527627909521};\\\", \\\"{x:1254,y:965,t:1527627909536};\\\", \\\"{x:1254,y:966,t:1527627909551};\\\", \\\"{x:1253,y:967,t:1527627909568};\\\", \\\"{x:1250,y:968,t:1527627909585};\\\", \\\"{x:1249,y:969,t:1527627909601};\\\", \\\"{x:1247,y:970,t:1527627909618};\\\", \\\"{x:1246,y:971,t:1527627909648};\\\", \\\"{x:1246,y:972,t:1527627909657};\\\", \\\"{x:1244,y:972,t:1527627909689};\\\", \\\"{x:1244,y:973,t:1527627909810};\\\", \\\"{x:1243,y:973,t:1527627909858};\\\", \\\"{x:1242,y:973,t:1527627909890};\\\", \\\"{x:1241,y:973,t:1527627909903};\\\", \\\"{x:1240,y:973,t:1527627909919};\\\", \\\"{x:1239,y:973,t:1527627909938};\\\", \\\"{x:1238,y:973,t:1527627909952};\\\", \\\"{x:1237,y:973,t:1527627909993};\\\", \\\"{x:1238,y:973,t:1527627911457};\\\", \\\"{x:1239,y:973,t:1527627911469};\\\", \\\"{x:1241,y:973,t:1527627911486};\\\", \\\"{x:1243,y:973,t:1527627911503};\\\", \\\"{x:1244,y:973,t:1527627911519};\\\", \\\"{x:1246,y:973,t:1527627911536};\\\", \\\"{x:1247,y:973,t:1527627911553};\\\", \\\"{x:1248,y:973,t:1527627911593};\\\", \\\"{x:1250,y:973,t:1527627911617};\\\", \\\"{x:1251,y:973,t:1527627911641};\\\", \\\"{x:1252,y:973,t:1527627911653};\\\", \\\"{x:1253,y:973,t:1527627911681};\\\", \\\"{x:1254,y:973,t:1527627911713};\\\", \\\"{x:1255,y:973,t:1527627911737};\\\", \\\"{x:1257,y:973,t:1527627911769};\\\", \\\"{x:1258,y:973,t:1527627911810};\\\", \\\"{x:1259,y:973,t:1527627911821};\\\", \\\"{x:1259,y:972,t:1527627911906};\\\", \\\"{x:1260,y:971,t:1527627911921};\\\", \\\"{x:1261,y:962,t:1527627911936};\\\", \\\"{x:1262,y:954,t:1527627911953};\\\", \\\"{x:1263,y:943,t:1527627911970};\\\", \\\"{x:1263,y:927,t:1527627911986};\\\", \\\"{x:1263,y:911,t:1527627912004};\\\", \\\"{x:1261,y:897,t:1527627912020};\\\", \\\"{x:1260,y:884,t:1527627912037};\\\", \\\"{x:1255,y:871,t:1527627912053};\\\", \\\"{x:1246,y:856,t:1527627912070};\\\", \\\"{x:1233,y:838,t:1527627912087};\\\", \\\"{x:1217,y:822,t:1527627912103};\\\", \\\"{x:1194,y:802,t:1527627912121};\\\", \\\"{x:1142,y:765,t:1527627912137};\\\", \\\"{x:1110,y:741,t:1527627912154};\\\", \\\"{x:1080,y:728,t:1527627912170};\\\", \\\"{x:1048,y:711,t:1527627912187};\\\", \\\"{x:1023,y:701,t:1527627912203};\\\", \\\"{x:999,y:691,t:1527627912220};\\\", \\\"{x:973,y:681,t:1527627912238};\\\", \\\"{x:947,y:670,t:1527627912254};\\\", \\\"{x:922,y:662,t:1527627912270};\\\", \\\"{x:905,y:657,t:1527627912287};\\\", \\\"{x:893,y:653,t:1527627912304};\\\", \\\"{x:879,y:649,t:1527627912320};\\\", \\\"{x:855,y:645,t:1527627912337};\\\", \\\"{x:837,y:641,t:1527627912353};\\\", \\\"{x:818,y:638,t:1527627912370};\\\", \\\"{x:807,y:637,t:1527627912387};\\\", \\\"{x:794,y:635,t:1527627912403};\\\", \\\"{x:775,y:633,t:1527627912420};\\\", \\\"{x:748,y:631,t:1527627912438};\\\", \\\"{x:718,y:626,t:1527627912455};\\\", \\\"{x:684,y:621,t:1527627912470};\\\", \\\"{x:653,y:617,t:1527627912488};\\\", \\\"{x:603,y:609,t:1527627912504};\\\", \\\"{x:555,y:601,t:1527627912521};\\\", \\\"{x:496,y:591,t:1527627912539};\\\", \\\"{x:426,y:581,t:1527627912554};\\\", \\\"{x:355,y:565,t:1527627912572};\\\", \\\"{x:304,y:557,t:1527627912588};\\\", \\\"{x:271,y:555,t:1527627912605};\\\", \\\"{x:248,y:550,t:1527627912622};\\\", \\\"{x:230,y:547,t:1527627912638};\\\", \\\"{x:217,y:545,t:1527627912656};\\\", \\\"{x:214,y:544,t:1527627912671};\\\", \\\"{x:213,y:543,t:1527627912729};\\\", \\\"{x:213,y:541,t:1527627912738};\\\", \\\"{x:223,y:534,t:1527627912756};\\\", \\\"{x:240,y:527,t:1527627912772};\\\", \\\"{x:259,y:519,t:1527627912788};\\\", \\\"{x:276,y:511,t:1527627912806};\\\", \\\"{x:290,y:506,t:1527627912821};\\\", \\\"{x:300,y:506,t:1527627912838};\\\", \\\"{x:305,y:506,t:1527627912855};\\\", \\\"{x:307,y:506,t:1527627912871};\\\", \\\"{x:312,y:507,t:1527627912888};\\\", \\\"{x:316,y:510,t:1527627912905};\\\", \\\"{x:321,y:511,t:1527627912922};\\\", \\\"{x:323,y:512,t:1527627912938};\\\", \\\"{x:324,y:513,t:1527627912956};\\\", \\\"{x:326,y:514,t:1527627913050};\\\", \\\"{x:327,y:515,t:1527627913057};\\\", \\\"{x:330,y:517,t:1527627913072};\\\", \\\"{x:332,y:518,t:1527627913089};\\\", \\\"{x:337,y:520,t:1527627913105};\\\", \\\"{x:338,y:521,t:1527627913121};\\\", \\\"{x:341,y:522,t:1527627913138};\\\", \\\"{x:343,y:522,t:1527627913162};\\\", \\\"{x:345,y:524,t:1527627913172};\\\", \\\"{x:347,y:525,t:1527627913189};\\\", \\\"{x:349,y:526,t:1527627913206};\\\", \\\"{x:351,y:526,t:1527627913222};\\\", \\\"{x:354,y:527,t:1527627913239};\\\", \\\"{x:357,y:528,t:1527627913256};\\\", \\\"{x:358,y:528,t:1527627913271};\\\", \\\"{x:359,y:528,t:1527627913289};\\\", \\\"{x:361,y:528,t:1527627913305};\\\", \\\"{x:366,y:528,t:1527627913323};\\\", \\\"{x:371,y:528,t:1527627913338};\\\", \\\"{x:373,y:528,t:1527627913356};\\\", \\\"{x:375,y:528,t:1527627913373};\\\", \\\"{x:377,y:528,t:1527627913389};\\\", \\\"{x:378,y:528,t:1527627913405};\\\", \\\"{x:382,y:528,t:1527627914049};\\\", \\\"{x:387,y:532,t:1527627914057};\\\", \\\"{x:396,y:536,t:1527627914074};\\\", \\\"{x:404,y:545,t:1527627914090};\\\", \\\"{x:410,y:553,t:1527627914106};\\\", \\\"{x:422,y:563,t:1527627914123};\\\", \\\"{x:434,y:574,t:1527627914139};\\\", \\\"{x:442,y:582,t:1527627914157};\\\", \\\"{x:451,y:591,t:1527627914172};\\\", \\\"{x:460,y:600,t:1527627914189};\\\", \\\"{x:468,y:609,t:1527627914205};\\\", \\\"{x:476,y:620,t:1527627914223};\\\", \\\"{x:489,y:631,t:1527627914239};\\\", \\\"{x:499,y:640,t:1527627914257};\\\", \\\"{x:502,y:645,t:1527627914272};\\\", \\\"{x:502,y:647,t:1527627914289};\\\", \\\"{x:503,y:648,t:1527627914306};\\\", \\\"{x:504,y:649,t:1527627914322};\\\", \\\"{x:504,y:650,t:1527627914340};\\\", \\\"{x:504,y:651,t:1527627914357};\\\", \\\"{x:505,y:654,t:1527627914372};\\\", \\\"{x:506,y:656,t:1527627914389};\\\", \\\"{x:506,y:658,t:1527627914407};\\\", \\\"{x:506,y:660,t:1527627914423};\\\", \\\"{x:506,y:663,t:1527627914440};\\\", \\\"{x:507,y:668,t:1527627914457};\\\", \\\"{x:507,y:671,t:1527627914472};\\\", \\\"{x:509,y:677,t:1527627914490};\\\", \\\"{x:509,y:682,t:1527627914506};\\\", \\\"{x:510,y:688,t:1527627914524};\\\", \\\"{x:510,y:693,t:1527627914540};\\\", \\\"{x:511,y:697,t:1527627914557};\\\", \\\"{x:512,y:702,t:1527627914575};\\\", \\\"{x:512,y:707,t:1527627914589};\\\", \\\"{x:513,y:710,t:1527627914606};\\\", \\\"{x:514,y:714,t:1527627914623};\\\", \\\"{x:514,y:715,t:1527627914639};\\\", \\\"{x:515,y:719,t:1527627914656};\\\", \\\"{x:515,y:722,t:1527627914672};\\\", \\\"{x:516,y:726,t:1527627914689};\\\", \\\"{x:516,y:729,t:1527627914706};\\\", \\\"{x:517,y:732,t:1527627914724};\\\", \\\"{x:517,y:734,t:1527627914740};\\\", \\\"{x:517,y:736,t:1527627914757};\\\", \\\"{x:517,y:737,t:1527627914773};\\\", \\\"{x:517,y:738,t:1527627914790};\\\", \\\"{x:517,y:737,t:1527627943038};\\\", \\\"{x:515,y:732,t:1527627943047};\\\", \\\"{x:513,y:729,t:1527627943059};\\\", \\\"{x:506,y:722,t:1527627943075};\\\", \\\"{x:504,y:718,t:1527627943092};\\\", \\\"{x:502,y:714,t:1527627943109};\\\", \\\"{x:502,y:713,t:1527627943126};\\\", \\\"{x:502,y:712,t:1527627943709};\\\", \\\"{x:502,y:702,t:1527627943726};\\\", \\\"{x:504,y:696,t:1527627943743};\\\", \\\"{x:508,y:685,t:1527627943760};\\\", \\\"{x:514,y:671,t:1527627943776};\\\", \\\"{x:522,y:652,t:1527627943793};\\\", \\\"{x:522,y:637,t:1527627943811};\\\", \\\"{x:522,y:611,t:1527627943826};\\\", \\\"{x:522,y:561,t:1527627943843};\\\", \\\"{x:522,y:502,t:1527627943861};\\\", \\\"{x:522,y:452,t:1527627943877};\\\", \\\"{x:524,y:443,t:1527627943894};\\\", \\\"{x:524,y:442,t:1527627943942};\\\", \\\"{x:524,y:438,t:1527627943949};\\\", \\\"{x:524,y:428,t:1527627943960};\\\", \\\"{x:524,y:369,t:1527627943976};\\\", \\\"{x:511,y:279,t:1527627943994};\\\", \\\"{x:495,y:221,t:1527627944011};\\\", \\\"{x:489,y:187,t:1527627944026};\\\", \\\"{x:489,y:167,t:1527627944044};\\\", \\\"{x:488,y:159,t:1527627944060};\\\", \\\"{x:488,y:158,t:1527627944077};\\\", \\\"{x:493,y:163,t:1527627944141};\\\", \\\"{x:499,y:167,t:1527627944149};\\\", \\\"{x:504,y:169,t:1527627944160};\\\", \\\"{x:506,y:171,t:1527627944177};\\\" ] }, { \\\"rt\\\": 17226, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 211174, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -Z -Z -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:172,t:1527627946165};\\\", \\\"{x:506,y:175,t:1527627946178};\\\", \\\"{x:506,y:181,t:1527627946195};\\\", \\\"{x:506,y:187,t:1527627946211};\\\", \\\"{x:506,y:194,t:1527627946228};\\\", \\\"{x:506,y:201,t:1527627946245};\\\", \\\"{x:506,y:207,t:1527627946261};\\\", \\\"{x:506,y:212,t:1527627946278};\\\", \\\"{x:507,y:216,t:1527627946295};\\\", \\\"{x:508,y:224,t:1527627946311};\\\", \\\"{x:509,y:233,t:1527627946328};\\\", \\\"{x:513,y:250,t:1527627946345};\\\", \\\"{x:517,y:266,t:1527627946363};\\\", \\\"{x:523,y:283,t:1527627946378};\\\", \\\"{x:526,y:301,t:1527627946395};\\\", \\\"{x:534,y:324,t:1527627946413};\\\", \\\"{x:544,y:348,t:1527627946428};\\\", \\\"{x:568,y:390,t:1527627946445};\\\", \\\"{x:577,y:412,t:1527627946462};\\\", \\\"{x:584,y:428,t:1527627946479};\\\", \\\"{x:588,y:439,t:1527627946496};\\\", \\\"{x:593,y:448,t:1527627946513};\\\", \\\"{x:595,y:450,t:1527627946528};\\\", \\\"{x:596,y:452,t:1527627946546};\\\", \\\"{x:599,y:456,t:1527627946838};\\\", \\\"{x:604,y:461,t:1527627946846};\\\", \\\"{x:614,y:467,t:1527627946863};\\\", \\\"{x:625,y:475,t:1527627946880};\\\", \\\"{x:631,y:478,t:1527627946896};\\\", \\\"{x:633,y:479,t:1527627946912};\\\", \\\"{x:634,y:479,t:1527627950326};\\\", \\\"{x:641,y:482,t:1527627950333};\\\", \\\"{x:664,y:492,t:1527627950350};\\\", \\\"{x:708,y:511,t:1527627950367};\\\", \\\"{x:752,y:521,t:1527627950382};\\\", \\\"{x:793,y:533,t:1527627950399};\\\", \\\"{x:845,y:544,t:1527627950416};\\\", \\\"{x:906,y:552,t:1527627950432};\\\", \\\"{x:964,y:557,t:1527627950449};\\\", \\\"{x:1007,y:558,t:1527627950465};\\\", \\\"{x:1045,y:564,t:1527627950482};\\\", \\\"{x:1074,y:568,t:1527627950498};\\\", \\\"{x:1097,y:572,t:1527627950515};\\\", \\\"{x:1118,y:575,t:1527627950531};\\\", \\\"{x:1148,y:585,t:1527627950549};\\\", \\\"{x:1166,y:594,t:1527627950565};\\\", \\\"{x:1189,y:605,t:1527627950582};\\\", \\\"{x:1214,y:621,t:1527627950599};\\\", \\\"{x:1250,y:643,t:1527627950616};\\\", \\\"{x:1295,y:674,t:1527627950633};\\\", \\\"{x:1316,y:692,t:1527627950649};\\\", \\\"{x:1332,y:708,t:1527627950665};\\\", \\\"{x:1345,y:722,t:1527627950683};\\\", \\\"{x:1357,y:736,t:1527627950699};\\\", \\\"{x:1367,y:747,t:1527627950716};\\\", \\\"{x:1374,y:755,t:1527627950733};\\\", \\\"{x:1376,y:757,t:1527627950749};\\\", \\\"{x:1377,y:760,t:1527627950767};\\\", \\\"{x:1380,y:765,t:1527627950783};\\\", \\\"{x:1381,y:768,t:1527627950799};\\\", \\\"{x:1383,y:771,t:1527627950817};\\\", \\\"{x:1383,y:773,t:1527627950833};\\\", \\\"{x:1383,y:775,t:1527627950849};\\\", \\\"{x:1383,y:777,t:1527627950866};\\\", \\\"{x:1384,y:780,t:1527627950883};\\\", \\\"{x:1385,y:782,t:1527627950898};\\\", \\\"{x:1385,y:783,t:1527627950916};\\\", \\\"{x:1385,y:785,t:1527627950933};\\\", \\\"{x:1385,y:786,t:1527627950949};\\\", \\\"{x:1385,y:787,t:1527627950966};\\\", \\\"{x:1385,y:788,t:1527627950989};\\\", \\\"{x:1385,y:790,t:1527627951005};\\\", \\\"{x:1385,y:791,t:1527627951021};\\\", \\\"{x:1385,y:793,t:1527627951033};\\\", \\\"{x:1384,y:797,t:1527627951049};\\\", \\\"{x:1382,y:801,t:1527627951066};\\\", \\\"{x:1382,y:807,t:1527627951082};\\\", \\\"{x:1378,y:813,t:1527627951099};\\\", \\\"{x:1375,y:818,t:1527627951116};\\\", \\\"{x:1373,y:824,t:1527627951133};\\\", \\\"{x:1370,y:828,t:1527627951150};\\\", \\\"{x:1368,y:833,t:1527627951165};\\\", \\\"{x:1366,y:835,t:1527627951184};\\\", \\\"{x:1366,y:839,t:1527627951200};\\\", \\\"{x:1363,y:842,t:1527627951216};\\\", \\\"{x:1362,y:847,t:1527627951233};\\\", \\\"{x:1360,y:849,t:1527627951250};\\\", \\\"{x:1359,y:854,t:1527627951266};\\\", \\\"{x:1357,y:858,t:1527627951283};\\\", \\\"{x:1355,y:861,t:1527627951300};\\\", \\\"{x:1355,y:864,t:1527627951316};\\\", \\\"{x:1352,y:867,t:1527627951333};\\\", \\\"{x:1352,y:871,t:1527627951349};\\\", \\\"{x:1352,y:875,t:1527627951366};\\\", \\\"{x:1351,y:880,t:1527627951385};\\\", \\\"{x:1349,y:886,t:1527627951400};\\\", \\\"{x:1347,y:892,t:1527627951416};\\\", \\\"{x:1345,y:897,t:1527627951433};\\\", \\\"{x:1344,y:902,t:1527627951451};\\\", \\\"{x:1344,y:905,t:1527627951466};\\\", \\\"{x:1343,y:908,t:1527627951483};\\\", \\\"{x:1342,y:909,t:1527627951500};\\\", \\\"{x:1341,y:911,t:1527627951516};\\\", \\\"{x:1341,y:913,t:1527627951533};\\\", \\\"{x:1340,y:916,t:1527627951550};\\\", \\\"{x:1340,y:918,t:1527627951567};\\\", \\\"{x:1339,y:920,t:1527627951584};\\\", \\\"{x:1338,y:922,t:1527627951600};\\\", \\\"{x:1337,y:926,t:1527627951617};\\\", \\\"{x:1337,y:928,t:1527627951634};\\\", \\\"{x:1337,y:931,t:1527627951650};\\\", \\\"{x:1334,y:934,t:1527627951667};\\\", \\\"{x:1334,y:936,t:1527627951683};\\\", \\\"{x:1333,y:938,t:1527627951701};\\\", \\\"{x:1332,y:941,t:1527627951717};\\\", \\\"{x:1331,y:942,t:1527627951733};\\\", \\\"{x:1331,y:944,t:1527627951750};\\\", \\\"{x:1331,y:946,t:1527627951767};\\\", \\\"{x:1330,y:948,t:1527627951784};\\\", \\\"{x:1328,y:950,t:1527627951800};\\\", \\\"{x:1328,y:952,t:1527627951817};\\\", \\\"{x:1327,y:955,t:1527627951834};\\\", \\\"{x:1326,y:958,t:1527627951850};\\\", \\\"{x:1325,y:960,t:1527627951867};\\\", \\\"{x:1324,y:962,t:1527627951884};\\\", \\\"{x:1324,y:964,t:1527627951900};\\\", \\\"{x:1324,y:965,t:1527627951917};\\\", \\\"{x:1323,y:965,t:1527627951965};\\\", \\\"{x:1323,y:964,t:1527627952134};\\\", \\\"{x:1322,y:961,t:1527627952150};\\\", \\\"{x:1322,y:959,t:1527627952174};\\\", \\\"{x:1322,y:958,t:1527627952190};\\\", \\\"{x:1321,y:956,t:1527627952205};\\\", \\\"{x:1321,y:955,t:1527627952217};\\\", \\\"{x:1321,y:953,t:1527627952234};\\\", \\\"{x:1320,y:949,t:1527627952250};\\\", \\\"{x:1320,y:948,t:1527627952267};\\\", \\\"{x:1320,y:945,t:1527627952284};\\\", \\\"{x:1320,y:943,t:1527627952301};\\\", \\\"{x:1320,y:940,t:1527627952318};\\\", \\\"{x:1319,y:937,t:1527627952334};\\\", \\\"{x:1318,y:935,t:1527627952352};\\\", \\\"{x:1318,y:931,t:1527627952367};\\\", \\\"{x:1318,y:926,t:1527627952385};\\\", \\\"{x:1317,y:921,t:1527627952401};\\\", \\\"{x:1316,y:917,t:1527627952417};\\\", \\\"{x:1316,y:913,t:1527627952434};\\\", \\\"{x:1315,y:913,t:1527627952451};\\\", \\\"{x:1315,y:911,t:1527627952467};\\\", \\\"{x:1315,y:910,t:1527627952484};\\\", \\\"{x:1315,y:908,t:1527627952501};\\\", \\\"{x:1314,y:907,t:1527627952517};\\\", \\\"{x:1314,y:906,t:1527627952534};\\\", \\\"{x:1314,y:904,t:1527627952551};\\\", \\\"{x:1314,y:902,t:1527627952598};\\\", \\\"{x:1314,y:901,t:1527627953038};\\\", \\\"{x:1314,y:899,t:1527627953054};\\\", \\\"{x:1314,y:898,t:1527627953069};\\\", \\\"{x:1314,y:896,t:1527627953085};\\\", \\\"{x:1314,y:895,t:1527627953118};\\\", \\\"{x:1314,y:893,t:1527627953175};\\\", \\\"{x:1314,y:892,t:1527627953286};\\\", \\\"{x:1314,y:891,t:1527627953309};\\\", \\\"{x:1314,y:890,t:1527627953333};\\\", \\\"{x:1315,y:889,t:1527627953398};\\\", \\\"{x:1315,y:887,t:1527627953430};\\\", \\\"{x:1315,y:886,t:1527627953445};\\\", \\\"{x:1316,y:884,t:1527627953478};\\\", \\\"{x:1316,y:883,t:1527627953509};\\\", \\\"{x:1316,y:882,t:1527627953533};\\\", \\\"{x:1317,y:881,t:1527627953573};\\\", \\\"{x:1318,y:880,t:1527627953629};\\\", \\\"{x:1318,y:879,t:1527627953653};\\\", \\\"{x:1318,y:878,t:1527627953676};\\\", \\\"{x:1319,y:877,t:1527627953693};\\\", \\\"{x:1320,y:876,t:1527627953709};\\\", \\\"{x:1320,y:875,t:1527627953725};\\\", \\\"{x:1320,y:874,t:1527627953741};\\\", \\\"{x:1321,y:873,t:1527627953757};\\\", \\\"{x:1322,y:871,t:1527627953781};\\\", \\\"{x:1322,y:870,t:1527627953805};\\\", \\\"{x:1323,y:870,t:1527627953818};\\\", \\\"{x:1324,y:868,t:1527627953835};\\\", \\\"{x:1324,y:867,t:1527627953861};\\\", \\\"{x:1324,y:866,t:1527627953870};\\\", \\\"{x:1324,y:865,t:1527627953885};\\\", \\\"{x:1325,y:864,t:1527627953902};\\\", \\\"{x:1326,y:861,t:1527627953919};\\\", \\\"{x:1327,y:860,t:1527627953942};\\\", \\\"{x:1327,y:859,t:1527627953965};\\\", \\\"{x:1328,y:859,t:1527627953974};\\\", \\\"{x:1328,y:858,t:1527627953990};\\\", \\\"{x:1328,y:857,t:1527627954005};\\\", \\\"{x:1328,y:856,t:1527627954019};\\\", \\\"{x:1329,y:855,t:1527627954035};\\\", \\\"{x:1329,y:854,t:1527627954052};\\\", \\\"{x:1330,y:853,t:1527627954069};\\\", \\\"{x:1330,y:852,t:1527627954085};\\\", \\\"{x:1331,y:851,t:1527627954102};\\\", \\\"{x:1331,y:850,t:1527627954119};\\\", \\\"{x:1331,y:849,t:1527627954135};\\\", \\\"{x:1333,y:848,t:1527627954153};\\\", \\\"{x:1333,y:847,t:1527627954170};\\\", \\\"{x:1333,y:846,t:1527627954186};\\\", \\\"{x:1334,y:845,t:1527627954214};\\\", \\\"{x:1334,y:843,t:1527627954238};\\\", \\\"{x:1335,y:842,t:1527627954261};\\\", \\\"{x:1336,y:841,t:1527627954278};\\\", \\\"{x:1336,y:840,t:1527627954302};\\\", \\\"{x:1336,y:838,t:1527627954325};\\\", \\\"{x:1337,y:838,t:1527627954341};\\\", \\\"{x:1337,y:837,t:1527627954358};\\\", \\\"{x:1337,y:836,t:1527627954374};\\\", \\\"{x:1337,y:835,t:1527627954387};\\\", \\\"{x:1339,y:833,t:1527627954402};\\\", \\\"{x:1339,y:832,t:1527627954430};\\\", \\\"{x:1339,y:831,t:1527627954446};\\\", \\\"{x:1340,y:830,t:1527627954453};\\\", \\\"{x:1340,y:828,t:1527627954470};\\\", \\\"{x:1341,y:828,t:1527627954487};\\\", \\\"{x:1341,y:827,t:1527627954503};\\\", \\\"{x:1342,y:826,t:1527627954525};\\\", \\\"{x:1342,y:825,t:1527627954542};\\\", \\\"{x:1342,y:824,t:1527627954566};\\\", \\\"{x:1343,y:824,t:1527627954574};\\\", \\\"{x:1343,y:823,t:1527627954588};\\\", \\\"{x:1344,y:822,t:1527627954602};\\\", \\\"{x:1344,y:821,t:1527627954619};\\\", \\\"{x:1345,y:820,t:1527627954636};\\\", \\\"{x:1345,y:819,t:1527627954661};\\\", \\\"{x:1345,y:818,t:1527627954669};\\\", \\\"{x:1345,y:817,t:1527627954701};\\\", \\\"{x:1346,y:817,t:1527627954716};\\\", \\\"{x:1346,y:816,t:1527627954740};\\\", \\\"{x:1346,y:815,t:1527627954757};\\\", \\\"{x:1346,y:814,t:1527627954773};\\\", \\\"{x:1347,y:813,t:1527627954786};\\\", \\\"{x:1348,y:812,t:1527627954803};\\\", \\\"{x:1348,y:811,t:1527627954819};\\\", \\\"{x:1350,y:808,t:1527627954836};\\\", \\\"{x:1351,y:805,t:1527627954854};\\\", \\\"{x:1352,y:802,t:1527627954869};\\\", \\\"{x:1353,y:800,t:1527627954886};\\\", \\\"{x:1354,y:798,t:1527627954903};\\\", \\\"{x:1355,y:794,t:1527627954918};\\\", \\\"{x:1357,y:792,t:1527627954935};\\\", \\\"{x:1359,y:788,t:1527627954953};\\\", \\\"{x:1360,y:783,t:1527627954969};\\\", \\\"{x:1363,y:779,t:1527627954986};\\\", \\\"{x:1365,y:776,t:1527627955003};\\\", \\\"{x:1366,y:774,t:1527627955019};\\\", \\\"{x:1368,y:770,t:1527627955036};\\\", \\\"{x:1369,y:769,t:1527627955053};\\\", \\\"{x:1370,y:768,t:1527627955069};\\\", \\\"{x:1370,y:767,t:1527627955086};\\\", \\\"{x:1370,y:766,t:1527627955103};\\\", \\\"{x:1371,y:766,t:1527627956782};\\\", \\\"{x:1377,y:760,t:1527627956790};\\\", \\\"{x:1389,y:755,t:1527627956804};\\\", \\\"{x:1456,y:717,t:1527627956820};\\\", \\\"{x:1538,y:685,t:1527627956838};\\\", \\\"{x:1625,y:635,t:1527627956854};\\\", \\\"{x:1710,y:588,t:1527627956871};\\\", \\\"{x:1768,y:547,t:1527627956888};\\\", \\\"{x:1805,y:520,t:1527627956904};\\\", \\\"{x:1821,y:506,t:1527627956921};\\\", \\\"{x:1825,y:501,t:1527627956938};\\\", \\\"{x:1826,y:499,t:1527627956954};\\\", \\\"{x:1826,y:497,t:1527627957142};\\\", \\\"{x:1824,y:496,t:1527627957155};\\\", \\\"{x:1823,y:496,t:1527627957171};\\\", \\\"{x:1821,y:495,t:1527627957189};\\\", \\\"{x:1820,y:495,t:1527627957205};\\\", \\\"{x:1810,y:496,t:1527627957221};\\\", \\\"{x:1804,y:498,t:1527627957239};\\\", \\\"{x:1801,y:500,t:1527627957256};\\\", \\\"{x:1797,y:501,t:1527627957271};\\\", \\\"{x:1792,y:504,t:1527627957289};\\\", \\\"{x:1787,y:505,t:1527627957305};\\\", \\\"{x:1783,y:508,t:1527627957321};\\\", \\\"{x:1779,y:509,t:1527627957339};\\\", \\\"{x:1774,y:511,t:1527627957355};\\\", \\\"{x:1770,y:513,t:1527627957372};\\\", \\\"{x:1767,y:514,t:1527627957389};\\\", \\\"{x:1762,y:518,t:1527627957404};\\\", \\\"{x:1757,y:520,t:1527627957421};\\\", \\\"{x:1750,y:526,t:1527627957437};\\\", \\\"{x:1744,y:531,t:1527627957455};\\\", \\\"{x:1737,y:538,t:1527627957471};\\\", \\\"{x:1730,y:546,t:1527627957488};\\\", \\\"{x:1725,y:555,t:1527627957505};\\\", \\\"{x:1718,y:564,t:1527627957521};\\\", \\\"{x:1712,y:575,t:1527627957538};\\\", \\\"{x:1704,y:584,t:1527627957555};\\\", \\\"{x:1699,y:592,t:1527627957571};\\\", \\\"{x:1692,y:601,t:1527627957588};\\\", \\\"{x:1687,y:610,t:1527627957604};\\\", \\\"{x:1686,y:612,t:1527627957622};\\\", \\\"{x:1684,y:615,t:1527627957638};\\\", \\\"{x:1682,y:617,t:1527627957656};\\\", \\\"{x:1681,y:618,t:1527627957672};\\\", \\\"{x:1680,y:618,t:1527627957688};\\\", \\\"{x:1678,y:618,t:1527627957705};\\\", \\\"{x:1677,y:620,t:1527627957723};\\\", \\\"{x:1675,y:621,t:1527627957739};\\\", \\\"{x:1674,y:621,t:1527627957755};\\\", \\\"{x:1672,y:621,t:1527627957772};\\\", \\\"{x:1670,y:621,t:1527627957788};\\\", \\\"{x:1664,y:621,t:1527627957805};\\\", \\\"{x:1653,y:617,t:1527627957822};\\\", \\\"{x:1640,y:614,t:1527627957838};\\\", \\\"{x:1636,y:613,t:1527627957855};\\\", \\\"{x:1634,y:612,t:1527627957872};\\\", \\\"{x:1632,y:612,t:1527627957888};\\\", \\\"{x:1631,y:611,t:1527627957909};\\\", \\\"{x:1629,y:612,t:1527627957981};\\\", \\\"{x:1629,y:615,t:1527627957989};\\\", \\\"{x:1625,y:630,t:1527627958005};\\\", \\\"{x:1623,y:652,t:1527627958022};\\\", \\\"{x:1619,y:683,t:1527627958038};\\\", \\\"{x:1615,y:723,t:1527627958055};\\\", \\\"{x:1612,y:754,t:1527627958072};\\\", \\\"{x:1607,y:778,t:1527627958089};\\\", \\\"{x:1606,y:791,t:1527627958105};\\\", \\\"{x:1603,y:801,t:1527627958122};\\\", \\\"{x:1603,y:802,t:1527627958139};\\\", \\\"{x:1603,y:800,t:1527627958206};\\\", \\\"{x:1601,y:785,t:1527627958222};\\\", \\\"{x:1599,y:765,t:1527627958239};\\\", \\\"{x:1597,y:742,t:1527627958255};\\\", \\\"{x:1597,y:722,t:1527627958273};\\\", \\\"{x:1597,y:708,t:1527627958289};\\\", \\\"{x:1597,y:693,t:1527627958305};\\\", \\\"{x:1597,y:680,t:1527627958322};\\\", \\\"{x:1597,y:668,t:1527627958339};\\\", \\\"{x:1599,y:655,t:1527627958355};\\\", \\\"{x:1601,y:643,t:1527627958372};\\\", \\\"{x:1604,y:633,t:1527627958389};\\\", \\\"{x:1606,y:626,t:1527627958405};\\\", \\\"{x:1607,y:622,t:1527627958423};\\\", \\\"{x:1609,y:619,t:1527627958439};\\\", \\\"{x:1609,y:617,t:1527627958455};\\\", \\\"{x:1610,y:614,t:1527627958472};\\\", \\\"{x:1610,y:611,t:1527627958490};\\\", \\\"{x:1611,y:607,t:1527627958506};\\\", \\\"{x:1613,y:600,t:1527627958522};\\\", \\\"{x:1614,y:595,t:1527627958539};\\\", \\\"{x:1614,y:589,t:1527627958556};\\\", \\\"{x:1615,y:585,t:1527627958573};\\\", \\\"{x:1615,y:582,t:1527627958590};\\\", \\\"{x:1615,y:580,t:1527627958646};\\\", \\\"{x:1615,y:577,t:1527627958669};\\\", \\\"{x:1614,y:577,t:1527627958678};\\\", \\\"{x:1614,y:576,t:1527627958822};\\\", \\\"{x:1613,y:575,t:1527627958950};\\\", \\\"{x:1612,y:575,t:1527627959006};\\\", \\\"{x:1611,y:575,t:1527627959023};\\\", \\\"{x:1610,y:575,t:1527627959382};\\\", \\\"{x:1608,y:575,t:1527627959398};\\\", \\\"{x:1607,y:575,t:1527627959407};\\\", \\\"{x:1598,y:575,t:1527627959423};\\\", \\\"{x:1580,y:575,t:1527627959441};\\\", \\\"{x:1556,y:575,t:1527627959456};\\\", \\\"{x:1526,y:575,t:1527627959473};\\\", \\\"{x:1478,y:575,t:1527627959491};\\\", \\\"{x:1414,y:575,t:1527627959507};\\\", \\\"{x:1339,y:575,t:1527627959524};\\\", \\\"{x:1283,y:575,t:1527627959541};\\\", \\\"{x:1208,y:575,t:1527627959557};\\\", \\\"{x:1097,y:575,t:1527627959573};\\\", \\\"{x:1032,y:575,t:1527627959590};\\\", \\\"{x:977,y:575,t:1527627959606};\\\", \\\"{x:935,y:575,t:1527627959623};\\\", \\\"{x:906,y:575,t:1527627959640};\\\", \\\"{x:879,y:575,t:1527627959656};\\\", \\\"{x:853,y:575,t:1527627959673};\\\", \\\"{x:833,y:575,t:1527627959690};\\\", \\\"{x:815,y:575,t:1527627959707};\\\", \\\"{x:801,y:575,t:1527627959722};\\\", \\\"{x:792,y:575,t:1527627959740};\\\", \\\"{x:776,y:576,t:1527627959757};\\\", \\\"{x:763,y:578,t:1527627959773};\\\", \\\"{x:752,y:579,t:1527627959790};\\\", \\\"{x:735,y:580,t:1527627959807};\\\", \\\"{x:716,y:584,t:1527627959824};\\\", \\\"{x:696,y:586,t:1527627959839};\\\", \\\"{x:680,y:589,t:1527627959857};\\\", \\\"{x:666,y:591,t:1527627959873};\\\", \\\"{x:653,y:592,t:1527627959890};\\\", \\\"{x:641,y:594,t:1527627959906};\\\", \\\"{x:632,y:594,t:1527627959923};\\\", \\\"{x:623,y:594,t:1527627959940};\\\", \\\"{x:615,y:594,t:1527627959956};\\\", \\\"{x:594,y:594,t:1527627959973};\\\", \\\"{x:576,y:591,t:1527627959990};\\\", \\\"{x:552,y:587,t:1527627960006};\\\", \\\"{x:524,y:583,t:1527627960023};\\\", \\\"{x:492,y:576,t:1527627960040};\\\", \\\"{x:465,y:572,t:1527627960057};\\\", \\\"{x:451,y:570,t:1527627960073};\\\", \\\"{x:436,y:567,t:1527627960089};\\\", \\\"{x:428,y:566,t:1527627960105};\\\", \\\"{x:423,y:566,t:1527627960123};\\\", \\\"{x:421,y:565,t:1527627960140};\\\", \\\"{x:420,y:565,t:1527627960188};\\\", \\\"{x:419,y:565,t:1527627960205};\\\", \\\"{x:418,y:565,t:1527627960213};\\\", \\\"{x:417,y:565,t:1527627960223};\\\", \\\"{x:413,y:565,t:1527627960240};\\\", \\\"{x:409,y:565,t:1527627960257};\\\", \\\"{x:405,y:565,t:1527627960273};\\\", \\\"{x:400,y:566,t:1527627960290};\\\", \\\"{x:393,y:567,t:1527627960308};\\\", \\\"{x:380,y:568,t:1527627960323};\\\", \\\"{x:366,y:571,t:1527627960340};\\\", \\\"{x:356,y:572,t:1527627960356};\\\", \\\"{x:348,y:572,t:1527627960372};\\\", \\\"{x:337,y:573,t:1527627960390};\\\", \\\"{x:328,y:575,t:1527627960408};\\\", \\\"{x:319,y:577,t:1527627960423};\\\", \\\"{x:311,y:578,t:1527627960440};\\\", \\\"{x:301,y:579,t:1527627960457};\\\", \\\"{x:290,y:580,t:1527627960473};\\\", \\\"{x:273,y:581,t:1527627960490};\\\", \\\"{x:255,y:585,t:1527627960508};\\\", \\\"{x:242,y:587,t:1527627960523};\\\", \\\"{x:235,y:588,t:1527627960540};\\\", \\\"{x:228,y:589,t:1527627960557};\\\", \\\"{x:226,y:590,t:1527627960573};\\\", \\\"{x:225,y:591,t:1527627960590};\\\", \\\"{x:223,y:591,t:1527627960608};\\\", \\\"{x:220,y:593,t:1527627960624};\\\", \\\"{x:219,y:594,t:1527627960640};\\\", \\\"{x:215,y:594,t:1527627960657};\\\", \\\"{x:211,y:597,t:1527627960674};\\\", \\\"{x:208,y:600,t:1527627960690};\\\", \\\"{x:205,y:602,t:1527627960708};\\\", \\\"{x:199,y:606,t:1527627960724};\\\", \\\"{x:196,y:609,t:1527627960740};\\\", \\\"{x:191,y:613,t:1527627960758};\\\", \\\"{x:188,y:615,t:1527627960773};\\\", \\\"{x:185,y:620,t:1527627960790};\\\", \\\"{x:182,y:622,t:1527627960807};\\\", \\\"{x:181,y:623,t:1527627960824};\\\", \\\"{x:181,y:625,t:1527627960840};\\\", \\\"{x:180,y:626,t:1527627960857};\\\", \\\"{x:180,y:627,t:1527627960874};\\\", \\\"{x:180,y:628,t:1527627960890};\\\", \\\"{x:179,y:628,t:1527627960907};\\\", \\\"{x:179,y:629,t:1527627960925};\\\", \\\"{x:178,y:630,t:1527627960949};\\\", \\\"{x:179,y:630,t:1527627961309};\\\", \\\"{x:183,y:632,t:1527627961324};\\\", \\\"{x:212,y:643,t:1527627961341};\\\", \\\"{x:233,y:651,t:1527627961357};\\\", \\\"{x:258,y:658,t:1527627961374};\\\", \\\"{x:282,y:663,t:1527627961391};\\\", \\\"{x:307,y:668,t:1527627961407};\\\", \\\"{x:331,y:672,t:1527627961424};\\\", \\\"{x:347,y:674,t:1527627961441};\\\", \\\"{x:362,y:676,t:1527627961457};\\\", \\\"{x:379,y:678,t:1527627961475};\\\", \\\"{x:388,y:679,t:1527627961491};\\\", \\\"{x:392,y:679,t:1527627961507};\\\", \\\"{x:396,y:679,t:1527627961524};\\\", \\\"{x:401,y:679,t:1527627961541};\\\", \\\"{x:402,y:679,t:1527627961557};\\\", \\\"{x:406,y:679,t:1527627961574};\\\", \\\"{x:414,y:680,t:1527627961591};\\\", \\\"{x:428,y:684,t:1527627961608};\\\", \\\"{x:441,y:688,t:1527627961624};\\\", \\\"{x:450,y:692,t:1527627961641};\\\", \\\"{x:460,y:696,t:1527627961657};\\\", \\\"{x:468,y:699,t:1527627961674};\\\", \\\"{x:482,y:707,t:1527627961692};\\\", \\\"{x:496,y:713,t:1527627961709};\\\", \\\"{x:508,y:718,t:1527627961724};\\\", \\\"{x:513,y:721,t:1527627961741};\\\", \\\"{x:514,y:722,t:1527627961758};\\\" ] }, { \\\"rt\\\": 11509, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 223889, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:722,t:1527627963941};\\\", \\\"{x:518,y:719,t:1527627963949};\\\", \\\"{x:521,y:715,t:1527627963959};\\\", \\\"{x:530,y:705,t:1527627963976};\\\", \\\"{x:541,y:693,t:1527627963993};\\\", \\\"{x:556,y:681,t:1527627964009};\\\", \\\"{x:566,y:672,t:1527627964026};\\\", \\\"{x:576,y:664,t:1527627964043};\\\", \\\"{x:584,y:655,t:1527627964060};\\\", \\\"{x:595,y:643,t:1527627964077};\\\", \\\"{x:608,y:629,t:1527627964093};\\\", \\\"{x:615,y:615,t:1527627964110};\\\", \\\"{x:622,y:603,t:1527627964126};\\\", \\\"{x:629,y:592,t:1527627964143};\\\", \\\"{x:632,y:584,t:1527627964160};\\\", \\\"{x:636,y:577,t:1527627964176};\\\", \\\"{x:637,y:573,t:1527627964194};\\\", \\\"{x:638,y:571,t:1527627964210};\\\", \\\"{x:638,y:570,t:1527627964226};\\\", \\\"{x:638,y:568,t:1527627964244};\\\", \\\"{x:638,y:567,t:1527627964260};\\\", \\\"{x:638,y:565,t:1527627964276};\\\", \\\"{x:636,y:563,t:1527627964293};\\\", \\\"{x:630,y:560,t:1527627964310};\\\", \\\"{x:625,y:558,t:1527627964327};\\\", \\\"{x:617,y:553,t:1527627964343};\\\", \\\"{x:606,y:546,t:1527627964360};\\\", \\\"{x:593,y:539,t:1527627964377};\\\", \\\"{x:585,y:535,t:1527627964394};\\\", \\\"{x:582,y:531,t:1527627964410};\\\", \\\"{x:580,y:530,t:1527627964426};\\\", \\\"{x:576,y:529,t:1527627964443};\\\", \\\"{x:574,y:527,t:1527627964460};\\\", \\\"{x:571,y:526,t:1527627964476};\\\", \\\"{x:567,y:523,t:1527627964493};\\\", \\\"{x:564,y:521,t:1527627964510};\\\", \\\"{x:561,y:520,t:1527627964527};\\\", \\\"{x:558,y:518,t:1527627964544};\\\", \\\"{x:552,y:514,t:1527627964560};\\\", \\\"{x:545,y:510,t:1527627964577};\\\", \\\"{x:536,y:505,t:1527627964594};\\\", \\\"{x:526,y:498,t:1527627964610};\\\", \\\"{x:517,y:491,t:1527627964626};\\\", \\\"{x:513,y:487,t:1527627964644};\\\", \\\"{x:507,y:483,t:1527627964660};\\\", \\\"{x:505,y:481,t:1527627964677};\\\", \\\"{x:502,y:478,t:1527627964693};\\\", \\\"{x:501,y:476,t:1527627964711};\\\", \\\"{x:499,y:474,t:1527627964726};\\\", \\\"{x:498,y:473,t:1527627964744};\\\", \\\"{x:496,y:471,t:1527627964761};\\\", \\\"{x:495,y:471,t:1527627964781};\\\", \\\"{x:494,y:470,t:1527627964815};\\\", \\\"{x:493,y:469,t:1527627964838};\\\", \\\"{x:492,y:469,t:1527627964862};\\\", \\\"{x:493,y:468,t:1527627965270};\\\", \\\"{x:498,y:465,t:1527627965277};\\\", \\\"{x:506,y:462,t:1527627965294};\\\", \\\"{x:515,y:457,t:1527627965311};\\\", \\\"{x:523,y:454,t:1527627965327};\\\", \\\"{x:531,y:451,t:1527627965344};\\\", \\\"{x:543,y:448,t:1527627965359};\\\", \\\"{x:555,y:447,t:1527627965377};\\\", \\\"{x:569,y:446,t:1527627965394};\\\", \\\"{x:584,y:446,t:1527627965409};\\\", \\\"{x:605,y:446,t:1527627965427};\\\", \\\"{x:637,y:446,t:1527627965443};\\\", \\\"{x:681,y:449,t:1527627965460};\\\", \\\"{x:745,y:460,t:1527627965477};\\\", \\\"{x:866,y:489,t:1527627965493};\\\", \\\"{x:944,y:514,t:1527627965511};\\\", \\\"{x:1017,y:533,t:1527627965527};\\\", \\\"{x:1081,y:553,t:1527627965545};\\\", \\\"{x:1124,y:567,t:1527627965561};\\\", \\\"{x:1167,y:582,t:1527627965578};\\\", \\\"{x:1194,y:593,t:1527627965594};\\\", \\\"{x:1220,y:605,t:1527627965611};\\\", \\\"{x:1242,y:615,t:1527627965628};\\\", \\\"{x:1258,y:625,t:1527627965645};\\\", \\\"{x:1279,y:638,t:1527627965661};\\\", \\\"{x:1293,y:649,t:1527627965678};\\\", \\\"{x:1301,y:657,t:1527627965695};\\\", \\\"{x:1309,y:667,t:1527627965711};\\\", \\\"{x:1315,y:677,t:1527627965728};\\\", \\\"{x:1319,y:684,t:1527627965745};\\\", \\\"{x:1320,y:687,t:1527627965761};\\\", \\\"{x:1322,y:693,t:1527627965778};\\\", \\\"{x:1324,y:704,t:1527627965795};\\\", \\\"{x:1328,y:717,t:1527627965812};\\\", \\\"{x:1333,y:734,t:1527627965828};\\\", \\\"{x:1337,y:751,t:1527627965845};\\\", \\\"{x:1340,y:768,t:1527627965861};\\\", \\\"{x:1342,y:774,t:1527627965878};\\\", \\\"{x:1342,y:776,t:1527627965894};\\\", \\\"{x:1341,y:780,t:1527627965912};\\\", \\\"{x:1339,y:784,t:1527627965927};\\\", \\\"{x:1334,y:790,t:1527627965945};\\\", \\\"{x:1331,y:794,t:1527627965962};\\\", \\\"{x:1324,y:803,t:1527627965978};\\\", \\\"{x:1315,y:813,t:1527627965995};\\\", \\\"{x:1303,y:820,t:1527627966012};\\\", \\\"{x:1287,y:829,t:1527627966028};\\\", \\\"{x:1273,y:837,t:1527627966045};\\\", \\\"{x:1254,y:847,t:1527627966061};\\\", \\\"{x:1244,y:852,t:1527627966077};\\\", \\\"{x:1235,y:856,t:1527627966095};\\\", \\\"{x:1230,y:856,t:1527627966112};\\\", \\\"{x:1226,y:858,t:1527627966129};\\\", \\\"{x:1224,y:859,t:1527627966145};\\\", \\\"{x:1221,y:859,t:1527627966161};\\\", \\\"{x:1219,y:859,t:1527627966179};\\\", \\\"{x:1218,y:859,t:1527627966195};\\\", \\\"{x:1215,y:859,t:1527627966212};\\\", \\\"{x:1214,y:859,t:1527627966229};\\\", \\\"{x:1213,y:859,t:1527627966262};\\\", \\\"{x:1211,y:858,t:1527627966279};\\\", \\\"{x:1210,y:856,t:1527627966309};\\\", \\\"{x:1209,y:855,t:1527627966325};\\\", \\\"{x:1208,y:854,t:1527627966341};\\\", \\\"{x:1208,y:853,t:1527627966349};\\\", \\\"{x:1207,y:852,t:1527627966373};\\\", \\\"{x:1207,y:851,t:1527627966389};\\\", \\\"{x:1206,y:850,t:1527627966438};\\\", \\\"{x:1205,y:848,t:1527627966462};\\\", \\\"{x:1205,y:846,t:1527627966479};\\\", \\\"{x:1204,y:845,t:1527627966501};\\\", \\\"{x:1204,y:844,t:1527627966558};\\\", \\\"{x:1204,y:843,t:1527627966934};\\\", \\\"{x:1204,y:842,t:1527627966946};\\\", \\\"{x:1204,y:839,t:1527627966962};\\\", \\\"{x:1204,y:837,t:1527627966979};\\\", \\\"{x:1204,y:835,t:1527627966996};\\\", \\\"{x:1204,y:834,t:1527627967012};\\\", \\\"{x:1204,y:832,t:1527627967029};\\\", \\\"{x:1205,y:831,t:1527627967086};\\\", \\\"{x:1206,y:829,t:1527627967118};\\\", \\\"{x:1207,y:829,t:1527627967142};\\\", \\\"{x:1207,y:828,t:1527627967158};\\\", \\\"{x:1208,y:827,t:1527627967215};\\\", \\\"{x:1208,y:826,t:1527627967245};\\\", \\\"{x:1209,y:826,t:1527627967264};\\\", \\\"{x:1209,y:825,t:1527627967279};\\\", \\\"{x:1209,y:824,t:1527627967296};\\\", \\\"{x:1211,y:822,t:1527627967313};\\\", \\\"{x:1212,y:822,t:1527627967328};\\\", \\\"{x:1213,y:821,t:1527627968845};\\\", \\\"{x:1215,y:821,t:1527627968853};\\\", \\\"{x:1218,y:821,t:1527627968864};\\\", \\\"{x:1220,y:821,t:1527627968880};\\\", \\\"{x:1222,y:821,t:1527627968897};\\\", \\\"{x:1226,y:822,t:1527627968914};\\\", \\\"{x:1232,y:822,t:1527627968930};\\\", \\\"{x:1237,y:823,t:1527627968947};\\\", \\\"{x:1244,y:825,t:1527627968964};\\\", \\\"{x:1247,y:825,t:1527627968980};\\\", \\\"{x:1251,y:827,t:1527627968997};\\\", \\\"{x:1255,y:828,t:1527627969013};\\\", \\\"{x:1259,y:830,t:1527627969030};\\\", \\\"{x:1269,y:835,t:1527627969047};\\\", \\\"{x:1282,y:840,t:1527627969064};\\\", \\\"{x:1293,y:845,t:1527627969080};\\\", \\\"{x:1304,y:852,t:1527627969096};\\\", \\\"{x:1311,y:854,t:1527627969114};\\\", \\\"{x:1321,y:860,t:1527627969129};\\\", \\\"{x:1329,y:864,t:1527627969147};\\\", \\\"{x:1335,y:868,t:1527627969163};\\\", \\\"{x:1339,y:871,t:1527627969180};\\\", \\\"{x:1344,y:874,t:1527627969198};\\\", \\\"{x:1345,y:875,t:1527627969215};\\\", \\\"{x:1346,y:876,t:1527627969230};\\\", \\\"{x:1347,y:877,t:1527627969261};\\\", \\\"{x:1348,y:877,t:1527627969270};\\\", \\\"{x:1348,y:878,t:1527627969280};\\\", \\\"{x:1351,y:881,t:1527627969297};\\\", \\\"{x:1354,y:882,t:1527627969314};\\\", \\\"{x:1357,y:885,t:1527627969329};\\\", \\\"{x:1358,y:886,t:1527627969347};\\\", \\\"{x:1359,y:887,t:1527627969365};\\\", \\\"{x:1360,y:887,t:1527627969380};\\\", \\\"{x:1360,y:888,t:1527627969397};\\\", \\\"{x:1361,y:888,t:1527627969416};\\\", \\\"{x:1362,y:890,t:1527627969431};\\\", \\\"{x:1363,y:891,t:1527627969447};\\\", \\\"{x:1363,y:892,t:1527627969478};\\\", \\\"{x:1362,y:892,t:1527627969605};\\\", \\\"{x:1361,y:892,t:1527627969622};\\\", \\\"{x:1360,y:892,t:1527627969630};\\\", \\\"{x:1358,y:892,t:1527627969646};\\\", \\\"{x:1357,y:891,t:1527627969664};\\\", \\\"{x:1355,y:891,t:1527627970045};\\\", \\\"{x:1354,y:891,t:1527627970070};\\\", \\\"{x:1353,y:892,t:1527627970094};\\\", \\\"{x:1353,y:893,t:1527627970125};\\\", \\\"{x:1353,y:894,t:1527627970136};\\\", \\\"{x:1352,y:895,t:1527627970173};\\\", \\\"{x:1352,y:896,t:1527627970374};\\\", \\\"{x:1352,y:897,t:1527627970381};\\\", \\\"{x:1352,y:898,t:1527627970398};\\\", \\\"{x:1352,y:899,t:1527627970415};\\\", \\\"{x:1352,y:900,t:1527627970430};\\\", \\\"{x:1351,y:902,t:1527627970449};\\\", \\\"{x:1351,y:903,t:1527627970494};\\\", \\\"{x:1351,y:904,t:1527627970534};\\\", \\\"{x:1351,y:905,t:1527627970646};\\\", \\\"{x:1351,y:906,t:1527627970653};\\\", \\\"{x:1350,y:906,t:1527627970669};\\\", \\\"{x:1350,y:907,t:1527627970693};\\\", \\\"{x:1348,y:908,t:1527627970701};\\\", \\\"{x:1345,y:909,t:1527627970726};\\\", \\\"{x:1341,y:909,t:1527627970733};\\\", \\\"{x:1335,y:909,t:1527627970749};\\\", \\\"{x:1288,y:891,t:1527627970765};\\\", \\\"{x:1214,y:852,t:1527627970781};\\\", \\\"{x:1118,y:814,t:1527627970798};\\\", \\\"{x:1016,y:769,t:1527627970815};\\\", \\\"{x:957,y:751,t:1527627970831};\\\", \\\"{x:932,y:745,t:1527627970848};\\\", \\\"{x:918,y:740,t:1527627970865};\\\", \\\"{x:913,y:737,t:1527627970881};\\\", \\\"{x:909,y:734,t:1527627970898};\\\", \\\"{x:906,y:731,t:1527627970915};\\\", \\\"{x:904,y:727,t:1527627970932};\\\", \\\"{x:902,y:721,t:1527627970948};\\\", \\\"{x:900,y:714,t:1527627970965};\\\", \\\"{x:898,y:707,t:1527627970981};\\\", \\\"{x:898,y:702,t:1527627970998};\\\", \\\"{x:897,y:699,t:1527627971015};\\\", \\\"{x:897,y:698,t:1527627971031};\\\", \\\"{x:900,y:695,t:1527627971048};\\\", \\\"{x:905,y:692,t:1527627971065};\\\", \\\"{x:913,y:688,t:1527627971082};\\\", \\\"{x:919,y:684,t:1527627971097};\\\", \\\"{x:921,y:681,t:1527627971115};\\\", \\\"{x:922,y:678,t:1527627971132};\\\", \\\"{x:923,y:675,t:1527627971148};\\\", \\\"{x:923,y:672,t:1527627971165};\\\", \\\"{x:923,y:671,t:1527627971181};\\\", \\\"{x:923,y:666,t:1527627971198};\\\", \\\"{x:921,y:659,t:1527627971215};\\\", \\\"{x:914,y:651,t:1527627971231};\\\", \\\"{x:906,y:645,t:1527627971248};\\\", \\\"{x:902,y:642,t:1527627971265};\\\", \\\"{x:896,y:640,t:1527627971282};\\\", \\\"{x:884,y:634,t:1527627971297};\\\", \\\"{x:871,y:629,t:1527627971315};\\\", \\\"{x:859,y:623,t:1527627971332};\\\", \\\"{x:852,y:621,t:1527627971348};\\\", \\\"{x:843,y:618,t:1527627971365};\\\", \\\"{x:830,y:614,t:1527627971382};\\\", \\\"{x:818,y:614,t:1527627971398};\\\", \\\"{x:809,y:614,t:1527627971415};\\\", \\\"{x:797,y:614,t:1527627971432};\\\", \\\"{x:782,y:615,t:1527627971449};\\\", \\\"{x:766,y:619,t:1527627971465};\\\", \\\"{x:754,y:622,t:1527627971482};\\\", \\\"{x:741,y:626,t:1527627971499};\\\", \\\"{x:732,y:628,t:1527627971515};\\\", \\\"{x:722,y:631,t:1527627971533};\\\", \\\"{x:697,y:634,t:1527627971548};\\\", \\\"{x:679,y:634,t:1527627971564};\\\", \\\"{x:661,y:634,t:1527627971582};\\\", \\\"{x:650,y:634,t:1527627971594};\\\", \\\"{x:625,y:634,t:1527627971611};\\\", \\\"{x:589,y:634,t:1527627971628};\\\", \\\"{x:512,y:632,t:1527627971649};\\\", \\\"{x:443,y:621,t:1527627971667};\\\", \\\"{x:376,y:612,t:1527627971683};\\\", \\\"{x:332,y:606,t:1527627971698};\\\", \\\"{x:303,y:605,t:1527627971715};\\\", \\\"{x:272,y:602,t:1527627971733};\\\", \\\"{x:255,y:602,t:1527627971749};\\\", \\\"{x:248,y:602,t:1527627971765};\\\", \\\"{x:243,y:602,t:1527627971782};\\\", \\\"{x:241,y:602,t:1527627971800};\\\", \\\"{x:239,y:602,t:1527627971816};\\\", \\\"{x:238,y:602,t:1527627971833};\\\", \\\"{x:236,y:603,t:1527627971849};\\\", \\\"{x:234,y:603,t:1527627971867};\\\", \\\"{x:229,y:605,t:1527627971882};\\\", \\\"{x:223,y:608,t:1527627971900};\\\", \\\"{x:221,y:610,t:1527627971917};\\\", \\\"{x:220,y:611,t:1527627971933};\\\", \\\"{x:220,y:612,t:1527627971950};\\\", \\\"{x:219,y:612,t:1527627971997};\\\", \\\"{x:219,y:613,t:1527627972016};\\\", \\\"{x:217,y:614,t:1527627972034};\\\", \\\"{x:215,y:615,t:1527627972050};\\\", \\\"{x:211,y:616,t:1527627972067};\\\", \\\"{x:208,y:617,t:1527627972082};\\\", \\\"{x:202,y:618,t:1527627972100};\\\", \\\"{x:189,y:618,t:1527627972117};\\\", \\\"{x:177,y:618,t:1527627972132};\\\", \\\"{x:161,y:612,t:1527627972150};\\\", \\\"{x:145,y:603,t:1527627972166};\\\", \\\"{x:138,y:601,t:1527627972183};\\\", \\\"{x:135,y:598,t:1527627972200};\\\", \\\"{x:134,y:598,t:1527627972216};\\\", \\\"{x:131,y:596,t:1527627972233};\\\", \\\"{x:128,y:592,t:1527627972249};\\\", \\\"{x:124,y:587,t:1527627972266};\\\", \\\"{x:121,y:578,t:1527627972283};\\\", \\\"{x:118,y:569,t:1527627972300};\\\", \\\"{x:116,y:563,t:1527627972316};\\\", \\\"{x:116,y:562,t:1527627972332};\\\", \\\"{x:116,y:561,t:1527627972350};\\\", \\\"{x:118,y:559,t:1527627972366};\\\", \\\"{x:127,y:555,t:1527627972384};\\\", \\\"{x:133,y:554,t:1527627972400};\\\", \\\"{x:139,y:554,t:1527627972417};\\\", \\\"{x:140,y:554,t:1527627972433};\\\", \\\"{x:142,y:554,t:1527627972449};\\\", \\\"{x:143,y:554,t:1527627972493};\\\", \\\"{x:144,y:555,t:1527627972501};\\\", \\\"{x:145,y:555,t:1527627972533};\\\", \\\"{x:147,y:555,t:1527627972830};\\\", \\\"{x:150,y:558,t:1527627972838};\\\", \\\"{x:153,y:559,t:1527627972850};\\\", \\\"{x:165,y:564,t:1527627972867};\\\", \\\"{x:185,y:575,t:1527627972884};\\\", \\\"{x:212,y:589,t:1527627972901};\\\", \\\"{x:229,y:597,t:1527627972916};\\\", \\\"{x:253,y:609,t:1527627972934};\\\", \\\"{x:283,y:623,t:1527627972951};\\\", \\\"{x:306,y:633,t:1527627972967};\\\", \\\"{x:328,y:643,t:1527627972983};\\\", \\\"{x:347,y:652,t:1527627973001};\\\", \\\"{x:362,y:658,t:1527627973017};\\\", \\\"{x:366,y:660,t:1527627973034};\\\", \\\"{x:371,y:663,t:1527627973051};\\\", \\\"{x:377,y:666,t:1527627973066};\\\", \\\"{x:386,y:673,t:1527627973084};\\\", \\\"{x:391,y:675,t:1527627973100};\\\", \\\"{x:388,y:675,t:1527627973182};\\\", \\\"{x:380,y:672,t:1527627973189};\\\", \\\"{x:362,y:661,t:1527627973201};\\\", \\\"{x:312,y:628,t:1527627973218};\\\", \\\"{x:273,y:603,t:1527627973234};\\\", \\\"{x:240,y:583,t:1527627973252};\\\", \\\"{x:224,y:574,t:1527627973268};\\\", \\\"{x:216,y:570,t:1527627973283};\\\", \\\"{x:207,y:568,t:1527627973301};\\\", \\\"{x:203,y:565,t:1527627973317};\\\", \\\"{x:196,y:565,t:1527627973334};\\\", \\\"{x:192,y:564,t:1527627973350};\\\", \\\"{x:191,y:564,t:1527627973422};\\\", \\\"{x:189,y:564,t:1527627973435};\\\", \\\"{x:188,y:564,t:1527627973450};\\\", \\\"{x:187,y:564,t:1527627973468};\\\", \\\"{x:186,y:564,t:1527627973484};\\\", \\\"{x:182,y:564,t:1527627973500};\\\", \\\"{x:175,y:561,t:1527627973518};\\\", \\\"{x:169,y:561,t:1527627973534};\\\", \\\"{x:166,y:561,t:1527627973551};\\\", \\\"{x:165,y:561,t:1527627973568};\\\", \\\"{x:164,y:561,t:1527627973584};\\\", \\\"{x:162,y:560,t:1527627973601};\\\", \\\"{x:159,y:558,t:1527627973617};\\\", \\\"{x:158,y:558,t:1527627973634};\\\", \\\"{x:162,y:559,t:1527627973908};\\\", \\\"{x:169,y:561,t:1527627973918};\\\", \\\"{x:181,y:567,t:1527627973935};\\\", \\\"{x:197,y:576,t:1527627973951};\\\", \\\"{x:213,y:585,t:1527627973968};\\\", \\\"{x:234,y:599,t:1527627973984};\\\", \\\"{x:253,y:612,t:1527627974000};\\\", \\\"{x:274,y:625,t:1527627974019};\\\", \\\"{x:297,y:636,t:1527627974035};\\\", \\\"{x:322,y:650,t:1527627974051};\\\", \\\"{x:347,y:664,t:1527627974068};\\\", \\\"{x:376,y:675,t:1527627974084};\\\", \\\"{x:392,y:681,t:1527627974100};\\\", \\\"{x:403,y:687,t:1527627974118};\\\", \\\"{x:417,y:692,t:1527627974135};\\\", \\\"{x:429,y:698,t:1527627974152};\\\", \\\"{x:435,y:701,t:1527627974168};\\\", \\\"{x:436,y:701,t:1527627974184};\\\", \\\"{x:438,y:702,t:1527627974201};\\\", \\\"{x:442,y:705,t:1527627974218};\\\", \\\"{x:449,y:709,t:1527627974235};\\\", \\\"{x:458,y:713,t:1527627974252};\\\", \\\"{x:470,y:717,t:1527627974268};\\\", \\\"{x:482,y:720,t:1527627974284};\\\", \\\"{x:487,y:722,t:1527627974300};\\\", \\\"{x:492,y:722,t:1527627974317};\\\", \\\"{x:494,y:722,t:1527627974349};\\\", \\\"{x:495,y:723,t:1527627974365};\\\", \\\"{x:497,y:723,t:1527627974568};\\\", \\\"{x:497,y:723,t:1527627974716};\\\" ] }, { \\\"rt\\\": 9108, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 234222, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:718,t:1527627976302};\\\", \\\"{x:498,y:680,t:1527627976374};\\\", \\\"{x:498,y:675,t:1527627976387};\\\", \\\"{x:498,y:670,t:1527627976403};\\\", \\\"{x:498,y:664,t:1527627976419};\\\", \\\"{x:498,y:661,t:1527627976436};\\\", \\\"{x:498,y:659,t:1527627976453};\\\", \\\"{x:498,y:658,t:1527627976470};\\\", \\\"{x:498,y:657,t:1527627976493};\\\", \\\"{x:498,y:656,t:1527627976524};\\\", \\\"{x:498,y:654,t:1527627976549};\\\", \\\"{x:497,y:650,t:1527627976904};\\\", \\\"{x:495,y:642,t:1527627976919};\\\", \\\"{x:494,y:637,t:1527627976936};\\\", \\\"{x:493,y:628,t:1527627976954};\\\", \\\"{x:492,y:621,t:1527627976969};\\\", \\\"{x:490,y:610,t:1527627976987};\\\", \\\"{x:486,y:596,t:1527627977003};\\\", \\\"{x:485,y:582,t:1527627977020};\\\", \\\"{x:479,y:559,t:1527627977037};\\\", \\\"{x:478,y:547,t:1527627977054};\\\", \\\"{x:478,y:538,t:1527627977071};\\\", \\\"{x:478,y:528,t:1527627977087};\\\", \\\"{x:478,y:515,t:1527627977103};\\\", \\\"{x:478,y:502,t:1527627977121};\\\", \\\"{x:478,y:488,t:1527627977136};\\\", \\\"{x:478,y:476,t:1527627977154};\\\", \\\"{x:478,y:465,t:1527627977171};\\\", \\\"{x:478,y:454,t:1527627977187};\\\", \\\"{x:478,y:448,t:1527627977204};\\\", \\\"{x:478,y:441,t:1527627977221};\\\", \\\"{x:479,y:440,t:1527627977237};\\\", \\\"{x:483,y:440,t:1527627977501};\\\", \\\"{x:495,y:440,t:1527627977510};\\\", \\\"{x:509,y:440,t:1527627977521};\\\", \\\"{x:531,y:442,t:1527627977538};\\\", \\\"{x:558,y:450,t:1527627977554};\\\", \\\"{x:594,y:462,t:1527627977571};\\\", \\\"{x:633,y:472,t:1527627977588};\\\", \\\"{x:672,y:483,t:1527627977604};\\\", \\\"{x:710,y:493,t:1527627977621};\\\", \\\"{x:732,y:499,t:1527627977638};\\\", \\\"{x:748,y:504,t:1527627977654};\\\", \\\"{x:762,y:508,t:1527627977672};\\\", \\\"{x:768,y:510,t:1527627977687};\\\", \\\"{x:770,y:510,t:1527627977704};\\\", \\\"{x:773,y:510,t:1527627977918};\\\", \\\"{x:776,y:510,t:1527627977925};\\\", \\\"{x:781,y:510,t:1527627977938};\\\", \\\"{x:800,y:510,t:1527627977953};\\\", \\\"{x:825,y:511,t:1527627977971};\\\", \\\"{x:855,y:516,t:1527627977988};\\\", \\\"{x:893,y:521,t:1527627978004};\\\", \\\"{x:959,y:531,t:1527627978021};\\\", \\\"{x:1005,y:541,t:1527627978038};\\\", \\\"{x:1049,y:546,t:1527627978054};\\\", \\\"{x:1077,y:550,t:1527627978071};\\\", \\\"{x:1095,y:554,t:1527627978088};\\\", \\\"{x:1113,y:559,t:1527627978105};\\\", \\\"{x:1122,y:560,t:1527627978121};\\\", \\\"{x:1128,y:561,t:1527627978138};\\\", \\\"{x:1131,y:563,t:1527627978155};\\\", \\\"{x:1135,y:564,t:1527627978172};\\\", \\\"{x:1140,y:564,t:1527627978189};\\\", \\\"{x:1147,y:567,t:1527627978205};\\\", \\\"{x:1152,y:571,t:1527627978221};\\\", \\\"{x:1158,y:575,t:1527627978239};\\\", \\\"{x:1164,y:580,t:1527627978255};\\\", \\\"{x:1167,y:583,t:1527627978271};\\\", \\\"{x:1174,y:589,t:1527627978288};\\\", \\\"{x:1182,y:597,t:1527627978305};\\\", \\\"{x:1193,y:604,t:1527627978322};\\\", \\\"{x:1203,y:611,t:1527627978338};\\\", \\\"{x:1214,y:619,t:1527627978355};\\\", \\\"{x:1226,y:628,t:1527627978371};\\\", \\\"{x:1243,y:639,t:1527627978388};\\\", \\\"{x:1270,y:655,t:1527627978405};\\\", \\\"{x:1292,y:667,t:1527627978422};\\\", \\\"{x:1319,y:681,t:1527627978438};\\\", \\\"{x:1357,y:703,t:1527627978455};\\\", \\\"{x:1393,y:724,t:1527627978471};\\\", \\\"{x:1425,y:741,t:1527627978489};\\\", \\\"{x:1448,y:754,t:1527627978506};\\\", \\\"{x:1469,y:766,t:1527627978521};\\\", \\\"{x:1488,y:777,t:1527627978538};\\\", \\\"{x:1504,y:788,t:1527627978555};\\\", \\\"{x:1522,y:799,t:1527627978571};\\\", \\\"{x:1533,y:808,t:1527627978588};\\\", \\\"{x:1545,y:826,t:1527627978605};\\\", \\\"{x:1553,y:842,t:1527627978622};\\\", \\\"{x:1558,y:857,t:1527627978638};\\\", \\\"{x:1560,y:867,t:1527627978656};\\\", \\\"{x:1560,y:876,t:1527627978672};\\\", \\\"{x:1560,y:884,t:1527627978688};\\\", \\\"{x:1557,y:891,t:1527627978704};\\\", \\\"{x:1555,y:899,t:1527627978722};\\\", \\\"{x:1552,y:908,t:1527627978737};\\\", \\\"{x:1550,y:916,t:1527627978754};\\\", \\\"{x:1550,y:920,t:1527627978772};\\\", \\\"{x:1548,y:924,t:1527627978788};\\\", \\\"{x:1547,y:929,t:1527627978805};\\\", \\\"{x:1546,y:930,t:1527627978822};\\\", \\\"{x:1546,y:931,t:1527627978844};\\\", \\\"{x:1546,y:932,t:1527627978860};\\\", \\\"{x:1545,y:934,t:1527627978893};\\\", \\\"{x:1544,y:934,t:1527627978917};\\\", \\\"{x:1544,y:935,t:1527627978925};\\\", \\\"{x:1544,y:936,t:1527627978939};\\\", \\\"{x:1542,y:938,t:1527627978956};\\\", \\\"{x:1539,y:941,t:1527627978973};\\\", \\\"{x:1537,y:944,t:1527627978988};\\\", \\\"{x:1535,y:945,t:1527627979005};\\\", \\\"{x:1534,y:946,t:1527627979023};\\\", \\\"{x:1533,y:946,t:1527627979069};\\\", \\\"{x:1532,y:946,t:1527627979086};\\\", \\\"{x:1531,y:946,t:1527627979141};\\\", \\\"{x:1530,y:946,t:1527627979155};\\\", \\\"{x:1529,y:947,t:1527627979172};\\\", \\\"{x:1527,y:947,t:1527627979190};\\\", \\\"{x:1525,y:947,t:1527627979205};\\\", \\\"{x:1524,y:947,t:1527627979262};\\\", \\\"{x:1524,y:948,t:1527627979272};\\\", \\\"{x:1523,y:948,t:1527627979289};\\\", \\\"{x:1521,y:949,t:1527627979306};\\\", \\\"{x:1521,y:950,t:1527627979322};\\\", \\\"{x:1520,y:950,t:1527627979339};\\\", \\\"{x:1519,y:951,t:1527627979355};\\\", \\\"{x:1518,y:952,t:1527627979373};\\\", \\\"{x:1518,y:953,t:1527627979397};\\\", \\\"{x:1516,y:954,t:1527627979421};\\\", \\\"{x:1516,y:955,t:1527627979445};\\\", \\\"{x:1515,y:956,t:1527627979455};\\\", \\\"{x:1514,y:957,t:1527627979485};\\\", \\\"{x:1513,y:958,t:1527627979493};\\\", \\\"{x:1512,y:959,t:1527627979533};\\\", \\\"{x:1512,y:961,t:1527627979566};\\\", \\\"{x:1510,y:962,t:1527627979589};\\\", \\\"{x:1510,y:963,t:1527627979638};\\\", \\\"{x:1509,y:963,t:1527627979701};\\\", \\\"{x:1508,y:963,t:1527627979717};\\\", \\\"{x:1507,y:963,t:1527627979732};\\\", \\\"{x:1507,y:964,t:1527627979740};\\\", \\\"{x:1506,y:964,t:1527627979765};\\\", \\\"{x:1505,y:964,t:1527627979844};\\\", \\\"{x:1502,y:962,t:1527627979856};\\\", \\\"{x:1499,y:957,t:1527627979872};\\\", \\\"{x:1491,y:948,t:1527627979889};\\\", \\\"{x:1484,y:938,t:1527627979906};\\\", \\\"{x:1478,y:926,t:1527627979922};\\\", \\\"{x:1473,y:914,t:1527627979939};\\\", \\\"{x:1469,y:905,t:1527627979956};\\\", \\\"{x:1468,y:900,t:1527627979972};\\\", \\\"{x:1467,y:896,t:1527627979989};\\\", \\\"{x:1467,y:895,t:1527627980007};\\\", \\\"{x:1467,y:893,t:1527627980023};\\\", \\\"{x:1467,y:891,t:1527627980039};\\\", \\\"{x:1467,y:888,t:1527627980057};\\\", \\\"{x:1467,y:887,t:1527627980073};\\\", \\\"{x:1468,y:884,t:1527627980089};\\\", \\\"{x:1470,y:881,t:1527627980106};\\\", \\\"{x:1471,y:878,t:1527627980123};\\\", \\\"{x:1474,y:874,t:1527627980139};\\\", \\\"{x:1477,y:871,t:1527627980156};\\\", \\\"{x:1481,y:864,t:1527627980173};\\\", \\\"{x:1483,y:859,t:1527627980189};\\\", \\\"{x:1485,y:855,t:1527627980206};\\\", \\\"{x:1487,y:853,t:1527627980223};\\\", \\\"{x:1489,y:850,t:1527627980239};\\\", \\\"{x:1491,y:847,t:1527627980256};\\\", \\\"{x:1492,y:844,t:1527627980273};\\\", \\\"{x:1493,y:842,t:1527627980289};\\\", \\\"{x:1493,y:841,t:1527627980307};\\\", \\\"{x:1495,y:836,t:1527627980323};\\\", \\\"{x:1495,y:835,t:1527627980339};\\\", \\\"{x:1495,y:831,t:1527627980357};\\\", \\\"{x:1495,y:827,t:1527627980373};\\\", \\\"{x:1495,y:825,t:1527627980390};\\\", \\\"{x:1495,y:824,t:1527627980406};\\\", \\\"{x:1495,y:822,t:1527627980423};\\\", \\\"{x:1495,y:821,t:1527627980440};\\\", \\\"{x:1495,y:820,t:1527627980461};\\\", \\\"{x:1494,y:819,t:1527627980485};\\\", \\\"{x:1493,y:819,t:1527627980501};\\\", \\\"{x:1492,y:819,t:1527627980525};\\\", \\\"{x:1492,y:818,t:1527627980540};\\\", \\\"{x:1490,y:818,t:1527627980557};\\\", \\\"{x:1489,y:818,t:1527627980613};\\\", \\\"{x:1486,y:818,t:1527627980662};\\\", \\\"{x:1484,y:819,t:1527627980942};\\\", \\\"{x:1483,y:819,t:1527627980957};\\\", \\\"{x:1482,y:821,t:1527627980974};\\\", \\\"{x:1480,y:821,t:1527627980991};\\\", \\\"{x:1478,y:822,t:1527627981007};\\\", \\\"{x:1476,y:823,t:1527627981023};\\\", \\\"{x:1475,y:823,t:1527627981042};\\\", \\\"{x:1474,y:824,t:1527627981058};\\\", \\\"{x:1473,y:825,t:1527627981074};\\\", \\\"{x:1472,y:825,t:1527627981109};\\\", \\\"{x:1470,y:826,t:1527627981141};\\\", \\\"{x:1469,y:828,t:1527627981190};\\\", \\\"{x:1469,y:829,t:1527627981238};\\\", \\\"{x:1469,y:830,t:1527627981278};\\\", \\\"{x:1465,y:831,t:1527627981590};\\\", \\\"{x:1439,y:822,t:1527627981608};\\\", \\\"{x:1386,y:800,t:1527627981625};\\\", \\\"{x:1307,y:771,t:1527627981641};\\\", \\\"{x:1211,y:733,t:1527627981658};\\\", \\\"{x:1120,y:708,t:1527627981674};\\\", \\\"{x:1023,y:682,t:1527627981691};\\\", \\\"{x:912,y:652,t:1527627981708};\\\", \\\"{x:815,y:622,t:1527627981724};\\\", \\\"{x:751,y:612,t:1527627981743};\\\", \\\"{x:695,y:601,t:1527627981758};\\\", \\\"{x:678,y:598,t:1527627981774};\\\", \\\"{x:671,y:596,t:1527627981791};\\\", \\\"{x:670,y:595,t:1527627981807};\\\", \\\"{x:669,y:600,t:1527627981997};\\\", \\\"{x:669,y:606,t:1527627982008};\\\", \\\"{x:668,y:619,t:1527627982025};\\\", \\\"{x:664,y:628,t:1527627982042};\\\", \\\"{x:664,y:631,t:1527627982058};\\\", \\\"{x:662,y:633,t:1527627982074};\\\", \\\"{x:662,y:634,t:1527627982091};\\\", \\\"{x:662,y:635,t:1527627982109};\\\", \\\"{x:655,y:633,t:1527627982245};\\\", \\\"{x:646,y:629,t:1527627982258};\\\", \\\"{x:627,y:622,t:1527627982275};\\\", \\\"{x:613,y:615,t:1527627982293};\\\", \\\"{x:605,y:612,t:1527627982310};\\\", \\\"{x:603,y:611,t:1527627982326};\\\", \\\"{x:603,y:610,t:1527627982509};\\\", \\\"{x:604,y:610,t:1527627982525};\\\", \\\"{x:605,y:609,t:1527627982542};\\\", \\\"{x:606,y:609,t:1527627982558};\\\", \\\"{x:600,y:615,t:1527627982918};\\\", \\\"{x:595,y:621,t:1527627982927};\\\", \\\"{x:589,y:633,t:1527627982941};\\\", \\\"{x:583,y:642,t:1527627982958};\\\", \\\"{x:579,y:647,t:1527627982975};\\\", \\\"{x:575,y:651,t:1527627982991};\\\", \\\"{x:570,y:660,t:1527627983008};\\\", \\\"{x:564,y:668,t:1527627983025};\\\", \\\"{x:560,y:672,t:1527627983042};\\\", \\\"{x:559,y:673,t:1527627983058};\\\", \\\"{x:559,y:674,t:1527627983075};\\\", \\\"{x:560,y:674,t:1527627983117};\\\", \\\"{x:566,y:672,t:1527627983125};\\\", \\\"{x:583,y:663,t:1527627983142};\\\", \\\"{x:599,y:651,t:1527627983158};\\\", \\\"{x:613,y:638,t:1527627983176};\\\", \\\"{x:621,y:631,t:1527627983192};\\\", \\\"{x:622,y:628,t:1527627983208};\\\", \\\"{x:622,y:627,t:1527627983422};\\\", \\\"{x:622,y:624,t:1527627983429};\\\", \\\"{x:622,y:622,t:1527627983442};\\\", \\\"{x:621,y:618,t:1527627983460};\\\", \\\"{x:619,y:615,t:1527627983476};\\\", \\\"{x:617,y:613,t:1527627983492};\\\", \\\"{x:616,y:610,t:1527627983509};\\\", \\\"{x:615,y:610,t:1527627983621};\\\", \\\"{x:613,y:608,t:1527627983630};\\\", \\\"{x:612,y:608,t:1527627983642};\\\", \\\"{x:606,y:605,t:1527627983659};\\\", \\\"{x:601,y:603,t:1527627983675};\\\", \\\"{x:599,y:602,t:1527627983692};\\\", \\\"{x:599,y:603,t:1527627984182};\\\", \\\"{x:596,y:610,t:1527627984193};\\\", \\\"{x:589,y:629,t:1527627984210};\\\", \\\"{x:579,y:650,t:1527627984226};\\\", \\\"{x:569,y:671,t:1527627984243};\\\", \\\"{x:554,y:692,t:1527627984259};\\\", \\\"{x:531,y:718,t:1527627984276};\\\", \\\"{x:514,y:731,t:1527627984292};\\\", \\\"{x:503,y:738,t:1527627984310};\\\", \\\"{x:497,y:743,t:1527627984326};\\\", \\\"{x:492,y:746,t:1527627984343};\\\", \\\"{x:489,y:748,t:1527627984359};\\\", \\\"{x:489,y:746,t:1527627984605};\\\", \\\"{x:489,y:743,t:1527627984613};\\\", \\\"{x:489,y:741,t:1527627984626};\\\", \\\"{x:489,y:735,t:1527627984644};\\\", \\\"{x:489,y:731,t:1527627984659};\\\", \\\"{x:489,y:730,t:1527627984685};\\\" ] }, { \\\"rt\\\": 59385, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 294809, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:489,y:727,t:1527627987326};\\\", \\\"{x:477,y:685,t:1527627987342};\\\", \\\"{x:471,y:666,t:1527627987348};\\\", \\\"{x:469,y:653,t:1527627987362};\\\", \\\"{x:466,y:626,t:1527627987379};\\\", \\\"{x:465,y:600,t:1527627987395};\\\", \\\"{x:458,y:569,t:1527627987413};\\\", \\\"{x:452,y:548,t:1527627987428};\\\", \\\"{x:450,y:538,t:1527627987445};\\\", \\\"{x:449,y:529,t:1527627987463};\\\", \\\"{x:448,y:523,t:1527627987478};\\\", \\\"{x:447,y:520,t:1527627987495};\\\", \\\"{x:446,y:518,t:1527627987513};\\\", \\\"{x:444,y:515,t:1527627987529};\\\", \\\"{x:444,y:513,t:1527627987545};\\\", \\\"{x:444,y:512,t:1527627987562};\\\", \\\"{x:444,y:508,t:1527627987718};\\\", \\\"{x:444,y:505,t:1527627987730};\\\", \\\"{x:442,y:502,t:1527627987746};\\\", \\\"{x:442,y:499,t:1527627987762};\\\", \\\"{x:441,y:497,t:1527627987779};\\\", \\\"{x:441,y:496,t:1527627987797};\\\", \\\"{x:441,y:495,t:1527627987830};\\\", \\\"{x:441,y:493,t:1527627987893};\\\", \\\"{x:441,y:492,t:1527627988086};\\\", \\\"{x:440,y:490,t:1527627988097};\\\", \\\"{x:440,y:489,t:1527627988114};\\\", \\\"{x:440,y:487,t:1527627988130};\\\", \\\"{x:440,y:486,t:1527627988147};\\\", \\\"{x:440,y:484,t:1527627988164};\\\", \\\"{x:440,y:483,t:1527627988179};\\\", \\\"{x:440,y:481,t:1527627988197};\\\", \\\"{x:440,y:480,t:1527627988214};\\\", \\\"{x:440,y:479,t:1527627988231};\\\", \\\"{x:440,y:477,t:1527627988247};\\\", \\\"{x:440,y:476,t:1527627988264};\\\", \\\"{x:440,y:474,t:1527627988285};\\\", \\\"{x:440,y:473,t:1527627988325};\\\", \\\"{x:440,y:471,t:1527627988341};\\\", \\\"{x:440,y:470,t:1527627988373};\\\", \\\"{x:440,y:469,t:1527627988381};\\\", \\\"{x:441,y:469,t:1527627988397};\\\", \\\"{x:442,y:468,t:1527627988414};\\\", \\\"{x:442,y:466,t:1527627988438};\\\", \\\"{x:443,y:466,t:1527627988453};\\\", \\\"{x:443,y:465,t:1527627988464};\\\", \\\"{x:444,y:463,t:1527627988481};\\\", \\\"{x:445,y:462,t:1527627988498};\\\", \\\"{x:446,y:461,t:1527627988514};\\\", \\\"{x:448,y:459,t:1527627988531};\\\", \\\"{x:449,y:457,t:1527627988548};\\\", \\\"{x:450,y:457,t:1527627988564};\\\", \\\"{x:453,y:455,t:1527627988581};\\\", \\\"{x:454,y:454,t:1527627988598};\\\", \\\"{x:456,y:453,t:1527627988613};\\\", \\\"{x:459,y:453,t:1527627990954};\\\", \\\"{x:468,y:454,t:1527627990965};\\\", \\\"{x:487,y:460,t:1527627990982};\\\", \\\"{x:505,y:461,t:1527627990999};\\\", \\\"{x:529,y:465,t:1527627991015};\\\", \\\"{x:555,y:468,t:1527627991032};\\\", \\\"{x:589,y:473,t:1527627991051};\\\", \\\"{x:600,y:474,t:1527627991065};\\\", \\\"{x:624,y:478,t:1527627991083};\\\", \\\"{x:634,y:479,t:1527627991099};\\\", \\\"{x:637,y:479,t:1527627991115};\\\", \\\"{x:639,y:481,t:1527627991315};\\\", \\\"{x:648,y:483,t:1527627991323};\\\", \\\"{x:659,y:484,t:1527627991332};\\\", \\\"{x:686,y:487,t:1527627991349};\\\", \\\"{x:726,y:494,t:1527627991367};\\\", \\\"{x:764,y:499,t:1527627991383};\\\", \\\"{x:823,y:508,t:1527627991399};\\\", \\\"{x:881,y:516,t:1527627991416};\\\", \\\"{x:940,y:524,t:1527627991435};\\\", \\\"{x:1004,y:534,t:1527627991450};\\\", \\\"{x:1078,y:534,t:1527627991483};\\\", \\\"{x:1089,y:535,t:1527627991495};\\\", \\\"{x:1103,y:535,t:1527627991512};\\\", \\\"{x:1112,y:538,t:1527627991529};\\\", \\\"{x:1117,y:538,t:1527627991545};\\\", \\\"{x:1121,y:539,t:1527627991562};\\\", \\\"{x:1123,y:539,t:1527627991579};\\\", \\\"{x:1125,y:539,t:1527627991594};\\\", \\\"{x:1127,y:539,t:1527627991612};\\\", \\\"{x:1130,y:539,t:1527627991629};\\\", \\\"{x:1139,y:540,t:1527627991646};\\\", \\\"{x:1150,y:542,t:1527627991662};\\\", \\\"{x:1161,y:542,t:1527627991679};\\\", \\\"{x:1175,y:542,t:1527627991695};\\\", \\\"{x:1185,y:542,t:1527627991712};\\\", \\\"{x:1191,y:542,t:1527627991729};\\\", \\\"{x:1197,y:542,t:1527627991746};\\\", \\\"{x:1200,y:542,t:1527627991762};\\\", \\\"{x:1202,y:542,t:1527627991779};\\\", \\\"{x:1203,y:541,t:1527627991797};\\\", \\\"{x:1204,y:541,t:1527627991922};\\\", \\\"{x:1205,y:540,t:1527627991930};\\\", \\\"{x:1207,y:540,t:1527627991946};\\\", \\\"{x:1209,y:539,t:1527627991962};\\\", \\\"{x:1215,y:537,t:1527627991979};\\\", \\\"{x:1220,y:536,t:1527627991996};\\\", \\\"{x:1226,y:534,t:1527627992012};\\\", \\\"{x:1229,y:534,t:1527627992029};\\\", \\\"{x:1232,y:532,t:1527627992047};\\\", \\\"{x:1236,y:531,t:1527627992063};\\\", \\\"{x:1241,y:528,t:1527627992080};\\\", \\\"{x:1244,y:527,t:1527627992096};\\\", \\\"{x:1249,y:524,t:1527627992113};\\\", \\\"{x:1253,y:523,t:1527627992130};\\\", \\\"{x:1258,y:521,t:1527627992146};\\\", \\\"{x:1260,y:520,t:1527627992163};\\\", \\\"{x:1262,y:519,t:1527627992180};\\\", \\\"{x:1267,y:517,t:1527627992196};\\\", \\\"{x:1269,y:516,t:1527627992212};\\\", \\\"{x:1271,y:515,t:1527627992229};\\\", \\\"{x:1273,y:514,t:1527627992247};\\\", \\\"{x:1274,y:513,t:1527627992264};\\\", \\\"{x:1275,y:512,t:1527627992279};\\\", \\\"{x:1277,y:512,t:1527627992296};\\\", \\\"{x:1280,y:510,t:1527627992313};\\\", \\\"{x:1281,y:510,t:1527627992330};\\\", \\\"{x:1284,y:509,t:1527627992346};\\\", \\\"{x:1285,y:508,t:1527627992371};\\\", \\\"{x:1287,y:508,t:1527627992395};\\\", \\\"{x:1288,y:507,t:1527627992402};\\\", \\\"{x:1289,y:507,t:1527627992413};\\\", \\\"{x:1290,y:506,t:1527627992429};\\\", \\\"{x:1293,y:505,t:1527627992447};\\\", \\\"{x:1296,y:504,t:1527627992464};\\\", \\\"{x:1297,y:503,t:1527627992479};\\\", \\\"{x:1298,y:503,t:1527627992497};\\\", \\\"{x:1300,y:502,t:1527627992563};\\\", \\\"{x:1301,y:502,t:1527627992587};\\\", \\\"{x:1302,y:502,t:1527627992596};\\\", \\\"{x:1303,y:501,t:1527627992627};\\\", \\\"{x:1304,y:500,t:1527627992715};\\\", \\\"{x:1306,y:500,t:1527627992738};\\\", \\\"{x:1307,y:500,t:1527627992778};\\\", \\\"{x:1308,y:499,t:1527627992797};\\\", \\\"{x:1309,y:499,t:1527627992816};\\\", \\\"{x:1311,y:498,t:1527627992865};\\\", \\\"{x:1312,y:498,t:1527627992905};\\\", \\\"{x:1313,y:497,t:1527627992970};\\\", \\\"{x:1314,y:498,t:1527627997298};\\\", \\\"{x:1318,y:511,t:1527627997317};\\\", \\\"{x:1320,y:527,t:1527627997333};\\\", \\\"{x:1324,y:540,t:1527627997350};\\\", \\\"{x:1324,y:547,t:1527627997365};\\\", \\\"{x:1326,y:553,t:1527627997382};\\\", \\\"{x:1327,y:557,t:1527627997400};\\\", \\\"{x:1328,y:558,t:1527627997416};\\\", \\\"{x:1328,y:562,t:1527627997432};\\\", \\\"{x:1330,y:566,t:1527627997451};\\\", \\\"{x:1331,y:568,t:1527627997467};\\\", \\\"{x:1331,y:571,t:1527627997483};\\\", \\\"{x:1331,y:574,t:1527627997500};\\\", \\\"{x:1332,y:578,t:1527627997517};\\\", \\\"{x:1332,y:582,t:1527627997533};\\\", \\\"{x:1332,y:588,t:1527627997550};\\\", \\\"{x:1332,y:592,t:1527627997567};\\\", \\\"{x:1332,y:596,t:1527627997583};\\\", \\\"{x:1332,y:601,t:1527627997599};\\\", \\\"{x:1332,y:604,t:1527627997616};\\\", \\\"{x:1332,y:607,t:1527627997633};\\\", \\\"{x:1332,y:610,t:1527627997651};\\\", \\\"{x:1332,y:612,t:1527627997667};\\\", \\\"{x:1331,y:615,t:1527627997683};\\\", \\\"{x:1331,y:617,t:1527627997700};\\\", \\\"{x:1330,y:621,t:1527627997717};\\\", \\\"{x:1330,y:624,t:1527627997732};\\\", \\\"{x:1329,y:626,t:1527627997749};\\\", \\\"{x:1329,y:629,t:1527627997767};\\\", \\\"{x:1329,y:632,t:1527627997783};\\\", \\\"{x:1329,y:634,t:1527627997799};\\\", \\\"{x:1326,y:638,t:1527627997816};\\\", \\\"{x:1326,y:641,t:1527627997833};\\\", \\\"{x:1323,y:648,t:1527627997851};\\\", \\\"{x:1321,y:652,t:1527627997867};\\\", \\\"{x:1320,y:658,t:1527627997883};\\\", \\\"{x:1319,y:662,t:1527627997900};\\\", \\\"{x:1317,y:667,t:1527627997917};\\\", \\\"{x:1317,y:670,t:1527627997933};\\\", \\\"{x:1316,y:671,t:1527627997949};\\\", \\\"{x:1314,y:675,t:1527627997967};\\\", \\\"{x:1314,y:677,t:1527627997983};\\\", \\\"{x:1312,y:680,t:1527627998000};\\\", \\\"{x:1312,y:684,t:1527627998017};\\\", \\\"{x:1312,y:688,t:1527627998033};\\\", \\\"{x:1310,y:695,t:1527627998051};\\\", \\\"{x:1310,y:698,t:1527627998067};\\\", \\\"{x:1309,y:702,t:1527627998084};\\\", \\\"{x:1309,y:704,t:1527627998100};\\\", \\\"{x:1309,y:706,t:1527627998116};\\\", \\\"{x:1309,y:708,t:1527627998133};\\\", \\\"{x:1308,y:709,t:1527627998149};\\\", \\\"{x:1308,y:712,t:1527627998166};\\\", \\\"{x:1307,y:714,t:1527627998184};\\\", \\\"{x:1307,y:715,t:1527627998200};\\\", \\\"{x:1307,y:718,t:1527627998217};\\\", \\\"{x:1307,y:721,t:1527627998234};\\\", \\\"{x:1307,y:724,t:1527627998251};\\\", \\\"{x:1307,y:725,t:1527627998266};\\\", \\\"{x:1305,y:727,t:1527627998284};\\\", \\\"{x:1305,y:729,t:1527627998299};\\\", \\\"{x:1305,y:730,t:1527627998317};\\\", \\\"{x:1305,y:731,t:1527627998371};\\\", \\\"{x:1305,y:732,t:1527627998386};\\\", \\\"{x:1305,y:733,t:1527627998403};\\\", \\\"{x:1305,y:734,t:1527627998426};\\\", \\\"{x:1305,y:735,t:1527627998467};\\\", \\\"{x:1305,y:736,t:1527627998484};\\\", \\\"{x:1305,y:737,t:1527627998499};\\\", \\\"{x:1305,y:739,t:1527627998517};\\\", \\\"{x:1305,y:740,t:1527627998534};\\\", \\\"{x:1305,y:743,t:1527627998550};\\\", \\\"{x:1305,y:744,t:1527627998570};\\\", \\\"{x:1305,y:745,t:1527627998584};\\\", \\\"{x:1305,y:747,t:1527627998600};\\\", \\\"{x:1306,y:749,t:1527627998617};\\\", \\\"{x:1306,y:752,t:1527627998633};\\\", \\\"{x:1306,y:754,t:1527627998651};\\\", \\\"{x:1306,y:756,t:1527627998667};\\\", \\\"{x:1306,y:758,t:1527627998683};\\\", \\\"{x:1306,y:759,t:1527627998699};\\\", \\\"{x:1308,y:761,t:1527627998717};\\\", \\\"{x:1308,y:763,t:1527627998734};\\\", \\\"{x:1308,y:766,t:1527627998751};\\\", \\\"{x:1308,y:767,t:1527627998770};\\\", \\\"{x:1308,y:768,t:1527627998784};\\\", \\\"{x:1308,y:769,t:1527627998800};\\\", \\\"{x:1309,y:770,t:1527627998817};\\\", \\\"{x:1309,y:772,t:1527627998834};\\\", \\\"{x:1309,y:774,t:1527627998851};\\\", \\\"{x:1309,y:775,t:1527627998867};\\\", \\\"{x:1310,y:777,t:1527627998883};\\\", \\\"{x:1310,y:778,t:1527627998900};\\\", \\\"{x:1310,y:780,t:1527627998916};\\\", \\\"{x:1310,y:781,t:1527627998954};\\\", \\\"{x:1310,y:782,t:1527627998966};\\\", \\\"{x:1311,y:783,t:1527627998984};\\\", \\\"{x:1311,y:784,t:1527627999000};\\\", \\\"{x:1311,y:786,t:1527627999018};\\\", \\\"{x:1311,y:787,t:1527627999034};\\\", \\\"{x:1312,y:789,t:1527627999058};\\\", \\\"{x:1312,y:791,t:1527627999074};\\\", \\\"{x:1312,y:792,t:1527627999083};\\\", \\\"{x:1312,y:795,t:1527627999100};\\\", \\\"{x:1313,y:800,t:1527627999116};\\\", \\\"{x:1313,y:803,t:1527627999133};\\\", \\\"{x:1313,y:807,t:1527627999151};\\\", \\\"{x:1315,y:811,t:1527627999167};\\\", \\\"{x:1315,y:814,t:1527627999183};\\\", \\\"{x:1315,y:817,t:1527627999200};\\\", \\\"{x:1315,y:820,t:1527627999217};\\\", \\\"{x:1315,y:822,t:1527627999234};\\\", \\\"{x:1316,y:828,t:1527627999251};\\\", \\\"{x:1316,y:829,t:1527627999268};\\\", \\\"{x:1316,y:831,t:1527627999284};\\\", \\\"{x:1316,y:833,t:1527627999300};\\\", \\\"{x:1316,y:835,t:1527627999318};\\\", \\\"{x:1316,y:837,t:1527627999333};\\\", \\\"{x:1316,y:838,t:1527627999351};\\\", \\\"{x:1316,y:841,t:1527627999368};\\\", \\\"{x:1316,y:843,t:1527627999384};\\\", \\\"{x:1316,y:844,t:1527627999402};\\\", \\\"{x:1316,y:846,t:1527627999418};\\\", \\\"{x:1316,y:847,t:1527627999434};\\\", \\\"{x:1316,y:850,t:1527627999451};\\\", \\\"{x:1316,y:853,t:1527627999467};\\\", \\\"{x:1316,y:854,t:1527627999491};\\\", \\\"{x:1316,y:855,t:1527627999501};\\\", \\\"{x:1316,y:857,t:1527627999518};\\\", \\\"{x:1316,y:860,t:1527627999533};\\\", \\\"{x:1316,y:862,t:1527627999551};\\\", \\\"{x:1316,y:866,t:1527627999568};\\\", \\\"{x:1315,y:868,t:1527627999583};\\\", \\\"{x:1314,y:870,t:1527627999600};\\\", \\\"{x:1314,y:872,t:1527627999617};\\\", \\\"{x:1314,y:875,t:1527627999633};\\\", \\\"{x:1314,y:878,t:1527627999650};\\\", \\\"{x:1314,y:881,t:1527627999667};\\\", \\\"{x:1314,y:883,t:1527627999684};\\\", \\\"{x:1314,y:886,t:1527627999701};\\\", \\\"{x:1312,y:889,t:1527627999717};\\\", \\\"{x:1312,y:891,t:1527627999733};\\\", \\\"{x:1312,y:894,t:1527627999750};\\\", \\\"{x:1312,y:896,t:1527627999767};\\\", \\\"{x:1312,y:898,t:1527627999784};\\\", \\\"{x:1311,y:900,t:1527627999801};\\\", \\\"{x:1311,y:902,t:1527627999817};\\\", \\\"{x:1311,y:903,t:1527627999835};\\\", \\\"{x:1311,y:904,t:1527627999851};\\\", \\\"{x:1311,y:905,t:1527627999868};\\\", \\\"{x:1311,y:906,t:1527627999885};\\\", \\\"{x:1311,y:907,t:1527627999906};\\\", \\\"{x:1311,y:908,t:1527627999922};\\\", \\\"{x:1311,y:909,t:1527627999934};\\\", \\\"{x:1311,y:910,t:1527627999951};\\\", \\\"{x:1311,y:912,t:1527627999968};\\\", \\\"{x:1311,y:914,t:1527627999985};\\\", \\\"{x:1311,y:915,t:1527628000000};\\\", \\\"{x:1311,y:917,t:1527628000017};\\\", \\\"{x:1311,y:920,t:1527628000034};\\\", \\\"{x:1311,y:921,t:1527628000050};\\\", \\\"{x:1311,y:923,t:1527628000068};\\\", \\\"{x:1311,y:924,t:1527628000085};\\\", \\\"{x:1311,y:926,t:1527628000106};\\\", \\\"{x:1311,y:927,t:1527628000139};\\\", \\\"{x:1311,y:929,t:1527628000151};\\\", \\\"{x:1311,y:930,t:1527628000178};\\\", \\\"{x:1311,y:931,t:1527628000186};\\\", \\\"{x:1311,y:932,t:1527628000210};\\\", \\\"{x:1311,y:933,t:1527628000243};\\\", \\\"{x:1311,y:934,t:1527628000267};\\\", \\\"{x:1311,y:935,t:1527628000285};\\\", \\\"{x:1311,y:936,t:1527628000306};\\\", \\\"{x:1311,y:937,t:1527628000318};\\\", \\\"{x:1311,y:938,t:1527628000335};\\\", \\\"{x:1311,y:940,t:1527628000352};\\\", \\\"{x:1311,y:941,t:1527628000368};\\\", \\\"{x:1311,y:942,t:1527628000387};\\\", \\\"{x:1311,y:943,t:1527628000402};\\\", \\\"{x:1311,y:944,t:1527628000418};\\\", \\\"{x:1311,y:947,t:1527628000435};\\\", \\\"{x:1311,y:948,t:1527628000453};\\\", \\\"{x:1311,y:950,t:1527628000467};\\\", \\\"{x:1311,y:951,t:1527628000484};\\\", \\\"{x:1311,y:953,t:1527628000501};\\\", \\\"{x:1311,y:954,t:1527628000517};\\\", \\\"{x:1311,y:956,t:1527628000537};\\\", \\\"{x:1311,y:957,t:1527628000562};\\\", \\\"{x:1311,y:959,t:1527628000593};\\\", \\\"{x:1311,y:960,t:1527628000642};\\\", \\\"{x:1311,y:962,t:1527628000763};\\\", \\\"{x:1311,y:963,t:1527628000812};\\\", \\\"{x:1311,y:965,t:1527628000843};\\\", \\\"{x:1311,y:966,t:1527628000857};\\\", \\\"{x:1311,y:967,t:1527628000890};\\\", \\\"{x:1311,y:968,t:1527628000902};\\\", \\\"{x:1312,y:968,t:1527628000918};\\\", \\\"{x:1312,y:969,t:1527628001139};\\\", \\\"{x:1312,y:971,t:1527628001169};\\\", \\\"{x:1313,y:972,t:1527628001523};\\\", \\\"{x:1314,y:972,t:1527628001546};\\\", \\\"{x:1315,y:972,t:1527628001579};\\\", \\\"{x:1315,y:969,t:1527628002235};\\\", \\\"{x:1315,y:968,t:1527628002253};\\\", \\\"{x:1315,y:966,t:1527628002269};\\\", \\\"{x:1315,y:965,t:1527628002286};\\\", \\\"{x:1315,y:964,t:1527628002347};\\\", \\\"{x:1315,y:965,t:1527628002931};\\\", \\\"{x:1315,y:966,t:1527628002939};\\\", \\\"{x:1315,y:967,t:1527628002963};\\\", \\\"{x:1315,y:966,t:1527628030659};\\\", \\\"{x:1316,y:946,t:1527628030670};\\\", \\\"{x:1311,y:923,t:1527628030688};\\\", \\\"{x:1310,y:922,t:1527628030703};\\\", \\\"{x:1321,y:922,t:1527628030891};\\\", \\\"{x:1343,y:928,t:1527628030903};\\\", \\\"{x:1391,y:942,t:1527628030921};\\\", \\\"{x:1428,y:949,t:1527628030937};\\\", \\\"{x:1451,y:956,t:1527628030953};\\\", \\\"{x:1479,y:962,t:1527628030970};\\\", \\\"{x:1492,y:965,t:1527628030987};\\\", \\\"{x:1497,y:967,t:1527628031003};\\\", \\\"{x:1499,y:967,t:1527628031020};\\\", \\\"{x:1499,y:968,t:1527628031066};\\\", \\\"{x:1501,y:968,t:1527628031075};\\\", \\\"{x:1503,y:968,t:1527628031087};\\\", \\\"{x:1509,y:968,t:1527628031103};\\\", \\\"{x:1514,y:968,t:1527628031120};\\\", \\\"{x:1515,y:968,t:1527628031137};\\\", \\\"{x:1517,y:968,t:1527628031177};\\\", \\\"{x:1521,y:968,t:1527628031187};\\\", \\\"{x:1527,y:968,t:1527628031203};\\\", \\\"{x:1530,y:968,t:1527628031219};\\\", \\\"{x:1531,y:968,t:1527628031237};\\\", \\\"{x:1532,y:968,t:1527628031298};\\\", \\\"{x:1533,y:967,t:1527628031411};\\\", \\\"{x:1534,y:967,t:1527628031579};\\\", \\\"{x:1536,y:967,t:1527628031594};\\\", \\\"{x:1537,y:967,t:1527628031604};\\\", \\\"{x:1538,y:967,t:1527628031626};\\\", \\\"{x:1539,y:967,t:1527628031715};\\\", \\\"{x:1540,y:967,t:1527628031730};\\\", \\\"{x:1542,y:967,t:1527628031779};\\\", \\\"{x:1542,y:966,t:1527628031995};\\\", \\\"{x:1542,y:965,t:1527628032004};\\\", \\\"{x:1542,y:961,t:1527628032021};\\\", \\\"{x:1542,y:959,t:1527628032038};\\\", \\\"{x:1542,y:957,t:1527628032054};\\\", \\\"{x:1542,y:956,t:1527628032071};\\\", \\\"{x:1542,y:955,t:1527628032097};\\\", \\\"{x:1542,y:954,t:1527628032113};\\\", \\\"{x:1542,y:952,t:1527628032129};\\\", \\\"{x:1542,y:951,t:1527628032145};\\\", \\\"{x:1542,y:950,t:1527628032162};\\\", \\\"{x:1541,y:949,t:1527628032170};\\\", \\\"{x:1541,y:948,t:1527628032187};\\\", \\\"{x:1541,y:946,t:1527628032203};\\\", \\\"{x:1540,y:945,t:1527628032221};\\\", \\\"{x:1540,y:943,t:1527628032237};\\\", \\\"{x:1539,y:940,t:1527628032254};\\\", \\\"{x:1538,y:938,t:1527628032271};\\\", \\\"{x:1537,y:935,t:1527628032287};\\\", \\\"{x:1536,y:933,t:1527628032304};\\\", \\\"{x:1535,y:930,t:1527628032321};\\\", \\\"{x:1535,y:928,t:1527628032337};\\\", \\\"{x:1532,y:924,t:1527628032354};\\\", \\\"{x:1532,y:922,t:1527628032371};\\\", \\\"{x:1531,y:919,t:1527628032388};\\\", \\\"{x:1531,y:918,t:1527628032404};\\\", \\\"{x:1531,y:916,t:1527628032422};\\\", \\\"{x:1530,y:914,t:1527628032439};\\\", \\\"{x:1530,y:913,t:1527628032454};\\\", \\\"{x:1530,y:912,t:1527628032482};\\\", \\\"{x:1530,y:911,t:1527628032498};\\\", \\\"{x:1530,y:910,t:1527628032505};\\\", \\\"{x:1530,y:908,t:1527628032531};\\\", \\\"{x:1530,y:907,t:1527628032538};\\\", \\\"{x:1530,y:905,t:1527628032561};\\\", \\\"{x:1530,y:904,t:1527628032577};\\\", \\\"{x:1531,y:903,t:1527628032587};\\\", \\\"{x:1532,y:902,t:1527628032604};\\\", \\\"{x:1533,y:902,t:1527628032625};\\\", \\\"{x:1533,y:901,t:1527628032689};\\\", \\\"{x:1534,y:901,t:1527628032754};\\\", \\\"{x:1535,y:901,t:1527628032826};\\\", \\\"{x:1536,y:901,t:1527628032838};\\\", \\\"{x:1537,y:902,t:1527628032855};\\\", \\\"{x:1539,y:903,t:1527628032871};\\\", \\\"{x:1539,y:907,t:1527628032887};\\\", \\\"{x:1540,y:913,t:1527628032904};\\\", \\\"{x:1543,y:918,t:1527628032921};\\\", \\\"{x:1544,y:924,t:1527628032937};\\\", \\\"{x:1544,y:927,t:1527628032954};\\\", \\\"{x:1544,y:929,t:1527628032970};\\\", \\\"{x:1544,y:930,t:1527628032987};\\\", \\\"{x:1544,y:932,t:1527628033005};\\\", \\\"{x:1544,y:935,t:1527628033021};\\\", \\\"{x:1544,y:937,t:1527628033038};\\\", \\\"{x:1544,y:939,t:1527628033055};\\\", \\\"{x:1544,y:942,t:1527628033071};\\\", \\\"{x:1544,y:943,t:1527628033088};\\\", \\\"{x:1544,y:946,t:1527628033105};\\\", \\\"{x:1544,y:948,t:1527628033121};\\\", \\\"{x:1544,y:949,t:1527628033138};\\\", \\\"{x:1544,y:951,t:1527628033155};\\\", \\\"{x:1544,y:954,t:1527628033171};\\\", \\\"{x:1544,y:957,t:1527628033188};\\\", \\\"{x:1544,y:960,t:1527628033205};\\\", \\\"{x:1544,y:962,t:1527628033221};\\\", \\\"{x:1544,y:964,t:1527628033238};\\\", \\\"{x:1544,y:965,t:1527628033255};\\\", \\\"{x:1544,y:967,t:1527628033271};\\\", \\\"{x:1544,y:968,t:1527628033288};\\\", \\\"{x:1545,y:967,t:1527628039059};\\\", \\\"{x:1550,y:962,t:1527628039076};\\\", \\\"{x:1552,y:960,t:1527628039092};\\\", \\\"{x:1554,y:957,t:1527628039109};\\\", \\\"{x:1553,y:959,t:1527628041434};\\\", \\\"{x:1553,y:960,t:1527628041444};\\\", \\\"{x:1552,y:963,t:1527628041460};\\\", \\\"{x:1550,y:966,t:1527628041477};\\\", \\\"{x:1549,y:968,t:1527628041494};\\\", \\\"{x:1549,y:969,t:1527628041514};\\\", \\\"{x:1548,y:970,t:1527628041526};\\\", \\\"{x:1547,y:969,t:1527628042194};\\\", \\\"{x:1547,y:967,t:1527628042212};\\\", \\\"{x:1547,y:966,t:1527628042227};\\\", \\\"{x:1547,y:965,t:1527628042243};\\\", \\\"{x:1547,y:964,t:1527628042291};\\\", \\\"{x:1546,y:964,t:1527628042803};\\\", \\\"{x:1546,y:966,t:1527628042827};\\\", \\\"{x:1545,y:969,t:1527628042834};\\\", \\\"{x:1545,y:970,t:1527628042843};\\\", \\\"{x:1544,y:974,t:1527628042861};\\\", \\\"{x:1543,y:977,t:1527628042878};\\\", \\\"{x:1542,y:978,t:1527628042895};\\\", \\\"{x:1542,y:979,t:1527628042910};\\\", \\\"{x:1540,y:979,t:1527628043210};\\\", \\\"{x:1540,y:978,t:1527628043228};\\\", \\\"{x:1540,y:975,t:1527628043245};\\\", \\\"{x:1540,y:974,t:1527628043266};\\\", \\\"{x:1540,y:972,t:1527628043315};\\\", \\\"{x:1537,y:969,t:1527628043554};\\\", \\\"{x:1527,y:965,t:1527628043562};\\\", \\\"{x:1496,y:947,t:1527628043578};\\\", \\\"{x:1443,y:924,t:1527628043595};\\\", \\\"{x:1383,y:900,t:1527628043612};\\\", \\\"{x:1328,y:876,t:1527628043628};\\\", \\\"{x:1273,y:855,t:1527628043645};\\\", \\\"{x:1222,y:837,t:1527628043662};\\\", \\\"{x:1152,y:813,t:1527628043678};\\\", \\\"{x:1066,y:789,t:1527628043695};\\\", \\\"{x:944,y:753,t:1527628043712};\\\", \\\"{x:804,y:714,t:1527628043728};\\\", \\\"{x:694,y:673,t:1527628043745};\\\", \\\"{x:619,y:634,t:1527628043763};\\\", \\\"{x:591,y:615,t:1527628043779};\\\", \\\"{x:562,y:589,t:1527628043794};\\\", \\\"{x:536,y:567,t:1527628043822};\\\", \\\"{x:518,y:550,t:1527628043839};\\\", \\\"{x:509,y:541,t:1527628043855};\\\", \\\"{x:507,y:536,t:1527628043871};\\\", \\\"{x:505,y:529,t:1527628043888};\\\", \\\"{x:504,y:520,t:1527628043905};\\\", \\\"{x:502,y:510,t:1527628043921};\\\", \\\"{x:500,y:499,t:1527628043938};\\\", \\\"{x:499,y:485,t:1527628043955};\\\", \\\"{x:499,y:468,t:1527628043972};\\\", \\\"{x:501,y:468,t:1527628044082};\\\", \\\"{x:503,y:468,t:1527628044090};\\\", \\\"{x:507,y:468,t:1527628044105};\\\", \\\"{x:514,y:468,t:1527628044123};\\\", \\\"{x:525,y:474,t:1527628044140};\\\", \\\"{x:537,y:479,t:1527628044155};\\\", \\\"{x:552,y:486,t:1527628044172};\\\", \\\"{x:564,y:494,t:1527628044190};\\\", \\\"{x:574,y:498,t:1527628044205};\\\", \\\"{x:581,y:504,t:1527628044222};\\\", \\\"{x:587,y:509,t:1527628044240};\\\", \\\"{x:592,y:513,t:1527628044257};\\\", \\\"{x:595,y:517,t:1527628044273};\\\", \\\"{x:601,y:523,t:1527628044290};\\\", \\\"{x:607,y:528,t:1527628044307};\\\", \\\"{x:611,y:530,t:1527628044322};\\\", \\\"{x:616,y:530,t:1527628044339};\\\", \\\"{x:623,y:530,t:1527628044355};\\\", \\\"{x:628,y:530,t:1527628044372};\\\", \\\"{x:629,y:530,t:1527628044389};\\\", \\\"{x:630,y:530,t:1527628044466};\\\", \\\"{x:630,y:532,t:1527628044481};\\\", \\\"{x:630,y:533,t:1527628044490};\\\", \\\"{x:630,y:535,t:1527628044505};\\\", \\\"{x:630,y:537,t:1527628044529};\\\", \\\"{x:630,y:540,t:1527628044540};\\\", \\\"{x:629,y:544,t:1527628044555};\\\", \\\"{x:629,y:553,t:1527628044574};\\\", \\\"{x:627,y:563,t:1527628044590};\\\", \\\"{x:623,y:577,t:1527628044605};\\\", \\\"{x:619,y:588,t:1527628044622};\\\", \\\"{x:615,y:596,t:1527628044639};\\\", \\\"{x:614,y:600,t:1527628044655};\\\", \\\"{x:612,y:604,t:1527628044673};\\\", \\\"{x:611,y:608,t:1527628044689};\\\", \\\"{x:609,y:610,t:1527628044706};\\\", \\\"{x:608,y:612,t:1527628044722};\\\", \\\"{x:607,y:612,t:1527628044740};\\\", \\\"{x:607,y:613,t:1527628044756};\\\", \\\"{x:606,y:614,t:1527628044772};\\\", \\\"{x:605,y:615,t:1527628045081};\\\", \\\"{x:602,y:622,t:1527628045089};\\\", \\\"{x:594,y:633,t:1527628045107};\\\", \\\"{x:584,y:647,t:1527628045123};\\\", \\\"{x:573,y:659,t:1527628045139};\\\", \\\"{x:555,y:675,t:1527628045156};\\\", \\\"{x:538,y:688,t:1527628045173};\\\", \\\"{x:522,y:699,t:1527628045189};\\\", \\\"{x:509,y:708,t:1527628045207};\\\", \\\"{x:498,y:716,t:1527628045224};\\\", \\\"{x:490,y:721,t:1527628045240};\\\", \\\"{x:485,y:723,t:1527628045256};\\\", \\\"{x:478,y:726,t:1527628045273};\\\", \\\"{x:474,y:729,t:1527628045289};\\\", \\\"{x:473,y:730,t:1527628045306};\\\", \\\"{x:472,y:730,t:1527628045681};\\\", \\\"{x:471,y:730,t:1527628045962};\\\", \\\"{x:470,y:730,t:1527628045973};\\\", \\\"{x:469,y:730,t:1527628045994};\\\", \\\"{x:467,y:730,t:1527628046025};\\\", \\\"{x:466,y:730,t:1527628046042};\\\", \\\"{x:466,y:729,t:1527628046081};\\\", \\\"{x:465,y:728,t:1527628046121};\\\", \\\"{x:465,y:727,t:1527628046849};\\\", \\\"{x:465,y:723,t:1527628046897};\\\", \\\"{x:465,y:722,t:1527628046907};\\\", \\\"{x:465,y:720,t:1527628046925};\\\", \\\"{x:465,y:716,t:1527628046940};\\\", \\\"{x:463,y:710,t:1527628046957};\\\" ] }, { \\\"rt\\\": 8455, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 304796, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:459,y:702,t:1527628047147};\\\", \\\"{x:464,y:695,t:1527628047325};\\\", \\\"{x:474,y:687,t:1527628047342};\\\", \\\"{x:487,y:678,t:1527628047357};\\\", \\\"{x:501,y:670,t:1527628047374};\\\", \\\"{x:511,y:663,t:1527628047391};\\\", \\\"{x:516,y:658,t:1527628047407};\\\", \\\"{x:519,y:656,t:1527628047424};\\\", \\\"{x:525,y:650,t:1527628047441};\\\", \\\"{x:526,y:650,t:1527628047457};\\\", \\\"{x:527,y:648,t:1527628047475};\\\", \\\"{x:528,y:647,t:1527628047497};\\\", \\\"{x:529,y:644,t:1527628047513};\\\", \\\"{x:529,y:643,t:1527628047553};\\\", \\\"{x:529,y:641,t:1527628049258};\\\", \\\"{x:537,y:634,t:1527628049266};\\\", \\\"{x:551,y:624,t:1527628049277};\\\", \\\"{x:597,y:597,t:1527628049293};\\\", \\\"{x:684,y:568,t:1527628049310};\\\", \\\"{x:761,y:535,t:1527628049327};\\\", \\\"{x:835,y:505,t:1527628049344};\\\", \\\"{x:897,y:484,t:1527628049360};\\\", \\\"{x:972,y:462,t:1527628049376};\\\", \\\"{x:1028,y:446,t:1527628049392};\\\", \\\"{x:1067,y:437,t:1527628049409};\\\", \\\"{x:1091,y:431,t:1527628049426};\\\", \\\"{x:1098,y:429,t:1527628049443};\\\", \\\"{x:1099,y:429,t:1527628049460};\\\", \\\"{x:1099,y:433,t:1527628049602};\\\", \\\"{x:1098,y:433,t:1527628049610};\\\", \\\"{x:1097,y:439,t:1527628049627};\\\", \\\"{x:1095,y:444,t:1527628049645};\\\", \\\"{x:1093,y:455,t:1527628049660};\\\", \\\"{x:1093,y:466,t:1527628049676};\\\", \\\"{x:1093,y:480,t:1527628049693};\\\", \\\"{x:1093,y:490,t:1527628049709};\\\", \\\"{x:1093,y:497,t:1527628049727};\\\", \\\"{x:1095,y:505,t:1527628049744};\\\", \\\"{x:1097,y:509,t:1527628049760};\\\", \\\"{x:1099,y:512,t:1527628049776};\\\", \\\"{x:1102,y:515,t:1527628049793};\\\", \\\"{x:1105,y:516,t:1527628049810};\\\", \\\"{x:1108,y:518,t:1527628049827};\\\", \\\"{x:1113,y:520,t:1527628049844};\\\", \\\"{x:1117,y:522,t:1527628049860};\\\", \\\"{x:1123,y:525,t:1527628049876};\\\", \\\"{x:1127,y:526,t:1527628049894};\\\", \\\"{x:1132,y:527,t:1527628049910};\\\", \\\"{x:1137,y:528,t:1527628049927};\\\", \\\"{x:1146,y:529,t:1527628049944};\\\", \\\"{x:1155,y:531,t:1527628049960};\\\", \\\"{x:1162,y:531,t:1527628049977};\\\", \\\"{x:1165,y:532,t:1527628049994};\\\", \\\"{x:1167,y:533,t:1527628050057};\\\", \\\"{x:1167,y:534,t:1527628050073};\\\", \\\"{x:1166,y:536,t:1527628050081};\\\", \\\"{x:1164,y:537,t:1527628050094};\\\", \\\"{x:1156,y:541,t:1527628050110};\\\", \\\"{x:1146,y:545,t:1527628050127};\\\", \\\"{x:1130,y:548,t:1527628050144};\\\", \\\"{x:1104,y:550,t:1527628050160};\\\", \\\"{x:1077,y:550,t:1527628050176};\\\", \\\"{x:1036,y:550,t:1527628050194};\\\", \\\"{x:1007,y:550,t:1527628050211};\\\", \\\"{x:985,y:552,t:1527628050227};\\\", \\\"{x:963,y:556,t:1527628050244};\\\", \\\"{x:941,y:557,t:1527628050259};\\\", \\\"{x:921,y:559,t:1527628050274};\\\", \\\"{x:908,y:562,t:1527628050291};\\\", \\\"{x:893,y:563,t:1527628050311};\\\", \\\"{x:878,y:566,t:1527628050324};\\\", \\\"{x:871,y:566,t:1527628050339};\\\", \\\"{x:861,y:567,t:1527628050355};\\\", \\\"{x:851,y:567,t:1527628050371};\\\", \\\"{x:835,y:567,t:1527628050391};\\\", \\\"{x:824,y:567,t:1527628050409};\\\", \\\"{x:810,y:567,t:1527628050425};\\\", \\\"{x:797,y:567,t:1527628050441};\\\", \\\"{x:788,y:567,t:1527628050458};\\\", \\\"{x:778,y:567,t:1527628050474};\\\", \\\"{x:769,y:567,t:1527628050491};\\\", \\\"{x:759,y:566,t:1527628050508};\\\", \\\"{x:748,y:565,t:1527628050526};\\\", \\\"{x:742,y:564,t:1527628050541};\\\", \\\"{x:734,y:563,t:1527628050558};\\\", \\\"{x:729,y:562,t:1527628050575};\\\", \\\"{x:722,y:561,t:1527628050591};\\\", \\\"{x:717,y:561,t:1527628050608};\\\", \\\"{x:705,y:558,t:1527628050625};\\\", \\\"{x:690,y:556,t:1527628050642};\\\", \\\"{x:677,y:555,t:1527628050659};\\\", \\\"{x:668,y:553,t:1527628050676};\\\", \\\"{x:662,y:553,t:1527628050691};\\\", \\\"{x:656,y:552,t:1527628050708};\\\", \\\"{x:647,y:551,t:1527628050725};\\\", \\\"{x:638,y:549,t:1527628050742};\\\", \\\"{x:628,y:548,t:1527628050758};\\\", \\\"{x:610,y:546,t:1527628050775};\\\", \\\"{x:599,y:544,t:1527628050792};\\\", \\\"{x:591,y:543,t:1527628050808};\\\", \\\"{x:580,y:543,t:1527628050825};\\\", \\\"{x:569,y:543,t:1527628050841};\\\", \\\"{x:557,y:543,t:1527628050858};\\\", \\\"{x:549,y:543,t:1527628050875};\\\", \\\"{x:542,y:543,t:1527628050892};\\\", \\\"{x:536,y:543,t:1527628050908};\\\", \\\"{x:532,y:543,t:1527628050925};\\\", \\\"{x:529,y:543,t:1527628050941};\\\", \\\"{x:527,y:542,t:1527628050959};\\\", \\\"{x:521,y:542,t:1527628050975};\\\", \\\"{x:516,y:542,t:1527628050992};\\\", \\\"{x:513,y:541,t:1527628051009};\\\", \\\"{x:511,y:541,t:1527628051026};\\\", \\\"{x:509,y:541,t:1527628051042};\\\", \\\"{x:504,y:541,t:1527628051059};\\\", \\\"{x:502,y:541,t:1527628051076};\\\", \\\"{x:500,y:541,t:1527628051093};\\\", \\\"{x:498,y:541,t:1527628051111};\\\", \\\"{x:495,y:541,t:1527628051125};\\\", \\\"{x:490,y:541,t:1527628051143};\\\", \\\"{x:486,y:541,t:1527628051159};\\\", \\\"{x:483,y:541,t:1527628051176};\\\", \\\"{x:480,y:542,t:1527628051192};\\\", \\\"{x:479,y:542,t:1527628051210};\\\", \\\"{x:478,y:543,t:1527628051225};\\\", \\\"{x:478,y:544,t:1527628051600};\\\", \\\"{x:479,y:545,t:1527628051610};\\\", \\\"{x:483,y:547,t:1527628051627};\\\", \\\"{x:486,y:548,t:1527628051644};\\\", \\\"{x:491,y:549,t:1527628051660};\\\", \\\"{x:494,y:549,t:1527628051677};\\\", \\\"{x:497,y:549,t:1527628051694};\\\", \\\"{x:502,y:549,t:1527628051711};\\\", \\\"{x:505,y:549,t:1527628051726};\\\", \\\"{x:511,y:549,t:1527628051742};\\\", \\\"{x:513,y:547,t:1527628051759};\\\", \\\"{x:516,y:547,t:1527628051776};\\\", \\\"{x:516,y:546,t:1527628051792};\\\", \\\"{x:517,y:546,t:1527628051810};\\\", \\\"{x:518,y:546,t:1527628051830};\\\", \\\"{x:519,y:545,t:1527628051842};\\\", \\\"{x:520,y:544,t:1527628051859};\\\", \\\"{x:524,y:541,t:1527628051875};\\\", \\\"{x:528,y:538,t:1527628051892};\\\", \\\"{x:539,y:532,t:1527628051909};\\\", \\\"{x:556,y:524,t:1527628051927};\\\", \\\"{x:585,y:513,t:1527628051943};\\\", \\\"{x:613,y:501,t:1527628051960};\\\", \\\"{x:618,y:498,t:1527628051976};\\\", \\\"{x:617,y:498,t:1527628052144};\\\", \\\"{x:615,y:498,t:1527628052176};\\\", \\\"{x:614,y:498,t:1527628052183};\\\", \\\"{x:617,y:495,t:1527628052503};\\\", \\\"{x:624,y:494,t:1527628052511};\\\", \\\"{x:635,y:493,t:1527628052527};\\\", \\\"{x:661,y:492,t:1527628052544};\\\", \\\"{x:683,y:492,t:1527628052561};\\\", \\\"{x:710,y:492,t:1527628052576};\\\", \\\"{x:732,y:497,t:1527628052594};\\\", \\\"{x:749,y:500,t:1527628052609};\\\", \\\"{x:766,y:502,t:1527628052626};\\\", \\\"{x:776,y:504,t:1527628052644};\\\", \\\"{x:782,y:506,t:1527628052661};\\\", \\\"{x:783,y:506,t:1527628052679};\\\", \\\"{x:785,y:507,t:1527628052694};\\\", \\\"{x:786,y:507,t:1527628052710};\\\", \\\"{x:787,y:508,t:1527628052726};\\\", \\\"{x:788,y:509,t:1527628052744};\\\", \\\"{x:790,y:510,t:1527628052761};\\\", \\\"{x:793,y:511,t:1527628052776};\\\", \\\"{x:795,y:513,t:1527628052793};\\\", \\\"{x:796,y:514,t:1527628052815};\\\", \\\"{x:799,y:516,t:1527628052827};\\\", \\\"{x:801,y:519,t:1527628052845};\\\", \\\"{x:807,y:523,t:1527628052861};\\\", \\\"{x:813,y:527,t:1527628052877};\\\", \\\"{x:814,y:527,t:1527628052893};\\\", \\\"{x:814,y:528,t:1527628052910};\\\", \\\"{x:815,y:529,t:1527628052926};\\\", \\\"{x:818,y:531,t:1527628052943};\\\", \\\"{x:820,y:533,t:1527628052960};\\\", \\\"{x:822,y:534,t:1527628052976};\\\", \\\"{x:822,y:536,t:1527628053416};\\\", \\\"{x:816,y:540,t:1527628053428};\\\", \\\"{x:801,y:550,t:1527628053444};\\\", \\\"{x:787,y:560,t:1527628053462};\\\", \\\"{x:771,y:571,t:1527628053478};\\\", \\\"{x:756,y:581,t:1527628053494};\\\", \\\"{x:733,y:598,t:1527628053511};\\\", \\\"{x:717,y:608,t:1527628053528};\\\", \\\"{x:703,y:617,t:1527628053545};\\\", \\\"{x:695,y:622,t:1527628053560};\\\", \\\"{x:694,y:622,t:1527628053577};\\\", \\\"{x:696,y:622,t:1527628053631};\\\", \\\"{x:703,y:621,t:1527628053645};\\\", \\\"{x:722,y:611,t:1527628053662};\\\", \\\"{x:742,y:599,t:1527628053678};\\\", \\\"{x:766,y:589,t:1527628053696};\\\", \\\"{x:794,y:573,t:1527628053710};\\\", \\\"{x:804,y:568,t:1527628053727};\\\", \\\"{x:808,y:566,t:1527628053745};\\\", \\\"{x:810,y:563,t:1527628053968};\\\", \\\"{x:810,y:561,t:1527628053980};\\\", \\\"{x:813,y:557,t:1527628053995};\\\", \\\"{x:815,y:553,t:1527628054011};\\\", \\\"{x:819,y:549,t:1527628054027};\\\", \\\"{x:821,y:548,t:1527628054045};\\\", \\\"{x:823,y:546,t:1527628054061};\\\", \\\"{x:824,y:546,t:1527628054079};\\\", \\\"{x:824,y:545,t:1527628054094};\\\", \\\"{x:826,y:545,t:1527628054127};\\\", \\\"{x:828,y:544,t:1527628054142};\\\", \\\"{x:829,y:543,t:1527628054159};\\\", \\\"{x:827,y:543,t:1527628054495};\\\", \\\"{x:817,y:547,t:1527628054512};\\\", \\\"{x:805,y:552,t:1527628054529};\\\", \\\"{x:792,y:562,t:1527628054545};\\\", \\\"{x:780,y:570,t:1527628054562};\\\", \\\"{x:769,y:578,t:1527628054579};\\\", \\\"{x:757,y:585,t:1527628054595};\\\", \\\"{x:743,y:593,t:1527628054611};\\\", \\\"{x:728,y:604,t:1527628054629};\\\", \\\"{x:715,y:611,t:1527628054645};\\\", \\\"{x:700,y:619,t:1527628054662};\\\", \\\"{x:688,y:626,t:1527628054678};\\\", \\\"{x:671,y:635,t:1527628054696};\\\", \\\"{x:659,y:642,t:1527628054712};\\\", \\\"{x:649,y:647,t:1527628054728};\\\", \\\"{x:636,y:654,t:1527628054746};\\\", \\\"{x:623,y:660,t:1527628054762};\\\", \\\"{x:612,y:664,t:1527628054779};\\\", \\\"{x:600,y:669,t:1527628054796};\\\", \\\"{x:595,y:671,t:1527628054811};\\\", \\\"{x:588,y:674,t:1527628054829};\\\", \\\"{x:581,y:677,t:1527628054846};\\\", \\\"{x:577,y:679,t:1527628054862};\\\", \\\"{x:572,y:681,t:1527628054878};\\\", \\\"{x:568,y:683,t:1527628054896};\\\", \\\"{x:566,y:683,t:1527628054912};\\\", \\\"{x:563,y:683,t:1527628054929};\\\", \\\"{x:562,y:685,t:1527628054946};\\\", \\\"{x:559,y:685,t:1527628054962};\\\", \\\"{x:555,y:687,t:1527628054979};\\\", \\\"{x:551,y:690,t:1527628054996};\\\", \\\"{x:546,y:693,t:1527628055013};\\\", \\\"{x:541,y:696,t:1527628055029};\\\", \\\"{x:533,y:702,t:1527628055046};\\\", \\\"{x:527,y:704,t:1527628055062};\\\", \\\"{x:521,y:709,t:1527628055078};\\\", \\\"{x:515,y:712,t:1527628055095};\\\", \\\"{x:512,y:716,t:1527628055113};\\\", \\\"{x:510,y:718,t:1527628055129};\\\", \\\"{x:508,y:721,t:1527628055147};\\\", \\\"{x:507,y:721,t:1527628055162};\\\", \\\"{x:506,y:722,t:1527628055179};\\\", \\\"{x:505,y:722,t:1527628055196};\\\", \\\"{x:503,y:723,t:1527628055212};\\\", \\\"{x:501,y:726,t:1527628055229};\\\", \\\"{x:500,y:729,t:1527628055246};\\\", \\\"{x:498,y:731,t:1527628055262};\\\", \\\"{x:496,y:733,t:1527628055278};\\\", \\\"{x:494,y:738,t:1527628055295};\\\", \\\"{x:494,y:740,t:1527628055312};\\\", \\\"{x:493,y:741,t:1527628055329};\\\", \\\"{x:493,y:743,t:1527628055346};\\\" ] }, { \\\"rt\\\": 16761, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 322766, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:742,t:1527628057816};\\\", \\\"{x:483,y:732,t:1527628057834};\\\", \\\"{x:459,y:713,t:1527628057857};\\\", \\\"{x:448,y:707,t:1527628057867};\\\", \\\"{x:428,y:695,t:1527628057881};\\\", \\\"{x:406,y:683,t:1527628057898};\\\", \\\"{x:363,y:660,t:1527628057915};\\\", \\\"{x:311,y:628,t:1527628057932};\\\", \\\"{x:253,y:595,t:1527628057948};\\\", \\\"{x:199,y:566,t:1527628057965};\\\", \\\"{x:149,y:544,t:1527628057981};\\\", \\\"{x:102,y:520,t:1527628057999};\\\", \\\"{x:49,y:501,t:1527628058015};\\\", \\\"{x:26,y:495,t:1527628058032};\\\", \\\"{x:12,y:490,t:1527628058048};\\\", \\\"{x:0,y:488,t:1527628058064};\\\", \\\"{x:0,y:484,t:1527628058080};\\\", \\\"{x:0,y:483,t:1527628058098};\\\", \\\"{x:0,y:482,t:1527628058115};\\\", \\\"{x:0,y:481,t:1527628058131};\\\", \\\"{x:0,y:479,t:1527628058184};\\\", \\\"{x:0,y:476,t:1527628058198};\\\", \\\"{x:1,y:468,t:1527628058214};\\\", \\\"{x:3,y:462,t:1527628058231};\\\", \\\"{x:6,y:459,t:1527628058247};\\\", \\\"{x:11,y:455,t:1527628058265};\\\", \\\"{x:17,y:452,t:1527628058280};\\\", \\\"{x:19,y:450,t:1527628058298};\\\", \\\"{x:22,y:448,t:1527628058314};\\\", \\\"{x:25,y:447,t:1527628058331};\\\", \\\"{x:29,y:446,t:1527628058347};\\\", \\\"{x:31,y:445,t:1527628058364};\\\", \\\"{x:34,y:440,t:1527628058381};\\\", \\\"{x:41,y:439,t:1527628058398};\\\", \\\"{x:50,y:434,t:1527628058414};\\\", \\\"{x:62,y:430,t:1527628058431};\\\", \\\"{x:65,y:428,t:1527628058448};\\\", \\\"{x:67,y:427,t:1527628058464};\\\", \\\"{x:71,y:425,t:1527628058481};\\\", \\\"{x:73,y:424,t:1527628058498};\\\", \\\"{x:77,y:423,t:1527628058514};\\\", \\\"{x:81,y:421,t:1527628058531};\\\", \\\"{x:87,y:419,t:1527628058548};\\\", \\\"{x:91,y:417,t:1527628058564};\\\", \\\"{x:99,y:417,t:1527628058581};\\\", \\\"{x:106,y:417,t:1527628058597};\\\", \\\"{x:113,y:417,t:1527628058614};\\\", \\\"{x:135,y:419,t:1527628058632};\\\", \\\"{x:152,y:423,t:1527628058647};\\\", \\\"{x:173,y:424,t:1527628058664};\\\", \\\"{x:191,y:427,t:1527628058681};\\\", \\\"{x:205,y:428,t:1527628058698};\\\", \\\"{x:213,y:429,t:1527628058714};\\\", \\\"{x:219,y:430,t:1527628058731};\\\", \\\"{x:226,y:431,t:1527628058748};\\\", \\\"{x:233,y:432,t:1527628058764};\\\", \\\"{x:244,y:434,t:1527628058781};\\\", \\\"{x:251,y:436,t:1527628058798};\\\", \\\"{x:260,y:438,t:1527628058814};\\\", \\\"{x:269,y:440,t:1527628058832};\\\", \\\"{x:271,y:440,t:1527628058847};\\\", \\\"{x:272,y:441,t:1527628058864};\\\", \\\"{x:273,y:442,t:1527628058887};\\\", \\\"{x:274,y:443,t:1527628058904};\\\", \\\"{x:275,y:444,t:1527628058914};\\\", \\\"{x:276,y:445,t:1527628058935};\\\", \\\"{x:277,y:446,t:1527628058948};\\\", \\\"{x:278,y:447,t:1527628058964};\\\", \\\"{x:279,y:448,t:1527628058982};\\\", \\\"{x:279,y:449,t:1527628059000};\\\", \\\"{x:279,y:450,t:1527628059014};\\\", \\\"{x:280,y:451,t:1527628059031};\\\", \\\"{x:281,y:451,t:1527628059047};\\\", \\\"{x:281,y:452,t:1527628059064};\\\", \\\"{x:281,y:453,t:1527628059081};\\\", \\\"{x:282,y:452,t:1527628059512};\\\", \\\"{x:283,y:452,t:1527628059520};\\\", \\\"{x:286,y:451,t:1527628059531};\\\", \\\"{x:288,y:451,t:1527628059548};\\\", \\\"{x:289,y:449,t:1527628059565};\\\", \\\"{x:290,y:449,t:1527628059582};\\\", \\\"{x:291,y:449,t:1527628059597};\\\", \\\"{x:292,y:449,t:1527628059616};\\\", \\\"{x:293,y:448,t:1527628059631};\\\", \\\"{x:294,y:448,t:1527628059647};\\\", \\\"{x:297,y:448,t:1527628059664};\\\", \\\"{x:299,y:448,t:1527628059680};\\\", \\\"{x:304,y:448,t:1527628059697};\\\", \\\"{x:308,y:448,t:1527628059714};\\\", \\\"{x:312,y:448,t:1527628059730};\\\", \\\"{x:315,y:448,t:1527628059747};\\\", \\\"{x:319,y:448,t:1527628059764};\\\", \\\"{x:322,y:448,t:1527628059780};\\\", \\\"{x:323,y:448,t:1527628059799};\\\", \\\"{x:324,y:448,t:1527628059815};\\\", \\\"{x:325,y:448,t:1527628059830};\\\", \\\"{x:326,y:448,t:1527628059856};\\\", \\\"{x:327,y:448,t:1527628059863};\\\", \\\"{x:328,y:448,t:1527628059880};\\\", \\\"{x:329,y:448,t:1527628059897};\\\", \\\"{x:330,y:448,t:1527628059914};\\\", \\\"{x:331,y:448,t:1527628059930};\\\", \\\"{x:332,y:448,t:1527628059999};\\\", \\\"{x:333,y:448,t:1527628060015};\\\", \\\"{x:334,y:448,t:1527628060030};\\\", \\\"{x:335,y:448,t:1527628060104};\\\", \\\"{x:336,y:448,t:1527628060114};\\\", \\\"{x:337,y:449,t:1527628060131};\\\", \\\"{x:338,y:449,t:1527628060148};\\\", \\\"{x:339,y:450,t:1527628060164};\\\", \\\"{x:340,y:450,t:1527628060181};\\\", \\\"{x:343,y:450,t:1527628060197};\\\", \\\"{x:344,y:450,t:1527628060213};\\\", \\\"{x:345,y:450,t:1527628060231};\\\", \\\"{x:346,y:450,t:1527628060271};\\\", \\\"{x:347,y:451,t:1527628060280};\\\", \\\"{x:348,y:451,t:1527628060326};\\\", \\\"{x:349,y:451,t:1527628060342};\\\", \\\"{x:350,y:451,t:1527628060351};\\\", \\\"{x:351,y:451,t:1527628060374};\\\", \\\"{x:352,y:451,t:1527628060398};\\\", \\\"{x:353,y:451,t:1527628060431};\\\", \\\"{x:354,y:451,t:1527628060463};\\\", \\\"{x:355,y:451,t:1527628060480};\\\", \\\"{x:356,y:451,t:1527628060497};\\\", \\\"{x:357,y:451,t:1527628060514};\\\", \\\"{x:358,y:451,t:1527628060530};\\\", \\\"{x:359,y:451,t:1527628060547};\\\", \\\"{x:361,y:451,t:1527628060564};\\\", \\\"{x:362,y:451,t:1527628060584};\\\", \\\"{x:363,y:451,t:1527628060597};\\\", \\\"{x:364,y:451,t:1527628060613};\\\", \\\"{x:365,y:451,t:1527628060640};\\\", \\\"{x:366,y:451,t:1527628060671};\\\", \\\"{x:367,y:451,t:1527628060704};\\\", \\\"{x:368,y:451,t:1527628060776};\\\", \\\"{x:369,y:451,t:1527628060783};\\\", \\\"{x:370,y:451,t:1527628060800};\\\", \\\"{x:371,y:451,t:1527628060824};\\\", \\\"{x:372,y:451,t:1527628060839};\\\", \\\"{x:373,y:451,t:1527628060855};\\\", \\\"{x:374,y:451,t:1527628060880};\\\", \\\"{x:375,y:451,t:1527628060897};\\\", \\\"{x:377,y:451,t:1527628060913};\\\", \\\"{x:379,y:451,t:1527628060930};\\\", \\\"{x:382,y:451,t:1527628060947};\\\", \\\"{x:385,y:451,t:1527628060963};\\\", \\\"{x:388,y:451,t:1527628060980};\\\", \\\"{x:390,y:451,t:1527628060997};\\\", \\\"{x:391,y:451,t:1527628061014};\\\", \\\"{x:392,y:451,t:1527628061030};\\\", \\\"{x:393,y:451,t:1527628061046};\\\", \\\"{x:395,y:451,t:1527628061063};\\\", \\\"{x:396,y:451,t:1527628061080};\\\", \\\"{x:397,y:451,t:1527628061096};\\\", \\\"{x:399,y:451,t:1527628061114};\\\", \\\"{x:400,y:451,t:1527628061152};\\\", \\\"{x:401,y:451,t:1527628061168};\\\", \\\"{x:402,y:451,t:1527628061184};\\\", \\\"{x:404,y:451,t:1527628061216};\\\", \\\"{x:406,y:451,t:1527628061232};\\\", \\\"{x:408,y:451,t:1527628061247};\\\", \\\"{x:410,y:451,t:1527628061263};\\\", \\\"{x:412,y:451,t:1527628061280};\\\", \\\"{x:416,y:451,t:1527628061296};\\\", \\\"{x:419,y:451,t:1527628061313};\\\", \\\"{x:422,y:451,t:1527628061331};\\\", \\\"{x:424,y:451,t:1527628061346};\\\", \\\"{x:428,y:451,t:1527628061363};\\\", \\\"{x:430,y:451,t:1527628061380};\\\", \\\"{x:431,y:451,t:1527628061397};\\\", \\\"{x:434,y:451,t:1527628061413};\\\", \\\"{x:435,y:451,t:1527628061430};\\\", \\\"{x:437,y:451,t:1527628061447};\\\", \\\"{x:440,y:452,t:1527628061463};\\\", \\\"{x:443,y:452,t:1527628061479};\\\", \\\"{x:444,y:452,t:1527628061497};\\\", \\\"{x:446,y:452,t:1527628061514};\\\", \\\"{x:447,y:452,t:1527628061530};\\\", \\\"{x:449,y:452,t:1527628061546};\\\", \\\"{x:450,y:452,t:1527628061563};\\\", \\\"{x:451,y:452,t:1527628061580};\\\", \\\"{x:452,y:452,t:1527628061596};\\\", \\\"{x:454,y:452,t:1527628061613};\\\", \\\"{x:455,y:452,t:1527628061629};\\\", \\\"{x:457,y:452,t:1527628061646};\\\", \\\"{x:459,y:452,t:1527628061664};\\\", \\\"{x:460,y:452,t:1527628061679};\\\", \\\"{x:462,y:452,t:1527628061697};\\\", \\\"{x:463,y:452,t:1527628061719};\\\", \\\"{x:464,y:452,t:1527628061735};\\\", \\\"{x:465,y:452,t:1527628061747};\\\", \\\"{x:467,y:452,t:1527628061763};\\\", \\\"{x:468,y:452,t:1527628061780};\\\", \\\"{x:470,y:452,t:1527628061797};\\\", \\\"{x:472,y:452,t:1527628061813};\\\", \\\"{x:474,y:452,t:1527628061829};\\\", \\\"{x:475,y:452,t:1527628061846};\\\", \\\"{x:478,y:452,t:1527628061863};\\\", \\\"{x:480,y:452,t:1527628061879};\\\", \\\"{x:483,y:452,t:1527628061896};\\\", \\\"{x:485,y:452,t:1527628061914};\\\", \\\"{x:487,y:452,t:1527628061929};\\\", \\\"{x:490,y:452,t:1527628061946};\\\", \\\"{x:493,y:452,t:1527628061963};\\\", \\\"{x:496,y:452,t:1527628061980};\\\", \\\"{x:500,y:452,t:1527628061996};\\\", \\\"{x:505,y:452,t:1527628062014};\\\", \\\"{x:511,y:452,t:1527628062029};\\\", \\\"{x:519,y:452,t:1527628062046};\\\", \\\"{x:539,y:452,t:1527628062062};\\\", \\\"{x:554,y:452,t:1527628062079};\\\", \\\"{x:570,y:451,t:1527628062096};\\\", \\\"{x:587,y:451,t:1527628062112};\\\", \\\"{x:602,y:450,t:1527628062128};\\\", \\\"{x:612,y:449,t:1527628062145};\\\", \\\"{x:619,y:447,t:1527628062163};\\\", \\\"{x:622,y:447,t:1527628062179};\\\", \\\"{x:623,y:447,t:1527628062196};\\\", \\\"{x:625,y:447,t:1527628062256};\\\", \\\"{x:626,y:447,t:1527628062263};\\\", \\\"{x:632,y:447,t:1527628062279};\\\", \\\"{x:639,y:447,t:1527628062296};\\\", \\\"{x:651,y:447,t:1527628062313};\\\", \\\"{x:663,y:447,t:1527628062329};\\\", \\\"{x:682,y:447,t:1527628062346};\\\", \\\"{x:703,y:447,t:1527628062362};\\\", \\\"{x:726,y:447,t:1527628062380};\\\", \\\"{x:754,y:447,t:1527628062396};\\\", \\\"{x:794,y:447,t:1527628062412};\\\", \\\"{x:833,y:447,t:1527628062429};\\\", \\\"{x:875,y:447,t:1527628062446};\\\", \\\"{x:935,y:451,t:1527628062462};\\\", \\\"{x:1048,y:478,t:1527628062479};\\\", \\\"{x:1136,y:503,t:1527628062496};\\\", \\\"{x:1227,y:539,t:1527628062512};\\\", \\\"{x:1291,y:560,t:1527628062529};\\\", \\\"{x:1327,y:575,t:1527628062546};\\\", \\\"{x:1354,y:587,t:1527628062562};\\\", \\\"{x:1376,y:596,t:1527628062579};\\\", \\\"{x:1396,y:607,t:1527628062596};\\\", \\\"{x:1407,y:614,t:1527628062612};\\\", \\\"{x:1412,y:617,t:1527628062629};\\\", \\\"{x:1416,y:619,t:1527628062646};\\\", \\\"{x:1417,y:619,t:1527628062662};\\\", \\\"{x:1418,y:620,t:1527628062680};\\\", \\\"{x:1418,y:622,t:1527628062736};\\\", \\\"{x:1418,y:624,t:1527628062746};\\\", \\\"{x:1418,y:627,t:1527628062762};\\\", \\\"{x:1416,y:632,t:1527628062780};\\\", \\\"{x:1408,y:638,t:1527628062796};\\\", \\\"{x:1401,y:643,t:1527628062812};\\\", \\\"{x:1387,y:650,t:1527628062829};\\\", \\\"{x:1371,y:653,t:1527628062845};\\\", \\\"{x:1353,y:659,t:1527628062863};\\\", \\\"{x:1319,y:669,t:1527628062879};\\\", \\\"{x:1291,y:676,t:1527628062896};\\\", \\\"{x:1261,y:685,t:1527628062912};\\\", \\\"{x:1233,y:691,t:1527628062929};\\\", \\\"{x:1214,y:695,t:1527628062947};\\\", \\\"{x:1199,y:699,t:1527628062963};\\\", \\\"{x:1188,y:702,t:1527628062979};\\\", \\\"{x:1179,y:707,t:1527628062996};\\\", \\\"{x:1173,y:709,t:1527628063012};\\\", \\\"{x:1171,y:711,t:1527628063029};\\\", \\\"{x:1168,y:711,t:1527628063045};\\\", \\\"{x:1167,y:711,t:1527628063062};\\\", \\\"{x:1161,y:711,t:1527628063079};\\\", \\\"{x:1156,y:713,t:1527628063095};\\\", \\\"{x:1149,y:713,t:1527628063113};\\\", \\\"{x:1143,y:715,t:1527628063129};\\\", \\\"{x:1139,y:717,t:1527628063145};\\\", \\\"{x:1135,y:718,t:1527628063162};\\\", \\\"{x:1134,y:718,t:1527628063183};\\\", \\\"{x:1132,y:718,t:1527628063264};\\\", \\\"{x:1128,y:716,t:1527628063280};\\\", \\\"{x:1124,y:713,t:1527628063296};\\\", \\\"{x:1120,y:712,t:1527628063312};\\\", \\\"{x:1116,y:709,t:1527628063330};\\\", \\\"{x:1112,y:708,t:1527628063346};\\\", \\\"{x:1110,y:708,t:1527628063363};\\\", \\\"{x:1108,y:706,t:1527628063379};\\\", \\\"{x:1107,y:706,t:1527628063448};\\\", \\\"{x:1106,y:706,t:1527628063462};\\\", \\\"{x:1105,y:706,t:1527628063480};\\\", \\\"{x:1102,y:705,t:1527628063496};\\\", \\\"{x:1100,y:705,t:1527628063513};\\\", \\\"{x:1096,y:702,t:1527628063530};\\\", \\\"{x:1092,y:701,t:1527628063545};\\\", \\\"{x:1088,y:699,t:1527628063563};\\\", \\\"{x:1085,y:699,t:1527628063580};\\\", \\\"{x:1082,y:698,t:1527628063595};\\\", \\\"{x:1081,y:698,t:1527628063612};\\\", \\\"{x:1080,y:697,t:1527628063629};\\\", \\\"{x:1079,y:697,t:1527628063694};\\\", \\\"{x:1081,y:695,t:1527628064353};\\\", \\\"{x:1083,y:694,t:1527628064362};\\\", \\\"{x:1089,y:691,t:1527628064379};\\\", \\\"{x:1093,y:689,t:1527628064396};\\\", \\\"{x:1094,y:688,t:1527628064412};\\\", \\\"{x:1096,y:687,t:1527628064429};\\\", \\\"{x:1097,y:687,t:1527628064446};\\\", \\\"{x:1098,y:687,t:1527628064461};\\\", \\\"{x:1100,y:687,t:1527628064479};\\\", \\\"{x:1109,y:687,t:1527628064496};\\\", \\\"{x:1118,y:687,t:1527628064512};\\\", \\\"{x:1126,y:687,t:1527628064529};\\\", \\\"{x:1135,y:687,t:1527628064545};\\\", \\\"{x:1143,y:687,t:1527628064562};\\\", \\\"{x:1148,y:687,t:1527628064579};\\\", \\\"{x:1151,y:687,t:1527628064596};\\\", \\\"{x:1153,y:687,t:1527628064961};\\\", \\\"{x:1155,y:687,t:1527628064968};\\\", \\\"{x:1159,y:687,t:1527628064979};\\\", \\\"{x:1166,y:687,t:1527628064994};\\\", \\\"{x:1177,y:687,t:1527628065011};\\\", \\\"{x:1192,y:687,t:1527628065029};\\\", \\\"{x:1211,y:687,t:1527628065045};\\\", \\\"{x:1226,y:687,t:1527628065062};\\\", \\\"{x:1241,y:687,t:1527628065079};\\\", \\\"{x:1258,y:687,t:1527628065094};\\\", \\\"{x:1272,y:687,t:1527628065111};\\\", \\\"{x:1275,y:687,t:1527628065129};\\\", \\\"{x:1279,y:687,t:1527628065144};\\\", \\\"{x:1281,y:687,t:1527628065161};\\\", \\\"{x:1285,y:687,t:1527628065179};\\\", \\\"{x:1287,y:687,t:1527628065195};\\\", \\\"{x:1291,y:687,t:1527628065212};\\\", \\\"{x:1292,y:688,t:1527628065230};\\\", \\\"{x:1294,y:688,t:1527628065244};\\\", \\\"{x:1295,y:688,t:1527628065261};\\\", \\\"{x:1296,y:688,t:1527628065278};\\\", \\\"{x:1297,y:688,t:1527628065294};\\\", \\\"{x:1299,y:688,t:1527628065310};\\\", \\\"{x:1301,y:688,t:1527628065328};\\\", \\\"{x:1302,y:688,t:1527628065344};\\\", \\\"{x:1304,y:688,t:1527628065362};\\\", \\\"{x:1305,y:688,t:1527628065561};\\\", \\\"{x:1306,y:688,t:1527628065568};\\\", \\\"{x:1307,y:689,t:1527628065578};\\\", \\\"{x:1309,y:689,t:1527628065595};\\\", \\\"{x:1310,y:689,t:1527628065753};\\\", \\\"{x:1312,y:689,t:1527628065762};\\\", \\\"{x:1313,y:689,t:1527628065778};\\\", \\\"{x:1315,y:689,t:1527628065794};\\\", \\\"{x:1316,y:689,t:1527628065812};\\\", \\\"{x:1319,y:689,t:1527628065829};\\\", \\\"{x:1320,y:689,t:1527628065864};\\\", \\\"{x:1321,y:689,t:1527628065904};\\\", \\\"{x:1321,y:690,t:1527628065912};\\\", \\\"{x:1322,y:690,t:1527628065927};\\\", \\\"{x:1323,y:690,t:1527628065945};\\\", \\\"{x:1325,y:690,t:1527628065961};\\\", \\\"{x:1326,y:691,t:1527628065978};\\\", \\\"{x:1327,y:691,t:1527628065994};\\\", \\\"{x:1328,y:691,t:1527628066012};\\\", \\\"{x:1329,y:691,t:1527628066029};\\\", \\\"{x:1331,y:692,t:1527628066208};\\\", \\\"{x:1332,y:692,t:1527628066224};\\\", \\\"{x:1334,y:693,t:1527628066240};\\\", \\\"{x:1336,y:694,t:1527628066264};\\\", \\\"{x:1337,y:694,t:1527628066278};\\\", \\\"{x:1337,y:695,t:1527628066295};\\\", \\\"{x:1339,y:695,t:1527628066310};\\\", \\\"{x:1339,y:696,t:1527628066368};\\\", \\\"{x:1340,y:696,t:1527628066378};\\\", \\\"{x:1341,y:696,t:1527628066395};\\\", \\\"{x:1342,y:697,t:1527628066602};\\\", \\\"{x:1342,y:699,t:1527628066611};\\\", \\\"{x:1344,y:703,t:1527628066628};\\\", \\\"{x:1345,y:705,t:1527628066645};\\\", \\\"{x:1347,y:709,t:1527628066660};\\\", \\\"{x:1348,y:709,t:1527628066677};\\\", \\\"{x:1348,y:712,t:1527628066694};\\\", \\\"{x:1349,y:714,t:1527628066710};\\\", \\\"{x:1351,y:717,t:1527628066727};\\\", \\\"{x:1352,y:720,t:1527628066744};\\\", \\\"{x:1352,y:722,t:1527628066760};\\\", \\\"{x:1354,y:725,t:1527628066777};\\\", \\\"{x:1354,y:728,t:1527628066795};\\\", \\\"{x:1355,y:729,t:1527628066810};\\\", \\\"{x:1355,y:731,t:1527628066828};\\\", \\\"{x:1356,y:731,t:1527628066845};\\\", \\\"{x:1356,y:732,t:1527628066861};\\\", \\\"{x:1356,y:733,t:1527628066878};\\\", \\\"{x:1356,y:734,t:1527628066903};\\\", \\\"{x:1356,y:735,t:1527628066927};\\\", \\\"{x:1356,y:737,t:1527628066944};\\\", \\\"{x:1356,y:738,t:1527628066961};\\\", \\\"{x:1356,y:741,t:1527628066978};\\\", \\\"{x:1356,y:743,t:1527628066994};\\\", \\\"{x:1357,y:745,t:1527628067011};\\\", \\\"{x:1357,y:746,t:1527628067030};\\\", \\\"{x:1358,y:749,t:1527628067044};\\\", \\\"{x:1358,y:751,t:1527628067061};\\\", \\\"{x:1358,y:754,t:1527628067078};\\\", \\\"{x:1359,y:755,t:1527628067096};\\\", \\\"{x:1359,y:756,t:1527628067112};\\\", \\\"{x:1359,y:757,t:1527628067127};\\\", \\\"{x:1359,y:758,t:1527628067143};\\\", \\\"{x:1359,y:759,t:1527628067167};\\\", \\\"{x:1359,y:760,t:1527628067191};\\\", \\\"{x:1360,y:761,t:1527628067222};\\\", \\\"{x:1360,y:762,t:1527628067239};\\\", \\\"{x:1360,y:763,t:1527628067254};\\\", \\\"{x:1360,y:764,t:1527628067278};\\\", \\\"{x:1360,y:765,t:1527628067293};\\\", \\\"{x:1360,y:766,t:1527628067311};\\\", \\\"{x:1360,y:767,t:1527628067335};\\\", \\\"{x:1360,y:768,t:1527628067825};\\\", \\\"{x:1360,y:769,t:1527628067872};\\\", \\\"{x:1360,y:771,t:1527628067880};\\\", \\\"{x:1360,y:772,t:1527628067894};\\\", \\\"{x:1359,y:775,t:1527628067911};\\\", \\\"{x:1358,y:774,t:1527628069031};\\\", \\\"{x:1356,y:773,t:1527628069151};\\\", \\\"{x:1352,y:769,t:1527628069159};\\\", \\\"{x:1347,y:763,t:1527628069176};\\\", \\\"{x:1342,y:758,t:1527628069193};\\\", \\\"{x:1340,y:755,t:1527628069210};\\\", \\\"{x:1337,y:754,t:1527628069226};\\\", \\\"{x:1333,y:752,t:1527628069243};\\\", \\\"{x:1330,y:751,t:1527628069260};\\\", \\\"{x:1321,y:747,t:1527628069277};\\\", \\\"{x:1314,y:744,t:1527628069292};\\\", \\\"{x:1305,y:740,t:1527628069309};\\\", \\\"{x:1293,y:735,t:1527628069327};\\\", \\\"{x:1275,y:728,t:1527628069342};\\\", \\\"{x:1238,y:717,t:1527628069359};\\\", \\\"{x:1208,y:709,t:1527628069378};\\\", \\\"{x:1180,y:699,t:1527628069393};\\\", \\\"{x:1157,y:694,t:1527628069410};\\\", \\\"{x:1139,y:689,t:1527628069426};\\\", \\\"{x:1118,y:686,t:1527628069442};\\\", \\\"{x:1098,y:683,t:1527628069460};\\\", \\\"{x:1078,y:677,t:1527628069477};\\\", \\\"{x:1064,y:676,t:1527628069493};\\\", \\\"{x:1059,y:675,t:1527628069509};\\\", \\\"{x:1057,y:675,t:1527628069527};\\\", \\\"{x:1053,y:674,t:1527628069543};\\\", \\\"{x:1047,y:671,t:1527628069559};\\\", \\\"{x:1039,y:669,t:1527628069575};\\\", \\\"{x:1028,y:664,t:1527628069593};\\\", \\\"{x:1016,y:658,t:1527628069610};\\\", \\\"{x:1011,y:654,t:1527628069625};\\\", \\\"{x:1008,y:652,t:1527628069642};\\\", \\\"{x:1008,y:651,t:1527628069660};\\\", \\\"{x:1004,y:648,t:1527628069676};\\\", \\\"{x:996,y:639,t:1527628069693};\\\", \\\"{x:986,y:632,t:1527628069709};\\\", \\\"{x:970,y:622,t:1527628069726};\\\", \\\"{x:948,y:610,t:1527628069743};\\\", \\\"{x:910,y:589,t:1527628069759};\\\", \\\"{x:864,y:569,t:1527628069792};\\\", \\\"{x:847,y:564,t:1527628069807};\\\", \\\"{x:835,y:560,t:1527628069825};\\\", \\\"{x:827,y:558,t:1527628069840};\\\", \\\"{x:825,y:556,t:1527628069857};\\\", \\\"{x:824,y:556,t:1527628069874};\\\", \\\"{x:823,y:556,t:1527628069975};\\\", \\\"{x:826,y:552,t:1527628069991};\\\", \\\"{x:830,y:545,t:1527628070009};\\\", \\\"{x:834,y:541,t:1527628070025};\\\", \\\"{x:837,y:537,t:1527628070041};\\\", \\\"{x:840,y:534,t:1527628070057};\\\", \\\"{x:841,y:531,t:1527628070075};\\\", \\\"{x:841,y:530,t:1527628070091};\\\", \\\"{x:843,y:528,t:1527628070107};\\\", \\\"{x:843,y:526,t:1527628070124};\\\", \\\"{x:844,y:523,t:1527628070141};\\\", \\\"{x:844,y:518,t:1527628070157};\\\", \\\"{x:844,y:513,t:1527628070176};\\\", \\\"{x:844,y:507,t:1527628070190};\\\", \\\"{x:844,y:498,t:1527628070207};\\\", \\\"{x:843,y:493,t:1527628070224};\\\", \\\"{x:842,y:490,t:1527628070242};\\\", \\\"{x:841,y:489,t:1527628070258};\\\", \\\"{x:841,y:488,t:1527628070274};\\\", \\\"{x:841,y:487,t:1527628070292};\\\", \\\"{x:840,y:487,t:1527628070751};\\\", \\\"{x:840,y:488,t:1527628070911};\\\", \\\"{x:840,y:488,t:1527628070983};\\\", \\\"{x:840,y:490,t:1527628071032};\\\", \\\"{x:840,y:491,t:1527628071041};\\\", \\\"{x:840,y:496,t:1527628071059};\\\", \\\"{x:840,y:501,t:1527628071075};\\\", \\\"{x:840,y:503,t:1527628071091};\\\", \\\"{x:839,y:508,t:1527628071108};\\\", \\\"{x:838,y:510,t:1527628071125};\\\", \\\"{x:838,y:511,t:1527628071141};\\\", \\\"{x:837,y:512,t:1527628071535};\\\", \\\"{x:836,y:512,t:1527628071543};\\\", \\\"{x:833,y:513,t:1527628071558};\\\", \\\"{x:825,y:516,t:1527628071576};\\\", \\\"{x:824,y:517,t:1527628071593};\\\", \\\"{x:822,y:517,t:1527628071615};\\\", \\\"{x:822,y:518,t:1527628071639};\\\", \\\"{x:820,y:518,t:1527628071654};\\\", \\\"{x:818,y:518,t:1527628071663};\\\", \\\"{x:813,y:518,t:1527628071675};\\\", \\\"{x:801,y:518,t:1527628071693};\\\", \\\"{x:779,y:518,t:1527628071708};\\\", \\\"{x:735,y:518,t:1527628071725};\\\", \\\"{x:657,y:515,t:1527628071743};\\\", \\\"{x:560,y:504,t:1527628071758};\\\", \\\"{x:426,y:491,t:1527628071776};\\\", \\\"{x:359,y:489,t:1527628071793};\\\", \\\"{x:323,y:489,t:1527628071810};\\\", \\\"{x:301,y:489,t:1527628071825};\\\", \\\"{x:285,y:490,t:1527628071842};\\\", \\\"{x:277,y:491,t:1527628071860};\\\", \\\"{x:271,y:492,t:1527628071877};\\\", \\\"{x:269,y:493,t:1527628071893};\\\", \\\"{x:266,y:494,t:1527628071910};\\\", \\\"{x:257,y:495,t:1527628071925};\\\", \\\"{x:239,y:498,t:1527628071942};\\\", \\\"{x:226,y:501,t:1527628071958};\\\", \\\"{x:215,y:504,t:1527628071975};\\\", \\\"{x:207,y:509,t:1527628071992};\\\", \\\"{x:201,y:511,t:1527628072009};\\\", \\\"{x:198,y:513,t:1527628072026};\\\", \\\"{x:194,y:516,t:1527628072043};\\\", \\\"{x:192,y:517,t:1527628072059};\\\", \\\"{x:189,y:519,t:1527628072076};\\\", \\\"{x:187,y:520,t:1527628072093};\\\", \\\"{x:186,y:522,t:1527628072110};\\\", \\\"{x:183,y:524,t:1527628072126};\\\", \\\"{x:178,y:527,t:1527628072143};\\\", \\\"{x:174,y:529,t:1527628072160};\\\", \\\"{x:171,y:531,t:1527628072176};\\\", \\\"{x:169,y:532,t:1527628072192};\\\", \\\"{x:168,y:533,t:1527628072209};\\\", \\\"{x:167,y:533,t:1527628072303};\\\", \\\"{x:166,y:533,t:1527628072311};\\\", \\\"{x:165,y:535,t:1527628072808};\\\", \\\"{x:169,y:537,t:1527628072816};\\\", \\\"{x:175,y:540,t:1527628072827};\\\", \\\"{x:186,y:545,t:1527628072844};\\\", \\\"{x:198,y:552,t:1527628072860};\\\", \\\"{x:210,y:558,t:1527628072877};\\\", \\\"{x:225,y:568,t:1527628072894};\\\", \\\"{x:241,y:578,t:1527628072910};\\\", \\\"{x:275,y:596,t:1527628072927};\\\", \\\"{x:297,y:608,t:1527628072944};\\\", \\\"{x:321,y:623,t:1527628072960};\\\", \\\"{x:347,y:637,t:1527628072977};\\\", \\\"{x:374,y:653,t:1527628072994};\\\", \\\"{x:399,y:667,t:1527628073010};\\\", \\\"{x:425,y:683,t:1527628073027};\\\", \\\"{x:445,y:692,t:1527628073044};\\\", \\\"{x:463,y:698,t:1527628073060};\\\", \\\"{x:476,y:704,t:1527628073077};\\\", \\\"{x:487,y:710,t:1527628073093};\\\", \\\"{x:502,y:717,t:1527628073110};\\\", \\\"{x:507,y:719,t:1527628073127};\\\", \\\"{x:513,y:723,t:1527628073145};\\\", \\\"{x:515,y:723,t:1527628073160};\\\", \\\"{x:516,y:724,t:1527628073191};\\\", \\\"{x:517,y:726,t:1527628073336};\\\", \\\"{x:519,y:727,t:1527628073343};\\\", \\\"{x:519,y:728,t:1527628073360};\\\", \\\"{x:520,y:728,t:1527628073415};\\\", \\\"{x:521,y:728,t:1527628073427};\\\", \\\"{x:522,y:728,t:1527628073444};\\\", \\\"{x:523,y:728,t:1527628073487};\\\", \\\"{x:523,y:728,t:1527628073592};\\\" ] }, { \\\"rt\\\": 32147, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 356137, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:721,t:1527628075479};\\\", \\\"{x:465,y:650,t:1527628075495};\\\", \\\"{x:396,y:565,t:1527628075511};\\\", \\\"{x:340,y:501,t:1527628075529};\\\", \\\"{x:297,y:456,t:1527628075546};\\\", \\\"{x:265,y:435,t:1527628075561};\\\", \\\"{x:241,y:419,t:1527628075579};\\\", \\\"{x:225,y:411,t:1527628075595};\\\", \\\"{x:218,y:406,t:1527628075611};\\\", \\\"{x:214,y:404,t:1527628075628};\\\", \\\"{x:212,y:403,t:1527628075646};\\\", \\\"{x:212,y:400,t:1527628075760};\\\", \\\"{x:212,y:399,t:1527628075767};\\\", \\\"{x:212,y:398,t:1527628075779};\\\", \\\"{x:212,y:397,t:1527628075795};\\\", \\\"{x:212,y:395,t:1527628075813};\\\", \\\"{x:213,y:395,t:1527628075829};\\\", \\\"{x:215,y:393,t:1527628075846};\\\", \\\"{x:219,y:391,t:1527628075863};\\\", \\\"{x:220,y:391,t:1527628075879};\\\", \\\"{x:221,y:390,t:1527628075896};\\\", \\\"{x:222,y:390,t:1527628075960};\\\", \\\"{x:223,y:390,t:1527628075967};\\\", \\\"{x:225,y:390,t:1527628075979};\\\", \\\"{x:230,y:391,t:1527628075996};\\\", \\\"{x:235,y:392,t:1527628076012};\\\", \\\"{x:239,y:395,t:1527628076029};\\\", \\\"{x:246,y:398,t:1527628076046};\\\", \\\"{x:261,y:404,t:1527628076063};\\\", \\\"{x:283,y:413,t:1527628076080};\\\", \\\"{x:309,y:421,t:1527628076096};\\\", \\\"{x:337,y:425,t:1527628076113};\\\", \\\"{x:360,y:428,t:1527628076129};\\\", \\\"{x:379,y:430,t:1527628076146};\\\", \\\"{x:403,y:432,t:1527628076163};\\\", \\\"{x:419,y:432,t:1527628076180};\\\", \\\"{x:428,y:432,t:1527628076196};\\\", \\\"{x:430,y:432,t:1527628076213};\\\", \\\"{x:431,y:432,t:1527628076304};\\\", \\\"{x:432,y:432,t:1527628076319};\\\", \\\"{x:435,y:432,t:1527628076330};\\\", \\\"{x:447,y:432,t:1527628076346};\\\", \\\"{x:466,y:432,t:1527628076363};\\\", \\\"{x:489,y:432,t:1527628076380};\\\", \\\"{x:515,y:432,t:1527628076396};\\\", \\\"{x:536,y:432,t:1527628076413};\\\", \\\"{x:558,y:432,t:1527628076430};\\\", \\\"{x:580,y:432,t:1527628076446};\\\", \\\"{x:614,y:432,t:1527628076463};\\\", \\\"{x:633,y:432,t:1527628076480};\\\", \\\"{x:652,y:432,t:1527628076496};\\\", \\\"{x:670,y:432,t:1527628076513};\\\", \\\"{x:684,y:432,t:1527628076530};\\\", \\\"{x:694,y:430,t:1527628076546};\\\", \\\"{x:706,y:426,t:1527628076563};\\\", \\\"{x:716,y:423,t:1527628076580};\\\", \\\"{x:732,y:414,t:1527628076596};\\\", \\\"{x:750,y:403,t:1527628076613};\\\", \\\"{x:768,y:390,t:1527628076630};\\\", \\\"{x:801,y:363,t:1527628076648};\\\", \\\"{x:832,y:342,t:1527628076663};\\\", \\\"{x:869,y:313,t:1527628076680};\\\", \\\"{x:912,y:281,t:1527628076697};\\\", \\\"{x:948,y:250,t:1527628076713};\\\", \\\"{x:977,y:229,t:1527628076730};\\\", \\\"{x:1002,y:215,t:1527628076747};\\\", \\\"{x:1019,y:207,t:1527628076763};\\\", \\\"{x:1030,y:202,t:1527628076781};\\\", \\\"{x:1035,y:202,t:1527628076798};\\\", \\\"{x:1036,y:200,t:1527628076813};\\\", \\\"{x:1037,y:200,t:1527628076848};\\\", \\\"{x:1037,y:201,t:1527628076872};\\\", \\\"{x:1038,y:202,t:1527628076880};\\\", \\\"{x:1038,y:205,t:1527628076898};\\\", \\\"{x:1041,y:208,t:1527628076913};\\\", \\\"{x:1044,y:216,t:1527628076930};\\\", \\\"{x:1046,y:226,t:1527628076947};\\\", \\\"{x:1050,y:239,t:1527628076963};\\\", \\\"{x:1055,y:254,t:1527628076980};\\\", \\\"{x:1061,y:268,t:1527628076998};\\\", \\\"{x:1066,y:283,t:1527628077014};\\\", \\\"{x:1072,y:296,t:1527628077030};\\\", \\\"{x:1079,y:314,t:1527628077048};\\\", \\\"{x:1083,y:323,t:1527628077064};\\\", \\\"{x:1087,y:333,t:1527628077081};\\\", \\\"{x:1091,y:342,t:1527628077097};\\\", \\\"{x:1095,y:350,t:1527628077113};\\\", \\\"{x:1099,y:359,t:1527628077129};\\\", \\\"{x:1104,y:370,t:1527628077146};\\\", \\\"{x:1107,y:380,t:1527628077164};\\\", \\\"{x:1111,y:387,t:1527628077180};\\\", \\\"{x:1113,y:393,t:1527628077197};\\\", \\\"{x:1115,y:397,t:1527628077214};\\\", \\\"{x:1116,y:401,t:1527628077229};\\\", \\\"{x:1117,y:406,t:1527628077246};\\\", \\\"{x:1118,y:412,t:1527628077264};\\\", \\\"{x:1118,y:415,t:1527628077279};\\\", \\\"{x:1120,y:421,t:1527628077297};\\\", \\\"{x:1120,y:426,t:1527628077313};\\\", \\\"{x:1120,y:430,t:1527628077330};\\\", \\\"{x:1120,y:435,t:1527628077347};\\\", \\\"{x:1120,y:439,t:1527628077364};\\\", \\\"{x:1119,y:444,t:1527628077379};\\\", \\\"{x:1117,y:448,t:1527628077397};\\\", \\\"{x:1116,y:452,t:1527628077414};\\\", \\\"{x:1114,y:456,t:1527628077429};\\\", \\\"{x:1112,y:462,t:1527628077446};\\\", \\\"{x:1111,y:467,t:1527628077464};\\\", \\\"{x:1109,y:470,t:1527628077480};\\\", \\\"{x:1106,y:476,t:1527628077497};\\\", \\\"{x:1105,y:478,t:1527628077515};\\\", \\\"{x:1105,y:481,t:1527628077530};\\\", \\\"{x:1104,y:482,t:1527628077546};\\\", \\\"{x:1103,y:483,t:1527628077564};\\\", \\\"{x:1103,y:484,t:1527628077580};\\\", \\\"{x:1102,y:485,t:1527628077597};\\\", \\\"{x:1102,y:487,t:1527628077720};\\\", \\\"{x:1102,y:489,t:1527628077752};\\\", \\\"{x:1102,y:490,t:1527628077768};\\\", \\\"{x:1102,y:491,t:1527628077783};\\\", \\\"{x:1102,y:492,t:1527628077799};\\\", \\\"{x:1102,y:493,t:1527628077896};\\\", \\\"{x:1102,y:494,t:1527628077920};\\\", \\\"{x:1101,y:495,t:1527628077935};\\\", \\\"{x:1101,y:496,t:1527628077952};\\\", \\\"{x:1100,y:497,t:1527628077976};\\\", \\\"{x:1099,y:498,t:1527628079704};\\\", \\\"{x:1097,y:498,t:1527628079912};\\\", \\\"{x:1096,y:498,t:1527628079936};\\\", \\\"{x:1095,y:498,t:1527628079992};\\\", \\\"{x:1094,y:498,t:1527628080023};\\\", \\\"{x:1096,y:498,t:1527628080560};\\\", \\\"{x:1098,y:498,t:1527628080567};\\\", \\\"{x:1101,y:498,t:1527628080583};\\\", \\\"{x:1114,y:500,t:1527628080599};\\\", \\\"{x:1122,y:500,t:1527628080617};\\\", \\\"{x:1129,y:500,t:1527628080634};\\\", \\\"{x:1134,y:500,t:1527628080650};\\\", \\\"{x:1138,y:500,t:1527628080667};\\\", \\\"{x:1140,y:500,t:1527628080684};\\\", \\\"{x:1142,y:500,t:1527628080700};\\\", \\\"{x:1143,y:500,t:1527628080716};\\\", \\\"{x:1145,y:500,t:1527628080733};\\\", \\\"{x:1146,y:500,t:1527628080749};\\\", \\\"{x:1148,y:500,t:1527628080766};\\\", \\\"{x:1154,y:500,t:1527628080784};\\\", \\\"{x:1161,y:497,t:1527628080799};\\\", \\\"{x:1166,y:497,t:1527628080816};\\\", \\\"{x:1172,y:495,t:1527628080834};\\\", \\\"{x:1177,y:493,t:1527628080850};\\\", \\\"{x:1181,y:493,t:1527628080867};\\\", \\\"{x:1183,y:492,t:1527628080883};\\\", \\\"{x:1184,y:492,t:1527628080899};\\\", \\\"{x:1186,y:492,t:1527628081016};\\\", \\\"{x:1190,y:493,t:1527628081034};\\\", \\\"{x:1200,y:497,t:1527628081050};\\\", \\\"{x:1210,y:500,t:1527628081066};\\\", \\\"{x:1226,y:504,t:1527628081083};\\\", \\\"{x:1240,y:507,t:1527628081101};\\\", \\\"{x:1255,y:509,t:1527628081116};\\\", \\\"{x:1272,y:510,t:1527628081133};\\\", \\\"{x:1289,y:513,t:1527628081150};\\\", \\\"{x:1300,y:515,t:1527628081166};\\\", \\\"{x:1313,y:517,t:1527628081182};\\\", \\\"{x:1320,y:518,t:1527628081200};\\\", \\\"{x:1325,y:519,t:1527628081215};\\\", \\\"{x:1329,y:521,t:1527628081233};\\\", \\\"{x:1333,y:522,t:1527628081250};\\\", \\\"{x:1337,y:522,t:1527628081266};\\\", \\\"{x:1339,y:522,t:1527628081283};\\\", \\\"{x:1343,y:523,t:1527628081300};\\\", \\\"{x:1345,y:523,t:1527628081316};\\\", \\\"{x:1346,y:523,t:1527628081335};\\\", \\\"{x:1346,y:524,t:1527628081384};\\\", \\\"{x:1347,y:524,t:1527628081407};\\\", \\\"{x:1348,y:526,t:1527628081416};\\\", \\\"{x:1351,y:530,t:1527628081434};\\\", \\\"{x:1357,y:536,t:1527628081451};\\\", \\\"{x:1360,y:540,t:1527628081466};\\\", \\\"{x:1363,y:545,t:1527628081483};\\\", \\\"{x:1366,y:549,t:1527628081500};\\\", \\\"{x:1368,y:552,t:1527628081518};\\\", \\\"{x:1370,y:555,t:1527628081533};\\\", \\\"{x:1371,y:557,t:1527628081551};\\\", \\\"{x:1374,y:562,t:1527628081568};\\\", \\\"{x:1375,y:565,t:1527628081583};\\\", \\\"{x:1377,y:568,t:1527628081600};\\\", \\\"{x:1379,y:570,t:1527628081617};\\\", \\\"{x:1381,y:573,t:1527628081633};\\\", \\\"{x:1384,y:577,t:1527628081650};\\\", \\\"{x:1388,y:580,t:1527628081668};\\\", \\\"{x:1392,y:585,t:1527628081684};\\\", \\\"{x:1394,y:587,t:1527628081700};\\\", \\\"{x:1395,y:590,t:1527628081717};\\\", \\\"{x:1396,y:591,t:1527628081733};\\\", \\\"{x:1397,y:593,t:1527628081751};\\\", \\\"{x:1398,y:594,t:1527628081776};\\\", \\\"{x:1398,y:596,t:1527628081888};\\\", \\\"{x:1397,y:597,t:1527628081900};\\\", \\\"{x:1395,y:600,t:1527628081920};\\\", \\\"{x:1395,y:601,t:1527628081934};\\\", \\\"{x:1393,y:602,t:1527628081951};\\\", \\\"{x:1390,y:606,t:1527628081968};\\\", \\\"{x:1387,y:609,t:1527628081984};\\\", \\\"{x:1383,y:612,t:1527628082000};\\\", \\\"{x:1380,y:615,t:1527628082017};\\\", \\\"{x:1375,y:621,t:1527628082035};\\\", \\\"{x:1370,y:629,t:1527628082051};\\\", \\\"{x:1368,y:636,t:1527628082067};\\\", \\\"{x:1363,y:643,t:1527628082084};\\\", \\\"{x:1359,y:651,t:1527628082100};\\\", \\\"{x:1356,y:658,t:1527628082118};\\\", \\\"{x:1352,y:667,t:1527628082135};\\\", \\\"{x:1350,y:675,t:1527628082150};\\\", \\\"{x:1348,y:689,t:1527628082167};\\\", \\\"{x:1347,y:698,t:1527628082187};\\\", \\\"{x:1345,y:706,t:1527628082200};\\\", \\\"{x:1345,y:712,t:1527628082217};\\\", \\\"{x:1344,y:716,t:1527628082233};\\\", \\\"{x:1344,y:720,t:1527628082250};\\\", \\\"{x:1344,y:724,t:1527628082267};\\\", \\\"{x:1344,y:726,t:1527628082284};\\\", \\\"{x:1344,y:727,t:1527628082300};\\\", \\\"{x:1344,y:728,t:1527628082317};\\\", \\\"{x:1344,y:729,t:1527628082334};\\\", \\\"{x:1344,y:730,t:1527628082351};\\\", \\\"{x:1345,y:731,t:1527628082391};\\\", \\\"{x:1345,y:732,t:1527628082408};\\\", \\\"{x:1345,y:733,t:1527628082423};\\\", \\\"{x:1345,y:734,t:1527628082433};\\\", \\\"{x:1345,y:735,t:1527628082451};\\\", \\\"{x:1345,y:738,t:1527628082466};\\\", \\\"{x:1346,y:739,t:1527628082484};\\\", \\\"{x:1346,y:741,t:1527628082501};\\\", \\\"{x:1346,y:743,t:1527628082517};\\\", \\\"{x:1346,y:745,t:1527628082534};\\\", \\\"{x:1346,y:749,t:1527628082551};\\\", \\\"{x:1346,y:751,t:1527628082566};\\\", \\\"{x:1346,y:752,t:1527628082584};\\\", \\\"{x:1346,y:754,t:1527628082601};\\\", \\\"{x:1346,y:755,t:1527628082617};\\\", \\\"{x:1346,y:757,t:1527628082634};\\\", \\\"{x:1346,y:758,t:1527628082651};\\\", \\\"{x:1346,y:760,t:1527628082703};\\\", \\\"{x:1346,y:761,t:1527628082752};\\\", \\\"{x:1346,y:760,t:1527628103496};\\\", \\\"{x:1333,y:751,t:1527628103505};\\\", \\\"{x:1313,y:736,t:1527628103516};\\\", \\\"{x:1264,y:706,t:1527628103533};\\\", \\\"{x:1218,y:689,t:1527628103549};\\\", \\\"{x:1153,y:667,t:1527628103566};\\\", \\\"{x:1041,y:632,t:1527628103583};\\\", \\\"{x:955,y:609,t:1527628103599};\\\", \\\"{x:853,y:579,t:1527628103617};\\\", \\\"{x:739,y:546,t:1527628103634};\\\", \\\"{x:639,y:516,t:1527628103651};\\\", \\\"{x:589,y:498,t:1527628103660};\\\", \\\"{x:503,y:473,t:1527628103678};\\\", \\\"{x:433,y:453,t:1527628103693};\\\", \\\"{x:362,y:428,t:1527628103718};\\\", \\\"{x:314,y:416,t:1527628103735};\\\", \\\"{x:292,y:407,t:1527628103752};\\\", \\\"{x:278,y:400,t:1527628103768};\\\", \\\"{x:271,y:398,t:1527628103785};\\\", \\\"{x:268,y:397,t:1527628103802};\\\", \\\"{x:271,y:400,t:1527628103863};\\\", \\\"{x:272,y:401,t:1527628103870};\\\", \\\"{x:274,y:401,t:1527628103885};\\\", \\\"{x:280,y:405,t:1527628103902};\\\", \\\"{x:287,y:410,t:1527628103918};\\\", \\\"{x:306,y:430,t:1527628103935};\\\", \\\"{x:323,y:445,t:1527628103952};\\\", \\\"{x:338,y:457,t:1527628103968};\\\", \\\"{x:347,y:464,t:1527628103985};\\\", \\\"{x:356,y:471,t:1527628104002};\\\", \\\"{x:362,y:474,t:1527628104018};\\\", \\\"{x:368,y:476,t:1527628104035};\\\", \\\"{x:370,y:477,t:1527628104052};\\\", \\\"{x:371,y:477,t:1527628104068};\\\", \\\"{x:372,y:477,t:1527628104085};\\\", \\\"{x:373,y:477,t:1527628104102};\\\", \\\"{x:375,y:479,t:1527628104118};\\\", \\\"{x:378,y:479,t:1527628104600};\\\", \\\"{x:381,y:479,t:1527628104607};\\\", \\\"{x:387,y:480,t:1527628104618};\\\", \\\"{x:401,y:481,t:1527628104635};\\\", \\\"{x:423,y:485,t:1527628104652};\\\", \\\"{x:446,y:488,t:1527628104668};\\\", \\\"{x:472,y:491,t:1527628104685};\\\", \\\"{x:507,y:497,t:1527628104702};\\\", \\\"{x:522,y:497,t:1527628104719};\\\", \\\"{x:537,y:500,t:1527628104736};\\\", \\\"{x:549,y:502,t:1527628104751};\\\", \\\"{x:561,y:503,t:1527628104769};\\\", \\\"{x:566,y:505,t:1527628104786};\\\", \\\"{x:570,y:505,t:1527628104802};\\\", \\\"{x:573,y:506,t:1527628104819};\\\", \\\"{x:577,y:507,t:1527628104836};\\\", \\\"{x:579,y:508,t:1527628104853};\\\", \\\"{x:583,y:510,t:1527628104869};\\\", \\\"{x:588,y:510,t:1527628104886};\\\", \\\"{x:593,y:512,t:1527628104903};\\\", \\\"{x:598,y:513,t:1527628104919};\\\", \\\"{x:603,y:513,t:1527628104937};\\\", \\\"{x:610,y:514,t:1527628104953};\\\", \\\"{x:618,y:514,t:1527628104969};\\\", \\\"{x:625,y:514,t:1527628104986};\\\", \\\"{x:633,y:514,t:1527628105003};\\\", \\\"{x:639,y:514,t:1527628105019};\\\", \\\"{x:645,y:514,t:1527628105036};\\\", \\\"{x:648,y:514,t:1527628105053};\\\", \\\"{x:649,y:514,t:1527628105069};\\\", \\\"{x:651,y:514,t:1527628105086};\\\", \\\"{x:652,y:514,t:1527628105103};\\\", \\\"{x:655,y:514,t:1527628105118};\\\", \\\"{x:656,y:514,t:1527628105167};\\\", \\\"{x:657,y:514,t:1527628105198};\\\", \\\"{x:658,y:514,t:1527628105222};\\\", \\\"{x:655,y:514,t:1527628105254};\\\", \\\"{x:648,y:514,t:1527628105270};\\\", \\\"{x:627,y:505,t:1527628105286};\\\", \\\"{x:616,y:503,t:1527628105303};\\\", \\\"{x:615,y:503,t:1527628105319};\\\", \\\"{x:617,y:502,t:1527628105399};\\\", \\\"{x:618,y:502,t:1527628105414};\\\", \\\"{x:619,y:502,t:1527628105422};\\\", \\\"{x:620,y:501,t:1527628105519};\\\", \\\"{x:619,y:504,t:1527628106024};\\\", \\\"{x:618,y:506,t:1527628106037};\\\", \\\"{x:616,y:512,t:1527628106054};\\\", \\\"{x:614,y:521,t:1527628106071};\\\", \\\"{x:606,y:544,t:1527628106088};\\\", \\\"{x:600,y:568,t:1527628106105};\\\", \\\"{x:592,y:589,t:1527628106120};\\\", \\\"{x:582,y:610,t:1527628106137};\\\", \\\"{x:573,y:625,t:1527628106154};\\\", \\\"{x:568,y:627,t:1527628106170};\\\", \\\"{x:559,y:631,t:1527628106187};\\\", \\\"{x:558,y:631,t:1527628106247};\\\", \\\"{x:557,y:631,t:1527628106263};\\\", \\\"{x:556,y:631,t:1527628106294};\\\", \\\"{x:554,y:633,t:1527628106369};\\\", \\\"{x:553,y:637,t:1527628106387};\\\", \\\"{x:551,y:643,t:1527628106404};\\\", \\\"{x:544,y:652,t:1527628106422};\\\", \\\"{x:543,y:656,t:1527628106438};\\\", \\\"{x:537,y:668,t:1527628106455};\\\", \\\"{x:530,y:689,t:1527628106472};\\\", \\\"{x:526,y:700,t:1527628106489};\\\", \\\"{x:523,y:708,t:1527628106504};\\\", \\\"{x:520,y:715,t:1527628106522};\\\", \\\"{x:519,y:719,t:1527628106538};\\\", \\\"{x:517,y:721,t:1527628106557};\\\", \\\"{x:516,y:722,t:1527628106571};\\\", \\\"{x:516,y:723,t:1527628106587};\\\", \\\"{x:515,y:724,t:1527628106604};\\\", \\\"{x:515,y:725,t:1527628106620};\\\", \\\"{x:513,y:726,t:1527628106637};\\\", \\\"{x:513,y:728,t:1527628106653};\\\", \\\"{x:512,y:732,t:1527628106670};\\\", \\\"{x:512,y:730,t:1527628107279};\\\", \\\"{x:512,y:729,t:1527628107289};\\\", \\\"{x:512,y:727,t:1527628107304};\\\", \\\"{x:512,y:725,t:1527628107321};\\\", \\\"{x:512,y:724,t:1527628107338};\\\", \\\"{x:512,y:723,t:1527628107354};\\\", \\\"{x:512,y:722,t:1527628107371};\\\", \\\"{x:512,y:721,t:1527628107388};\\\", \\\"{x:513,y:719,t:1527628107405};\\\", \\\"{x:513,y:717,t:1527628107423};\\\", \\\"{x:513,y:716,t:1527628107439};\\\", \\\"{x:513,y:715,t:1527628107455};\\\", \\\"{x:513,y:713,t:1527628107471};\\\", \\\"{x:513,y:708,t:1527628107489};\\\", \\\"{x:513,y:706,t:1527628107505};\\\", \\\"{x:513,y:703,t:1527628107521};\\\", \\\"{x:513,y:701,t:1527628107543};\\\", \\\"{x:513,y:700,t:1527628107559};\\\", \\\"{x:513,y:698,t:1527628107571};\\\", \\\"{x:513,y:697,t:1527628107588};\\\", \\\"{x:513,y:696,t:1527628107606};\\\", \\\"{x:513,y:694,t:1527628107621};\\\", \\\"{x:513,y:693,t:1527628107695};\\\" ] }, { \\\"rt\\\": 19814, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 377184, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:691,t:1527628108591};\\\", \\\"{x:510,y:685,t:1527628108606};\\\", \\\"{x:508,y:676,t:1527628108622};\\\", \\\"{x:508,y:672,t:1527628108639};\\\", \\\"{x:507,y:670,t:1527628108655};\\\", \\\"{x:506,y:668,t:1527628108672};\\\", \\\"{x:499,y:641,t:1527628108762};\\\", \\\"{x:499,y:640,t:1527628108772};\\\", \\\"{x:497,y:636,t:1527628108790};\\\", \\\"{x:494,y:627,t:1527628108807};\\\", \\\"{x:493,y:622,t:1527628108822};\\\", \\\"{x:489,y:614,t:1527628108839};\\\", \\\"{x:487,y:608,t:1527628108856};\\\", \\\"{x:484,y:601,t:1527628108872};\\\", \\\"{x:481,y:594,t:1527628108890};\\\", \\\"{x:478,y:588,t:1527628108907};\\\", \\\"{x:476,y:582,t:1527628108922};\\\", \\\"{x:474,y:576,t:1527628108939};\\\", \\\"{x:472,y:569,t:1527628108956};\\\", \\\"{x:468,y:558,t:1527628108972};\\\", \\\"{x:465,y:550,t:1527628108989};\\\", \\\"{x:463,y:540,t:1527628109006};\\\", \\\"{x:460,y:532,t:1527628109022};\\\", \\\"{x:456,y:518,t:1527628109039};\\\", \\\"{x:453,y:503,t:1527628109057};\\\", \\\"{x:449,y:494,t:1527628109072};\\\", \\\"{x:446,y:484,t:1527628109089};\\\", \\\"{x:442,y:473,t:1527628109105};\\\", \\\"{x:439,y:467,t:1527628109122};\\\", \\\"{x:436,y:458,t:1527628109139};\\\", \\\"{x:436,y:454,t:1527628109156};\\\", \\\"{x:435,y:449,t:1527628109173};\\\", \\\"{x:431,y:442,t:1527628109189};\\\", \\\"{x:428,y:438,t:1527628109206};\\\", \\\"{x:428,y:437,t:1527628109222};\\\", \\\"{x:427,y:437,t:1527628109600};\\\", \\\"{x:425,y:437,t:1527628109607};\\\", \\\"{x:421,y:440,t:1527628109622};\\\", \\\"{x:421,y:442,t:1527628109640};\\\", \\\"{x:420,y:442,t:1527628109656};\\\", \\\"{x:420,y:444,t:1527628109703};\\\", \\\"{x:419,y:445,t:1527628110071};\\\", \\\"{x:418,y:447,t:1527628110103};\\\", \\\"{x:418,y:449,t:1527628110771};\\\", \\\"{x:431,y:449,t:1527628110787};\\\", \\\"{x:447,y:449,t:1527628110803};\\\", \\\"{x:464,y:449,t:1527628110820};\\\", \\\"{x:478,y:449,t:1527628110837};\\\", \\\"{x:490,y:448,t:1527628110853};\\\", \\\"{x:502,y:447,t:1527628110870};\\\", \\\"{x:511,y:446,t:1527628110886};\\\", \\\"{x:517,y:443,t:1527628110903};\\\", \\\"{x:523,y:443,t:1527628110919};\\\", \\\"{x:526,y:443,t:1527628110936};\\\", \\\"{x:532,y:442,t:1527628110953};\\\", \\\"{x:538,y:441,t:1527628110970};\\\", \\\"{x:552,y:439,t:1527628110987};\\\", \\\"{x:561,y:437,t:1527628111003};\\\", \\\"{x:568,y:437,t:1527628111020};\\\", \\\"{x:578,y:437,t:1527628111037};\\\", \\\"{x:590,y:437,t:1527628111054};\\\", \\\"{x:607,y:437,t:1527628111070};\\\", \\\"{x:623,y:437,t:1527628111087};\\\", \\\"{x:637,y:437,t:1527628111104};\\\", \\\"{x:646,y:437,t:1527628111120};\\\", \\\"{x:655,y:437,t:1527628111137};\\\", \\\"{x:669,y:437,t:1527628111154};\\\", \\\"{x:685,y:441,t:1527628111170};\\\", \\\"{x:702,y:445,t:1527628111187};\\\", \\\"{x:715,y:446,t:1527628111203};\\\", \\\"{x:728,y:449,t:1527628111220};\\\", \\\"{x:738,y:450,t:1527628111237};\\\", \\\"{x:748,y:451,t:1527628111254};\\\", \\\"{x:758,y:451,t:1527628111270};\\\", \\\"{x:767,y:454,t:1527628111287};\\\", \\\"{x:781,y:455,t:1527628111304};\\\", \\\"{x:789,y:456,t:1527628111320};\\\", \\\"{x:805,y:459,t:1527628111337};\\\", \\\"{x:821,y:460,t:1527628111354};\\\", \\\"{x:841,y:461,t:1527628111371};\\\", \\\"{x:872,y:461,t:1527628111388};\\\", \\\"{x:891,y:461,t:1527628111403};\\\", \\\"{x:909,y:461,t:1527628111420};\\\", \\\"{x:924,y:461,t:1527628111437};\\\", \\\"{x:940,y:462,t:1527628111454};\\\", \\\"{x:956,y:463,t:1527628111470};\\\", \\\"{x:967,y:465,t:1527628111487};\\\", \\\"{x:982,y:466,t:1527628111504};\\\", \\\"{x:998,y:469,t:1527628111519};\\\", \\\"{x:1019,y:470,t:1527628111537};\\\", \\\"{x:1035,y:471,t:1527628111554};\\\", \\\"{x:1056,y:471,t:1527628111570};\\\", \\\"{x:1088,y:469,t:1527628111587};\\\", \\\"{x:1113,y:468,t:1527628111603};\\\", \\\"{x:1157,y:468,t:1527628111620};\\\", \\\"{x:1213,y:468,t:1527628111636};\\\", \\\"{x:1266,y:468,t:1527628111654};\\\", \\\"{x:1308,y:468,t:1527628111670};\\\", \\\"{x:1347,y:468,t:1527628111687};\\\", \\\"{x:1384,y:468,t:1527628111704};\\\", \\\"{x:1407,y:468,t:1527628111720};\\\", \\\"{x:1426,y:468,t:1527628111737};\\\", \\\"{x:1436,y:468,t:1527628111754};\\\", \\\"{x:1439,y:468,t:1527628111769};\\\", \\\"{x:1440,y:468,t:1527628111787};\\\", \\\"{x:1442,y:468,t:1527628111901};\\\", \\\"{x:1443,y:468,t:1527628111916};\\\", \\\"{x:1445,y:469,t:1527628111924};\\\", \\\"{x:1448,y:470,t:1527628111938};\\\", \\\"{x:1458,y:473,t:1527628111954};\\\", \\\"{x:1478,y:477,t:1527628111971};\\\", \\\"{x:1488,y:477,t:1527628111988};\\\", \\\"{x:1498,y:479,t:1527628112004};\\\", \\\"{x:1509,y:481,t:1527628112022};\\\", \\\"{x:1516,y:482,t:1527628112037};\\\", \\\"{x:1525,y:483,t:1527628112054};\\\", \\\"{x:1531,y:484,t:1527628112071};\\\", \\\"{x:1533,y:484,t:1527628112088};\\\", \\\"{x:1534,y:484,t:1527628112104};\\\", \\\"{x:1534,y:488,t:1527628112372};\\\", \\\"{x:1530,y:495,t:1527628112388};\\\", \\\"{x:1528,y:499,t:1527628112404};\\\", \\\"{x:1525,y:505,t:1527628112422};\\\", \\\"{x:1521,y:511,t:1527628112438};\\\", \\\"{x:1518,y:519,t:1527628112454};\\\", \\\"{x:1514,y:526,t:1527628112472};\\\", \\\"{x:1510,y:535,t:1527628112488};\\\", \\\"{x:1507,y:545,t:1527628112504};\\\", \\\"{x:1503,y:551,t:1527628112521};\\\", \\\"{x:1499,y:559,t:1527628112537};\\\", \\\"{x:1495,y:567,t:1527628112555};\\\", \\\"{x:1490,y:580,t:1527628112572};\\\", \\\"{x:1488,y:586,t:1527628112589};\\\", \\\"{x:1486,y:592,t:1527628112604};\\\", \\\"{x:1485,y:601,t:1527628112621};\\\", \\\"{x:1483,y:609,t:1527628112637};\\\", \\\"{x:1481,y:620,t:1527628112654};\\\", \\\"{x:1481,y:633,t:1527628112671};\\\", \\\"{x:1481,y:648,t:1527628112687};\\\", \\\"{x:1481,y:666,t:1527628112704};\\\", \\\"{x:1481,y:681,t:1527628112721};\\\", \\\"{x:1481,y:697,t:1527628112738};\\\", \\\"{x:1481,y:712,t:1527628112754};\\\", \\\"{x:1481,y:730,t:1527628112771};\\\", \\\"{x:1481,y:739,t:1527628112787};\\\", \\\"{x:1482,y:744,t:1527628112804};\\\", \\\"{x:1483,y:750,t:1527628112821};\\\", \\\"{x:1483,y:753,t:1527628112838};\\\", \\\"{x:1483,y:758,t:1527628112854};\\\", \\\"{x:1483,y:764,t:1527628112871};\\\", \\\"{x:1483,y:773,t:1527628112887};\\\", \\\"{x:1483,y:783,t:1527628112904};\\\", \\\"{x:1480,y:794,t:1527628112921};\\\", \\\"{x:1476,y:802,t:1527628112938};\\\", \\\"{x:1472,y:807,t:1527628112954};\\\", \\\"{x:1462,y:811,t:1527628112971};\\\", \\\"{x:1456,y:813,t:1527628112988};\\\", \\\"{x:1450,y:815,t:1527628113004};\\\", \\\"{x:1446,y:815,t:1527628113021};\\\", \\\"{x:1442,y:817,t:1527628113038};\\\", \\\"{x:1438,y:818,t:1527628113054};\\\", \\\"{x:1434,y:818,t:1527628113071};\\\", \\\"{x:1429,y:818,t:1527628113088};\\\", \\\"{x:1423,y:818,t:1527628113104};\\\", \\\"{x:1420,y:819,t:1527628113121};\\\", \\\"{x:1417,y:821,t:1527628113138};\\\", \\\"{x:1416,y:821,t:1527628113154};\\\", \\\"{x:1414,y:822,t:1527628113171};\\\", \\\"{x:1413,y:822,t:1527628113188};\\\", \\\"{x:1410,y:823,t:1527628113204};\\\", \\\"{x:1406,y:824,t:1527628113221};\\\", \\\"{x:1399,y:824,t:1527628113238};\\\", \\\"{x:1392,y:826,t:1527628113254};\\\", \\\"{x:1379,y:827,t:1527628113272};\\\", \\\"{x:1363,y:830,t:1527628113288};\\\", \\\"{x:1344,y:832,t:1527628113304};\\\", \\\"{x:1321,y:834,t:1527628113321};\\\", \\\"{x:1294,y:834,t:1527628113338};\\\", \\\"{x:1265,y:834,t:1527628113354};\\\", \\\"{x:1218,y:834,t:1527628113373};\\\", \\\"{x:1195,y:834,t:1527628113388};\\\", \\\"{x:1180,y:835,t:1527628113404};\\\", \\\"{x:1171,y:836,t:1527628113421};\\\", \\\"{x:1167,y:837,t:1527628113439};\\\", \\\"{x:1168,y:837,t:1527628113596};\\\", \\\"{x:1172,y:837,t:1527628113604};\\\", \\\"{x:1179,y:837,t:1527628113622};\\\", \\\"{x:1184,y:836,t:1527628113638};\\\", \\\"{x:1189,y:835,t:1527628113655};\\\", \\\"{x:1193,y:833,t:1527628113672};\\\", \\\"{x:1196,y:832,t:1527628113688};\\\", \\\"{x:1198,y:832,t:1527628113705};\\\", \\\"{x:1199,y:831,t:1527628113721};\\\", \\\"{x:1201,y:831,t:1527628113738};\\\", \\\"{x:1202,y:831,t:1527628113763};\\\", \\\"{x:1203,y:831,t:1527628113778};\\\", \\\"{x:1204,y:831,t:1527628113794};\\\", \\\"{x:1205,y:831,t:1527628113819};\\\", \\\"{x:1206,y:831,t:1527628113826};\\\", \\\"{x:1207,y:831,t:1527628113838};\\\", \\\"{x:1210,y:831,t:1527628113855};\\\", \\\"{x:1212,y:831,t:1527628113871};\\\", \\\"{x:1213,y:831,t:1527628113890};\\\", \\\"{x:1214,y:831,t:1527628113904};\\\", \\\"{x:1215,y:831,t:1527628113921};\\\", \\\"{x:1216,y:831,t:1527628113938};\\\", \\\"{x:1218,y:831,t:1527628113955};\\\", \\\"{x:1218,y:828,t:1527628122452};\\\", \\\"{x:1210,y:821,t:1527628122460};\\\", \\\"{x:1202,y:812,t:1527628122475};\\\", \\\"{x:1200,y:810,t:1527628122491};\\\", \\\"{x:1199,y:809,t:1527628122509};\\\", \\\"{x:1199,y:808,t:1527628122595};\\\", \\\"{x:1198,y:808,t:1527628122608};\\\", \\\"{x:1195,y:804,t:1527628122625};\\\", \\\"{x:1192,y:800,t:1527628122642};\\\", \\\"{x:1184,y:795,t:1527628122658};\\\", \\\"{x:1170,y:782,t:1527628122675};\\\", \\\"{x:1152,y:770,t:1527628122692};\\\", \\\"{x:1134,y:757,t:1527628122709};\\\", \\\"{x:1113,y:744,t:1527628122726};\\\", \\\"{x:1094,y:733,t:1527628122742};\\\", \\\"{x:1075,y:723,t:1527628122759};\\\", \\\"{x:1056,y:716,t:1527628122775};\\\", \\\"{x:1035,y:706,t:1527628122792};\\\", \\\"{x:1010,y:695,t:1527628122809};\\\", \\\"{x:986,y:684,t:1527628122826};\\\", \\\"{x:960,y:672,t:1527628122842};\\\", \\\"{x:937,y:663,t:1527628122859};\\\", \\\"{x:899,y:647,t:1527628122875};\\\", \\\"{x:880,y:637,t:1527628122892};\\\", \\\"{x:863,y:631,t:1527628122909};\\\", \\\"{x:853,y:627,t:1527628122925};\\\", \\\"{x:849,y:625,t:1527628122943};\\\", \\\"{x:848,y:625,t:1527628122958};\\\", \\\"{x:846,y:624,t:1527628123075};\\\", \\\"{x:844,y:622,t:1527628123082};\\\", \\\"{x:841,y:620,t:1527628123098};\\\", \\\"{x:832,y:614,t:1527628123114};\\\", \\\"{x:821,y:609,t:1527628123131};\\\", \\\"{x:800,y:598,t:1527628123147};\\\", \\\"{x:786,y:593,t:1527628123164};\\\", \\\"{x:770,y:587,t:1527628123180};\\\", \\\"{x:756,y:579,t:1527628123198};\\\", \\\"{x:743,y:576,t:1527628123214};\\\", \\\"{x:734,y:573,t:1527628123231};\\\", \\\"{x:731,y:573,t:1527628123247};\\\", \\\"{x:727,y:571,t:1527628123265};\\\", \\\"{x:724,y:571,t:1527628123280};\\\", \\\"{x:722,y:569,t:1527628123299};\\\", \\\"{x:719,y:569,t:1527628123315};\\\", \\\"{x:716,y:568,t:1527628123330};\\\", \\\"{x:711,y:566,t:1527628123347};\\\", \\\"{x:706,y:565,t:1527628123363};\\\", \\\"{x:700,y:563,t:1527628123380};\\\", \\\"{x:689,y:561,t:1527628123398};\\\", \\\"{x:677,y:556,t:1527628123413};\\\", \\\"{x:658,y:548,t:1527628123430};\\\", \\\"{x:637,y:543,t:1527628123447};\\\", \\\"{x:615,y:536,t:1527628123465};\\\", \\\"{x:594,y:530,t:1527628123481};\\\", \\\"{x:578,y:526,t:1527628123497};\\\", \\\"{x:565,y:523,t:1527628123514};\\\", \\\"{x:556,y:520,t:1527628123531};\\\", \\\"{x:552,y:519,t:1527628123547};\\\", \\\"{x:552,y:518,t:1527628123707};\\\", \\\"{x:554,y:518,t:1527628123723};\\\", \\\"{x:556,y:518,t:1527628123731};\\\", \\\"{x:561,y:520,t:1527628123747};\\\", \\\"{x:562,y:520,t:1527628123764};\\\", \\\"{x:563,y:520,t:1527628123787};\\\", \\\"{x:564,y:520,t:1527628123800};\\\", \\\"{x:567,y:520,t:1527628123815};\\\", \\\"{x:568,y:520,t:1527628123832};\\\", \\\"{x:569,y:520,t:1527628123848};\\\", \\\"{x:571,y:520,t:1527628123865};\\\", \\\"{x:572,y:520,t:1527628123891};\\\", \\\"{x:573,y:520,t:1527628123899};\\\", \\\"{x:574,y:520,t:1527628123915};\\\", \\\"{x:578,y:520,t:1527628123932};\\\", \\\"{x:579,y:521,t:1527628123947};\\\", \\\"{x:579,y:522,t:1527628124204};\\\", \\\"{x:573,y:525,t:1527628124215};\\\", \\\"{x:557,y:526,t:1527628124232};\\\", \\\"{x:529,y:524,t:1527628124249};\\\", \\\"{x:498,y:519,t:1527628124264};\\\", \\\"{x:470,y:515,t:1527628124282};\\\", \\\"{x:453,y:512,t:1527628124298};\\\", \\\"{x:444,y:511,t:1527628124314};\\\", \\\"{x:438,y:510,t:1527628124331};\\\", \\\"{x:437,y:510,t:1527628124524};\\\", \\\"{x:433,y:506,t:1527628124532};\\\", \\\"{x:413,y:501,t:1527628124548};\\\", \\\"{x:389,y:494,t:1527628124565};\\\", \\\"{x:362,y:487,t:1527628124581};\\\", \\\"{x:333,y:483,t:1527628124598};\\\", \\\"{x:302,y:479,t:1527628124615};\\\", \\\"{x:271,y:474,t:1527628124631};\\\", \\\"{x:242,y:469,t:1527628124649};\\\", \\\"{x:214,y:466,t:1527628124665};\\\", \\\"{x:191,y:462,t:1527628124681};\\\", \\\"{x:175,y:461,t:1527628124698};\\\", \\\"{x:167,y:461,t:1527628124715};\\\", \\\"{x:165,y:461,t:1527628124731};\\\", \\\"{x:164,y:461,t:1527628124748};\\\", \\\"{x:161,y:461,t:1527628124765};\\\", \\\"{x:161,y:462,t:1527628124782};\\\", \\\"{x:159,y:462,t:1527628124798};\\\", \\\"{x:157,y:465,t:1527628124816};\\\", \\\"{x:155,y:468,t:1527628124832};\\\", \\\"{x:152,y:472,t:1527628124849};\\\", \\\"{x:150,y:475,t:1527628124866};\\\", \\\"{x:147,y:480,t:1527628124882};\\\", \\\"{x:146,y:484,t:1527628124899};\\\", \\\"{x:144,y:495,t:1527628124917};\\\", \\\"{x:143,y:500,t:1527628124932};\\\", \\\"{x:142,y:504,t:1527628124948};\\\", \\\"{x:142,y:506,t:1527628124965};\\\", \\\"{x:142,y:507,t:1527628124982};\\\", \\\"{x:143,y:507,t:1527628125332};\\\", \\\"{x:144,y:507,t:1527628125340};\\\", \\\"{x:146,y:507,t:1527628125350};\\\", \\\"{x:147,y:507,t:1527628125366};\\\", \\\"{x:148,y:507,t:1527628125531};\\\", \\\"{x:151,y:506,t:1527628125924};\\\", \\\"{x:153,y:506,t:1527628125936};\\\", \\\"{x:153,y:505,t:1527628125951};\\\", \\\"{x:154,y:505,t:1527628125966};\\\", \\\"{x:155,y:505,t:1527628125982};\\\", \\\"{x:156,y:505,t:1527628126210};\\\", \\\"{x:159,y:505,t:1527628126404};\\\", \\\"{x:166,y:505,t:1527628126417};\\\", \\\"{x:178,y:512,t:1527628126434};\\\", \\\"{x:198,y:526,t:1527628126450};\\\", \\\"{x:238,y:555,t:1527628126467};\\\", \\\"{x:272,y:579,t:1527628126486};\\\", \\\"{x:321,y:609,t:1527628126500};\\\", \\\"{x:389,y:646,t:1527628126517};\\\", \\\"{x:457,y:680,t:1527628126534};\\\", \\\"{x:520,y:708,t:1527628126550};\\\", \\\"{x:578,y:732,t:1527628126566};\\\", \\\"{x:607,y:740,t:1527628126584};\\\", \\\"{x:632,y:750,t:1527628126600};\\\", \\\"{x:652,y:756,t:1527628126616};\\\", \\\"{x:662,y:761,t:1527628126634};\\\", \\\"{x:664,y:761,t:1527628126651};\\\", \\\"{x:660,y:760,t:1527628126788};\\\", \\\"{x:654,y:757,t:1527628126800};\\\", \\\"{x:635,y:744,t:1527628126816};\\\", \\\"{x:619,y:737,t:1527628126833};\\\", \\\"{x:606,y:733,t:1527628126850};\\\", \\\"{x:597,y:730,t:1527628126867};\\\", \\\"{x:588,y:728,t:1527628126884};\\\", \\\"{x:583,y:728,t:1527628126901};\\\", \\\"{x:576,y:725,t:1527628126916};\\\", \\\"{x:574,y:725,t:1527628126934};\\\", \\\"{x:572,y:725,t:1527628126951};\\\", \\\"{x:571,y:725,t:1527628126967};\\\", \\\"{x:570,y:725,t:1527628127004};\\\", \\\"{x:569,y:725,t:1527628127018};\\\", \\\"{x:567,y:725,t:1527628127035};\\\", \\\"{x:565,y:725,t:1527628127050};\\\", \\\"{x:564,y:725,t:1527628127067};\\\", \\\"{x:562,y:725,t:1527628127084};\\\", \\\"{x:561,y:725,t:1527628127122};\\\", \\\"{x:560,y:725,t:1527628127138};\\\", \\\"{x:560,y:726,t:1527628127154};\\\", \\\"{x:559,y:726,t:1527628127203};\\\" ] }, { \\\"rt\\\": 19058, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 397460, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:558,y:726,t:1527628129714};\\\", \\\"{x:558,y:720,t:1527628129723};\\\", \\\"{x:558,y:717,t:1527628129735};\\\", \\\"{x:558,y:712,t:1527628129752};\\\", \\\"{x:558,y:706,t:1527628129769};\\\", \\\"{x:556,y:700,t:1527628129786};\\\", \\\"{x:553,y:692,t:1527628129803};\\\", \\\"{x:552,y:687,t:1527628129820};\\\", \\\"{x:550,y:683,t:1527628129836};\\\", \\\"{x:549,y:678,t:1527628129852};\\\", \\\"{x:548,y:674,t:1527628129870};\\\", \\\"{x:547,y:670,t:1527628129886};\\\", \\\"{x:546,y:667,t:1527628129903};\\\", \\\"{x:546,y:663,t:1527628129920};\\\", \\\"{x:546,y:660,t:1527628129936};\\\", \\\"{x:545,y:658,t:1527628129953};\\\", \\\"{x:545,y:655,t:1527628129970};\\\", \\\"{x:545,y:653,t:1527628129987};\\\", \\\"{x:545,y:651,t:1527628130002};\\\", \\\"{x:545,y:650,t:1527628130020};\\\", \\\"{x:544,y:647,t:1527628130037};\\\", \\\"{x:544,y:645,t:1527628130053};\\\", \\\"{x:544,y:644,t:1527628130070};\\\", \\\"{x:544,y:641,t:1527628130087};\\\", \\\"{x:545,y:638,t:1527628130104};\\\", \\\"{x:548,y:636,t:1527628130120};\\\", \\\"{x:552,y:633,t:1527628130137};\\\", \\\"{x:559,y:629,t:1527628130154};\\\", \\\"{x:564,y:620,t:1527628130170};\\\", \\\"{x:568,y:595,t:1527628130187};\\\", \\\"{x:571,y:575,t:1527628130204};\\\", \\\"{x:571,y:550,t:1527628130220};\\\", \\\"{x:571,y:522,t:1527628130237};\\\", \\\"{x:571,y:509,t:1527628130254};\\\", \\\"{x:571,y:495,t:1527628130270};\\\", \\\"{x:571,y:484,t:1527628130287};\\\", \\\"{x:571,y:477,t:1527628130304};\\\", \\\"{x:571,y:472,t:1527628130320};\\\", \\\"{x:571,y:470,t:1527628130336};\\\", \\\"{x:570,y:467,t:1527628130353};\\\", \\\"{x:570,y:465,t:1527628130370};\\\", \\\"{x:570,y:463,t:1527628130387};\\\", \\\"{x:570,y:462,t:1527628130499};\\\", \\\"{x:575,y:459,t:1527628130891};\\\", \\\"{x:581,y:457,t:1527628130904};\\\", \\\"{x:595,y:452,t:1527628130921};\\\", \\\"{x:610,y:449,t:1527628130937};\\\", \\\"{x:624,y:449,t:1527628130954};\\\", \\\"{x:634,y:447,t:1527628130971};\\\", \\\"{x:640,y:447,t:1527628130986};\\\", \\\"{x:644,y:447,t:1527628131004};\\\", \\\"{x:646,y:445,t:1527628131021};\\\", \\\"{x:650,y:445,t:1527628131038};\\\", \\\"{x:654,y:445,t:1527628131054};\\\", \\\"{x:659,y:445,t:1527628131071};\\\", \\\"{x:664,y:445,t:1527628131088};\\\", \\\"{x:670,y:445,t:1527628131104};\\\", \\\"{x:677,y:445,t:1527628131121};\\\", \\\"{x:682,y:445,t:1527628131138};\\\", \\\"{x:690,y:445,t:1527628131154};\\\", \\\"{x:702,y:445,t:1527628131170};\\\", \\\"{x:711,y:447,t:1527628131188};\\\", \\\"{x:723,y:451,t:1527628131204};\\\", \\\"{x:740,y:456,t:1527628131220};\\\", \\\"{x:758,y:462,t:1527628131238};\\\", \\\"{x:779,y:467,t:1527628131255};\\\", \\\"{x:802,y:472,t:1527628131271};\\\", \\\"{x:820,y:476,t:1527628131288};\\\", \\\"{x:841,y:478,t:1527628131304};\\\", \\\"{x:863,y:482,t:1527628131320};\\\", \\\"{x:889,y:485,t:1527628131338};\\\", \\\"{x:928,y:488,t:1527628131355};\\\", \\\"{x:952,y:490,t:1527628131371};\\\", \\\"{x:981,y:491,t:1527628131388};\\\", \\\"{x:1008,y:491,t:1527628131404};\\\", \\\"{x:1032,y:491,t:1527628131421};\\\", \\\"{x:1055,y:491,t:1527628131438};\\\", \\\"{x:1086,y:491,t:1527628131454};\\\", \\\"{x:1114,y:491,t:1527628131470};\\\", \\\"{x:1138,y:491,t:1527628131488};\\\", \\\"{x:1158,y:491,t:1527628131505};\\\", \\\"{x:1180,y:491,t:1527628131521};\\\", \\\"{x:1198,y:491,t:1527628131538};\\\", \\\"{x:1221,y:489,t:1527628131555};\\\", \\\"{x:1236,y:487,t:1527628131570};\\\", \\\"{x:1245,y:486,t:1527628131587};\\\", \\\"{x:1251,y:483,t:1527628131605};\\\", \\\"{x:1258,y:483,t:1527628131621};\\\", \\\"{x:1262,y:483,t:1527628131637};\\\", \\\"{x:1265,y:483,t:1527628131655};\\\", \\\"{x:1269,y:483,t:1527628131670};\\\", \\\"{x:1273,y:483,t:1527628131688};\\\", \\\"{x:1279,y:483,t:1527628131704};\\\", \\\"{x:1288,y:483,t:1527628131721};\\\", \\\"{x:1297,y:483,t:1527628131738};\\\", \\\"{x:1327,y:478,t:1527628131755};\\\", \\\"{x:1354,y:471,t:1527628131771};\\\", \\\"{x:1380,y:460,t:1527628131787};\\\", \\\"{x:1406,y:448,t:1527628131805};\\\", \\\"{x:1425,y:436,t:1527628131822};\\\", \\\"{x:1438,y:421,t:1527628131838};\\\", \\\"{x:1447,y:405,t:1527628131855};\\\", \\\"{x:1457,y:388,t:1527628131872};\\\", \\\"{x:1463,y:377,t:1527628131887};\\\", \\\"{x:1467,y:371,t:1527628131905};\\\", \\\"{x:1471,y:367,t:1527628131922};\\\", \\\"{x:1473,y:365,t:1527628131938};\\\", \\\"{x:1475,y:363,t:1527628131955};\\\", \\\"{x:1475,y:365,t:1527628132085};\\\", \\\"{x:1473,y:373,t:1527628132092};\\\", \\\"{x:1472,y:384,t:1527628132104};\\\", \\\"{x:1466,y:412,t:1527628132121};\\\", \\\"{x:1453,y:458,t:1527628132138};\\\", \\\"{x:1441,y:489,t:1527628132154};\\\", \\\"{x:1425,y:523,t:1527628132172};\\\", \\\"{x:1405,y:558,t:1527628132189};\\\", \\\"{x:1386,y:590,t:1527628132206};\\\", \\\"{x:1361,y:627,t:1527628132222};\\\", \\\"{x:1349,y:645,t:1527628132238};\\\", \\\"{x:1340,y:657,t:1527628132256};\\\", \\\"{x:1333,y:669,t:1527628132271};\\\", \\\"{x:1327,y:681,t:1527628132288};\\\", \\\"{x:1322,y:691,t:1527628132305};\\\", \\\"{x:1320,y:696,t:1527628132322};\\\", \\\"{x:1317,y:702,t:1527628132338};\\\", \\\"{x:1317,y:704,t:1527628132355};\\\", \\\"{x:1317,y:707,t:1527628132372};\\\", \\\"{x:1317,y:711,t:1527628132389};\\\", \\\"{x:1317,y:713,t:1527628132405};\\\", \\\"{x:1317,y:715,t:1527628132538};\\\", \\\"{x:1320,y:717,t:1527628132555};\\\", \\\"{x:1322,y:717,t:1527628132573};\\\", \\\"{x:1323,y:717,t:1527628132594};\\\", \\\"{x:1324,y:717,t:1527628132606};\\\", \\\"{x:1325,y:717,t:1527628132622};\\\", \\\"{x:1326,y:717,t:1527628132640};\\\", \\\"{x:1326,y:716,t:1527628132658};\\\", \\\"{x:1326,y:715,t:1527628132674};\\\", \\\"{x:1328,y:714,t:1527628132690};\\\", \\\"{x:1328,y:713,t:1527628132705};\\\", \\\"{x:1328,y:712,t:1527628132723};\\\", \\\"{x:1328,y:710,t:1527628132739};\\\", \\\"{x:1329,y:708,t:1527628132755};\\\", \\\"{x:1330,y:706,t:1527628132773};\\\", \\\"{x:1330,y:705,t:1527628132789};\\\", \\\"{x:1330,y:703,t:1527628132806};\\\", \\\"{x:1331,y:701,t:1527628132823};\\\", \\\"{x:1332,y:701,t:1527628132907};\\\", \\\"{x:1333,y:701,t:1527628132963};\\\", \\\"{x:1334,y:701,t:1527628132973};\\\", \\\"{x:1335,y:701,t:1527628133204};\\\", \\\"{x:1338,y:702,t:1527628133219};\\\", \\\"{x:1339,y:702,t:1527628133228};\\\", \\\"{x:1340,y:702,t:1527628133240};\\\", \\\"{x:1341,y:703,t:1527628133284};\\\", \\\"{x:1342,y:703,t:1527628133299};\\\", \\\"{x:1344,y:703,t:1527628133572};\\\", \\\"{x:1346,y:703,t:1527628133596};\\\", \\\"{x:1347,y:703,t:1527628133609};\\\", \\\"{x:1351,y:703,t:1527628133625};\\\", \\\"{x:1353,y:702,t:1527628133642};\\\", \\\"{x:1356,y:702,t:1527628133658};\\\", \\\"{x:1357,y:701,t:1527628133674};\\\", \\\"{x:1358,y:701,t:1527628133692};\\\", \\\"{x:1359,y:701,t:1527628133708};\\\", \\\"{x:1360,y:701,t:1527628133725};\\\", \\\"{x:1361,y:701,t:1527628133747};\\\", \\\"{x:1362,y:701,t:1527628133759};\\\", \\\"{x:1367,y:701,t:1527628133775};\\\", \\\"{x:1372,y:701,t:1527628133791};\\\", \\\"{x:1379,y:701,t:1527628133808};\\\", \\\"{x:1385,y:701,t:1527628133825};\\\", \\\"{x:1391,y:701,t:1527628133842};\\\", \\\"{x:1397,y:701,t:1527628133859};\\\", \\\"{x:1401,y:701,t:1527628133875};\\\", \\\"{x:1402,y:701,t:1527628133892};\\\", \\\"{x:1403,y:700,t:1527628133909};\\\", \\\"{x:1404,y:700,t:1527628133948};\\\", \\\"{x:1405,y:700,t:1527628133979};\\\", \\\"{x:1406,y:700,t:1527628133992};\\\", \\\"{x:1407,y:700,t:1527628134008};\\\", \\\"{x:1407,y:699,t:1527628134212};\\\", \\\"{x:1408,y:699,t:1527628134252};\\\", \\\"{x:1409,y:699,t:1527628134276};\\\", \\\"{x:1410,y:698,t:1527628134292};\\\", \\\"{x:1411,y:698,t:1527628134309};\\\", \\\"{x:1413,y:697,t:1527628134325};\\\", \\\"{x:1414,y:697,t:1527628134343};\\\", \\\"{x:1416,y:697,t:1527628134360};\\\", \\\"{x:1417,y:696,t:1527628134377};\\\", \\\"{x:1420,y:696,t:1527628134393};\\\", \\\"{x:1421,y:696,t:1527628134411};\\\", \\\"{x:1423,y:695,t:1527628134427};\\\", \\\"{x:1425,y:695,t:1527628134442};\\\", \\\"{x:1429,y:695,t:1527628134460};\\\", \\\"{x:1431,y:695,t:1527628134476};\\\", \\\"{x:1432,y:695,t:1527628134492};\\\", \\\"{x:1434,y:695,t:1527628134555};\\\", \\\"{x:1436,y:695,t:1527628134563};\\\", \\\"{x:1437,y:695,t:1527628134576};\\\", \\\"{x:1441,y:695,t:1527628134594};\\\", \\\"{x:1444,y:695,t:1527628134609};\\\", \\\"{x:1447,y:695,t:1527628134627};\\\", \\\"{x:1452,y:695,t:1527628134643};\\\", \\\"{x:1457,y:695,t:1527628134660};\\\", \\\"{x:1461,y:695,t:1527628134676};\\\", \\\"{x:1464,y:695,t:1527628134694};\\\", \\\"{x:1467,y:695,t:1527628134710};\\\", \\\"{x:1470,y:695,t:1527628134727};\\\", \\\"{x:1472,y:695,t:1527628134747};\\\", \\\"{x:1473,y:695,t:1527628134820};\\\", \\\"{x:1474,y:695,t:1527628134836};\\\", \\\"{x:1475,y:695,t:1527628134844};\\\", \\\"{x:1476,y:695,t:1527628134861};\\\", \\\"{x:1478,y:696,t:1527628134876};\\\", \\\"{x:1479,y:696,t:1527628134893};\\\", \\\"{x:1480,y:696,t:1527628135004};\\\", \\\"{x:1481,y:696,t:1527628135339};\\\", \\\"{x:1484,y:696,t:1527628135346};\\\", \\\"{x:1487,y:696,t:1527628135360};\\\", \\\"{x:1491,y:696,t:1527628135377};\\\", \\\"{x:1495,y:696,t:1527628135394};\\\", \\\"{x:1497,y:696,t:1527628135410};\\\", \\\"{x:1500,y:696,t:1527628135427};\\\", \\\"{x:1502,y:695,t:1527628135444};\\\", \\\"{x:1504,y:695,t:1527628135460};\\\", \\\"{x:1508,y:695,t:1527628135477};\\\", \\\"{x:1510,y:695,t:1527628135494};\\\", \\\"{x:1512,y:695,t:1527628135511};\\\", \\\"{x:1513,y:694,t:1527628135527};\\\", \\\"{x:1517,y:694,t:1527628135544};\\\", \\\"{x:1519,y:694,t:1527628135561};\\\", \\\"{x:1522,y:694,t:1527628135577};\\\", \\\"{x:1524,y:694,t:1527628135594};\\\", \\\"{x:1527,y:694,t:1527628135611};\\\", \\\"{x:1529,y:694,t:1527628135627};\\\", \\\"{x:1531,y:694,t:1527628135644};\\\", \\\"{x:1532,y:694,t:1527628135675};\\\", \\\"{x:1534,y:694,t:1527628135708};\\\", \\\"{x:1537,y:694,t:1527628135716};\\\", \\\"{x:1538,y:694,t:1527628135731};\\\", \\\"{x:1539,y:694,t:1527628135744};\\\", \\\"{x:1540,y:694,t:1527628135761};\\\", \\\"{x:1543,y:694,t:1527628135779};\\\", \\\"{x:1547,y:694,t:1527628135794};\\\", \\\"{x:1550,y:694,t:1527628135812};\\\", \\\"{x:1552,y:694,t:1527628135828};\\\", \\\"{x:1553,y:694,t:1527628135972};\\\", \\\"{x:1556,y:694,t:1527628135987};\\\", \\\"{x:1559,y:694,t:1527628135996};\\\", \\\"{x:1566,y:694,t:1527628136012};\\\", \\\"{x:1576,y:694,t:1527628136029};\\\", \\\"{x:1590,y:694,t:1527628136045};\\\", \\\"{x:1605,y:694,t:1527628136060};\\\", \\\"{x:1617,y:694,t:1527628136078};\\\", \\\"{x:1624,y:694,t:1527628136095};\\\", \\\"{x:1626,y:693,t:1527628136112};\\\", \\\"{x:1626,y:692,t:1527628136436};\\\", \\\"{x:1625,y:692,t:1527628136451};\\\", \\\"{x:1624,y:691,t:1527628136463};\\\", \\\"{x:1623,y:691,t:1527628136500};\\\", \\\"{x:1622,y:691,t:1527628136513};\\\", \\\"{x:1621,y:691,t:1527628136532};\\\", \\\"{x:1620,y:691,t:1527628136612};\\\", \\\"{x:1620,y:692,t:1527628136630};\\\", \\\"{x:1619,y:692,t:1527628136676};\\\", \\\"{x:1617,y:693,t:1527628136732};\\\", \\\"{x:1617,y:694,t:1527628136787};\\\", \\\"{x:1611,y:694,t:1527628146090};\\\", \\\"{x:1600,y:689,t:1527628146099};\\\", \\\"{x:1587,y:684,t:1527628146110};\\\", \\\"{x:1508,y:653,t:1527628146127};\\\", \\\"{x:1414,y:613,t:1527628146144};\\\", \\\"{x:1291,y:571,t:1527628146160};\\\", \\\"{x:1172,y:535,t:1527628146177};\\\", \\\"{x:1001,y:490,t:1527628146194};\\\", \\\"{x:905,y:480,t:1527628146211};\\\", \\\"{x:846,y:470,t:1527628146227};\\\", \\\"{x:823,y:466,t:1527628146244};\\\", \\\"{x:816,y:466,t:1527628146260};\\\", \\\"{x:817,y:470,t:1527628146354};\\\", \\\"{x:823,y:482,t:1527628146362};\\\", \\\"{x:834,y:500,t:1527628146377};\\\", \\\"{x:847,y:537,t:1527628146394};\\\", \\\"{x:851,y:556,t:1527628146412};\\\", \\\"{x:853,y:566,t:1527628146434};\\\", \\\"{x:853,y:571,t:1527628146449};\\\", \\\"{x:853,y:577,t:1527628146466};\\\", \\\"{x:852,y:582,t:1527628146482};\\\", \\\"{x:835,y:581,t:1527628146499};\\\", \\\"{x:809,y:572,t:1527628146516};\\\", \\\"{x:787,y:568,t:1527628146532};\\\", \\\"{x:766,y:565,t:1527628146549};\\\", \\\"{x:744,y:561,t:1527628146566};\\\", \\\"{x:723,y:559,t:1527628146583};\\\", \\\"{x:715,y:559,t:1527628146599};\\\", \\\"{x:709,y:559,t:1527628146616};\\\", \\\"{x:707,y:559,t:1527628146632};\\\", \\\"{x:705,y:559,t:1527628146649};\\\", \\\"{x:702,y:559,t:1527628146666};\\\", \\\"{x:701,y:560,t:1527628146682};\\\", \\\"{x:700,y:561,t:1527628146722};\\\", \\\"{x:699,y:562,t:1527628146732};\\\", \\\"{x:695,y:565,t:1527628146750};\\\", \\\"{x:690,y:567,t:1527628146767};\\\", \\\"{x:686,y:569,t:1527628146783};\\\", \\\"{x:681,y:572,t:1527628146799};\\\", \\\"{x:677,y:575,t:1527628146816};\\\", \\\"{x:672,y:576,t:1527628146833};\\\", \\\"{x:662,y:577,t:1527628146849};\\\", \\\"{x:649,y:577,t:1527628146866};\\\", \\\"{x:643,y:577,t:1527628146883};\\\", \\\"{x:639,y:577,t:1527628146900};\\\", \\\"{x:638,y:577,t:1527628146916};\\\", \\\"{x:637,y:577,t:1527628146934};\\\", \\\"{x:636,y:577,t:1527628146962};\\\", \\\"{x:635,y:577,t:1527628146979};\\\", \\\"{x:634,y:577,t:1527628146986};\\\", \\\"{x:633,y:578,t:1527628146999};\\\", \\\"{x:631,y:579,t:1527628147016};\\\", \\\"{x:628,y:579,t:1527628147034};\\\", \\\"{x:626,y:579,t:1527628147049};\\\", \\\"{x:625,y:579,t:1527628147074};\\\", \\\"{x:624,y:579,t:1527628147083};\\\", \\\"{x:622,y:579,t:1527628147099};\\\", \\\"{x:620,y:579,t:1527628147116};\\\", \\\"{x:619,y:579,t:1527628147133};\\\", \\\"{x:618,y:579,t:1527628147150};\\\", \\\"{x:615,y:583,t:1527628147467};\\\", \\\"{x:608,y:598,t:1527628147484};\\\", \\\"{x:597,y:617,t:1527628147502};\\\", \\\"{x:580,y:635,t:1527628147518};\\\", \\\"{x:559,y:659,t:1527628147533};\\\", \\\"{x:545,y:677,t:1527628147551};\\\", \\\"{x:535,y:686,t:1527628147567};\\\", \\\"{x:532,y:695,t:1527628147583};\\\", \\\"{x:530,y:697,t:1527628147601};\\\", \\\"{x:528,y:697,t:1527628147617};\\\", \\\"{x:528,y:699,t:1527628147634};\\\", \\\"{x:529,y:699,t:1527628147836};\\\", \\\"{x:531,y:699,t:1527628147867};\\\", \\\"{x:531,y:701,t:1527628147907};\\\", \\\"{x:531,y:705,t:1527628147918};\\\", \\\"{x:531,y:714,t:1527628147934};\\\", \\\"{x:531,y:722,t:1527628147950};\\\", \\\"{x:531,y:727,t:1527628147967};\\\", \\\"{x:531,y:732,t:1527628147984};\\\", \\\"{x:530,y:734,t:1527628148001};\\\", \\\"{x:529,y:734,t:1527628148017};\\\", \\\"{x:528,y:735,t:1527628148091};\\\", \\\"{x:527,y:735,t:1527628148235};\\\", \\\"{x:526,y:735,t:1527628148285};\\\", \\\"{x:525,y:735,t:1527628148300};\\\", \\\"{x:524,y:735,t:1527628148395};\\\", \\\"{x:524,y:734,t:1527628148410};\\\", \\\"{x:524,y:733,t:1527628148418};\\\", \\\"{x:524,y:730,t:1527628148435};\\\", \\\"{x:524,y:728,t:1527628148450};\\\", \\\"{x:523,y:725,t:1527628148468};\\\", \\\"{x:522,y:719,t:1527628148484};\\\", \\\"{x:521,y:711,t:1527628148502};\\\", \\\"{x:518,y:700,t:1527628148518};\\\", \\\"{x:513,y:686,t:1527628148535};\\\", \\\"{x:510,y:672,t:1527628148551};\\\", \\\"{x:503,y:657,t:1527628148567};\\\", \\\"{x:497,y:642,t:1527628148585};\\\", \\\"{x:495,y:631,t:1527628148601};\\\", \\\"{x:490,y:616,t:1527628148617};\\\", \\\"{x:485,y:600,t:1527628148634};\\\", \\\"{x:482,y:586,t:1527628148651};\\\", \\\"{x:478,y:572,t:1527628148669};\\\", \\\"{x:476,y:566,t:1527628148685};\\\", \\\"{x:475,y:563,t:1527628148702};\\\", \\\"{x:474,y:559,t:1527628148718};\\\", \\\"{x:473,y:557,t:1527628148734};\\\", \\\"{x:472,y:555,t:1527628148752};\\\", \\\"{x:472,y:552,t:1527628148769};\\\", \\\"{x:472,y:550,t:1527628148784};\\\", \\\"{x:470,y:546,t:1527628148801};\\\", \\\"{x:469,y:543,t:1527628148819};\\\", \\\"{x:468,y:540,t:1527628148835};\\\", \\\"{x:468,y:539,t:1527628148851};\\\", \\\"{x:467,y:539,t:1527628148869};\\\", \\\"{x:467,y:537,t:1527628148885};\\\", \\\"{x:467,y:536,t:1527628148907};\\\", \\\"{x:466,y:535,t:1527628148972};\\\" ] }, { \\\"rt\\\": 15048, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 413708, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:466,y:532,t:1527628150684};\\\", \\\"{x:471,y:524,t:1527628150705};\\\", \\\"{x:473,y:519,t:1527628150719};\\\", \\\"{x:476,y:514,t:1527628150737};\\\", \\\"{x:479,y:508,t:1527628150752};\\\", \\\"{x:481,y:504,t:1527628150769};\\\", \\\"{x:487,y:496,t:1527628150786};\\\", \\\"{x:489,y:493,t:1527628150803};\\\", \\\"{x:492,y:489,t:1527628150820};\\\", \\\"{x:494,y:486,t:1527628150837};\\\", \\\"{x:495,y:484,t:1527628150853};\\\", \\\"{x:496,y:483,t:1527628150869};\\\", \\\"{x:497,y:481,t:1527628150886};\\\", \\\"{x:498,y:480,t:1527628150904};\\\", \\\"{x:499,y:479,t:1527628150955};\\\", \\\"{x:499,y:477,t:1527628150971};\\\", \\\"{x:499,y:476,t:1527628150987};\\\", \\\"{x:501,y:474,t:1527628151003};\\\", \\\"{x:501,y:473,t:1527628151019};\\\", \\\"{x:502,y:471,t:1527628151037};\\\", \\\"{x:502,y:470,t:1527628151053};\\\", \\\"{x:502,y:469,t:1527628151070};\\\", \\\"{x:504,y:467,t:1527628151087};\\\", \\\"{x:504,y:466,t:1527628151107};\\\", \\\"{x:504,y:464,t:1527628151120};\\\", \\\"{x:505,y:464,t:1527628151137};\\\", \\\"{x:505,y:462,t:1527628151153};\\\", \\\"{x:505,y:461,t:1527628151170};\\\", \\\"{x:506,y:460,t:1527628151187};\\\", \\\"{x:511,y:460,t:1527628152348};\\\", \\\"{x:531,y:463,t:1527628152355};\\\", \\\"{x:584,y:463,t:1527628152372};\\\", \\\"{x:648,y:463,t:1527628152388};\\\", \\\"{x:693,y:463,t:1527628152405};\\\", \\\"{x:732,y:463,t:1527628152422};\\\", \\\"{x:764,y:463,t:1527628152438};\\\", \\\"{x:800,y:463,t:1527628152456};\\\", \\\"{x:832,y:463,t:1527628152472};\\\", \\\"{x:855,y:463,t:1527628152488};\\\", \\\"{x:869,y:463,t:1527628152505};\\\", \\\"{x:874,y:463,t:1527628152522};\\\", \\\"{x:877,y:463,t:1527628152539};\\\", \\\"{x:879,y:463,t:1527628152555};\\\", \\\"{x:880,y:463,t:1527628152572};\\\", \\\"{x:882,y:463,t:1527628152590};\\\", \\\"{x:883,y:463,t:1527628152605};\\\", \\\"{x:889,y:463,t:1527628152622};\\\", \\\"{x:900,y:464,t:1527628152639};\\\", \\\"{x:921,y:467,t:1527628152655};\\\", \\\"{x:954,y:472,t:1527628152673};\\\", \\\"{x:1002,y:481,t:1527628152690};\\\", \\\"{x:1052,y:487,t:1527628152705};\\\", \\\"{x:1100,y:493,t:1527628152722};\\\", \\\"{x:1180,y:506,t:1527628152739};\\\", \\\"{x:1242,y:516,t:1527628152756};\\\", \\\"{x:1310,y:530,t:1527628152772};\\\", \\\"{x:1368,y:538,t:1527628152790};\\\", \\\"{x:1418,y:542,t:1527628152805};\\\", \\\"{x:1460,y:550,t:1527628152822};\\\", \\\"{x:1492,y:555,t:1527628152840};\\\", \\\"{x:1516,y:558,t:1527628152857};\\\", \\\"{x:1538,y:561,t:1527628152873};\\\", \\\"{x:1554,y:563,t:1527628152890};\\\", \\\"{x:1560,y:564,t:1527628152907};\\\", \\\"{x:1563,y:565,t:1527628152922};\\\", \\\"{x:1564,y:565,t:1527628152940};\\\", \\\"{x:1563,y:565,t:1527628153228};\\\", \\\"{x:1562,y:564,t:1527628153244};\\\", \\\"{x:1561,y:564,t:1527628153259};\\\", \\\"{x:1560,y:563,t:1527628153308};\\\", \\\"{x:1558,y:563,t:1527628153331};\\\", \\\"{x:1557,y:563,t:1527628153371};\\\", \\\"{x:1556,y:562,t:1527628153380};\\\", \\\"{x:1555,y:561,t:1527628153411};\\\", \\\"{x:1554,y:561,t:1527628153443};\\\", \\\"{x:1553,y:560,t:1527628153468};\\\", \\\"{x:1552,y:560,t:1527628153499};\\\", \\\"{x:1550,y:559,t:1527628153531};\\\", \\\"{x:1549,y:558,t:1527628153540};\\\", \\\"{x:1548,y:558,t:1527628153563};\\\", \\\"{x:1546,y:557,t:1527628153579};\\\", \\\"{x:1545,y:556,t:1527628153612};\\\", \\\"{x:1543,y:556,t:1527628153652};\\\", \\\"{x:1542,y:555,t:1527628153675};\\\", \\\"{x:1540,y:555,t:1527628153764};\\\", \\\"{x:1540,y:554,t:1527628153819};\\\", \\\"{x:1539,y:554,t:1527628153867};\\\", \\\"{x:1537,y:554,t:1527628153971};\\\", \\\"{x:1537,y:553,t:1527628154003};\\\", \\\"{x:1536,y:552,t:1527628154019};\\\", \\\"{x:1535,y:552,t:1527628154075};\\\", \\\"{x:1534,y:552,t:1527628154091};\\\", \\\"{x:1533,y:551,t:1527628154139};\\\", \\\"{x:1532,y:551,t:1527628154196};\\\", \\\"{x:1531,y:551,t:1527628154207};\\\", \\\"{x:1530,y:551,t:1527628154276};\\\", \\\"{x:1534,y:552,t:1527628154572};\\\", \\\"{x:1539,y:555,t:1527628154579};\\\", \\\"{x:1544,y:564,t:1527628154591};\\\", \\\"{x:1546,y:580,t:1527628154608};\\\", \\\"{x:1547,y:602,t:1527628154624};\\\", \\\"{x:1547,y:631,t:1527628154641};\\\", \\\"{x:1547,y:656,t:1527628154658};\\\", \\\"{x:1547,y:683,t:1527628154674};\\\", \\\"{x:1547,y:720,t:1527628154691};\\\", \\\"{x:1544,y:741,t:1527628154707};\\\", \\\"{x:1539,y:758,t:1527628154725};\\\", \\\"{x:1531,y:778,t:1527628154741};\\\", \\\"{x:1522,y:793,t:1527628154758};\\\", \\\"{x:1514,y:812,t:1527628154774};\\\", \\\"{x:1506,y:826,t:1527628154793};\\\", \\\"{x:1497,y:846,t:1527628154808};\\\", \\\"{x:1485,y:863,t:1527628154825};\\\", \\\"{x:1478,y:877,t:1527628154842};\\\", \\\"{x:1466,y:894,t:1527628154858};\\\", \\\"{x:1453,y:909,t:1527628154875};\\\", \\\"{x:1429,y:929,t:1527628154892};\\\", \\\"{x:1412,y:942,t:1527628154908};\\\", \\\"{x:1392,y:955,t:1527628154924};\\\", \\\"{x:1372,y:964,t:1527628154942};\\\", \\\"{x:1356,y:971,t:1527628154959};\\\", \\\"{x:1344,y:974,t:1527628154975};\\\", \\\"{x:1340,y:974,t:1527628154992};\\\", \\\"{x:1337,y:974,t:1527628155008};\\\", \\\"{x:1335,y:974,t:1527628155076};\\\", \\\"{x:1334,y:971,t:1527628155091};\\\", \\\"{x:1334,y:968,t:1527628155109};\\\", \\\"{x:1334,y:965,t:1527628155125};\\\", \\\"{x:1334,y:963,t:1527628155142};\\\", \\\"{x:1334,y:961,t:1527628155159};\\\", \\\"{x:1334,y:959,t:1527628155176};\\\", \\\"{x:1334,y:958,t:1527628155191};\\\", \\\"{x:1334,y:957,t:1527628155212};\\\", \\\"{x:1334,y:956,t:1527628155235};\\\", \\\"{x:1335,y:955,t:1527628155251};\\\", \\\"{x:1336,y:955,t:1527628155268};\\\", \\\"{x:1338,y:955,t:1527628155294};\\\", \\\"{x:1340,y:955,t:1527628155309};\\\", \\\"{x:1341,y:954,t:1527628156100};\\\", \\\"{x:1341,y:950,t:1527628156110};\\\", \\\"{x:1341,y:941,t:1527628156127};\\\", \\\"{x:1341,y:933,t:1527628156142};\\\", \\\"{x:1343,y:924,t:1527628156159};\\\", \\\"{x:1343,y:919,t:1527628156176};\\\", \\\"{x:1344,y:914,t:1527628156193};\\\", \\\"{x:1344,y:911,t:1527628156210};\\\", \\\"{x:1344,y:908,t:1527628156227};\\\", \\\"{x:1344,y:905,t:1527628156243};\\\", \\\"{x:1344,y:900,t:1527628156260};\\\", \\\"{x:1344,y:898,t:1527628156277};\\\", \\\"{x:1344,y:894,t:1527628156293};\\\", \\\"{x:1344,y:890,t:1527628156309};\\\", \\\"{x:1344,y:883,t:1527628156326};\\\", \\\"{x:1344,y:877,t:1527628156343};\\\", \\\"{x:1344,y:871,t:1527628156359};\\\", \\\"{x:1344,y:868,t:1527628156376};\\\", \\\"{x:1344,y:864,t:1527628156393};\\\", \\\"{x:1344,y:859,t:1527628156409};\\\", \\\"{x:1342,y:853,t:1527628156426};\\\", \\\"{x:1341,y:844,t:1527628156442};\\\", \\\"{x:1339,y:836,t:1527628156459};\\\", \\\"{x:1337,y:831,t:1527628156476};\\\", \\\"{x:1337,y:827,t:1527628156493};\\\", \\\"{x:1337,y:824,t:1527628156509};\\\", \\\"{x:1336,y:820,t:1527628156526};\\\", \\\"{x:1336,y:818,t:1527628156543};\\\", \\\"{x:1336,y:814,t:1527628156559};\\\", \\\"{x:1336,y:811,t:1527628156575};\\\", \\\"{x:1335,y:806,t:1527628156593};\\\", \\\"{x:1334,y:799,t:1527628156608};\\\", \\\"{x:1334,y:791,t:1527628156626};\\\", \\\"{x:1334,y:779,t:1527628156642};\\\", \\\"{x:1334,y:775,t:1527628156660};\\\", \\\"{x:1334,y:771,t:1527628156676};\\\", \\\"{x:1334,y:768,t:1527628156693};\\\", \\\"{x:1334,y:766,t:1527628156710};\\\", \\\"{x:1334,y:764,t:1527628156727};\\\", \\\"{x:1334,y:763,t:1527628156747};\\\", \\\"{x:1334,y:762,t:1527628156763};\\\", \\\"{x:1334,y:761,t:1527628156777};\\\", \\\"{x:1334,y:760,t:1527628156793};\\\", \\\"{x:1334,y:759,t:1527628156810};\\\", \\\"{x:1334,y:757,t:1527628156826};\\\", \\\"{x:1335,y:755,t:1527628156843};\\\", \\\"{x:1335,y:754,t:1527628156860};\\\", \\\"{x:1334,y:750,t:1527628157179};\\\", \\\"{x:1329,y:742,t:1527628157193};\\\", \\\"{x:1313,y:727,t:1527628157210};\\\", \\\"{x:1296,y:700,t:1527628157227};\\\", \\\"{x:1289,y:688,t:1527628157244};\\\", \\\"{x:1284,y:678,t:1527628157260};\\\", \\\"{x:1280,y:669,t:1527628157277};\\\", \\\"{x:1276,y:661,t:1527628157294};\\\", \\\"{x:1272,y:656,t:1527628157310};\\\", \\\"{x:1268,y:650,t:1527628157327};\\\", \\\"{x:1267,y:648,t:1527628157344};\\\", \\\"{x:1265,y:645,t:1527628157361};\\\", \\\"{x:1263,y:644,t:1527628157507};\\\", \\\"{x:1262,y:644,t:1527628157515};\\\", \\\"{x:1259,y:642,t:1527628157527};\\\", \\\"{x:1256,y:642,t:1527628157544};\\\", \\\"{x:1252,y:640,t:1527628157560};\\\", \\\"{x:1250,y:639,t:1527628157577};\\\", \\\"{x:1249,y:639,t:1527628157594};\\\", \\\"{x:1247,y:638,t:1527628157610};\\\", \\\"{x:1244,y:637,t:1527628157628};\\\", \\\"{x:1241,y:637,t:1527628157645};\\\", \\\"{x:1238,y:636,t:1527628157662};\\\", \\\"{x:1237,y:636,t:1527628157677};\\\", \\\"{x:1234,y:636,t:1527628157695};\\\", \\\"{x:1231,y:635,t:1527628157712};\\\", \\\"{x:1229,y:635,t:1527628157727};\\\", \\\"{x:1228,y:635,t:1527628157744};\\\", \\\"{x:1226,y:635,t:1527628157761};\\\", \\\"{x:1225,y:634,t:1527628157777};\\\", \\\"{x:1224,y:634,t:1527628157835};\\\", \\\"{x:1222,y:632,t:1527628158292};\\\", \\\"{x:1219,y:632,t:1527628158299};\\\", \\\"{x:1213,y:632,t:1527628158312};\\\", \\\"{x:1205,y:632,t:1527628158329};\\\", \\\"{x:1194,y:632,t:1527628158346};\\\", \\\"{x:1181,y:632,t:1527628158362};\\\", \\\"{x:1165,y:632,t:1527628158378};\\\", \\\"{x:1133,y:632,t:1527628158395};\\\", \\\"{x:1112,y:632,t:1527628158411};\\\", \\\"{x:1086,y:632,t:1527628158429};\\\", \\\"{x:1060,y:632,t:1527628158446};\\\", \\\"{x:1034,y:632,t:1527628158462};\\\", \\\"{x:1018,y:632,t:1527628158478};\\\", \\\"{x:1003,y:629,t:1527628158495};\\\", \\\"{x:992,y:628,t:1527628158512};\\\", \\\"{x:984,y:627,t:1527628158528};\\\", \\\"{x:976,y:626,t:1527628158545};\\\", \\\"{x:966,y:625,t:1527628158561};\\\", \\\"{x:957,y:622,t:1527628158578};\\\", \\\"{x:940,y:621,t:1527628158596};\\\", \\\"{x:925,y:618,t:1527628158611};\\\", \\\"{x:908,y:616,t:1527628158627};\\\", \\\"{x:885,y:612,t:1527628158645};\\\", \\\"{x:860,y:609,t:1527628158660};\\\", \\\"{x:834,y:605,t:1527628158675};\\\", \\\"{x:810,y:601,t:1527628158693};\\\", \\\"{x:790,y:599,t:1527628158709};\\\", \\\"{x:770,y:596,t:1527628158725};\\\", \\\"{x:752,y:595,t:1527628158743};\\\", \\\"{x:741,y:594,t:1527628158759};\\\", \\\"{x:733,y:591,t:1527628158776};\\\", \\\"{x:726,y:591,t:1527628158793};\\\", \\\"{x:720,y:590,t:1527628158810};\\\", \\\"{x:716,y:590,t:1527628158826};\\\", \\\"{x:709,y:589,t:1527628158843};\\\", \\\"{x:708,y:588,t:1527628158860};\\\", \\\"{x:706,y:588,t:1527628158898};\\\", \\\"{x:705,y:588,t:1527628158930};\\\", \\\"{x:704,y:588,t:1527628158947};\\\", \\\"{x:703,y:587,t:1527628158960};\\\", \\\"{x:701,y:587,t:1527628158977};\\\", \\\"{x:700,y:587,t:1527628158993};\\\", \\\"{x:699,y:587,t:1527628159010};\\\", \\\"{x:693,y:584,t:1527628159027};\\\", \\\"{x:690,y:584,t:1527628159043};\\\", \\\"{x:685,y:584,t:1527628159060};\\\", \\\"{x:680,y:583,t:1527628159076};\\\", \\\"{x:673,y:583,t:1527628159093};\\\", \\\"{x:664,y:580,t:1527628159110};\\\", \\\"{x:660,y:580,t:1527628159126};\\\", \\\"{x:653,y:579,t:1527628159143};\\\", \\\"{x:649,y:578,t:1527628159160};\\\", \\\"{x:645,y:578,t:1527628159177};\\\", \\\"{x:641,y:577,t:1527628159194};\\\", \\\"{x:638,y:576,t:1527628159210};\\\", \\\"{x:635,y:576,t:1527628159226};\\\", \\\"{x:633,y:575,t:1527628159242};\\\", \\\"{x:630,y:575,t:1527628159259};\\\", \\\"{x:628,y:574,t:1527628159277};\\\", \\\"{x:626,y:574,t:1527628159295};\\\", \\\"{x:624,y:573,t:1527628159309};\\\", \\\"{x:622,y:573,t:1527628159325};\\\", \\\"{x:621,y:572,t:1527628159342};\\\", \\\"{x:619,y:571,t:1527628159359};\\\", \\\"{x:617,y:571,t:1527628159376};\\\", \\\"{x:612,y:570,t:1527628159392};\\\", \\\"{x:610,y:569,t:1527628159409};\\\", \\\"{x:608,y:568,t:1527628159426};\\\", \\\"{x:605,y:567,t:1527628159442};\\\", \\\"{x:602,y:566,t:1527628159459};\\\", \\\"{x:602,y:565,t:1527628159477};\\\", \\\"{x:600,y:564,t:1527628159492};\\\", \\\"{x:597,y:561,t:1527628159510};\\\", \\\"{x:594,y:558,t:1527628159527};\\\", \\\"{x:594,y:552,t:1527628159544};\\\", \\\"{x:592,y:548,t:1527628159560};\\\", \\\"{x:592,y:542,t:1527628159576};\\\", \\\"{x:592,y:539,t:1527628159593};\\\", \\\"{x:592,y:535,t:1527628159610};\\\", \\\"{x:592,y:532,t:1527628159627};\\\", \\\"{x:592,y:531,t:1527628159644};\\\", \\\"{x:592,y:530,t:1527628159660};\\\", \\\"{x:587,y:527,t:1527628159955};\\\", \\\"{x:580,y:525,t:1527628159963};\\\", \\\"{x:568,y:521,t:1527628159979};\\\", \\\"{x:537,y:518,t:1527628159994};\\\", \\\"{x:491,y:510,t:1527628160010};\\\", \\\"{x:442,y:504,t:1527628160026};\\\", \\\"{x:421,y:501,t:1527628160044};\\\", \\\"{x:412,y:501,t:1527628160061};\\\", \\\"{x:405,y:501,t:1527628160077};\\\", \\\"{x:399,y:501,t:1527628160094};\\\", \\\"{x:392,y:502,t:1527628160110};\\\", \\\"{x:391,y:503,t:1527628160127};\\\", \\\"{x:389,y:505,t:1527628160145};\\\", \\\"{x:387,y:509,t:1527628160160};\\\", \\\"{x:384,y:512,t:1527628160177};\\\", \\\"{x:380,y:516,t:1527628160195};\\\", \\\"{x:378,y:519,t:1527628160210};\\\", \\\"{x:375,y:524,t:1527628160227};\\\", \\\"{x:373,y:529,t:1527628160245};\\\", \\\"{x:371,y:534,t:1527628160262};\\\", \\\"{x:369,y:538,t:1527628160277};\\\", \\\"{x:366,y:541,t:1527628160294};\\\", \\\"{x:362,y:544,t:1527628160311};\\\", \\\"{x:359,y:547,t:1527628160327};\\\", \\\"{x:344,y:556,t:1527628160345};\\\", \\\"{x:331,y:561,t:1527628160362};\\\", \\\"{x:314,y:567,t:1527628160378};\\\", \\\"{x:285,y:573,t:1527628160394};\\\", \\\"{x:263,y:577,t:1527628160412};\\\", \\\"{x:236,y:582,t:1527628160426};\\\", \\\"{x:213,y:584,t:1527628160444};\\\", \\\"{x:191,y:588,t:1527628160461};\\\", \\\"{x:172,y:588,t:1527628160477};\\\", \\\"{x:154,y:592,t:1527628160494};\\\", \\\"{x:140,y:594,t:1527628160512};\\\", \\\"{x:129,y:596,t:1527628160527};\\\", \\\"{x:122,y:598,t:1527628160544};\\\", \\\"{x:117,y:600,t:1527628160561};\\\", \\\"{x:116,y:601,t:1527628160579};\\\", \\\"{x:117,y:598,t:1527628160675};\\\", \\\"{x:119,y:589,t:1527628160695};\\\", \\\"{x:124,y:577,t:1527628160711};\\\", \\\"{x:126,y:568,t:1527628160728};\\\", \\\"{x:126,y:562,t:1527628160745};\\\", \\\"{x:127,y:557,t:1527628160762};\\\", \\\"{x:128,y:554,t:1527628160779};\\\", \\\"{x:129,y:551,t:1527628160794};\\\", \\\"{x:131,y:549,t:1527628160811};\\\", \\\"{x:131,y:548,t:1527628160828};\\\", \\\"{x:132,y:547,t:1527628160939};\\\", \\\"{x:133,y:546,t:1527628160955};\\\", \\\"{x:135,y:544,t:1527628160963};\\\", \\\"{x:136,y:543,t:1527628160978};\\\", \\\"{x:143,y:540,t:1527628160994};\\\", \\\"{x:148,y:539,t:1527628161011};\\\", \\\"{x:149,y:538,t:1527628161029};\\\", \\\"{x:149,y:537,t:1527628161074};\\\", \\\"{x:150,y:537,t:1527628161082};\\\", \\\"{x:152,y:536,t:1527628161498};\\\", \\\"{x:157,y:534,t:1527628161512};\\\", \\\"{x:165,y:531,t:1527628161528};\\\", \\\"{x:173,y:527,t:1527628161546};\\\", \\\"{x:182,y:523,t:1527628161562};\\\", \\\"{x:185,y:523,t:1527628161578};\\\", \\\"{x:189,y:520,t:1527628161595};\\\", \\\"{x:190,y:520,t:1527628161612};\\\", \\\"{x:192,y:519,t:1527628161628};\\\", \\\"{x:193,y:519,t:1527628161645};\\\", \\\"{x:194,y:519,t:1527628161662};\\\", \\\"{x:195,y:519,t:1527628161678};\\\", \\\"{x:196,y:519,t:1527628161706};\\\", \\\"{x:197,y:519,t:1527628161747};\\\", \\\"{x:202,y:521,t:1527628161763};\\\", \\\"{x:207,y:525,t:1527628161780};\\\", \\\"{x:216,y:531,t:1527628161795};\\\", \\\"{x:224,y:534,t:1527628161812};\\\", \\\"{x:235,y:539,t:1527628161828};\\\", \\\"{x:251,y:543,t:1527628161845};\\\", \\\"{x:277,y:550,t:1527628161863};\\\", \\\"{x:322,y:556,t:1527628161880};\\\", \\\"{x:386,y:565,t:1527628161896};\\\", \\\"{x:445,y:565,t:1527628161912};\\\", \\\"{x:498,y:565,t:1527628161928};\\\", \\\"{x:562,y:565,t:1527628161946};\\\", \\\"{x:676,y:565,t:1527628161962};\\\", \\\"{x:748,y:565,t:1527628161979};\\\", \\\"{x:809,y:565,t:1527628161995};\\\", \\\"{x:857,y:565,t:1527628162012};\\\", \\\"{x:893,y:565,t:1527628162029};\\\", \\\"{x:924,y:565,t:1527628162045};\\\", \\\"{x:938,y:565,t:1527628162062};\\\", \\\"{x:949,y:565,t:1527628162079};\\\", \\\"{x:953,y:565,t:1527628162095};\\\", \\\"{x:954,y:565,t:1527628162179};\\\", \\\"{x:954,y:564,t:1527628162196};\\\", \\\"{x:947,y:558,t:1527628162212};\\\", \\\"{x:933,y:551,t:1527628162230};\\\", \\\"{x:917,y:544,t:1527628162247};\\\", \\\"{x:904,y:539,t:1527628162262};\\\", \\\"{x:892,y:534,t:1527628162280};\\\", \\\"{x:888,y:532,t:1527628162296};\\\", \\\"{x:887,y:532,t:1527628162312};\\\", \\\"{x:884,y:531,t:1527628162330};\\\", \\\"{x:878,y:530,t:1527628162347};\\\", \\\"{x:873,y:530,t:1527628162362};\\\", \\\"{x:868,y:527,t:1527628162379};\\\", \\\"{x:864,y:526,t:1527628162396};\\\", \\\"{x:863,y:526,t:1527628162413};\\\", \\\"{x:862,y:525,t:1527628162459};\\\", \\\"{x:860,y:524,t:1527628162468};\\\", \\\"{x:859,y:523,t:1527628162479};\\\", \\\"{x:852,y:521,t:1527628162496};\\\", \\\"{x:848,y:519,t:1527628162512};\\\", \\\"{x:847,y:519,t:1527628162529};\\\", \\\"{x:846,y:517,t:1527628162611};\\\", \\\"{x:842,y:512,t:1527628162629};\\\", \\\"{x:838,y:507,t:1527628162646};\\\", \\\"{x:835,y:504,t:1527628162663};\\\", \\\"{x:835,y:503,t:1527628163171};\\\", \\\"{x:833,y:503,t:1527628163180};\\\", \\\"{x:825,y:507,t:1527628163197};\\\", \\\"{x:814,y:516,t:1527628163213};\\\", \\\"{x:801,y:528,t:1527628163230};\\\", \\\"{x:786,y:541,t:1527628163246};\\\", \\\"{x:767,y:555,t:1527628163264};\\\", \\\"{x:746,y:570,t:1527628163281};\\\", \\\"{x:726,y:583,t:1527628163296};\\\", \\\"{x:705,y:594,t:1527628163314};\\\", \\\"{x:676,y:611,t:1527628163331};\\\", \\\"{x:653,y:621,t:1527628163346};\\\", \\\"{x:633,y:628,t:1527628163363};\\\", \\\"{x:612,y:639,t:1527628163381};\\\", \\\"{x:597,y:644,t:1527628163396};\\\", \\\"{x:587,y:649,t:1527628163413};\\\", \\\"{x:579,y:652,t:1527628163430};\\\", \\\"{x:569,y:657,t:1527628163448};\\\", \\\"{x:561,y:661,t:1527628163464};\\\", \\\"{x:556,y:663,t:1527628163481};\\\", \\\"{x:549,y:668,t:1527628163497};\\\", \\\"{x:545,y:672,t:1527628163513};\\\", \\\"{x:539,y:679,t:1527628163530};\\\", \\\"{x:532,y:687,t:1527628163547};\\\", \\\"{x:528,y:692,t:1527628163563};\\\", \\\"{x:521,y:701,t:1527628163580};\\\", \\\"{x:517,y:714,t:1527628163597};\\\", \\\"{x:512,y:728,t:1527628163614};\\\", \\\"{x:507,y:738,t:1527628163630};\\\", \\\"{x:505,y:744,t:1527628163648};\\\", \\\"{x:503,y:750,t:1527628163663};\\\", \\\"{x:501,y:754,t:1527628163681};\\\", \\\"{x:500,y:756,t:1527628163698};\\\", \\\"{x:500,y:757,t:1527628163713};\\\", \\\"{x:500,y:755,t:1527628164084};\\\", \\\"{x:500,y:754,t:1527628164108};\\\", \\\"{x:500,y:753,t:1527628164114};\\\", \\\"{x:500,y:752,t:1527628164131};\\\", \\\"{x:500,y:749,t:1527628164147};\\\", \\\"{x:500,y:748,t:1527628164163};\\\", \\\"{x:500,y:747,t:1527628164180};\\\", \\\"{x:500,y:746,t:1527628164197};\\\", \\\"{x:500,y:744,t:1527628164214};\\\", \\\"{x:500,y:743,t:1527628164234};\\\", \\\"{x:500,y:742,t:1527628164248};\\\", \\\"{x:500,y:740,t:1527628164264};\\\", \\\"{x:500,y:736,t:1527628164280};\\\", \\\"{x:500,y:735,t:1527628164299};\\\" ] }, { \\\"rt\\\": 9392, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 424310, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:728,t:1527628166395};\\\", \\\"{x:500,y:689,t:1527628166430};\\\", \\\"{x:501,y:673,t:1527628166449};\\\", \\\"{x:505,y:655,t:1527628166465};\\\", \\\"{x:510,y:629,t:1527628166483};\\\", \\\"{x:513,y:611,t:1527628166500};\\\", \\\"{x:519,y:590,t:1527628166516};\\\", \\\"{x:524,y:572,t:1527628166532};\\\", \\\"{x:529,y:556,t:1527628166550};\\\", \\\"{x:532,y:547,t:1527628166566};\\\", \\\"{x:534,y:538,t:1527628166582};\\\", \\\"{x:536,y:530,t:1527628166599};\\\", \\\"{x:536,y:525,t:1527628166616};\\\", \\\"{x:536,y:521,t:1527628166632};\\\", \\\"{x:536,y:520,t:1527628166649};\\\", \\\"{x:537,y:516,t:1527628166667};\\\", \\\"{x:537,y:514,t:1527628166682};\\\", \\\"{x:537,y:513,t:1527628166700};\\\", \\\"{x:537,y:511,t:1527628166716};\\\", \\\"{x:537,y:510,t:1527628166738};\\\", \\\"{x:537,y:509,t:1527628166754};\\\", \\\"{x:537,y:507,t:1527628166766};\\\", \\\"{x:537,y:505,t:1527628166782};\\\", \\\"{x:537,y:503,t:1527628166799};\\\", \\\"{x:537,y:502,t:1527628166817};\\\", \\\"{x:537,y:500,t:1527628166832};\\\", \\\"{x:537,y:499,t:1527628166849};\\\", \\\"{x:537,y:496,t:1527628166866};\\\", \\\"{x:537,y:495,t:1527628166882};\\\", \\\"{x:537,y:493,t:1527628166899};\\\", \\\"{x:537,y:491,t:1527628166916};\\\", \\\"{x:537,y:490,t:1527628166933};\\\", \\\"{x:537,y:488,t:1527628166949};\\\", \\\"{x:537,y:487,t:1527628166967};\\\", \\\"{x:537,y:484,t:1527628166984};\\\", \\\"{x:537,y:482,t:1527628167000};\\\", \\\"{x:537,y:480,t:1527628167016};\\\", \\\"{x:537,y:479,t:1527628167034};\\\", \\\"{x:537,y:478,t:1527628167049};\\\", \\\"{x:537,y:476,t:1527628167067};\\\", \\\"{x:537,y:475,t:1527628167082};\\\", \\\"{x:537,y:474,t:1527628167099};\\\", \\\"{x:537,y:472,t:1527628167116};\\\", \\\"{x:537,y:471,t:1527628167133};\\\", \\\"{x:537,y:469,t:1527628167149};\\\", \\\"{x:537,y:468,t:1527628167171};\\\", \\\"{x:537,y:467,t:1527628167182};\\\", \\\"{x:537,y:466,t:1527628167210};\\\", \\\"{x:537,y:465,t:1527628167226};\\\", \\\"{x:538,y:464,t:1527628167259};\\\", \\\"{x:542,y:461,t:1527628167852};\\\", \\\"{x:556,y:455,t:1527628167867};\\\", \\\"{x:577,y:446,t:1527628167883};\\\", \\\"{x:601,y:437,t:1527628167900};\\\", \\\"{x:623,y:429,t:1527628167916};\\\", \\\"{x:639,y:426,t:1527628167934};\\\", \\\"{x:658,y:426,t:1527628167950};\\\", \\\"{x:675,y:426,t:1527628167967};\\\", \\\"{x:695,y:426,t:1527628167983};\\\", \\\"{x:723,y:428,t:1527628168000};\\\", \\\"{x:770,y:439,t:1527628168017};\\\", \\\"{x:821,y:448,t:1527628168034};\\\", \\\"{x:898,y:467,t:1527628168051};\\\", \\\"{x:947,y:478,t:1527628168067};\\\", \\\"{x:1008,y:486,t:1527628168085};\\\", \\\"{x:1065,y:496,t:1527628168101};\\\", \\\"{x:1117,y:508,t:1527628168117};\\\", \\\"{x:1162,y:522,t:1527628168134};\\\", \\\"{x:1196,y:532,t:1527628168151};\\\", \\\"{x:1220,y:540,t:1527628168167};\\\", \\\"{x:1237,y:545,t:1527628168184};\\\", \\\"{x:1251,y:551,t:1527628168201};\\\", \\\"{x:1259,y:553,t:1527628168217};\\\", \\\"{x:1267,y:557,t:1527628168234};\\\", \\\"{x:1280,y:562,t:1527628168253};\\\", \\\"{x:1288,y:566,t:1527628168266};\\\", \\\"{x:1293,y:568,t:1527628168283};\\\", \\\"{x:1298,y:570,t:1527628168301};\\\", \\\"{x:1302,y:573,t:1527628168316};\\\", \\\"{x:1304,y:575,t:1527628168333};\\\", \\\"{x:1306,y:577,t:1527628168351};\\\", \\\"{x:1306,y:578,t:1527628168367};\\\", \\\"{x:1306,y:579,t:1527628168475};\\\", \\\"{x:1306,y:580,t:1527628168491};\\\", \\\"{x:1306,y:581,t:1527628168501};\\\", \\\"{x:1305,y:582,t:1527628168517};\\\", \\\"{x:1304,y:584,t:1527628169308};\\\", \\\"{x:1304,y:589,t:1527628169318};\\\", \\\"{x:1304,y:602,t:1527628169335};\\\", \\\"{x:1304,y:615,t:1527628169351};\\\", \\\"{x:1304,y:628,t:1527628169368};\\\", \\\"{x:1306,y:638,t:1527628169385};\\\", \\\"{x:1307,y:646,t:1527628169401};\\\", \\\"{x:1307,y:651,t:1527628169417};\\\", \\\"{x:1308,y:656,t:1527628169434};\\\", \\\"{x:1308,y:658,t:1527628169451};\\\", \\\"{x:1309,y:660,t:1527628169468};\\\", \\\"{x:1309,y:663,t:1527628169485};\\\", \\\"{x:1309,y:665,t:1527628169501};\\\", \\\"{x:1309,y:669,t:1527628169518};\\\", \\\"{x:1309,y:673,t:1527628169535};\\\", \\\"{x:1309,y:677,t:1527628169550};\\\", \\\"{x:1309,y:681,t:1527628169567};\\\", \\\"{x:1309,y:684,t:1527628169584};\\\", \\\"{x:1309,y:686,t:1527628169601};\\\", \\\"{x:1309,y:687,t:1527628169618};\\\", \\\"{x:1309,y:689,t:1527628169634};\\\", \\\"{x:1310,y:689,t:1527628169651};\\\", \\\"{x:1311,y:690,t:1527628169668};\\\", \\\"{x:1312,y:690,t:1527628169691};\\\", \\\"{x:1313,y:690,t:1527628169701};\\\", \\\"{x:1315,y:691,t:1527628169718};\\\", \\\"{x:1316,y:691,t:1527628169735};\\\", \\\"{x:1318,y:692,t:1527628169751};\\\", \\\"{x:1319,y:692,t:1527628169768};\\\", \\\"{x:1320,y:692,t:1527628169785};\\\", \\\"{x:1323,y:692,t:1527628169801};\\\", \\\"{x:1325,y:692,t:1527628169818};\\\", \\\"{x:1328,y:692,t:1527628169835};\\\", \\\"{x:1329,y:692,t:1527628169851};\\\", \\\"{x:1331,y:692,t:1527628169868};\\\", \\\"{x:1332,y:692,t:1527628169891};\\\", \\\"{x:1333,y:692,t:1527628169901};\\\", \\\"{x:1334,y:693,t:1527628169918};\\\", \\\"{x:1336,y:694,t:1527628169935};\\\", \\\"{x:1338,y:694,t:1527628169952};\\\", \\\"{x:1339,y:695,t:1527628169968};\\\", \\\"{x:1340,y:696,t:1527628169985};\\\", \\\"{x:1341,y:701,t:1527628170522};\\\", \\\"{x:1342,y:706,t:1527628170533};\\\", \\\"{x:1343,y:716,t:1527628170550};\\\", \\\"{x:1343,y:724,t:1527628170566};\\\", \\\"{x:1343,y:733,t:1527628170583};\\\", \\\"{x:1343,y:739,t:1527628170599};\\\", \\\"{x:1343,y:746,t:1527628170616};\\\", \\\"{x:1343,y:750,t:1527628170632};\\\", \\\"{x:1343,y:752,t:1527628170649};\\\", \\\"{x:1343,y:754,t:1527628170666};\\\", \\\"{x:1343,y:755,t:1527628170682};\\\", \\\"{x:1343,y:757,t:1527628170700};\\\", \\\"{x:1343,y:760,t:1527628170717};\\\", \\\"{x:1343,y:762,t:1527628170732};\\\", \\\"{x:1343,y:765,t:1527628170750};\\\", \\\"{x:1343,y:766,t:1527628170767};\\\", \\\"{x:1343,y:767,t:1527628172587};\\\", \\\"{x:1319,y:752,t:1527628172601};\\\", \\\"{x:1258,y:724,t:1527628172618};\\\", \\\"{x:1202,y:699,t:1527628172634};\\\", \\\"{x:1147,y:677,t:1527628172651};\\\", \\\"{x:1117,y:670,t:1527628172668};\\\", \\\"{x:1093,y:663,t:1527628172684};\\\", \\\"{x:1072,y:655,t:1527628172701};\\\", \\\"{x:1055,y:652,t:1527628172718};\\\", \\\"{x:1042,y:648,t:1527628172734};\\\", \\\"{x:1027,y:643,t:1527628172751};\\\", \\\"{x:1017,y:638,t:1527628172769};\\\", \\\"{x:1007,y:632,t:1527628172784};\\\", \\\"{x:986,y:619,t:1527628172801};\\\", \\\"{x:976,y:614,t:1527628172819};\\\", \\\"{x:960,y:607,t:1527628172834};\\\", \\\"{x:943,y:598,t:1527628172851};\\\", \\\"{x:923,y:589,t:1527628172870};\\\", \\\"{x:898,y:579,t:1527628172883};\\\", \\\"{x:872,y:569,t:1527628172900};\\\", \\\"{x:837,y:555,t:1527628172919};\\\", \\\"{x:800,y:543,t:1527628172936};\\\", \\\"{x:756,y:531,t:1527628172952};\\\", \\\"{x:678,y:518,t:1527628172969};\\\", \\\"{x:608,y:506,t:1527628172986};\\\", \\\"{x:526,y:491,t:1527628173003};\\\", \\\"{x:457,y:482,t:1527628173019};\\\", \\\"{x:379,y:470,t:1527628173035};\\\", \\\"{x:303,y:457,t:1527628173053};\\\", \\\"{x:241,y:447,t:1527628173068};\\\", \\\"{x:194,y:441,t:1527628173085};\\\", \\\"{x:157,y:436,t:1527628173103};\\\", \\\"{x:137,y:435,t:1527628173118};\\\", \\\"{x:127,y:435,t:1527628173136};\\\", \\\"{x:122,y:435,t:1527628173153};\\\", \\\"{x:120,y:435,t:1527628173169};\\\", \\\"{x:116,y:438,t:1527628173185};\\\", \\\"{x:113,y:439,t:1527628173203};\\\", \\\"{x:105,y:447,t:1527628173220};\\\", \\\"{x:99,y:454,t:1527628173236};\\\", \\\"{x:94,y:470,t:1527628173253};\\\", \\\"{x:91,y:491,t:1527628173270};\\\", \\\"{x:88,y:511,t:1527628173286};\\\", \\\"{x:85,y:533,t:1527628173304};\\\", \\\"{x:85,y:545,t:1527628173320};\\\", \\\"{x:85,y:553,t:1527628173336};\\\", \\\"{x:93,y:563,t:1527628173353};\\\", \\\"{x:101,y:565,t:1527628173370};\\\", \\\"{x:104,y:565,t:1527628173385};\\\", \\\"{x:105,y:565,t:1527628173402};\\\", \\\"{x:106,y:565,t:1527628173420};\\\", \\\"{x:108,y:565,t:1527628173436};\\\", \\\"{x:109,y:565,t:1527628173464};\\\", \\\"{x:109,y:564,t:1527628173480};\\\", \\\"{x:110,y:564,t:1527628173488};\\\", \\\"{x:111,y:562,t:1527628173503};\\\", \\\"{x:113,y:557,t:1527628173520};\\\", \\\"{x:116,y:553,t:1527628173536};\\\", \\\"{x:122,y:547,t:1527628173553};\\\", \\\"{x:125,y:545,t:1527628173569};\\\", \\\"{x:129,y:544,t:1527628173586};\\\", \\\"{x:131,y:542,t:1527628173603};\\\", \\\"{x:134,y:540,t:1527628173620};\\\", \\\"{x:139,y:537,t:1527628173635};\\\", \\\"{x:142,y:536,t:1527628173653};\\\", \\\"{x:143,y:535,t:1527628173670};\\\", \\\"{x:144,y:535,t:1527628174033};\\\", \\\"{x:145,y:535,t:1527628174049};\\\", \\\"{x:148,y:535,t:1527628174057};\\\", \\\"{x:150,y:535,t:1527628174071};\\\", \\\"{x:154,y:539,t:1527628174086};\\\", \\\"{x:156,y:542,t:1527628174104};\\\", \\\"{x:157,y:542,t:1527628174136};\\\", \\\"{x:159,y:542,t:1527628174456};\\\", \\\"{x:166,y:544,t:1527628174471};\\\", \\\"{x:192,y:563,t:1527628174488};\\\", \\\"{x:230,y:592,t:1527628174503};\\\", \\\"{x:269,y:619,t:1527628174520};\\\", \\\"{x:331,y:662,t:1527628174537};\\\", \\\"{x:366,y:688,t:1527628174554};\\\", \\\"{x:396,y:710,t:1527628174571};\\\", \\\"{x:416,y:722,t:1527628174587};\\\", \\\"{x:427,y:732,t:1527628174604};\\\", \\\"{x:431,y:735,t:1527628174620};\\\", \\\"{x:432,y:735,t:1527628174636};\\\", \\\"{x:433,y:735,t:1527628174654};\\\", \\\"{x:434,y:736,t:1527628174671};\\\", \\\"{x:435,y:736,t:1527628174686};\\\", \\\"{x:436,y:737,t:1527628174825};\\\", \\\"{x:437,y:737,t:1527628174838};\\\", \\\"{x:440,y:737,t:1527628174854};\\\", \\\"{x:442,y:738,t:1527628174871};\\\", \\\"{x:445,y:738,t:1527628174889};\\\", \\\"{x:447,y:738,t:1527628174904};\\\", \\\"{x:453,y:738,t:1527628174920};\\\", \\\"{x:454,y:738,t:1527628174938};\\\", \\\"{x:456,y:738,t:1527628175000};\\\", \\\"{x:457,y:738,t:1527628175016};\\\", \\\"{x:459,y:738,t:1527628175032};\\\", \\\"{x:460,y:738,t:1527628175048};\\\", \\\"{x:460,y:738,t:1527628175134};\\\" ] }, { \\\"rt\\\": 34685, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 460222, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -F -F -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:463,y:737,t:1527628177313};\\\", \\\"{x:465,y:733,t:1527628177347};\\\", \\\"{x:466,y:733,t:1527628177358};\\\", \\\"{x:466,y:732,t:1527628177384};\\\", \\\"{x:467,y:732,t:1527628177424};\\\", \\\"{x:467,y:731,t:1527628177441};\\\", \\\"{x:468,y:730,t:1527628177464};\\\", \\\"{x:468,y:729,t:1527628177475};\\\", \\\"{x:469,y:728,t:1527628177528};\\\", \\\"{x:470,y:728,t:1527628177594};\\\", \\\"{x:470,y:726,t:1527628177608};\\\", \\\"{x:470,y:725,t:1527628177625};\\\", \\\"{x:471,y:725,t:1527628177642};\\\", \\\"{x:471,y:724,t:1527628177659};\\\", \\\"{x:471,y:723,t:1527628177675};\\\", \\\"{x:472,y:723,t:1527628177692};\\\", \\\"{x:473,y:722,t:1527628177721};\\\", \\\"{x:473,y:720,t:1527628177745};\\\", \\\"{x:475,y:719,t:1527628177761};\\\", \\\"{x:475,y:718,t:1527628177776};\\\", \\\"{x:476,y:717,t:1527628177789};\\\", \\\"{x:476,y:716,t:1527628177806};\\\", \\\"{x:477,y:715,t:1527628177823};\\\", \\\"{x:479,y:712,t:1527628177839};\\\", \\\"{x:482,y:709,t:1527628177855};\\\", \\\"{x:484,y:706,t:1527628177872};\\\", \\\"{x:487,y:703,t:1527628177890};\\\", \\\"{x:488,y:702,t:1527628177906};\\\", \\\"{x:491,y:699,t:1527628177923};\\\", \\\"{x:492,y:699,t:1527628177940};\\\", \\\"{x:494,y:697,t:1527628177956};\\\", \\\"{x:496,y:696,t:1527628177973};\\\", \\\"{x:497,y:695,t:1527628177992};\\\", \\\"{x:498,y:694,t:1527628178040};\\\", \\\"{x:499,y:694,t:1527628178393};\\\", \\\"{x:500,y:692,t:1527628178407};\\\", \\\"{x:504,y:689,t:1527628178423};\\\", \\\"{x:509,y:686,t:1527628178440};\\\", \\\"{x:516,y:682,t:1527628178457};\\\", \\\"{x:523,y:678,t:1527628178473};\\\", \\\"{x:529,y:676,t:1527628178490};\\\", \\\"{x:535,y:672,t:1527628178507};\\\", \\\"{x:544,y:668,t:1527628178523};\\\", \\\"{x:550,y:667,t:1527628178540};\\\", \\\"{x:556,y:664,t:1527628178557};\\\", \\\"{x:562,y:662,t:1527628178575};\\\", \\\"{x:566,y:660,t:1527628178590};\\\", \\\"{x:571,y:659,t:1527628178608};\\\", \\\"{x:574,y:657,t:1527628178624};\\\", \\\"{x:580,y:656,t:1527628178641};\\\", \\\"{x:584,y:655,t:1527628178656};\\\", \\\"{x:587,y:653,t:1527628178674};\\\", \\\"{x:589,y:653,t:1527628178690};\\\", \\\"{x:592,y:652,t:1527628178707};\\\", \\\"{x:594,y:652,t:1527628178736};\\\", \\\"{x:595,y:651,t:1527628178752};\\\", \\\"{x:598,y:651,t:1527628178905};\\\", \\\"{x:600,y:650,t:1527628178913};\\\", \\\"{x:603,y:650,t:1527628178925};\\\", \\\"{x:611,y:649,t:1527628178941};\\\", \\\"{x:627,y:647,t:1527628178957};\\\", \\\"{x:650,y:644,t:1527628178974};\\\", \\\"{x:678,y:639,t:1527628178990};\\\", \\\"{x:709,y:638,t:1527628179007};\\\", \\\"{x:768,y:633,t:1527628179024};\\\", \\\"{x:816,y:633,t:1527628179040};\\\", \\\"{x:861,y:633,t:1527628179057};\\\", \\\"{x:908,y:633,t:1527628179074};\\\", \\\"{x:945,y:633,t:1527628179091};\\\", \\\"{x:979,y:633,t:1527628179107};\\\", \\\"{x:1013,y:633,t:1527628179125};\\\", \\\"{x:1049,y:633,t:1527628179142};\\\", \\\"{x:1081,y:633,t:1527628179158};\\\", \\\"{x:1113,y:633,t:1527628179174};\\\", \\\"{x:1143,y:633,t:1527628179191};\\\", \\\"{x:1180,y:633,t:1527628179207};\\\", \\\"{x:1239,y:633,t:1527628179224};\\\", \\\"{x:1272,y:633,t:1527628179240};\\\", \\\"{x:1311,y:636,t:1527628179257};\\\", \\\"{x:1340,y:636,t:1527628179274};\\\", \\\"{x:1369,y:638,t:1527628179291};\\\", \\\"{x:1392,y:642,t:1527628179307};\\\", \\\"{x:1417,y:645,t:1527628179324};\\\", \\\"{x:1436,y:647,t:1527628179341};\\\", \\\"{x:1450,y:649,t:1527628179357};\\\", \\\"{x:1455,y:650,t:1527628179374};\\\", \\\"{x:1457,y:650,t:1527628179391};\\\", \\\"{x:1459,y:659,t:1527628179689};\\\", \\\"{x:1466,y:669,t:1527628179697};\\\", \\\"{x:1477,y:681,t:1527628179708};\\\", \\\"{x:1493,y:701,t:1527628179724};\\\", \\\"{x:1510,y:722,t:1527628179741};\\\", \\\"{x:1527,y:739,t:1527628179759};\\\", \\\"{x:1544,y:751,t:1527628179774};\\\", \\\"{x:1559,y:761,t:1527628179792};\\\", \\\"{x:1573,y:767,t:1527628179809};\\\", \\\"{x:1576,y:770,t:1527628179825};\\\", \\\"{x:1578,y:770,t:1527628179842};\\\", \\\"{x:1579,y:771,t:1527628179859};\\\", \\\"{x:1581,y:772,t:1527628179913};\\\", \\\"{x:1582,y:772,t:1527628179929};\\\", \\\"{x:1583,y:772,t:1527628179942};\\\", \\\"{x:1583,y:773,t:1527628179958};\\\", \\\"{x:1584,y:774,t:1527628179977};\\\", \\\"{x:1583,y:774,t:1527628181033};\\\", \\\"{x:1581,y:775,t:1527628181042};\\\", \\\"{x:1576,y:776,t:1527628181060};\\\", \\\"{x:1570,y:778,t:1527628181076};\\\", \\\"{x:1563,y:781,t:1527628181092};\\\", \\\"{x:1558,y:781,t:1527628181109};\\\", \\\"{x:1552,y:782,t:1527628181126};\\\", \\\"{x:1549,y:782,t:1527628181143};\\\", \\\"{x:1548,y:783,t:1527628181160};\\\", \\\"{x:1547,y:780,t:1527628181410};\\\", \\\"{x:1546,y:769,t:1527628181426};\\\", \\\"{x:1543,y:758,t:1527628181443};\\\", \\\"{x:1543,y:749,t:1527628181460};\\\", \\\"{x:1543,y:742,t:1527628181476};\\\", \\\"{x:1543,y:736,t:1527628181493};\\\", \\\"{x:1542,y:731,t:1527628181510};\\\", \\\"{x:1539,y:726,t:1527628181526};\\\", \\\"{x:1538,y:722,t:1527628181543};\\\", \\\"{x:1536,y:716,t:1527628181560};\\\", \\\"{x:1536,y:710,t:1527628181577};\\\", \\\"{x:1536,y:706,t:1527628181593};\\\", \\\"{x:1536,y:701,t:1527628181609};\\\", \\\"{x:1536,y:697,t:1527628181627};\\\", \\\"{x:1536,y:692,t:1527628181643};\\\", \\\"{x:1536,y:690,t:1527628181660};\\\", \\\"{x:1537,y:686,t:1527628181677};\\\", \\\"{x:1538,y:683,t:1527628181693};\\\", \\\"{x:1538,y:680,t:1527628181710};\\\", \\\"{x:1539,y:676,t:1527628181727};\\\", \\\"{x:1539,y:673,t:1527628181743};\\\", \\\"{x:1539,y:671,t:1527628181759};\\\", \\\"{x:1539,y:669,t:1527628181776};\\\", \\\"{x:1540,y:668,t:1527628181792};\\\", \\\"{x:1540,y:666,t:1527628181809};\\\", \\\"{x:1540,y:664,t:1527628181826};\\\", \\\"{x:1540,y:662,t:1527628181842};\\\", \\\"{x:1540,y:658,t:1527628181859};\\\", \\\"{x:1540,y:655,t:1527628181876};\\\", \\\"{x:1540,y:651,t:1527628181893};\\\", \\\"{x:1540,y:647,t:1527628181909};\\\", \\\"{x:1538,y:643,t:1527628181926};\\\", \\\"{x:1535,y:639,t:1527628181943};\\\", \\\"{x:1534,y:636,t:1527628181959};\\\", \\\"{x:1527,y:631,t:1527628181977};\\\", \\\"{x:1524,y:627,t:1527628181993};\\\", \\\"{x:1519,y:625,t:1527628182010};\\\", \\\"{x:1515,y:622,t:1527628182026};\\\", \\\"{x:1512,y:620,t:1527628182043};\\\", \\\"{x:1510,y:618,t:1527628182059};\\\", \\\"{x:1508,y:618,t:1527628182076};\\\", \\\"{x:1507,y:617,t:1527628182093};\\\", \\\"{x:1507,y:616,t:1527628182109};\\\", \\\"{x:1506,y:615,t:1527628182126};\\\", \\\"{x:1504,y:615,t:1527628182490};\\\", \\\"{x:1502,y:615,t:1527628182505};\\\", \\\"{x:1499,y:615,t:1527628182512};\\\", \\\"{x:1495,y:624,t:1527628182526};\\\", \\\"{x:1492,y:632,t:1527628182543};\\\", \\\"{x:1486,y:646,t:1527628182560};\\\", \\\"{x:1482,y:652,t:1527628182576};\\\", \\\"{x:1480,y:655,t:1527628182593};\\\", \\\"{x:1480,y:656,t:1527628182673};\\\", \\\"{x:1479,y:658,t:1527628182681};\\\", \\\"{x:1477,y:661,t:1527628182694};\\\", \\\"{x:1475,y:664,t:1527628182711};\\\", \\\"{x:1473,y:669,t:1527628182726};\\\", \\\"{x:1470,y:674,t:1527628182743};\\\", \\\"{x:1465,y:681,t:1527628182761};\\\", \\\"{x:1463,y:683,t:1527628182776};\\\", \\\"{x:1462,y:685,t:1527628182793};\\\", \\\"{x:1462,y:686,t:1527628182810};\\\", \\\"{x:1462,y:688,t:1527628182827};\\\", \\\"{x:1461,y:689,t:1527628182843};\\\", \\\"{x:1461,y:693,t:1527628182860};\\\", \\\"{x:1460,y:694,t:1527628182876};\\\", \\\"{x:1459,y:697,t:1527628182894};\\\", \\\"{x:1459,y:700,t:1527628182910};\\\", \\\"{x:1459,y:702,t:1527628182927};\\\", \\\"{x:1459,y:705,t:1527628182944};\\\", \\\"{x:1458,y:708,t:1527628182961};\\\", \\\"{x:1457,y:710,t:1527628182978};\\\", \\\"{x:1457,y:713,t:1527628182993};\\\", \\\"{x:1455,y:718,t:1527628183010};\\\", \\\"{x:1455,y:720,t:1527628183027};\\\", \\\"{x:1453,y:722,t:1527628183043};\\\", \\\"{x:1452,y:723,t:1527628183060};\\\", \\\"{x:1451,y:724,t:1527628183077};\\\", \\\"{x:1450,y:726,t:1527628183093};\\\", \\\"{x:1449,y:727,t:1527628183110};\\\", \\\"{x:1448,y:729,t:1527628183127};\\\", \\\"{x:1446,y:731,t:1527628183143};\\\", \\\"{x:1443,y:734,t:1527628183160};\\\", \\\"{x:1443,y:736,t:1527628183178};\\\", \\\"{x:1441,y:739,t:1527628183194};\\\", \\\"{x:1441,y:745,t:1527628183210};\\\", \\\"{x:1439,y:754,t:1527628183227};\\\", \\\"{x:1439,y:764,t:1527628183243};\\\", \\\"{x:1439,y:774,t:1527628183260};\\\", \\\"{x:1439,y:781,t:1527628183278};\\\", \\\"{x:1439,y:786,t:1527628183293};\\\", \\\"{x:1440,y:790,t:1527628183310};\\\", \\\"{x:1444,y:792,t:1527628183327};\\\", \\\"{x:1449,y:793,t:1527628183343};\\\", \\\"{x:1458,y:794,t:1527628183361};\\\", \\\"{x:1468,y:796,t:1527628183378};\\\", \\\"{x:1476,y:797,t:1527628183393};\\\", \\\"{x:1481,y:798,t:1527628183411};\\\", \\\"{x:1488,y:799,t:1527628183427};\\\", \\\"{x:1496,y:800,t:1527628183445};\\\", \\\"{x:1500,y:800,t:1527628183461};\\\", \\\"{x:1505,y:800,t:1527628183477};\\\", \\\"{x:1511,y:800,t:1527628183495};\\\", \\\"{x:1515,y:801,t:1527628183510};\\\", \\\"{x:1519,y:801,t:1527628183528};\\\", \\\"{x:1527,y:803,t:1527628183545};\\\", \\\"{x:1534,y:804,t:1527628183560};\\\", \\\"{x:1543,y:807,t:1527628183577};\\\", \\\"{x:1561,y:813,t:1527628183594};\\\", \\\"{x:1577,y:821,t:1527628183610};\\\", \\\"{x:1598,y:828,t:1527628183627};\\\", \\\"{x:1614,y:833,t:1527628183645};\\\", \\\"{x:1629,y:838,t:1527628183660};\\\", \\\"{x:1633,y:839,t:1527628183678};\\\", \\\"{x:1635,y:840,t:1527628183695};\\\", \\\"{x:1629,y:836,t:1527628183785};\\\", \\\"{x:1621,y:831,t:1527628183794};\\\", \\\"{x:1601,y:817,t:1527628183811};\\\", \\\"{x:1594,y:813,t:1527628183828};\\\", \\\"{x:1591,y:811,t:1527628183844};\\\", \\\"{x:1589,y:809,t:1527628183861};\\\", \\\"{x:1588,y:807,t:1527628183877};\\\", \\\"{x:1585,y:799,t:1527628183894};\\\", \\\"{x:1582,y:786,t:1527628183911};\\\", \\\"{x:1577,y:773,t:1527628183927};\\\", \\\"{x:1573,y:756,t:1527628183944};\\\", \\\"{x:1569,y:744,t:1527628183961};\\\", \\\"{x:1567,y:735,t:1527628183977};\\\", \\\"{x:1564,y:726,t:1527628183994};\\\", \\\"{x:1561,y:717,t:1527628184011};\\\", \\\"{x:1556,y:707,t:1527628184027};\\\", \\\"{x:1555,y:704,t:1527628184044};\\\", \\\"{x:1554,y:701,t:1527628184061};\\\", \\\"{x:1554,y:700,t:1527628184076};\\\", \\\"{x:1553,y:698,t:1527628184095};\\\", \\\"{x:1552,y:697,t:1527628184120};\\\", \\\"{x:1551,y:696,t:1527628184127};\\\", \\\"{x:1549,y:694,t:1527628184144};\\\", \\\"{x:1547,y:691,t:1527628184161};\\\", \\\"{x:1544,y:687,t:1527628184177};\\\", \\\"{x:1542,y:686,t:1527628184194};\\\", \\\"{x:1540,y:685,t:1527628184212};\\\", \\\"{x:1540,y:684,t:1527628184227};\\\", \\\"{x:1549,y:687,t:1527628184649};\\\", \\\"{x:1557,y:690,t:1527628184661};\\\", \\\"{x:1567,y:695,t:1527628184679};\\\", \\\"{x:1569,y:695,t:1527628184694};\\\", \\\"{x:1570,y:695,t:1527628184712};\\\", \\\"{x:1572,y:698,t:1527628185058};\\\", \\\"{x:1574,y:698,t:1527628185065};\\\", \\\"{x:1577,y:699,t:1527628185079};\\\", \\\"{x:1581,y:701,t:1527628185096};\\\", \\\"{x:1582,y:702,t:1527628185113};\\\", \\\"{x:1584,y:702,t:1527628185137};\\\", \\\"{x:1584,y:703,t:1527628185146};\\\", \\\"{x:1585,y:703,t:1527628185169};\\\", \\\"{x:1587,y:703,t:1527628185201};\\\", \\\"{x:1589,y:704,t:1527628185225};\\\", \\\"{x:1589,y:705,t:1527628185233};\\\", \\\"{x:1590,y:705,t:1527628185249};\\\", \\\"{x:1591,y:706,t:1527628185305};\\\", \\\"{x:1592,y:706,t:1527628185313};\\\", \\\"{x:1594,y:706,t:1527628185329};\\\", \\\"{x:1596,y:708,t:1527628185345};\\\", \\\"{x:1597,y:708,t:1527628185377};\\\", \\\"{x:1598,y:708,t:1527628185409};\\\", \\\"{x:1600,y:708,t:1527628185425};\\\", \\\"{x:1601,y:708,t:1527628185433};\\\", \\\"{x:1602,y:708,t:1527628185457};\\\", \\\"{x:1604,y:708,t:1527628185465};\\\", \\\"{x:1606,y:707,t:1527628185513};\\\", \\\"{x:1607,y:707,t:1527628185746};\\\", \\\"{x:1609,y:707,t:1527628185794};\\\", \\\"{x:1611,y:705,t:1527628185801};\\\", \\\"{x:1612,y:705,t:1527628185812};\\\", \\\"{x:1613,y:704,t:1527628185829};\\\", \\\"{x:1615,y:703,t:1527628185846};\\\", \\\"{x:1617,y:703,t:1527628185865};\\\", \\\"{x:1617,y:702,t:1527628193458};\\\", \\\"{x:1609,y:701,t:1527628193469};\\\", \\\"{x:1576,y:710,t:1527628193484};\\\", \\\"{x:1539,y:730,t:1527628193502};\\\", \\\"{x:1507,y:748,t:1527628193518};\\\", \\\"{x:1466,y:762,t:1527628193534};\\\", \\\"{x:1414,y:777,t:1527628193551};\\\", \\\"{x:1380,y:787,t:1527628193567};\\\", \\\"{x:1368,y:790,t:1527628193585};\\\", \\\"{x:1364,y:790,t:1527628193602};\\\", \\\"{x:1364,y:787,t:1527628193832};\\\", \\\"{x:1364,y:786,t:1527628193841};\\\", \\\"{x:1366,y:784,t:1527628193852};\\\", \\\"{x:1371,y:780,t:1527628193867};\\\", \\\"{x:1377,y:776,t:1527628193884};\\\", \\\"{x:1381,y:774,t:1527628193902};\\\", \\\"{x:1384,y:772,t:1527628193918};\\\", \\\"{x:1386,y:772,t:1527628193935};\\\", \\\"{x:1388,y:770,t:1527628193952};\\\", \\\"{x:1389,y:770,t:1527628193969};\\\", \\\"{x:1390,y:769,t:1527628193985};\\\", \\\"{x:1390,y:768,t:1527628194002};\\\", \\\"{x:1392,y:768,t:1527628194019};\\\", \\\"{x:1396,y:766,t:1527628194035};\\\", \\\"{x:1400,y:765,t:1527628194052};\\\", \\\"{x:1402,y:764,t:1527628194069};\\\", \\\"{x:1403,y:763,t:1527628194096};\\\", \\\"{x:1404,y:762,t:1527628194120};\\\", \\\"{x:1405,y:762,t:1527628194136};\\\", \\\"{x:1407,y:760,t:1527628194161};\\\", \\\"{x:1410,y:759,t:1527628194217};\\\", \\\"{x:1411,y:759,t:1527628194265};\\\", \\\"{x:1412,y:759,t:1527628194314};\\\", \\\"{x:1413,y:759,t:1527628194329};\\\", \\\"{x:1416,y:759,t:1527628194337};\\\", \\\"{x:1417,y:759,t:1527628194352};\\\", \\\"{x:1419,y:758,t:1527628194369};\\\", \\\"{x:1422,y:758,t:1527628194634};\\\", \\\"{x:1425,y:760,t:1527628194641};\\\", \\\"{x:1428,y:760,t:1527628194652};\\\", \\\"{x:1430,y:761,t:1527628194668};\\\", \\\"{x:1432,y:762,t:1527628194686};\\\", \\\"{x:1433,y:762,t:1527628194701};\\\", \\\"{x:1435,y:763,t:1527628194719};\\\", \\\"{x:1437,y:763,t:1527628194744};\\\", \\\"{x:1439,y:763,t:1527628194760};\\\", \\\"{x:1441,y:764,t:1527628194769};\\\", \\\"{x:1448,y:766,t:1527628194786};\\\", \\\"{x:1451,y:767,t:1527628194801};\\\", \\\"{x:1455,y:767,t:1527628194818};\\\", \\\"{x:1459,y:767,t:1527628194836};\\\", \\\"{x:1463,y:768,t:1527628194852};\\\", \\\"{x:1467,y:769,t:1527628194868};\\\", \\\"{x:1469,y:769,t:1527628194885};\\\", \\\"{x:1471,y:769,t:1527628194904};\\\", \\\"{x:1473,y:769,t:1527628194918};\\\", \\\"{x:1475,y:769,t:1527628194935};\\\", \\\"{x:1479,y:769,t:1527628194952};\\\", \\\"{x:1481,y:769,t:1527628194969};\\\", \\\"{x:1482,y:769,t:1527628195065};\\\", \\\"{x:1483,y:768,t:1527628195081};\\\", \\\"{x:1484,y:768,t:1527628195088};\\\", \\\"{x:1484,y:767,t:1527628195102};\\\", \\\"{x:1487,y:766,t:1527628195119};\\\", \\\"{x:1489,y:766,t:1527628195135};\\\", \\\"{x:1491,y:764,t:1527628195152};\\\", \\\"{x:1493,y:764,t:1527628195169};\\\", \\\"{x:1497,y:762,t:1527628195185};\\\", \\\"{x:1501,y:761,t:1527628195202};\\\", \\\"{x:1504,y:760,t:1527628195219};\\\", \\\"{x:1508,y:759,t:1527628195236};\\\", \\\"{x:1512,y:759,t:1527628195254};\\\", \\\"{x:1517,y:759,t:1527628195269};\\\", \\\"{x:1522,y:757,t:1527628195287};\\\", \\\"{x:1530,y:757,t:1527628195303};\\\", \\\"{x:1536,y:757,t:1527628195319};\\\", \\\"{x:1540,y:757,t:1527628195336};\\\", \\\"{x:1546,y:757,t:1527628195352};\\\", \\\"{x:1552,y:757,t:1527628195369};\\\", \\\"{x:1555,y:757,t:1527628195386};\\\", \\\"{x:1556,y:757,t:1527628195403};\\\", \\\"{x:1555,y:756,t:1527628195465};\\\", \\\"{x:1548,y:753,t:1527628195473};\\\", \\\"{x:1537,y:748,t:1527628195486};\\\", \\\"{x:1513,y:738,t:1527628195503};\\\", \\\"{x:1484,y:726,t:1527628195520};\\\", \\\"{x:1466,y:717,t:1527628195536};\\\", \\\"{x:1459,y:716,t:1527628195553};\\\", \\\"{x:1458,y:716,t:1527628195577};\\\", \\\"{x:1456,y:716,t:1527628195593};\\\", \\\"{x:1453,y:714,t:1527628195603};\\\", \\\"{x:1451,y:714,t:1527628195620};\\\", \\\"{x:1447,y:713,t:1527628195637};\\\", \\\"{x:1445,y:712,t:1527628195653};\\\", \\\"{x:1444,y:712,t:1527628195681};\\\", \\\"{x:1443,y:711,t:1527628195705};\\\", \\\"{x:1442,y:711,t:1527628195721};\\\", \\\"{x:1441,y:710,t:1527628195737};\\\", \\\"{x:1433,y:706,t:1527628195753};\\\", \\\"{x:1428,y:705,t:1527628195770};\\\", \\\"{x:1421,y:702,t:1527628195786};\\\", \\\"{x:1415,y:701,t:1527628195803};\\\", \\\"{x:1413,y:700,t:1527628195820};\\\", \\\"{x:1408,y:698,t:1527628195836};\\\", \\\"{x:1402,y:695,t:1527628195853};\\\", \\\"{x:1394,y:691,t:1527628195871};\\\", \\\"{x:1389,y:690,t:1527628195887};\\\", \\\"{x:1387,y:690,t:1527628195903};\\\", \\\"{x:1386,y:690,t:1527628195921};\\\", \\\"{x:1384,y:689,t:1527628195937};\\\", \\\"{x:1383,y:688,t:1527628195953};\\\", \\\"{x:1380,y:687,t:1527628195970};\\\", \\\"{x:1378,y:686,t:1527628195988};\\\", \\\"{x:1377,y:686,t:1527628196065};\\\", \\\"{x:1375,y:686,t:1527628196089};\\\", \\\"{x:1374,y:686,t:1527628196103};\\\", \\\"{x:1372,y:686,t:1527628196121};\\\", \\\"{x:1371,y:686,t:1527628196138};\\\", \\\"{x:1369,y:686,t:1527628196153};\\\", \\\"{x:1368,y:687,t:1527628196169};\\\", \\\"{x:1366,y:688,t:1527628196187};\\\", \\\"{x:1364,y:688,t:1527628196203};\\\", \\\"{x:1364,y:689,t:1527628196232};\\\", \\\"{x:1363,y:690,t:1527628196248};\\\", \\\"{x:1363,y:691,t:1527628196272};\\\", \\\"{x:1362,y:692,t:1527628196288};\\\", \\\"{x:1361,y:692,t:1527628196303};\\\", \\\"{x:1361,y:694,t:1527628196320};\\\", \\\"{x:1359,y:695,t:1527628196337};\\\", \\\"{x:1359,y:697,t:1527628196489};\\\", \\\"{x:1360,y:697,t:1527628196505};\\\", \\\"{x:1361,y:697,t:1527628196521};\\\", \\\"{x:1363,y:698,t:1527628196537};\\\", \\\"{x:1365,y:699,t:1527628196554};\\\", \\\"{x:1365,y:700,t:1527628196571};\\\", \\\"{x:1367,y:700,t:1527628196587};\\\", \\\"{x:1368,y:701,t:1527628196617};\\\", \\\"{x:1370,y:701,t:1527628196633};\\\", \\\"{x:1372,y:702,t:1527628196650};\\\", \\\"{x:1373,y:702,t:1527628196657};\\\", \\\"{x:1374,y:703,t:1527628196670};\\\", \\\"{x:1376,y:704,t:1527628196687};\\\", \\\"{x:1378,y:704,t:1527628196704};\\\", \\\"{x:1380,y:706,t:1527628196721};\\\", \\\"{x:1384,y:707,t:1527628196737};\\\", \\\"{x:1386,y:707,t:1527628196754};\\\", \\\"{x:1388,y:707,t:1527628196770};\\\", \\\"{x:1391,y:707,t:1527628196787};\\\", \\\"{x:1395,y:707,t:1527628196804};\\\", \\\"{x:1401,y:705,t:1527628196820};\\\", \\\"{x:1406,y:702,t:1527628196837};\\\", \\\"{x:1408,y:701,t:1527628196854};\\\", \\\"{x:1410,y:701,t:1527628196870};\\\", \\\"{x:1413,y:699,t:1527628196887};\\\", \\\"{x:1414,y:699,t:1527628196904};\\\", \\\"{x:1416,y:698,t:1527628196922};\\\", \\\"{x:1417,y:697,t:1527628196937};\\\", \\\"{x:1417,y:696,t:1527628196955};\\\", \\\"{x:1418,y:696,t:1527628196971};\\\", \\\"{x:1418,y:695,t:1527628197042};\\\", \\\"{x:1418,y:694,t:1527628197054};\\\", \\\"{x:1419,y:693,t:1527628197185};\\\", \\\"{x:1421,y:693,t:1527628197193};\\\", \\\"{x:1424,y:693,t:1527628197204};\\\", \\\"{x:1431,y:695,t:1527628197222};\\\", \\\"{x:1437,y:697,t:1527628197237};\\\", \\\"{x:1446,y:700,t:1527628197255};\\\", \\\"{x:1455,y:703,t:1527628197271};\\\", \\\"{x:1461,y:704,t:1527628197287};\\\", \\\"{x:1470,y:706,t:1527628197305};\\\", \\\"{x:1472,y:706,t:1527628197321};\\\", \\\"{x:1474,y:706,t:1527628197338};\\\", \\\"{x:1475,y:706,t:1527628197355};\\\", \\\"{x:1477,y:706,t:1527628197372};\\\", \\\"{x:1480,y:706,t:1527628197388};\\\", \\\"{x:1481,y:706,t:1527628197404};\\\", \\\"{x:1485,y:705,t:1527628197422};\\\", \\\"{x:1487,y:704,t:1527628197465};\\\", \\\"{x:1488,y:704,t:1527628197497};\\\", \\\"{x:1489,y:704,t:1527628197721};\\\", \\\"{x:1492,y:704,t:1527628197738};\\\", \\\"{x:1498,y:704,t:1527628197754};\\\", \\\"{x:1503,y:704,t:1527628197771};\\\", \\\"{x:1508,y:704,t:1527628197788};\\\", \\\"{x:1510,y:704,t:1527628197804};\\\", \\\"{x:1512,y:703,t:1527628197822};\\\", \\\"{x:1515,y:703,t:1527628197838};\\\", \\\"{x:1519,y:702,t:1527628197854};\\\", \\\"{x:1524,y:702,t:1527628197871};\\\", \\\"{x:1533,y:699,t:1527628197889};\\\", \\\"{x:1536,y:699,t:1527628197904};\\\", \\\"{x:1537,y:699,t:1527628197921};\\\", \\\"{x:1538,y:698,t:1527628197938};\\\", \\\"{x:1539,y:698,t:1527628198201};\\\", \\\"{x:1543,y:698,t:1527628198209};\\\", \\\"{x:1545,y:698,t:1527628198222};\\\", \\\"{x:1551,y:699,t:1527628198238};\\\", \\\"{x:1562,y:700,t:1527628198255};\\\", \\\"{x:1572,y:701,t:1527628198271};\\\", \\\"{x:1586,y:703,t:1527628198289};\\\", \\\"{x:1596,y:704,t:1527628198304};\\\", \\\"{x:1604,y:704,t:1527628198322};\\\", \\\"{x:1610,y:704,t:1527628198339};\\\", \\\"{x:1615,y:704,t:1527628198356};\\\", \\\"{x:1618,y:704,t:1527628198373};\\\", \\\"{x:1620,y:704,t:1527628198389};\\\", \\\"{x:1624,y:704,t:1527628198406};\\\", \\\"{x:1630,y:704,t:1527628198423};\\\", \\\"{x:1633,y:704,t:1527628198438};\\\", \\\"{x:1635,y:704,t:1527628198456};\\\", \\\"{x:1637,y:704,t:1527628198472};\\\", \\\"{x:1636,y:704,t:1527628198882};\\\", \\\"{x:1635,y:704,t:1527628198888};\\\", \\\"{x:1624,y:704,t:1527628198906};\\\", \\\"{x:1611,y:704,t:1527628198922};\\\", \\\"{x:1596,y:704,t:1527628198940};\\\", \\\"{x:1583,y:705,t:1527628198955};\\\", \\\"{x:1575,y:707,t:1527628198972};\\\", \\\"{x:1566,y:709,t:1527628198989};\\\", \\\"{x:1556,y:710,t:1527628199005};\\\", \\\"{x:1546,y:712,t:1527628199022};\\\", \\\"{x:1530,y:712,t:1527628199039};\\\", \\\"{x:1510,y:712,t:1527628199056};\\\", \\\"{x:1472,y:712,t:1527628199073};\\\", \\\"{x:1460,y:712,t:1527628199089};\\\", \\\"{x:1453,y:712,t:1527628199106};\\\", \\\"{x:1447,y:712,t:1527628199123};\\\", \\\"{x:1442,y:712,t:1527628199140};\\\", \\\"{x:1435,y:712,t:1527628199156};\\\", \\\"{x:1427,y:708,t:1527628199172};\\\", \\\"{x:1416,y:705,t:1527628199190};\\\", \\\"{x:1408,y:703,t:1527628199205};\\\", \\\"{x:1402,y:701,t:1527628199222};\\\", \\\"{x:1400,y:700,t:1527628199240};\\\", \\\"{x:1397,y:700,t:1527628199256};\\\", \\\"{x:1396,y:700,t:1527628199272};\\\", \\\"{x:1394,y:700,t:1527628199337};\\\", \\\"{x:1393,y:700,t:1527628199353};\\\", \\\"{x:1393,y:699,t:1527628199361};\\\", \\\"{x:1391,y:699,t:1527628199373};\\\", \\\"{x:1388,y:698,t:1527628199390};\\\", \\\"{x:1382,y:697,t:1527628199406};\\\", \\\"{x:1373,y:696,t:1527628199423};\\\", \\\"{x:1364,y:695,t:1527628199439};\\\", \\\"{x:1356,y:695,t:1527628199457};\\\", \\\"{x:1349,y:695,t:1527628199473};\\\", \\\"{x:1342,y:694,t:1527628199490};\\\", \\\"{x:1337,y:693,t:1527628199507};\\\", \\\"{x:1335,y:693,t:1527628199522};\\\", \\\"{x:1333,y:693,t:1527628199539};\\\", \\\"{x:1332,y:692,t:1527628199561};\\\", \\\"{x:1331,y:692,t:1527628199572};\\\", \\\"{x:1330,y:692,t:1527628199589};\\\", \\\"{x:1328,y:692,t:1527628199607};\\\", \\\"{x:1324,y:689,t:1527628199623};\\\", \\\"{x:1323,y:689,t:1527628199698};\\\", \\\"{x:1324,y:689,t:1527628199857};\\\", \\\"{x:1327,y:689,t:1527628199872};\\\", \\\"{x:1327,y:690,t:1527628199889};\\\", \\\"{x:1331,y:690,t:1527628199907};\\\", \\\"{x:1334,y:693,t:1527628199924};\\\", \\\"{x:1340,y:695,t:1527628199939};\\\", \\\"{x:1345,y:697,t:1527628199957};\\\", \\\"{x:1353,y:702,t:1527628199974};\\\", \\\"{x:1360,y:705,t:1527628199989};\\\", \\\"{x:1364,y:707,t:1527628200006};\\\", \\\"{x:1368,y:710,t:1527628200024};\\\", \\\"{x:1372,y:713,t:1527628200040};\\\", \\\"{x:1380,y:721,t:1527628200057};\\\", \\\"{x:1387,y:726,t:1527628200072};\\\", \\\"{x:1393,y:734,t:1527628200089};\\\", \\\"{x:1399,y:741,t:1527628200106};\\\", \\\"{x:1403,y:747,t:1527628200124};\\\", \\\"{x:1406,y:751,t:1527628200140};\\\", \\\"{x:1409,y:758,t:1527628200157};\\\", \\\"{x:1413,y:766,t:1527628200173};\\\", \\\"{x:1415,y:775,t:1527628200189};\\\", \\\"{x:1419,y:785,t:1527628200206};\\\", \\\"{x:1421,y:795,t:1527628200223};\\\", \\\"{x:1425,y:812,t:1527628200239};\\\", \\\"{x:1428,y:821,t:1527628200255};\\\", \\\"{x:1429,y:829,t:1527628200273};\\\", \\\"{x:1430,y:836,t:1527628200290};\\\", \\\"{x:1432,y:841,t:1527628200306};\\\", \\\"{x:1433,y:842,t:1527628200323};\\\", \\\"{x:1434,y:845,t:1527628200340};\\\", \\\"{x:1436,y:846,t:1527628200356};\\\", \\\"{x:1437,y:847,t:1527628200377};\\\", \\\"{x:1438,y:848,t:1527628200392};\\\", \\\"{x:1439,y:848,t:1527628200408};\\\", \\\"{x:1441,y:848,t:1527628200425};\\\", \\\"{x:1444,y:848,t:1527628200440};\\\", \\\"{x:1448,y:848,t:1527628200456};\\\", \\\"{x:1450,y:848,t:1527628200473};\\\", \\\"{x:1451,y:848,t:1527628200491};\\\", \\\"{x:1454,y:847,t:1527628200506};\\\", \\\"{x:1456,y:846,t:1527628200524};\\\", \\\"{x:1459,y:844,t:1527628200540};\\\", \\\"{x:1461,y:843,t:1527628200556};\\\", \\\"{x:1463,y:842,t:1527628200574};\\\", \\\"{x:1465,y:841,t:1527628200590};\\\", \\\"{x:1466,y:840,t:1527628200825};\\\", \\\"{x:1469,y:837,t:1527628200840};\\\", \\\"{x:1475,y:834,t:1527628200856};\\\", \\\"{x:1481,y:830,t:1527628200874};\\\", \\\"{x:1484,y:829,t:1527628200890};\\\", \\\"{x:1487,y:826,t:1527628200908};\\\", \\\"{x:1488,y:826,t:1527628200936};\\\", \\\"{x:1491,y:826,t:1527628201530};\\\", \\\"{x:1493,y:826,t:1527628201540};\\\", \\\"{x:1495,y:827,t:1527628201557};\\\", \\\"{x:1498,y:828,t:1527628201574};\\\", \\\"{x:1499,y:828,t:1527628201590};\\\", \\\"{x:1500,y:829,t:1527628201607};\\\", \\\"{x:1501,y:829,t:1527628201632};\\\", \\\"{x:1502,y:829,t:1527628201640};\\\", \\\"{x:1504,y:830,t:1527628201657};\\\", \\\"{x:1505,y:830,t:1527628201674};\\\", \\\"{x:1508,y:830,t:1527628201690};\\\", \\\"{x:1516,y:830,t:1527628201707};\\\", \\\"{x:1525,y:830,t:1527628201724};\\\", \\\"{x:1536,y:830,t:1527628201741};\\\", \\\"{x:1545,y:830,t:1527628201757};\\\", \\\"{x:1551,y:830,t:1527628201774};\\\", \\\"{x:1557,y:830,t:1527628201791};\\\", \\\"{x:1561,y:830,t:1527628201807};\\\", \\\"{x:1568,y:829,t:1527628201824};\\\", \\\"{x:1572,y:829,t:1527628201841};\\\", \\\"{x:1576,y:827,t:1527628201857};\\\", \\\"{x:1577,y:826,t:1527628201880};\\\", \\\"{x:1577,y:825,t:1527628202105};\\\", \\\"{x:1577,y:824,t:1527628202113};\\\", \\\"{x:1576,y:824,t:1527628202125};\\\", \\\"{x:1575,y:824,t:1527628202141};\\\", \\\"{x:1573,y:822,t:1527628202158};\\\", \\\"{x:1571,y:821,t:1527628202176};\\\", \\\"{x:1570,y:821,t:1527628202232};\\\", \\\"{x:1568,y:821,t:1527628202241};\\\", \\\"{x:1567,y:821,t:1527628202258};\\\", \\\"{x:1566,y:821,t:1527628202274};\\\", \\\"{x:1565,y:821,t:1527628202320};\\\", \\\"{x:1564,y:821,t:1527628202560};\\\", \\\"{x:1563,y:822,t:1527628202615};\\\", \\\"{x:1563,y:823,t:1527628202632};\\\", \\\"{x:1567,y:823,t:1527628202786};\\\", \\\"{x:1573,y:823,t:1527628202793};\\\", \\\"{x:1581,y:823,t:1527628202808};\\\", \\\"{x:1592,y:820,t:1527628202825};\\\", \\\"{x:1599,y:819,t:1527628202841};\\\", \\\"{x:1603,y:819,t:1527628202858};\\\", \\\"{x:1605,y:819,t:1527628202876};\\\", \\\"{x:1606,y:819,t:1527628202891};\\\", \\\"{x:1607,y:819,t:1527628202912};\\\", \\\"{x:1608,y:820,t:1527628202928};\\\", \\\"{x:1609,y:821,t:1527628202942};\\\", \\\"{x:1609,y:824,t:1527628202958};\\\", \\\"{x:1609,y:828,t:1527628202975};\\\", \\\"{x:1609,y:833,t:1527628202991};\\\", \\\"{x:1608,y:841,t:1527628203008};\\\", \\\"{x:1602,y:847,t:1527628203025};\\\", \\\"{x:1593,y:853,t:1527628203042};\\\", \\\"{x:1583,y:857,t:1527628203058};\\\", \\\"{x:1571,y:862,t:1527628203076};\\\", \\\"{x:1553,y:864,t:1527628203092};\\\", \\\"{x:1540,y:867,t:1527628203108};\\\", \\\"{x:1531,y:868,t:1527628203126};\\\", \\\"{x:1525,y:868,t:1527628203143};\\\", \\\"{x:1524,y:868,t:1527628203161};\\\", \\\"{x:1522,y:868,t:1527628203671};\\\", \\\"{x:1519,y:868,t:1527628203688};\\\", \\\"{x:1516,y:867,t:1527628203695};\\\", \\\"{x:1513,y:865,t:1527628203709};\\\", \\\"{x:1505,y:860,t:1527628203724};\\\", \\\"{x:1496,y:854,t:1527628203742};\\\", \\\"{x:1483,y:847,t:1527628203759};\\\", \\\"{x:1476,y:845,t:1527628203775};\\\", \\\"{x:1474,y:843,t:1527628203792};\\\", \\\"{x:1473,y:843,t:1527628203809};\\\", \\\"{x:1471,y:841,t:1527628203825};\\\", \\\"{x:1469,y:840,t:1527628203842};\\\", \\\"{x:1465,y:836,t:1527628203859};\\\", \\\"{x:1464,y:836,t:1527628203876};\\\", \\\"{x:1463,y:835,t:1527628203969};\\\", \\\"{x:1463,y:834,t:1527628203976};\\\", \\\"{x:1463,y:833,t:1527628203992};\\\", \\\"{x:1463,y:832,t:1527628204009};\\\", \\\"{x:1465,y:830,t:1527628204025};\\\", \\\"{x:1466,y:828,t:1527628204043};\\\", \\\"{x:1468,y:827,t:1527628204060};\\\", \\\"{x:1469,y:826,t:1527628204077};\\\", \\\"{x:1469,y:825,t:1527628205161};\\\", \\\"{x:1457,y:817,t:1527628205177};\\\", \\\"{x:1439,y:807,t:1527628205194};\\\", \\\"{x:1425,y:802,t:1527628205211};\\\", \\\"{x:1414,y:798,t:1527628205227};\\\", \\\"{x:1409,y:797,t:1527628205244};\\\", \\\"{x:1407,y:796,t:1527628205260};\\\", \\\"{x:1406,y:796,t:1527628205276};\\\", \\\"{x:1405,y:795,t:1527628205297};\\\", \\\"{x:1403,y:795,t:1527628205313};\\\", \\\"{x:1402,y:795,t:1527628205327};\\\", \\\"{x:1399,y:793,t:1527628205344};\\\", \\\"{x:1393,y:790,t:1527628205360};\\\", \\\"{x:1387,y:789,t:1527628205377};\\\", \\\"{x:1382,y:786,t:1527628205394};\\\", \\\"{x:1371,y:782,t:1527628205411};\\\", \\\"{x:1359,y:777,t:1527628205428};\\\", \\\"{x:1345,y:772,t:1527628205444};\\\", \\\"{x:1331,y:766,t:1527628205461};\\\", \\\"{x:1317,y:761,t:1527628205477};\\\", \\\"{x:1301,y:754,t:1527628205494};\\\", \\\"{x:1285,y:749,t:1527628205510};\\\", \\\"{x:1268,y:745,t:1527628205526};\\\", \\\"{x:1250,y:739,t:1527628205544};\\\", \\\"{x:1224,y:733,t:1527628205561};\\\", \\\"{x:1206,y:730,t:1527628205578};\\\", \\\"{x:1192,y:729,t:1527628205594};\\\", \\\"{x:1181,y:728,t:1527628205610};\\\", \\\"{x:1169,y:724,t:1527628205628};\\\", \\\"{x:1156,y:721,t:1527628205644};\\\", \\\"{x:1144,y:718,t:1527628205661};\\\", \\\"{x:1131,y:714,t:1527628205678};\\\", \\\"{x:1122,y:711,t:1527628205694};\\\", \\\"{x:1111,y:708,t:1527628205711};\\\", \\\"{x:1099,y:705,t:1527628205728};\\\", \\\"{x:1088,y:701,t:1527628205743};\\\", \\\"{x:1064,y:695,t:1527628205761};\\\", \\\"{x:1047,y:690,t:1527628205777};\\\", \\\"{x:1029,y:684,t:1527628205794};\\\", \\\"{x:1005,y:678,t:1527628205811};\\\", \\\"{x:981,y:671,t:1527628205828};\\\", \\\"{x:960,y:665,t:1527628205844};\\\", \\\"{x:938,y:660,t:1527628205860};\\\", \\\"{x:915,y:654,t:1527628205877};\\\", \\\"{x:893,y:646,t:1527628205893};\\\", \\\"{x:874,y:640,t:1527628205911};\\\", \\\"{x:858,y:633,t:1527628205928};\\\", \\\"{x:838,y:624,t:1527628205945};\\\", \\\"{x:812,y:616,t:1527628205962};\\\", \\\"{x:779,y:601,t:1527628205993};\\\", \\\"{x:764,y:596,t:1527628206012};\\\", \\\"{x:755,y:591,t:1527628206029};\\\", \\\"{x:746,y:588,t:1527628206046};\\\", \\\"{x:735,y:585,t:1527628206062};\\\", \\\"{x:722,y:579,t:1527628206081};\\\", \\\"{x:691,y:567,t:1527628206096};\\\", \\\"{x:678,y:562,t:1527628206112};\\\", \\\"{x:671,y:559,t:1527628206129};\\\", \\\"{x:668,y:557,t:1527628206146};\\\", \\\"{x:667,y:557,t:1527628206162};\\\", \\\"{x:664,y:557,t:1527628206369};\\\", \\\"{x:662,y:556,t:1527628206379};\\\", \\\"{x:653,y:555,t:1527628206397};\\\", \\\"{x:648,y:554,t:1527628206413};\\\", \\\"{x:644,y:553,t:1527628206429};\\\", \\\"{x:641,y:552,t:1527628206446};\\\", \\\"{x:638,y:552,t:1527628206463};\\\", \\\"{x:632,y:552,t:1527628206480};\\\", \\\"{x:630,y:550,t:1527628206497};\\\", \\\"{x:628,y:549,t:1527628206513};\\\", \\\"{x:624,y:549,t:1527628206529};\\\", \\\"{x:621,y:548,t:1527628206546};\\\", \\\"{x:619,y:547,t:1527628206563};\\\", \\\"{x:618,y:546,t:1527628206579};\\\", \\\"{x:615,y:546,t:1527628206596};\\\", \\\"{x:613,y:545,t:1527628206613};\\\", \\\"{x:612,y:545,t:1527628206629};\\\", \\\"{x:611,y:545,t:1527628206656};\\\", \\\"{x:610,y:545,t:1527628206809};\\\", \\\"{x:609,y:545,t:1527628206817};\\\", \\\"{x:609,y:544,t:1527628206831};\\\", \\\"{x:605,y:543,t:1527628206847};\\\", \\\"{x:602,y:543,t:1527628206864};\\\", \\\"{x:600,y:541,t:1527628206880};\\\", \\\"{x:598,y:540,t:1527628206898};\\\", \\\"{x:596,y:539,t:1527628206913};\\\", \\\"{x:594,y:537,t:1527628206930};\\\", \\\"{x:593,y:536,t:1527628206946};\\\", \\\"{x:591,y:534,t:1527628206963};\\\", \\\"{x:589,y:534,t:1527628206980};\\\", \\\"{x:588,y:533,t:1527628206996};\\\", \\\"{x:586,y:532,t:1527628207013};\\\", \\\"{x:585,y:531,t:1527628207030};\\\", \\\"{x:584,y:530,t:1527628207048};\\\", \\\"{x:583,y:529,t:1527628207272};\\\", \\\"{x:584,y:527,t:1527628207280};\\\", \\\"{x:592,y:526,t:1527628207297};\\\", \\\"{x:605,y:524,t:1527628207315};\\\", \\\"{x:613,y:524,t:1527628207330};\\\", \\\"{x:619,y:523,t:1527628207347};\\\", \\\"{x:621,y:522,t:1527628207363};\\\", \\\"{x:622,y:522,t:1527628207380};\\\", \\\"{x:622,y:521,t:1527628207593};\\\", \\\"{x:620,y:520,t:1527628207600};\\\", \\\"{x:618,y:520,t:1527628207613};\\\", \\\"{x:614,y:518,t:1527628207630};\\\", \\\"{x:611,y:516,t:1527628207648};\\\", \\\"{x:610,y:515,t:1527628207663};\\\", \\\"{x:605,y:512,t:1527628207681};\\\", \\\"{x:604,y:511,t:1527628207697};\\\", \\\"{x:604,y:509,t:1527628207714};\\\", \\\"{x:622,y:502,t:1527628207731};\\\", \\\"{x:637,y:498,t:1527628207748};\\\", \\\"{x:646,y:494,t:1527628207765};\\\", \\\"{x:656,y:490,t:1527628207781};\\\", \\\"{x:662,y:489,t:1527628207797};\\\", \\\"{x:673,y:484,t:1527628207816};\\\", \\\"{x:682,y:483,t:1527628207830};\\\", \\\"{x:691,y:483,t:1527628207848};\\\", \\\"{x:700,y:483,t:1527628207865};\\\", \\\"{x:702,y:482,t:1527628207880};\\\", \\\"{x:703,y:482,t:1527628207897};\\\", \\\"{x:704,y:482,t:1527628207915};\\\", \\\"{x:707,y:482,t:1527628207932};\\\", \\\"{x:711,y:482,t:1527628207947};\\\", \\\"{x:716,y:482,t:1527628207964};\\\", \\\"{x:723,y:483,t:1527628207982};\\\", \\\"{x:732,y:486,t:1527628207997};\\\", \\\"{x:738,y:487,t:1527628208015};\\\", \\\"{x:740,y:488,t:1527628208031};\\\", \\\"{x:743,y:490,t:1527628208048};\\\", \\\"{x:749,y:491,t:1527628208064};\\\", \\\"{x:755,y:494,t:1527628208081};\\\", \\\"{x:763,y:497,t:1527628208098};\\\", \\\"{x:770,y:500,t:1527628208114};\\\", \\\"{x:771,y:500,t:1527628208131};\\\", \\\"{x:772,y:500,t:1527628208209};\\\", \\\"{x:775,y:502,t:1527628208216};\\\", \\\"{x:778,y:503,t:1527628208232};\\\", \\\"{x:782,y:504,t:1527628208248};\\\", \\\"{x:787,y:507,t:1527628208265};\\\", \\\"{x:788,y:507,t:1527628208377};\\\", \\\"{x:789,y:508,t:1527628208385};\\\", \\\"{x:790,y:508,t:1527628208399};\\\", \\\"{x:793,y:509,t:1527628208414};\\\", \\\"{x:796,y:509,t:1527628208431};\\\", \\\"{x:798,y:509,t:1527628208449};\\\", \\\"{x:800,y:509,t:1527628208464};\\\", \\\"{x:803,y:508,t:1527628208482};\\\", \\\"{x:810,y:506,t:1527628208498};\\\", \\\"{x:812,y:506,t:1527628208515};\\\", \\\"{x:814,y:506,t:1527628208532};\\\", \\\"{x:815,y:506,t:1527628208549};\\\", \\\"{x:816,y:505,t:1527628208565};\\\", \\\"{x:817,y:505,t:1527628208904};\\\", \\\"{x:819,y:505,t:1527628208916};\\\", \\\"{x:823,y:505,t:1527628208931};\\\", \\\"{x:827,y:506,t:1527628208948};\\\", \\\"{x:830,y:506,t:1527628208966};\\\", \\\"{x:831,y:506,t:1527628208981};\\\", \\\"{x:831,y:508,t:1527628209440};\\\", \\\"{x:826,y:510,t:1527628209448};\\\", \\\"{x:816,y:514,t:1527628209466};\\\", \\\"{x:806,y:520,t:1527628209483};\\\", \\\"{x:797,y:524,t:1527628209498};\\\", \\\"{x:784,y:529,t:1527628209516};\\\", \\\"{x:772,y:535,t:1527628209532};\\\", \\\"{x:761,y:540,t:1527628209549};\\\", \\\"{x:752,y:544,t:1527628209566};\\\", \\\"{x:745,y:548,t:1527628209582};\\\", \\\"{x:734,y:551,t:1527628209598};\\\", \\\"{x:725,y:556,t:1527628209617};\\\", \\\"{x:713,y:560,t:1527628209632};\\\", \\\"{x:709,y:562,t:1527628209649};\\\", \\\"{x:705,y:562,t:1527628209666};\\\", \\\"{x:701,y:563,t:1527628209683};\\\", \\\"{x:697,y:563,t:1527628209699};\\\", \\\"{x:694,y:564,t:1527628209715};\\\", \\\"{x:690,y:564,t:1527628209732};\\\", \\\"{x:685,y:566,t:1527628209748};\\\", \\\"{x:680,y:566,t:1527628209765};\\\", \\\"{x:675,y:566,t:1527628209782};\\\", \\\"{x:670,y:566,t:1527628209799};\\\", \\\"{x:665,y:566,t:1527628209815};\\\", \\\"{x:659,y:566,t:1527628209832};\\\", \\\"{x:655,y:566,t:1527628209848};\\\", \\\"{x:650,y:566,t:1527628209865};\\\", \\\"{x:644,y:566,t:1527628209882};\\\", \\\"{x:640,y:566,t:1527628209899};\\\", \\\"{x:636,y:566,t:1527628209916};\\\", \\\"{x:633,y:567,t:1527628209933};\\\", \\\"{x:630,y:568,t:1527628209951};\\\", \\\"{x:628,y:568,t:1527628209966};\\\", \\\"{x:625,y:569,t:1527628209982};\\\", \\\"{x:621,y:570,t:1527628210000};\\\", \\\"{x:619,y:570,t:1527628210016};\\\", \\\"{x:616,y:570,t:1527628210033};\\\", \\\"{x:615,y:570,t:1527628210050};\\\", \\\"{x:615,y:571,t:1527628210066};\\\", \\\"{x:612,y:574,t:1527628210408};\\\", \\\"{x:612,y:576,t:1527628210416};\\\", \\\"{x:607,y:588,t:1527628210432};\\\", \\\"{x:599,y:604,t:1527628210451};\\\", \\\"{x:590,y:619,t:1527628210466};\\\", \\\"{x:579,y:636,t:1527628210483};\\\", \\\"{x:570,y:649,t:1527628210499};\\\", \\\"{x:561,y:659,t:1527628210516};\\\", \\\"{x:554,y:665,t:1527628210532};\\\", \\\"{x:549,y:670,t:1527628210549};\\\", \\\"{x:547,y:673,t:1527628210566};\\\", \\\"{x:544,y:676,t:1527628210583};\\\", \\\"{x:543,y:678,t:1527628210600};\\\", \\\"{x:539,y:683,t:1527628210615};\\\", \\\"{x:536,y:686,t:1527628210632};\\\", \\\"{x:533,y:692,t:1527628210649};\\\", \\\"{x:531,y:695,t:1527628210666};\\\", \\\"{x:528,y:700,t:1527628210684};\\\", \\\"{x:523,y:706,t:1527628210699};\\\", \\\"{x:520,y:710,t:1527628210716};\\\", \\\"{x:517,y:714,t:1527628210733};\\\", \\\"{x:514,y:719,t:1527628210750};\\\", \\\"{x:513,y:721,t:1527628210767};\\\", \\\"{x:511,y:723,t:1527628210783};\\\", \\\"{x:510,y:725,t:1527628210799};\\\", \\\"{x:509,y:728,t:1527628210816};\\\", \\\"{x:509,y:730,t:1527628210834};\\\", \\\"{x:508,y:732,t:1527628210849};\\\", \\\"{x:507,y:733,t:1527628210867};\\\" ] }, { \\\"rt\\\": 31692, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 493243, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:727,t:1527628213064};\\\", \\\"{x:514,y:721,t:1527628213071};\\\", \\\"{x:518,y:716,t:1527628213085};\\\", \\\"{x:532,y:702,t:1527628213101};\\\", \\\"{x:555,y:684,t:1527628213119};\\\", \\\"{x:590,y:663,t:1527628213134};\\\", \\\"{x:630,y:644,t:1527628213152};\\\", \\\"{x:700,y:613,t:1527628213168};\\\", \\\"{x:749,y:594,t:1527628213185};\\\", \\\"{x:803,y:578,t:1527628213202};\\\", \\\"{x:848,y:564,t:1527628213218};\\\", \\\"{x:882,y:554,t:1527628213236};\\\", \\\"{x:918,y:550,t:1527628213251};\\\", \\\"{x:949,y:545,t:1527628213268};\\\", \\\"{x:978,y:540,t:1527628213286};\\\", \\\"{x:1002,y:539,t:1527628213301};\\\", \\\"{x:1028,y:534,t:1527628213318};\\\", \\\"{x:1046,y:532,t:1527628213336};\\\", \\\"{x:1065,y:529,t:1527628213351};\\\", \\\"{x:1093,y:525,t:1527628213368};\\\", \\\"{x:1111,y:523,t:1527628213385};\\\", \\\"{x:1126,y:522,t:1527628213401};\\\", \\\"{x:1139,y:519,t:1527628213418};\\\", \\\"{x:1150,y:519,t:1527628213436};\\\", \\\"{x:1164,y:519,t:1527628213452};\\\", \\\"{x:1183,y:519,t:1527628213469};\\\", \\\"{x:1201,y:519,t:1527628213485};\\\", \\\"{x:1225,y:521,t:1527628213502};\\\", \\\"{x:1245,y:524,t:1527628213519};\\\", \\\"{x:1267,y:527,t:1527628213536};\\\", \\\"{x:1290,y:535,t:1527628213552};\\\", \\\"{x:1318,y:543,t:1527628213568};\\\", \\\"{x:1334,y:550,t:1527628213586};\\\", \\\"{x:1342,y:556,t:1527628213601};\\\", \\\"{x:1347,y:561,t:1527628213619};\\\", \\\"{x:1353,y:569,t:1527628213636};\\\", \\\"{x:1362,y:583,t:1527628213651};\\\", \\\"{x:1373,y:597,t:1527628213668};\\\", \\\"{x:1387,y:615,t:1527628213686};\\\", \\\"{x:1399,y:630,t:1527628213702};\\\", \\\"{x:1415,y:648,t:1527628213719};\\\", \\\"{x:1429,y:662,t:1527628213736};\\\", \\\"{x:1443,y:676,t:1527628213752};\\\", \\\"{x:1463,y:693,t:1527628213768};\\\", \\\"{x:1477,y:704,t:1527628213786};\\\", \\\"{x:1493,y:717,t:1527628213802};\\\", \\\"{x:1505,y:726,t:1527628213819};\\\", \\\"{x:1516,y:734,t:1527628213836};\\\", \\\"{x:1526,y:740,t:1527628213853};\\\", \\\"{x:1534,y:747,t:1527628213869};\\\", \\\"{x:1540,y:752,t:1527628213887};\\\", \\\"{x:1545,y:758,t:1527628213902};\\\", \\\"{x:1551,y:768,t:1527628213919};\\\", \\\"{x:1557,y:775,t:1527628213936};\\\", \\\"{x:1564,y:787,t:1527628213952};\\\", \\\"{x:1570,y:796,t:1527628213969};\\\", \\\"{x:1574,y:804,t:1527628213986};\\\", \\\"{x:1576,y:806,t:1527628214002};\\\", \\\"{x:1578,y:813,t:1527628214078};\\\", \\\"{x:1579,y:816,t:1527628214085};\\\", \\\"{x:1580,y:820,t:1527628214102};\\\", \\\"{x:1580,y:821,t:1527628214119};\\\", \\\"{x:1580,y:823,t:1527628214225};\\\", \\\"{x:1580,y:828,t:1527628214235};\\\", \\\"{x:1580,y:832,t:1527628214252};\\\", \\\"{x:1580,y:838,t:1527628214268};\\\", \\\"{x:1580,y:839,t:1527628214285};\\\", \\\"{x:1580,y:841,t:1527628214303};\\\", \\\"{x:1580,y:842,t:1527628214328};\\\", \\\"{x:1580,y:844,t:1527628214360};\\\", \\\"{x:1579,y:844,t:1527628214369};\\\", \\\"{x:1579,y:845,t:1527628214417};\\\", \\\"{x:1579,y:846,t:1527628214432};\\\", \\\"{x:1578,y:848,t:1527628214449};\\\", \\\"{x:1577,y:849,t:1527628214465};\\\", \\\"{x:1577,y:850,t:1527628214472};\\\", \\\"{x:1576,y:853,t:1527628214489};\\\", \\\"{x:1576,y:855,t:1527628214503};\\\", \\\"{x:1574,y:861,t:1527628214519};\\\", \\\"{x:1574,y:868,t:1527628214536};\\\", \\\"{x:1574,y:885,t:1527628214553};\\\", \\\"{x:1573,y:893,t:1527628214570};\\\", \\\"{x:1573,y:900,t:1527628214586};\\\", \\\"{x:1573,y:908,t:1527628214603};\\\", \\\"{x:1572,y:914,t:1527628214620};\\\", \\\"{x:1571,y:919,t:1527628214637};\\\", \\\"{x:1571,y:923,t:1527628214653};\\\", \\\"{x:1570,y:924,t:1527628214670};\\\", \\\"{x:1570,y:927,t:1527628214686};\\\", \\\"{x:1570,y:928,t:1527628214705};\\\", \\\"{x:1570,y:929,t:1527628214720};\\\", \\\"{x:1570,y:930,t:1527628214736};\\\", \\\"{x:1570,y:932,t:1527628214753};\\\", \\\"{x:1570,y:933,t:1527628214771};\\\", \\\"{x:1569,y:933,t:1527628214787};\\\", \\\"{x:1569,y:935,t:1527628214802};\\\", \\\"{x:1569,y:937,t:1527628214820};\\\", \\\"{x:1570,y:941,t:1527628214836};\\\", \\\"{x:1571,y:944,t:1527628214852};\\\", \\\"{x:1572,y:947,t:1527628214870};\\\", \\\"{x:1575,y:949,t:1527628214886};\\\", \\\"{x:1580,y:951,t:1527628214903};\\\", \\\"{x:1592,y:955,t:1527628214920};\\\", \\\"{x:1603,y:956,t:1527628214936};\\\", \\\"{x:1627,y:956,t:1527628214953};\\\", \\\"{x:1645,y:956,t:1527628214970};\\\", \\\"{x:1651,y:956,t:1527628214986};\\\", \\\"{x:1658,y:955,t:1527628215003};\\\", \\\"{x:1660,y:955,t:1527628215020};\\\", \\\"{x:1655,y:955,t:1527628215193};\\\", \\\"{x:1651,y:956,t:1527628215203};\\\", \\\"{x:1635,y:960,t:1527628215220};\\\", \\\"{x:1616,y:966,t:1527628215236};\\\", \\\"{x:1597,y:970,t:1527628215253};\\\", \\\"{x:1579,y:972,t:1527628215270};\\\", \\\"{x:1561,y:974,t:1527628215288};\\\", \\\"{x:1544,y:978,t:1527628215303};\\\", \\\"{x:1535,y:978,t:1527628215320};\\\", \\\"{x:1528,y:978,t:1527628215336};\\\", \\\"{x:1527,y:978,t:1527628215353};\\\", \\\"{x:1526,y:978,t:1527628215370};\\\", \\\"{x:1526,y:973,t:1527628215513};\\\", \\\"{x:1526,y:968,t:1527628215521};\\\", \\\"{x:1526,y:961,t:1527628215537};\\\", \\\"{x:1529,y:950,t:1527628215553};\\\", \\\"{x:1533,y:942,t:1527628215570};\\\", \\\"{x:1536,y:938,t:1527628215587};\\\", \\\"{x:1537,y:935,t:1527628215603};\\\", \\\"{x:1538,y:933,t:1527628215620};\\\", \\\"{x:1539,y:933,t:1527628215637};\\\", \\\"{x:1539,y:932,t:1527628215697};\\\", \\\"{x:1540,y:932,t:1527628215705};\\\", \\\"{x:1541,y:934,t:1527628215857};\\\", \\\"{x:1541,y:937,t:1527628215870};\\\", \\\"{x:1541,y:943,t:1527628215887};\\\", \\\"{x:1541,y:949,t:1527628215905};\\\", \\\"{x:1541,y:956,t:1527628215921};\\\", \\\"{x:1541,y:960,t:1527628215937};\\\", \\\"{x:1541,y:961,t:1527628215955};\\\", \\\"{x:1541,y:963,t:1527628215993};\\\", \\\"{x:1541,y:964,t:1527628216032};\\\", \\\"{x:1541,y:966,t:1527628216049};\\\", \\\"{x:1541,y:967,t:1527628216073};\\\", \\\"{x:1541,y:968,t:1527628216089};\\\", \\\"{x:1541,y:969,t:1527628216105};\\\", \\\"{x:1541,y:968,t:1527628216465};\\\", \\\"{x:1541,y:966,t:1527628216472};\\\", \\\"{x:1541,y:965,t:1527628216489};\\\", \\\"{x:1541,y:963,t:1527628216505};\\\", \\\"{x:1541,y:962,t:1527628216530};\\\", \\\"{x:1542,y:961,t:1527628216553};\\\", \\\"{x:1542,y:960,t:1527628218233};\\\", \\\"{x:1542,y:957,t:1527628218241};\\\", \\\"{x:1542,y:951,t:1527628218255};\\\", \\\"{x:1542,y:945,t:1527628218271};\\\", \\\"{x:1542,y:938,t:1527628218289};\\\", \\\"{x:1541,y:935,t:1527628218305};\\\", \\\"{x:1541,y:934,t:1527628218321};\\\", \\\"{x:1541,y:932,t:1527628218338};\\\", \\\"{x:1541,y:931,t:1527628218355};\\\", \\\"{x:1540,y:930,t:1527628218372};\\\", \\\"{x:1540,y:929,t:1527628218388};\\\", \\\"{x:1539,y:927,t:1527628218405};\\\", \\\"{x:1539,y:925,t:1527628218421};\\\", \\\"{x:1539,y:924,t:1527628218438};\\\", \\\"{x:1539,y:922,t:1527628218454};\\\", \\\"{x:1539,y:919,t:1527628218471};\\\", \\\"{x:1539,y:916,t:1527628218488};\\\", \\\"{x:1539,y:915,t:1527628218505};\\\", \\\"{x:1539,y:912,t:1527628218522};\\\", \\\"{x:1539,y:909,t:1527628218537};\\\", \\\"{x:1539,y:905,t:1527628218555};\\\", \\\"{x:1539,y:902,t:1527628218571};\\\", \\\"{x:1539,y:898,t:1527628218588};\\\", \\\"{x:1539,y:895,t:1527628218605};\\\", \\\"{x:1539,y:891,t:1527628218622};\\\", \\\"{x:1539,y:888,t:1527628218638};\\\", \\\"{x:1539,y:884,t:1527628218655};\\\", \\\"{x:1540,y:878,t:1527628218672};\\\", \\\"{x:1540,y:873,t:1527628218688};\\\", \\\"{x:1541,y:869,t:1527628218705};\\\", \\\"{x:1543,y:865,t:1527628218722};\\\", \\\"{x:1543,y:863,t:1527628218738};\\\", \\\"{x:1544,y:860,t:1527628218755};\\\", \\\"{x:1545,y:856,t:1527628218772};\\\", \\\"{x:1545,y:855,t:1527628218787};\\\", \\\"{x:1546,y:853,t:1527628218805};\\\", \\\"{x:1547,y:851,t:1527628218822};\\\", \\\"{x:1547,y:849,t:1527628218838};\\\", \\\"{x:1547,y:847,t:1527628218855};\\\", \\\"{x:1548,y:845,t:1527628218872};\\\", \\\"{x:1549,y:843,t:1527628218889};\\\", \\\"{x:1549,y:842,t:1527628218905};\\\", \\\"{x:1549,y:841,t:1527628218936};\\\", \\\"{x:1550,y:840,t:1527628218945};\\\", \\\"{x:1550,y:839,t:1527628218994};\\\", \\\"{x:1550,y:838,t:1527628219009};\\\", \\\"{x:1550,y:837,t:1527628219025};\\\", \\\"{x:1549,y:835,t:1527628233221};\\\", \\\"{x:1540,y:830,t:1527628233230};\\\", \\\"{x:1527,y:825,t:1527628233244};\\\", \\\"{x:1494,y:813,t:1527628233260};\\\", \\\"{x:1465,y:802,t:1527628233277};\\\", \\\"{x:1429,y:794,t:1527628233293};\\\", \\\"{x:1411,y:791,t:1527628233309};\\\", \\\"{x:1394,y:787,t:1527628233327};\\\", \\\"{x:1381,y:782,t:1527628233343};\\\", \\\"{x:1368,y:777,t:1527628233359};\\\", \\\"{x:1357,y:775,t:1527628233376};\\\", \\\"{x:1339,y:766,t:1527628233394};\\\", \\\"{x:1319,y:759,t:1527628233411};\\\", \\\"{x:1299,y:752,t:1527628233427};\\\", \\\"{x:1283,y:746,t:1527628233443};\\\", \\\"{x:1263,y:739,t:1527628233460};\\\", \\\"{x:1251,y:736,t:1527628233476};\\\", \\\"{x:1247,y:735,t:1527628233493};\\\", \\\"{x:1244,y:734,t:1527628233511};\\\", \\\"{x:1242,y:733,t:1527628233526};\\\", \\\"{x:1239,y:732,t:1527628233543};\\\", \\\"{x:1235,y:730,t:1527628233560};\\\", \\\"{x:1226,y:726,t:1527628233577};\\\", \\\"{x:1212,y:720,t:1527628233594};\\\", \\\"{x:1197,y:714,t:1527628233611};\\\", \\\"{x:1180,y:706,t:1527628233627};\\\", \\\"{x:1160,y:698,t:1527628233643};\\\", \\\"{x:1125,y:682,t:1527628233660};\\\", \\\"{x:1102,y:673,t:1527628233676};\\\", \\\"{x:1082,y:661,t:1527628233693};\\\", \\\"{x:1062,y:649,t:1527628233710};\\\", \\\"{x:1041,y:636,t:1527628233726};\\\", \\\"{x:1022,y:622,t:1527628233744};\\\", \\\"{x:1007,y:610,t:1527628233761};\\\", \\\"{x:987,y:593,t:1527628233777};\\\", \\\"{x:966,y:579,t:1527628233793};\\\", \\\"{x:947,y:564,t:1527628233811};\\\", \\\"{x:928,y:552,t:1527628233827};\\\", \\\"{x:876,y:523,t:1527628233860};\\\", \\\"{x:860,y:516,t:1527628233883};\\\", \\\"{x:850,y:513,t:1527628233898};\\\", \\\"{x:843,y:509,t:1527628233915};\\\", \\\"{x:834,y:506,t:1527628233932};\\\", \\\"{x:828,y:505,t:1527628233948};\\\", \\\"{x:817,y:502,t:1527628233965};\\\", \\\"{x:808,y:501,t:1527628233981};\\\", \\\"{x:790,y:499,t:1527628233998};\\\", \\\"{x:767,y:497,t:1527628234014};\\\", \\\"{x:737,y:497,t:1527628234030};\\\", \\\"{x:684,y:489,t:1527628234048};\\\", \\\"{x:606,y:478,t:1527628234065};\\\", \\\"{x:525,y:467,t:1527628234082};\\\", \\\"{x:465,y:462,t:1527628234098};\\\", \\\"{x:409,y:460,t:1527628234115};\\\", \\\"{x:362,y:460,t:1527628234132};\\\", \\\"{x:340,y:460,t:1527628234148};\\\", \\\"{x:325,y:460,t:1527628234165};\\\", \\\"{x:317,y:460,t:1527628234182};\\\", \\\"{x:313,y:460,t:1527628234199};\\\", \\\"{x:312,y:461,t:1527628234215};\\\", \\\"{x:309,y:462,t:1527628234232};\\\", \\\"{x:306,y:464,t:1527628234249};\\\", \\\"{x:301,y:468,t:1527628234266};\\\", \\\"{x:293,y:474,t:1527628234282};\\\", \\\"{x:284,y:480,t:1527628234299};\\\", \\\"{x:272,y:490,t:1527628234317};\\\", \\\"{x:266,y:495,t:1527628234332};\\\", \\\"{x:263,y:499,t:1527628234349};\\\", \\\"{x:259,y:503,t:1527628234364};\\\", \\\"{x:256,y:508,t:1527628234382};\\\", \\\"{x:254,y:510,t:1527628234399};\\\", \\\"{x:249,y:513,t:1527628234415};\\\", \\\"{x:248,y:516,t:1527628234431};\\\", \\\"{x:243,y:519,t:1527628234449};\\\", \\\"{x:240,y:522,t:1527628234465};\\\", \\\"{x:237,y:524,t:1527628234482};\\\", \\\"{x:231,y:527,t:1527628234499};\\\", \\\"{x:223,y:530,t:1527628234514};\\\", \\\"{x:207,y:534,t:1527628234532};\\\", \\\"{x:195,y:536,t:1527628234549};\\\", \\\"{x:182,y:538,t:1527628234566};\\\", \\\"{x:171,y:538,t:1527628234582};\\\", \\\"{x:165,y:538,t:1527628234599};\\\", \\\"{x:158,y:538,t:1527628234615};\\\", \\\"{x:154,y:538,t:1527628234632};\\\", \\\"{x:151,y:539,t:1527628234649};\\\", \\\"{x:150,y:539,t:1527628234668};\\\", \\\"{x:149,y:539,t:1527628234682};\\\", \\\"{x:148,y:539,t:1527628234699};\\\", \\\"{x:147,y:539,t:1527628234716};\\\", \\\"{x:149,y:539,t:1527628238406};\\\", \\\"{x:162,y:539,t:1527628238420};\\\", \\\"{x:171,y:539,t:1527628238437};\\\", \\\"{x:183,y:543,t:1527628238452};\\\", \\\"{x:193,y:545,t:1527628238469};\\\", \\\"{x:199,y:546,t:1527628238485};\\\", \\\"{x:205,y:546,t:1527628238502};\\\", \\\"{x:207,y:547,t:1527628238518};\\\", \\\"{x:208,y:547,t:1527628238535};\\\", \\\"{x:209,y:547,t:1527628238564};\\\", \\\"{x:210,y:547,t:1527628238605};\\\", \\\"{x:211,y:547,t:1527628238618};\\\", \\\"{x:212,y:547,t:1527628238635};\\\", \\\"{x:219,y:549,t:1527628238653};\\\", \\\"{x:225,y:551,t:1527628238669};\\\", \\\"{x:231,y:552,t:1527628238685};\\\", \\\"{x:239,y:555,t:1527628238702};\\\", \\\"{x:245,y:557,t:1527628238719};\\\", \\\"{x:257,y:561,t:1527628238735};\\\", \\\"{x:263,y:562,t:1527628238752};\\\", \\\"{x:271,y:564,t:1527628238770};\\\", \\\"{x:277,y:566,t:1527628238787};\\\", \\\"{x:284,y:568,t:1527628238802};\\\", \\\"{x:287,y:568,t:1527628238819};\\\", \\\"{x:290,y:570,t:1527628238835};\\\", \\\"{x:294,y:570,t:1527628238852};\\\", \\\"{x:296,y:572,t:1527628238869};\\\", \\\"{x:300,y:573,t:1527628238885};\\\", \\\"{x:305,y:574,t:1527628238902};\\\", \\\"{x:314,y:579,t:1527628238919};\\\", \\\"{x:329,y:584,t:1527628238935};\\\", \\\"{x:344,y:589,t:1527628238952};\\\", \\\"{x:361,y:594,t:1527628238971};\\\", \\\"{x:380,y:600,t:1527628238986};\\\", \\\"{x:400,y:605,t:1527628239002};\\\", \\\"{x:422,y:613,t:1527628239019};\\\", \\\"{x:449,y:621,t:1527628239035};\\\", \\\"{x:467,y:625,t:1527628239052};\\\", \\\"{x:484,y:630,t:1527628239069};\\\", \\\"{x:499,y:636,t:1527628239086};\\\", \\\"{x:508,y:637,t:1527628239102};\\\", \\\"{x:513,y:640,t:1527628239119};\\\", \\\"{x:519,y:641,t:1527628239136};\\\", \\\"{x:522,y:642,t:1527628239152};\\\", \\\"{x:525,y:643,t:1527628239169};\\\", \\\"{x:527,y:644,t:1527628239186};\\\", \\\"{x:528,y:644,t:1527628239245};\\\", \\\"{x:526,y:643,t:1527628239413};\\\", \\\"{x:514,y:636,t:1527628239420};\\\", \\\"{x:471,y:605,t:1527628239437};\\\", \\\"{x:416,y:571,t:1527628239454};\\\", \\\"{x:353,y:535,t:1527628239470};\\\", \\\"{x:296,y:504,t:1527628239487};\\\", \\\"{x:247,y:475,t:1527628239503};\\\", \\\"{x:221,y:462,t:1527628239519};\\\", \\\"{x:193,y:449,t:1527628239536};\\\", \\\"{x:173,y:439,t:1527628239552};\\\", \\\"{x:165,y:437,t:1527628239569};\\\", \\\"{x:164,y:436,t:1527628239588};\\\", \\\"{x:163,y:439,t:1527628239685};\\\", \\\"{x:161,y:449,t:1527628239703};\\\", \\\"{x:160,y:466,t:1527628239719};\\\", \\\"{x:160,y:490,t:1527628239736};\\\", \\\"{x:160,y:513,t:1527628239753};\\\", \\\"{x:160,y:528,t:1527628239770};\\\", \\\"{x:160,y:537,t:1527628239786};\\\", \\\"{x:160,y:541,t:1527628239803};\\\", \\\"{x:160,y:542,t:1527628239820};\\\", \\\"{x:160,y:544,t:1527628239844};\\\", \\\"{x:160,y:544,t:1527628240113};\\\", \\\"{x:160,y:544,t:1527628240120};\\\", \\\"{x:161,y:544,t:1527628240284};\\\", \\\"{x:163,y:544,t:1527628240292};\\\", \\\"{x:166,y:544,t:1527628240303};\\\", \\\"{x:182,y:551,t:1527628240320};\\\", \\\"{x:208,y:565,t:1527628240337};\\\", \\\"{x:235,y:582,t:1527628240353};\\\", \\\"{x:277,y:602,t:1527628240370};\\\", \\\"{x:324,y:620,t:1527628240387};\\\", \\\"{x:363,y:639,t:1527628240404};\\\", \\\"{x:420,y:663,t:1527628240419};\\\", \\\"{x:452,y:676,t:1527628240438};\\\", \\\"{x:483,y:690,t:1527628240453};\\\", \\\"{x:496,y:696,t:1527628240470};\\\", \\\"{x:500,y:697,t:1527628240487};\\\", \\\"{x:501,y:698,t:1527628240503};\\\", \\\"{x:501,y:699,t:1527628240604};\\\", \\\"{x:502,y:704,t:1527628240620};\\\", \\\"{x:502,y:707,t:1527628240637};\\\", \\\"{x:502,y:709,t:1527628240654};\\\", \\\"{x:503,y:714,t:1527628240670};\\\", \\\"{x:505,y:721,t:1527628240687};\\\", \\\"{x:511,y:732,t:1527628240704};\\\", \\\"{x:517,y:745,t:1527628240720};\\\", \\\"{x:522,y:755,t:1527628240738};\\\", \\\"{x:525,y:761,t:1527628240754};\\\", \\\"{x:526,y:761,t:1527628240828};\\\", \\\"{x:527,y:761,t:1527628240884};\\\", \\\"{x:528,y:761,t:1527628240924};\\\", \\\"{x:530,y:761,t:1527628240980};\\\", \\\"{x:530,y:759,t:1527628240987};\\\", \\\"{x:530,y:753,t:1527628241004};\\\", \\\"{x:532,y:751,t:1527628241020};\\\", \\\"{x:532,y:749,t:1527628241037};\\\", \\\"{x:532,y:748,t:1527628241054};\\\", \\\"{x:532,y:746,t:1527628242836};\\\", \\\"{x:532,y:741,t:1527628242844};\\\", \\\"{x:532,y:739,t:1527628242854};\\\", \\\"{x:539,y:728,t:1527628242871};\\\", \\\"{x:551,y:717,t:1527628242887};\\\", \\\"{x:565,y:704,t:1527628242904};\\\", \\\"{x:582,y:691,t:1527628242921};\\\", \\\"{x:606,y:670,t:1527628242939};\\\", \\\"{x:634,y:642,t:1527628242955};\\\", \\\"{x:669,y:603,t:1527628242972};\\\", \\\"{x:690,y:577,t:1527628242990};\\\", \\\"{x:708,y:556,t:1527628243006};\\\", \\\"{x:716,y:545,t:1527628243022};\\\", \\\"{x:723,y:536,t:1527628243039};\\\", \\\"{x:723,y:535,t:1527628243056};\\\", \\\"{x:722,y:537,t:1527628243395};\\\", \\\"{x:715,y:540,t:1527628243405};\\\", \\\"{x:706,y:555,t:1527628243421};\\\", \\\"{x:694,y:575,t:1527628243438};\\\", \\\"{x:675,y:603,t:1527628243456};\\\", \\\"{x:659,y:626,t:1527628243471};\\\", \\\"{x:637,y:648,t:1527628243489};\\\", \\\"{x:619,y:664,t:1527628243505};\\\", \\\"{x:603,y:677,t:1527628243522};\\\", \\\"{x:590,y:688,t:1527628243539};\\\", \\\"{x:583,y:696,t:1527628243556};\\\", \\\"{x:579,y:702,t:1527628243572};\\\", \\\"{x:576,y:705,t:1527628243590};\\\", \\\"{x:574,y:711,t:1527628243606};\\\", \\\"{x:571,y:715,t:1527628243622};\\\", \\\"{x:567,y:723,t:1527628243639};\\\", \\\"{x:563,y:729,t:1527628243657};\\\", \\\"{x:558,y:734,t:1527628243672};\\\", \\\"{x:555,y:738,t:1527628243689};\\\", \\\"{x:553,y:740,t:1527628243706};\\\", \\\"{x:551,y:740,t:1527628243723};\\\", \\\"{x:550,y:742,t:1527628243739};\\\", \\\"{x:550,y:741,t:1527628244460};\\\", \\\"{x:550,y:739,t:1527628244474};\\\", \\\"{x:550,y:737,t:1527628244489};\\\", \\\"{x:550,y:733,t:1527628244506};\\\", \\\"{x:550,y:731,t:1527628244523};\\\", \\\"{x:552,y:728,t:1527628244540};\\\", \\\"{x:552,y:727,t:1527628244557};\\\", \\\"{x:552,y:725,t:1527628244573};\\\", \\\"{x:552,y:722,t:1527628244590};\\\", \\\"{x:552,y:719,t:1527628244607};\\\", \\\"{x:552,y:716,t:1527628244623};\\\", \\\"{x:553,y:713,t:1527628244640};\\\", \\\"{x:553,y:710,t:1527628244657};\\\", \\\"{x:554,y:706,t:1527628244673};\\\", \\\"{x:555,y:703,t:1527628244689};\\\", \\\"{x:555,y:699,t:1527628244707};\\\", \\\"{x:556,y:695,t:1527628244722};\\\", \\\"{x:556,y:688,t:1527628244740};\\\", \\\"{x:557,y:684,t:1527628244757};\\\", \\\"{x:557,y:683,t:1527628244773};\\\", \\\"{x:557,y:682,t:1527628244790};\\\", \\\"{x:557,y:680,t:1527628244807};\\\", \\\"{x:557,y:679,t:1527628244836};\\\", \\\"{x:557,y:678,t:1527628244876};\\\", \\\"{x:557,y:677,t:1527628244892};\\\", \\\"{x:557,y:676,t:1527628244924};\\\", \\\"{x:557,y:675,t:1527628244972};\\\" ] }, { \\\"rt\\\": 46777, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 541276, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-02 PM-02 PM-02 PM-G -E -12 PM-03 PM-04 PM-05 PM-04 PM-03 PM-02 PM-7-C -F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:556,y:674,t:1527628246229};\\\", \\\"{x:554,y:666,t:1527628246242};\\\", \\\"{x:550,y:654,t:1527628246259};\\\", \\\"{x:546,y:642,t:1527628246276};\\\", \\\"{x:544,y:634,t:1527628246292};\\\", \\\"{x:539,y:624,t:1527628246308};\\\", \\\"{x:537,y:620,t:1527628246325};\\\", \\\"{x:536,y:617,t:1527628246342};\\\", \\\"{x:534,y:613,t:1527628246359};\\\", \\\"{x:532,y:608,t:1527628246375};\\\", \\\"{x:529,y:601,t:1527628246392};\\\", \\\"{x:526,y:595,t:1527628246408};\\\", \\\"{x:523,y:586,t:1527628246426};\\\", \\\"{x:519,y:578,t:1527628246441};\\\", \\\"{x:516,y:572,t:1527628246458};\\\", \\\"{x:513,y:565,t:1527628246476};\\\", \\\"{x:511,y:558,t:1527628246491};\\\", \\\"{x:508,y:550,t:1527628246508};\\\", \\\"{x:504,y:540,t:1527628246525};\\\", \\\"{x:502,y:536,t:1527628246542};\\\", \\\"{x:499,y:529,t:1527628246559};\\\", \\\"{x:495,y:522,t:1527628246575};\\\", \\\"{x:492,y:515,t:1527628246591};\\\", \\\"{x:491,y:512,t:1527628246609};\\\", \\\"{x:488,y:508,t:1527628246625};\\\", \\\"{x:487,y:506,t:1527628246642};\\\", \\\"{x:486,y:504,t:1527628246658};\\\", \\\"{x:486,y:502,t:1527628246675};\\\", \\\"{x:485,y:501,t:1527628246692};\\\", \\\"{x:484,y:499,t:1527628246717};\\\", \\\"{x:483,y:498,t:1527628246844};\\\", \\\"{x:481,y:495,t:1527628247452};\\\", \\\"{x:481,y:493,t:1527628247462};\\\", \\\"{x:481,y:487,t:1527628247478};\\\", \\\"{x:481,y:483,t:1527628247495};\\\", \\\"{x:481,y:480,t:1527628247512};\\\", \\\"{x:480,y:477,t:1527628247528};\\\", \\\"{x:480,y:474,t:1527628247544};\\\", \\\"{x:480,y:472,t:1527628247561};\\\", \\\"{x:480,y:471,t:1527628247578};\\\", \\\"{x:480,y:470,t:1527628247637};\\\", \\\"{x:482,y:469,t:1527628251077};\\\", \\\"{x:498,y:472,t:1527628251085};\\\", \\\"{x:521,y:490,t:1527628251096};\\\", \\\"{x:578,y:533,t:1527628251112};\\\", \\\"{x:623,y:565,t:1527628251131};\\\", \\\"{x:667,y:592,t:1527628251146};\\\", \\\"{x:718,y:622,t:1527628251163};\\\", \\\"{x:765,y:649,t:1527628251179};\\\", \\\"{x:841,y:692,t:1527628251196};\\\", \\\"{x:896,y:715,t:1527628251212};\\\", \\\"{x:940,y:733,t:1527628251228};\\\", \\\"{x:976,y:750,t:1527628251246};\\\", \\\"{x:1019,y:773,t:1527628251263};\\\", \\\"{x:1057,y:795,t:1527628251279};\\\", \\\"{x:1090,y:814,t:1527628251296};\\\", \\\"{x:1123,y:835,t:1527628251312};\\\", \\\"{x:1161,y:857,t:1527628251329};\\\", \\\"{x:1201,y:879,t:1527628251346};\\\", \\\"{x:1223,y:892,t:1527628251363};\\\", \\\"{x:1242,y:904,t:1527628251379};\\\", \\\"{x:1267,y:920,t:1527628251395};\\\", \\\"{x:1284,y:932,t:1527628251413};\\\", \\\"{x:1306,y:948,t:1527628251429};\\\", \\\"{x:1331,y:964,t:1527628251446};\\\", \\\"{x:1347,y:974,t:1527628251463};\\\", \\\"{x:1355,y:980,t:1527628251479};\\\", \\\"{x:1359,y:981,t:1527628251496};\\\", \\\"{x:1362,y:984,t:1527628251513};\\\", \\\"{x:1368,y:985,t:1527628251530};\\\", \\\"{x:1377,y:988,t:1527628251546};\\\", \\\"{x:1384,y:988,t:1527628251563};\\\", \\\"{x:1392,y:988,t:1527628251578};\\\", \\\"{x:1404,y:988,t:1527628251596};\\\", \\\"{x:1410,y:988,t:1527628251612};\\\", \\\"{x:1418,y:988,t:1527628251629};\\\", \\\"{x:1434,y:988,t:1527628251646};\\\", \\\"{x:1450,y:986,t:1527628251663};\\\", \\\"{x:1462,y:982,t:1527628251679};\\\", \\\"{x:1470,y:979,t:1527628251696};\\\", \\\"{x:1472,y:978,t:1527628251713};\\\", \\\"{x:1474,y:977,t:1527628251729};\\\", \\\"{x:1477,y:977,t:1527628251746};\\\", \\\"{x:1478,y:977,t:1527628251764};\\\", \\\"{x:1481,y:977,t:1527628251779};\\\", \\\"{x:1482,y:976,t:1527628251797};\\\", \\\"{x:1483,y:975,t:1527628251813};\\\", \\\"{x:1484,y:974,t:1527628251853};\\\", \\\"{x:1485,y:974,t:1527628251864};\\\", \\\"{x:1487,y:972,t:1527628251880};\\\", \\\"{x:1488,y:970,t:1527628251896};\\\", \\\"{x:1489,y:968,t:1527628251914};\\\", \\\"{x:1490,y:966,t:1527628251930};\\\", \\\"{x:1491,y:963,t:1527628251947};\\\", \\\"{x:1491,y:962,t:1527628251965};\\\", \\\"{x:1492,y:962,t:1527628251981};\\\", \\\"{x:1492,y:960,t:1527628251997};\\\", \\\"{x:1492,y:959,t:1527628252013};\\\", \\\"{x:1493,y:958,t:1527628252031};\\\", \\\"{x:1494,y:956,t:1527628252046};\\\", \\\"{x:1494,y:952,t:1527628252063};\\\", \\\"{x:1494,y:948,t:1527628252080};\\\", \\\"{x:1494,y:943,t:1527628252097};\\\", \\\"{x:1495,y:934,t:1527628252114};\\\", \\\"{x:1497,y:925,t:1527628252131};\\\", \\\"{x:1497,y:914,t:1527628252147};\\\", \\\"{x:1497,y:906,t:1527628252163};\\\", \\\"{x:1497,y:897,t:1527628252180};\\\", \\\"{x:1497,y:894,t:1527628252197};\\\", \\\"{x:1497,y:891,t:1527628252213};\\\", \\\"{x:1497,y:888,t:1527628252230};\\\", \\\"{x:1497,y:885,t:1527628252247};\\\", \\\"{x:1497,y:882,t:1527628252263};\\\", \\\"{x:1497,y:881,t:1527628252281};\\\", \\\"{x:1497,y:880,t:1527628252296};\\\", \\\"{x:1496,y:878,t:1527628252313};\\\", \\\"{x:1495,y:876,t:1527628252332};\\\", \\\"{x:1494,y:874,t:1527628252349};\\\", \\\"{x:1493,y:873,t:1527628252364};\\\", \\\"{x:1491,y:869,t:1527628252381};\\\", \\\"{x:1490,y:868,t:1527628252396};\\\", \\\"{x:1489,y:868,t:1527628252493};\\\", \\\"{x:1489,y:874,t:1527628252533};\\\", \\\"{x:1489,y:884,t:1527628252548};\\\", \\\"{x:1489,y:906,t:1527628252564};\\\", \\\"{x:1489,y:928,t:1527628252581};\\\", \\\"{x:1487,y:958,t:1527628252597};\\\", \\\"{x:1485,y:974,t:1527628252614};\\\", \\\"{x:1484,y:979,t:1527628252630};\\\", \\\"{x:1484,y:986,t:1527628252648};\\\", \\\"{x:1483,y:987,t:1527628252664};\\\", \\\"{x:1483,y:989,t:1527628252680};\\\", \\\"{x:1483,y:986,t:1527628253005};\\\", \\\"{x:1483,y:983,t:1527628253013};\\\", \\\"{x:1483,y:978,t:1527628253031};\\\", \\\"{x:1483,y:971,t:1527628253047};\\\", \\\"{x:1483,y:965,t:1527628253064};\\\", \\\"{x:1483,y:964,t:1527628253080};\\\", \\\"{x:1483,y:963,t:1527628253097};\\\", \\\"{x:1483,y:962,t:1527628253382};\\\", \\\"{x:1481,y:958,t:1527628253397};\\\", \\\"{x:1481,y:956,t:1527628253414};\\\", \\\"{x:1480,y:954,t:1527628253430};\\\", \\\"{x:1479,y:953,t:1527628253447};\\\", \\\"{x:1478,y:951,t:1527628253464};\\\", \\\"{x:1478,y:949,t:1527628253480};\\\", \\\"{x:1476,y:948,t:1527628253498};\\\", \\\"{x:1477,y:948,t:1527628253924};\\\", \\\"{x:1480,y:948,t:1527628253931};\\\", \\\"{x:1480,y:949,t:1527628253947};\\\", \\\"{x:1481,y:949,t:1527628253964};\\\", \\\"{x:1482,y:950,t:1527628254077};\\\", \\\"{x:1483,y:951,t:1527628254222};\\\", \\\"{x:1483,y:952,t:1527628254525};\\\", \\\"{x:1483,y:954,t:1527628254541};\\\", \\\"{x:1482,y:946,t:1527628260269};\\\", \\\"{x:1451,y:867,t:1527628260285};\\\", \\\"{x:1411,y:773,t:1527628260301};\\\", \\\"{x:1374,y:688,t:1527628260317};\\\", \\\"{x:1351,y:630,t:1527628260335};\\\", \\\"{x:1342,y:598,t:1527628260351};\\\", \\\"{x:1337,y:581,t:1527628260367};\\\", \\\"{x:1336,y:574,t:1527628260384};\\\", \\\"{x:1335,y:572,t:1527628260402};\\\", \\\"{x:1334,y:570,t:1527628260417};\\\", \\\"{x:1334,y:568,t:1527628260434};\\\", \\\"{x:1333,y:567,t:1527628260451};\\\", \\\"{x:1334,y:566,t:1527628260677};\\\", \\\"{x:1335,y:565,t:1527628260685};\\\", \\\"{x:1338,y:564,t:1527628260702};\\\", \\\"{x:1340,y:563,t:1527628260718};\\\", \\\"{x:1341,y:563,t:1527628260735};\\\", \\\"{x:1342,y:563,t:1527628260751};\\\", \\\"{x:1343,y:563,t:1527628260767};\\\", \\\"{x:1344,y:562,t:1527628260784};\\\", \\\"{x:1347,y:560,t:1527628260828};\\\", \\\"{x:1348,y:560,t:1527628260843};\\\", \\\"{x:1351,y:560,t:1527628260852};\\\", \\\"{x:1352,y:560,t:1527628260867};\\\", \\\"{x:1358,y:560,t:1527628260885};\\\", \\\"{x:1361,y:560,t:1527628260902};\\\", \\\"{x:1362,y:560,t:1527628260917};\\\", \\\"{x:1366,y:560,t:1527628260934};\\\", \\\"{x:1370,y:560,t:1527628260951};\\\", \\\"{x:1376,y:562,t:1527628260969};\\\", \\\"{x:1379,y:563,t:1527628260984};\\\", \\\"{x:1383,y:564,t:1527628261002};\\\", \\\"{x:1385,y:565,t:1527628261070};\\\", \\\"{x:1387,y:565,t:1527628261084};\\\", \\\"{x:1389,y:566,t:1527628261101};\\\", \\\"{x:1390,y:566,t:1527628261124};\\\", \\\"{x:1391,y:566,t:1527628261134};\\\", \\\"{x:1392,y:567,t:1527628261151};\\\", \\\"{x:1393,y:568,t:1527628261169};\\\", \\\"{x:1394,y:568,t:1527628261245};\\\", \\\"{x:1395,y:568,t:1527628261261};\\\", \\\"{x:1396,y:568,t:1527628261268};\\\", \\\"{x:1397,y:568,t:1527628261292};\\\", \\\"{x:1399,y:568,t:1527628261349};\\\", \\\"{x:1400,y:568,t:1527628261357};\\\", \\\"{x:1403,y:568,t:1527628261372};\\\", \\\"{x:1404,y:568,t:1527628261385};\\\", \\\"{x:1406,y:568,t:1527628261401};\\\", \\\"{x:1407,y:568,t:1527628261419};\\\", \\\"{x:1409,y:568,t:1527628261435};\\\", \\\"{x:1410,y:568,t:1527628261461};\\\", \\\"{x:1410,y:567,t:1527628261472};\\\", \\\"{x:1411,y:567,t:1527628261484};\\\", \\\"{x:1414,y:567,t:1527628261501};\\\", \\\"{x:1415,y:566,t:1527628261518};\\\", \\\"{x:1418,y:566,t:1527628261534};\\\", \\\"{x:1420,y:565,t:1527628261552};\\\", \\\"{x:1421,y:565,t:1527628261568};\\\", \\\"{x:1425,y:565,t:1527628261585};\\\", \\\"{x:1428,y:565,t:1527628261601};\\\", \\\"{x:1431,y:565,t:1527628261618};\\\", \\\"{x:1432,y:565,t:1527628261635};\\\", \\\"{x:1433,y:565,t:1527628261651};\\\", \\\"{x:1436,y:564,t:1527628261668};\\\", \\\"{x:1440,y:564,t:1527628261685};\\\", \\\"{x:1443,y:564,t:1527628261701};\\\", \\\"{x:1445,y:564,t:1527628261718};\\\", \\\"{x:1448,y:564,t:1527628261735};\\\", \\\"{x:1450,y:564,t:1527628261751};\\\", \\\"{x:1453,y:564,t:1527628261768};\\\", \\\"{x:1455,y:564,t:1527628261786};\\\", \\\"{x:1457,y:564,t:1527628261801};\\\", \\\"{x:1459,y:564,t:1527628261818};\\\", \\\"{x:1461,y:564,t:1527628261835};\\\", \\\"{x:1464,y:564,t:1527628261851};\\\", \\\"{x:1465,y:564,t:1527628261868};\\\", \\\"{x:1466,y:564,t:1527628261989};\\\", \\\"{x:1467,y:564,t:1527628262093};\\\", \\\"{x:1468,y:564,t:1527628262116};\\\", \\\"{x:1470,y:563,t:1527628262140};\\\", \\\"{x:1471,y:563,t:1527628262541};\\\", \\\"{x:1472,y:562,t:1527628263253};\\\", \\\"{x:1473,y:562,t:1527628263317};\\\", \\\"{x:1474,y:562,t:1527628263348};\\\", \\\"{x:1475,y:562,t:1527628263356};\\\", \\\"{x:1476,y:562,t:1527628263369};\\\", \\\"{x:1477,y:562,t:1527628263386};\\\", \\\"{x:1478,y:562,t:1527628263404};\\\", \\\"{x:1479,y:563,t:1527628263669};\\\", \\\"{x:1479,y:564,t:1527628263868};\\\", \\\"{x:1479,y:566,t:1527628263876};\\\", \\\"{x:1479,y:568,t:1527628263886};\\\", \\\"{x:1480,y:571,t:1527628263902};\\\", \\\"{x:1480,y:575,t:1527628263919};\\\", \\\"{x:1480,y:578,t:1527628263936};\\\", \\\"{x:1480,y:580,t:1527628263953};\\\", \\\"{x:1480,y:582,t:1527628263969};\\\", \\\"{x:1480,y:583,t:1527628263986};\\\", \\\"{x:1480,y:585,t:1527628264002};\\\", \\\"{x:1480,y:586,t:1527628264019};\\\", \\\"{x:1480,y:590,t:1527628264036};\\\", \\\"{x:1480,y:592,t:1527628264052};\\\", \\\"{x:1480,y:596,t:1527628264069};\\\", \\\"{x:1480,y:599,t:1527628264086};\\\", \\\"{x:1480,y:602,t:1527628264102};\\\", \\\"{x:1480,y:604,t:1527628264120};\\\", \\\"{x:1480,y:606,t:1527628264136};\\\", \\\"{x:1480,y:609,t:1527628264154};\\\", \\\"{x:1480,y:611,t:1527628264169};\\\", \\\"{x:1480,y:613,t:1527628264186};\\\", \\\"{x:1480,y:616,t:1527628264204};\\\", \\\"{x:1480,y:617,t:1527628264219};\\\", \\\"{x:1480,y:619,t:1527628264236};\\\", \\\"{x:1480,y:620,t:1527628264254};\\\", \\\"{x:1480,y:621,t:1527628264269};\\\", \\\"{x:1480,y:622,t:1527628264286};\\\", \\\"{x:1480,y:624,t:1527628264303};\\\", \\\"{x:1480,y:626,t:1527628264320};\\\", \\\"{x:1480,y:627,t:1527628264336};\\\", \\\"{x:1479,y:630,t:1527628264354};\\\", \\\"{x:1479,y:632,t:1527628264370};\\\", \\\"{x:1478,y:636,t:1527628264387};\\\", \\\"{x:1478,y:638,t:1527628264403};\\\", \\\"{x:1478,y:640,t:1527628264420};\\\", \\\"{x:1476,y:646,t:1527628264437};\\\", \\\"{x:1476,y:650,t:1527628264454};\\\", \\\"{x:1475,y:655,t:1527628264470};\\\", \\\"{x:1475,y:661,t:1527628264486};\\\", \\\"{x:1474,y:665,t:1527628264504};\\\", \\\"{x:1472,y:669,t:1527628264519};\\\", \\\"{x:1472,y:671,t:1527628264537};\\\", \\\"{x:1472,y:673,t:1527628264554};\\\", \\\"{x:1471,y:674,t:1527628264569};\\\", \\\"{x:1471,y:676,t:1527628264586};\\\", \\\"{x:1470,y:678,t:1527628264603};\\\", \\\"{x:1470,y:681,t:1527628264620};\\\", \\\"{x:1469,y:684,t:1527628264636};\\\", \\\"{x:1469,y:687,t:1527628264654};\\\", \\\"{x:1469,y:689,t:1527628264670};\\\", \\\"{x:1468,y:691,t:1527628264687};\\\", \\\"{x:1468,y:694,t:1527628264704};\\\", \\\"{x:1468,y:697,t:1527628264720};\\\", \\\"{x:1468,y:701,t:1527628264736};\\\", \\\"{x:1468,y:704,t:1527628264753};\\\", \\\"{x:1467,y:708,t:1527628264769};\\\", \\\"{x:1467,y:712,t:1527628264787};\\\", \\\"{x:1467,y:715,t:1527628264804};\\\", \\\"{x:1467,y:719,t:1527628264820};\\\", \\\"{x:1467,y:723,t:1527628264836};\\\", \\\"{x:1467,y:725,t:1527628264854};\\\", \\\"{x:1467,y:729,t:1527628264871};\\\", \\\"{x:1467,y:730,t:1527628264887};\\\", \\\"{x:1467,y:734,t:1527628264903};\\\", \\\"{x:1467,y:738,t:1527628264920};\\\", \\\"{x:1467,y:742,t:1527628264936};\\\", \\\"{x:1467,y:744,t:1527628264954};\\\", \\\"{x:1467,y:748,t:1527628264971};\\\", \\\"{x:1467,y:751,t:1527628264987};\\\", \\\"{x:1467,y:755,t:1527628265004};\\\", \\\"{x:1467,y:760,t:1527628265020};\\\", \\\"{x:1467,y:764,t:1527628265036};\\\", \\\"{x:1467,y:768,t:1527628265053};\\\", \\\"{x:1467,y:773,t:1527628265071};\\\", \\\"{x:1467,y:776,t:1527628265086};\\\", \\\"{x:1467,y:781,t:1527628265103};\\\", \\\"{x:1468,y:786,t:1527628265121};\\\", \\\"{x:1468,y:790,t:1527628265137};\\\", \\\"{x:1469,y:795,t:1527628265154};\\\", \\\"{x:1469,y:799,t:1527628265171};\\\", \\\"{x:1470,y:803,t:1527628265187};\\\", \\\"{x:1470,y:807,t:1527628265204};\\\", \\\"{x:1470,y:810,t:1527628265221};\\\", \\\"{x:1470,y:812,t:1527628265236};\\\", \\\"{x:1471,y:814,t:1527628265253};\\\", \\\"{x:1471,y:816,t:1527628265275};\\\", \\\"{x:1471,y:817,t:1527628265292};\\\", \\\"{x:1471,y:819,t:1527628265308};\\\", \\\"{x:1472,y:821,t:1527628265321};\\\", \\\"{x:1472,y:822,t:1527628265337};\\\", \\\"{x:1472,y:823,t:1527628265353};\\\", \\\"{x:1472,y:824,t:1527628265371};\\\", \\\"{x:1472,y:825,t:1527628265386};\\\", \\\"{x:1472,y:823,t:1527628265501};\\\", \\\"{x:1467,y:815,t:1527628265509};\\\", \\\"{x:1465,y:807,t:1527628265521};\\\", \\\"{x:1459,y:790,t:1527628265537};\\\", \\\"{x:1450,y:771,t:1527628265554};\\\", \\\"{x:1442,y:751,t:1527628265571};\\\", \\\"{x:1432,y:730,t:1527628265588};\\\", \\\"{x:1422,y:711,t:1527628265603};\\\", \\\"{x:1406,y:685,t:1527628265621};\\\", \\\"{x:1395,y:667,t:1527628265637};\\\", \\\"{x:1384,y:653,t:1527628265653};\\\", \\\"{x:1374,y:641,t:1527628265670};\\\", \\\"{x:1362,y:629,t:1527628265687};\\\", \\\"{x:1350,y:614,t:1527628265703};\\\", \\\"{x:1341,y:603,t:1527628265720};\\\", \\\"{x:1339,y:599,t:1527628265737};\\\", \\\"{x:1339,y:598,t:1527628265753};\\\", \\\"{x:1337,y:597,t:1527628265770};\\\", \\\"{x:1335,y:594,t:1527628265787};\\\", \\\"{x:1330,y:590,t:1527628265804};\\\", \\\"{x:1315,y:581,t:1527628265820};\\\", \\\"{x:1304,y:572,t:1527628265838};\\\", \\\"{x:1299,y:568,t:1527628265853};\\\", \\\"{x:1297,y:567,t:1527628265871};\\\", \\\"{x:1295,y:566,t:1527628265888};\\\", \\\"{x:1294,y:565,t:1527628265916};\\\", \\\"{x:1292,y:565,t:1527628266101};\\\", \\\"{x:1291,y:564,t:1527628266181};\\\", \\\"{x:1290,y:564,t:1527628266188};\\\", \\\"{x:1289,y:563,t:1527628266205};\\\", \\\"{x:1288,y:563,t:1527628266228};\\\", \\\"{x:1286,y:563,t:1527628266438};\\\", \\\"{x:1284,y:562,t:1527628266455};\\\", \\\"{x:1283,y:562,t:1527628266470};\\\", \\\"{x:1280,y:561,t:1527628266488};\\\", \\\"{x:1279,y:560,t:1527628267699};\\\", \\\"{x:1279,y:578,t:1527628273302};\\\", \\\"{x:1290,y:628,t:1527628273308};\\\", \\\"{x:1320,y:730,t:1527628273325};\\\", \\\"{x:1332,y:846,t:1527628273342};\\\", \\\"{x:1336,y:963,t:1527628273358};\\\", \\\"{x:1340,y:1069,t:1527628273375};\\\", \\\"{x:1336,y:1120,t:1527628273392};\\\", \\\"{x:1331,y:1130,t:1527628273408};\\\", \\\"{x:1313,y:1161,t:1527628273425};\\\", \\\"{x:1313,y:1162,t:1527628273442};\\\", \\\"{x:1308,y:1172,t:1527628273458};\\\", \\\"{x:1303,y:1175,t:1527628273475};\\\", \\\"{x:1300,y:1173,t:1527628273532};\\\", \\\"{x:1298,y:1165,t:1527628273542};\\\", \\\"{x:1288,y:1143,t:1527628273558};\\\", \\\"{x:1284,y:1121,t:1527628273575};\\\", \\\"{x:1281,y:1094,t:1527628273592};\\\", \\\"{x:1281,y:1065,t:1527628273608};\\\", \\\"{x:1283,y:1043,t:1527628273625};\\\", \\\"{x:1285,y:1031,t:1527628273642};\\\", \\\"{x:1287,y:1016,t:1527628273659};\\\", \\\"{x:1289,y:1011,t:1527628273675};\\\", \\\"{x:1290,y:1004,t:1527628273692};\\\", \\\"{x:1291,y:1001,t:1527628273708};\\\", \\\"{x:1291,y:1000,t:1527628273740};\\\", \\\"{x:1291,y:999,t:1527628273749};\\\", \\\"{x:1291,y:998,t:1527628273758};\\\", \\\"{x:1292,y:998,t:1527628273775};\\\", \\\"{x:1292,y:997,t:1527628273893};\\\", \\\"{x:1294,y:995,t:1527628273908};\\\", \\\"{x:1298,y:992,t:1527628273925};\\\", \\\"{x:1301,y:990,t:1527628273941};\\\", \\\"{x:1303,y:988,t:1527628273959};\\\", \\\"{x:1305,y:987,t:1527628273975};\\\", \\\"{x:1306,y:986,t:1527628273992};\\\", \\\"{x:1308,y:985,t:1527628274009};\\\", \\\"{x:1310,y:985,t:1527628274025};\\\", \\\"{x:1313,y:984,t:1527628274042};\\\", \\\"{x:1315,y:983,t:1527628274058};\\\", \\\"{x:1316,y:982,t:1527628274075};\\\", \\\"{x:1319,y:981,t:1527628274092};\\\", \\\"{x:1320,y:981,t:1527628274109};\\\", \\\"{x:1321,y:981,t:1527628274125};\\\", \\\"{x:1321,y:980,t:1527628274142};\\\", \\\"{x:1322,y:980,t:1527628274159};\\\", \\\"{x:1325,y:978,t:1527628274175};\\\", \\\"{x:1328,y:977,t:1527628274192};\\\", \\\"{x:1333,y:975,t:1527628274209};\\\", \\\"{x:1335,y:974,t:1527628274224};\\\", \\\"{x:1337,y:974,t:1527628274241};\\\", \\\"{x:1338,y:973,t:1527628274259};\\\", \\\"{x:1340,y:972,t:1527628274274};\\\", \\\"{x:1342,y:971,t:1527628274292};\\\", \\\"{x:1343,y:971,t:1527628274309};\\\", \\\"{x:1345,y:970,t:1527628274325};\\\", \\\"{x:1346,y:969,t:1527628274372};\\\", \\\"{x:1348,y:969,t:1527628274725};\\\", \\\"{x:1348,y:968,t:1527628274733};\\\", \\\"{x:1349,y:968,t:1527628274748};\\\", \\\"{x:1350,y:968,t:1527628274765};\\\", \\\"{x:1351,y:968,t:1527628274780};\\\", \\\"{x:1351,y:967,t:1527628274792};\\\", \\\"{x:1352,y:967,t:1527628274813};\\\", \\\"{x:1355,y:966,t:1527628274828};\\\", \\\"{x:1356,y:965,t:1527628274844};\\\", \\\"{x:1358,y:964,t:1527628274861};\\\", \\\"{x:1359,y:964,t:1527628274876};\\\", \\\"{x:1364,y:962,t:1527628274893};\\\", \\\"{x:1369,y:960,t:1527628274910};\\\", \\\"{x:1371,y:959,t:1527628274927};\\\", \\\"{x:1376,y:958,t:1527628274942};\\\", \\\"{x:1383,y:958,t:1527628274959};\\\", \\\"{x:1390,y:958,t:1527628274976};\\\", \\\"{x:1395,y:958,t:1527628274992};\\\", \\\"{x:1401,y:958,t:1527628275010};\\\", \\\"{x:1407,y:958,t:1527628275026};\\\", \\\"{x:1416,y:958,t:1527628275042};\\\", \\\"{x:1427,y:958,t:1527628275059};\\\", \\\"{x:1441,y:959,t:1527628275077};\\\", \\\"{x:1448,y:960,t:1527628275093};\\\", \\\"{x:1454,y:961,t:1527628275110};\\\", \\\"{x:1459,y:961,t:1527628275125};\\\", \\\"{x:1465,y:963,t:1527628275142};\\\", \\\"{x:1474,y:964,t:1527628275159};\\\", \\\"{x:1484,y:967,t:1527628275175};\\\", \\\"{x:1494,y:968,t:1527628275191};\\\", \\\"{x:1506,y:968,t:1527628275209};\\\", \\\"{x:1516,y:971,t:1527628275226};\\\", \\\"{x:1526,y:972,t:1527628275242};\\\", \\\"{x:1537,y:973,t:1527628275259};\\\", \\\"{x:1552,y:976,t:1527628275276};\\\", \\\"{x:1558,y:977,t:1527628275293};\\\", \\\"{x:1564,y:978,t:1527628275309};\\\", \\\"{x:1569,y:978,t:1527628275326};\\\", \\\"{x:1576,y:980,t:1527628275343};\\\", \\\"{x:1583,y:981,t:1527628275359};\\\", \\\"{x:1588,y:982,t:1527628275376};\\\", \\\"{x:1595,y:982,t:1527628275393};\\\", \\\"{x:1601,y:982,t:1527628275409};\\\", \\\"{x:1607,y:982,t:1527628275426};\\\", \\\"{x:1613,y:984,t:1527628275443};\\\", \\\"{x:1619,y:984,t:1527628275459};\\\", \\\"{x:1627,y:984,t:1527628275476};\\\", \\\"{x:1632,y:984,t:1527628275493};\\\", \\\"{x:1635,y:984,t:1527628275509};\\\", \\\"{x:1638,y:984,t:1527628275527};\\\", \\\"{x:1640,y:984,t:1527628275543};\\\", \\\"{x:1641,y:984,t:1527628275559};\\\", \\\"{x:1643,y:983,t:1527628275588};\\\", \\\"{x:1645,y:983,t:1527628275677};\\\", \\\"{x:1646,y:981,t:1527628275693};\\\", \\\"{x:1649,y:981,t:1527628275710};\\\", \\\"{x:1653,y:979,t:1527628275726};\\\", \\\"{x:1655,y:978,t:1527628275743};\\\", \\\"{x:1658,y:976,t:1527628275759};\\\", \\\"{x:1662,y:975,t:1527628275777};\\\", \\\"{x:1662,y:974,t:1527628275793};\\\", \\\"{x:1658,y:974,t:1527628275933};\\\", \\\"{x:1654,y:974,t:1527628275943};\\\", \\\"{x:1644,y:973,t:1527628275961};\\\", \\\"{x:1634,y:971,t:1527628275977};\\\", \\\"{x:1627,y:971,t:1527628275993};\\\", \\\"{x:1622,y:971,t:1527628276010};\\\", \\\"{x:1617,y:971,t:1527628276027};\\\", \\\"{x:1615,y:972,t:1527628276043};\\\", \\\"{x:1612,y:973,t:1527628276061};\\\", \\\"{x:1610,y:974,t:1527628276077};\\\", \\\"{x:1611,y:974,t:1527628276325};\\\", \\\"{x:1612,y:974,t:1527628276332};\\\", \\\"{x:1614,y:974,t:1527628276356};\\\", \\\"{x:1616,y:973,t:1527628276372};\\\", \\\"{x:1619,y:972,t:1527628276397};\\\", \\\"{x:1618,y:972,t:1527628277420};\\\", \\\"{x:1617,y:972,t:1527628277436};\\\", \\\"{x:1616,y:972,t:1527628277452};\\\", \\\"{x:1615,y:972,t:1527628277493};\\\", \\\"{x:1614,y:972,t:1527628277501};\\\", \\\"{x:1613,y:972,t:1527628277510};\\\", \\\"{x:1613,y:973,t:1527628277528};\\\", \\\"{x:1612,y:973,t:1527628277544};\\\", \\\"{x:1609,y:973,t:1527628277560};\\\", \\\"{x:1605,y:973,t:1527628277577};\\\", \\\"{x:1603,y:973,t:1527628277595};\\\", \\\"{x:1602,y:973,t:1527628277611};\\\", \\\"{x:1600,y:973,t:1527628277627};\\\", \\\"{x:1597,y:973,t:1527628277644};\\\", \\\"{x:1595,y:973,t:1527628277660};\\\", \\\"{x:1593,y:973,t:1527628277678};\\\", \\\"{x:1588,y:972,t:1527628277695};\\\", \\\"{x:1584,y:972,t:1527628277710};\\\", \\\"{x:1582,y:971,t:1527628277728};\\\", \\\"{x:1579,y:971,t:1527628277745};\\\", \\\"{x:1574,y:970,t:1527628277761};\\\", \\\"{x:1569,y:970,t:1527628277778};\\\", \\\"{x:1562,y:970,t:1527628277795};\\\", \\\"{x:1556,y:970,t:1527628277810};\\\", \\\"{x:1549,y:970,t:1527628277828};\\\", \\\"{x:1539,y:970,t:1527628277845};\\\", \\\"{x:1532,y:970,t:1527628277861};\\\", \\\"{x:1526,y:970,t:1527628277878};\\\", \\\"{x:1521,y:970,t:1527628277895};\\\", \\\"{x:1513,y:972,t:1527628277912};\\\", \\\"{x:1507,y:974,t:1527628277928};\\\", \\\"{x:1501,y:975,t:1527628277945};\\\", \\\"{x:1493,y:976,t:1527628277962};\\\", \\\"{x:1487,y:976,t:1527628277977};\\\", \\\"{x:1481,y:976,t:1527628277994};\\\", \\\"{x:1475,y:976,t:1527628278011};\\\", \\\"{x:1474,y:976,t:1527628278028};\\\", \\\"{x:1471,y:976,t:1527628280076};\\\", \\\"{x:1457,y:967,t:1527628280085};\\\", \\\"{x:1434,y:940,t:1527628280095};\\\", \\\"{x:1386,y:883,t:1527628280113};\\\", \\\"{x:1335,y:822,t:1527628280129};\\\", \\\"{x:1294,y:776,t:1527628280145};\\\", \\\"{x:1271,y:748,t:1527628280163};\\\", \\\"{x:1254,y:728,t:1527628280178};\\\", \\\"{x:1240,y:717,t:1527628280196};\\\", \\\"{x:1215,y:688,t:1527628280212};\\\", \\\"{x:1176,y:648,t:1527628280229};\\\", \\\"{x:1161,y:633,t:1527628280246};\\\", \\\"{x:1150,y:622,t:1527628280262};\\\", \\\"{x:1145,y:617,t:1527628280279};\\\", \\\"{x:1142,y:614,t:1527628280296};\\\", \\\"{x:1140,y:612,t:1527628280313};\\\", \\\"{x:1137,y:610,t:1527628280329};\\\", \\\"{x:1133,y:607,t:1527628280346};\\\", \\\"{x:1129,y:604,t:1527628280362};\\\", \\\"{x:1128,y:604,t:1527628280379};\\\", \\\"{x:1126,y:603,t:1527628280396};\\\", \\\"{x:1119,y:601,t:1527628280412};\\\", \\\"{x:1107,y:597,t:1527628280429};\\\", \\\"{x:1092,y:596,t:1527628280445};\\\", \\\"{x:1073,y:593,t:1527628280462};\\\", \\\"{x:1052,y:588,t:1527628280480};\\\", \\\"{x:1030,y:584,t:1527628280496};\\\", \\\"{x:1005,y:578,t:1527628280513};\\\", \\\"{x:980,y:570,t:1527628280530};\\\", \\\"{x:952,y:562,t:1527628280546};\\\", \\\"{x:926,y:554,t:1527628280564};\\\", \\\"{x:899,y:547,t:1527628280579};\\\", \\\"{x:881,y:544,t:1527628280595};\\\", \\\"{x:863,y:544,t:1527628280619};\\\", \\\"{x:859,y:544,t:1527628280635};\\\", \\\"{x:858,y:544,t:1527628280723};\\\", \\\"{x:857,y:544,t:1527628280736};\\\", \\\"{x:856,y:544,t:1527628280752};\\\", \\\"{x:854,y:544,t:1527628280769};\\\", \\\"{x:853,y:544,t:1527628280786};\\\", \\\"{x:847,y:544,t:1527628280803};\\\", \\\"{x:832,y:544,t:1527628280820};\\\", \\\"{x:814,y:544,t:1527628280836};\\\", \\\"{x:773,y:537,t:1527628280853};\\\", \\\"{x:748,y:529,t:1527628280869};\\\", \\\"{x:725,y:523,t:1527628280886};\\\", \\\"{x:714,y:519,t:1527628280905};\\\", \\\"{x:712,y:519,t:1527628280920};\\\", \\\"{x:710,y:519,t:1527628280936};\\\", \\\"{x:708,y:519,t:1527628281003};\\\", \\\"{x:703,y:517,t:1527628281019};\\\", \\\"{x:694,y:515,t:1527628281036};\\\", \\\"{x:679,y:514,t:1527628281053};\\\", \\\"{x:661,y:511,t:1527628281070};\\\", \\\"{x:645,y:509,t:1527628281086};\\\", \\\"{x:635,y:509,t:1527628281104};\\\", \\\"{x:625,y:507,t:1527628281120};\\\", \\\"{x:618,y:506,t:1527628281136};\\\", \\\"{x:612,y:506,t:1527628281153};\\\", \\\"{x:605,y:505,t:1527628281170};\\\", \\\"{x:602,y:505,t:1527628281187};\\\", \\\"{x:603,y:505,t:1527628281413};\\\", \\\"{x:604,y:505,t:1527628281421};\\\", \\\"{x:605,y:505,t:1527628281452};\\\", \\\"{x:605,y:506,t:1527628281597};\\\", \\\"{x:605,y:508,t:1527628281612};\\\", \\\"{x:605,y:509,t:1527628281620};\\\", \\\"{x:605,y:510,t:1527628282181};\\\", \\\"{x:607,y:510,t:1527628282188};\\\", \\\"{x:613,y:513,t:1527628282204};\\\", \\\"{x:617,y:515,t:1527628282221};\\\", \\\"{x:622,y:517,t:1527628282238};\\\", \\\"{x:628,y:517,t:1527628282254};\\\", \\\"{x:636,y:518,t:1527628282271};\\\", \\\"{x:647,y:518,t:1527628282288};\\\", \\\"{x:664,y:518,t:1527628282304};\\\", \\\"{x:680,y:518,t:1527628282321};\\\", \\\"{x:702,y:518,t:1527628282337};\\\", \\\"{x:730,y:518,t:1527628282355};\\\", \\\"{x:764,y:518,t:1527628282371};\\\", \\\"{x:814,y:518,t:1527628282387};\\\", \\\"{x:870,y:515,t:1527628282404};\\\", \\\"{x:916,y:513,t:1527628282421};\\\", \\\"{x:963,y:509,t:1527628282439};\\\", \\\"{x:993,y:505,t:1527628282454};\\\", \\\"{x:1030,y:503,t:1527628282471};\\\", \\\"{x:1057,y:502,t:1527628282488};\\\", \\\"{x:1076,y:500,t:1527628282504};\\\", \\\"{x:1090,y:498,t:1527628282521};\\\", \\\"{x:1094,y:498,t:1527628282538};\\\", \\\"{x:1094,y:497,t:1527628282554};\\\", \\\"{x:1095,y:497,t:1527628282571};\\\", \\\"{x:1096,y:497,t:1527628282588};\\\", \\\"{x:1097,y:497,t:1527628282604};\\\", \\\"{x:1099,y:497,t:1527628282621};\\\", \\\"{x:1109,y:497,t:1527628282639};\\\", \\\"{x:1135,y:505,t:1527628282655};\\\", \\\"{x:1187,y:526,t:1527628282672};\\\", \\\"{x:1269,y:561,t:1527628282689};\\\", \\\"{x:1344,y:592,t:1527628282704};\\\", \\\"{x:1407,y:617,t:1527628282722};\\\", \\\"{x:1441,y:627,t:1527628282739};\\\", \\\"{x:1468,y:634,t:1527628282755};\\\", \\\"{x:1484,y:641,t:1527628282771};\\\", \\\"{x:1487,y:643,t:1527628282789};\\\", \\\"{x:1488,y:643,t:1527628282869};\\\", \\\"{x:1487,y:643,t:1527628282900};\\\", \\\"{x:1486,y:643,t:1527628282909};\\\", \\\"{x:1481,y:643,t:1527628282922};\\\", \\\"{x:1477,y:642,t:1527628282938};\\\", \\\"{x:1470,y:638,t:1527628282955};\\\", \\\"{x:1464,y:634,t:1527628282972};\\\", \\\"{x:1456,y:631,t:1527628282987};\\\", \\\"{x:1453,y:631,t:1527628283005};\\\", \\\"{x:1448,y:628,t:1527628283022};\\\", \\\"{x:1446,y:627,t:1527628283038};\\\", \\\"{x:1444,y:626,t:1527628283055};\\\", \\\"{x:1441,y:625,t:1527628283072};\\\", \\\"{x:1437,y:624,t:1527628283088};\\\", \\\"{x:1435,y:623,t:1527628283105};\\\", \\\"{x:1429,y:620,t:1527628283121};\\\", \\\"{x:1425,y:619,t:1527628283139};\\\", \\\"{x:1423,y:618,t:1527628283155};\\\", \\\"{x:1422,y:617,t:1527628283172};\\\", \\\"{x:1421,y:617,t:1527628283189};\\\", \\\"{x:1419,y:616,t:1527628283220};\\\", \\\"{x:1418,y:616,t:1527628283261};\\\", \\\"{x:1417,y:616,t:1527628283272};\\\", \\\"{x:1416,y:617,t:1527628283340};\\\", \\\"{x:1415,y:619,t:1527628283355};\\\", \\\"{x:1413,y:624,t:1527628283372};\\\", \\\"{x:1407,y:638,t:1527628283389};\\\", \\\"{x:1402,y:647,t:1527628283406};\\\", \\\"{x:1397,y:654,t:1527628283423};\\\", \\\"{x:1392,y:661,t:1527628283439};\\\", \\\"{x:1388,y:668,t:1527628283456};\\\", \\\"{x:1386,y:673,t:1527628283473};\\\", \\\"{x:1383,y:678,t:1527628283489};\\\", \\\"{x:1379,y:684,t:1527628283505};\\\", \\\"{x:1378,y:687,t:1527628283523};\\\", \\\"{x:1375,y:692,t:1527628283539};\\\", \\\"{x:1372,y:695,t:1527628283556};\\\", \\\"{x:1369,y:699,t:1527628283573};\\\", \\\"{x:1367,y:702,t:1527628283589};\\\", \\\"{x:1366,y:704,t:1527628283606};\\\", \\\"{x:1364,y:705,t:1527628283623};\\\", \\\"{x:1363,y:705,t:1527628283677};\\\", \\\"{x:1362,y:705,t:1527628283700};\\\", \\\"{x:1360,y:705,t:1527628283773};\\\", \\\"{x:1358,y:705,t:1527628283797};\\\", \\\"{x:1356,y:703,t:1527628283813};\\\", \\\"{x:1354,y:701,t:1527628283823};\\\", \\\"{x:1346,y:691,t:1527628283839};\\\", \\\"{x:1335,y:679,t:1527628283857};\\\", \\\"{x:1330,y:674,t:1527628283872};\\\", \\\"{x:1329,y:672,t:1527628283890};\\\", \\\"{x:1330,y:672,t:1527628284084};\\\", \\\"{x:1332,y:672,t:1527628284092};\\\", \\\"{x:1334,y:674,t:1527628284105};\\\", \\\"{x:1335,y:675,t:1527628284123};\\\", \\\"{x:1338,y:677,t:1527628284140};\\\", \\\"{x:1339,y:678,t:1527628284156};\\\", \\\"{x:1341,y:678,t:1527628284173};\\\", \\\"{x:1342,y:679,t:1527628284317};\\\", \\\"{x:1343,y:680,t:1527628284435};\\\", \\\"{x:1343,y:682,t:1527628284443};\\\", \\\"{x:1343,y:683,t:1527628284456};\\\", \\\"{x:1343,y:684,t:1527628284472};\\\", \\\"{x:1343,y:685,t:1527628284500};\\\", \\\"{x:1343,y:686,t:1527628284731};\\\", \\\"{x:1343,y:687,t:1527628284748};\\\", \\\"{x:1343,y:688,t:1527628284787};\\\", \\\"{x:1343,y:689,t:1527628284803};\\\", \\\"{x:1343,y:690,t:1527628284819};\\\", \\\"{x:1343,y:691,t:1527628284843};\\\", \\\"{x:1343,y:692,t:1527628284857};\\\", \\\"{x:1343,y:693,t:1527628284874};\\\", \\\"{x:1343,y:694,t:1527628284889};\\\", \\\"{x:1343,y:695,t:1527628284906};\\\", \\\"{x:1343,y:697,t:1527628284924};\\\", \\\"{x:1343,y:699,t:1527628284940};\\\", \\\"{x:1343,y:701,t:1527628284957};\\\", \\\"{x:1343,y:702,t:1527628284974};\\\", \\\"{x:1343,y:703,t:1527628284990};\\\", \\\"{x:1343,y:704,t:1527628285007};\\\", \\\"{x:1339,y:703,t:1527628287109};\\\", \\\"{x:1321,y:695,t:1527628287125};\\\", \\\"{x:1302,y:692,t:1527628287141};\\\", \\\"{x:1284,y:688,t:1527628287158};\\\", \\\"{x:1264,y:683,t:1527628287174};\\\", \\\"{x:1241,y:682,t:1527628287192};\\\", \\\"{x:1212,y:677,t:1527628287208};\\\", \\\"{x:1177,y:672,t:1527628287225};\\\", \\\"{x:1146,y:664,t:1527628287241};\\\", \\\"{x:1114,y:654,t:1527628287259};\\\", \\\"{x:1076,y:644,t:1527628287274};\\\", \\\"{x:1045,y:634,t:1527628287291};\\\", \\\"{x:1036,y:632,t:1527628287309};\\\", \\\"{x:1032,y:630,t:1527628287324};\\\", \\\"{x:1030,y:629,t:1527628287342};\\\", \\\"{x:1029,y:629,t:1527628287359};\\\", \\\"{x:1026,y:626,t:1527628287374};\\\", \\\"{x:1024,y:624,t:1527628287392};\\\", \\\"{x:1020,y:622,t:1527628287408};\\\", \\\"{x:1017,y:620,t:1527628287425};\\\", \\\"{x:1017,y:619,t:1527628287441};\\\", \\\"{x:1014,y:616,t:1527628287459};\\\", \\\"{x:1005,y:606,t:1527628287475};\\\", \\\"{x:1001,y:603,t:1527628287492};\\\", \\\"{x:982,y:586,t:1527628287508};\\\", \\\"{x:966,y:574,t:1527628287526};\\\", \\\"{x:944,y:559,t:1527628287542};\\\", \\\"{x:920,y:545,t:1527628287558};\\\", \\\"{x:892,y:527,t:1527628287576};\\\", \\\"{x:860,y:515,t:1527628287593};\\\", \\\"{x:839,y:508,t:1527628287608};\\\", \\\"{x:826,y:504,t:1527628287626};\\\", \\\"{x:813,y:500,t:1527628287642};\\\", \\\"{x:805,y:498,t:1527628287658};\\\", \\\"{x:799,y:496,t:1527628287676};\\\", \\\"{x:798,y:496,t:1527628287699};\\\", \\\"{x:801,y:496,t:1527628287788};\\\", \\\"{x:806,y:500,t:1527628287796};\\\", \\\"{x:811,y:504,t:1527628287809};\\\", \\\"{x:818,y:509,t:1527628287825};\\\", \\\"{x:822,y:512,t:1527628287842};\\\", \\\"{x:824,y:514,t:1527628287859};\\\", \\\"{x:826,y:515,t:1527628288110};\\\", \\\"{x:829,y:517,t:1527628288125};\\\", \\\"{x:831,y:518,t:1527628288142};\\\", \\\"{x:833,y:518,t:1527628288159};\\\", \\\"{x:833,y:521,t:1527628291238};\\\", \\\"{x:833,y:526,t:1527628291246};\\\", \\\"{x:832,y:535,t:1527628291265};\\\", \\\"{x:829,y:546,t:1527628291281};\\\", \\\"{x:815,y:569,t:1527628291313};\\\", \\\"{x:806,y:578,t:1527628291331};\\\", \\\"{x:792,y:585,t:1527628291346};\\\", \\\"{x:774,y:595,t:1527628291363};\\\", \\\"{x:752,y:608,t:1527628291381};\\\", \\\"{x:726,y:622,t:1527628291396};\\\", \\\"{x:689,y:644,t:1527628291414};\\\", \\\"{x:658,y:658,t:1527628291430};\\\", \\\"{x:632,y:670,t:1527628291446};\\\", \\\"{x:606,y:680,t:1527628291463};\\\", \\\"{x:588,y:689,t:1527628291480};\\\", \\\"{x:574,y:695,t:1527628291495};\\\", \\\"{x:567,y:700,t:1527628291513};\\\", \\\"{x:562,y:703,t:1527628291529};\\\", \\\"{x:561,y:705,t:1527628291546};\\\", \\\"{x:560,y:706,t:1527628291563};\\\", \\\"{x:559,y:708,t:1527628291579};\\\", \\\"{x:558,y:710,t:1527628291596};\\\", \\\"{x:557,y:713,t:1527628291613};\\\", \\\"{x:557,y:715,t:1527628291629};\\\", \\\"{x:557,y:716,t:1527628291646};\\\", \\\"{x:556,y:718,t:1527628291663};\\\", \\\"{x:556,y:719,t:1527628291680};\\\", \\\"{x:555,y:722,t:1527628291696};\\\", \\\"{x:555,y:723,t:1527628291713};\\\", \\\"{x:555,y:725,t:1527628291729};\\\", \\\"{x:555,y:726,t:1527628291746};\\\", \\\"{x:555,y:728,t:1527628291763};\\\", \\\"{x:555,y:730,t:1527628291779};\\\", \\\"{x:555,y:735,t:1527628291797};\\\", \\\"{x:555,y:740,t:1527628291812};\\\", \\\"{x:553,y:747,t:1527628291829};\\\", \\\"{x:552,y:751,t:1527628291847};\\\", \\\"{x:552,y:752,t:1527628291863};\\\", \\\"{x:552,y:751,t:1527628292374};\\\", \\\"{x:552,y:750,t:1527628292381};\\\", \\\"{x:552,y:748,t:1527628292397};\\\", \\\"{x:552,y:746,t:1527628292414};\\\", \\\"{x:552,y:744,t:1527628292430};\\\", \\\"{x:553,y:742,t:1527628292447};\\\", \\\"{x:553,y:741,t:1527628292464};\\\", \\\"{x:553,y:740,t:1527628292480};\\\", \\\"{x:554,y:740,t:1527628292497};\\\", \\\"{x:554,y:738,t:1527628292514};\\\", \\\"{x:554,y:737,t:1527628292550};\\\", \\\"{x:555,y:737,t:1527628292582};\\\", \\\"{x:555,y:734,t:1527628292837};\\\", \\\"{x:555,y:731,t:1527628292848};\\\", \\\"{x:555,y:723,t:1527628292865};\\\", \\\"{x:554,y:712,t:1527628292881};\\\", \\\"{x:553,y:704,t:1527628292897};\\\", \\\"{x:552,y:696,t:1527628292914};\\\", \\\"{x:551,y:690,t:1527628292931};\\\", \\\"{x:551,y:684,t:1527628292948};\\\", \\\"{x:550,y:679,t:1527628292964};\\\", \\\"{x:549,y:674,t:1527628292982};\\\", \\\"{x:549,y:672,t:1527628292997};\\\", \\\"{x:548,y:669,t:1527628293014};\\\", \\\"{x:548,y:668,t:1527628293038};\\\", \\\"{x:548,y:667,t:1527628293048};\\\", \\\"{x:548,y:666,t:1527628293069};\\\", \\\"{x:547,y:666,t:1527628293085};\\\", \\\"{x:547,y:665,t:1527628293181};\\\" ] }, { \\\"rt\\\": 26645, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 569154, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Shifts B and F start at 12pm\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10610, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 580770, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 12965, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 594757, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 1697, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 597541, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"F92ER\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"F92ER\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 189, dom: 642, initialDom: 721",
  "javascriptErrors": []
}