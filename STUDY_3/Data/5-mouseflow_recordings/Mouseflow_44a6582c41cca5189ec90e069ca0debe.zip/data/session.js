var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "44a6582c41cca5189ec90e069ca0debe",
  "created": "2018-05-15T14:09:29.8129298-07:00",
  "lastActivity": "2018-05-15T14:10:21.2019298-07:00",
  "pageViews": [
    {
      "id": "05153027b709d2119c89bd3a4f7dba8406927ab7",
      "startTime": "2018-05-15T14:09:29.8129298-07:00",
      "endTime": "2018-05-15T14:10:21.2019298-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 51389,
      "engagementTime": 27037,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 51389,
  "engagementTime": 27037,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8LGZ4",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "51031b459a7b4e713c6211e72e50fa1c",
  "gdpr": false
}