var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ab4ad839e557344b0b4ecf97313957a2",
  "created": "2018-05-15T14:08:29.4801363-07:00",
  "lastActivity": "2018-05-15T14:09:49.9261363-07:00",
  "pageViews": [
    {
      "id": "05153087cd6f6be752123352f647fa5a25f49375",
      "startTime": "2018-05-15T14:08:29.4801363-07:00",
      "endTime": "2018-05-15T14:09:49.9261363-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 80446,
      "engagementTime": 79997,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 80446,
  "engagementTime": 79997,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=B4LD9",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "74c943364e694de4c4ea715310a1bdfd",
  "gdpr": false
}