var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05214229489b1cddba8544d857f122e8a023c2fb"] = {
  "startTime": "2018-05-21T19:20:42.7105187Z",
  "websitePageUrl": "/16",
  "visitTime": 111991,
  "engagementTime": 102188,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "0ea22847d2ed93f72c38b28027337d0f",
    "created": "2018-05-21T19:20:42.693043+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=UX4QZ",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "098d9d912906d2b599641184b70764aa",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/0ea22847d2ed93f72c38b28027337d0f/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 200,
      "e": 200,
      "ty": 2,
      "x": 566,
      "y": 748
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 19216,
      "y": 40938,
      "ta": "html > body"
    },
    {
      "t": 300,
      "e": 300,
      "ty": 2,
      "x": 571,
      "y": 744
    },
    {
      "t": 556,
      "e": 556,
      "ty": 2,
      "x": 582,
      "y": 741
    },
    {
      "t": 557,
      "e": 557,
      "ty": 41,
      "x": 54508,
      "y": 40606,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 643,
      "e": 643,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 643,
      "e": 643,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 735,
      "e": 735,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 741,
      "e": 741,
      "ty": 2,
      "x": 583,
      "y": 741
    },
    {
      "t": 750,
      "e": 750,
      "ty": 41,
      "x": 54620,
      "y": 40606,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 547,
      "y": 696
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 50573,
      "y": 38113,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 550,
      "y": 670
    },
    {
      "t": 4146,
      "e": 4146,
      "ty": 6,
      "x": 561,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 558,
      "y": 546
    },
    {
      "t": 4229,
      "e": 4229,
      "ty": 7,
      "x": 539,
      "y": 492,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 48325,
      "y": 25815,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 513,
      "y": 460
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 489,
      "y": 488
    },
    {
      "t": 4446,
      "e": 4446,
      "ty": 6,
      "x": 487,
      "y": 528,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 2,
      "x": 490,
      "y": 550
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 41,
      "x": 44166,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4600,
      "e": 4600,
      "ty": 2,
      "x": 490,
      "y": 567
    },
    {
      "t": 4644,
      "e": 4644,
      "ty": 3,
      "x": 490,
      "y": 567,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4645,
      "e": 4645,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4732,
      "e": 4732,
      "ty": 4,
      "x": 44166,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4732,
      "e": 4732,
      "ty": 5,
      "x": 490,
      "y": 567,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 44166,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 491,
      "y": 568
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 496,
      "y": 567
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 45065,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 499,
      "y": 566
    },
    {
      "t": 6900,
      "e": 6900,
      "ty": 2,
      "x": 504,
      "y": 565
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 505,
      "y": 564
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 45852,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9786,
      "e": 9786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 9786,
      "e": 9786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9872,
      "e": 9872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10040,
      "e": 10040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10040,
      "e": 10040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10120,
      "e": 10120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lo"
    },
    {
      "t": 10208,
      "e": 10208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10209,
      "e": 10209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10336,
      "e": 10336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 10337,
      "e": 10337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10392,
      "e": 10392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look"
    },
    {
      "t": 10479,
      "e": 10479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10480,
      "e": 10480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10480,
      "e": 10480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10602,
      "e": 10602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look "
    },
    {
      "t": 10655,
      "e": 10655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11319,
      "e": 11319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 11320,
      "e": 11320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11449,
      "e": 11449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 11568,
      "e": 11568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 11570,
      "e": 11570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11703,
      "e": 11703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 11849,
      "e": 11849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11849,
      "e": 11849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11952,
      "e": 11952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11992,
      "e": 11992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 11992,
      "e": 11992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12081,
      "e": 12081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 12081,
      "e": 12081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12160,
      "e": 12160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 12215,
      "e": 12215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12216,
      "e": 12216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12248,
      "e": 12248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12288,
      "e": 12288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12352,
      "e": 12352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12352,
      "e": 12352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12400,
      "e": 12400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13216,
      "e": 13216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13312,
      "e": 13312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 "
    },
    {
      "t": 14137,
      "e": 14137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 14137,
      "e": 14137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14297,
      "e": 14297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 14297,
      "e": 14297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14336,
      "e": 14336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 14432,
      "e": 14432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14729,
      "e": 14729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14856,
      "e": 14856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 p"
    },
    {
      "t": 14871,
      "e": 14871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14872,
      "e": 14872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14960,
      "e": 14960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 15040,
      "e": 15040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15041,
      "e": 15041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15135,
      "e": 15135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15199,
      "e": 15199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15200,
      "e": 15200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15312,
      "e": 15312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15352,
      "e": 15352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15354,
      "e": 15354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15488,
      "e": 15488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 15649,
      "e": 15649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15650,
      "e": 15650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15720,
      "e": 15720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15776,
      "e": 15776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15776,
      "e": 15776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15913,
      "e": 15913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16097,
      "e": 16097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 16097,
      "e": 16097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16183,
      "e": 16183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 16232,
      "e": 16232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16232,
      "e": 16232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16345,
      "e": 16345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16441,
      "e": 16441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16442,
      "e": 16442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16544,
      "e": 16544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17232,
      "e": 17232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 17234,
      "e": 17234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17344,
      "e": 17344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 17729,
      "e": 17729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17730,
      "e": 17730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17823,
      "e": 17823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 17831,
      "e": 17831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17832,
      "e": 17832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17912,
      "e": 17912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 17937,
      "e": 17937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17937,
      "e": 17937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18056,
      "e": 18056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18096,
      "e": 18096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18097,
      "e": 18097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18204,
      "e": 18204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 pn the x axis a"
    },
    {
      "t": 18257,
      "e": 18257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 18352,
      "e": 18352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18354,
      "e": 18354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18496,
      "e": 18496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 18520,
      "e": 18520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 18520,
      "e": 18520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18576,
      "e": 18576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 18577,
      "e": 18577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18632,
      "e": 18632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fd"
    },
    {
      "t": 18655,
      "e": 18655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18808,
      "e": 18808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18808,
      "e": 18808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18904,
      "e": 18904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19080,
      "e": 19080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19183,
      "e": 19183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 pn the x axis anfd"
    },
    {
      "t": 19280,
      "e": 19280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19344,
      "e": 19344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 pn the x axis anf"
    },
    {
      "t": 19448,
      "e": 19448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19552,
      "e": 19552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 pn the x axis an"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20433,
      "e": 20433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20603,
      "e": 20603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 pn the x axis a"
    },
    {
      "t": 20933,
      "e": 20933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20965,
      "e": 20965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20998,
      "e": 20998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21031,
      "e": 21031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21064,
      "e": 21064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21096,
      "e": 21096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21129,
      "e": 21129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21162,
      "e": 21162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21195,
      "e": 21195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21229,
      "e": 21229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21231,
      "e": 21231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 pn th"
    },
    {
      "t": 21403,
      "e": 21403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 pn th"
    },
    {
      "t": 21416,
      "e": 21416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21504,
      "e": 21504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 pn t"
    },
    {
      "t": 21592,
      "e": 21592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21656,
      "e": 21656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 pn "
    },
    {
      "t": 21752,
      "e": 21752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21808,
      "e": 21808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 pn"
    },
    {
      "t": 21920,
      "e": 21920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21976,
      "e": 21976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 p"
    },
    {
      "t": 22281,
      "e": 22281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22360,
      "e": 22360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 "
    },
    {
      "t": 23265,
      "e": 23265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23265,
      "e": 23265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23335,
      "e": 23335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23335,
      "e": 23335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23424,
      "e": 23424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 23432,
      "e": 23432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23496,
      "e": 23496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23497,
      "e": 23497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23599,
      "e": 23599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23600,
      "e": 23600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23615,
      "e": 23615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 23704,
      "e": 23704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23728,
      "e": 23728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23729,
      "e": 23729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23815,
      "e": 23815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23816,
      "e": 23816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23847,
      "e": 23847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 23936,
      "e": 23936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23936,
      "e": 23936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23937,
      "e": 23937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24024,
      "e": 24024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24905,
      "e": 24905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 24905,
      "e": 24905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24984,
      "e": 24984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 25016,
      "e": 25016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25016,
      "e": 25016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25112,
      "e": 25112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25129,
      "e": 25129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25130,
      "e": 25130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25224,
      "e": 25224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25224,
      "e": 25224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25301,
      "e": 25301,
      "ty": 2,
      "x": 506,
      "y": 564
    },
    {
      "t": 25304,
      "e": 25304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||as"
    },
    {
      "t": 25376,
      "e": 25376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25501,
      "e": 25501,
      "ty": 41,
      "x": 45965,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25568,
      "e": 25568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25570,
      "e": 25570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25632,
      "e": 25632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 25759,
      "e": 25759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 25760,
      "e": 25760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25864,
      "e": 25864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25865,
      "e": 25865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25872,
      "e": 25872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z "
    },
    {
      "t": 25985,
      "e": 25985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25992,
      "e": 25992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25993,
      "e": 25993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26112,
      "e": 26112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26167,
      "e": 26167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26169,
      "e": 26169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26248,
      "e": 26248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 26328,
      "e": 26328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 26331,
      "e": 26331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26440,
      "e": 26440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26440,
      "e": 26440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26456,
      "e": 26456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 26553,
      "e": 26553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26616,
      "e": 26616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26617,
      "e": 26617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26728,
      "e": 26728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26736,
      "e": 26736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26737,
      "e": 26737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26808,
      "e": 26808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 26863,
      "e": 26863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26864,
      "e": 26864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26969,
      "e": 26969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26992,
      "e": 26992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26993,
      "e": 26993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27072,
      "e": 27072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 27167,
      "e": 27167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27168,
      "e": 27168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27280,
      "e": 27280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30000,
      "e": 30000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40727,
      "e": 32280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41226,
      "e": 32779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41258,
      "e": 32811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41291,
      "e": 32844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41324,
      "e": 32877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41357,
      "e": 32910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41390,
      "e": 32943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41423,
      "e": 32976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41456,
      "e": 33009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41489,
      "e": 33042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41501,
      "e": 33054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 on the x asiz"
    },
    {
      "t": 41702,
      "e": 33255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41797,
      "e": 33350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 on the x asi"
    },
    {
      "t": 41927,
      "e": 33480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41973,
      "e": 33526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 on the x as"
    },
    {
      "t": 42118,
      "e": 33671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42190,
      "e": 33743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 on the x a"
    },
    {
      "t": 43110,
      "e": 34663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 43111,
      "e": 34664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43213,
      "e": 34766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 43309,
      "e": 34862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43311,
      "e": 34864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43414,
      "e": 34967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 43518,
      "e": 35071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 43518,
      "e": 35071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43614,
      "e": 35167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43614,
      "e": 35167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43629,
      "e": 35182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 43766,
      "e": 35319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 43767,
      "e": 35320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43781,
      "e": 35334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 43918,
      "e": 35471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44030,
      "e": 35583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 44031,
      "e": 35584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44150,
      "e": 35703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 44159,
      "e": 35712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 44159,
      "e": 35712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44269,
      "e": 35822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44270,
      "e": 35823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44301,
      "e": 35854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 44415,
      "e": 35968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44670,
      "e": 36223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44671,
      "e": 36224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44789,
      "e": 36342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44806,
      "e": 36359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44806,
      "e": 36359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44918,
      "e": 36471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44918,
      "e": 36471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44926,
      "e": 36479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 45061,
      "e": 36614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45062,
      "e": 36615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 45063,
      "e": 36616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45125,
      "e": 36678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 45230,
      "e": 36783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45230,
      "e": 36783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45327,
      "e": 36880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46349,
      "e": 37902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 46349,
      "e": 37902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46453,
      "e": 38006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 46543,
      "e": 38096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 46543,
      "e": 38096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46637,
      "e": 38190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 46829,
      "e": 38382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 46829,
      "e": 38382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46893,
      "e": 38446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 46982,
      "e": 38535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 46982,
      "e": 38535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47054,
      "e": 38607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 47174,
      "e": 38727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 47175,
      "e": 38728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47285,
      "e": 38838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 47462,
      "e": 39015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 47463,
      "e": 39016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47565,
      "e": 39118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 47613,
      "e": 39166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47613,
      "e": 39166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47774,
      "e": 39327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49486,
      "e": 41039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 49487,
      "e": 41040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49598,
      "e": 41151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49598,
      "e": 41151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49709,
      "e": 41262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fr"
    },
    {
      "t": 49742,
      "e": 41295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49790,
      "e": 41343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49791,
      "e": 41344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49853,
      "e": 41406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 49853,
      "e": 41406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49909,
      "e": 41462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 49965,
      "e": 41518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49999,
      "e": 41552,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50045,
      "e": 41598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 50045,
      "e": 41598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50053,
      "e": 41606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50054,
      "e": 41607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50126,
      "e": 41679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50126,
      "e": 41679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50133,
      "e": 41686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m t"
    },
    {
      "t": 50133,
      "e": 41686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50237,
      "e": 41790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50350,
      "e": 41903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 50351,
      "e": 41904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50478,
      "e": 42031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 50478,
      "e": 42031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50501,
      "e": 42054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 50602,
      "e": 42155,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 on the x axis and then follow fromm tha"
    },
    {
      "t": 50605,
      "e": 42158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50606,
      "e": 42159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50646,
      "e": 42199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 50701,
      "e": 42254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50701,
      "e": 42254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50725,
      "e": 42278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50838,
      "e": 42391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51158,
      "e": 42711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 51159,
      "e": 42712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51342,
      "e": 42895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 51343,
      "e": 42896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51365,
      "e": 42918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 51469,
      "e": 43022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51606,
      "e": 43159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51606,
      "e": 43159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51709,
      "e": 43262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 51709,
      "e": 43262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51789,
      "e": 43342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 51870,
      "e": 43423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51910,
      "e": 43463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51910,
      "e": 43463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52029,
      "e": 43582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52030,
      "e": 43583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52037,
      "e": 43590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 52201,
      "e": 43754,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 on the x axis and then follow fromm that point "
    },
    {
      "t": 52206,
      "e": 43759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52469,
      "e": 44022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 52471,
      "e": 44024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52573,
      "e": 44126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 52694,
      "e": 44247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 52694,
      "e": 44247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52801,
      "e": 44354,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 on the x axis and then follow fromm that point up"
    },
    {
      "t": 52829,
      "e": 44382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 52910,
      "e": 44463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52911,
      "e": 44464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53046,
      "e": 44599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53047,
      "e": 44600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53061,
      "e": 44614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 53150,
      "e": 44703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53966,
      "e": 45519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54029,
      "e": 45582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 on the x axis and then follow fromm that point up "
    },
    {
      "t": 56319,
      "e": 47872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56321,
      "e": 47874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56437,
      "e": 47990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 56461,
      "e": 48014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 56461,
      "e": 48014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56589,
      "e": 48142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 56598,
      "e": 48151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 56599,
      "e": 48152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56709,
      "e": 48262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 56733,
      "e": 48286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56734,
      "e": 48287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56877,
      "e": 48430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57045,
      "e": 48598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 57047,
      "e": 48600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57157,
      "e": 48710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 57622,
      "e": 49175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57622,
      "e": 49175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57757,
      "e": 49310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58022,
      "e": 49575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 58023,
      "e": 49576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58125,
      "e": 49678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 58477,
      "e": 50030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 58479,
      "e": 50032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58589,
      "e": 50142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 58669,
      "e": 50222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 58670,
      "e": 50223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58758,
      "e": 50311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 58805,
      "e": 50358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 58807,
      "e": 50360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58901,
      "e": 50454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 59462,
      "e": 51015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59462,
      "e": 51015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59589,
      "e": 51142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59999,
      "e": 51552,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60662,
      "e": 52215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 60800,
      "e": 52353,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 on the x axis and then follow fromm that point up the y axis"
    },
    {
      "t": 60805,
      "e": 52358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 on the x axis and then follow fromm that point up the y axis"
    },
    {
      "t": 61847,
      "e": 53400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 61847,
      "e": 53400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61933,
      "e": 53486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 62798,
      "e": 54351,
      "ty": 2,
      "x": 493,
      "y": 548
    },
    {
      "t": 62898,
      "e": 54451,
      "ty": 2,
      "x": 483,
      "y": 541
    },
    {
      "t": 62998,
      "e": 54551,
      "ty": 2,
      "x": 443,
      "y": 546
    },
    {
      "t": 62998,
      "e": 54551,
      "ty": 41,
      "x": 38883,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63099,
      "e": 54652,
      "ty": 2,
      "x": 421,
      "y": 547
    },
    {
      "t": 63198,
      "e": 54751,
      "ty": 2,
      "x": 425,
      "y": 545
    },
    {
      "t": 63249,
      "e": 54802,
      "ty": 41,
      "x": 37871,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63299,
      "e": 54852,
      "ty": 2,
      "x": 435,
      "y": 539
    },
    {
      "t": 63499,
      "e": 55052,
      "ty": 41,
      "x": 37984,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63538,
      "e": 55091,
      "ty": 3,
      "x": 435,
      "y": 539,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63657,
      "e": 55210,
      "ty": 4,
      "x": 37984,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63657,
      "e": 55210,
      "ty": 5,
      "x": 435,
      "y": 539,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64246,
      "e": 55799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64317,
      "e": 55870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 on the x axis and then follow from that point up the y axis."
    },
    {
      "t": 64493,
      "e": 56046,
      "ty": 7,
      "x": 436,
      "y": 617,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64498,
      "e": 56051,
      "ty": 2,
      "x": 436,
      "y": 617
    },
    {
      "t": 64499,
      "e": 56052,
      "ty": 41,
      "x": 38096,
      "y": 63387,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 64576,
      "e": 56129,
      "ty": 6,
      "x": 431,
      "y": 657,
      "ta": "#strategyButton"
    },
    {
      "t": 64599,
      "e": 56152,
      "ty": 2,
      "x": 430,
      "y": 660
    },
    {
      "t": 64698,
      "e": 56251,
      "ty": 2,
      "x": 407,
      "y": 683
    },
    {
      "t": 64748,
      "e": 56301,
      "ty": 41,
      "x": 35719,
      "y": 56409,
      "ta": "#strategyButton"
    },
    {
      "t": 64799,
      "e": 56352,
      "ty": 2,
      "x": 402,
      "y": 685
    },
    {
      "t": 64899,
      "e": 56452,
      "ty": 2,
      "x": 400,
      "y": 685
    },
    {
      "t": 64947,
      "e": 56500,
      "ty": 3,
      "x": 400,
      "y": 685,
      "ta": "#strategyButton"
    },
    {
      "t": 64948,
      "e": 56501,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look up 12 on the x axis and then follow from that point up the y axis."
    },
    {
      "t": 64949,
      "e": 56502,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64951,
      "e": 56504,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 64999,
      "e": 56552,
      "ty": 41,
      "x": 33535,
      "y": 58336,
      "ta": "#strategyButton"
    },
    {
      "t": 65040,
      "e": 56593,
      "ty": 4,
      "x": 33535,
      "y": 58336,
      "ta": "#strategyButton"
    },
    {
      "t": 65052,
      "e": 56605,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 65053,
      "e": 56606,
      "ty": 5,
      "x": 400,
      "y": 685,
      "ta": "#strategyButton"
    },
    {
      "t": 65058,
      "e": 56611,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 65199,
      "e": 56752,
      "ty": 2,
      "x": 408,
      "y": 675
    },
    {
      "t": 65248,
      "e": 56801,
      "ty": 41,
      "x": 13775,
      "y": 36839,
      "ta": "html > body"
    },
    {
      "t": 65299,
      "e": 56852,
      "ty": 2,
      "x": 408,
      "y": 672
    },
    {
      "t": 65499,
      "e": 57052,
      "ty": 41,
      "x": 13775,
      "y": 36783,
      "ta": "html > body"
    },
    {
      "t": 65599,
      "e": 57152,
      "ty": 2,
      "x": 411,
      "y": 670
    },
    {
      "t": 65698,
      "e": 57251,
      "ty": 2,
      "x": 415,
      "y": 668
    },
    {
      "t": 65748,
      "e": 57301,
      "ty": 41,
      "x": 14016,
      "y": 36562,
      "ta": "html > body"
    },
    {
      "t": 66061,
      "e": 57614,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 66748,
      "e": 58301,
      "ty": 41,
      "x": 20111,
      "y": 37060,
      "ta": "html > body"
    },
    {
      "t": 66799,
      "e": 58352,
      "ty": 2,
      "x": 801,
      "y": 684
    },
    {
      "t": 66828,
      "e": 58381,
      "ty": 6,
      "x": 918,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66898,
      "e": 58451,
      "ty": 2,
      "x": 969,
      "y": 689
    },
    {
      "t": 66927,
      "e": 58480,
      "ty": 7,
      "x": 977,
      "y": 671,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66945,
      "e": 58498,
      "ty": 6,
      "x": 980,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66978,
      "e": 58531,
      "ty": 7,
      "x": 990,
      "y": 640,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66999,
      "e": 58552,
      "ty": 2,
      "x": 992,
      "y": 625
    },
    {
      "t": 67000,
      "e": 58553,
      "ty": 41,
      "x": 39796,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 67094,
      "e": 58647,
      "ty": 6,
      "x": 982,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67100,
      "e": 58653,
      "ty": 2,
      "x": 982,
      "y": 574
    },
    {
      "t": 67199,
      "e": 58752,
      "ty": 2,
      "x": 982,
      "y": 573
    },
    {
      "t": 67248,
      "e": 58801,
      "ty": 41,
      "x": 37417,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67299,
      "e": 58852,
      "ty": 2,
      "x": 979,
      "y": 573
    },
    {
      "t": 67354,
      "e": 58907,
      "ty": 3,
      "x": 979,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67355,
      "e": 58908,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67482,
      "e": 59035,
      "ty": 4,
      "x": 36985,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67482,
      "e": 59035,
      "ty": 5,
      "x": 979,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67499,
      "e": 59052,
      "ty": 41,
      "x": 36985,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68302,
      "e": 59855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 68302,
      "e": 59855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68374,
      "e": 59927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "51"
    },
    {
      "t": 68375,
      "e": 59928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68444,
      "e": 59997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 68517,
      "e": 60070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 68562,
      "e": 60115,
      "ty": 7,
      "x": 965,
      "y": 581,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 68599,
      "e": 60152,
      "ty": 2,
      "x": 959,
      "y": 589
    },
    {
      "t": 68699,
      "e": 60252,
      "ty": 2,
      "x": 948,
      "y": 601
    },
    {
      "t": 68749,
      "e": 60302,
      "ty": 41,
      "x": 29415,
      "y": 23405,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 68799,
      "e": 60352,
      "ty": 2,
      "x": 929,
      "y": 625
    },
    {
      "t": 68898,
      "e": 60451,
      "ty": 2,
      "x": 909,
      "y": 643
    },
    {
      "t": 68999,
      "e": 60552,
      "ty": 2,
      "x": 908,
      "y": 646
    },
    {
      "t": 68999,
      "e": 60552,
      "ty": 41,
      "x": 21628,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 69131,
      "e": 60684,
      "ty": 6,
      "x": 907,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69199,
      "e": 60752,
      "ty": 2,
      "x": 898,
      "y": 654
    },
    {
      "t": 69249,
      "e": 60802,
      "ty": 41,
      "x": 19465,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69298,
      "e": 60851,
      "ty": 2,
      "x": 897,
      "y": 654
    },
    {
      "t": 69400,
      "e": 60852,
      "ty": 2,
      "x": 896,
      "y": 655
    },
    {
      "t": 69434,
      "e": 60886,
      "ty": 3,
      "x": 895,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69435,
      "e": 60887,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 69436,
      "e": 60888,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69436,
      "e": 60888,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69499,
      "e": 60951,
      "ty": 2,
      "x": 895,
      "y": 656
    },
    {
      "t": 69499,
      "e": 60951,
      "ty": 41,
      "x": 18816,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69560,
      "e": 61012,
      "ty": 4,
      "x": 18816,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69561,
      "e": 61013,
      "ty": 5,
      "x": 895,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70836,
      "e": 62288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 70837,
      "e": 62289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70869,
      "e": 62321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 70869,
      "e": 62321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70989,
      "e": 62441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "ca"
    },
    {
      "t": 71037,
      "e": 62489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "ca"
    },
    {
      "t": 71389,
      "e": 62841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 71461,
      "e": 62913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "c"
    },
    {
      "t": 71573,
      "e": 63025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 71621,
      "e": 63073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 71717,
      "e": 63169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 71781,
      "e": 63233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 72894,
      "e": 64346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 72894,
      "e": 64346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73000,
      "e": 64452,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 73021,
      "e": 64473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 73021,
      "e": 64473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73069,
      "e": 64521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "un"
    },
    {
      "t": 73189,
      "e": 64641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 73190,
      "e": 64642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73301,
      "e": 64753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "uni"
    },
    {
      "t": 73373,
      "e": 64825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "uni"
    },
    {
      "t": 73437,
      "e": 64889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 73438,
      "e": 64890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73533,
      "e": 64985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 73533,
      "e": 64985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73556,
      "e": 65008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "unite"
    },
    {
      "t": 73694,
      "e": 65146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 73694,
      "e": 65146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73773,
      "e": 65225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 73829,
      "e": 65281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 73829,
      "e": 65281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73852,
      "e": 65304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 73996,
      "e": 65448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 74036,
      "e": 65488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 74037,
      "e": 65489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74200,
      "e": 65652,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "united s"
    },
    {
      "t": 74245,
      "e": 65697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 74445,
      "e": 65897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 74446,
      "e": 65898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74548,
      "e": 66000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 74548,
      "e": 66000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74653,
      "e": 66105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ta"
    },
    {
      "t": 74781,
      "e": 66233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 74789,
      "e": 66241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 74790,
      "e": 66242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74997,
      "e": 66449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 74998,
      "e": 66450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75029,
      "e": 66481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||te"
    },
    {
      "t": 75165,
      "e": 66617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 75285,
      "e": 66737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 75286,
      "e": 66738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75400,
      "e": 66852,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "united states"
    },
    {
      "t": 75436,
      "e": 66888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 76651,
      "e": 68103,
      "ty": 7,
      "x": 933,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76686,
      "e": 68138,
      "ty": 6,
      "x": 942,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76699,
      "e": 68151,
      "ty": 2,
      "x": 942,
      "y": 684
    },
    {
      "t": 76749,
      "e": 68201,
      "ty": 41,
      "x": 25294,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76799,
      "e": 68251,
      "ty": 2,
      "x": 945,
      "y": 689
    },
    {
      "t": 76906,
      "e": 68358,
      "ty": 3,
      "x": 945,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76906,
      "e": 68358,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "united states"
    },
    {
      "t": 76906,
      "e": 68358,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76907,
      "e": 68359,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77000,
      "e": 68452,
      "ty": 4,
      "x": 25294,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77001,
      "e": 68453,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77002,
      "e": 68454,
      "ty": 5,
      "x": 945,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77002,
      "e": 68454,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 78016,
      "e": 69468,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 78899,
      "e": 70351,
      "ty": 2,
      "x": 941,
      "y": 635
    },
    {
      "t": 78999,
      "e": 70451,
      "ty": 2,
      "x": 825,
      "y": 157
    },
    {
      "t": 78999,
      "e": 70451,
      "ty": 41,
      "x": 28135,
      "y": 8254,
      "ta": "html > body"
    },
    {
      "t": 79099,
      "e": 70551,
      "ty": 2,
      "x": 799,
      "y": 113
    },
    {
      "t": 79250,
      "e": 70702,
      "ty": 41,
      "x": 27171,
      "y": 5816,
      "ta": "html > body"
    },
    {
      "t": 79299,
      "e": 70751,
      "ty": 2,
      "x": 808,
      "y": 191
    },
    {
      "t": 79399,
      "e": 70851,
      "ty": 2,
      "x": 810,
      "y": 206
    },
    {
      "t": 79499,
      "e": 70951,
      "ty": 41,
      "x": 27619,
      "y": 10968,
      "ta": "html > body"
    },
    {
      "t": 79599,
      "e": 71051,
      "ty": 2,
      "x": 833,
      "y": 221
    },
    {
      "t": 79700,
      "e": 71152,
      "ty": 2,
      "x": 842,
      "y": 225
    },
    {
      "t": 79749,
      "e": 71201,
      "ty": 41,
      "x": 16850,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 79799,
      "e": 71251,
      "ty": 2,
      "x": 841,
      "y": 233
    },
    {
      "t": 79821,
      "e": 71273,
      "ty": 6,
      "x": 839,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 79899,
      "e": 71351,
      "ty": 2,
      "x": 834,
      "y": 242
    },
    {
      "t": 79999,
      "e": 71451,
      "ty": 2,
      "x": 832,
      "y": 243
    },
    {
      "t": 80000,
      "e": 71452,
      "ty": 41,
      "x": 28120,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 80000,
      "e": 71452,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80049,
      "e": 71501,
      "ty": 3,
      "x": 832,
      "y": 243,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 80049,
      "e": 71501,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 80185,
      "e": 71637,
      "ty": 4,
      "x": 28120,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 80185,
      "e": 71637,
      "ty": 5,
      "x": 832,
      "y": 243,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 80186,
      "e": 71638,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 80297,
      "e": 71749,
      "ty": 7,
      "x": 832,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 80300,
      "e": 71752,
      "ty": 2,
      "x": 832,
      "y": 245
    },
    {
      "t": 80399,
      "e": 71851,
      "ty": 2,
      "x": 914,
      "y": 348
    },
    {
      "t": 80500,
      "e": 71952,
      "ty": 2,
      "x": 956,
      "y": 450
    },
    {
      "t": 80500,
      "e": 71952,
      "ty": 41,
      "x": 31938,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 80599,
      "e": 72051,
      "ty": 2,
      "x": 945,
      "y": 474
    },
    {
      "t": 80699,
      "e": 72151,
      "ty": 2,
      "x": 943,
      "y": 474
    },
    {
      "t": 80750,
      "e": 72202,
      "ty": 41,
      "x": 28853,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 81100,
      "e": 72552,
      "ty": 2,
      "x": 939,
      "y": 474
    },
    {
      "t": 81248,
      "e": 72700,
      "ty": 41,
      "x": 27904,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 81500,
      "e": 72952,
      "ty": 2,
      "x": 926,
      "y": 477
    },
    {
      "t": 81500,
      "e": 72952,
      "ty": 41,
      "x": 24818,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 81600,
      "e": 73052,
      "ty": 2,
      "x": 877,
      "y": 542
    },
    {
      "t": 81700,
      "e": 73152,
      "ty": 2,
      "x": 873,
      "y": 550
    },
    {
      "t": 81750,
      "e": 73202,
      "ty": 41,
      "x": 32463,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 81799,
      "e": 73251,
      "ty": 2,
      "x": 864,
      "y": 551
    },
    {
      "t": 81899,
      "e": 73351,
      "ty": 2,
      "x": 849,
      "y": 543
    },
    {
      "t": 81998,
      "e": 73450,
      "ty": 2,
      "x": 839,
      "y": 538
    },
    {
      "t": 81999,
      "e": 73451,
      "ty": 41,
      "x": 4171,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 82040,
      "e": 73492,
      "ty": 6,
      "x": 831,
      "y": 532,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 82099,
      "e": 73551,
      "ty": 2,
      "x": 831,
      "y": 532
    },
    {
      "t": 82198,
      "e": 73650,
      "ty": 2,
      "x": 831,
      "y": 531
    },
    {
      "t": 82250,
      "e": 73702,
      "ty": 41,
      "x": 28120,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 82298,
      "e": 73750,
      "ty": 2,
      "x": 832,
      "y": 529
    },
    {
      "t": 82418,
      "e": 73870,
      "ty": 3,
      "x": 832,
      "y": 529,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 82418,
      "e": 73870,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 82420,
      "e": 73872,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 82537,
      "e": 73989,
      "ty": 4,
      "x": 28120,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 82537,
      "e": 73989,
      "ty": 5,
      "x": 832,
      "y": 529,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 82537,
      "e": 73989,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf",
      "v": "Fifth"
    },
    {
      "t": 82698,
      "e": 74150,
      "ty": 2,
      "x": 839,
      "y": 528
    },
    {
      "t": 82708,
      "e": 74160,
      "ty": 7,
      "x": 849,
      "y": 533,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 82748,
      "e": 74200,
      "ty": 41,
      "x": 59756,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 82799,
      "e": 74251,
      "ty": 2,
      "x": 1008,
      "y": 551
    },
    {
      "t": 82899,
      "e": 74351,
      "ty": 2,
      "x": 1140,
      "y": 567
    },
    {
      "t": 82999,
      "e": 74451,
      "ty": 41,
      "x": 38983,
      "y": 30967,
      "ta": "html > body"
    },
    {
      "t": 83199,
      "e": 74651,
      "ty": 2,
      "x": 1147,
      "y": 566
    },
    {
      "t": 83248,
      "e": 74700,
      "ty": 41,
      "x": 39224,
      "y": 30911,
      "ta": "html > body"
    },
    {
      "t": 83398,
      "e": 74850,
      "ty": 1,
      "x": 0,
      "y": 2
    },
    {
      "t": 83498,
      "e": 74950,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 83598,
      "e": 75050,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 83699,
      "e": 75151,
      "ty": 2,
      "x": 1141,
      "y": 618
    },
    {
      "t": 83749,
      "e": 75201,
      "ty": 41,
      "x": 38501,
      "y": 35786,
      "ta": "html > body"
    },
    {
      "t": 83798,
      "e": 75250,
      "ty": 2,
      "x": 1079,
      "y": 699
    },
    {
      "t": 83898,
      "e": 75350,
      "ty": 2,
      "x": 1023,
      "y": 728
    },
    {
      "t": 83999,
      "e": 75451,
      "ty": 2,
      "x": 1023,
      "y": 706
    },
    {
      "t": 83999,
      "e": 75451,
      "ty": 41,
      "x": 50794,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 84098,
      "e": 75550,
      "ty": 2,
      "x": 991,
      "y": 698
    },
    {
      "t": 84198,
      "e": 75650,
      "ty": 2,
      "x": 926,
      "y": 704
    },
    {
      "t": 84249,
      "e": 75701,
      "ty": 41,
      "x": 20309,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 84298,
      "e": 75750,
      "ty": 2,
      "x": 892,
      "y": 723
    },
    {
      "t": 84398,
      "e": 75850,
      "ty": 2,
      "x": 877,
      "y": 741
    },
    {
      "t": 84498,
      "e": 75950,
      "ty": 2,
      "x": 860,
      "y": 772
    },
    {
      "t": 84499,
      "e": 75951,
      "ty": 41,
      "x": 9155,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 84598,
      "e": 76050,
      "ty": 2,
      "x": 854,
      "y": 794
    },
    {
      "t": 84699,
      "e": 76151,
      "ty": 2,
      "x": 850,
      "y": 807
    },
    {
      "t": 84748,
      "e": 76200,
      "ty": 41,
      "x": 16867,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 84798,
      "e": 76250,
      "ty": 2,
      "x": 850,
      "y": 812
    },
    {
      "t": 84898,
      "e": 76350,
      "ty": 2,
      "x": 848,
      "y": 814
    },
    {
      "t": 84999,
      "e": 76451,
      "ty": 41,
      "x": 15687,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 85098,
      "e": 76550,
      "ty": 2,
      "x": 843,
      "y": 815
    },
    {
      "t": 85249,
      "e": 76701,
      "ty": 41,
      "x": 12736,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 85478,
      "e": 76702,
      "ty": 6,
      "x": 836,
      "y": 791,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 85492,
      "e": 76716,
      "ty": 7,
      "x": 833,
      "y": 779,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 85498,
      "e": 76722,
      "ty": 2,
      "x": 833,
      "y": 779
    },
    {
      "t": 85498,
      "e": 76722,
      "ty": 41,
      "x": 6481,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 85526,
      "e": 76750,
      "ty": 6,
      "x": 828,
      "y": 763,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 85559,
      "e": 76783,
      "ty": 7,
      "x": 825,
      "y": 750,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 85598,
      "e": 76822,
      "ty": 2,
      "x": 822,
      "y": 736
    },
    {
      "t": 85698,
      "e": 76922,
      "ty": 2,
      "x": 794,
      "y": 678
    },
    {
      "t": 85749,
      "e": 76973,
      "ty": 41,
      "x": 27068,
      "y": 37116,
      "ta": "html > body"
    },
    {
      "t": 85899,
      "e": 77123,
      "ty": 2,
      "x": 816,
      "y": 696
    },
    {
      "t": 85985,
      "e": 77209,
      "ty": 6,
      "x": 826,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 85998,
      "e": 77222,
      "ty": 2,
      "x": 826,
      "y": 703
    },
    {
      "t": 85998,
      "e": 77222,
      "ty": 41,
      "x": 0,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 86098,
      "e": 77322,
      "ty": 2,
      "x": 828,
      "y": 703
    },
    {
      "t": 86249,
      "e": 77473,
      "ty": 41,
      "x": 7955,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 86250,
      "e": 77474,
      "ty": 3,
      "x": 828,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 86250,
      "e": 77474,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 86251,
      "e": 77475,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 86368,
      "e": 77592,
      "ty": 4,
      "x": 7955,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 86368,
      "e": 77592,
      "ty": 5,
      "x": 828,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 86370,
      "e": 77594,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 86529,
      "e": 77753,
      "ty": 7,
      "x": 840,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 86598,
      "e": 77822,
      "ty": 2,
      "x": 1114,
      "y": 779
    },
    {
      "t": 86699,
      "e": 77923,
      "ty": 2,
      "x": 1308,
      "y": 845
    },
    {
      "t": 86749,
      "e": 77973,
      "ty": 41,
      "x": 45354,
      "y": 47198,
      "ta": "html > body"
    },
    {
      "t": 86798,
      "e": 78022,
      "ty": 2,
      "x": 1301,
      "y": 881
    },
    {
      "t": 86898,
      "e": 78122,
      "ty": 2,
      "x": 1259,
      "y": 909
    },
    {
      "t": 86999,
      "e": 78223,
      "ty": 2,
      "x": 1183,
      "y": 972
    },
    {
      "t": 86999,
      "e": 78223,
      "ty": 41,
      "x": 40464,
      "y": 53402,
      "ta": "html > body"
    },
    {
      "t": 87099,
      "e": 78323,
      "ty": 2,
      "x": 1171,
      "y": 977
    },
    {
      "t": 87249,
      "e": 78473,
      "ty": 41,
      "x": 40051,
      "y": 53679,
      "ta": "html > body"
    },
    {
      "t": 87499,
      "e": 78723,
      "ty": 2,
      "x": 1168,
      "y": 978
    },
    {
      "t": 87499,
      "e": 78723,
      "ty": 41,
      "x": 39947,
      "y": 53735,
      "ta": "html > body"
    },
    {
      "t": 87699,
      "e": 78923,
      "ty": 2,
      "x": 1166,
      "y": 979
    },
    {
      "t": 87749,
      "e": 78973,
      "ty": 41,
      "x": 39878,
      "y": 53790,
      "ta": "html > body"
    },
    {
      "t": 88248,
      "e": 79472,
      "ty": 41,
      "x": 39362,
      "y": 53901,
      "ta": "html > body"
    },
    {
      "t": 88298,
      "e": 79522,
      "ty": 2,
      "x": 1131,
      "y": 986
    },
    {
      "t": 88399,
      "e": 79623,
      "ty": 2,
      "x": 1088,
      "y": 998
    },
    {
      "t": 88498,
      "e": 79722,
      "ty": 2,
      "x": 989,
      "y": 1002
    },
    {
      "t": 88498,
      "e": 79722,
      "ty": 41,
      "x": 39770,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 88599,
      "e": 79823,
      "ty": 2,
      "x": 931,
      "y": 938
    },
    {
      "t": 88698,
      "e": 79922,
      "ty": 2,
      "x": 896,
      "y": 907
    },
    {
      "t": 88749,
      "e": 79973,
      "ty": 41,
      "x": 16037,
      "y": 15123,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 88798,
      "e": 80022,
      "ty": 2,
      "x": 882,
      "y": 914
    },
    {
      "t": 88899,
      "e": 80123,
      "ty": 2,
      "x": 873,
      "y": 923
    },
    {
      "t": 88998,
      "e": 80222,
      "ty": 2,
      "x": 869,
      "y": 928
    },
    {
      "t": 88999,
      "e": 80223,
      "ty": 41,
      "x": 51967,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 89098,
      "e": 80322,
      "ty": 2,
      "x": 859,
      "y": 935
    },
    {
      "t": 89199,
      "e": 80423,
      "ty": 2,
      "x": 852,
      "y": 938
    },
    {
      "t": 89249,
      "e": 80473,
      "ty": 41,
      "x": 33398,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 89299,
      "e": 80523,
      "ty": 2,
      "x": 851,
      "y": 938
    },
    {
      "t": 89398,
      "e": 80622,
      "ty": 2,
      "x": 850,
      "y": 938
    },
    {
      "t": 89499,
      "e": 80723,
      "ty": 2,
      "x": 841,
      "y": 938
    },
    {
      "t": 89499,
      "e": 80723,
      "ty": 41,
      "x": 21384,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 89509,
      "e": 80733,
      "ty": 6,
      "x": 839,
      "y": 938,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 89598,
      "e": 80822,
      "ty": 2,
      "x": 834,
      "y": 938
    },
    {
      "t": 89748,
      "e": 80972,
      "ty": 41,
      "x": 38202,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 89841,
      "e": 81065,
      "ty": 3,
      "x": 833,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 89842,
      "e": 81066,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 89843,
      "e": 81067,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 89898,
      "e": 81122,
      "ty": 2,
      "x": 833,
      "y": 939
    },
    {
      "t": 89969,
      "e": 81193,
      "ty": 4,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 89970,
      "e": 81194,
      "ty": 5,
      "x": 833,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 89970,
      "e": 81194,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 89998,
      "e": 81194,
      "ty": 41,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 90098,
      "e": 81294,
      "ty": 2,
      "x": 832,
      "y": 939
    },
    {
      "t": 90249,
      "e": 81445,
      "ty": 41,
      "x": 28120,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 93274,
      "e": 84470,
      "ty": 7,
      "x": 853,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 93299,
      "e": 84495,
      "ty": 2,
      "x": 1052,
      "y": 939
    },
    {
      "t": 93398,
      "e": 84594,
      "ty": 2,
      "x": 1919,
      "y": 1074
    },
    {
      "t": 93499,
      "e": 84695,
      "ty": 2,
      "x": 1852,
      "y": 1087
    },
    {
      "t": 93499,
      "e": 84695,
      "ty": 41,
      "x": 63503,
      "y": 59773,
      "ta": "html > body"
    },
    {
      "t": 93599,
      "e": 84795,
      "ty": 2,
      "x": 1750,
      "y": 1142
    },
    {
      "t": 93699,
      "e": 84895,
      "ty": 2,
      "x": 1716,
      "y": 1154
    },
    {
      "t": 93749,
      "e": 84945,
      "ty": 41,
      "x": 56305,
      "y": 63319,
      "ta": "html > body"
    },
    {
      "t": 93798,
      "e": 84994,
      "ty": 2,
      "x": 1374,
      "y": 1149
    },
    {
      "t": 93899,
      "e": 85095,
      "ty": 2,
      "x": 993,
      "y": 1121
    },
    {
      "t": 93999,
      "e": 85195,
      "ty": 2,
      "x": 967,
      "y": 1119
    },
    {
      "t": 93999,
      "e": 85195,
      "ty": 41,
      "x": 33025,
      "y": 61546,
      "ta": "html > body"
    },
    {
      "t": 94099,
      "e": 85295,
      "ty": 2,
      "x": 936,
      "y": 1048
    },
    {
      "t": 94101,
      "e": 85297,
      "ty": 6,
      "x": 928,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94198,
      "e": 85394,
      "ty": 2,
      "x": 914,
      "y": 1019
    },
    {
      "t": 94249,
      "e": 85445,
      "ty": 41,
      "x": 35344,
      "y": 23830,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94299,
      "e": 85495,
      "ty": 2,
      "x": 887,
      "y": 1013
    },
    {
      "t": 94378,
      "e": 85574,
      "ty": 3,
      "x": 887,
      "y": 1013,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94380,
      "e": 85576,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 94381,
      "e": 85577,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94480,
      "e": 85676,
      "ty": 4,
      "x": 29675,
      "y": 15887,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94481,
      "e": 85677,
      "ty": 5,
      "x": 887,
      "y": 1013,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94483,
      "e": 85679,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 94484,
      "e": 85680,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 94485,
      "e": 85681,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 94499,
      "e": 85695,
      "ty": 41,
      "x": 30270,
      "y": 55674,
      "ta": "html > body"
    },
    {
      "t": 94898,
      "e": 86094,
      "ty": 2,
      "x": 889,
      "y": 1013
    },
    {
      "t": 94999,
      "e": 86195,
      "ty": 2,
      "x": 910,
      "y": 1019
    },
    {
      "t": 94999,
      "e": 86195,
      "ty": 41,
      "x": 31062,
      "y": 56006,
      "ta": "html > body"
    },
    {
      "t": 95099,
      "e": 86295,
      "ty": 2,
      "x": 937,
      "y": 1025
    },
    {
      "t": 95199,
      "e": 86395,
      "ty": 2,
      "x": 938,
      "y": 1026
    },
    {
      "t": 95249,
      "e": 86445,
      "ty": 41,
      "x": 32027,
      "y": 56394,
      "ta": "html > body"
    },
    {
      "t": 95824,
      "e": 87020,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 99999,
      "e": 91195,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100998,
      "e": 91445,
      "ty": 2,
      "x": 857,
      "y": 923
    },
    {
      "t": 100999,
      "e": 91446,
      "ty": 41,
      "x": 27724,
      "y": 55169,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 101097,
      "e": 91544,
      "ty": 2,
      "x": 816,
      "y": 853
    },
    {
      "t": 101197,
      "e": 91644,
      "ty": 2,
      "x": 807,
      "y": 821
    },
    {
      "t": 101248,
      "e": 91695,
      "ty": 41,
      "x": 25363,
      "y": 6454,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 101297,
      "e": 91744,
      "ty": 2,
      "x": 827,
      "y": 787
    },
    {
      "t": 101397,
      "e": 91844,
      "ty": 2,
      "x": 837,
      "y": 780
    },
    {
      "t": 101498,
      "e": 91945,
      "ty": 41,
      "x": 26740,
      "y": 65251,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 106748,
      "e": 96945,
      "ty": 41,
      "x": 28069,
      "y": 52279,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 106798,
      "e": 96995,
      "ty": 2,
      "x": 970,
      "y": 840
    },
    {
      "t": 106898,
      "e": 97095,
      "ty": 2,
      "x": 982,
      "y": 859
    },
    {
      "t": 106998,
      "e": 97195,
      "ty": 2,
      "x": 982,
      "y": 869
    },
    {
      "t": 106999,
      "e": 97196,
      "ty": 41,
      "x": 33874,
      "y": 61889,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 107098,
      "e": 97295,
      "ty": 2,
      "x": 977,
      "y": 916
    },
    {
      "t": 107198,
      "e": 97395,
      "ty": 2,
      "x": 982,
      "y": 960
    },
    {
      "t": 107248,
      "e": 97445,
      "ty": 41,
      "x": 33874,
      "y": 59393,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 107298,
      "e": 97495,
      "ty": 2,
      "x": 982,
      "y": 1000
    },
    {
      "t": 107398,
      "e": 97595,
      "ty": 2,
      "x": 976,
      "y": 1052
    },
    {
      "t": 107498,
      "e": 97695,
      "ty": 2,
      "x": 975,
      "y": 1066
    },
    {
      "t": 107498,
      "e": 97695,
      "ty": 41,
      "x": 33530,
      "y": 65071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 107508,
      "e": 97705,
      "ty": 6,
      "x": 975,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 107598,
      "e": 97795,
      "ty": 2,
      "x": 975,
      "y": 1089
    },
    {
      "t": 107748,
      "e": 97945,
      "ty": 41,
      "x": 35771,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 109561,
      "e": 99758,
      "ty": 3,
      "x": 975,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 109561,
      "e": 99758,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 109719,
      "e": 99916,
      "ty": 4,
      "x": 35771,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 109720,
      "e": 99917,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 109720,
      "e": 99917,
      "ty": 5,
      "x": 975,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 109721,
      "e": 99918,
      "ty": 38,
      "x": 10,
      "y": 0
    },
    {
      "t": 109998,
      "e": 100195,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110757,
      "e": 100954,
      "ty": 38,
      "x": 11,
      "y": 0
    },
    {
      "t": 111991,
      "e": 102188,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":6}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":5}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2304},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2315},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2302}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2342},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2342}},{\"nodeType\":1,\"id\":2393,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2343}},{\"nodeType\":1,\"id\":2394,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2393},\"parentNode\":{\"id\":2343}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2418,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2392}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2394}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2421,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2420}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2434},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2434}},{\"nodeType\":1,\"id\":2461,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2435}},{\"nodeType\":1,\"id\":2462,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2461},\"parentNode\":{\"id\":2435}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"0\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"1\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"2\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"3\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"4\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"5\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"6\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"7\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"8\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"9\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"10\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2474,\"textContent\":\"11\",\"parentNode\":{\"id\":2460}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"12\",\"parentNode\":{\"id\":2462}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2477,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2487},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2488},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2488}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2489}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2523},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2541},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2543}},{\"nodeType\":1,\"id\":2579,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2578},\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"A \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"B \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"C \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"D \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"E \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"F \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"G \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"H \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"I \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"J \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"K \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"L \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"M \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"N \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"O \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"P \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2596,\"textContent\":\"Z \",\"parentNode\":{\"id\":2577}},{\"nodeType\":3,\"id\":2597,\"textContent\":\"X \",\"parentNode\":{\"id\":2579}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2313},{\"id\":2318},{\"id\":2319},{\"id\":2345},{\"id\":2346},{\"id\":2395},{\"id\":2320},{\"id\":2347},{\"id\":2348},{\"id\":2396},{\"id\":2321},{\"id\":2349},{\"id\":2350},{\"id\":2397},{\"id\":2322},{\"id\":2351},{\"id\":2352},{\"id\":2398},{\"id\":2323},{\"id\":2353},{\"id\":2354},{\"id\":2399},{\"id\":2324},{\"id\":2355},{\"id\":2356},{\"id\":2400},{\"id\":2325},{\"id\":2357},{\"id\":2358},{\"id\":2401},{\"id\":2326},{\"id\":2359},{\"id\":2360},{\"id\":2402},{\"id\":2327},{\"id\":2361},{\"id\":2362},{\"id\":2403},{\"id\":2328},{\"id\":2363},{\"id\":2364},{\"id\":2404},{\"id\":2329},{\"id\":2365},{\"id\":2366},{\"id\":2405},{\"id\":2330},{\"id\":2367},{\"id\":2368},{\"id\":2406},{\"id\":2331},{\"id\":2369},{\"id\":2370},{\"id\":2407},{\"id\":2332},{\"id\":2371},{\"id\":2372},{\"id\":2408},{\"id\":2333},{\"id\":2373},{\"id\":2374},{\"id\":2409},{\"id\":2334},{\"id\":2375},{\"id\":2376},{\"id\":2410},{\"id\":2335},{\"id\":2377},{\"id\":2378},{\"id\":2411},{\"id\":2336},{\"id\":2379},{\"id\":2380},{\"id\":2412},{\"id\":2337},{\"id\":2381},{\"id\":2382},{\"id\":2413},{\"id\":2338},{\"id\":2383},{\"id\":2384},{\"id\":2414},{\"id\":2339},{\"id\":2385},{\"id\":2386},{\"id\":2415},{\"id\":2340},{\"id\":2387},{\"id\":2388},{\"id\":2416},{\"id\":2341},{\"id\":2389},{\"id\":2390},{\"id\":2417},{\"id\":2342},{\"id\":2391},{\"id\":2392},{\"id\":2418},{\"id\":2343},{\"id\":2393},{\"id\":2394},{\"id\":2419},{\"id\":2344},{\"id\":2420},{\"id\":2421},{\"id\":2314},{\"id\":2422},{\"id\":2423},{\"id\":2437},{\"id\":2438},{\"id\":2463},{\"id\":2424},{\"id\":2439},{\"id\":2440},{\"id\":2464},{\"id\":2425},{\"id\":2441},{\"id\":2442},{\"id\":2465},{\"id\":2426},{\"id\":2443},{\"id\":2444},{\"id\":2466},{\"id\":2427},{\"id\":2445},{\"id\":2446},{\"id\":2467},{\"id\":2428},{\"id\":2447},{\"id\":2448},{\"id\":2468},{\"id\":2429},{\"id\":2449},{\"id\":2450},{\"id\":2469},{\"id\":2430},{\"id\":2451},{\"id\":2452},{\"id\":2470},{\"id\":2431},{\"id\":2453},{\"id\":2454},{\"id\":2471},{\"id\":2432},{\"id\":2455},{\"id\":2456},{\"id\":2472},{\"id\":2433},{\"id\":2457},{\"id\":2458},{\"id\":2473},{\"id\":2434},{\"id\":2459},{\"id\":2460},{\"id\":2474},{\"id\":2435},{\"id\":2461},{\"id\":2462},{\"id\":2475},{\"id\":2436},{\"id\":2476},{\"id\":2477},{\"id\":2315},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2488},{\"id\":2500},{\"id\":2489},{\"id\":2501},{\"id\":2316},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2317},{\"id\":2526},{\"id\":2544},{\"id\":2545},{\"id\":2580},{\"id\":2527},{\"id\":2546},{\"id\":2547},{\"id\":2581},{\"id\":2528},{\"id\":2548},{\"id\":2549},{\"id\":2582},{\"id\":2529},{\"id\":2550},{\"id\":2551},{\"id\":2583},{\"id\":2530},{\"id\":2552},{\"id\":2553},{\"id\":2584},{\"id\":2531},{\"id\":2554},{\"id\":2555},{\"id\":2585},{\"id\":2532},{\"id\":2556},{\"id\":2557},{\"id\":2586},{\"id\":2533},{\"id\":2558},{\"id\":2559},{\"id\":2587},{\"id\":2534},{\"id\":2560},{\"id\":2561},{\"id\":2588},{\"id\":2535},{\"id\":2562},{\"id\":2563},{\"id\":2589},{\"id\":2536},{\"id\":2564},{\"id\":2565},{\"id\":2590},{\"id\":2537},{\"id\":2566},{\"id\":2567},{\"id\":2591},{\"id\":2538},{\"id\":2568},{\"id\":2569},{\"id\":2592},{\"id\":2539},{\"id\":2570},{\"id\":2571},{\"id\":2593},{\"id\":2540},{\"id\":2572},{\"id\":2573},{\"id\":2594},{\"id\":2541},{\"id\":2574},{\"id\":2575},{\"id\":2595},{\"id\":2542},{\"id\":2576},{\"id\":2577},{\"id\":2596},{\"id\":2543},{\"id\":2578},{\"id\":2579},{\"id\":2597},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2598,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2310},{\"id\":2311},{\"nodeType\":3,\"id\":2599,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2312}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":57}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":57}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2601},\"parentNode\":{\"id\":57}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":57}},{\"nodeType\":1,\"id\":2604,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2604},\"parentNode\":{\"id\":2601}},{\"nodeType\":3,\"id\":2606,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2604}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":2602}},{\"nodeType\":3,\"id\":2609,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2610,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2603}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2600},{\"id\":2601},{\"id\":2604},{\"id\":2606},{\"id\":2605},{\"id\":2602},{\"id\":2607},{\"id\":2609},{\"id\":2608},{\"id\":2603},{\"id\":2610}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2611,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":57}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2615},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2623,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2623},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":3,\"id\":2627,\"textContent\":\"English\",\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":3,\"id\":2630,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2637,\"textContent\":\"*\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2643},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2646,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":3,\"id\":2650,\"textContent\":\"First\",\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":3,\"id\":2653,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2669,\"textContent\":\"*\",\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2675},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2615}},{\"nodeType\":3,\"id\":2678,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":3,\"id\":2682,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":3,\"id\":2685,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2701,\"textContent\":\"*\",\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2703},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2616}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2706},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2708}},{\"nodeType\":3,\"id\":2710,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":3,\"id\":2713,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2705}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2717,\"textContent\":\"*\",\"parentNode\":{\"id\":2707}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2611},{\"id\":2612},{\"id\":2613},{\"id\":2618},{\"id\":2623},{\"id\":2624},{\"id\":2637},{\"id\":2619},{\"id\":2625},{\"id\":2626},{\"id\":2627},{\"id\":2620},{\"id\":2628},{\"id\":2629},{\"id\":2630},{\"id\":2621},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2622},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2614},{\"id\":2638},{\"id\":2646},{\"id\":2647},{\"id\":2669},{\"id\":2639},{\"id\":2648},{\"id\":2649},{\"id\":2650},{\"id\":2640},{\"id\":2651},{\"id\":2652},{\"id\":2653},{\"id\":2641},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2642},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2643},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2644},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2645},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2615},{\"id\":2670},{\"id\":2678},{\"id\":2679},{\"id\":2701},{\"id\":2671},{\"id\":2680},{\"id\":2681},{\"id\":2682},{\"id\":2672},{\"id\":2683},{\"id\":2684},{\"id\":2685},{\"id\":2673},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2674},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2675},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2676},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2677},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2616},{\"id\":2702},{\"id\":2706},{\"id\":2707},{\"id\":2717},{\"id\":2703},{\"id\":2708},{\"id\":2709},{\"id\":2710},{\"id\":2704},{\"id\":2711},{\"id\":2712},{\"id\":2713},{\"id\":2705},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2617}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2718,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":57}},{\"nodeType\":3,\"id\":2719,\"textContent\":\" \",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":57}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"parentNode\":{\"id\":2718}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2718}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2718}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2718}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2718}},{\"nodeType\":1,\"id\":2725,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":2718}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2718}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2729,\"textContent\":\" \",\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"parentNode\":{\"id\":2728}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2728}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2728}},{\"nodeType\":3,\"id\":2733,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2737,\"textContent\":\" \",\"parentNode\":{\"id\":2735}},{\"nodeType\":1,\"id\":2738,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2735}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2735}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2735}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2735}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2735}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2735}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2735}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2735}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2735}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2735}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2735}},{\"nodeType\":3,\"id\":2749,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2753,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2755,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2754},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2755},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2755}},{\"nodeType\":1,\"id\":2758,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2759,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2758},\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2758}},{\"nodeType\":3,\"id\":2761,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2762,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"parentNode\":{\"id\":2725}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2763},\"parentNode\":{\"id\":2725}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2725}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2764}}],[],[]]}"
    },
    {
      "sequence": 10,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2718},{\"id\":2720},{\"id\":2721},{\"id\":2727},{\"id\":2728},{\"id\":2730},{\"id\":2731},{\"id\":2733},{\"id\":2732},{\"id\":2729},{\"id\":2722},{\"id\":2723},{\"id\":2734},{\"id\":2735},{\"id\":2737},{\"id\":2738},{\"id\":2749},{\"id\":2739},{\"id\":2750},{\"id\":2751},{\"id\":2753},{\"id\":2752},{\"id\":2740},{\"id\":2741},{\"id\":2754},{\"id\":2755},{\"id\":2757},{\"id\":2756},{\"id\":2742},{\"id\":2743},{\"id\":2758},{\"id\":2760},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2761},{\"id\":2746},{\"id\":2747},{\"id\":2762},{\"id\":2748},{\"id\":2736},{\"id\":2724},{\"id\":2725},{\"id\":2763},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2726},{\"id\":2719}],[],[],[]]}"
    },
    {
      "sequence": 11,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2767,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":57}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"[ { \\\"rt\\\": 149922, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 149929, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 24839, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 176089, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 13998, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"CHARLIE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 191095, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 21833, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 214016, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 14198, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 229217, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 48803, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 279430, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-A -A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:823,y:969,t:1526929877890};\\\", \\\"{x:797,y:959,t:1526929877909};\\\", \\\"{x:764,y:953,t:1526929877925};\\\", \\\"{x:746,y:946,t:1526929877941};\\\", \\\"{x:732,y:932,t:1526929877958};\\\", \\\"{x:721,y:918,t:1526929877976};\\\", \\\"{x:715,y:904,t:1526929877991};\\\", \\\"{x:710,y:890,t:1526929878009};\\\", \\\"{x:706,y:870,t:1526929878025};\\\", \\\"{x:702,y:861,t:1526929878042};\\\", \\\"{x:700,y:852,t:1526929878058};\\\", \\\"{x:700,y:846,t:1526929878075};\\\", \\\"{x:700,y:836,t:1526929878093};\\\", \\\"{x:708,y:821,t:1526929878108};\\\", \\\"{x:721,y:802,t:1526929878125};\\\", \\\"{x:739,y:779,t:1526929878144};\\\", \\\"{x:759,y:757,t:1526929878158};\\\", \\\"{x:774,y:732,t:1526929878175};\\\", \\\"{x:790,y:710,t:1526929878193};\\\", \\\"{x:807,y:677,t:1526929878209};\\\", \\\"{x:813,y:660,t:1526929878225};\\\", \\\"{x:820,y:647,t:1526929878242};\\\", \\\"{x:821,y:634,t:1526929878258};\\\", \\\"{x:823,y:624,t:1526929878276};\\\", \\\"{x:826,y:617,t:1526929878292};\\\", \\\"{x:830,y:608,t:1526929878310};\\\", \\\"{x:832,y:603,t:1526929878324};\\\", \\\"{x:834,y:598,t:1526929878341};\\\", \\\"{x:836,y:593,t:1526929878357};\\\", \\\"{x:838,y:589,t:1526929878375};\\\", \\\"{x:839,y:584,t:1526929878391};\\\", \\\"{x:841,y:581,t:1526929878408};\\\", \\\"{x:845,y:573,t:1526929878425};\\\", \\\"{x:847,y:569,t:1526929878442};\\\", \\\"{x:850,y:563,t:1526929878458};\\\", \\\"{x:854,y:557,t:1526929878475};\\\", \\\"{x:861,y:549,t:1526929878492};\\\", \\\"{x:867,y:542,t:1526929878509};\\\", \\\"{x:871,y:536,t:1526929878525};\\\", \\\"{x:876,y:528,t:1526929878542};\\\", \\\"{x:881,y:518,t:1526929878559};\\\", \\\"{x:888,y:505,t:1526929878576};\\\", \\\"{x:906,y:467,t:1526929878592};\\\", \\\"{x:928,y:403,t:1526929878609};\\\", \\\"{x:948,y:337,t:1526929878625};\\\", \\\"{x:967,y:265,t:1526929878641};\\\", \\\"{x:992,y:184,t:1526929878659};\\\", \\\"{x:1008,y:115,t:1526929878676};\\\", \\\"{x:1016,y:43,t:1526929878692};\\\", \\\"{x:1027,y:0,t:1526929878708};\\\", \\\"{x:1039,y:0,t:1526929878725};\\\", \\\"{x:1055,y:0,t:1526929878742};\\\", \\\"{x:1085,y:0,t:1526929878759};\\\", \\\"{x:1115,y:0,t:1526929878775};\\\", \\\"{x:1145,y:0,t:1526929878791};\\\", \\\"{x:1186,y:0,t:1526929878808};\\\", \\\"{x:1214,y:0,t:1526929878826};\\\", \\\"{x:1245,y:0,t:1526929878842};\\\", \\\"{x:1279,y:0,t:1526929878859};\\\", \\\"{x:1316,y:4,t:1526929878876};\\\", \\\"{x:1364,y:22,t:1526929878892};\\\", \\\"{x:1423,y:53,t:1526929878909};\\\", \\\"{x:1482,y:92,t:1526929878925};\\\", \\\"{x:1523,y:127,t:1526929878943};\\\", \\\"{x:1565,y:184,t:1526929878959};\\\", \\\"{x:1611,y:248,t:1526929878976};\\\", \\\"{x:1637,y:296,t:1526929878992};\\\", \\\"{x:1663,y:348,t:1526929879009};\\\", \\\"{x:1691,y:399,t:1526929879026};\\\", \\\"{x:1717,y:448,t:1526929879042};\\\", \\\"{x:1734,y:478,t:1526929879059};\\\", \\\"{x:1737,y:496,t:1526929879076};\\\", \\\"{x:1742,y:515,t:1526929879092};\\\", \\\"{x:1748,y:544,t:1526929879109};\\\", \\\"{x:1751,y:607,t:1526929879127};\\\", \\\"{x:1744,y:653,t:1526929879143};\\\", \\\"{x:1732,y:679,t:1526929879160};\\\", \\\"{x:1725,y:697,t:1526929879176};\\\", \\\"{x:1717,y:709,t:1526929879192};\\\", \\\"{x:1701,y:723,t:1526929879209};\\\", \\\"{x:1679,y:734,t:1526929879226};\\\", \\\"{x:1653,y:747,t:1526929879242};\\\", \\\"{x:1632,y:757,t:1526929879259};\\\", \\\"{x:1609,y:770,t:1526929879277};\\\", \\\"{x:1589,y:781,t:1526929879292};\\\", \\\"{x:1573,y:791,t:1526929879310};\\\", \\\"{x:1554,y:803,t:1526929879326};\\\", \\\"{x:1538,y:812,t:1526929879342};\\\", \\\"{x:1519,y:817,t:1526929879360};\\\", \\\"{x:1508,y:819,t:1526929879376};\\\", \\\"{x:1499,y:823,t:1526929879392};\\\", \\\"{x:1495,y:825,t:1526929879410};\\\", \\\"{x:1493,y:827,t:1526929879426};\\\", \\\"{x:1487,y:831,t:1526929879443};\\\", \\\"{x:1475,y:839,t:1526929879459};\\\", \\\"{x:1463,y:847,t:1526929879476};\\\", \\\"{x:1450,y:858,t:1526929879492};\\\", \\\"{x:1437,y:867,t:1526929879510};\\\", \\\"{x:1425,y:875,t:1526929879526};\\\", \\\"{x:1410,y:883,t:1526929879543};\\\", \\\"{x:1398,y:888,t:1526929879559};\\\", \\\"{x:1390,y:892,t:1526929879576};\\\", \\\"{x:1384,y:897,t:1526929879592};\\\", \\\"{x:1378,y:901,t:1526929879610};\\\", \\\"{x:1376,y:903,t:1526929879627};\\\", \\\"{x:1374,y:904,t:1526929879643};\\\", \\\"{x:1370,y:907,t:1526929879660};\\\", \\\"{x:1367,y:908,t:1526929879676};\\\", \\\"{x:1364,y:911,t:1526929879693};\\\", \\\"{x:1363,y:911,t:1526929879709};\\\", \\\"{x:1361,y:913,t:1526929879727};\\\", \\\"{x:1360,y:914,t:1526929879744};\\\", \\\"{x:1358,y:917,t:1526929879760};\\\", \\\"{x:1355,y:918,t:1526929879776};\\\", \\\"{x:1347,y:922,t:1526929879793};\\\", \\\"{x:1342,y:925,t:1526929879810};\\\", \\\"{x:1336,y:927,t:1526929879827};\\\", \\\"{x:1332,y:930,t:1526929879843};\\\", \\\"{x:1328,y:931,t:1526929879859};\\\", \\\"{x:1325,y:932,t:1526929879877};\\\", \\\"{x:1321,y:933,t:1526929879894};\\\", \\\"{x:1319,y:936,t:1526929879910};\\\", \\\"{x:1316,y:937,t:1526929879926};\\\", \\\"{x:1315,y:939,t:1526929879945};\\\", \\\"{x:1311,y:939,t:1526929879960};\\\", \\\"{x:1310,y:940,t:1526929879977};\\\", \\\"{x:1309,y:941,t:1526929880025};\\\", \\\"{x:1307,y:942,t:1526929880050};\\\", \\\"{x:1306,y:944,t:1526929880065};\\\", \\\"{x:1305,y:945,t:1526929880077};\\\", \\\"{x:1304,y:947,t:1526929880094};\\\", \\\"{x:1304,y:948,t:1526929880110};\\\", \\\"{x:1304,y:949,t:1526929880127};\\\", \\\"{x:1303,y:950,t:1526929880144};\\\", \\\"{x:1302,y:950,t:1526929880178};\\\", \\\"{x:1302,y:951,t:1526929880193};\\\", \\\"{x:1301,y:951,t:1526929880217};\\\", \\\"{x:1301,y:952,t:1526929880227};\\\", \\\"{x:1300,y:952,t:1526929880265};\\\", \\\"{x:1299,y:952,t:1526929880281};\\\", \\\"{x:1297,y:953,t:1526929880297};\\\", \\\"{x:1297,y:954,t:1526929880328};\\\", \\\"{x:1296,y:955,t:1526929880343};\\\", \\\"{x:1295,y:955,t:1526929880441};\\\", \\\"{x:1294,y:956,t:1526929880472};\\\", \\\"{x:1293,y:956,t:1526929880496};\\\", \\\"{x:1292,y:957,t:1526929880626};\\\", \\\"{x:1291,y:958,t:1526929880665};\\\", \\\"{x:1290,y:958,t:1526929880681};\\\", \\\"{x:1288,y:959,t:1526929880697};\\\", \\\"{x:1287,y:960,t:1526929880729};\\\", \\\"{x:1286,y:961,t:1526929880745};\\\", \\\"{x:1285,y:961,t:1526929880772};\\\", \\\"{x:1284,y:961,t:1526929880897};\\\", \\\"{x:1283,y:962,t:1526929880908};\\\", \\\"{x:1282,y:963,t:1526929880926};\\\", \\\"{x:1280,y:964,t:1526929880943};\\\", \\\"{x:1279,y:965,t:1526929880960};\\\", \\\"{x:1280,y:970,t:1526929880976};\\\", \\\"{x:1291,y:975,t:1526929880993};\\\", \\\"{x:1295,y:976,t:1526929881010};\\\", \\\"{x:1295,y:977,t:1526929881089};\\\", \\\"{x:1296,y:977,t:1526929881097};\\\", \\\"{x:1297,y:978,t:1526929881178};\\\", \\\"{x:1296,y:978,t:1526929881201};\\\", \\\"{x:1294,y:979,t:1526929881217};\\\", \\\"{x:1293,y:979,t:1526929881227};\\\", \\\"{x:1291,y:979,t:1526929881243};\\\", \\\"{x:1290,y:979,t:1526929881260};\\\", \\\"{x:1289,y:980,t:1526929881277};\\\", \\\"{x:1288,y:980,t:1526929881294};\\\", \\\"{x:1287,y:981,t:1526929881311};\\\", \\\"{x:1286,y:981,t:1526929881329};\\\", \\\"{x:1286,y:980,t:1526929881361};\\\", \\\"{x:1284,y:980,t:1526929881570};\\\", \\\"{x:1283,y:982,t:1526929881577};\\\", \\\"{x:1282,y:984,t:1526929881594};\\\", \\\"{x:1282,y:985,t:1526929882331};\\\", \\\"{x:1282,y:987,t:1526929882344};\\\", \\\"{x:1282,y:993,t:1526929882360};\\\", \\\"{x:1290,y:1007,t:1526929882377};\\\", \\\"{x:1300,y:1020,t:1526929882393};\\\", \\\"{x:1306,y:1029,t:1526929882411};\\\", \\\"{x:1314,y:1036,t:1526929882428};\\\", \\\"{x:1320,y:1044,t:1526929882444};\\\", \\\"{x:1323,y:1047,t:1526929882461};\\\", \\\"{x:1330,y:1057,t:1526929882484};\\\", \\\"{x:1331,y:1059,t:1526929882495};\\\", \\\"{x:1334,y:1063,t:1526929882510};\\\", \\\"{x:1337,y:1064,t:1526929882527};\\\", \\\"{x:1339,y:1064,t:1526929883031};\\\", \\\"{x:1347,y:1066,t:1526929883041};\\\", \\\"{x:1355,y:1074,t:1526929883058};\\\", \\\"{x:1359,y:1076,t:1526929883074};\\\", \\\"{x:1360,y:1077,t:1526929883091};\\\", \\\"{x:1361,y:1077,t:1526929883107};\\\", \\\"{x:1362,y:1076,t:1526929883238};\\\", \\\"{x:1362,y:1070,t:1526929883246};\\\", \\\"{x:1361,y:1063,t:1526929883257};\\\", \\\"{x:1354,y:1047,t:1526929883275};\\\", \\\"{x:1344,y:1021,t:1526929883292};\\\", \\\"{x:1334,y:999,t:1526929883307};\\\", \\\"{x:1326,y:979,t:1526929883324};\\\", \\\"{x:1312,y:958,t:1526929883341};\\\", \\\"{x:1305,y:945,t:1526929883357};\\\", \\\"{x:1297,y:936,t:1526929883374};\\\", \\\"{x:1288,y:924,t:1526929883392};\\\", \\\"{x:1278,y:914,t:1526929883408};\\\", \\\"{x:1270,y:908,t:1526929883425};\\\", \\\"{x:1265,y:905,t:1526929883441};\\\", \\\"{x:1260,y:900,t:1526929883458};\\\", \\\"{x:1256,y:897,t:1526929883475};\\\", \\\"{x:1255,y:895,t:1526929883492};\\\", \\\"{x:1253,y:892,t:1526929883507};\\\", \\\"{x:1253,y:891,t:1526929883524};\\\", \\\"{x:1252,y:889,t:1526929883542};\\\", \\\"{x:1250,y:886,t:1526929883557};\\\", \\\"{x:1250,y:876,t:1526929883574};\\\", \\\"{x:1250,y:871,t:1526929883591};\\\", \\\"{x:1250,y:866,t:1526929883608};\\\", \\\"{x:1250,y:864,t:1526929883625};\\\", \\\"{x:1250,y:862,t:1526929883643};\\\", \\\"{x:1250,y:860,t:1526929883658};\\\", \\\"{x:1250,y:855,t:1526929883675};\\\", \\\"{x:1250,y:851,t:1526929883692};\\\", \\\"{x:1250,y:847,t:1526929883708};\\\", \\\"{x:1250,y:846,t:1526929883725};\\\", \\\"{x:1250,y:845,t:1526929883741};\\\", \\\"{x:1251,y:843,t:1526929883757};\\\", \\\"{x:1252,y:843,t:1526929884119};\\\", \\\"{x:1253,y:842,t:1526929884127};\\\", \\\"{x:1254,y:841,t:1526929884175};\\\", \\\"{x:1255,y:841,t:1526929884215};\\\", \\\"{x:1257,y:839,t:1526929884535};\\\", \\\"{x:1260,y:838,t:1526929884542};\\\", \\\"{x:1263,y:835,t:1526929884559};\\\", \\\"{x:1266,y:835,t:1526929884575};\\\", \\\"{x:1268,y:834,t:1526929884592};\\\", \\\"{x:1270,y:834,t:1526929884609};\\\", \\\"{x:1272,y:834,t:1526929884625};\\\", \\\"{x:1273,y:834,t:1526929890255};\\\", \\\"{x:1274,y:833,t:1526929890271};\\\", \\\"{x:1274,y:830,t:1526929890287};\\\", \\\"{x:1275,y:828,t:1526929890295};\\\", \\\"{x:1275,y:826,t:1526929890311};\\\", \\\"{x:1276,y:824,t:1526929890328};\\\", \\\"{x:1277,y:822,t:1526929890344};\\\", \\\"{x:1277,y:821,t:1526929890360};\\\", \\\"{x:1279,y:823,t:1526929890535};\\\", \\\"{x:1279,y:824,t:1526929890544};\\\", \\\"{x:1280,y:827,t:1526929890564};\\\", \\\"{x:1280,y:828,t:1526929890576};\\\", \\\"{x:1280,y:830,t:1526929890593};\\\", \\\"{x:1282,y:832,t:1526929894095};\\\", \\\"{x:1288,y:832,t:1526929894112};\\\", \\\"{x:1296,y:830,t:1526929894129};\\\", \\\"{x:1297,y:830,t:1526929894145};\\\", \\\"{x:1299,y:829,t:1526929894344};\\\", \\\"{x:1301,y:828,t:1526929894350};\\\", \\\"{x:1304,y:826,t:1526929894361};\\\", \\\"{x:1312,y:822,t:1526929894378};\\\", \\\"{x:1323,y:816,t:1526929894396};\\\", \\\"{x:1331,y:812,t:1526929894411};\\\", \\\"{x:1335,y:810,t:1526929894428};\\\", \\\"{x:1335,y:809,t:1526929894687};\\\", \\\"{x:1335,y:808,t:1526929894695};\\\", \\\"{x:1338,y:805,t:1526929894712};\\\", \\\"{x:1337,y:805,t:1526929895566};\\\", \\\"{x:1328,y:805,t:1526929895578};\\\", \\\"{x:1298,y:796,t:1526929895595};\\\", \\\"{x:1252,y:779,t:1526929895613};\\\", \\\"{x:1220,y:769,t:1526929895629};\\\", \\\"{x:1197,y:764,t:1526929895645};\\\", \\\"{x:1157,y:752,t:1526929895662};\\\", \\\"{x:1121,y:740,t:1526929895678};\\\", \\\"{x:1079,y:730,t:1526929895695};\\\", \\\"{x:1043,y:719,t:1526929895712};\\\", \\\"{x:1020,y:712,t:1526929895728};\\\", \\\"{x:1003,y:708,t:1526929895746};\\\", \\\"{x:996,y:706,t:1526929895762};\\\", \\\"{x:990,y:704,t:1526929895778};\\\", \\\"{x:987,y:703,t:1526929895796};\\\", \\\"{x:985,y:703,t:1526929895813};\\\", \\\"{x:978,y:703,t:1526929895998};\\\", \\\"{x:963,y:703,t:1526929896013};\\\", \\\"{x:909,y:695,t:1526929896029};\\\", \\\"{x:849,y:692,t:1526929896046};\\\", \\\"{x:775,y:683,t:1526929896062};\\\", \\\"{x:717,y:675,t:1526929896079};\\\", \\\"{x:639,y:664,t:1526929896095};\\\", \\\"{x:563,y:649,t:1526929896113};\\\", \\\"{x:492,y:635,t:1526929896129};\\\", \\\"{x:420,y:614,t:1526929896145};\\\", \\\"{x:357,y:587,t:1526929896170};\\\", \\\"{x:334,y:571,t:1526929896187};\\\", \\\"{x:314,y:556,t:1526929896204};\\\", \\\"{x:296,y:544,t:1526929896220};\\\", \\\"{x:286,y:536,t:1526929896237};\\\", \\\"{x:283,y:531,t:1526929896253};\\\", \\\"{x:283,y:529,t:1526929896269};\\\", \\\"{x:283,y:526,t:1526929896287};\\\", \\\"{x:284,y:523,t:1526929896303};\\\", \\\"{x:289,y:519,t:1526929896320};\\\", \\\"{x:298,y:514,t:1526929896336};\\\", \\\"{x:304,y:512,t:1526929896353};\\\", \\\"{x:314,y:509,t:1526929896370};\\\", \\\"{x:321,y:508,t:1526929896386};\\\", \\\"{x:323,y:508,t:1526929896403};\\\", \\\"{x:325,y:508,t:1526929896421};\\\", \\\"{x:326,y:507,t:1526929896436};\\\", \\\"{x:329,y:507,t:1526929896454};\\\", \\\"{x:334,y:508,t:1526929896470};\\\", \\\"{x:335,y:509,t:1526929896486};\\\", \\\"{x:338,y:511,t:1526929896504};\\\", \\\"{x:339,y:511,t:1526929896521};\\\", \\\"{x:340,y:512,t:1526929896575};\\\", \\\"{x:341,y:512,t:1526929896590};\\\", \\\"{x:342,y:513,t:1526929896606};\\\", \\\"{x:343,y:514,t:1526929896621};\\\", \\\"{x:344,y:515,t:1526929896637};\\\", \\\"{x:345,y:515,t:1526929896654};\\\", \\\"{x:346,y:516,t:1526929896677};\\\", \\\"{x:347,y:517,t:1526929896702};\\\", \\\"{x:348,y:519,t:1526929896709};\\\", \\\"{x:350,y:521,t:1526929896722};\\\", \\\"{x:352,y:524,t:1526929896739};\\\", \\\"{x:353,y:525,t:1526929896754};\\\", \\\"{x:355,y:526,t:1526929896772};\\\", \\\"{x:356,y:526,t:1526929896789};\\\", \\\"{x:358,y:526,t:1526929896854};\\\", \\\"{x:359,y:526,t:1526929896871};\\\", \\\"{x:362,y:526,t:1526929896888};\\\", \\\"{x:363,y:526,t:1526929896905};\\\", \\\"{x:366,y:525,t:1526929896922};\\\", \\\"{x:372,y:523,t:1526929896939};\\\", \\\"{x:375,y:521,t:1526929896955};\\\", \\\"{x:376,y:520,t:1526929896972};\\\", \\\"{x:377,y:520,t:1526929896990};\\\", \\\"{x:378,y:520,t:1526929897767};\\\", \\\"{x:379,y:520,t:1526929897790};\\\", \\\"{x:380,y:520,t:1526929898198};\\\", \\\"{x:384,y:521,t:1526929901047};\\\", \\\"{x:402,y:527,t:1526929901059};\\\", \\\"{x:488,y:538,t:1526929901077};\\\", \\\"{x:615,y:572,t:1526929901092};\\\", \\\"{x:764,y:613,t:1526929901109};\\\", \\\"{x:908,y:655,t:1526929901125};\\\", \\\"{x:1062,y:711,t:1526929901141};\\\", \\\"{x:1108,y:738,t:1526929901157};\\\", \\\"{x:1132,y:757,t:1526929901173};\\\", \\\"{x:1134,y:761,t:1526929901191};\\\", \\\"{x:1134,y:762,t:1526929901207};\\\", \\\"{x:1134,y:763,t:1526929901224};\\\", \\\"{x:1134,y:765,t:1526929901277};\\\", \\\"{x:1134,y:767,t:1526929901290};\\\", \\\"{x:1137,y:773,t:1526929901307};\\\", \\\"{x:1145,y:776,t:1526929901324};\\\", \\\"{x:1149,y:777,t:1526929901341};\\\", \\\"{x:1150,y:778,t:1526929901357};\\\", \\\"{x:1152,y:778,t:1526929901374};\\\", \\\"{x:1153,y:779,t:1526929901391};\\\", \\\"{x:1158,y:780,t:1526929901408};\\\", \\\"{x:1163,y:780,t:1526929901424};\\\", \\\"{x:1172,y:780,t:1526929901441};\\\", \\\"{x:1183,y:780,t:1526929901457};\\\", \\\"{x:1193,y:780,t:1526929901475};\\\", \\\"{x:1203,y:780,t:1526929901491};\\\", \\\"{x:1216,y:780,t:1526929901509};\\\", \\\"{x:1232,y:783,t:1526929901524};\\\", \\\"{x:1259,y:791,t:1526929901542};\\\", \\\"{x:1276,y:796,t:1526929901557};\\\", \\\"{x:1288,y:800,t:1526929901574};\\\", \\\"{x:1292,y:801,t:1526929901592};\\\", \\\"{x:1293,y:801,t:1526929901608};\\\", \\\"{x:1293,y:800,t:1526929901654};\\\", \\\"{x:1290,y:795,t:1526929901663};\\\", \\\"{x:1288,y:792,t:1526929901674};\\\", \\\"{x:1284,y:785,t:1526929901691};\\\", \\\"{x:1281,y:777,t:1526929901709};\\\", \\\"{x:1279,y:767,t:1526929901725};\\\", \\\"{x:1276,y:747,t:1526929901743};\\\", \\\"{x:1274,y:737,t:1526929901758};\\\", \\\"{x:1270,y:725,t:1526929901774};\\\", \\\"{x:1265,y:713,t:1526929901791};\\\", \\\"{x:1264,y:708,t:1526929901808};\\\", \\\"{x:1264,y:703,t:1526929901824};\\\", \\\"{x:1264,y:698,t:1526929901841};\\\", \\\"{x:1264,y:696,t:1526929901858};\\\", \\\"{x:1264,y:693,t:1526929901875};\\\", \\\"{x:1264,y:689,t:1526929901891};\\\", \\\"{x:1264,y:687,t:1526929901908};\\\", \\\"{x:1264,y:685,t:1526929901924};\\\", \\\"{x:1264,y:683,t:1526929901942};\\\", \\\"{x:1264,y:681,t:1526929901958};\\\", \\\"{x:1264,y:679,t:1526929901975};\\\", \\\"{x:1264,y:678,t:1526929901992};\\\", \\\"{x:1264,y:676,t:1526929902008};\\\", \\\"{x:1264,y:675,t:1526929902025};\\\", \\\"{x:1264,y:674,t:1526929902126};\\\", \\\"{x:1265,y:673,t:1526929902183};\\\", \\\"{x:1266,y:672,t:1526929902192};\\\", \\\"{x:1267,y:670,t:1526929902209};\\\", \\\"{x:1269,y:668,t:1526929902226};\\\", \\\"{x:1272,y:664,t:1526929902242};\\\", \\\"{x:1275,y:659,t:1526929902259};\\\", \\\"{x:1277,y:657,t:1526929902275};\\\", \\\"{x:1278,y:655,t:1526929902292};\\\", \\\"{x:1279,y:654,t:1526929902309};\\\", \\\"{x:1279,y:653,t:1526929902422};\\\", \\\"{x:1281,y:653,t:1526929902471};\\\", \\\"{x:1282,y:653,t:1526929902582};\\\", \\\"{x:1282,y:652,t:1526929902593};\\\", \\\"{x:1283,y:648,t:1526929902609};\\\", \\\"{x:1284,y:644,t:1526929902626};\\\", \\\"{x:1286,y:639,t:1526929902643};\\\", \\\"{x:1287,y:633,t:1526929902659};\\\", \\\"{x:1288,y:629,t:1526929902676};\\\", \\\"{x:1289,y:624,t:1526929902693};\\\", \\\"{x:1290,y:620,t:1526929902709};\\\", \\\"{x:1291,y:612,t:1526929902726};\\\", \\\"{x:1292,y:606,t:1526929902742};\\\", \\\"{x:1292,y:601,t:1526929902759};\\\", \\\"{x:1292,y:596,t:1526929902775};\\\", \\\"{x:1292,y:590,t:1526929902792};\\\", \\\"{x:1292,y:582,t:1526929902809};\\\", \\\"{x:1292,y:578,t:1526929902826};\\\", \\\"{x:1292,y:572,t:1526929902842};\\\", \\\"{x:1292,y:568,t:1526929902860};\\\", \\\"{x:1291,y:564,t:1526929902876};\\\", \\\"{x:1289,y:558,t:1526929902892};\\\", \\\"{x:1288,y:553,t:1526929902910};\\\", \\\"{x:1287,y:552,t:1526929902927};\\\", \\\"{x:1286,y:550,t:1526929902942};\\\", \\\"{x:1286,y:549,t:1526929902959};\\\", \\\"{x:1286,y:548,t:1526929902976};\\\", \\\"{x:1285,y:547,t:1526929903015};\\\", \\\"{x:1284,y:547,t:1526929903174};\\\", \\\"{x:1284,y:549,t:1526929903193};\\\", \\\"{x:1284,y:550,t:1526929903238};\\\", \\\"{x:1284,y:552,t:1526929903286};\\\", \\\"{x:1284,y:553,t:1526929903351};\\\", \\\"{x:1284,y:555,t:1526929903390};\\\", \\\"{x:1284,y:556,t:1526929903414};\\\", \\\"{x:1284,y:558,t:1526929903430};\\\", \\\"{x:1284,y:559,t:1526929903447};\\\", \\\"{x:1284,y:561,t:1526929903478};\\\", \\\"{x:1284,y:562,t:1526929903502};\\\", \\\"{x:1284,y:564,t:1526929903518};\\\", \\\"{x:1284,y:565,t:1526929903527};\\\", \\\"{x:1283,y:566,t:1526929903543};\\\", \\\"{x:1283,y:567,t:1526929903559};\\\", \\\"{x:1283,y:568,t:1526929903576};\\\", \\\"{x:1283,y:569,t:1526929903614};\\\", \\\"{x:1283,y:570,t:1526929903654};\\\", \\\"{x:1282,y:571,t:1526929903670};\\\", \\\"{x:1282,y:572,t:1526929903694};\\\", \\\"{x:1281,y:573,t:1526929903710};\\\", \\\"{x:1281,y:574,t:1526929903742};\\\", \\\"{x:1281,y:575,t:1526929903757};\\\", \\\"{x:1280,y:576,t:1526929903797};\\\", \\\"{x:1280,y:575,t:1526929904126};\\\", \\\"{x:1280,y:574,t:1526929904167};\\\", \\\"{x:1280,y:573,t:1526929904999};\\\", \\\"{x:1280,y:572,t:1526929905014};\\\", \\\"{x:1280,y:571,t:1526929905027};\\\", \\\"{x:1279,y:570,t:1526929905044};\\\", \\\"{x:1279,y:572,t:1526929907806};\\\", \\\"{x:1276,y:578,t:1526929907814};\\\", \\\"{x:1264,y:594,t:1526929907830};\\\", \\\"{x:1251,y:613,t:1526929907846};\\\", \\\"{x:1234,y:637,t:1526929907863};\\\", \\\"{x:1214,y:664,t:1526929907880};\\\", \\\"{x:1195,y:681,t:1526929907896};\\\", \\\"{x:1176,y:694,t:1526929907913};\\\", \\\"{x:1162,y:704,t:1526929907930};\\\", \\\"{x:1151,y:708,t:1526929907946};\\\", \\\"{x:1138,y:709,t:1526929907963};\\\", \\\"{x:1127,y:709,t:1526929907980};\\\", \\\"{x:1115,y:706,t:1526929907995};\\\", \\\"{x:1095,y:695,t:1526929908013};\\\", \\\"{x:1039,y:658,t:1526929908030};\\\", \\\"{x:1022,y:638,t:1526929908046};\\\", \\\"{x:1011,y:616,t:1526929908063};\\\", \\\"{x:1005,y:592,t:1526929908080};\\\", \\\"{x:1003,y:567,t:1526929908097};\\\", \\\"{x:1001,y:545,t:1526929908112};\\\", \\\"{x:1001,y:516,t:1526929908130};\\\", \\\"{x:1001,y:487,t:1526929908146};\\\", \\\"{x:1001,y:462,t:1526929908163};\\\", \\\"{x:1001,y:440,t:1526929908180};\\\", \\\"{x:1003,y:420,t:1526929908197};\\\", \\\"{x:1003,y:403,t:1526929908214};\\\", \\\"{x:1003,y:371,t:1526929908230};\\\", \\\"{x:998,y:348,t:1526929908246};\\\", \\\"{x:992,y:333,t:1526929908263};\\\", \\\"{x:988,y:324,t:1526929908280};\\\", \\\"{x:988,y:321,t:1526929908297};\\\", \\\"{x:988,y:329,t:1526929908390};\\\", \\\"{x:988,y:346,t:1526929908398};\\\", \\\"{x:988,y:371,t:1526929908413};\\\", \\\"{x:979,y:487,t:1526929908430};\\\", \\\"{x:979,y:595,t:1526929908447};\\\", \\\"{x:979,y:720,t:1526929908463};\\\", \\\"{x:979,y:842,t:1526929908480};\\\", \\\"{x:971,y:932,t:1526929908496};\\\", \\\"{x:971,y:994,t:1526929908513};\\\", \\\"{x:971,y:1032,t:1526929908529};\\\", \\\"{x:971,y:1054,t:1526929908547};\\\", \\\"{x:971,y:1062,t:1526929908563};\\\", \\\"{x:971,y:1070,t:1526929908580};\\\", \\\"{x:973,y:1077,t:1526929908597};\\\", \\\"{x:980,y:1089,t:1526929908614};\\\", \\\"{x:984,y:1095,t:1526929908630};\\\", \\\"{x:986,y:1097,t:1526929908647};\\\", \\\"{x:988,y:1099,t:1526929908664};\\\", \\\"{x:989,y:1099,t:1526929908694};\\\", \\\"{x:993,y:1099,t:1526929908701};\\\", \\\"{x:999,y:1098,t:1526929908714};\\\", \\\"{x:1028,y:1090,t:1526929908730};\\\", \\\"{x:1073,y:1084,t:1526929908747};\\\", \\\"{x:1134,y:1084,t:1526929908764};\\\", \\\"{x:1214,y:1084,t:1526929908780};\\\", \\\"{x:1295,y:1084,t:1526929908797};\\\", \\\"{x:1392,y:1084,t:1526929908814};\\\", \\\"{x:1443,y:1084,t:1526929908829};\\\", \\\"{x:1488,y:1090,t:1526929908847};\\\", \\\"{x:1526,y:1102,t:1526929908863};\\\", \\\"{x:1546,y:1107,t:1526929908880};\\\", \\\"{x:1553,y:1109,t:1526929908897};\\\", \\\"{x:1552,y:1109,t:1526929909047};\\\", \\\"{x:1542,y:1106,t:1526929909064};\\\", \\\"{x:1526,y:1101,t:1526929909081};\\\", \\\"{x:1510,y:1097,t:1526929909096};\\\", \\\"{x:1486,y:1090,t:1526929909113};\\\", \\\"{x:1459,y:1084,t:1526929909131};\\\", \\\"{x:1416,y:1075,t:1526929909150};\\\", \\\"{x:1379,y:1068,t:1526929909164};\\\", \\\"{x:1354,y:1062,t:1526929909181};\\\", \\\"{x:1332,y:1056,t:1526929909196};\\\", \\\"{x:1313,y:1051,t:1526929909213};\\\", \\\"{x:1307,y:1049,t:1526929909230};\\\", \\\"{x:1302,y:1049,t:1526929909246};\\\", \\\"{x:1300,y:1049,t:1526929909263};\\\", \\\"{x:1298,y:1049,t:1526929909280};\\\", \\\"{x:1294,y:1049,t:1526929909297};\\\", \\\"{x:1289,y:1049,t:1526929909313};\\\", \\\"{x:1288,y:1049,t:1526929909330};\\\", \\\"{x:1287,y:1049,t:1526929909346};\\\", \\\"{x:1286,y:1049,t:1526929909363};\\\", \\\"{x:1285,y:1049,t:1526929909549};\\\", \\\"{x:1285,y:1046,t:1526929909563};\\\", \\\"{x:1285,y:1043,t:1526929909581};\\\", \\\"{x:1290,y:1036,t:1526929909597};\\\", \\\"{x:1299,y:1030,t:1526929909613};\\\", \\\"{x:1318,y:1022,t:1526929909630};\\\", \\\"{x:1343,y:1010,t:1526929909647};\\\", \\\"{x:1367,y:1000,t:1526929909663};\\\", \\\"{x:1382,y:994,t:1526929909680};\\\", \\\"{x:1388,y:992,t:1526929909697};\\\", \\\"{x:1389,y:992,t:1526929909713};\\\", \\\"{x:1390,y:992,t:1526929909789};\\\", \\\"{x:1390,y:993,t:1526929909879};\\\", \\\"{x:1390,y:994,t:1526929909886};\\\", \\\"{x:1390,y:995,t:1526929909901};\\\", \\\"{x:1390,y:996,t:1526929909914};\\\", \\\"{x:1390,y:997,t:1526929909931};\\\", \\\"{x:1391,y:1000,t:1526929909948};\\\", \\\"{x:1393,y:1005,t:1526929909965};\\\", \\\"{x:1395,y:1010,t:1526929909982};\\\", \\\"{x:1398,y:1021,t:1526929909998};\\\", \\\"{x:1398,y:1029,t:1526929910014};\\\", \\\"{x:1398,y:1033,t:1526929910031};\\\", \\\"{x:1398,y:1035,t:1526929910048};\\\", \\\"{x:1398,y:1036,t:1526929910070};\\\", \\\"{x:1398,y:1034,t:1526929910615};\\\", \\\"{x:1398,y:1027,t:1526929910632};\\\", \\\"{x:1397,y:1017,t:1526929910649};\\\", \\\"{x:1393,y:1005,t:1526929910665};\\\", \\\"{x:1387,y:988,t:1526929910682};\\\", \\\"{x:1375,y:972,t:1526929910698};\\\", \\\"{x:1365,y:958,t:1526929910715};\\\", \\\"{x:1356,y:944,t:1526929910732};\\\", \\\"{x:1348,y:933,t:1526929910747};\\\", \\\"{x:1340,y:922,t:1526929910764};\\\", \\\"{x:1331,y:908,t:1526929910781};\\\", \\\"{x:1329,y:903,t:1526929910797};\\\", \\\"{x:1326,y:897,t:1526929910814};\\\", \\\"{x:1326,y:895,t:1526929910831};\\\", \\\"{x:1325,y:894,t:1526929910847};\\\", \\\"{x:1325,y:892,t:1526929910869};\\\", \\\"{x:1324,y:891,t:1526929910893};\\\", \\\"{x:1323,y:890,t:1526929910909};\\\", \\\"{x:1323,y:888,t:1526929910918};\\\", \\\"{x:1322,y:887,t:1526929910934};\\\", \\\"{x:1320,y:885,t:1526929910948};\\\", \\\"{x:1319,y:881,t:1526929910965};\\\", \\\"{x:1316,y:875,t:1526929910982};\\\", \\\"{x:1315,y:873,t:1526929910999};\\\", \\\"{x:1310,y:865,t:1526929911014};\\\", \\\"{x:1306,y:857,t:1526929911032};\\\", \\\"{x:1300,y:846,t:1526929911048};\\\", \\\"{x:1296,y:839,t:1526929911065};\\\", \\\"{x:1292,y:833,t:1526929911082};\\\", \\\"{x:1288,y:826,t:1526929911099};\\\", \\\"{x:1286,y:823,t:1526929911115};\\\", \\\"{x:1284,y:821,t:1526929911132};\\\", \\\"{x:1284,y:820,t:1526929911157};\\\", \\\"{x:1283,y:820,t:1526929911285};\\\", \\\"{x:1283,y:822,t:1526929911479};\\\", \\\"{x:1282,y:822,t:1526929911518};\\\", \\\"{x:1281,y:822,t:1526929911532};\\\", \\\"{x:1280,y:822,t:1526929911549};\\\", \\\"{x:1280,y:823,t:1526929911670};\\\", \\\"{x:1278,y:823,t:1526929911682};\\\", \\\"{x:1277,y:823,t:1526929911702};\\\", \\\"{x:1276,y:825,t:1526929911718};\\\", \\\"{x:1276,y:827,t:1526929912222};\\\", \\\"{x:1276,y:828,t:1526929912254};\\\", \\\"{x:1276,y:830,t:1526929912277};\\\", \\\"{x:1276,y:831,t:1526929912302};\\\", \\\"{x:1274,y:831,t:1526929920639};\\\", \\\"{x:1243,y:831,t:1526929920656};\\\", \\\"{x:1179,y:831,t:1526929920672};\\\", \\\"{x:1106,y:831,t:1526929920689};\\\", \\\"{x:1017,y:831,t:1526929920706};\\\", \\\"{x:942,y:831,t:1526929920722};\\\", \\\"{x:884,y:831,t:1526929920740};\\\", \\\"{x:831,y:831,t:1526929920755};\\\", \\\"{x:802,y:831,t:1526929920772};\\\", \\\"{x:774,y:831,t:1526929920790};\\\", \\\"{x:757,y:831,t:1526929920806};\\\", \\\"{x:742,y:831,t:1526929920822};\\\", \\\"{x:723,y:831,t:1526929920839};\\\", \\\"{x:693,y:831,t:1526929920856};\\\", \\\"{x:665,y:831,t:1526929920872};\\\", \\\"{x:638,y:831,t:1526929920889};\\\", \\\"{x:611,y:828,t:1526929920906};\\\", \\\"{x:587,y:824,t:1526929920922};\\\", \\\"{x:562,y:814,t:1526929920939};\\\", \\\"{x:535,y:799,t:1526929920956};\\\", \\\"{x:516,y:787,t:1526929920972};\\\", \\\"{x:499,y:767,t:1526929920990};\\\", \\\"{x:495,y:752,t:1526929921005};\\\", \\\"{x:491,y:738,t:1526929921022};\\\", \\\"{x:489,y:725,t:1526929921040};\\\", \\\"{x:487,y:712,t:1526929921055};\\\", \\\"{x:486,y:700,t:1526929921072};\\\", \\\"{x:482,y:688,t:1526929921091};\\\", \\\"{x:477,y:672,t:1526929921106};\\\", \\\"{x:471,y:653,t:1526929921124};\\\", \\\"{x:463,y:623,t:1526929921141};\\\", \\\"{x:458,y:606,t:1526929921157};\\\", \\\"{x:454,y:594,t:1526929921173};\\\", \\\"{x:447,y:583,t:1526929921190};\\\", \\\"{x:442,y:577,t:1526929921207};\\\", \\\"{x:436,y:571,t:1526929921224};\\\", \\\"{x:433,y:566,t:1526929921241};\\\", \\\"{x:427,y:559,t:1526929921257};\\\", \\\"{x:422,y:554,t:1526929921274};\\\", \\\"{x:418,y:548,t:1526929921291};\\\", \\\"{x:414,y:544,t:1526929921307};\\\", \\\"{x:409,y:539,t:1526929921325};\\\", \\\"{x:402,y:535,t:1526929921342};\\\", \\\"{x:398,y:534,t:1526929921358};\\\", \\\"{x:396,y:533,t:1526929921374};\\\", \\\"{x:393,y:532,t:1526929921390};\\\", \\\"{x:388,y:530,t:1526929921408};\\\", \\\"{x:387,y:530,t:1526929921423};\\\", \\\"{x:386,y:530,t:1526929921469};\\\", \\\"{x:385,y:530,t:1526929921477};\\\", \\\"{x:383,y:529,t:1526929921490};\\\", \\\"{x:380,y:528,t:1526929921508};\\\", \\\"{x:376,y:526,t:1526929921525};\\\", \\\"{x:376,y:525,t:1526929921541};\\\", \\\"{x:380,y:526,t:1526929921901};\\\", \\\"{x:381,y:528,t:1526929921909};\\\", \\\"{x:385,y:531,t:1526929921924};\\\", \\\"{x:395,y:541,t:1526929921941};\\\", \\\"{x:403,y:551,t:1526929921958};\\\", \\\"{x:411,y:560,t:1526929921975};\\\", \\\"{x:422,y:574,t:1526929921991};\\\", \\\"{x:433,y:590,t:1526929922008};\\\", \\\"{x:438,y:603,t:1526929922025};\\\", \\\"{x:442,y:620,t:1526929922042};\\\", \\\"{x:446,y:634,t:1526929922058};\\\", \\\"{x:452,y:649,t:1526929922074};\\\", \\\"{x:455,y:656,t:1526929922091};\\\", \\\"{x:458,y:661,t:1526929922108};\\\", \\\"{x:460,y:669,t:1526929922124};\\\", \\\"{x:462,y:677,t:1526929922140};\\\", \\\"{x:463,y:681,t:1526929922157};\\\", \\\"{x:463,y:685,t:1526929922174};\\\", \\\"{x:463,y:687,t:1526929922191};\\\", \\\"{x:463,y:688,t:1526929922208};\\\", \\\"{x:465,y:689,t:1526929922262};\\\", \\\"{x:465,y:691,t:1526929922275};\\\", \\\"{x:467,y:694,t:1526929922291};\\\", \\\"{x:470,y:698,t:1526929922308};\\\", \\\"{x:473,y:703,t:1526929922324};\\\", \\\"{x:480,y:713,t:1526929922341};\\\", \\\"{x:482,y:716,t:1526929922358};\\\", \\\"{x:486,y:720,t:1526929922375};\\\", \\\"{x:490,y:724,t:1526929922391};\\\", \\\"{x:491,y:726,t:1526929922407};\\\", \\\"{x:493,y:727,t:1526929922425};\\\", \\\"{x:494,y:728,t:1526929922441};\\\" ] }, { \\\"rt\\\": 10563, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 291254, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -E -E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:728,t:1526929925990};\\\", \\\"{x:507,y:716,t:1526929925999};\\\", \\\"{x:516,y:706,t:1526929926010};\\\", \\\"{x:541,y:688,t:1526929926027};\\\", \\\"{x:564,y:675,t:1526929926042};\\\", \\\"{x:595,y:664,t:1526929926060};\\\", \\\"{x:613,y:662,t:1526929926077};\\\", \\\"{x:636,y:660,t:1526929926093};\\\", \\\"{x:657,y:653,t:1526929926111};\\\", \\\"{x:685,y:645,t:1526929926127};\\\", \\\"{x:722,y:638,t:1526929926143};\\\", \\\"{x:762,y:631,t:1526929926161};\\\", \\\"{x:798,y:620,t:1526929926177};\\\", \\\"{x:835,y:610,t:1526929926194};\\\", \\\"{x:870,y:597,t:1526929926211};\\\", \\\"{x:904,y:587,t:1526929926228};\\\", \\\"{x:954,y:564,t:1526929926244};\\\", \\\"{x:1052,y:522,t:1526929926260};\\\", \\\"{x:1116,y:504,t:1526929926277};\\\", \\\"{x:1160,y:494,t:1526929926293};\\\", \\\"{x:1186,y:486,t:1526929926311};\\\", \\\"{x:1216,y:480,t:1526929926328};\\\", \\\"{x:1241,y:473,t:1526929926345};\\\", \\\"{x:1265,y:466,t:1526929926361};\\\", \\\"{x:1282,y:461,t:1526929926378};\\\", \\\"{x:1296,y:455,t:1526929926395};\\\", \\\"{x:1307,y:450,t:1526929926411};\\\", \\\"{x:1319,y:443,t:1526929926428};\\\", \\\"{x:1326,y:438,t:1526929926444};\\\", \\\"{x:1333,y:435,t:1526929926461};\\\", \\\"{x:1336,y:432,t:1526929926479};\\\", \\\"{x:1337,y:432,t:1526929926495};\\\", \\\"{x:1338,y:431,t:1526929926511};\\\", \\\"{x:1342,y:426,t:1526929926528};\\\", \\\"{x:1348,y:417,t:1526929926545};\\\", \\\"{x:1354,y:406,t:1526929926561};\\\", \\\"{x:1357,y:399,t:1526929926578};\\\", \\\"{x:1360,y:396,t:1526929926595};\\\", \\\"{x:1364,y:388,t:1526929926611};\\\", \\\"{x:1367,y:383,t:1526929926629};\\\", \\\"{x:1374,y:372,t:1526929926646};\\\", \\\"{x:1379,y:364,t:1526929926661};\\\", \\\"{x:1388,y:353,t:1526929926678};\\\", \\\"{x:1394,y:344,t:1526929926695};\\\", \\\"{x:1399,y:338,t:1526929926711};\\\", \\\"{x:1403,y:336,t:1526929926728};\\\", \\\"{x:1411,y:330,t:1526929926745};\\\", \\\"{x:1417,y:326,t:1526929926761};\\\", \\\"{x:1422,y:324,t:1526929926778};\\\", \\\"{x:1427,y:322,t:1526929926795};\\\", \\\"{x:1436,y:322,t:1526929926812};\\\", \\\"{x:1444,y:323,t:1526929926828};\\\", \\\"{x:1467,y:337,t:1526929926845};\\\", \\\"{x:1484,y:349,t:1526929926861};\\\", \\\"{x:1499,y:360,t:1526929926878};\\\", \\\"{x:1518,y:371,t:1526929926895};\\\", \\\"{x:1535,y:377,t:1526929926912};\\\", \\\"{x:1551,y:382,t:1526929926928};\\\", \\\"{x:1561,y:385,t:1526929926945};\\\", \\\"{x:1565,y:387,t:1526929926962};\\\", \\\"{x:1568,y:387,t:1526929926978};\\\", \\\"{x:1571,y:389,t:1526929926995};\\\", \\\"{x:1572,y:389,t:1526929927012};\\\", \\\"{x:1574,y:389,t:1526929927029};\\\", \\\"{x:1575,y:390,t:1526929927045};\\\", \\\"{x:1576,y:390,t:1526929927062};\\\", \\\"{x:1577,y:391,t:1526929927158};\\\", \\\"{x:1577,y:392,t:1526929927165};\\\", \\\"{x:1578,y:397,t:1526929927178};\\\", \\\"{x:1583,y:402,t:1526929927195};\\\", \\\"{x:1587,y:410,t:1526929927213};\\\", \\\"{x:1591,y:416,t:1526929927228};\\\", \\\"{x:1595,y:425,t:1526929927246};\\\", \\\"{x:1599,y:431,t:1526929927262};\\\", \\\"{x:1599,y:435,t:1526929927279};\\\", \\\"{x:1600,y:438,t:1526929927295};\\\", \\\"{x:1600,y:439,t:1526929927312};\\\", \\\"{x:1601,y:441,t:1526929927328};\\\", \\\"{x:1602,y:443,t:1526929927345};\\\", \\\"{x:1602,y:444,t:1526929927363};\\\", \\\"{x:1602,y:448,t:1526929927379};\\\", \\\"{x:1603,y:451,t:1526929927395};\\\", \\\"{x:1603,y:454,t:1526929927412};\\\", \\\"{x:1606,y:458,t:1526929927429};\\\", \\\"{x:1606,y:459,t:1526929927445};\\\", \\\"{x:1606,y:460,t:1526929927462};\\\", \\\"{x:1606,y:461,t:1526929927557};\\\", \\\"{x:1606,y:463,t:1526929927565};\\\", \\\"{x:1606,y:464,t:1526929927579};\\\", \\\"{x:1607,y:468,t:1526929927595};\\\", \\\"{x:1608,y:472,t:1526929927612};\\\", \\\"{x:1609,y:479,t:1526929927629};\\\", \\\"{x:1610,y:482,t:1526929927645};\\\", \\\"{x:1610,y:487,t:1526929927661};\\\", \\\"{x:1611,y:490,t:1526929927678};\\\", \\\"{x:1611,y:492,t:1526929927695};\\\", \\\"{x:1612,y:493,t:1526929927712};\\\", \\\"{x:1612,y:494,t:1526929927765};\\\", \\\"{x:1612,y:495,t:1526929927806};\\\", \\\"{x:1612,y:496,t:1526929927822};\\\", \\\"{x:1612,y:497,t:1526929927846};\\\", \\\"{x:1612,y:499,t:1526929927863};\\\", \\\"{x:1611,y:502,t:1526929927879};\\\", \\\"{x:1611,y:505,t:1526929927897};\\\", \\\"{x:1610,y:507,t:1526929927913};\\\", \\\"{x:1608,y:513,t:1526929927929};\\\", \\\"{x:1606,y:519,t:1526929927946};\\\", \\\"{x:1603,y:525,t:1526929927962};\\\", \\\"{x:1602,y:531,t:1526929927979};\\\", \\\"{x:1601,y:538,t:1526929927996};\\\", \\\"{x:1601,y:542,t:1526929928012};\\\", \\\"{x:1601,y:545,t:1526929928029};\\\", \\\"{x:1601,y:546,t:1526929928046};\\\", \\\"{x:1601,y:547,t:1526929928062};\\\", \\\"{x:1600,y:548,t:1526929928086};\\\", \\\"{x:1600,y:549,t:1526929928096};\\\", \\\"{x:1600,y:550,t:1526929928112};\\\", \\\"{x:1601,y:554,t:1526929928130};\\\", \\\"{x:1601,y:556,t:1526929928146};\\\", \\\"{x:1601,y:557,t:1526929928163};\\\", \\\"{x:1601,y:559,t:1526929928180};\\\", \\\"{x:1601,y:560,t:1526929928196};\\\", \\\"{x:1602,y:561,t:1526929928260};\\\", \\\"{x:1603,y:561,t:1526929928284};\\\", \\\"{x:1604,y:561,t:1526929928296};\\\", \\\"{x:1606,y:561,t:1526929928312};\\\", \\\"{x:1610,y:561,t:1526929928330};\\\", \\\"{x:1612,y:560,t:1526929928345};\\\", \\\"{x:1614,y:559,t:1526929928363};\\\", \\\"{x:1616,y:558,t:1526929928379};\\\", \\\"{x:1616,y:557,t:1526929928397};\\\", \\\"{x:1617,y:557,t:1526929928413};\\\", \\\"{x:1618,y:557,t:1526929928950};\\\", \\\"{x:1618,y:559,t:1526929928974};\\\", \\\"{x:1618,y:560,t:1526929928996};\\\", \\\"{x:1618,y:562,t:1526929929013};\\\", \\\"{x:1618,y:563,t:1526929929030};\\\", \\\"{x:1618,y:565,t:1526929929047};\\\", \\\"{x:1618,y:568,t:1526929929065};\\\", \\\"{x:1618,y:570,t:1526929929081};\\\", \\\"{x:1618,y:572,t:1526929929098};\\\", \\\"{x:1618,y:573,t:1526929929113};\\\", \\\"{x:1618,y:574,t:1526929929262};\\\", \\\"{x:1617,y:574,t:1526929929302};\\\", \\\"{x:1617,y:575,t:1526929929313};\\\", \\\"{x:1616,y:575,t:1526929929330};\\\", \\\"{x:1612,y:575,t:1526929929348};\\\", \\\"{x:1607,y:569,t:1526929929364};\\\", \\\"{x:1605,y:564,t:1526929929380};\\\", \\\"{x:1605,y:560,t:1526929929398};\\\", \\\"{x:1603,y:558,t:1526929929413};\\\", \\\"{x:1603,y:557,t:1526929929526};\\\", \\\"{x:1603,y:556,t:1526929929558};\\\", \\\"{x:1603,y:554,t:1526929929565};\\\", \\\"{x:1604,y:553,t:1526929929589};\\\", \\\"{x:1604,y:552,t:1526929929613};\\\", \\\"{x:1605,y:551,t:1526929929661};\\\", \\\"{x:1606,y:551,t:1526929929694};\\\", \\\"{x:1607,y:551,t:1526929929878};\\\", \\\"{x:1607,y:553,t:1526929929901};\\\", \\\"{x:1608,y:554,t:1526929930398};\\\", \\\"{x:1609,y:554,t:1526929930429};\\\", \\\"{x:1609,y:555,t:1526929930438};\\\", \\\"{x:1610,y:556,t:1526929930448};\\\", \\\"{x:1610,y:557,t:1526929930464};\\\", \\\"{x:1612,y:559,t:1526929930482};\\\", \\\"{x:1613,y:561,t:1526929930499};\\\", \\\"{x:1615,y:564,t:1526929930514};\\\", \\\"{x:1616,y:565,t:1526929930531};\\\", \\\"{x:1617,y:565,t:1526929930548};\\\", \\\"{x:1618,y:565,t:1526929930564};\\\", \\\"{x:1619,y:567,t:1526929930823};\\\", \\\"{x:1619,y:570,t:1526929930832};\\\", \\\"{x:1620,y:575,t:1526929930849};\\\", \\\"{x:1620,y:577,t:1526929930866};\\\", \\\"{x:1622,y:579,t:1526929930881};\\\", \\\"{x:1622,y:581,t:1526929930899};\\\", \\\"{x:1623,y:581,t:1526929930916};\\\", \\\"{x:1623,y:582,t:1526929930932};\\\", \\\"{x:1624,y:584,t:1526929930948};\\\", \\\"{x:1625,y:584,t:1526929930966};\\\", \\\"{x:1625,y:585,t:1526929930982};\\\", \\\"{x:1625,y:586,t:1526929930998};\\\", \\\"{x:1626,y:587,t:1526929931016};\\\", \\\"{x:1626,y:589,t:1526929931061};\\\", \\\"{x:1626,y:590,t:1526929931142};\\\", \\\"{x:1625,y:590,t:1526929931149};\\\", \\\"{x:1611,y:590,t:1526929931166};\\\", \\\"{x:1590,y:590,t:1526929931183};\\\", \\\"{x:1564,y:590,t:1526929931198};\\\", \\\"{x:1519,y:590,t:1526929931215};\\\", \\\"{x:1469,y:590,t:1526929931231};\\\", \\\"{x:1415,y:590,t:1526929931248};\\\", \\\"{x:1362,y:590,t:1526929931266};\\\", \\\"{x:1320,y:590,t:1526929931282};\\\", \\\"{x:1273,y:590,t:1526929931298};\\\", \\\"{x:1225,y:596,t:1526929931315};\\\", \\\"{x:1192,y:600,t:1526929931333};\\\", \\\"{x:1161,y:610,t:1526929931350};\\\", \\\"{x:1147,y:613,t:1526929931366};\\\", \\\"{x:1131,y:614,t:1526929931382};\\\", \\\"{x:1117,y:616,t:1526929931399};\\\", \\\"{x:1099,y:618,t:1526929931416};\\\", \\\"{x:1077,y:618,t:1526929931432};\\\", \\\"{x:1053,y:618,t:1526929931448};\\\", \\\"{x:1026,y:618,t:1526929931465};\\\", \\\"{x:996,y:618,t:1526929931483};\\\", \\\"{x:963,y:618,t:1526929931499};\\\", \\\"{x:923,y:618,t:1526929931515};\\\", \\\"{x:881,y:618,t:1526929931532};\\\", \\\"{x:840,y:615,t:1526929931548};\\\", \\\"{x:796,y:615,t:1526929931565};\\\", \\\"{x:767,y:617,t:1526929931582};\\\", \\\"{x:739,y:617,t:1526929931598};\\\", \\\"{x:708,y:619,t:1526929931615};\\\", \\\"{x:672,y:619,t:1526929931633};\\\", \\\"{x:624,y:619,t:1526929931649};\\\", \\\"{x:579,y:619,t:1526929931665};\\\", \\\"{x:546,y:617,t:1526929931683};\\\", \\\"{x:517,y:613,t:1526929931699};\\\", \\\"{x:501,y:611,t:1526929931717};\\\", \\\"{x:492,y:610,t:1526929931733};\\\", \\\"{x:489,y:608,t:1526929931749};\\\", \\\"{x:487,y:608,t:1526929931804};\\\", \\\"{x:485,y:608,t:1526929931815};\\\", \\\"{x:479,y:608,t:1526929931831};\\\", \\\"{x:473,y:608,t:1526929931849};\\\", \\\"{x:466,y:608,t:1526929931866};\\\", \\\"{x:457,y:608,t:1526929931882};\\\", \\\"{x:443,y:608,t:1526929931899};\\\", \\\"{x:427,y:608,t:1526929931916};\\\", \\\"{x:405,y:607,t:1526929931933};\\\", \\\"{x:370,y:602,t:1526929931949};\\\", \\\"{x:352,y:599,t:1526929931964};\\\", \\\"{x:342,y:597,t:1526929931982};\\\", \\\"{x:333,y:593,t:1526929931999};\\\", \\\"{x:325,y:588,t:1526929932015};\\\", \\\"{x:322,y:584,t:1526929932032};\\\", \\\"{x:316,y:578,t:1526929932049};\\\", \\\"{x:311,y:575,t:1526929932066};\\\", \\\"{x:306,y:572,t:1526929932083};\\\", \\\"{x:300,y:570,t:1526929932099};\\\", \\\"{x:294,y:567,t:1526929932116};\\\", \\\"{x:286,y:566,t:1526929932132};\\\", \\\"{x:271,y:562,t:1526929932151};\\\", \\\"{x:260,y:559,t:1526929932165};\\\", \\\"{x:248,y:558,t:1526929932181};\\\", \\\"{x:235,y:558,t:1526929932199};\\\", \\\"{x:221,y:558,t:1526929932216};\\\", \\\"{x:212,y:561,t:1526929932232};\\\", \\\"{x:204,y:566,t:1526929932248};\\\", \\\"{x:196,y:570,t:1526929932266};\\\", \\\"{x:190,y:574,t:1526929932281};\\\", \\\"{x:181,y:580,t:1526929932299};\\\", \\\"{x:175,y:585,t:1526929932317};\\\", \\\"{x:172,y:587,t:1526929932332};\\\", \\\"{x:170,y:590,t:1526929932349};\\\", \\\"{x:169,y:591,t:1526929932367};\\\", \\\"{x:168,y:592,t:1526929932382};\\\", \\\"{x:167,y:595,t:1526929932399};\\\", \\\"{x:165,y:597,t:1526929932416};\\\", \\\"{x:164,y:598,t:1526929932432};\\\", \\\"{x:163,y:599,t:1526929932449};\\\", \\\"{x:162,y:599,t:1526929932466};\\\", \\\"{x:162,y:601,t:1526929932482};\\\", \\\"{x:162,y:605,t:1526929932499};\\\", \\\"{x:159,y:616,t:1526929932516};\\\", \\\"{x:158,y:628,t:1526929932532};\\\", \\\"{x:158,y:631,t:1526929932549};\\\", \\\"{x:158,y:633,t:1526929932565};\\\", \\\"{x:158,y:634,t:1526929932582};\\\", \\\"{x:157,y:636,t:1526929932599};\\\", \\\"{x:157,y:638,t:1526929932615};\\\", \\\"{x:157,y:640,t:1526929932632};\\\", \\\"{x:157,y:643,t:1526929932649};\\\", \\\"{x:157,y:645,t:1526929932664};\\\", \\\"{x:157,y:647,t:1526929933974};\\\", \\\"{x:160,y:651,t:1526929933985};\\\", \\\"{x:180,y:659,t:1526929934000};\\\", \\\"{x:202,y:667,t:1526929934017};\\\", \\\"{x:236,y:677,t:1526929934034};\\\", \\\"{x:286,y:698,t:1526929934050};\\\", \\\"{x:317,y:711,t:1526929934067};\\\", \\\"{x:339,y:722,t:1526929934084};\\\", \\\"{x:359,y:728,t:1526929934100};\\\", \\\"{x:379,y:734,t:1526929934117};\\\", \\\"{x:387,y:734,t:1526929934133};\\\", \\\"{x:392,y:734,t:1526929934150};\\\", \\\"{x:394,y:734,t:1526929934167};\\\", \\\"{x:395,y:734,t:1526929934184};\\\", \\\"{x:398,y:734,t:1526929934200};\\\", \\\"{x:401,y:733,t:1526929934217};\\\", \\\"{x:408,y:732,t:1526929934234};\\\", \\\"{x:417,y:729,t:1526929934250};\\\", \\\"{x:424,y:728,t:1526929934267};\\\", \\\"{x:428,y:727,t:1526929934284};\\\", \\\"{x:432,y:727,t:1526929934300};\\\", \\\"{x:434,y:727,t:1526929934317};\\\", \\\"{x:439,y:727,t:1526929934334};\\\", \\\"{x:442,y:727,t:1526929934351};\\\", \\\"{x:449,y:727,t:1526929934368};\\\", \\\"{x:451,y:728,t:1526929934384};\\\", \\\"{x:452,y:728,t:1526929934401};\\\", \\\"{x:454,y:728,t:1526929934417};\\\", \\\"{x:456,y:728,t:1526929934434};\\\", \\\"{x:458,y:728,t:1526929934451};\\\", \\\"{x:460,y:728,t:1526929934467};\\\", \\\"{x:465,y:728,t:1526929934484};\\\", \\\"{x:470,y:725,t:1526929934500};\\\", \\\"{x:470,y:724,t:1526929934517};\\\", \\\"{x:471,y:724,t:1526929934534};\\\", \\\"{x:470,y:725,t:1526929935157};\\\", \\\"{x:469,y:725,t:1526929935168};\\\", \\\"{x:467,y:726,t:1526929935185};\\\", \\\"{x:466,y:728,t:1526929935201};\\\", \\\"{x:465,y:729,t:1526929935229};\\\", \\\"{x:463,y:729,t:1526929935237};\\\", \\\"{x:463,y:730,t:1526929935252};\\\", \\\"{x:460,y:732,t:1526929935268};\\\", \\\"{x:457,y:735,t:1526929935285};\\\", \\\"{x:454,y:737,t:1526929935302};\\\", \\\"{x:452,y:738,t:1526929935318};\\\", \\\"{x:450,y:739,t:1526929935335};\\\", \\\"{x:449,y:741,t:1526929935351};\\\", \\\"{x:447,y:744,t:1526929935368};\\\", \\\"{x:442,y:749,t:1526929935386};\\\", \\\"{x:442,y:750,t:1526929935402};\\\", \\\"{x:438,y:751,t:1526929935418};\\\", \\\"{x:436,y:752,t:1526929935436};\\\", \\\"{x:433,y:753,t:1526929935451};\\\", \\\"{x:427,y:755,t:1526929935469};\\\", \\\"{x:419,y:755,t:1526929935485};\\\", \\\"{x:412,y:756,t:1526929935502};\\\", \\\"{x:403,y:757,t:1526929935518};\\\", \\\"{x:384,y:757,t:1526929935536};\\\", \\\"{x:355,y:757,t:1526929935551};\\\", \\\"{x:325,y:753,t:1526929935568};\\\", \\\"{x:236,y:726,t:1526929935585};\\\", \\\"{x:77,y:700,t:1526929935602};\\\", \\\"{x:0,y:691,t:1526929935618};\\\", \\\"{x:0,y:676,t:1526929935636};\\\", \\\"{x:0,y:663,t:1526929935652};\\\", \\\"{x:0,y:643,t:1526929935668};\\\", \\\"{x:0,y:624,t:1526929935685};\\\", \\\"{x:0,y:614,t:1526929935702};\\\", \\\"{x:0,y:608,t:1526929935718};\\\", \\\"{x:0,y:605,t:1526929935735};\\\", \\\"{x:0,y:603,t:1526929935752};\\\", \\\"{x:0,y:601,t:1526929935781};\\\", \\\"{x:0,y:600,t:1526929935844};\\\" ] }, { \\\"rt\\\": 22924, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 315395, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -C -C -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:11,y:596,t:1526929935969};\\\", \\\"{x:14,y:596,t:1526929935985};\\\", \\\"{x:17,y:596,t:1526929936001};\\\", \\\"{x:22,y:596,t:1526929936018};\\\", \\\"{x:24,y:596,t:1526929936035};\\\", \\\"{x:25,y:596,t:1526929936052};\\\", \\\"{x:26,y:596,t:1526929936141};\\\", \\\"{x:27,y:596,t:1526929936152};\\\", \\\"{x:30,y:596,t:1526929936169};\\\", \\\"{x:31,y:596,t:1526929936185};\\\", \\\"{x:33,y:596,t:1526929936202};\\\", \\\"{x:34,y:596,t:1526929936219};\\\", \\\"{x:35,y:596,t:1526929936235};\\\", \\\"{x:36,y:596,t:1526929936252};\\\", \\\"{x:37,y:596,t:1526929936269};\\\", \\\"{x:39,y:594,t:1526929936788};\\\", \\\"{x:41,y:594,t:1526929936803};\\\", \\\"{x:47,y:592,t:1526929936819};\\\", \\\"{x:64,y:592,t:1526929936837};\\\", \\\"{x:83,y:592,t:1526929936852};\\\", \\\"{x:109,y:592,t:1526929936869};\\\", \\\"{x:136,y:592,t:1526929936886};\\\", \\\"{x:158,y:592,t:1526929936905};\\\", \\\"{x:197,y:592,t:1526929936919};\\\", \\\"{x:260,y:596,t:1526929936936};\\\", \\\"{x:317,y:608,t:1526929936953};\\\", \\\"{x:376,y:625,t:1526929936970};\\\", \\\"{x:413,y:637,t:1526929936985};\\\", \\\"{x:438,y:644,t:1526929937003};\\\", \\\"{x:461,y:649,t:1526929937019};\\\", \\\"{x:483,y:654,t:1526929937036};\\\", \\\"{x:488,y:654,t:1526929937053};\\\", \\\"{x:489,y:655,t:1526929937068};\\\", \\\"{x:489,y:653,t:1526929937221};\\\", \\\"{x:489,y:649,t:1526929937237};\\\", \\\"{x:489,y:643,t:1526929937253};\\\", \\\"{x:485,y:631,t:1526929937270};\\\", \\\"{x:483,y:622,t:1526929937286};\\\", \\\"{x:483,y:598,t:1526929937303};\\\", \\\"{x:484,y:563,t:1526929937321};\\\", \\\"{x:489,y:524,t:1526929937336};\\\", \\\"{x:492,y:502,t:1526929937353};\\\", \\\"{x:494,y:488,t:1526929937370};\\\", \\\"{x:496,y:478,t:1526929937386};\\\", \\\"{x:496,y:474,t:1526929937403};\\\", \\\"{x:497,y:471,t:1526929937420};\\\", \\\"{x:498,y:470,t:1526929937725};\\\", \\\"{x:499,y:470,t:1526929937736};\\\", \\\"{x:514,y:470,t:1526929937753};\\\", \\\"{x:555,y:470,t:1526929937771};\\\", \\\"{x:619,y:470,t:1526929937788};\\\", \\\"{x:694,y:470,t:1526929937803};\\\", \\\"{x:797,y:470,t:1526929937821};\\\", \\\"{x:853,y:470,t:1526929937838};\\\", \\\"{x:895,y:470,t:1526929937853};\\\", \\\"{x:925,y:470,t:1526929937871};\\\", \\\"{x:952,y:470,t:1526929937887};\\\", \\\"{x:977,y:470,t:1526929937903};\\\", \\\"{x:996,y:469,t:1526929937921};\\\", \\\"{x:1015,y:469,t:1526929937938};\\\", \\\"{x:1030,y:469,t:1526929937953};\\\", \\\"{x:1043,y:469,t:1526929937970};\\\", \\\"{x:1058,y:469,t:1526929937988};\\\", \\\"{x:1076,y:469,t:1526929938004};\\\", \\\"{x:1110,y:469,t:1526929938021};\\\", \\\"{x:1138,y:469,t:1526929938038};\\\", \\\"{x:1163,y:472,t:1526929938053};\\\", \\\"{x:1192,y:474,t:1526929938071};\\\", \\\"{x:1221,y:474,t:1526929938088};\\\", \\\"{x:1253,y:475,t:1526929938104};\\\", \\\"{x:1281,y:477,t:1526929938120};\\\", \\\"{x:1298,y:478,t:1526929938138};\\\", \\\"{x:1311,y:480,t:1526929938154};\\\", \\\"{x:1320,y:482,t:1526929938172};\\\", \\\"{x:1330,y:484,t:1526929938187};\\\", \\\"{x:1336,y:486,t:1526929938204};\\\", \\\"{x:1340,y:487,t:1526929938220};\\\", \\\"{x:1342,y:487,t:1526929938237};\\\", \\\"{x:1345,y:488,t:1526929938597};\\\", \\\"{x:1348,y:490,t:1526929938606};\\\", \\\"{x:1361,y:499,t:1526929938622};\\\", \\\"{x:1390,y:512,t:1526929938637};\\\", \\\"{x:1425,y:522,t:1526929938655};\\\", \\\"{x:1456,y:532,t:1526929938672};\\\", \\\"{x:1471,y:537,t:1526929938688};\\\", \\\"{x:1486,y:542,t:1526929938705};\\\", \\\"{x:1495,y:547,t:1526929938721};\\\", \\\"{x:1500,y:549,t:1526929938738};\\\", \\\"{x:1504,y:552,t:1526929938755};\\\", \\\"{x:1505,y:552,t:1526929938773};\\\", \\\"{x:1505,y:553,t:1526929938829};\\\", \\\"{x:1505,y:554,t:1526929938877};\\\", \\\"{x:1504,y:554,t:1526929939022};\\\", \\\"{x:1483,y:549,t:1526929939038};\\\", \\\"{x:1458,y:542,t:1526929939055};\\\", \\\"{x:1419,y:531,t:1526929939072};\\\", \\\"{x:1380,y:519,t:1526929939087};\\\", \\\"{x:1356,y:514,t:1526929939105};\\\", \\\"{x:1336,y:508,t:1526929939122};\\\", \\\"{x:1317,y:503,t:1526929939138};\\\", \\\"{x:1294,y:497,t:1526929939155};\\\", \\\"{x:1281,y:492,t:1526929939172};\\\", \\\"{x:1269,y:490,t:1526929939189};\\\", \\\"{x:1261,y:490,t:1526929939205};\\\", \\\"{x:1254,y:490,t:1526929939221};\\\", \\\"{x:1252,y:490,t:1526929939238};\\\", \\\"{x:1250,y:490,t:1526929939255};\\\", \\\"{x:1249,y:490,t:1526929939286};\\\", \\\"{x:1248,y:491,t:1526929939301};\\\", \\\"{x:1247,y:491,t:1526929939317};\\\", \\\"{x:1244,y:493,t:1526929939341};\\\", \\\"{x:1243,y:493,t:1526929939357};\\\", \\\"{x:1242,y:493,t:1526929939374};\\\", \\\"{x:1241,y:494,t:1526929939388};\\\", \\\"{x:1237,y:496,t:1526929939405};\\\", \\\"{x:1233,y:498,t:1526929939422};\\\", \\\"{x:1230,y:502,t:1526929939439};\\\", \\\"{x:1223,y:512,t:1526929939455};\\\", \\\"{x:1218,y:524,t:1526929939471};\\\", \\\"{x:1213,y:535,t:1526929939489};\\\", \\\"{x:1209,y:547,t:1526929939505};\\\", \\\"{x:1208,y:557,t:1526929939521};\\\", \\\"{x:1206,y:565,t:1526929939539};\\\", \\\"{x:1206,y:571,t:1526929939554};\\\", \\\"{x:1206,y:575,t:1526929939572};\\\", \\\"{x:1206,y:577,t:1526929939589};\\\", \\\"{x:1206,y:578,t:1526929939605};\\\", \\\"{x:1206,y:579,t:1526929939621};\\\", \\\"{x:1206,y:580,t:1526929939639};\\\", \\\"{x:1206,y:581,t:1526929939656};\\\", \\\"{x:1206,y:582,t:1526929939672};\\\", \\\"{x:1206,y:583,t:1526929939689};\\\", \\\"{x:1206,y:584,t:1526929939783};\\\", \\\"{x:1206,y:585,t:1526929939789};\\\", \\\"{x:1206,y:586,t:1526929939806};\\\", \\\"{x:1206,y:588,t:1526929939822};\\\", \\\"{x:1206,y:589,t:1526929939839};\\\", \\\"{x:1206,y:591,t:1526929939856};\\\", \\\"{x:1206,y:592,t:1526929939871};\\\", \\\"{x:1206,y:593,t:1526929939888};\\\", \\\"{x:1206,y:594,t:1526929939906};\\\", \\\"{x:1206,y:595,t:1526929939925};\\\", \\\"{x:1206,y:597,t:1526929939950};\\\", \\\"{x:1206,y:598,t:1526929939965};\\\", \\\"{x:1206,y:599,t:1526929939981};\\\", \\\"{x:1207,y:600,t:1526929939989};\\\", \\\"{x:1209,y:605,t:1526929940005};\\\", \\\"{x:1211,y:609,t:1526929940022};\\\", \\\"{x:1211,y:612,t:1526929940039};\\\", \\\"{x:1214,y:617,t:1526929940056};\\\", \\\"{x:1216,y:622,t:1526929940072};\\\", \\\"{x:1218,y:629,t:1526929940089};\\\", \\\"{x:1223,y:638,t:1526929940105};\\\", \\\"{x:1227,y:646,t:1526929940123};\\\", \\\"{x:1228,y:654,t:1526929940139};\\\", \\\"{x:1231,y:659,t:1526929940156};\\\", \\\"{x:1232,y:663,t:1526929940173};\\\", \\\"{x:1232,y:666,t:1526929940189};\\\", \\\"{x:1232,y:669,t:1526929940206};\\\", \\\"{x:1232,y:672,t:1526929940222};\\\", \\\"{x:1232,y:674,t:1526929940239};\\\", \\\"{x:1232,y:677,t:1526929940256};\\\", \\\"{x:1232,y:682,t:1526929940273};\\\", \\\"{x:1232,y:686,t:1526929940289};\\\", \\\"{x:1232,y:690,t:1526929940306};\\\", \\\"{x:1232,y:693,t:1526929940323};\\\", \\\"{x:1232,y:694,t:1526929940339};\\\", \\\"{x:1232,y:697,t:1526929940356};\\\", \\\"{x:1233,y:703,t:1526929940373};\\\", \\\"{x:1234,y:707,t:1526929940389};\\\", \\\"{x:1234,y:712,t:1526929940406};\\\", \\\"{x:1235,y:719,t:1526929940423};\\\", \\\"{x:1236,y:724,t:1526929940439};\\\", \\\"{x:1236,y:728,t:1526929940456};\\\", \\\"{x:1237,y:731,t:1526929940473};\\\", \\\"{x:1238,y:734,t:1526929940489};\\\", \\\"{x:1238,y:737,t:1526929940506};\\\", \\\"{x:1239,y:740,t:1526929940523};\\\", \\\"{x:1239,y:743,t:1526929940538};\\\", \\\"{x:1239,y:746,t:1526929940556};\\\", \\\"{x:1239,y:751,t:1526929940573};\\\", \\\"{x:1239,y:753,t:1526929940589};\\\", \\\"{x:1239,y:755,t:1526929940606};\\\", \\\"{x:1240,y:758,t:1526929940622};\\\", \\\"{x:1241,y:760,t:1526929940639};\\\", \\\"{x:1241,y:761,t:1526929940656};\\\", \\\"{x:1241,y:764,t:1526929940673};\\\", \\\"{x:1241,y:767,t:1526929940689};\\\", \\\"{x:1241,y:769,t:1526929940706};\\\", \\\"{x:1241,y:770,t:1526929940722};\\\", \\\"{x:1241,y:771,t:1526929940740};\\\", \\\"{x:1241,y:773,t:1526929940755};\\\", \\\"{x:1241,y:774,t:1526929940781};\\\", \\\"{x:1241,y:775,t:1526929940789};\\\", \\\"{x:1241,y:776,t:1526929940806};\\\", \\\"{x:1240,y:779,t:1526929940822};\\\", \\\"{x:1240,y:781,t:1526929940840};\\\", \\\"{x:1240,y:783,t:1526929940855};\\\", \\\"{x:1238,y:785,t:1526929940872};\\\", \\\"{x:1238,y:786,t:1526929940889};\\\", \\\"{x:1238,y:787,t:1526929940906};\\\", \\\"{x:1237,y:787,t:1526929940922};\\\", \\\"{x:1237,y:788,t:1526929940940};\\\", \\\"{x:1237,y:789,t:1526929940957};\\\", \\\"{x:1237,y:790,t:1526929940973};\\\", \\\"{x:1237,y:791,t:1526929941005};\\\", \\\"{x:1237,y:792,t:1526929941069};\\\", \\\"{x:1235,y:793,t:1526929941109};\\\", \\\"{x:1235,y:794,t:1526929941123};\\\", \\\"{x:1234,y:795,t:1526929941157};\\\", \\\"{x:1234,y:796,t:1526929941181};\\\", \\\"{x:1234,y:797,t:1526929941197};\\\", \\\"{x:1234,y:798,t:1526929941310};\\\", \\\"{x:1234,y:799,t:1526929941323};\\\", \\\"{x:1233,y:799,t:1526929941340};\\\", \\\"{x:1232,y:800,t:1526929941357};\\\", \\\"{x:1232,y:801,t:1526929941414};\\\", \\\"{x:1231,y:801,t:1526929941646};\\\", \\\"{x:1231,y:802,t:1526929941657};\\\", \\\"{x:1231,y:803,t:1526929941674};\\\", \\\"{x:1229,y:804,t:1526929941690};\\\", \\\"{x:1228,y:805,t:1526929941766};\\\", \\\"{x:1228,y:806,t:1526929941783};\\\", \\\"{x:1228,y:807,t:1526929941797};\\\", \\\"{x:1228,y:809,t:1526929941902};\\\", \\\"{x:1227,y:810,t:1526929941917};\\\", \\\"{x:1227,y:812,t:1526929941957};\\\", \\\"{x:1227,y:813,t:1526929942045};\\\", \\\"{x:1227,y:815,t:1526929942078};\\\", \\\"{x:1226,y:815,t:1526929942093};\\\", \\\"{x:1226,y:816,t:1526929942117};\\\", \\\"{x:1225,y:816,t:1526929942198};\\\", \\\"{x:1225,y:818,t:1526929942213};\\\", \\\"{x:1225,y:819,t:1526929942405};\\\", \\\"{x:1224,y:820,t:1526929942429};\\\", \\\"{x:1224,y:821,t:1526929942494};\\\", \\\"{x:1223,y:821,t:1526929942517};\\\", \\\"{x:1222,y:822,t:1526929942867};\\\", \\\"{x:1221,y:822,t:1526929942883};\\\", \\\"{x:1220,y:823,t:1526929942899};\\\", \\\"{x:1219,y:823,t:1526929942939};\\\", \\\"{x:1218,y:824,t:1526929942955};\\\", \\\"{x:1216,y:825,t:1526929942975};\\\", \\\"{x:1213,y:826,t:1526929942988};\\\", \\\"{x:1210,y:826,t:1526929943006};\\\", \\\"{x:1207,y:828,t:1526929943024};\\\", \\\"{x:1206,y:828,t:1526929943043};\\\", \\\"{x:1207,y:828,t:1526929946506};\\\", \\\"{x:1210,y:828,t:1526929946522};\\\", \\\"{x:1212,y:828,t:1526929946541};\\\", \\\"{x:1214,y:828,t:1526929946558};\\\", \\\"{x:1215,y:828,t:1526929946574};\\\", \\\"{x:1217,y:828,t:1526929947235};\\\", \\\"{x:1217,y:829,t:1526929947291};\\\", \\\"{x:1218,y:829,t:1526929947314};\\\", \\\"{x:1218,y:824,t:1526929947332};\\\", \\\"{x:1218,y:823,t:1526929947342};\\\", \\\"{x:1218,y:816,t:1526929947359};\\\", \\\"{x:1212,y:810,t:1526929947375};\\\", \\\"{x:1211,y:810,t:1526929949139};\\\", \\\"{x:1209,y:810,t:1526929949419};\\\", \\\"{x:1208,y:810,t:1526929949427};\\\", \\\"{x:1205,y:814,t:1526929949444};\\\", \\\"{x:1205,y:819,t:1526929949460};\\\", \\\"{x:1205,y:824,t:1526929949477};\\\", \\\"{x:1205,y:831,t:1526929949494};\\\", \\\"{x:1208,y:835,t:1526929949510};\\\", \\\"{x:1209,y:836,t:1526929949526};\\\", \\\"{x:1210,y:837,t:1526929949544};\\\", \\\"{x:1211,y:838,t:1526929949560};\\\", \\\"{x:1212,y:838,t:1526929949835};\\\", \\\"{x:1214,y:838,t:1526929950275};\\\", \\\"{x:1216,y:837,t:1526929950283};\\\", \\\"{x:1216,y:836,t:1526929950294};\\\", \\\"{x:1216,y:834,t:1526929950312};\\\", \\\"{x:1217,y:832,t:1526929950344};\\\", \\\"{x:1220,y:829,t:1526929951771};\\\", \\\"{x:1226,y:825,t:1526929951780};\\\", \\\"{x:1241,y:819,t:1526929951795};\\\", \\\"{x:1261,y:809,t:1526929951813};\\\", \\\"{x:1279,y:800,t:1526929951829};\\\", \\\"{x:1291,y:797,t:1526929951845};\\\", \\\"{x:1293,y:797,t:1526929951862};\\\", \\\"{x:1294,y:796,t:1526929951882};\\\", \\\"{x:1294,y:799,t:1526929951971};\\\", \\\"{x:1294,y:802,t:1526929951978};\\\", \\\"{x:1292,y:806,t:1526929951996};\\\", \\\"{x:1291,y:811,t:1526929952012};\\\", \\\"{x:1291,y:813,t:1526929952029};\\\", \\\"{x:1291,y:815,t:1526929952046};\\\", \\\"{x:1290,y:817,t:1526929952062};\\\", \\\"{x:1289,y:818,t:1526929952079};\\\", \\\"{x:1289,y:819,t:1526929952096};\\\", \\\"{x:1289,y:820,t:1526929952179};\\\", \\\"{x:1291,y:820,t:1526929952211};\\\", \\\"{x:1299,y:816,t:1526929952229};\\\", \\\"{x:1308,y:814,t:1526929952246};\\\", \\\"{x:1316,y:809,t:1526929952262};\\\", \\\"{x:1319,y:808,t:1526929952279};\\\", \\\"{x:1320,y:808,t:1526929952296};\\\", \\\"{x:1322,y:808,t:1526929952355};\\\", \\\"{x:1324,y:808,t:1526929952363};\\\", \\\"{x:1327,y:809,t:1526929952379};\\\", \\\"{x:1329,y:811,t:1526929952396};\\\", \\\"{x:1331,y:815,t:1526929952413};\\\", \\\"{x:1334,y:818,t:1526929952429};\\\", \\\"{x:1337,y:823,t:1526929952446};\\\", \\\"{x:1339,y:826,t:1526929952463};\\\", \\\"{x:1340,y:827,t:1526929952479};\\\", \\\"{x:1343,y:829,t:1526929952496};\\\", \\\"{x:1345,y:830,t:1526929952513};\\\", \\\"{x:1346,y:830,t:1526929952529};\\\", \\\"{x:1352,y:831,t:1526929952547};\\\", \\\"{x:1353,y:832,t:1526929952563};\\\", \\\"{x:1355,y:833,t:1526929952579};\\\", \\\"{x:1356,y:833,t:1526929952597};\\\", \\\"{x:1356,y:834,t:1526929952613};\\\", \\\"{x:1357,y:834,t:1526929952651};\\\", \\\"{x:1356,y:834,t:1526929952835};\\\", \\\"{x:1355,y:834,t:1526929952846};\\\", \\\"{x:1353,y:832,t:1526929952863};\\\", \\\"{x:1352,y:832,t:1526929952879};\\\", \\\"{x:1351,y:831,t:1526929952896};\\\", \\\"{x:1349,y:830,t:1526929952915};\\\", \\\"{x:1348,y:829,t:1526929953012};\\\", \\\"{x:1345,y:829,t:1526929953932};\\\", \\\"{x:1325,y:826,t:1526929953947};\\\", \\\"{x:1291,y:816,t:1526929953964};\\\", \\\"{x:1238,y:799,t:1526929953981};\\\", \\\"{x:1131,y:759,t:1526929953997};\\\", \\\"{x:1007,y:723,t:1526929954014};\\\", \\\"{x:864,y:686,t:1526929954030};\\\", \\\"{x:726,y:647,t:1526929954047};\\\", \\\"{x:620,y:616,t:1526929954064};\\\", \\\"{x:537,y:592,t:1526929954081};\\\", \\\"{x:494,y:577,t:1526929954097};\\\", \\\"{x:464,y:564,t:1526929954114};\\\", \\\"{x:461,y:564,t:1526929954123};\\\", \\\"{x:460,y:562,t:1526929954140};\\\", \\\"{x:458,y:562,t:1526929954156};\\\", \\\"{x:456,y:561,t:1526929954174};\\\", \\\"{x:446,y:557,t:1526929954191};\\\", \\\"{x:428,y:553,t:1526929954207};\\\", \\\"{x:411,y:552,t:1526929954224};\\\", \\\"{x:389,y:550,t:1526929954241};\\\", \\\"{x:376,y:550,t:1526929954264};\\\", \\\"{x:375,y:550,t:1526929954306};\\\", \\\"{x:373,y:552,t:1526929954331};\\\", \\\"{x:372,y:559,t:1526929954347};\\\", \\\"{x:367,y:569,t:1526929954364};\\\", \\\"{x:358,y:580,t:1526929954382};\\\", \\\"{x:343,y:590,t:1526929954398};\\\", \\\"{x:298,y:607,t:1526929954432};\\\", \\\"{x:277,y:611,t:1526929954448};\\\", \\\"{x:266,y:614,t:1526929954465};\\\", \\\"{x:256,y:616,t:1526929954481};\\\", \\\"{x:252,y:617,t:1526929954498};\\\", \\\"{x:242,y:618,t:1526929954514};\\\", \\\"{x:239,y:618,t:1526929954531};\\\", \\\"{x:243,y:618,t:1526929954602};\\\", \\\"{x:250,y:615,t:1526929954614};\\\", \\\"{x:268,y:610,t:1526929954632};\\\", \\\"{x:296,y:603,t:1526929954647};\\\", \\\"{x:361,y:592,t:1526929954665};\\\", \\\"{x:561,y:572,t:1526929954681};\\\", \\\"{x:691,y:572,t:1526929954697};\\\", \\\"{x:777,y:572,t:1526929954715};\\\", \\\"{x:824,y:576,t:1526929954732};\\\", \\\"{x:852,y:581,t:1526929954749};\\\", \\\"{x:864,y:582,t:1526929954765};\\\", \\\"{x:873,y:582,t:1526929954782};\\\", \\\"{x:875,y:582,t:1526929954799};\\\", \\\"{x:876,y:583,t:1526929954849};\\\", \\\"{x:877,y:585,t:1526929954865};\\\", \\\"{x:878,y:588,t:1526929954882};\\\", \\\"{x:878,y:589,t:1526929954946};\\\", \\\"{x:875,y:591,t:1526929954954};\\\", \\\"{x:865,y:591,t:1526929954966};\\\", \\\"{x:845,y:591,t:1526929954983};\\\", \\\"{x:820,y:591,t:1526929954999};\\\", \\\"{x:789,y:589,t:1526929955014};\\\", \\\"{x:764,y:585,t:1526929955031};\\\", \\\"{x:738,y:579,t:1526929955050};\\\", \\\"{x:709,y:573,t:1526929955065};\\\", \\\"{x:670,y:568,t:1526929955082};\\\", \\\"{x:656,y:566,t:1526929955098};\\\", \\\"{x:654,y:566,t:1526929955116};\\\", \\\"{x:653,y:566,t:1526929955177};\\\", \\\"{x:652,y:566,t:1526929955185};\\\", \\\"{x:650,y:566,t:1526929955198};\\\", \\\"{x:647,y:572,t:1526929955216};\\\", \\\"{x:644,y:581,t:1526929955232};\\\", \\\"{x:639,y:590,t:1526929955249};\\\", \\\"{x:632,y:596,t:1526929955264};\\\", \\\"{x:616,y:607,t:1526929955282};\\\", \\\"{x:602,y:611,t:1526929955298};\\\", \\\"{x:577,y:615,t:1526929955315};\\\", \\\"{x:538,y:618,t:1526929955331};\\\", \\\"{x:488,y:618,t:1526929955349};\\\", \\\"{x:434,y:618,t:1526929955365};\\\", \\\"{x:390,y:613,t:1526929955381};\\\", \\\"{x:353,y:608,t:1526929955399};\\\", \\\"{x:330,y:602,t:1526929955416};\\\", \\\"{x:315,y:599,t:1526929955433};\\\", \\\"{x:306,y:595,t:1526929955449};\\\", \\\"{x:298,y:593,t:1526929955466};\\\", \\\"{x:295,y:592,t:1526929955482};\\\", \\\"{x:292,y:591,t:1526929955500};\\\", \\\"{x:290,y:589,t:1526929955516};\\\", \\\"{x:289,y:588,t:1526929955532};\\\", \\\"{x:289,y:586,t:1526929955554};\\\", \\\"{x:288,y:586,t:1526929955570};\\\", \\\"{x:288,y:585,t:1526929955595};\\\", \\\"{x:288,y:584,t:1526929955602};\\\", \\\"{x:288,y:583,t:1526929955618};\\\", \\\"{x:288,y:582,t:1526929955666};\\\", \\\"{x:288,y:581,t:1526929955685};\\\", \\\"{x:288,y:580,t:1526929955701};\\\", \\\"{x:288,y:579,t:1526929955715};\\\", \\\"{x:287,y:579,t:1526929955817};\\\", \\\"{x:285,y:579,t:1526929955833};\\\", \\\"{x:274,y:584,t:1526929955850};\\\", \\\"{x:259,y:589,t:1526929955866};\\\", \\\"{x:250,y:594,t:1526929955882};\\\", \\\"{x:242,y:596,t:1526929955899};\\\", \\\"{x:237,y:599,t:1526929955915};\\\", \\\"{x:236,y:600,t:1526929955985};\\\", \\\"{x:239,y:600,t:1526929956042};\\\", \\\"{x:243,y:600,t:1526929956050};\\\", \\\"{x:265,y:600,t:1526929956066};\\\", \\\"{x:295,y:603,t:1526929956083};\\\", \\\"{x:353,y:608,t:1526929956100};\\\", \\\"{x:429,y:611,t:1526929956116};\\\", \\\"{x:497,y:616,t:1526929956133};\\\", \\\"{x:536,y:622,t:1526929956150};\\\", \\\"{x:558,y:625,t:1526929956166};\\\", \\\"{x:569,y:628,t:1526929956183};\\\", \\\"{x:572,y:630,t:1526929956199};\\\", \\\"{x:573,y:630,t:1526929956215};\\\", \\\"{x:573,y:631,t:1526929956250};\\\", \\\"{x:571,y:632,t:1526929956266};\\\", \\\"{x:567,y:635,t:1526929956283};\\\", \\\"{x:567,y:637,t:1526929956299};\\\", \\\"{x:566,y:638,t:1526929956385};\\\", \\\"{x:565,y:638,t:1526929956399};\\\", \\\"{x:562,y:640,t:1526929956416};\\\", \\\"{x:554,y:642,t:1526929956432};\\\", \\\"{x:543,y:643,t:1526929956450};\\\", \\\"{x:541,y:644,t:1526929956466};\\\", \\\"{x:536,y:644,t:1526929956482};\\\", \\\"{x:533,y:645,t:1526929956499};\\\", \\\"{x:532,y:645,t:1526929956562};\\\", \\\"{x:531,y:645,t:1526929956570};\\\", \\\"{x:530,y:646,t:1526929956634};\\\", \\\"{x:528,y:646,t:1526929956658};\\\", \\\"{x:527,y:647,t:1526929956666};\\\", \\\"{x:525,y:647,t:1526929956683};\\\", \\\"{x:524,y:647,t:1526929956700};\\\", \\\"{x:521,y:647,t:1526929957274};\\\", \\\"{x:514,y:647,t:1526929957284};\\\", \\\"{x:489,y:647,t:1526929957302};\\\", \\\"{x:444,y:645,t:1526929957316};\\\", \\\"{x:371,y:634,t:1526929957334};\\\", \\\"{x:284,y:617,t:1526929957351};\\\", \\\"{x:194,y:598,t:1526929957366};\\\", \\\"{x:140,y:588,t:1526929957384};\\\", \\\"{x:115,y:583,t:1526929957400};\\\", \\\"{x:101,y:580,t:1526929957417};\\\", \\\"{x:96,y:578,t:1526929957434};\\\", \\\"{x:95,y:577,t:1526929957451};\\\", \\\"{x:96,y:574,t:1526929957467};\\\", \\\"{x:97,y:573,t:1526929957483};\\\", \\\"{x:98,y:571,t:1526929957514};\\\", \\\"{x:98,y:570,t:1526929957530};\\\", \\\"{x:100,y:569,t:1526929957537};\\\", \\\"{x:105,y:566,t:1526929957550};\\\", \\\"{x:119,y:563,t:1526929957567};\\\", \\\"{x:136,y:561,t:1526929957583};\\\", \\\"{x:147,y:561,t:1526929957601};\\\", \\\"{x:153,y:561,t:1526929957617};\\\", \\\"{x:156,y:561,t:1526929957634};\\\", \\\"{x:159,y:561,t:1526929957650};\\\", \\\"{x:161,y:561,t:1526929957667};\\\", \\\"{x:162,y:561,t:1526929957706};\\\", \\\"{x:163,y:562,t:1526929957722};\\\", \\\"{x:163,y:563,t:1526929957755};\\\", \\\"{x:163,y:564,t:1526929957779};\\\", \\\"{x:162,y:565,t:1526929957802};\\\", \\\"{x:160,y:565,t:1526929957818};\\\", \\\"{x:158,y:566,t:1526929957834};\\\", \\\"{x:157,y:567,t:1526929957875};\\\", \\\"{x:159,y:568,t:1526929958121};\\\", \\\"{x:163,y:571,t:1526929958134};\\\", \\\"{x:195,y:586,t:1526929958152};\\\", \\\"{x:255,y:622,t:1526929958169};\\\", \\\"{x:329,y:667,t:1526929958185};\\\", \\\"{x:400,y:706,t:1526929958200};\\\", \\\"{x:462,y:745,t:1526929958218};\\\", \\\"{x:476,y:756,t:1526929958233};\\\", \\\"{x:486,y:762,t:1526929958250};\\\", \\\"{x:494,y:768,t:1526929958267};\\\", \\\"{x:498,y:771,t:1526929958283};\\\", \\\"{x:499,y:772,t:1526929958301};\\\", \\\"{x:499,y:771,t:1526929958378};\\\", \\\"{x:499,y:769,t:1526929958386};\\\", \\\"{x:499,y:768,t:1526929958401};\\\", \\\"{x:498,y:764,t:1526929958416};\\\", \\\"{x:498,y:758,t:1526929958434};\\\", \\\"{x:496,y:756,t:1526929958450};\\\", \\\"{x:493,y:751,t:1526929958466};\\\", \\\"{x:492,y:747,t:1526929958484};\\\", \\\"{x:491,y:742,t:1526929958500};\\\", \\\"{x:490,y:738,t:1526929958516};\\\", \\\"{x:489,y:736,t:1526929958534};\\\", \\\"{x:489,y:735,t:1526929958551};\\\", \\\"{x:489,y:733,t:1526929958570};\\\", \\\"{x:489,y:732,t:1526929958593};\\\", \\\"{x:489,y:729,t:1526929958601};\\\", \\\"{x:489,y:727,t:1526929958617};\\\", \\\"{x:489,y:726,t:1526929958634};\\\", \\\"{x:489,y:725,t:1526929959754};\\\", \\\"{x:490,y:725,t:1526929959768};\\\", \\\"{x:491,y:725,t:1526929959785};\\\", \\\"{x:492,y:727,t:1526929959802};\\\", \\\"{x:492,y:728,t:1526929959819};\\\", \\\"{x:492,y:729,t:1526929959835};\\\", \\\"{x:492,y:730,t:1526929959858};\\\", \\\"{x:492,y:731,t:1526929959874};\\\" ] }, { \\\"rt\\\": 51485, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 368109, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-04 PM-04 PM-F -02 PM-F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:732,t:1526929960459};\\\", \\\"{x:493,y:733,t:1526929960473};\\\", \\\"{x:493,y:735,t:1526929960598};\\\", \\\"{x:492,y:735,t:1526929960611};\\\", \\\"{x:491,y:736,t:1526929960619};\\\", \\\"{x:490,y:736,t:1526929960642};\\\", \\\"{x:489,y:736,t:1526929960666};\\\", \\\"{x:488,y:736,t:1526929960674};\\\", \\\"{x:486,y:737,t:1526929960690};\\\", \\\"{x:485,y:737,t:1526929960722};\\\", \\\"{x:484,y:738,t:1526929960761};\\\", \\\"{x:484,y:739,t:1526929960794};\\\", \\\"{x:484,y:740,t:1526929960803};\\\", \\\"{x:485,y:743,t:1526929960819};\\\", \\\"{x:487,y:745,t:1526929960837};\\\", \\\"{x:489,y:745,t:1526929960853};\\\", \\\"{x:490,y:745,t:1526929960870};\\\", \\\"{x:492,y:745,t:1526929960887};\\\", \\\"{x:496,y:745,t:1526929961162};\\\", \\\"{x:507,y:738,t:1526929961170};\\\", \\\"{x:537,y:730,t:1526929961188};\\\", \\\"{x:563,y:728,t:1526929961203};\\\", \\\"{x:582,y:740,t:1526929961220};\\\", \\\"{x:594,y:749,t:1526929961237};\\\", \\\"{x:623,y:764,t:1526929961254};\\\", \\\"{x:692,y:797,t:1526929961270};\\\", \\\"{x:783,y:820,t:1526929961286};\\\", \\\"{x:878,y:848,t:1526929961303};\\\", \\\"{x:953,y:871,t:1526929961319};\\\", \\\"{x:992,y:889,t:1526929961337};\\\", \\\"{x:1021,y:902,t:1526929961354};\\\", \\\"{x:1024,y:904,t:1526929961370};\\\", \\\"{x:1025,y:905,t:1526929961387};\\\", \\\"{x:1021,y:905,t:1526929962387};\\\", \\\"{x:1015,y:905,t:1526929962404};\\\", \\\"{x:1009,y:905,t:1526929962421};\\\", \\\"{x:1002,y:903,t:1526929962439};\\\", \\\"{x:997,y:901,t:1526929962455};\\\", \\\"{x:991,y:901,t:1526929962471};\\\", \\\"{x:982,y:898,t:1526929962488};\\\", \\\"{x:970,y:894,t:1526929962505};\\\", \\\"{x:963,y:892,t:1526929962521};\\\", \\\"{x:951,y:889,t:1526929962538};\\\", \\\"{x:940,y:885,t:1526929962554};\\\", \\\"{x:931,y:883,t:1526929962571};\\\", \\\"{x:922,y:879,t:1526929962588};\\\", \\\"{x:919,y:879,t:1526929962605};\\\", \\\"{x:914,y:876,t:1526929962622};\\\", \\\"{x:911,y:876,t:1526929962639};\\\", \\\"{x:909,y:875,t:1526929962656};\\\", \\\"{x:907,y:874,t:1526929962671};\\\", \\\"{x:902,y:871,t:1526929962688};\\\", \\\"{x:899,y:871,t:1526929962705};\\\", \\\"{x:898,y:871,t:1526929962721};\\\", \\\"{x:896,y:870,t:1526929962738};\\\", \\\"{x:895,y:869,t:1526929962777};\\\", \\\"{x:893,y:869,t:1526929964563};\\\", \\\"{x:892,y:869,t:1526929964649};\\\", \\\"{x:890,y:869,t:1526929964682};\\\", \\\"{x:889,y:869,t:1526929964705};\\\", \\\"{x:894,y:870,t:1526929965410};\\\", \\\"{x:921,y:882,t:1526929965423};\\\", \\\"{x:1011,y:915,t:1526929965440};\\\", \\\"{x:1092,y:940,t:1526929965457};\\\", \\\"{x:1156,y:957,t:1526929965473};\\\", \\\"{x:1214,y:974,t:1526929965490};\\\", \\\"{x:1241,y:981,t:1526929965507};\\\", \\\"{x:1254,y:985,t:1526929965523};\\\", \\\"{x:1260,y:986,t:1526929965540};\\\", \\\"{x:1261,y:986,t:1526929965557};\\\", \\\"{x:1262,y:986,t:1526929965573};\\\", \\\"{x:1264,y:986,t:1526929965625};\\\", \\\"{x:1266,y:986,t:1526929965642};\\\", \\\"{x:1266,y:985,t:1526929965657};\\\", \\\"{x:1267,y:985,t:1526929965673};\\\", \\\"{x:1267,y:984,t:1526929965731};\\\", \\\"{x:1269,y:983,t:1526929965771};\\\", \\\"{x:1270,y:983,t:1526929965786};\\\", \\\"{x:1271,y:982,t:1526929965794};\\\", \\\"{x:1272,y:981,t:1526929965818};\\\", \\\"{x:1273,y:981,t:1526929966491};\\\", \\\"{x:1284,y:975,t:1526929966508};\\\", \\\"{x:1297,y:967,t:1526929966525};\\\", \\\"{x:1308,y:963,t:1526929966541};\\\", \\\"{x:1309,y:963,t:1526929966557};\\\", \\\"{x:1310,y:963,t:1526929966602};\\\", \\\"{x:1311,y:962,t:1526929966611};\\\", \\\"{x:1312,y:962,t:1526929966626};\\\", \\\"{x:1313,y:962,t:1526929966641};\\\", \\\"{x:1315,y:962,t:1526929966657};\\\", \\\"{x:1320,y:962,t:1526929966674};\\\", \\\"{x:1324,y:962,t:1526929966691};\\\", \\\"{x:1325,y:961,t:1526929966707};\\\", \\\"{x:1327,y:960,t:1526929966771};\\\", \\\"{x:1327,y:959,t:1526929966778};\\\", \\\"{x:1328,y:959,t:1526929966792};\\\", \\\"{x:1329,y:959,t:1526929966810};\\\", \\\"{x:1328,y:958,t:1526929966827};\\\", \\\"{x:1320,y:955,t:1526929966842};\\\", \\\"{x:1298,y:949,t:1526929966858};\\\", \\\"{x:1234,y:920,t:1526929966874};\\\", \\\"{x:1181,y:897,t:1526929966892};\\\", \\\"{x:1133,y:888,t:1526929966909};\\\", \\\"{x:1087,y:881,t:1526929966924};\\\", \\\"{x:1048,y:876,t:1526929966941};\\\", \\\"{x:1022,y:870,t:1526929966959};\\\", \\\"{x:1010,y:867,t:1526929966974};\\\", \\\"{x:1005,y:865,t:1526929966991};\\\", \\\"{x:1004,y:864,t:1526929967009};\\\", \\\"{x:1003,y:863,t:1526929967024};\\\", \\\"{x:1002,y:863,t:1526929967042};\\\", \\\"{x:1002,y:862,t:1526929967075};\\\", \\\"{x:1003,y:862,t:1526929967091};\\\", \\\"{x:1003,y:861,t:1526929967114};\\\", \\\"{x:1004,y:860,t:1526929967347};\\\", \\\"{x:1005,y:859,t:1526929967425};\\\", \\\"{x:1006,y:859,t:1526929967442};\\\", \\\"{x:1008,y:859,t:1526929967458};\\\", \\\"{x:1009,y:859,t:1526929967482};\\\", \\\"{x:1012,y:859,t:1526929967491};\\\", \\\"{x:1016,y:862,t:1526929967508};\\\", \\\"{x:1019,y:862,t:1526929967525};\\\", \\\"{x:1021,y:864,t:1526929967541};\\\", \\\"{x:1023,y:865,t:1526929967558};\\\", \\\"{x:1026,y:866,t:1526929967575};\\\", \\\"{x:1030,y:867,t:1526929967591};\\\", \\\"{x:1037,y:870,t:1526929967608};\\\", \\\"{x:1046,y:871,t:1526929967625};\\\", \\\"{x:1056,y:874,t:1526929967641};\\\", \\\"{x:1077,y:879,t:1526929967658};\\\", \\\"{x:1092,y:880,t:1526929967675};\\\", \\\"{x:1119,y:885,t:1526929967691};\\\", \\\"{x:1154,y:890,t:1526929967708};\\\", \\\"{x:1192,y:893,t:1526929967725};\\\", \\\"{x:1225,y:894,t:1526929967741};\\\", \\\"{x:1248,y:899,t:1526929967758};\\\", \\\"{x:1269,y:904,t:1526929967775};\\\", \\\"{x:1279,y:908,t:1526929967792};\\\", \\\"{x:1281,y:908,t:1526929967808};\\\", \\\"{x:1282,y:908,t:1526929967826};\\\", \\\"{x:1283,y:908,t:1526929971163};\\\", \\\"{x:1290,y:908,t:1526929971178};\\\", \\\"{x:1306,y:909,t:1526929971194};\\\", \\\"{x:1326,y:913,t:1526929971211};\\\", \\\"{x:1351,y:917,t:1526929971228};\\\", \\\"{x:1371,y:919,t:1526929971244};\\\", \\\"{x:1395,y:924,t:1526929971262};\\\", \\\"{x:1419,y:928,t:1526929971278};\\\", \\\"{x:1440,y:935,t:1526929971295};\\\", \\\"{x:1453,y:941,t:1526929971312};\\\", \\\"{x:1456,y:942,t:1526929971328};\\\", \\\"{x:1457,y:943,t:1526929971344};\\\", \\\"{x:1459,y:944,t:1526929971473};\\\", \\\"{x:1461,y:945,t:1526929971490};\\\", \\\"{x:1463,y:947,t:1526929971497};\\\", \\\"{x:1465,y:948,t:1526929971513};\\\", \\\"{x:1467,y:949,t:1526929971529};\\\", \\\"{x:1469,y:949,t:1526929971545};\\\", \\\"{x:1472,y:951,t:1526929971561};\\\", \\\"{x:1475,y:952,t:1526929971578};\\\", \\\"{x:1477,y:953,t:1526929971595};\\\", \\\"{x:1479,y:954,t:1526929971611};\\\", \\\"{x:1485,y:955,t:1526929971628};\\\", \\\"{x:1495,y:957,t:1526929971645};\\\", \\\"{x:1513,y:960,t:1526929971661};\\\", \\\"{x:1532,y:962,t:1526929971678};\\\", \\\"{x:1550,y:964,t:1526929971695};\\\", \\\"{x:1564,y:966,t:1526929971711};\\\", \\\"{x:1577,y:968,t:1526929971728};\\\", \\\"{x:1584,y:970,t:1526929971745};\\\", \\\"{x:1590,y:970,t:1526929971762};\\\", \\\"{x:1593,y:970,t:1526929971779};\\\", \\\"{x:1595,y:969,t:1526929971795};\\\", \\\"{x:1596,y:969,t:1526929971811};\\\", \\\"{x:1598,y:968,t:1526929971830};\\\", \\\"{x:1599,y:968,t:1526929971844};\\\", \\\"{x:1600,y:968,t:1526929971875};\\\", \\\"{x:1601,y:966,t:1526929971898};\\\", \\\"{x:1602,y:966,t:1526929971912};\\\", \\\"{x:1604,y:965,t:1526929971929};\\\", \\\"{x:1606,y:964,t:1526929971944};\\\", \\\"{x:1609,y:962,t:1526929971961};\\\", \\\"{x:1610,y:962,t:1526929972026};\\\", \\\"{x:1611,y:961,t:1526929972049};\\\", \\\"{x:1612,y:961,t:1526929972074};\\\", \\\"{x:1613,y:961,t:1526929973275};\\\", \\\"{x:1615,y:961,t:1526929977186};\\\", \\\"{x:1616,y:961,t:1526929977200};\\\", \\\"{x:1617,y:961,t:1526929977226};\\\", \\\"{x:1617,y:963,t:1526929978579};\\\", \\\"{x:1617,y:964,t:1526929978586};\\\", \\\"{x:1617,y:967,t:1526929978601};\\\", \\\"{x:1617,y:969,t:1526929978618};\\\", \\\"{x:1617,y:971,t:1526929978633};\\\", \\\"{x:1617,y:972,t:1526929978650};\\\", \\\"{x:1617,y:973,t:1526929978859};\\\", \\\"{x:1616,y:973,t:1526929978898};\\\", \\\"{x:1615,y:973,t:1526929979194};\\\", \\\"{x:1614,y:973,t:1526929979218};\\\", \\\"{x:1612,y:973,t:1526929979234};\\\", \\\"{x:1607,y:971,t:1526929979250};\\\", \\\"{x:1595,y:964,t:1526929979267};\\\", \\\"{x:1577,y:957,t:1526929979284};\\\", \\\"{x:1541,y:944,t:1526929979301};\\\", \\\"{x:1460,y:915,t:1526929979317};\\\", \\\"{x:1372,y:880,t:1526929979334};\\\", \\\"{x:1272,y:850,t:1526929979351};\\\", \\\"{x:1158,y:815,t:1526929979367};\\\", \\\"{x:1045,y:782,t:1526929979384};\\\", \\\"{x:950,y:748,t:1526929979401};\\\", \\\"{x:861,y:704,t:1526929979418};\\\", \\\"{x:761,y:653,t:1526929979434};\\\", \\\"{x:724,y:633,t:1526929979451};\\\", \\\"{x:693,y:619,t:1526929979466};\\\", \\\"{x:671,y:613,t:1526929979484};\\\", \\\"{x:661,y:609,t:1526929979503};\\\", \\\"{x:658,y:609,t:1526929979518};\\\", \\\"{x:656,y:609,t:1526929979534};\\\", \\\"{x:655,y:609,t:1526929979569};\\\", \\\"{x:654,y:609,t:1526929979593};\\\", \\\"{x:653,y:609,t:1526929979600};\\\", \\\"{x:651,y:609,t:1526929979617};\\\", \\\"{x:650,y:609,t:1526929979634};\\\", \\\"{x:650,y:608,t:1526929979665};\\\", \\\"{x:649,y:608,t:1526929979673};\\\", \\\"{x:648,y:607,t:1526929979684};\\\", \\\"{x:647,y:606,t:1526929979701};\\\", \\\"{x:644,y:603,t:1526929979717};\\\", \\\"{x:638,y:600,t:1526929979735};\\\", \\\"{x:634,y:598,t:1526929979751};\\\", \\\"{x:629,y:596,t:1526929979768};\\\", \\\"{x:625,y:595,t:1526929979784};\\\", \\\"{x:619,y:592,t:1526929979801};\\\", \\\"{x:618,y:590,t:1526929979817};\\\", \\\"{x:618,y:589,t:1526929979841};\\\", \\\"{x:619,y:586,t:1526929979857};\\\", \\\"{x:621,y:585,t:1526929979868};\\\", \\\"{x:626,y:583,t:1526929979885};\\\", \\\"{x:627,y:582,t:1526929979902};\\\", \\\"{x:626,y:584,t:1526929979985};\\\", \\\"{x:620,y:588,t:1526929980002};\\\", \\\"{x:614,y:591,t:1526929980018};\\\", \\\"{x:612,y:593,t:1526929980035};\\\", \\\"{x:615,y:593,t:1526929980465};\\\", \\\"{x:619,y:593,t:1526929980473};\\\", \\\"{x:623,y:593,t:1526929980485};\\\", \\\"{x:640,y:592,t:1526929980503};\\\", \\\"{x:665,y:592,t:1526929980519};\\\", \\\"{x:707,y:592,t:1526929980536};\\\", \\\"{x:793,y:592,t:1526929980553};\\\", \\\"{x:898,y:607,t:1526929980568};\\\", \\\"{x:1053,y:631,t:1526929980586};\\\", \\\"{x:1127,y:640,t:1526929980602};\\\", \\\"{x:1175,y:648,t:1526929980618};\\\", \\\"{x:1200,y:652,t:1526929980635};\\\", \\\"{x:1213,y:653,t:1526929980653};\\\", \\\"{x:1215,y:653,t:1526929980669};\\\", \\\"{x:1216,y:653,t:1526929980686};\\\", \\\"{x:1221,y:654,t:1526929980703};\\\", \\\"{x:1225,y:655,t:1526929980718};\\\", \\\"{x:1233,y:656,t:1526929980736};\\\", \\\"{x:1245,y:660,t:1526929980752};\\\", \\\"{x:1257,y:666,t:1526929980768};\\\", \\\"{x:1282,y:686,t:1526929980785};\\\", \\\"{x:1307,y:700,t:1526929980803};\\\", \\\"{x:1345,y:724,t:1526929980819};\\\", \\\"{x:1407,y:767,t:1526929980835};\\\", \\\"{x:1487,y:818,t:1526929980853};\\\", \\\"{x:1563,y:862,t:1526929980870};\\\", \\\"{x:1600,y:884,t:1526929980885};\\\", \\\"{x:1610,y:889,t:1526929980903};\\\", \\\"{x:1613,y:890,t:1526929980919};\\\", \\\"{x:1615,y:891,t:1526929980936};\\\", \\\"{x:1616,y:892,t:1526929980961};\\\", \\\"{x:1615,y:891,t:1526929981001};\\\", \\\"{x:1607,y:888,t:1526929981020};\\\", \\\"{x:1582,y:878,t:1526929981036};\\\", \\\"{x:1551,y:864,t:1526929981053};\\\", \\\"{x:1530,y:855,t:1526929981070};\\\", \\\"{x:1513,y:847,t:1526929981086};\\\", \\\"{x:1491,y:835,t:1526929981103};\\\", \\\"{x:1462,y:817,t:1526929981120};\\\", \\\"{x:1437,y:804,t:1526929981137};\\\", \\\"{x:1423,y:797,t:1526929981153};\\\", \\\"{x:1415,y:790,t:1526929981170};\\\", \\\"{x:1413,y:787,t:1526929981186};\\\", \\\"{x:1412,y:786,t:1526929981202};\\\", \\\"{x:1410,y:785,t:1526929981220};\\\", \\\"{x:1408,y:783,t:1526929981236};\\\", \\\"{x:1406,y:782,t:1526929981253};\\\", \\\"{x:1403,y:780,t:1526929981270};\\\", \\\"{x:1402,y:779,t:1526929981286};\\\", \\\"{x:1400,y:778,t:1526929981303};\\\", \\\"{x:1397,y:776,t:1526929981320};\\\", \\\"{x:1395,y:773,t:1526929981338};\\\", \\\"{x:1394,y:773,t:1526929981353};\\\", \\\"{x:1393,y:773,t:1526929981370};\\\", \\\"{x:1393,y:772,t:1526929981385};\\\", \\\"{x:1391,y:772,t:1526929981403};\\\", \\\"{x:1390,y:770,t:1526929981465};\\\", \\\"{x:1388,y:770,t:1526929981594};\\\", \\\"{x:1387,y:770,t:1526929981866};\\\", \\\"{x:1385,y:769,t:1526929981955};\\\", \\\"{x:1384,y:768,t:1526929982005};\\\", \\\"{x:1383,y:768,t:1526929982020};\\\", \\\"{x:1383,y:767,t:1526929982050};\\\", \\\"{x:1383,y:765,t:1526929982569};\\\", \\\"{x:1383,y:764,t:1526929982593};\\\", \\\"{x:1384,y:764,t:1526929982618};\\\", \\\"{x:1384,y:763,t:1526929982625};\\\", \\\"{x:1386,y:762,t:1526929982674};\\\", \\\"{x:1388,y:761,t:1526929982687};\\\", \\\"{x:1392,y:760,t:1526929982704};\\\", \\\"{x:1397,y:758,t:1526929982720};\\\", \\\"{x:1401,y:756,t:1526929982737};\\\", \\\"{x:1403,y:756,t:1526929982753};\\\", \\\"{x:1404,y:756,t:1526929982778};\\\", \\\"{x:1405,y:756,t:1526929982787};\\\", \\\"{x:1415,y:756,t:1526929982804};\\\", \\\"{x:1429,y:756,t:1526929982821};\\\", \\\"{x:1438,y:756,t:1526929982837};\\\", \\\"{x:1446,y:757,t:1526929982854};\\\", \\\"{x:1450,y:758,t:1526929982871};\\\", \\\"{x:1452,y:759,t:1526929982887};\\\", \\\"{x:1452,y:760,t:1526929983090};\\\", \\\"{x:1452,y:761,t:1526929983114};\\\", \\\"{x:1452,y:762,t:1526929983138};\\\", \\\"{x:1451,y:762,t:1526929983250};\\\", \\\"{x:1449,y:763,t:1526929983259};\\\", \\\"{x:1449,y:764,t:1526929983274};\\\", \\\"{x:1448,y:764,t:1526929983387};\\\", \\\"{x:1447,y:764,t:1526929985658};\\\", \\\"{x:1446,y:763,t:1526929986019};\\\", \\\"{x:1444,y:763,t:1526929986226};\\\", \\\"{x:1441,y:766,t:1526929986240};\\\", \\\"{x:1437,y:780,t:1526929986256};\\\", \\\"{x:1432,y:795,t:1526929986273};\\\", \\\"{x:1431,y:818,t:1526929986290};\\\", \\\"{x:1438,y:864,t:1526929986306};\\\", \\\"{x:1445,y:887,t:1526929986322};\\\", \\\"{x:1453,y:901,t:1526929986339};\\\", \\\"{x:1459,y:917,t:1526929986356};\\\", \\\"{x:1463,y:928,t:1526929986372};\\\", \\\"{x:1466,y:937,t:1526929986389};\\\", \\\"{x:1468,y:948,t:1526929986406};\\\", \\\"{x:1470,y:959,t:1526929986422};\\\", \\\"{x:1470,y:967,t:1526929986438};\\\", \\\"{x:1470,y:971,t:1526929986456};\\\", \\\"{x:1470,y:973,t:1526929986472};\\\", \\\"{x:1470,y:974,t:1526929986489};\\\", \\\"{x:1463,y:974,t:1526929986505};\\\", \\\"{x:1461,y:973,t:1526929986522};\\\", \\\"{x:1453,y:970,t:1526929986539};\\\", \\\"{x:1447,y:968,t:1526929986556};\\\", \\\"{x:1437,y:960,t:1526929986572};\\\", \\\"{x:1422,y:941,t:1526929986589};\\\", \\\"{x:1411,y:917,t:1526929986606};\\\", \\\"{x:1404,y:896,t:1526929986622};\\\", \\\"{x:1403,y:883,t:1526929986640};\\\", \\\"{x:1402,y:872,t:1526929986656};\\\", \\\"{x:1399,y:862,t:1526929986673};\\\", \\\"{x:1399,y:855,t:1526929986690};\\\", \\\"{x:1399,y:842,t:1526929986705};\\\", \\\"{x:1399,y:835,t:1526929986723};\\\", \\\"{x:1399,y:829,t:1526929986739};\\\", \\\"{x:1397,y:827,t:1526929986756};\\\", \\\"{x:1397,y:825,t:1526929986773};\\\", \\\"{x:1397,y:824,t:1526929986789};\\\", \\\"{x:1396,y:821,t:1526929986806};\\\", \\\"{x:1395,y:819,t:1526929986823};\\\", \\\"{x:1395,y:817,t:1526929986838};\\\", \\\"{x:1393,y:815,t:1526929986856};\\\", \\\"{x:1391,y:811,t:1526929986873};\\\", \\\"{x:1389,y:809,t:1526929986889};\\\", \\\"{x:1387,y:807,t:1526929986906};\\\", \\\"{x:1386,y:805,t:1526929986923};\\\", \\\"{x:1386,y:803,t:1526929986939};\\\", \\\"{x:1386,y:801,t:1526929986955};\\\", \\\"{x:1385,y:798,t:1526929986973};\\\", \\\"{x:1385,y:797,t:1526929986989};\\\", \\\"{x:1385,y:795,t:1526929987006};\\\", \\\"{x:1384,y:793,t:1526929987023};\\\", \\\"{x:1383,y:792,t:1526929987039};\\\", \\\"{x:1383,y:790,t:1526929987499};\\\", \\\"{x:1383,y:789,t:1526929987506};\\\", \\\"{x:1383,y:788,t:1526929987530};\\\", \\\"{x:1383,y:787,t:1526929987541};\\\", \\\"{x:1383,y:786,t:1526929987556};\\\", \\\"{x:1382,y:784,t:1526929987574};\\\", \\\"{x:1382,y:783,t:1526929987591};\\\", \\\"{x:1382,y:782,t:1526929987690};\\\", \\\"{x:1382,y:781,t:1526929987714};\\\", \\\"{x:1382,y:780,t:1526929987738};\\\", \\\"{x:1382,y:779,t:1526929987770};\\\", \\\"{x:1382,y:778,t:1526929987786};\\\", \\\"{x:1382,y:777,t:1526929987808};\\\", \\\"{x:1382,y:776,t:1526929987825};\\\", \\\"{x:1382,y:775,t:1526929987840};\\\", \\\"{x:1382,y:774,t:1526929987856};\\\", \\\"{x:1382,y:772,t:1526929987872};\\\", \\\"{x:1382,y:771,t:1526929987889};\\\", \\\"{x:1382,y:770,t:1526929987906};\\\", \\\"{x:1382,y:769,t:1526929987922};\\\", \\\"{x:1382,y:768,t:1526929987962};\\\", \\\"{x:1382,y:767,t:1526929987973};\\\", \\\"{x:1382,y:766,t:1526929987990};\\\", \\\"{x:1382,y:764,t:1526929988009};\\\", \\\"{x:1383,y:763,t:1526929988065};\\\", \\\"{x:1384,y:762,t:1526929988073};\\\", \\\"{x:1387,y:762,t:1526929988090};\\\", \\\"{x:1391,y:760,t:1526929988106};\\\", \\\"{x:1397,y:758,t:1526929988123};\\\", \\\"{x:1402,y:758,t:1526929988140};\\\", \\\"{x:1403,y:758,t:1526929988157};\\\", \\\"{x:1404,y:758,t:1526929988173};\\\", \\\"{x:1405,y:758,t:1526929988234};\\\", \\\"{x:1407,y:758,t:1526929988651};\\\", \\\"{x:1408,y:758,t:1526929988658};\\\", \\\"{x:1411,y:758,t:1526929988674};\\\", \\\"{x:1413,y:758,t:1526929988690};\\\", \\\"{x:1415,y:758,t:1526929988707};\\\", \\\"{x:1417,y:758,t:1526929988725};\\\", \\\"{x:1419,y:758,t:1526929988740};\\\", \\\"{x:1421,y:758,t:1526929988757};\\\", \\\"{x:1423,y:758,t:1526929988774};\\\", \\\"{x:1424,y:758,t:1526929988789};\\\", \\\"{x:1425,y:758,t:1526929988806};\\\", \\\"{x:1426,y:758,t:1526929988833};\\\", \\\"{x:1427,y:758,t:1526929988865};\\\", \\\"{x:1428,y:758,t:1526929988873};\\\", \\\"{x:1429,y:758,t:1526929988890};\\\", \\\"{x:1430,y:759,t:1526929988978};\\\", \\\"{x:1431,y:759,t:1526929988990};\\\", \\\"{x:1432,y:759,t:1526929989007};\\\", \\\"{x:1433,y:759,t:1526929989099};\\\", \\\"{x:1434,y:759,t:1526929989194};\\\", \\\"{x:1435,y:759,t:1526929989306};\\\", \\\"{x:1435,y:760,t:1526929989324};\\\", \\\"{x:1436,y:761,t:1526929989418};\\\", \\\"{x:1437,y:761,t:1526929989466};\\\", \\\"{x:1439,y:761,t:1526929989506};\\\", \\\"{x:1440,y:761,t:1526929989778};\\\", \\\"{x:1442,y:761,t:1526929989802};\\\", \\\"{x:1444,y:761,t:1526929989859};\\\", \\\"{x:1445,y:761,t:1526929989906};\\\", \\\"{x:1446,y:761,t:1526929990354};\\\", \\\"{x:1448,y:761,t:1526929990361};\\\", \\\"{x:1449,y:761,t:1526929990375};\\\", \\\"{x:1455,y:760,t:1526929990392};\\\", \\\"{x:1463,y:760,t:1526929990409};\\\", \\\"{x:1475,y:759,t:1526929990426};\\\", \\\"{x:1483,y:759,t:1526929990442};\\\", \\\"{x:1486,y:759,t:1526929990458};\\\", \\\"{x:1490,y:759,t:1526929990475};\\\", \\\"{x:1491,y:759,t:1526929990506};\\\", \\\"{x:1493,y:759,t:1526929990522};\\\", \\\"{x:1495,y:759,t:1526929990530};\\\", \\\"{x:1496,y:758,t:1526929990542};\\\", \\\"{x:1497,y:758,t:1526929990559};\\\", \\\"{x:1498,y:758,t:1526929990575};\\\", \\\"{x:1499,y:758,t:1526929990611};\\\", \\\"{x:1501,y:758,t:1526929990625};\\\", \\\"{x:1504,y:758,t:1526929990642};\\\", \\\"{x:1510,y:758,t:1526929990659};\\\", \\\"{x:1513,y:758,t:1526929990675};\\\", \\\"{x:1519,y:758,t:1526929990691};\\\", \\\"{x:1527,y:758,t:1526929990709};\\\", \\\"{x:1535,y:758,t:1526929990726};\\\", \\\"{x:1541,y:758,t:1526929990741};\\\", \\\"{x:1548,y:759,t:1526929990758};\\\", \\\"{x:1554,y:759,t:1526929990774};\\\", \\\"{x:1555,y:759,t:1526929990790};\\\", \\\"{x:1557,y:759,t:1526929990808};\\\", \\\"{x:1558,y:759,t:1526929990882};\\\", \\\"{x:1560,y:759,t:1526929990891};\\\", \\\"{x:1563,y:759,t:1526929990908};\\\", \\\"{x:1567,y:759,t:1526929990925};\\\", \\\"{x:1568,y:759,t:1526929990994};\\\", \\\"{x:1570,y:759,t:1526929991010};\\\", \\\"{x:1571,y:759,t:1526929991025};\\\", \\\"{x:1573,y:759,t:1526929991170};\\\", \\\"{x:1574,y:759,t:1526929991202};\\\", \\\"{x:1576,y:759,t:1526929991218};\\\", \\\"{x:1577,y:760,t:1526929991267};\\\", \\\"{x:1579,y:760,t:1526929991290};\\\", \\\"{x:1579,y:761,t:1526929991298};\\\", \\\"{x:1580,y:761,t:1526929991309};\\\", \\\"{x:1583,y:762,t:1526929991326};\\\", \\\"{x:1584,y:762,t:1526929991346};\\\", \\\"{x:1585,y:762,t:1526929991593};\\\", \\\"{x:1586,y:763,t:1526929991665};\\\", \\\"{x:1586,y:764,t:1526929991713};\\\", \\\"{x:1586,y:765,t:1526929991753};\\\", \\\"{x:1585,y:766,t:1526929992449};\\\", \\\"{x:1584,y:766,t:1526929992835};\\\", \\\"{x:1583,y:766,t:1526929992882};\\\", \\\"{x:1582,y:767,t:1526929992898};\\\", \\\"{x:1580,y:767,t:1526930000850};\\\", \\\"{x:1576,y:767,t:1526930000864};\\\", \\\"{x:1559,y:767,t:1526930000881};\\\", \\\"{x:1511,y:774,t:1526930000897};\\\", \\\"{x:1451,y:777,t:1526930000914};\\\", \\\"{x:1362,y:777,t:1526930000930};\\\", \\\"{x:1282,y:777,t:1526930000948};\\\", \\\"{x:1198,y:777,t:1526930000963};\\\", \\\"{x:1115,y:777,t:1526930000980};\\\", \\\"{x:1029,y:777,t:1526930000997};\\\", \\\"{x:959,y:777,t:1526930001013};\\\", \\\"{x:906,y:777,t:1526930001030};\\\", \\\"{x:861,y:777,t:1526930001047};\\\", \\\"{x:828,y:777,t:1526930001063};\\\", \\\"{x:801,y:777,t:1526930001080};\\\", \\\"{x:772,y:777,t:1526930001096};\\\", \\\"{x:755,y:777,t:1526930001113};\\\", \\\"{x:740,y:777,t:1526930001131};\\\", \\\"{x:728,y:777,t:1526930001147};\\\", \\\"{x:714,y:777,t:1526930001164};\\\", \\\"{x:700,y:777,t:1526930001180};\\\", \\\"{x:689,y:777,t:1526930001198};\\\", \\\"{x:676,y:777,t:1526930001214};\\\", \\\"{x:667,y:777,t:1526930001231};\\\", \\\"{x:659,y:777,t:1526930001247};\\\", \\\"{x:650,y:777,t:1526930001264};\\\", \\\"{x:642,y:777,t:1526930001280};\\\", \\\"{x:633,y:776,t:1526930001297};\\\", \\\"{x:628,y:774,t:1526930001314};\\\", \\\"{x:626,y:773,t:1526930001330};\\\", \\\"{x:625,y:771,t:1526930001347};\\\", \\\"{x:622,y:766,t:1526930001365};\\\", \\\"{x:617,y:763,t:1526930001380};\\\", \\\"{x:613,y:760,t:1526930001397};\\\", \\\"{x:611,y:757,t:1526930001414};\\\", \\\"{x:610,y:756,t:1526930001430};\\\", \\\"{x:610,y:755,t:1526930001448};\\\", \\\"{x:609,y:754,t:1526930001464};\\\", \\\"{x:607,y:752,t:1526930001480};\\\", \\\"{x:605,y:749,t:1526930001497};\\\", \\\"{x:604,y:748,t:1526930001515};\\\", \\\"{x:604,y:747,t:1526930001531};\\\", \\\"{x:603,y:747,t:1526930001548};\\\", \\\"{x:601,y:745,t:1526930001565};\\\", \\\"{x:600,y:744,t:1526930001580};\\\", \\\"{x:596,y:742,t:1526930001598};\\\", \\\"{x:593,y:740,t:1526930001615};\\\", \\\"{x:586,y:738,t:1526930001630};\\\", \\\"{x:576,y:736,t:1526930001647};\\\", \\\"{x:564,y:732,t:1526930001664};\\\", \\\"{x:557,y:731,t:1526930001681};\\\", \\\"{x:549,y:729,t:1526930001697};\\\", \\\"{x:547,y:728,t:1526930001714};\\\", \\\"{x:545,y:727,t:1526930001761};\\\", \\\"{x:544,y:727,t:1526930001777};\\\", \\\"{x:543,y:727,t:1526930001786};\\\", \\\"{x:537,y:727,t:1526930001802};\\\", \\\"{x:532,y:727,t:1526930001819};\\\", \\\"{x:529,y:725,t:1526930001836};\\\", \\\"{x:528,y:724,t:1526930001852};\\\", \\\"{x:526,y:724,t:1526930005624};\\\", \\\"{x:525,y:724,t:1526930005647};\\\", \\\"{x:523,y:724,t:1526930012151};\\\", \\\"{x:523,y:725,t:1526930012158};\\\", \\\"{x:521,y:726,t:1526930012175};\\\", \\\"{x:519,y:729,t:1526930012193};\\\", \\\"{x:519,y:731,t:1526930012208};\\\", \\\"{x:518,y:732,t:1526930012225};\\\", \\\"{x:518,y:733,t:1526930012407};\\\" ] }, { \\\"rt\\\": 55391, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 424813, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -I -12 PM-11 AM-05 PM-03 PM-03 PM-03 PM-U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:735,t:1526930016527};\\\", \\\"{x:510,y:740,t:1526930016543};\\\", \\\"{x:505,y:743,t:1526930016560};\\\", \\\"{x:503,y:744,t:1526930016575};\\\", \\\"{x:503,y:745,t:1526930018679};\\\", \\\"{x:514,y:757,t:1526930018694};\\\", \\\"{x:640,y:807,t:1526930018709};\\\", \\\"{x:802,y:862,t:1526930018725};\\\", \\\"{x:1029,y:933,t:1526930018747};\\\", \\\"{x:1150,y:967,t:1526930018763};\\\", \\\"{x:1236,y:978,t:1526930018780};\\\", \\\"{x:1305,y:983,t:1526930018798};\\\", \\\"{x:1382,y:983,t:1526930018814};\\\", \\\"{x:1478,y:962,t:1526930018830};\\\", \\\"{x:1517,y:945,t:1526930018847};\\\", \\\"{x:1536,y:936,t:1526930018864};\\\", \\\"{x:1551,y:927,t:1526930018880};\\\", \\\"{x:1563,y:917,t:1526930018897};\\\", \\\"{x:1580,y:899,t:1526930018915};\\\", \\\"{x:1614,y:863,t:1526930018930};\\\", \\\"{x:1649,y:826,t:1526930018947};\\\", \\\"{x:1685,y:795,t:1526930018964};\\\", \\\"{x:1703,y:776,t:1526930018981};\\\", \\\"{x:1714,y:762,t:1526930018998};\\\", \\\"{x:1718,y:754,t:1526930019014};\\\", \\\"{x:1722,y:742,t:1526930019030};\\\", \\\"{x:1723,y:727,t:1526930019048};\\\", \\\"{x:1724,y:714,t:1526930019064};\\\", \\\"{x:1724,y:706,t:1526930019080};\\\", \\\"{x:1724,y:695,t:1526930019098};\\\", \\\"{x:1719,y:682,t:1526930019115};\\\", \\\"{x:1704,y:666,t:1526930019131};\\\", \\\"{x:1689,y:651,t:1526930019147};\\\", \\\"{x:1671,y:637,t:1526930019165};\\\", \\\"{x:1656,y:626,t:1526930019180};\\\", \\\"{x:1642,y:616,t:1526930019197};\\\", \\\"{x:1612,y:599,t:1526930019214};\\\", \\\"{x:1588,y:590,t:1526930019230};\\\", \\\"{x:1565,y:580,t:1526930019248};\\\", \\\"{x:1544,y:573,t:1526930019265};\\\", \\\"{x:1528,y:568,t:1526930019281};\\\", \\\"{x:1514,y:564,t:1526930019298};\\\", \\\"{x:1503,y:560,t:1526930019315};\\\", \\\"{x:1498,y:558,t:1526930019331};\\\", \\\"{x:1493,y:557,t:1526930019348};\\\", \\\"{x:1491,y:556,t:1526930019365};\\\", \\\"{x:1485,y:556,t:1526930019382};\\\", \\\"{x:1483,y:555,t:1526930019398};\\\", \\\"{x:1481,y:555,t:1526930019414};\\\", \\\"{x:1479,y:553,t:1526930019431};\\\", \\\"{x:1478,y:553,t:1526930019448};\\\", \\\"{x:1475,y:553,t:1526930019464};\\\", \\\"{x:1473,y:552,t:1526930019482};\\\", \\\"{x:1470,y:551,t:1526930019497};\\\", \\\"{x:1466,y:550,t:1526930019515};\\\", \\\"{x:1462,y:549,t:1526930019532};\\\", \\\"{x:1451,y:545,t:1526930019548};\\\", \\\"{x:1434,y:540,t:1526930019565};\\\", \\\"{x:1417,y:535,t:1526930019581};\\\", \\\"{x:1403,y:532,t:1526930019598};\\\", \\\"{x:1384,y:527,t:1526930019615};\\\", \\\"{x:1376,y:523,t:1526930019632};\\\", \\\"{x:1370,y:520,t:1526930019647};\\\", \\\"{x:1365,y:516,t:1526930019665};\\\", \\\"{x:1352,y:512,t:1526930019683};\\\", \\\"{x:1337,y:509,t:1526930019699};\\\", \\\"{x:1326,y:505,t:1526930019715};\\\", \\\"{x:1318,y:501,t:1526930019735};\\\", \\\"{x:1314,y:500,t:1526930019749};\\\", \\\"{x:1310,y:497,t:1526930019765};\\\", \\\"{x:1307,y:496,t:1526930019782};\\\", \\\"{x:1305,y:495,t:1526930019798};\\\", \\\"{x:1304,y:494,t:1526930019815};\\\", \\\"{x:1303,y:494,t:1526930019838};\\\", \\\"{x:1302,y:493,t:1526930019849};\\\", \\\"{x:1301,y:493,t:1526930019864};\\\", \\\"{x:1301,y:492,t:1526930019881};\\\", \\\"{x:1301,y:491,t:1526930021095};\\\", \\\"{x:1303,y:491,t:1526930021256};\\\", \\\"{x:1304,y:491,t:1526930021267};\\\", \\\"{x:1306,y:491,t:1526930021284};\\\", \\\"{x:1308,y:491,t:1526930021300};\\\", \\\"{x:1310,y:491,t:1526930021318};\\\", \\\"{x:1311,y:491,t:1526930021333};\\\", \\\"{x:1312,y:491,t:1526930021350};\\\", \\\"{x:1313,y:491,t:1526930021368};\\\", \\\"{x:1314,y:491,t:1526930021559};\\\", \\\"{x:1315,y:491,t:1526930021575};\\\", \\\"{x:1316,y:491,t:1526930021591};\\\", \\\"{x:1317,y:491,t:1526930021606};\\\", \\\"{x:1318,y:492,t:1526930021617};\\\", \\\"{x:1319,y:492,t:1526930021636};\\\", \\\"{x:1319,y:493,t:1526930021651};\\\", \\\"{x:1320,y:495,t:1526930021667};\\\", \\\"{x:1320,y:497,t:1526930021799};\\\", \\\"{x:1321,y:498,t:1526930021816};\\\", \\\"{x:1322,y:498,t:1526930021834};\\\", \\\"{x:1322,y:499,t:1526930021855};\\\", \\\"{x:1323,y:500,t:1526930021887};\\\", \\\"{x:1325,y:501,t:1526930021943};\\\", \\\"{x:1325,y:503,t:1526930021967};\\\", \\\"{x:1326,y:504,t:1526930021991};\\\", \\\"{x:1326,y:506,t:1526930022006};\\\", \\\"{x:1326,y:507,t:1526930022031};\\\", \\\"{x:1326,y:509,t:1526930022055};\\\", \\\"{x:1327,y:511,t:1526930022071};\\\", \\\"{x:1328,y:511,t:1526930022086};\\\", \\\"{x:1328,y:513,t:1526930022103};\\\", \\\"{x:1328,y:511,t:1526930022829};\\\", \\\"{x:1328,y:510,t:1526930022926};\\\", \\\"{x:1328,y:508,t:1526930022950};\\\", \\\"{x:1328,y:513,t:1526930023070};\\\", \\\"{x:1328,y:520,t:1526930023085};\\\", \\\"{x:1330,y:541,t:1526930023101};\\\", \\\"{x:1332,y:554,t:1526930023118};\\\", \\\"{x:1335,y:571,t:1526930023134};\\\", \\\"{x:1337,y:594,t:1526930023152};\\\", \\\"{x:1337,y:621,t:1526930023168};\\\", \\\"{x:1337,y:649,t:1526930023185};\\\", \\\"{x:1333,y:683,t:1526930023201};\\\", \\\"{x:1333,y:719,t:1526930023219};\\\", \\\"{x:1333,y:749,t:1526930023235};\\\", \\\"{x:1333,y:780,t:1526930023251};\\\", \\\"{x:1333,y:809,t:1526930023269};\\\", \\\"{x:1333,y:832,t:1526930023285};\\\", \\\"{x:1334,y:854,t:1526930023301};\\\", \\\"{x:1336,y:887,t:1526930023319};\\\", \\\"{x:1336,y:908,t:1526930023335};\\\", \\\"{x:1334,y:923,t:1526930023352};\\\", \\\"{x:1334,y:929,t:1526930023369};\\\", \\\"{x:1333,y:934,t:1526930023385};\\\", \\\"{x:1332,y:936,t:1526930023403};\\\", \\\"{x:1332,y:938,t:1526930023419};\\\", \\\"{x:1331,y:938,t:1526930023435};\\\", \\\"{x:1330,y:940,t:1526930023452};\\\", \\\"{x:1330,y:946,t:1526930023469};\\\", \\\"{x:1330,y:950,t:1526930023485};\\\", \\\"{x:1329,y:951,t:1526930023502};\\\", \\\"{x:1329,y:952,t:1526930023575};\\\", \\\"{x:1329,y:955,t:1526930023586};\\\", \\\"{x:1329,y:960,t:1526930023603};\\\", \\\"{x:1329,y:964,t:1526930023620};\\\", \\\"{x:1332,y:971,t:1526930023637};\\\", \\\"{x:1333,y:973,t:1526930023652};\\\", \\\"{x:1336,y:975,t:1526930023669};\\\", \\\"{x:1335,y:975,t:1526930024463};\\\", \\\"{x:1334,y:975,t:1526930024471};\\\", \\\"{x:1328,y:975,t:1526930024485};\\\", \\\"{x:1315,y:974,t:1526930024503};\\\", \\\"{x:1305,y:973,t:1526930024519};\\\", \\\"{x:1300,y:970,t:1526930024535};\\\", \\\"{x:1298,y:970,t:1526930024553};\\\", \\\"{x:1297,y:970,t:1526930024569};\\\", \\\"{x:1297,y:969,t:1526930024646};\\\", \\\"{x:1297,y:968,t:1526930024654};\\\", \\\"{x:1297,y:967,t:1526930024670};\\\", \\\"{x:1297,y:966,t:1526930024686};\\\", \\\"{x:1297,y:965,t:1526930024702};\\\", \\\"{x:1298,y:964,t:1526930024719};\\\", \\\"{x:1299,y:964,t:1526930024737};\\\", \\\"{x:1300,y:964,t:1526930024775};\\\", \\\"{x:1302,y:964,t:1526930024799};\\\", \\\"{x:1303,y:964,t:1526930024815};\\\", \\\"{x:1305,y:964,t:1526930024839};\\\", \\\"{x:1306,y:964,t:1526930024855};\\\", \\\"{x:1308,y:964,t:1526930024870};\\\", \\\"{x:1309,y:964,t:1526930024910};\\\", \\\"{x:1311,y:964,t:1526930025023};\\\", \\\"{x:1313,y:964,t:1526930025038};\\\", \\\"{x:1314,y:962,t:1526930025055};\\\", \\\"{x:1315,y:959,t:1526930025070};\\\", \\\"{x:1316,y:958,t:1526930025087};\\\", \\\"{x:1316,y:954,t:1526930025104};\\\", \\\"{x:1316,y:951,t:1526930025119};\\\", \\\"{x:1316,y:947,t:1526930025137};\\\", \\\"{x:1316,y:944,t:1526930025154};\\\", \\\"{x:1316,y:940,t:1526930025170};\\\", \\\"{x:1316,y:937,t:1526930025187};\\\", \\\"{x:1316,y:934,t:1526930025204};\\\", \\\"{x:1316,y:933,t:1526930025220};\\\", \\\"{x:1316,y:932,t:1526930025237};\\\", \\\"{x:1316,y:930,t:1526930025254};\\\", \\\"{x:1316,y:928,t:1526930025270};\\\", \\\"{x:1316,y:927,t:1526930025287};\\\", \\\"{x:1316,y:926,t:1526930025310};\\\", \\\"{x:1316,y:924,t:1526930025320};\\\", \\\"{x:1316,y:921,t:1526930025337};\\\", \\\"{x:1316,y:918,t:1526930025354};\\\", \\\"{x:1316,y:917,t:1526930025371};\\\", \\\"{x:1316,y:915,t:1526930025391};\\\", \\\"{x:1316,y:914,t:1526930025407};\\\", \\\"{x:1316,y:913,t:1526930025423};\\\", \\\"{x:1316,y:912,t:1526930025437};\\\", \\\"{x:1316,y:907,t:1526930025455};\\\", \\\"{x:1315,y:903,t:1526930025471};\\\", \\\"{x:1312,y:900,t:1526930025487};\\\", \\\"{x:1310,y:897,t:1526930025505};\\\", \\\"{x:1308,y:894,t:1526930025522};\\\", \\\"{x:1304,y:890,t:1526930025538};\\\", \\\"{x:1301,y:887,t:1526930025554};\\\", \\\"{x:1300,y:886,t:1526930025583};\\\", \\\"{x:1300,y:884,t:1526930025599};\\\", \\\"{x:1300,y:883,t:1526930025607};\\\", \\\"{x:1299,y:881,t:1526930025621};\\\", \\\"{x:1298,y:878,t:1526930025638};\\\", \\\"{x:1297,y:876,t:1526930025654};\\\", \\\"{x:1297,y:874,t:1526930025671};\\\", \\\"{x:1297,y:873,t:1526930025688};\\\", \\\"{x:1296,y:873,t:1526930025711};\\\", \\\"{x:1296,y:871,t:1526930025767};\\\", \\\"{x:1297,y:871,t:1526930026071};\\\", \\\"{x:1298,y:871,t:1526930026088};\\\", \\\"{x:1299,y:871,t:1526930026105};\\\", \\\"{x:1300,y:871,t:1526930026121};\\\", \\\"{x:1301,y:871,t:1526930026143};\\\", \\\"{x:1303,y:871,t:1526930026175};\\\", \\\"{x:1304,y:871,t:1526930026191};\\\", \\\"{x:1305,y:871,t:1526930026205};\\\", \\\"{x:1306,y:871,t:1526930026221};\\\", \\\"{x:1309,y:872,t:1526930033279};\\\", \\\"{x:1327,y:867,t:1526930033295};\\\", \\\"{x:1341,y:862,t:1526930033312};\\\", \\\"{x:1344,y:861,t:1526930033328};\\\", \\\"{x:1356,y:863,t:1526930033346};\\\", \\\"{x:1369,y:869,t:1526930033362};\\\", \\\"{x:1417,y:897,t:1526930033378};\\\", \\\"{x:1516,y:963,t:1526930033396};\\\", \\\"{x:1617,y:1019,t:1526930033412};\\\", \\\"{x:1730,y:1069,t:1526930033429};\\\", \\\"{x:1847,y:1126,t:1526930033446};\\\", \\\"{x:1919,y:1199,t:1526930033463};\\\", \\\"{x:1918,y:1199,t:1526930033551};\\\", \\\"{x:1914,y:1199,t:1526930033566};\\\", \\\"{x:1912,y:1197,t:1526930033579};\\\", \\\"{x:1909,y:1194,t:1526930033596};\\\", \\\"{x:1905,y:1189,t:1526930033612};\\\", \\\"{x:1899,y:1182,t:1526930033629};\\\", \\\"{x:1890,y:1172,t:1526930033646};\\\", \\\"{x:1867,y:1152,t:1526930033662};\\\", \\\"{x:1846,y:1137,t:1526930033678};\\\", \\\"{x:1822,y:1117,t:1526930033696};\\\", \\\"{x:1795,y:1096,t:1526930033713};\\\", \\\"{x:1774,y:1080,t:1526930033729};\\\", \\\"{x:1760,y:1070,t:1526930033745};\\\", \\\"{x:1750,y:1063,t:1526930033763};\\\", \\\"{x:1735,y:1052,t:1526930033779};\\\", \\\"{x:1729,y:1047,t:1526930033796};\\\", \\\"{x:1719,y:1039,t:1526930033812};\\\", \\\"{x:1710,y:1030,t:1526930033829};\\\", \\\"{x:1689,y:1003,t:1526930033847};\\\", \\\"{x:1679,y:972,t:1526930033862};\\\", \\\"{x:1669,y:953,t:1526930033880};\\\", \\\"{x:1661,y:942,t:1526930033896};\\\", \\\"{x:1656,y:936,t:1526930033912};\\\", \\\"{x:1652,y:932,t:1526930033929};\\\", \\\"{x:1649,y:930,t:1526930033945};\\\", \\\"{x:1647,y:928,t:1526930033963};\\\", \\\"{x:1646,y:928,t:1526930034023};\\\", \\\"{x:1643,y:928,t:1526930034030};\\\", \\\"{x:1639,y:929,t:1526930034046};\\\", \\\"{x:1627,y:936,t:1526930034062};\\\", \\\"{x:1620,y:941,t:1526930034080};\\\", \\\"{x:1613,y:945,t:1526930034096};\\\", \\\"{x:1605,y:951,t:1526930034113};\\\", \\\"{x:1595,y:958,t:1526930034130};\\\", \\\"{x:1587,y:963,t:1526930034146};\\\", \\\"{x:1584,y:965,t:1526930034163};\\\", \\\"{x:1581,y:967,t:1526930034180};\\\", \\\"{x:1580,y:967,t:1526930034215};\\\", \\\"{x:1580,y:968,t:1526930034229};\\\", \\\"{x:1577,y:972,t:1526930034246};\\\", \\\"{x:1575,y:974,t:1526930034262};\\\", \\\"{x:1574,y:974,t:1526930034279};\\\", \\\"{x:1573,y:974,t:1526930034407};\\\", \\\"{x:1572,y:973,t:1526930034415};\\\", \\\"{x:1571,y:973,t:1526930034430};\\\", \\\"{x:1567,y:967,t:1526930034446};\\\", \\\"{x:1563,y:963,t:1526930034463};\\\", \\\"{x:1559,y:959,t:1526930034480};\\\", \\\"{x:1558,y:958,t:1526930034497};\\\", \\\"{x:1556,y:958,t:1526930034513};\\\", \\\"{x:1554,y:958,t:1526930034879};\\\", \\\"{x:1553,y:958,t:1526930034887};\\\", \\\"{x:1551,y:958,t:1526930034999};\\\", \\\"{x:1550,y:958,t:1526930035031};\\\", \\\"{x:1549,y:958,t:1526930035079};\\\", \\\"{x:1548,y:959,t:1526930035094};\\\", \\\"{x:1547,y:959,t:1526930035175};\\\", \\\"{x:1547,y:960,t:1526930035199};\\\", \\\"{x:1546,y:960,t:1526930035279};\\\", \\\"{x:1544,y:962,t:1526930035438};\\\", \\\"{x:1543,y:962,t:1526930035447};\\\", \\\"{x:1542,y:963,t:1526930035494};\\\", \\\"{x:1541,y:963,t:1526930035502};\\\", \\\"{x:1540,y:963,t:1526930035517};\\\", \\\"{x:1540,y:962,t:1526930036319};\\\", \\\"{x:1540,y:961,t:1526930036331};\\\", \\\"{x:1543,y:959,t:1526930036349};\\\", \\\"{x:1547,y:957,t:1526930036364};\\\", \\\"{x:1549,y:956,t:1526930036382};\\\", \\\"{x:1551,y:955,t:1526930036398};\\\", \\\"{x:1553,y:955,t:1526930036719};\\\", \\\"{x:1554,y:955,t:1526930036732};\\\", \\\"{x:1555,y:955,t:1526930036749};\\\", \\\"{x:1557,y:958,t:1526930036766};\\\", \\\"{x:1563,y:965,t:1526930036782};\\\", \\\"{x:1567,y:970,t:1526930036799};\\\", \\\"{x:1566,y:970,t:1526930037135};\\\", \\\"{x:1565,y:970,t:1526930037148};\\\", \\\"{x:1559,y:967,t:1526930037166};\\\", \\\"{x:1552,y:963,t:1526930037183};\\\", \\\"{x:1549,y:961,t:1526930037199};\\\", \\\"{x:1547,y:959,t:1526930037216};\\\", \\\"{x:1546,y:959,t:1526930037271};\\\", \\\"{x:1545,y:958,t:1526930037295};\\\", \\\"{x:1545,y:957,t:1526930037302};\\\", \\\"{x:1544,y:956,t:1526930037318};\\\", \\\"{x:1543,y:955,t:1526930037351};\\\", \\\"{x:1543,y:954,t:1526930037679};\\\", \\\"{x:1543,y:953,t:1526930037687};\\\", \\\"{x:1543,y:951,t:1526930037700};\\\", \\\"{x:1543,y:950,t:1526930037716};\\\", \\\"{x:1542,y:948,t:1526930037732};\\\", \\\"{x:1541,y:947,t:1526930037750};\\\", \\\"{x:1540,y:947,t:1526930038255};\\\", \\\"{x:1539,y:948,t:1526930038267};\\\", \\\"{x:1539,y:949,t:1526930038287};\\\", \\\"{x:1539,y:950,t:1526930038300};\\\", \\\"{x:1539,y:953,t:1526930038317};\\\", \\\"{x:1539,y:954,t:1526930038335};\\\", \\\"{x:1539,y:955,t:1526930038399};\\\", \\\"{x:1539,y:957,t:1526930038415};\\\", \\\"{x:1539,y:958,t:1526930038422};\\\", \\\"{x:1539,y:959,t:1526930038434};\\\", \\\"{x:1540,y:960,t:1526930038450};\\\", \\\"{x:1541,y:962,t:1526930038467};\\\", \\\"{x:1541,y:963,t:1526930038495};\\\", \\\"{x:1542,y:964,t:1526930038607};\\\", \\\"{x:1542,y:965,t:1526930038919};\\\", \\\"{x:1542,y:966,t:1526930038935};\\\", \\\"{x:1542,y:967,t:1526930038951};\\\", \\\"{x:1543,y:968,t:1526930038968};\\\", \\\"{x:1544,y:968,t:1526930038984};\\\", \\\"{x:1545,y:969,t:1526930039022};\\\", \\\"{x:1545,y:970,t:1526930039079};\\\", \\\"{x:1546,y:970,t:1526930039087};\\\", \\\"{x:1547,y:970,t:1526930039103};\\\", \\\"{x:1549,y:970,t:1526930039118};\\\", \\\"{x:1550,y:970,t:1526930039207};\\\", \\\"{x:1551,y:970,t:1526930039222};\\\", \\\"{x:1552,y:969,t:1526930039271};\\\", \\\"{x:1553,y:968,t:1526930039295};\\\", \\\"{x:1553,y:967,t:1526930039318};\\\", \\\"{x:1554,y:964,t:1526930039335};\\\", \\\"{x:1554,y:963,t:1526930039350};\\\", \\\"{x:1554,y:962,t:1526930039369};\\\", \\\"{x:1555,y:958,t:1526930039385};\\\", \\\"{x:1555,y:953,t:1526930039401};\\\", \\\"{x:1556,y:949,t:1526930039418};\\\", \\\"{x:1557,y:940,t:1526930039435};\\\", \\\"{x:1560,y:931,t:1526930039451};\\\", \\\"{x:1561,y:927,t:1526930039467};\\\", \\\"{x:1564,y:921,t:1526930039485};\\\", \\\"{x:1566,y:917,t:1526930039502};\\\", \\\"{x:1568,y:914,t:1526930039518};\\\", \\\"{x:1569,y:909,t:1526930039535};\\\", \\\"{x:1569,y:904,t:1526930039551};\\\", \\\"{x:1570,y:896,t:1526930039567};\\\", \\\"{x:1572,y:888,t:1526930039584};\\\", \\\"{x:1572,y:881,t:1526930039601};\\\", \\\"{x:1572,y:878,t:1526930039618};\\\", \\\"{x:1572,y:874,t:1526930039634};\\\", \\\"{x:1572,y:871,t:1526930039651};\\\", \\\"{x:1572,y:865,t:1526930039667};\\\", \\\"{x:1572,y:857,t:1526930039684};\\\", \\\"{x:1572,y:853,t:1526930039701};\\\", \\\"{x:1572,y:850,t:1526930039717};\\\", \\\"{x:1572,y:846,t:1526930039734};\\\", \\\"{x:1572,y:845,t:1526930039751};\\\", \\\"{x:1572,y:844,t:1526930039767};\\\", \\\"{x:1572,y:843,t:1526930039879};\\\", \\\"{x:1570,y:843,t:1526930039895};\\\", \\\"{x:1568,y:843,t:1526930039902};\\\", \\\"{x:1566,y:842,t:1526930039918};\\\", \\\"{x:1563,y:841,t:1526930039935};\\\", \\\"{x:1558,y:839,t:1526930039952};\\\", \\\"{x:1556,y:838,t:1526930039975};\\\", \\\"{x:1555,y:837,t:1526930039985};\\\", \\\"{x:1553,y:836,t:1526930040002};\\\", \\\"{x:1548,y:833,t:1526930040019};\\\", \\\"{x:1546,y:832,t:1526930040035};\\\", \\\"{x:1544,y:830,t:1526930040052};\\\", \\\"{x:1543,y:829,t:1526930040070};\\\", \\\"{x:1544,y:829,t:1526930040862};\\\", \\\"{x:1545,y:830,t:1526930040878};\\\", \\\"{x:1546,y:830,t:1526930040983};\\\", \\\"{x:1547,y:830,t:1526930040990};\\\", \\\"{x:1548,y:830,t:1526930041111};\\\", \\\"{x:1542,y:830,t:1526930049999};\\\", \\\"{x:1527,y:827,t:1526930050011};\\\", \\\"{x:1466,y:810,t:1526930050029};\\\", \\\"{x:1297,y:759,t:1526930050045};\\\", \\\"{x:1221,y:730,t:1526930050062};\\\", \\\"{x:974,y:642,t:1526930050079};\\\", \\\"{x:826,y:592,t:1526930050095};\\\", \\\"{x:704,y:554,t:1526930050112};\\\", \\\"{x:607,y:526,t:1526930050129};\\\", \\\"{x:557,y:510,t:1526930050146};\\\", \\\"{x:535,y:508,t:1526930050161};\\\", \\\"{x:532,y:507,t:1526930050171};\\\", \\\"{x:531,y:507,t:1526930050189};\\\", \\\"{x:529,y:507,t:1526930050213};\\\", \\\"{x:527,y:508,t:1526930050222};\\\", \\\"{x:526,y:509,t:1526930050238};\\\", \\\"{x:520,y:514,t:1526930050255};\\\", \\\"{x:520,y:521,t:1526930050273};\\\", \\\"{x:520,y:529,t:1526930050289};\\\", \\\"{x:521,y:538,t:1526930050306};\\\", \\\"{x:532,y:554,t:1526930050323};\\\", \\\"{x:544,y:567,t:1526930050339};\\\", \\\"{x:559,y:577,t:1526930050355};\\\", \\\"{x:573,y:587,t:1526930050373};\\\", \\\"{x:583,y:593,t:1526930050390};\\\", \\\"{x:591,y:597,t:1526930050406};\\\", \\\"{x:593,y:598,t:1526930050422};\\\", \\\"{x:593,y:599,t:1526930050518};\\\", \\\"{x:594,y:600,t:1526930050550};\\\", \\\"{x:595,y:601,t:1526930050566};\\\", \\\"{x:596,y:602,t:1526930050582};\\\", \\\"{x:596,y:603,t:1526930050590};\\\", \\\"{x:599,y:606,t:1526930050607};\\\", \\\"{x:602,y:608,t:1526930050623};\\\", \\\"{x:606,y:611,t:1526930050638};\\\", \\\"{x:608,y:611,t:1526930050950};\\\", \\\"{x:609,y:611,t:1526930050998};\\\", \\\"{x:610,y:612,t:1526930051006};\\\", \\\"{x:611,y:614,t:1526930051022};\\\", \\\"{x:611,y:615,t:1526930051038};\\\", \\\"{x:613,y:617,t:1526930051055};\\\", \\\"{x:615,y:619,t:1526930051870};\\\", \\\"{x:620,y:621,t:1526930051879};\\\", \\\"{x:626,y:624,t:1526930051891};\\\", \\\"{x:650,y:634,t:1526930051907};\\\", \\\"{x:703,y:647,t:1526930051923};\\\", \\\"{x:775,y:668,t:1526930051941};\\\", \\\"{x:865,y:702,t:1526930051957};\\\", \\\"{x:979,y:750,t:1526930051973};\\\", \\\"{x:1047,y:776,t:1526930051991};\\\", \\\"{x:1125,y:796,t:1526930052006};\\\", \\\"{x:1209,y:823,t:1526930052024};\\\", \\\"{x:1264,y:846,t:1526930052040};\\\", \\\"{x:1303,y:863,t:1526930052058};\\\", \\\"{x:1338,y:883,t:1526930052074};\\\", \\\"{x:1370,y:902,t:1526930052091};\\\", \\\"{x:1393,y:913,t:1526930052107};\\\", \\\"{x:1435,y:931,t:1526930052124};\\\", \\\"{x:1488,y:954,t:1526930052141};\\\", \\\"{x:1525,y:972,t:1526930052157};\\\", \\\"{x:1548,y:986,t:1526930052174};\\\", \\\"{x:1557,y:992,t:1526930052191};\\\", \\\"{x:1564,y:997,t:1526930052207};\\\", \\\"{x:1566,y:998,t:1526930052224};\\\", \\\"{x:1567,y:998,t:1526930052241};\\\", \\\"{x:1567,y:997,t:1526930052518};\\\", \\\"{x:1567,y:993,t:1526930052526};\\\", \\\"{x:1567,y:989,t:1526930052541};\\\", \\\"{x:1562,y:972,t:1526930052559};\\\", \\\"{x:1554,y:954,t:1526930052574};\\\", \\\"{x:1544,y:932,t:1526930052592};\\\", \\\"{x:1534,y:910,t:1526930052608};\\\", \\\"{x:1523,y:891,t:1526930052625};\\\", \\\"{x:1515,y:875,t:1526930052641};\\\", \\\"{x:1510,y:864,t:1526930052658};\\\", \\\"{x:1508,y:857,t:1526930052674};\\\", \\\"{x:1507,y:854,t:1526930052691};\\\", \\\"{x:1506,y:851,t:1526930052708};\\\", \\\"{x:1506,y:847,t:1526930052725};\\\", \\\"{x:1504,y:844,t:1526930052741};\\\", \\\"{x:1503,y:837,t:1526930052757};\\\", \\\"{x:1503,y:834,t:1526930052775};\\\", \\\"{x:1502,y:833,t:1526930052791};\\\", \\\"{x:1502,y:831,t:1526930052808};\\\", \\\"{x:1502,y:830,t:1526930052824};\\\", \\\"{x:1502,y:828,t:1526930052870};\\\", \\\"{x:1501,y:827,t:1526930053158};\\\", \\\"{x:1499,y:827,t:1526930053175};\\\", \\\"{x:1498,y:827,t:1526930053192};\\\", \\\"{x:1497,y:827,t:1526930053209};\\\", \\\"{x:1495,y:827,t:1526930053225};\\\", \\\"{x:1494,y:827,t:1526930053246};\\\", \\\"{x:1492,y:827,t:1526930053263};\\\", \\\"{x:1491,y:827,t:1526930053287};\\\", \\\"{x:1489,y:827,t:1526930053295};\\\", \\\"{x:1488,y:827,t:1526930053311};\\\", \\\"{x:1487,y:827,t:1526930053325};\\\", \\\"{x:1486,y:827,t:1526930053383};\\\", \\\"{x:1485,y:827,t:1526930053742};\\\", \\\"{x:1484,y:827,t:1526930053759};\\\", \\\"{x:1483,y:827,t:1526930053776};\\\", \\\"{x:1482,y:828,t:1526930053792};\\\", \\\"{x:1481,y:828,t:1526930053814};\\\", \\\"{x:1480,y:828,t:1526930053826};\\\", \\\"{x:1479,y:829,t:1526930053843};\\\", \\\"{x:1481,y:829,t:1526930054087};\\\", \\\"{x:1486,y:828,t:1526930054094};\\\", \\\"{x:1489,y:826,t:1526930054110};\\\", \\\"{x:1493,y:825,t:1526930054126};\\\", \\\"{x:1495,y:823,t:1526930054142};\\\", \\\"{x:1497,y:823,t:1526930054174};\\\", \\\"{x:1498,y:823,t:1526930054191};\\\", \\\"{x:1500,y:822,t:1526930054198};\\\", \\\"{x:1500,y:821,t:1526930054209};\\\", \\\"{x:1501,y:821,t:1526930054246};\\\", \\\"{x:1504,y:821,t:1526930054279};\\\", \\\"{x:1504,y:820,t:1526930054292};\\\", \\\"{x:1508,y:820,t:1526930054309};\\\", \\\"{x:1514,y:820,t:1526930054326};\\\", \\\"{x:1515,y:820,t:1526930054343};\\\", \\\"{x:1516,y:820,t:1526930054360};\\\", \\\"{x:1517,y:820,t:1526930054376};\\\", \\\"{x:1519,y:822,t:1526930054394};\\\", \\\"{x:1523,y:826,t:1526930054409};\\\", \\\"{x:1526,y:827,t:1526930054426};\\\", \\\"{x:1528,y:829,t:1526930054444};\\\", \\\"{x:1530,y:830,t:1526930054459};\\\", \\\"{x:1531,y:831,t:1526930054476};\\\", \\\"{x:1534,y:832,t:1526930054492};\\\", \\\"{x:1536,y:834,t:1526930054509};\\\", \\\"{x:1540,y:838,t:1526930054525};\\\", \\\"{x:1542,y:840,t:1526930054543};\\\", \\\"{x:1543,y:841,t:1526930054565};\\\", \\\"{x:1544,y:842,t:1526930054605};\\\", \\\"{x:1545,y:843,t:1526930054751};\\\", \\\"{x:1545,y:842,t:1526930054823};\\\", \\\"{x:1545,y:841,t:1526930054838};\\\", \\\"{x:1546,y:841,t:1526930054846};\\\", \\\"{x:1546,y:840,t:1526930054950};\\\", \\\"{x:1546,y:838,t:1526930054961};\\\", \\\"{x:1546,y:835,t:1526930054977};\\\", \\\"{x:1545,y:832,t:1526930054993};\\\", \\\"{x:1544,y:831,t:1526930055010};\\\", \\\"{x:1543,y:830,t:1526930055031};\\\", \\\"{x:1543,y:828,t:1526930055054};\\\", \\\"{x:1543,y:827,t:1526930055095};\\\", \\\"{x:1543,y:825,t:1526930055118};\\\", \\\"{x:1542,y:825,t:1526930057287};\\\", \\\"{x:1540,y:825,t:1526930057296};\\\", \\\"{x:1537,y:825,t:1526930057312};\\\", \\\"{x:1536,y:826,t:1526930057328};\\\", \\\"{x:1535,y:826,t:1526930057345};\\\", \\\"{x:1536,y:826,t:1526930057566};\\\", \\\"{x:1537,y:826,t:1526930057607};\\\", \\\"{x:1539,y:826,t:1526930057638};\\\", \\\"{x:1539,y:827,t:1526930057646};\\\", \\\"{x:1540,y:828,t:1526930057662};\\\", \\\"{x:1542,y:829,t:1526930057678};\\\", \\\"{x:1545,y:832,t:1526930057695};\\\", \\\"{x:1546,y:832,t:1526930057713};\\\", \\\"{x:1548,y:834,t:1526930057729};\\\", \\\"{x:1550,y:834,t:1526930057745};\\\", \\\"{x:1551,y:834,t:1526930057763};\\\", \\\"{x:1552,y:835,t:1526930057782};\\\", \\\"{x:1553,y:835,t:1526930058206};\\\", \\\"{x:1553,y:834,t:1526930058222};\\\", \\\"{x:1553,y:832,t:1526930058248};\\\", \\\"{x:1552,y:831,t:1526930058639};\\\", \\\"{x:1551,y:830,t:1526930058647};\\\", \\\"{x:1549,y:829,t:1526930058662};\\\", \\\"{x:1547,y:827,t:1526930058679};\\\", \\\"{x:1545,y:827,t:1526930058696};\\\", \\\"{x:1544,y:827,t:1526930058717};\\\", \\\"{x:1544,y:826,t:1526930058729};\\\", \\\"{x:1543,y:825,t:1526930058757};\\\", \\\"{x:1543,y:824,t:1526930061479};\\\", \\\"{x:1543,y:823,t:1526930061486};\\\", \\\"{x:1544,y:822,t:1526930061499};\\\", \\\"{x:1544,y:819,t:1526930061516};\\\", \\\"{x:1544,y:815,t:1526930061532};\\\", \\\"{x:1544,y:812,t:1526930061548};\\\", \\\"{x:1544,y:811,t:1526930061565};\\\", \\\"{x:1544,y:809,t:1526930061582};\\\", \\\"{x:1543,y:809,t:1526930061727};\\\", \\\"{x:1541,y:809,t:1526930061734};\\\", \\\"{x:1540,y:809,t:1526930061767};\\\", \\\"{x:1538,y:810,t:1526930061782};\\\", \\\"{x:1537,y:811,t:1526930061799};\\\", \\\"{x:1536,y:812,t:1526930061815};\\\", \\\"{x:1535,y:812,t:1526930061833};\\\", \\\"{x:1534,y:813,t:1526930061848};\\\", \\\"{x:1534,y:815,t:1526930061865};\\\", \\\"{x:1534,y:816,t:1526930061885};\\\", \\\"{x:1533,y:818,t:1526930061901};\\\", \\\"{x:1533,y:819,t:1526930062062};\\\", \\\"{x:1534,y:819,t:1526930062070};\\\", \\\"{x:1535,y:819,t:1526930062093};\\\", \\\"{x:1537,y:819,t:1526930062110};\\\", \\\"{x:1538,y:819,t:1526930062135};\\\", \\\"{x:1539,y:818,t:1526930062150};\\\", \\\"{x:1541,y:817,t:1526930062166};\\\", \\\"{x:1545,y:816,t:1526930062182};\\\", \\\"{x:1547,y:814,t:1526930062199};\\\", \\\"{x:1549,y:812,t:1526930062216};\\\", \\\"{x:1549,y:810,t:1526930062233};\\\", \\\"{x:1549,y:807,t:1526930062249};\\\", \\\"{x:1549,y:802,t:1526930062265};\\\", \\\"{x:1549,y:797,t:1526930062283};\\\", \\\"{x:1549,y:793,t:1526930062299};\\\", \\\"{x:1549,y:789,t:1526930062316};\\\", \\\"{x:1549,y:785,t:1526930062333};\\\", \\\"{x:1549,y:780,t:1526930062350};\\\", \\\"{x:1549,y:778,t:1526930062365};\\\", \\\"{x:1549,y:777,t:1526930062383};\\\", \\\"{x:1549,y:775,t:1526930062406};\\\", \\\"{x:1548,y:774,t:1526930062416};\\\", \\\"{x:1548,y:772,t:1526930062432};\\\", \\\"{x:1547,y:770,t:1526930062450};\\\", \\\"{x:1547,y:768,t:1526930062466};\\\", \\\"{x:1547,y:767,t:1526930062502};\\\", \\\"{x:1547,y:766,t:1526930062830};\\\", \\\"{x:1547,y:765,t:1526930062854};\\\", \\\"{x:1547,y:764,t:1526930062870};\\\", \\\"{x:1546,y:764,t:1526930066700};\\\", \\\"{x:1542,y:764,t:1526930066708};\\\", \\\"{x:1535,y:764,t:1526930066718};\\\", \\\"{x:1521,y:764,t:1526930066734};\\\", \\\"{x:1505,y:762,t:1526930066751};\\\", \\\"{x:1484,y:758,t:1526930066768};\\\", \\\"{x:1460,y:756,t:1526930066783};\\\", \\\"{x:1427,y:751,t:1526930066801};\\\", \\\"{x:1371,y:743,t:1526930066818};\\\", \\\"{x:1317,y:734,t:1526930066834};\\\", \\\"{x:1249,y:719,t:1526930066851};\\\", \\\"{x:1111,y:683,t:1526930066868};\\\", \\\"{x:1025,y:660,t:1526930066884};\\\", \\\"{x:942,y:635,t:1526930066901};\\\", \\\"{x:895,y:623,t:1526930066918};\\\", \\\"{x:861,y:612,t:1526930066934};\\\", \\\"{x:835,y:606,t:1526930066951};\\\", \\\"{x:818,y:605,t:1526930066964};\\\", \\\"{x:802,y:604,t:1526930066981};\\\", \\\"{x:785,y:604,t:1526930066997};\\\", \\\"{x:773,y:604,t:1526930067014};\\\", \\\"{x:759,y:604,t:1526930067031};\\\", \\\"{x:743,y:607,t:1526930067047};\\\", \\\"{x:729,y:612,t:1526930067063};\\\", \\\"{x:717,y:618,t:1526930067081};\\\", \\\"{x:706,y:623,t:1526930067097};\\\", \\\"{x:687,y:633,t:1526930067118};\\\", \\\"{x:672,y:641,t:1526930067135};\\\", \\\"{x:654,y:652,t:1526930067152};\\\", \\\"{x:633,y:662,t:1526930067167};\\\", \\\"{x:613,y:671,t:1526930067185};\\\", \\\"{x:595,y:676,t:1526930067200};\\\", \\\"{x:578,y:679,t:1526930067218};\\\", \\\"{x:558,y:682,t:1526930067235};\\\", \\\"{x:543,y:685,t:1526930067250};\\\", \\\"{x:522,y:685,t:1526930067267};\\\", \\\"{x:513,y:685,t:1526930067285};\\\", \\\"{x:506,y:685,t:1526930067301};\\\", \\\"{x:505,y:685,t:1526930067325};\\\", \\\"{x:504,y:686,t:1526930067335};\\\", \\\"{x:504,y:687,t:1526930067351};\\\", \\\"{x:504,y:690,t:1526930067368};\\\", \\\"{x:504,y:695,t:1526930067385};\\\", \\\"{x:504,y:706,t:1526930067401};\\\", \\\"{x:504,y:720,t:1526930067419};\\\", \\\"{x:509,y:736,t:1526930067435};\\\", \\\"{x:517,y:755,t:1526930067452};\\\", \\\"{x:518,y:759,t:1526930067468};\\\", \\\"{x:520,y:762,t:1526930067485};\\\", \\\"{x:521,y:764,t:1526930067502};\\\", \\\"{x:522,y:764,t:1526930067645};\\\", \\\"{x:522,y:763,t:1526930067660};\\\", \\\"{x:522,y:760,t:1526930067668};\\\", \\\"{x:522,y:755,t:1526930067685};\\\", \\\"{x:522,y:750,t:1526930067703};\\\", \\\"{x:524,y:747,t:1526930067720};\\\", \\\"{x:524,y:746,t:1526930067739};\\\", \\\"{x:525,y:746,t:1526930068924};\\\", \\\"{x:526,y:746,t:1526930068936};\\\", \\\"{x:527,y:746,t:1526930068953};\\\", \\\"{x:528,y:746,t:1526930068972};\\\", \\\"{x:529,y:746,t:1526930068986};\\\", \\\"{x:530,y:746,t:1526930069004};\\\", \\\"{x:531,y:746,t:1526930069036};\\\", \\\"{x:533,y:746,t:1526930069069};\\\", \\\"{x:534,y:746,t:1526930069092};\\\", \\\"{x:535,y:746,t:1526930069103};\\\", \\\"{x:536,y:746,t:1526930069148};\\\", \\\"{x:537,y:746,t:1526930069165};\\\", \\\"{x:538,y:746,t:1526930069172};\\\", \\\"{x:539,y:746,t:1526930069186};\\\", \\\"{x:540,y:745,t:1526930069203};\\\", \\\"{x:543,y:744,t:1526930069220};\\\", \\\"{x:546,y:742,t:1526930069237};\\\", \\\"{x:548,y:742,t:1526930069254};\\\", \\\"{x:549,y:754,t:1526930069342};\\\", \\\"{x:550,y:760,t:1526930069353};\\\", \\\"{x:554,y:774,t:1526930069370};\\\", \\\"{x:562,y:793,t:1526930069385};\\\", \\\"{x:571,y:810,t:1526930069403};\\\" ] }, { \\\"rt\\\": 10517, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 436605, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:709,y:858,t:1526930069585};\\\", \\\"{x:717,y:856,t:1526930069603};\\\", \\\"{x:722,y:855,t:1526930069620};\\\", \\\"{x:726,y:853,t:1526930069637};\\\", \\\"{x:735,y:847,t:1526930069653};\\\", \\\"{x:769,y:828,t:1526930069676};\\\", \\\"{x:779,y:823,t:1526930069686};\\\", \\\"{x:789,y:816,t:1526930069703};\\\", \\\"{x:790,y:816,t:1526930069720};\\\", \\\"{x:791,y:815,t:1526930069737};\\\", \\\"{x:795,y:813,t:1526930069753};\\\", \\\"{x:796,y:812,t:1526930069770};\\\", \\\"{x:797,y:812,t:1526930069787};\\\", \\\"{x:799,y:812,t:1526930069860};\\\", \\\"{x:799,y:811,t:1526930069870};\\\", \\\"{x:800,y:811,t:1526930069900};\\\", \\\"{x:800,y:810,t:1526930069908};\\\", \\\"{x:801,y:809,t:1526930069932};\\\", \\\"{x:802,y:809,t:1526930069948};\\\", \\\"{x:806,y:808,t:1526930071757};\\\", \\\"{x:816,y:805,t:1526930071772};\\\", \\\"{x:889,y:774,t:1526930071788};\\\", \\\"{x:981,y:745,t:1526930071806};\\\", \\\"{x:1068,y:709,t:1526930071822};\\\", \\\"{x:1138,y:678,t:1526930071838};\\\", \\\"{x:1172,y:671,t:1526930071856};\\\", \\\"{x:1187,y:670,t:1526930071872};\\\", \\\"{x:1192,y:669,t:1526930071889};\\\", \\\"{x:1193,y:669,t:1526930071905};\\\", \\\"{x:1194,y:669,t:1526930071924};\\\", \\\"{x:1196,y:668,t:1526930071939};\\\", \\\"{x:1202,y:664,t:1526930071956};\\\", \\\"{x:1209,y:661,t:1526930071972};\\\", \\\"{x:1217,y:657,t:1526930071989};\\\", \\\"{x:1219,y:655,t:1526930072006};\\\", \\\"{x:1221,y:654,t:1526930072022};\\\", \\\"{x:1223,y:653,t:1526930072039};\\\", \\\"{x:1226,y:650,t:1526930072055};\\\", \\\"{x:1231,y:646,t:1526930072073};\\\", \\\"{x:1237,y:640,t:1526930072089};\\\", \\\"{x:1240,y:634,t:1526930072105};\\\", \\\"{x:1241,y:631,t:1526930072123};\\\", \\\"{x:1241,y:625,t:1526930072139};\\\", \\\"{x:1242,y:624,t:1526930072156};\\\", \\\"{x:1246,y:613,t:1526930072172};\\\", \\\"{x:1252,y:602,t:1526930072189};\\\", \\\"{x:1257,y:596,t:1526930072205};\\\", \\\"{x:1258,y:594,t:1526930072223};\\\", \\\"{x:1258,y:593,t:1526930072245};\\\", \\\"{x:1258,y:592,t:1526930072256};\\\", \\\"{x:1259,y:590,t:1526930072273};\\\", \\\"{x:1260,y:587,t:1526930072288};\\\", \\\"{x:1262,y:582,t:1526930072305};\\\", \\\"{x:1263,y:579,t:1526930072322};\\\", \\\"{x:1266,y:575,t:1526930072339};\\\", \\\"{x:1266,y:573,t:1526930072355};\\\", \\\"{x:1268,y:569,t:1526930072372};\\\", \\\"{x:1269,y:567,t:1526930072388};\\\", \\\"{x:1270,y:566,t:1526930072405};\\\", \\\"{x:1272,y:563,t:1526930072423};\\\", \\\"{x:1273,y:562,t:1526930072445};\\\", \\\"{x:1275,y:562,t:1526930072597};\\\", \\\"{x:1277,y:560,t:1526930072608};\\\", \\\"{x:1279,y:560,t:1526930072622};\\\", \\\"{x:1280,y:560,t:1526930072639};\\\", \\\"{x:1286,y:560,t:1526930072655};\\\", \\\"{x:1301,y:560,t:1526930072672};\\\", \\\"{x:1316,y:560,t:1526930072689};\\\", \\\"{x:1332,y:560,t:1526930072705};\\\", \\\"{x:1342,y:560,t:1526930072722};\\\", \\\"{x:1346,y:561,t:1526930072739};\\\", \\\"{x:1347,y:563,t:1526930072804};\\\", \\\"{x:1347,y:566,t:1526930072811};\\\", \\\"{x:1342,y:571,t:1526930072822};\\\", \\\"{x:1317,y:584,t:1526930072839};\\\", \\\"{x:1264,y:605,t:1526930072855};\\\", \\\"{x:1178,y:630,t:1526930072872};\\\", \\\"{x:1102,y:644,t:1526930072890};\\\", \\\"{x:1038,y:653,t:1526930072905};\\\", \\\"{x:991,y:653,t:1526930072923};\\\", \\\"{x:938,y:653,t:1526930072939};\\\", \\\"{x:887,y:653,t:1526930072955};\\\", \\\"{x:844,y:649,t:1526930072972};\\\", \\\"{x:821,y:645,t:1526930072990};\\\", \\\"{x:799,y:641,t:1526930073006};\\\", \\\"{x:783,y:636,t:1526930073022};\\\", \\\"{x:768,y:629,t:1526930073041};\\\", \\\"{x:764,y:626,t:1526930073056};\\\", \\\"{x:763,y:626,t:1526930073072};\\\", \\\"{x:763,y:625,t:1526930073089};\\\", \\\"{x:763,y:624,t:1526930073140};\\\", \\\"{x:763,y:619,t:1526930073156};\\\", \\\"{x:768,y:612,t:1526930073173};\\\", \\\"{x:775,y:606,t:1526930073188};\\\", \\\"{x:779,y:604,t:1526930073206};\\\", \\\"{x:781,y:602,t:1526930073223};\\\", \\\"{x:782,y:601,t:1526930073240};\\\", \\\"{x:780,y:598,t:1526930073269};\\\", \\\"{x:775,y:595,t:1526930073276};\\\", \\\"{x:765,y:591,t:1526930073289};\\\", \\\"{x:736,y:580,t:1526930073306};\\\", \\\"{x:677,y:561,t:1526930073324};\\\", \\\"{x:566,y:543,t:1526930073340};\\\", \\\"{x:497,y:535,t:1526930073357};\\\", \\\"{x:430,y:535,t:1526930073373};\\\", \\\"{x:385,y:535,t:1526930073389};\\\", \\\"{x:353,y:535,t:1526930073406};\\\", \\\"{x:339,y:537,t:1526930073423};\\\", \\\"{x:337,y:538,t:1526930073440};\\\", \\\"{x:334,y:539,t:1526930073456};\\\", \\\"{x:334,y:540,t:1526930073473};\\\", \\\"{x:332,y:541,t:1526930073489};\\\", \\\"{x:331,y:541,t:1526930073516};\\\", \\\"{x:330,y:541,t:1526930073523};\\\", \\\"{x:329,y:542,t:1526930073539};\\\", \\\"{x:327,y:545,t:1526930073556};\\\", \\\"{x:327,y:549,t:1526930073573};\\\", \\\"{x:327,y:553,t:1526930073590};\\\", \\\"{x:329,y:561,t:1526930073607};\\\", \\\"{x:333,y:568,t:1526930073623};\\\", \\\"{x:335,y:573,t:1526930073640};\\\", \\\"{x:337,y:580,t:1526930073656};\\\", \\\"{x:337,y:583,t:1526930073673};\\\", \\\"{x:338,y:585,t:1526930073690};\\\", \\\"{x:338,y:586,t:1526930073707};\\\", \\\"{x:338,y:588,t:1526930073723};\\\", \\\"{x:338,y:592,t:1526930073740};\\\", \\\"{x:336,y:593,t:1526930073757};\\\", \\\"{x:334,y:595,t:1526930073773};\\\", \\\"{x:327,y:596,t:1526930073790};\\\", \\\"{x:316,y:596,t:1526930073807};\\\", \\\"{x:302,y:596,t:1526930073823};\\\", \\\"{x:282,y:596,t:1526930073840};\\\", \\\"{x:264,y:596,t:1526930073857};\\\", \\\"{x:247,y:594,t:1526930073873};\\\", \\\"{x:239,y:593,t:1526930073891};\\\", \\\"{x:227,y:592,t:1526930073907};\\\", \\\"{x:223,y:591,t:1526930073924};\\\", \\\"{x:219,y:590,t:1526930073941};\\\", \\\"{x:215,y:590,t:1526930073956};\\\", \\\"{x:207,y:591,t:1526930073973};\\\", \\\"{x:202,y:591,t:1526930073990};\\\", \\\"{x:189,y:591,t:1526930074006};\\\", \\\"{x:180,y:591,t:1526930074023};\\\", \\\"{x:169,y:589,t:1526930074041};\\\", \\\"{x:165,y:586,t:1526930074058};\\\", \\\"{x:160,y:586,t:1526930074073};\\\", \\\"{x:157,y:586,t:1526930074090};\\\", \\\"{x:153,y:586,t:1526930074107};\\\", \\\"{x:152,y:586,t:1526930074122};\\\", \\\"{x:151,y:586,t:1526930074164};\\\", \\\"{x:151,y:588,t:1526930074187};\\\", \\\"{x:151,y:590,t:1526930074196};\\\", \\\"{x:154,y:596,t:1526930074207};\\\", \\\"{x:160,y:606,t:1526930074224};\\\", \\\"{x:163,y:614,t:1526930074241};\\\", \\\"{x:164,y:619,t:1526930074257};\\\", \\\"{x:167,y:621,t:1526930074274};\\\", \\\"{x:174,y:625,t:1526930074291};\\\", \\\"{x:176,y:628,t:1526930074308};\\\", \\\"{x:178,y:630,t:1526930074323};\\\", \\\"{x:178,y:637,t:1526930074341};\\\", \\\"{x:177,y:644,t:1526930074358};\\\", \\\"{x:177,y:650,t:1526930074373};\\\", \\\"{x:179,y:657,t:1526930074390};\\\", \\\"{x:192,y:664,t:1526930074407};\\\", \\\"{x:202,y:667,t:1526930074424};\\\", \\\"{x:209,y:667,t:1526930074440};\\\", \\\"{x:223,y:667,t:1526930074457};\\\", \\\"{x:246,y:667,t:1526930074474};\\\", \\\"{x:293,y:667,t:1526930074493};\\\", \\\"{x:382,y:667,t:1526930074507};\\\", \\\"{x:518,y:667,t:1526930074524};\\\", \\\"{x:584,y:672,t:1526930074540};\\\", \\\"{x:611,y:674,t:1526930074557};\\\", \\\"{x:625,y:674,t:1526930074574};\\\", \\\"{x:632,y:674,t:1526930074590};\\\", \\\"{x:638,y:671,t:1526930074607};\\\", \\\"{x:644,y:668,t:1526930074624};\\\", \\\"{x:648,y:664,t:1526930074640};\\\", \\\"{x:651,y:661,t:1526930074657};\\\", \\\"{x:653,y:658,t:1526930074674};\\\", \\\"{x:654,y:653,t:1526930074690};\\\", \\\"{x:654,y:646,t:1526930074707};\\\", \\\"{x:643,y:627,t:1526930074725};\\\", \\\"{x:631,y:610,t:1526930074741};\\\", \\\"{x:621,y:593,t:1526930074758};\\\", \\\"{x:615,y:577,t:1526930074774};\\\", \\\"{x:610,y:565,t:1526930074791};\\\", \\\"{x:608,y:557,t:1526930074808};\\\", \\\"{x:608,y:553,t:1526930074825};\\\", \\\"{x:608,y:549,t:1526930074842};\\\", \\\"{x:608,y:545,t:1526930074857};\\\", \\\"{x:618,y:537,t:1526930074874};\\\", \\\"{x:628,y:527,t:1526930074891};\\\", \\\"{x:629,y:526,t:1526930074907};\\\", \\\"{x:629,y:525,t:1526930075045};\\\", \\\"{x:629,y:524,t:1526930075204};\\\", \\\"{x:629,y:523,t:1526930075212};\\\", \\\"{x:629,y:520,t:1526930075224};\\\", \\\"{x:628,y:518,t:1526930075241};\\\", \\\"{x:623,y:515,t:1526930075259};\\\", \\\"{x:618,y:511,t:1526930075274};\\\", \\\"{x:614,y:507,t:1526930075291};\\\", \\\"{x:608,y:501,t:1526930075307};\\\", \\\"{x:605,y:498,t:1526930075324};\\\", \\\"{x:604,y:496,t:1526930075342};\\\", \\\"{x:603,y:495,t:1526930075372};\\\", \\\"{x:604,y:494,t:1526930075517};\\\", \\\"{x:606,y:494,t:1526930075524};\\\", \\\"{x:607,y:495,t:1526930075541};\\\", \\\"{x:608,y:496,t:1526930075558};\\\", \\\"{x:620,y:500,t:1526930076108};\\\", \\\"{x:671,y:516,t:1526930076126};\\\", \\\"{x:725,y:536,t:1526930076144};\\\", \\\"{x:773,y:560,t:1526930076159};\\\", \\\"{x:808,y:580,t:1526930076176};\\\", \\\"{x:828,y:593,t:1526930076192};\\\", \\\"{x:847,y:600,t:1526930076208};\\\", \\\"{x:849,y:601,t:1526930076226};\\\", \\\"{x:851,y:601,t:1526930076242};\\\", \\\"{x:853,y:601,t:1526930076324};\\\", \\\"{x:854,y:600,t:1526930076345};\\\", \\\"{x:854,y:591,t:1526930076360};\\\", \\\"{x:854,y:587,t:1526930076375};\\\", \\\"{x:854,y:583,t:1526930076392};\\\", \\\"{x:854,y:580,t:1526930076408};\\\", \\\"{x:853,y:574,t:1526930076424};\\\", \\\"{x:852,y:572,t:1526930076442};\\\", \\\"{x:851,y:568,t:1526930076458};\\\", \\\"{x:851,y:565,t:1526930076475};\\\", \\\"{x:848,y:558,t:1526930076492};\\\", \\\"{x:847,y:553,t:1526930076508};\\\", \\\"{x:845,y:550,t:1526930076525};\\\", \\\"{x:843,y:548,t:1526930076543};\\\", \\\"{x:842,y:547,t:1526930076558};\\\", \\\"{x:840,y:545,t:1526930076575};\\\", \\\"{x:836,y:541,t:1526930076592};\\\", \\\"{x:833,y:537,t:1526930076609};\\\", \\\"{x:831,y:536,t:1526930076625};\\\", \\\"{x:830,y:537,t:1526930077732};\\\", \\\"{x:829,y:539,t:1526930077744};\\\", \\\"{x:828,y:539,t:1526930077759};\\\", \\\"{x:828,y:542,t:1526930077776};\\\", \\\"{x:827,y:543,t:1526930077793};\\\", \\\"{x:826,y:545,t:1526930077811};\\\", \\\"{x:825,y:546,t:1526930077852};\\\", \\\"{x:824,y:546,t:1526930077868};\\\", \\\"{x:824,y:547,t:1526930077876};\\\", \\\"{x:824,y:548,t:1526930077893};\\\", \\\"{x:822,y:550,t:1526930077911};\\\", \\\"{x:821,y:552,t:1526930077926};\\\", \\\"{x:819,y:554,t:1526930077943};\\\", \\\"{x:818,y:555,t:1526930077960};\\\", \\\"{x:817,y:559,t:1526930077977};\\\", \\\"{x:813,y:562,t:1526930077993};\\\", \\\"{x:810,y:567,t:1526930078011};\\\", \\\"{x:805,y:572,t:1526930078026};\\\", \\\"{x:795,y:579,t:1526930078043};\\\", \\\"{x:787,y:581,t:1526930078059};\\\", \\\"{x:775,y:584,t:1526930078076};\\\", \\\"{x:756,y:590,t:1526930078094};\\\", \\\"{x:737,y:594,t:1526930078111};\\\", \\\"{x:718,y:596,t:1526930078126};\\\", \\\"{x:696,y:603,t:1526930078144};\\\", \\\"{x:678,y:605,t:1526930078160};\\\", \\\"{x:658,y:607,t:1526930078176};\\\", \\\"{x:647,y:610,t:1526930078193};\\\", \\\"{x:638,y:611,t:1526930078211};\\\", \\\"{x:634,y:612,t:1526930078227};\\\", \\\"{x:630,y:615,t:1526930078243};\\\", \\\"{x:626,y:622,t:1526930078260};\\\", \\\"{x:625,y:633,t:1526930078278};\\\", \\\"{x:636,y:645,t:1526930078297};\\\", \\\"{x:687,y:680,t:1526930078327};\\\", \\\"{x:697,y:687,t:1526930078331};\\\", \\\"{x:706,y:692,t:1526930078343};\\\", \\\"{x:722,y:702,t:1526930078360};\\\", \\\"{x:731,y:709,t:1526930078376};\\\", \\\"{x:735,y:717,t:1526930078393};\\\", \\\"{x:738,y:726,t:1526930078411};\\\", \\\"{x:737,y:735,t:1526930078427};\\\", \\\"{x:735,y:739,t:1526930078443};\\\", \\\"{x:733,y:741,t:1526930078460};\\\", \\\"{x:728,y:744,t:1526930078477};\\\", \\\"{x:724,y:747,t:1526930078493};\\\", \\\"{x:717,y:750,t:1526930078510};\\\", \\\"{x:706,y:753,t:1526930078528};\\\", \\\"{x:695,y:756,t:1526930078543};\\\", \\\"{x:685,y:759,t:1526930078560};\\\", \\\"{x:678,y:760,t:1526930078577};\\\", \\\"{x:674,y:762,t:1526930078593};\\\", \\\"{x:672,y:763,t:1526930078610};\\\", \\\"{x:670,y:763,t:1526930078627};\\\", \\\"{x:668,y:764,t:1526930078644};\\\", \\\"{x:667,y:765,t:1526930078684};\\\", \\\"{x:665,y:766,t:1526930078700};\\\", \\\"{x:663,y:766,t:1526930078724};\\\", \\\"{x:662,y:767,t:1526930078732};\\\", \\\"{x:661,y:767,t:1526930078745};\\\", \\\"{x:659,y:769,t:1526930078760};\\\", \\\"{x:655,y:770,t:1526930078778};\\\", \\\"{x:652,y:770,t:1526930078795};\\\", \\\"{x:651,y:772,t:1526930078810};\\\", \\\"{x:649,y:772,t:1526930078828};\\\", \\\"{x:648,y:773,t:1526930078845};\\\", \\\"{x:647,y:773,t:1526930078861};\\\", \\\"{x:645,y:774,t:1526930078878};\\\", \\\"{x:643,y:775,t:1526930078895};\\\", \\\"{x:642,y:776,t:1526930078911};\\\", \\\"{x:638,y:777,t:1526930078930};\\\", \\\"{x:635,y:779,t:1526930078950};\\\", \\\"{x:634,y:780,t:1526930078961};\\\", \\\"{x:632,y:781,t:1526930078977};\\\", \\\"{x:631,y:781,t:1526930079309};\\\", \\\"{x:628,y:781,t:1526930079316};\\\", \\\"{x:623,y:779,t:1526930079327};\\\", \\\"{x:606,y:768,t:1526930079344};\\\", \\\"{x:586,y:753,t:1526930079361};\\\", \\\"{x:569,y:743,t:1526930079377};\\\", \\\"{x:555,y:738,t:1526930079397};\\\", \\\"{x:540,y:733,t:1526930079411};\\\", \\\"{x:539,y:733,t:1526930079428};\\\", \\\"{x:537,y:733,t:1526930079443};\\\", \\\"{x:536,y:733,t:1526930079507};\\\", \\\"{x:535,y:733,t:1526930079515};\\\", \\\"{x:534,y:733,t:1526930079526};\\\", \\\"{x:532,y:733,t:1526930079543};\\\", \\\"{x:529,y:734,t:1526930079559};\\\", \\\"{x:525,y:735,t:1526930079576};\\\", \\\"{x:523,y:736,t:1526930079593};\\\", \\\"{x:522,y:737,t:1526930079610};\\\", \\\"{x:521,y:738,t:1526930079626};\\\", \\\"{x:520,y:738,t:1526930079643};\\\", \\\"{x:520,y:739,t:1526930079660};\\\", \\\"{x:519,y:740,t:1526930079675};\\\", \\\"{x:518,y:741,t:1526930079699};\\\", \\\"{x:518,y:743,t:1526930079740};\\\", \\\"{x:518,y:744,t:1526930079845};\\\" ] }, { \\\"rt\\\": 15710, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 453561, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:743,t:1526930087613};\\\", \\\"{x:534,y:739,t:1526930087621};\\\", \\\"{x:546,y:737,t:1526930087638};\\\", \\\"{x:577,y:737,t:1526930087655};\\\", \\\"{x:641,y:737,t:1526930087671};\\\", \\\"{x:721,y:737,t:1526930087684};\\\", \\\"{x:805,y:737,t:1526930087700};\\\", \\\"{x:896,y:737,t:1526930087717};\\\", \\\"{x:988,y:737,t:1526930087735};\\\", \\\"{x:1074,y:737,t:1526930087751};\\\", \\\"{x:1141,y:737,t:1526930087767};\\\", \\\"{x:1183,y:737,t:1526930087784};\\\", \\\"{x:1213,y:732,t:1526930087800};\\\", \\\"{x:1230,y:727,t:1526930087818};\\\", \\\"{x:1233,y:726,t:1526930087835};\\\", \\\"{x:1235,y:725,t:1526930087851};\\\", \\\"{x:1235,y:724,t:1526930087901};\\\", \\\"{x:1235,y:723,t:1526930087908};\\\", \\\"{x:1235,y:721,t:1526930087918};\\\", \\\"{x:1234,y:720,t:1526930087940};\\\", \\\"{x:1233,y:720,t:1526930087953};\\\", \\\"{x:1225,y:717,t:1526930087968};\\\", \\\"{x:1215,y:717,t:1526930087985};\\\", \\\"{x:1205,y:717,t:1526930088002};\\\", \\\"{x:1197,y:716,t:1526930088017};\\\", \\\"{x:1192,y:716,t:1526930088035};\\\", \\\"{x:1181,y:712,t:1526930088052};\\\", \\\"{x:1177,y:711,t:1526930088068};\\\", \\\"{x:1176,y:711,t:1526930088108};\\\", \\\"{x:1175,y:711,t:1526930088118};\\\", \\\"{x:1175,y:709,t:1526930088189};\\\", \\\"{x:1175,y:708,t:1526930088220};\\\", \\\"{x:1175,y:707,t:1526930088236};\\\", \\\"{x:1175,y:706,t:1526930088252};\\\", \\\"{x:1175,y:705,t:1526930088268};\\\", \\\"{x:1175,y:703,t:1526930088285};\\\", \\\"{x:1178,y:701,t:1526930088303};\\\", \\\"{x:1179,y:700,t:1526930088319};\\\", \\\"{x:1180,y:699,t:1526930089541};\\\", \\\"{x:1182,y:699,t:1526930089553};\\\", \\\"{x:1193,y:694,t:1526930089569};\\\", \\\"{x:1213,y:688,t:1526930089585};\\\", \\\"{x:1230,y:684,t:1526930089602};\\\", \\\"{x:1239,y:683,t:1526930089619};\\\", \\\"{x:1240,y:683,t:1526930089636};\\\", \\\"{x:1241,y:683,t:1526930089692};\\\", \\\"{x:1243,y:682,t:1526930089703};\\\", \\\"{x:1243,y:681,t:1526930089719};\\\", \\\"{x:1244,y:681,t:1526930089836};\\\", \\\"{x:1245,y:680,t:1526930089853};\\\", \\\"{x:1246,y:680,t:1526930089892};\\\", \\\"{x:1248,y:680,t:1526930089904};\\\", \\\"{x:1261,y:686,t:1526930089921};\\\", \\\"{x:1281,y:696,t:1526930089936};\\\", \\\"{x:1293,y:701,t:1526930089953};\\\", \\\"{x:1302,y:703,t:1526930089970};\\\", \\\"{x:1314,y:707,t:1526930089986};\\\", \\\"{x:1316,y:708,t:1526930090003};\\\", \\\"{x:1317,y:708,t:1526930090020};\\\", \\\"{x:1318,y:708,t:1526930090036};\\\", \\\"{x:1324,y:708,t:1526930090053};\\\", \\\"{x:1338,y:704,t:1526930090071};\\\", \\\"{x:1362,y:690,t:1526930090086};\\\", \\\"{x:1387,y:678,t:1526930090103};\\\", \\\"{x:1406,y:669,t:1526930090119};\\\", \\\"{x:1415,y:666,t:1526930090136};\\\", \\\"{x:1419,y:665,t:1526930090153};\\\", \\\"{x:1420,y:665,t:1526930090170};\\\", \\\"{x:1421,y:665,t:1526930090260};\\\", \\\"{x:1422,y:665,t:1526930090277};\\\", \\\"{x:1423,y:665,t:1526930090287};\\\", \\\"{x:1423,y:666,t:1526930090304};\\\", \\\"{x:1423,y:668,t:1526930090320};\\\", \\\"{x:1423,y:671,t:1526930090337};\\\", \\\"{x:1421,y:675,t:1526930090353};\\\", \\\"{x:1418,y:680,t:1526930090370};\\\", \\\"{x:1416,y:686,t:1526930090387};\\\", \\\"{x:1412,y:694,t:1526930090404};\\\", \\\"{x:1410,y:698,t:1526930090420};\\\", \\\"{x:1409,y:698,t:1526930090437};\\\", \\\"{x:1409,y:697,t:1526930090628};\\\", \\\"{x:1409,y:696,t:1526930090637};\\\", \\\"{x:1407,y:694,t:1526930090654};\\\", \\\"{x:1406,y:693,t:1526930090670};\\\", \\\"{x:1406,y:692,t:1526930090700};\\\", \\\"{x:1405,y:691,t:1526930090708};\\\", \\\"{x:1405,y:690,t:1526930090764};\\\", \\\"{x:1408,y:687,t:1526930090772};\\\", \\\"{x:1412,y:685,t:1526930090787};\\\", \\\"{x:1422,y:680,t:1526930090805};\\\", \\\"{x:1423,y:678,t:1526930090821};\\\", \\\"{x:1423,y:679,t:1526930090924};\\\", \\\"{x:1421,y:679,t:1526930090940};\\\", \\\"{x:1420,y:680,t:1526930090956};\\\", \\\"{x:1419,y:681,t:1526930090970};\\\", \\\"{x:1417,y:682,t:1526930090987};\\\", \\\"{x:1414,y:683,t:1526930091005};\\\", \\\"{x:1410,y:683,t:1526930091116};\\\", \\\"{x:1401,y:679,t:1526930091124};\\\", \\\"{x:1389,y:674,t:1526930091137};\\\", \\\"{x:1353,y:659,t:1526930091155};\\\", \\\"{x:1295,y:633,t:1526930091171};\\\", \\\"{x:1226,y:604,t:1526930091187};\\\", \\\"{x:1117,y:560,t:1526930091203};\\\", \\\"{x:1049,y:533,t:1526930091220};\\\", \\\"{x:1002,y:513,t:1526930091237};\\\", \\\"{x:979,y:503,t:1526930091253};\\\", \\\"{x:966,y:497,t:1526930091270};\\\", \\\"{x:961,y:495,t:1526930091287};\\\", \\\"{x:960,y:494,t:1526930091304};\\\", \\\"{x:959,y:494,t:1526930091363};\\\", \\\"{x:957,y:494,t:1526930091380};\\\", \\\"{x:956,y:494,t:1526930091388};\\\", \\\"{x:954,y:494,t:1526930091403};\\\", \\\"{x:953,y:494,t:1526930091421};\\\", \\\"{x:951,y:494,t:1526930091436};\\\", \\\"{x:950,y:494,t:1526930091621};\\\", \\\"{x:943,y:494,t:1526930091638};\\\", \\\"{x:940,y:494,t:1526930091654};\\\", \\\"{x:939,y:494,t:1526930091671};\\\", \\\"{x:937,y:494,t:1526930091687};\\\", \\\"{x:936,y:494,t:1526930091703};\\\", \\\"{x:935,y:494,t:1526930091721};\\\", \\\"{x:934,y:494,t:1526930091738};\\\", \\\"{x:933,y:494,t:1526930091753};\\\", \\\"{x:932,y:494,t:1526930091770};\\\", \\\"{x:928,y:494,t:1526930091787};\\\", \\\"{x:926,y:494,t:1526930091804};\\\", \\\"{x:923,y:494,t:1526930091820};\\\", \\\"{x:914,y:495,t:1526930091838};\\\", \\\"{x:904,y:498,t:1526930091855};\\\", \\\"{x:886,y:499,t:1526930091871};\\\", \\\"{x:864,y:503,t:1526930091888};\\\", \\\"{x:840,y:505,t:1526930091905};\\\", \\\"{x:820,y:509,t:1526930091922};\\\", \\\"{x:799,y:510,t:1526930091937};\\\", \\\"{x:783,y:510,t:1526930091955};\\\", \\\"{x:775,y:511,t:1526930091971};\\\", \\\"{x:770,y:511,t:1526930091988};\\\", \\\"{x:769,y:511,t:1526930092005};\\\", \\\"{x:767,y:511,t:1526930092020};\\\", \\\"{x:765,y:511,t:1526930092038};\\\", \\\"{x:760,y:511,t:1526930092054};\\\", \\\"{x:753,y:511,t:1526930092071};\\\", \\\"{x:743,y:511,t:1526930092088};\\\", \\\"{x:729,y:511,t:1526930092105};\\\", \\\"{x:714,y:511,t:1526930092122};\\\", \\\"{x:696,y:511,t:1526930092137};\\\", \\\"{x:681,y:511,t:1526930092155};\\\", \\\"{x:669,y:511,t:1526930092171};\\\", \\\"{x:655,y:511,t:1526930092188};\\\", \\\"{x:646,y:511,t:1526930092205};\\\", \\\"{x:632,y:511,t:1526930092222};\\\", \\\"{x:617,y:511,t:1526930092237};\\\", \\\"{x:608,y:511,t:1526930092254};\\\", \\\"{x:595,y:511,t:1526930092272};\\\", \\\"{x:588,y:511,t:1526930092287};\\\", \\\"{x:582,y:512,t:1526930092304};\\\", \\\"{x:578,y:513,t:1526930092322};\\\", \\\"{x:575,y:514,t:1526930092337};\\\", \\\"{x:573,y:514,t:1526930092355};\\\", \\\"{x:570,y:516,t:1526930092371};\\\", \\\"{x:568,y:518,t:1526930092388};\\\", \\\"{x:565,y:519,t:1526930092404};\\\", \\\"{x:562,y:520,t:1526930092421};\\\", \\\"{x:558,y:524,t:1526930092438};\\\", \\\"{x:552,y:528,t:1526930092456};\\\", \\\"{x:548,y:531,t:1526930092472};\\\", \\\"{x:543,y:535,t:1526930092487};\\\", \\\"{x:539,y:539,t:1526930092505};\\\", \\\"{x:534,y:544,t:1526930092522};\\\", \\\"{x:530,y:548,t:1526930092538};\\\", \\\"{x:529,y:551,t:1526930092555};\\\", \\\"{x:527,y:558,t:1526930092572};\\\", \\\"{x:527,y:562,t:1526930092588};\\\", \\\"{x:526,y:565,t:1526930092606};\\\", \\\"{x:524,y:569,t:1526930092622};\\\", \\\"{x:523,y:572,t:1526930092639};\\\", \\\"{x:519,y:576,t:1526930092655};\\\", \\\"{x:517,y:577,t:1526930092671};\\\", \\\"{x:516,y:579,t:1526930092688};\\\", \\\"{x:513,y:581,t:1526930092705};\\\", \\\"{x:510,y:582,t:1526930092721};\\\", \\\"{x:500,y:583,t:1526930092738};\\\", \\\"{x:478,y:583,t:1526930092755};\\\", \\\"{x:437,y:580,t:1526930092772};\\\", \\\"{x:398,y:571,t:1526930092788};\\\", \\\"{x:356,y:557,t:1526930092805};\\\", \\\"{x:324,y:546,t:1526930092822};\\\", \\\"{x:307,y:539,t:1526930092839};\\\", \\\"{x:298,y:534,t:1526930092854};\\\", \\\"{x:294,y:530,t:1526930092872};\\\", \\\"{x:292,y:528,t:1526930092889};\\\", \\\"{x:291,y:528,t:1526930092916};\\\", \\\"{x:290,y:528,t:1526930092924};\\\", \\\"{x:288,y:528,t:1526930092939};\\\", \\\"{x:285,y:528,t:1526930092956};\\\", \\\"{x:282,y:528,t:1526930092972};\\\", \\\"{x:281,y:529,t:1526930092989};\\\", \\\"{x:280,y:529,t:1526930093006};\\\", \\\"{x:277,y:532,t:1526930093022};\\\", \\\"{x:276,y:539,t:1526930093039};\\\", \\\"{x:273,y:543,t:1526930093055};\\\", \\\"{x:267,y:548,t:1526930093073};\\\", \\\"{x:262,y:551,t:1526930093089};\\\", \\\"{x:261,y:552,t:1526930093106};\\\", \\\"{x:258,y:553,t:1526930093122};\\\", \\\"{x:249,y:555,t:1526930093139};\\\", \\\"{x:216,y:560,t:1526930093157};\\\", \\\"{x:186,y:560,t:1526930093173};\\\", \\\"{x:160,y:558,t:1526930093189};\\\", \\\"{x:141,y:554,t:1526930093206};\\\", \\\"{x:129,y:549,t:1526930093222};\\\", \\\"{x:128,y:549,t:1526930093239};\\\", \\\"{x:128,y:548,t:1526930093267};\\\", \\\"{x:128,y:547,t:1526930093300};\\\", \\\"{x:129,y:546,t:1526930093307};\\\", \\\"{x:133,y:544,t:1526930093322};\\\", \\\"{x:137,y:542,t:1526930093339};\\\", \\\"{x:139,y:541,t:1526930093356};\\\", \\\"{x:140,y:541,t:1526930093411};\\\", \\\"{x:140,y:540,t:1526930093516};\\\", \\\"{x:141,y:540,t:1526930093564};\\\", \\\"{x:143,y:538,t:1526930093884};\\\", \\\"{x:146,y:538,t:1526930093891};\\\", \\\"{x:155,y:536,t:1526930093909};\\\", \\\"{x:162,y:536,t:1526930093923};\\\", \\\"{x:191,y:536,t:1526930093939};\\\", \\\"{x:215,y:536,t:1526930093956};\\\", \\\"{x:269,y:541,t:1526930093972};\\\", \\\"{x:342,y:545,t:1526930093990};\\\", \\\"{x:417,y:545,t:1526930094006};\\\", \\\"{x:466,y:546,t:1526930094022};\\\", \\\"{x:499,y:550,t:1526930094040};\\\", \\\"{x:527,y:550,t:1526930094056};\\\", \\\"{x:559,y:550,t:1526930094072};\\\", \\\"{x:618,y:546,t:1526930094090};\\\", \\\"{x:671,y:538,t:1526930094106};\\\", \\\"{x:699,y:535,t:1526930094123};\\\", \\\"{x:734,y:534,t:1526930094140};\\\", \\\"{x:751,y:530,t:1526930094156};\\\", \\\"{x:772,y:525,t:1526930094173};\\\", \\\"{x:796,y:519,t:1526930094190};\\\", \\\"{x:804,y:517,t:1526930094206};\\\", \\\"{x:808,y:514,t:1526930094222};\\\", \\\"{x:810,y:513,t:1526930094240};\\\", \\\"{x:812,y:512,t:1526930094257};\\\", \\\"{x:814,y:510,t:1526930094273};\\\", \\\"{x:817,y:508,t:1526930094290};\\\", \\\"{x:818,y:507,t:1526930094380};\\\", \\\"{x:820,y:506,t:1526930094391};\\\", \\\"{x:824,y:503,t:1526930094407};\\\", \\\"{x:826,y:503,t:1526930094425};\\\", \\\"{x:829,y:501,t:1526930094439};\\\", \\\"{x:830,y:501,t:1526930094499};\\\", \\\"{x:831,y:501,t:1526930094716};\\\", \\\"{x:832,y:501,t:1526930094739};\\\", \\\"{x:833,y:501,t:1526930094757};\\\", \\\"{x:835,y:502,t:1526930094773};\\\", \\\"{x:838,y:505,t:1526930094789};\\\", \\\"{x:842,y:506,t:1526930094807};\\\", \\\"{x:843,y:506,t:1526930094823};\\\", \\\"{x:841,y:506,t:1526930095155};\\\", \\\"{x:835,y:506,t:1526930095162};\\\", \\\"{x:826,y:505,t:1526930095174};\\\", \\\"{x:807,y:505,t:1526930095191};\\\", \\\"{x:788,y:502,t:1526930095207};\\\", \\\"{x:765,y:502,t:1526930095223};\\\", \\\"{x:722,y:502,t:1526930095241};\\\", \\\"{x:671,y:502,t:1526930095257};\\\", \\\"{x:607,y:501,t:1526930095274};\\\", \\\"{x:497,y:487,t:1526930095292};\\\", \\\"{x:414,y:475,t:1526930095307};\\\", \\\"{x:349,y:465,t:1526930095324};\\\", \\\"{x:303,y:462,t:1526930095341};\\\", \\\"{x:279,y:462,t:1526930095357};\\\", \\\"{x:264,y:462,t:1526930095373};\\\", \\\"{x:251,y:464,t:1526930095391};\\\", \\\"{x:243,y:467,t:1526930095407};\\\", \\\"{x:235,y:471,t:1526930095423};\\\", \\\"{x:228,y:475,t:1526930095441};\\\", \\\"{x:223,y:478,t:1526930095457};\\\", \\\"{x:220,y:482,t:1526930095474};\\\", \\\"{x:217,y:485,t:1526930095491};\\\", \\\"{x:216,y:490,t:1526930095507};\\\", \\\"{x:215,y:494,t:1526930095523};\\\", \\\"{x:211,y:499,t:1526930095540};\\\", \\\"{x:204,y:505,t:1526930095557};\\\", \\\"{x:196,y:513,t:1526930095574};\\\", \\\"{x:187,y:519,t:1526930095592};\\\", \\\"{x:179,y:522,t:1526930095607};\\\", \\\"{x:170,y:526,t:1526930095625};\\\", \\\"{x:164,y:529,t:1526930095641};\\\", \\\"{x:156,y:530,t:1526930095658};\\\", \\\"{x:152,y:531,t:1526930095674};\\\", \\\"{x:149,y:533,t:1526930095691};\\\", \\\"{x:148,y:534,t:1526930096083};\\\", \\\"{x:148,y:536,t:1526930096091};\\\", \\\"{x:156,y:540,t:1526930096108};\\\", \\\"{x:167,y:546,t:1526930096125};\\\", \\\"{x:183,y:553,t:1526930096141};\\\", \\\"{x:205,y:563,t:1526930096159};\\\", \\\"{x:228,y:574,t:1526930096175};\\\", \\\"{x:247,y:584,t:1526930096190};\\\", \\\"{x:267,y:596,t:1526930096208};\\\", \\\"{x:289,y:612,t:1526930096225};\\\", \\\"{x:314,y:633,t:1526930096241};\\\", \\\"{x:336,y:652,t:1526930096258};\\\", \\\"{x:360,y:674,t:1526930096276};\\\", \\\"{x:371,y:685,t:1526930096291};\\\", \\\"{x:383,y:698,t:1526930096308};\\\", \\\"{x:390,y:706,t:1526930096325};\\\", \\\"{x:397,y:715,t:1526930096340};\\\", \\\"{x:406,y:725,t:1526930096358};\\\", \\\"{x:414,y:736,t:1526930096375};\\\", \\\"{x:423,y:748,t:1526930096391};\\\", \\\"{x:431,y:755,t:1526930096408};\\\", \\\"{x:437,y:761,t:1526930096425};\\\", \\\"{x:444,y:763,t:1526930096441};\\\", \\\"{x:450,y:766,t:1526930096458};\\\", \\\"{x:456,y:768,t:1526930096476};\\\", \\\"{x:459,y:769,t:1526930096492};\\\", \\\"{x:459,y:770,t:1526930096508};\\\", \\\"{x:461,y:770,t:1526930096526};\\\", \\\"{x:465,y:770,t:1526930096541};\\\", \\\"{x:467,y:768,t:1526930096558};\\\", \\\"{x:469,y:767,t:1526930096575};\\\", \\\"{x:471,y:765,t:1526930096592};\\\", \\\"{x:473,y:764,t:1526930096608};\\\", \\\"{x:474,y:764,t:1526930096625};\\\", \\\"{x:475,y:761,t:1526930096642};\\\", \\\"{x:477,y:759,t:1526930096658};\\\", \\\"{x:480,y:754,t:1526930096676};\\\", \\\"{x:480,y:752,t:1526930096692};\\\", \\\"{x:480,y:751,t:1526930096723};\\\", \\\"{x:480,y:749,t:1526930096803};\\\", \\\"{x:480,y:748,t:1526930096811};\\\", \\\"{x:481,y:748,t:1526930096826};\\\", \\\"{x:481,y:746,t:1526930096842};\\\", \\\"{x:481,y:744,t:1526930097115};\\\", \\\"{x:480,y:744,t:1526930097131};\\\", \\\"{x:479,y:744,t:1526930097146};\\\", \\\"{x:478,y:744,t:1526930097158};\\\", \\\"{x:477,y:744,t:1526930097267};\\\", \\\"{x:476,y:744,t:1526930097283};\\\", \\\"{x:475,y:744,t:1526930097292};\\\", \\\"{x:474,y:744,t:1526930097309};\\\", \\\"{x:473,y:744,t:1526930097396};\\\", \\\"{x:472,y:743,t:1526930097644};\\\", \\\"{x:472,y:742,t:1526930097659};\\\", \\\"{x:472,y:740,t:1526930097675};\\\", \\\"{x:472,y:739,t:1526930097692};\\\", \\\"{x:473,y:738,t:1526930097709};\\\", \\\"{x:474,y:737,t:1526930097739};\\\" ] }, { \\\"rt\\\": 88691, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 543506, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -G -B -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:474,y:736,t:1526930098539};\\\", \\\"{x:473,y:736,t:1526930098555};\\\", \\\"{x:472,y:735,t:1526930098579};\\\", \\\"{x:472,y:734,t:1526930098592};\\\", \\\"{x:471,y:733,t:1526930098609};\\\", \\\"{x:471,y:731,t:1526930098626};\\\", \\\"{x:470,y:730,t:1526930098643};\\\", \\\"{x:470,y:729,t:1526930098659};\\\", \\\"{x:470,y:728,t:1526930098768};\\\", \\\"{x:469,y:728,t:1526930099092};\\\", \\\"{x:469,y:727,t:1526930099109};\\\", \\\"{x:469,y:726,t:1526930099204};\\\", \\\"{x:468,y:726,t:1526930099211};\\\", \\\"{x:466,y:726,t:1526930099652};\\\", \\\"{x:466,y:725,t:1526930099660};\\\", \\\"{x:466,y:724,t:1526930099675};\\\", \\\"{x:465,y:723,t:1526930099691};\\\", \\\"{x:464,y:723,t:1526930099708};\\\", \\\"{x:463,y:721,t:1526930099756};\\\", \\\"{x:462,y:720,t:1526930099796};\\\", \\\"{x:474,y:714,t:1526930103901};\\\", \\\"{x:501,y:697,t:1526930103919};\\\", \\\"{x:546,y:673,t:1526930103936};\\\", \\\"{x:708,y:638,t:1526930103947};\\\", \\\"{x:899,y:608,t:1526930103964};\\\", \\\"{x:1068,y:584,t:1526930103981};\\\", \\\"{x:1220,y:562,t:1526930103997};\\\", \\\"{x:1336,y:531,t:1526930104014};\\\", \\\"{x:1416,y:511,t:1526930104031};\\\", \\\"{x:1458,y:499,t:1526930104047};\\\", \\\"{x:1482,y:493,t:1526930104064};\\\", \\\"{x:1488,y:491,t:1526930104081};\\\", \\\"{x:1488,y:490,t:1526930104099};\\\", \\\"{x:1488,y:489,t:1526930104115};\\\", \\\"{x:1477,y:476,t:1526930104131};\\\", \\\"{x:1467,y:467,t:1526930104147};\\\", \\\"{x:1455,y:459,t:1526930104165};\\\", \\\"{x:1433,y:450,t:1526930104182};\\\", \\\"{x:1408,y:442,t:1526930104197};\\\", \\\"{x:1380,y:435,t:1526930104214};\\\", \\\"{x:1341,y:423,t:1526930104231};\\\", \\\"{x:1298,y:414,t:1526930104247};\\\", \\\"{x:1258,y:407,t:1526930104264};\\\", \\\"{x:1226,y:407,t:1526930104281};\\\", \\\"{x:1206,y:409,t:1526930104297};\\\", \\\"{x:1194,y:415,t:1526930104314};\\\", \\\"{x:1185,y:422,t:1526930104331};\\\", \\\"{x:1182,y:433,t:1526930104348};\\\", \\\"{x:1177,y:449,t:1526930104364};\\\", \\\"{x:1173,y:465,t:1526930104381};\\\", \\\"{x:1167,y:471,t:1526930104397};\\\", \\\"{x:1162,y:475,t:1526930104414};\\\", \\\"{x:1158,y:480,t:1526930104431};\\\", \\\"{x:1152,y:484,t:1526930104448};\\\", \\\"{x:1147,y:491,t:1526930104464};\\\", \\\"{x:1137,y:495,t:1526930104481};\\\", \\\"{x:1129,y:499,t:1526930104498};\\\", \\\"{x:1124,y:500,t:1526930104514};\\\", \\\"{x:1118,y:500,t:1526930104531};\\\", \\\"{x:1117,y:500,t:1526930104549};\\\", \\\"{x:1115,y:500,t:1526930104604};\\\", \\\"{x:1114,y:500,t:1526930104908};\\\", \\\"{x:1111,y:500,t:1526930104916};\\\", \\\"{x:1109,y:503,t:1526930104932};\\\", \\\"{x:1106,y:509,t:1526930104949};\\\", \\\"{x:1106,y:512,t:1526930104966};\\\", \\\"{x:1105,y:514,t:1526930104982};\\\", \\\"{x:1104,y:517,t:1526930104999};\\\", \\\"{x:1104,y:518,t:1526930105149};\\\", \\\"{x:1103,y:519,t:1526930105166};\\\", \\\"{x:1103,y:520,t:1526930105182};\\\", \\\"{x:1103,y:521,t:1526930105204};\\\", \\\"{x:1102,y:521,t:1526930105332};\\\", \\\"{x:1103,y:520,t:1526930105412};\\\", \\\"{x:1104,y:519,t:1526930105700};\\\", \\\"{x:1105,y:519,t:1526930107116};\\\", \\\"{x:1107,y:518,t:1526930107134};\\\", \\\"{x:1109,y:516,t:1526930107150};\\\", \\\"{x:1109,y:515,t:1526930107167};\\\", \\\"{x:1110,y:516,t:1526930108517};\\\", \\\"{x:1110,y:519,t:1526930108524};\\\", \\\"{x:1109,y:520,t:1526930108535};\\\", \\\"{x:1108,y:520,t:1526930108551};\\\", \\\"{x:1109,y:520,t:1526930109708};\\\", \\\"{x:1114,y:520,t:1526930109719};\\\", \\\"{x:1131,y:520,t:1526930109736};\\\", \\\"{x:1182,y:520,t:1526930109752};\\\", \\\"{x:1246,y:520,t:1526930109769};\\\", \\\"{x:1287,y:529,t:1526930109785};\\\", \\\"{x:1328,y:545,t:1526930109801};\\\", \\\"{x:1372,y:563,t:1526930109819};\\\", \\\"{x:1408,y:579,t:1526930109835};\\\", \\\"{x:1418,y:585,t:1526930109852};\\\", \\\"{x:1421,y:587,t:1526930109868};\\\", \\\"{x:1421,y:588,t:1526930109963};\\\", \\\"{x:1421,y:589,t:1526930109980};\\\", \\\"{x:1421,y:590,t:1526930109987};\\\", \\\"{x:1420,y:591,t:1526930110002};\\\", \\\"{x:1416,y:595,t:1526930110019};\\\", \\\"{x:1411,y:601,t:1526930110035};\\\", \\\"{x:1408,y:605,t:1526930110052};\\\", \\\"{x:1405,y:609,t:1526930110069};\\\", \\\"{x:1401,y:614,t:1526930110086};\\\", \\\"{x:1401,y:615,t:1526930110102};\\\", \\\"{x:1398,y:615,t:1526930110268};\\\", \\\"{x:1387,y:615,t:1526930110286};\\\", \\\"{x:1368,y:615,t:1526930110303};\\\", \\\"{x:1341,y:615,t:1526930110319};\\\", \\\"{x:1307,y:608,t:1526930110336};\\\", \\\"{x:1258,y:597,t:1526930110353};\\\", \\\"{x:1223,y:584,t:1526930110368};\\\", \\\"{x:1204,y:578,t:1526930110385};\\\", \\\"{x:1196,y:574,t:1526930110403};\\\", \\\"{x:1196,y:573,t:1526930110499};\\\", \\\"{x:1196,y:572,t:1526930110506};\\\", \\\"{x:1198,y:571,t:1526930110519};\\\", \\\"{x:1217,y:569,t:1526930110535};\\\", \\\"{x:1238,y:569,t:1526930110552};\\\", \\\"{x:1253,y:569,t:1526930110570};\\\", \\\"{x:1266,y:575,t:1526930110586};\\\", \\\"{x:1274,y:579,t:1526930110602};\\\", \\\"{x:1285,y:586,t:1526930110618};\\\", \\\"{x:1289,y:593,t:1526930110636};\\\", \\\"{x:1293,y:605,t:1526930110652};\\\", \\\"{x:1295,y:622,t:1526930110669};\\\", \\\"{x:1300,y:648,t:1526930110686};\\\", \\\"{x:1304,y:679,t:1526930110702};\\\", \\\"{x:1316,y:723,t:1526930110719};\\\", \\\"{x:1321,y:740,t:1526930110735};\\\", \\\"{x:1322,y:751,t:1526930110753};\\\", \\\"{x:1323,y:761,t:1526930110769};\\\", \\\"{x:1324,y:763,t:1526930110786};\\\", \\\"{x:1325,y:764,t:1526930110802};\\\", \\\"{x:1326,y:764,t:1526930110835};\\\", \\\"{x:1328,y:764,t:1526930110852};\\\", \\\"{x:1330,y:764,t:1526930110869};\\\", \\\"{x:1332,y:761,t:1526930110886};\\\", \\\"{x:1331,y:752,t:1526930110903};\\\", \\\"{x:1328,y:739,t:1526930110920};\\\", \\\"{x:1321,y:718,t:1526930110936};\\\", \\\"{x:1314,y:692,t:1526930110953};\\\", \\\"{x:1309,y:669,t:1526930110970};\\\", \\\"{x:1303,y:646,t:1526930110986};\\\", \\\"{x:1293,y:612,t:1526930111003};\\\", \\\"{x:1280,y:582,t:1526930111020};\\\", \\\"{x:1269,y:568,t:1526930111037};\\\", \\\"{x:1265,y:563,t:1526930111053};\\\", \\\"{x:1265,y:567,t:1526930111140};\\\", \\\"{x:1266,y:579,t:1526930111153};\\\", \\\"{x:1268,y:599,t:1526930111170};\\\", \\\"{x:1274,y:628,t:1526930111187};\\\", \\\"{x:1281,y:658,t:1526930111203};\\\", \\\"{x:1294,y:700,t:1526930111220};\\\", \\\"{x:1297,y:719,t:1526930111237};\\\", \\\"{x:1298,y:732,t:1526930111253};\\\", \\\"{x:1298,y:744,t:1526930111270};\\\", \\\"{x:1301,y:755,t:1526930111287};\\\", \\\"{x:1303,y:771,t:1526930111303};\\\", \\\"{x:1312,y:792,t:1526930111320};\\\", \\\"{x:1319,y:812,t:1526930111337};\\\", \\\"{x:1320,y:818,t:1526930111353};\\\", \\\"{x:1320,y:822,t:1526930111370};\\\", \\\"{x:1320,y:823,t:1526930111387};\\\", \\\"{x:1320,y:817,t:1526930111476};\\\", \\\"{x:1320,y:815,t:1526930111487};\\\", \\\"{x:1323,y:810,t:1526930111503};\\\", \\\"{x:1329,y:804,t:1526930111519};\\\", \\\"{x:1334,y:799,t:1526930111536};\\\", \\\"{x:1336,y:797,t:1526930111553};\\\", \\\"{x:1339,y:794,t:1526930111569};\\\", \\\"{x:1339,y:787,t:1526930111586};\\\", \\\"{x:1337,y:780,t:1526930111603};\\\", \\\"{x:1337,y:779,t:1526930111619};\\\", \\\"{x:1337,y:777,t:1526930111637};\\\", \\\"{x:1337,y:772,t:1526930111653};\\\", \\\"{x:1338,y:771,t:1526930111670};\\\", \\\"{x:1338,y:770,t:1526930111691};\\\", \\\"{x:1338,y:769,t:1526930111704};\\\", \\\"{x:1338,y:766,t:1526930111720};\\\", \\\"{x:1336,y:760,t:1526930111737};\\\", \\\"{x:1331,y:748,t:1526930111754};\\\", \\\"{x:1326,y:732,t:1526930111770};\\\", \\\"{x:1319,y:711,t:1526930111787};\\\", \\\"{x:1310,y:683,t:1526930111803};\\\", \\\"{x:1305,y:673,t:1526930111820};\\\", \\\"{x:1297,y:660,t:1526930111837};\\\", \\\"{x:1291,y:650,t:1526930111854};\\\", \\\"{x:1288,y:644,t:1526930111870};\\\", \\\"{x:1287,y:632,t:1526930111886};\\\", \\\"{x:1287,y:624,t:1526930111903};\\\", \\\"{x:1287,y:619,t:1526930111920};\\\", \\\"{x:1287,y:615,t:1526930111937};\\\", \\\"{x:1287,y:613,t:1526930111954};\\\", \\\"{x:1287,y:611,t:1526930111971};\\\", \\\"{x:1287,y:609,t:1526930111987};\\\", \\\"{x:1287,y:605,t:1526930112004};\\\", \\\"{x:1287,y:602,t:1526930112020};\\\", \\\"{x:1287,y:600,t:1526930112037};\\\", \\\"{x:1287,y:599,t:1526930112054};\\\", \\\"{x:1287,y:598,t:1526930112071};\\\", \\\"{x:1288,y:596,t:1526930112088};\\\", \\\"{x:1289,y:593,t:1526930112104};\\\", \\\"{x:1292,y:587,t:1526930112121};\\\", \\\"{x:1293,y:580,t:1526930112137};\\\", \\\"{x:1296,y:576,t:1526930112154};\\\", \\\"{x:1297,y:573,t:1526930112171};\\\", \\\"{x:1298,y:570,t:1526930112188};\\\", \\\"{x:1299,y:568,t:1526930112203};\\\", \\\"{x:1299,y:567,t:1526930122748};\\\", \\\"{x:1302,y:564,t:1526930122762};\\\", \\\"{x:1308,y:561,t:1526930122779};\\\", \\\"{x:1311,y:559,t:1526930122795};\\\", \\\"{x:1312,y:559,t:1526930122812};\\\", \\\"{x:1313,y:558,t:1526930122829};\\\", \\\"{x:1313,y:557,t:1526930122851};\\\", \\\"{x:1314,y:557,t:1526930122862};\\\", \\\"{x:1316,y:557,t:1526930122884};\\\", \\\"{x:1318,y:556,t:1526930122896};\\\", \\\"{x:1321,y:555,t:1526930122913};\\\", \\\"{x:1322,y:555,t:1526930122929};\\\", \\\"{x:1323,y:555,t:1526930122944};\\\", \\\"{x:1324,y:555,t:1526930122994};\\\", \\\"{x:1327,y:555,t:1526930123010};\\\", \\\"{x:1334,y:556,t:1526930123027};\\\", \\\"{x:1345,y:564,t:1526930123043};\\\", \\\"{x:1361,y:576,t:1526930123060};\\\", \\\"{x:1375,y:587,t:1526930123077};\\\", \\\"{x:1382,y:597,t:1526930123093};\\\", \\\"{x:1383,y:600,t:1526930123110};\\\", \\\"{x:1383,y:606,t:1526930123126};\\\", \\\"{x:1383,y:607,t:1526930123143};\\\", \\\"{x:1383,y:609,t:1526930123160};\\\", \\\"{x:1383,y:610,t:1526930123184};\\\", \\\"{x:1383,y:614,t:1526930123192};\\\", \\\"{x:1379,y:620,t:1526930123210};\\\", \\\"{x:1375,y:626,t:1526930123225};\\\", \\\"{x:1373,y:631,t:1526930123243};\\\", \\\"{x:1372,y:635,t:1526930123260};\\\", \\\"{x:1371,y:638,t:1526930123276};\\\", \\\"{x:1370,y:640,t:1526930123293};\\\", \\\"{x:1371,y:640,t:1526930124658};\\\", \\\"{x:1376,y:636,t:1526930124665};\\\", \\\"{x:1383,y:630,t:1526930124678};\\\", \\\"{x:1395,y:619,t:1526930124694};\\\", \\\"{x:1406,y:613,t:1526930124711};\\\", \\\"{x:1416,y:608,t:1526930124727};\\\", \\\"{x:1433,y:603,t:1526930124744};\\\", \\\"{x:1454,y:600,t:1526930124760};\\\", \\\"{x:1458,y:599,t:1526930124778};\\\", \\\"{x:1460,y:599,t:1526930124794};\\\", \\\"{x:1463,y:596,t:1526930124811};\\\", \\\"{x:1459,y:596,t:1526930124906};\\\", \\\"{x:1448,y:595,t:1526930124914};\\\", \\\"{x:1436,y:595,t:1526930124929};\\\", \\\"{x:1398,y:595,t:1526930124945};\\\", \\\"{x:1333,y:588,t:1526930124962};\\\", \\\"{x:1303,y:583,t:1526930124979};\\\", \\\"{x:1281,y:577,t:1526930124995};\\\", \\\"{x:1262,y:571,t:1526930125012};\\\", \\\"{x:1255,y:567,t:1526930125029};\\\", \\\"{x:1251,y:565,t:1526930125044};\\\", \\\"{x:1251,y:564,t:1526930125169};\\\", \\\"{x:1251,y:562,t:1526930125185};\\\", \\\"{x:1251,y:561,t:1526930125194};\\\", \\\"{x:1253,y:558,t:1526930125212};\\\", \\\"{x:1254,y:557,t:1526930125229};\\\", \\\"{x:1255,y:557,t:1526930125497};\\\", \\\"{x:1256,y:558,t:1526930125546};\\\", \\\"{x:1258,y:558,t:1526930125898};\\\", \\\"{x:1263,y:558,t:1526930125912};\\\", \\\"{x:1295,y:555,t:1526930125928};\\\", \\\"{x:1367,y:549,t:1526930125945};\\\", \\\"{x:1392,y:549,t:1526930125962};\\\", \\\"{x:1405,y:550,t:1526930125979};\\\", \\\"{x:1405,y:551,t:1526930125995};\\\", \\\"{x:1406,y:551,t:1526930126137};\\\", \\\"{x:1408,y:551,t:1526930126145};\\\", \\\"{x:1412,y:551,t:1526930126162};\\\", \\\"{x:1420,y:551,t:1526930126179};\\\", \\\"{x:1437,y:548,t:1526930126196};\\\", \\\"{x:1458,y:545,t:1526930126213};\\\", \\\"{x:1480,y:541,t:1526930126230};\\\", \\\"{x:1498,y:540,t:1526930126246};\\\", \\\"{x:1516,y:537,t:1526930126263};\\\", \\\"{x:1533,y:534,t:1526930126280};\\\", \\\"{x:1552,y:531,t:1526930126296};\\\", \\\"{x:1573,y:527,t:1526930126312};\\\", \\\"{x:1601,y:524,t:1526930126329};\\\", \\\"{x:1617,y:519,t:1526930126345};\\\", \\\"{x:1629,y:515,t:1526930126363};\\\", \\\"{x:1639,y:512,t:1526930126380};\\\", \\\"{x:1648,y:510,t:1526930126395};\\\", \\\"{x:1654,y:509,t:1526930126413};\\\", \\\"{x:1658,y:508,t:1526930126430};\\\", \\\"{x:1659,y:508,t:1526930126450};\\\", \\\"{x:1659,y:507,t:1526930127082};\\\", \\\"{x:1663,y:502,t:1526930127097};\\\", \\\"{x:1666,y:497,t:1526930127114};\\\", \\\"{x:1666,y:496,t:1526930127130};\\\", \\\"{x:1667,y:495,t:1526930127146};\\\", \\\"{x:1669,y:494,t:1526930127163};\\\", \\\"{x:1669,y:493,t:1526930127457};\\\", \\\"{x:1668,y:493,t:1526930127497};\\\", \\\"{x:1667,y:493,t:1526930127513};\\\", \\\"{x:1665,y:493,t:1526930127530};\\\", \\\"{x:1665,y:494,t:1526930127547};\\\", \\\"{x:1664,y:494,t:1526930127577};\\\", \\\"{x:1663,y:494,t:1526930127585};\\\", \\\"{x:1662,y:494,t:1526930127597};\\\", \\\"{x:1661,y:494,t:1526930127617};\\\", \\\"{x:1659,y:495,t:1526930127630};\\\", \\\"{x:1657,y:495,t:1526930127649};\\\", \\\"{x:1656,y:496,t:1526930127664};\\\", \\\"{x:1654,y:496,t:1526930127680};\\\", \\\"{x:1654,y:497,t:1526930127697};\\\", \\\"{x:1651,y:497,t:1526930127713};\\\", \\\"{x:1650,y:497,t:1526930127731};\\\", \\\"{x:1648,y:497,t:1526930127747};\\\", \\\"{x:1647,y:499,t:1526930127764};\\\", \\\"{x:1646,y:499,t:1526930127781};\\\", \\\"{x:1644,y:499,t:1526930127797};\\\", \\\"{x:1644,y:500,t:1526930127850};\\\", \\\"{x:1643,y:501,t:1526930127873};\\\", \\\"{x:1642,y:503,t:1526930127881};\\\", \\\"{x:1641,y:504,t:1526930127905};\\\", \\\"{x:1641,y:505,t:1526930127914};\\\", \\\"{x:1641,y:506,t:1526930127931};\\\", \\\"{x:1641,y:507,t:1526930127946};\\\", \\\"{x:1640,y:509,t:1526930127969};\\\", \\\"{x:1638,y:509,t:1526930128232};\\\", \\\"{x:1638,y:510,t:1526930128417};\\\", \\\"{x:1637,y:511,t:1526930128490};\\\", \\\"{x:1636,y:511,t:1526930128554};\\\", \\\"{x:1635,y:511,t:1526930129169};\\\", \\\"{x:1633,y:513,t:1526930129182};\\\", \\\"{x:1624,y:516,t:1526930129197};\\\", \\\"{x:1610,y:522,t:1526930129215};\\\", \\\"{x:1596,y:525,t:1526930129231};\\\", \\\"{x:1584,y:528,t:1526930129248};\\\", \\\"{x:1572,y:532,t:1526930129264};\\\", \\\"{x:1559,y:533,t:1526930129281};\\\", \\\"{x:1551,y:537,t:1526930129297};\\\", \\\"{x:1539,y:540,t:1526930129315};\\\", \\\"{x:1527,y:542,t:1526930129331};\\\", \\\"{x:1513,y:547,t:1526930129348};\\\", \\\"{x:1499,y:548,t:1526930129364};\\\", \\\"{x:1489,y:550,t:1526930129381};\\\", \\\"{x:1472,y:550,t:1526930129398};\\\", \\\"{x:1457,y:550,t:1526930129414};\\\", \\\"{x:1445,y:550,t:1526930129432};\\\", \\\"{x:1431,y:550,t:1526930129448};\\\", \\\"{x:1423,y:550,t:1526930129464};\\\", \\\"{x:1418,y:550,t:1526930129482};\\\", \\\"{x:1416,y:550,t:1526930129498};\\\", \\\"{x:1415,y:551,t:1526930130057};\\\", \\\"{x:1416,y:552,t:1526930130105};\\\", \\\"{x:1417,y:553,t:1526930130121};\\\", \\\"{x:1418,y:553,t:1526930130132};\\\", \\\"{x:1421,y:553,t:1526930130149};\\\", \\\"{x:1423,y:551,t:1526930130166};\\\", \\\"{x:1423,y:550,t:1526930130181};\\\", \\\"{x:1424,y:549,t:1526930130199};\\\", \\\"{x:1425,y:547,t:1526930130216};\\\", \\\"{x:1425,y:546,t:1526930130231};\\\", \\\"{x:1425,y:547,t:1526930131737};\\\", \\\"{x:1425,y:548,t:1526930131761};\\\", \\\"{x:1425,y:549,t:1526930131777};\\\", \\\"{x:1425,y:550,t:1526930131801};\\\", \\\"{x:1425,y:551,t:1526930131898};\\\", \\\"{x:1425,y:552,t:1526930131954};\\\", \\\"{x:1426,y:553,t:1526930132506};\\\", \\\"{x:1426,y:554,t:1526930132529};\\\", \\\"{x:1426,y:555,t:1526930132537};\\\", \\\"{x:1426,y:556,t:1526930132551};\\\", \\\"{x:1426,y:557,t:1526930132566};\\\", \\\"{x:1426,y:558,t:1526930132584};\\\", \\\"{x:1426,y:559,t:1526930132601};\\\", \\\"{x:1426,y:560,t:1526930132617};\\\", \\\"{x:1426,y:561,t:1526930132641};\\\", \\\"{x:1426,y:562,t:1526930132673};\\\", \\\"{x:1425,y:563,t:1526930132697};\\\", \\\"{x:1425,y:564,t:1526930132716};\\\", \\\"{x:1424,y:565,t:1526930132733};\\\", \\\"{x:1423,y:566,t:1526930132752};\\\", \\\"{x:1423,y:567,t:1526930132768};\\\", \\\"{x:1422,y:568,t:1526930132783};\\\", \\\"{x:1421,y:568,t:1526930132816};\\\", \\\"{x:1418,y:571,t:1526930133809};\\\", \\\"{x:1413,y:577,t:1526930133818};\\\", \\\"{x:1395,y:602,t:1526930133835};\\\", \\\"{x:1362,y:636,t:1526930133852};\\\", \\\"{x:1322,y:678,t:1526930133868};\\\", \\\"{x:1293,y:711,t:1526930133885};\\\", \\\"{x:1283,y:729,t:1526930133902};\\\", \\\"{x:1282,y:738,t:1526930133918};\\\", \\\"{x:1282,y:742,t:1526930133935};\\\", \\\"{x:1285,y:744,t:1526930133952};\\\", \\\"{x:1287,y:746,t:1526930133968};\\\", \\\"{x:1288,y:746,t:1526930134001};\\\", \\\"{x:1289,y:746,t:1526930134018};\\\", \\\"{x:1290,y:747,t:1526930134035};\\\", \\\"{x:1299,y:750,t:1526930134052};\\\", \\\"{x:1314,y:755,t:1526930134068};\\\", \\\"{x:1324,y:756,t:1526930134084};\\\", \\\"{x:1333,y:758,t:1526930134101};\\\", \\\"{x:1339,y:759,t:1526930134118};\\\", \\\"{x:1342,y:760,t:1526930134134};\\\", \\\"{x:1345,y:760,t:1526930134155};\\\", \\\"{x:1346,y:760,t:1526930134167};\\\", \\\"{x:1350,y:763,t:1526930134184};\\\", \\\"{x:1351,y:764,t:1526930134201};\\\", \\\"{x:1353,y:767,t:1526930134219};\\\", \\\"{x:1354,y:768,t:1526930134234};\\\", \\\"{x:1355,y:770,t:1526930134251};\\\", \\\"{x:1358,y:774,t:1526930134268};\\\", \\\"{x:1360,y:778,t:1526930134285};\\\", \\\"{x:1361,y:779,t:1526930134301};\\\", \\\"{x:1362,y:782,t:1526930134318};\\\", \\\"{x:1361,y:782,t:1526930134626};\\\", \\\"{x:1360,y:782,t:1526930134641};\\\", \\\"{x:1359,y:782,t:1526930134681};\\\", \\\"{x:1358,y:782,t:1526930134690};\\\", \\\"{x:1357,y:781,t:1526930134702};\\\", \\\"{x:1357,y:780,t:1526930134719};\\\", \\\"{x:1356,y:779,t:1526930134736};\\\", \\\"{x:1355,y:778,t:1526930134752};\\\", \\\"{x:1353,y:776,t:1526930134769};\\\", \\\"{x:1352,y:775,t:1526930134786};\\\", \\\"{x:1351,y:775,t:1526930134802};\\\", \\\"{x:1350,y:773,t:1526930134825};\\\", \\\"{x:1350,y:772,t:1526930134865};\\\", \\\"{x:1349,y:771,t:1526930134873};\\\", \\\"{x:1348,y:770,t:1526930134886};\\\", \\\"{x:1348,y:769,t:1526930134913};\\\", \\\"{x:1348,y:768,t:1526930134930};\\\", \\\"{x:1348,y:767,t:1526930134969};\\\", \\\"{x:1347,y:766,t:1526930135217};\\\", \\\"{x:1344,y:766,t:1526930145233};\\\", \\\"{x:1338,y:769,t:1526930145244};\\\", \\\"{x:1328,y:769,t:1526930145260};\\\", \\\"{x:1324,y:770,t:1526930145276};\\\", \\\"{x:1325,y:769,t:1526930145577};\\\", \\\"{x:1326,y:769,t:1526930145593};\\\", \\\"{x:1329,y:768,t:1526930145610};\\\", \\\"{x:1331,y:767,t:1526930145682};\\\", \\\"{x:1332,y:767,t:1526930145696};\\\", \\\"{x:1333,y:766,t:1526930145712};\\\", \\\"{x:1334,y:766,t:1526930145744};\\\", \\\"{x:1335,y:765,t:1526930145760};\\\", \\\"{x:1336,y:765,t:1526930145848};\\\", \\\"{x:1337,y:765,t:1526930145920};\\\", \\\"{x:1337,y:764,t:1526930145936};\\\", \\\"{x:1338,y:764,t:1526930145944};\\\", \\\"{x:1339,y:764,t:1526930145959};\\\", \\\"{x:1342,y:762,t:1526930145976};\\\", \\\"{x:1343,y:761,t:1526930145993};\\\", \\\"{x:1345,y:761,t:1526930146010};\\\", \\\"{x:1342,y:763,t:1526930146593};\\\", \\\"{x:1321,y:774,t:1526930146612};\\\", \\\"{x:1309,y:784,t:1526930146627};\\\", \\\"{x:1304,y:786,t:1526930146645};\\\", \\\"{x:1307,y:786,t:1526930146698};\\\", \\\"{x:1310,y:786,t:1526930146711};\\\", \\\"{x:1320,y:783,t:1526930146727};\\\", \\\"{x:1324,y:782,t:1526930146745};\\\", \\\"{x:1325,y:782,t:1526930146762};\\\", \\\"{x:1326,y:781,t:1526930146777};\\\", \\\"{x:1327,y:781,t:1526930146800};\\\", \\\"{x:1328,y:780,t:1526930146811};\\\", \\\"{x:1330,y:780,t:1526930146827};\\\", \\\"{x:1335,y:778,t:1526930146845};\\\", \\\"{x:1340,y:776,t:1526930146862};\\\", \\\"{x:1346,y:773,t:1526930146878};\\\", \\\"{x:1348,y:773,t:1526930146894};\\\", \\\"{x:1348,y:772,t:1526930146912};\\\", \\\"{x:1349,y:772,t:1526930146953};\\\", \\\"{x:1352,y:770,t:1526930146968};\\\", \\\"{x:1357,y:768,t:1526930146977};\\\", \\\"{x:1359,y:768,t:1526930146994};\\\", \\\"{x:1359,y:767,t:1526930147011};\\\", \\\"{x:1358,y:767,t:1526930147458};\\\", \\\"{x:1357,y:767,t:1526930147473};\\\", \\\"{x:1353,y:767,t:1526930152209};\\\", \\\"{x:1347,y:767,t:1526930152217};\\\", \\\"{x:1340,y:765,t:1526930152232};\\\", \\\"{x:1323,y:760,t:1526930152248};\\\", \\\"{x:1319,y:758,t:1526930152264};\\\", \\\"{x:1319,y:757,t:1526930152321};\\\", \\\"{x:1319,y:756,t:1526930152505};\\\", \\\"{x:1320,y:756,t:1526930152521};\\\", \\\"{x:1322,y:756,t:1526930152531};\\\", \\\"{x:1323,y:756,t:1526930152548};\\\", \\\"{x:1326,y:757,t:1526930152565};\\\", \\\"{x:1325,y:758,t:1526930158545};\\\", \\\"{x:1326,y:758,t:1526930159729};\\\", \\\"{x:1326,y:756,t:1526930159736};\\\", \\\"{x:1325,y:755,t:1526930159754};\\\", \\\"{x:1325,y:754,t:1526930159777};\\\", \\\"{x:1324,y:754,t:1526930160345};\\\", \\\"{x:1323,y:754,t:1526930160593};\\\", \\\"{x:1318,y:755,t:1526930160605};\\\", \\\"{x:1296,y:759,t:1526930160621};\\\", \\\"{x:1266,y:759,t:1526930160638};\\\", \\\"{x:1234,y:759,t:1526930160655};\\\", \\\"{x:1201,y:752,t:1526930160671};\\\", \\\"{x:1159,y:738,t:1526930160690};\\\", \\\"{x:1134,y:722,t:1526930160705};\\\", \\\"{x:1116,y:706,t:1526930160721};\\\", \\\"{x:1097,y:687,t:1526930160737};\\\", \\\"{x:1084,y:675,t:1526930160755};\\\", \\\"{x:1070,y:661,t:1526930160772};\\\", \\\"{x:1036,y:634,t:1526930160788};\\\", \\\"{x:982,y:607,t:1526930160804};\\\", \\\"{x:927,y:584,t:1526930160823};\\\", \\\"{x:853,y:554,t:1526930160839};\\\", \\\"{x:775,y:532,t:1526930160853};\\\", \\\"{x:698,y:513,t:1526930160875};\\\", \\\"{x:648,y:506,t:1526930160891};\\\", \\\"{x:609,y:502,t:1526930160909};\\\", \\\"{x:581,y:502,t:1526930160924};\\\", \\\"{x:561,y:502,t:1526930160941};\\\", \\\"{x:554,y:502,t:1526930160957};\\\", \\\"{x:550,y:502,t:1526930160974};\\\", \\\"{x:545,y:502,t:1526930160991};\\\", \\\"{x:532,y:505,t:1526930161007};\\\", \\\"{x:522,y:508,t:1526930161024};\\\", \\\"{x:512,y:510,t:1526930161041};\\\", \\\"{x:507,y:512,t:1526930161058};\\\", \\\"{x:501,y:514,t:1526930161074};\\\", \\\"{x:493,y:518,t:1526930161092};\\\", \\\"{x:478,y:522,t:1526930161108};\\\", \\\"{x:457,y:529,t:1526930161125};\\\", \\\"{x:428,y:534,t:1526930161141};\\\", \\\"{x:399,y:539,t:1526930161158};\\\", \\\"{x:375,y:542,t:1526930161174};\\\", \\\"{x:353,y:544,t:1526930161191};\\\", \\\"{x:327,y:549,t:1526930161207};\\\", \\\"{x:317,y:550,t:1526930161224};\\\", \\\"{x:304,y:550,t:1526930161241};\\\", \\\"{x:292,y:550,t:1526930161258};\\\", \\\"{x:271,y:550,t:1526930161276};\\\", \\\"{x:257,y:547,t:1526930161291};\\\", \\\"{x:256,y:546,t:1526930161308};\\\", \\\"{x:256,y:545,t:1526930161327};\\\", \\\"{x:257,y:542,t:1526930161340};\\\", \\\"{x:268,y:534,t:1526930161357};\\\", \\\"{x:290,y:525,t:1526930161375};\\\", \\\"{x:313,y:518,t:1526930161392};\\\", \\\"{x:346,y:513,t:1526930161409};\\\", \\\"{x:385,y:507,t:1526930161426};\\\", \\\"{x:417,y:505,t:1526930161441};\\\", \\\"{x:432,y:505,t:1526930161458};\\\", \\\"{x:438,y:505,t:1526930161474};\\\", \\\"{x:442,y:505,t:1526930161491};\\\", \\\"{x:444,y:505,t:1526930161511};\\\", \\\"{x:445,y:505,t:1526930161525};\\\", \\\"{x:447,y:505,t:1526930161541};\\\", \\\"{x:451,y:506,t:1526930161559};\\\", \\\"{x:457,y:507,t:1526930161575};\\\", \\\"{x:466,y:510,t:1526930161591};\\\", \\\"{x:478,y:512,t:1526930161608};\\\", \\\"{x:491,y:515,t:1526930161625};\\\", \\\"{x:503,y:516,t:1526930161642};\\\", \\\"{x:513,y:517,t:1526930161658};\\\", \\\"{x:520,y:517,t:1526930161674};\\\", \\\"{x:527,y:517,t:1526930161691};\\\", \\\"{x:537,y:517,t:1526930161708};\\\", \\\"{x:546,y:517,t:1526930161725};\\\", \\\"{x:552,y:517,t:1526930161741};\\\", \\\"{x:555,y:517,t:1526930161758};\\\", \\\"{x:559,y:516,t:1526930161774};\\\", \\\"{x:561,y:516,t:1526930161809};\\\", \\\"{x:567,y:514,t:1526930161825};\\\", \\\"{x:572,y:511,t:1526930161842};\\\", \\\"{x:575,y:509,t:1526930161859};\\\", \\\"{x:578,y:508,t:1526930161875};\\\", \\\"{x:578,y:507,t:1526930161892};\\\", \\\"{x:579,y:507,t:1526930161908};\\\", \\\"{x:581,y:507,t:1526930161925};\\\", \\\"{x:582,y:506,t:1526930161942};\\\", \\\"{x:584,y:505,t:1526930161958};\\\", \\\"{x:585,y:504,t:1526930162008};\\\", \\\"{x:586,y:504,t:1526930162224};\\\", \\\"{x:587,y:504,t:1526930162241};\\\", \\\"{x:588,y:504,t:1526930162259};\\\", \\\"{x:590,y:504,t:1526930162275};\\\", \\\"{x:591,y:504,t:1526930162292};\\\", \\\"{x:593,y:504,t:1526930163777};\\\", \\\"{x:597,y:504,t:1526930163790};\\\", \\\"{x:600,y:506,t:1526930163809};\\\", \\\"{x:602,y:508,t:1526930163825};\\\", \\\"{x:604,y:509,t:1526930163841};\\\", \\\"{x:605,y:509,t:1526930163861};\\\", \\\"{x:607,y:509,t:1526930163903};\\\", \\\"{x:608,y:509,t:1526930164016};\\\", \\\"{x:608,y:508,t:1526930164209};\\\", \\\"{x:608,y:506,t:1526930164225};\\\", \\\"{x:608,y:505,t:1526930164240};\\\", \\\"{x:608,y:503,t:1526930164377};\\\", \\\"{x:608,y:503,t:1526930164439};\\\", \\\"{x:613,y:494,t:1526930170527};\\\", \\\"{x:622,y:486,t:1526930170535};\\\", \\\"{x:641,y:478,t:1526930170549};\\\", \\\"{x:744,y:462,t:1526930170564};\\\", \\\"{x:878,y:456,t:1526930170582};\\\", \\\"{x:1049,y:456,t:1526930170598};\\\", \\\"{x:1239,y:467,t:1526930170616};\\\", \\\"{x:1328,y:480,t:1526930170632};\\\", \\\"{x:1382,y:488,t:1526930170649};\\\", \\\"{x:1410,y:492,t:1526930170665};\\\", \\\"{x:1416,y:495,t:1526930170683};\\\", \\\"{x:1417,y:495,t:1526930170728};\\\", \\\"{x:1418,y:497,t:1526930170735};\\\", \\\"{x:1422,y:499,t:1526930170748};\\\", \\\"{x:1431,y:504,t:1526930170765};\\\", \\\"{x:1443,y:509,t:1526930170782};\\\", \\\"{x:1454,y:513,t:1526930170799};\\\", \\\"{x:1462,y:521,t:1526930170815};\\\", \\\"{x:1466,y:524,t:1526930170832};\\\", \\\"{x:1466,y:525,t:1526930170849};\\\", \\\"{x:1466,y:528,t:1526930170866};\\\", \\\"{x:1466,y:532,t:1526930170882};\\\", \\\"{x:1466,y:537,t:1526930170900};\\\", \\\"{x:1466,y:543,t:1526930170916};\\\", \\\"{x:1462,y:548,t:1526930170932};\\\", \\\"{x:1455,y:553,t:1526930170949};\\\", \\\"{x:1448,y:557,t:1526930170966};\\\", \\\"{x:1444,y:560,t:1526930170983};\\\", \\\"{x:1443,y:560,t:1526930170999};\\\", \\\"{x:1439,y:560,t:1526930171015};\\\", \\\"{x:1436,y:561,t:1526930171033};\\\", \\\"{x:1429,y:561,t:1526930171050};\\\", \\\"{x:1425,y:561,t:1526930171066};\\\", \\\"{x:1422,y:561,t:1526930171082};\\\", \\\"{x:1421,y:561,t:1526930171100};\\\", \\\"{x:1426,y:561,t:1526930171273};\\\", \\\"{x:1431,y:561,t:1526930171283};\\\", \\\"{x:1444,y:564,t:1526930171301};\\\", \\\"{x:1457,y:566,t:1526930171316};\\\", \\\"{x:1468,y:568,t:1526930171333};\\\", \\\"{x:1477,y:570,t:1526930171350};\\\", \\\"{x:1481,y:570,t:1526930171367};\\\", \\\"{x:1484,y:570,t:1526930171382};\\\", \\\"{x:1488,y:570,t:1526930171399};\\\", \\\"{x:1489,y:570,t:1526930171416};\\\", \\\"{x:1488,y:570,t:1526930171801};\\\", \\\"{x:1487,y:571,t:1526930171824};\\\", \\\"{x:1486,y:571,t:1526930171905};\\\", \\\"{x:1488,y:567,t:1526930172840};\\\", \\\"{x:1490,y:566,t:1526930172851};\\\", \\\"{x:1491,y:564,t:1526930172868};\\\", \\\"{x:1493,y:563,t:1526930172884};\\\", \\\"{x:1494,y:561,t:1526930172901};\\\", \\\"{x:1495,y:560,t:1526930172961};\\\", \\\"{x:1497,y:560,t:1526930173553};\\\", \\\"{x:1498,y:560,t:1526930173568};\\\", \\\"{x:1499,y:560,t:1526930175961};\\\", \\\"{x:1500,y:561,t:1526930185694};\\\", \\\"{x:1438,y:590,t:1526930185709};\\\", \\\"{x:1378,y:613,t:1526930185726};\\\", \\\"{x:1294,y:628,t:1526930185743};\\\", \\\"{x:1156,y:665,t:1526930185760};\\\", \\\"{x:983,y:710,t:1526930185776};\\\", \\\"{x:803,y:737,t:1526930185793};\\\", \\\"{x:626,y:759,t:1526930185810};\\\", \\\"{x:484,y:787,t:1526930185826};\\\", \\\"{x:365,y:802,t:1526930185843};\\\", \\\"{x:309,y:810,t:1526930185860};\\\", \\\"{x:287,y:813,t:1526930185876};\\\", \\\"{x:273,y:818,t:1526930185893};\\\", \\\"{x:269,y:820,t:1526930185909};\\\", \\\"{x:258,y:825,t:1526930185927};\\\", \\\"{x:247,y:829,t:1526930185943};\\\", \\\"{x:236,y:831,t:1526930185960};\\\", \\\"{x:232,y:831,t:1526930185977};\\\", \\\"{x:231,y:829,t:1526930185993};\\\", \\\"{x:234,y:813,t:1526930186009};\\\", \\\"{x:267,y:773,t:1526930186027};\\\", \\\"{x:306,y:750,t:1526930186042};\\\", \\\"{x:332,y:737,t:1526930186060};\\\", \\\"{x:367,y:727,t:1526930186077};\\\", \\\"{x:389,y:723,t:1526930186093};\\\", \\\"{x:411,y:721,t:1526930186110};\\\", \\\"{x:424,y:720,t:1526930186127};\\\", \\\"{x:435,y:720,t:1526930186143};\\\", \\\"{x:444,y:720,t:1526930186160};\\\", \\\"{x:452,y:720,t:1526930186178};\\\", \\\"{x:459,y:723,t:1526930186192};\\\", \\\"{x:470,y:725,t:1526930186209};\\\", \\\"{x:478,y:727,t:1526930186224};\\\", \\\"{x:483,y:728,t:1526930186241};\\\", \\\"{x:489,y:731,t:1526930186258};\\\", \\\"{x:492,y:732,t:1526930186274};\\\", \\\"{x:498,y:736,t:1526930186291};\\\", \\\"{x:508,y:743,t:1526930186308};\\\", \\\"{x:510,y:745,t:1526930186324};\\\", \\\"{x:511,y:745,t:1526930186356};\\\" ] }, { \\\"rt\\\": 34361, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 579403, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -B -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:742,t:1526930193213};\\\", \\\"{x:524,y:738,t:1526930193221};\\\", \\\"{x:528,y:736,t:1526930193232};\\\", \\\"{x:531,y:734,t:1526930193249};\\\", \\\"{x:533,y:734,t:1526930193265};\\\", \\\"{x:537,y:731,t:1526930193282};\\\", \\\"{x:539,y:730,t:1526930193299};\\\", \\\"{x:546,y:726,t:1526930193316};\\\", \\\"{x:551,y:721,t:1526930193332};\\\", \\\"{x:562,y:704,t:1526930193350};\\\", \\\"{x:572,y:686,t:1526930193366};\\\", \\\"{x:579,y:675,t:1526930193382};\\\", \\\"{x:583,y:667,t:1526930193397};\\\", \\\"{x:592,y:651,t:1526930193414};\\\", \\\"{x:612,y:624,t:1526930193430};\\\", \\\"{x:648,y:573,t:1526930193448};\\\", \\\"{x:700,y:505,t:1526930193465};\\\", \\\"{x:735,y:460,t:1526930193480};\\\", \\\"{x:737,y:456,t:1526930193498};\\\", \\\"{x:738,y:451,t:1526930193514};\\\", \\\"{x:735,y:438,t:1526930193530};\\\", \\\"{x:731,y:429,t:1526930193547};\\\", \\\"{x:730,y:426,t:1526930193564};\\\", \\\"{x:730,y:425,t:1526930193582};\\\", \\\"{x:729,y:424,t:1526930193598};\\\", \\\"{x:726,y:424,t:1526930193757};\\\", \\\"{x:724,y:424,t:1526930193765};\\\", \\\"{x:703,y:429,t:1526930193781};\\\", \\\"{x:662,y:440,t:1526930193798};\\\", \\\"{x:606,y:450,t:1526930193815};\\\", \\\"{x:522,y:465,t:1526930193832};\\\", \\\"{x:422,y:478,t:1526930193848};\\\", \\\"{x:336,y:490,t:1526930193866};\\\", \\\"{x:289,y:496,t:1526930193881};\\\", \\\"{x:267,y:499,t:1526930193899};\\\", \\\"{x:253,y:499,t:1526930193914};\\\", \\\"{x:249,y:500,t:1526930193932};\\\", \\\"{x:245,y:501,t:1526930193948};\\\", \\\"{x:239,y:503,t:1526930193965};\\\", \\\"{x:238,y:503,t:1526930193981};\\\", \\\"{x:237,y:503,t:1526930193998};\\\", \\\"{x:238,y:503,t:1526930194205};\\\", \\\"{x:247,y:499,t:1526930194215};\\\", \\\"{x:290,y:477,t:1526930194233};\\\", \\\"{x:348,y:455,t:1526930194248};\\\", \\\"{x:409,y:438,t:1526930194264};\\\", \\\"{x:469,y:424,t:1526930194282};\\\", \\\"{x:514,y:417,t:1526930194298};\\\", \\\"{x:545,y:412,t:1526930194315};\\\", \\\"{x:576,y:409,t:1526930194332};\\\", \\\"{x:653,y:398,t:1526930194348};\\\", \\\"{x:753,y:398,t:1526930194365};\\\", \\\"{x:892,y:401,t:1526930194382};\\\", \\\"{x:1028,y:422,t:1526930194398};\\\", \\\"{x:1150,y:441,t:1526930194415};\\\", \\\"{x:1239,y:452,t:1526930194431};\\\", \\\"{x:1302,y:459,t:1526930194449};\\\", \\\"{x:1358,y:469,t:1526930194465};\\\", \\\"{x:1412,y:477,t:1526930194481};\\\", \\\"{x:1465,y:485,t:1526930194499};\\\", \\\"{x:1547,y:504,t:1526930194515};\\\", \\\"{x:1642,y:535,t:1526930194532};\\\", \\\"{x:1773,y:594,t:1526930194548};\\\", \\\"{x:1835,y:636,t:1526930194566};\\\", \\\"{x:1853,y:658,t:1526930194582};\\\", \\\"{x:1854,y:675,t:1526930194599};\\\", \\\"{x:1849,y:686,t:1526930194616};\\\", \\\"{x:1838,y:699,t:1526930194632};\\\", \\\"{x:1824,y:712,t:1526930194649};\\\", \\\"{x:1810,y:722,t:1526930194666};\\\", \\\"{x:1798,y:729,t:1526930194682};\\\", \\\"{x:1787,y:736,t:1526930194699};\\\", \\\"{x:1778,y:742,t:1526930194717};\\\", \\\"{x:1767,y:749,t:1526930194732};\\\", \\\"{x:1753,y:763,t:1526930194749};\\\", \\\"{x:1744,y:773,t:1526930194766};\\\", \\\"{x:1739,y:777,t:1526930194782};\\\", \\\"{x:1732,y:784,t:1526930194799};\\\", \\\"{x:1723,y:789,t:1526930194816};\\\", \\\"{x:1713,y:795,t:1526930194832};\\\", \\\"{x:1705,y:799,t:1526930194849};\\\", \\\"{x:1694,y:802,t:1526930194866};\\\", \\\"{x:1684,y:804,t:1526930194882};\\\", \\\"{x:1676,y:805,t:1526930194899};\\\", \\\"{x:1661,y:807,t:1526930194916};\\\", \\\"{x:1644,y:807,t:1526930194932};\\\", \\\"{x:1625,y:809,t:1526930194948};\\\", \\\"{x:1618,y:810,t:1526930194966};\\\", \\\"{x:1609,y:812,t:1526930194982};\\\", \\\"{x:1598,y:814,t:1526930194999};\\\", \\\"{x:1579,y:819,t:1526930195016};\\\", \\\"{x:1561,y:824,t:1526930195033};\\\", \\\"{x:1547,y:831,t:1526930195049};\\\", \\\"{x:1530,y:840,t:1526930195066};\\\", \\\"{x:1505,y:856,t:1526930195083};\\\", \\\"{x:1484,y:868,t:1526930195099};\\\", \\\"{x:1465,y:882,t:1526930195116};\\\", \\\"{x:1430,y:902,t:1526930195132};\\\", \\\"{x:1414,y:911,t:1526930195149};\\\", \\\"{x:1408,y:916,t:1526930195166};\\\", \\\"{x:1407,y:917,t:1526930195183};\\\", \\\"{x:1403,y:917,t:1526930195286};\\\", \\\"{x:1400,y:917,t:1526930195299};\\\", \\\"{x:1392,y:913,t:1526930195316};\\\", \\\"{x:1374,y:900,t:1526930195333};\\\", \\\"{x:1357,y:886,t:1526930195350};\\\", \\\"{x:1342,y:878,t:1526930195366};\\\", \\\"{x:1326,y:868,t:1526930195383};\\\", \\\"{x:1311,y:859,t:1526930195399};\\\", \\\"{x:1297,y:851,t:1526930195416};\\\", \\\"{x:1286,y:846,t:1526930195433};\\\", \\\"{x:1271,y:839,t:1526930195449};\\\", \\\"{x:1258,y:834,t:1526930195466};\\\", \\\"{x:1251,y:831,t:1526930195483};\\\", \\\"{x:1246,y:829,t:1526930195499};\\\", \\\"{x:1239,y:828,t:1526930195516};\\\", \\\"{x:1233,y:828,t:1526930195533};\\\", \\\"{x:1229,y:828,t:1526930195550};\\\", \\\"{x:1225,y:828,t:1526930195566};\\\", \\\"{x:1223,y:828,t:1526930195583};\\\", \\\"{x:1221,y:828,t:1526930195600};\\\", \\\"{x:1219,y:828,t:1526930195880};\\\", \\\"{x:1218,y:828,t:1526930195915};\\\", \\\"{x:1216,y:828,t:1526930195932};\\\", \\\"{x:1218,y:828,t:1526930202565};\\\", \\\"{x:1221,y:825,t:1526930202574};\\\", \\\"{x:1224,y:821,t:1526930202588};\\\", \\\"{x:1227,y:814,t:1526930202605};\\\", \\\"{x:1228,y:812,t:1526930202621};\\\", \\\"{x:1229,y:810,t:1526930202637};\\\", \\\"{x:1229,y:808,t:1526930202654};\\\", \\\"{x:1230,y:808,t:1526930202671};\\\", \\\"{x:1232,y:806,t:1526930202687};\\\", \\\"{x:1235,y:802,t:1526930202704};\\\", \\\"{x:1239,y:798,t:1526930202722};\\\", \\\"{x:1243,y:795,t:1526930202738};\\\", \\\"{x:1245,y:795,t:1526930202754};\\\", \\\"{x:1245,y:794,t:1526930202771};\\\", \\\"{x:1247,y:793,t:1526930202821};\\\", \\\"{x:1248,y:792,t:1526930202838};\\\", \\\"{x:1250,y:790,t:1526930202855};\\\", \\\"{x:1253,y:787,t:1526930202871};\\\", \\\"{x:1255,y:785,t:1526930202888};\\\", \\\"{x:1255,y:784,t:1526930202903};\\\", \\\"{x:1256,y:783,t:1526930202921};\\\", \\\"{x:1256,y:781,t:1526930202938};\\\", \\\"{x:1257,y:779,t:1526930202953};\\\", \\\"{x:1258,y:777,t:1526930202971};\\\", \\\"{x:1259,y:774,t:1526930202988};\\\", \\\"{x:1260,y:773,t:1526930203004};\\\", \\\"{x:1260,y:771,t:1526930203021};\\\", \\\"{x:1261,y:770,t:1526930203038};\\\", \\\"{x:1261,y:769,t:1526930203055};\\\", \\\"{x:1261,y:767,t:1526930203071};\\\", \\\"{x:1261,y:766,t:1526930203089};\\\", \\\"{x:1260,y:765,t:1526930203109};\\\", \\\"{x:1258,y:764,t:1526930203149};\\\", \\\"{x:1256,y:764,t:1526930203229};\\\", \\\"{x:1255,y:764,t:1526930203253};\\\", \\\"{x:1253,y:764,t:1526930203271};\\\", \\\"{x:1252,y:764,t:1526930203293};\\\", \\\"{x:1255,y:764,t:1526930204013};\\\", \\\"{x:1257,y:763,t:1526930204023};\\\", \\\"{x:1262,y:761,t:1526930204039};\\\", \\\"{x:1266,y:759,t:1526930204056};\\\", \\\"{x:1268,y:759,t:1526930204072};\\\", \\\"{x:1269,y:759,t:1526930204089};\\\", \\\"{x:1271,y:759,t:1526930204105};\\\", \\\"{x:1274,y:758,t:1526930204123};\\\", \\\"{x:1279,y:758,t:1526930204139};\\\", \\\"{x:1286,y:756,t:1526930204155};\\\", \\\"{x:1293,y:755,t:1526930204173};\\\", \\\"{x:1295,y:755,t:1526930204189};\\\", \\\"{x:1296,y:755,t:1526930204206};\\\", \\\"{x:1297,y:755,t:1526930204278};\\\", \\\"{x:1298,y:755,t:1526930204289};\\\", \\\"{x:1299,y:755,t:1526930204305};\\\", \\\"{x:1301,y:755,t:1526930204322};\\\", \\\"{x:1303,y:755,t:1526930204340};\\\", \\\"{x:1304,y:755,t:1526930204355};\\\", \\\"{x:1304,y:756,t:1526930204373};\\\", \\\"{x:1305,y:756,t:1526930204397};\\\", \\\"{x:1306,y:757,t:1526930204405};\\\", \\\"{x:1307,y:758,t:1526930204429};\\\", \\\"{x:1309,y:759,t:1526930204445};\\\", \\\"{x:1311,y:760,t:1526930204469};\\\", \\\"{x:1312,y:761,t:1526930204485};\\\", \\\"{x:1312,y:762,t:1526930204493};\\\", \\\"{x:1313,y:763,t:1526930204509};\\\", \\\"{x:1314,y:764,t:1526930204525};\\\", \\\"{x:1315,y:764,t:1526930205655};\\\", \\\"{x:1319,y:764,t:1526930205661};\\\", \\\"{x:1323,y:764,t:1526930205673};\\\", \\\"{x:1334,y:762,t:1526930205689};\\\", \\\"{x:1350,y:759,t:1526930205707};\\\", \\\"{x:1367,y:758,t:1526930205725};\\\", \\\"{x:1380,y:755,t:1526930205740};\\\", \\\"{x:1389,y:755,t:1526930205757};\\\", \\\"{x:1392,y:755,t:1526930205773};\\\", \\\"{x:1393,y:755,t:1526930205797};\\\", \\\"{x:1395,y:755,t:1526930205829};\\\", \\\"{x:1394,y:756,t:1526930205974};\\\", \\\"{x:1394,y:757,t:1526930205997};\\\", \\\"{x:1393,y:758,t:1526930206054};\\\", \\\"{x:1392,y:758,t:1526930206101};\\\", \\\"{x:1389,y:758,t:1526930206117};\\\", \\\"{x:1389,y:759,t:1526930206269};\\\", \\\"{x:1388,y:759,t:1526930206277};\\\", \\\"{x:1386,y:760,t:1526930206290};\\\", \\\"{x:1385,y:761,t:1526930206405};\\\", \\\"{x:1384,y:761,t:1526930206421};\\\", \\\"{x:1383,y:762,t:1526930206813};\\\", \\\"{x:1381,y:762,t:1526930206824};\\\", \\\"{x:1380,y:762,t:1526930206868};\\\", \\\"{x:1379,y:763,t:1526930213365};\\\", \\\"{x:1379,y:764,t:1526930213438};\\\", \\\"{x:1378,y:764,t:1526930216157};\\\", \\\"{x:1377,y:765,t:1526930216164};\\\", \\\"{x:1375,y:766,t:1526930216189};\\\", \\\"{x:1374,y:767,t:1526930216197};\\\", \\\"{x:1370,y:772,t:1526930216213};\\\", \\\"{x:1368,y:777,t:1526930216230};\\\", \\\"{x:1365,y:782,t:1526930216247};\\\", \\\"{x:1360,y:793,t:1526930216264};\\\", \\\"{x:1351,y:809,t:1526930216280};\\\", \\\"{x:1345,y:823,t:1526930216297};\\\", \\\"{x:1339,y:835,t:1526930216313};\\\", \\\"{x:1333,y:851,t:1526930216331};\\\", \\\"{x:1327,y:868,t:1526930216347};\\\", \\\"{x:1323,y:883,t:1526930216364};\\\", \\\"{x:1315,y:899,t:1526930216381};\\\", \\\"{x:1313,y:907,t:1526930216396};\\\", \\\"{x:1310,y:910,t:1526930216413};\\\", \\\"{x:1307,y:911,t:1526930216431};\\\", \\\"{x:1305,y:912,t:1526930216447};\\\", \\\"{x:1304,y:912,t:1526930216464};\\\", \\\"{x:1304,y:913,t:1526930216480};\\\", \\\"{x:1303,y:913,t:1526930216565};\\\", \\\"{x:1301,y:911,t:1526930216580};\\\", \\\"{x:1299,y:908,t:1526930216597};\\\", \\\"{x:1295,y:904,t:1526930216614};\\\", \\\"{x:1291,y:897,t:1526930216630};\\\", \\\"{x:1286,y:892,t:1526930216647};\\\", \\\"{x:1279,y:886,t:1526930216664};\\\", \\\"{x:1275,y:880,t:1526930216680};\\\", \\\"{x:1271,y:874,t:1526930216697};\\\", \\\"{x:1266,y:864,t:1526930216714};\\\", \\\"{x:1263,y:856,t:1526930216731};\\\", \\\"{x:1262,y:853,t:1526930216747};\\\", \\\"{x:1261,y:848,t:1526930216763};\\\", \\\"{x:1257,y:842,t:1526930216780};\\\", \\\"{x:1254,y:840,t:1526930216798};\\\", \\\"{x:1250,y:838,t:1526930216814};\\\", \\\"{x:1248,y:838,t:1526930216831};\\\", \\\"{x:1245,y:838,t:1526930216848};\\\", \\\"{x:1241,y:838,t:1526930216864};\\\", \\\"{x:1238,y:838,t:1526930216881};\\\", \\\"{x:1233,y:838,t:1526930216898};\\\", \\\"{x:1226,y:838,t:1526930216914};\\\", \\\"{x:1220,y:838,t:1526930216931};\\\", \\\"{x:1217,y:838,t:1526930216947};\\\", \\\"{x:1216,y:837,t:1526930217309};\\\", \\\"{x:1215,y:835,t:1526930217317};\\\", \\\"{x:1215,y:833,t:1526930217330};\\\", \\\"{x:1215,y:829,t:1526930217347};\\\", \\\"{x:1214,y:821,t:1526930217364};\\\", \\\"{x:1212,y:807,t:1526930217380};\\\", \\\"{x:1223,y:760,t:1526930217398};\\\", \\\"{x:1227,y:741,t:1526930217415};\\\", \\\"{x:1227,y:727,t:1526930217430};\\\", \\\"{x:1227,y:716,t:1526930217448};\\\", \\\"{x:1228,y:706,t:1526930217464};\\\", \\\"{x:1230,y:700,t:1526930217480};\\\", \\\"{x:1233,y:694,t:1526930217497};\\\", \\\"{x:1236,y:690,t:1526930217514};\\\", \\\"{x:1236,y:687,t:1526930217530};\\\", \\\"{x:1238,y:685,t:1526930217547};\\\", \\\"{x:1239,y:682,t:1526930217564};\\\", \\\"{x:1240,y:681,t:1526930217596};\\\", \\\"{x:1241,y:681,t:1526930217924};\\\", \\\"{x:1246,y:679,t:1526930217932};\\\", \\\"{x:1251,y:676,t:1526930217948};\\\", \\\"{x:1253,y:675,t:1526930217965};\\\", \\\"{x:1254,y:675,t:1526930218629};\\\", \\\"{x:1254,y:673,t:1526930218636};\\\", \\\"{x:1253,y:669,t:1526930218649};\\\", \\\"{x:1245,y:664,t:1526930218665};\\\", \\\"{x:1210,y:651,t:1526930218682};\\\", \\\"{x:1160,y:637,t:1526930218699};\\\", \\\"{x:1093,y:616,t:1526930218715};\\\", \\\"{x:1022,y:602,t:1526930218733};\\\", \\\"{x:872,y:598,t:1526930218749};\\\", \\\"{x:747,y:598,t:1526930218765};\\\", \\\"{x:665,y:593,t:1526930218783};\\\", \\\"{x:652,y:592,t:1526930218798};\\\", \\\"{x:651,y:592,t:1526930218835};\\\", \\\"{x:648,y:592,t:1526930218850};\\\", \\\"{x:644,y:593,t:1526930218868};\\\", \\\"{x:640,y:593,t:1526930218884};\\\", \\\"{x:638,y:593,t:1526930218908};\\\", \\\"{x:637,y:593,t:1526930218972};\\\", \\\"{x:633,y:592,t:1526930218983};\\\", \\\"{x:624,y:589,t:1526930219000};\\\", \\\"{x:607,y:586,t:1526930219018};\\\", \\\"{x:585,y:584,t:1526930219034};\\\", \\\"{x:546,y:581,t:1526930219052};\\\", \\\"{x:517,y:581,t:1526930219067};\\\", \\\"{x:498,y:581,t:1526930219086};\\\", \\\"{x:484,y:581,t:1526930219101};\\\", \\\"{x:473,y:582,t:1526930219118};\\\", \\\"{x:467,y:586,t:1526930219134};\\\", \\\"{x:460,y:590,t:1526930219151};\\\", \\\"{x:454,y:593,t:1526930219167};\\\", \\\"{x:452,y:594,t:1526930219185};\\\", \\\"{x:444,y:596,t:1526930219201};\\\", \\\"{x:423,y:604,t:1526930219219};\\\", \\\"{x:399,y:613,t:1526930219236};\\\", \\\"{x:378,y:621,t:1526930219252};\\\", \\\"{x:375,y:622,t:1526930219268};\\\", \\\"{x:372,y:622,t:1526930219285};\\\", \\\"{x:371,y:622,t:1526930219302};\\\", \\\"{x:369,y:622,t:1526930219318};\\\", \\\"{x:367,y:622,t:1526930219335};\\\", \\\"{x:360,y:622,t:1526930219351};\\\", \\\"{x:354,y:622,t:1526930219368};\\\", \\\"{x:351,y:622,t:1526930219385};\\\", \\\"{x:350,y:622,t:1526930219401};\\\", \\\"{x:350,y:621,t:1526930219454};\\\", \\\"{x:353,y:617,t:1526930219469};\\\", \\\"{x:360,y:614,t:1526930219486};\\\", \\\"{x:367,y:608,t:1526930219501};\\\", \\\"{x:369,y:604,t:1526930219519};\\\", \\\"{x:371,y:599,t:1526930219536};\\\", \\\"{x:373,y:591,t:1526930219552};\\\", \\\"{x:373,y:574,t:1526930219573};\\\", \\\"{x:371,y:568,t:1526930219586};\\\", \\\"{x:364,y:560,t:1526930219602};\\\", \\\"{x:349,y:550,t:1526930219618};\\\", \\\"{x:326,y:543,t:1526930219635};\\\", \\\"{x:302,y:538,t:1526930219652};\\\", \\\"{x:263,y:538,t:1526930219669};\\\", \\\"{x:230,y:536,t:1526930219685};\\\", \\\"{x:205,y:532,t:1526930219701};\\\", \\\"{x:193,y:528,t:1526930219718};\\\", \\\"{x:191,y:526,t:1526930219735};\\\", \\\"{x:190,y:526,t:1526930219751};\\\", \\\"{x:189,y:525,t:1526930219771};\\\", \\\"{x:189,y:524,t:1526930219786};\\\", \\\"{x:186,y:522,t:1526930219802};\\\", \\\"{x:177,y:517,t:1526930219819};\\\", \\\"{x:170,y:515,t:1526930219836};\\\", \\\"{x:169,y:513,t:1526930219853};\\\", \\\"{x:168,y:513,t:1526930219868};\\\", \\\"{x:167,y:512,t:1526930219924};\\\", \\\"{x:164,y:511,t:1526930219936};\\\", \\\"{x:155,y:507,t:1526930219953};\\\", \\\"{x:153,y:504,t:1526930219969};\\\", \\\"{x:151,y:503,t:1526930219986};\\\", \\\"{x:151,y:502,t:1526930220001};\\\", \\\"{x:151,y:501,t:1526930220317};\\\", \\\"{x:153,y:501,t:1526930220325};\\\", \\\"{x:158,y:504,t:1526930220336};\\\", \\\"{x:169,y:514,t:1526930220353};\\\", \\\"{x:186,y:535,t:1526930220370};\\\", \\\"{x:206,y:557,t:1526930220386};\\\", \\\"{x:225,y:572,t:1526930220403};\\\", \\\"{x:256,y:593,t:1526930220419};\\\", \\\"{x:275,y:608,t:1526930220436};\\\", \\\"{x:297,y:623,t:1526930220453};\\\", \\\"{x:319,y:642,t:1526930220470};\\\", \\\"{x:330,y:651,t:1526930220485};\\\", \\\"{x:340,y:659,t:1526930220502};\\\", \\\"{x:346,y:662,t:1526930220519};\\\", \\\"{x:350,y:663,t:1526930220536};\\\", \\\"{x:352,y:665,t:1526930220553};\\\", \\\"{x:353,y:666,t:1526930220569};\\\", \\\"{x:354,y:666,t:1526930220700};\\\", \\\"{x:354,y:665,t:1526930220708};\\\", \\\"{x:352,y:660,t:1526930220719};\\\", \\\"{x:346,y:645,t:1526930220737};\\\", \\\"{x:333,y:622,t:1526930220755};\\\", \\\"{x:313,y:595,t:1526930220771};\\\", \\\"{x:288,y:562,t:1526930220786};\\\", \\\"{x:244,y:525,t:1526930220803};\\\", \\\"{x:190,y:487,t:1526930220820};\\\", \\\"{x:175,y:476,t:1526930220837};\\\", \\\"{x:173,y:475,t:1526930220852};\\\", \\\"{x:172,y:475,t:1526930221141};\\\", \\\"{x:170,y:475,t:1526930221152};\\\", \\\"{x:166,y:475,t:1526930221170};\\\", \\\"{x:164,y:476,t:1526930221186};\\\", \\\"{x:163,y:478,t:1526930221204};\\\", \\\"{x:162,y:480,t:1526930221220};\\\", \\\"{x:161,y:482,t:1526930221269};\\\", \\\"{x:161,y:483,t:1526930221293};\\\", \\\"{x:161,y:486,t:1526930221302};\\\", \\\"{x:161,y:492,t:1526930221321};\\\", \\\"{x:163,y:495,t:1526930221335};\\\", \\\"{x:164,y:498,t:1526930221353};\\\", \\\"{x:165,y:498,t:1526930221369};\\\", \\\"{x:167,y:502,t:1526930221973};\\\", \\\"{x:183,y:518,t:1526930221989};\\\", \\\"{x:193,y:528,t:1526930222005};\\\", \\\"{x:244,y:569,t:1526930222021};\\\", \\\"{x:277,y:596,t:1526930222038};\\\", \\\"{x:304,y:620,t:1526930222054};\\\", \\\"{x:331,y:638,t:1526930222071};\\\", \\\"{x:350,y:650,t:1526930222088};\\\", \\\"{x:360,y:657,t:1526930222104};\\\", \\\"{x:366,y:661,t:1526930222121};\\\", \\\"{x:367,y:663,t:1526930222138};\\\", \\\"{x:369,y:663,t:1526930222153};\\\", \\\"{x:372,y:664,t:1526930222170};\\\", \\\"{x:375,y:667,t:1526930222187};\\\", \\\"{x:377,y:668,t:1526930222203};\\\", \\\"{x:380,y:670,t:1526930222221};\\\", \\\"{x:381,y:671,t:1526930222237};\\\", \\\"{x:382,y:671,t:1526930222284};\\\", \\\"{x:383,y:671,t:1526930222300};\\\", \\\"{x:387,y:672,t:1526930222308};\\\", \\\"{x:389,y:673,t:1526930222320};\\\", \\\"{x:395,y:676,t:1526930222338};\\\", \\\"{x:401,y:679,t:1526930222354};\\\", \\\"{x:408,y:684,t:1526930222370};\\\", \\\"{x:424,y:696,t:1526930222388};\\\", \\\"{x:438,y:705,t:1526930222404};\\\", \\\"{x:451,y:714,t:1526930222420};\\\", \\\"{x:461,y:720,t:1526930222438};\\\", \\\"{x:467,y:725,t:1526930222455};\\\", \\\"{x:470,y:727,t:1526930222471};\\\", \\\"{x:473,y:729,t:1526930222487};\\\", \\\"{x:475,y:730,t:1526930222504};\\\", \\\"{x:477,y:730,t:1526930222521};\\\", \\\"{x:479,y:733,t:1526930222537};\\\", \\\"{x:483,y:734,t:1526930222555};\\\", \\\"{x:488,y:736,t:1526930222571};\\\", \\\"{x:492,y:739,t:1526930222588};\\\", \\\"{x:494,y:740,t:1526930222605};\\\", \\\"{x:494,y:741,t:1526930223724};\\\" ] }, { \\\"rt\\\": 44213, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 624816, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-F -Z -Z -Z -O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:741,t:1526930224267};\\\", \\\"{x:491,y:741,t:1526930224285};\\\", \\\"{x:490,y:742,t:1526930224291};\\\", \\\"{x:489,y:742,t:1526930224305};\\\", \\\"{x:490,y:741,t:1526930226685};\\\", \\\"{x:491,y:741,t:1526930226692};\\\", \\\"{x:492,y:740,t:1526930226707};\\\", \\\"{x:493,y:739,t:1526930226733};\\\", \\\"{x:494,y:738,t:1526930226748};\\\", \\\"{x:496,y:737,t:1526930226765};\\\", \\\"{x:496,y:736,t:1526930226774};\\\", \\\"{x:499,y:735,t:1526930226790};\\\", \\\"{x:501,y:733,t:1526930226807};\\\", \\\"{x:503,y:732,t:1526930226824};\\\", \\\"{x:504,y:732,t:1526930226844};\\\", \\\"{x:505,y:732,t:1526930227837};\\\", \\\"{x:512,y:730,t:1526930227845};\\\", \\\"{x:520,y:727,t:1526930227858};\\\", \\\"{x:547,y:719,t:1526930227875};\\\", \\\"{x:589,y:716,t:1526930227890};\\\", \\\"{x:641,y:716,t:1526930227908};\\\", \\\"{x:663,y:720,t:1526930227925};\\\", \\\"{x:690,y:728,t:1526930227942};\\\", \\\"{x:727,y:739,t:1526930227958};\\\", \\\"{x:793,y:745,t:1526930227976};\\\", \\\"{x:904,y:749,t:1526930227992};\\\", \\\"{x:1056,y:769,t:1526930228009};\\\", \\\"{x:1223,y:776,t:1526930228026};\\\", \\\"{x:1389,y:776,t:1526930228041};\\\", \\\"{x:1522,y:776,t:1526930228059};\\\", \\\"{x:1622,y:776,t:1526930228076};\\\", \\\"{x:1645,y:773,t:1526930228092};\\\", \\\"{x:1666,y:770,t:1526930228109};\\\", \\\"{x:1683,y:765,t:1526930228126};\\\", \\\"{x:1700,y:760,t:1526930228142};\\\", \\\"{x:1710,y:759,t:1526930228159};\\\", \\\"{x:1713,y:758,t:1526930228176};\\\", \\\"{x:1708,y:758,t:1526930228316};\\\", \\\"{x:1699,y:760,t:1526930228326};\\\", \\\"{x:1680,y:762,t:1526930228343};\\\", \\\"{x:1667,y:764,t:1526930228358};\\\", \\\"{x:1664,y:765,t:1526930228376};\\\", \\\"{x:1663,y:765,t:1526930228393};\\\", \\\"{x:1657,y:763,t:1526930228451};\\\", \\\"{x:1646,y:753,t:1526930228460};\\\", \\\"{x:1608,y:731,t:1526930228476};\\\", \\\"{x:1582,y:713,t:1526930228493};\\\", \\\"{x:1554,y:688,t:1526930228510};\\\", \\\"{x:1541,y:673,t:1526930228526};\\\", \\\"{x:1538,y:667,t:1526930228543};\\\", \\\"{x:1535,y:664,t:1526930228560};\\\", \\\"{x:1535,y:663,t:1526930228575};\\\", \\\"{x:1532,y:663,t:1526930228908};\\\", \\\"{x:1529,y:663,t:1526930228917};\\\", \\\"{x:1526,y:663,t:1526930228927};\\\", \\\"{x:1521,y:663,t:1526930228943};\\\", \\\"{x:1517,y:665,t:1526930228960};\\\", \\\"{x:1513,y:666,t:1526930228978};\\\", \\\"{x:1510,y:667,t:1526930228993};\\\", \\\"{x:1506,y:668,t:1526930229010};\\\", \\\"{x:1500,y:668,t:1526930229027};\\\", \\\"{x:1489,y:673,t:1526930229043};\\\", \\\"{x:1463,y:683,t:1526930229060};\\\", \\\"{x:1446,y:688,t:1526930229078};\\\", \\\"{x:1430,y:691,t:1526930229094};\\\", \\\"{x:1420,y:693,t:1526930229110};\\\", \\\"{x:1417,y:694,t:1526930229128};\\\", \\\"{x:1414,y:696,t:1526930229144};\\\", \\\"{x:1409,y:697,t:1526930229161};\\\", \\\"{x:1405,y:699,t:1526930229178};\\\", \\\"{x:1402,y:699,t:1526930229194};\\\", \\\"{x:1400,y:700,t:1526930229210};\\\", \\\"{x:1399,y:700,t:1526930229227};\\\", \\\"{x:1397,y:700,t:1526930229244};\\\", \\\"{x:1396,y:701,t:1526930229325};\\\", \\\"{x:1394,y:701,t:1526930229572};\\\", \\\"{x:1393,y:701,t:1526930229580};\\\", \\\"{x:1392,y:701,t:1526930229594};\\\", \\\"{x:1390,y:701,t:1526930229611};\\\", \\\"{x:1388,y:701,t:1526930229628};\\\", \\\"{x:1386,y:700,t:1526930229644};\\\", \\\"{x:1384,y:699,t:1526930229660};\\\", \\\"{x:1382,y:699,t:1526930229677};\\\", \\\"{x:1380,y:698,t:1526930229694};\\\", \\\"{x:1375,y:696,t:1526930229711};\\\", \\\"{x:1372,y:696,t:1526930229728};\\\", \\\"{x:1371,y:696,t:1526930229744};\\\", \\\"{x:1370,y:696,t:1526930229761};\\\", \\\"{x:1369,y:696,t:1526930229789};\\\", \\\"{x:1368,y:695,t:1526930229797};\\\", \\\"{x:1367,y:695,t:1526930229811};\\\", \\\"{x:1366,y:695,t:1526930229828};\\\", \\\"{x:1365,y:695,t:1526930229844};\\\", \\\"{x:1364,y:695,t:1526930229900};\\\", \\\"{x:1363,y:695,t:1526930229917};\\\", \\\"{x:1362,y:695,t:1526930229928};\\\", \\\"{x:1360,y:695,t:1526930229945};\\\", \\\"{x:1359,y:695,t:1526930229961};\\\", \\\"{x:1358,y:695,t:1526930229978};\\\", \\\"{x:1357,y:695,t:1526930230045};\\\", \\\"{x:1355,y:696,t:1526930230061};\\\", \\\"{x:1354,y:696,t:1526930230293};\\\", \\\"{x:1353,y:696,t:1526930230359};\\\", \\\"{x:1354,y:696,t:1526930230765};\\\", \\\"{x:1356,y:695,t:1526930230780};\\\", \\\"{x:1359,y:694,t:1526930230795};\\\", \\\"{x:1362,y:693,t:1526930230812};\\\", \\\"{x:1365,y:693,t:1526930230829};\\\", \\\"{x:1366,y:693,t:1526930230846};\\\", \\\"{x:1369,y:693,t:1526930230862};\\\", \\\"{x:1373,y:694,t:1526930230879};\\\", \\\"{x:1378,y:696,t:1526930230897};\\\", \\\"{x:1384,y:696,t:1526930230912};\\\", \\\"{x:1390,y:696,t:1526930230929};\\\", \\\"{x:1394,y:696,t:1526930230946};\\\", \\\"{x:1397,y:696,t:1526930230962};\\\", \\\"{x:1400,y:698,t:1526930230979};\\\", \\\"{x:1411,y:702,t:1526930230996};\\\", \\\"{x:1417,y:702,t:1526930231013};\\\", \\\"{x:1420,y:702,t:1526930231030};\\\", \\\"{x:1421,y:702,t:1526930231046};\\\", \\\"{x:1423,y:702,t:1526930231140};\\\", \\\"{x:1424,y:702,t:1526930231341};\\\", \\\"{x:1429,y:701,t:1526930231348};\\\", \\\"{x:1432,y:699,t:1526930231363};\\\", \\\"{x:1434,y:698,t:1526930231379};\\\", \\\"{x:1435,y:698,t:1526930231396};\\\", \\\"{x:1436,y:698,t:1526930231501};\\\", \\\"{x:1439,y:697,t:1526930231514};\\\", \\\"{x:1447,y:695,t:1526930231530};\\\", \\\"{x:1451,y:692,t:1526930231546};\\\", \\\"{x:1456,y:690,t:1526930231563};\\\", \\\"{x:1463,y:689,t:1526930231580};\\\", \\\"{x:1466,y:688,t:1526930231596};\\\", \\\"{x:1467,y:688,t:1526930231643};\\\", \\\"{x:1467,y:687,t:1526930231651};\\\", \\\"{x:1467,y:688,t:1526930231780};\\\", \\\"{x:1467,y:689,t:1526930231844};\\\", \\\"{x:1468,y:692,t:1526930231884};\\\", \\\"{x:1473,y:694,t:1526930231897};\\\", \\\"{x:1490,y:702,t:1526930231913};\\\", \\\"{x:1507,y:707,t:1526930231931};\\\", \\\"{x:1526,y:713,t:1526930231947};\\\", \\\"{x:1533,y:714,t:1526930231963};\\\", \\\"{x:1535,y:716,t:1526930231980};\\\", \\\"{x:1537,y:716,t:1526930232149};\\\", \\\"{x:1540,y:715,t:1526930232164};\\\", \\\"{x:1556,y:707,t:1526930232181};\\\", \\\"{x:1557,y:707,t:1526930232198};\\\", \\\"{x:1558,y:707,t:1526930232214};\\\", \\\"{x:1559,y:706,t:1526930232252};\\\", \\\"{x:1560,y:706,t:1526930232269};\\\", \\\"{x:1562,y:705,t:1526930232280};\\\", \\\"{x:1566,y:705,t:1526930232297};\\\", \\\"{x:1570,y:705,t:1526930232314};\\\", \\\"{x:1573,y:705,t:1526930232330};\\\", \\\"{x:1576,y:705,t:1526930232348};\\\", \\\"{x:1581,y:704,t:1526930232372};\\\", \\\"{x:1607,y:698,t:1526930232422};\\\", \\\"{x:1610,y:697,t:1526930232430};\\\", \\\"{x:1613,y:697,t:1526930232447};\\\", \\\"{x:1615,y:697,t:1526930234141};\\\", \\\"{x:1616,y:697,t:1526930234572};\\\", \\\"{x:1614,y:700,t:1526930234820};\\\", \\\"{x:1606,y:704,t:1526930234835};\\\", \\\"{x:1579,y:711,t:1526930234851};\\\", \\\"{x:1483,y:720,t:1526930234868};\\\", \\\"{x:1430,y:720,t:1526930234883};\\\", \\\"{x:1289,y:720,t:1526930234900};\\\", \\\"{x:1233,y:720,t:1526930234918};\\\", \\\"{x:1199,y:719,t:1526930234933};\\\", \\\"{x:1179,y:716,t:1526930234950};\\\", \\\"{x:1173,y:715,t:1526930234968};\\\", \\\"{x:1172,y:715,t:1526930234984};\\\", \\\"{x:1171,y:715,t:1526930235013};\\\", \\\"{x:1168,y:715,t:1526930235077};\\\", \\\"{x:1163,y:715,t:1526930235084};\\\", \\\"{x:1135,y:715,t:1526930235100};\\\", \\\"{x:1099,y:712,t:1526930235117};\\\", \\\"{x:1048,y:695,t:1526930235134};\\\", \\\"{x:992,y:676,t:1526930235149};\\\", \\\"{x:939,y:653,t:1526930235167};\\\", \\\"{x:910,y:640,t:1526930235184};\\\", \\\"{x:892,y:629,t:1526930235200};\\\", \\\"{x:883,y:623,t:1526930235217};\\\", \\\"{x:879,y:619,t:1526930235233};\\\", \\\"{x:877,y:618,t:1526930235248};\\\", \\\"{x:874,y:616,t:1526930235263};\\\", \\\"{x:872,y:614,t:1526930235280};\\\", \\\"{x:868,y:613,t:1526930235298};\\\", \\\"{x:863,y:610,t:1526930235314};\\\", \\\"{x:861,y:607,t:1526930235332};\\\", \\\"{x:860,y:606,t:1526930235355};\\\", \\\"{x:859,y:605,t:1526930235468};\\\", \\\"{x:858,y:605,t:1526930235484};\\\", \\\"{x:857,y:605,t:1526930235508};\\\", \\\"{x:856,y:605,t:1526930235516};\\\", \\\"{x:855,y:605,t:1526930235533};\\\", \\\"{x:854,y:605,t:1526930235548};\\\", \\\"{x:860,y:605,t:1526930238300};\\\", \\\"{x:904,y:600,t:1526930238319};\\\", \\\"{x:993,y:598,t:1526930238333};\\\", \\\"{x:1132,y:598,t:1526930238350};\\\", \\\"{x:1306,y:598,t:1526930238367};\\\", \\\"{x:1466,y:598,t:1526930238383};\\\", \\\"{x:1591,y:598,t:1526930238400};\\\", \\\"{x:1658,y:607,t:1526930238417};\\\", \\\"{x:1681,y:616,t:1526930238434};\\\", \\\"{x:1682,y:616,t:1526930238524};\\\", \\\"{x:1682,y:618,t:1526930238534};\\\", \\\"{x:1668,y:629,t:1526930238550};\\\", \\\"{x:1656,y:637,t:1526930238568};\\\", \\\"{x:1640,y:645,t:1526930238585};\\\", \\\"{x:1633,y:650,t:1526930238601};\\\", \\\"{x:1629,y:653,t:1526930238618};\\\", \\\"{x:1629,y:654,t:1526930238708};\\\", \\\"{x:1629,y:656,t:1526930238718};\\\", \\\"{x:1629,y:658,t:1526930238735};\\\", \\\"{x:1631,y:665,t:1526930238751};\\\", \\\"{x:1631,y:668,t:1526930238768};\\\", \\\"{x:1632,y:671,t:1526930238784};\\\", \\\"{x:1633,y:675,t:1526930238802};\\\", \\\"{x:1634,y:677,t:1526930238818};\\\", \\\"{x:1634,y:678,t:1526930238835};\\\", \\\"{x:1635,y:681,t:1526930238851};\\\", \\\"{x:1635,y:683,t:1526930238868};\\\", \\\"{x:1635,y:684,t:1526930238885};\\\", \\\"{x:1635,y:685,t:1526930238902};\\\", \\\"{x:1635,y:686,t:1526930238924};\\\", \\\"{x:1634,y:686,t:1526930238940};\\\", \\\"{x:1634,y:687,t:1526930238972};\\\", \\\"{x:1633,y:688,t:1526930238985};\\\", \\\"{x:1632,y:689,t:1526930239001};\\\", \\\"{x:1630,y:691,t:1526930239017};\\\", \\\"{x:1629,y:691,t:1526930239035};\\\", \\\"{x:1628,y:692,t:1526930239052};\\\", \\\"{x:1628,y:693,t:1526930239068};\\\", \\\"{x:1627,y:693,t:1526930239092};\\\", \\\"{x:1626,y:694,t:1526930239108};\\\", \\\"{x:1625,y:694,t:1526930239117};\\\", \\\"{x:1625,y:696,t:1526930239135};\\\", \\\"{x:1623,y:697,t:1526930239151};\\\", \\\"{x:1622,y:698,t:1526930239180};\\\", \\\"{x:1620,y:698,t:1526930239284};\\\", \\\"{x:1619,y:698,t:1526930239319};\\\", \\\"{x:1618,y:699,t:1526930239412};\\\", \\\"{x:1617,y:700,t:1526930239420};\\\", \\\"{x:1616,y:700,t:1526930240124};\\\", \\\"{x:1615,y:699,t:1526930240324};\\\", \\\"{x:1614,y:699,t:1526930244347};\\\", \\\"{x:1613,y:699,t:1526930244354};\\\", \\\"{x:1612,y:699,t:1526930244435};\\\", \\\"{x:1611,y:699,t:1526930244571};\\\", \\\"{x:1610,y:699,t:1526930245067};\\\", \\\"{x:1611,y:698,t:1526930245091};\\\", \\\"{x:1611,y:697,t:1526930245107};\\\", \\\"{x:1611,y:696,t:1526930245779};\\\", \\\"{x:1613,y:696,t:1526930245790};\\\", \\\"{x:1615,y:696,t:1526930245805};\\\", \\\"{x:1617,y:697,t:1526930245823};\\\", \\\"{x:1620,y:700,t:1526930245841};\\\", \\\"{x:1621,y:702,t:1526930245855};\\\", \\\"{x:1621,y:701,t:1526930246203};\\\", \\\"{x:1620,y:701,t:1526930246762};\\\", \\\"{x:1620,y:700,t:1526930247547};\\\", \\\"{x:1619,y:700,t:1526930247579};\\\", \\\"{x:1618,y:700,t:1526930247667};\\\", \\\"{x:1617,y:700,t:1526930248107};\\\", \\\"{x:1616,y:699,t:1526930248146};\\\", \\\"{x:1615,y:698,t:1526930248171};\\\", \\\"{x:1614,y:697,t:1526930248179};\\\", \\\"{x:1614,y:696,t:1526930248259};\\\", \\\"{x:1611,y:696,t:1526930259570};\\\", \\\"{x:1609,y:696,t:1526930259583};\\\", \\\"{x:1609,y:697,t:1526930259699};\\\", \\\"{x:1610,y:697,t:1526930259770};\\\", \\\"{x:1611,y:698,t:1526930259794};\\\", \\\"{x:1611,y:699,t:1526930259826};\\\", \\\"{x:1611,y:700,t:1526930259922};\\\", \\\"{x:1611,y:701,t:1526930259935};\\\", \\\"{x:1608,y:703,t:1526930259951};\\\", \\\"{x:1604,y:705,t:1526930259967};\\\", \\\"{x:1601,y:708,t:1526930259984};\\\", \\\"{x:1594,y:711,t:1526930260000};\\\", \\\"{x:1577,y:721,t:1526930260018};\\\", \\\"{x:1560,y:728,t:1526930260034};\\\", \\\"{x:1542,y:739,t:1526930260050};\\\", \\\"{x:1529,y:748,t:1526930260067};\\\", \\\"{x:1522,y:751,t:1526930260085};\\\", \\\"{x:1518,y:753,t:1526930260101};\\\", \\\"{x:1514,y:755,t:1526930260118};\\\", \\\"{x:1514,y:756,t:1526930260134};\\\", \\\"{x:1513,y:756,t:1526930260162};\\\", \\\"{x:1512,y:757,t:1526930260186};\\\", \\\"{x:1511,y:759,t:1526930260716};\\\", \\\"{x:1513,y:764,t:1526930260735};\\\", \\\"{x:1515,y:767,t:1526930260752};\\\", \\\"{x:1516,y:769,t:1526930260770};\\\", \\\"{x:1517,y:770,t:1526930260785};\\\", \\\"{x:1517,y:771,t:1526930260962};\\\", \\\"{x:1515,y:773,t:1526930260979};\\\", \\\"{x:1514,y:774,t:1526930260986};\\\", \\\"{x:1511,y:777,t:1526930261003};\\\", \\\"{x:1509,y:784,t:1526930261019};\\\", \\\"{x:1505,y:794,t:1526930261036};\\\", \\\"{x:1503,y:802,t:1526930261052};\\\", \\\"{x:1503,y:807,t:1526930261070};\\\", \\\"{x:1503,y:810,t:1526930261086};\\\", \\\"{x:1503,y:813,t:1526930261102};\\\", \\\"{x:1503,y:814,t:1526930261123};\\\", \\\"{x:1503,y:815,t:1526930261136};\\\", \\\"{x:1504,y:817,t:1526930261152};\\\", \\\"{x:1505,y:818,t:1526930261170};\\\", \\\"{x:1506,y:819,t:1526930261202};\\\", \\\"{x:1506,y:820,t:1526930261315};\\\", \\\"{x:1506,y:821,t:1526930261322};\\\", \\\"{x:1506,y:822,t:1526930261335};\\\", \\\"{x:1505,y:822,t:1526930261352};\\\", \\\"{x:1503,y:824,t:1526930261368};\\\", \\\"{x:1501,y:824,t:1526930261386};\\\", \\\"{x:1501,y:825,t:1526930261402};\\\", \\\"{x:1499,y:827,t:1526930261419};\\\", \\\"{x:1497,y:829,t:1526930261436};\\\", \\\"{x:1496,y:830,t:1526930261453};\\\", \\\"{x:1495,y:830,t:1526930261469};\\\", \\\"{x:1495,y:831,t:1526930261963};\\\", \\\"{x:1496,y:831,t:1526930261970};\\\", \\\"{x:1498,y:831,t:1526930261985};\\\", \\\"{x:1500,y:831,t:1526930262003};\\\", \\\"{x:1504,y:831,t:1526930262019};\\\", \\\"{x:1507,y:831,t:1526930262036};\\\", \\\"{x:1513,y:831,t:1526930262053};\\\", \\\"{x:1516,y:831,t:1526930262070};\\\", \\\"{x:1519,y:831,t:1526930262086};\\\", \\\"{x:1521,y:831,t:1526930262103};\\\", \\\"{x:1523,y:831,t:1526930262120};\\\", \\\"{x:1526,y:830,t:1526930262136};\\\", \\\"{x:1530,y:828,t:1526930262152};\\\", \\\"{x:1533,y:827,t:1526930262170};\\\", \\\"{x:1535,y:827,t:1526930262202};\\\", \\\"{x:1536,y:825,t:1526930262220};\\\", \\\"{x:1539,y:825,t:1526930262235};\\\", \\\"{x:1541,y:825,t:1526930262253};\\\", \\\"{x:1543,y:825,t:1526930262270};\\\", \\\"{x:1546,y:825,t:1526930262287};\\\", \\\"{x:1550,y:825,t:1526930262303};\\\", \\\"{x:1553,y:825,t:1526930262320};\\\", \\\"{x:1556,y:825,t:1526930262337};\\\", \\\"{x:1558,y:825,t:1526930262353};\\\", \\\"{x:1559,y:825,t:1526930262370};\\\", \\\"{x:1561,y:825,t:1526930262395};\\\", \\\"{x:1562,y:825,t:1526930262403};\\\", \\\"{x:1563,y:826,t:1526930262420};\\\", \\\"{x:1566,y:827,t:1526930262437};\\\", \\\"{x:1567,y:827,t:1526930262453};\\\", \\\"{x:1568,y:827,t:1526930262470};\\\", \\\"{x:1570,y:828,t:1526930262487};\\\", \\\"{x:1571,y:828,t:1526930262503};\\\", \\\"{x:1572,y:829,t:1526930262619};\\\", \\\"{x:1571,y:830,t:1526930263427};\\\", \\\"{x:1573,y:831,t:1526930263611};\\\", \\\"{x:1577,y:831,t:1526930263621};\\\", \\\"{x:1590,y:831,t:1526930263638};\\\", \\\"{x:1597,y:832,t:1526930263654};\\\", \\\"{x:1602,y:833,t:1526930263671};\\\", \\\"{x:1605,y:835,t:1526930263688};\\\", \\\"{x:1609,y:835,t:1526930263705};\\\", \\\"{x:1612,y:835,t:1526930263721};\\\", \\\"{x:1620,y:835,t:1526930263739};\\\", \\\"{x:1618,y:835,t:1526930263946};\\\", \\\"{x:1617,y:835,t:1526930263955};\\\", \\\"{x:1616,y:835,t:1526930263971};\\\", \\\"{x:1615,y:834,t:1526930263988};\\\", \\\"{x:1612,y:832,t:1526930264005};\\\", \\\"{x:1611,y:831,t:1526930264022};\\\", \\\"{x:1610,y:830,t:1526930264039};\\\", \\\"{x:1610,y:829,t:1526930264675};\\\", \\\"{x:1610,y:828,t:1526930264722};\\\", \\\"{x:1608,y:828,t:1526930265066};\\\", \\\"{x:1603,y:828,t:1526930265074};\\\", \\\"{x:1593,y:828,t:1526930265089};\\\", \\\"{x:1553,y:828,t:1526930265107};\\\", \\\"{x:1489,y:828,t:1526930265122};\\\", \\\"{x:1372,y:828,t:1526930265139};\\\", \\\"{x:1240,y:812,t:1526930265156};\\\", \\\"{x:1074,y:788,t:1526930265172};\\\", \\\"{x:904,y:754,t:1526930265190};\\\", \\\"{x:736,y:709,t:1526930265206};\\\", \\\"{x:618,y:687,t:1526930265223};\\\", \\\"{x:540,y:672,t:1526930265239};\\\", \\\"{x:510,y:662,t:1526930265256};\\\", \\\"{x:504,y:659,t:1526930265272};\\\", \\\"{x:504,y:658,t:1526930265289};\\\", \\\"{x:505,y:655,t:1526930265306};\\\", \\\"{x:510,y:649,t:1526930265322};\\\", \\\"{x:513,y:642,t:1526930265339};\\\", \\\"{x:517,y:636,t:1526930265356};\\\", \\\"{x:522,y:629,t:1526930265374};\\\", \\\"{x:528,y:622,t:1526930265388};\\\", \\\"{x:531,y:618,t:1526930265406};\\\", \\\"{x:532,y:616,t:1526930265421};\\\", \\\"{x:534,y:614,t:1526930265437};\\\", \\\"{x:539,y:611,t:1526930265453};\\\", \\\"{x:540,y:610,t:1526930265471};\\\", \\\"{x:542,y:610,t:1526930265487};\\\", \\\"{x:543,y:610,t:1526930265505};\\\", \\\"{x:546,y:610,t:1526930265520};\\\", \\\"{x:552,y:612,t:1526930265536};\\\", \\\"{x:563,y:617,t:1526930265553};\\\", \\\"{x:573,y:618,t:1526930265570};\\\", \\\"{x:583,y:620,t:1526930265587};\\\", \\\"{x:588,y:620,t:1526930265604};\\\", \\\"{x:591,y:620,t:1526930265621};\\\", \\\"{x:596,y:618,t:1526930265637};\\\", \\\"{x:602,y:612,t:1526930265654};\\\", \\\"{x:608,y:605,t:1526930265671};\\\", \\\"{x:612,y:598,t:1526930265688};\\\", \\\"{x:613,y:593,t:1526930265705};\\\", \\\"{x:616,y:589,t:1526930265721};\\\", \\\"{x:617,y:581,t:1526930265737};\\\", \\\"{x:618,y:579,t:1526930265753};\\\", \\\"{x:618,y:578,t:1526930265771};\\\", \\\"{x:618,y:577,t:1526930265817};\\\", \\\"{x:618,y:576,t:1526930265833};\\\", \\\"{x:618,y:575,t:1526930265841};\\\", \\\"{x:617,y:575,t:1526930266554};\\\", \\\"{x:616,y:576,t:1526930267218};\\\", \\\"{x:615,y:578,t:1526930267226};\\\", \\\"{x:614,y:580,t:1526930267239};\\\", \\\"{x:614,y:582,t:1526930267256};\\\", \\\"{x:614,y:590,t:1526930267273};\\\", \\\"{x:621,y:596,t:1526930267290};\\\", \\\"{x:627,y:603,t:1526930267306};\\\", \\\"{x:630,y:606,t:1526930267321};\\\", \\\"{x:631,y:608,t:1526930267339};\\\", \\\"{x:633,y:609,t:1526930267356};\\\", \\\"{x:634,y:611,t:1526930267372};\\\", \\\"{x:635,y:612,t:1526930267389};\\\", \\\"{x:637,y:614,t:1526930267406};\\\", \\\"{x:637,y:616,t:1526930267425};\\\", \\\"{x:637,y:617,t:1526930267450};\\\", \\\"{x:637,y:618,t:1526930267458};\\\", \\\"{x:637,y:621,t:1526930267472};\\\", \\\"{x:637,y:624,t:1526930267489};\\\", \\\"{x:637,y:630,t:1526930267506};\\\", \\\"{x:637,y:635,t:1526930267523};\\\", \\\"{x:637,y:638,t:1526930267538};\\\", \\\"{x:639,y:642,t:1526930267556};\\\", \\\"{x:639,y:646,t:1526930267572};\\\", \\\"{x:639,y:656,t:1526930267589};\\\", \\\"{x:632,y:680,t:1526930267606};\\\", \\\"{x:623,y:696,t:1526930267624};\\\", \\\"{x:620,y:703,t:1526930267639};\\\", \\\"{x:619,y:706,t:1526930267656};\\\", \\\"{x:616,y:709,t:1526930267673};\\\", \\\"{x:614,y:711,t:1526930267689};\\\", \\\"{x:614,y:716,t:1526930267705};\\\", \\\"{x:613,y:717,t:1526930267723};\\\", \\\"{x:611,y:720,t:1526930267739};\\\", \\\"{x:608,y:722,t:1526930267756};\\\", \\\"{x:604,y:725,t:1526930267773};\\\", \\\"{x:598,y:727,t:1526930267789};\\\", \\\"{x:597,y:728,t:1526930267806};\\\", \\\"{x:594,y:730,t:1526930267823};\\\", \\\"{x:593,y:730,t:1526930267839};\\\", \\\"{x:590,y:732,t:1526930267856};\\\", \\\"{x:588,y:732,t:1526930267874};\\\", \\\"{x:587,y:732,t:1526930267889};\\\", \\\"{x:585,y:732,t:1526930267906};\\\", \\\"{x:584,y:733,t:1526930267930};\\\", \\\"{x:581,y:733,t:1526930267946};\\\", \\\"{x:579,y:734,t:1526930267956};\\\", \\\"{x:577,y:735,t:1526930267973};\\\", \\\"{x:573,y:736,t:1526930267990};\\\", \\\"{x:567,y:736,t:1526930268006};\\\", \\\"{x:559,y:737,t:1526930268025};\\\", \\\"{x:553,y:737,t:1526930268039};\\\", \\\"{x:546,y:737,t:1526930268056};\\\", \\\"{x:542,y:737,t:1526930268072};\\\", \\\"{x:534,y:737,t:1526930268089};\\\", \\\"{x:531,y:737,t:1526930268105};\\\" ] }, { \\\"rt\\\": 9860, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 636014, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-09 AM-12 PM-10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:737,t:1526930270451};\\\", \\\"{x:527,y:737,t:1526930271385};\\\", \\\"{x:526,y:737,t:1526930271393};\\\", \\\"{x:525,y:738,t:1526930271408};\\\", \\\"{x:524,y:738,t:1526930271457};\\\", \\\"{x:523,y:738,t:1526930271482};\\\", \\\"{x:522,y:738,t:1526930271521};\\\", \\\"{x:522,y:739,t:1526930271530};\\\", \\\"{x:519,y:739,t:1526930271729};\\\", \\\"{x:516,y:738,t:1526930271742};\\\", \\\"{x:512,y:727,t:1526930271759};\\\", \\\"{x:509,y:715,t:1526930271776};\\\", \\\"{x:506,y:708,t:1526930271791};\\\", \\\"{x:504,y:706,t:1526930271809};\\\", \\\"{x:504,y:705,t:1526930271937};\\\", \\\"{x:503,y:705,t:1526930271945};\\\", \\\"{x:503,y:704,t:1526930271959};\\\", \\\"{x:501,y:703,t:1526930271976};\\\", \\\"{x:500,y:701,t:1526930271993};\\\", \\\"{x:500,y:699,t:1526930272274};\\\", \\\"{x:500,y:698,t:1526930272281};\\\", \\\"{x:504,y:695,t:1526930272293};\\\", \\\"{x:515,y:684,t:1526930272309};\\\", \\\"{x:537,y:668,t:1526930272327};\\\", \\\"{x:573,y:645,t:1526930272343};\\\", \\\"{x:603,y:628,t:1526930272360};\\\", \\\"{x:620,y:620,t:1526930272378};\\\", \\\"{x:625,y:618,t:1526930272393};\\\", \\\"{x:636,y:613,t:1526930272409};\\\", \\\"{x:661,y:604,t:1526930272426};\\\", \\\"{x:716,y:582,t:1526930272444};\\\", \\\"{x:812,y:572,t:1526930272459};\\\", \\\"{x:935,y:601,t:1526930272477};\\\", \\\"{x:1082,y:703,t:1526930272493};\\\", \\\"{x:1258,y:848,t:1526930272510};\\\", \\\"{x:1424,y:966,t:1526930272526};\\\", \\\"{x:1496,y:1002,t:1526930272543};\\\", \\\"{x:1508,y:1005,t:1526930272560};\\\", \\\"{x:1521,y:1010,t:1526930272576};\\\", \\\"{x:1535,y:1019,t:1526930272593};\\\", \\\"{x:1535,y:1020,t:1526930272641};\\\", \\\"{x:1535,y:1021,t:1526930272657};\\\", \\\"{x:1534,y:1021,t:1526930272665};\\\", \\\"{x:1534,y:1022,t:1526930272676};\\\", \\\"{x:1531,y:1022,t:1526930272693};\\\", \\\"{x:1525,y:1022,t:1526930272710};\\\", \\\"{x:1522,y:1024,t:1526930272726};\\\", \\\"{x:1521,y:1024,t:1526930272743};\\\", \\\"{x:1518,y:1025,t:1526930272760};\\\", \\\"{x:1515,y:1026,t:1526930272776};\\\", \\\"{x:1511,y:1027,t:1526930272794};\\\", \\\"{x:1502,y:1027,t:1526930272809};\\\", \\\"{x:1492,y:1027,t:1526930272826};\\\", \\\"{x:1470,y:1021,t:1526930272844};\\\", \\\"{x:1446,y:1014,t:1526930272860};\\\", \\\"{x:1392,y:993,t:1526930272877};\\\", \\\"{x:1313,y:961,t:1526930272893};\\\", \\\"{x:1263,y:948,t:1526930272910};\\\", \\\"{x:1238,y:946,t:1526930272927};\\\", \\\"{x:1218,y:946,t:1526930272944};\\\", \\\"{x:1203,y:946,t:1526930272961};\\\", \\\"{x:1188,y:946,t:1526930272977};\\\", \\\"{x:1178,y:946,t:1526930272994};\\\", \\\"{x:1169,y:949,t:1526930273010};\\\", \\\"{x:1162,y:957,t:1526930273027};\\\", \\\"{x:1155,y:963,t:1526930273044};\\\", \\\"{x:1143,y:972,t:1526930273060};\\\", \\\"{x:1131,y:976,t:1526930273078};\\\", \\\"{x:1120,y:982,t:1526930273094};\\\", \\\"{x:1116,y:984,t:1526930273110};\\\", \\\"{x:1113,y:985,t:1526930273128};\\\", \\\"{x:1112,y:986,t:1526930273186};\\\", \\\"{x:1112,y:985,t:1526930273875};\\\", \\\"{x:1118,y:982,t:1526930273882};\\\", \\\"{x:1125,y:980,t:1526930273894};\\\", \\\"{x:1134,y:975,t:1526930273912};\\\", \\\"{x:1142,y:970,t:1526930273927};\\\", \\\"{x:1156,y:964,t:1526930273945};\\\", \\\"{x:1202,y:941,t:1526930273962};\\\", \\\"{x:1221,y:934,t:1526930273978};\\\", \\\"{x:1231,y:934,t:1526930273995};\\\", \\\"{x:1236,y:934,t:1526930274012};\\\", \\\"{x:1239,y:934,t:1526930274027};\\\", \\\"{x:1240,y:934,t:1526930274044};\\\", \\\"{x:1241,y:934,t:1526930274066};\\\", \\\"{x:1241,y:935,t:1526930274122};\\\", \\\"{x:1243,y:936,t:1526930274146};\\\", \\\"{x:1246,y:940,t:1526930274162};\\\", \\\"{x:1250,y:943,t:1526930274178};\\\", \\\"{x:1258,y:947,t:1526930274194};\\\", \\\"{x:1264,y:948,t:1526930274211};\\\", \\\"{x:1269,y:950,t:1526930274228};\\\", \\\"{x:1272,y:950,t:1526930274244};\\\", \\\"{x:1280,y:952,t:1526930274261};\\\", \\\"{x:1289,y:954,t:1526930274279};\\\", \\\"{x:1302,y:954,t:1526930274294};\\\", \\\"{x:1320,y:954,t:1526930274312};\\\", \\\"{x:1335,y:955,t:1526930274329};\\\", \\\"{x:1347,y:956,t:1526930274345};\\\", \\\"{x:1351,y:959,t:1526930274362};\\\", \\\"{x:1352,y:960,t:1526930274378};\\\", \\\"{x:1353,y:961,t:1526930274586};\\\", \\\"{x:1352,y:963,t:1526930274594};\\\", \\\"{x:1350,y:964,t:1526930274611};\\\", \\\"{x:1347,y:965,t:1526930274628};\\\", \\\"{x:1346,y:966,t:1526930274644};\\\", \\\"{x:1345,y:966,t:1526930274661};\\\", \\\"{x:1344,y:967,t:1526930275306};\\\", \\\"{x:1343,y:969,t:1526930275314};\\\", \\\"{x:1338,y:972,t:1526930275329};\\\", \\\"{x:1308,y:988,t:1526930275346};\\\", \\\"{x:1284,y:990,t:1526930275362};\\\", \\\"{x:1266,y:989,t:1526930275378};\\\", \\\"{x:1224,y:970,t:1526930275395};\\\", \\\"{x:1180,y:952,t:1526930275412};\\\", \\\"{x:1142,y:934,t:1526930275428};\\\", \\\"{x:1098,y:908,t:1526930275445};\\\", \\\"{x:1046,y:880,t:1526930275462};\\\", \\\"{x:998,y:845,t:1526930275478};\\\", \\\"{x:942,y:804,t:1526930275495};\\\", \\\"{x:887,y:770,t:1526930275512};\\\", \\\"{x:832,y:738,t:1526930275528};\\\", \\\"{x:777,y:709,t:1526930275545};\\\", \\\"{x:753,y:699,t:1526930275561};\\\", \\\"{x:732,y:688,t:1526930275578};\\\", \\\"{x:717,y:677,t:1526930275595};\\\", \\\"{x:711,y:672,t:1526930275613};\\\", \\\"{x:704,y:666,t:1526930275629};\\\", \\\"{x:697,y:661,t:1526930275645};\\\", \\\"{x:689,y:657,t:1526930275663};\\\", \\\"{x:685,y:655,t:1526930275679};\\\", \\\"{x:681,y:653,t:1526930275695};\\\", \\\"{x:678,y:652,t:1526930275712};\\\", \\\"{x:670,y:648,t:1526930275729};\\\", \\\"{x:662,y:645,t:1526930275745};\\\", \\\"{x:653,y:641,t:1526930275762};\\\", \\\"{x:648,y:640,t:1526930275779};\\\", \\\"{x:639,y:636,t:1526930275795};\\\", \\\"{x:635,y:633,t:1526930275812};\\\", \\\"{x:631,y:630,t:1526930275829};\\\", \\\"{x:627,y:627,t:1526930275845};\\\", \\\"{x:623,y:626,t:1526930275862};\\\", \\\"{x:612,y:622,t:1526930275879};\\\", \\\"{x:599,y:618,t:1526930275895};\\\", \\\"{x:589,y:616,t:1526930275912};\\\", \\\"{x:566,y:607,t:1526930275929};\\\", \\\"{x:555,y:605,t:1526930275945};\\\", \\\"{x:552,y:603,t:1526930275962};\\\", \\\"{x:551,y:602,t:1526930275979};\\\", \\\"{x:554,y:596,t:1526930275996};\\\", \\\"{x:573,y:582,t:1526930276012};\\\", \\\"{x:602,y:565,t:1526930276029};\\\", \\\"{x:629,y:552,t:1526930276046};\\\", \\\"{x:646,y:542,t:1526930276062};\\\", \\\"{x:656,y:535,t:1526930276079};\\\", \\\"{x:661,y:531,t:1526930276095};\\\", \\\"{x:666,y:528,t:1526930276112};\\\", \\\"{x:670,y:528,t:1526930276129};\\\", \\\"{x:673,y:525,t:1526930276145};\\\", \\\"{x:678,y:524,t:1526930276163};\\\", \\\"{x:683,y:522,t:1526930276179};\\\", \\\"{x:687,y:520,t:1526930276196};\\\", \\\"{x:694,y:519,t:1526930276213};\\\", \\\"{x:702,y:517,t:1526930276230};\\\", \\\"{x:716,y:516,t:1526930276247};\\\", \\\"{x:734,y:513,t:1526930276264};\\\", \\\"{x:751,y:511,t:1526930276279};\\\", \\\"{x:764,y:508,t:1526930276296};\\\", \\\"{x:775,y:507,t:1526930276313};\\\", \\\"{x:782,y:507,t:1526930276329};\\\", \\\"{x:791,y:506,t:1526930276345};\\\", \\\"{x:800,y:503,t:1526930276363};\\\", \\\"{x:805,y:502,t:1526930276379};\\\", \\\"{x:806,y:502,t:1526930276402};\\\", \\\"{x:807,y:502,t:1526930276425};\\\", \\\"{x:808,y:502,t:1526930276473};\\\", \\\"{x:809,y:502,t:1526930276546};\\\", \\\"{x:814,y:500,t:1526930276564};\\\", \\\"{x:817,y:499,t:1526930276581};\\\", \\\"{x:820,y:499,t:1526930276596};\\\", \\\"{x:822,y:498,t:1526930276613};\\\", \\\"{x:823,y:498,t:1526930276642};\\\", \\\"{x:824,y:497,t:1526930276650};\\\", \\\"{x:825,y:497,t:1526930276673};\\\", \\\"{x:826,y:497,t:1526930276682};\\\", \\\"{x:828,y:497,t:1526930276697};\\\", \\\"{x:831,y:497,t:1526930276712};\\\", \\\"{x:832,y:497,t:1526930276729};\\\", \\\"{x:833,y:497,t:1526930276745};\\\", \\\"{x:834,y:496,t:1526930276762};\\\", \\\"{x:835,y:496,t:1526930277018};\\\", \\\"{x:835,y:496,t:1526930277063};\\\", \\\"{x:834,y:497,t:1526930277225};\\\", \\\"{x:826,y:498,t:1526930277234};\\\", \\\"{x:820,y:499,t:1526930277247};\\\", \\\"{x:793,y:502,t:1526930277262};\\\", \\\"{x:735,y:509,t:1526930277280};\\\", \\\"{x:616,y:509,t:1526930277298};\\\", \\\"{x:524,y:509,t:1526930277314};\\\", \\\"{x:444,y:509,t:1526930277331};\\\", \\\"{x:369,y:509,t:1526930277347};\\\", \\\"{x:318,y:509,t:1526930277363};\\\", \\\"{x:279,y:509,t:1526930277380};\\\", \\\"{x:253,y:509,t:1526930277399};\\\", \\\"{x:229,y:509,t:1526930277413};\\\", \\\"{x:200,y:509,t:1526930277430};\\\", \\\"{x:169,y:509,t:1526930277447};\\\", \\\"{x:129,y:509,t:1526930277463};\\\", \\\"{x:99,y:509,t:1526930277480};\\\", \\\"{x:67,y:508,t:1526930277497};\\\", \\\"{x:65,y:507,t:1526930277514};\\\", \\\"{x:67,y:507,t:1526930277626};\\\", \\\"{x:68,y:507,t:1526930277633};\\\", \\\"{x:70,y:507,t:1526930277647};\\\", \\\"{x:74,y:508,t:1526930277663};\\\", \\\"{x:78,y:511,t:1526930277681};\\\", \\\"{x:85,y:517,t:1526930277697};\\\", \\\"{x:90,y:519,t:1526930277715};\\\", \\\"{x:92,y:521,t:1526930277730};\\\", \\\"{x:94,y:522,t:1526930277746};\\\", \\\"{x:95,y:523,t:1526930277764};\\\", \\\"{x:96,y:524,t:1526930277780};\\\", \\\"{x:98,y:524,t:1526930277797};\\\", \\\"{x:100,y:525,t:1526930277815};\\\", \\\"{x:104,y:527,t:1526930277830};\\\", \\\"{x:108,y:530,t:1526930277847};\\\", \\\"{x:113,y:535,t:1526930277864};\\\", \\\"{x:118,y:539,t:1526930277880};\\\", \\\"{x:123,y:543,t:1526930277897};\\\", \\\"{x:125,y:543,t:1526930277914};\\\", \\\"{x:129,y:545,t:1526930277930};\\\", \\\"{x:133,y:546,t:1526930277947};\\\", \\\"{x:142,y:549,t:1526930277964};\\\", \\\"{x:153,y:552,t:1526930277982};\\\", \\\"{x:160,y:552,t:1526930277997};\\\", \\\"{x:161,y:552,t:1526930278014};\\\", \\\"{x:161,y:551,t:1526930278187};\\\", \\\"{x:160,y:548,t:1526930278201};\\\", \\\"{x:160,y:544,t:1526930278214};\\\", \\\"{x:160,y:539,t:1526930278231};\\\", \\\"{x:160,y:538,t:1526930278247};\\\", \\\"{x:161,y:541,t:1526930278529};\\\", \\\"{x:165,y:550,t:1526930278537};\\\", \\\"{x:169,y:555,t:1526930278548};\\\", \\\"{x:177,y:566,t:1526930278565};\\\", \\\"{x:188,y:582,t:1526930278581};\\\", \\\"{x:193,y:594,t:1526930278599};\\\", \\\"{x:206,y:613,t:1526930278615};\\\", \\\"{x:218,y:628,t:1526930278631};\\\", \\\"{x:228,y:646,t:1526930278649};\\\", \\\"{x:238,y:668,t:1526930278665};\\\", \\\"{x:244,y:681,t:1526930278682};\\\", \\\"{x:254,y:702,t:1526930278698};\\\", \\\"{x:263,y:716,t:1526930278714};\\\", \\\"{x:269,y:724,t:1526930278731};\\\", \\\"{x:272,y:726,t:1526930278748};\\\", \\\"{x:273,y:728,t:1526930278764};\\\", \\\"{x:277,y:730,t:1526930278781};\\\", \\\"{x:281,y:733,t:1526930278798};\\\", \\\"{x:283,y:734,t:1526930278814};\\\", \\\"{x:284,y:734,t:1526930278831};\\\", \\\"{x:288,y:735,t:1526930278849};\\\", \\\"{x:290,y:735,t:1526930278864};\\\", \\\"{x:291,y:735,t:1526930278881};\\\", \\\"{x:293,y:736,t:1526930278899};\\\", \\\"{x:294,y:736,t:1526930278921};\\\", \\\"{x:296,y:737,t:1526930278938};\\\", \\\"{x:298,y:738,t:1526930278954};\\\", \\\"{x:301,y:739,t:1526930278965};\\\", \\\"{x:308,y:743,t:1526930278982};\\\", \\\"{x:314,y:744,t:1526930278999};\\\", \\\"{x:322,y:747,t:1526930279014};\\\", \\\"{x:332,y:747,t:1526930279031};\\\", \\\"{x:347,y:747,t:1526930279049};\\\", \\\"{x:361,y:747,t:1526930279064};\\\", \\\"{x:386,y:747,t:1526930279081};\\\", \\\"{x:397,y:747,t:1526930279098};\\\", \\\"{x:409,y:747,t:1526930279114};\\\", \\\"{x:418,y:747,t:1526930279131};\\\", \\\"{x:426,y:745,t:1526930279148};\\\", \\\"{x:436,y:742,t:1526930279165};\\\", \\\"{x:440,y:739,t:1526930279181};\\\", \\\"{x:444,y:738,t:1526930279199};\\\", \\\"{x:450,y:737,t:1526930279214};\\\", \\\"{x:456,y:735,t:1526930279232};\\\", \\\"{x:465,y:735,t:1526930279248};\\\", \\\"{x:470,y:735,t:1526930279265};\\\", \\\"{x:474,y:733,t:1526930280130};\\\", \\\"{x:488,y:725,t:1526930280137};\\\", \\\"{x:499,y:718,t:1526930280149};\\\", \\\"{x:519,y:707,t:1526930280165};\\\", \\\"{x:521,y:707,t:1526930280182};\\\", \\\"{x:521,y:708,t:1526930280506};\\\", \\\"{x:526,y:708,t:1526930280516};\\\", \\\"{x:544,y:698,t:1526930280539};\\\", \\\"{x:553,y:693,t:1526930280549};\\\", \\\"{x:570,y:678,t:1526930280566};\\\", \\\"{x:587,y:665,t:1526930280582};\\\", \\\"{x:599,y:655,t:1526930280599};\\\" ] }, { \\\"rt\\\": 17506, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 654759, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:658,y:613,t:1526930280752};\\\", \\\"{x:677,y:603,t:1526930280766};\\\", \\\"{x:698,y:593,t:1526930280783};\\\", \\\"{x:722,y:583,t:1526930280799};\\\", \\\"{x:745,y:574,t:1526930280817};\\\", \\\"{x:765,y:572,t:1526930280833};\\\", \\\"{x:776,y:569,t:1526930280851};\\\", \\\"{x:785,y:569,t:1526930280866};\\\", \\\"{x:793,y:569,t:1526930280883};\\\", \\\"{x:800,y:568,t:1526930280900};\\\", \\\"{x:807,y:565,t:1526930280931};\\\", \\\"{x:810,y:565,t:1526930281340};\\\", \\\"{x:808,y:565,t:1526930281465};\\\", \\\"{x:807,y:565,t:1526930281473};\\\", \\\"{x:805,y:565,t:1526930281482};\\\", \\\"{x:798,y:565,t:1526930281499};\\\", \\\"{x:790,y:565,t:1526930281516};\\\", \\\"{x:782,y:565,t:1526930281532};\\\", \\\"{x:772,y:565,t:1526930281549};\\\", \\\"{x:761,y:565,t:1526930281565};\\\", \\\"{x:754,y:566,t:1526930281582};\\\", \\\"{x:748,y:567,t:1526930281599};\\\", \\\"{x:744,y:567,t:1526930281615};\\\", \\\"{x:741,y:568,t:1526930281632};\\\", \\\"{x:736,y:569,t:1526930281649};\\\", \\\"{x:732,y:570,t:1526930281666};\\\", \\\"{x:723,y:573,t:1526930281683};\\\", \\\"{x:717,y:573,t:1526930281699};\\\", \\\"{x:711,y:574,t:1526930281717};\\\", \\\"{x:705,y:575,t:1526930281734};\\\", \\\"{x:703,y:575,t:1526930281750};\\\", \\\"{x:700,y:576,t:1526930281767};\\\", \\\"{x:696,y:576,t:1526930281784};\\\", \\\"{x:691,y:576,t:1526930281800};\\\", \\\"{x:688,y:576,t:1526930281817};\\\", \\\"{x:687,y:576,t:1526930281834};\\\", \\\"{x:684,y:577,t:1526930281850};\\\", \\\"{x:681,y:578,t:1526930281867};\\\", \\\"{x:680,y:578,t:1526930281884};\\\", \\\"{x:677,y:578,t:1526930281901};\\\", \\\"{x:670,y:580,t:1526930281917};\\\", \\\"{x:667,y:580,t:1526930281934};\\\", \\\"{x:664,y:580,t:1526930281950};\\\", \\\"{x:663,y:580,t:1526930281970};\\\", \\\"{x:661,y:580,t:1526930281986};\\\", \\\"{x:661,y:581,t:1526930285874};\\\", \\\"{x:665,y:584,t:1526930285889};\\\", \\\"{x:702,y:599,t:1526930285907};\\\", \\\"{x:732,y:612,t:1526930285923};\\\", \\\"{x:768,y:629,t:1526930285938};\\\", \\\"{x:792,y:638,t:1526930285954};\\\", \\\"{x:818,y:651,t:1526930285971};\\\", \\\"{x:838,y:661,t:1526930285987};\\\", \\\"{x:860,y:673,t:1526930286004};\\\", \\\"{x:892,y:691,t:1526930286020};\\\", \\\"{x:930,y:715,t:1526930286037};\\\", \\\"{x:968,y:737,t:1526930286053};\\\", \\\"{x:996,y:753,t:1526930286071};\\\", \\\"{x:1013,y:763,t:1526930286087};\\\", \\\"{x:1024,y:770,t:1526930286103};\\\", \\\"{x:1033,y:774,t:1526930286121};\\\", \\\"{x:1043,y:779,t:1526930286136};\\\", \\\"{x:1046,y:782,t:1526930286154};\\\", \\\"{x:1047,y:782,t:1526930286171};\\\", \\\"{x:1049,y:782,t:1526930286187};\\\", \\\"{x:1050,y:782,t:1526930286204};\\\", \\\"{x:1051,y:782,t:1526930286242};\\\", \\\"{x:1054,y:781,t:1526930286818};\\\", \\\"{x:1060,y:779,t:1526930286825};\\\", \\\"{x:1063,y:777,t:1526930286837};\\\", \\\"{x:1070,y:775,t:1526930286855};\\\", \\\"{x:1075,y:772,t:1526930286872};\\\", \\\"{x:1082,y:772,t:1526930286888};\\\", \\\"{x:1090,y:772,t:1526930286905};\\\", \\\"{x:1113,y:774,t:1526930286921};\\\", \\\"{x:1130,y:776,t:1526930286938};\\\", \\\"{x:1143,y:779,t:1526930286954};\\\", \\\"{x:1157,y:781,t:1526930286972};\\\", \\\"{x:1168,y:784,t:1526930286988};\\\", \\\"{x:1183,y:788,t:1526930287005};\\\", \\\"{x:1201,y:793,t:1526930287022};\\\", \\\"{x:1214,y:796,t:1526930287040};\\\", \\\"{x:1228,y:800,t:1526930287055};\\\", \\\"{x:1239,y:805,t:1526930287072};\\\", \\\"{x:1251,y:810,t:1526930287088};\\\", \\\"{x:1263,y:814,t:1526930287105};\\\", \\\"{x:1278,y:821,t:1526930287122};\\\", \\\"{x:1284,y:824,t:1526930287138};\\\", \\\"{x:1293,y:828,t:1526930287156};\\\", \\\"{x:1303,y:832,t:1526930287171};\\\", \\\"{x:1312,y:838,t:1526930287189};\\\", \\\"{x:1320,y:842,t:1526930287205};\\\", \\\"{x:1327,y:847,t:1526930287222};\\\", \\\"{x:1331,y:848,t:1526930287239};\\\", \\\"{x:1335,y:850,t:1526930287255};\\\", \\\"{x:1339,y:852,t:1526930287272};\\\", \\\"{x:1344,y:855,t:1526930287290};\\\", \\\"{x:1345,y:855,t:1526930287313};\\\", \\\"{x:1346,y:855,t:1526930287418};\\\", \\\"{x:1347,y:855,t:1526930287426};\\\", \\\"{x:1347,y:856,t:1526930287442};\\\", \\\"{x:1348,y:856,t:1526930287455};\\\", \\\"{x:1350,y:858,t:1526930287472};\\\", \\\"{x:1352,y:858,t:1526930287489};\\\", \\\"{x:1359,y:862,t:1526930287506};\\\", \\\"{x:1361,y:862,t:1526930287522};\\\", \\\"{x:1365,y:862,t:1526930287540};\\\", \\\"{x:1367,y:864,t:1526930287555};\\\", \\\"{x:1370,y:864,t:1526930287572};\\\", \\\"{x:1373,y:864,t:1526930287589};\\\", \\\"{x:1374,y:864,t:1526930287606};\\\", \\\"{x:1377,y:864,t:1526930287622};\\\", \\\"{x:1378,y:864,t:1526930287639};\\\", \\\"{x:1379,y:864,t:1526930287656};\\\", \\\"{x:1380,y:864,t:1526930287672};\\\", \\\"{x:1381,y:864,t:1526930287689};\\\", \\\"{x:1382,y:864,t:1526930287705};\\\", \\\"{x:1385,y:866,t:1526930287722};\\\", \\\"{x:1390,y:868,t:1526930287739};\\\", \\\"{x:1394,y:870,t:1526930287756};\\\", \\\"{x:1398,y:873,t:1526930287772};\\\", \\\"{x:1403,y:876,t:1526930287789};\\\", \\\"{x:1408,y:879,t:1526930287806};\\\", \\\"{x:1412,y:880,t:1526930287822};\\\", \\\"{x:1413,y:880,t:1526930287842};\\\", \\\"{x:1414,y:881,t:1526930287856};\\\", \\\"{x:1414,y:880,t:1526930290785};\\\", \\\"{x:1414,y:876,t:1526930290794};\\\", \\\"{x:1414,y:873,t:1526930290808};\\\", \\\"{x:1416,y:871,t:1526930290825};\\\", \\\"{x:1416,y:870,t:1526930290841};\\\", \\\"{x:1417,y:869,t:1526930290858};\\\", \\\"{x:1419,y:868,t:1526930292650};\\\", \\\"{x:1419,y:867,t:1526930292659};\\\", \\\"{x:1421,y:866,t:1526930292677};\\\", \\\"{x:1422,y:865,t:1526930292694};\\\", \\\"{x:1422,y:864,t:1526930292906};\\\", \\\"{x:1418,y:864,t:1526930292914};\\\", \\\"{x:1407,y:864,t:1526930292926};\\\", \\\"{x:1376,y:866,t:1526930292943};\\\", \\\"{x:1320,y:866,t:1526930292961};\\\", \\\"{x:1253,y:855,t:1526930292976};\\\", \\\"{x:1115,y:820,t:1526930292993};\\\", \\\"{x:1023,y:795,t:1526930293010};\\\", \\\"{x:932,y:756,t:1526930293026};\\\", \\\"{x:830,y:711,t:1526930293043};\\\", \\\"{x:742,y:675,t:1526930293060};\\\", \\\"{x:685,y:654,t:1526930293076};\\\", \\\"{x:654,y:641,t:1526930293093};\\\", \\\"{x:635,y:635,t:1526930293110};\\\", \\\"{x:626,y:634,t:1526930293127};\\\", \\\"{x:622,y:632,t:1526930293143};\\\", \\\"{x:619,y:631,t:1526930293161};\\\", \\\"{x:616,y:631,t:1526930293177};\\\", \\\"{x:615,y:631,t:1526930293209};\\\", \\\"{x:613,y:631,t:1526930293233};\\\", \\\"{x:612,y:631,t:1526930293241};\\\", \\\"{x:608,y:631,t:1526930293253};\\\", \\\"{x:595,y:631,t:1526930293269};\\\", \\\"{x:582,y:629,t:1526930293285};\\\", \\\"{x:572,y:627,t:1526930293303};\\\", \\\"{x:569,y:627,t:1526930293320};\\\", \\\"{x:568,y:626,t:1526930293336};\\\", \\\"{x:567,y:625,t:1526930293458};\\\", \\\"{x:567,y:623,t:1526930293470};\\\", \\\"{x:568,y:616,t:1526930293487};\\\", \\\"{x:568,y:613,t:1526930293504};\\\", \\\"{x:569,y:611,t:1526930293520};\\\", \\\"{x:569,y:609,t:1526930293537};\\\", \\\"{x:570,y:608,t:1526930293553};\\\", \\\"{x:571,y:607,t:1526930293570};\\\", \\\"{x:572,y:606,t:1526930293602};\\\", \\\"{x:573,y:606,t:1526930293642};\\\", \\\"{x:573,y:605,t:1526930293657};\\\", \\\"{x:574,y:604,t:1526930294033};\\\", \\\"{x:577,y:603,t:1526930294042};\\\", \\\"{x:578,y:602,t:1526930294074};\\\", \\\"{x:582,y:600,t:1526930295307};\\\", \\\"{x:594,y:595,t:1526930295323};\\\", \\\"{x:610,y:587,t:1526930295345};\\\", \\\"{x:618,y:584,t:1526930295361};\\\", \\\"{x:624,y:581,t:1526930295378};\\\", \\\"{x:625,y:580,t:1526930295409};\\\", \\\"{x:626,y:580,t:1526930295424};\\\", \\\"{x:627,y:579,t:1526930295432};\\\", \\\"{x:628,y:578,t:1526930295444};\\\", \\\"{x:629,y:578,t:1526930295461};\\\", \\\"{x:633,y:576,t:1526930295478};\\\", \\\"{x:634,y:575,t:1526930295495};\\\", \\\"{x:637,y:574,t:1526930295511};\\\", \\\"{x:640,y:573,t:1526930295527};\\\", \\\"{x:642,y:571,t:1526930295544};\\\", \\\"{x:643,y:571,t:1526930295562};\\\", \\\"{x:640,y:569,t:1526930295706};\\\", \\\"{x:636,y:567,t:1526930295713};\\\", \\\"{x:634,y:565,t:1526930295728};\\\", \\\"{x:620,y:554,t:1526930295745};\\\", \\\"{x:614,y:543,t:1526930295762};\\\", \\\"{x:610,y:536,t:1526930295778};\\\", \\\"{x:606,y:529,t:1526930295795};\\\", \\\"{x:603,y:522,t:1526930295812};\\\", \\\"{x:602,y:515,t:1526930295829};\\\", \\\"{x:600,y:510,t:1526930295844};\\\", \\\"{x:600,y:501,t:1526930295862};\\\", \\\"{x:599,y:496,t:1526930295878};\\\", \\\"{x:595,y:491,t:1526930295894};\\\", \\\"{x:591,y:485,t:1526930295912};\\\", \\\"{x:581,y:480,t:1526930295928};\\\", \\\"{x:557,y:476,t:1526930295945};\\\", \\\"{x:532,y:476,t:1526930295962};\\\", \\\"{x:505,y:476,t:1526930295979};\\\", \\\"{x:475,y:476,t:1526930295995};\\\", \\\"{x:446,y:476,t:1526930296012};\\\", \\\"{x:419,y:476,t:1526930296028};\\\", \\\"{x:390,y:476,t:1526930296046};\\\", \\\"{x:362,y:476,t:1526930296062};\\\", \\\"{x:330,y:476,t:1526930296078};\\\", \\\"{x:299,y:476,t:1526930296096};\\\", \\\"{x:270,y:477,t:1526930296112};\\\", \\\"{x:241,y:481,t:1526930296129};\\\", \\\"{x:228,y:483,t:1526930296146};\\\", \\\"{x:217,y:483,t:1526930296163};\\\", \\\"{x:207,y:486,t:1526930296179};\\\", \\\"{x:200,y:487,t:1526930296197};\\\", \\\"{x:191,y:488,t:1526930296213};\\\", \\\"{x:181,y:491,t:1526930296229};\\\", \\\"{x:173,y:492,t:1526930296244};\\\", \\\"{x:166,y:496,t:1526930296261};\\\", \\\"{x:162,y:498,t:1526930296278};\\\", \\\"{x:159,y:501,t:1526930296295};\\\", \\\"{x:153,y:505,t:1526930296312};\\\", \\\"{x:141,y:512,t:1526930296329};\\\", \\\"{x:136,y:516,t:1526930296345};\\\", \\\"{x:131,y:521,t:1526930296362};\\\", \\\"{x:129,y:524,t:1526930296378};\\\", \\\"{x:128,y:525,t:1526930296397};\\\", \\\"{x:128,y:527,t:1526930296664};\\\", \\\"{x:129,y:527,t:1526930296679};\\\", \\\"{x:130,y:528,t:1526930296695};\\\", \\\"{x:133,y:531,t:1526930296712};\\\", \\\"{x:135,y:534,t:1526930296729};\\\", \\\"{x:136,y:536,t:1526930296745};\\\", \\\"{x:137,y:538,t:1526930296762};\\\", \\\"{x:137,y:539,t:1526930296779};\\\", \\\"{x:139,y:541,t:1526930296796};\\\", \\\"{x:140,y:542,t:1526930296833};\\\", \\\"{x:141,y:543,t:1526930296846};\\\", \\\"{x:142,y:544,t:1526930296863};\\\", \\\"{x:144,y:544,t:1526930296889};\\\", \\\"{x:146,y:544,t:1526930296913};\\\", \\\"{x:147,y:544,t:1526930296929};\\\", \\\"{x:149,y:544,t:1526930296947};\\\", \\\"{x:150,y:544,t:1526930296962};\\\", \\\"{x:152,y:544,t:1526930297233};\\\", \\\"{x:155,y:544,t:1526930297246};\\\", \\\"{x:178,y:561,t:1526930297263};\\\", \\\"{x:228,y:606,t:1526930297280};\\\", \\\"{x:304,y:677,t:1526930297296};\\\", \\\"{x:424,y:786,t:1526930297312};\\\", \\\"{x:491,y:834,t:1526930297330};\\\", \\\"{x:553,y:866,t:1526930297346};\\\", \\\"{x:594,y:884,t:1526930297363};\\\", \\\"{x:615,y:891,t:1526930297380};\\\", \\\"{x:626,y:894,t:1526930297396};\\\", \\\"{x:631,y:895,t:1526930297412};\\\", \\\"{x:633,y:897,t:1526930297430};\\\", \\\"{x:633,y:894,t:1526930297489};\\\", \\\"{x:633,y:891,t:1526930297496};\\\", \\\"{x:633,y:887,t:1526930297512};\\\", \\\"{x:634,y:880,t:1526930297530};\\\", \\\"{x:634,y:874,t:1526930297546};\\\", \\\"{x:629,y:857,t:1526930297563};\\\", \\\"{x:610,y:827,t:1526930297580};\\\", \\\"{x:581,y:794,t:1526930297595};\\\", \\\"{x:562,y:778,t:1526930297613};\\\", \\\"{x:550,y:769,t:1526930297629};\\\", \\\"{x:542,y:763,t:1526930297646};\\\", \\\"{x:540,y:761,t:1526930297663};\\\", \\\"{x:539,y:761,t:1526930297681};\\\", \\\"{x:538,y:761,t:1526930297696};\\\", \\\"{x:532,y:762,t:1526930297713};\\\", \\\"{x:528,y:763,t:1526930297730};\\\", \\\"{x:527,y:763,t:1526930297746};\\\", \\\"{x:526,y:763,t:1526930297777};\\\", \\\"{x:525,y:761,t:1526930297882};\\\", \\\"{x:525,y:758,t:1526930297896};\\\", \\\"{x:523,y:750,t:1526930297915};\\\", \\\"{x:523,y:743,t:1526930297930};\\\", \\\"{x:523,y:740,t:1526930297946};\\\", \\\"{x:521,y:736,t:1526930297963};\\\", \\\"{x:520,y:735,t:1526930297980};\\\", \\\"{x:520,y:734,t:1526930297997};\\\", \\\"{x:520,y:733,t:1526930298481};\\\" ] }, { \\\"rt\\\": 36320, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 692315, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-05 PM-C -C -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:733,t:1526930302505};\\\", \\\"{x:523,y:734,t:1526930302517};\\\", \\\"{x:538,y:742,t:1526930302534};\\\", \\\"{x:567,y:750,t:1526930302552};\\\", \\\"{x:602,y:759,t:1526930302568};\\\", \\\"{x:641,y:771,t:1526930302585};\\\", \\\"{x:694,y:785,t:1526930302599};\\\", \\\"{x:804,y:814,t:1526930302616};\\\", \\\"{x:913,y:834,t:1526930302633};\\\", \\\"{x:1042,y:861,t:1526930302650};\\\", \\\"{x:1189,y:883,t:1526930302667};\\\", \\\"{x:1322,y:902,t:1526930302684};\\\", \\\"{x:1440,y:927,t:1526930302699};\\\", \\\"{x:1539,y:955,t:1526930302717};\\\", \\\"{x:1609,y:976,t:1526930302734};\\\", \\\"{x:1661,y:989,t:1526930302751};\\\", \\\"{x:1692,y:997,t:1526930302767};\\\", \\\"{x:1700,y:998,t:1526930302784};\\\", \\\"{x:1701,y:998,t:1526930302800};\\\", \\\"{x:1698,y:995,t:1526930302832};\\\", \\\"{x:1684,y:983,t:1526930302851};\\\", \\\"{x:1670,y:971,t:1526930302867};\\\", \\\"{x:1658,y:956,t:1526930302884};\\\", \\\"{x:1644,y:937,t:1526930302901};\\\", \\\"{x:1628,y:915,t:1526930302916};\\\", \\\"{x:1618,y:901,t:1526930302934};\\\", \\\"{x:1608,y:888,t:1526930302951};\\\", \\\"{x:1601,y:876,t:1526930302967};\\\", \\\"{x:1594,y:866,t:1526930302984};\\\", \\\"{x:1590,y:858,t:1526930303001};\\\", \\\"{x:1587,y:855,t:1526930303017};\\\", \\\"{x:1584,y:854,t:1526930303034};\\\", \\\"{x:1578,y:854,t:1526930303052};\\\", \\\"{x:1566,y:859,t:1526930303067};\\\", \\\"{x:1554,y:866,t:1526930303085};\\\", \\\"{x:1547,y:870,t:1526930303101};\\\", \\\"{x:1545,y:871,t:1526930303117};\\\", \\\"{x:1543,y:871,t:1526930303134};\\\", \\\"{x:1542,y:871,t:1526930303148};\\\", \\\"{x:1540,y:872,t:1526930303164};\\\", \\\"{x:1539,y:872,t:1526930303182};\\\", \\\"{x:1540,y:872,t:1526930303367};\\\", \\\"{x:1543,y:872,t:1526930303382};\\\", \\\"{x:1563,y:862,t:1526930303399};\\\", \\\"{x:1577,y:854,t:1526930303416};\\\", \\\"{x:1592,y:845,t:1526930303432};\\\", \\\"{x:1607,y:837,t:1526930303449};\\\", \\\"{x:1621,y:827,t:1526930303466};\\\", \\\"{x:1634,y:817,t:1526930303482};\\\", \\\"{x:1651,y:805,t:1526930303499};\\\", \\\"{x:1663,y:794,t:1526930303517};\\\", \\\"{x:1669,y:788,t:1526930303532};\\\", \\\"{x:1674,y:783,t:1526930303550};\\\", \\\"{x:1677,y:779,t:1526930303566};\\\", \\\"{x:1678,y:776,t:1526930303582};\\\", \\\"{x:1680,y:773,t:1526930303599};\\\", \\\"{x:1681,y:771,t:1526930303616};\\\", \\\"{x:1683,y:769,t:1526930303631};\\\", \\\"{x:1686,y:765,t:1526930303649};\\\", \\\"{x:1688,y:761,t:1526930303666};\\\", \\\"{x:1692,y:755,t:1526930303682};\\\", \\\"{x:1695,y:750,t:1526930303699};\\\", \\\"{x:1696,y:743,t:1526930303716};\\\", \\\"{x:1697,y:734,t:1526930303732};\\\", \\\"{x:1697,y:718,t:1526930303749};\\\", \\\"{x:1686,y:699,t:1526930303767};\\\", \\\"{x:1613,y:632,t:1526930303783};\\\", \\\"{x:1497,y:582,t:1526930303800};\\\", \\\"{x:1328,y:551,t:1526930303816};\\\", \\\"{x:1175,y:544,t:1526930303833};\\\", \\\"{x:1096,y:541,t:1526930303849};\\\", \\\"{x:1076,y:541,t:1526930303866};\\\", \\\"{x:1071,y:539,t:1526930303883};\\\", \\\"{x:1057,y:530,t:1526930303899};\\\", \\\"{x:1040,y:522,t:1526930303916};\\\", \\\"{x:1021,y:512,t:1526930303933};\\\", \\\"{x:1012,y:507,t:1526930303950};\\\", \\\"{x:1010,y:507,t:1526930303966};\\\", \\\"{x:1010,y:505,t:1526930304063};\\\", \\\"{x:1024,y:497,t:1526930304070};\\\", \\\"{x:1048,y:482,t:1526930304083};\\\", \\\"{x:1108,y:437,t:1526930304099};\\\", \\\"{x:1159,y:388,t:1526930304116};\\\", \\\"{x:1192,y:358,t:1526930304132};\\\", \\\"{x:1220,y:322,t:1526930304149};\\\", \\\"{x:1242,y:284,t:1526930304165};\\\", \\\"{x:1254,y:232,t:1526930304182};\\\", \\\"{x:1231,y:162,t:1526930304198};\\\", \\\"{x:1163,y:49,t:1526930304215};\\\", \\\"{x:1092,y:0,t:1526930304232};\\\", \\\"{x:1054,y:0,t:1526930304249};\\\", \\\"{x:1037,y:0,t:1526930304266};\\\", \\\"{x:1029,y:0,t:1526930304282};\\\", \\\"{x:1025,y:0,t:1526930304299};\\\", \\\"{x:1027,y:0,t:1526930304326};\\\", \\\"{x:1028,y:0,t:1526930304334};\\\", \\\"{x:1030,y:0,t:1526930304349};\\\", \\\"{x:1032,y:0,t:1526930304366};\\\", \\\"{x:1039,y:0,t:1526930304382};\\\", \\\"{x:1046,y:0,t:1526930304400};\\\", \\\"{x:1066,y:0,t:1526930304415};\\\", \\\"{x:1109,y:11,t:1526930304433};\\\", \\\"{x:1204,y:43,t:1526930304450};\\\", \\\"{x:1292,y:76,t:1526930304466};\\\", \\\"{x:1375,y:114,t:1526930304482};\\\", \\\"{x:1461,y:158,t:1526930304500};\\\", \\\"{x:1540,y:198,t:1526930304516};\\\", \\\"{x:1586,y:225,t:1526930304533};\\\", \\\"{x:1601,y:238,t:1526930304549};\\\", \\\"{x:1602,y:245,t:1526930304566};\\\", \\\"{x:1602,y:251,t:1526930304583};\\\", \\\"{x:1602,y:254,t:1526930304631};\\\", \\\"{x:1602,y:260,t:1526930304639};\\\", \\\"{x:1596,y:271,t:1526930304651};\\\", \\\"{x:1582,y:292,t:1526930304666};\\\", \\\"{x:1566,y:314,t:1526930304683};\\\", \\\"{x:1555,y:331,t:1526930304701};\\\", \\\"{x:1547,y:346,t:1526930304716};\\\", \\\"{x:1543,y:352,t:1526930304733};\\\", \\\"{x:1540,y:356,t:1526930304750};\\\", \\\"{x:1539,y:358,t:1526930304767};\\\", \\\"{x:1537,y:361,t:1526930304783};\\\", \\\"{x:1536,y:366,t:1526930304799};\\\", \\\"{x:1532,y:373,t:1526930304817};\\\", \\\"{x:1531,y:379,t:1526930304832};\\\", \\\"{x:1529,y:389,t:1526930304849};\\\", \\\"{x:1525,y:400,t:1526930304866};\\\", \\\"{x:1524,y:406,t:1526930304883};\\\", \\\"{x:1523,y:412,t:1526930304899};\\\", \\\"{x:1521,y:419,t:1526930304917};\\\", \\\"{x:1519,y:429,t:1526930304933};\\\", \\\"{x:1518,y:438,t:1526930304950};\\\", \\\"{x:1518,y:461,t:1526930304967};\\\", \\\"{x:1518,y:475,t:1526930304983};\\\", \\\"{x:1520,y:484,t:1526930305000};\\\", \\\"{x:1520,y:494,t:1526930305018};\\\", \\\"{x:1521,y:507,t:1526930305033};\\\", \\\"{x:1523,y:518,t:1526930305050};\\\", \\\"{x:1524,y:527,t:1526930305067};\\\", \\\"{x:1530,y:539,t:1526930305083};\\\", \\\"{x:1533,y:547,t:1526930305100};\\\", \\\"{x:1534,y:550,t:1526930305118};\\\", \\\"{x:1534,y:552,t:1526930305133};\\\", \\\"{x:1535,y:559,t:1526930305151};\\\", \\\"{x:1535,y:564,t:1526930305167};\\\", \\\"{x:1535,y:567,t:1526930305183};\\\", \\\"{x:1535,y:569,t:1526930305200};\\\", \\\"{x:1535,y:570,t:1526930305217};\\\", \\\"{x:1535,y:571,t:1526930305235};\\\", \\\"{x:1534,y:573,t:1526930305255};\\\", \\\"{x:1533,y:573,t:1526930305267};\\\", \\\"{x:1526,y:576,t:1526930305284};\\\", \\\"{x:1520,y:579,t:1526930305300};\\\", \\\"{x:1513,y:583,t:1526930305317};\\\", \\\"{x:1504,y:588,t:1526930305334};\\\", \\\"{x:1497,y:591,t:1526930305351};\\\", \\\"{x:1490,y:594,t:1526930305367};\\\", \\\"{x:1486,y:595,t:1526930305384};\\\", \\\"{x:1483,y:596,t:1526930305400};\\\", \\\"{x:1480,y:598,t:1526930305417};\\\", \\\"{x:1476,y:598,t:1526930305434};\\\", \\\"{x:1474,y:600,t:1526930305451};\\\", \\\"{x:1469,y:603,t:1526930305467};\\\", \\\"{x:1465,y:605,t:1526930305484};\\\", \\\"{x:1460,y:608,t:1526930305500};\\\", \\\"{x:1456,y:610,t:1526930305517};\\\", \\\"{x:1447,y:623,t:1526930305535};\\\", \\\"{x:1445,y:628,t:1526930305553};\\\", \\\"{x:1441,y:641,t:1526930305567};\\\", \\\"{x:1440,y:651,t:1526930305584};\\\", \\\"{x:1438,y:666,t:1526930305599};\\\", \\\"{x:1437,y:681,t:1526930305617};\\\", \\\"{x:1436,y:702,t:1526930305634};\\\", \\\"{x:1435,y:720,t:1526930305649};\\\", \\\"{x:1433,y:734,t:1526930305667};\\\", \\\"{x:1432,y:744,t:1526930305683};\\\", \\\"{x:1431,y:748,t:1526930305700};\\\", \\\"{x:1431,y:750,t:1526930305717};\\\", \\\"{x:1431,y:751,t:1526930305734};\\\", \\\"{x:1431,y:753,t:1526930305750};\\\", \\\"{x:1431,y:754,t:1526930305774};\\\", \\\"{x:1431,y:755,t:1526930305790};\\\", \\\"{x:1431,y:756,t:1526930305823};\\\", \\\"{x:1431,y:757,t:1526930305839};\\\", \\\"{x:1431,y:759,t:1526930305851};\\\", \\\"{x:1431,y:760,t:1526930305868};\\\", \\\"{x:1431,y:762,t:1526930305884};\\\", \\\"{x:1431,y:766,t:1526930305901};\\\", \\\"{x:1431,y:768,t:1526930305918};\\\", \\\"{x:1431,y:771,t:1526930305934};\\\", \\\"{x:1431,y:774,t:1526930305951};\\\", \\\"{x:1432,y:782,t:1526930305967};\\\", \\\"{x:1435,y:791,t:1526930305984};\\\", \\\"{x:1438,y:798,t:1526930306001};\\\", \\\"{x:1439,y:805,t:1526930306017};\\\", \\\"{x:1442,y:814,t:1526930306035};\\\", \\\"{x:1444,y:819,t:1526930306052};\\\", \\\"{x:1445,y:823,t:1526930306067};\\\", \\\"{x:1446,y:825,t:1526930306084};\\\", \\\"{x:1446,y:827,t:1526930306101};\\\", \\\"{x:1446,y:828,t:1526930306117};\\\", \\\"{x:1448,y:832,t:1526930306134};\\\", \\\"{x:1450,y:835,t:1526930306151};\\\", \\\"{x:1450,y:837,t:1526930306175};\\\", \\\"{x:1451,y:837,t:1526930306184};\\\", \\\"{x:1452,y:838,t:1526930306223};\\\", \\\"{x:1453,y:838,t:1526930306303};\\\", \\\"{x:1453,y:839,t:1526930306318};\\\", \\\"{x:1455,y:839,t:1526930306334};\\\", \\\"{x:1458,y:841,t:1526930306351};\\\", \\\"{x:1459,y:841,t:1526930306368};\\\", \\\"{x:1461,y:842,t:1526930306384};\\\", \\\"{x:1462,y:844,t:1526930306401};\\\", \\\"{x:1465,y:845,t:1526930306418};\\\", \\\"{x:1467,y:846,t:1526930306435};\\\", \\\"{x:1469,y:846,t:1526930306451};\\\", \\\"{x:1470,y:847,t:1526930306468};\\\", \\\"{x:1471,y:847,t:1526930306485};\\\", \\\"{x:1471,y:848,t:1526930306501};\\\", \\\"{x:1473,y:849,t:1526930306518};\\\", \\\"{x:1475,y:849,t:1526930306535};\\\", \\\"{x:1475,y:850,t:1526930306575};\\\", \\\"{x:1475,y:851,t:1526930306585};\\\", \\\"{x:1475,y:854,t:1526930306601};\\\", \\\"{x:1475,y:856,t:1526930306619};\\\", \\\"{x:1475,y:859,t:1526930306636};\\\", \\\"{x:1475,y:862,t:1526930306651};\\\", \\\"{x:1475,y:864,t:1526930306669};\\\", \\\"{x:1475,y:866,t:1526930306685};\\\", \\\"{x:1475,y:867,t:1526930306701};\\\", \\\"{x:1475,y:869,t:1526930306718};\\\", \\\"{x:1475,y:870,t:1526930306734};\\\", \\\"{x:1475,y:872,t:1526930306839};\\\", \\\"{x:1475,y:870,t:1526930307374};\\\", \\\"{x:1475,y:868,t:1526930307385};\\\", \\\"{x:1475,y:863,t:1526930307403};\\\", \\\"{x:1476,y:860,t:1526930320095};\\\", \\\"{x:1514,y:837,t:1526930320112};\\\", \\\"{x:1552,y:819,t:1526930320128};\\\", \\\"{x:1561,y:815,t:1526930320145};\\\", \\\"{x:1562,y:814,t:1526930320162};\\\", \\\"{x:1561,y:810,t:1526930320303};\\\", \\\"{x:1528,y:791,t:1526930320313};\\\", \\\"{x:1416,y:735,t:1526930320328};\\\", \\\"{x:1323,y:695,t:1526930320345};\\\", \\\"{x:1265,y:660,t:1526930320362};\\\", \\\"{x:1179,y:622,t:1526930320379};\\\", \\\"{x:1063,y:589,t:1526930320395};\\\", \\\"{x:894,y:566,t:1526930320413};\\\", \\\"{x:720,y:564,t:1526930320430};\\\", \\\"{x:552,y:549,t:1526930320445};\\\", \\\"{x:299,y:538,t:1526930320462};\\\", \\\"{x:163,y:533,t:1526930320479};\\\", \\\"{x:55,y:517,t:1526930320495};\\\", \\\"{x:0,y:507,t:1526930320513};\\\", \\\"{x:0,y:506,t:1526930320529};\\\", \\\"{x:0,y:505,t:1526930320545};\\\", \\\"{x:2,y:505,t:1526930320574};\\\", \\\"{x:10,y:510,t:1526930320581};\\\", \\\"{x:20,y:515,t:1526930320595};\\\", \\\"{x:40,y:520,t:1526930320612};\\\", \\\"{x:61,y:520,t:1526930320629};\\\", \\\"{x:84,y:520,t:1526930320645};\\\", \\\"{x:147,y:520,t:1526930320662};\\\", \\\"{x:251,y:513,t:1526930320680};\\\", \\\"{x:375,y:505,t:1526930320697};\\\", \\\"{x:499,y:503,t:1526930320713};\\\", \\\"{x:601,y:512,t:1526930320729};\\\", \\\"{x:659,y:517,t:1526930320746};\\\", \\\"{x:689,y:520,t:1526930320762};\\\", \\\"{x:700,y:524,t:1526930320779};\\\", \\\"{x:702,y:524,t:1526930320796};\\\", \\\"{x:703,y:524,t:1526930320830};\\\", \\\"{x:717,y:524,t:1526930320846};\\\", \\\"{x:732,y:524,t:1526930320862};\\\", \\\"{x:736,y:525,t:1526930320880};\\\", \\\"{x:735,y:530,t:1526930320896};\\\", \\\"{x:722,y:536,t:1526930320913};\\\", \\\"{x:705,y:546,t:1526930320929};\\\", \\\"{x:683,y:557,t:1526930320946};\\\", \\\"{x:662,y:569,t:1526930320962};\\\", \\\"{x:652,y:580,t:1526930320979};\\\", \\\"{x:647,y:589,t:1526930320996};\\\", \\\"{x:645,y:595,t:1526930321012};\\\", \\\"{x:645,y:597,t:1526930321029};\\\", \\\"{x:645,y:598,t:1526930321046};\\\", \\\"{x:644,y:599,t:1526930321230};\\\", \\\"{x:644,y:600,t:1526930321254};\\\", \\\"{x:643,y:600,t:1526930321383};\\\", \\\"{x:642,y:600,t:1526930321422};\\\", \\\"{x:641,y:601,t:1526930321742};\\\", \\\"{x:640,y:601,t:1526930321774};\\\", \\\"{x:640,y:600,t:1526930322200};\\\", \\\"{x:639,y:598,t:1526930322215};\\\", \\\"{x:638,y:597,t:1526930322230};\\\", \\\"{x:637,y:596,t:1526930322247};\\\", \\\"{x:636,y:595,t:1526930322270};\\\", \\\"{x:635,y:594,t:1526930322326};\\\", \\\"{x:633,y:593,t:1526930322343};\\\", \\\"{x:632,y:593,t:1526930322349};\\\", \\\"{x:631,y:592,t:1526930322364};\\\", \\\"{x:630,y:592,t:1526930322380};\\\", \\\"{x:629,y:592,t:1526930322397};\\\", \\\"{x:626,y:592,t:1526930322413};\\\", \\\"{x:624,y:592,t:1526930322437};\\\", \\\"{x:624,y:591,t:1526930322447};\\\", \\\"{x:623,y:590,t:1526930322463};\\\", \\\"{x:622,y:589,t:1526930322480};\\\", \\\"{x:621,y:588,t:1526930322497};\\\", \\\"{x:620,y:587,t:1526930322514};\\\", \\\"{x:619,y:587,t:1526930322530};\\\", \\\"{x:619,y:586,t:1526930322557};\\\", \\\"{x:618,y:586,t:1526930322582};\\\", \\\"{x:618,y:585,t:1526930322598};\\\", \\\"{x:617,y:584,t:1526930322630};\\\", \\\"{x:618,y:582,t:1526930323063};\\\", \\\"{x:621,y:581,t:1526930323071};\\\", \\\"{x:626,y:580,t:1526930323081};\\\", \\\"{x:641,y:578,t:1526930323097};\\\", \\\"{x:666,y:573,t:1526930323115};\\\", \\\"{x:704,y:565,t:1526930323131};\\\", \\\"{x:747,y:564,t:1526930323148};\\\", \\\"{x:825,y:564,t:1526930323164};\\\", \\\"{x:922,y:564,t:1526930323181};\\\", \\\"{x:1046,y:579,t:1526930323198};\\\", \\\"{x:1256,y:634,t:1526930323214};\\\", \\\"{x:1414,y:683,t:1526930323231};\\\", \\\"{x:1554,y:739,t:1526930323248};\\\", \\\"{x:1635,y:782,t:1526930323264};\\\", \\\"{x:1674,y:809,t:1526930323281};\\\", \\\"{x:1690,y:821,t:1526930323299};\\\", \\\"{x:1696,y:828,t:1526930323314};\\\", \\\"{x:1697,y:828,t:1526930323331};\\\", \\\"{x:1696,y:828,t:1526930323374};\\\", \\\"{x:1692,y:823,t:1526930323382};\\\", \\\"{x:1682,y:799,t:1526930323398};\\\", \\\"{x:1676,y:775,t:1526930323415};\\\", \\\"{x:1672,y:755,t:1526930323431};\\\", \\\"{x:1669,y:733,t:1526930323449};\\\", \\\"{x:1665,y:717,t:1526930323465};\\\", \\\"{x:1661,y:709,t:1526930323482};\\\", \\\"{x:1657,y:704,t:1526930323499};\\\", \\\"{x:1648,y:702,t:1526930323514};\\\", \\\"{x:1634,y:700,t:1526930323531};\\\", \\\"{x:1616,y:700,t:1526930323550};\\\", \\\"{x:1597,y:700,t:1526930323565};\\\", \\\"{x:1583,y:702,t:1526930323582};\\\", \\\"{x:1569,y:709,t:1526930323598};\\\", \\\"{x:1561,y:713,t:1526930323615};\\\", \\\"{x:1551,y:719,t:1526930323632};\\\", \\\"{x:1543,y:723,t:1526930323649};\\\", \\\"{x:1536,y:730,t:1526930323665};\\\", \\\"{x:1534,y:734,t:1526930323681};\\\", \\\"{x:1534,y:740,t:1526930323699};\\\", \\\"{x:1534,y:750,t:1526930323715};\\\", \\\"{x:1538,y:759,t:1526930323731};\\\", \\\"{x:1545,y:768,t:1526930323748};\\\", \\\"{x:1549,y:772,t:1526930323765};\\\", \\\"{x:1557,y:775,t:1526930323782};\\\", \\\"{x:1566,y:776,t:1526930323798};\\\", \\\"{x:1575,y:776,t:1526930323815};\\\", \\\"{x:1578,y:776,t:1526930323832};\\\", \\\"{x:1580,y:777,t:1526930323870};\\\", \\\"{x:1581,y:779,t:1526930323886};\\\", \\\"{x:1582,y:779,t:1526930323899};\\\", \\\"{x:1585,y:781,t:1526930323916};\\\", \\\"{x:1587,y:782,t:1526930323932};\\\", \\\"{x:1588,y:783,t:1526930323983};\\\", \\\"{x:1588,y:784,t:1526930323998};\\\", \\\"{x:1588,y:785,t:1526930324016};\\\", \\\"{x:1591,y:789,t:1526930324032};\\\", \\\"{x:1592,y:791,t:1526930324049};\\\", \\\"{x:1592,y:795,t:1526930324066};\\\", \\\"{x:1593,y:802,t:1526930324082};\\\", \\\"{x:1593,y:806,t:1526930324099};\\\", \\\"{x:1594,y:811,t:1526930324115};\\\", \\\"{x:1596,y:817,t:1526930324132};\\\", \\\"{x:1599,y:821,t:1526930324148};\\\", \\\"{x:1603,y:826,t:1526930324166};\\\", \\\"{x:1603,y:827,t:1526930324182};\\\", \\\"{x:1605,y:829,t:1526930324198};\\\", \\\"{x:1606,y:831,t:1526930324216};\\\", \\\"{x:1607,y:832,t:1526930324232};\\\", \\\"{x:1608,y:834,t:1526930324248};\\\", \\\"{x:1609,y:835,t:1526930324271};\\\", \\\"{x:1609,y:836,t:1526930324287};\\\", \\\"{x:1610,y:836,t:1526930324301};\\\", \\\"{x:1610,y:838,t:1526930324318};\\\", \\\"{x:1611,y:838,t:1526930324332};\\\", \\\"{x:1612,y:840,t:1526930324348};\\\", \\\"{x:1613,y:841,t:1526930324365};\\\", \\\"{x:1614,y:842,t:1526930324383};\\\", \\\"{x:1614,y:844,t:1526930324543};\\\", \\\"{x:1613,y:845,t:1526930324551};\\\", \\\"{x:1611,y:846,t:1526930324566};\\\", \\\"{x:1600,y:847,t:1526930324583};\\\", \\\"{x:1593,y:848,t:1526930324599};\\\", \\\"{x:1590,y:848,t:1526930324616};\\\", \\\"{x:1589,y:848,t:1526930324633};\\\", \\\"{x:1588,y:848,t:1526930324655};\\\", \\\"{x:1587,y:848,t:1526930324759};\\\", \\\"{x:1586,y:847,t:1526930324783};\\\", \\\"{x:1586,y:845,t:1526930324798};\\\", \\\"{x:1585,y:842,t:1526930324816};\\\", \\\"{x:1585,y:840,t:1526930324833};\\\", \\\"{x:1583,y:837,t:1526930324849};\\\", \\\"{x:1582,y:836,t:1526930324866};\\\", \\\"{x:1581,y:835,t:1526930324883};\\\", \\\"{x:1577,y:832,t:1526930324899};\\\", \\\"{x:1570,y:830,t:1526930324917};\\\", \\\"{x:1563,y:827,t:1526930324933};\\\", \\\"{x:1559,y:824,t:1526930324949};\\\", \\\"{x:1555,y:823,t:1526930324966};\\\", \\\"{x:1553,y:823,t:1526930324983};\\\", \\\"{x:1551,y:823,t:1526930325000};\\\", \\\"{x:1549,y:823,t:1526930325017};\\\", \\\"{x:1546,y:823,t:1526930325033};\\\", \\\"{x:1545,y:823,t:1526930325050};\\\", \\\"{x:1544,y:823,t:1526930325066};\\\", \\\"{x:1543,y:823,t:1526930325084};\\\", \\\"{x:1542,y:823,t:1526930325100};\\\", \\\"{x:1542,y:824,t:1526930325206};\\\", \\\"{x:1542,y:825,t:1526930325231};\\\", \\\"{x:1542,y:826,t:1526930325247};\\\", \\\"{x:1542,y:827,t:1526930325349};\\\", \\\"{x:1542,y:828,t:1526930325366};\\\", \\\"{x:1544,y:830,t:1526930325383};\\\", \\\"{x:1545,y:830,t:1526930325527};\\\", \\\"{x:1546,y:830,t:1526930325559};\\\", \\\"{x:1546,y:831,t:1526930325598};\\\", \\\"{x:1548,y:831,t:1526930325616};\\\", \\\"{x:1549,y:831,t:1526930325719};\\\", \\\"{x:1550,y:831,t:1526930326519};\\\", \\\"{x:1558,y:830,t:1526930326535};\\\", \\\"{x:1571,y:825,t:1526930326551};\\\", \\\"{x:1594,y:822,t:1526930326567};\\\", \\\"{x:1623,y:812,t:1526930326584};\\\", \\\"{x:1638,y:810,t:1526930326600};\\\", \\\"{x:1642,y:809,t:1526930326617};\\\", \\\"{x:1643,y:809,t:1526930326634};\\\", \\\"{x:1645,y:809,t:1526930326650};\\\", \\\"{x:1642,y:810,t:1526930326766};\\\", \\\"{x:1639,y:812,t:1526930326784};\\\", \\\"{x:1634,y:813,t:1526930326800};\\\", \\\"{x:1626,y:817,t:1526930326817};\\\", \\\"{x:1620,y:820,t:1526930326834};\\\", \\\"{x:1618,y:821,t:1526930326851};\\\", \\\"{x:1617,y:821,t:1526930326902};\\\", \\\"{x:1617,y:822,t:1526930326919};\\\", \\\"{x:1617,y:823,t:1526930326934};\\\", \\\"{x:1617,y:824,t:1526930326950};\\\", \\\"{x:1617,y:825,t:1526930326990};\\\", \\\"{x:1617,y:822,t:1526930328848};\\\", \\\"{x:1617,y:813,t:1526930328854};\\\", \\\"{x:1617,y:803,t:1526930328868};\\\", \\\"{x:1613,y:777,t:1526930328885};\\\", \\\"{x:1608,y:748,t:1526930328903};\\\", \\\"{x:1607,y:735,t:1526930328918};\\\", \\\"{x:1603,y:722,t:1526930328935};\\\", \\\"{x:1600,y:714,t:1526930328952};\\\", \\\"{x:1598,y:709,t:1526930328969};\\\", \\\"{x:1596,y:700,t:1526930328985};\\\", \\\"{x:1596,y:697,t:1526930329003};\\\", \\\"{x:1596,y:695,t:1526930329019};\\\", \\\"{x:1596,y:693,t:1526930329036};\\\", \\\"{x:1596,y:691,t:1526930329052};\\\", \\\"{x:1597,y:690,t:1526930329111};\\\", \\\"{x:1598,y:689,t:1526930329126};\\\", \\\"{x:1599,y:689,t:1526930329135};\\\", \\\"{x:1600,y:689,t:1526930329152};\\\", \\\"{x:1601,y:688,t:1526930329169};\\\", \\\"{x:1603,y:689,t:1526930329398};\\\", \\\"{x:1603,y:690,t:1526930329407};\\\", \\\"{x:1603,y:691,t:1526930329419};\\\", \\\"{x:1605,y:693,t:1526930329435};\\\", \\\"{x:1606,y:695,t:1526930329452};\\\", \\\"{x:1607,y:695,t:1526930331055};\\\", \\\"{x:1606,y:695,t:1526930331246};\\\", \\\"{x:1603,y:695,t:1526930331254};\\\", \\\"{x:1601,y:695,t:1526930331270};\\\", \\\"{x:1597,y:694,t:1526930331287};\\\", \\\"{x:1596,y:694,t:1526930331303};\\\", \\\"{x:1596,y:693,t:1526930331365};\\\", \\\"{x:1597,y:692,t:1526930331373};\\\", \\\"{x:1599,y:692,t:1526930331387};\\\", \\\"{x:1600,y:690,t:1526930331403};\\\", \\\"{x:1601,y:690,t:1526930331429};\\\", \\\"{x:1602,y:689,t:1526930331974};\\\", \\\"{x:1603,y:689,t:1526930331991};\\\", \\\"{x:1604,y:688,t:1526930332006};\\\", \\\"{x:1604,y:687,t:1526930332020};\\\", \\\"{x:1605,y:687,t:1526930332038};\\\", \\\"{x:1607,y:686,t:1526930332054};\\\", \\\"{x:1608,y:686,t:1526930332102};\\\", \\\"{x:1609,y:686,t:1526930332119};\\\", \\\"{x:1609,y:685,t:1526930332134};\\\", \\\"{x:1610,y:685,t:1526930332815};\\\", \\\"{x:1609,y:686,t:1526930332823};\\\", \\\"{x:1606,y:688,t:1526930332838};\\\", \\\"{x:1596,y:693,t:1526930332854};\\\", \\\"{x:1591,y:696,t:1526930332871};\\\", \\\"{x:1588,y:697,t:1526930332889};\\\", \\\"{x:1586,y:698,t:1526930332904};\\\", \\\"{x:1582,y:699,t:1526930332921};\\\", \\\"{x:1578,y:700,t:1526930332937};\\\", \\\"{x:1564,y:702,t:1526930332954};\\\", \\\"{x:1540,y:704,t:1526930332971};\\\", \\\"{x:1488,y:704,t:1526930332988};\\\", \\\"{x:1377,y:704,t:1526930333004};\\\", \\\"{x:1247,y:704,t:1526930333021};\\\", \\\"{x:1034,y:704,t:1526930333038};\\\", \\\"{x:913,y:695,t:1526930333054};\\\", \\\"{x:812,y:689,t:1526930333070};\\\", \\\"{x:753,y:681,t:1526930333088};\\\", \\\"{x:729,y:678,t:1526930333104};\\\", \\\"{x:718,y:677,t:1526930333121};\\\", \\\"{x:714,y:676,t:1526930333138};\\\", \\\"{x:710,y:674,t:1526930333153};\\\", \\\"{x:705,y:674,t:1526930333170};\\\", \\\"{x:695,y:670,t:1526930333188};\\\", \\\"{x:687,y:669,t:1526930333204};\\\", \\\"{x:681,y:667,t:1526930333221};\\\", \\\"{x:678,y:665,t:1526930333237};\\\", \\\"{x:677,y:663,t:1526930333253};\\\", \\\"{x:677,y:661,t:1526930333271};\\\", \\\"{x:677,y:658,t:1526930333288};\\\", \\\"{x:673,y:654,t:1526930333304};\\\", \\\"{x:671,y:650,t:1526930333321};\\\", \\\"{x:669,y:645,t:1526930333338};\\\", \\\"{x:669,y:641,t:1526930333354};\\\", \\\"{x:669,y:634,t:1526930333371};\\\", \\\"{x:669,y:627,t:1526930333390};\\\", \\\"{x:669,y:621,t:1526930333403};\\\", \\\"{x:667,y:616,t:1526930333421};\\\", \\\"{x:662,y:611,t:1526930333437};\\\", \\\"{x:657,y:607,t:1526930333455};\\\", \\\"{x:651,y:601,t:1526930333472};\\\", \\\"{x:651,y:598,t:1526930333490};\\\", \\\"{x:651,y:591,t:1526930333506};\\\", \\\"{x:669,y:578,t:1526930333522};\\\", \\\"{x:687,y:566,t:1526930333539};\\\", \\\"{x:706,y:553,t:1526930333556};\\\", \\\"{x:721,y:545,t:1526930333572};\\\", \\\"{x:748,y:533,t:1526930333590};\\\", \\\"{x:755,y:530,t:1526930333607};\\\", \\\"{x:759,y:528,t:1526930333775};\\\", \\\"{x:775,y:523,t:1526930333792};\\\", \\\"{x:786,y:518,t:1526930333807};\\\", \\\"{x:794,y:514,t:1526930333823};\\\", \\\"{x:799,y:511,t:1526930333840};\\\", \\\"{x:804,y:509,t:1526930333856};\\\", \\\"{x:808,y:508,t:1526930333873};\\\", \\\"{x:811,y:506,t:1526930333889};\\\", \\\"{x:813,y:506,t:1526930333907};\\\", \\\"{x:810,y:506,t:1526930334398};\\\", \\\"{x:809,y:507,t:1526930334407};\\\", \\\"{x:803,y:511,t:1526930334424};\\\", \\\"{x:802,y:513,t:1526930334440};\\\", \\\"{x:802,y:515,t:1526930334457};\\\", \\\"{x:802,y:516,t:1526930334474};\\\", \\\"{x:803,y:517,t:1526930334491};\\\", \\\"{x:817,y:517,t:1526930334507};\\\", \\\"{x:830,y:512,t:1526930334525};\\\", \\\"{x:839,y:509,t:1526930334541};\\\", \\\"{x:843,y:507,t:1526930334557};\\\", \\\"{x:844,y:506,t:1526930334574};\\\", \\\"{x:845,y:506,t:1526930334598};\\\", \\\"{x:846,y:506,t:1526930334606};\\\", \\\"{x:848,y:505,t:1526930334637};\\\", \\\"{x:848,y:504,t:1526930334645};\\\", \\\"{x:847,y:504,t:1526930334941};\\\", \\\"{x:846,y:504,t:1526930334957};\\\", \\\"{x:844,y:505,t:1526930334981};\\\", \\\"{x:843,y:505,t:1526930335062};\\\", \\\"{x:841,y:506,t:1526930335078};\\\", \\\"{x:837,y:507,t:1526930335091};\\\", \\\"{x:826,y:510,t:1526930335107};\\\", \\\"{x:800,y:522,t:1526930335125};\\\", \\\"{x:761,y:539,t:1526930335141};\\\", \\\"{x:705,y:568,t:1526930335158};\\\", \\\"{x:659,y:595,t:1526930335174};\\\", \\\"{x:614,y:623,t:1526930335190};\\\", \\\"{x:568,y:648,t:1526930335208};\\\", \\\"{x:530,y:672,t:1526930335223};\\\", \\\"{x:512,y:684,t:1526930335240};\\\", \\\"{x:501,y:693,t:1526930335257};\\\", \\\"{x:499,y:695,t:1526930335275};\\\", \\\"{x:498,y:696,t:1526930335334};\\\", \\\"{x:497,y:696,t:1526930335341};\\\", \\\"{x:496,y:698,t:1526930335357};\\\", \\\"{x:495,y:700,t:1526930335375};\\\", \\\"{x:495,y:701,t:1526930335391};\\\", \\\"{x:495,y:703,t:1526930335408};\\\", \\\"{x:495,y:705,t:1526930335424};\\\", \\\"{x:496,y:706,t:1526930335441};\\\", \\\"{x:496,y:708,t:1526930335459};\\\", \\\"{x:499,y:711,t:1526930335475};\\\", \\\"{x:501,y:716,t:1526930335491};\\\", \\\"{x:504,y:721,t:1526930335509};\\\", \\\"{x:510,y:733,t:1526930335525};\\\", \\\"{x:512,y:735,t:1526930335540};\\\", \\\"{x:516,y:742,t:1526930335557};\\\", \\\"{x:517,y:744,t:1526930335575};\\\", \\\"{x:518,y:745,t:1526930335590};\\\", \\\"{x:519,y:746,t:1526930335608};\\\", \\\"{x:519,y:748,t:1526930335625};\\\", \\\"{x:522,y:752,t:1526930335641};\\\", \\\"{x:523,y:753,t:1526930335658};\\\", \\\"{x:524,y:754,t:1526930335675};\\\", \\\"{x:523,y:754,t:1526930336142};\\\", \\\"{x:522,y:754,t:1526930336157};\\\", \\\"{x:519,y:754,t:1526930336175};\\\", \\\"{x:518,y:748,t:1526930336192};\\\", \\\"{x:518,y:746,t:1526930336208};\\\", \\\"{x:518,y:744,t:1526930336225};\\\" ] }, { \\\"rt\\\": 22762, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 716296, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:744,t:1526930338575};\\\", \\\"{x:515,y:744,t:1526930338590};\\\", \\\"{x:515,y:743,t:1526930338782};\\\", \\\"{x:517,y:741,t:1526930338797};\\\", \\\"{x:524,y:740,t:1526930338814};\\\", \\\"{x:547,y:740,t:1526930338830};\\\", \\\"{x:578,y:749,t:1526930338847};\\\", \\\"{x:620,y:768,t:1526930338864};\\\", \\\"{x:670,y:792,t:1526930338881};\\\", \\\"{x:721,y:819,t:1526930338893};\\\", \\\"{x:769,y:843,t:1526930338909};\\\", \\\"{x:815,y:861,t:1526930338926};\\\", \\\"{x:867,y:881,t:1526930338943};\\\", \\\"{x:923,y:899,t:1526930338961};\\\", \\\"{x:976,y:915,t:1526930338977};\\\", \\\"{x:1024,y:929,t:1526930338994};\\\", \\\"{x:1057,y:940,t:1526930339011};\\\", \\\"{x:1073,y:946,t:1526930339027};\\\", \\\"{x:1081,y:949,t:1526930339044};\\\", \\\"{x:1098,y:953,t:1526930339060};\\\", \\\"{x:1119,y:953,t:1526930339077};\\\", \\\"{x:1146,y:953,t:1526930339093};\\\", \\\"{x:1168,y:951,t:1526930339111};\\\", \\\"{x:1189,y:944,t:1526930339127};\\\", \\\"{x:1205,y:940,t:1526930339144};\\\", \\\"{x:1220,y:934,t:1526930339161};\\\", \\\"{x:1233,y:928,t:1526930339176};\\\", \\\"{x:1243,y:925,t:1526930339194};\\\", \\\"{x:1247,y:925,t:1526930339211};\\\", \\\"{x:1248,y:925,t:1526930339227};\\\", \\\"{x:1249,y:925,t:1526930339262};\\\", \\\"{x:1251,y:925,t:1526930339286};\\\", \\\"{x:1253,y:925,t:1526930339294};\\\", \\\"{x:1255,y:925,t:1526930339312};\\\", \\\"{x:1258,y:925,t:1526930339327};\\\", \\\"{x:1261,y:925,t:1526930339345};\\\", \\\"{x:1265,y:926,t:1526930339361};\\\", \\\"{x:1275,y:929,t:1526930339377};\\\", \\\"{x:1280,y:930,t:1526930339394};\\\", \\\"{x:1286,y:932,t:1526930339411};\\\", \\\"{x:1294,y:934,t:1526930339429};\\\", \\\"{x:1299,y:936,t:1526930339444};\\\", \\\"{x:1302,y:938,t:1526930339461};\\\", \\\"{x:1303,y:939,t:1526930339479};\\\", \\\"{x:1305,y:940,t:1526930339502};\\\", \\\"{x:1310,y:940,t:1526930340150};\\\", \\\"{x:1318,y:940,t:1526930340162};\\\", \\\"{x:1333,y:940,t:1526930340178};\\\", \\\"{x:1346,y:937,t:1526930340196};\\\", \\\"{x:1365,y:937,t:1526930340211};\\\", \\\"{x:1390,y:937,t:1526930340228};\\\", \\\"{x:1427,y:939,t:1526930340247};\\\", \\\"{x:1447,y:943,t:1526930340262};\\\", \\\"{x:1509,y:961,t:1526930340279};\\\", \\\"{x:1545,y:972,t:1526930340295};\\\", \\\"{x:1565,y:979,t:1526930340312};\\\", \\\"{x:1580,y:984,t:1526930340329};\\\", \\\"{x:1586,y:988,t:1526930340345};\\\", \\\"{x:1586,y:990,t:1526930340471};\\\", \\\"{x:1583,y:992,t:1526930340486};\\\", \\\"{x:1581,y:992,t:1526930340502};\\\", \\\"{x:1580,y:992,t:1526930340518};\\\", \\\"{x:1579,y:992,t:1526930340542};\\\", \\\"{x:1576,y:992,t:1526930340550};\\\", \\\"{x:1573,y:992,t:1526930340562};\\\", \\\"{x:1568,y:992,t:1526930340579};\\\", \\\"{x:1565,y:992,t:1526930340595};\\\", \\\"{x:1564,y:992,t:1526930340630};\\\", \\\"{x:1563,y:990,t:1526930340647};\\\", \\\"{x:1563,y:989,t:1526930340663};\\\", \\\"{x:1563,y:987,t:1526930340679};\\\", \\\"{x:1563,y:985,t:1526930340695};\\\", \\\"{x:1563,y:984,t:1526930340713};\\\", \\\"{x:1562,y:982,t:1526930340730};\\\", \\\"{x:1562,y:981,t:1526930340863};\\\", \\\"{x:1562,y:980,t:1526930340886};\\\", \\\"{x:1562,y:979,t:1526930340902};\\\", \\\"{x:1562,y:978,t:1526930340958};\\\", \\\"{x:1561,y:977,t:1526930340966};\\\", \\\"{x:1559,y:975,t:1526930340979};\\\", \\\"{x:1558,y:974,t:1526930340995};\\\", \\\"{x:1555,y:971,t:1526930341012};\\\", \\\"{x:1555,y:970,t:1526930341029};\\\", \\\"{x:1553,y:967,t:1526930341048};\\\", \\\"{x:1553,y:966,t:1526930341062};\\\", \\\"{x:1552,y:965,t:1526930341080};\\\", \\\"{x:1551,y:964,t:1526930341102};\\\", \\\"{x:1549,y:964,t:1526930341112};\\\", \\\"{x:1545,y:962,t:1526930341130};\\\", \\\"{x:1543,y:961,t:1526930341146};\\\", \\\"{x:1542,y:961,t:1526930341162};\\\", \\\"{x:1542,y:959,t:1526930341179};\\\", \\\"{x:1542,y:958,t:1526930341230};\\\", \\\"{x:1542,y:957,t:1526930341318};\\\", \\\"{x:1542,y:956,t:1526930341342};\\\", \\\"{x:1542,y:955,t:1526930341382};\\\", \\\"{x:1542,y:954,t:1526930341439};\\\", \\\"{x:1542,y:953,t:1526930341486};\\\", \\\"{x:1543,y:952,t:1526930341518};\\\", \\\"{x:1543,y:953,t:1526930341694};\\\", \\\"{x:1543,y:954,t:1526930341759};\\\", \\\"{x:1543,y:953,t:1526930342966};\\\", \\\"{x:1543,y:952,t:1526930343535};\\\", \\\"{x:1542,y:952,t:1526930343574};\\\", \\\"{x:1542,y:953,t:1526930343717};\\\", \\\"{x:1542,y:955,t:1526930343731};\\\", \\\"{x:1542,y:957,t:1526930343747};\\\", \\\"{x:1542,y:958,t:1526930343764};\\\", \\\"{x:1542,y:964,t:1526930343781};\\\", \\\"{x:1544,y:967,t:1526930343797};\\\", \\\"{x:1547,y:970,t:1526930343814};\\\", \\\"{x:1547,y:971,t:1526930343831};\\\", \\\"{x:1548,y:972,t:1526930343848};\\\", \\\"{x:1549,y:972,t:1526930344151};\\\", \\\"{x:1549,y:971,t:1526930344166};\\\", \\\"{x:1550,y:971,t:1526930344182};\\\", \\\"{x:1550,y:968,t:1526930344199};\\\", \\\"{x:1550,y:966,t:1526930344215};\\\", \\\"{x:1550,y:965,t:1526930344262};\\\", \\\"{x:1550,y:964,t:1526930344390};\\\", \\\"{x:1550,y:963,t:1526930344463};\\\", \\\"{x:1550,y:962,t:1526930344558};\\\", \\\"{x:1549,y:962,t:1526930344870};\\\", \\\"{x:1549,y:961,t:1526930345687};\\\", \\\"{x:1548,y:959,t:1526930345711};\\\", \\\"{x:1548,y:958,t:1526930345718};\\\", \\\"{x:1548,y:957,t:1526930345732};\\\", \\\"{x:1545,y:948,t:1526930345750};\\\", \\\"{x:1544,y:943,t:1526930345766};\\\", \\\"{x:1542,y:939,t:1526930345783};\\\", \\\"{x:1541,y:934,t:1526930345800};\\\", \\\"{x:1540,y:931,t:1526930345817};\\\", \\\"{x:1539,y:927,t:1526930345833};\\\", \\\"{x:1538,y:925,t:1526930345854};\\\", \\\"{x:1538,y:924,t:1526930345870};\\\", \\\"{x:1538,y:922,t:1526930345883};\\\", \\\"{x:1538,y:921,t:1526930345900};\\\", \\\"{x:1538,y:918,t:1526930345917};\\\", \\\"{x:1538,y:917,t:1526930345933};\\\", \\\"{x:1538,y:915,t:1526930345949};\\\", \\\"{x:1538,y:907,t:1526930345966};\\\", \\\"{x:1538,y:903,t:1526930345984};\\\", \\\"{x:1538,y:896,t:1526930345999};\\\", \\\"{x:1538,y:890,t:1526930346017};\\\", \\\"{x:1538,y:885,t:1526930346034};\\\", \\\"{x:1538,y:878,t:1526930346049};\\\", \\\"{x:1538,y:873,t:1526930346067};\\\", \\\"{x:1539,y:866,t:1526930346083};\\\", \\\"{x:1540,y:861,t:1526930346099};\\\", \\\"{x:1540,y:858,t:1526930346116};\\\", \\\"{x:1541,y:854,t:1526930346133};\\\", \\\"{x:1542,y:850,t:1526930346150};\\\", \\\"{x:1542,y:845,t:1526930346166};\\\", \\\"{x:1543,y:843,t:1526930346184};\\\", \\\"{x:1544,y:840,t:1526930346199};\\\", \\\"{x:1544,y:838,t:1526930346216};\\\", \\\"{x:1544,y:837,t:1526930346233};\\\", \\\"{x:1544,y:835,t:1526930346250};\\\", \\\"{x:1544,y:834,t:1526930346267};\\\", \\\"{x:1544,y:832,t:1526930346283};\\\", \\\"{x:1545,y:831,t:1526930346350};\\\", \\\"{x:1546,y:829,t:1526930346390};\\\", \\\"{x:1546,y:828,t:1526930346479};\\\", \\\"{x:1547,y:828,t:1526930347935};\\\", \\\"{x:1548,y:827,t:1526930347952};\\\", \\\"{x:1549,y:827,t:1526930347968};\\\", \\\"{x:1551,y:826,t:1526930347985};\\\", \\\"{x:1552,y:825,t:1526930348001};\\\", \\\"{x:1555,y:824,t:1526930348018};\\\", \\\"{x:1555,y:823,t:1526930348035};\\\", \\\"{x:1555,y:820,t:1526930348052};\\\", \\\"{x:1555,y:818,t:1526930348068};\\\", \\\"{x:1555,y:816,t:1526930348084};\\\", \\\"{x:1555,y:813,t:1526930348102};\\\", \\\"{x:1555,y:812,t:1526930348118};\\\", \\\"{x:1555,y:809,t:1526930348135};\\\", \\\"{x:1555,y:808,t:1526930348151};\\\", \\\"{x:1554,y:807,t:1526930348169};\\\", \\\"{x:1554,y:806,t:1526930348198};\\\", \\\"{x:1554,y:805,t:1526930348222};\\\", \\\"{x:1554,y:804,t:1526930348235};\\\", \\\"{x:1553,y:802,t:1526930348252};\\\", \\\"{x:1553,y:800,t:1526930348269};\\\", \\\"{x:1553,y:798,t:1526930348285};\\\", \\\"{x:1552,y:793,t:1526930348302};\\\", \\\"{x:1551,y:791,t:1526930348318};\\\", \\\"{x:1551,y:788,t:1526930348334};\\\", \\\"{x:1551,y:786,t:1526930348352};\\\", \\\"{x:1551,y:784,t:1526930348368};\\\", \\\"{x:1551,y:782,t:1526930348385};\\\", \\\"{x:1551,y:781,t:1526930348402};\\\", \\\"{x:1551,y:779,t:1526930348419};\\\", \\\"{x:1551,y:778,t:1526930348435};\\\", \\\"{x:1551,y:776,t:1526930348454};\\\", \\\"{x:1551,y:775,t:1526930348468};\\\", \\\"{x:1549,y:773,t:1526930348484};\\\", \\\"{x:1549,y:771,t:1526930348501};\\\", \\\"{x:1549,y:770,t:1526930348518};\\\", \\\"{x:1549,y:769,t:1526930348535};\\\", \\\"{x:1548,y:769,t:1526930348551};\\\", \\\"{x:1548,y:768,t:1526930348573};\\\", \\\"{x:1548,y:767,t:1526930348585};\\\", \\\"{x:1548,y:766,t:1526930348601};\\\", \\\"{x:1546,y:765,t:1526930348618};\\\", \\\"{x:1546,y:764,t:1526930348636};\\\", \\\"{x:1546,y:763,t:1526930348651};\\\", \\\"{x:1546,y:762,t:1526930348669};\\\", \\\"{x:1546,y:760,t:1526930349127};\\\", \\\"{x:1547,y:758,t:1526930349135};\\\", \\\"{x:1549,y:755,t:1526930349153};\\\", \\\"{x:1551,y:752,t:1526930349169};\\\", \\\"{x:1552,y:749,t:1526930349186};\\\", \\\"{x:1552,y:746,t:1526930349203};\\\", \\\"{x:1552,y:743,t:1526930349219};\\\", \\\"{x:1552,y:738,t:1526930349235};\\\", \\\"{x:1551,y:735,t:1526930349253};\\\", \\\"{x:1550,y:734,t:1526930349269};\\\", \\\"{x:1550,y:732,t:1526930349286};\\\", \\\"{x:1549,y:729,t:1526930349302};\\\", \\\"{x:1549,y:728,t:1526930349318};\\\", \\\"{x:1549,y:726,t:1526930349336};\\\", \\\"{x:1549,y:723,t:1526930349352};\\\", \\\"{x:1548,y:722,t:1526930349369};\\\", \\\"{x:1548,y:720,t:1526930349389};\\\", \\\"{x:1548,y:719,t:1526930349402};\\\", \\\"{x:1548,y:717,t:1526930349419};\\\", \\\"{x:1548,y:714,t:1526930349435};\\\", \\\"{x:1548,y:710,t:1526930349453};\\\", \\\"{x:1548,y:707,t:1526930349469};\\\", \\\"{x:1548,y:704,t:1526930349486};\\\", \\\"{x:1548,y:703,t:1526930349502};\\\", \\\"{x:1548,y:702,t:1526930349542};\\\", \\\"{x:1548,y:701,t:1526930349566};\\\", \\\"{x:1548,y:700,t:1526930349582};\\\", \\\"{x:1548,y:699,t:1526930349639};\\\", \\\"{x:1548,y:698,t:1526930349903};\\\", \\\"{x:1547,y:698,t:1526930351287};\\\", \\\"{x:1550,y:696,t:1526930351375};\\\", \\\"{x:1555,y:695,t:1526930351388};\\\", \\\"{x:1559,y:691,t:1526930351404};\\\", \\\"{x:1562,y:691,t:1526930351421};\\\", \\\"{x:1563,y:689,t:1526930351438};\\\", \\\"{x:1564,y:689,t:1526930351606};\\\", \\\"{x:1563,y:690,t:1526930351621};\\\", \\\"{x:1559,y:691,t:1526930351638};\\\", \\\"{x:1557,y:692,t:1526930351653};\\\", \\\"{x:1556,y:692,t:1526930351711};\\\", \\\"{x:1554,y:693,t:1526930351726};\\\", \\\"{x:1553,y:693,t:1526930351738};\\\", \\\"{x:1550,y:695,t:1526930351755};\\\", \\\"{x:1549,y:695,t:1526930351782};\\\", \\\"{x:1548,y:695,t:1526930351790};\\\", \\\"{x:1548,y:696,t:1526930351806};\\\", \\\"{x:1547,y:696,t:1526930351879};\\\", \\\"{x:1546,y:697,t:1526930355695};\\\", \\\"{x:1539,y:699,t:1526930355708};\\\", \\\"{x:1500,y:704,t:1526930355724};\\\", \\\"{x:1424,y:708,t:1526930355741};\\\", \\\"{x:1274,y:708,t:1526930355757};\\\", \\\"{x:1158,y:708,t:1526930355774};\\\", \\\"{x:1052,y:708,t:1526930355791};\\\", \\\"{x:950,y:708,t:1526930355808};\\\", \\\"{x:877,y:708,t:1526930355824};\\\", \\\"{x:816,y:708,t:1526930355840};\\\", \\\"{x:763,y:708,t:1526930355858};\\\", \\\"{x:737,y:708,t:1526930355873};\\\", \\\"{x:724,y:708,t:1526930355891};\\\", \\\"{x:715,y:708,t:1526930355908};\\\", \\\"{x:712,y:708,t:1526930355924};\\\", \\\"{x:709,y:708,t:1526930355941};\\\", \\\"{x:707,y:708,t:1526930355966};\\\", \\\"{x:706,y:708,t:1526930355974};\\\", \\\"{x:702,y:708,t:1526930355991};\\\", \\\"{x:692,y:707,t:1526930356008};\\\", \\\"{x:679,y:704,t:1526930356024};\\\", \\\"{x:661,y:701,t:1526930356040};\\\", \\\"{x:641,y:694,t:1526930356057};\\\", \\\"{x:621,y:688,t:1526930356075};\\\", \\\"{x:595,y:682,t:1526930356091};\\\", \\\"{x:564,y:672,t:1526930356108};\\\", \\\"{x:541,y:665,t:1526930356125};\\\", \\\"{x:517,y:658,t:1526930356141};\\\", \\\"{x:489,y:647,t:1526930356159};\\\", \\\"{x:476,y:638,t:1526930356174};\\\", \\\"{x:465,y:627,t:1526930356190};\\\", \\\"{x:442,y:599,t:1526930356225};\\\", \\\"{x:432,y:589,t:1526930356241};\\\", \\\"{x:426,y:580,t:1526930356258};\\\", \\\"{x:418,y:573,t:1526930356274};\\\", \\\"{x:412,y:568,t:1526930356291};\\\", \\\"{x:406,y:563,t:1526930356308};\\\", \\\"{x:402,y:558,t:1526930356325};\\\", \\\"{x:399,y:553,t:1526930356341};\\\", \\\"{x:398,y:551,t:1526930356358};\\\", \\\"{x:396,y:549,t:1526930356375};\\\", \\\"{x:395,y:548,t:1526930356390};\\\", \\\"{x:392,y:546,t:1526930356407};\\\", \\\"{x:389,y:546,t:1526930356425};\\\", \\\"{x:386,y:545,t:1526930356441};\\\", \\\"{x:383,y:543,t:1526930356457};\\\", \\\"{x:380,y:543,t:1526930356475};\\\", \\\"{x:379,y:543,t:1526930356491};\\\", \\\"{x:378,y:542,t:1526930356508};\\\", \\\"{x:377,y:542,t:1526930356574};\\\", \\\"{x:375,y:542,t:1526930356806};\\\", \\\"{x:372,y:542,t:1526930356814};\\\", \\\"{x:369,y:542,t:1526930356825};\\\", \\\"{x:365,y:542,t:1526930356841};\\\", \\\"{x:360,y:542,t:1526930356859};\\\", \\\"{x:354,y:542,t:1526930356874};\\\", \\\"{x:349,y:542,t:1526930356892};\\\", \\\"{x:342,y:542,t:1526930356908};\\\", \\\"{x:335,y:542,t:1526930356924};\\\", \\\"{x:317,y:543,t:1526930356941};\\\", \\\"{x:300,y:544,t:1526930356959};\\\", \\\"{x:285,y:544,t:1526930356974};\\\", \\\"{x:270,y:544,t:1526930356992};\\\", \\\"{x:264,y:544,t:1526930357008};\\\", \\\"{x:255,y:545,t:1526930357025};\\\", \\\"{x:247,y:546,t:1526930357041};\\\", \\\"{x:239,y:548,t:1526930357058};\\\", \\\"{x:231,y:548,t:1526930357074};\\\", \\\"{x:223,y:549,t:1526930357091};\\\", \\\"{x:214,y:552,t:1526930357108};\\\", \\\"{x:205,y:553,t:1526930357125};\\\", \\\"{x:201,y:554,t:1526930357141};\\\", \\\"{x:200,y:554,t:1526930357214};\\\", \\\"{x:200,y:555,t:1526930357225};\\\", \\\"{x:201,y:557,t:1526930357243};\\\", \\\"{x:218,y:559,t:1526930357259};\\\", \\\"{x:249,y:563,t:1526930357276};\\\", \\\"{x:310,y:563,t:1526930357291};\\\", \\\"{x:382,y:563,t:1526930357308};\\\", \\\"{x:483,y:563,t:1526930357325};\\\", \\\"{x:541,y:563,t:1526930357342};\\\", \\\"{x:577,y:563,t:1526930357358};\\\", \\\"{x:606,y:563,t:1526930357374};\\\", \\\"{x:625,y:563,t:1526930357391};\\\", \\\"{x:632,y:563,t:1526930357409};\\\", \\\"{x:634,y:562,t:1526930357425};\\\", \\\"{x:635,y:561,t:1526930357517};\\\", \\\"{x:636,y:560,t:1526930357565};\\\", \\\"{x:636,y:559,t:1526930357575};\\\", \\\"{x:636,y:555,t:1526930357592};\\\", \\\"{x:636,y:548,t:1526930357608};\\\", \\\"{x:636,y:539,t:1526930357625};\\\", \\\"{x:633,y:531,t:1526930357641};\\\", \\\"{x:627,y:526,t:1526930357659};\\\", \\\"{x:621,y:523,t:1526930357676};\\\", \\\"{x:619,y:521,t:1526930357691};\\\", \\\"{x:618,y:521,t:1526930357708};\\\", \\\"{x:616,y:521,t:1526930357878};\\\", \\\"{x:614,y:522,t:1526930357892};\\\", \\\"{x:612,y:524,t:1526930357909};\\\", \\\"{x:612,y:527,t:1526930357927};\\\", \\\"{x:612,y:528,t:1526930357949};\\\", \\\"{x:612,y:529,t:1526930357960};\\\", \\\"{x:613,y:532,t:1526930357975};\\\", \\\"{x:618,y:533,t:1526930357992};\\\", \\\"{x:631,y:533,t:1526930358009};\\\", \\\"{x:642,y:533,t:1526930358026};\\\", \\\"{x:654,y:533,t:1526930358042};\\\", \\\"{x:670,y:531,t:1526930358060};\\\", \\\"{x:687,y:525,t:1526930358076};\\\", \\\"{x:704,y:517,t:1526930358093};\\\", \\\"{x:726,y:508,t:1526930358109};\\\", \\\"{x:735,y:504,t:1526930358125};\\\", \\\"{x:741,y:501,t:1526930358143};\\\", \\\"{x:745,y:499,t:1526930358159};\\\", \\\"{x:748,y:497,t:1526930358175};\\\", \\\"{x:750,y:496,t:1526930358205};\\\", \\\"{x:751,y:496,t:1526930358222};\\\", \\\"{x:752,y:496,t:1526930358229};\\\", \\\"{x:755,y:495,t:1526930358242};\\\", \\\"{x:760,y:493,t:1526930358260};\\\", \\\"{x:769,y:492,t:1526930358276};\\\", \\\"{x:777,y:492,t:1526930358293};\\\", \\\"{x:781,y:492,t:1526930358308};\\\", \\\"{x:785,y:492,t:1526930358325};\\\", \\\"{x:788,y:492,t:1526930358342};\\\", \\\"{x:792,y:492,t:1526930358359};\\\", \\\"{x:799,y:492,t:1526930358375};\\\", \\\"{x:805,y:492,t:1526930358393};\\\", \\\"{x:807,y:492,t:1526930358410};\\\", \\\"{x:808,y:492,t:1526930358425};\\\", \\\"{x:809,y:492,t:1526930358443};\\\", \\\"{x:810,y:492,t:1526930358460};\\\", \\\"{x:812,y:492,t:1526930358477};\\\", \\\"{x:818,y:492,t:1526930358493};\\\", \\\"{x:822,y:492,t:1526930358510};\\\", \\\"{x:823,y:492,t:1526930358526};\\\", \\\"{x:825,y:492,t:1526930358543};\\\", \\\"{x:826,y:492,t:1526930358574};\\\", \\\"{x:829,y:492,t:1526930358593};\\\", \\\"{x:834,y:494,t:1526930358611};\\\", \\\"{x:840,y:496,t:1526930358627};\\\", \\\"{x:848,y:498,t:1526930358644};\\\", \\\"{x:851,y:500,t:1526930358660};\\\", \\\"{x:853,y:501,t:1526930358677};\\\", \\\"{x:851,y:503,t:1526930359005};\\\", \\\"{x:849,y:503,t:1526930359013};\\\", \\\"{x:848,y:503,t:1526930359026};\\\", \\\"{x:846,y:503,t:1526930359043};\\\", \\\"{x:845,y:503,t:1526930359060};\\\", \\\"{x:844,y:503,t:1526930359076};\\\", \\\"{x:842,y:504,t:1526930359093};\\\", \\\"{x:838,y:507,t:1526930359109};\\\", \\\"{x:826,y:512,t:1526930359127};\\\", \\\"{x:807,y:519,t:1526930359144};\\\", \\\"{x:775,y:532,t:1526930359161};\\\", \\\"{x:723,y:554,t:1526930359178};\\\", \\\"{x:649,y:583,t:1526930359194};\\\", \\\"{x:556,y:621,t:1526930359210};\\\", \\\"{x:471,y:654,t:1526930359227};\\\", \\\"{x:418,y:679,t:1526930359243};\\\", \\\"{x:386,y:693,t:1526930359259};\\\", \\\"{x:369,y:701,t:1526930359277};\\\", \\\"{x:365,y:704,t:1526930359294};\\\", \\\"{x:365,y:705,t:1526930359309};\\\", \\\"{x:367,y:708,t:1526930359326};\\\", \\\"{x:367,y:709,t:1526930359344};\\\", \\\"{x:367,y:711,t:1526930359388};\\\", \\\"{x:370,y:714,t:1526930359397};\\\", \\\"{x:375,y:717,t:1526930359409};\\\", \\\"{x:398,y:724,t:1526930359427};\\\", \\\"{x:436,y:729,t:1526930359444};\\\", \\\"{x:468,y:729,t:1526930359462};\\\", \\\"{x:493,y:729,t:1526930359477};\\\", \\\"{x:508,y:730,t:1526930359494};\\\", \\\"{x:517,y:732,t:1526930359510};\\\", \\\"{x:525,y:733,t:1526930359527};\\\", \\\"{x:532,y:734,t:1526930359544};\\\", \\\"{x:537,y:734,t:1526930359560};\\\", \\\"{x:541,y:734,t:1526930359577};\\\" ] }, { \\\"rt\\\": 80900, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 798399, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X -O -O -O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:734,t:1526930362566};\\\", \\\"{x:540,y:734,t:1526930363491};\\\", \\\"{x:536,y:733,t:1526930363500};\\\", \\\"{x:529,y:711,t:1526930363514};\\\", \\\"{x:535,y:698,t:1526930363530};\\\", \\\"{x:536,y:698,t:1526930363543};\\\", \\\"{x:534,y:695,t:1526930391907};\\\", \\\"{x:418,y:625,t:1526930391924};\\\", \\\"{x:284,y:548,t:1526930391939};\\\", \\\"{x:196,y:513,t:1526930391956};\\\", \\\"{x:175,y:510,t:1526930391983};\\\", \\\"{x:175,y:508,t:1526930392619};\\\", \\\"{x:180,y:496,t:1526930392636};\\\", \\\"{x:187,y:486,t:1526930392651};\\\", \\\"{x:191,y:480,t:1526930392666};\\\", \\\"{x:192,y:480,t:1526930392682};\\\", \\\"{x:193,y:479,t:1526930392699};\\\", \\\"{x:194,y:479,t:1526930392851};\\\", \\\"{x:197,y:479,t:1526930392866};\\\", \\\"{x:204,y:479,t:1526930392882};\\\", \\\"{x:213,y:479,t:1526930392899};\\\", \\\"{x:220,y:479,t:1526930392915};\\\", \\\"{x:226,y:480,t:1526930392932};\\\", \\\"{x:234,y:481,t:1526930392948};\\\", \\\"{x:243,y:484,t:1526930392966};\\\", \\\"{x:251,y:486,t:1526930392982};\\\", \\\"{x:257,y:489,t:1526930392998};\\\", \\\"{x:264,y:490,t:1526930393016};\\\", \\\"{x:271,y:493,t:1526930393032};\\\", \\\"{x:277,y:494,t:1526930393048};\\\", \\\"{x:285,y:497,t:1526930393065};\\\", \\\"{x:287,y:498,t:1526930393082};\\\", \\\"{x:290,y:498,t:1526930393099};\\\", \\\"{x:292,y:500,t:1526930393115};\\\", \\\"{x:295,y:501,t:1526930393133};\\\", \\\"{x:298,y:503,t:1526930393148};\\\", \\\"{x:305,y:505,t:1526930393168};\\\", \\\"{x:311,y:508,t:1526930393185};\\\", \\\"{x:315,y:510,t:1526930393202};\\\", \\\"{x:322,y:513,t:1526930393218};\\\", \\\"{x:326,y:516,t:1526930393234};\\\", \\\"{x:330,y:517,t:1526930393251};\\\", \\\"{x:336,y:520,t:1526930393268};\\\", \\\"{x:341,y:524,t:1526930393285};\\\", \\\"{x:346,y:526,t:1526930393301};\\\", \\\"{x:351,y:528,t:1526930393319};\\\", \\\"{x:357,y:530,t:1526930393335};\\\", \\\"{x:365,y:532,t:1526930393352};\\\", \\\"{x:378,y:534,t:1526930393369};\\\", \\\"{x:391,y:535,t:1526930393385};\\\", \\\"{x:409,y:537,t:1526930393402};\\\", \\\"{x:438,y:538,t:1526930393418};\\\", \\\"{x:453,y:538,t:1526930393436};\\\", \\\"{x:465,y:539,t:1526930393452};\\\", \\\"{x:472,y:540,t:1526930393468};\\\", \\\"{x:478,y:542,t:1526930393485};\\\", \\\"{x:479,y:542,t:1526930393501};\\\", \\\"{x:480,y:542,t:1526930393518};\\\", \\\"{x:481,y:543,t:1526930393610};\\\", \\\"{x:483,y:543,t:1526930393618};\\\", \\\"{x:490,y:546,t:1526930393636};\\\", \\\"{x:504,y:550,t:1526930393652};\\\", \\\"{x:528,y:553,t:1526930393668};\\\", \\\"{x:557,y:557,t:1526930393686};\\\", \\\"{x:602,y:557,t:1526930393703};\\\", \\\"{x:652,y:557,t:1526930393718};\\\", \\\"{x:705,y:557,t:1526930393735};\\\", \\\"{x:750,y:557,t:1526930393752};\\\", \\\"{x:780,y:557,t:1526930393768};\\\", \\\"{x:799,y:557,t:1526930393785};\\\", \\\"{x:810,y:557,t:1526930393801};\\\", \\\"{x:814,y:557,t:1526930393818};\\\", \\\"{x:814,y:558,t:1526930393882};\\\", \\\"{x:811,y:561,t:1526930393898};\\\", \\\"{x:809,y:562,t:1526930393906};\\\", \\\"{x:806,y:562,t:1526930393918};\\\", \\\"{x:800,y:565,t:1526930393935};\\\", \\\"{x:796,y:568,t:1526930393951};\\\", \\\"{x:791,y:569,t:1526930393969};\\\", \\\"{x:781,y:569,t:1526930393985};\\\", \\\"{x:767,y:569,t:1526930394002};\\\", \\\"{x:723,y:558,t:1526930394020};\\\", \\\"{x:685,y:549,t:1526930394035};\\\", \\\"{x:649,y:542,t:1526930394053};\\\", \\\"{x:622,y:534,t:1526930394070};\\\", \\\"{x:610,y:529,t:1526930394086};\\\", \\\"{x:604,y:526,t:1526930394103};\\\", \\\"{x:604,y:524,t:1526930394202};\\\", \\\"{x:604,y:522,t:1526930394226};\\\", \\\"{x:606,y:522,t:1526930394235};\\\", \\\"{x:616,y:520,t:1526930394253};\\\", \\\"{x:635,y:518,t:1526930394270};\\\", \\\"{x:659,y:514,t:1526930394286};\\\", \\\"{x:682,y:511,t:1526930394302};\\\", \\\"{x:711,y:511,t:1526930394319};\\\", \\\"{x:739,y:511,t:1526930394337};\\\", \\\"{x:765,y:511,t:1526930394353};\\\", \\\"{x:780,y:511,t:1526930394369};\\\", \\\"{x:788,y:511,t:1526930394385};\\\", \\\"{x:794,y:511,t:1526930394403};\\\", \\\"{x:797,y:511,t:1526930394419};\\\", \\\"{x:799,y:511,t:1526930394436};\\\", \\\"{x:800,y:511,t:1526930394458};\\\", \\\"{x:802,y:511,t:1526930394595};\\\", \\\"{x:805,y:511,t:1526930394602};\\\", \\\"{x:809,y:514,t:1526930394619};\\\", \\\"{x:813,y:514,t:1526930394635};\\\", \\\"{x:816,y:514,t:1526930394652};\\\", \\\"{x:818,y:514,t:1526930394670};\\\", \\\"{x:821,y:514,t:1526930394686};\\\", \\\"{x:823,y:514,t:1526930394702};\\\", \\\"{x:824,y:514,t:1526930394719};\\\", \\\"{x:825,y:514,t:1526930394736};\\\", \\\"{x:826,y:513,t:1526930394753};\\\", \\\"{x:827,y:512,t:1526930394850};\\\", \\\"{x:828,y:511,t:1526930394866};\\\", \\\"{x:829,y:510,t:1526930394874};\\\", \\\"{x:831,y:510,t:1526930394899};\\\", \\\"{x:832,y:509,t:1526930394939};\\\", \\\"{x:833,y:509,t:1526930394963};\\\", \\\"{x:833,y:508,t:1526930395330};\\\", \\\"{x:834,y:507,t:1526930395338};\\\", \\\"{x:835,y:506,t:1526930395354};\\\", \\\"{x:836,y:506,t:1526930395370};\\\", \\\"{x:842,y:506,t:1526930395386};\\\", \\\"{x:861,y:506,t:1526930395404};\\\", \\\"{x:910,y:508,t:1526930395420};\\\", \\\"{x:994,y:519,t:1526930395437};\\\", \\\"{x:1102,y:533,t:1526930395453};\\\", \\\"{x:1225,y:539,t:1526930395470};\\\", \\\"{x:1342,y:543,t:1526930395486};\\\", \\\"{x:1448,y:547,t:1526930395504};\\\", \\\"{x:1553,y:549,t:1526930395520};\\\", \\\"{x:1621,y:553,t:1526930395536};\\\", \\\"{x:1659,y:553,t:1526930395553};\\\", \\\"{x:1668,y:553,t:1526930395571};\\\", \\\"{x:1667,y:554,t:1526930395650};\\\", \\\"{x:1663,y:558,t:1526930395658};\\\", \\\"{x:1659,y:563,t:1526930395671};\\\", \\\"{x:1648,y:575,t:1526930395687};\\\", \\\"{x:1629,y:591,t:1526930395704};\\\", \\\"{x:1607,y:605,t:1526930395721};\\\", \\\"{x:1588,y:622,t:1526930395736};\\\", \\\"{x:1575,y:636,t:1526930395754};\\\", \\\"{x:1563,y:657,t:1526930395770};\\\", \\\"{x:1555,y:668,t:1526930395786};\\\", \\\"{x:1550,y:675,t:1526930395804};\\\", \\\"{x:1547,y:682,t:1526930395821};\\\", \\\"{x:1543,y:687,t:1526930395838};\\\", \\\"{x:1541,y:693,t:1526930395854};\\\", \\\"{x:1539,y:696,t:1526930395871};\\\", \\\"{x:1539,y:697,t:1526930395887};\\\", \\\"{x:1538,y:698,t:1526930395904};\\\", \\\"{x:1538,y:699,t:1526930395921};\\\", \\\"{x:1535,y:701,t:1526930395938};\\\", \\\"{x:1529,y:704,t:1526930395954};\\\", \\\"{x:1515,y:713,t:1526930395971};\\\", \\\"{x:1510,y:717,t:1526930395987};\\\", \\\"{x:1507,y:718,t:1526930396004};\\\", \\\"{x:1504,y:719,t:1526930396021};\\\", \\\"{x:1503,y:719,t:1526930396038};\\\", \\\"{x:1502,y:719,t:1526930396054};\\\", \\\"{x:1497,y:719,t:1526930396071};\\\", \\\"{x:1489,y:719,t:1526930396088};\\\", \\\"{x:1483,y:719,t:1526930396104};\\\", \\\"{x:1475,y:719,t:1526930396121};\\\", \\\"{x:1469,y:719,t:1526930396138};\\\", \\\"{x:1465,y:719,t:1526930396154};\\\", \\\"{x:1463,y:719,t:1526930396170};\\\", \\\"{x:1461,y:719,t:1526930396188};\\\", \\\"{x:1460,y:719,t:1526930396204};\\\", \\\"{x:1458,y:719,t:1526930396243};\\\", \\\"{x:1458,y:720,t:1526930396259};\\\", \\\"{x:1457,y:720,t:1526930396271};\\\", \\\"{x:1457,y:721,t:1526930396291};\\\", \\\"{x:1457,y:723,t:1526930396304};\\\", \\\"{x:1457,y:725,t:1526930396321};\\\", \\\"{x:1457,y:728,t:1526930396338};\\\", \\\"{x:1460,y:739,t:1526930396354};\\\", \\\"{x:1464,y:751,t:1526930396371};\\\", \\\"{x:1469,y:764,t:1526930396389};\\\", \\\"{x:1471,y:780,t:1526930396405};\\\", \\\"{x:1474,y:791,t:1526930396421};\\\", \\\"{x:1475,y:800,t:1526930396439};\\\", \\\"{x:1476,y:809,t:1526930396455};\\\", \\\"{x:1479,y:820,t:1526930396471};\\\", \\\"{x:1484,y:837,t:1526930396490};\\\", \\\"{x:1489,y:854,t:1526930396505};\\\", \\\"{x:1492,y:867,t:1526930396521};\\\", \\\"{x:1494,y:876,t:1526930396538};\\\", \\\"{x:1494,y:889,t:1526930396554};\\\", \\\"{x:1493,y:899,t:1526930396571};\\\", \\\"{x:1493,y:914,t:1526930396589};\\\", \\\"{x:1493,y:928,t:1526930396606};\\\", \\\"{x:1494,y:943,t:1526930396621};\\\", \\\"{x:1494,y:951,t:1526930396638};\\\", \\\"{x:1494,y:952,t:1526930396655};\\\", \\\"{x:1492,y:952,t:1526930396763};\\\", \\\"{x:1486,y:942,t:1526930396771};\\\", \\\"{x:1479,y:923,t:1526930396788};\\\", \\\"{x:1475,y:908,t:1526930396805};\\\", \\\"{x:1473,y:895,t:1526930396822};\\\", \\\"{x:1473,y:889,t:1526930396838};\\\", \\\"{x:1473,y:882,t:1526930396856};\\\", \\\"{x:1473,y:873,t:1526930396872};\\\", \\\"{x:1473,y:864,t:1526930396888};\\\", \\\"{x:1473,y:854,t:1526930396906};\\\", \\\"{x:1473,y:845,t:1526930396922};\\\", \\\"{x:1473,y:838,t:1526930396939};\\\", \\\"{x:1474,y:829,t:1526930396955};\\\", \\\"{x:1475,y:824,t:1526930396972};\\\", \\\"{x:1475,y:820,t:1526930396988};\\\", \\\"{x:1476,y:814,t:1526930397006};\\\", \\\"{x:1476,y:809,t:1526930397022};\\\", \\\"{x:1476,y:803,t:1526930397038};\\\", \\\"{x:1476,y:797,t:1526930397055};\\\", \\\"{x:1476,y:793,t:1526930397073};\\\", \\\"{x:1476,y:790,t:1526930397088};\\\", \\\"{x:1476,y:785,t:1526930397105};\\\", \\\"{x:1477,y:775,t:1526930397122};\\\", \\\"{x:1477,y:768,t:1526930397138};\\\", \\\"{x:1477,y:750,t:1526930397155};\\\", \\\"{x:1478,y:740,t:1526930397172};\\\", \\\"{x:1478,y:733,t:1526930397188};\\\", \\\"{x:1478,y:723,t:1526930397205};\\\", \\\"{x:1478,y:714,t:1526930397222};\\\", \\\"{x:1478,y:701,t:1526930397239};\\\", \\\"{x:1478,y:698,t:1526930397255};\\\", \\\"{x:1478,y:694,t:1526930397272};\\\", \\\"{x:1478,y:693,t:1526930397288};\\\", \\\"{x:1478,y:690,t:1526930397306};\\\", \\\"{x:1478,y:688,t:1526930397326};\\\", \\\"{x:1478,y:687,t:1526930397337};\\\", \\\"{x:1479,y:687,t:1526930397499};\\\", \\\"{x:1479,y:689,t:1526930397514};\\\", \\\"{x:1482,y:691,t:1526930397521};\\\", \\\"{x:1483,y:692,t:1526930397538};\\\", \\\"{x:1483,y:693,t:1526930397555};\\\", \\\"{x:1483,y:694,t:1526930397995};\\\", \\\"{x:1483,y:694,t:1526930409381};\\\", \\\"{x:1483,y:696,t:1526930413100};\\\", \\\"{x:1482,y:697,t:1526930413107};\\\", \\\"{x:1480,y:699,t:1526930413118};\\\", \\\"{x:1476,y:702,t:1526930413135};\\\", \\\"{x:1473,y:704,t:1526930413151};\\\", \\\"{x:1472,y:704,t:1526930413170};\\\", \\\"{x:1473,y:704,t:1526930413833};\\\", \\\"{x:1474,y:704,t:1526930413841};\\\", \\\"{x:1475,y:704,t:1526930413858};\\\", \\\"{x:1476,y:704,t:1526930413873};\\\", \\\"{x:1477,y:704,t:1526930413885};\\\", \\\"{x:1477,y:703,t:1526930413901};\\\", \\\"{x:1478,y:703,t:1526930413979};\\\", \\\"{x:1479,y:703,t:1526930413994};\\\", \\\"{x:1479,y:702,t:1526930414018};\\\", \\\"{x:1480,y:701,t:1526930414035};\\\", \\\"{x:1480,y:699,t:1526930414835};\\\", \\\"{x:1481,y:699,t:1526930414882};\\\", \\\"{x:1482,y:698,t:1526930414947};\\\", \\\"{x:1482,y:696,t:1526930414979};\\\", \\\"{x:1482,y:695,t:1526930414994};\\\", \\\"{x:1480,y:693,t:1526930415003};\\\", \\\"{x:1479,y:692,t:1526930415018};\\\", \\\"{x:1478,y:692,t:1526930417810};\\\", \\\"{x:1478,y:695,t:1526930417821};\\\", \\\"{x:1477,y:699,t:1526930417837};\\\", \\\"{x:1477,y:700,t:1526930417855};\\\", \\\"{x:1477,y:701,t:1526930417871};\\\", \\\"{x:1477,y:702,t:1526930417888};\\\", \\\"{x:1476,y:702,t:1526930417962};\\\", \\\"{x:1477,y:702,t:1526930418147};\\\", \\\"{x:1478,y:702,t:1526930418195};\\\", \\\"{x:1478,y:700,t:1526930418227};\\\", \\\"{x:1479,y:699,t:1526930423520};\\\", \\\"{x:1480,y:698,t:1526930423528};\\\", \\\"{x:1482,y:696,t:1526930423540};\\\", \\\"{x:1485,y:696,t:1526930423556};\\\", \\\"{x:1487,y:695,t:1526930423574};\\\", \\\"{x:1487,y:696,t:1526930432537};\\\", \\\"{x:1488,y:697,t:1526930432547};\\\", \\\"{x:1488,y:698,t:1526930432563};\\\", \\\"{x:1489,y:700,t:1526930432580};\\\", \\\"{x:1490,y:700,t:1526930432596};\\\", \\\"{x:1490,y:701,t:1526930432615};\\\", \\\"{x:1491,y:703,t:1526930432656};\\\", \\\"{x:1492,y:704,t:1526930432671};\\\", \\\"{x:1493,y:705,t:1526930432687};\\\", \\\"{x:1493,y:706,t:1526930432719};\\\", \\\"{x:1494,y:707,t:1526930432735};\\\", \\\"{x:1495,y:709,t:1526930432745};\\\", \\\"{x:1497,y:712,t:1526930432763};\\\", \\\"{x:1500,y:717,t:1526930432780};\\\", \\\"{x:1504,y:723,t:1526930432796};\\\", \\\"{x:1506,y:731,t:1526930432813};\\\", \\\"{x:1510,y:737,t:1526930432830};\\\", \\\"{x:1514,y:745,t:1526930432846};\\\", \\\"{x:1516,y:748,t:1526930432863};\\\", \\\"{x:1518,y:751,t:1526930432879};\\\", \\\"{x:1519,y:753,t:1526930432896};\\\", \\\"{x:1520,y:756,t:1526930432912};\\\", \\\"{x:1520,y:757,t:1526930432929};\\\", \\\"{x:1520,y:758,t:1526930432946};\\\", \\\"{x:1521,y:759,t:1526930432962};\\\", \\\"{x:1521,y:760,t:1526930433064};\\\", \\\"{x:1520,y:760,t:1526930433080};\\\", \\\"{x:1519,y:758,t:1526930433097};\\\", \\\"{x:1516,y:755,t:1526930433113};\\\", \\\"{x:1514,y:754,t:1526930433130};\\\", \\\"{x:1512,y:752,t:1526930433147};\\\", \\\"{x:1511,y:751,t:1526930433163};\\\", \\\"{x:1510,y:751,t:1526930433180};\\\", \\\"{x:1510,y:750,t:1526930433197};\\\", \\\"{x:1509,y:750,t:1526930433409};\\\", \\\"{x:1509,y:751,t:1526930433432};\\\", \\\"{x:1509,y:752,t:1526930433512};\\\", \\\"{x:1510,y:752,t:1526930434920};\\\", \\\"{x:1511,y:753,t:1526930434951};\\\", \\\"{x:1512,y:753,t:1526930434965};\\\", \\\"{x:1513,y:754,t:1526930434981};\\\", \\\"{x:1514,y:755,t:1526930435023};\\\", \\\"{x:1515,y:755,t:1526930435047};\\\", \\\"{x:1516,y:755,t:1526930435065};\\\", \\\"{x:1517,y:755,t:1526930435096};\\\", \\\"{x:1518,y:755,t:1526930435152};\\\", \\\"{x:1518,y:756,t:1526930435383};\\\", \\\"{x:1518,y:757,t:1526930435398};\\\", \\\"{x:1516,y:758,t:1526930435418};\\\", \\\"{x:1512,y:761,t:1526930435431};\\\", \\\"{x:1511,y:761,t:1526930437503};\\\", \\\"{x:1509,y:760,t:1526930439634};\\\", \\\"{x:1497,y:753,t:1526930439639};\\\", \\\"{x:1481,y:742,t:1526930439651};\\\", \\\"{x:1444,y:711,t:1526930439667};\\\", \\\"{x:1348,y:664,t:1526930439684};\\\", \\\"{x:1157,y:594,t:1526930439700};\\\", \\\"{x:960,y:537,t:1526930439717};\\\", \\\"{x:677,y:466,t:1526930439734};\\\", \\\"{x:510,y:435,t:1526930439751};\\\", \\\"{x:413,y:421,t:1526930439767};\\\", \\\"{x:380,y:416,t:1526930439785};\\\", \\\"{x:377,y:415,t:1526930439800};\\\", \\\"{x:380,y:415,t:1526930439846};\\\", \\\"{x:388,y:418,t:1526930439854};\\\", \\\"{x:399,y:423,t:1526930439867};\\\", \\\"{x:419,y:430,t:1526930439885};\\\", \\\"{x:435,y:439,t:1526930439901};\\\", \\\"{x:443,y:446,t:1526930439918};\\\", \\\"{x:458,y:466,t:1526930439935};\\\", \\\"{x:469,y:481,t:1526930439952};\\\", \\\"{x:479,y:494,t:1526930439968};\\\", \\\"{x:493,y:504,t:1526930439985};\\\", \\\"{x:505,y:509,t:1526930440003};\\\", \\\"{x:513,y:510,t:1526930440017};\\\", \\\"{x:513,y:511,t:1526930440037};\\\", \\\"{x:512,y:511,t:1526930440079};\\\", \\\"{x:510,y:511,t:1526930440086};\\\", \\\"{x:513,y:511,t:1526930440142};\\\", \\\"{x:518,y:513,t:1526930440215};\\\", \\\"{x:524,y:517,t:1526930440223};\\\", \\\"{x:533,y:521,t:1526930440236};\\\", \\\"{x:547,y:530,t:1526930440254};\\\", \\\"{x:559,y:536,t:1526930440270};\\\", \\\"{x:570,y:542,t:1526930440286};\\\", \\\"{x:578,y:542,t:1526930440303};\\\", \\\"{x:584,y:542,t:1526930440319};\\\", \\\"{x:586,y:542,t:1526930440335};\\\", \\\"{x:588,y:542,t:1526930440391};\\\", \\\"{x:591,y:542,t:1526930440403};\\\", \\\"{x:600,y:537,t:1526930440419};\\\", \\\"{x:616,y:527,t:1526930440436};\\\", \\\"{x:623,y:522,t:1526930440454};\\\", \\\"{x:626,y:518,t:1526930440470};\\\", \\\"{x:626,y:516,t:1526930440486};\\\", \\\"{x:626,y:515,t:1526930440584};\\\", \\\"{x:626,y:514,t:1526930440607};\\\", \\\"{x:625,y:514,t:1526930440712};\\\", \\\"{x:624,y:514,t:1526930440959};\\\", \\\"{x:622,y:516,t:1526930440971};\\\", \\\"{x:618,y:521,t:1526930440987};\\\", \\\"{x:609,y:531,t:1526930441004};\\\", \\\"{x:600,y:546,t:1526930441022};\\\", \\\"{x:586,y:563,t:1526930441038};\\\", \\\"{x:575,y:580,t:1526930441054};\\\", \\\"{x:570,y:611,t:1526930441070};\\\", \\\"{x:571,y:633,t:1526930441088};\\\", \\\"{x:580,y:654,t:1526930441104};\\\", \\\"{x:587,y:669,t:1526930441121};\\\", \\\"{x:588,y:670,t:1526930441137};\\\", \\\"{x:589,y:673,t:1526930441153};\\\", \\\"{x:591,y:679,t:1526930441171};\\\", \\\"{x:591,y:685,t:1526930441187};\\\", \\\"{x:591,y:688,t:1526930441204};\\\", \\\"{x:590,y:696,t:1526930441221};\\\", \\\"{x:585,y:706,t:1526930441238};\\\", \\\"{x:579,y:715,t:1526930441254};\\\", \\\"{x:578,y:717,t:1526930441270};\\\", \\\"{x:576,y:717,t:1526930441288};\\\", \\\"{x:571,y:717,t:1526930441304};\\\", \\\"{x:566,y:717,t:1526930441321};\\\", \\\"{x:560,y:717,t:1526930441338};\\\", \\\"{x:558,y:717,t:1526930441354};\\\", \\\"{x:556,y:717,t:1526930441371};\\\", \\\"{x:555,y:717,t:1526930441388};\\\", \\\"{x:551,y:719,t:1526930441405};\\\", \\\"{x:546,y:722,t:1526930441422};\\\", \\\"{x:541,y:726,t:1526930441438};\\\", \\\"{x:537,y:727,t:1526930441454};\\\", \\\"{x:537,y:728,t:1526930441471};\\\", \\\"{x:534,y:731,t:1526930441575};\\\", \\\"{x:534,y:733,t:1526930441588};\\\", \\\"{x:529,y:742,t:1526930441606};\\\", \\\"{x:524,y:751,t:1526930441623};\\\", \\\"{x:523,y:754,t:1526930441638};\\\", \\\"{x:520,y:758,t:1526930441654};\\\", \\\"{x:519,y:758,t:1526930441894};\\\", \\\"{x:519,y:759,t:1526930441915};\\\", \\\"{x:520,y:759,t:1526930442160};\\\", \\\"{x:521,y:759,t:1526930442183};\\\", \\\"{x:522,y:759,t:1526930442224};\\\", \\\"{x:523,y:759,t:1526930442263};\\\", \\\"{x:524,y:759,t:1526930442351};\\\", \\\"{x:525,y:759,t:1526930442367};\\\", \\\"{x:526,y:759,t:1526930442375};\\\", \\\"{x:527,y:759,t:1526930442391};\\\", \\\"{x:528,y:759,t:1526930442415};\\\", \\\"{x:529,y:759,t:1526930442431};\\\", \\\"{x:530,y:759,t:1526930442455};\\\", \\\"{x:531,y:759,t:1526930442495};\\\", \\\"{x:532,y:759,t:1526930442504};\\\", \\\"{x:533,y:759,t:1526930442522};\\\", \\\"{x:536,y:759,t:1526930442539};\\\", \\\"{x:537,y:759,t:1526930442555};\\\", \\\"{x:538,y:759,t:1526930442571};\\\", \\\"{x:539,y:759,t:1526930442589};\\\", \\\"{x:540,y:759,t:1526930442711};\\\", \\\"{x:541,y:759,t:1526930442727};\\\", \\\"{x:542,y:759,t:1526930442743};\\\", \\\"{x:543,y:758,t:1526930442767};\\\", \\\"{x:545,y:757,t:1526930442871};\\\", \\\"{x:554,y:754,t:1526930442889};\\\", \\\"{x:558,y:751,t:1526930442905};\\\", \\\"{x:559,y:751,t:1526930443038};\\\", \\\"{x:562,y:749,t:1526930443054};\\\", \\\"{x:566,y:748,t:1526930443072};\\\", \\\"{x:566,y:747,t:1526930443175};\\\", \\\"{x:567,y:746,t:1526930443189};\\\", \\\"{x:570,y:744,t:1526930443204};\\\", \\\"{x:571,y:744,t:1526930443221};\\\", \\\"{x:572,y:744,t:1526930443247};\\\" ] }, { \\\"rt\\\": 64487, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 864473, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"look up 12 on the x axis and then follow from that point up the y axis.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10942, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"23\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"united states\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 876423, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 16467, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fifth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 893904, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 13905, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 909141, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"UX4QZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2767}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":5,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":6,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":7,\"textContent\":\" \"},{\"nodeType\":1,\"id\":8,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":9,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":8,\"id\":11},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":20,\"textContent\":\" \"},{\"nodeType\":1,\"id\":21,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":22,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":8,\"id\":24},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":1,\"id\":38,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":8,\"id\":40},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":1,\"id\":42,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":8,\"id\":46},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":51,\"textContent\":\" \"},{\"nodeType\":1,\"id\":52,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":53,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":8,\"id\":55},{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":8,\"id\":61},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\" \"},{\"nodeType\":1,\"id\":77,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":78,\"textContent\":\"UX4QZ\"}]},{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":1,\"id\":80,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":8,\"id\":82},{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\" \"},{\"nodeType\":1,\"id\":86,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":87,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":88,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":8,\"id\":92},{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\" \"},{\"nodeType\":1,\"id\":98,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":99,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":103,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":104,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":105,\"textContent\":\" \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":108,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":111,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":112,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":113,\"textContent\":\" \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":116,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":117,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":119,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":120,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":121,\"textContent\":\" \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":124,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":125,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":223,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\" \"},{\"nodeType\":1,\"id\":227,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":228,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":232,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":233,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":237,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":238,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":239,\"textContent\":\" \"},{\"nodeType\":1,\"id\":240,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":241,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":242,\"textContent\":\" \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":245,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":246,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":247,\"textContent\":\" \"},{\"nodeType\":1,\"id\":248,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":249,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":250,\"textContent\":\" \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":253,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":254,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":256,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":257,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":258,\"textContent\":\" \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":261,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":262,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":263,\"textContent\":\" \"},{\"nodeType\":1,\"id\":264,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":265,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":266,\"textContent\":\" \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":269,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":270,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":271,\"textContent\":\" \"},{\"nodeType\":1,\"id\":272,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":273,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":277,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":278,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":279,\"textContent\":\" \"},{\"nodeType\":1,\"id\":280,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":281,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":282,\"textContent\":\" \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":285,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":286,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":288,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":289,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":293,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":294,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":295,\"textContent\":\" \"},{\"nodeType\":1,\"id\":296,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":297,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":301,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":302,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":303,\"textContent\":\" \"},{\"nodeType\":1,\"id\":304,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":305,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":309,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":310,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":311,\"textContent\":\" \"},{\"nodeType\":1,\"id\":312,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":313,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":314,\"textContent\":\" \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":317,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":318,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":319,\"textContent\":\" \"},{\"nodeType\":1,\"id\":320,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":321,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":322,\"textContent\":\" \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":325,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":326,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":327,\"textContent\":\" \"},{\"nodeType\":1,\"id\":328,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":329,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":330,\"textContent\":\" \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":333,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":334,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":335,\"textContent\":\" \"},{\"nodeType\":1,\"id\":336,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":337,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":338,\"textContent\":\" \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":341,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":342,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":343,\"textContent\":\" \"},{\"nodeType\":1,\"id\":344,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":345,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":346,\"textContent\":\" \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":349,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":352,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\" \"},{\"nodeType\":1,\"id\":356,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":357,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":360,\"textContent\":\" \"},{\"nodeType\":1,\"id\":361,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":362,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":363,\"textContent\":\" \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":366,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":367,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":368,\"textContent\":\" \"},{\"nodeType\":1,\"id\":369,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":370,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":371,\"textContent\":\" \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":374,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":375,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":376,\"textContent\":\" \"},{\"nodeType\":1,\"id\":377,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":378,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":379,\"textContent\":\" \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":382,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":383,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":384,\"textContent\":\" \"},{\"nodeType\":1,\"id\":385,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":386,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":387,\"textContent\":\" \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":390,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":391,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":392,\"textContent\":\" \"},{\"nodeType\":1,\"id\":393,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":394,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":395,\"textContent\":\" \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":398,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":399,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":400,\"textContent\":\" \"},{\"nodeType\":1,\"id\":401,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":402,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":403,\"textContent\":\" \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":406,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":407,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":408,\"textContent\":\" \"},{\"nodeType\":1,\"id\":409,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":410,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":411,\"textContent\":\" \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":414,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":415,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":416,\"textContent\":\" \"},{\"nodeType\":1,\"id\":417,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":418,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":419,\"textContent\":\" \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":422,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":423,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":424,\"textContent\":\" \"},{\"nodeType\":1,\"id\":425,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":426,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":427,\"textContent\":\" \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":430,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":431,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":432,\"textContent\":\" \"},{\"nodeType\":1,\"id\":433,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":434,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":435,\"textContent\":\" \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":438,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":439,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":440,\"textContent\":\" \"},{\"nodeType\":1,\"id\":441,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":442,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":443,\"textContent\":\" \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":446,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":447,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":448,\"textContent\":\" \"},{\"nodeType\":1,\"id\":449,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":450,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":451,\"textContent\":\" \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":454,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":455,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":456,\"textContent\":\" \"},{\"nodeType\":1,\"id\":457,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":458,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":459,\"textContent\":\" \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":462,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":463,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":464,\"textContent\":\" \"},{\"nodeType\":1,\"id\":465,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":466,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":467,\"textContent\":\" \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":470,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":471,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":472,\"textContent\":\" \"},{\"nodeType\":1,\"id\":473,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":474,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":475,\"textContent\":\" \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":478,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":481,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" \"},{\"nodeType\":1,\"id\":485,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":486,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":489,\"textContent\":\" \"},{\"nodeType\":1,\"id\":490,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":491,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":492,\"textContent\":\" \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":495,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":496,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":497,\"textContent\":\" \"},{\"nodeType\":1,\"id\":498,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":499,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":500,\"textContent\":\" \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":503,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":504,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":506,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":507,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":508,\"textContent\":\" \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":511,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":512,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":513,\"textContent\":\" \"},{\"nodeType\":1,\"id\":514,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":515,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":516,\"textContent\":\" \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":519,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":520,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":521,\"textContent\":\" \"},{\"nodeType\":1,\"id\":522,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":523,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":524,\"textContent\":\" \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":527,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":528,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":529,\"textContent\":\" \"},{\"nodeType\":1,\"id\":530,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":531,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":532,\"textContent\":\" \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":535,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":536,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":537,\"textContent\":\" \"},{\"nodeType\":1,\"id\":538,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":539,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":540,\"textContent\":\" \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":543,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":544,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":545,\"textContent\":\" \"},{\"nodeType\":1,\"id\":546,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":547,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":548,\"textContent\":\" \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":551,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":552,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":553,\"textContent\":\" \"},{\"nodeType\":1,\"id\":554,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":555,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":556,\"textContent\":\" \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":559,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":560,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":561,\"textContent\":\" \"},{\"nodeType\":1,\"id\":562,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":563,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":564,\"textContent\":\" \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":567,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":568,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":569,\"textContent\":\" \"},{\"nodeType\":1,\"id\":570,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":571,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":572,\"textContent\":\" \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":575,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":576,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":577,\"textContent\":\" \"},{\"nodeType\":1,\"id\":578,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":579,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":580,\"textContent\":\" \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":583,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":584,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":585,\"textContent\":\" \"},{\"nodeType\":1,\"id\":586,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":587,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":588,\"textContent\":\" \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":591,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":592,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":594,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":595,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":596,\"textContent\":\" \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":599,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":600,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":602,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":603,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":604,\"textContent\":\" \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":607,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":610,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\" \"},{\"nodeType\":1,\"id\":614,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":615,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":616,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":617,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":620,\"textContent\":\" \"},{\"nodeType\":1,\"id\":621,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":622,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":623,\"textContent\":\" \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":626,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":627,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":628,\"textContent\":\" \"},{\"nodeType\":1,\"id\":629,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":630,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":631,\"textContent\":\" \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":634,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":635,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":636,\"textContent\":\" \"},{\"nodeType\":1,\"id\":637,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":638,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":639,\"textContent\":\" \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":642,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":643,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":644,\"textContent\":\" \"},{\"nodeType\":1,\"id\":645,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":647,\"textContent\":\" \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":650,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":651,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":652,\"textContent\":\" \"},{\"nodeType\":1,\"id\":653,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":655,\"textContent\":\" \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":658,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":659,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":661,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":662,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":666,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":667,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":669,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":670,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":671,\"textContent\":\" \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":674,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":675,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":677,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":679,\"textContent\":\" \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":682,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":683,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":685,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":687,\"textContent\":\" \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":690,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":691,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":693,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":694,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":695,\"textContent\":\" \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":698,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":699,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":701,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":702,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":703,\"textContent\":\" \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":706,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":707,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":709,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":710,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":711,\"textContent\":\" \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":714,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":715,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":717,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":718,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":719,\"textContent\":\" \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":722,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":723,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":725,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":726,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":727,\"textContent\":\" \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":730,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":731,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":733,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":734,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":735,\"textContent\":\" \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":738,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":741,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\" \"},{\"nodeType\":1,\"id\":745,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":746,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":749,\"textContent\":\" \"},{\"nodeType\":1,\"id\":750,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":751,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":752,\"textContent\":\" \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":755,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":756,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":757,\"textContent\":\" \"},{\"nodeType\":1,\"id\":758,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":759,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":760,\"textContent\":\" \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":763,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":764,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":765,\"textContent\":\" \"},{\"nodeType\":1,\"id\":766,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":767,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":768,\"textContent\":\" \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":771,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":772,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":773,\"textContent\":\" \"},{\"nodeType\":1,\"id\":774,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":775,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":776,\"textContent\":\" \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":779,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":780,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":781,\"textContent\":\" \"},{\"nodeType\":1,\"id\":782,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":783,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":784,\"textContent\":\" \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":787,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":788,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":789,\"textContent\":\" \"},{\"nodeType\":1,\"id\":790,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":791,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":792,\"textContent\":\" \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":795,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":796,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":797,\"textContent\":\" \"},{\"nodeType\":1,\"id\":798,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":799,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":800,\"textContent\":\" \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":803,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":804,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":805,\"textContent\":\" \"},{\"nodeType\":1,\"id\":806,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":807,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":808,\"textContent\":\" \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":811,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":812,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":814,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":815,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":819,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":820,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":822,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":823,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":824,\"textContent\":\" \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":827,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":828,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":830,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":831,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":832,\"textContent\":\" \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":835,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":836,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":838,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":839,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":840,\"textContent\":\" \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":843,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":844,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":846,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":847,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":848,\"textContent\":\" \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":851,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":852,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":854,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":855,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":856,\"textContent\":\" \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":859,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":860,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":862,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":863,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":864,\"textContent\":\" \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":867,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":868,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":870,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":871,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":872,\"textContent\":\" \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":875,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":876,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":878,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":879,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":880,\"textContent\":\" \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":883,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":884,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":886,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":887,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":888,\"textContent\":\" \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":891,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":894,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\" \"},{\"nodeType\":1,\"id\":898,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":899,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":902,\"textContent\":\" \"},{\"nodeType\":1,\"id\":903,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":904,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":905,\"textContent\":\" \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":908,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":909,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":910,\"textContent\":\" \"},{\"nodeType\":1,\"id\":911,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":912,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":913,\"textContent\":\" \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":916,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":917,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":918,\"textContent\":\" \"},{\"nodeType\":1,\"id\":919,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":920,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":921,\"textContent\":\" \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":924,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":925,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":926,\"textContent\":\" \"},{\"nodeType\":1,\"id\":927,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":928,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":929,\"textContent\":\" \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":932,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":933,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":934,\"textContent\":\" \"},{\"nodeType\":1,\"id\":935,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":936,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":937,\"textContent\":\" \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":940,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":941,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":942,\"textContent\":\" \"},{\"nodeType\":1,\"id\":943,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":944,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":945,\"textContent\":\" \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":948,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":949,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":950,\"textContent\":\" \"},{\"nodeType\":1,\"id\":951,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":952,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":953,\"textContent\":\" \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":956,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":957,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":958,\"textContent\":\" \"},{\"nodeType\":1,\"id\":959,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":960,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":961,\"textContent\":\" \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":964,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":965,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":967,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":968,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":972,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":973,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":975,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":976,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":977,\"textContent\":\" \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":980,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":981,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":983,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":984,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":985,\"textContent\":\" \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":988,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":989,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":991,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":992,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":993,\"textContent\":\" \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":996,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":997,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":999,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1000,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1001,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1004,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1005,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1007,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1008,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1009,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1012,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1013,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1015,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1016,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1017,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1020,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1021,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1023,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1024,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1025,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1028,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1029,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1031,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1032,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1033,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1036,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1037,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1039,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1040,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1041,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1044,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1047,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1051,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1052,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1055,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1056,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1057,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1058,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1061,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1062,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1063,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1064,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1065,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1066,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1069,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1070,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1071,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1072,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1073,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1074,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1077,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1078,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1079,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1080,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1081,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1082,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1085,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1086,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1087,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1088,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1089,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1090,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1093,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1094,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1095,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1096,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1097,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1098,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1101,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1102,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1104,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1105,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1106,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1109,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1110,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1112,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1113,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1114,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1117,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1118,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1120,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1121,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1122,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1125,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1126,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1128,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1129,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1130,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1134,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1136,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1137,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1138,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1141,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1142,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1144,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1145,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1146,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1149,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1150,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1152,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1153,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1154,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1157,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1158,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1160,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1161,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1162,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1165,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1166,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1168,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1169,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1170,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1173,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1174,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1176,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1177,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1178,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1181,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1182,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1184,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1185,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1186,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1189,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1190,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1192,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1193,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1194,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1197,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1200,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1204,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1205,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1208,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1209,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1210,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1211,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1214,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1215,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1216,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1217,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1218,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1219,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1222,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1223,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1225,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1226,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1230,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1231,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1233,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1234,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1235,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1238,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1239,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1241,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1242,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1243,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1246,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1247,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1249,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1250,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1251,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1254,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1255,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1257,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1258,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1259,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1262,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1263,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1265,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1266,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1267,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1270,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1271,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1273,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1274,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1275,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1278,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1279,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1281,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1282,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1283,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1287,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1289,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1290,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1291,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1294,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1295,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1297,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1298,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1299,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1302,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1303,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1305,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1306,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1307,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1310,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1311,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1313,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1314,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1315,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1318,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1319,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1321,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1322,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1323,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1326,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1327,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1329,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1330,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1331,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1334,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1335,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1337,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1338,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1339,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1342,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1343,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1345,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1346,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1347,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1350,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1353,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1357,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1358,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1362,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1363,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1364,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1367,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1368,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1370,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1371,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1372,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1375,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1376,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1378,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1379,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1380,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1383,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1384,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1386,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1387,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1388,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1391,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1392,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1394,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1395,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1396,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1399,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1400,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1402,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1403,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1404,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1407,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1408,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1410,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1411,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1412,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1415,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1416,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1418,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1419,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1420,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1423,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1424,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1426,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1427,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1428,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1431,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1432,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1434,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1435,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1436,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1439,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1440,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1442,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1443,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1444,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1447,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1448,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1450,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1451,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1452,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1455,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1456,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1458,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1459,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1460,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1463,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1464,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1466,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1467,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1468,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1471,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1472,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1474,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1475,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1476,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1479,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1480,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1481,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1482,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1483,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1484,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1487,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1488,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1489,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1490,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1491,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1492,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1495,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1496,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1497,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1498,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1499,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1500,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1503,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1506,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1510,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1511,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1515,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1516,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1517,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1520,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1521,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1523,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1524,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1525,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1528,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1529,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1531,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1532,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1533,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1536,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1537,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1539,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1540,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1541,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1544,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1545,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1547,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1548,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1549,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1552,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1553,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1555,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1556,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1557,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1560,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1561,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1563,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1564,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1565,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1568,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1569,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1571,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1572,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1573,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1576,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1577,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1579,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1580,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1581,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1584,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1585,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1587,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1588,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1589,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1592,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1593,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1595,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1596,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1597,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1600,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1601,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1603,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1604,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1605,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1608,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1609,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1610,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1611,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1612,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1613,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1616,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1617,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1659,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1663,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1664,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1667,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1668,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1670,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1673,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1674,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1675,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1676,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1677,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1678,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1681,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1682,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1683,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1684,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1685,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1686,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1689,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1690,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1691,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1692,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1694,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1697,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1698,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1699,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1700,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1702,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1705,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1706,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1707,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1708,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1710,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1713,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1714,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1715,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1716,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1718,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1722,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1723,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1724,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1725,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1726,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1730,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1731,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1732,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1733,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1734,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1737,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1738,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1739,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1740,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1741,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1745,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1746,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1812,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1816,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1817,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1820,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1821,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1822,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1823,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1826,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1827,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1828,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1829,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1830,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1831,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1834,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1835,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1836,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1837,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1838,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1839,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1842,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1843,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1844,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1845,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1846,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1847,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1850,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1851,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1852,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1853,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1854,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1855,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1858,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1859,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1860,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1861,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1862,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1863,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1866,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1867,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1868,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1869,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1870,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1871,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1874,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1875,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1876,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1877,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1878,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1879,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1882,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1883,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1884,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1885,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1886,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1887,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1890,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1891,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1892,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1893,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1894,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1898,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1899,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1965,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1969,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1970,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1973,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1974,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1975,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1976,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1979,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1980,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1981,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1982,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1983,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1984,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1987,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1988,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1989,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1990,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1991,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1992,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1995,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1996,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1997,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1998,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1999,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2000,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2003,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2004,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2005,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2006,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2007,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2008,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2011,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2012,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2013,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2014,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2015,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2016,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2019,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2020,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2021,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2022,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2023,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2024,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2027,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2028,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2029,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2030,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2031,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2032,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2035,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2036,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2037,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2038,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2039,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2040,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2043,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2044,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2045,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2046,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2047,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2051,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2052,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2118,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2123,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2124,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2125,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2129,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2130,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2131,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2134,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2135,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2137,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2138,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2139,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2142,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2143,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2145,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2146,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2147,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2150,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2151,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2153,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2154,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2155,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2158,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2159,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2161,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2162,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2163,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2166,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2167,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2169,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2170,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2171,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2174,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2175,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2177,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2178,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2179,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2182,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2183,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2185,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2186,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2187,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2190,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2191,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2193,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2194,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2195,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2198,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2199,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2201,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2202,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2203,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2206,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2207,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2208,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2209,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2210,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2211,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2214,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2215,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2216,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2217,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2218,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2219,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2222,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2223,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2225,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2226,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2230,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2231,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2233,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2234,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2235,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2238,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2239,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2241,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2242,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2243,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2246,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2247,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2249,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2250,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2251,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2254,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2255,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2257,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2258,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2259,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2262,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2263,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2265,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2266,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2267,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2270,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2273,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2277,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2278,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2280,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2282,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2286},{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2290,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2291,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2292,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2293,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2294,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2296,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2298},{\"nodeType\":3,\"id\":2299,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2304,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2305,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2307},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2311,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2312,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 130, dom: 1184, initialDom: 1286",
  "javascriptErrors": []
}