var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8c5e2a495a0d928c4408ba626551e0a3",
  "created": "2018-05-18T11:11:10.1639747-07:00",
  "lastActivity": "2018-05-18T11:11:25.7479747-07:00",
  "pageViews": [
    {
      "id": "05181006ef2eafcc66e6a1b67795f8f071d54819",
      "startTime": "2018-05-18T11:11:10.1639747-07:00",
      "endTime": "2018-05-18T11:11:25.7479747-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 15584,
      "engagementTime": 15484,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15584,
  "engagementTime": 15484,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.42",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=HWJDK",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "72235b1b29f3518556aa68d5bfaee1ac",
  "gdpr": false
}