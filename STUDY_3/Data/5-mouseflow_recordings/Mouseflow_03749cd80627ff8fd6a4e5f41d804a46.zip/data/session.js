var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "03749cd80627ff8fd6a4e5f41d804a46",
  "created": "2018-05-29T16:08:07.9377669-07:00",
  "lastActivity": "2018-05-29T16:08:25.2027669-07:00",
  "pageViews": [
    {
      "id": "0529086799088eaf1729a6d2e8571d0c118733f8",
      "startTime": "2018-05-29T16:08:07.9377669-07:00",
      "endTime": "2018-05-29T16:08:25.2027669-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 17265,
      "engagementTime": 17265,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17265,
  "engagementTime": 17265,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.49",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=93XU7",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6a7e4819268a7fb8cb2a31eeedeade5a",
  "gdpr": false
}