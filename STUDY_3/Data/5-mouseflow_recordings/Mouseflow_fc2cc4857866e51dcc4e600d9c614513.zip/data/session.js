var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "fc2cc4857866e51dcc4e600d9c614513",
  "created": "2018-05-18T10:22:23.5949458-07:00",
  "lastActivity": "2018-05-18T10:23:40.8900368-07:00",
  "pageViews": [
    {
      "id": "05182366e905508956949b57b1ebdd5becfdfb70",
      "startTime": "2018-05-18T10:22:23.5949458-07:00",
      "endTime": "2018-05-18T10:23:40.8900368-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 77315,
      "engagementTime": 76929,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 77315,
  "engagementTime": 76929,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=J994U",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a3d3289d8bbd18e6e2c011545d82defe",
  "gdpr": false
}