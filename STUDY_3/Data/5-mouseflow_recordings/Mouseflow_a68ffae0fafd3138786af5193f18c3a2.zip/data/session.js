var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a68ffae0fafd3138786af5193f18c3a2",
  "created": "2018-05-24T12:06:37.876139-07:00",
  "lastActivity": "2018-05-24T12:06:48.581139-07:00",
  "pageViews": [
    {
      "id": "05243818755c58b967be20d9c0772cfa3b9a9d09",
      "startTime": "2018-05-24T12:06:37.876139-07:00",
      "endTime": "2018-05-24T12:06:48.581139-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 10705,
      "engagementTime": 10624,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10705,
  "engagementTime": 10624,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZUJQV",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "cddf81417cc9e3a8aef4f43f63cb1cce",
  "gdpr": false
}