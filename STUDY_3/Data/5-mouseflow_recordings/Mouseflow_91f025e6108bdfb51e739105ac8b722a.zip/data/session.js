var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "91f025e6108bdfb51e739105ac8b722a",
  "created": "2018-05-22T10:07:15.6986315-07:00",
  "lastActivity": "2018-05-22T10:10:19.1928047-07:00",
  "pageViews": [
    {
      "id": "05221530269dda69d8e72b1543a750fd026ce6ff",
      "startTime": "2018-05-22T10:07:15.6986315-07:00",
      "endTime": "2018-05-22T10:10:19.1928047-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 183693,
      "engagementTime": 57652,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 183693,
  "engagementTime": 57652,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c1b64bd82fbdb257c65379dadce7152e",
  "gdpr": false
}