var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6e7b4f1535848b50209e23423ff94e52",
  "created": "2018-05-29T13:17:46.3679479-07:00",
  "lastActivity": "2018-05-29T13:19:17.0649479-07:00",
  "pageViews": [
    {
      "id": "05294641373ba80970096372ad14884746adc6a5",
      "startTime": "2018-05-29T13:17:46.3679479-07:00",
      "endTime": "2018-05-29T13:19:17.0649479-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 90697,
      "engagementTime": 56241,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 90697,
  "engagementTime": 56241,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=EPDQP",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "309a3bdaf4ce8269cc68cc56bd108b93",
  "gdpr": false
}