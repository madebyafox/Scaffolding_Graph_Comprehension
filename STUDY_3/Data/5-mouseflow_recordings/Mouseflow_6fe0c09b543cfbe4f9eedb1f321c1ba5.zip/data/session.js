var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6fe0c09b543cfbe4f9eedb1f321c1ba5",
  "created": "2018-06-04T12:14:13.8450494-07:00",
  "lastActivity": "2018-06-04T12:14:41.4920494-07:00",
  "pageViews": [
    {
      "id": "06041446f1e707e722615da5049a0427f4bca731",
      "startTime": "2018-06-04T12:14:13.8450494-07:00",
      "endTime": "2018-06-04T12:14:41.4920494-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 27647,
      "engagementTime": 27647,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 27647,
  "engagementTime": 27647,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZEPVG",
    "CONDITION=311",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c46d5dcddaaddd36e91c3f792bee3da4",
  "gdpr": false
}