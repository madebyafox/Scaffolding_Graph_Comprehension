var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "100f611afe6b7c4f46f7a41f8569f3d5",
  "created": "2018-05-22T10:25:34.8758584-07:00",
  "lastActivity": "2018-05-22T10:26:54.055971-07:00",
  "pageViews": [
    {
      "id": "052234509197815bf3db58c2b8845d944a40b645",
      "startTime": "2018-05-22T10:25:34.8758584-07:00",
      "endTime": "2018-05-22T10:26:54.055971-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 79191,
      "engagementTime": 78421,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 79191,
  "engagementTime": 78421,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=FSWW4",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2c78ebfec13cc6151cc26a915042f799",
  "gdpr": false
}