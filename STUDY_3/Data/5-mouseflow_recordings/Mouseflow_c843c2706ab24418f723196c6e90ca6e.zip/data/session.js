var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c843c2706ab24418f723196c6e90ca6e",
  "created": "2018-05-15T14:07:13.3628132-07:00",
  "lastActivity": "2018-05-15T14:08:44.7158132-07:00",
  "pageViews": [
    {
      "id": "05151383ddb6a4accd310faa606369ffe118a5a6",
      "startTime": "2018-05-15T14:07:13.3628132-07:00",
      "endTime": "2018-05-15T14:08:44.7158132-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 91353,
      "engagementTime": 42557,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 91353,
  "engagementTime": 42557,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8LGZ4",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "86ad494a487720bad070af31ac1d074c",
  "gdpr": false
}