var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "63fdeb4725db9832aa096524761429e7",
  "created": "2018-06-01T10:14:43.148516-07:00",
  "lastActivity": "2018-06-01T10:16:21.242516-07:00",
  "pageViews": [
    {
      "id": "06014347b8a3be546dbf10fbcd621eb4e79787cd",
      "startTime": "2018-06-01T10:14:43.148516-07:00",
      "endTime": "2018-06-01T10:16:21.242516-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 98094,
      "engagementTime": 96539,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 98094,
  "engagementTime": 96539,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=ZAOCZ",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "20023c8a4dbd3499b12331e86de9eb55",
  "gdpr": false
}