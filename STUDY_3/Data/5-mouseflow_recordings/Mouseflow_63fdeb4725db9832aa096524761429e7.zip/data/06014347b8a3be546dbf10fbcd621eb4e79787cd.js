var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06014347b8a3be546dbf10fbcd621eb4e79787cd"] = {
  "startTime": "2018-06-01T17:14:43.148516Z",
  "websitePageUrl": "/16",
  "visitTime": 98094,
  "engagementTime": 96539,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "63fdeb4725db9832aa096524761429e7",
    "created": "2018-06-01T17:14:43.148516+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=ZAOCZ",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "20023c8a4dbd3499b12331e86de9eb55",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/63fdeb4725db9832aa096524761429e7/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 225,
      "e": 225,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 225,
      "e": 225,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 400,
      "e": 400,
      "ty": 2,
      "x": 492,
      "y": 746
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 494,
      "y": 734
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 44616,
      "y": 40218,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 675,
      "e": 675,
      "ty": 2,
      "x": 496,
      "y": 706
    },
    {
      "t": 678,
      "e": 678,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 496,
      "y": 702
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 44616,
      "y": 38002,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 490,
      "y": 684
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 451,
      "y": 613
    },
    {
      "t": 918,
      "e": 918,
      "ty": 6,
      "x": 449,
      "y": 595,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 449,
      "y": 589
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 39557,
      "y": 53613,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 451,
      "y": 576
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 450,
      "y": 573
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 39670,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1302,
      "e": 1302,
      "ty": 3,
      "x": 450,
      "y": 573,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1304,
      "e": 1304,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1429,
      "e": 1429,
      "ty": 4,
      "x": 39670,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1429,
      "e": 1429,
      "ty": 5,
      "x": 450,
      "y": 573,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 447,
      "y": 573
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 39332,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 446,
      "y": 573
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 39220,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 445,
      "y": 573
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 39108,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 444,
      "y": 574
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 443,
      "y": 577
    },
    {
      "t": 5456,
      "e": 5456,
      "ty": 7,
      "x": 484,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 551,
      "y": 632
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 51023,
      "y": 34567,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 878,
      "y": 766
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 996,
      "y": 842
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 18534,
      "y": 52786,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5800,
      "e": 5800,
      "ty": 2,
      "x": 1125,
      "y": 926
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1186,
      "y": 976
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 1282,
      "y": 1025
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 34953,
      "y": 63529,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6100,
      "e": 6100,
      "ty": 2,
      "x": 1293,
      "y": 1027
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1325,
      "y": 1031
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 44372,
      "y": 13107,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[26] > text"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1330,
      "y": 1029
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1293,
      "y": 1018
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1200,
      "y": 989
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 29174,
      "y": 60951,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1153,
      "y": 968
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 1138,
      "y": 955
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 24805,
      "y": 58157,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1139,
      "y": 947
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1143,
      "y": 929
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 2,
      "x": 1140,
      "y": 901
    },
    {
      "t": 7002,
      "e": 7002,
      "ty": 41,
      "x": 24946,
      "y": 54648,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 1138,
      "y": 897
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 24805,
      "y": 54361,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9099,
      "e": 9099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9250,
      "e": 9250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9250,
      "e": 9250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9329,
      "e": 9329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 9329,
      "e": 9329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9337,
      "e": 9337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "ON"
    },
    {
      "t": 9361,
      "e": 9361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "ON"
    },
    {
      "t": 9457,
      "e": 9457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "ON"
    },
    {
      "t": 9546,
      "e": 9546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9546,
      "e": 9546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9649,
      "e": 9649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "ON "
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10010,
      "e": 10010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10065,
      "e": 10065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "ON"
    },
    {
      "t": 10161,
      "e": 10161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10210,
      "e": 10210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "O"
    },
    {
      "t": 10434,
      "e": 10434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 10434,
      "e": 10434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10498,
      "e": 10498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On"
    },
    {
      "t": 10570,
      "e": 10570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10571,
      "e": 10571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10673,
      "e": 10673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On "
    },
    {
      "t": 11086,
      "e": 11086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11086,
      "e": 11086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11181,
      "e": 11181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On t"
    },
    {
      "t": 11206,
      "e": 11206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11206,
      "e": 11206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11302,
      "e": 11302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 11309,
      "e": 11309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11310,
      "e": 11310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11422,
      "e": 11422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 11438,
      "e": 11438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11439,
      "e": 11439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11549,
      "e": 11549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12446,
      "e": 12446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 12447,
      "e": 12447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12509,
      "e": 12509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 12557,
      "e": 12557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12557,
      "e": 12557,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12638,
      "e": 12638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12718,
      "e": 12718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12719,
      "e": 12719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12814,
      "e": 12814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 12997,
      "e": 12997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 12997,
      "e": 12997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13101,
      "e": 13101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 13125,
      "e": 13125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13126,
      "e": 13126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13174,
      "e": 13174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 13253,
      "e": 13253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13255,
      "e": 13255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13325,
      "e": 13325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 13357,
      "e": 13357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13358,
      "e": 13358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13445,
      "e": 13445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13486,
      "e": 13486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13486,
      "e": 13486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13549,
      "e": 13549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 13550,
      "e": 13550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13556,
      "e": 13556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||of"
    },
    {
      "t": 13613,
      "e": 13613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13629,
      "e": 13629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13629,
      "e": 13629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13709,
      "e": 13709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13742,
      "e": 13742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13742,
      "e": 13742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13805,
      "e": 13805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13806,
      "e": 13806,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13813,
      "e": 13813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 13885,
      "e": 13885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13925,
      "e": 13925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13926,
      "e": 13926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14007,
      "e": 14007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14008,
      "e": 14008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14012,
      "e": 14012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 14117,
      "e": 14117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14133,
      "e": 14133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 14134,
      "e": 14134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14181,
      "e": 14181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 14285,
      "e": 14285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14286,
      "e": 14286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14381,
      "e": 14381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 14381,
      "e": 14381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14381,
      "e": 14381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14413,
      "e": 14413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 14414,
      "e": 14414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14510,
      "e": 14510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ap"
    },
    {
      "t": 14518,
      "e": 14518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14574,
      "e": 14574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14574,
      "e": 14574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14677,
      "e": 14677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14790,
      "e": 14790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 14791,
      "e": 14791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14853,
      "e": 14853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 14925,
      "e": 14925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14926,
      "e": 14926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14981,
      "e": 14981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15302,
      "e": 15302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15357,
      "e": 15357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph."
    },
    {
      "t": 15446,
      "e": 15446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15501,
      "e": 15501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph"
    },
    {
      "t": 15607,
      "e": 15607,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph"
    },
    {
      "t": 16245,
      "e": 16245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 16245,
      "e": 16245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16301,
      "e": 16301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 16373,
      "e": 16373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16374,
      "e": 16374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16437,
      "e": 16437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18062,
      "e": 18062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18063,
      "e": 18063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18101,
      "e": 18101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18206,
      "e": 18206,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, l"
    },
    {
      "t": 18246,
      "e": 18246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18246,
      "e": 18246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18293,
      "e": 18293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18381,
      "e": 18381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18383,
      "e": 18383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18445,
      "e": 18445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18558,
      "e": 18558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 18558,
      "e": 18558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18612,
      "e": 18612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 18620,
      "e": 18620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18621,
      "e": 18621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18733,
      "e": 18733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18765,
      "e": 18765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 18766,
      "e": 18766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18885,
      "e": 18885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 18909,
      "e": 18909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18909,
      "e": 18909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18933,
      "e": 18933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18934,
      "e": 18934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19014,
      "e": 18935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 19077,
      "e": 18998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19141,
      "e": 19062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 19143,
      "e": 19064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19277,
      "e": 19198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19277,
      "e": 19198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19285,
      "e": 19206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 19382,
      "e": 19303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19430,
      "e": 19351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19430,
      "e": 19351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19525,
      "e": 19446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19621,
      "e": 19542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19621,
      "e": 19542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19677,
      "e": 19598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19677,
      "e": 19598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19709,
      "e": 19630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 19773,
      "e": 19694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19797,
      "e": 19718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19797,
      "e": 19718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19901,
      "e": 19822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 19901,
      "e": 19822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19925,
      "e": 19846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 20014,
      "e": 19935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20014,
      "e": 19935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20037,
      "e": 19958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 20109,
      "e": 20030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21221,
      "e": 21142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21269,
      "e": 21190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where ther"
    },
    {
      "t": 21366,
      "e": 21287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21397,
      "e": 21318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where the"
    },
    {
      "t": 21620,
      "e": 21541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21661,
      "e": 21582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where th"
    },
    {
      "t": 21741,
      "e": 21662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21797,
      "e": 21718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where t"
    },
    {
      "t": 22766,
      "e": 22687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 22767,
      "e": 22688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22829,
      "e": 22750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 22829,
      "e": 22750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22885,
      "e": 22806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 22933,
      "e": 22854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23413,
      "e": 23334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23414,
      "e": 23335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23500,
      "e": 23421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23525,
      "e": 23446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 23525,
      "e": 23446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23589,
      "e": 23510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 23725,
      "e": 23646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 23727,
      "e": 23648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23798,
      "e": 23719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 23821,
      "e": 23742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23821,
      "e": 23742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23894,
      "e": 23815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23981,
      "e": 23902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23982,
      "e": 23903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24085,
      "e": 24006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 24301,
      "e": 24222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24349,
      "e": 24270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where t12 pm "
    },
    {
      "t": 24429,
      "e": 24350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24469,
      "e": 24390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where t12 pm"
    },
    {
      "t": 24541,
      "e": 24462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24588,
      "e": 24509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where t12 p"
    },
    {
      "t": 24661,
      "e": 24582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24693,
      "e": 24614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where t12 "
    },
    {
      "t": 24788,
      "e": 24709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24820,
      "e": 24741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where t12"
    },
    {
      "t": 24909,
      "e": 24830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24957,
      "e": 24878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where t1"
    },
    {
      "t": 25053,
      "e": 24974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25085,
      "e": 25006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where t"
    },
    {
      "t": 25207,
      "e": 25007,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where t"
    },
    {
      "t": 25486,
      "e": 25286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25557,
      "e": 25357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where "
    },
    {
      "t": 25957,
      "e": 25757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 25958,
      "e": 25758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26021,
      "e": 25821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 26021,
      "e": 25821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26053,
      "e": 25853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 26125,
      "e": 25925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26157,
      "e": 25957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26157,
      "e": 25957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26270,
      "e": 26070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26270,
      "e": 26070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26271,
      "e": 26071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26381,
      "e": 26181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 26573,
      "e": 26373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26574,
      "e": 26374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26662,
      "e": 26462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26821,
      "e": 26621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26885,
      "e": 26685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 p"
    },
    {
      "t": 27005,
      "e": 26805,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 p"
    },
    {
      "t": 27270,
      "e": 27070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 27270,
      "e": 27070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27308,
      "e": 27108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 27348,
      "e": 27148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27349,
      "e": 27149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27413,
      "e": 27213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27429,
      "e": 27229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27429,
      "e": 27229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27477,
      "e": 27277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27550,
      "e": 27350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 27551,
      "e": 27351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27637,
      "e": 27437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27637,
      "e": 27437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 27637,
      "e": 27437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27701,
      "e": 27501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 27749,
      "e": 27549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27750,
      "e": 27550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27806,
      "e": 27606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31071,
      "e": 30871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 31526,
      "e": 31326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 31526,
      "e": 31326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31608,
      "e": 31408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||G"
    },
    {
      "t": 31608,
      "e": 31408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31845,
      "e": 31645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31847,
      "e": 31647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31902,
      "e": 31702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31940,
      "e": 31740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31941,
      "e": 31741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32012,
      "e": 31812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32413,
      "e": 32213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32414,
      "e": 32214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32478,
      "e": 32278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 32589,
      "e": 32389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32590,
      "e": 32390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32646,
      "e": 32446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32750,
      "e": 32550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 32750,
      "e": 32550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32844,
      "e": 32644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 32893,
      "e": 32693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32893,
      "e": 32693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32981,
      "e": 32781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32982,
      "e": 32782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33007,
      "e": 32807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ai"
    },
    {
      "t": 33077,
      "e": 32877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33142,
      "e": 32942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 33142,
      "e": 32942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33205,
      "e": 33005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 33206,
      "e": 33006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33206,
      "e": 33006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33293,
      "e": 33093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 33317,
      "e": 33117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33319,
      "e": 33119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33381,
      "e": 33181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33413,
      "e": 33213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33415,
      "e": 33215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33501,
      "e": 33301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33581,
      "e": 33381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 33582,
      "e": 33382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33693,
      "e": 33493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 33694,
      "e": 33494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33709,
      "e": 33509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 33805,
      "e": 33605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33861,
      "e": 33661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33862,
      "e": 33662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33957,
      "e": 33757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34285,
      "e": 34085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 34287,
      "e": 34087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34350,
      "e": 34150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 34446,
      "e": 34246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 34446,
      "e": 34246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34516,
      "e": 34316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 34525,
      "e": 34325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34525,
      "e": 34325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34621,
      "e": 34421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 34621,
      "e": 34421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34645,
      "e": 34445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 34718,
      "e": 34518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34742,
      "e": 34542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34742,
      "e": 34542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34796,
      "e": 34596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35276,
      "e": 35076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 35277,
      "e": 35077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35349,
      "e": 35149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 35349,
      "e": 35149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35381,
      "e": 35181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 35453,
      "e": 35253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36382,
      "e": 36182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 36382,
      "e": 36182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36493,
      "e": 36293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 36696,
      "e": 36296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 36698,
      "e": 36298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36749,
      "e": 36349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 36821,
      "e": 36421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36821,
      "e": 36421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36885,
      "e": 36485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37007,
      "e": 36607,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12pm "
    },
    {
      "t": 37566,
      "e": 37166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37621,
      "e": 37221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12pm"
    },
    {
      "t": 37717,
      "e": 37317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37741,
      "e": 37341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12p"
    },
    {
      "t": 37853,
      "e": 37453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37885,
      "e": 37485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12"
    },
    {
      "t": 38006,
      "e": 37606,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12"
    },
    {
      "t": 38102,
      "e": 37702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38102,
      "e": 37702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38181,
      "e": 37781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38245,
      "e": 37845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 38245,
      "e": 37845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38325,
      "e": 37925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 38453,
      "e": 38053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 38454,
      "e": 38054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38485,
      "e": 38085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 38607,
      "e": 38207,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12 pn"
    },
    {
      "t": 38965,
      "e": 38565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39012,
      "e": 38612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12 p"
    },
    {
      "t": 39350,
      "e": 38950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 39350,
      "e": 38950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39421,
      "e": 39021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 39461,
      "e": 39061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39461,
      "e": 39061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39533,
      "e": 39133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39557,
      "e": 39157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39558,
      "e": 39158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39637,
      "e": 39237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 39637,
      "e": 39237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39661,
      "e": 39261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 39724,
      "e": 39324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39748,
      "e": 39348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 39749,
      "e": 39349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39813,
      "e": 39413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 39845,
      "e": 39445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39846,
      "e": 39446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39924,
      "e": 39524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42302,
      "e": 41902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42303,
      "e": 41903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42357,
      "e": 41957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42388,
      "e": 41988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42389,
      "e": 41989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42460,
      "e": 42060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 42484,
      "e": 42084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42485,
      "e": 42085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42565,
      "e": 42165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 42589,
      "e": 42189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42591,
      "e": 42191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42660,
      "e": 42260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42798,
      "e": 42398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42798,
      "e": 42398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42877,
      "e": 42477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 42877,
      "e": 42477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42884,
      "e": 42484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 42948,
      "e": 42548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43134,
      "e": 42734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43173,
      "e": 42734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12 pm and the h"
    },
    {
      "t": 43261,
      "e": 42822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43308,
      "e": 42869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12 pm and the "
    },
    {
      "t": 43413,
      "e": 42974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 43413,
      "e": 42974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43493,
      "e": 43054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 43517,
      "e": 43078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 43518,
      "e": 43079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43588,
      "e": 43149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43588,
      "e": 43149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43612,
      "e": 43173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 43685,
      "e": 43246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43709,
      "e": 43270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 43709,
      "e": 43270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43757,
      "e": 43318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 43909,
      "e": 43470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43910,
      "e": 43471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43965,
      "e": 43526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44125,
      "e": 43686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 44125,
      "e": 43686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44213,
      "e": 43774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 44286,
      "e": 43847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44286,
      "e": 43847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44380,
      "e": 43941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45117,
      "e": 44678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45118,
      "e": 44679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45197,
      "e": 44758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45213,
      "e": 44774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 45213,
      "e": 44774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45284,
      "e": 44845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 45293,
      "e": 44854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45293,
      "e": 44854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45381,
      "e": 44942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45381,
      "e": 44942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45389,
      "e": 44950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 45454,
      "e": 45015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45501,
      "e": 45062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45502,
      "e": 45063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45572,
      "e": 45133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45669,
      "e": 45230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45669,
      "e": 45230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45805,
      "e": 45366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 45822,
      "e": 45383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 45823,
      "e": 45384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45933,
      "e": 45494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 45934,
      "e": 45495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45964,
      "e": 45525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 46012,
      "e": 45573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46036,
      "e": 45597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46037,
      "e": 45598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46109,
      "e": 45670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46125,
      "e": 45686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46126,
      "e": 45687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46180,
      "e": 45741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 46205,
      "e": 45766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 46206,
      "e": 45767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46276,
      "e": 45837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 46301,
      "e": 45862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 46301,
      "e": 45862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46373,
      "e": 45934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 46381,
      "e": 45942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46381,
      "e": 45942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46509,
      "e": 46070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 46510,
      "e": 46071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46541,
      "e": 46102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 46620,
      "e": 46181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46637,
      "e": 46198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46637,
      "e": 46198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46733,
      "e": 46294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46805,
      "e": 46366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 46806,
      "e": 46367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46884,
      "e": 46445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 47013,
      "e": 46574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47014,
      "e": 46575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47093,
      "e": 46654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47205,
      "e": 46766,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12 pm and the shifts that are there st"
    },
    {
      "t": 47228,
      "e": 46789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 47228,
      "e": 46789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47333,
      "e": 46894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 47333,
      "e": 46894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47357,
      "e": 46918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 47404,
      "e": 46965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47469,
      "e": 47030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47470,
      "e": 47031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47564,
      "e": 47125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47612,
      "e": 47173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47613,
      "e": 47174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47694,
      "e": 47255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 47694,
      "e": 47255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47716,
      "e": 47277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 47804,
      "e": 47365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47812,
      "e": 47373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47813,
      "e": 47374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47925,
      "e": 47486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47974,
      "e": 47535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47974,
      "e": 47535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48069,
      "e": 47630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48880,
      "e": 47631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 48882,
      "e": 47633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48948,
      "e": 47699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 48948,
      "e": 47699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48972,
      "e": 47723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 49044,
      "e": 47795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49158,
      "e": 47909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49158,
      "e": 47909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49212,
      "e": 47963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49260,
      "e": 48011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49260,
      "e": 48011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49341,
      "e": 48092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49413,
      "e": 48164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 49413,
      "e": 48164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49508,
      "e": 48259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 49844,
      "e": 48595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49908,
      "e": 48659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12 pm and the shifts that are there start at 12  "
    },
    {
      "t": 49996,
      "e": 48747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50044,
      "e": 48795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12 pm and the shifts that are there start at 12 "
    },
    {
      "t": 50749,
      "e": 49500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 50750,
      "e": 49501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50812,
      "e": 49563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 51037,
      "e": 49788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 51038,
      "e": 49789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51092,
      "e": 49843,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 51206,
      "e": 49957,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12 pm and the shifts that are there start at 12 pm"
    },
    {
      "t": 52255,
      "e": 51006,
      "ty": 41,
      "x": 23819,
      "y": 60521,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 52304,
      "e": 51055,
      "ty": 2,
      "x": 1092,
      "y": 1019
    },
    {
      "t": 52405,
      "e": 51156,
      "ty": 2,
      "x": 1069,
      "y": 1052
    },
    {
      "t": 52504,
      "e": 51255,
      "ty": 2,
      "x": 1025,
      "y": 1076
    },
    {
      "t": 52504,
      "e": 51255,
      "ty": 41,
      "x": 35023,
      "y": 59164,
      "ta": "> div.stimulus"
    },
    {
      "t": 52604,
      "e": 51355,
      "ty": 2,
      "x": 667,
      "y": 918
    },
    {
      "t": 52705,
      "e": 51456,
      "ty": 2,
      "x": 370,
      "y": 768
    },
    {
      "t": 52755,
      "e": 51506,
      "ty": 41,
      "x": 30002,
      "y": 40384,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 52805,
      "e": 51556,
      "ty": 2,
      "x": 355,
      "y": 703
    },
    {
      "t": 52865,
      "e": 51616,
      "ty": 6,
      "x": 355,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 52904,
      "e": 51655,
      "ty": 2,
      "x": 362,
      "y": 684
    },
    {
      "t": 53005,
      "e": 51756,
      "ty": 2,
      "x": 384,
      "y": 677
    },
    {
      "t": 53005,
      "e": 51756,
      "ty": 41,
      "x": 24797,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 53104,
      "e": 51855,
      "ty": 2,
      "x": 392,
      "y": 670
    },
    {
      "t": 53204,
      "e": 51955,
      "ty": 2,
      "x": 397,
      "y": 663
    },
    {
      "t": 53255,
      "e": 52006,
      "ty": 41,
      "x": 32443,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 53304,
      "e": 52055,
      "ty": 2,
      "x": 398,
      "y": 660
    },
    {
      "t": 55779,
      "e": 54530,
      "ty": 3,
      "x": 398,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 55780,
      "e": 54531,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x axis of the graph, look where 12 pm is. Go straight up from 12 pm and the shifts that are there start at 12 pm"
    },
    {
      "t": 55782,
      "e": 54533,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55783,
      "e": 54534,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 55953,
      "e": 54704,
      "ty": 4,
      "x": 32443,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 55967,
      "e": 54718,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 55968,
      "e": 54719,
      "ty": 5,
      "x": 398,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 55974,
      "e": 54725,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 56978,
      "e": 55729,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 57304,
      "e": 56055,
      "ty": 2,
      "x": 408,
      "y": 673
    },
    {
      "t": 57405,
      "e": 56156,
      "ty": 2,
      "x": 497,
      "y": 747
    },
    {
      "t": 57505,
      "e": 56256,
      "ty": 2,
      "x": 526,
      "y": 773
    },
    {
      "t": 57505,
      "e": 56256,
      "ty": 41,
      "x": 17838,
      "y": 42378,
      "ta": "html > body"
    },
    {
      "t": 57805,
      "e": 56556,
      "ty": 2,
      "x": 529,
      "y": 773
    },
    {
      "t": 57904,
      "e": 56655,
      "ty": 2,
      "x": 722,
      "y": 695
    },
    {
      "t": 57969,
      "e": 56720,
      "ty": 6,
      "x": 820,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58001,
      "e": 56752,
      "ty": 7,
      "x": 833,
      "y": 636,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58003,
      "e": 56754,
      "ty": 2,
      "x": 833,
      "y": 636
    },
    {
      "t": 58003,
      "e": 56754,
      "ty": 41,
      "x": 5407,
      "y": 37347,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 58105,
      "e": 56856,
      "ty": 2,
      "x": 862,
      "y": 612
    },
    {
      "t": 58205,
      "e": 56956,
      "ty": 2,
      "x": 884,
      "y": 579
    },
    {
      "t": 58220,
      "e": 56957,
      "ty": 6,
      "x": 886,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58255,
      "e": 56992,
      "ty": 41,
      "x": 18168,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58302,
      "e": 57039,
      "ty": 7,
      "x": 898,
      "y": 552,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58304,
      "e": 57041,
      "ty": 2,
      "x": 898,
      "y": 552
    },
    {
      "t": 58405,
      "e": 57142,
      "ty": 2,
      "x": 899,
      "y": 549
    },
    {
      "t": 58409,
      "e": 57146,
      "ty": 3,
      "x": 899,
      "y": 549,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 58473,
      "e": 57210,
      "ty": 6,
      "x": 902,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58504,
      "e": 57241,
      "ty": 2,
      "x": 902,
      "y": 567
    },
    {
      "t": 58505,
      "e": 57242,
      "ty": 4,
      "x": 20330,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58505,
      "e": 57242,
      "ty": 41,
      "x": 20330,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58605,
      "e": 57342,
      "ty": 2,
      "x": 902,
      "y": 569
    },
    {
      "t": 58658,
      "e": 57395,
      "ty": 3,
      "x": 902,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58659,
      "e": 57396,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58744,
      "e": 57481,
      "ty": 4,
      "x": 20330,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58744,
      "e": 57481,
      "ty": 5,
      "x": 902,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58754,
      "e": 57491,
      "ty": 41,
      "x": 20330,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59581,
      "e": 58318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 59582,
      "e": 58319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59644,
      "e": 58381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 59685,
      "e": 58422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 59685,
      "e": 58422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59788,
      "e": 58525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 60403,
      "e": 59140,
      "ty": 2,
      "x": 902,
      "y": 574
    },
    {
      "t": 60409,
      "e": 59146,
      "ty": 7,
      "x": 903,
      "y": 581,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60503,
      "e": 59240,
      "ty": 6,
      "x": 931,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60504,
      "e": 59241,
      "ty": 2,
      "x": 931,
      "y": 648
    },
    {
      "t": 60504,
      "e": 59241,
      "ty": 41,
      "x": 26603,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60554,
      "e": 59291,
      "ty": 7,
      "x": 937,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60571,
      "e": 59308,
      "ty": 6,
      "x": 938,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60603,
      "e": 59340,
      "ty": 2,
      "x": 940,
      "y": 680
    },
    {
      "t": 60754,
      "e": 59491,
      "ty": 41,
      "x": 22717,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60803,
      "e": 59540,
      "ty": 7,
      "x": 944,
      "y": 673,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60808,
      "e": 59545,
      "ty": 2,
      "x": 944,
      "y": 673
    },
    {
      "t": 60820,
      "e": 59557,
      "ty": 6,
      "x": 945,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60904,
      "e": 59641,
      "ty": 2,
      "x": 947,
      "y": 659
    },
    {
      "t": 61004,
      "e": 59741,
      "ty": 41,
      "x": 30063,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61057,
      "e": 59794,
      "ty": 3,
      "x": 947,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61058,
      "e": 59795,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 61058,
      "e": 59795,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61060,
      "e": 59797,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61120,
      "e": 59857,
      "ty": 4,
      "x": 30063,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61120,
      "e": 59857,
      "ty": 5,
      "x": 947,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61904,
      "e": 60641,
      "ty": 2,
      "x": 1030,
      "y": 658
    },
    {
      "t": 62004,
      "e": 60741,
      "ty": 2,
      "x": 1083,
      "y": 662
    },
    {
      "t": 62004,
      "e": 60741,
      "ty": 41,
      "x": 59478,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62103,
      "e": 60840,
      "ty": 7,
      "x": 1113,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62105,
      "e": 60842,
      "ty": 2,
      "x": 1113,
      "y": 668
    },
    {
      "t": 62204,
      "e": 60941,
      "ty": 2,
      "x": 1119,
      "y": 668
    },
    {
      "t": 62254,
      "e": 60991,
      "ty": 41,
      "x": 38260,
      "y": 36562,
      "ta": "html > body"
    },
    {
      "t": 62504,
      "e": 61241,
      "ty": 2,
      "x": 1117,
      "y": 668
    },
    {
      "t": 62505,
      "e": 61242,
      "ty": 41,
      "x": 38191,
      "y": 36562,
      "ta": "html > body"
    },
    {
      "t": 62589,
      "e": 61326,
      "ty": 6,
      "x": 1106,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62604,
      "e": 61341,
      "ty": 2,
      "x": 1106,
      "y": 667
    },
    {
      "t": 62754,
      "e": 61491,
      "ty": 41,
      "x": 64453,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62881,
      "e": 61618,
      "ty": 3,
      "x": 1106,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62984,
      "e": 61721,
      "ty": 4,
      "x": 64453,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62985,
      "e": 61722,
      "ty": 5,
      "x": 1106,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63204,
      "e": 61941,
      "ty": 2,
      "x": 1105,
      "y": 654
    },
    {
      "t": 63254,
      "e": 61991,
      "ty": 41,
      "x": 64237,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63288,
      "e": 62025,
      "ty": 3,
      "x": 1105,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63304,
      "e": 62041,
      "ty": 2,
      "x": 1105,
      "y": 651
    },
    {
      "t": 63392,
      "e": 62129,
      "ty": 4,
      "x": 64237,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63393,
      "e": 62130,
      "ty": 5,
      "x": 1105,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64373,
      "e": 63110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 64437,
      "e": 63174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 64469,
      "e": 63206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 64597,
      "e": 63334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 64597,
      "e": 63334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64700,
      "e": 63437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 64708,
      "e": 63445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 64708,
      "e": 63445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64853,
      "e": 63590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 64853,
      "e": 63590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64876,
      "e": 63613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 65005,
      "e": 63742,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 65045,
      "e": 63782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 65381,
      "e": 64118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 65541,
      "e": 64278,
      "ty": 7,
      "x": 1102,
      "y": 646,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65604,
      "e": 64341,
      "ty": 2,
      "x": 1091,
      "y": 639
    },
    {
      "t": 65754,
      "e": 64491,
      "ty": 41,
      "x": 61209,
      "y": 39461,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 65804,
      "e": 64541,
      "ty": 2,
      "x": 1085,
      "y": 645
    },
    {
      "t": 65808,
      "e": 64545,
      "ty": 6,
      "x": 1077,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65874,
      "e": 64611,
      "ty": 7,
      "x": 1027,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65903,
      "e": 64640,
      "ty": 2,
      "x": 1021,
      "y": 674
    },
    {
      "t": 65907,
      "e": 64644,
      "ty": 6,
      "x": 1014,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66003,
      "e": 64740,
      "ty": 2,
      "x": 988,
      "y": 689
    },
    {
      "t": 66004,
      "e": 64741,
      "ty": 41,
      "x": 47456,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66104,
      "e": 64841,
      "ty": 2,
      "x": 978,
      "y": 695
    },
    {
      "t": 66147,
      "e": 64884,
      "ty": 3,
      "x": 978,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66147,
      "e": 64884,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 66148,
      "e": 64885,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66148,
      "e": 64885,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66209,
      "e": 64946,
      "ty": 4,
      "x": 42302,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66210,
      "e": 64947,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66211,
      "e": 64948,
      "ty": 5,
      "x": 978,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66211,
      "e": 64948,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 66254,
      "e": 64991,
      "ty": 41,
      "x": 33404,
      "y": 38057,
      "ta": "html > body"
    },
    {
      "t": 67234,
      "e": 65971,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 67904,
      "e": 66641,
      "ty": 2,
      "x": 978,
      "y": 679
    },
    {
      "t": 68005,
      "e": 66742,
      "ty": 2,
      "x": 978,
      "y": 522
    },
    {
      "t": 68005,
      "e": 66742,
      "ty": 41,
      "x": 37159,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 68104,
      "e": 66841,
      "ty": 2,
      "x": 978,
      "y": 394
    },
    {
      "t": 68204,
      "e": 66941,
      "ty": 2,
      "x": 975,
      "y": 326
    },
    {
      "t": 68255,
      "e": 66992,
      "ty": 41,
      "x": 35023,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 68304,
      "e": 67041,
      "ty": 2,
      "x": 961,
      "y": 290
    },
    {
      "t": 68404,
      "e": 67141,
      "ty": 2,
      "x": 931,
      "y": 279
    },
    {
      "t": 68504,
      "e": 67241,
      "ty": 2,
      "x": 854,
      "y": 258
    },
    {
      "t": 68504,
      "e": 67241,
      "ty": 41,
      "x": 24812,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 68605,
      "e": 67342,
      "ty": 2,
      "x": 815,
      "y": 244
    },
    {
      "t": 68754,
      "e": 67491,
      "ty": 41,
      "x": 27894,
      "y": 13073,
      "ta": "html > body"
    },
    {
      "t": 68804,
      "e": 67541,
      "ty": 2,
      "x": 824,
      "y": 243
    },
    {
      "t": 68939,
      "e": 67542,
      "ty": 6,
      "x": 826,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69004,
      "e": 67607,
      "ty": 2,
      "x": 829,
      "y": 239
    },
    {
      "t": 69005,
      "e": 67608,
      "ty": 41,
      "x": 12996,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69104,
      "e": 67707,
      "ty": 2,
      "x": 831,
      "y": 237
    },
    {
      "t": 69204,
      "e": 67807,
      "ty": 2,
      "x": 832,
      "y": 234
    },
    {
      "t": 69254,
      "e": 67857,
      "ty": 41,
      "x": 33161,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69305,
      "e": 67908,
      "ty": 2,
      "x": 834,
      "y": 233
    },
    {
      "t": 69330,
      "e": 67933,
      "ty": 3,
      "x": 834,
      "y": 233,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69330,
      "e": 67933,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69392,
      "e": 67995,
      "ty": 4,
      "x": 38202,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69392,
      "e": 67995,
      "ty": 5,
      "x": 834,
      "y": 233,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69392,
      "e": 67995,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 69504,
      "e": 68107,
      "ty": 41,
      "x": 38202,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69704,
      "e": 68307,
      "ty": 2,
      "x": 834,
      "y": 238
    },
    {
      "t": 69755,
      "e": 68358,
      "ty": 41,
      "x": 38202,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69762,
      "e": 68365,
      "ty": 7,
      "x": 834,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69804,
      "e": 68407,
      "ty": 2,
      "x": 832,
      "y": 255
    },
    {
      "t": 69811,
      "e": 68414,
      "ty": 6,
      "x": 832,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 69878,
      "e": 68481,
      "ty": 7,
      "x": 829,
      "y": 277,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 69905,
      "e": 68508,
      "ty": 2,
      "x": 829,
      "y": 281
    },
    {
      "t": 69927,
      "e": 68530,
      "ty": 6,
      "x": 829,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 69961,
      "e": 68564,
      "ty": 7,
      "x": 831,
      "y": 304,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 70004,
      "e": 68607,
      "ty": 2,
      "x": 832,
      "y": 313
    },
    {
      "t": 70004,
      "e": 68607,
      "ty": 41,
      "x": 10501,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 70010,
      "e": 68613,
      "ty": 6,
      "x": 832,
      "y": 319,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 70044,
      "e": 68647,
      "ty": 7,
      "x": 835,
      "y": 333,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 70104,
      "e": 68707,
      "ty": 2,
      "x": 839,
      "y": 357
    },
    {
      "t": 70204,
      "e": 68807,
      "ty": 2,
      "x": 842,
      "y": 389
    },
    {
      "t": 70254,
      "e": 68857,
      "ty": 41,
      "x": 28771,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 70304,
      "e": 68907,
      "ty": 2,
      "x": 846,
      "y": 416
    },
    {
      "t": 70404,
      "e": 69007,
      "ty": 2,
      "x": 846,
      "y": 425
    },
    {
      "t": 70504,
      "e": 69107,
      "ty": 41,
      "x": 5832,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 70804,
      "e": 69407,
      "ty": 2,
      "x": 840,
      "y": 423
    },
    {
      "t": 70900,
      "e": 69503,
      "ty": 6,
      "x": 833,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 70907,
      "e": 69510,
      "ty": 2,
      "x": 833,
      "y": 420
    },
    {
      "t": 71007,
      "e": 69610,
      "ty": 2,
      "x": 828,
      "y": 414
    },
    {
      "t": 71007,
      "e": 69610,
      "ty": 41,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 71075,
      "e": 69678,
      "ty": 7,
      "x": 825,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 71107,
      "e": 69710,
      "ty": 2,
      "x": 825,
      "y": 410
    },
    {
      "t": 71187,
      "e": 69790,
      "ty": 3,
      "x": 825,
      "y": 410,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 71187,
      "e": 69790,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71258,
      "e": 69861,
      "ty": 41,
      "x": 4188,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 71283,
      "e": 69886,
      "ty": 4,
      "x": 4188,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 71284,
      "e": 69887,
      "ty": 5,
      "x": 825,
      "y": 410,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 71284,
      "e": 69887,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 71284,
      "e": 69887,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 71807,
      "e": 70410,
      "ty": 2,
      "x": 825,
      "y": 413
    },
    {
      "t": 71849,
      "e": 70410,
      "ty": 6,
      "x": 829,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 71882,
      "e": 70443,
      "ty": 7,
      "x": 837,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 71907,
      "e": 70468,
      "ty": 2,
      "x": 843,
      "y": 455
    },
    {
      "t": 72008,
      "e": 70569,
      "ty": 2,
      "x": 859,
      "y": 477
    },
    {
      "t": 72008,
      "e": 70569,
      "ty": 41,
      "x": 39720,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 72108,
      "e": 70669,
      "ty": 2,
      "x": 877,
      "y": 501
    },
    {
      "t": 72207,
      "e": 70768,
      "ty": 2,
      "x": 930,
      "y": 545
    },
    {
      "t": 72258,
      "e": 70819,
      "ty": 41,
      "x": 35973,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 72308,
      "e": 70869,
      "ty": 2,
      "x": 1009,
      "y": 621
    },
    {
      "t": 72408,
      "e": 70969,
      "ty": 2,
      "x": 1017,
      "y": 655
    },
    {
      "t": 72507,
      "e": 71068,
      "ty": 2,
      "x": 983,
      "y": 689
    },
    {
      "t": 72507,
      "e": 71068,
      "ty": 41,
      "x": 38346,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 72608,
      "e": 71169,
      "ty": 2,
      "x": 964,
      "y": 694
    },
    {
      "t": 72707,
      "e": 71268,
      "ty": 2,
      "x": 940,
      "y": 693
    },
    {
      "t": 72758,
      "e": 71319,
      "ty": 41,
      "x": 26005,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 72807,
      "e": 71368,
      "ty": 2,
      "x": 906,
      "y": 684
    },
    {
      "t": 72908,
      "e": 71469,
      "ty": 2,
      "x": 875,
      "y": 678
    },
    {
      "t": 73007,
      "e": 71568,
      "ty": 2,
      "x": 873,
      "y": 678
    },
    {
      "t": 73008,
      "e": 71569,
      "ty": 41,
      "x": 13848,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 73107,
      "e": 71668,
      "ty": 2,
      "x": 859,
      "y": 674
    },
    {
      "t": 73208,
      "e": 71769,
      "ty": 2,
      "x": 854,
      "y": 672
    },
    {
      "t": 73258,
      "e": 71819,
      "ty": 41,
      "x": 8210,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 73307,
      "e": 71868,
      "ty": 2,
      "x": 852,
      "y": 672
    },
    {
      "t": 73407,
      "e": 71968,
      "ty": 2,
      "x": 852,
      "y": 671
    },
    {
      "t": 73507,
      "e": 72068,
      "ty": 2,
      "x": 851,
      "y": 669
    },
    {
      "t": 73507,
      "e": 72068,
      "ty": 41,
      "x": 7941,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 73758,
      "e": 72319,
      "ty": 41,
      "x": 7404,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 73807,
      "e": 72368,
      "ty": 2,
      "x": 847,
      "y": 675
    },
    {
      "t": 73907,
      "e": 72468,
      "ty": 2,
      "x": 847,
      "y": 681
    },
    {
      "t": 74008,
      "e": 72569,
      "ty": 2,
      "x": 844,
      "y": 695
    },
    {
      "t": 74008,
      "e": 72569,
      "ty": 41,
      "x": 5689,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74107,
      "e": 72668,
      "ty": 2,
      "x": 843,
      "y": 706
    },
    {
      "t": 74207,
      "e": 72768,
      "ty": 2,
      "x": 840,
      "y": 718
    },
    {
      "t": 74251,
      "e": 72812,
      "ty": 6,
      "x": 839,
      "y": 724,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 74258,
      "e": 72819,
      "ty": 41,
      "x": 63408,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 74307,
      "e": 72868,
      "ty": 2,
      "x": 837,
      "y": 728
    },
    {
      "t": 74408,
      "e": 72969,
      "ty": 2,
      "x": 835,
      "y": 733
    },
    {
      "t": 74508,
      "e": 73069,
      "ty": 41,
      "x": 43243,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 74608,
      "e": 73169,
      "ty": 2,
      "x": 835,
      "y": 734
    },
    {
      "t": 74807,
      "e": 73368,
      "ty": 2,
      "x": 835,
      "y": 731
    },
    {
      "t": 74907,
      "e": 73468,
      "ty": 3,
      "x": 835,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 74907,
      "e": 73468,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 74908,
      "e": 73469,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 74995,
      "e": 73556,
      "ty": 4,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 74996,
      "e": 73557,
      "ty": 5,
      "x": 835,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 74996,
      "e": 73557,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 75007,
      "e": 73568,
      "ty": 41,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 75258,
      "e": 73819,
      "ty": 41,
      "x": 43243,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 75268,
      "e": 73829,
      "ty": 7,
      "x": 837,
      "y": 740,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 75307,
      "e": 73868,
      "ty": 2,
      "x": 842,
      "y": 753
    },
    {
      "t": 75408,
      "e": 73969,
      "ty": 2,
      "x": 871,
      "y": 821
    },
    {
      "t": 75508,
      "e": 74069,
      "ty": 2,
      "x": 888,
      "y": 867
    },
    {
      "t": 75508,
      "e": 74069,
      "ty": 41,
      "x": 15800,
      "y": 52756,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 76307,
      "e": 74868,
      "ty": 2,
      "x": 886,
      "y": 862
    },
    {
      "t": 76408,
      "e": 74969,
      "ty": 2,
      "x": 876,
      "y": 838
    },
    {
      "t": 76507,
      "e": 75068,
      "ty": 2,
      "x": 863,
      "y": 814
    },
    {
      "t": 76507,
      "e": 75068,
      "ty": 41,
      "x": 24541,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 76608,
      "e": 75068,
      "ty": 2,
      "x": 857,
      "y": 795
    },
    {
      "t": 76708,
      "e": 75168,
      "ty": 2,
      "x": 853,
      "y": 778
    },
    {
      "t": 76758,
      "e": 75218,
      "ty": 41,
      "x": 7256,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 76808,
      "e": 75268,
      "ty": 2,
      "x": 846,
      "y": 763
    },
    {
      "t": 76907,
      "e": 75367,
      "ty": 2,
      "x": 842,
      "y": 759
    },
    {
      "t": 77008,
      "e": 75468,
      "ty": 2,
      "x": 840,
      "y": 759
    },
    {
      "t": 77008,
      "e": 75468,
      "ty": 41,
      "x": 7751,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 77028,
      "e": 75488,
      "ty": 6,
      "x": 839,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 77108,
      "e": 75568,
      "ty": 2,
      "x": 835,
      "y": 760
    },
    {
      "t": 77208,
      "e": 75668,
      "ty": 2,
      "x": 828,
      "y": 763
    },
    {
      "t": 77258,
      "e": 75718,
      "ty": 41,
      "x": 7955,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 77308,
      "e": 75768,
      "ty": 2,
      "x": 827,
      "y": 763
    },
    {
      "t": 77408,
      "e": 75868,
      "ty": 2,
      "x": 827,
      "y": 761
    },
    {
      "t": 77508,
      "e": 75968,
      "ty": 2,
      "x": 827,
      "y": 760
    },
    {
      "t": 77508,
      "e": 75968,
      "ty": 41,
      "x": 2914,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 77653,
      "e": 76113,
      "ty": 7,
      "x": 827,
      "y": 765,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 77708,
      "e": 76168,
      "ty": 2,
      "x": 829,
      "y": 777
    },
    {
      "t": 77720,
      "e": 76180,
      "ty": 6,
      "x": 829,
      "y": 784,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 77737,
      "e": 76197,
      "ty": 7,
      "x": 829,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 77758,
      "e": 76218,
      "ty": 41,
      "x": 1798,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 77770,
      "e": 76230,
      "ty": 6,
      "x": 829,
      "y": 812,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 77791,
      "e": 76251,
      "ty": 7,
      "x": 831,
      "y": 836,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 77791,
      "e": 76251,
      "ty": 6,
      "x": 831,
      "y": 836,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 77803,
      "e": 76263,
      "ty": 7,
      "x": 834,
      "y": 851,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 77808,
      "e": 76268,
      "ty": 2,
      "x": 834,
      "y": 851
    },
    {
      "t": 77907,
      "e": 76367,
      "ty": 2,
      "x": 843,
      "y": 899
    },
    {
      "t": 78007,
      "e": 76467,
      "ty": 2,
      "x": 843,
      "y": 924
    },
    {
      "t": 78008,
      "e": 76468,
      "ty": 41,
      "x": 5121,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 78107,
      "e": 76567,
      "ty": 2,
      "x": 840,
      "y": 930
    },
    {
      "t": 78131,
      "e": 76591,
      "ty": 6,
      "x": 839,
      "y": 930,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78208,
      "e": 76668,
      "ty": 2,
      "x": 836,
      "y": 932
    },
    {
      "t": 78258,
      "e": 76718,
      "ty": 41,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78307,
      "e": 76767,
      "ty": 2,
      "x": 829,
      "y": 937
    },
    {
      "t": 78508,
      "e": 76968,
      "ty": 3,
      "x": 829,
      "y": 937,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78509,
      "e": 76969,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 78509,
      "e": 76969,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78510,
      "e": 76970,
      "ty": 41,
      "x": 12996,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78595,
      "e": 77055,
      "ty": 4,
      "x": 12996,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78596,
      "e": 77056,
      "ty": 5,
      "x": 829,
      "y": 937,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78597,
      "e": 77057,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 78684,
      "e": 77144,
      "ty": 7,
      "x": 831,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78708,
      "e": 77168,
      "ty": 2,
      "x": 847,
      "y": 961
    },
    {
      "t": 78757,
      "e": 77217,
      "ty": 41,
      "x": 18411,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 78772,
      "e": 77217,
      "ty": 6,
      "x": 901,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78808,
      "e": 77253,
      "ty": 2,
      "x": 902,
      "y": 1007
    },
    {
      "t": 78908,
      "e": 77353,
      "ty": 2,
      "x": 902,
      "y": 1009
    },
    {
      "t": 78995,
      "e": 77440,
      "ty": 3,
      "x": 902,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78996,
      "e": 77441,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78997,
      "e": 77442,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 79008,
      "e": 77453,
      "ty": 41,
      "x": 37406,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 79075,
      "e": 77520,
      "ty": 4,
      "x": 37406,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 79075,
      "e": 77520,
      "ty": 5,
      "x": 902,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 79077,
      "e": 77522,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 79078,
      "e": 77523,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 79079,
      "e": 77524,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 79507,
      "e": 77952,
      "ty": 2,
      "x": 902,
      "y": 994
    },
    {
      "t": 79507,
      "e": 77952,
      "ty": 41,
      "x": 30787,
      "y": 54621,
      "ta": "html > body"
    },
    {
      "t": 79607,
      "e": 78052,
      "ty": 2,
      "x": 879,
      "y": 925
    },
    {
      "t": 79707,
      "e": 78152,
      "ty": 2,
      "x": 819,
      "y": 836
    },
    {
      "t": 79758,
      "e": 78203,
      "ty": 41,
      "x": 26654,
      "y": 43376,
      "ta": "html > body"
    },
    {
      "t": 79808,
      "e": 78253,
      "ty": 2,
      "x": 753,
      "y": 746
    },
    {
      "t": 79907,
      "e": 78352,
      "ty": 2,
      "x": 669,
      "y": 659
    },
    {
      "t": 80008,
      "e": 78453,
      "ty": 2,
      "x": 644,
      "y": 616
    },
    {
      "t": 80008,
      "e": 78453,
      "ty": 41,
      "x": 21902,
      "y": 33681,
      "ta": "html > body"
    },
    {
      "t": 80107,
      "e": 78552,
      "ty": 2,
      "x": 636,
      "y": 584
    },
    {
      "t": 80208,
      "e": 78653,
      "ty": 2,
      "x": 632,
      "y": 571
    },
    {
      "t": 80258,
      "e": 78703,
      "ty": 41,
      "x": 21489,
      "y": 31022,
      "ta": "html > body"
    },
    {
      "t": 80307,
      "e": 78752,
      "ty": 2,
      "x": 632,
      "y": 567
    },
    {
      "t": 80395,
      "e": 78840,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 80407,
      "e": 78852,
      "ty": 2,
      "x": 629,
      "y": 563
    },
    {
      "t": 80508,
      "e": 78953,
      "ty": 2,
      "x": 624,
      "y": 561
    },
    {
      "t": 80508,
      "e": 78953,
      "ty": 41,
      "x": 16261,
      "y": 30628,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 80908,
      "e": 79353,
      "ty": 2,
      "x": 623,
      "y": 561
    },
    {
      "t": 81008,
      "e": 79453,
      "ty": 2,
      "x": 618,
      "y": 561
    },
    {
      "t": 81008,
      "e": 79453,
      "ty": 41,
      "x": 15966,
      "y": 30628,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85008,
      "e": 83453,
      "ty": 2,
      "x": 617,
      "y": 560
    },
    {
      "t": 85009,
      "e": 83454,
      "ty": 41,
      "x": 15917,
      "y": 30238,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85308,
      "e": 83753,
      "ty": 2,
      "x": 623,
      "y": 554
    },
    {
      "t": 85407,
      "e": 83852,
      "ty": 2,
      "x": 625,
      "y": 553
    },
    {
      "t": 85509,
      "e": 83954,
      "ty": 41,
      "x": 16311,
      "y": 27507,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85907,
      "e": 84352,
      "ty": 2,
      "x": 628,
      "y": 551
    },
    {
      "t": 86008,
      "e": 84453,
      "ty": 2,
      "x": 629,
      "y": 551
    },
    {
      "t": 86008,
      "e": 84453,
      "ty": 41,
      "x": 16507,
      "y": 26727,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 86109,
      "e": 84554,
      "ty": 2,
      "x": 630,
      "y": 551
    },
    {
      "t": 86207,
      "e": 84652,
      "ty": 2,
      "x": 631,
      "y": 551
    },
    {
      "t": 86257,
      "e": 84702,
      "ty": 41,
      "x": 16606,
      "y": 26727,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 86708,
      "e": 85153,
      "ty": 2,
      "x": 620,
      "y": 550
    },
    {
      "t": 86758,
      "e": 85203,
      "ty": 41,
      "x": 15769,
      "y": 26337,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 86807,
      "e": 85252,
      "ty": 2,
      "x": 612,
      "y": 550
    },
    {
      "t": 86907,
      "e": 85352,
      "ty": 2,
      "x": 611,
      "y": 550
    },
    {
      "t": 87008,
      "e": 85453,
      "ty": 41,
      "x": 15622,
      "y": 26337,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 90007,
      "e": 88452,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90807,
      "e": 89252,
      "ty": 2,
      "x": 607,
      "y": 550
    },
    {
      "t": 90907,
      "e": 89352,
      "ty": 2,
      "x": 553,
      "y": 559
    },
    {
      "t": 91007,
      "e": 89452,
      "ty": 2,
      "x": 493,
      "y": 580
    },
    {
      "t": 91007,
      "e": 89452,
      "ty": 41,
      "x": 9817,
      "y": 38039,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 91107,
      "e": 89552,
      "ty": 2,
      "x": 483,
      "y": 584
    },
    {
      "t": 91257,
      "e": 89702,
      "ty": 41,
      "x": 9325,
      "y": 39600,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 91407,
      "e": 89852,
      "ty": 2,
      "x": 523,
      "y": 584
    },
    {
      "t": 91508,
      "e": 89953,
      "ty": 2,
      "x": 583,
      "y": 584
    },
    {
      "t": 91508,
      "e": 89953,
      "ty": 41,
      "x": 14244,
      "y": 39600,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 91607,
      "e": 90052,
      "ty": 2,
      "x": 631,
      "y": 583
    },
    {
      "t": 91707,
      "e": 90152,
      "ty": 2,
      "x": 682,
      "y": 597
    },
    {
      "t": 91758,
      "e": 90203,
      "ty": 41,
      "x": 19213,
      "y": 45061,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 91807,
      "e": 90252,
      "ty": 2,
      "x": 685,
      "y": 599
    },
    {
      "t": 91908,
      "e": 90353,
      "ty": 2,
      "x": 690,
      "y": 603
    },
    {
      "t": 92008,
      "e": 90453,
      "ty": 2,
      "x": 708,
      "y": 621
    },
    {
      "t": 92008,
      "e": 90453,
      "ty": 41,
      "x": 20394,
      "y": 54033,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 92107,
      "e": 90552,
      "ty": 2,
      "x": 778,
      "y": 779
    },
    {
      "t": 92207,
      "e": 90652,
      "ty": 2,
      "x": 830,
      "y": 863
    },
    {
      "t": 92258,
      "e": 90703,
      "ty": 41,
      "x": 27134,
      "y": 5887,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 92308,
      "e": 90753,
      "ty": 2,
      "x": 857,
      "y": 896
    },
    {
      "t": 92408,
      "e": 90853,
      "ty": 2,
      "x": 870,
      "y": 931
    },
    {
      "t": 92507,
      "e": 90952,
      "ty": 2,
      "x": 880,
      "y": 954
    },
    {
      "t": 92508,
      "e": 90953,
      "ty": 41,
      "x": 28856,
      "y": 57316,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92608,
      "e": 91053,
      "ty": 2,
      "x": 910,
      "y": 993
    },
    {
      "t": 92707,
      "e": 91152,
      "ty": 2,
      "x": 957,
      "y": 1024
    },
    {
      "t": 92758,
      "e": 91203,
      "ty": 41,
      "x": 33530,
      "y": 63825,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92808,
      "e": 91253,
      "ty": 2,
      "x": 985,
      "y": 1059
    },
    {
      "t": 92849,
      "e": 91294,
      "ty": 6,
      "x": 999,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 92907,
      "e": 91352,
      "ty": 2,
      "x": 1001,
      "y": 1074
    },
    {
      "t": 93008,
      "e": 91453,
      "ty": 2,
      "x": 1001,
      "y": 1076
    },
    {
      "t": 93008,
      "e": 91453,
      "ty": 41,
      "x": 49970,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 93107,
      "e": 91552,
      "ty": 2,
      "x": 986,
      "y": 1080
    },
    {
      "t": 93207,
      "e": 91652,
      "ty": 2,
      "x": 980,
      "y": 1082
    },
    {
      "t": 93258,
      "e": 91703,
      "ty": 41,
      "x": 36863,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 93308,
      "e": 91753,
      "ty": 2,
      "x": 975,
      "y": 1085
    },
    {
      "t": 93508,
      "e": 91953,
      "ty": 41,
      "x": 35771,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 95525,
      "e": 93970,
      "ty": 3,
      "x": 975,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 95526,
      "e": 93971,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 95619,
      "e": 94064,
      "ty": 4,
      "x": 35771,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 95620,
      "e": 94065,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 95620,
      "e": 94065,
      "ty": 5,
      "x": 975,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 95620,
      "e": 94065,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 96658,
      "e": 95103,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 97474,
      "e": 95919,
      "ty": 2,
      "x": 962,
      "y": 1084
    },
    {
      "t": 97474,
      "e": 95919,
      "ty": 41,
      "x": 32891,
      "y": 32875,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 97608,
      "e": 96053,
      "ty": 2,
      "x": 961,
      "y": 1082
    },
    {
      "t": 97707,
      "e": 96152,
      "ty": 2,
      "x": 960,
      "y": 1081
    },
    {
      "t": 97758,
      "e": 96203,
      "ty": 41,
      "x": 32792,
      "y": 32874,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 98008,
      "e": 96453,
      "ty": 2,
      "x": 956,
      "y": 1078
    },
    {
      "t": 98008,
      "e": 96453,
      "ty": 41,
      "x": 32594,
      "y": 32873,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 98094,
      "e": 96539,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":5}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"id\":2593},{\"nodeType\":3,\"id\":2597,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2594},{\"id\":2595},{\"nodeType\":3,\"id\":2598,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2596}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2601},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2604,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2603},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2605,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2603}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":2601}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2606}},{\"nodeType\":3,\"id\":2609,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2602}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2599},{\"id\":2600},{\"id\":2603},{\"id\":2605},{\"id\":2604},{\"id\":2601},{\"id\":2606},{\"id\":2608},{\"id\":2607},{\"id\":2602},{\"id\":2609}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2610,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2615},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2622,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2624}},{\"nodeType\":3,\"id\":2626,\"textContent\":\"English\",\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2628},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2630}},{\"nodeType\":3,\"id\":2632,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2631},\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2633}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2634},\"parentNode\":{\"id\":2633}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"*\",\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2643},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2645,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":3,\"id\":2649,\"textContent\":\"First\",\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2651},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2653}},{\"nodeType\":3,\"id\":2655,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2654},\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2656}},{\"nodeType\":3,\"id\":2658,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2657},\"parentNode\":{\"id\":2656}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2659}},{\"nodeType\":3,\"id\":2661,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2660},\"parentNode\":{\"id\":2659}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2662}},{\"nodeType\":3,\"id\":2664,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2663},\"parentNode\":{\"id\":2662}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2665}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2666},\"parentNode\":{\"id\":2665}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"*\",\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2675},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2677,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":3,\"id\":2681,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2683},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2685}},{\"nodeType\":3,\"id\":2687,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2686},\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2688}},{\"nodeType\":3,\"id\":2690,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2689},\"parentNode\":{\"id\":2688}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2691}},{\"nodeType\":3,\"id\":2693,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2692},\"parentNode\":{\"id\":2691}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2694}},{\"nodeType\":3,\"id\":2696,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2695},\"parentNode\":{\"id\":2694}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2697}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2698},\"parentNode\":{\"id\":2697}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"*\",\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2703},\"parentNode\":{\"id\":2615}},{\"nodeType\":3,\"id\":2705,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2707}},{\"nodeType\":3,\"id\":2709,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2707}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2711},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2714},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"*\",\"parentNode\":{\"id\":2706}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2610},{\"id\":2611},{\"id\":2612},{\"id\":2617},{\"id\":2622},{\"id\":2623},{\"id\":2636},{\"id\":2618},{\"id\":2624},{\"id\":2625},{\"id\":2626},{\"id\":2619},{\"id\":2627},{\"id\":2628},{\"id\":2629},{\"id\":2620},{\"id\":2630},{\"id\":2631},{\"id\":2632},{\"id\":2621},{\"id\":2633},{\"id\":2634},{\"id\":2635},{\"id\":2613},{\"id\":2637},{\"id\":2645},{\"id\":2646},{\"id\":2668},{\"id\":2638},{\"id\":2647},{\"id\":2648},{\"id\":2649},{\"id\":2639},{\"id\":2650},{\"id\":2651},{\"id\":2652},{\"id\":2640},{\"id\":2653},{\"id\":2654},{\"id\":2655},{\"id\":2641},{\"id\":2656},{\"id\":2657},{\"id\":2658},{\"id\":2642},{\"id\":2659},{\"id\":2660},{\"id\":2661},{\"id\":2643},{\"id\":2662},{\"id\":2663},{\"id\":2664},{\"id\":2644},{\"id\":2665},{\"id\":2666},{\"id\":2667},{\"id\":2614},{\"id\":2669},{\"id\":2677},{\"id\":2678},{\"id\":2700},{\"id\":2670},{\"id\":2679},{\"id\":2680},{\"id\":2681},{\"id\":2671},{\"id\":2682},{\"id\":2683},{\"id\":2684},{\"id\":2672},{\"id\":2685},{\"id\":2686},{\"id\":2687},{\"id\":2673},{\"id\":2688},{\"id\":2689},{\"id\":2690},{\"id\":2674},{\"id\":2691},{\"id\":2692},{\"id\":2693},{\"id\":2675},{\"id\":2694},{\"id\":2695},{\"id\":2696},{\"id\":2676},{\"id\":2697},{\"id\":2698},{\"id\":2699},{\"id\":2615},{\"id\":2701},{\"id\":2705},{\"id\":2706},{\"id\":2716},{\"id\":2702},{\"id\":2707},{\"id\":2708},{\"id\":2709},{\"id\":2703},{\"id\":2710},{\"id\":2711},{\"id\":2712},{\"id\":2704},{\"id\":2713},{\"id\":2714},{\"id\":2715},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2717,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"previousSibling\":{\"id\":2717},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":2719,\"textContent\":\" \",\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2721,\"textContent\":\" \",\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2722,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2723,\"textContent\":\" \",\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2720}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2729,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2730,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2731,\"textContent\":\" \",\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2732,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2738,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\" \",\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2740,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2741,\"textContent\":\" \",\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2742,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2745,\"textContent\":\" \",\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2746,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2747,\"textContent\":\" \",\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2748,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2749,\"textContent\":\" \",\"parentNode\":{\"id\":2738}},{\"nodeType\":1,\"id\":2750,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2751,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2752,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2750}},{\"nodeType\":3,\"id\":2753,\"textContent\":\" \",\"parentNode\":{\"id\":2740}},{\"nodeType\":1,\"id\":2754,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2740}},{\"nodeType\":3,\"id\":2755,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2754},\"parentNode\":{\"id\":2740}},{\"nodeType\":3,\"id\":2756,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2754}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2742}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2742}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2761,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2746}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2763,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2764,\"textContent\":\" \",\"previousSibling\":{\"id\":2763},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2765,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2763}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2717},{\"id\":2719},{\"id\":2720},{\"id\":2726},{\"id\":2727},{\"id\":2729},{\"id\":2730},{\"id\":2732},{\"id\":2731},{\"id\":2728},{\"id\":2721},{\"id\":2722},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2748},{\"id\":2738},{\"id\":2749},{\"id\":2750},{\"id\":2752},{\"id\":2751},{\"id\":2739},{\"id\":2740},{\"id\":2753},{\"id\":2754},{\"id\":2756},{\"id\":2755},{\"id\":2741},{\"id\":2742},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2743},{\"id\":2744},{\"id\":2760},{\"id\":2745},{\"id\":2746},{\"id\":2761},{\"id\":2747},{\"id\":2735},{\"id\":2723},{\"id\":2724},{\"id\":2762},{\"id\":2763},{\"id\":2765},{\"id\":2764},{\"id\":2725},{\"id\":2718}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2766,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"[ { \\\"rt\\\": 25321, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 25325, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 3738, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 30154, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 15297, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"WHISKEY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 46458, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 6541, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 54080, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 23038, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 78120, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8364, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 87694, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-A -A -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:919,y:749,t:1527872896268};\\\", \\\"{x:930,y:756,t:1527872896283};\\\", \\\"{x:963,y:784,t:1527872896299};\\\", \\\"{x:985,y:803,t:1527872896317};\\\", \\\"{x:1012,y:823,t:1527872896333};\\\", \\\"{x:1042,y:843,t:1527872896349};\\\", \\\"{x:1072,y:861,t:1527872896366};\\\", \\\"{x:1107,y:882,t:1527872896383};\\\", \\\"{x:1147,y:903,t:1527872896399};\\\", \\\"{x:1180,y:918,t:1527872896416};\\\", \\\"{x:1213,y:935,t:1527872896433};\\\", \\\"{x:1240,y:949,t:1527872896449};\\\", \\\"{x:1251,y:956,t:1527872896467};\\\", \\\"{x:1276,y:964,t:1527872896483};\\\", \\\"{x:1283,y:967,t:1527872896499};\\\", \\\"{x:1286,y:968,t:1527872896516};\\\", \\\"{x:1291,y:968,t:1527872896533};\\\", \\\"{x:1293,y:969,t:1527872896549};\\\", \\\"{x:1294,y:969,t:1527872896566};\\\", \\\"{x:1295,y:969,t:1527872896610};\\\", \\\"{x:1295,y:970,t:1527872896618};\\\", \\\"{x:1295,y:971,t:1527872896633};\\\", \\\"{x:1295,y:974,t:1527872896649};\\\", \\\"{x:1295,y:976,t:1527872896666};\\\", \\\"{x:1295,y:978,t:1527872896682};\\\", \\\"{x:1294,y:982,t:1527872896699};\\\", \\\"{x:1294,y:988,t:1527872896716};\\\", \\\"{x:1294,y:993,t:1527872896733};\\\", \\\"{x:1294,y:999,t:1527872896749};\\\", \\\"{x:1294,y:1000,t:1527872896767};\\\", \\\"{x:1294,y:1002,t:1527872896784};\\\", \\\"{x:1293,y:1003,t:1527872896800};\\\", \\\"{x:1293,y:1005,t:1527872896852};\\\", \\\"{x:1292,y:1005,t:1527872896867};\\\", \\\"{x:1290,y:1005,t:1527872896883};\\\", \\\"{x:1286,y:1005,t:1527872896901};\\\", \\\"{x:1284,y:1005,t:1527872896916};\\\", \\\"{x:1282,y:1003,t:1527872896933};\\\", \\\"{x:1279,y:1000,t:1527872896951};\\\", \\\"{x:1276,y:996,t:1527872896966};\\\", \\\"{x:1275,y:995,t:1527872896983};\\\", \\\"{x:1274,y:995,t:1527872897000};\\\", \\\"{x:1274,y:993,t:1527872897016};\\\", \\\"{x:1274,y:992,t:1527872897043};\\\", \\\"{x:1274,y:990,t:1527872897066};\\\", \\\"{x:1274,y:989,t:1527872897292};\\\", \\\"{x:1275,y:988,t:1527872897306};\\\", \\\"{x:1276,y:987,t:1527872897317};\\\", \\\"{x:1278,y:986,t:1527872897334};\\\", \\\"{x:1279,y:984,t:1527872897350};\\\", \\\"{x:1280,y:983,t:1527872897367};\\\", \\\"{x:1281,y:982,t:1527872897383};\\\", \\\"{x:1281,y:980,t:1527872897435};\\\", \\\"{x:1282,y:980,t:1527872897450};\\\", \\\"{x:1282,y:977,t:1527872897467};\\\", \\\"{x:1283,y:975,t:1527872897484};\\\", \\\"{x:1284,y:974,t:1527872897507};\\\", \\\"{x:1284,y:973,t:1527872897523};\\\", \\\"{x:1284,y:972,t:1527872897534};\\\", \\\"{x:1285,y:971,t:1527872897550};\\\", \\\"{x:1286,y:970,t:1527872897636};\\\", \\\"{x:1286,y:969,t:1527872897651};\\\", \\\"{x:1286,y:968,t:1527872897668};\\\", \\\"{x:1287,y:966,t:1527872897685};\\\", \\\"{x:1287,y:965,t:1527872897703};\\\", \\\"{x:1287,y:964,t:1527872897723};\\\", \\\"{x:1287,y:963,t:1527872897734};\\\", \\\"{x:1287,y:962,t:1527872897751};\\\", \\\"{x:1287,y:959,t:1527872897767};\\\", \\\"{x:1287,y:958,t:1527872897784};\\\", \\\"{x:1287,y:955,t:1527872897800};\\\", \\\"{x:1287,y:951,t:1527872897818};\\\", \\\"{x:1288,y:948,t:1527872897834};\\\", \\\"{x:1288,y:941,t:1527872897851};\\\", \\\"{x:1288,y:929,t:1527872897867};\\\", \\\"{x:1288,y:918,t:1527872897884};\\\", \\\"{x:1288,y:909,t:1527872897902};\\\", \\\"{x:1288,y:902,t:1527872897918};\\\", \\\"{x:1288,y:898,t:1527872897934};\\\", \\\"{x:1288,y:892,t:1527872897951};\\\", \\\"{x:1288,y:886,t:1527872897968};\\\", \\\"{x:1288,y:879,t:1527872897985};\\\", \\\"{x:1288,y:875,t:1527872898001};\\\", \\\"{x:1288,y:868,t:1527872898018};\\\", \\\"{x:1288,y:865,t:1527872898035};\\\", \\\"{x:1288,y:861,t:1527872898051};\\\", \\\"{x:1288,y:854,t:1527872898067};\\\", \\\"{x:1288,y:849,t:1527872898085};\\\", \\\"{x:1288,y:843,t:1527872898103};\\\", \\\"{x:1288,y:838,t:1527872898117};\\\", \\\"{x:1287,y:834,t:1527872898134};\\\", \\\"{x:1287,y:828,t:1527872898151};\\\", \\\"{x:1287,y:825,t:1527872898167};\\\", \\\"{x:1285,y:821,t:1527872898185};\\\", \\\"{x:1284,y:818,t:1527872898202};\\\", \\\"{x:1283,y:816,t:1527872898217};\\\", \\\"{x:1283,y:815,t:1527872898234};\\\", \\\"{x:1283,y:813,t:1527872898252};\\\", \\\"{x:1283,y:811,t:1527872898268};\\\", \\\"{x:1283,y:810,t:1527872898324};\\\", \\\"{x:1283,y:811,t:1527872898450};\\\", \\\"{x:1282,y:814,t:1527872898467};\\\", \\\"{x:1282,y:815,t:1527872898484};\\\", \\\"{x:1281,y:816,t:1527872898501};\\\", \\\"{x:1280,y:817,t:1527872898518};\\\", \\\"{x:1276,y:820,t:1527872898535};\\\", \\\"{x:1264,y:822,t:1527872898552};\\\", \\\"{x:1244,y:823,t:1527872898567};\\\", \\\"{x:1212,y:823,t:1527872898584};\\\", \\\"{x:1159,y:818,t:1527872898601};\\\", \\\"{x:1079,y:807,t:1527872898618};\\\", \\\"{x:986,y:787,t:1527872898635};\\\", \\\"{x:830,y:741,t:1527872898651};\\\", \\\"{x:731,y:715,t:1527872898668};\\\", \\\"{x:653,y:693,t:1527872898685};\\\", \\\"{x:581,y:671,t:1527872898703};\\\", \\\"{x:502,y:643,t:1527872898718};\\\", \\\"{x:438,y:624,t:1527872898735};\\\", \\\"{x:398,y:605,t:1527872898752};\\\", \\\"{x:369,y:591,t:1527872898768};\\\", \\\"{x:349,y:582,t:1527872898785};\\\", \\\"{x:338,y:576,t:1527872898801};\\\", \\\"{x:333,y:572,t:1527872898819};\\\", \\\"{x:324,y:564,t:1527872898835};\\\", \\\"{x:320,y:559,t:1527872898852};\\\", \\\"{x:315,y:556,t:1527872898868};\\\", \\\"{x:309,y:552,t:1527872898885};\\\", \\\"{x:301,y:547,t:1527872898902};\\\", \\\"{x:291,y:543,t:1527872898919};\\\", \\\"{x:282,y:542,t:1527872898935};\\\", \\\"{x:275,y:542,t:1527872898952};\\\", \\\"{x:274,y:541,t:1527872898968};\\\", \\\"{x:273,y:541,t:1527872899019};\\\", \\\"{x:269,y:538,t:1527872899035};\\\", \\\"{x:262,y:534,t:1527872899054};\\\", \\\"{x:254,y:530,t:1527872899069};\\\", \\\"{x:246,y:529,t:1527872899085};\\\", \\\"{x:236,y:528,t:1527872899103};\\\", \\\"{x:229,y:528,t:1527872899118};\\\", \\\"{x:221,y:528,t:1527872899136};\\\", \\\"{x:214,y:528,t:1527872899153};\\\", \\\"{x:211,y:528,t:1527872899168};\\\", \\\"{x:205,y:529,t:1527872899185};\\\", \\\"{x:202,y:531,t:1527872899203};\\\", \\\"{x:200,y:533,t:1527872899218};\\\", \\\"{x:196,y:537,t:1527872899236};\\\", \\\"{x:196,y:539,t:1527872899252};\\\", \\\"{x:196,y:542,t:1527872899268};\\\", \\\"{x:196,y:543,t:1527872899285};\\\", \\\"{x:196,y:544,t:1527872899307};\\\", \\\"{x:196,y:545,t:1527872899318};\\\", \\\"{x:201,y:546,t:1527872899335};\\\", \\\"{x:223,y:546,t:1527872899352};\\\", \\\"{x:250,y:545,t:1527872899368};\\\", \\\"{x:273,y:543,t:1527872899386};\\\", \\\"{x:293,y:540,t:1527872899402};\\\", \\\"{x:321,y:535,t:1527872899420};\\\", \\\"{x:338,y:530,t:1527872899435};\\\", \\\"{x:348,y:526,t:1527872899452};\\\", \\\"{x:353,y:523,t:1527872899468};\\\", \\\"{x:356,y:520,t:1527872899486};\\\", \\\"{x:357,y:520,t:1527872899579};\\\", \\\"{x:358,y:519,t:1527872899587};\\\", \\\"{x:360,y:518,t:1527872899603};\\\", \\\"{x:367,y:515,t:1527872899619};\\\", \\\"{x:372,y:512,t:1527872899635};\\\", \\\"{x:380,y:508,t:1527872899653};\\\", \\\"{x:383,y:505,t:1527872899669};\\\", \\\"{x:384,y:505,t:1527872899698};\\\", \\\"{x:385,y:504,t:1527872899706};\\\", \\\"{x:387,y:503,t:1527872899723};\\\", \\\"{x:388,y:503,t:1527872899736};\\\", \\\"{x:389,y:502,t:1527872899752};\\\", \\\"{x:391,y:501,t:1527872899769};\\\", \\\"{x:393,y:501,t:1527872899787};\\\", \\\"{x:393,y:504,t:1527872899851};\\\", \\\"{x:393,y:507,t:1527872899860};\\\", \\\"{x:393,y:511,t:1527872899869};\\\", \\\"{x:393,y:517,t:1527872899886};\\\", \\\"{x:393,y:518,t:1527872899902};\\\", \\\"{x:393,y:519,t:1527872899920};\\\", \\\"{x:393,y:521,t:1527872900251};\\\", \\\"{x:393,y:525,t:1527872900259};\\\", \\\"{x:394,y:528,t:1527872900269};\\\", \\\"{x:398,y:535,t:1527872900287};\\\", \\\"{x:403,y:543,t:1527872900304};\\\", \\\"{x:420,y:563,t:1527872900319};\\\", \\\"{x:436,y:578,t:1527872900338};\\\", \\\"{x:458,y:600,t:1527872900354};\\\", \\\"{x:477,y:619,t:1527872900370};\\\", \\\"{x:499,y:641,t:1527872900387};\\\", \\\"{x:507,y:652,t:1527872900402};\\\", \\\"{x:512,y:659,t:1527872900419};\\\", \\\"{x:519,y:670,t:1527872900436};\\\", \\\"{x:525,y:678,t:1527872900453};\\\", \\\"{x:532,y:688,t:1527872900469};\\\", \\\"{x:538,y:695,t:1527872900486};\\\", \\\"{x:542,y:700,t:1527872900503};\\\", \\\"{x:544,y:704,t:1527872900519};\\\", \\\"{x:545,y:707,t:1527872900537};\\\", \\\"{x:545,y:710,t:1527872900553};\\\", \\\"{x:545,y:711,t:1527872900569};\\\", \\\"{x:545,y:713,t:1527872900586};\\\", \\\"{x:545,y:718,t:1527872900603};\\\", \\\"{x:545,y:722,t:1527872900620};\\\", \\\"{x:545,y:726,t:1527872900636};\\\", \\\"{x:545,y:729,t:1527872900654};\\\", \\\"{x:544,y:730,t:1527872900884};\\\", \\\"{x:543,y:730,t:1527872900900};\\\", \\\"{x:542,y:730,t:1527872900923};\\\", \\\"{x:541,y:730,t:1527872900937};\\\", \\\"{x:539,y:729,t:1527872900972};\\\" ] }, { \\\"rt\\\": 28979, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 117954, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-04 PM-04 PM-G -04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:723,t:1527872908610};\\\", \\\"{x:527,y:713,t:1527872908626};\\\", \\\"{x:511,y:696,t:1527872908643};\\\", \\\"{x:508,y:690,t:1527872908660};\\\", \\\"{x:503,y:682,t:1527872908677};\\\", \\\"{x:497,y:672,t:1527872908693};\\\", \\\"{x:494,y:664,t:1527872908709};\\\", \\\"{x:489,y:657,t:1527872908727};\\\", \\\"{x:486,y:651,t:1527872908742};\\\", \\\"{x:482,y:642,t:1527872908760};\\\", \\\"{x:479,y:636,t:1527872908776};\\\", \\\"{x:476,y:632,t:1527872908792};\\\", \\\"{x:473,y:626,t:1527872908809};\\\", \\\"{x:468,y:615,t:1527872908827};\\\", \\\"{x:467,y:609,t:1527872908843};\\\", \\\"{x:467,y:603,t:1527872908859};\\\", \\\"{x:467,y:599,t:1527872908876};\\\", \\\"{x:467,y:594,t:1527872908892};\\\", \\\"{x:467,y:588,t:1527872908909};\\\", \\\"{x:467,y:581,t:1527872908927};\\\", \\\"{x:468,y:576,t:1527872908942};\\\", \\\"{x:468,y:571,t:1527872908960};\\\", \\\"{x:468,y:566,t:1527872908977};\\\", \\\"{x:468,y:564,t:1527872908993};\\\", \\\"{x:468,y:561,t:1527872909010};\\\", \\\"{x:465,y:552,t:1527872909026};\\\", \\\"{x:460,y:540,t:1527872909044};\\\", \\\"{x:454,y:530,t:1527872909060};\\\", \\\"{x:453,y:526,t:1527872909076};\\\", \\\"{x:449,y:519,t:1527872909093};\\\", \\\"{x:449,y:514,t:1527872909110};\\\", \\\"{x:449,y:511,t:1527872909127};\\\", \\\"{x:449,y:507,t:1527872909143};\\\", \\\"{x:449,y:505,t:1527872909160};\\\", \\\"{x:449,y:504,t:1527872909177};\\\", \\\"{x:449,y:502,t:1527872909194};\\\", \\\"{x:451,y:500,t:1527872909210};\\\", \\\"{x:455,y:496,t:1527872909227};\\\", \\\"{x:461,y:493,t:1527872909243};\\\", \\\"{x:467,y:488,t:1527872909260};\\\", \\\"{x:475,y:485,t:1527872909277};\\\", \\\"{x:479,y:482,t:1527872909294};\\\", \\\"{x:483,y:482,t:1527872909310};\\\", \\\"{x:486,y:482,t:1527872909327};\\\", \\\"{x:492,y:481,t:1527872909344};\\\", \\\"{x:496,y:480,t:1527872909360};\\\", \\\"{x:501,y:479,t:1527872909377};\\\", \\\"{x:508,y:479,t:1527872909394};\\\", \\\"{x:512,y:478,t:1527872909410};\\\", \\\"{x:519,y:477,t:1527872909427};\\\", \\\"{x:524,y:477,t:1527872909444};\\\", \\\"{x:527,y:477,t:1527872909461};\\\", \\\"{x:530,y:477,t:1527872909477};\\\", \\\"{x:533,y:478,t:1527872909494};\\\", \\\"{x:540,y:483,t:1527872909511};\\\", \\\"{x:545,y:484,t:1527872909527};\\\", \\\"{x:547,y:486,t:1527872909544};\\\", \\\"{x:549,y:487,t:1527872909561};\\\", \\\"{x:552,y:487,t:1527872909577};\\\", \\\"{x:553,y:489,t:1527872909594};\\\", \\\"{x:554,y:489,t:1527872909611};\\\", \\\"{x:555,y:489,t:1527872909643};\\\", \\\"{x:555,y:490,t:1527872909661};\\\", \\\"{x:555,y:491,t:1527872909678};\\\", \\\"{x:555,y:492,t:1527872909694};\\\", \\\"{x:555,y:493,t:1527872909962};\\\", \\\"{x:556,y:494,t:1527872909977};\\\", \\\"{x:559,y:496,t:1527872909994};\\\", \\\"{x:563,y:496,t:1527872910011};\\\", \\\"{x:566,y:497,t:1527872910028};\\\", \\\"{x:575,y:498,t:1527872910045};\\\", \\\"{x:587,y:499,t:1527872910060};\\\", \\\"{x:599,y:500,t:1527872910078};\\\", \\\"{x:613,y:501,t:1527872910094};\\\", \\\"{x:633,y:501,t:1527872910110};\\\", \\\"{x:658,y:505,t:1527872910128};\\\", \\\"{x:683,y:509,t:1527872910146};\\\", \\\"{x:706,y:511,t:1527872910160};\\\", \\\"{x:733,y:517,t:1527872910179};\\\", \\\"{x:782,y:524,t:1527872910194};\\\", \\\"{x:820,y:534,t:1527872910210};\\\", \\\"{x:874,y:544,t:1527872910228};\\\", \\\"{x:947,y:556,t:1527872910244};\\\", \\\"{x:1048,y:576,t:1527872910261};\\\", \\\"{x:1137,y:591,t:1527872910277};\\\", \\\"{x:1227,y:608,t:1527872910293};\\\", \\\"{x:1319,y:622,t:1527872910311};\\\", \\\"{x:1405,y:647,t:1527872910328};\\\", \\\"{x:1471,y:664,t:1527872910344};\\\", \\\"{x:1527,y:682,t:1527872910361};\\\", \\\"{x:1571,y:700,t:1527872910378};\\\", \\\"{x:1602,y:716,t:1527872910395};\\\", \\\"{x:1611,y:723,t:1527872910411};\\\", \\\"{x:1618,y:731,t:1527872910428};\\\", \\\"{x:1623,y:747,t:1527872910445};\\\", \\\"{x:1626,y:765,t:1527872910462};\\\", \\\"{x:1629,y:777,t:1527872910478};\\\", \\\"{x:1631,y:787,t:1527872910495};\\\", \\\"{x:1631,y:797,t:1527872910511};\\\", \\\"{x:1631,y:805,t:1527872910528};\\\", \\\"{x:1628,y:818,t:1527872910545};\\\", \\\"{x:1622,y:834,t:1527872910562};\\\", \\\"{x:1613,y:854,t:1527872910578};\\\", \\\"{x:1599,y:888,t:1527872910594};\\\", \\\"{x:1589,y:906,t:1527872910612};\\\", \\\"{x:1583,y:921,t:1527872910628};\\\", \\\"{x:1575,y:938,t:1527872910645};\\\", \\\"{x:1566,y:951,t:1527872910662};\\\", \\\"{x:1557,y:964,t:1527872910679};\\\", \\\"{x:1546,y:979,t:1527872910695};\\\", \\\"{x:1535,y:989,t:1527872910713};\\\", \\\"{x:1521,y:997,t:1527872910728};\\\", \\\"{x:1512,y:1006,t:1527872910746};\\\", \\\"{x:1506,y:1016,t:1527872910763};\\\", \\\"{x:1493,y:1029,t:1527872910780};\\\", \\\"{x:1483,y:1036,t:1527872910795};\\\", \\\"{x:1474,y:1041,t:1527872910812};\\\", \\\"{x:1466,y:1045,t:1527872910829};\\\", \\\"{x:1457,y:1047,t:1527872910845};\\\", \\\"{x:1448,y:1049,t:1527872910862};\\\", \\\"{x:1439,y:1052,t:1527872910879};\\\", \\\"{x:1430,y:1052,t:1527872910895};\\\", \\\"{x:1424,y:1052,t:1527872910912};\\\", \\\"{x:1417,y:1052,t:1527872910929};\\\", \\\"{x:1412,y:1052,t:1527872910945};\\\", \\\"{x:1410,y:1052,t:1527872910962};\\\", \\\"{x:1407,y:1052,t:1527872910978};\\\", \\\"{x:1406,y:1052,t:1527872911003};\\\", \\\"{x:1405,y:1052,t:1527872911011};\\\", \\\"{x:1401,y:1052,t:1527872911029};\\\", \\\"{x:1400,y:1052,t:1527872911045};\\\", \\\"{x:1399,y:1051,t:1527872911062};\\\", \\\"{x:1397,y:1051,t:1527872911079};\\\", \\\"{x:1395,y:1048,t:1527872911096};\\\", \\\"{x:1392,y:1045,t:1527872911112};\\\", \\\"{x:1390,y:1045,t:1527872911129};\\\", \\\"{x:1387,y:1041,t:1527872911146};\\\", \\\"{x:1386,y:1038,t:1527872911162};\\\", \\\"{x:1383,y:1031,t:1527872911179};\\\", \\\"{x:1383,y:1027,t:1527872911196};\\\", \\\"{x:1382,y:1024,t:1527872911213};\\\", \\\"{x:1381,y:1020,t:1527872911229};\\\", \\\"{x:1380,y:1016,t:1527872911247};\\\", \\\"{x:1379,y:1013,t:1527872911263};\\\", \\\"{x:1378,y:1009,t:1527872911279};\\\", \\\"{x:1376,y:1006,t:1527872911296};\\\", \\\"{x:1376,y:1003,t:1527872911314};\\\", \\\"{x:1376,y:999,t:1527872911330};\\\", \\\"{x:1376,y:997,t:1527872911346};\\\", \\\"{x:1376,y:994,t:1527872911364};\\\", \\\"{x:1376,y:993,t:1527872911379};\\\", \\\"{x:1376,y:989,t:1527872911396};\\\", \\\"{x:1376,y:982,t:1527872911414};\\\", \\\"{x:1376,y:972,t:1527872911430};\\\", \\\"{x:1378,y:962,t:1527872911446};\\\", \\\"{x:1378,y:956,t:1527872911463};\\\", \\\"{x:1378,y:947,t:1527872911480};\\\", \\\"{x:1376,y:942,t:1527872911497};\\\", \\\"{x:1373,y:934,t:1527872911513};\\\", \\\"{x:1371,y:930,t:1527872911530};\\\", \\\"{x:1371,y:927,t:1527872911547};\\\", \\\"{x:1370,y:924,t:1527872911563};\\\", \\\"{x:1370,y:921,t:1527872911580};\\\", \\\"{x:1370,y:916,t:1527872911596};\\\", \\\"{x:1370,y:912,t:1527872911613};\\\", \\\"{x:1369,y:907,t:1527872911630};\\\", \\\"{x:1368,y:903,t:1527872911646};\\\", \\\"{x:1368,y:899,t:1527872911664};\\\", \\\"{x:1367,y:896,t:1527872911680};\\\", \\\"{x:1367,y:891,t:1527872911697};\\\", \\\"{x:1367,y:883,t:1527872911714};\\\", \\\"{x:1367,y:878,t:1527872911731};\\\", \\\"{x:1367,y:871,t:1527872911746};\\\", \\\"{x:1367,y:863,t:1527872911763};\\\", \\\"{x:1368,y:855,t:1527872911780};\\\", \\\"{x:1369,y:843,t:1527872911797};\\\", \\\"{x:1369,y:825,t:1527872911813};\\\", \\\"{x:1367,y:807,t:1527872911831};\\\", \\\"{x:1364,y:795,t:1527872911847};\\\", \\\"{x:1363,y:787,t:1527872911864};\\\", \\\"{x:1361,y:783,t:1527872911880};\\\", \\\"{x:1361,y:781,t:1527872911898};\\\", \\\"{x:1360,y:780,t:1527872911913};\\\", \\\"{x:1360,y:779,t:1527872912163};\\\", \\\"{x:1359,y:771,t:1527872912180};\\\", \\\"{x:1359,y:761,t:1527872912198};\\\", \\\"{x:1359,y:750,t:1527872912215};\\\", \\\"{x:1359,y:736,t:1527872912231};\\\", \\\"{x:1359,y:724,t:1527872912247};\\\", \\\"{x:1359,y:714,t:1527872912263};\\\", \\\"{x:1360,y:700,t:1527872912281};\\\", \\\"{x:1360,y:692,t:1527872912298};\\\", \\\"{x:1361,y:683,t:1527872912314};\\\", \\\"{x:1364,y:668,t:1527872912331};\\\", \\\"{x:1366,y:657,t:1527872912347};\\\", \\\"{x:1366,y:647,t:1527872912364};\\\", \\\"{x:1369,y:636,t:1527872912381};\\\", \\\"{x:1372,y:624,t:1527872912398};\\\", \\\"{x:1375,y:615,t:1527872912414};\\\", \\\"{x:1378,y:606,t:1527872912431};\\\", \\\"{x:1383,y:594,t:1527872912448};\\\", \\\"{x:1388,y:583,t:1527872912465};\\\", \\\"{x:1393,y:572,t:1527872912481};\\\", \\\"{x:1399,y:558,t:1527872912498};\\\", \\\"{x:1405,y:546,t:1527872912515};\\\", \\\"{x:1414,y:531,t:1527872912530};\\\", \\\"{x:1418,y:526,t:1527872912549};\\\", \\\"{x:1423,y:517,t:1527872912564};\\\", \\\"{x:1426,y:512,t:1527872912581};\\\", \\\"{x:1429,y:505,t:1527872912598};\\\", \\\"{x:1432,y:499,t:1527872912615};\\\", \\\"{x:1437,y:489,t:1527872912632};\\\", \\\"{x:1442,y:480,t:1527872912648};\\\", \\\"{x:1448,y:473,t:1527872912665};\\\", \\\"{x:1454,y:467,t:1527872912681};\\\", \\\"{x:1459,y:461,t:1527872912699};\\\", \\\"{x:1468,y:456,t:1527872912715};\\\", \\\"{x:1475,y:455,t:1527872912732};\\\", \\\"{x:1490,y:451,t:1527872912749};\\\", \\\"{x:1505,y:446,t:1527872912766};\\\", \\\"{x:1525,y:443,t:1527872912782};\\\", \\\"{x:1538,y:439,t:1527872912799};\\\", \\\"{x:1551,y:435,t:1527872912816};\\\", \\\"{x:1561,y:433,t:1527872912831};\\\", \\\"{x:1569,y:430,t:1527872912849};\\\", \\\"{x:1574,y:429,t:1527872912866};\\\", \\\"{x:1582,y:427,t:1527872912881};\\\", \\\"{x:1591,y:425,t:1527872912898};\\\", \\\"{x:1603,y:425,t:1527872912915};\\\", \\\"{x:1619,y:425,t:1527872912932};\\\", \\\"{x:1630,y:425,t:1527872912949};\\\", \\\"{x:1641,y:425,t:1527872912965};\\\", \\\"{x:1645,y:425,t:1527872912981};\\\", \\\"{x:1647,y:425,t:1527872912998};\\\", \\\"{x:1648,y:425,t:1527872913018};\\\", \\\"{x:1649,y:425,t:1527872913163};\\\", \\\"{x:1648,y:427,t:1527872913202};\\\", \\\"{x:1647,y:429,t:1527872913215};\\\", \\\"{x:1643,y:431,t:1527872913232};\\\", \\\"{x:1641,y:433,t:1527872913249};\\\", \\\"{x:1640,y:434,t:1527872913265};\\\", \\\"{x:1639,y:436,t:1527872913283};\\\", \\\"{x:1638,y:438,t:1527872913299};\\\", \\\"{x:1637,y:442,t:1527872913315};\\\", \\\"{x:1637,y:448,t:1527872913331};\\\", \\\"{x:1635,y:461,t:1527872913348};\\\", \\\"{x:1635,y:471,t:1527872913365};\\\", \\\"{x:1635,y:483,t:1527872913382};\\\", \\\"{x:1635,y:495,t:1527872913399};\\\", \\\"{x:1633,y:509,t:1527872913416};\\\", \\\"{x:1633,y:518,t:1527872913432};\\\", \\\"{x:1632,y:528,t:1527872913449};\\\", \\\"{x:1632,y:539,t:1527872913466};\\\", \\\"{x:1632,y:547,t:1527872913482};\\\", \\\"{x:1632,y:558,t:1527872913499};\\\", \\\"{x:1630,y:565,t:1527872913516};\\\", \\\"{x:1629,y:571,t:1527872913532};\\\", \\\"{x:1628,y:576,t:1527872913549};\\\", \\\"{x:1628,y:580,t:1527872913566};\\\", \\\"{x:1626,y:584,t:1527872913582};\\\", \\\"{x:1625,y:588,t:1527872913599};\\\", \\\"{x:1624,y:596,t:1527872913616};\\\", \\\"{x:1622,y:606,t:1527872913633};\\\", \\\"{x:1621,y:612,t:1527872913649};\\\", \\\"{x:1621,y:620,t:1527872913666};\\\", \\\"{x:1620,y:633,t:1527872913683};\\\", \\\"{x:1620,y:640,t:1527872913700};\\\", \\\"{x:1620,y:648,t:1527872913717};\\\", \\\"{x:1620,y:656,t:1527872913733};\\\", \\\"{x:1620,y:669,t:1527872913750};\\\", \\\"{x:1620,y:680,t:1527872913766};\\\", \\\"{x:1618,y:688,t:1527872913783};\\\", \\\"{x:1617,y:690,t:1527872913799};\\\", \\\"{x:1617,y:691,t:1527872913819};\\\", \\\"{x:1616,y:693,t:1527872913835};\\\", \\\"{x:1616,y:696,t:1527872913851};\\\", \\\"{x:1613,y:698,t:1527872913867};\\\", \\\"{x:1613,y:707,t:1527872913883};\\\", \\\"{x:1613,y:716,t:1527872913900};\\\", \\\"{x:1613,y:721,t:1527872913917};\\\", \\\"{x:1613,y:725,t:1527872913934};\\\", \\\"{x:1613,y:728,t:1527872913950};\\\", \\\"{x:1613,y:734,t:1527872913966};\\\", \\\"{x:1613,y:742,t:1527872913984};\\\", \\\"{x:1615,y:754,t:1527872914000};\\\", \\\"{x:1618,y:763,t:1527872914017};\\\", \\\"{x:1620,y:769,t:1527872914033};\\\", \\\"{x:1621,y:772,t:1527872914050};\\\", \\\"{x:1622,y:773,t:1527872914066};\\\", \\\"{x:1622,y:775,t:1527872914083};\\\", \\\"{x:1622,y:778,t:1527872914100};\\\", \\\"{x:1623,y:784,t:1527872914117};\\\", \\\"{x:1624,y:794,t:1527872914132};\\\", \\\"{x:1626,y:801,t:1527872914150};\\\", \\\"{x:1626,y:806,t:1527872914167};\\\", \\\"{x:1626,y:812,t:1527872914183};\\\", \\\"{x:1627,y:817,t:1527872914200};\\\", \\\"{x:1628,y:826,t:1527872914217};\\\", \\\"{x:1628,y:835,t:1527872914233};\\\", \\\"{x:1630,y:842,t:1527872914250};\\\", \\\"{x:1630,y:850,t:1527872914267};\\\", \\\"{x:1630,y:855,t:1527872914283};\\\", \\\"{x:1630,y:862,t:1527872914301};\\\", \\\"{x:1631,y:866,t:1527872914318};\\\", \\\"{x:1631,y:868,t:1527872914335};\\\", \\\"{x:1632,y:871,t:1527872914350};\\\", \\\"{x:1633,y:876,t:1527872914367};\\\", \\\"{x:1635,y:886,t:1527872914385};\\\", \\\"{x:1635,y:897,t:1527872914401};\\\", \\\"{x:1638,y:908,t:1527872914418};\\\", \\\"{x:1639,y:919,t:1527872914435};\\\", \\\"{x:1639,y:925,t:1527872914451};\\\", \\\"{x:1639,y:931,t:1527872914467};\\\", \\\"{x:1639,y:935,t:1527872914485};\\\", \\\"{x:1639,y:938,t:1527872914501};\\\", \\\"{x:1639,y:942,t:1527872914517};\\\", \\\"{x:1639,y:945,t:1527872914534};\\\", \\\"{x:1639,y:946,t:1527872914550};\\\", \\\"{x:1639,y:948,t:1527872914571};\\\", \\\"{x:1639,y:949,t:1527872914585};\\\", \\\"{x:1639,y:952,t:1527872914602};\\\", \\\"{x:1639,y:955,t:1527872914618};\\\", \\\"{x:1638,y:958,t:1527872914635};\\\", \\\"{x:1635,y:964,t:1527872914652};\\\", \\\"{x:1634,y:967,t:1527872914668};\\\", \\\"{x:1634,y:969,t:1527872914684};\\\", \\\"{x:1633,y:971,t:1527872914702};\\\", \\\"{x:1631,y:973,t:1527872914717};\\\", \\\"{x:1631,y:974,t:1527872914735};\\\", \\\"{x:1630,y:976,t:1527872914752};\\\", \\\"{x:1627,y:979,t:1527872914767};\\\", \\\"{x:1624,y:982,t:1527872914785};\\\", \\\"{x:1621,y:986,t:1527872914802};\\\", \\\"{x:1620,y:987,t:1527872914819};\\\", \\\"{x:1619,y:987,t:1527872914834};\\\", \\\"{x:1618,y:987,t:1527872914851};\\\", \\\"{x:1617,y:988,t:1527872914869};\\\", \\\"{x:1616,y:988,t:1527872914885};\\\", \\\"{x:1615,y:988,t:1527872914956};\\\", \\\"{x:1615,y:987,t:1527872915003};\\\", \\\"{x:1615,y:984,t:1527872915019};\\\", \\\"{x:1615,y:983,t:1527872915034};\\\", \\\"{x:1615,y:981,t:1527872915052};\\\", \\\"{x:1615,y:979,t:1527872915069};\\\", \\\"{x:1615,y:978,t:1527872915085};\\\", \\\"{x:1615,y:977,t:1527872915114};\\\", \\\"{x:1615,y:976,t:1527872915250};\\\", \\\"{x:1615,y:974,t:1527872915972};\\\", \\\"{x:1616,y:972,t:1527872916036};\\\", \\\"{x:1618,y:967,t:1527872916054};\\\", \\\"{x:1622,y:951,t:1527872916069};\\\", \\\"{x:1630,y:927,t:1527872916086};\\\", \\\"{x:1635,y:901,t:1527872916103};\\\", \\\"{x:1639,y:874,t:1527872916120};\\\", \\\"{x:1642,y:855,t:1527872916135};\\\", \\\"{x:1643,y:838,t:1527872916153};\\\", \\\"{x:1644,y:818,t:1527872916170};\\\", \\\"{x:1649,y:786,t:1527872916186};\\\", \\\"{x:1652,y:759,t:1527872916203};\\\", \\\"{x:1654,y:734,t:1527872916220};\\\", \\\"{x:1657,y:712,t:1527872916236};\\\", \\\"{x:1659,y:694,t:1527872916252};\\\", \\\"{x:1662,y:679,t:1527872916269};\\\", \\\"{x:1664,y:666,t:1527872916286};\\\", \\\"{x:1664,y:652,t:1527872916303};\\\", \\\"{x:1664,y:641,t:1527872916320};\\\", \\\"{x:1660,y:626,t:1527872916336};\\\", \\\"{x:1652,y:612,t:1527872916353};\\\", \\\"{x:1643,y:596,t:1527872916371};\\\", \\\"{x:1638,y:591,t:1527872916387};\\\", \\\"{x:1633,y:587,t:1527872916404};\\\", \\\"{x:1628,y:584,t:1527872916420};\\\", \\\"{x:1624,y:582,t:1527872916437};\\\", \\\"{x:1620,y:581,t:1527872916454};\\\", \\\"{x:1618,y:580,t:1527872916470};\\\", \\\"{x:1617,y:580,t:1527872916487};\\\", \\\"{x:1615,y:580,t:1527872916504};\\\", \\\"{x:1614,y:580,t:1527872916521};\\\", \\\"{x:1613,y:580,t:1527872916537};\\\", \\\"{x:1612,y:580,t:1527872916571};\\\", \\\"{x:1612,y:583,t:1527872916595};\\\", \\\"{x:1612,y:585,t:1527872916611};\\\", \\\"{x:1612,y:586,t:1527872916621};\\\", \\\"{x:1612,y:588,t:1527872916637};\\\", \\\"{x:1612,y:590,t:1527872916654};\\\", \\\"{x:1612,y:596,t:1527872916670};\\\", \\\"{x:1612,y:602,t:1527872916687};\\\", \\\"{x:1612,y:611,t:1527872916704};\\\", \\\"{x:1612,y:616,t:1527872916722};\\\", \\\"{x:1612,y:620,t:1527872916737};\\\", \\\"{x:1612,y:624,t:1527872916754};\\\", \\\"{x:1612,y:631,t:1527872916771};\\\", \\\"{x:1612,y:636,t:1527872916787};\\\", \\\"{x:1612,y:642,t:1527872916805};\\\", \\\"{x:1612,y:647,t:1527872916820};\\\", \\\"{x:1612,y:657,t:1527872916837};\\\", \\\"{x:1612,y:663,t:1527872916854};\\\", \\\"{x:1612,y:669,t:1527872916870};\\\", \\\"{x:1612,y:676,t:1527872916888};\\\", \\\"{x:1612,y:683,t:1527872916904};\\\", \\\"{x:1613,y:691,t:1527872916921};\\\", \\\"{x:1613,y:699,t:1527872916938};\\\", \\\"{x:1616,y:711,t:1527872916955};\\\", \\\"{x:1619,y:723,t:1527872916971};\\\", \\\"{x:1619,y:730,t:1527872916987};\\\", \\\"{x:1619,y:734,t:1527872917005};\\\", \\\"{x:1620,y:742,t:1527872917022};\\\", \\\"{x:1620,y:747,t:1527872917037};\\\", \\\"{x:1620,y:753,t:1527872917055};\\\", \\\"{x:1622,y:758,t:1527872917071};\\\", \\\"{x:1623,y:761,t:1527872917088};\\\", \\\"{x:1623,y:765,t:1527872917105};\\\", \\\"{x:1623,y:767,t:1527872917122};\\\", \\\"{x:1623,y:771,t:1527872917138};\\\", \\\"{x:1624,y:778,t:1527872917156};\\\", \\\"{x:1626,y:783,t:1527872917171};\\\", \\\"{x:1626,y:788,t:1527872917189};\\\", \\\"{x:1626,y:791,t:1527872917204};\\\", \\\"{x:1626,y:794,t:1527872917221};\\\", \\\"{x:1626,y:795,t:1527872917239};\\\", \\\"{x:1626,y:798,t:1527872917255};\\\", \\\"{x:1628,y:801,t:1527872917272};\\\", \\\"{x:1628,y:804,t:1527872917289};\\\", \\\"{x:1628,y:806,t:1527872917304};\\\", \\\"{x:1628,y:810,t:1527872917322};\\\", \\\"{x:1628,y:813,t:1527872917338};\\\", \\\"{x:1628,y:817,t:1527872917355};\\\", \\\"{x:1629,y:821,t:1527872917371};\\\", \\\"{x:1629,y:824,t:1527872917388};\\\", \\\"{x:1629,y:827,t:1527872917405};\\\", \\\"{x:1630,y:830,t:1527872917422};\\\", \\\"{x:1630,y:832,t:1527872917439};\\\", \\\"{x:1631,y:835,t:1527872917456};\\\", \\\"{x:1631,y:837,t:1527872917471};\\\", \\\"{x:1631,y:839,t:1527872917489};\\\", \\\"{x:1631,y:841,t:1527872917506};\\\", \\\"{x:1631,y:843,t:1527872917522};\\\", \\\"{x:1631,y:845,t:1527872917538};\\\", \\\"{x:1631,y:848,t:1527872917555};\\\", \\\"{x:1631,y:850,t:1527872917572};\\\", \\\"{x:1631,y:851,t:1527872917588};\\\", \\\"{x:1631,y:854,t:1527872917606};\\\", \\\"{x:1631,y:856,t:1527872917622};\\\", \\\"{x:1631,y:857,t:1527872917639};\\\", \\\"{x:1631,y:862,t:1527872917656};\\\", \\\"{x:1631,y:867,t:1527872917673};\\\", \\\"{x:1631,y:871,t:1527872917689};\\\", \\\"{x:1631,y:875,t:1527872917706};\\\", \\\"{x:1631,y:883,t:1527872917723};\\\", \\\"{x:1631,y:888,t:1527872917739};\\\", \\\"{x:1633,y:896,t:1527872917756};\\\", \\\"{x:1634,y:904,t:1527872917773};\\\", \\\"{x:1634,y:911,t:1527872917789};\\\", \\\"{x:1634,y:917,t:1527872917806};\\\", \\\"{x:1634,y:922,t:1527872917823};\\\", \\\"{x:1634,y:926,t:1527872917839};\\\", \\\"{x:1634,y:927,t:1527872917859};\\\", \\\"{x:1634,y:928,t:1527872917875};\\\", \\\"{x:1634,y:929,t:1527872917892};\\\", \\\"{x:1634,y:930,t:1527872917907};\\\", \\\"{x:1634,y:931,t:1527872917923};\\\", \\\"{x:1634,y:932,t:1527872917947};\\\", \\\"{x:1634,y:933,t:1527872917979};\\\", \\\"{x:1634,y:934,t:1527872917996};\\\", \\\"{x:1634,y:935,t:1527872918019};\\\", \\\"{x:1634,y:936,t:1527872918028};\\\", \\\"{x:1634,y:937,t:1527872918040};\\\", \\\"{x:1634,y:939,t:1527872918055};\\\", \\\"{x:1633,y:943,t:1527872918073};\\\", \\\"{x:1633,y:945,t:1527872918090};\\\", \\\"{x:1633,y:947,t:1527872918106};\\\", \\\"{x:1631,y:950,t:1527872918123};\\\", \\\"{x:1631,y:951,t:1527872918140};\\\", \\\"{x:1630,y:955,t:1527872918157};\\\", \\\"{x:1629,y:959,t:1527872918173};\\\", \\\"{x:1629,y:961,t:1527872918190};\\\", \\\"{x:1627,y:963,t:1527872918207};\\\", \\\"{x:1627,y:964,t:1527872918223};\\\", \\\"{x:1626,y:966,t:1527872921444};\\\", \\\"{x:1626,y:967,t:1527872921461};\\\", \\\"{x:1626,y:968,t:1527872921477};\\\", \\\"{x:1626,y:970,t:1527872921495};\\\", \\\"{x:1626,y:971,t:1527872921515};\\\", \\\"{x:1626,y:972,t:1527872921529};\\\", \\\"{x:1626,y:973,t:1527872921554};\\\", \\\"{x:1625,y:974,t:1527872921635};\\\", \\\"{x:1624,y:975,t:1527872923923};\\\", \\\"{x:1623,y:975,t:1527872924827};\\\", \\\"{x:1623,y:974,t:1527872924843};\\\", \\\"{x:1622,y:973,t:1527872924931};\\\", \\\"{x:1621,y:973,t:1527872924954};\\\", \\\"{x:1621,y:972,t:1527872924978};\\\", \\\"{x:1620,y:971,t:1527872925010};\\\", \\\"{x:1619,y:970,t:1527872925042};\\\", \\\"{x:1618,y:969,t:1527872925066};\\\", \\\"{x:1617,y:969,t:1527872925091};\\\", \\\"{x:1616,y:969,t:1527872925106};\\\", \\\"{x:1615,y:969,t:1527872925117};\\\", \\\"{x:1613,y:969,t:1527872925132};\\\", \\\"{x:1611,y:967,t:1527872925149};\\\", \\\"{x:1604,y:967,t:1527872925166};\\\", \\\"{x:1594,y:965,t:1527872925182};\\\", \\\"{x:1584,y:961,t:1527872925199};\\\", \\\"{x:1576,y:956,t:1527872925216};\\\", \\\"{x:1572,y:953,t:1527872925233};\\\", \\\"{x:1565,y:950,t:1527872925250};\\\", \\\"{x:1555,y:946,t:1527872925267};\\\", \\\"{x:1547,y:944,t:1527872925283};\\\", \\\"{x:1538,y:939,t:1527872925300};\\\", \\\"{x:1531,y:937,t:1527872925317};\\\", \\\"{x:1524,y:932,t:1527872925332};\\\", \\\"{x:1516,y:927,t:1527872925349};\\\", \\\"{x:1506,y:921,t:1527872925366};\\\", \\\"{x:1493,y:915,t:1527872925383};\\\", \\\"{x:1476,y:910,t:1527872925400};\\\", \\\"{x:1458,y:904,t:1527872925416};\\\", \\\"{x:1438,y:896,t:1527872925433};\\\", \\\"{x:1413,y:891,t:1527872925449};\\\", \\\"{x:1370,y:879,t:1527872925466};\\\", \\\"{x:1342,y:873,t:1527872925483};\\\", \\\"{x:1320,y:870,t:1527872925500};\\\", \\\"{x:1294,y:864,t:1527872925517};\\\", \\\"{x:1271,y:859,t:1527872925534};\\\", \\\"{x:1244,y:853,t:1527872925549};\\\", \\\"{x:1218,y:845,t:1527872925566};\\\", \\\"{x:1193,y:837,t:1527872925584};\\\", \\\"{x:1176,y:833,t:1527872925601};\\\", \\\"{x:1154,y:827,t:1527872925616};\\\", \\\"{x:1128,y:820,t:1527872925634};\\\", \\\"{x:1089,y:809,t:1527872925650};\\\", \\\"{x:1067,y:803,t:1527872925667};\\\", \\\"{x:1045,y:796,t:1527872925684};\\\", \\\"{x:1021,y:788,t:1527872925701};\\\", \\\"{x:1002,y:781,t:1527872925716};\\\", \\\"{x:989,y:775,t:1527872925734};\\\", \\\"{x:974,y:767,t:1527872925751};\\\", \\\"{x:959,y:759,t:1527872925767};\\\", \\\"{x:942,y:750,t:1527872925783};\\\", \\\"{x:926,y:743,t:1527872925800};\\\", \\\"{x:910,y:737,t:1527872925817};\\\", \\\"{x:897,y:734,t:1527872925833};\\\", \\\"{x:869,y:730,t:1527872925850};\\\", \\\"{x:847,y:728,t:1527872925867};\\\", \\\"{x:822,y:722,t:1527872925884};\\\", \\\"{x:800,y:715,t:1527872925900};\\\", \\\"{x:782,y:711,t:1527872925917};\\\", \\\"{x:769,y:706,t:1527872925934};\\\", \\\"{x:754,y:702,t:1527872925951};\\\", \\\"{x:739,y:698,t:1527872925968};\\\", \\\"{x:724,y:692,t:1527872925983};\\\", \\\"{x:703,y:687,t:1527872926001};\\\", \\\"{x:682,y:680,t:1527872926018};\\\", \\\"{x:661,y:673,t:1527872926034};\\\", \\\"{x:631,y:661,t:1527872926051};\\\", \\\"{x:614,y:653,t:1527872926068};\\\", \\\"{x:601,y:643,t:1527872926085};\\\", \\\"{x:587,y:634,t:1527872926100};\\\", \\\"{x:570,y:622,t:1527872926117};\\\", \\\"{x:550,y:608,t:1527872926141};\\\", \\\"{x:536,y:600,t:1527872926157};\\\", \\\"{x:527,y:595,t:1527872926173};\\\", \\\"{x:522,y:594,t:1527872926190};\\\", \\\"{x:512,y:590,t:1527872926207};\\\", \\\"{x:505,y:587,t:1527872926224};\\\", \\\"{x:499,y:586,t:1527872926241};\\\", \\\"{x:494,y:585,t:1527872926257};\\\", \\\"{x:492,y:585,t:1527872926273};\\\", \\\"{x:490,y:583,t:1527872926290};\\\", \\\"{x:487,y:580,t:1527872926308};\\\", \\\"{x:481,y:575,t:1527872926324};\\\", \\\"{x:477,y:574,t:1527872926341};\\\", \\\"{x:473,y:573,t:1527872926357};\\\", \\\"{x:471,y:572,t:1527872926374};\\\", \\\"{x:469,y:572,t:1527872926390};\\\", \\\"{x:467,y:572,t:1527872926407};\\\", \\\"{x:463,y:572,t:1527872926424};\\\", \\\"{x:458,y:572,t:1527872926440};\\\", \\\"{x:450,y:572,t:1527872926458};\\\", \\\"{x:437,y:572,t:1527872926473};\\\", \\\"{x:428,y:572,t:1527872926490};\\\", \\\"{x:416,y:572,t:1527872926507};\\\", \\\"{x:409,y:572,t:1527872926525};\\\", \\\"{x:398,y:572,t:1527872926540};\\\", \\\"{x:378,y:572,t:1527872926558};\\\", \\\"{x:362,y:572,t:1527872926575};\\\", \\\"{x:347,y:572,t:1527872926591};\\\", \\\"{x:338,y:572,t:1527872926607};\\\", \\\"{x:335,y:572,t:1527872926625};\\\", \\\"{x:332,y:572,t:1527872926641};\\\", \\\"{x:331,y:572,t:1527872926683};\\\", \\\"{x:328,y:572,t:1527872926707};\\\", \\\"{x:326,y:572,t:1527872926779};\\\", \\\"{x:325,y:572,t:1527872926791};\\\", \\\"{x:320,y:572,t:1527872926808};\\\", \\\"{x:312,y:575,t:1527872926826};\\\", \\\"{x:306,y:576,t:1527872926841};\\\", \\\"{x:298,y:577,t:1527872926858};\\\", \\\"{x:288,y:579,t:1527872926873};\\\", \\\"{x:281,y:580,t:1527872926890};\\\", \\\"{x:277,y:581,t:1527872926907};\\\", \\\"{x:273,y:582,t:1527872926925};\\\", \\\"{x:266,y:584,t:1527872926941};\\\", \\\"{x:262,y:585,t:1527872926957};\\\", \\\"{x:258,y:587,t:1527872926974};\\\", \\\"{x:253,y:588,t:1527872926990};\\\", \\\"{x:248,y:590,t:1527872927007};\\\", \\\"{x:243,y:592,t:1527872927024};\\\", \\\"{x:231,y:595,t:1527872927041};\\\", \\\"{x:219,y:597,t:1527872927057};\\\", \\\"{x:208,y:598,t:1527872927074};\\\", \\\"{x:203,y:600,t:1527872927091};\\\", \\\"{x:199,y:600,t:1527872927107};\\\", \\\"{x:195,y:600,t:1527872927125};\\\", \\\"{x:192,y:600,t:1527872927141};\\\", \\\"{x:187,y:600,t:1527872927158};\\\", \\\"{x:184,y:600,t:1527872927175};\\\", \\\"{x:182,y:600,t:1527872927192};\\\", \\\"{x:181,y:600,t:1527872927211};\\\", \\\"{x:180,y:600,t:1527872927225};\\\", \\\"{x:179,y:599,t:1527872927242};\\\", \\\"{x:178,y:599,t:1527872927299};\\\", \\\"{x:178,y:598,t:1527872927308};\\\", \\\"{x:178,y:597,t:1527872927325};\\\", \\\"{x:181,y:594,t:1527872927341};\\\", \\\"{x:185,y:593,t:1527872927358};\\\", \\\"{x:196,y:589,t:1527872927376};\\\", \\\"{x:207,y:587,t:1527872927392};\\\", \\\"{x:224,y:583,t:1527872927407};\\\", \\\"{x:242,y:579,t:1527872927426};\\\", \\\"{x:265,y:577,t:1527872927441};\\\", \\\"{x:345,y:562,t:1527872927458};\\\", \\\"{x:409,y:546,t:1527872927474};\\\", \\\"{x:441,y:540,t:1527872927491};\\\", \\\"{x:472,y:533,t:1527872927508};\\\", \\\"{x:486,y:531,t:1527872927524};\\\", \\\"{x:491,y:531,t:1527872927542};\\\", \\\"{x:492,y:530,t:1527872927558};\\\", \\\"{x:493,y:530,t:1527872927683};\\\", \\\"{x:494,y:532,t:1527872927691};\\\", \\\"{x:495,y:537,t:1527872927709};\\\", \\\"{x:498,y:543,t:1527872927724};\\\", \\\"{x:512,y:552,t:1527872927742};\\\", \\\"{x:536,y:559,t:1527872927758};\\\", \\\"{x:567,y:565,t:1527872927774};\\\", \\\"{x:592,y:567,t:1527872927792};\\\", \\\"{x:611,y:567,t:1527872927809};\\\", \\\"{x:630,y:567,t:1527872927825};\\\", \\\"{x:639,y:567,t:1527872927841};\\\", \\\"{x:644,y:566,t:1527872927859};\\\", \\\"{x:649,y:563,t:1527872927874};\\\", \\\"{x:652,y:559,t:1527872927891};\\\", \\\"{x:655,y:556,t:1527872927909};\\\", \\\"{x:657,y:553,t:1527872927926};\\\", \\\"{x:658,y:553,t:1527872927941};\\\", \\\"{x:656,y:553,t:1527872928011};\\\", \\\"{x:655,y:553,t:1527872928025};\\\", \\\"{x:648,y:554,t:1527872928042};\\\", \\\"{x:639,y:557,t:1527872928060};\\\", \\\"{x:631,y:558,t:1527872928075};\\\", \\\"{x:624,y:560,t:1527872928091};\\\", \\\"{x:620,y:561,t:1527872928109};\\\", \\\"{x:617,y:562,t:1527872928125};\\\", \\\"{x:616,y:562,t:1527872928141};\\\", \\\"{x:615,y:562,t:1527872928178};\\\", \\\"{x:614,y:562,t:1527872928194};\\\", \\\"{x:612,y:562,t:1527872928208};\\\", \\\"{x:608,y:562,t:1527872928225};\\\", \\\"{x:602,y:562,t:1527872928241};\\\", \\\"{x:596,y:562,t:1527872928259};\\\", \\\"{x:590,y:562,t:1527872928275};\\\", \\\"{x:585,y:561,t:1527872928291};\\\", \\\"{x:576,y:560,t:1527872928309};\\\", \\\"{x:567,y:560,t:1527872928326};\\\", \\\"{x:552,y:559,t:1527872928341};\\\", \\\"{x:536,y:559,t:1527872928358};\\\", \\\"{x:517,y:559,t:1527872928375};\\\", \\\"{x:501,y:559,t:1527872928392};\\\", \\\"{x:490,y:559,t:1527872928409};\\\", \\\"{x:483,y:559,t:1527872928425};\\\", \\\"{x:473,y:559,t:1527872928442};\\\", \\\"{x:470,y:559,t:1527872928458};\\\", \\\"{x:466,y:559,t:1527872928476};\\\", \\\"{x:462,y:559,t:1527872928492};\\\", \\\"{x:456,y:559,t:1527872928510};\\\", \\\"{x:448,y:557,t:1527872928525};\\\", \\\"{x:442,y:557,t:1527872928542};\\\", \\\"{x:434,y:557,t:1527872928560};\\\", \\\"{x:429,y:557,t:1527872928575};\\\", \\\"{x:425,y:557,t:1527872928592};\\\", \\\"{x:423,y:557,t:1527872928610};\\\", \\\"{x:422,y:557,t:1527872928626};\\\", \\\"{x:419,y:557,t:1527872928643};\\\", \\\"{x:415,y:557,t:1527872928660};\\\", \\\"{x:409,y:557,t:1527872928676};\\\", \\\"{x:402,y:557,t:1527872928693};\\\", \\\"{x:399,y:557,t:1527872928710};\\\", \\\"{x:397,y:557,t:1527872928726};\\\", \\\"{x:396,y:557,t:1527872928787};\\\", \\\"{x:395,y:557,t:1527872928811};\\\", \\\"{x:394,y:558,t:1527872928827};\\\", \\\"{x:393,y:561,t:1527872928842};\\\", \\\"{x:391,y:562,t:1527872928860};\\\", \\\"{x:390,y:564,t:1527872928876};\\\", \\\"{x:388,y:566,t:1527872928893};\\\", \\\"{x:387,y:566,t:1527872928910};\\\", \\\"{x:385,y:568,t:1527872928927};\\\", \\\"{x:384,y:569,t:1527872928942};\\\", \\\"{x:380,y:571,t:1527872928961};\\\", \\\"{x:376,y:572,t:1527872928977};\\\", \\\"{x:371,y:574,t:1527872928993};\\\", \\\"{x:364,y:577,t:1527872929011};\\\", \\\"{x:353,y:581,t:1527872929026};\\\", \\\"{x:349,y:582,t:1527872929042};\\\", \\\"{x:340,y:585,t:1527872929059};\\\", \\\"{x:335,y:586,t:1527872929076};\\\", \\\"{x:331,y:586,t:1527872929092};\\\", \\\"{x:330,y:586,t:1527872929109};\\\", \\\"{x:329,y:586,t:1527872929137};\\\", \\\"{x:328,y:586,t:1527872929146};\\\", \\\"{x:327,y:586,t:1527872929159};\\\", \\\"{x:324,y:586,t:1527872929175};\\\", \\\"{x:320,y:585,t:1527872929193};\\\", \\\"{x:317,y:585,t:1527872929210};\\\", \\\"{x:316,y:584,t:1527872929226};\\\", \\\"{x:316,y:583,t:1527872929283};\\\", \\\"{x:316,y:581,t:1527872929301};\\\", \\\"{x:318,y:578,t:1527872929310};\\\", \\\"{x:324,y:575,t:1527872929326};\\\", \\\"{x:330,y:573,t:1527872929344};\\\", \\\"{x:341,y:569,t:1527872929359};\\\", \\\"{x:352,y:565,t:1527872929376};\\\", \\\"{x:368,y:561,t:1527872929392};\\\", \\\"{x:392,y:557,t:1527872929409};\\\", \\\"{x:439,y:549,t:1527872929426};\\\", \\\"{x:463,y:547,t:1527872929442};\\\", \\\"{x:476,y:542,t:1527872929460};\\\", \\\"{x:487,y:541,t:1527872929477};\\\", \\\"{x:489,y:540,t:1527872929492};\\\", \\\"{x:491,y:540,t:1527872929674};\\\", \\\"{x:492,y:540,t:1527872929682};\\\", \\\"{x:493,y:540,t:1527872929694};\\\", \\\"{x:494,y:540,t:1527872929709};\\\", \\\"{x:496,y:540,t:1527872929726};\\\", \\\"{x:497,y:540,t:1527872929743};\\\", \\\"{x:498,y:540,t:1527872929759};\\\", \\\"{x:499,y:540,t:1527872929777};\\\", \\\"{x:499,y:541,t:1527872929793};\\\", \\\"{x:500,y:541,t:1527872929809};\\\", \\\"{x:502,y:543,t:1527872929826};\\\", \\\"{x:503,y:544,t:1527872929844};\\\", \\\"{x:505,y:546,t:1527872929860};\\\", \\\"{x:506,y:546,t:1527872929876};\\\", \\\"{x:509,y:547,t:1527872929894};\\\", \\\"{x:510,y:548,t:1527872929910};\\\", \\\"{x:512,y:549,t:1527872929926};\\\", \\\"{x:512,y:550,t:1527872929946};\\\", \\\"{x:512,y:551,t:1527872929960};\\\", \\\"{x:512,y:552,t:1527872929978};\\\", \\\"{x:513,y:552,t:1527872930107};\\\", \\\"{x:515,y:552,t:1527872930123};\\\", \\\"{x:517,y:552,t:1527872930131};\\\", \\\"{x:518,y:552,t:1527872930143};\\\", \\\"{x:525,y:552,t:1527872930161};\\\", \\\"{x:534,y:552,t:1527872930178};\\\", \\\"{x:547,y:549,t:1527872930194};\\\", \\\"{x:561,y:549,t:1527872930211};\\\", \\\"{x:569,y:549,t:1527872930228};\\\", \\\"{x:580,y:549,t:1527872930244};\\\", \\\"{x:585,y:549,t:1527872930261};\\\", \\\"{x:595,y:549,t:1527872930278};\\\", \\\"{x:606,y:549,t:1527872930294};\\\", \\\"{x:618,y:549,t:1527872930311};\\\", \\\"{x:632,y:549,t:1527872930328};\\\", \\\"{x:642,y:549,t:1527872930343};\\\", \\\"{x:651,y:549,t:1527872930361};\\\", \\\"{x:660,y:549,t:1527872930378};\\\", \\\"{x:674,y:549,t:1527872930394};\\\", \\\"{x:699,y:544,t:1527872930410};\\\", \\\"{x:718,y:544,t:1527872930428};\\\", \\\"{x:741,y:544,t:1527872930446};\\\", \\\"{x:759,y:544,t:1527872930460};\\\", \\\"{x:773,y:544,t:1527872930477};\\\", \\\"{x:777,y:544,t:1527872930493};\\\", \\\"{x:782,y:545,t:1527872930510};\\\", \\\"{x:786,y:546,t:1527872930526};\\\", \\\"{x:789,y:548,t:1527872930544};\\\", \\\"{x:788,y:549,t:1527872930602};\\\", \\\"{x:784,y:551,t:1527872930610};\\\", \\\"{x:768,y:558,t:1527872930628};\\\", \\\"{x:741,y:565,t:1527872930643};\\\", \\\"{x:702,y:576,t:1527872930662};\\\", \\\"{x:643,y:588,t:1527872930678};\\\", \\\"{x:582,y:594,t:1527872930695};\\\", \\\"{x:550,y:601,t:1527872930710};\\\", \\\"{x:523,y:601,t:1527872930727};\\\", \\\"{x:500,y:602,t:1527872930744};\\\", \\\"{x:478,y:602,t:1527872930761};\\\", \\\"{x:457,y:605,t:1527872930777};\\\", \\\"{x:424,y:609,t:1527872930794};\\\", \\\"{x:402,y:611,t:1527872930811};\\\", \\\"{x:382,y:611,t:1527872930828};\\\", \\\"{x:364,y:611,t:1527872930843};\\\", \\\"{x:353,y:611,t:1527872930861};\\\", \\\"{x:344,y:610,t:1527872930877};\\\", \\\"{x:337,y:609,t:1527872930894};\\\", \\\"{x:328,y:607,t:1527872930910};\\\", \\\"{x:315,y:603,t:1527872930928};\\\", \\\"{x:298,y:601,t:1527872930944};\\\", \\\"{x:286,y:601,t:1527872930961};\\\", \\\"{x:274,y:601,t:1527872930978};\\\", \\\"{x:266,y:601,t:1527872930997};\\\", \\\"{x:262,y:602,t:1527872931010};\\\", \\\"{x:260,y:603,t:1527872931027};\\\", \\\"{x:253,y:606,t:1527872931044};\\\", \\\"{x:245,y:608,t:1527872931060};\\\", \\\"{x:237,y:610,t:1527872931077};\\\", \\\"{x:225,y:611,t:1527872931094};\\\", \\\"{x:219,y:612,t:1527872931110};\\\", \\\"{x:211,y:614,t:1527872931128};\\\", \\\"{x:207,y:615,t:1527872931144};\\\", \\\"{x:200,y:617,t:1527872931160};\\\", \\\"{x:195,y:620,t:1527872931178};\\\", \\\"{x:180,y:625,t:1527872931194};\\\", \\\"{x:171,y:627,t:1527872931210};\\\", \\\"{x:163,y:629,t:1527872931228};\\\", \\\"{x:160,y:631,t:1527872931244};\\\", \\\"{x:159,y:631,t:1527872931315};\\\", \\\"{x:159,y:632,t:1527872931327};\\\", \\\"{x:157,y:633,t:1527872931344};\\\", \\\"{x:156,y:635,t:1527872931361};\\\", \\\"{x:156,y:637,t:1527872931842};\\\", \\\"{x:162,y:643,t:1527872931850};\\\", \\\"{x:172,y:646,t:1527872931862};\\\", \\\"{x:205,y:655,t:1527872931879};\\\", \\\"{x:261,y:673,t:1527872931894};\\\", \\\"{x:322,y:690,t:1527872931912};\\\", \\\"{x:376,y:701,t:1527872931929};\\\", \\\"{x:418,y:707,t:1527872931944};\\\", \\\"{x:450,y:711,t:1527872931963};\\\", \\\"{x:480,y:717,t:1527872931978};\\\", \\\"{x:492,y:718,t:1527872931995};\\\", \\\"{x:495,y:719,t:1527872932011};\\\", \\\"{x:497,y:719,t:1527872932029};\\\", \\\"{x:499,y:720,t:1527872932044};\\\" ] }, { \\\"rt\\\": 12040, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 131223, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-12 PM-12 PM-C -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:720,t:1527872934222};\\\", \\\"{x:506,y:712,t:1527872934234};\\\", \\\"{x:519,y:692,t:1527872934251};\\\", \\\"{x:529,y:674,t:1527872934267};\\\", \\\"{x:537,y:657,t:1527872934284};\\\", \\\"{x:548,y:636,t:1527872934301};\\\", \\\"{x:553,y:623,t:1527872934318};\\\", \\\"{x:558,y:606,t:1527872934335};\\\", \\\"{x:561,y:595,t:1527872934351};\\\", \\\"{x:563,y:584,t:1527872934367};\\\", \\\"{x:571,y:568,t:1527872934384};\\\", \\\"{x:584,y:549,t:1527872934401};\\\", \\\"{x:597,y:532,t:1527872934418};\\\", \\\"{x:612,y:519,t:1527872934435};\\\", \\\"{x:626,y:511,t:1527872934451};\\\", \\\"{x:646,y:501,t:1527872934468};\\\", \\\"{x:663,y:494,t:1527872934483};\\\", \\\"{x:675,y:489,t:1527872934500};\\\", \\\"{x:683,y:487,t:1527872934518};\\\", \\\"{x:684,y:486,t:1527872934534};\\\", \\\"{x:685,y:486,t:1527872934551};\\\", \\\"{x:687,y:486,t:1527872934568};\\\", \\\"{x:692,y:486,t:1527872934585};\\\", \\\"{x:699,y:486,t:1527872934601};\\\", \\\"{x:710,y:486,t:1527872934618};\\\", \\\"{x:722,y:485,t:1527872934635};\\\", \\\"{x:744,y:485,t:1527872934651};\\\", \\\"{x:775,y:485,t:1527872934668};\\\", \\\"{x:822,y:485,t:1527872934685};\\\", \\\"{x:881,y:485,t:1527872934701};\\\", \\\"{x:953,y:485,t:1527872934718};\\\", \\\"{x:1048,y:495,t:1527872934735};\\\", \\\"{x:1092,y:499,t:1527872934752};\\\", \\\"{x:1127,y:505,t:1527872934768};\\\", \\\"{x:1150,y:505,t:1527872934785};\\\", \\\"{x:1172,y:508,t:1527872934801};\\\", \\\"{x:1191,y:512,t:1527872934819};\\\", \\\"{x:1208,y:517,t:1527872934835};\\\", \\\"{x:1229,y:523,t:1527872934852};\\\", \\\"{x:1248,y:528,t:1527872934868};\\\", \\\"{x:1274,y:535,t:1527872934885};\\\", \\\"{x:1297,y:545,t:1527872934902};\\\", \\\"{x:1320,y:557,t:1527872934919};\\\", \\\"{x:1327,y:561,t:1527872934935};\\\", \\\"{x:1330,y:564,t:1527872934952};\\\", \\\"{x:1331,y:564,t:1527872934968};\\\", \\\"{x:1332,y:566,t:1527872934999};\\\", \\\"{x:1332,y:568,t:1527872935015};\\\", \\\"{x:1332,y:570,t:1527872935023};\\\", \\\"{x:1332,y:575,t:1527872935034};\\\", \\\"{x:1332,y:584,t:1527872935052};\\\", \\\"{x:1332,y:597,t:1527872935068};\\\", \\\"{x:1332,y:612,t:1527872935085};\\\", \\\"{x:1333,y:630,t:1527872935103};\\\", \\\"{x:1338,y:650,t:1527872935118};\\\", \\\"{x:1343,y:666,t:1527872935134};\\\", \\\"{x:1346,y:675,t:1527872935152};\\\", \\\"{x:1347,y:679,t:1527872935169};\\\", \\\"{x:1350,y:686,t:1527872935185};\\\", \\\"{x:1351,y:690,t:1527872935203};\\\", \\\"{x:1350,y:695,t:1527872935218};\\\", \\\"{x:1347,y:700,t:1527872935236};\\\", \\\"{x:1346,y:702,t:1527872935252};\\\", \\\"{x:1342,y:707,t:1527872935268};\\\", \\\"{x:1341,y:709,t:1527872935285};\\\", \\\"{x:1339,y:711,t:1527872935303};\\\", \\\"{x:1339,y:718,t:1527872935318};\\\", \\\"{x:1339,y:726,t:1527872935335};\\\", \\\"{x:1339,y:736,t:1527872935353};\\\", \\\"{x:1340,y:746,t:1527872935369};\\\", \\\"{x:1341,y:750,t:1527872935386};\\\", \\\"{x:1341,y:753,t:1527872935402};\\\", \\\"{x:1341,y:757,t:1527872935419};\\\", \\\"{x:1344,y:762,t:1527872935435};\\\", \\\"{x:1345,y:767,t:1527872935452};\\\", \\\"{x:1346,y:774,t:1527872935470};\\\", \\\"{x:1348,y:781,t:1527872935486};\\\", \\\"{x:1348,y:785,t:1527872935502};\\\", \\\"{x:1348,y:790,t:1527872935519};\\\", \\\"{x:1349,y:794,t:1527872935535};\\\", \\\"{x:1349,y:798,t:1527872935553};\\\", \\\"{x:1349,y:801,t:1527872935569};\\\", \\\"{x:1349,y:802,t:1527872935586};\\\", \\\"{x:1349,y:803,t:1527872935607};\\\", \\\"{x:1349,y:804,t:1527872935619};\\\", \\\"{x:1350,y:806,t:1527872935635};\\\", \\\"{x:1350,y:807,t:1527872935663};\\\", \\\"{x:1350,y:808,t:1527872935679};\\\", \\\"{x:1350,y:809,t:1527872935719};\\\", \\\"{x:1350,y:810,t:1527872935904};\\\", \\\"{x:1350,y:811,t:1527872935919};\\\", \\\"{x:1351,y:814,t:1527872935936};\\\", \\\"{x:1351,y:816,t:1527872935952};\\\", \\\"{x:1352,y:818,t:1527872935970};\\\", \\\"{x:1353,y:821,t:1527872935986};\\\", \\\"{x:1353,y:825,t:1527872936002};\\\", \\\"{x:1354,y:829,t:1527872936019};\\\", \\\"{x:1355,y:836,t:1527872936036};\\\", \\\"{x:1356,y:839,t:1527872936052};\\\", \\\"{x:1356,y:841,t:1527872936070};\\\", \\\"{x:1357,y:844,t:1527872936086};\\\", \\\"{x:1357,y:849,t:1527872936103};\\\", \\\"{x:1359,y:851,t:1527872936120};\\\", \\\"{x:1359,y:853,t:1527872936142};\\\", \\\"{x:1360,y:854,t:1527872936159};\\\", \\\"{x:1361,y:856,t:1527872936175};\\\", \\\"{x:1361,y:857,t:1527872936191};\\\", \\\"{x:1362,y:859,t:1527872936203};\\\", \\\"{x:1363,y:863,t:1527872936220};\\\", \\\"{x:1364,y:867,t:1527872936236};\\\", \\\"{x:1366,y:870,t:1527872936253};\\\", \\\"{x:1366,y:872,t:1527872936270};\\\", \\\"{x:1367,y:873,t:1527872936286};\\\", \\\"{x:1367,y:878,t:1527872936303};\\\", \\\"{x:1369,y:882,t:1527872936320};\\\", \\\"{x:1371,y:887,t:1527872936336};\\\", \\\"{x:1371,y:891,t:1527872936353};\\\", \\\"{x:1373,y:894,t:1527872936370};\\\", \\\"{x:1373,y:895,t:1527872936386};\\\", \\\"{x:1374,y:899,t:1527872936403};\\\", \\\"{x:1374,y:902,t:1527872936419};\\\", \\\"{x:1377,y:907,t:1527872936436};\\\", \\\"{x:1377,y:910,t:1527872936453};\\\", \\\"{x:1378,y:914,t:1527872936470};\\\", \\\"{x:1380,y:920,t:1527872936486};\\\", \\\"{x:1383,y:930,t:1527872936503};\\\", \\\"{x:1385,y:938,t:1527872936520};\\\", \\\"{x:1387,y:946,t:1527872936536};\\\", \\\"{x:1389,y:950,t:1527872936553};\\\", \\\"{x:1390,y:954,t:1527872936569};\\\", \\\"{x:1391,y:956,t:1527872936586};\\\", \\\"{x:1391,y:958,t:1527872936603};\\\", \\\"{x:1392,y:958,t:1527872936619};\\\", \\\"{x:1393,y:960,t:1527872936636};\\\", \\\"{x:1396,y:964,t:1527872936653};\\\", \\\"{x:1397,y:967,t:1527872936669};\\\", \\\"{x:1402,y:975,t:1527872936686};\\\", \\\"{x:1406,y:981,t:1527872936702};\\\", \\\"{x:1410,y:987,t:1527872936719};\\\", \\\"{x:1417,y:996,t:1527872936736};\\\", \\\"{x:1422,y:1006,t:1527872936752};\\\", \\\"{x:1427,y:1016,t:1527872936770};\\\", \\\"{x:1432,y:1026,t:1527872936786};\\\", \\\"{x:1436,y:1034,t:1527872936803};\\\", \\\"{x:1440,y:1038,t:1527872936820};\\\", \\\"{x:1441,y:1039,t:1527872936836};\\\", \\\"{x:1441,y:1040,t:1527872936903};\\\", \\\"{x:1440,y:1040,t:1527872936926};\\\", \\\"{x:1438,y:1040,t:1527872936936};\\\", \\\"{x:1434,y:1040,t:1527872936952};\\\", \\\"{x:1429,y:1040,t:1527872936969};\\\", \\\"{x:1422,y:1039,t:1527872936986};\\\", \\\"{x:1414,y:1038,t:1527872937003};\\\", \\\"{x:1403,y:1036,t:1527872937019};\\\", \\\"{x:1394,y:1033,t:1527872937035};\\\", \\\"{x:1383,y:1028,t:1527872937053};\\\", \\\"{x:1365,y:1019,t:1527872937070};\\\", \\\"{x:1361,y:1013,t:1527872937086};\\\", \\\"{x:1354,y:1010,t:1527872937102};\\\", \\\"{x:1352,y:1007,t:1527872937120};\\\", \\\"{x:1350,y:1007,t:1527872937137};\\\", \\\"{x:1347,y:1006,t:1527872937153};\\\", \\\"{x:1344,y:1004,t:1527872937170};\\\", \\\"{x:1342,y:999,t:1527872937187};\\\", \\\"{x:1341,y:997,t:1527872937203};\\\", \\\"{x:1340,y:993,t:1527872937220};\\\", \\\"{x:1339,y:989,t:1527872937237};\\\", \\\"{x:1337,y:987,t:1527872937254};\\\", \\\"{x:1336,y:985,t:1527872937271};\\\", \\\"{x:1332,y:982,t:1527872937286};\\\", \\\"{x:1330,y:981,t:1527872937318};\\\", \\\"{x:1331,y:982,t:1527872937376};\\\", \\\"{x:1335,y:985,t:1527872937388};\\\", \\\"{x:1337,y:988,t:1527872937403};\\\", \\\"{x:1340,y:990,t:1527872937420};\\\", \\\"{x:1342,y:990,t:1527872937437};\\\", \\\"{x:1343,y:990,t:1527872937454};\\\", \\\"{x:1343,y:988,t:1527872937479};\\\", \\\"{x:1342,y:982,t:1527872937487};\\\", \\\"{x:1335,y:971,t:1527872937503};\\\", \\\"{x:1330,y:962,t:1527872937520};\\\", \\\"{x:1317,y:951,t:1527872937538};\\\", \\\"{x:1309,y:946,t:1527872937554};\\\", \\\"{x:1303,y:941,t:1527872937570};\\\", \\\"{x:1293,y:935,t:1527872937587};\\\", \\\"{x:1282,y:930,t:1527872937604};\\\", \\\"{x:1271,y:925,t:1527872937620};\\\", \\\"{x:1259,y:917,t:1527872937638};\\\", \\\"{x:1250,y:910,t:1527872937655};\\\", \\\"{x:1247,y:908,t:1527872937671};\\\", \\\"{x:1243,y:905,t:1527872937687};\\\", \\\"{x:1239,y:902,t:1527872937704};\\\", \\\"{x:1232,y:898,t:1527872937721};\\\", \\\"{x:1226,y:894,t:1527872937737};\\\", \\\"{x:1219,y:888,t:1527872937754};\\\", \\\"{x:1214,y:881,t:1527872937770};\\\", \\\"{x:1210,y:876,t:1527872937787};\\\", \\\"{x:1207,y:872,t:1527872937804};\\\", \\\"{x:1206,y:871,t:1527872937821};\\\", \\\"{x:1206,y:870,t:1527872937837};\\\", \\\"{x:1206,y:866,t:1527872937854};\\\", \\\"{x:1203,y:862,t:1527872937871};\\\", \\\"{x:1203,y:860,t:1527872937887};\\\", \\\"{x:1203,y:858,t:1527872937904};\\\", \\\"{x:1203,y:857,t:1527872937921};\\\", \\\"{x:1203,y:856,t:1527872937938};\\\", \\\"{x:1203,y:854,t:1527872937954};\\\", \\\"{x:1203,y:853,t:1527872937975};\\\", \\\"{x:1203,y:852,t:1527872937988};\\\", \\\"{x:1204,y:851,t:1527872938004};\\\", \\\"{x:1206,y:850,t:1527872938022};\\\", \\\"{x:1210,y:848,t:1527872938038};\\\", \\\"{x:1212,y:845,t:1527872938055};\\\", \\\"{x:1214,y:842,t:1527872938071};\\\", \\\"{x:1214,y:841,t:1527872938095};\\\", \\\"{x:1214,y:842,t:1527872938214};\\\", \\\"{x:1214,y:844,t:1527872938223};\\\", \\\"{x:1214,y:847,t:1527872938237};\\\", \\\"{x:1214,y:856,t:1527872938255};\\\", \\\"{x:1214,y:863,t:1527872938271};\\\", \\\"{x:1214,y:868,t:1527872938287};\\\", \\\"{x:1214,y:872,t:1527872938305};\\\", \\\"{x:1214,y:878,t:1527872938322};\\\", \\\"{x:1214,y:884,t:1527872938337};\\\", \\\"{x:1216,y:890,t:1527872938354};\\\", \\\"{x:1216,y:895,t:1527872938371};\\\", \\\"{x:1216,y:899,t:1527872938389};\\\", \\\"{x:1216,y:902,t:1527872938404};\\\", \\\"{x:1216,y:906,t:1527872938422};\\\", \\\"{x:1216,y:909,t:1527872938437};\\\", \\\"{x:1216,y:914,t:1527872938455};\\\", \\\"{x:1216,y:919,t:1527872938471};\\\", \\\"{x:1217,y:923,t:1527872938488};\\\", \\\"{x:1217,y:925,t:1527872938504};\\\", \\\"{x:1217,y:928,t:1527872938521};\\\", \\\"{x:1217,y:932,t:1527872938538};\\\", \\\"{x:1217,y:935,t:1527872938554};\\\", \\\"{x:1217,y:940,t:1527872938571};\\\", \\\"{x:1217,y:944,t:1527872938587};\\\", \\\"{x:1217,y:947,t:1527872938603};\\\", \\\"{x:1217,y:949,t:1527872938620};\\\", \\\"{x:1218,y:954,t:1527872938638};\\\", \\\"{x:1218,y:956,t:1527872938653};\\\", \\\"{x:1219,y:961,t:1527872938671};\\\", \\\"{x:1219,y:962,t:1527872938688};\\\", \\\"{x:1220,y:963,t:1527872938704};\\\", \\\"{x:1220,y:964,t:1527872938721};\\\", \\\"{x:1220,y:965,t:1527872938742};\\\", \\\"{x:1220,y:964,t:1527872938871};\\\", \\\"{x:1220,y:960,t:1527872938889};\\\", \\\"{x:1220,y:953,t:1527872938905};\\\", \\\"{x:1220,y:948,t:1527872938921};\\\", \\\"{x:1220,y:939,t:1527872938939};\\\", \\\"{x:1220,y:931,t:1527872938956};\\\", \\\"{x:1220,y:920,t:1527872938971};\\\", \\\"{x:1220,y:911,t:1527872938988};\\\", \\\"{x:1220,y:905,t:1527872939005};\\\", \\\"{x:1220,y:899,t:1527872939021};\\\", \\\"{x:1220,y:891,t:1527872939039};\\\", \\\"{x:1220,y:884,t:1527872939054};\\\", \\\"{x:1220,y:875,t:1527872939071};\\\", \\\"{x:1220,y:871,t:1527872939088};\\\", \\\"{x:1220,y:866,t:1527872939105};\\\", \\\"{x:1220,y:860,t:1527872939121};\\\", \\\"{x:1220,y:855,t:1527872939139};\\\", \\\"{x:1219,y:852,t:1527872939155};\\\", \\\"{x:1219,y:848,t:1527872939171};\\\", \\\"{x:1219,y:845,t:1527872939188};\\\", \\\"{x:1219,y:843,t:1527872939206};\\\", \\\"{x:1219,y:841,t:1527872939221};\\\", \\\"{x:1219,y:836,t:1527872939238};\\\", \\\"{x:1219,y:833,t:1527872939256};\\\", \\\"{x:1219,y:831,t:1527872939272};\\\", \\\"{x:1219,y:829,t:1527872939288};\\\", \\\"{x:1219,y:825,t:1527872939306};\\\", \\\"{x:1219,y:822,t:1527872939322};\\\", \\\"{x:1218,y:821,t:1527872939338};\\\", \\\"{x:1218,y:819,t:1527872939355};\\\", \\\"{x:1219,y:819,t:1527872939558};\\\", \\\"{x:1221,y:819,t:1527872939572};\\\", \\\"{x:1223,y:820,t:1527872939588};\\\", \\\"{x:1226,y:821,t:1527872939605};\\\", \\\"{x:1227,y:822,t:1527872939654};\\\", \\\"{x:1227,y:823,t:1527872939695};\\\", \\\"{x:1227,y:824,t:1527872939710};\\\", \\\"{x:1227,y:825,t:1527872939726};\\\", \\\"{x:1227,y:826,t:1527872939743};\\\", \\\"{x:1226,y:828,t:1527872939755};\\\", \\\"{x:1226,y:830,t:1527872939772};\\\", \\\"{x:1226,y:834,t:1527872939790};\\\", \\\"{x:1226,y:838,t:1527872939805};\\\", \\\"{x:1231,y:844,t:1527872939823};\\\", \\\"{x:1242,y:852,t:1527872939839};\\\", \\\"{x:1251,y:857,t:1527872939856};\\\", \\\"{x:1260,y:862,t:1527872939872};\\\", \\\"{x:1267,y:866,t:1527872939890};\\\", \\\"{x:1271,y:870,t:1527872939906};\\\", \\\"{x:1276,y:875,t:1527872939923};\\\", \\\"{x:1281,y:880,t:1527872939940};\\\", \\\"{x:1292,y:890,t:1527872939955};\\\", \\\"{x:1304,y:899,t:1527872939972};\\\", \\\"{x:1313,y:905,t:1527872939990};\\\", \\\"{x:1325,y:913,t:1527872940006};\\\", \\\"{x:1337,y:922,t:1527872940023};\\\", \\\"{x:1342,y:925,t:1527872940039};\\\", \\\"{x:1347,y:930,t:1527872940055};\\\", \\\"{x:1355,y:937,t:1527872940072};\\\", \\\"{x:1359,y:942,t:1527872940089};\\\", \\\"{x:1363,y:947,t:1527872940105};\\\", \\\"{x:1368,y:952,t:1527872940122};\\\", \\\"{x:1374,y:957,t:1527872940140};\\\", \\\"{x:1380,y:961,t:1527872940157};\\\", \\\"{x:1382,y:963,t:1527872940172};\\\", \\\"{x:1383,y:964,t:1527872940189};\\\", \\\"{x:1382,y:964,t:1527872940253};\\\", \\\"{x:1381,y:965,t:1527872940262};\\\", \\\"{x:1379,y:965,t:1527872940272};\\\", \\\"{x:1374,y:965,t:1527872940289};\\\", \\\"{x:1371,y:966,t:1527872940305};\\\", \\\"{x:1367,y:967,t:1527872940321};\\\", \\\"{x:1364,y:967,t:1527872940339};\\\", \\\"{x:1360,y:967,t:1527872940356};\\\", \\\"{x:1359,y:967,t:1527872940372};\\\", \\\"{x:1354,y:965,t:1527872940390};\\\", \\\"{x:1350,y:963,t:1527872940406};\\\", \\\"{x:1350,y:962,t:1527872940679};\\\", \\\"{x:1350,y:961,t:1527872940690};\\\", \\\"{x:1350,y:959,t:1527872940706};\\\", \\\"{x:1352,y:953,t:1527872940724};\\\", \\\"{x:1352,y:949,t:1527872940740};\\\", \\\"{x:1353,y:945,t:1527872940756};\\\", \\\"{x:1354,y:937,t:1527872940773};\\\", \\\"{x:1354,y:934,t:1527872940790};\\\", \\\"{x:1354,y:930,t:1527872940807};\\\", \\\"{x:1354,y:923,t:1527872940823};\\\", \\\"{x:1354,y:919,t:1527872940839};\\\", \\\"{x:1354,y:916,t:1527872940856};\\\", \\\"{x:1354,y:912,t:1527872940872};\\\", \\\"{x:1353,y:910,t:1527872940889};\\\", \\\"{x:1353,y:908,t:1527872940905};\\\", \\\"{x:1353,y:906,t:1527872940923};\\\", \\\"{x:1353,y:905,t:1527872940939};\\\", \\\"{x:1353,y:903,t:1527872940956};\\\", \\\"{x:1353,y:902,t:1527872940973};\\\", \\\"{x:1353,y:899,t:1527872940990};\\\", \\\"{x:1353,y:897,t:1527872941023};\\\", \\\"{x:1353,y:896,t:1527872941367};\\\", \\\"{x:1351,y:896,t:1527872941383};\\\", \\\"{x:1350,y:896,t:1527872941390};\\\", \\\"{x:1347,y:895,t:1527872941407};\\\", \\\"{x:1336,y:892,t:1527872941424};\\\", \\\"{x:1322,y:884,t:1527872941441};\\\", \\\"{x:1293,y:872,t:1527872941456};\\\", \\\"{x:1255,y:857,t:1527872941473};\\\", \\\"{x:1203,y:838,t:1527872941490};\\\", \\\"{x:1129,y:818,t:1527872941507};\\\", \\\"{x:1045,y:793,t:1527872941524};\\\", \\\"{x:976,y:773,t:1527872941540};\\\", \\\"{x:925,y:758,t:1527872941558};\\\", \\\"{x:885,y:745,t:1527872941573};\\\", \\\"{x:847,y:731,t:1527872941591};\\\", \\\"{x:820,y:721,t:1527872941607};\\\", \\\"{x:798,y:710,t:1527872941623};\\\", \\\"{x:787,y:703,t:1527872941640};\\\", \\\"{x:782,y:698,t:1527872941657};\\\", \\\"{x:776,y:692,t:1527872941673};\\\", \\\"{x:771,y:685,t:1527872941690};\\\", \\\"{x:765,y:679,t:1527872941708};\\\", \\\"{x:753,y:674,t:1527872941723};\\\", \\\"{x:740,y:669,t:1527872941740};\\\", \\\"{x:723,y:666,t:1527872941757};\\\", \\\"{x:705,y:662,t:1527872941773};\\\", \\\"{x:667,y:657,t:1527872941791};\\\", \\\"{x:632,y:654,t:1527872941807};\\\", \\\"{x:597,y:648,t:1527872941825};\\\", \\\"{x:563,y:643,t:1527872941840};\\\", \\\"{x:533,y:637,t:1527872941857};\\\", \\\"{x:512,y:635,t:1527872941873};\\\", \\\"{x:497,y:632,t:1527872941890};\\\", \\\"{x:485,y:631,t:1527872941906};\\\", \\\"{x:478,y:630,t:1527872941924};\\\", \\\"{x:470,y:629,t:1527872941940};\\\", \\\"{x:461,y:629,t:1527872941957};\\\", \\\"{x:448,y:629,t:1527872941973};\\\", \\\"{x:441,y:629,t:1527872941990};\\\", \\\"{x:432,y:629,t:1527872942007};\\\", \\\"{x:416,y:629,t:1527872942024};\\\", \\\"{x:401,y:629,t:1527872942040};\\\", \\\"{x:386,y:629,t:1527872942057};\\\", \\\"{x:376,y:629,t:1527872942074};\\\", \\\"{x:372,y:629,t:1527872942091};\\\", \\\"{x:371,y:628,t:1527872942107};\\\", \\\"{x:369,y:628,t:1527872942126};\\\", \\\"{x:367,y:627,t:1527872942140};\\\", \\\"{x:362,y:625,t:1527872942157};\\\", \\\"{x:356,y:620,t:1527872942174};\\\", \\\"{x:350,y:614,t:1527872942191};\\\", \\\"{x:336,y:604,t:1527872942208};\\\", \\\"{x:312,y:592,t:1527872942223};\\\", \\\"{x:291,y:587,t:1527872942240};\\\", \\\"{x:271,y:582,t:1527872942258};\\\", \\\"{x:259,y:578,t:1527872942273};\\\", \\\"{x:248,y:573,t:1527872942293};\\\", \\\"{x:242,y:569,t:1527872942308};\\\", \\\"{x:236,y:566,t:1527872942324};\\\", \\\"{x:228,y:564,t:1527872942341};\\\", \\\"{x:220,y:560,t:1527872942357};\\\", \\\"{x:211,y:559,t:1527872942373};\\\", \\\"{x:207,y:558,t:1527872942390};\\\", \\\"{x:205,y:558,t:1527872942470};\\\", \\\"{x:204,y:558,t:1527872942478};\\\", \\\"{x:201,y:558,t:1527872942491};\\\", \\\"{x:196,y:558,t:1527872942508};\\\", \\\"{x:189,y:558,t:1527872942525};\\\", \\\"{x:184,y:558,t:1527872942540};\\\", \\\"{x:178,y:557,t:1527872942557};\\\", \\\"{x:165,y:555,t:1527872942575};\\\", \\\"{x:156,y:553,t:1527872942591};\\\", \\\"{x:152,y:553,t:1527872942607};\\\", \\\"{x:149,y:553,t:1527872942624};\\\", \\\"{x:146,y:553,t:1527872942641};\\\", \\\"{x:145,y:553,t:1527872942658};\\\", \\\"{x:143,y:553,t:1527872942759};\\\", \\\"{x:142,y:553,t:1527872943111};\\\", \\\"{x:144,y:556,t:1527872943123};\\\", \\\"{x:163,y:562,t:1527872943140};\\\", \\\"{x:188,y:575,t:1527872943158};\\\", \\\"{x:244,y:596,t:1527872943174};\\\", \\\"{x:283,y:607,t:1527872943190};\\\", \\\"{x:309,y:614,t:1527872943207};\\\", \\\"{x:329,y:619,t:1527872943224};\\\", \\\"{x:345,y:625,t:1527872943241};\\\", \\\"{x:359,y:630,t:1527872943258};\\\", \\\"{x:365,y:633,t:1527872943274};\\\", \\\"{x:367,y:634,t:1527872943290};\\\", \\\"{x:364,y:634,t:1527872943374};\\\", \\\"{x:359,y:632,t:1527872943382};\\\", \\\"{x:354,y:631,t:1527872943392};\\\", \\\"{x:339,y:627,t:1527872943408};\\\", \\\"{x:327,y:621,t:1527872943425};\\\", \\\"{x:306,y:613,t:1527872943442};\\\", \\\"{x:282,y:605,t:1527872943459};\\\", \\\"{x:261,y:596,t:1527872943475};\\\", \\\"{x:250,y:592,t:1527872943491};\\\", \\\"{x:241,y:587,t:1527872943508};\\\", \\\"{x:234,y:583,t:1527872943525};\\\", \\\"{x:228,y:580,t:1527872943542};\\\", \\\"{x:213,y:573,t:1527872943558};\\\", \\\"{x:200,y:568,t:1527872943575};\\\", \\\"{x:190,y:564,t:1527872943591};\\\", \\\"{x:182,y:562,t:1527872943608};\\\", \\\"{x:178,y:561,t:1527872943624};\\\", \\\"{x:175,y:560,t:1527872943642};\\\", \\\"{x:172,y:559,t:1527872943658};\\\", \\\"{x:171,y:558,t:1527872943675};\\\", \\\"{x:167,y:556,t:1527872943692};\\\", \\\"{x:160,y:553,t:1527872943708};\\\", \\\"{x:156,y:551,t:1527872943725};\\\", \\\"{x:152,y:550,t:1527872943741};\\\", \\\"{x:149,y:549,t:1527872943758};\\\", \\\"{x:150,y:549,t:1527872944055};\\\", \\\"{x:160,y:553,t:1527872944062};\\\", \\\"{x:172,y:559,t:1527872944075};\\\", \\\"{x:197,y:567,t:1527872944092};\\\", \\\"{x:230,y:577,t:1527872944109};\\\", \\\"{x:263,y:585,t:1527872944125};\\\", \\\"{x:280,y:592,t:1527872944140};\\\", \\\"{x:286,y:593,t:1527872944157};\\\", \\\"{x:287,y:593,t:1527872944174};\\\", \\\"{x:287,y:594,t:1527872944302};\\\", \\\"{x:288,y:594,t:1527872944310};\\\", \\\"{x:287,y:595,t:1527872944367};\\\", \\\"{x:284,y:595,t:1527872944375};\\\", \\\"{x:272,y:595,t:1527872944393};\\\", \\\"{x:260,y:595,t:1527872944409};\\\", \\\"{x:243,y:591,t:1527872944426};\\\", \\\"{x:223,y:586,t:1527872944442};\\\", \\\"{x:211,y:585,t:1527872944459};\\\", \\\"{x:203,y:583,t:1527872944475};\\\", \\\"{x:198,y:581,t:1527872944494};\\\", \\\"{x:197,y:581,t:1527872944510};\\\", \\\"{x:197,y:580,t:1527872944526};\\\", \\\"{x:195,y:579,t:1527872944541};\\\", \\\"{x:194,y:578,t:1527872944566};\\\", \\\"{x:192,y:578,t:1527872944576};\\\", \\\"{x:189,y:576,t:1527872944592};\\\", \\\"{x:187,y:575,t:1527872944609};\\\", \\\"{x:185,y:573,t:1527872944626};\\\", \\\"{x:183,y:571,t:1527872944642};\\\", \\\"{x:177,y:567,t:1527872944660};\\\", \\\"{x:170,y:562,t:1527872944676};\\\", \\\"{x:165,y:559,t:1527872944692};\\\", \\\"{x:158,y:558,t:1527872944709};\\\", \\\"{x:157,y:557,t:1527872944726};\\\", \\\"{x:156,y:557,t:1527872944798};\\\", \\\"{x:164,y:562,t:1527872945085};\\\", \\\"{x:171,y:564,t:1527872945093};\\\", \\\"{x:188,y:572,t:1527872945110};\\\", \\\"{x:204,y:579,t:1527872945126};\\\", \\\"{x:225,y:589,t:1527872945145};\\\", \\\"{x:253,y:601,t:1527872945160};\\\", \\\"{x:283,y:614,t:1527872945176};\\\", \\\"{x:314,y:628,t:1527872945193};\\\", \\\"{x:357,y:644,t:1527872945208};\\\", \\\"{x:398,y:659,t:1527872945226};\\\", \\\"{x:419,y:668,t:1527872945243};\\\", \\\"{x:429,y:673,t:1527872945259};\\\", \\\"{x:436,y:678,t:1527872945276};\\\", \\\"{x:440,y:681,t:1527872945293};\\\", \\\"{x:442,y:682,t:1527872945309};\\\", \\\"{x:445,y:685,t:1527872945325};\\\", \\\"{x:447,y:686,t:1527872945343};\\\", \\\"{x:449,y:689,t:1527872945359};\\\", \\\"{x:449,y:690,t:1527872945376};\\\", \\\"{x:450,y:691,t:1527872945393};\\\", \\\"{x:450,y:692,t:1527872945430};\\\", \\\"{x:451,y:695,t:1527872945442};\\\", \\\"{x:455,y:699,t:1527872945460};\\\", \\\"{x:461,y:705,t:1527872945476};\\\", \\\"{x:468,y:710,t:1527872945492};\\\", \\\"{x:473,y:712,t:1527872945509};\\\", \\\"{x:474,y:713,t:1527872945526};\\\" ] }, { \\\"rt\\\": 38989, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 171496, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-04 PM-04 PM-04 PM-03 PM-02 PM-H -01 PM-F -F -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:476,y:713,t:1527872947654};\\\", \\\"{x:477,y:713,t:1527872947661};\\\", \\\"{x:479,y:712,t:1527872947678};\\\", \\\"{x:484,y:708,t:1527872947695};\\\", \\\"{x:493,y:702,t:1527872947711};\\\", \\\"{x:504,y:693,t:1527872947729};\\\", \\\"{x:519,y:679,t:1527872947745};\\\", \\\"{x:535,y:655,t:1527872947761};\\\", \\\"{x:556,y:631,t:1527872947779};\\\", \\\"{x:575,y:610,t:1527872947796};\\\", \\\"{x:591,y:596,t:1527872947811};\\\", \\\"{x:602,y:583,t:1527872947828};\\\", \\\"{x:608,y:570,t:1527872947846};\\\", \\\"{x:611,y:558,t:1527872947861};\\\", \\\"{x:613,y:546,t:1527872947879};\\\", \\\"{x:613,y:540,t:1527872947896};\\\", \\\"{x:614,y:534,t:1527872947912};\\\", \\\"{x:614,y:529,t:1527872947929};\\\", \\\"{x:614,y:526,t:1527872947945};\\\", \\\"{x:614,y:525,t:1527872947961};\\\", \\\"{x:614,y:524,t:1527872947978};\\\", \\\"{x:615,y:523,t:1527872948006};\\\", \\\"{x:614,y:523,t:1527872948455};\\\", \\\"{x:612,y:523,t:1527872948471};\\\", \\\"{x:611,y:523,t:1527872948486};\\\", \\\"{x:607,y:523,t:1527872948495};\\\", \\\"{x:605,y:523,t:1527872948511};\\\", \\\"{x:601,y:522,t:1527872948530};\\\", \\\"{x:599,y:520,t:1527872948545};\\\", \\\"{x:597,y:519,t:1527872948561};\\\", \\\"{x:596,y:518,t:1527872948578};\\\", \\\"{x:594,y:516,t:1527872948595};\\\", \\\"{x:592,y:514,t:1527872948611};\\\", \\\"{x:591,y:513,t:1527872948629};\\\", \\\"{x:591,y:512,t:1527872948645};\\\", \\\"{x:591,y:511,t:1527872948661};\\\", \\\"{x:591,y:509,t:1527872948678};\\\", \\\"{x:591,y:508,t:1527872948696};\\\", \\\"{x:591,y:507,t:1527872948734};\\\", \\\"{x:591,y:506,t:1527872948774};\\\", \\\"{x:591,y:505,t:1527872948784};\\\", \\\"{x:592,y:504,t:1527872948805};\\\", \\\"{x:594,y:503,t:1527872948822};\\\", \\\"{x:595,y:502,t:1527872948829};\\\", \\\"{x:597,y:501,t:1527872948845};\\\", \\\"{x:602,y:499,t:1527872948861};\\\", \\\"{x:603,y:498,t:1527872948879};\\\", \\\"{x:605,y:497,t:1527872948896};\\\", \\\"{x:606,y:497,t:1527872948918};\\\", \\\"{x:607,y:497,t:1527872948950};\\\", \\\"{x:608,y:496,t:1527872948963};\\\", \\\"{x:610,y:495,t:1527872948979};\\\", \\\"{x:614,y:495,t:1527872948997};\\\", \\\"{x:619,y:494,t:1527872949013};\\\", \\\"{x:625,y:493,t:1527872949029};\\\", \\\"{x:630,y:492,t:1527872949046};\\\", \\\"{x:631,y:492,t:1527872949143};\\\", \\\"{x:633,y:492,t:1527872949150};\\\", \\\"{x:634,y:492,t:1527872949163};\\\", \\\"{x:638,y:492,t:1527872949180};\\\", \\\"{x:640,y:492,t:1527872949197};\\\", \\\"{x:642,y:493,t:1527872949239};\\\", \\\"{x:643,y:493,t:1527872949246};\\\", \\\"{x:646,y:493,t:1527872949263};\\\", \\\"{x:650,y:495,t:1527872949280};\\\", \\\"{x:652,y:495,t:1527872949297};\\\", \\\"{x:654,y:495,t:1527872949313};\\\", \\\"{x:655,y:495,t:1527872949334};\\\", \\\"{x:656,y:495,t:1527872949350};\\\", \\\"{x:657,y:495,t:1527872949363};\\\", \\\"{x:659,y:495,t:1527872949379};\\\", \\\"{x:660,y:495,t:1527872949398};\\\", \\\"{x:662,y:495,t:1527872949414};\\\", \\\"{x:663,y:495,t:1527872949430};\\\", \\\"{x:665,y:495,t:1527872949463};\\\", \\\"{x:666,y:495,t:1527872949495};\\\", \\\"{x:667,y:495,t:1527872949519};\\\", \\\"{x:668,y:495,t:1527872949534};\\\", \\\"{x:669,y:495,t:1527872949559};\\\", \\\"{x:671,y:495,t:1527872949583};\\\", \\\"{x:672,y:495,t:1527872949623};\\\", \\\"{x:673,y:495,t:1527872949639};\\\", \\\"{x:674,y:495,t:1527872949654};\\\", \\\"{x:675,y:495,t:1527872949678};\\\", \\\"{x:676,y:495,t:1527872949686};\\\", \\\"{x:677,y:495,t:1527872949696};\\\", \\\"{x:678,y:495,t:1527872949734};\\\", \\\"{x:679,y:495,t:1527872950015};\\\", \\\"{x:680,y:495,t:1527872950030};\\\", \\\"{x:681,y:495,t:1527872950063};\\\", \\\"{x:682,y:495,t:1527872950081};\\\", \\\"{x:683,y:496,t:1527872950098};\\\", \\\"{x:685,y:496,t:1527872950113};\\\", \\\"{x:686,y:496,t:1527872950134};\\\", \\\"{x:687,y:496,t:1527872950147};\\\", \\\"{x:687,y:497,t:1527872950164};\\\", \\\"{x:688,y:498,t:1527872950206};\\\", \\\"{x:688,y:499,t:1527872950295};\\\", \\\"{x:689,y:499,t:1527872950375};\\\", \\\"{x:690,y:499,t:1527872950406};\\\", \\\"{x:690,y:500,t:1527872950471};\\\", \\\"{x:690,y:501,t:1527872950502};\\\", \\\"{x:691,y:501,t:1527872950515};\\\", \\\"{x:691,y:502,t:1527872950534};\\\", \\\"{x:692,y:504,t:1527872950574};\\\", \\\"{x:693,y:504,t:1527872950591};\\\", \\\"{x:694,y:505,t:1527872950599};\\\", \\\"{x:695,y:506,t:1527872950615};\\\", \\\"{x:695,y:508,t:1527872950631};\\\", \\\"{x:697,y:509,t:1527872950647};\\\", \\\"{x:700,y:510,t:1527872950664};\\\", \\\"{x:708,y:513,t:1527872950680};\\\", \\\"{x:718,y:518,t:1527872950697};\\\", \\\"{x:726,y:520,t:1527872950714};\\\", \\\"{x:734,y:521,t:1527872950730};\\\", \\\"{x:740,y:525,t:1527872950747};\\\", \\\"{x:753,y:526,t:1527872950764};\\\", \\\"{x:763,y:527,t:1527872950780};\\\", \\\"{x:771,y:529,t:1527872950797};\\\", \\\"{x:779,y:531,t:1527872950813};\\\", \\\"{x:790,y:535,t:1527872950830};\\\", \\\"{x:797,y:535,t:1527872950847};\\\", \\\"{x:811,y:537,t:1527872950865};\\\", \\\"{x:823,y:539,t:1527872950880};\\\", \\\"{x:835,y:540,t:1527872950897};\\\", \\\"{x:855,y:545,t:1527872950915};\\\", \\\"{x:879,y:554,t:1527872950930};\\\", \\\"{x:897,y:557,t:1527872950947};\\\", \\\"{x:921,y:565,t:1527872950964};\\\", \\\"{x:951,y:573,t:1527872950981};\\\", \\\"{x:984,y:581,t:1527872950998};\\\", \\\"{x:1030,y:596,t:1527872951014};\\\", \\\"{x:1060,y:604,t:1527872951031};\\\", \\\"{x:1102,y:619,t:1527872951048};\\\", \\\"{x:1145,y:634,t:1527872951065};\\\", \\\"{x:1198,y:655,t:1527872951081};\\\", \\\"{x:1241,y:673,t:1527872951098};\\\", \\\"{x:1281,y:686,t:1527872951115};\\\", \\\"{x:1308,y:693,t:1527872951132};\\\", \\\"{x:1330,y:699,t:1527872951148};\\\", \\\"{x:1346,y:704,t:1527872951165};\\\", \\\"{x:1368,y:713,t:1527872951182};\\\", \\\"{x:1373,y:715,t:1527872951198};\\\", \\\"{x:1389,y:725,t:1527872951214};\\\", \\\"{x:1407,y:734,t:1527872951231};\\\", \\\"{x:1425,y:741,t:1527872951247};\\\", \\\"{x:1441,y:748,t:1527872951265};\\\", \\\"{x:1456,y:755,t:1527872951282};\\\", \\\"{x:1472,y:765,t:1527872951298};\\\", \\\"{x:1483,y:772,t:1527872951315};\\\", \\\"{x:1495,y:779,t:1527872951332};\\\", \\\"{x:1504,y:786,t:1527872951348};\\\", \\\"{x:1511,y:793,t:1527872951365};\\\", \\\"{x:1517,y:801,t:1527872951382};\\\", \\\"{x:1522,y:806,t:1527872951398};\\\", \\\"{x:1534,y:820,t:1527872951415};\\\", \\\"{x:1542,y:826,t:1527872951432};\\\", \\\"{x:1548,y:832,t:1527872951449};\\\", \\\"{x:1556,y:842,t:1527872951464};\\\", \\\"{x:1562,y:855,t:1527872951482};\\\", \\\"{x:1566,y:861,t:1527872951499};\\\", \\\"{x:1570,y:869,t:1527872951515};\\\", \\\"{x:1578,y:883,t:1527872951531};\\\", \\\"{x:1585,y:895,t:1527872951549};\\\", \\\"{x:1591,y:910,t:1527872951565};\\\", \\\"{x:1595,y:920,t:1527872951582};\\\", \\\"{x:1599,y:929,t:1527872951599};\\\", \\\"{x:1599,y:933,t:1527872951615};\\\", \\\"{x:1603,y:939,t:1527872951632};\\\", \\\"{x:1606,y:947,t:1527872951649};\\\", \\\"{x:1610,y:956,t:1527872951665};\\\", \\\"{x:1615,y:963,t:1527872951682};\\\", \\\"{x:1618,y:968,t:1527872951699};\\\", \\\"{x:1619,y:970,t:1527872951715};\\\", \\\"{x:1620,y:972,t:1527872951732};\\\", \\\"{x:1620,y:975,t:1527872951748};\\\", \\\"{x:1620,y:979,t:1527872951765};\\\", \\\"{x:1620,y:981,t:1527872951782};\\\", \\\"{x:1619,y:983,t:1527872951799};\\\", \\\"{x:1618,y:984,t:1527872951830};\\\", \\\"{x:1617,y:984,t:1527872951854};\\\", \\\"{x:1616,y:984,t:1527872951865};\\\", \\\"{x:1613,y:984,t:1527872951882};\\\", \\\"{x:1612,y:984,t:1527872951899};\\\", \\\"{x:1609,y:984,t:1527872951915};\\\", \\\"{x:1609,y:983,t:1527872951951};\\\", \\\"{x:1611,y:982,t:1527872951966};\\\", \\\"{x:1612,y:982,t:1527872951982};\\\", \\\"{x:1614,y:982,t:1527872952015};\\\", \\\"{x:1615,y:982,t:1527872952030};\\\", \\\"{x:1617,y:982,t:1527872952049};\\\", \\\"{x:1620,y:980,t:1527872952066};\\\", \\\"{x:1621,y:980,t:1527872952081};\\\", \\\"{x:1622,y:978,t:1527872952098};\\\", \\\"{x:1624,y:977,t:1527872952115};\\\", \\\"{x:1628,y:975,t:1527872952132};\\\", \\\"{x:1628,y:974,t:1527872952151};\\\", \\\"{x:1628,y:973,t:1527872952175};\\\", \\\"{x:1628,y:972,t:1527872952335};\\\", \\\"{x:1629,y:972,t:1527872952927};\\\", \\\"{x:1630,y:973,t:1527872952935};\\\", \\\"{x:1631,y:974,t:1527872952950};\\\", \\\"{x:1632,y:974,t:1527872953031};\\\", \\\"{x:1633,y:976,t:1527872953046};\\\", \\\"{x:1635,y:978,t:1527872953055};\\\", \\\"{x:1636,y:978,t:1527872953067};\\\", \\\"{x:1637,y:980,t:1527872953082};\\\", \\\"{x:1638,y:980,t:1527872953100};\\\", \\\"{x:1638,y:981,t:1527872953116};\\\", \\\"{x:1639,y:982,t:1527872953142};\\\", \\\"{x:1640,y:983,t:1527872953150};\\\", \\\"{x:1641,y:983,t:1527872953167};\\\", \\\"{x:1641,y:984,t:1527872953183};\\\", \\\"{x:1642,y:984,t:1527872953286};\\\", \\\"{x:1642,y:982,t:1527872953302};\\\", \\\"{x:1642,y:981,t:1527872953317};\\\", \\\"{x:1639,y:975,t:1527872953333};\\\", \\\"{x:1628,y:970,t:1527872953351};\\\", \\\"{x:1620,y:965,t:1527872953368};\\\", \\\"{x:1616,y:962,t:1527872953384};\\\", \\\"{x:1614,y:959,t:1527872953400};\\\", \\\"{x:1611,y:957,t:1527872953417};\\\", \\\"{x:1611,y:956,t:1527872953433};\\\", \\\"{x:1610,y:955,t:1527872953449};\\\", \\\"{x:1609,y:956,t:1527872953671};\\\", \\\"{x:1609,y:958,t:1527872953759};\\\", \\\"{x:1609,y:959,t:1527872953775};\\\", \\\"{x:1610,y:959,t:1527872953784};\\\", \\\"{x:1611,y:959,t:1527872953830};\\\", \\\"{x:1612,y:960,t:1527872953855};\\\", \\\"{x:1612,y:961,t:1527872953903};\\\", \\\"{x:1613,y:961,t:1527872953967};\\\", \\\"{x:1614,y:962,t:1527872953984};\\\", \\\"{x:1614,y:964,t:1527872954055};\\\", \\\"{x:1615,y:964,t:1527872954067};\\\", \\\"{x:1617,y:969,t:1527872954085};\\\", \\\"{x:1624,y:975,t:1527872954101};\\\", \\\"{x:1626,y:978,t:1527872954117};\\\", \\\"{x:1627,y:979,t:1527872954134};\\\", \\\"{x:1628,y:980,t:1527872954206};\\\", \\\"{x:1628,y:979,t:1527872954247};\\\", \\\"{x:1628,y:978,t:1527872954255};\\\", \\\"{x:1628,y:977,t:1527872954267};\\\", \\\"{x:1628,y:976,t:1527872954284};\\\", \\\"{x:1628,y:974,t:1527872954301};\\\", \\\"{x:1628,y:973,t:1527872954318};\\\", \\\"{x:1628,y:972,t:1527872954334};\\\", \\\"{x:1628,y:971,t:1527872954350};\\\", \\\"{x:1628,y:969,t:1527872954368};\\\", \\\"{x:1628,y:967,t:1527872954384};\\\", \\\"{x:1628,y:965,t:1527872954400};\\\", \\\"{x:1628,y:964,t:1527872954431};\\\", \\\"{x:1628,y:963,t:1527872954439};\\\", \\\"{x:1628,y:962,t:1527872954451};\\\", \\\"{x:1628,y:960,t:1527872954468};\\\", \\\"{x:1628,y:958,t:1527872954484};\\\", \\\"{x:1628,y:954,t:1527872954501};\\\", \\\"{x:1629,y:951,t:1527872954517};\\\", \\\"{x:1629,y:949,t:1527872954533};\\\", \\\"{x:1629,y:946,t:1527872954550};\\\", \\\"{x:1629,y:944,t:1527872954568};\\\", \\\"{x:1629,y:941,t:1527872954583};\\\", \\\"{x:1629,y:936,t:1527872954601};\\\", \\\"{x:1629,y:930,t:1527872954617};\\\", \\\"{x:1629,y:923,t:1527872954634};\\\", \\\"{x:1629,y:919,t:1527872954651};\\\", \\\"{x:1629,y:916,t:1527872954667};\\\", \\\"{x:1629,y:914,t:1527872954685};\\\", \\\"{x:1629,y:909,t:1527872954701};\\\", \\\"{x:1629,y:901,t:1527872954718};\\\", \\\"{x:1626,y:894,t:1527872954734};\\\", \\\"{x:1626,y:893,t:1527872954750};\\\", \\\"{x:1626,y:891,t:1527872954768};\\\", \\\"{x:1626,y:889,t:1527872954785};\\\", \\\"{x:1626,y:884,t:1527872954801};\\\", \\\"{x:1626,y:880,t:1527872954818};\\\", \\\"{x:1627,y:875,t:1527872954835};\\\", \\\"{x:1627,y:867,t:1527872954851};\\\", \\\"{x:1627,y:860,t:1527872954868};\\\", \\\"{x:1627,y:853,t:1527872954885};\\\", \\\"{x:1627,y:844,t:1527872954901};\\\", \\\"{x:1627,y:834,t:1527872954918};\\\", \\\"{x:1627,y:826,t:1527872954935};\\\", \\\"{x:1627,y:817,t:1527872954951};\\\", \\\"{x:1627,y:805,t:1527872954968};\\\", \\\"{x:1627,y:798,t:1527872954986};\\\", \\\"{x:1627,y:793,t:1527872955002};\\\", \\\"{x:1627,y:790,t:1527872955017};\\\", \\\"{x:1627,y:786,t:1527872955034};\\\", \\\"{x:1627,y:784,t:1527872955051};\\\", \\\"{x:1627,y:783,t:1527872955069};\\\", \\\"{x:1627,y:782,t:1527872955093};\\\", \\\"{x:1627,y:780,t:1527872955101};\\\", \\\"{x:1627,y:779,t:1527872955125};\\\", \\\"{x:1627,y:778,t:1527872955135};\\\", \\\"{x:1627,y:777,t:1527872955152};\\\", \\\"{x:1627,y:776,t:1527872955190};\\\", \\\"{x:1627,y:775,t:1527872955214};\\\", \\\"{x:1627,y:774,t:1527872955222};\\\", \\\"{x:1627,y:772,t:1527872955237};\\\", \\\"{x:1627,y:771,t:1527872955251};\\\", \\\"{x:1627,y:770,t:1527872955267};\\\", \\\"{x:1627,y:768,t:1527872955284};\\\", \\\"{x:1627,y:767,t:1527872955301};\\\", \\\"{x:1627,y:766,t:1527872955317};\\\", \\\"{x:1627,y:764,t:1527872955334};\\\", \\\"{x:1627,y:762,t:1527872955351};\\\", \\\"{x:1627,y:759,t:1527872955368};\\\", \\\"{x:1627,y:757,t:1527872955384};\\\", \\\"{x:1626,y:754,t:1527872955402};\\\", \\\"{x:1626,y:752,t:1527872955419};\\\", \\\"{x:1625,y:751,t:1527872955435};\\\", \\\"{x:1625,y:750,t:1527872955452};\\\", \\\"{x:1625,y:749,t:1527872955468};\\\", \\\"{x:1625,y:745,t:1527872955485};\\\", \\\"{x:1625,y:739,t:1527872955502};\\\", \\\"{x:1625,y:735,t:1527872955517};\\\", \\\"{x:1625,y:731,t:1527872955534};\\\", \\\"{x:1625,y:727,t:1527872955552};\\\", \\\"{x:1625,y:722,t:1527872955568};\\\", \\\"{x:1625,y:719,t:1527872955584};\\\", \\\"{x:1625,y:715,t:1527872955602};\\\", \\\"{x:1625,y:709,t:1527872955618};\\\", \\\"{x:1622,y:699,t:1527872955634};\\\", \\\"{x:1621,y:693,t:1527872955651};\\\", \\\"{x:1621,y:688,t:1527872955668};\\\", \\\"{x:1621,y:680,t:1527872955684};\\\", \\\"{x:1618,y:665,t:1527872955702};\\\", \\\"{x:1617,y:657,t:1527872955718};\\\", \\\"{x:1616,y:648,t:1527872955734};\\\", \\\"{x:1615,y:640,t:1527872955751};\\\", \\\"{x:1613,y:634,t:1527872955769};\\\", \\\"{x:1612,y:631,t:1527872955784};\\\", \\\"{x:1611,y:627,t:1527872955801};\\\", \\\"{x:1611,y:623,t:1527872955819};\\\", \\\"{x:1609,y:620,t:1527872955836};\\\", \\\"{x:1608,y:615,t:1527872955852};\\\", \\\"{x:1608,y:611,t:1527872955869};\\\", \\\"{x:1605,y:604,t:1527872955886};\\\", \\\"{x:1605,y:600,t:1527872955902};\\\", \\\"{x:1605,y:597,t:1527872955918};\\\", \\\"{x:1605,y:595,t:1527872955936};\\\", \\\"{x:1605,y:593,t:1527872955952};\\\", \\\"{x:1605,y:590,t:1527872955969};\\\", \\\"{x:1605,y:587,t:1527872955986};\\\", \\\"{x:1605,y:583,t:1527872956002};\\\", \\\"{x:1605,y:580,t:1527872956019};\\\", \\\"{x:1605,y:579,t:1527872956036};\\\", \\\"{x:1605,y:578,t:1527872956052};\\\", \\\"{x:1605,y:575,t:1527872956069};\\\", \\\"{x:1605,y:573,t:1527872956086};\\\", \\\"{x:1605,y:572,t:1527872956103};\\\", \\\"{x:1605,y:568,t:1527872956119};\\\", \\\"{x:1606,y:566,t:1527872956136};\\\", \\\"{x:1606,y:565,t:1527872956152};\\\", \\\"{x:1606,y:563,t:1527872956169};\\\", \\\"{x:1606,y:562,t:1527872956187};\\\", \\\"{x:1606,y:559,t:1527872956202};\\\", \\\"{x:1608,y:557,t:1527872956219};\\\", \\\"{x:1608,y:553,t:1527872956236};\\\", \\\"{x:1609,y:548,t:1527872956253};\\\", \\\"{x:1609,y:542,t:1527872956269};\\\", \\\"{x:1610,y:531,t:1527872956286};\\\", \\\"{x:1610,y:520,t:1527872956302};\\\", \\\"{x:1610,y:506,t:1527872956319};\\\", \\\"{x:1610,y:497,t:1527872956336};\\\", \\\"{x:1610,y:488,t:1527872956353};\\\", \\\"{x:1610,y:484,t:1527872956369};\\\", \\\"{x:1610,y:478,t:1527872956386};\\\", \\\"{x:1610,y:472,t:1527872956403};\\\", \\\"{x:1610,y:469,t:1527872956419};\\\", \\\"{x:1610,y:464,t:1527872956436};\\\", \\\"{x:1609,y:459,t:1527872956453};\\\", \\\"{x:1609,y:458,t:1527872956469};\\\", \\\"{x:1608,y:458,t:1527872956486};\\\", \\\"{x:1608,y:457,t:1527872956623};\\\", \\\"{x:1608,y:456,t:1527872956636};\\\", \\\"{x:1608,y:455,t:1527872956654};\\\", \\\"{x:1608,y:453,t:1527872956671};\\\", \\\"{x:1608,y:452,t:1527872956703};\\\", \\\"{x:1608,y:457,t:1527872956807};\\\", \\\"{x:1608,y:464,t:1527872956820};\\\", \\\"{x:1609,y:475,t:1527872956836};\\\", \\\"{x:1611,y:492,t:1527872956853};\\\", \\\"{x:1615,y:506,t:1527872956870};\\\", \\\"{x:1618,y:515,t:1527872956886};\\\", \\\"{x:1620,y:527,t:1527872956903};\\\", \\\"{x:1623,y:543,t:1527872956920};\\\", \\\"{x:1623,y:553,t:1527872956936};\\\", \\\"{x:1624,y:568,t:1527872956953};\\\", \\\"{x:1624,y:582,t:1527872956970};\\\", \\\"{x:1625,y:594,t:1527872956986};\\\", \\\"{x:1625,y:607,t:1527872957003};\\\", \\\"{x:1625,y:616,t:1527872957020};\\\", \\\"{x:1625,y:623,t:1527872957037};\\\", \\\"{x:1625,y:631,t:1527872957053};\\\", \\\"{x:1625,y:644,t:1527872957071};\\\", \\\"{x:1625,y:649,t:1527872957086};\\\", \\\"{x:1625,y:653,t:1527872957103};\\\", \\\"{x:1625,y:655,t:1527872957120};\\\", \\\"{x:1625,y:658,t:1527872957137};\\\", \\\"{x:1625,y:659,t:1527872957154};\\\", \\\"{x:1625,y:662,t:1527872957170};\\\", \\\"{x:1625,y:666,t:1527872957187};\\\", \\\"{x:1624,y:671,t:1527872957203};\\\", \\\"{x:1624,y:676,t:1527872957220};\\\", \\\"{x:1623,y:684,t:1527872957237};\\\", \\\"{x:1623,y:691,t:1527872957253};\\\", \\\"{x:1623,y:700,t:1527872957271};\\\", \\\"{x:1623,y:704,t:1527872957286};\\\", \\\"{x:1623,y:707,t:1527872957303};\\\", \\\"{x:1623,y:711,t:1527872957320};\\\", \\\"{x:1623,y:715,t:1527872957337};\\\", \\\"{x:1623,y:719,t:1527872957353};\\\", \\\"{x:1623,y:723,t:1527872957370};\\\", \\\"{x:1622,y:726,t:1527872957387};\\\", \\\"{x:1622,y:728,t:1527872957403};\\\", \\\"{x:1622,y:731,t:1527872957420};\\\", \\\"{x:1622,y:734,t:1527872957437};\\\", \\\"{x:1622,y:736,t:1527872957453};\\\", \\\"{x:1622,y:739,t:1527872957470};\\\", \\\"{x:1621,y:741,t:1527872957487};\\\", \\\"{x:1621,y:742,t:1527872957505};\\\", \\\"{x:1621,y:744,t:1527872957520};\\\", \\\"{x:1621,y:748,t:1527872957537};\\\", \\\"{x:1621,y:751,t:1527872957554};\\\", \\\"{x:1621,y:755,t:1527872957570};\\\", \\\"{x:1621,y:759,t:1527872957587};\\\", \\\"{x:1621,y:763,t:1527872957604};\\\", \\\"{x:1621,y:768,t:1527872957621};\\\", \\\"{x:1620,y:773,t:1527872957636};\\\", \\\"{x:1620,y:780,t:1527872957653};\\\", \\\"{x:1620,y:788,t:1527872957670};\\\", \\\"{x:1620,y:801,t:1527872957687};\\\", \\\"{x:1620,y:812,t:1527872957703};\\\", \\\"{x:1620,y:824,t:1527872957719};\\\", \\\"{x:1620,y:834,t:1527872957736};\\\", \\\"{x:1620,y:841,t:1527872957754};\\\", \\\"{x:1620,y:847,t:1527872957770};\\\", \\\"{x:1620,y:853,t:1527872957787};\\\", \\\"{x:1620,y:858,t:1527872957804};\\\", \\\"{x:1619,y:868,t:1527872957820};\\\", \\\"{x:1619,y:874,t:1527872957837};\\\", \\\"{x:1619,y:884,t:1527872957854};\\\", \\\"{x:1619,y:890,t:1527872957871};\\\", \\\"{x:1619,y:897,t:1527872957887};\\\", \\\"{x:1619,y:901,t:1527872957904};\\\", \\\"{x:1619,y:907,t:1527872957921};\\\", \\\"{x:1619,y:914,t:1527872957937};\\\", \\\"{x:1619,y:922,t:1527872957954};\\\", \\\"{x:1618,y:936,t:1527872957971};\\\", \\\"{x:1618,y:947,t:1527872957986};\\\", \\\"{x:1618,y:956,t:1527872958004};\\\", \\\"{x:1618,y:964,t:1527872958021};\\\", \\\"{x:1618,y:969,t:1527872958037};\\\", \\\"{x:1618,y:973,t:1527872958054};\\\", \\\"{x:1618,y:977,t:1527872958070};\\\", \\\"{x:1618,y:979,t:1527872958087};\\\", \\\"{x:1618,y:983,t:1527872958104};\\\", \\\"{x:1618,y:986,t:1527872958121};\\\", \\\"{x:1618,y:988,t:1527872958137};\\\", \\\"{x:1617,y:989,t:1527872958222};\\\", \\\"{x:1616,y:989,t:1527872958239};\\\", \\\"{x:1615,y:989,t:1527872958254};\\\", \\\"{x:1613,y:988,t:1527872958271};\\\", \\\"{x:1612,y:987,t:1527872958288};\\\", \\\"{x:1611,y:986,t:1527872958304};\\\", \\\"{x:1609,y:985,t:1527872958326};\\\", \\\"{x:1607,y:985,t:1527872958338};\\\", \\\"{x:1602,y:983,t:1527872958355};\\\", \\\"{x:1596,y:982,t:1527872958371};\\\", \\\"{x:1593,y:980,t:1527872958388};\\\", \\\"{x:1590,y:979,t:1527872958404};\\\", \\\"{x:1589,y:979,t:1527872958421};\\\", \\\"{x:1586,y:978,t:1527872958438};\\\", \\\"{x:1584,y:977,t:1527872958455};\\\", \\\"{x:1582,y:977,t:1527872958471};\\\", \\\"{x:1577,y:976,t:1527872958488};\\\", \\\"{x:1570,y:975,t:1527872958504};\\\", \\\"{x:1560,y:975,t:1527872958521};\\\", \\\"{x:1554,y:975,t:1527872958537};\\\", \\\"{x:1549,y:975,t:1527872958554};\\\", \\\"{x:1547,y:975,t:1527872958570};\\\", \\\"{x:1546,y:975,t:1527872958637};\\\", \\\"{x:1545,y:975,t:1527872958654};\\\", \\\"{x:1543,y:975,t:1527872958670};\\\", \\\"{x:1543,y:974,t:1527872958687};\\\", \\\"{x:1543,y:973,t:1527872958717};\\\", \\\"{x:1543,y:972,t:1527872958733};\\\", \\\"{x:1543,y:971,t:1527872958854};\\\", \\\"{x:1543,y:970,t:1527872958886};\\\", \\\"{x:1543,y:969,t:1527872958918};\\\", \\\"{x:1543,y:968,t:1527872958943};\\\", \\\"{x:1544,y:967,t:1527872958991};\\\", \\\"{x:1544,y:966,t:1527872959006};\\\", \\\"{x:1545,y:964,t:1527872959023};\\\", \\\"{x:1543,y:964,t:1527872960703};\\\", \\\"{x:1540,y:964,t:1527872960711};\\\", \\\"{x:1539,y:964,t:1527872960724};\\\", \\\"{x:1535,y:964,t:1527872960740};\\\", \\\"{x:1531,y:964,t:1527872960756};\\\", \\\"{x:1529,y:964,t:1527872960773};\\\", \\\"{x:1525,y:965,t:1527872960790};\\\", \\\"{x:1521,y:965,t:1527872960806};\\\", \\\"{x:1515,y:965,t:1527872960823};\\\", \\\"{x:1508,y:965,t:1527872960841};\\\", \\\"{x:1503,y:965,t:1527872960856};\\\", \\\"{x:1496,y:965,t:1527872960873};\\\", \\\"{x:1490,y:965,t:1527872960890};\\\", \\\"{x:1483,y:965,t:1527872960906};\\\", \\\"{x:1476,y:965,t:1527872960923};\\\", \\\"{x:1475,y:965,t:1527872960941};\\\", \\\"{x:1475,y:966,t:1527872961367};\\\", \\\"{x:1475,y:967,t:1527872961375};\\\", \\\"{x:1476,y:967,t:1527872961390};\\\", \\\"{x:1477,y:968,t:1527872961422};\\\", \\\"{x:1478,y:969,t:1527872961479};\\\", \\\"{x:1479,y:970,t:1527872961494};\\\", \\\"{x:1480,y:970,t:1527872961510};\\\", \\\"{x:1482,y:971,t:1527872961524};\\\", \\\"{x:1484,y:971,t:1527872961540};\\\", \\\"{x:1485,y:971,t:1527872961557};\\\", \\\"{x:1486,y:972,t:1527872961573};\\\", \\\"{x:1485,y:970,t:1527872961743};\\\", \\\"{x:1485,y:969,t:1527872961774};\\\", \\\"{x:1485,y:968,t:1527872961791};\\\", \\\"{x:1484,y:967,t:1527872961807};\\\", \\\"{x:1481,y:965,t:1527872962479};\\\", \\\"{x:1479,y:964,t:1527872962491};\\\", \\\"{x:1466,y:957,t:1527872962509};\\\", \\\"{x:1437,y:949,t:1527872962524};\\\", \\\"{x:1391,y:932,t:1527872962542};\\\", \\\"{x:1305,y:899,t:1527872962559};\\\", \\\"{x:1264,y:881,t:1527872962574};\\\", \\\"{x:1232,y:862,t:1527872962591};\\\", \\\"{x:1209,y:843,t:1527872962608};\\\", \\\"{x:1191,y:826,t:1527872962624};\\\", \\\"{x:1173,y:810,t:1527872962641};\\\", \\\"{x:1159,y:795,t:1527872962658};\\\", \\\"{x:1146,y:783,t:1527872962674};\\\", \\\"{x:1132,y:768,t:1527872962691};\\\", \\\"{x:1114,y:747,t:1527872962708};\\\", \\\"{x:1094,y:731,t:1527872962724};\\\", \\\"{x:1073,y:716,t:1527872962741};\\\", \\\"{x:1061,y:708,t:1527872962758};\\\", \\\"{x:1050,y:704,t:1527872962774};\\\", \\\"{x:1030,y:700,t:1527872962791};\\\", \\\"{x:999,y:694,t:1527872962808};\\\", \\\"{x:960,y:682,t:1527872962826};\\\", \\\"{x:914,y:665,t:1527872962841};\\\", \\\"{x:867,y:653,t:1527872962858};\\\", \\\"{x:819,y:638,t:1527872962874};\\\", \\\"{x:772,y:625,t:1527872962891};\\\", \\\"{x:737,y:612,t:1527872962909};\\\", \\\"{x:713,y:602,t:1527872962925};\\\", \\\"{x:697,y:592,t:1527872962940};\\\", \\\"{x:683,y:581,t:1527872962957};\\\", \\\"{x:673,y:571,t:1527872962974};\\\", \\\"{x:666,y:566,t:1527872962990};\\\", \\\"{x:659,y:563,t:1527872963006};\\\", \\\"{x:655,y:562,t:1527872963023};\\\", \\\"{x:648,y:560,t:1527872963040};\\\", \\\"{x:643,y:560,t:1527872963057};\\\", \\\"{x:637,y:556,t:1527872963074};\\\", \\\"{x:636,y:556,t:1527872963134};\\\", \\\"{x:636,y:555,t:1527872963142};\\\", \\\"{x:635,y:555,t:1527872963156};\\\", \\\"{x:632,y:555,t:1527872963174};\\\", \\\"{x:629,y:555,t:1527872963190};\\\", \\\"{x:625,y:558,t:1527872963208};\\\", \\\"{x:621,y:565,t:1527872963224};\\\", \\\"{x:618,y:570,t:1527872963240};\\\", \\\"{x:615,y:574,t:1527872963258};\\\", \\\"{x:612,y:579,t:1527872963275};\\\", \\\"{x:609,y:582,t:1527872963292};\\\", \\\"{x:608,y:582,t:1527872963350};\\\", \\\"{x:607,y:584,t:1527872963358};\\\", \\\"{x:606,y:586,t:1527872963375};\\\", \\\"{x:606,y:589,t:1527872963391};\\\", \\\"{x:606,y:590,t:1527872963790};\\\", \\\"{x:609,y:592,t:1527872963797};\\\", \\\"{x:618,y:596,t:1527872963808};\\\", \\\"{x:640,y:603,t:1527872963825};\\\", \\\"{x:666,y:611,t:1527872963842};\\\", \\\"{x:703,y:619,t:1527872963859};\\\", \\\"{x:763,y:631,t:1527872963875};\\\", \\\"{x:831,y:645,t:1527872963891};\\\", \\\"{x:898,y:655,t:1527872963909};\\\", \\\"{x:973,y:664,t:1527872963925};\\\", \\\"{x:1100,y:689,t:1527872963942};\\\", \\\"{x:1185,y:708,t:1527872963959};\\\", \\\"{x:1268,y:726,t:1527872963976};\\\", \\\"{x:1330,y:738,t:1527872963992};\\\", \\\"{x:1386,y:746,t:1527872964009};\\\", \\\"{x:1432,y:755,t:1527872964026};\\\", \\\"{x:1470,y:769,t:1527872964042};\\\", \\\"{x:1492,y:779,t:1527872964059};\\\", \\\"{x:1508,y:788,t:1527872964076};\\\", \\\"{x:1521,y:795,t:1527872964092};\\\", \\\"{x:1531,y:801,t:1527872964109};\\\", \\\"{x:1543,y:809,t:1527872964126};\\\", \\\"{x:1556,y:818,t:1527872964143};\\\", \\\"{x:1565,y:825,t:1527872964159};\\\", \\\"{x:1575,y:833,t:1527872964176};\\\", \\\"{x:1580,y:838,t:1527872964194};\\\", \\\"{x:1581,y:842,t:1527872964210};\\\", \\\"{x:1581,y:843,t:1527872964226};\\\", \\\"{x:1581,y:849,t:1527872964243};\\\", \\\"{x:1576,y:858,t:1527872964260};\\\", \\\"{x:1570,y:864,t:1527872964276};\\\", \\\"{x:1563,y:871,t:1527872964293};\\\", \\\"{x:1551,y:879,t:1527872964309};\\\", \\\"{x:1541,y:885,t:1527872964326};\\\", \\\"{x:1530,y:889,t:1527872964343};\\\", \\\"{x:1521,y:890,t:1527872964359};\\\", \\\"{x:1511,y:891,t:1527872964377};\\\", \\\"{x:1505,y:893,t:1527872964392};\\\", \\\"{x:1499,y:894,t:1527872964410};\\\", \\\"{x:1492,y:895,t:1527872964426};\\\", \\\"{x:1486,y:895,t:1527872964442};\\\", \\\"{x:1481,y:895,t:1527872964460};\\\", \\\"{x:1478,y:895,t:1527872964477};\\\", \\\"{x:1476,y:893,t:1527872964494};\\\", \\\"{x:1474,y:886,t:1527872964510};\\\", \\\"{x:1474,y:883,t:1527872964527};\\\", \\\"{x:1474,y:879,t:1527872964544};\\\", \\\"{x:1473,y:875,t:1527872964561};\\\", \\\"{x:1473,y:870,t:1527872964578};\\\", \\\"{x:1473,y:861,t:1527872964594};\\\", \\\"{x:1473,y:855,t:1527872964611};\\\", \\\"{x:1473,y:850,t:1527872964627};\\\", \\\"{x:1473,y:845,t:1527872964644};\\\", \\\"{x:1473,y:843,t:1527872964661};\\\", \\\"{x:1472,y:839,t:1527872964677};\\\", \\\"{x:1469,y:835,t:1527872964694};\\\", \\\"{x:1466,y:833,t:1527872964711};\\\", \\\"{x:1465,y:832,t:1527872964728};\\\", \\\"{x:1464,y:831,t:1527872964744};\\\", \\\"{x:1464,y:830,t:1527872964855};\\\", \\\"{x:1464,y:829,t:1527872964903};\\\", \\\"{x:1464,y:828,t:1527872964991};\\\", \\\"{x:1464,y:827,t:1527872964999};\\\", \\\"{x:1463,y:825,t:1527872965167};\\\", \\\"{x:1463,y:826,t:1527872965351};\\\", \\\"{x:1463,y:827,t:1527872965363};\\\", \\\"{x:1463,y:828,t:1527872965379};\\\", \\\"{x:1463,y:830,t:1527872965396};\\\", \\\"{x:1462,y:833,t:1527872965414};\\\", \\\"{x:1462,y:834,t:1527872965431};\\\", \\\"{x:1462,y:837,t:1527872965446};\\\", \\\"{x:1461,y:838,t:1527872965464};\\\", \\\"{x:1461,y:841,t:1527872965480};\\\", \\\"{x:1461,y:842,t:1527872965496};\\\", \\\"{x:1461,y:843,t:1527872965514};\\\", \\\"{x:1461,y:844,t:1527872965530};\\\", \\\"{x:1461,y:846,t:1527872965547};\\\", \\\"{x:1461,y:849,t:1527872965563};\\\", \\\"{x:1461,y:855,t:1527872965581};\\\", \\\"{x:1461,y:859,t:1527872965598};\\\", \\\"{x:1462,y:865,t:1527872965614};\\\", \\\"{x:1462,y:866,t:1527872965631};\\\", \\\"{x:1463,y:868,t:1527872965678};\\\", \\\"{x:1463,y:869,t:1527872965703};\\\", \\\"{x:1463,y:871,t:1527872965714};\\\", \\\"{x:1463,y:872,t:1527872965731};\\\", \\\"{x:1463,y:876,t:1527872965747};\\\", \\\"{x:1464,y:880,t:1527872965764};\\\", \\\"{x:1465,y:882,t:1527872965781};\\\", \\\"{x:1465,y:884,t:1527872965797};\\\", \\\"{x:1465,y:889,t:1527872965814};\\\", \\\"{x:1465,y:891,t:1527872965831};\\\", \\\"{x:1465,y:895,t:1527872965848};\\\", \\\"{x:1465,y:898,t:1527872965865};\\\", \\\"{x:1465,y:900,t:1527872965881};\\\", \\\"{x:1467,y:902,t:1527872965898};\\\", \\\"{x:1467,y:904,t:1527872965918};\\\", \\\"{x:1467,y:905,t:1527872965951};\\\", \\\"{x:1467,y:906,t:1527872965964};\\\", \\\"{x:1467,y:907,t:1527872965982};\\\", \\\"{x:1467,y:909,t:1527872965999};\\\", \\\"{x:1467,y:910,t:1527872966016};\\\", \\\"{x:1467,y:912,t:1527872966031};\\\", \\\"{x:1467,y:913,t:1527872966049};\\\", \\\"{x:1467,y:915,t:1527872966066};\\\", \\\"{x:1467,y:917,t:1527872966081};\\\", \\\"{x:1467,y:920,t:1527872966099};\\\", \\\"{x:1464,y:926,t:1527872966116};\\\", \\\"{x:1460,y:931,t:1527872966133};\\\", \\\"{x:1453,y:937,t:1527872966148};\\\", \\\"{x:1445,y:940,t:1527872966166};\\\", \\\"{x:1427,y:945,t:1527872966182};\\\", \\\"{x:1421,y:947,t:1527872966199};\\\", \\\"{x:1414,y:949,t:1527872966215};\\\", \\\"{x:1410,y:950,t:1527872966232};\\\", \\\"{x:1407,y:952,t:1527872966249};\\\", \\\"{x:1405,y:952,t:1527872966265};\\\", \\\"{x:1402,y:955,t:1527872966281};\\\", \\\"{x:1400,y:956,t:1527872966298};\\\", \\\"{x:1400,y:957,t:1527872966315};\\\", \\\"{x:1399,y:957,t:1527872966331};\\\", \\\"{x:1399,y:956,t:1527872966422};\\\", \\\"{x:1399,y:954,t:1527872966433};\\\", \\\"{x:1399,y:950,t:1527872966450};\\\", \\\"{x:1399,y:944,t:1527872966467};\\\", \\\"{x:1397,y:938,t:1527872966482};\\\", \\\"{x:1397,y:932,t:1527872966499};\\\", \\\"{x:1396,y:928,t:1527872966516};\\\", \\\"{x:1396,y:918,t:1527872966534};\\\", \\\"{x:1398,y:909,t:1527872966550};\\\", \\\"{x:1399,y:893,t:1527872966566};\\\", \\\"{x:1399,y:888,t:1527872966583};\\\", \\\"{x:1401,y:881,t:1527872966599};\\\", \\\"{x:1402,y:878,t:1527872966617};\\\", \\\"{x:1402,y:873,t:1527872966633};\\\", \\\"{x:1403,y:869,t:1527872966650};\\\", \\\"{x:1405,y:860,t:1527872966666};\\\", \\\"{x:1407,y:846,t:1527872966684};\\\", \\\"{x:1411,y:834,t:1527872966700};\\\", \\\"{x:1413,y:826,t:1527872966717};\\\", \\\"{x:1415,y:822,t:1527872966734};\\\", \\\"{x:1416,y:820,t:1527872966750};\\\", \\\"{x:1416,y:819,t:1527872966768};\\\", \\\"{x:1417,y:817,t:1527872966784};\\\", \\\"{x:1417,y:816,t:1527872966801};\\\", \\\"{x:1418,y:813,t:1527872966817};\\\", \\\"{x:1418,y:808,t:1527872966835};\\\", \\\"{x:1418,y:805,t:1527872966850};\\\", \\\"{x:1418,y:802,t:1527872966868};\\\", \\\"{x:1418,y:800,t:1527872966885};\\\", \\\"{x:1418,y:799,t:1527872966901};\\\", \\\"{x:1418,y:797,t:1527872966917};\\\", \\\"{x:1418,y:796,t:1527872966934};\\\", \\\"{x:1418,y:794,t:1527872967127};\\\", \\\"{x:1417,y:786,t:1527872967134};\\\", \\\"{x:1414,y:766,t:1527872967152};\\\", \\\"{x:1412,y:753,t:1527872967168};\\\", \\\"{x:1412,y:744,t:1527872967184};\\\", \\\"{x:1412,y:734,t:1527872967201};\\\", \\\"{x:1412,y:719,t:1527872967219};\\\", \\\"{x:1412,y:702,t:1527872967236};\\\", \\\"{x:1412,y:691,t:1527872967252};\\\", \\\"{x:1414,y:685,t:1527872967268};\\\", \\\"{x:1414,y:682,t:1527872967286};\\\", \\\"{x:1415,y:676,t:1527872967302};\\\", \\\"{x:1417,y:673,t:1527872967318};\\\", \\\"{x:1417,y:668,t:1527872967336};\\\", \\\"{x:1417,y:663,t:1527872967352};\\\", \\\"{x:1418,y:654,t:1527872967368};\\\", \\\"{x:1418,y:647,t:1527872967385};\\\", \\\"{x:1418,y:643,t:1527872967403};\\\", \\\"{x:1418,y:639,t:1527872967418};\\\", \\\"{x:1418,y:635,t:1527872967435};\\\", \\\"{x:1418,y:629,t:1527872967453};\\\", \\\"{x:1417,y:621,t:1527872967469};\\\", \\\"{x:1416,y:612,t:1527872967486};\\\", \\\"{x:1411,y:598,t:1527872967502};\\\", \\\"{x:1410,y:593,t:1527872967519};\\\", \\\"{x:1407,y:586,t:1527872967536};\\\", \\\"{x:1405,y:581,t:1527872967552};\\\", \\\"{x:1404,y:579,t:1527872967570};\\\", \\\"{x:1403,y:576,t:1527872967586};\\\", \\\"{x:1403,y:574,t:1527872967603};\\\", \\\"{x:1402,y:572,t:1527872967620};\\\", \\\"{x:1402,y:571,t:1527872967637};\\\", \\\"{x:1402,y:570,t:1527872967653};\\\", \\\"{x:1402,y:569,t:1527872967670};\\\", \\\"{x:1402,y:568,t:1527872967726};\\\", \\\"{x:1402,y:567,t:1527872967750};\\\", \\\"{x:1402,y:566,t:1527872967766};\\\", \\\"{x:1403,y:566,t:1527872967782};\\\", \\\"{x:1404,y:566,t:1527872967822};\\\", \\\"{x:1405,y:565,t:1527872967836};\\\", \\\"{x:1407,y:564,t:1527872967854};\\\", \\\"{x:1408,y:564,t:1527872967871};\\\", \\\"{x:1408,y:563,t:1527872967887};\\\", \\\"{x:1409,y:563,t:1527872967906};\\\", \\\"{x:1410,y:563,t:1527872967920};\\\", \\\"{x:1411,y:562,t:1527872967949};\\\", \\\"{x:1412,y:562,t:1527872967997};\\\", \\\"{x:1413,y:561,t:1527872968029};\\\", \\\"{x:1413,y:562,t:1527872970103};\\\", \\\"{x:1414,y:563,t:1527872972183};\\\", \\\"{x:1414,y:565,t:1527872972206};\\\", \\\"{x:1414,y:566,t:1527872972230};\\\", \\\"{x:1414,y:567,t:1527872972238};\\\", \\\"{x:1414,y:568,t:1527872972250};\\\", \\\"{x:1415,y:569,t:1527872972267};\\\", \\\"{x:1415,y:572,t:1527872972283};\\\", \\\"{x:1415,y:577,t:1527872972300};\\\", \\\"{x:1415,y:582,t:1527872972317};\\\", \\\"{x:1416,y:587,t:1527872972332};\\\", \\\"{x:1416,y:590,t:1527872972350};\\\", \\\"{x:1418,y:597,t:1527872972366};\\\", \\\"{x:1418,y:607,t:1527872972383};\\\", \\\"{x:1418,y:618,t:1527872972399};\\\", \\\"{x:1418,y:632,t:1527872972417};\\\", \\\"{x:1419,y:644,t:1527872972433};\\\", \\\"{x:1422,y:656,t:1527872972450};\\\", \\\"{x:1422,y:667,t:1527872972467};\\\", \\\"{x:1422,y:681,t:1527872972484};\\\", \\\"{x:1426,y:694,t:1527872972500};\\\", \\\"{x:1426,y:704,t:1527872972517};\\\", \\\"{x:1426,y:718,t:1527872972534};\\\", \\\"{x:1426,y:731,t:1527872972550};\\\", \\\"{x:1426,y:738,t:1527872972567};\\\", \\\"{x:1427,y:747,t:1527872972584};\\\", \\\"{x:1430,y:758,t:1527872972601};\\\", \\\"{x:1431,y:768,t:1527872972617};\\\", \\\"{x:1436,y:785,t:1527872972633};\\\", \\\"{x:1437,y:797,t:1527872972650};\\\", \\\"{x:1438,y:805,t:1527872972666};\\\", \\\"{x:1440,y:812,t:1527872972683};\\\", \\\"{x:1440,y:818,t:1527872972700};\\\", \\\"{x:1441,y:826,t:1527872972717};\\\", \\\"{x:1442,y:833,t:1527872972733};\\\", \\\"{x:1442,y:838,t:1527872972751};\\\", \\\"{x:1442,y:844,t:1527872972767};\\\", \\\"{x:1442,y:851,t:1527872972784};\\\", \\\"{x:1442,y:859,t:1527872972801};\\\", \\\"{x:1442,y:864,t:1527872972818};\\\", \\\"{x:1442,y:869,t:1527872972834};\\\", \\\"{x:1442,y:872,t:1527872972850};\\\", \\\"{x:1442,y:874,t:1527872972867};\\\", \\\"{x:1442,y:878,t:1527872972885};\\\", \\\"{x:1442,y:881,t:1527872972900};\\\", \\\"{x:1442,y:889,t:1527872972918};\\\", \\\"{x:1440,y:894,t:1527872972934};\\\", \\\"{x:1440,y:897,t:1527872972952};\\\", \\\"{x:1440,y:899,t:1527872972968};\\\", \\\"{x:1440,y:900,t:1527872972984};\\\", \\\"{x:1440,y:902,t:1527872973002};\\\", \\\"{x:1439,y:904,t:1527872973018};\\\", \\\"{x:1439,y:905,t:1527872973035};\\\", \\\"{x:1438,y:906,t:1527872973051};\\\", \\\"{x:1438,y:907,t:1527872973069};\\\", \\\"{x:1438,y:908,t:1527872973085};\\\", \\\"{x:1437,y:909,t:1527872973175};\\\", \\\"{x:1437,y:911,t:1527872973454};\\\", \\\"{x:1437,y:912,t:1527872973519};\\\", \\\"{x:1436,y:915,t:1527872973537};\\\", \\\"{x:1436,y:918,t:1527872973553};\\\", \\\"{x:1434,y:921,t:1527872973570};\\\", \\\"{x:1434,y:925,t:1527872973587};\\\", \\\"{x:1434,y:929,t:1527872973603};\\\", \\\"{x:1432,y:934,t:1527872973620};\\\", \\\"{x:1429,y:940,t:1527872973637};\\\", \\\"{x:1424,y:948,t:1527872973654};\\\", \\\"{x:1422,y:950,t:1527872973670};\\\", \\\"{x:1421,y:953,t:1527872973687};\\\", \\\"{x:1420,y:954,t:1527872973704};\\\", \\\"{x:1419,y:956,t:1527872973719};\\\", \\\"{x:1418,y:957,t:1527872973736};\\\", \\\"{x:1416,y:960,t:1527872973754};\\\", \\\"{x:1413,y:962,t:1527872973772};\\\", \\\"{x:1409,y:965,t:1527872973787};\\\", \\\"{x:1408,y:966,t:1527872973804};\\\", \\\"{x:1405,y:968,t:1527872973820};\\\", \\\"{x:1404,y:969,t:1527872973837};\\\", \\\"{x:1402,y:970,t:1527872973854};\\\", \\\"{x:1398,y:972,t:1527872973870};\\\", \\\"{x:1397,y:972,t:1527872973894};\\\", \\\"{x:1396,y:972,t:1527872973904};\\\", \\\"{x:1395,y:972,t:1527872973920};\\\", \\\"{x:1394,y:972,t:1527872973938};\\\", \\\"{x:1393,y:973,t:1527872973953};\\\", \\\"{x:1392,y:973,t:1527872973971};\\\", \\\"{x:1391,y:973,t:1527872973988};\\\", \\\"{x:1389,y:973,t:1527872974004};\\\", \\\"{x:1387,y:973,t:1527872974095};\\\", \\\"{x:1386,y:973,t:1527872974110};\\\", \\\"{x:1386,y:972,t:1527872974126};\\\", \\\"{x:1386,y:971,t:1527872974138};\\\", \\\"{x:1386,y:969,t:1527872974154};\\\", \\\"{x:1385,y:967,t:1527872974172};\\\", \\\"{x:1385,y:965,t:1527872974188};\\\", \\\"{x:1385,y:962,t:1527872974205};\\\", \\\"{x:1385,y:955,t:1527872974222};\\\", \\\"{x:1385,y:949,t:1527872974238};\\\", \\\"{x:1383,y:945,t:1527872974254};\\\", \\\"{x:1383,y:940,t:1527872974272};\\\", \\\"{x:1383,y:932,t:1527872974289};\\\", \\\"{x:1383,y:918,t:1527872974305};\\\", \\\"{x:1383,y:903,t:1527872974322};\\\", \\\"{x:1383,y:883,t:1527872974338};\\\", \\\"{x:1383,y:865,t:1527872974355};\\\", \\\"{x:1383,y:851,t:1527872974371};\\\", \\\"{x:1383,y:837,t:1527872974388};\\\", \\\"{x:1383,y:823,t:1527872974405};\\\", \\\"{x:1383,y:815,t:1527872974422};\\\", \\\"{x:1383,y:807,t:1527872974438};\\\", \\\"{x:1383,y:798,t:1527872974455};\\\", \\\"{x:1383,y:793,t:1527872974472};\\\", \\\"{x:1383,y:788,t:1527872974488};\\\", \\\"{x:1383,y:784,t:1527872974506};\\\", \\\"{x:1383,y:779,t:1527872974523};\\\", \\\"{x:1383,y:776,t:1527872974538};\\\", \\\"{x:1383,y:773,t:1527872974555};\\\", \\\"{x:1383,y:772,t:1527872974572};\\\", \\\"{x:1383,y:770,t:1527872974589};\\\", \\\"{x:1383,y:769,t:1527872974613};\\\", \\\"{x:1383,y:768,t:1527872974638};\\\", \\\"{x:1383,y:767,t:1527872974655};\\\", \\\"{x:1383,y:766,t:1527872974710};\\\", \\\"{x:1382,y:764,t:1527872975007};\\\", \\\"{x:1381,y:763,t:1527872975086};\\\", \\\"{x:1380,y:762,t:1527872975183};\\\", \\\"{x:1379,y:761,t:1527872975222};\\\", \\\"{x:1378,y:761,t:1527872975246};\\\", \\\"{x:1377,y:760,t:1527872975258};\\\", \\\"{x:1376,y:759,t:1527872975295};\\\", \\\"{x:1376,y:760,t:1527872977647};\\\", \\\"{x:1376,y:762,t:1527872977681};\\\", \\\"{x:1376,y:763,t:1527872977697};\\\", \\\"{x:1376,y:764,t:1527872977715};\\\", \\\"{x:1376,y:765,t:1527872977731};\\\", \\\"{x:1376,y:766,t:1527872977747};\\\", \\\"{x:1376,y:768,t:1527872977765};\\\", \\\"{x:1376,y:776,t:1527872977782};\\\", \\\"{x:1376,y:780,t:1527872977798};\\\", \\\"{x:1378,y:788,t:1527872977815};\\\", \\\"{x:1379,y:800,t:1527872977832};\\\", \\\"{x:1382,y:814,t:1527872977849};\\\", \\\"{x:1382,y:828,t:1527872977865};\\\", \\\"{x:1383,y:838,t:1527872977881};\\\", \\\"{x:1384,y:852,t:1527872977898};\\\", \\\"{x:1385,y:862,t:1527872977915};\\\", \\\"{x:1385,y:870,t:1527872977932};\\\", \\\"{x:1385,y:879,t:1527872977949};\\\", \\\"{x:1385,y:890,t:1527872977966};\\\", \\\"{x:1385,y:899,t:1527872977982};\\\", \\\"{x:1385,y:907,t:1527872977999};\\\", \\\"{x:1385,y:916,t:1527872978016};\\\", \\\"{x:1380,y:927,t:1527872978032};\\\", \\\"{x:1375,y:935,t:1527872978048};\\\", \\\"{x:1369,y:941,t:1527872978066};\\\", \\\"{x:1365,y:945,t:1527872978083};\\\", \\\"{x:1362,y:947,t:1527872978099};\\\", \\\"{x:1361,y:948,t:1527872978118};\\\", \\\"{x:1360,y:948,t:1527872978143};\\\", \\\"{x:1360,y:950,t:1527872978174};\\\", \\\"{x:1359,y:950,t:1527872978199};\\\", \\\"{x:1359,y:949,t:1527872978334};\\\", \\\"{x:1359,y:948,t:1527872978350};\\\", \\\"{x:1359,y:945,t:1527872978366};\\\", \\\"{x:1359,y:944,t:1527872978383};\\\", \\\"{x:1358,y:939,t:1527872978400};\\\", \\\"{x:1357,y:935,t:1527872978417};\\\", \\\"{x:1356,y:931,t:1527872978433};\\\", \\\"{x:1354,y:927,t:1527872978450};\\\", \\\"{x:1353,y:922,t:1527872978467};\\\", \\\"{x:1353,y:916,t:1527872978484};\\\", \\\"{x:1350,y:911,t:1527872978500};\\\", \\\"{x:1349,y:905,t:1527872978517};\\\", \\\"{x:1346,y:898,t:1527872978533};\\\", \\\"{x:1346,y:892,t:1527872978550};\\\", \\\"{x:1345,y:888,t:1527872978566};\\\", \\\"{x:1345,y:885,t:1527872978583};\\\", \\\"{x:1345,y:884,t:1527872978600};\\\", \\\"{x:1345,y:883,t:1527872978616};\\\", \\\"{x:1345,y:884,t:1527872978798};\\\", \\\"{x:1345,y:885,t:1527872978805};\\\", \\\"{x:1345,y:888,t:1527872978817};\\\", \\\"{x:1345,y:889,t:1527872978835};\\\", \\\"{x:1345,y:891,t:1527872978850};\\\", \\\"{x:1345,y:892,t:1527872978878};\\\", \\\"{x:1345,y:893,t:1527872978902};\\\", \\\"{x:1345,y:894,t:1527872978918};\\\", \\\"{x:1345,y:895,t:1527872979015};\\\", \\\"{x:1345,y:896,t:1527872979022};\\\", \\\"{x:1345,y:897,t:1527872979034};\\\", \\\"{x:1345,y:898,t:1527872979053};\\\", \\\"{x:1345,y:899,t:1527872979102};\\\", \\\"{x:1345,y:900,t:1527872979125};\\\", \\\"{x:1346,y:900,t:1527872979862};\\\", \\\"{x:1347,y:900,t:1527872980086};\\\", \\\"{x:1348,y:899,t:1527872980110};\\\", \\\"{x:1348,y:898,t:1527872980149};\\\", \\\"{x:1348,y:897,t:1527872980198};\\\", \\\"{x:1349,y:896,t:1527872980255};\\\", \\\"{x:1349,y:897,t:1527872981318};\\\", \\\"{x:1349,y:898,t:1527872981325};\\\", \\\"{x:1349,y:901,t:1527872981342};\\\", \\\"{x:1348,y:906,t:1527872981359};\\\", \\\"{x:1348,y:908,t:1527872981375};\\\", \\\"{x:1348,y:911,t:1527872981392};\\\", \\\"{x:1346,y:914,t:1527872981409};\\\", \\\"{x:1346,y:917,t:1527872981425};\\\", \\\"{x:1345,y:918,t:1527872981442};\\\", \\\"{x:1344,y:920,t:1527872981459};\\\", \\\"{x:1343,y:921,t:1527872981475};\\\", \\\"{x:1342,y:923,t:1527872981494};\\\", \\\"{x:1342,y:924,t:1527872981518};\\\", \\\"{x:1341,y:925,t:1527872981526};\\\", \\\"{x:1339,y:927,t:1527872981542};\\\", \\\"{x:1338,y:930,t:1527872981559};\\\", \\\"{x:1336,y:932,t:1527872981576};\\\", \\\"{x:1334,y:934,t:1527872981592};\\\", \\\"{x:1333,y:934,t:1527872981734};\\\", \\\"{x:1332,y:934,t:1527872981767};\\\", \\\"{x:1332,y:933,t:1527872981782};\\\", \\\"{x:1331,y:931,t:1527872981793};\\\", \\\"{x:1330,y:930,t:1527872981810};\\\", \\\"{x:1330,y:928,t:1527872981826};\\\", \\\"{x:1330,y:927,t:1527872981843};\\\", \\\"{x:1330,y:926,t:1527872981860};\\\", \\\"{x:1329,y:924,t:1527872981877};\\\", \\\"{x:1329,y:920,t:1527872981893};\\\", \\\"{x:1329,y:915,t:1527872981910};\\\", \\\"{x:1329,y:912,t:1527872981926};\\\", \\\"{x:1329,y:911,t:1527872981943};\\\", \\\"{x:1329,y:910,t:1527872981960};\\\", \\\"{x:1329,y:908,t:1527872981976};\\\", \\\"{x:1329,y:905,t:1527872981993};\\\", \\\"{x:1328,y:904,t:1527872982013};\\\", \\\"{x:1328,y:902,t:1527872982026};\\\", \\\"{x:1327,y:900,t:1527872982043};\\\", \\\"{x:1327,y:899,t:1527872982059};\\\", \\\"{x:1326,y:898,t:1527872982076};\\\", \\\"{x:1326,y:897,t:1527872982093};\\\", \\\"{x:1326,y:895,t:1527872982110};\\\", \\\"{x:1326,y:894,t:1527872982127};\\\", \\\"{x:1325,y:894,t:1527872982143};\\\", \\\"{x:1324,y:892,t:1527872982161};\\\", \\\"{x:1324,y:891,t:1527872982176};\\\", \\\"{x:1323,y:891,t:1527872983822};\\\", \\\"{x:1322,y:892,t:1527872983846};\\\", \\\"{x:1321,y:893,t:1527872983934};\\\", \\\"{x:1321,y:894,t:1527872983950};\\\", \\\"{x:1321,y:896,t:1527872983966};\\\", \\\"{x:1320,y:898,t:1527872983983};\\\", \\\"{x:1320,y:900,t:1527872983999};\\\", \\\"{x:1319,y:903,t:1527872984016};\\\", \\\"{x:1318,y:910,t:1527872984032};\\\", \\\"{x:1314,y:916,t:1527872984048};\\\", \\\"{x:1313,y:921,t:1527872984065};\\\", \\\"{x:1312,y:923,t:1527872984082};\\\", \\\"{x:1309,y:927,t:1527872984098};\\\", \\\"{x:1305,y:932,t:1527872984115};\\\", \\\"{x:1304,y:933,t:1527872984132};\\\", \\\"{x:1303,y:936,t:1527872984150};\\\", \\\"{x:1302,y:938,t:1527872984166};\\\", \\\"{x:1301,y:939,t:1527872984183};\\\", \\\"{x:1300,y:942,t:1527872984200};\\\", \\\"{x:1298,y:944,t:1527872984215};\\\", \\\"{x:1298,y:945,t:1527872984238};\\\", \\\"{x:1297,y:947,t:1527872984261};\\\", \\\"{x:1296,y:947,t:1527872984382};\\\", \\\"{x:1295,y:946,t:1527872984406};\\\", \\\"{x:1295,y:944,t:1527872984417};\\\", \\\"{x:1294,y:937,t:1527872984434};\\\", \\\"{x:1293,y:929,t:1527872984451};\\\", \\\"{x:1291,y:918,t:1527872984467};\\\", \\\"{x:1290,y:910,t:1527872984484};\\\", \\\"{x:1289,y:902,t:1527872984502};\\\", \\\"{x:1287,y:888,t:1527872984517};\\\", \\\"{x:1286,y:884,t:1527872984534};\\\", \\\"{x:1286,y:881,t:1527872984552};\\\", \\\"{x:1286,y:879,t:1527872984567};\\\", \\\"{x:1286,y:878,t:1527872984584};\\\", \\\"{x:1286,y:876,t:1527872984601};\\\", \\\"{x:1286,y:875,t:1527872984618};\\\", \\\"{x:1286,y:874,t:1527872984633};\\\", \\\"{x:1286,y:873,t:1527872984650};\\\", \\\"{x:1286,y:872,t:1527872984667};\\\", \\\"{x:1286,y:870,t:1527872984684};\\\", \\\"{x:1287,y:865,t:1527872984700};\\\", \\\"{x:1287,y:864,t:1527872984717};\\\", \\\"{x:1288,y:862,t:1527872984734};\\\", \\\"{x:1288,y:861,t:1527872984757};\\\", \\\"{x:1288,y:860,t:1527872984774};\\\", \\\"{x:1288,y:859,t:1527872984785};\\\", \\\"{x:1288,y:858,t:1527872984813};\\\", \\\"{x:1288,y:857,t:1527872984830};\\\", \\\"{x:1288,y:856,t:1527872984845};\\\", \\\"{x:1287,y:856,t:1527872984999};\\\", \\\"{x:1285,y:855,t:1527872985006};\\\", \\\"{x:1282,y:854,t:1527872985019};\\\", \\\"{x:1261,y:854,t:1527872985034};\\\", \\\"{x:1224,y:854,t:1527872985051};\\\", \\\"{x:1193,y:854,t:1527872985068};\\\", \\\"{x:1138,y:848,t:1527872985084};\\\", \\\"{x:1041,y:834,t:1527872985102};\\\", \\\"{x:985,y:825,t:1527872985119};\\\", \\\"{x:923,y:813,t:1527872985135};\\\", \\\"{x:869,y:797,t:1527872985152};\\\", \\\"{x:822,y:783,t:1527872985169};\\\", \\\"{x:783,y:772,t:1527872985186};\\\", \\\"{x:750,y:763,t:1527872985202};\\\", \\\"{x:730,y:754,t:1527872985219};\\\", \\\"{x:704,y:747,t:1527872985235};\\\", \\\"{x:679,y:740,t:1527872985252};\\\", \\\"{x:654,y:736,t:1527872985268};\\\", \\\"{x:623,y:731,t:1527872985286};\\\", \\\"{x:609,y:730,t:1527872985303};\\\", \\\"{x:603,y:729,t:1527872985319};\\\", \\\"{x:599,y:729,t:1527872985336};\\\", \\\"{x:593,y:727,t:1527872985352};\\\", \\\"{x:581,y:725,t:1527872985369};\\\", \\\"{x:564,y:722,t:1527872985387};\\\", \\\"{x:546,y:721,t:1527872985402};\\\", \\\"{x:533,y:719,t:1527872985419};\\\", \\\"{x:520,y:717,t:1527872985440};\\\", \\\"{x:517,y:717,t:1527872985457};\\\", \\\"{x:515,y:717,t:1527872985473};\\\", \\\"{x:511,y:717,t:1527872985490};\\\", \\\"{x:508,y:717,t:1527872985507};\\\", \\\"{x:503,y:717,t:1527872985524};\\\", \\\"{x:500,y:717,t:1527872985540};\\\", \\\"{x:498,y:717,t:1527872985557};\\\" ] }, { \\\"rt\\\": 55844, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 228538, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -I -12 PM-03 PM-O -12 PM-12 PM-02 PM-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:716,t:1527872987901};\\\", \\\"{x:493,y:702,t:1527872987912};\\\", \\\"{x:482,y:683,t:1527872987929};\\\", \\\"{x:475,y:668,t:1527872987944};\\\", \\\"{x:469,y:655,t:1527872987961};\\\", \\\"{x:461,y:641,t:1527872987977};\\\", \\\"{x:458,y:627,t:1527872987994};\\\", \\\"{x:455,y:614,t:1527872988012};\\\", \\\"{x:455,y:608,t:1527872988026};\\\", \\\"{x:454,y:601,t:1527872988044};\\\", \\\"{x:454,y:597,t:1527872988060};\\\", \\\"{x:453,y:594,t:1527872988077};\\\", \\\"{x:453,y:591,t:1527872988093};\\\", \\\"{x:452,y:588,t:1527872988111};\\\", \\\"{x:452,y:582,t:1527872988127};\\\", \\\"{x:452,y:576,t:1527872988144};\\\", \\\"{x:452,y:572,t:1527872988161};\\\", \\\"{x:452,y:565,t:1527872988178};\\\", \\\"{x:452,y:556,t:1527872988194};\\\", \\\"{x:454,y:546,t:1527872988212};\\\", \\\"{x:456,y:536,t:1527872988228};\\\", \\\"{x:458,y:528,t:1527872988244};\\\", \\\"{x:459,y:515,t:1527872988262};\\\", \\\"{x:459,y:508,t:1527872988278};\\\", \\\"{x:460,y:503,t:1527872988293};\\\", \\\"{x:460,y:500,t:1527872988311};\\\", \\\"{x:460,y:493,t:1527872988327};\\\", \\\"{x:462,y:488,t:1527872988345};\\\", \\\"{x:462,y:485,t:1527872988361};\\\", \\\"{x:462,y:484,t:1527872988388};\\\", \\\"{x:463,y:483,t:1527872988614};\\\", \\\"{x:462,y:483,t:1527872988750};\\\", \\\"{x:462,y:484,t:1527872988766};\\\", \\\"{x:461,y:485,t:1527872988780};\\\", \\\"{x:461,y:486,t:1527872988814};\\\", \\\"{x:460,y:488,t:1527872988837};\\\", \\\"{x:460,y:489,t:1527872988847};\\\", \\\"{x:460,y:490,t:1527872988864};\\\", \\\"{x:460,y:491,t:1527872988880};\\\", \\\"{x:460,y:492,t:1527872988901};\\\", \\\"{x:460,y:493,t:1527872988926};\\\", \\\"{x:460,y:494,t:1527872988982};\\\", \\\"{x:460,y:495,t:1527872989102};\\\", \\\"{x:460,y:496,t:1527872989134};\\\", \\\"{x:460,y:497,t:1527872989246};\\\", \\\"{x:459,y:497,t:1527872989318};\\\", \\\"{x:458,y:498,t:1527872989332};\\\", \\\"{x:457,y:499,t:1527872989349};\\\", \\\"{x:455,y:500,t:1527872989366};\\\", \\\"{x:453,y:500,t:1527872989398};\\\", \\\"{x:452,y:501,t:1527872989462};\\\", \\\"{x:451,y:502,t:1527872989510};\\\", \\\"{x:450,y:502,t:1527872989518};\\\", \\\"{x:449,y:503,t:1527872989556};\\\", \\\"{x:448,y:504,t:1527872989597};\\\", \\\"{x:447,y:504,t:1527872989621};\\\", \\\"{x:446,y:504,t:1527872989645};\\\", \\\"{x:446,y:505,t:1527872989701};\\\", \\\"{x:446,y:507,t:1527872989717};\\\", \\\"{x:445,y:507,t:1527872989733};\\\", \\\"{x:444,y:508,t:1527872989751};\\\", \\\"{x:443,y:509,t:1527872989773};\\\", \\\"{x:443,y:510,t:1527872989950};\\\", \\\"{x:443,y:511,t:1527872990990};\\\", \\\"{x:447,y:515,t:1527872991007};\\\", \\\"{x:451,y:517,t:1527872991023};\\\", \\\"{x:454,y:518,t:1527872991040};\\\", \\\"{x:463,y:521,t:1527872991058};\\\", \\\"{x:476,y:525,t:1527872991073};\\\", \\\"{x:497,y:526,t:1527872991094};\\\", \\\"{x:518,y:529,t:1527872991111};\\\", \\\"{x:543,y:533,t:1527872991127};\\\", \\\"{x:574,y:536,t:1527872991145};\\\", \\\"{x:609,y:543,t:1527872991163};\\\", \\\"{x:633,y:545,t:1527872991180};\\\", \\\"{x:718,y:558,t:1527872991197};\\\", \\\"{x:810,y:571,t:1527872991214};\\\", \\\"{x:895,y:590,t:1527872991230};\\\", \\\"{x:979,y:605,t:1527872991246};\\\", \\\"{x:1039,y:616,t:1527872991263};\\\", \\\"{x:1084,y:624,t:1527872991280};\\\", \\\"{x:1111,y:631,t:1527872991297};\\\", \\\"{x:1121,y:635,t:1527872991312};\\\", \\\"{x:1123,y:635,t:1527872991342};\\\", \\\"{x:1125,y:636,t:1527872991606};\\\", \\\"{x:1129,y:639,t:1527872991614};\\\", \\\"{x:1138,y:645,t:1527872991631};\\\", \\\"{x:1159,y:653,t:1527872991647};\\\", \\\"{x:1183,y:661,t:1527872991664};\\\", \\\"{x:1216,y:670,t:1527872991680};\\\", \\\"{x:1245,y:677,t:1527872991697};\\\", \\\"{x:1273,y:685,t:1527872991714};\\\", \\\"{x:1301,y:691,t:1527872991730};\\\", \\\"{x:1323,y:697,t:1527872991747};\\\", \\\"{x:1340,y:700,t:1527872991764};\\\", \\\"{x:1356,y:704,t:1527872991781};\\\", \\\"{x:1373,y:709,t:1527872991797};\\\", \\\"{x:1386,y:712,t:1527872991814};\\\", \\\"{x:1398,y:715,t:1527872991830};\\\", \\\"{x:1409,y:719,t:1527872991847};\\\", \\\"{x:1423,y:720,t:1527872991864};\\\", \\\"{x:1435,y:723,t:1527872991881};\\\", \\\"{x:1448,y:726,t:1527872991897};\\\", \\\"{x:1464,y:731,t:1527872991914};\\\", \\\"{x:1479,y:736,t:1527872991931};\\\", \\\"{x:1491,y:738,t:1527872991948};\\\", \\\"{x:1503,y:741,t:1527872991965};\\\", \\\"{x:1512,y:745,t:1527872991980};\\\", \\\"{x:1519,y:749,t:1527872991997};\\\", \\\"{x:1522,y:751,t:1527872992014};\\\", \\\"{x:1525,y:754,t:1527872992031};\\\", \\\"{x:1527,y:755,t:1527872992047};\\\", \\\"{x:1529,y:757,t:1527872992064};\\\", \\\"{x:1533,y:760,t:1527872992080};\\\", \\\"{x:1536,y:761,t:1527872992097};\\\", \\\"{x:1539,y:763,t:1527872992114};\\\", \\\"{x:1543,y:765,t:1527872992130};\\\", \\\"{x:1547,y:768,t:1527872992147};\\\", \\\"{x:1555,y:772,t:1527872992165};\\\", \\\"{x:1564,y:775,t:1527872992181};\\\", \\\"{x:1568,y:775,t:1527872992197};\\\", \\\"{x:1575,y:776,t:1527872992215};\\\", \\\"{x:1578,y:777,t:1527872992232};\\\", \\\"{x:1581,y:777,t:1527872992248};\\\", \\\"{x:1582,y:777,t:1527872992265};\\\", \\\"{x:1584,y:778,t:1527872992282};\\\", \\\"{x:1588,y:778,t:1527872992298};\\\", \\\"{x:1595,y:778,t:1527872992315};\\\", \\\"{x:1604,y:778,t:1527872992332};\\\", \\\"{x:1611,y:778,t:1527872992348};\\\", \\\"{x:1616,y:778,t:1527872992364};\\\", \\\"{x:1621,y:777,t:1527872992382};\\\", \\\"{x:1623,y:777,t:1527872992397};\\\", \\\"{x:1624,y:776,t:1527872992415};\\\", \\\"{x:1625,y:775,t:1527872992431};\\\", \\\"{x:1627,y:774,t:1527872992448};\\\", \\\"{x:1628,y:772,t:1527872992464};\\\", \\\"{x:1630,y:770,t:1527872992482};\\\", \\\"{x:1633,y:768,t:1527872992498};\\\", \\\"{x:1635,y:767,t:1527872992515};\\\", \\\"{x:1639,y:765,t:1527872992532};\\\", \\\"{x:1642,y:764,t:1527872992550};\\\", \\\"{x:1646,y:762,t:1527872992564};\\\", \\\"{x:1650,y:760,t:1527872992580};\\\", \\\"{x:1654,y:754,t:1527872992598};\\\", \\\"{x:1655,y:752,t:1527872992614};\\\", \\\"{x:1658,y:748,t:1527872992631};\\\", \\\"{x:1659,y:743,t:1527872992647};\\\", \\\"{x:1659,y:739,t:1527872992664};\\\", \\\"{x:1660,y:735,t:1527872992681};\\\", \\\"{x:1661,y:728,t:1527872992698};\\\", \\\"{x:1661,y:724,t:1527872992714};\\\", \\\"{x:1661,y:718,t:1527872992732};\\\", \\\"{x:1661,y:713,t:1527872992748};\\\", \\\"{x:1660,y:708,t:1527872992764};\\\", \\\"{x:1654,y:700,t:1527872992782};\\\", \\\"{x:1651,y:696,t:1527872992797};\\\", \\\"{x:1646,y:690,t:1527872992815};\\\", \\\"{x:1642,y:678,t:1527872992831};\\\", \\\"{x:1634,y:665,t:1527872992848};\\\", \\\"{x:1626,y:652,t:1527872992865};\\\", \\\"{x:1621,y:645,t:1527872992881};\\\", \\\"{x:1618,y:639,t:1527872992898};\\\", \\\"{x:1614,y:632,t:1527872992914};\\\", \\\"{x:1610,y:627,t:1527872992931};\\\", \\\"{x:1607,y:622,t:1527872992948};\\\", \\\"{x:1602,y:617,t:1527872992964};\\\", \\\"{x:1595,y:607,t:1527872992982};\\\", \\\"{x:1591,y:604,t:1527872992998};\\\", \\\"{x:1586,y:598,t:1527872993015};\\\", \\\"{x:1579,y:591,t:1527872993031};\\\", \\\"{x:1571,y:583,t:1527872993048};\\\", \\\"{x:1562,y:572,t:1527872993065};\\\", \\\"{x:1548,y:561,t:1527872993082};\\\", \\\"{x:1532,y:549,t:1527872993099};\\\", \\\"{x:1516,y:540,t:1527872993115};\\\", \\\"{x:1500,y:533,t:1527872993131};\\\", \\\"{x:1486,y:525,t:1527872993148};\\\", \\\"{x:1457,y:504,t:1527872993164};\\\", \\\"{x:1443,y:494,t:1527872993180};\\\", \\\"{x:1436,y:490,t:1527872993198};\\\", \\\"{x:1432,y:487,t:1527872993215};\\\", \\\"{x:1429,y:484,t:1527872993231};\\\", \\\"{x:1427,y:483,t:1527872993248};\\\", \\\"{x:1426,y:481,t:1527872993265};\\\", \\\"{x:1424,y:480,t:1527872993281};\\\", \\\"{x:1423,y:477,t:1527872993298};\\\", \\\"{x:1422,y:474,t:1527872993315};\\\", \\\"{x:1419,y:468,t:1527872993331};\\\", \\\"{x:1417,y:465,t:1527872993348};\\\", \\\"{x:1414,y:462,t:1527872993365};\\\", \\\"{x:1413,y:461,t:1527872993381};\\\", \\\"{x:1411,y:460,t:1527872993398};\\\", \\\"{x:1410,y:459,t:1527872993415};\\\", \\\"{x:1408,y:459,t:1527872993432};\\\", \\\"{x:1407,y:458,t:1527872993448};\\\", \\\"{x:1405,y:458,t:1527872993465};\\\", \\\"{x:1404,y:458,t:1527872993486};\\\", \\\"{x:1403,y:458,t:1527872993510};\\\", \\\"{x:1401,y:458,t:1527872993566};\\\", \\\"{x:1396,y:458,t:1527872993582};\\\", \\\"{x:1391,y:462,t:1527872993598};\\\", \\\"{x:1385,y:467,t:1527872993615};\\\", \\\"{x:1380,y:469,t:1527872993632};\\\", \\\"{x:1375,y:472,t:1527872993648};\\\", \\\"{x:1371,y:475,t:1527872993665};\\\", \\\"{x:1366,y:477,t:1527872993682};\\\", \\\"{x:1358,y:481,t:1527872993698};\\\", \\\"{x:1353,y:484,t:1527872993716};\\\", \\\"{x:1348,y:485,t:1527872993736};\\\", \\\"{x:1346,y:487,t:1527872993752};\\\", \\\"{x:1342,y:488,t:1527872993770};\\\", \\\"{x:1341,y:488,t:1527872993786};\\\", \\\"{x:1340,y:489,t:1527872993825};\\\", \\\"{x:1339,y:490,t:1527872993836};\\\", \\\"{x:1338,y:490,t:1527872993852};\\\", \\\"{x:1334,y:492,t:1527872993868};\\\", \\\"{x:1330,y:493,t:1527872993886};\\\", \\\"{x:1328,y:494,t:1527872993902};\\\", \\\"{x:1323,y:495,t:1527872993919};\\\", \\\"{x:1319,y:497,t:1527872993936};\\\", \\\"{x:1316,y:498,t:1527872993952};\\\", \\\"{x:1312,y:499,t:1527872993968};\\\", \\\"{x:1310,y:501,t:1527872993986};\\\", \\\"{x:1307,y:501,t:1527872994003};\\\", \\\"{x:1307,y:502,t:1527872994019};\\\", \\\"{x:1305,y:503,t:1527872994036};\\\", \\\"{x:1304,y:503,t:1527872994053};\\\", \\\"{x:1303,y:504,t:1527872994097};\\\", \\\"{x:1302,y:504,t:1527872994105};\\\", \\\"{x:1301,y:504,t:1527872994121};\\\", \\\"{x:1301,y:505,t:1527872994137};\\\", \\\"{x:1299,y:506,t:1527872994161};\\\", \\\"{x:1299,y:507,t:1527872994210};\\\", \\\"{x:1298,y:508,t:1527872994266};\\\", \\\"{x:1297,y:508,t:1527872994298};\\\", \\\"{x:1297,y:509,t:1527872994363};\\\", \\\"{x:1298,y:508,t:1527872995121};\\\", \\\"{x:1301,y:505,t:1527872995137};\\\", \\\"{x:1302,y:503,t:1527872995153};\\\", \\\"{x:1302,y:502,t:1527872995169};\\\", \\\"{x:1303,y:502,t:1527872995225};\\\", \\\"{x:1304,y:502,t:1527872995298};\\\", \\\"{x:1306,y:502,t:1527872995313};\\\", \\\"{x:1307,y:502,t:1527872995330};\\\", \\\"{x:1308,y:502,t:1527872995337};\\\", \\\"{x:1308,y:503,t:1527872995353};\\\", \\\"{x:1310,y:504,t:1527872995370};\\\", \\\"{x:1312,y:504,t:1527872995387};\\\", \\\"{x:1313,y:506,t:1527872995404};\\\", \\\"{x:1314,y:506,t:1527872995441};\\\", \\\"{x:1315,y:506,t:1527872995458};\\\", \\\"{x:1316,y:506,t:1527872995473};\\\", \\\"{x:1317,y:506,t:1527872995487};\\\", \\\"{x:1318,y:506,t:1527872995553};\\\", \\\"{x:1319,y:507,t:1527872996258};\\\", \\\"{x:1319,y:509,t:1527872996271};\\\", \\\"{x:1319,y:514,t:1527872996287};\\\", \\\"{x:1319,y:528,t:1527872996304};\\\", \\\"{x:1319,y:547,t:1527872996321};\\\", \\\"{x:1319,y:556,t:1527872996338};\\\", \\\"{x:1320,y:565,t:1527872996354};\\\", \\\"{x:1322,y:578,t:1527872996371};\\\", \\\"{x:1324,y:589,t:1527872996388};\\\", \\\"{x:1325,y:602,t:1527872996404};\\\", \\\"{x:1325,y:618,t:1527872996421};\\\", \\\"{x:1325,y:632,t:1527872996438};\\\", \\\"{x:1325,y:643,t:1527872996454};\\\", \\\"{x:1325,y:660,t:1527872996478};\\\", \\\"{x:1324,y:672,t:1527872996501};\\\", \\\"{x:1323,y:677,t:1527872996505};\\\", \\\"{x:1322,y:690,t:1527872996519};\\\", \\\"{x:1319,y:703,t:1527872996537};\\\", \\\"{x:1318,y:714,t:1527872996553};\\\", \\\"{x:1317,y:720,t:1527872996570};\\\", \\\"{x:1316,y:723,t:1527872996587};\\\", \\\"{x:1316,y:725,t:1527872996604};\\\", \\\"{x:1316,y:728,t:1527872996620};\\\", \\\"{x:1316,y:730,t:1527872996637};\\\", \\\"{x:1315,y:731,t:1527872996654};\\\", \\\"{x:1315,y:734,t:1527872996670};\\\", \\\"{x:1315,y:736,t:1527872996687};\\\", \\\"{x:1315,y:740,t:1527872996704};\\\", \\\"{x:1315,y:744,t:1527872996721};\\\", \\\"{x:1315,y:748,t:1527872996738};\\\", \\\"{x:1315,y:749,t:1527872996754};\\\", \\\"{x:1316,y:751,t:1527872996771};\\\", \\\"{x:1316,y:754,t:1527872996788};\\\", \\\"{x:1316,y:757,t:1527872996804};\\\", \\\"{x:1316,y:763,t:1527872996821};\\\", \\\"{x:1317,y:768,t:1527872996838};\\\", \\\"{x:1319,y:773,t:1527872996854};\\\", \\\"{x:1319,y:780,t:1527872996871};\\\", \\\"{x:1320,y:786,t:1527872996888};\\\", \\\"{x:1320,y:793,t:1527872996905};\\\", \\\"{x:1320,y:796,t:1527872996921};\\\", \\\"{x:1320,y:799,t:1527872996938};\\\", \\\"{x:1320,y:802,t:1527872996955};\\\", \\\"{x:1320,y:803,t:1527872996971};\\\", \\\"{x:1320,y:805,t:1527872996988};\\\", \\\"{x:1320,y:806,t:1527872997004};\\\", \\\"{x:1320,y:808,t:1527872997020};\\\", \\\"{x:1320,y:811,t:1527872997037};\\\", \\\"{x:1320,y:815,t:1527872997054};\\\", \\\"{x:1320,y:818,t:1527872997070};\\\", \\\"{x:1320,y:820,t:1527872997087};\\\", \\\"{x:1320,y:823,t:1527872997104};\\\", \\\"{x:1320,y:826,t:1527872997120};\\\", \\\"{x:1320,y:828,t:1527872997137};\\\", \\\"{x:1319,y:830,t:1527872997154};\\\", \\\"{x:1319,y:831,t:1527872997171};\\\", \\\"{x:1319,y:834,t:1527872997188};\\\", \\\"{x:1318,y:835,t:1527872997205};\\\", \\\"{x:1318,y:836,t:1527872997220};\\\", \\\"{x:1317,y:838,t:1527872997238};\\\", \\\"{x:1316,y:840,t:1527872997255};\\\", \\\"{x:1316,y:841,t:1527872997271};\\\", \\\"{x:1315,y:842,t:1527872997288};\\\", \\\"{x:1315,y:843,t:1527872997305};\\\", \\\"{x:1315,y:845,t:1527872997321};\\\", \\\"{x:1315,y:848,t:1527872997338};\\\", \\\"{x:1313,y:852,t:1527872997355};\\\", \\\"{x:1313,y:857,t:1527872997372};\\\", \\\"{x:1313,y:863,t:1527872997388};\\\", \\\"{x:1311,y:866,t:1527872997405};\\\", \\\"{x:1311,y:868,t:1527872997422};\\\", \\\"{x:1311,y:869,t:1527872997438};\\\", \\\"{x:1311,y:871,t:1527872997455};\\\", \\\"{x:1311,y:873,t:1527872997473};\\\", \\\"{x:1311,y:877,t:1527872997487};\\\", \\\"{x:1311,y:882,t:1527872997505};\\\", \\\"{x:1313,y:886,t:1527872997522};\\\", \\\"{x:1313,y:891,t:1527872997538};\\\", \\\"{x:1315,y:897,t:1527872997554};\\\", \\\"{x:1315,y:901,t:1527872997571};\\\", \\\"{x:1316,y:906,t:1527872997587};\\\", \\\"{x:1317,y:909,t:1527872997605};\\\", \\\"{x:1317,y:914,t:1527872997621};\\\", \\\"{x:1317,y:916,t:1527872997637};\\\", \\\"{x:1317,y:920,t:1527872997654};\\\", \\\"{x:1317,y:924,t:1527872997672};\\\", \\\"{x:1317,y:928,t:1527872997687};\\\", \\\"{x:1317,y:934,t:1527872997704};\\\", \\\"{x:1316,y:938,t:1527872997722};\\\", \\\"{x:1315,y:942,t:1527872997738};\\\", \\\"{x:1313,y:945,t:1527872997755};\\\", \\\"{x:1313,y:949,t:1527872997771};\\\", \\\"{x:1313,y:952,t:1527872997788};\\\", \\\"{x:1312,y:955,t:1527872997804};\\\", \\\"{x:1312,y:956,t:1527872997822};\\\", \\\"{x:1312,y:957,t:1527872997857};\\\", \\\"{x:1312,y:958,t:1527872997872};\\\", \\\"{x:1312,y:959,t:1527872997889};\\\", \\\"{x:1312,y:960,t:1527872997905};\\\", \\\"{x:1312,y:961,t:1527872997922};\\\", \\\"{x:1312,y:962,t:1527872997939};\\\", \\\"{x:1312,y:963,t:1527872997962};\\\", \\\"{x:1312,y:964,t:1527872997972};\\\", \\\"{x:1312,y:965,t:1527872997989};\\\", \\\"{x:1312,y:966,t:1527872998009};\\\", \\\"{x:1312,y:967,t:1527872998022};\\\", \\\"{x:1311,y:968,t:1527872998039};\\\", \\\"{x:1310,y:970,t:1527872998065};\\\", \\\"{x:1310,y:971,t:1527872998106};\\\", \\\"{x:1310,y:973,t:1527872998145};\\\", \\\"{x:1310,y:974,t:1527872998209};\\\", \\\"{x:1309,y:975,t:1527872998249};\\\", \\\"{x:1309,y:976,t:1527872998273};\\\", \\\"{x:1309,y:977,t:1527872998401};\\\", \\\"{x:1309,y:979,t:1527872998506};\\\", \\\"{x:1309,y:980,t:1527872999057};\\\", \\\"{x:1310,y:980,t:1527872999377};\\\", \\\"{x:1311,y:979,t:1527873001890};\\\", \\\"{x:1311,y:977,t:1527873001897};\\\", \\\"{x:1312,y:976,t:1527873001908};\\\", \\\"{x:1313,y:975,t:1527873001925};\\\", \\\"{x:1313,y:974,t:1527873001941};\\\", \\\"{x:1314,y:973,t:1527873001959};\\\", \\\"{x:1314,y:972,t:1527873002049};\\\", \\\"{x:1314,y:971,t:1527873002058};\\\", \\\"{x:1315,y:970,t:1527873002154};\\\", \\\"{x:1315,y:968,t:1527873002234};\\\", \\\"{x:1316,y:967,t:1527873002506};\\\", \\\"{x:1319,y:967,t:1527873002513};\\\", \\\"{x:1324,y:965,t:1527873002525};\\\", \\\"{x:1339,y:957,t:1527873002543};\\\", \\\"{x:1352,y:953,t:1527873002560};\\\", \\\"{x:1358,y:952,t:1527873002575};\\\", \\\"{x:1365,y:950,t:1527873002593};\\\", \\\"{x:1366,y:950,t:1527873002609};\\\", \\\"{x:1365,y:950,t:1527873002816};\\\", \\\"{x:1365,y:951,t:1527873002825};\\\", \\\"{x:1364,y:952,t:1527873002842};\\\", \\\"{x:1362,y:954,t:1527873002859};\\\", \\\"{x:1360,y:956,t:1527873002876};\\\", \\\"{x:1358,y:958,t:1527873002893};\\\", \\\"{x:1357,y:959,t:1527873002909};\\\", \\\"{x:1355,y:961,t:1527873002926};\\\", \\\"{x:1353,y:962,t:1527873002943};\\\", \\\"{x:1353,y:964,t:1527873002959};\\\", \\\"{x:1352,y:965,t:1527873002975};\\\", \\\"{x:1352,y:966,t:1527873002993};\\\", \\\"{x:1351,y:968,t:1527873003009};\\\", \\\"{x:1350,y:969,t:1527873003025};\\\", \\\"{x:1350,y:970,t:1527873003081};\\\", \\\"{x:1350,y:971,t:1527873003097};\\\", \\\"{x:1350,y:972,t:1527873003145};\\\", \\\"{x:1350,y:971,t:1527873003313};\\\", \\\"{x:1350,y:970,t:1527873003329};\\\", \\\"{x:1352,y:967,t:1527873003343};\\\", \\\"{x:1353,y:966,t:1527873003359};\\\", \\\"{x:1357,y:962,t:1527873003377};\\\", \\\"{x:1361,y:962,t:1527873003393};\\\", \\\"{x:1377,y:958,t:1527873003409};\\\", \\\"{x:1392,y:955,t:1527873003426};\\\", \\\"{x:1404,y:952,t:1527873003442};\\\", \\\"{x:1408,y:948,t:1527873003459};\\\", \\\"{x:1410,y:947,t:1527873003476};\\\", \\\"{x:1410,y:946,t:1527873003493};\\\", \\\"{x:1412,y:946,t:1527873003537};\\\", \\\"{x:1413,y:946,t:1527873003545};\\\", \\\"{x:1413,y:947,t:1527873003626};\\\", \\\"{x:1413,y:949,t:1527873003643};\\\", \\\"{x:1412,y:951,t:1527873003660};\\\", \\\"{x:1412,y:953,t:1527873003677};\\\", \\\"{x:1410,y:955,t:1527873003693};\\\", \\\"{x:1410,y:956,t:1527873003709};\\\", \\\"{x:1410,y:958,t:1527873003727};\\\", \\\"{x:1412,y:958,t:1527873003865};\\\", \\\"{x:1413,y:957,t:1527873003877};\\\", \\\"{x:1418,y:955,t:1527873003894};\\\", \\\"{x:1425,y:954,t:1527873003910};\\\", \\\"{x:1431,y:951,t:1527873003926};\\\", \\\"{x:1438,y:951,t:1527873003943};\\\", \\\"{x:1441,y:950,t:1527873003959};\\\", \\\"{x:1445,y:949,t:1527873003977};\\\", \\\"{x:1447,y:949,t:1527873003993};\\\", \\\"{x:1450,y:949,t:1527873004011};\\\", \\\"{x:1454,y:949,t:1527873004026};\\\", \\\"{x:1458,y:949,t:1527873004044};\\\", \\\"{x:1460,y:949,t:1527873004060};\\\", \\\"{x:1462,y:949,t:1527873004105};\\\", \\\"{x:1466,y:949,t:1527873004121};\\\", \\\"{x:1473,y:949,t:1527873004129};\\\", \\\"{x:1479,y:951,t:1527873004143};\\\", \\\"{x:1490,y:953,t:1527873004160};\\\", \\\"{x:1497,y:956,t:1527873004177};\\\", \\\"{x:1502,y:957,t:1527873004193};\\\", \\\"{x:1503,y:959,t:1527873004210};\\\", \\\"{x:1504,y:959,t:1527873004226};\\\", \\\"{x:1504,y:960,t:1527873004290};\\\", \\\"{x:1504,y:962,t:1527873004296};\\\", \\\"{x:1506,y:962,t:1527873004433};\\\", \\\"{x:1509,y:962,t:1527873004443};\\\", \\\"{x:1512,y:961,t:1527873004461};\\\", \\\"{x:1518,y:961,t:1527873004477};\\\", \\\"{x:1522,y:958,t:1527873004493};\\\", \\\"{x:1523,y:958,t:1527873004510};\\\", \\\"{x:1526,y:957,t:1527873004527};\\\", \\\"{x:1530,y:956,t:1527873004544};\\\", \\\"{x:1537,y:955,t:1527873004561};\\\", \\\"{x:1540,y:955,t:1527873004577};\\\", \\\"{x:1547,y:955,t:1527873004593};\\\", \\\"{x:1549,y:955,t:1527873004610};\\\", \\\"{x:1552,y:955,t:1527873004627};\\\", \\\"{x:1557,y:958,t:1527873004643};\\\", \\\"{x:1559,y:960,t:1527873004661};\\\", \\\"{x:1560,y:961,t:1527873004677};\\\", \\\"{x:1561,y:962,t:1527873004693};\\\", \\\"{x:1562,y:963,t:1527873004713};\\\", \\\"{x:1563,y:964,t:1527873004727};\\\", \\\"{x:1564,y:966,t:1527873004753};\\\", \\\"{x:1564,y:968,t:1527873004874};\\\", \\\"{x:1564,y:969,t:1527873004897};\\\", \\\"{x:1563,y:970,t:1527873004910};\\\", \\\"{x:1560,y:970,t:1527873004927};\\\", \\\"{x:1559,y:971,t:1527873004945};\\\", \\\"{x:1558,y:971,t:1527873004961};\\\", \\\"{x:1556,y:971,t:1527873004977};\\\", \\\"{x:1555,y:971,t:1527873004994};\\\", \\\"{x:1553,y:971,t:1527873005011};\\\", \\\"{x:1552,y:971,t:1527873005027};\\\", \\\"{x:1551,y:971,t:1527873005057};\\\", \\\"{x:1550,y:971,t:1527873005065};\\\", \\\"{x:1550,y:970,t:1527873005081};\\\", \\\"{x:1549,y:970,t:1527873005409};\\\", \\\"{x:1542,y:965,t:1527873023554};\\\", \\\"{x:1527,y:953,t:1527873023561};\\\", \\\"{x:1502,y:940,t:1527873023574};\\\", \\\"{x:1453,y:910,t:1527873023591};\\\", \\\"{x:1384,y:881,t:1527873023608};\\\", \\\"{x:1272,y:833,t:1527873023625};\\\", \\\"{x:1218,y:811,t:1527873023641};\\\", \\\"{x:1177,y:795,t:1527873023658};\\\", \\\"{x:1151,y:783,t:1527873023674};\\\", \\\"{x:1131,y:776,t:1527873023691};\\\", \\\"{x:1121,y:772,t:1527873023708};\\\", \\\"{x:1119,y:770,t:1527873023724};\\\", \\\"{x:1117,y:768,t:1527873023742};\\\", \\\"{x:1110,y:764,t:1527873023758};\\\", \\\"{x:1095,y:758,t:1527873023774};\\\", \\\"{x:1074,y:748,t:1527873023791};\\\", \\\"{x:1037,y:735,t:1527873023808};\\\", \\\"{x:1007,y:727,t:1527873023824};\\\", \\\"{x:950,y:709,t:1527873023841};\\\", \\\"{x:907,y:694,t:1527873023858};\\\", \\\"{x:874,y:679,t:1527873023875};\\\", \\\"{x:845,y:667,t:1527873023892};\\\", \\\"{x:813,y:655,t:1527873023908};\\\", \\\"{x:772,y:643,t:1527873023924};\\\", \\\"{x:743,y:630,t:1527873023941};\\\", \\\"{x:722,y:621,t:1527873023959};\\\", \\\"{x:711,y:613,t:1527873023975};\\\", \\\"{x:708,y:611,t:1527873023990};\\\", \\\"{x:703,y:606,t:1527873024009};\\\", \\\"{x:696,y:605,t:1527873024027};\\\", \\\"{x:682,y:602,t:1527873024043};\\\", \\\"{x:660,y:601,t:1527873024059};\\\", \\\"{x:639,y:597,t:1527873024076};\\\", \\\"{x:630,y:597,t:1527873024093};\\\", \\\"{x:625,y:597,t:1527873024109};\\\", \\\"{x:622,y:597,t:1527873024126};\\\", \\\"{x:621,y:598,t:1527873024144};\\\", \\\"{x:618,y:600,t:1527873024161};\\\", \\\"{x:613,y:600,t:1527873024176};\\\", \\\"{x:611,y:600,t:1527873024194};\\\", \\\"{x:609,y:600,t:1527873024211};\\\", \\\"{x:609,y:601,t:1527873024296};\\\", \\\"{x:609,y:602,t:1527873024329};\\\", \\\"{x:609,y:603,t:1527873024345};\\\", \\\"{x:609,y:604,t:1527873024384};\\\", \\\"{x:611,y:604,t:1527873024864};\\\", \\\"{x:613,y:604,t:1527873024877};\\\", \\\"{x:621,y:606,t:1527873024894};\\\", \\\"{x:636,y:608,t:1527873024911};\\\", \\\"{x:657,y:614,t:1527873024927};\\\", \\\"{x:691,y:618,t:1527873024943};\\\", \\\"{x:733,y:623,t:1527873024962};\\\", \\\"{x:797,y:634,t:1527873024977};\\\", \\\"{x:871,y:641,t:1527873024994};\\\", \\\"{x:955,y:654,t:1527873025010};\\\", \\\"{x:1039,y:669,t:1527873025026};\\\", \\\"{x:1120,y:683,t:1527873025043};\\\", \\\"{x:1197,y:702,t:1527873025061};\\\", \\\"{x:1252,y:715,t:1527873025077};\\\", \\\"{x:1293,y:718,t:1527873025094};\\\", \\\"{x:1334,y:721,t:1527873025111};\\\", \\\"{x:1379,y:721,t:1527873025126};\\\", \\\"{x:1451,y:732,t:1527873025144};\\\", \\\"{x:1493,y:739,t:1527873025160};\\\", \\\"{x:1523,y:746,t:1527873025177};\\\", \\\"{x:1542,y:749,t:1527873025194};\\\", \\\"{x:1556,y:750,t:1527873025211};\\\", \\\"{x:1560,y:751,t:1527873025227};\\\", \\\"{x:1561,y:751,t:1527873025244};\\\", \\\"{x:1562,y:751,t:1527873025261};\\\", \\\"{x:1563,y:752,t:1527873025279};\\\", \\\"{x:1569,y:757,t:1527873025294};\\\", \\\"{x:1574,y:761,t:1527873025311};\\\", \\\"{x:1584,y:771,t:1527873025328};\\\", \\\"{x:1586,y:773,t:1527873025344};\\\", \\\"{x:1586,y:775,t:1527873025361};\\\", \\\"{x:1586,y:776,t:1527873025378};\\\", \\\"{x:1584,y:777,t:1527873025394};\\\", \\\"{x:1581,y:777,t:1527873025411};\\\", \\\"{x:1580,y:777,t:1527873025428};\\\", \\\"{x:1574,y:776,t:1527873025444};\\\", \\\"{x:1568,y:769,t:1527873025461};\\\", \\\"{x:1563,y:763,t:1527873025478};\\\", \\\"{x:1560,y:759,t:1527873025495};\\\", \\\"{x:1557,y:752,t:1527873025511};\\\", \\\"{x:1554,y:743,t:1527873025528};\\\", \\\"{x:1554,y:739,t:1527873025544};\\\", \\\"{x:1549,y:727,t:1527873025561};\\\", \\\"{x:1547,y:719,t:1527873025578};\\\", \\\"{x:1547,y:710,t:1527873025594};\\\", \\\"{x:1547,y:701,t:1527873025611};\\\", \\\"{x:1547,y:695,t:1527873025628};\\\", \\\"{x:1549,y:690,t:1527873025645};\\\", \\\"{x:1549,y:688,t:1527873025661};\\\", \\\"{x:1551,y:686,t:1527873025678};\\\", \\\"{x:1551,y:684,t:1527873025695};\\\", \\\"{x:1551,y:679,t:1527873025711};\\\", \\\"{x:1551,y:669,t:1527873025729};\\\", \\\"{x:1550,y:659,t:1527873025745};\\\", \\\"{x:1547,y:652,t:1527873025761};\\\", \\\"{x:1546,y:646,t:1527873025778};\\\", \\\"{x:1546,y:640,t:1527873025795};\\\", \\\"{x:1544,y:626,t:1527873025811};\\\", \\\"{x:1544,y:613,t:1527873025828};\\\", \\\"{x:1544,y:605,t:1527873025845};\\\", \\\"{x:1544,y:598,t:1527873025861};\\\", \\\"{x:1545,y:595,t:1527873025878};\\\", \\\"{x:1545,y:594,t:1527873026049};\\\", \\\"{x:1544,y:593,t:1527873026065};\\\", \\\"{x:1543,y:593,t:1527873026080};\\\", \\\"{x:1542,y:592,t:1527873026097};\\\", \\\"{x:1541,y:592,t:1527873026120};\\\", \\\"{x:1539,y:592,t:1527873026128};\\\", \\\"{x:1532,y:592,t:1527873026144};\\\", \\\"{x:1528,y:592,t:1527873026161};\\\", \\\"{x:1523,y:592,t:1527873026178};\\\", \\\"{x:1519,y:596,t:1527873026196};\\\", \\\"{x:1514,y:605,t:1527873026212};\\\", \\\"{x:1506,y:614,t:1527873026229};\\\", \\\"{x:1499,y:624,t:1527873026246};\\\", \\\"{x:1493,y:633,t:1527873026262};\\\", \\\"{x:1487,y:639,t:1527873026279};\\\", \\\"{x:1484,y:643,t:1527873026296};\\\", \\\"{x:1478,y:650,t:1527873026313};\\\", \\\"{x:1475,y:654,t:1527873026328};\\\", \\\"{x:1470,y:662,t:1527873026345};\\\", \\\"{x:1465,y:670,t:1527873026362};\\\", \\\"{x:1460,y:678,t:1527873026379};\\\", \\\"{x:1452,y:687,t:1527873026395};\\\", \\\"{x:1442,y:695,t:1527873026412};\\\", \\\"{x:1429,y:701,t:1527873026429};\\\", \\\"{x:1410,y:710,t:1527873026446};\\\", \\\"{x:1394,y:716,t:1527873026462};\\\", \\\"{x:1385,y:718,t:1527873026479};\\\", \\\"{x:1377,y:718,t:1527873026495};\\\", \\\"{x:1361,y:718,t:1527873026512};\\\", \\\"{x:1354,y:713,t:1527873026528};\\\", \\\"{x:1348,y:707,t:1527873026546};\\\", \\\"{x:1342,y:699,t:1527873026562};\\\", \\\"{x:1338,y:691,t:1527873026578};\\\", \\\"{x:1332,y:685,t:1527873026596};\\\", \\\"{x:1326,y:679,t:1527873026612};\\\", \\\"{x:1322,y:677,t:1527873026630};\\\", \\\"{x:1321,y:677,t:1527873026649};\\\", \\\"{x:1320,y:678,t:1527873026664};\\\", \\\"{x:1319,y:680,t:1527873026681};\\\", \\\"{x:1318,y:683,t:1527873026696};\\\", \\\"{x:1316,y:685,t:1527873026711};\\\", \\\"{x:1314,y:687,t:1527873026728};\\\", \\\"{x:1313,y:686,t:1527873026776};\\\", \\\"{x:1313,y:682,t:1527873026784};\\\", \\\"{x:1313,y:680,t:1527873026795};\\\", \\\"{x:1314,y:671,t:1527873026811};\\\", \\\"{x:1314,y:665,t:1527873026829};\\\", \\\"{x:1314,y:660,t:1527873026845};\\\", \\\"{x:1314,y:659,t:1527873026861};\\\", \\\"{x:1314,y:658,t:1527873026878};\\\", \\\"{x:1314,y:657,t:1527873026936};\\\", \\\"{x:1314,y:655,t:1527873026945};\\\", \\\"{x:1317,y:646,t:1527873026962};\\\", \\\"{x:1320,y:631,t:1527873026979};\\\", \\\"{x:1322,y:623,t:1527873026995};\\\", \\\"{x:1323,y:617,t:1527873027011};\\\", \\\"{x:1327,y:608,t:1527873027028};\\\", \\\"{x:1327,y:599,t:1527873027046};\\\", \\\"{x:1327,y:591,t:1527873027062};\\\", \\\"{x:1327,y:586,t:1527873027078};\\\", \\\"{x:1327,y:577,t:1527873027095};\\\", \\\"{x:1327,y:576,t:1527873027112};\\\", \\\"{x:1327,y:575,t:1527873027168};\\\", \\\"{x:1327,y:577,t:1527873027201};\\\", \\\"{x:1327,y:580,t:1527873027212};\\\", \\\"{x:1327,y:581,t:1527873027229};\\\", \\\"{x:1327,y:584,t:1527873027246};\\\", \\\"{x:1326,y:591,t:1527873027262};\\\", \\\"{x:1325,y:595,t:1527873027279};\\\", \\\"{x:1325,y:606,t:1527873027296};\\\", \\\"{x:1325,y:614,t:1527873027312};\\\", \\\"{x:1325,y:625,t:1527873027329};\\\", \\\"{x:1325,y:645,t:1527873027346};\\\", \\\"{x:1323,y:662,t:1527873027362};\\\", \\\"{x:1323,y:679,t:1527873027379};\\\", \\\"{x:1323,y:694,t:1527873027396};\\\", \\\"{x:1323,y:705,t:1527873027412};\\\", \\\"{x:1323,y:715,t:1527873027429};\\\", \\\"{x:1323,y:722,t:1527873027446};\\\", \\\"{x:1322,y:728,t:1527873027462};\\\", \\\"{x:1321,y:735,t:1527873027479};\\\", \\\"{x:1318,y:743,t:1527873027496};\\\", \\\"{x:1318,y:745,t:1527873027512};\\\", \\\"{x:1318,y:746,t:1527873027529};\\\", \\\"{x:1318,y:749,t:1527873027546};\\\", \\\"{x:1318,y:751,t:1527873027563};\\\", \\\"{x:1318,y:755,t:1527873027580};\\\", \\\"{x:1318,y:760,t:1527873027596};\\\", \\\"{x:1318,y:765,t:1527873027613};\\\", \\\"{x:1318,y:770,t:1527873027630};\\\", \\\"{x:1318,y:775,t:1527873027647};\\\", \\\"{x:1318,y:782,t:1527873027664};\\\", \\\"{x:1318,y:790,t:1527873027680};\\\", \\\"{x:1318,y:795,t:1527873027697};\\\", \\\"{x:1318,y:798,t:1527873027712};\\\", \\\"{x:1317,y:801,t:1527873027736};\\\", \\\"{x:1317,y:802,t:1527873027753};\\\", \\\"{x:1316,y:803,t:1527873027763};\\\", \\\"{x:1316,y:805,t:1527873027779};\\\", \\\"{x:1316,y:808,t:1527873027796};\\\", \\\"{x:1315,y:812,t:1527873027813};\\\", \\\"{x:1315,y:816,t:1527873027830};\\\", \\\"{x:1315,y:821,t:1527873027847};\\\", \\\"{x:1315,y:824,t:1527873027863};\\\", \\\"{x:1315,y:828,t:1527873027880};\\\", \\\"{x:1315,y:840,t:1527873027896};\\\", \\\"{x:1315,y:864,t:1527873027912};\\\", \\\"{x:1316,y:870,t:1527873027929};\\\", \\\"{x:1316,y:876,t:1527873027946};\\\", \\\"{x:1316,y:880,t:1527873027963};\\\", \\\"{x:1316,y:884,t:1527873027980};\\\", \\\"{x:1317,y:891,t:1527873027996};\\\", \\\"{x:1317,y:898,t:1527873028013};\\\", \\\"{x:1317,y:903,t:1527873028030};\\\", \\\"{x:1317,y:907,t:1527873028047};\\\", \\\"{x:1317,y:908,t:1527873028063};\\\", \\\"{x:1317,y:910,t:1527873028080};\\\", \\\"{x:1317,y:911,t:1527873028096};\\\", \\\"{x:1317,y:913,t:1527873028113};\\\", \\\"{x:1317,y:915,t:1527873028130};\\\", \\\"{x:1317,y:916,t:1527873028161};\\\", \\\"{x:1317,y:917,t:1527873028168};\\\", \\\"{x:1317,y:918,t:1527873028181};\\\", \\\"{x:1317,y:919,t:1527873028196};\\\", \\\"{x:1317,y:922,t:1527873028214};\\\", \\\"{x:1317,y:926,t:1527873028230};\\\", \\\"{x:1318,y:930,t:1527873028246};\\\", \\\"{x:1319,y:933,t:1527873028264};\\\", \\\"{x:1320,y:938,t:1527873028281};\\\", \\\"{x:1320,y:941,t:1527873028296};\\\", \\\"{x:1321,y:946,t:1527873028313};\\\", \\\"{x:1323,y:954,t:1527873028330};\\\", \\\"{x:1325,y:961,t:1527873028346};\\\", \\\"{x:1327,y:965,t:1527873028363};\\\", \\\"{x:1327,y:967,t:1527873028380};\\\", \\\"{x:1327,y:969,t:1527873028396};\\\", \\\"{x:1327,y:971,t:1527873028414};\\\", \\\"{x:1327,y:973,t:1527873028430};\\\", \\\"{x:1327,y:975,t:1527873028447};\\\", \\\"{x:1327,y:976,t:1527873028463};\\\", \\\"{x:1326,y:977,t:1527873028481};\\\", \\\"{x:1326,y:978,t:1527873028496};\\\", \\\"{x:1326,y:977,t:1527873028920};\\\", \\\"{x:1326,y:976,t:1527873029305};\\\", \\\"{x:1326,y:975,t:1527873029314};\\\", \\\"{x:1327,y:975,t:1527873029331};\\\", \\\"{x:1327,y:974,t:1527873029347};\\\", \\\"{x:1328,y:973,t:1527873029364};\\\", \\\"{x:1329,y:973,t:1527873029380};\\\", \\\"{x:1331,y:972,t:1527873029397};\\\", \\\"{x:1332,y:972,t:1527873029414};\\\", \\\"{x:1333,y:972,t:1527873029431};\\\", \\\"{x:1334,y:970,t:1527873029448};\\\", \\\"{x:1340,y:970,t:1527873029464};\\\", \\\"{x:1344,y:970,t:1527873029480};\\\", \\\"{x:1351,y:969,t:1527873029498};\\\", \\\"{x:1359,y:969,t:1527873029515};\\\", \\\"{x:1364,y:969,t:1527873029531};\\\", \\\"{x:1367,y:969,t:1527873029547};\\\", \\\"{x:1368,y:968,t:1527873029569};\\\", \\\"{x:1368,y:969,t:1527873029650};\\\", \\\"{x:1368,y:970,t:1527873029665};\\\", \\\"{x:1367,y:971,t:1527873029681};\\\", \\\"{x:1365,y:973,t:1527873029697};\\\", \\\"{x:1362,y:974,t:1527873029714};\\\", \\\"{x:1358,y:977,t:1527873029732};\\\", \\\"{x:1355,y:977,t:1527873029747};\\\", \\\"{x:1352,y:977,t:1527873029764};\\\", \\\"{x:1348,y:977,t:1527873029782};\\\", \\\"{x:1346,y:978,t:1527873029797};\\\", \\\"{x:1345,y:978,t:1527873029814};\\\", \\\"{x:1345,y:977,t:1527873029984};\\\", \\\"{x:1345,y:976,t:1527873030081};\\\", \\\"{x:1345,y:975,t:1527873030099};\\\", \\\"{x:1345,y:974,t:1527873030288};\\\", \\\"{x:1345,y:973,t:1527873030425};\\\", \\\"{x:1345,y:972,t:1527873030432};\\\", \\\"{x:1345,y:971,t:1527873030464};\\\", \\\"{x:1345,y:970,t:1527873030496};\\\", \\\"{x:1346,y:969,t:1527873030504};\\\", \\\"{x:1347,y:969,t:1527873030515};\\\", \\\"{x:1355,y:964,t:1527873030532};\\\", \\\"{x:1367,y:957,t:1527873030548};\\\", \\\"{x:1383,y:946,t:1527873030565};\\\", \\\"{x:1397,y:941,t:1527873030582};\\\", \\\"{x:1407,y:937,t:1527873030599};\\\", \\\"{x:1414,y:936,t:1527873030616};\\\", \\\"{x:1419,y:935,t:1527873030631};\\\", \\\"{x:1421,y:935,t:1527873030649};\\\", \\\"{x:1423,y:935,t:1527873030665};\\\", \\\"{x:1426,y:935,t:1527873030681};\\\", \\\"{x:1428,y:935,t:1527873030698};\\\", \\\"{x:1430,y:935,t:1527873030715};\\\", \\\"{x:1433,y:936,t:1527873030732};\\\", \\\"{x:1434,y:938,t:1527873030749};\\\", \\\"{x:1434,y:943,t:1527873030765};\\\", \\\"{x:1434,y:945,t:1527873030782};\\\", \\\"{x:1433,y:949,t:1527873030798};\\\", \\\"{x:1430,y:954,t:1527873030815};\\\", \\\"{x:1428,y:958,t:1527873030832};\\\", \\\"{x:1425,y:960,t:1527873030849};\\\", \\\"{x:1424,y:963,t:1527873030865};\\\", \\\"{x:1423,y:963,t:1527873030881};\\\", \\\"{x:1424,y:963,t:1527873030969};\\\", \\\"{x:1426,y:963,t:1527873030982};\\\", \\\"{x:1429,y:962,t:1527873030999};\\\", \\\"{x:1433,y:958,t:1527873031015};\\\", \\\"{x:1439,y:957,t:1527873031032};\\\", \\\"{x:1442,y:957,t:1527873031049};\\\", \\\"{x:1443,y:957,t:1527873031065};\\\", \\\"{x:1443,y:960,t:1527873031097};\\\", \\\"{x:1442,y:963,t:1527873031105};\\\", \\\"{x:1441,y:966,t:1527873031116};\\\", \\\"{x:1440,y:968,t:1527873031133};\\\", \\\"{x:1438,y:972,t:1527873031148};\\\", \\\"{x:1438,y:974,t:1527873031165};\\\", \\\"{x:1436,y:976,t:1527873031182};\\\", \\\"{x:1436,y:979,t:1527873031198};\\\", \\\"{x:1436,y:981,t:1527873031215};\\\", \\\"{x:1436,y:984,t:1527873031232};\\\", \\\"{x:1436,y:986,t:1527873031257};\\\", \\\"{x:1438,y:986,t:1527873031329};\\\", \\\"{x:1441,y:986,t:1527873031337};\\\", \\\"{x:1443,y:986,t:1527873031349};\\\", \\\"{x:1448,y:986,t:1527873031369};\\\", \\\"{x:1452,y:986,t:1527873031383};\\\", \\\"{x:1459,y:985,t:1527873031399};\\\", \\\"{x:1469,y:985,t:1527873031416};\\\", \\\"{x:1477,y:982,t:1527873031433};\\\", \\\"{x:1484,y:982,t:1527873031448};\\\", \\\"{x:1494,y:980,t:1527873031465};\\\", \\\"{x:1501,y:980,t:1527873031482};\\\", \\\"{x:1506,y:979,t:1527873031500};\\\", \\\"{x:1509,y:978,t:1527873031515};\\\", \\\"{x:1510,y:978,t:1527873031537};\\\", \\\"{x:1513,y:978,t:1527873031561};\\\", \\\"{x:1515,y:978,t:1527873031577};\\\", \\\"{x:1517,y:978,t:1527873031592};\\\", \\\"{x:1520,y:978,t:1527873031601};\\\", \\\"{x:1526,y:978,t:1527873031615};\\\", \\\"{x:1536,y:978,t:1527873031632};\\\", \\\"{x:1543,y:978,t:1527873031649};\\\", \\\"{x:1548,y:978,t:1527873031665};\\\", \\\"{x:1551,y:978,t:1527873031682};\\\", \\\"{x:1552,y:978,t:1527873031712};\\\", \\\"{x:1554,y:978,t:1527873031720};\\\", \\\"{x:1556,y:978,t:1527873031733};\\\", \\\"{x:1564,y:975,t:1527873031749};\\\", \\\"{x:1569,y:973,t:1527873031766};\\\", \\\"{x:1573,y:972,t:1527873031783};\\\", \\\"{x:1573,y:971,t:1527873031799};\\\", \\\"{x:1574,y:971,t:1527873031824};\\\", \\\"{x:1575,y:971,t:1527873031840};\\\", \\\"{x:1575,y:970,t:1527873031897};\\\", \\\"{x:1575,y:969,t:1527873031937};\\\", \\\"{x:1574,y:969,t:1527873031949};\\\", \\\"{x:1570,y:968,t:1527873031966};\\\", \\\"{x:1563,y:968,t:1527873031983};\\\", \\\"{x:1553,y:967,t:1527873032000};\\\", \\\"{x:1547,y:967,t:1527873032017};\\\", \\\"{x:1546,y:967,t:1527873032031};\\\", \\\"{x:1545,y:966,t:1527873032273};\\\", \\\"{x:1545,y:965,t:1527873032329};\\\", \\\"{x:1545,y:964,t:1527873032345};\\\", \\\"{x:1546,y:963,t:1527873032361};\\\", \\\"{x:1547,y:963,t:1527873032401};\\\", \\\"{x:1548,y:961,t:1527873032433};\\\", \\\"{x:1549,y:961,t:1527873032449};\\\", \\\"{x:1550,y:961,t:1527873038052};\\\", \\\"{x:1548,y:961,t:1527873042048};\\\", \\\"{x:1545,y:961,t:1527873042056};\\\", \\\"{x:1537,y:961,t:1527873042074};\\\", \\\"{x:1526,y:961,t:1527873042090};\\\", \\\"{x:1509,y:959,t:1527873042106};\\\", \\\"{x:1463,y:953,t:1527873042123};\\\", \\\"{x:1431,y:951,t:1527873042139};\\\", \\\"{x:1392,y:946,t:1527873042156};\\\", \\\"{x:1351,y:934,t:1527873042174};\\\", \\\"{x:1313,y:926,t:1527873042189};\\\", \\\"{x:1267,y:917,t:1527873042207};\\\", \\\"{x:1221,y:902,t:1527873042223};\\\", \\\"{x:1168,y:888,t:1527873042239};\\\", \\\"{x:1138,y:880,t:1527873042256};\\\", \\\"{x:1114,y:873,t:1527873042274};\\\", \\\"{x:1096,y:868,t:1527873042290};\\\", \\\"{x:1084,y:865,t:1527873042307};\\\", \\\"{x:1068,y:860,t:1527873042324};\\\", \\\"{x:1044,y:849,t:1527873042340};\\\", \\\"{x:1019,y:842,t:1527873042357};\\\", \\\"{x:992,y:833,t:1527873042374};\\\", \\\"{x:966,y:827,t:1527873042390};\\\", \\\"{x:943,y:821,t:1527873042406};\\\", \\\"{x:920,y:814,t:1527873042424};\\\", \\\"{x:881,y:797,t:1527873042440};\\\", \\\"{x:841,y:783,t:1527873042456};\\\", \\\"{x:788,y:770,t:1527873042474};\\\", \\\"{x:743,y:761,t:1527873042491};\\\", \\\"{x:701,y:756,t:1527873042506};\\\", \\\"{x:673,y:753,t:1527873042524};\\\", \\\"{x:652,y:748,t:1527873042540};\\\", \\\"{x:635,y:744,t:1527873042557};\\\", \\\"{x:620,y:742,t:1527873042574};\\\", \\\"{x:603,y:736,t:1527873042591};\\\", \\\"{x:579,y:732,t:1527873042606};\\\", \\\"{x:553,y:724,t:1527873042625};\\\", \\\"{x:521,y:717,t:1527873042640};\\\", \\\"{x:512,y:716,t:1527873042656};\\\", \\\"{x:508,y:715,t:1527873042674};\\\", \\\"{x:507,y:715,t:1527873042728};\\\", \\\"{x:507,y:716,t:1527873042767};\\\", \\\"{x:507,y:718,t:1527873042808};\\\", \\\"{x:507,y:723,t:1527873042824};\\\", \\\"{x:507,y:727,t:1527873042842};\\\", \\\"{x:507,y:728,t:1527873042858};\\\", \\\"{x:507,y:729,t:1527873042874};\\\", \\\"{x:508,y:729,t:1527873043992};\\\", \\\"{x:508,y:728,t:1527873044008};\\\", \\\"{x:508,y:725,t:1527873044025};\\\", \\\"{x:508,y:724,t:1527873044043};\\\", \\\"{x:510,y:722,t:1527873044059};\\\", \\\"{x:510,y:720,t:1527873044075};\\\", \\\"{x:510,y:717,t:1527873044092};\\\", \\\"{x:512,y:701,t:1527873044160};\\\", \\\"{x:514,y:695,t:1527873044175};\\\", \\\"{x:515,y:690,t:1527873044192};\\\", \\\"{x:515,y:687,t:1527873044209};\\\", \\\"{x:516,y:686,t:1527873044225};\\\" ] }, { \\\"rt\\\": 8024, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 237857, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:639,t:1527873044394};\\\", \\\"{x:534,y:638,t:1527873044409};\\\", \\\"{x:534,y:637,t:1527873044447};\\\", \\\"{x:534,y:636,t:1527873044459};\\\", \\\"{x:534,y:635,t:1527873044492};\\\", \\\"{x:534,y:634,t:1527873044527};\\\", \\\"{x:534,y:633,t:1527873044542};\\\", \\\"{x:533,y:632,t:1527873044559};\\\", \\\"{x:530,y:630,t:1527873044576};\\\", \\\"{x:527,y:625,t:1527873044592};\\\", \\\"{x:527,y:622,t:1527873044609};\\\", \\\"{x:526,y:617,t:1527873044626};\\\", \\\"{x:526,y:611,t:1527873044643};\\\", \\\"{x:526,y:608,t:1527873044659};\\\", \\\"{x:524,y:604,t:1527873044676};\\\", \\\"{x:523,y:602,t:1527873044694};\\\", \\\"{x:523,y:601,t:1527873044709};\\\", \\\"{x:523,y:600,t:1527873044727};\\\", \\\"{x:522,y:599,t:1527873044824};\\\", \\\"{x:520,y:599,t:1527873044903};\\\", \\\"{x:519,y:599,t:1527873044911};\\\", \\\"{x:518,y:599,t:1527873044926};\\\", \\\"{x:517,y:599,t:1527873044943};\\\", \\\"{x:515,y:597,t:1527873045273};\\\", \\\"{x:512,y:595,t:1527873045280};\\\", \\\"{x:510,y:593,t:1527873045297};\\\", \\\"{x:509,y:593,t:1527873045320};\\\", \\\"{x:508,y:592,t:1527873045328};\\\", \\\"{x:508,y:591,t:1527873045384};\\\", \\\"{x:507,y:590,t:1527873045417};\\\", \\\"{x:507,y:588,t:1527873045440};\\\", \\\"{x:506,y:587,t:1527873045456};\\\", \\\"{x:507,y:586,t:1527873045905};\\\", \\\"{x:515,y:586,t:1527873045912};\\\", \\\"{x:523,y:587,t:1527873045927};\\\", \\\"{x:552,y:591,t:1527873045944};\\\", \\\"{x:601,y:597,t:1527873045961};\\\", \\\"{x:649,y:604,t:1527873045977};\\\", \\\"{x:688,y:614,t:1527873045994};\\\", \\\"{x:726,y:618,t:1527873046011};\\\", \\\"{x:772,y:625,t:1527873046028};\\\", \\\"{x:822,y:631,t:1527873046045};\\\", \\\"{x:865,y:640,t:1527873046060};\\\", \\\"{x:909,y:650,t:1527873046077};\\\", \\\"{x:945,y:661,t:1527873046095};\\\", \\\"{x:975,y:670,t:1527873046110};\\\", \\\"{x:1014,y:684,t:1527873046127};\\\", \\\"{x:1034,y:694,t:1527873046144};\\\", \\\"{x:1046,y:700,t:1527873046161};\\\", \\\"{x:1060,y:708,t:1527873046178};\\\", \\\"{x:1067,y:714,t:1527873046194};\\\", \\\"{x:1073,y:719,t:1527873046210};\\\", \\\"{x:1082,y:729,t:1527873046228};\\\", \\\"{x:1092,y:739,t:1527873046245};\\\", \\\"{x:1100,y:744,t:1527873046260};\\\", \\\"{x:1110,y:751,t:1527873046278};\\\", \\\"{x:1118,y:753,t:1527873046295};\\\", \\\"{x:1123,y:757,t:1527873046310};\\\", \\\"{x:1134,y:766,t:1527873046328};\\\", \\\"{x:1145,y:774,t:1527873046344};\\\", \\\"{x:1157,y:784,t:1527873046362};\\\", \\\"{x:1175,y:795,t:1527873046378};\\\", \\\"{x:1192,y:803,t:1527873046395};\\\", \\\"{x:1204,y:808,t:1527873046411};\\\", \\\"{x:1209,y:811,t:1527873046428};\\\", \\\"{x:1212,y:811,t:1527873046445};\\\", \\\"{x:1214,y:811,t:1527873046504};\\\", \\\"{x:1215,y:811,t:1527873046528};\\\", \\\"{x:1217,y:811,t:1527873046546};\\\", \\\"{x:1218,y:811,t:1527873046633};\\\", \\\"{x:1219,y:811,t:1527873046689};\\\", \\\"{x:1220,y:811,t:1527873046697};\\\", \\\"{x:1221,y:810,t:1527873046712};\\\", \\\"{x:1222,y:806,t:1527873046728};\\\", \\\"{x:1225,y:798,t:1527873046745};\\\", \\\"{x:1229,y:788,t:1527873046763};\\\", \\\"{x:1231,y:774,t:1527873046778};\\\", \\\"{x:1234,y:759,t:1527873046795};\\\", \\\"{x:1236,y:744,t:1527873046812};\\\", \\\"{x:1239,y:730,t:1527873046829};\\\", \\\"{x:1240,y:717,t:1527873046845};\\\", \\\"{x:1242,y:707,t:1527873046862};\\\", \\\"{x:1245,y:695,t:1527873046878};\\\", \\\"{x:1249,y:682,t:1527873046895};\\\", \\\"{x:1254,y:675,t:1527873046912};\\\", \\\"{x:1263,y:666,t:1527873046928};\\\", \\\"{x:1272,y:654,t:1527873046945};\\\", \\\"{x:1279,y:646,t:1527873046962};\\\", \\\"{x:1284,y:641,t:1527873046979};\\\", \\\"{x:1287,y:637,t:1527873046995};\\\", \\\"{x:1289,y:634,t:1527873047012};\\\", \\\"{x:1293,y:630,t:1527873047029};\\\", \\\"{x:1297,y:625,t:1527873047044};\\\", \\\"{x:1301,y:619,t:1527873047061};\\\", \\\"{x:1303,y:617,t:1527873047079};\\\", \\\"{x:1306,y:613,t:1527873047095};\\\", \\\"{x:1311,y:604,t:1527873047111};\\\", \\\"{x:1314,y:599,t:1527873047129};\\\", \\\"{x:1314,y:593,t:1527873047144};\\\", \\\"{x:1316,y:590,t:1527873047162};\\\", \\\"{x:1317,y:586,t:1527873047178};\\\", \\\"{x:1317,y:582,t:1527873047195};\\\", \\\"{x:1317,y:580,t:1527873047212};\\\", \\\"{x:1318,y:576,t:1527873047228};\\\", \\\"{x:1318,y:575,t:1527873047246};\\\", \\\"{x:1318,y:573,t:1527873047261};\\\", \\\"{x:1318,y:572,t:1527873047297};\\\", \\\"{x:1318,y:570,t:1527873047368};\\\", \\\"{x:1319,y:569,t:1527873047569};\\\", \\\"{x:1320,y:569,t:1527873047579};\\\", \\\"{x:1323,y:568,t:1527873047595};\\\", \\\"{x:1324,y:568,t:1527873047613};\\\", \\\"{x:1326,y:568,t:1527873047629};\\\", \\\"{x:1327,y:568,t:1527873047656};\\\", \\\"{x:1328,y:568,t:1527873047688};\\\", \\\"{x:1329,y:568,t:1527873047720};\\\", \\\"{x:1330,y:569,t:1527873047785};\\\", \\\"{x:1331,y:569,t:1527873047800};\\\", \\\"{x:1331,y:570,t:1527873047880};\\\", \\\"{x:1332,y:570,t:1527873048193};\\\", \\\"{x:1332,y:571,t:1527873048200};\\\", \\\"{x:1332,y:572,t:1527873048248};\\\", \\\"{x:1332,y:573,t:1527873048272};\\\", \\\"{x:1331,y:573,t:1527873048281};\\\", \\\"{x:1329,y:575,t:1527873048296};\\\", \\\"{x:1328,y:576,t:1527873048314};\\\", \\\"{x:1326,y:577,t:1527873048330};\\\", \\\"{x:1324,y:577,t:1527873048347};\\\", \\\"{x:1323,y:578,t:1527873048364};\\\", \\\"{x:1322,y:578,t:1527873048380};\\\", \\\"{x:1320,y:579,t:1527873048409};\\\", \\\"{x:1318,y:580,t:1527873048432};\\\", \\\"{x:1316,y:581,t:1527873048448};\\\", \\\"{x:1314,y:581,t:1527873048463};\\\", \\\"{x:1312,y:582,t:1527873048480};\\\", \\\"{x:1311,y:582,t:1527873048497};\\\", \\\"{x:1310,y:582,t:1527873048544};\\\", \\\"{x:1308,y:583,t:1527873048561};\\\", \\\"{x:1306,y:584,t:1527873048569};\\\", \\\"{x:1303,y:584,t:1527873048580};\\\", \\\"{x:1296,y:585,t:1527873048597};\\\", \\\"{x:1285,y:585,t:1527873048612};\\\", \\\"{x:1268,y:586,t:1527873048629};\\\", \\\"{x:1247,y:586,t:1527873048647};\\\", \\\"{x:1215,y:586,t:1527873048662};\\\", \\\"{x:1162,y:586,t:1527873048680};\\\", \\\"{x:1115,y:586,t:1527873048697};\\\", \\\"{x:1053,y:586,t:1527873048712};\\\", \\\"{x:992,y:586,t:1527873048730};\\\", \\\"{x:939,y:586,t:1527873048748};\\\", \\\"{x:889,y:586,t:1527873048764};\\\", \\\"{x:840,y:588,t:1527873048778};\\\", \\\"{x:808,y:590,t:1527873048794};\\\", \\\"{x:778,y:594,t:1527873048812};\\\", \\\"{x:753,y:596,t:1527873048829};\\\", \\\"{x:732,y:596,t:1527873048846};\\\", \\\"{x:713,y:596,t:1527873048863};\\\", \\\"{x:700,y:596,t:1527873048880};\\\", \\\"{x:698,y:596,t:1527873048896};\\\", \\\"{x:697,y:596,t:1527873048913};\\\", \\\"{x:694,y:596,t:1527873048930};\\\", \\\"{x:691,y:596,t:1527873048946};\\\", \\\"{x:687,y:596,t:1527873048963};\\\", \\\"{x:684,y:596,t:1527873048980};\\\", \\\"{x:678,y:593,t:1527873048997};\\\", \\\"{x:673,y:588,t:1527873049013};\\\", \\\"{x:669,y:584,t:1527873049029};\\\", \\\"{x:662,y:574,t:1527873049046};\\\", \\\"{x:653,y:569,t:1527873049063};\\\", \\\"{x:631,y:558,t:1527873049079};\\\", \\\"{x:618,y:552,t:1527873049097};\\\", \\\"{x:610,y:548,t:1527873049112};\\\", \\\"{x:603,y:542,t:1527873049129};\\\", \\\"{x:600,y:540,t:1527873049146};\\\", \\\"{x:600,y:537,t:1527873049162};\\\", \\\"{x:600,y:534,t:1527873049179};\\\", \\\"{x:600,y:530,t:1527873049196};\\\", \\\"{x:599,y:526,t:1527873049213};\\\", \\\"{x:598,y:523,t:1527873049230};\\\", \\\"{x:598,y:520,t:1527873049247};\\\", \\\"{x:598,y:517,t:1527873049263};\\\", \\\"{x:597,y:510,t:1527873049279};\\\", \\\"{x:597,y:505,t:1527873049297};\\\", \\\"{x:597,y:501,t:1527873049313};\\\", \\\"{x:597,y:499,t:1527873049329};\\\", \\\"{x:597,y:497,t:1527873049347};\\\", \\\"{x:597,y:496,t:1527873049363};\\\", \\\"{x:597,y:494,t:1527873049379};\\\", \\\"{x:597,y:493,t:1527873049396};\\\", \\\"{x:597,y:492,t:1527873049416};\\\", \\\"{x:597,y:491,t:1527873049430};\\\", \\\"{x:597,y:490,t:1527873049447};\\\", \\\"{x:598,y:489,t:1527873049464};\\\", \\\"{x:599,y:489,t:1527873049488};\\\", \\\"{x:600,y:489,t:1527873049528};\\\", \\\"{x:601,y:489,t:1527873049552};\\\", \\\"{x:603,y:489,t:1527873049872};\\\", \\\"{x:605,y:491,t:1527873049881};\\\", \\\"{x:611,y:499,t:1527873049897};\\\", \\\"{x:621,y:506,t:1527873049914};\\\", \\\"{x:639,y:517,t:1527873049932};\\\", \\\"{x:663,y:527,t:1527873049949};\\\", \\\"{x:691,y:537,t:1527873049963};\\\", \\\"{x:717,y:543,t:1527873049981};\\\", \\\"{x:742,y:546,t:1527873050000};\\\", \\\"{x:765,y:549,t:1527873050014};\\\", \\\"{x:782,y:551,t:1527873050030};\\\", \\\"{x:803,y:554,t:1527873050047};\\\", \\\"{x:811,y:555,t:1527873050063};\\\", \\\"{x:814,y:555,t:1527873050080};\\\", \\\"{x:817,y:555,t:1527873050096};\\\", \\\"{x:820,y:555,t:1527873050113};\\\", \\\"{x:821,y:555,t:1527873050131};\\\", \\\"{x:822,y:555,t:1527873050148};\\\", \\\"{x:823,y:555,t:1527873050163};\\\", \\\"{x:824,y:555,t:1527873050183};\\\", \\\"{x:826,y:555,t:1527873050199};\\\", \\\"{x:827,y:555,t:1527873050224};\\\", \\\"{x:827,y:554,t:1527873050240};\\\", \\\"{x:828,y:552,t:1527873050272};\\\", \\\"{x:830,y:550,t:1527873050281};\\\", \\\"{x:831,y:548,t:1527873050297};\\\", \\\"{x:832,y:546,t:1527873050313};\\\", \\\"{x:834,y:544,t:1527873050330};\\\", \\\"{x:835,y:541,t:1527873050348};\\\", \\\"{x:838,y:537,t:1527873050364};\\\", \\\"{x:839,y:535,t:1527873050380};\\\", \\\"{x:839,y:534,t:1527873050400};\\\", \\\"{x:841,y:533,t:1527873050431};\\\", \\\"{x:840,y:534,t:1527873050711};\\\", \\\"{x:839,y:536,t:1527873050719};\\\", \\\"{x:837,y:538,t:1527873050730};\\\", \\\"{x:836,y:539,t:1527873050747};\\\", \\\"{x:834,y:540,t:1527873050767};\\\", \\\"{x:833,y:540,t:1527873050780};\\\", \\\"{x:832,y:541,t:1527873050831};\\\", \\\"{x:827,y:541,t:1527873050848};\\\", \\\"{x:818,y:541,t:1527873050865};\\\", \\\"{x:801,y:541,t:1527873050881};\\\", \\\"{x:788,y:541,t:1527873050897};\\\", \\\"{x:767,y:541,t:1527873050913};\\\", \\\"{x:744,y:541,t:1527873050930};\\\", \\\"{x:717,y:541,t:1527873050948};\\\", \\\"{x:691,y:541,t:1527873050964};\\\", \\\"{x:671,y:541,t:1527873050981};\\\", \\\"{x:656,y:541,t:1527873050997};\\\", \\\"{x:653,y:541,t:1527873051014};\\\", \\\"{x:652,y:541,t:1527873051030};\\\", \\\"{x:651,y:541,t:1527873051119};\\\", \\\"{x:650,y:540,t:1527873051144};\\\", \\\"{x:650,y:538,t:1527873051151};\\\", \\\"{x:650,y:535,t:1527873051165};\\\", \\\"{x:648,y:529,t:1527873051182};\\\", \\\"{x:646,y:523,t:1527873051199};\\\", \\\"{x:640,y:518,t:1527873051214};\\\", \\\"{x:633,y:516,t:1527873051231};\\\", \\\"{x:628,y:513,t:1527873051247};\\\", \\\"{x:624,y:513,t:1527873051265};\\\", \\\"{x:622,y:512,t:1527873051282};\\\", \\\"{x:620,y:511,t:1527873051298};\\\", \\\"{x:618,y:511,t:1527873051315};\\\", \\\"{x:616,y:511,t:1527873051343};\\\", \\\"{x:615,y:510,t:1527873051351};\\\", \\\"{x:614,y:509,t:1527873051367};\\\", \\\"{x:613,y:508,t:1527873051381};\\\", \\\"{x:612,y:508,t:1527873051399};\\\", \\\"{x:612,y:507,t:1527873051423};\\\", \\\"{x:611,y:507,t:1527873051464};\\\", \\\"{x:610,y:507,t:1527873051687};\\\", \\\"{x:609,y:507,t:1527873051699};\\\", \\\"{x:605,y:517,t:1527873051715};\\\", \\\"{x:600,y:531,t:1527873051732};\\\", \\\"{x:595,y:549,t:1527873051749};\\\", \\\"{x:589,y:565,t:1527873051765};\\\", \\\"{x:585,y:585,t:1527873051781};\\\", \\\"{x:582,y:600,t:1527873051799};\\\", \\\"{x:578,y:619,t:1527873051815};\\\", \\\"{x:573,y:648,t:1527873051831};\\\", \\\"{x:568,y:667,t:1527873051849};\\\", \\\"{x:563,y:683,t:1527873051865};\\\", \\\"{x:561,y:697,t:1527873051881};\\\", \\\"{x:559,y:704,t:1527873051898};\\\", \\\"{x:557,y:709,t:1527873051915};\\\", \\\"{x:557,y:715,t:1527873051932};\\\", \\\"{x:555,y:720,t:1527873051950};\\\", \\\"{x:554,y:722,t:1527873051964};\\\", \\\"{x:553,y:725,t:1527873051982};\\\", \\\"{x:552,y:727,t:1527873051999};\\\", \\\"{x:552,y:728,t:1527873052024};\\\", \\\"{x:551,y:729,t:1527873052039};\\\", \\\"{x:551,y:730,t:1527873052049};\\\", \\\"{x:547,y:736,t:1527873052065};\\\", \\\"{x:546,y:739,t:1527873052082};\\\", \\\"{x:545,y:741,t:1527873052098};\\\", \\\"{x:544,y:741,t:1527873052115};\\\", \\\"{x:543,y:742,t:1527873052152};\\\", \\\"{x:544,y:742,t:1527873052624};\\\", \\\"{x:557,y:743,t:1527873052633};\\\", \\\"{x:592,y:749,t:1527873052649};\\\", \\\"{x:650,y:756,t:1527873052666};\\\", \\\"{x:727,y:763,t:1527873052683};\\\", \\\"{x:795,y:767,t:1527873052699};\\\", \\\"{x:842,y:767,t:1527873052716};\\\", \\\"{x:888,y:770,t:1527873052733};\\\", \\\"{x:925,y:770,t:1527873052750};\\\", \\\"{x:954,y:771,t:1527873052766};\\\", \\\"{x:980,y:771,t:1527873052783};\\\", \\\"{x:1011,y:771,t:1527873052800};\\\", \\\"{x:1026,y:771,t:1527873052816};\\\", \\\"{x:1040,y:769,t:1527873052833};\\\", \\\"{x:1050,y:768,t:1527873052850};\\\", \\\"{x:1064,y:766,t:1527873052865};\\\", \\\"{x:1076,y:764,t:1527873052882};\\\", \\\"{x:1090,y:759,t:1527873052900};\\\", \\\"{x:1106,y:754,t:1527873052915};\\\", \\\"{x:1121,y:748,t:1527873052933};\\\", \\\"{x:1131,y:743,t:1527873052949};\\\", \\\"{x:1138,y:739,t:1527873052966};\\\", \\\"{x:1144,y:735,t:1527873052983};\\\", \\\"{x:1145,y:734,t:1527873053000};\\\", \\\"{x:1145,y:733,t:1527873053016};\\\", \\\"{x:1145,y:732,t:1527873053040};\\\" ] }, { \\\"rt\\\": 23687, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 262776, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1145,y:730,t:1527873057755};\\\", \\\"{x:1131,y:722,t:1527873057773};\\\", \\\"{x:1115,y:716,t:1527873057794};\\\", \\\"{x:1093,y:706,t:1527873057806};\\\", \\\"{x:1072,y:699,t:1527873057824};\\\", \\\"{x:1054,y:691,t:1527873057839};\\\", \\\"{x:1034,y:684,t:1527873057856};\\\", \\\"{x:1015,y:676,t:1527873057874};\\\", \\\"{x:986,y:662,t:1527873057890};\\\", \\\"{x:978,y:657,t:1527873057907};\\\", \\\"{x:943,y:638,t:1527873057923};\\\", \\\"{x:921,y:628,t:1527873057941};\\\", \\\"{x:899,y:619,t:1527873057956};\\\", \\\"{x:877,y:610,t:1527873057973};\\\", \\\"{x:850,y:599,t:1527873057990};\\\", \\\"{x:818,y:583,t:1527873058008};\\\", \\\"{x:796,y:567,t:1527873058023};\\\", \\\"{x:779,y:553,t:1527873058040};\\\", \\\"{x:767,y:542,t:1527873058057};\\\", \\\"{x:756,y:531,t:1527873058073};\\\", \\\"{x:733,y:514,t:1527873058091};\\\", \\\"{x:722,y:505,t:1527873058107};\\\", \\\"{x:711,y:498,t:1527873058124};\\\", \\\"{x:702,y:490,t:1527873058140};\\\", \\\"{x:695,y:485,t:1527873058157};\\\", \\\"{x:689,y:479,t:1527873058174};\\\", \\\"{x:686,y:477,t:1527873058190};\\\", \\\"{x:683,y:474,t:1527873058207};\\\", \\\"{x:680,y:474,t:1527873058223};\\\", \\\"{x:677,y:474,t:1527873058240};\\\", \\\"{x:670,y:474,t:1527873058257};\\\", \\\"{x:667,y:474,t:1527873058274};\\\", \\\"{x:665,y:474,t:1527873058290};\\\", \\\"{x:664,y:474,t:1527873058307};\\\", \\\"{x:662,y:474,t:1527873058330};\\\", \\\"{x:661,y:474,t:1527873058355};\\\", \\\"{x:660,y:474,t:1527873058395};\\\", \\\"{x:659,y:474,t:1527873058435};\\\", \\\"{x:658,y:475,t:1527873058444};\\\", \\\"{x:658,y:476,t:1527873058483};\\\", \\\"{x:656,y:476,t:1527873058860};\\\", \\\"{x:655,y:477,t:1527873058874};\\\", \\\"{x:655,y:478,t:1527873059875};\\\", \\\"{x:654,y:479,t:1527873059893};\\\", \\\"{x:654,y:480,t:1527873059980};\\\", \\\"{x:654,y:481,t:1527873060196};\\\", \\\"{x:654,y:482,t:1527873060251};\\\", \\\"{x:654,y:483,t:1527873060452};\\\", \\\"{x:654,y:484,t:1527873060715};\\\", \\\"{x:654,y:486,t:1527873060738};\\\", \\\"{x:655,y:487,t:1527873060765};\\\", \\\"{x:655,y:488,t:1527873060776};\\\", \\\"{x:656,y:489,t:1527873060793};\\\", \\\"{x:657,y:491,t:1527873060810};\\\", \\\"{x:659,y:493,t:1527873060827};\\\", \\\"{x:660,y:494,t:1527873060843};\\\", \\\"{x:661,y:497,t:1527873060859};\\\", \\\"{x:662,y:498,t:1527873060877};\\\", \\\"{x:663,y:500,t:1527873060892};\\\", \\\"{x:665,y:503,t:1527873060910};\\\", \\\"{x:667,y:505,t:1527873060931};\\\", \\\"{x:668,y:506,t:1527873060942};\\\", \\\"{x:676,y:510,t:1527873060960};\\\", \\\"{x:682,y:511,t:1527873060976};\\\", \\\"{x:691,y:512,t:1527873060994};\\\", \\\"{x:697,y:514,t:1527873061009};\\\", \\\"{x:701,y:514,t:1527873061027};\\\", \\\"{x:702,y:514,t:1527873061043};\\\", \\\"{x:718,y:516,t:1527873061060};\\\", \\\"{x:736,y:519,t:1527873061078};\\\", \\\"{x:757,y:521,t:1527873061093};\\\", \\\"{x:781,y:521,t:1527873061109};\\\", \\\"{x:809,y:526,t:1527873061127};\\\", \\\"{x:835,y:530,t:1527873061143};\\\", \\\"{x:861,y:534,t:1527873061159};\\\", \\\"{x:901,y:540,t:1527873061176};\\\", \\\"{x:939,y:549,t:1527873061192};\\\", \\\"{x:975,y:558,t:1527873061209};\\\", \\\"{x:1018,y:571,t:1527873061227};\\\", \\\"{x:1049,y:583,t:1527873061243};\\\", \\\"{x:1078,y:591,t:1527873061259};\\\", \\\"{x:1107,y:602,t:1527873061276};\\\", \\\"{x:1139,y:615,t:1527873061292};\\\", \\\"{x:1178,y:630,t:1527873061309};\\\", \\\"{x:1218,y:645,t:1527873061326};\\\", \\\"{x:1239,y:655,t:1527873061342};\\\", \\\"{x:1256,y:664,t:1527873061359};\\\", \\\"{x:1272,y:676,t:1527873061377};\\\", \\\"{x:1286,y:687,t:1527873061393};\\\", \\\"{x:1298,y:697,t:1527873061410};\\\", \\\"{x:1314,y:708,t:1527873061427};\\\", \\\"{x:1318,y:712,t:1527873061443};\\\", \\\"{x:1319,y:715,t:1527873061459};\\\", \\\"{x:1319,y:721,t:1527873061476};\\\", \\\"{x:1320,y:729,t:1527873061493};\\\", \\\"{x:1320,y:741,t:1527873061509};\\\", \\\"{x:1320,y:752,t:1527873061527};\\\", \\\"{x:1320,y:761,t:1527873061543};\\\", \\\"{x:1320,y:770,t:1527873061560};\\\", \\\"{x:1320,y:778,t:1527873061577};\\\", \\\"{x:1318,y:790,t:1527873061594};\\\", \\\"{x:1318,y:800,t:1527873061610};\\\", \\\"{x:1319,y:809,t:1527873061627};\\\", \\\"{x:1321,y:810,t:1527873061643};\\\", \\\"{x:1322,y:813,t:1527873061660};\\\", \\\"{x:1322,y:814,t:1527873061677};\\\", \\\"{x:1322,y:816,t:1527873061693};\\\", \\\"{x:1323,y:818,t:1527873061710};\\\", \\\"{x:1326,y:821,t:1527873061727};\\\", \\\"{x:1327,y:824,t:1527873061744};\\\", \\\"{x:1328,y:825,t:1527873061760};\\\", \\\"{x:1329,y:827,t:1527873061777};\\\", \\\"{x:1330,y:827,t:1527873061884};\\\", \\\"{x:1331,y:827,t:1527873061923};\\\", \\\"{x:1332,y:827,t:1527873061931};\\\", \\\"{x:1333,y:826,t:1527873061948};\\\", \\\"{x:1334,y:824,t:1527873061961};\\\", \\\"{x:1334,y:819,t:1527873061977};\\\", \\\"{x:1334,y:815,t:1527873061994};\\\", \\\"{x:1334,y:803,t:1527873062012};\\\", \\\"{x:1332,y:794,t:1527873062027};\\\", \\\"{x:1325,y:783,t:1527873062043};\\\", \\\"{x:1320,y:772,t:1527873062061};\\\", \\\"{x:1317,y:763,t:1527873062076};\\\", \\\"{x:1313,y:756,t:1527873062094};\\\", \\\"{x:1313,y:751,t:1527873062111};\\\", \\\"{x:1313,y:745,t:1527873062126};\\\", \\\"{x:1313,y:742,t:1527873062144};\\\", \\\"{x:1313,y:738,t:1527873062161};\\\", \\\"{x:1314,y:738,t:1527873062202};\\\", \\\"{x:1315,y:738,t:1527873062211};\\\", \\\"{x:1323,y:739,t:1527873062227};\\\", \\\"{x:1328,y:742,t:1527873062244};\\\", \\\"{x:1333,y:746,t:1527873062261};\\\", \\\"{x:1339,y:750,t:1527873062277};\\\", \\\"{x:1348,y:757,t:1527873062294};\\\", \\\"{x:1362,y:764,t:1527873062311};\\\", \\\"{x:1374,y:771,t:1527873062327};\\\", \\\"{x:1376,y:771,t:1527873062343};\\\", \\\"{x:1378,y:772,t:1527873062360};\\\", \\\"{x:1378,y:773,t:1527873062377};\\\", \\\"{x:1378,y:772,t:1527873062459};\\\", \\\"{x:1378,y:769,t:1527873062478};\\\", \\\"{x:1378,y:768,t:1527873062499};\\\", \\\"{x:1378,y:767,t:1527873062516};\\\", \\\"{x:1377,y:767,t:1527873062528};\\\", \\\"{x:1373,y:764,t:1527873062543};\\\", \\\"{x:1370,y:761,t:1527873062560};\\\", \\\"{x:1368,y:758,t:1527873062578};\\\", \\\"{x:1367,y:757,t:1527873062594};\\\", \\\"{x:1366,y:755,t:1527873062611};\\\", \\\"{x:1365,y:752,t:1527873062628};\\\", \\\"{x:1364,y:750,t:1527873062644};\\\", \\\"{x:1364,y:749,t:1527873062661};\\\", \\\"{x:1364,y:748,t:1527873062678};\\\", \\\"{x:1364,y:746,t:1527873062694};\\\", \\\"{x:1363,y:744,t:1527873062711};\\\", \\\"{x:1363,y:743,t:1527873062729};\\\", \\\"{x:1363,y:741,t:1527873062745};\\\", \\\"{x:1363,y:739,t:1527873062762};\\\", \\\"{x:1363,y:736,t:1527873062778};\\\", \\\"{x:1362,y:735,t:1527873062795};\\\", \\\"{x:1362,y:733,t:1527873062811};\\\", \\\"{x:1362,y:729,t:1527873062828};\\\", \\\"{x:1362,y:726,t:1527873062845};\\\", \\\"{x:1362,y:724,t:1527873062861};\\\", \\\"{x:1362,y:723,t:1527873062879};\\\", \\\"{x:1362,y:721,t:1527873062895};\\\", \\\"{x:1362,y:719,t:1527873062911};\\\", \\\"{x:1362,y:718,t:1527873062928};\\\", \\\"{x:1361,y:716,t:1527873062945};\\\", \\\"{x:1361,y:715,t:1527873062962};\\\", \\\"{x:1361,y:713,t:1527873062978};\\\", \\\"{x:1361,y:711,t:1527873062995};\\\", \\\"{x:1361,y:710,t:1527873063011};\\\", \\\"{x:1361,y:708,t:1527873063028};\\\", \\\"{x:1361,y:706,t:1527873063045};\\\", \\\"{x:1361,y:705,t:1527873063061};\\\", \\\"{x:1361,y:704,t:1527873063079};\\\", \\\"{x:1361,y:703,t:1527873063095};\\\", \\\"{x:1361,y:704,t:1527873063203};\\\", \\\"{x:1360,y:706,t:1527873063211};\\\", \\\"{x:1359,y:709,t:1527873063228};\\\", \\\"{x:1357,y:714,t:1527873063245};\\\", \\\"{x:1357,y:717,t:1527873063262};\\\", \\\"{x:1357,y:722,t:1527873063278};\\\", \\\"{x:1357,y:725,t:1527873063295};\\\", \\\"{x:1357,y:727,t:1527873063311};\\\", \\\"{x:1357,y:729,t:1527873063331};\\\", \\\"{x:1357,y:730,t:1527873063348};\\\", \\\"{x:1357,y:732,t:1527873063363};\\\", \\\"{x:1357,y:733,t:1527873063380};\\\", \\\"{x:1357,y:734,t:1527873063395};\\\", \\\"{x:1357,y:735,t:1527873063419};\\\", \\\"{x:1356,y:735,t:1527873063460};\\\", \\\"{x:1354,y:737,t:1527873063652};\\\", \\\"{x:1353,y:738,t:1527873063662};\\\", \\\"{x:1353,y:739,t:1527873063677};\\\", \\\"{x:1352,y:742,t:1527873063694};\\\", \\\"{x:1351,y:742,t:1527873064028};\\\", \\\"{x:1346,y:742,t:1527873064046};\\\", \\\"{x:1341,y:738,t:1527873064062};\\\", \\\"{x:1333,y:738,t:1527873064079};\\\", \\\"{x:1321,y:735,t:1527873064095};\\\", \\\"{x:1304,y:735,t:1527873064112};\\\", \\\"{x:1286,y:733,t:1527873064129};\\\", \\\"{x:1260,y:731,t:1527873064145};\\\", \\\"{x:1229,y:727,t:1527873064162};\\\", \\\"{x:1166,y:718,t:1527873064179};\\\", \\\"{x:1124,y:712,t:1527873064195};\\\", \\\"{x:1090,y:702,t:1527873064212};\\\", \\\"{x:1066,y:695,t:1527873064229};\\\", \\\"{x:1047,y:691,t:1527873064245};\\\", \\\"{x:1027,y:688,t:1527873064261};\\\", \\\"{x:1005,y:682,t:1527873064279};\\\", \\\"{x:979,y:679,t:1527873064295};\\\", \\\"{x:947,y:672,t:1527873064312};\\\", \\\"{x:918,y:668,t:1527873064329};\\\", \\\"{x:892,y:667,t:1527873064346};\\\", \\\"{x:871,y:667,t:1527873064362};\\\", \\\"{x:838,y:662,t:1527873064379};\\\", \\\"{x:818,y:661,t:1527873064395};\\\", \\\"{x:802,y:661,t:1527873064412};\\\", \\\"{x:772,y:656,t:1527873064429};\\\", \\\"{x:741,y:654,t:1527873064446};\\\", \\\"{x:713,y:649,t:1527873064462};\\\", \\\"{x:682,y:645,t:1527873064479};\\\", \\\"{x:655,y:641,t:1527873064496};\\\", \\\"{x:629,y:637,t:1527873064512};\\\", \\\"{x:612,y:632,t:1527873064529};\\\", \\\"{x:604,y:631,t:1527873064547};\\\", \\\"{x:602,y:629,t:1527873064562};\\\", \\\"{x:602,y:625,t:1527873064578};\\\", \\\"{x:602,y:622,t:1527873064593};\\\", \\\"{x:602,y:618,t:1527873064609};\\\", \\\"{x:603,y:611,t:1527873064626};\\\", \\\"{x:604,y:607,t:1527873064642};\\\", \\\"{x:607,y:600,t:1527873064659};\\\", \\\"{x:612,y:593,t:1527873064676};\\\", \\\"{x:614,y:584,t:1527873064695};\\\", \\\"{x:617,y:576,t:1527873064712};\\\", \\\"{x:620,y:568,t:1527873064729};\\\", \\\"{x:622,y:562,t:1527873064746};\\\", \\\"{x:624,y:554,t:1527873064763};\\\", \\\"{x:624,y:549,t:1527873064779};\\\", \\\"{x:621,y:539,t:1527873064796};\\\", \\\"{x:615,y:532,t:1527873064813};\\\", \\\"{x:606,y:526,t:1527873064829};\\\", \\\"{x:596,y:525,t:1527873064845};\\\", \\\"{x:582,y:524,t:1527873064863};\\\", \\\"{x:567,y:524,t:1527873064879};\\\", \\\"{x:550,y:521,t:1527873064895};\\\", \\\"{x:534,y:521,t:1527873064913};\\\", \\\"{x:519,y:520,t:1527873064930};\\\", \\\"{x:498,y:520,t:1527873064947};\\\", \\\"{x:487,y:520,t:1527873064962};\\\", \\\"{x:476,y:520,t:1527873064980};\\\", \\\"{x:461,y:520,t:1527873064997};\\\", \\\"{x:448,y:520,t:1527873065014};\\\", \\\"{x:437,y:520,t:1527873065030};\\\", \\\"{x:431,y:520,t:1527873065047};\\\", \\\"{x:427,y:521,t:1527873065064};\\\", \\\"{x:423,y:522,t:1527873065079};\\\", \\\"{x:418,y:524,t:1527873065097};\\\", \\\"{x:415,y:525,t:1527873065115};\\\", \\\"{x:408,y:528,t:1527873065131};\\\", \\\"{x:402,y:530,t:1527873065146};\\\", \\\"{x:389,y:535,t:1527873065164};\\\", \\\"{x:375,y:539,t:1527873065179};\\\", \\\"{x:362,y:543,t:1527873065197};\\\", \\\"{x:350,y:545,t:1527873065212};\\\", \\\"{x:334,y:548,t:1527873065230};\\\", \\\"{x:315,y:550,t:1527873065246};\\\", \\\"{x:298,y:552,t:1527873065263};\\\", \\\"{x:288,y:554,t:1527873065280};\\\", \\\"{x:279,y:554,t:1527873065296};\\\", \\\"{x:271,y:555,t:1527873065315};\\\", \\\"{x:267,y:555,t:1527873065330};\\\", \\\"{x:263,y:557,t:1527873065347};\\\", \\\"{x:260,y:557,t:1527873065362};\\\", \\\"{x:257,y:558,t:1527873065379};\\\", \\\"{x:253,y:559,t:1527873065395};\\\", \\\"{x:247,y:561,t:1527873065412};\\\", \\\"{x:241,y:562,t:1527873065430};\\\", \\\"{x:238,y:562,t:1527873065446};\\\", \\\"{x:234,y:563,t:1527873065463};\\\", \\\"{x:232,y:563,t:1527873065480};\\\", \\\"{x:228,y:564,t:1527873065496};\\\", \\\"{x:221,y:565,t:1527873065512};\\\", \\\"{x:214,y:567,t:1527873065530};\\\", \\\"{x:202,y:569,t:1527873065545};\\\", \\\"{x:194,y:571,t:1527873065563};\\\", \\\"{x:185,y:574,t:1527873065579};\\\", \\\"{x:177,y:574,t:1527873065597};\\\", \\\"{x:172,y:574,t:1527873065613};\\\", \\\"{x:169,y:573,t:1527873065629};\\\", \\\"{x:167,y:573,t:1527873065647};\\\", \\\"{x:167,y:572,t:1527873065663};\\\", \\\"{x:165,y:570,t:1527873065680};\\\", \\\"{x:162,y:568,t:1527873065697};\\\", \\\"{x:160,y:566,t:1527873065713};\\\", \\\"{x:156,y:563,t:1527873065731};\\\", \\\"{x:154,y:559,t:1527873065747};\\\", \\\"{x:154,y:558,t:1527873065763};\\\", \\\"{x:154,y:556,t:1527873065779};\\\", \\\"{x:154,y:555,t:1527873065797};\\\", \\\"{x:154,y:554,t:1527873065812};\\\", \\\"{x:153,y:552,t:1527873065829};\\\", \\\"{x:153,y:551,t:1527873065847};\\\", \\\"{x:153,y:550,t:1527873065863};\\\", \\\"{x:153,y:549,t:1527873065879};\\\", \\\"{x:153,y:548,t:1527873065956};\\\", \\\"{x:153,y:547,t:1527873065963};\\\", \\\"{x:153,y:545,t:1527873065980};\\\", \\\"{x:153,y:544,t:1527873065997};\\\", \\\"{x:153,y:543,t:1527873066051};\\\", \\\"{x:154,y:542,t:1527873066124};\\\", \\\"{x:155,y:542,t:1527873066867};\\\", \\\"{x:156,y:541,t:1527873066881};\\\", \\\"{x:175,y:541,t:1527873066899};\\\", \\\"{x:200,y:542,t:1527873066915};\\\", \\\"{x:261,y:543,t:1527873066931};\\\", \\\"{x:312,y:544,t:1527873066949};\\\", \\\"{x:346,y:544,t:1527873066964};\\\", \\\"{x:382,y:544,t:1527873066981};\\\", \\\"{x:430,y:544,t:1527873066998};\\\", \\\"{x:475,y:546,t:1527873067013};\\\", \\\"{x:507,y:546,t:1527873067031};\\\", \\\"{x:535,y:546,t:1527873067047};\\\", \\\"{x:567,y:548,t:1527873067064};\\\", \\\"{x:601,y:548,t:1527873067081};\\\", \\\"{x:640,y:548,t:1527873067098};\\\", \\\"{x:669,y:548,t:1527873067114};\\\", \\\"{x:713,y:548,t:1527873067131};\\\", \\\"{x:741,y:549,t:1527873067148};\\\", \\\"{x:764,y:549,t:1527873067163};\\\", \\\"{x:779,y:549,t:1527873067180};\\\", \\\"{x:787,y:549,t:1527873067197};\\\", \\\"{x:792,y:549,t:1527873067214};\\\", \\\"{x:795,y:549,t:1527873067230};\\\", \\\"{x:800,y:550,t:1527873067248};\\\", \\\"{x:807,y:550,t:1527873067265};\\\", \\\"{x:821,y:550,t:1527873067281};\\\", \\\"{x:836,y:546,t:1527873067298};\\\", \\\"{x:855,y:534,t:1527873067316};\\\", \\\"{x:862,y:528,t:1527873067330};\\\", \\\"{x:870,y:525,t:1527873067348};\\\", \\\"{x:876,y:521,t:1527873067366};\\\", \\\"{x:880,y:517,t:1527873067381};\\\", \\\"{x:884,y:511,t:1527873067397};\\\", \\\"{x:886,y:506,t:1527873067415};\\\", \\\"{x:886,y:505,t:1527873067435};\\\", \\\"{x:886,y:504,t:1527873067475};\\\", \\\"{x:886,y:503,t:1527873067491};\\\", \\\"{x:884,y:503,t:1527873067507};\\\", \\\"{x:882,y:503,t:1527873067515};\\\", \\\"{x:875,y:503,t:1527873067531};\\\", \\\"{x:869,y:503,t:1527873067548};\\\", \\\"{x:864,y:503,t:1527873067565};\\\", \\\"{x:861,y:503,t:1527873067582};\\\", \\\"{x:860,y:503,t:1527873067598};\\\", \\\"{x:859,y:503,t:1527873067615};\\\", \\\"{x:858,y:503,t:1527873067632};\\\", \\\"{x:857,y:503,t:1527873067648};\\\", \\\"{x:855,y:503,t:1527873067665};\\\", \\\"{x:854,y:503,t:1527873067715};\\\", \\\"{x:853,y:504,t:1527873067731};\\\", \\\"{x:851,y:505,t:1527873067749};\\\", \\\"{x:848,y:505,t:1527873067765};\\\", \\\"{x:845,y:506,t:1527873067783};\\\", \\\"{x:843,y:506,t:1527873067799};\\\", \\\"{x:839,y:506,t:1527873067815};\\\", \\\"{x:838,y:506,t:1527873067832};\\\", \\\"{x:836,y:508,t:1527873067849};\\\", \\\"{x:835,y:508,t:1527873067883};\\\", \\\"{x:834,y:508,t:1527873068668};\\\", \\\"{x:843,y:512,t:1527873068683};\\\", \\\"{x:879,y:517,t:1527873068700};\\\", \\\"{x:906,y:518,t:1527873068716};\\\", \\\"{x:928,y:521,t:1527873068733};\\\", \\\"{x:950,y:525,t:1527873068749};\\\", \\\"{x:971,y:528,t:1527873068766};\\\", \\\"{x:990,y:530,t:1527873068782};\\\", \\\"{x:1015,y:534,t:1527873068799};\\\", \\\"{x:1040,y:537,t:1527873068815};\\\", \\\"{x:1063,y:539,t:1527873068832};\\\", \\\"{x:1089,y:541,t:1527873068849};\\\", \\\"{x:1116,y:545,t:1527873068866};\\\", \\\"{x:1149,y:548,t:1527873068882};\\\", \\\"{x:1211,y:553,t:1527873068898};\\\", \\\"{x:1253,y:553,t:1527873068916};\\\", \\\"{x:1302,y:556,t:1527873068933};\\\", \\\"{x:1344,y:556,t:1527873068950};\\\", \\\"{x:1394,y:556,t:1527873068966};\\\", \\\"{x:1424,y:556,t:1527873068983};\\\", \\\"{x:1445,y:556,t:1527873068999};\\\", \\\"{x:1463,y:556,t:1527873069016};\\\", \\\"{x:1482,y:554,t:1527873069033};\\\", \\\"{x:1500,y:552,t:1527873069049};\\\", \\\"{x:1516,y:547,t:1527873069066};\\\", \\\"{x:1543,y:535,t:1527873069083};\\\", \\\"{x:1562,y:527,t:1527873069099};\\\", \\\"{x:1575,y:520,t:1527873069116};\\\", \\\"{x:1589,y:508,t:1527873069133};\\\", \\\"{x:1601,y:498,t:1527873069150};\\\", \\\"{x:1609,y:489,t:1527873069166};\\\", \\\"{x:1614,y:481,t:1527873069183};\\\", \\\"{x:1617,y:470,t:1527873069200};\\\", \\\"{x:1619,y:460,t:1527873069217};\\\", \\\"{x:1619,y:450,t:1527873069234};\\\", \\\"{x:1619,y:442,t:1527873069249};\\\", \\\"{x:1619,y:433,t:1527873069267};\\\", \\\"{x:1619,y:421,t:1527873069284};\\\", \\\"{x:1619,y:413,t:1527873069299};\\\", \\\"{x:1619,y:407,t:1527873069317};\\\", \\\"{x:1619,y:403,t:1527873069333};\\\", \\\"{x:1619,y:401,t:1527873069350};\\\", \\\"{x:1619,y:400,t:1527873069367};\\\", \\\"{x:1619,y:398,t:1527873069384};\\\", \\\"{x:1617,y:397,t:1527873069399};\\\", \\\"{x:1617,y:395,t:1527873069417};\\\", \\\"{x:1616,y:394,t:1527873069515};\\\", \\\"{x:1615,y:394,t:1527873069692};\\\", \\\"{x:1613,y:394,t:1527873069732};\\\", \\\"{x:1611,y:394,t:1527873069772};\\\", \\\"{x:1610,y:394,t:1527873069787};\\\", \\\"{x:1609,y:394,t:1527873069800};\\\", \\\"{x:1607,y:394,t:1527873069818};\\\", \\\"{x:1602,y:394,t:1527873069834};\\\", \\\"{x:1596,y:394,t:1527873069851};\\\", \\\"{x:1588,y:397,t:1527873069867};\\\", \\\"{x:1575,y:403,t:1527873069883};\\\", \\\"{x:1572,y:404,t:1527873069901};\\\", \\\"{x:1571,y:405,t:1527873069918};\\\", \\\"{x:1570,y:406,t:1527873069933};\\\", \\\"{x:1569,y:407,t:1527873069950};\\\", \\\"{x:1567,y:412,t:1527873069968};\\\", \\\"{x:1566,y:417,t:1527873069983};\\\", \\\"{x:1565,y:421,t:1527873070001};\\\", \\\"{x:1563,y:427,t:1527873070018};\\\", \\\"{x:1559,y:434,t:1527873070034};\\\", \\\"{x:1554,y:445,t:1527873070051};\\\", \\\"{x:1550,y:454,t:1527873070068};\\\", \\\"{x:1549,y:458,t:1527873070084};\\\", \\\"{x:1546,y:464,t:1527873070100};\\\", \\\"{x:1545,y:470,t:1527873070117};\\\", \\\"{x:1543,y:472,t:1527873070134};\\\", \\\"{x:1542,y:475,t:1527873070150};\\\", \\\"{x:1542,y:477,t:1527873070168};\\\", \\\"{x:1541,y:479,t:1527873070183};\\\", \\\"{x:1541,y:482,t:1527873070200};\\\", \\\"{x:1541,y:483,t:1527873070218};\\\", \\\"{x:1540,y:484,t:1527873070233};\\\", \\\"{x:1539,y:486,t:1527873070250};\\\", \\\"{x:1538,y:488,t:1527873070267};\\\", \\\"{x:1536,y:491,t:1527873070284};\\\", \\\"{x:1535,y:495,t:1527873070301};\\\", \\\"{x:1531,y:501,t:1527873070317};\\\", \\\"{x:1526,y:512,t:1527873070334};\\\", \\\"{x:1520,y:527,t:1527873070350};\\\", \\\"{x:1507,y:547,t:1527873070368};\\\", \\\"{x:1491,y:569,t:1527873070385};\\\", \\\"{x:1473,y:593,t:1527873070401};\\\", \\\"{x:1454,y:609,t:1527873070418};\\\", \\\"{x:1434,y:620,t:1527873070435};\\\", \\\"{x:1408,y:633,t:1527873070451};\\\", \\\"{x:1337,y:662,t:1527873070467};\\\", \\\"{x:1286,y:680,t:1527873070484};\\\", \\\"{x:1225,y:695,t:1527873070500};\\\", \\\"{x:1161,y:703,t:1527873070517};\\\", \\\"{x:1107,y:713,t:1527873070534};\\\", \\\"{x:1054,y:721,t:1527873070550};\\\", \\\"{x:1000,y:722,t:1527873070567};\\\", \\\"{x:956,y:722,t:1527873070583};\\\", \\\"{x:914,y:722,t:1527873070599};\\\", \\\"{x:879,y:722,t:1527873070617};\\\", \\\"{x:841,y:722,t:1527873070634};\\\", \\\"{x:809,y:722,t:1527873070650};\\\", \\\"{x:765,y:722,t:1527873070666};\\\", \\\"{x:742,y:722,t:1527873070684};\\\", \\\"{x:721,y:722,t:1527873070700};\\\", \\\"{x:706,y:722,t:1527873070717};\\\", \\\"{x:693,y:719,t:1527873070734};\\\", \\\"{x:683,y:718,t:1527873070750};\\\", \\\"{x:674,y:717,t:1527873070767};\\\", \\\"{x:667,y:717,t:1527873070783};\\\", \\\"{x:655,y:717,t:1527873070801};\\\", \\\"{x:637,y:717,t:1527873070817};\\\", \\\"{x:618,y:720,t:1527873070834};\\\", \\\"{x:580,y:724,t:1527873070851};\\\", \\\"{x:562,y:726,t:1527873070868};\\\", \\\"{x:547,y:726,t:1527873070884};\\\", \\\"{x:544,y:726,t:1527873070901};\\\", \\\"{x:539,y:726,t:1527873070916};\\\", \\\"{x:536,y:727,t:1527873070933};\\\", \\\"{x:534,y:727,t:1527873070951};\\\", \\\"{x:532,y:727,t:1527873070968};\\\", \\\"{x:530,y:728,t:1527873070983};\\\", \\\"{x:529,y:728,t:1527873071035};\\\", \\\"{x:528,y:728,t:1527873071051};\\\", \\\"{x:527,y:729,t:1527873071067};\\\", \\\"{x:526,y:730,t:1527873071084};\\\", \\\"{x:525,y:730,t:1527873071101};\\\", \\\"{x:525,y:731,t:1527873071404};\\\", \\\"{x:524,y:731,t:1527873071419};\\\", \\\"{x:524,y:732,t:1527873072435};\\\", \\\"{x:525,y:732,t:1527873072924};\\\", \\\"{x:527,y:732,t:1527873073722};\\\", \\\"{x:528,y:732,t:1527873074411};\\\" ] }, { \\\"rt\\\": 38172, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 302231, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -04 PM-Z -O -01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:733,t:1527873079979};\\\", \\\"{x:521,y:733,t:1527873079992};\\\", \\\"{x:519,y:735,t:1527873080008};\\\", \\\"{x:518,y:735,t:1527873080043};\\\", \\\"{x:517,y:735,t:1527873080252};\\\", \\\"{x:515,y:735,t:1527873080259};\\\", \\\"{x:514,y:735,t:1527873080275};\\\", \\\"{x:513,y:735,t:1527873080291};\\\", \\\"{x:512,y:735,t:1527873080315};\\\", \\\"{x:511,y:735,t:1527873080364};\\\", \\\"{x:510,y:735,t:1527873080884};\\\", \\\"{x:509,y:735,t:1527873080893};\\\", \\\"{x:505,y:735,t:1527873080908};\\\", \\\"{x:504,y:734,t:1527873080926};\\\", \\\"{x:500,y:732,t:1527873080942};\\\", \\\"{x:498,y:731,t:1527873080959};\\\", \\\"{x:498,y:730,t:1527873080976};\\\", \\\"{x:498,y:729,t:1527873080995};\\\", \\\"{x:498,y:728,t:1527873081019};\\\", \\\"{x:498,y:727,t:1527873081027};\\\", \\\"{x:498,y:725,t:1527873081043};\\\", \\\"{x:498,y:720,t:1527873081059};\\\", \\\"{x:498,y:713,t:1527873081077};\\\", \\\"{x:499,y:706,t:1527873081092};\\\", \\\"{x:502,y:696,t:1527873081108};\\\", \\\"{x:504,y:689,t:1527873081125};\\\", \\\"{x:507,y:678,t:1527873081142};\\\", \\\"{x:511,y:664,t:1527873081159};\\\", \\\"{x:514,y:651,t:1527873081176};\\\", \\\"{x:520,y:634,t:1527873081192};\\\", \\\"{x:528,y:617,t:1527873081210};\\\", \\\"{x:539,y:597,t:1527873081226};\\\", \\\"{x:545,y:582,t:1527873081242};\\\", \\\"{x:550,y:570,t:1527873081259};\\\", \\\"{x:556,y:556,t:1527873081275};\\\", \\\"{x:563,y:543,t:1527873081293};\\\", \\\"{x:568,y:535,t:1527873081309};\\\", \\\"{x:570,y:531,t:1527873081326};\\\", \\\"{x:572,y:526,t:1527873081342};\\\", \\\"{x:572,y:524,t:1527873081359};\\\", \\\"{x:572,y:522,t:1527873081376};\\\", \\\"{x:572,y:520,t:1527873081392};\\\", \\\"{x:572,y:518,t:1527873081409};\\\", \\\"{x:572,y:515,t:1527873081426};\\\", \\\"{x:571,y:514,t:1527873081443};\\\", \\\"{x:569,y:512,t:1527873081460};\\\", \\\"{x:568,y:509,t:1527873081476};\\\", \\\"{x:566,y:509,t:1527873081492};\\\", \\\"{x:565,y:509,t:1527873081509};\\\", \\\"{x:562,y:508,t:1527873081526};\\\", \\\"{x:561,y:507,t:1527873081542};\\\", \\\"{x:560,y:507,t:1527873081587};\\\", \\\"{x:558,y:507,t:1527873081603};\\\", \\\"{x:556,y:507,t:1527873081611};\\\", \\\"{x:553,y:507,t:1527873081627};\\\", \\\"{x:549,y:505,t:1527873081643};\\\", \\\"{x:545,y:504,t:1527873081659};\\\", \\\"{x:541,y:504,t:1527873081677};\\\", \\\"{x:537,y:503,t:1527873081692};\\\", \\\"{x:530,y:501,t:1527873081709};\\\", \\\"{x:520,y:499,t:1527873081726};\\\", \\\"{x:506,y:495,t:1527873081743};\\\", \\\"{x:497,y:494,t:1527873081762};\\\", \\\"{x:488,y:492,t:1527873081776};\\\", \\\"{x:476,y:490,t:1527873081792};\\\", \\\"{x:468,y:487,t:1527873081809};\\\", \\\"{x:459,y:485,t:1527873081827};\\\", \\\"{x:453,y:482,t:1527873081842};\\\", \\\"{x:446,y:481,t:1527873081859};\\\", \\\"{x:439,y:479,t:1527873081876};\\\", \\\"{x:430,y:477,t:1527873081893};\\\", \\\"{x:421,y:475,t:1527873081909};\\\", \\\"{x:416,y:474,t:1527873081926};\\\", \\\"{x:410,y:472,t:1527873081944};\\\", \\\"{x:404,y:470,t:1527873081959};\\\", \\\"{x:396,y:469,t:1527873081976};\\\", \\\"{x:387,y:469,t:1527873081993};\\\", \\\"{x:379,y:469,t:1527873082010};\\\", \\\"{x:366,y:469,t:1527873082026};\\\", \\\"{x:360,y:469,t:1527873082042};\\\", \\\"{x:357,y:469,t:1527873082060};\\\", \\\"{x:355,y:469,t:1527873082076};\\\", \\\"{x:350,y:469,t:1527873082093};\\\", \\\"{x:347,y:469,t:1527873082109};\\\", \\\"{x:343,y:469,t:1527873082126};\\\", \\\"{x:341,y:469,t:1527873082143};\\\", \\\"{x:338,y:469,t:1527873082159};\\\", \\\"{x:335,y:469,t:1527873082176};\\\", \\\"{x:331,y:469,t:1527873082193};\\\", \\\"{x:325,y:469,t:1527873082209};\\\", \\\"{x:317,y:469,t:1527873082227};\\\", \\\"{x:312,y:469,t:1527873082243};\\\", \\\"{x:308,y:469,t:1527873082260};\\\", \\\"{x:306,y:469,t:1527873082276};\\\", \\\"{x:304,y:469,t:1527873082293};\\\", \\\"{x:303,y:469,t:1527873082310};\\\", \\\"{x:301,y:469,t:1527873082326};\\\", \\\"{x:300,y:469,t:1527873082344};\\\", \\\"{x:299,y:469,t:1527873082360};\\\", \\\"{x:298,y:469,t:1527873082376};\\\", \\\"{x:297,y:469,t:1527873082395};\\\", \\\"{x:296,y:469,t:1527873082459};\\\", \\\"{x:295,y:469,t:1527873082515};\\\", \\\"{x:294,y:469,t:1527873082699};\\\", \\\"{x:293,y:469,t:1527873082715};\\\", \\\"{x:292,y:469,t:1527873082727};\\\", \\\"{x:291,y:469,t:1527873082811};\\\", \\\"{x:294,y:469,t:1527873083163};\\\", \\\"{x:300,y:469,t:1527873083178};\\\", \\\"{x:322,y:469,t:1527873083195};\\\", \\\"{x:334,y:469,t:1527873083211};\\\", \\\"{x:347,y:469,t:1527873083227};\\\", \\\"{x:354,y:469,t:1527873083245};\\\", \\\"{x:359,y:469,t:1527873083260};\\\", \\\"{x:363,y:469,t:1527873083277};\\\", \\\"{x:366,y:469,t:1527873083295};\\\", \\\"{x:367,y:469,t:1527873083311};\\\", \\\"{x:368,y:469,t:1527873083328};\\\", \\\"{x:369,y:469,t:1527873083345};\\\", \\\"{x:370,y:469,t:1527873083771};\\\", \\\"{x:371,y:469,t:1527873083779};\\\", \\\"{x:372,y:469,t:1527873083803};\\\", \\\"{x:373,y:469,t:1527873083811};\\\", \\\"{x:375,y:468,t:1527873083828};\\\", \\\"{x:378,y:468,t:1527873083845};\\\", \\\"{x:379,y:468,t:1527873083875};\\\", \\\"{x:379,y:467,t:1527873083932};\\\", \\\"{x:380,y:467,t:1527873084395};\\\", \\\"{x:381,y:467,t:1527873084547};\\\", \\\"{x:382,y:468,t:1527873084667};\\\", \\\"{x:382,y:469,t:1527873084916};\\\", \\\"{x:383,y:469,t:1527873084963};\\\", \\\"{x:383,y:470,t:1527873084996};\\\", \\\"{x:384,y:471,t:1527873085013};\\\", \\\"{x:385,y:471,t:1527873085028};\\\", \\\"{x:385,y:472,t:1527873085045};\\\", \\\"{x:387,y:473,t:1527873085067};\\\", \\\"{x:389,y:474,t:1527873085139};\\\", \\\"{x:390,y:474,t:1527873085187};\\\", \\\"{x:391,y:475,t:1527873085259};\\\", \\\"{x:392,y:475,t:1527873085363};\\\", \\\"{x:393,y:475,t:1527873085492};\\\", \\\"{x:394,y:476,t:1527873085515};\\\", \\\"{x:395,y:476,t:1527873085539};\\\", \\\"{x:396,y:477,t:1527873085564};\\\", \\\"{x:398,y:477,t:1527873085907};\\\", \\\"{x:398,y:478,t:1527873085987};\\\", \\\"{x:399,y:478,t:1527873086002};\\\", \\\"{x:400,y:478,t:1527873086051};\\\", \\\"{x:401,y:479,t:1527873086064};\\\", \\\"{x:402,y:479,t:1527873086115};\\\", \\\"{x:403,y:479,t:1527873086171};\\\", \\\"{x:404,y:479,t:1527873086187};\\\", \\\"{x:404,y:480,t:1527873086197};\\\", \\\"{x:405,y:480,t:1527873086214};\\\", \\\"{x:410,y:480,t:1527873086229};\\\", \\\"{x:417,y:481,t:1527873086247};\\\", \\\"{x:425,y:482,t:1527873086264};\\\", \\\"{x:431,y:484,t:1527873086280};\\\", \\\"{x:438,y:484,t:1527873086297};\\\", \\\"{x:446,y:485,t:1527873086314};\\\", \\\"{x:454,y:486,t:1527873086331};\\\", \\\"{x:462,y:486,t:1527873086347};\\\", \\\"{x:471,y:486,t:1527873086364};\\\", \\\"{x:476,y:486,t:1527873086381};\\\", \\\"{x:484,y:486,t:1527873086397};\\\", \\\"{x:493,y:486,t:1527873086414};\\\", \\\"{x:496,y:486,t:1527873086430};\\\", \\\"{x:500,y:486,t:1527873086447};\\\", \\\"{x:504,y:487,t:1527873086465};\\\", \\\"{x:506,y:487,t:1527873086480};\\\", \\\"{x:509,y:488,t:1527873086496};\\\", \\\"{x:513,y:488,t:1527873086512};\\\", \\\"{x:518,y:488,t:1527873086528};\\\", \\\"{x:529,y:488,t:1527873086546};\\\", \\\"{x:550,y:490,t:1527873086562};\\\", \\\"{x:566,y:490,t:1527873086578};\\\", \\\"{x:586,y:492,t:1527873086595};\\\", \\\"{x:604,y:495,t:1527873086613};\\\", \\\"{x:618,y:496,t:1527873086628};\\\", \\\"{x:632,y:498,t:1527873086645};\\\", \\\"{x:641,y:501,t:1527873086662};\\\", \\\"{x:651,y:502,t:1527873086680};\\\", \\\"{x:666,y:502,t:1527873086695};\\\", \\\"{x:682,y:505,t:1527873086713};\\\", \\\"{x:698,y:506,t:1527873086730};\\\", \\\"{x:712,y:508,t:1527873086746};\\\", \\\"{x:743,y:511,t:1527873086763};\\\", \\\"{x:763,y:514,t:1527873086780};\\\", \\\"{x:787,y:518,t:1527873086797};\\\", \\\"{x:809,y:523,t:1527873086813};\\\", \\\"{x:834,y:527,t:1527873086831};\\\", \\\"{x:857,y:529,t:1527873086847};\\\", \\\"{x:885,y:533,t:1527873086864};\\\", \\\"{x:915,y:539,t:1527873086881};\\\", \\\"{x:947,y:547,t:1527873086896};\\\", \\\"{x:986,y:552,t:1527873086915};\\\", \\\"{x:1040,y:562,t:1527873086930};\\\", \\\"{x:1078,y:570,t:1527873086946};\\\", \\\"{x:1104,y:574,t:1527873086963};\\\", \\\"{x:1130,y:579,t:1527873086981};\\\", \\\"{x:1157,y:585,t:1527873086997};\\\", \\\"{x:1178,y:590,t:1527873087013};\\\", \\\"{x:1198,y:597,t:1527873087030};\\\", \\\"{x:1212,y:602,t:1527873087047};\\\", \\\"{x:1226,y:607,t:1527873087063};\\\", \\\"{x:1239,y:611,t:1527873087080};\\\", \\\"{x:1253,y:615,t:1527873087097};\\\", \\\"{x:1262,y:619,t:1527873087113};\\\", \\\"{x:1276,y:625,t:1527873087130};\\\", \\\"{x:1290,y:630,t:1527873087147};\\\", \\\"{x:1315,y:641,t:1527873087164};\\\", \\\"{x:1338,y:651,t:1527873087180};\\\", \\\"{x:1358,y:662,t:1527873087197};\\\", \\\"{x:1373,y:671,t:1527873087215};\\\", \\\"{x:1382,y:678,t:1527873087231};\\\", \\\"{x:1388,y:687,t:1527873087248};\\\", \\\"{x:1393,y:696,t:1527873087265};\\\", \\\"{x:1398,y:706,t:1527873087282};\\\", \\\"{x:1402,y:711,t:1527873087298};\\\", \\\"{x:1409,y:718,t:1527873087315};\\\", \\\"{x:1413,y:725,t:1527873087331};\\\", \\\"{x:1415,y:727,t:1527873087349};\\\", \\\"{x:1415,y:730,t:1527873087364};\\\", \\\"{x:1415,y:733,t:1527873087381};\\\", \\\"{x:1415,y:737,t:1527873087398};\\\", \\\"{x:1415,y:742,t:1527873087414};\\\", \\\"{x:1410,y:751,t:1527873087432};\\\", \\\"{x:1401,y:759,t:1527873087447};\\\", \\\"{x:1395,y:763,t:1527873087464};\\\", \\\"{x:1389,y:767,t:1527873087482};\\\", \\\"{x:1379,y:771,t:1527873087498};\\\", \\\"{x:1371,y:773,t:1527873087515};\\\", \\\"{x:1365,y:773,t:1527873087532};\\\", \\\"{x:1359,y:773,t:1527873087548};\\\", \\\"{x:1353,y:774,t:1527873087565};\\\", \\\"{x:1350,y:774,t:1527873087582};\\\", \\\"{x:1347,y:774,t:1527873087599};\\\", \\\"{x:1346,y:774,t:1527873087614};\\\", \\\"{x:1343,y:774,t:1527873087631};\\\", \\\"{x:1341,y:772,t:1527873087648};\\\", \\\"{x:1341,y:771,t:1527873087664};\\\", \\\"{x:1340,y:771,t:1527873087681};\\\", \\\"{x:1340,y:770,t:1527873087699};\\\", \\\"{x:1340,y:769,t:1527873087722};\\\", \\\"{x:1340,y:768,t:1527873087731};\\\", \\\"{x:1340,y:767,t:1527873087748};\\\", \\\"{x:1340,y:765,t:1527873087764};\\\", \\\"{x:1341,y:764,t:1527873087794};\\\", \\\"{x:1342,y:763,t:1527873087819};\\\", \\\"{x:1343,y:763,t:1527873087848};\\\", \\\"{x:1344,y:762,t:1527873087866};\\\", \\\"{x:1345,y:761,t:1527873087881};\\\", \\\"{x:1345,y:760,t:1527873087899};\\\", \\\"{x:1345,y:759,t:1527873087947};\\\", \\\"{x:1346,y:759,t:1527873088019};\\\", \\\"{x:1353,y:760,t:1527873095525};\\\", \\\"{x:1361,y:763,t:1527873095531};\\\", \\\"{x:1370,y:768,t:1527873095545};\\\", \\\"{x:1390,y:777,t:1527873095561};\\\", \\\"{x:1423,y:786,t:1527873095578};\\\", \\\"{x:1443,y:791,t:1527873095594};\\\", \\\"{x:1459,y:796,t:1527873095610};\\\", \\\"{x:1469,y:800,t:1527873095628};\\\", \\\"{x:1476,y:803,t:1527873095644};\\\", \\\"{x:1485,y:807,t:1527873095661};\\\", \\\"{x:1496,y:814,t:1527873095678};\\\", \\\"{x:1506,y:822,t:1527873095695};\\\", \\\"{x:1515,y:830,t:1527873095711};\\\", \\\"{x:1522,y:836,t:1527873095728};\\\", \\\"{x:1526,y:839,t:1527873095745};\\\", \\\"{x:1527,y:841,t:1527873095761};\\\", \\\"{x:1529,y:845,t:1527873095779};\\\", \\\"{x:1532,y:853,t:1527873095795};\\\", \\\"{x:1533,y:857,t:1527873095812};\\\", \\\"{x:1534,y:860,t:1527873095828};\\\", \\\"{x:1534,y:861,t:1527873095859};\\\", \\\"{x:1533,y:862,t:1527873095867};\\\", \\\"{x:1531,y:863,t:1527873095879};\\\", \\\"{x:1524,y:864,t:1527873095896};\\\", \\\"{x:1517,y:864,t:1527873095912};\\\", \\\"{x:1508,y:864,t:1527873095929};\\\", \\\"{x:1503,y:864,t:1527873095946};\\\", \\\"{x:1491,y:864,t:1527873095963};\\\", \\\"{x:1486,y:863,t:1527873095978};\\\", \\\"{x:1483,y:861,t:1527873095995};\\\", \\\"{x:1482,y:859,t:1527873096012};\\\", \\\"{x:1481,y:855,t:1527873096029};\\\", \\\"{x:1481,y:854,t:1527873096044};\\\", \\\"{x:1481,y:853,t:1527873096062};\\\", \\\"{x:1481,y:852,t:1527873096090};\\\", \\\"{x:1482,y:851,t:1527873096106};\\\", \\\"{x:1482,y:850,t:1527873096114};\\\", \\\"{x:1484,y:850,t:1527873096129};\\\", \\\"{x:1488,y:849,t:1527873096145};\\\", \\\"{x:1488,y:848,t:1527873096162};\\\", \\\"{x:1491,y:847,t:1527873096179};\\\", \\\"{x:1491,y:846,t:1527873096267};\\\", \\\"{x:1492,y:846,t:1527873096323};\\\", \\\"{x:1492,y:845,t:1527873096427};\\\", \\\"{x:1492,y:844,t:1527873096459};\\\", \\\"{x:1492,y:843,t:1527873096467};\\\", \\\"{x:1491,y:843,t:1527873096483};\\\", \\\"{x:1490,y:842,t:1527873096499};\\\", \\\"{x:1489,y:842,t:1527873096515};\\\", \\\"{x:1486,y:841,t:1527873096531};\\\", \\\"{x:1486,y:840,t:1527873096547};\\\", \\\"{x:1484,y:840,t:1527873096563};\\\", \\\"{x:1484,y:837,t:1527873096636};\\\", \\\"{x:1486,y:837,t:1527873096684};\\\", \\\"{x:1487,y:837,t:1527873096696};\\\", \\\"{x:1492,y:838,t:1527873096713};\\\", \\\"{x:1497,y:842,t:1527873096731};\\\", \\\"{x:1503,y:846,t:1527873096747};\\\", \\\"{x:1507,y:849,t:1527873096763};\\\", \\\"{x:1508,y:851,t:1527873096781};\\\", \\\"{x:1511,y:854,t:1527873096797};\\\", \\\"{x:1514,y:857,t:1527873096813};\\\", \\\"{x:1521,y:861,t:1527873096830};\\\", \\\"{x:1526,y:865,t:1527873096848};\\\", \\\"{x:1531,y:869,t:1527873096864};\\\", \\\"{x:1538,y:874,t:1527873096880};\\\", \\\"{x:1540,y:876,t:1527873096898};\\\", \\\"{x:1545,y:880,t:1527873096914};\\\", \\\"{x:1556,y:889,t:1527873096931};\\\", \\\"{x:1563,y:893,t:1527873096947};\\\", \\\"{x:1573,y:899,t:1527873096963};\\\", \\\"{x:1584,y:907,t:1527873096980};\\\", \\\"{x:1588,y:909,t:1527873096997};\\\", \\\"{x:1591,y:911,t:1527873097014};\\\", \\\"{x:1591,y:912,t:1527873097030};\\\", \\\"{x:1591,y:914,t:1527873097051};\\\", \\\"{x:1592,y:915,t:1527873097064};\\\", \\\"{x:1596,y:920,t:1527873097081};\\\", \\\"{x:1603,y:928,t:1527873097097};\\\", \\\"{x:1612,y:936,t:1527873097114};\\\", \\\"{x:1613,y:939,t:1527873097130};\\\", \\\"{x:1613,y:940,t:1527873097146};\\\", \\\"{x:1613,y:941,t:1527873097164};\\\", \\\"{x:1613,y:945,t:1527873097180};\\\", \\\"{x:1613,y:947,t:1527873097197};\\\", \\\"{x:1616,y:949,t:1527873097214};\\\", \\\"{x:1617,y:951,t:1527873097231};\\\", \\\"{x:1618,y:952,t:1527873097247};\\\", \\\"{x:1618,y:953,t:1527873097339};\\\", \\\"{x:1618,y:954,t:1527873097348};\\\", \\\"{x:1618,y:955,t:1527873097365};\\\", \\\"{x:1617,y:956,t:1527873097420};\\\", \\\"{x:1616,y:957,t:1527873097451};\\\", \\\"{x:1616,y:958,t:1527873097483};\\\", \\\"{x:1615,y:960,t:1527873097499};\\\", \\\"{x:1615,y:961,t:1527873097515};\\\", \\\"{x:1615,y:962,t:1527873097531};\\\", \\\"{x:1614,y:963,t:1527873097549};\\\", \\\"{x:1614,y:964,t:1527873097611};\\\", \\\"{x:1614,y:965,t:1527873097619};\\\", \\\"{x:1614,y:967,t:1527873097635};\\\", \\\"{x:1614,y:968,t:1527873097648};\\\", \\\"{x:1615,y:971,t:1527873097666};\\\", \\\"{x:1616,y:971,t:1527873098004};\\\", \\\"{x:1616,y:970,t:1527873098059};\\\", \\\"{x:1616,y:969,t:1527873098075};\\\", \\\"{x:1616,y:968,t:1527873098092};\\\", \\\"{x:1614,y:968,t:1527873110771};\\\", \\\"{x:1604,y:968,t:1527873110787};\\\", \\\"{x:1589,y:968,t:1527873110803};\\\", \\\"{x:1564,y:967,t:1527873110820};\\\", \\\"{x:1538,y:962,t:1527873110837};\\\", \\\"{x:1496,y:957,t:1527873110853};\\\", \\\"{x:1443,y:949,t:1527873110870};\\\", \\\"{x:1407,y:939,t:1527873110887};\\\", \\\"{x:1375,y:929,t:1527873110903};\\\", \\\"{x:1344,y:915,t:1527873110920};\\\", \\\"{x:1316,y:902,t:1527873110937};\\\", \\\"{x:1269,y:881,t:1527873110953};\\\", \\\"{x:1220,y:864,t:1527873110970};\\\", \\\"{x:1146,y:830,t:1527873110987};\\\", \\\"{x:1104,y:811,t:1527873111004};\\\", \\\"{x:1074,y:798,t:1527873111020};\\\", \\\"{x:1053,y:789,t:1527873111037};\\\", \\\"{x:1029,y:779,t:1527873111053};\\\", \\\"{x:1002,y:767,t:1527873111070};\\\", \\\"{x:979,y:758,t:1527873111087};\\\", \\\"{x:967,y:751,t:1527873111104};\\\", \\\"{x:960,y:746,t:1527873111119};\\\", \\\"{x:951,y:738,t:1527873111137};\\\", \\\"{x:940,y:729,t:1527873111154};\\\", \\\"{x:926,y:717,t:1527873111170};\\\", \\\"{x:914,y:708,t:1527873111187};\\\", \\\"{x:910,y:705,t:1527873111204};\\\", \\\"{x:898,y:697,t:1527873111221};\\\", \\\"{x:878,y:682,t:1527873111238};\\\", \\\"{x:842,y:662,t:1527873111254};\\\", \\\"{x:795,y:642,t:1527873111271};\\\", \\\"{x:745,y:619,t:1527873111288};\\\", \\\"{x:709,y:604,t:1527873111304};\\\", \\\"{x:689,y:593,t:1527873111320};\\\", \\\"{x:666,y:576,t:1527873111349};\\\", \\\"{x:658,y:566,t:1527873111367};\\\", \\\"{x:648,y:553,t:1527873111383};\\\", \\\"{x:634,y:544,t:1527873111399};\\\", \\\"{x:620,y:538,t:1527873111416};\\\", \\\"{x:611,y:535,t:1527873111433};\\\", \\\"{x:607,y:533,t:1527873111449};\\\", \\\"{x:606,y:533,t:1527873111473};\\\", \\\"{x:606,y:532,t:1527873111484};\\\", \\\"{x:606,y:528,t:1527873111500};\\\", \\\"{x:604,y:518,t:1527873111517};\\\", \\\"{x:603,y:514,t:1527873111534};\\\", \\\"{x:603,y:511,t:1527873111550};\\\", \\\"{x:602,y:505,t:1527873111567};\\\", \\\"{x:601,y:500,t:1527873111583};\\\", \\\"{x:601,y:497,t:1527873111599};\\\", \\\"{x:600,y:496,t:1527873111616};\\\", \\\"{x:599,y:494,t:1527873111634};\\\", \\\"{x:599,y:493,t:1527873111658};\\\", \\\"{x:599,y:492,t:1527873111698};\\\", \\\"{x:599,y:494,t:1527873112706};\\\", \\\"{x:599,y:498,t:1527873112717};\\\", \\\"{x:599,y:504,t:1527873112735};\\\", \\\"{x:599,y:510,t:1527873112750};\\\", \\\"{x:598,y:514,t:1527873112767};\\\", \\\"{x:598,y:519,t:1527873112786};\\\", \\\"{x:598,y:525,t:1527873112801};\\\", \\\"{x:596,y:532,t:1527873112814};\\\", \\\"{x:595,y:539,t:1527873112831};\\\", \\\"{x:594,y:549,t:1527873112848};\\\", \\\"{x:592,y:557,t:1527873112866};\\\", \\\"{x:591,y:568,t:1527873112882};\\\", \\\"{x:589,y:588,t:1527873112900};\\\", \\\"{x:584,y:606,t:1527873112918};\\\", \\\"{x:581,y:626,t:1527873112934};\\\", \\\"{x:577,y:648,t:1527873112951};\\\", \\\"{x:571,y:663,t:1527873112967};\\\", \\\"{x:569,y:668,t:1527873112985};\\\", \\\"{x:568,y:671,t:1527873113001};\\\", \\\"{x:568,y:667,t:1527873113066};\\\", \\\"{x:572,y:657,t:1527873113073};\\\", \\\"{x:575,y:644,t:1527873113084};\\\", \\\"{x:586,y:604,t:1527873113101};\\\", \\\"{x:598,y:572,t:1527873113118};\\\", \\\"{x:603,y:554,t:1527873113135};\\\", \\\"{x:607,y:542,t:1527873113152};\\\", \\\"{x:608,y:537,t:1527873113167};\\\", \\\"{x:611,y:534,t:1527873113184};\\\", \\\"{x:612,y:529,t:1527873113202};\\\", \\\"{x:612,y:525,t:1527873113218};\\\", \\\"{x:613,y:521,t:1527873113235};\\\", \\\"{x:614,y:519,t:1527873113251};\\\", \\\"{x:614,y:516,t:1527873113269};\\\", \\\"{x:615,y:512,t:1527873113284};\\\", \\\"{x:615,y:511,t:1527873113515};\\\", \\\"{x:615,y:510,t:1527873113538};\\\", \\\"{x:615,y:509,t:1527873113552};\\\", \\\"{x:615,y:510,t:1527873113942};\\\", \\\"{x:615,y:513,t:1527873113955};\\\", \\\"{x:616,y:519,t:1527873113973};\\\", \\\"{x:629,y:531,t:1527873113989};\\\", \\\"{x:638,y:537,t:1527873114004};\\\", \\\"{x:678,y:550,t:1527873114022};\\\", \\\"{x:746,y:564,t:1527873114039};\\\", \\\"{x:832,y:575,t:1527873114055};\\\", \\\"{x:923,y:586,t:1527873114071};\\\", \\\"{x:1007,y:599,t:1527873114089};\\\", \\\"{x:1085,y:610,t:1527873114105};\\\", \\\"{x:1163,y:621,t:1527873114122};\\\", \\\"{x:1243,y:632,t:1527873114139};\\\", \\\"{x:1306,y:646,t:1527873114155};\\\", \\\"{x:1378,y:654,t:1527873114172};\\\", \\\"{x:1478,y:670,t:1527873114189};\\\", \\\"{x:1531,y:678,t:1527873114205};\\\", \\\"{x:1555,y:683,t:1527873114222};\\\", \\\"{x:1584,y:691,t:1527873114239};\\\", \\\"{x:1604,y:696,t:1527873114256};\\\", \\\"{x:1614,y:696,t:1527873114272};\\\", \\\"{x:1618,y:697,t:1527873114289};\\\", \\\"{x:1622,y:698,t:1527873114305};\\\", \\\"{x:1622,y:700,t:1527873114322};\\\", \\\"{x:1622,y:703,t:1527873114339};\\\", \\\"{x:1622,y:706,t:1527873114356};\\\", \\\"{x:1616,y:710,t:1527873114372};\\\", \\\"{x:1599,y:720,t:1527873114389};\\\", \\\"{x:1580,y:733,t:1527873114405};\\\", \\\"{x:1556,y:744,t:1527873114422};\\\", \\\"{x:1534,y:750,t:1527873114439};\\\", \\\"{x:1512,y:754,t:1527873114456};\\\", \\\"{x:1494,y:760,t:1527873114472};\\\", \\\"{x:1484,y:763,t:1527873114489};\\\", \\\"{x:1477,y:765,t:1527873114507};\\\", \\\"{x:1470,y:767,t:1527873114522};\\\", \\\"{x:1467,y:768,t:1527873114539};\\\", \\\"{x:1466,y:770,t:1527873114556};\\\", \\\"{x:1465,y:772,t:1527873114572};\\\", \\\"{x:1462,y:776,t:1527873114590};\\\", \\\"{x:1460,y:778,t:1527873114606};\\\", \\\"{x:1459,y:779,t:1527873114622};\\\", \\\"{x:1457,y:782,t:1527873114640};\\\", \\\"{x:1455,y:783,t:1527873114656};\\\", \\\"{x:1453,y:786,t:1527873114673};\\\", \\\"{x:1451,y:787,t:1527873114689};\\\", \\\"{x:1451,y:789,t:1527873114706};\\\", \\\"{x:1450,y:790,t:1527873114723};\\\", \\\"{x:1448,y:791,t:1527873114739};\\\", \\\"{x:1446,y:795,t:1527873114756};\\\", \\\"{x:1439,y:800,t:1527873114773};\\\", \\\"{x:1439,y:801,t:1527873114789};\\\", \\\"{x:1438,y:803,t:1527873114806};\\\", \\\"{x:1438,y:804,t:1527873114824};\\\", \\\"{x:1438,y:805,t:1527873114846};\\\", \\\"{x:1438,y:807,t:1527873114862};\\\", \\\"{x:1438,y:808,t:1527873114874};\\\", \\\"{x:1437,y:809,t:1527873114889};\\\", \\\"{x:1436,y:810,t:1527873114906};\\\", \\\"{x:1435,y:811,t:1527873114982};\\\", \\\"{x:1435,y:812,t:1527873114990};\\\", \\\"{x:1435,y:815,t:1527873115006};\\\", \\\"{x:1435,y:821,t:1527873115024};\\\", \\\"{x:1435,y:826,t:1527873115039};\\\", \\\"{x:1435,y:833,t:1527873115057};\\\", \\\"{x:1432,y:844,t:1527873115073};\\\", \\\"{x:1430,y:850,t:1527873115089};\\\", \\\"{x:1428,y:855,t:1527873115107};\\\", \\\"{x:1426,y:862,t:1527873115123};\\\", \\\"{x:1422,y:872,t:1527873115139};\\\", \\\"{x:1418,y:880,t:1527873115156};\\\", \\\"{x:1411,y:894,t:1527873115174};\\\", \\\"{x:1406,y:903,t:1527873115190};\\\", \\\"{x:1400,y:911,t:1527873115206};\\\", \\\"{x:1398,y:915,t:1527873115223};\\\", \\\"{x:1393,y:920,t:1527873115241};\\\", \\\"{x:1392,y:922,t:1527873115257};\\\", \\\"{x:1389,y:926,t:1527873115272};\\\", \\\"{x:1389,y:927,t:1527873115290};\\\", \\\"{x:1388,y:929,t:1527873115305};\\\", \\\"{x:1388,y:931,t:1527873115322};\\\", \\\"{x:1388,y:935,t:1527873115340};\\\", \\\"{x:1389,y:940,t:1527873115356};\\\", \\\"{x:1392,y:947,t:1527873115373};\\\", \\\"{x:1394,y:954,t:1527873115389};\\\", \\\"{x:1395,y:959,t:1527873115406};\\\", \\\"{x:1396,y:960,t:1527873115423};\\\", \\\"{x:1398,y:962,t:1527873115440};\\\", \\\"{x:1400,y:964,t:1527873115456};\\\", \\\"{x:1402,y:965,t:1527873115474};\\\", \\\"{x:1405,y:967,t:1527873115490};\\\", \\\"{x:1408,y:969,t:1527873115507};\\\", \\\"{x:1411,y:970,t:1527873115523};\\\", \\\"{x:1415,y:972,t:1527873115540};\\\", \\\"{x:1418,y:972,t:1527873115556};\\\", \\\"{x:1420,y:972,t:1527873115573};\\\", \\\"{x:1421,y:972,t:1527873115590};\\\", \\\"{x:1423,y:972,t:1527873115606};\\\", \\\"{x:1425,y:971,t:1527873115662};\\\", \\\"{x:1426,y:971,t:1527873115673};\\\", \\\"{x:1427,y:970,t:1527873115691};\\\", \\\"{x:1428,y:970,t:1527873115750};\\\", \\\"{x:1428,y:969,t:1527873115838};\\\", \\\"{x:1428,y:968,t:1527873115943};\\\", \\\"{x:1427,y:968,t:1527873115974};\\\", \\\"{x:1425,y:968,t:1527873115991};\\\", \\\"{x:1422,y:967,t:1527873116007};\\\", \\\"{x:1414,y:965,t:1527873116024};\\\", \\\"{x:1400,y:964,t:1527873116041};\\\", \\\"{x:1379,y:961,t:1527873116057};\\\", \\\"{x:1350,y:955,t:1527873116073};\\\", \\\"{x:1294,y:947,t:1527873116090};\\\", \\\"{x:1208,y:936,t:1527873116108};\\\", \\\"{x:1115,y:914,t:1527873116124};\\\", \\\"{x:1028,y:899,t:1527873116141};\\\", \\\"{x:913,y:874,t:1527873116158};\\\", \\\"{x:874,y:864,t:1527873116174};\\\", \\\"{x:844,y:857,t:1527873116191};\\\", \\\"{x:823,y:850,t:1527873116207};\\\", \\\"{x:800,y:843,t:1527873116224};\\\", \\\"{x:777,y:835,t:1527873116240};\\\", \\\"{x:743,y:824,t:1527873116257};\\\", \\\"{x:695,y:810,t:1527873116274};\\\", \\\"{x:646,y:797,t:1527873116290};\\\", \\\"{x:620,y:788,t:1527873116307};\\\", \\\"{x:606,y:783,t:1527873116324};\\\", \\\"{x:595,y:778,t:1527873116340};\\\", \\\"{x:590,y:775,t:1527873116357};\\\", \\\"{x:582,y:770,t:1527873116374};\\\", \\\"{x:568,y:764,t:1527873116390};\\\", \\\"{x:556,y:759,t:1527873116407};\\\", \\\"{x:548,y:754,t:1527873116425};\\\", \\\"{x:541,y:750,t:1527873116440};\\\", \\\"{x:535,y:745,t:1527873116456};\\\", \\\"{x:531,y:741,t:1527873116473};\\\", \\\"{x:527,y:739,t:1527873116491};\\\", \\\"{x:523,y:738,t:1527873116507};\\\", \\\"{x:522,y:737,t:1527873116524};\\\", \\\"{x:522,y:735,t:1527873116541};\\\", \\\"{x:520,y:732,t:1527873116557};\\\", \\\"{x:520,y:730,t:1527873117382};\\\", \\\"{x:520,y:729,t:1527873117422};\\\", \\\"{x:520,y:726,t:1527873117437};\\\", \\\"{x:520,y:725,t:1527873117453};\\\", \\\"{x:520,y:723,t:1527873117461};\\\", \\\"{x:521,y:719,t:1527873117475};\\\", \\\"{x:521,y:712,t:1527873117491};\\\", \\\"{x:521,y:702,t:1527873117508};\\\", \\\"{x:516,y:688,t:1527873117525};\\\", \\\"{x:508,y:680,t:1527873117541};\\\", \\\"{x:504,y:673,t:1527873117558};\\\", \\\"{x:501,y:669,t:1527873117575};\\\", \\\"{x:496,y:663,t:1527873117591};\\\", \\\"{x:491,y:656,t:1527873117608};\\\", \\\"{x:484,y:648,t:1527873117625};\\\", \\\"{x:480,y:643,t:1527873117642};\\\", \\\"{x:476,y:638,t:1527873117658};\\\", \\\"{x:474,y:635,t:1527873117674};\\\", \\\"{x:472,y:631,t:1527873117692};\\\", \\\"{x:470,y:625,t:1527873117708};\\\", \\\"{x:463,y:610,t:1527873117726};\\\", \\\"{x:456,y:598,t:1527873117741};\\\", \\\"{x:453,y:588,t:1527873117758};\\\", \\\"{x:450,y:581,t:1527873117775};\\\", \\\"{x:446,y:573,t:1527873117792};\\\", \\\"{x:442,y:563,t:1527873117819};\\\", \\\"{x:442,y:561,t:1527873117825};\\\", \\\"{x:441,y:558,t:1527873117842};\\\", \\\"{x:440,y:556,t:1527873117858};\\\", \\\"{x:440,y:555,t:1527873117875};\\\", \\\"{x:439,y:553,t:1527873117891};\\\" ] }, { \\\"rt\\\": 18864, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 322312, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:438,y:548,t:1527873118007};\\\", \\\"{x:438,y:547,t:1527873118620};\\\", \\\"{x:432,y:548,t:1527873118644};\\\", \\\"{x:421,y:549,t:1527873118658};\\\", \\\"{x:411,y:550,t:1527873118676};\\\", \\\"{x:398,y:550,t:1527873118691};\\\", \\\"{x:385,y:550,t:1527873118709};\\\", \\\"{x:379,y:550,t:1527873118726};\\\", \\\"{x:375,y:550,t:1527873118741};\\\", \\\"{x:369,y:550,t:1527873118759};\\\", \\\"{x:357,y:547,t:1527873118776};\\\", \\\"{x:345,y:542,t:1527873118791};\\\", \\\"{x:337,y:537,t:1527873118809};\\\", \\\"{x:331,y:533,t:1527873118826};\\\", \\\"{x:328,y:529,t:1527873118842};\\\", \\\"{x:328,y:527,t:1527873118859};\\\", \\\"{x:327,y:526,t:1527873118875};\\\", \\\"{x:327,y:522,t:1527873118893};\\\", \\\"{x:328,y:518,t:1527873118909};\\\", \\\"{x:330,y:513,t:1527873118926};\\\", \\\"{x:334,y:509,t:1527873118942};\\\", \\\"{x:338,y:508,t:1527873118959};\\\", \\\"{x:343,y:505,t:1527873118976};\\\", \\\"{x:346,y:504,t:1527873118992};\\\", \\\"{x:354,y:500,t:1527873119009};\\\", \\\"{x:362,y:497,t:1527873119026};\\\", \\\"{x:368,y:496,t:1527873119043};\\\", \\\"{x:378,y:496,t:1527873119059};\\\", \\\"{x:392,y:494,t:1527873119076};\\\", \\\"{x:409,y:492,t:1527873119094};\\\", \\\"{x:418,y:490,t:1527873119110};\\\", \\\"{x:424,y:490,t:1527873119126};\\\", \\\"{x:427,y:490,t:1527873119144};\\\", \\\"{x:431,y:490,t:1527873119160};\\\", \\\"{x:437,y:490,t:1527873119177};\\\", \\\"{x:448,y:491,t:1527873119193};\\\", \\\"{x:458,y:491,t:1527873119209};\\\", \\\"{x:470,y:491,t:1527873119226};\\\", \\\"{x:479,y:491,t:1527873119244};\\\", \\\"{x:485,y:491,t:1527873119259};\\\", \\\"{x:490,y:491,t:1527873119276};\\\", \\\"{x:499,y:492,t:1527873119295};\\\", \\\"{x:506,y:492,t:1527873119308};\\\", \\\"{x:515,y:492,t:1527873119326};\\\", \\\"{x:517,y:492,t:1527873119343};\\\", \\\"{x:518,y:492,t:1527873119359};\\\", \\\"{x:520,y:492,t:1527873119429};\\\", \\\"{x:521,y:492,t:1527873119445};\\\", \\\"{x:523,y:492,t:1527873119694};\\\", \\\"{x:525,y:492,t:1527873119710};\\\", \\\"{x:526,y:492,t:1527873119733};\\\", \\\"{x:527,y:491,t:1527873119757};\\\", \\\"{x:528,y:491,t:1527873119765};\\\", \\\"{x:529,y:491,t:1527873119782};\\\", \\\"{x:530,y:490,t:1527873120022};\\\", \\\"{x:530,y:489,t:1527873120046};\\\", \\\"{x:529,y:489,t:1527873120069};\\\", \\\"{x:528,y:489,t:1527873120093};\\\", \\\"{x:527,y:489,t:1527873120117};\\\", \\\"{x:524,y:488,t:1527873120141};\\\", \\\"{x:523,y:488,t:1527873120150};\\\", \\\"{x:521,y:487,t:1527873120161};\\\", \\\"{x:518,y:486,t:1527873120179};\\\", \\\"{x:516,y:485,t:1527873120194};\\\", \\\"{x:511,y:484,t:1527873120210};\\\", \\\"{x:507,y:484,t:1527873120227};\\\", \\\"{x:505,y:482,t:1527873120243};\\\", \\\"{x:503,y:482,t:1527873120260};\\\", \\\"{x:501,y:481,t:1527873120276};\\\", \\\"{x:501,y:480,t:1527873120470};\\\", \\\"{x:501,y:479,t:1527873120494};\\\", \\\"{x:501,y:478,t:1527873120510};\\\", \\\"{x:502,y:478,t:1527873120534};\\\", \\\"{x:503,y:478,t:1527873120545};\\\", \\\"{x:505,y:478,t:1527873120560};\\\", \\\"{x:508,y:479,t:1527873120577};\\\", \\\"{x:512,y:480,t:1527873120595};\\\", \\\"{x:516,y:480,t:1527873120611};\\\", \\\"{x:518,y:480,t:1527873120627};\\\", \\\"{x:519,y:480,t:1527873120644};\\\", \\\"{x:520,y:480,t:1527873120660};\\\", \\\"{x:531,y:480,t:1527873120677};\\\", \\\"{x:546,y:482,t:1527873120694};\\\", \\\"{x:557,y:483,t:1527873120710};\\\", \\\"{x:571,y:483,t:1527873120727};\\\", \\\"{x:581,y:483,t:1527873120744};\\\", \\\"{x:587,y:483,t:1527873120760};\\\", \\\"{x:592,y:483,t:1527873120777};\\\", \\\"{x:596,y:483,t:1527873120795};\\\", \\\"{x:599,y:483,t:1527873120811};\\\", \\\"{x:601,y:483,t:1527873120827};\\\", \\\"{x:605,y:483,t:1527873120845};\\\", \\\"{x:611,y:483,t:1527873120860};\\\", \\\"{x:625,y:483,t:1527873120877};\\\", \\\"{x:639,y:483,t:1527873120895};\\\", \\\"{x:654,y:483,t:1527873120911};\\\", \\\"{x:671,y:483,t:1527873120928};\\\", \\\"{x:686,y:483,t:1527873120944};\\\", \\\"{x:694,y:483,t:1527873120962};\\\", \\\"{x:697,y:483,t:1527873120977};\\\", \\\"{x:699,y:483,t:1527873120994};\\\", \\\"{x:700,y:483,t:1527873121038};\\\", \\\"{x:701,y:483,t:1527873121086};\\\", \\\"{x:702,y:483,t:1527873121094};\\\", \\\"{x:703,y:483,t:1527873121111};\\\", \\\"{x:704,y:483,t:1527873121128};\\\", \\\"{x:705,y:483,t:1527873121144};\\\", \\\"{x:706,y:483,t:1527873121182};\\\", \\\"{x:707,y:483,t:1527873121213};\\\", \\\"{x:708,y:483,t:1527873121228};\\\", \\\"{x:711,y:482,t:1527873121244};\\\", \\\"{x:714,y:480,t:1527873121262};\\\", \\\"{x:720,y:479,t:1527873121278};\\\", \\\"{x:722,y:479,t:1527873121294};\\\", \\\"{x:723,y:479,t:1527873121311};\\\", \\\"{x:724,y:479,t:1527873121333};\\\", \\\"{x:725,y:478,t:1527873121492};\\\", \\\"{x:725,y:477,t:1527873121500};\\\", \\\"{x:726,y:476,t:1527873122350};\\\", \\\"{x:728,y:476,t:1527873122362};\\\", \\\"{x:739,y:476,t:1527873122379};\\\", \\\"{x:750,y:476,t:1527873122395};\\\", \\\"{x:763,y:476,t:1527873122412};\\\", \\\"{x:771,y:476,t:1527873122429};\\\", \\\"{x:777,y:476,t:1527873122445};\\\", \\\"{x:780,y:476,t:1527873122462};\\\", \\\"{x:786,y:476,t:1527873122478};\\\", \\\"{x:792,y:476,t:1527873122495};\\\", \\\"{x:799,y:476,t:1527873122512};\\\", \\\"{x:803,y:476,t:1527873122528};\\\", \\\"{x:811,y:477,t:1527873122545};\\\", \\\"{x:821,y:478,t:1527873122563};\\\", \\\"{x:833,y:480,t:1527873122579};\\\", \\\"{x:850,y:483,t:1527873122596};\\\", \\\"{x:867,y:484,t:1527873122613};\\\", \\\"{x:886,y:487,t:1527873122629};\\\", \\\"{x:911,y:489,t:1527873122645};\\\", \\\"{x:918,y:490,t:1527873122662};\\\", \\\"{x:923,y:490,t:1527873122678};\\\", \\\"{x:928,y:492,t:1527873122695};\\\", \\\"{x:936,y:492,t:1527873122711};\\\", \\\"{x:947,y:494,t:1527873122729};\\\", \\\"{x:968,y:498,t:1527873122745};\\\", \\\"{x:989,y:500,t:1527873122762};\\\", \\\"{x:1005,y:500,t:1527873122779};\\\", \\\"{x:1019,y:500,t:1527873122795};\\\", \\\"{x:1027,y:500,t:1527873122812};\\\", \\\"{x:1055,y:503,t:1527873122829};\\\", \\\"{x:1083,y:509,t:1527873122845};\\\", \\\"{x:1114,y:517,t:1527873122863};\\\", \\\"{x:1136,y:523,t:1527873122879};\\\", \\\"{x:1159,y:531,t:1527873122895};\\\", \\\"{x:1178,y:540,t:1527873122912};\\\", \\\"{x:1197,y:550,t:1527873122930};\\\", \\\"{x:1213,y:561,t:1527873122946};\\\", \\\"{x:1225,y:572,t:1527873122963};\\\", \\\"{x:1235,y:585,t:1527873122980};\\\", \\\"{x:1242,y:597,t:1527873122996};\\\", \\\"{x:1254,y:612,t:1527873123012};\\\", \\\"{x:1268,y:631,t:1527873123029};\\\", \\\"{x:1276,y:642,t:1527873123046};\\\", \\\"{x:1283,y:653,t:1527873123063};\\\", \\\"{x:1287,y:663,t:1527873123079};\\\", \\\"{x:1287,y:667,t:1527873123097};\\\", \\\"{x:1288,y:674,t:1527873123112};\\\", \\\"{x:1288,y:680,t:1527873123130};\\\", \\\"{x:1291,y:689,t:1527873123146};\\\", \\\"{x:1292,y:697,t:1527873123163};\\\", \\\"{x:1294,y:702,t:1527873123179};\\\", \\\"{x:1296,y:706,t:1527873123196};\\\", \\\"{x:1298,y:710,t:1527873123213};\\\", \\\"{x:1302,y:719,t:1527873123230};\\\", \\\"{x:1307,y:725,t:1527873123246};\\\", \\\"{x:1317,y:737,t:1527873123263};\\\", \\\"{x:1327,y:749,t:1527873123280};\\\", \\\"{x:1337,y:760,t:1527873123297};\\\", \\\"{x:1345,y:769,t:1527873123313};\\\", \\\"{x:1350,y:777,t:1527873123330};\\\", \\\"{x:1357,y:787,t:1527873123346};\\\", \\\"{x:1363,y:795,t:1527873123363};\\\", \\\"{x:1367,y:799,t:1527873123380};\\\", \\\"{x:1370,y:802,t:1527873123397};\\\", \\\"{x:1370,y:803,t:1527873123413};\\\", \\\"{x:1371,y:806,t:1527873123430};\\\", \\\"{x:1371,y:810,t:1527873123447};\\\", \\\"{x:1372,y:814,t:1527873123464};\\\", \\\"{x:1372,y:820,t:1527873123479};\\\", \\\"{x:1362,y:829,t:1527873123496};\\\", \\\"{x:1350,y:834,t:1527873123513};\\\", \\\"{x:1334,y:839,t:1527873123530};\\\", \\\"{x:1318,y:844,t:1527873123546};\\\", \\\"{x:1306,y:845,t:1527873123564};\\\", \\\"{x:1291,y:845,t:1527873123580};\\\", \\\"{x:1278,y:845,t:1527873123596};\\\", \\\"{x:1269,y:845,t:1527873123613};\\\", \\\"{x:1263,y:843,t:1527873123629};\\\", \\\"{x:1257,y:839,t:1527873123646};\\\", \\\"{x:1251,y:838,t:1527873123664};\\\", \\\"{x:1249,y:837,t:1527873123680};\\\", \\\"{x:1248,y:835,t:1527873123697};\\\", \\\"{x:1246,y:834,t:1527873123713};\\\", \\\"{x:1246,y:833,t:1527873123729};\\\", \\\"{x:1244,y:830,t:1527873123747};\\\", \\\"{x:1237,y:827,t:1527873123764};\\\", \\\"{x:1232,y:824,t:1527873123780};\\\", \\\"{x:1227,y:823,t:1527873123796};\\\", \\\"{x:1225,y:823,t:1527873123814};\\\", \\\"{x:1224,y:823,t:1527873123830};\\\", \\\"{x:1222,y:823,t:1527873123847};\\\", \\\"{x:1221,y:823,t:1527873123942};\\\", \\\"{x:1219,y:823,t:1527873123965};\\\", \\\"{x:1218,y:823,t:1527873123982};\\\", \\\"{x:1216,y:823,t:1527873123997};\\\", \\\"{x:1215,y:823,t:1527873124014};\\\", \\\"{x:1212,y:821,t:1527873124030};\\\", \\\"{x:1209,y:820,t:1527873124047};\\\", \\\"{x:1208,y:819,t:1527873124064};\\\", \\\"{x:1207,y:818,t:1527873124081};\\\", \\\"{x:1207,y:816,t:1527873124097};\\\", \\\"{x:1206,y:810,t:1527873124114};\\\", \\\"{x:1203,y:802,t:1527873124130};\\\", \\\"{x:1196,y:796,t:1527873124147};\\\", \\\"{x:1195,y:793,t:1527873124163};\\\", \\\"{x:1193,y:789,t:1527873124181};\\\", \\\"{x:1192,y:787,t:1527873124198};\\\", \\\"{x:1191,y:784,t:1527873124214};\\\", \\\"{x:1191,y:782,t:1527873124231};\\\", \\\"{x:1189,y:778,t:1527873124247};\\\", \\\"{x:1188,y:775,t:1527873124264};\\\", \\\"{x:1185,y:772,t:1527873124281};\\\", \\\"{x:1184,y:770,t:1527873124297};\\\", \\\"{x:1183,y:768,t:1527873124316};\\\", \\\"{x:1180,y:765,t:1527873124331};\\\", \\\"{x:1178,y:762,t:1527873124347};\\\", \\\"{x:1177,y:760,t:1527873124364};\\\", \\\"{x:1176,y:758,t:1527873124382};\\\", \\\"{x:1175,y:758,t:1527873124397};\\\", \\\"{x:1174,y:757,t:1527873124414};\\\", \\\"{x:1174,y:758,t:1527873124726};\\\", \\\"{x:1174,y:760,t:1527873124733};\\\", \\\"{x:1174,y:763,t:1527873124748};\\\", \\\"{x:1172,y:765,t:1527873124764};\\\", \\\"{x:1172,y:764,t:1527873125070};\\\", \\\"{x:1172,y:763,t:1527873125222};\\\", \\\"{x:1173,y:762,t:1527873125438};\\\", \\\"{x:1172,y:762,t:1527873134670};\\\", \\\"{x:1170,y:762,t:1527873134688};\\\", \\\"{x:1166,y:762,t:1527873134705};\\\", \\\"{x:1148,y:761,t:1527873134721};\\\", \\\"{x:1118,y:753,t:1527873134738};\\\", \\\"{x:1055,y:735,t:1527873134756};\\\", \\\"{x:975,y:712,t:1527873134771};\\\", \\\"{x:895,y:690,t:1527873134789};\\\", \\\"{x:790,y:661,t:1527873134806};\\\", \\\"{x:750,y:648,t:1527873134822};\\\", \\\"{x:723,y:642,t:1527873134838};\\\", \\\"{x:704,y:636,t:1527873134854};\\\", \\\"{x:691,y:632,t:1527873134872};\\\", \\\"{x:675,y:630,t:1527873134888};\\\", \\\"{x:655,y:628,t:1527873134904};\\\", \\\"{x:635,y:624,t:1527873134922};\\\", \\\"{x:610,y:619,t:1527873134939};\\\", \\\"{x:583,y:616,t:1527873134955};\\\", \\\"{x:553,y:616,t:1527873134972};\\\", \\\"{x:534,y:616,t:1527873134988};\\\", \\\"{x:507,y:616,t:1527873135006};\\\", \\\"{x:478,y:616,t:1527873135023};\\\", \\\"{x:446,y:616,t:1527873135038};\\\", \\\"{x:412,y:613,t:1527873135056};\\\", \\\"{x:388,y:613,t:1527873135072};\\\", \\\"{x:359,y:613,t:1527873135089};\\\", \\\"{x:336,y:606,t:1527873135105};\\\", \\\"{x:313,y:598,t:1527873135122};\\\", \\\"{x:297,y:591,t:1527873135138};\\\", \\\"{x:277,y:580,t:1527873135156};\\\", \\\"{x:248,y:564,t:1527873135173};\\\", \\\"{x:231,y:557,t:1527873135188};\\\", \\\"{x:220,y:550,t:1527873135206};\\\", \\\"{x:216,y:547,t:1527873135222};\\\", \\\"{x:215,y:545,t:1527873135238};\\\", \\\"{x:216,y:540,t:1527873135255};\\\", \\\"{x:218,y:535,t:1527873135272};\\\", \\\"{x:219,y:531,t:1527873135288};\\\", \\\"{x:219,y:528,t:1527873135305};\\\", \\\"{x:216,y:524,t:1527873135322};\\\", \\\"{x:214,y:523,t:1527873135338};\\\", \\\"{x:212,y:522,t:1527873135355};\\\", \\\"{x:211,y:522,t:1527873135373};\\\", \\\"{x:210,y:521,t:1527873135388};\\\", \\\"{x:204,y:519,t:1527873135406};\\\", \\\"{x:200,y:518,t:1527873135422};\\\", \\\"{x:195,y:516,t:1527873135440};\\\", \\\"{x:193,y:516,t:1527873135455};\\\", \\\"{x:191,y:515,t:1527873135472};\\\", \\\"{x:189,y:514,t:1527873135489};\\\", \\\"{x:187,y:514,t:1527873135506};\\\", \\\"{x:182,y:511,t:1527873135523};\\\", \\\"{x:173,y:508,t:1527873135539};\\\", \\\"{x:165,y:504,t:1527873135555};\\\", \\\"{x:158,y:502,t:1527873135573};\\\", \\\"{x:155,y:502,t:1527873135589};\\\", \\\"{x:154,y:501,t:1527873135670};\\\", \\\"{x:154,y:500,t:1527873136116};\\\", \\\"{x:160,y:500,t:1527873136124};\\\", \\\"{x:182,y:504,t:1527873136139};\\\", \\\"{x:279,y:532,t:1527873136157};\\\", \\\"{x:332,y:546,t:1527873136172};\\\", \\\"{x:380,y:560,t:1527873136190};\\\", \\\"{x:407,y:572,t:1527873136207};\\\", \\\"{x:431,y:588,t:1527873136223};\\\", \\\"{x:450,y:599,t:1527873136240};\\\", \\\"{x:470,y:611,t:1527873136256};\\\", \\\"{x:493,y:624,t:1527873136273};\\\", \\\"{x:509,y:634,t:1527873136289};\\\", \\\"{x:526,y:644,t:1527873136307};\\\", \\\"{x:538,y:654,t:1527873136323};\\\", \\\"{x:549,y:665,t:1527873136340};\\\", \\\"{x:561,y:681,t:1527873136356};\\\", \\\"{x:566,y:687,t:1527873136373};\\\", \\\"{x:566,y:689,t:1527873136396};\\\", \\\"{x:566,y:690,t:1527873136407};\\\", \\\"{x:566,y:694,t:1527873136423};\\\", \\\"{x:560,y:701,t:1527873136439};\\\", \\\"{x:551,y:705,t:1527873136457};\\\", \\\"{x:542,y:710,t:1527873136472};\\\", \\\"{x:531,y:711,t:1527873136489};\\\", \\\"{x:518,y:711,t:1527873136507};\\\", \\\"{x:511,y:711,t:1527873136523};\\\", \\\"{x:507,y:713,t:1527873136540};\\\", \\\"{x:502,y:716,t:1527873136557};\\\", \\\"{x:499,y:721,t:1527873136573};\\\", \\\"{x:499,y:722,t:1527873136597};\\\", \\\"{x:499,y:723,t:1527873136620};\\\", \\\"{x:499,y:724,t:1527873136628};\\\", \\\"{x:499,y:726,t:1527873136645};\\\", \\\"{x:499,y:727,t:1527873136657};\\\", \\\"{x:499,y:731,t:1527873136674};\\\", \\\"{x:499,y:732,t:1527873137357};\\\", \\\"{x:501,y:732,t:1527873137374};\\\", \\\"{x:503,y:732,t:1527873137391};\\\", \\\"{x:506,y:732,t:1527873137407};\\\", \\\"{x:513,y:732,t:1527873137423};\\\", \\\"{x:520,y:732,t:1527873137441};\\\", \\\"{x:526,y:732,t:1527873137457};\\\", \\\"{x:531,y:731,t:1527873137474};\\\", \\\"{x:533,y:731,t:1527873137491};\\\", \\\"{x:535,y:731,t:1527873137508};\\\", \\\"{x:538,y:730,t:1527873137524};\\\", \\\"{x:539,y:729,t:1527873137541};\\\", \\\"{x:540,y:728,t:1527873137558};\\\", \\\"{x:541,y:727,t:1527873137574};\\\", \\\"{x:544,y:725,t:1527873137591};\\\", \\\"{x:546,y:724,t:1527873137608};\\\", \\\"{x:551,y:722,t:1527873137624};\\\", \\\"{x:557,y:718,t:1527873137641};\\\", \\\"{x:565,y:713,t:1527873137657};\\\", \\\"{x:574,y:706,t:1527873137674};\\\", \\\"{x:578,y:703,t:1527873137690};\\\", \\\"{x:581,y:701,t:1527873137708};\\\", \\\"{x:586,y:699,t:1527873137723};\\\", \\\"{x:591,y:697,t:1527873137741};\\\", \\\"{x:592,y:696,t:1527873137757};\\\", \\\"{x:593,y:694,t:1527873137773};\\\", \\\"{x:594,y:693,t:1527873137791};\\\", \\\"{x:596,y:690,t:1527873137808};\\\", \\\"{x:600,y:685,t:1527873137824};\\\", \\\"{x:601,y:683,t:1527873137841};\\\", \\\"{x:604,y:681,t:1527873137858};\\\", \\\"{x:605,y:680,t:1527873137874};\\\", \\\"{x:605,y:679,t:1527873137903};\\\", \\\"{x:607,y:676,t:1527873137924};\\\", \\\"{x:608,y:675,t:1527873137949};\\\" ] }, { \\\"rt\\\": 20079, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 343662, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:615,y:653,t:1527873138142};\\\", \\\"{x:616,y:648,t:1527873138175};\\\", \\\"{x:616,y:643,t:1527873138190};\\\", \\\"{x:616,y:642,t:1527873138208};\\\", \\\"{x:616,y:639,t:1527873138228};\\\", \\\"{x:616,y:638,t:1527873138241};\\\", \\\"{x:616,y:637,t:1527873138257};\\\", \\\"{x:616,y:635,t:1527873138275};\\\", \\\"{x:616,y:634,t:1527873138291};\\\", \\\"{x:616,y:630,t:1527873138308};\\\", \\\"{x:616,y:624,t:1527873138325};\\\", \\\"{x:616,y:621,t:1527873138341};\\\", \\\"{x:616,y:616,t:1527873138357};\\\", \\\"{x:614,y:612,t:1527873138374};\\\", \\\"{x:613,y:610,t:1527873138391};\\\", \\\"{x:612,y:607,t:1527873138407};\\\", \\\"{x:608,y:601,t:1527873138424};\\\", \\\"{x:605,y:596,t:1527873138442};\\\", \\\"{x:601,y:591,t:1527873138458};\\\", \\\"{x:600,y:589,t:1527873138474};\\\", \\\"{x:598,y:586,t:1527873138492};\\\", \\\"{x:597,y:583,t:1527873138508};\\\", \\\"{x:595,y:579,t:1527873138524};\\\", \\\"{x:594,y:577,t:1527873138542};\\\", \\\"{x:592,y:573,t:1527873138557};\\\", \\\"{x:589,y:567,t:1527873138575};\\\", \\\"{x:584,y:560,t:1527873138592};\\\", \\\"{x:582,y:556,t:1527873138608};\\\", \\\"{x:580,y:553,t:1527873138625};\\\", \\\"{x:574,y:546,t:1527873138641};\\\", \\\"{x:527,y:514,t:1527873138710};\\\", \\\"{x:515,y:508,t:1527873138724};\\\", \\\"{x:507,y:505,t:1527873138742};\\\", \\\"{x:498,y:502,t:1527873138758};\\\", \\\"{x:490,y:500,t:1527873138775};\\\", \\\"{x:483,y:495,t:1527873138791};\\\", \\\"{x:479,y:493,t:1527873138808};\\\", \\\"{x:477,y:492,t:1527873138824};\\\", \\\"{x:473,y:490,t:1527873138842};\\\", \\\"{x:465,y:487,t:1527873138858};\\\", \\\"{x:459,y:485,t:1527873138875};\\\", \\\"{x:451,y:482,t:1527873138891};\\\", \\\"{x:445,y:481,t:1527873138908};\\\", \\\"{x:441,y:480,t:1527873138925};\\\", \\\"{x:439,y:480,t:1527873138942};\\\", \\\"{x:437,y:480,t:1527873138959};\\\", \\\"{x:433,y:478,t:1527873138976};\\\", \\\"{x:430,y:477,t:1527873138991};\\\", \\\"{x:428,y:477,t:1527873139008};\\\", \\\"{x:424,y:476,t:1527873139026};\\\", \\\"{x:423,y:476,t:1527873139044};\\\", \\\"{x:422,y:475,t:1527873139067};\\\", \\\"{x:423,y:475,t:1527873139757};\\\", \\\"{x:424,y:475,t:1527873139764};\\\", \\\"{x:425,y:476,t:1527873139780};\\\", \\\"{x:427,y:476,t:1527873139796};\\\", \\\"{x:427,y:477,t:1527873139809};\\\", \\\"{x:429,y:478,t:1527873139827};\\\", \\\"{x:430,y:478,t:1527873139843};\\\", \\\"{x:435,y:478,t:1527873139860};\\\", \\\"{x:447,y:479,t:1527873139877};\\\", \\\"{x:462,y:482,t:1527873139893};\\\", \\\"{x:478,y:485,t:1527873139910};\\\", \\\"{x:498,y:488,t:1527873139928};\\\", \\\"{x:515,y:490,t:1527873139943};\\\", \\\"{x:527,y:492,t:1527873139959};\\\", \\\"{x:541,y:493,t:1527873139975};\\\", \\\"{x:553,y:494,t:1527873139992};\\\", \\\"{x:564,y:494,t:1527873140009};\\\", \\\"{x:572,y:494,t:1527873140025};\\\", \\\"{x:580,y:494,t:1527873140043};\\\", \\\"{x:588,y:494,t:1527873140060};\\\", \\\"{x:597,y:494,t:1527873140076};\\\", \\\"{x:620,y:494,t:1527873140093};\\\", \\\"{x:639,y:494,t:1527873140110};\\\", \\\"{x:666,y:494,t:1527873140126};\\\", \\\"{x:689,y:494,t:1527873140143};\\\", \\\"{x:716,y:499,t:1527873140160};\\\", \\\"{x:744,y:501,t:1527873140177};\\\", \\\"{x:778,y:507,t:1527873140192};\\\", \\\"{x:805,y:511,t:1527873140210};\\\", \\\"{x:822,y:511,t:1527873140226};\\\", \\\"{x:837,y:511,t:1527873140243};\\\", \\\"{x:850,y:511,t:1527873140259};\\\", \\\"{x:857,y:512,t:1527873140276};\\\", \\\"{x:858,y:512,t:1527873140292};\\\", \\\"{x:859,y:512,t:1527873140309};\\\", \\\"{x:860,y:512,t:1527873140327};\\\", \\\"{x:862,y:512,t:1527873140344};\\\", \\\"{x:867,y:512,t:1527873140360};\\\", \\\"{x:872,y:512,t:1527873140377};\\\", \\\"{x:881,y:512,t:1527873140394};\\\", \\\"{x:889,y:512,t:1527873140410};\\\", \\\"{x:903,y:512,t:1527873140427};\\\", \\\"{x:918,y:513,t:1527873140443};\\\", \\\"{x:934,y:514,t:1527873140460};\\\", \\\"{x:942,y:514,t:1527873140477};\\\", \\\"{x:951,y:514,t:1527873140495};\\\", \\\"{x:954,y:514,t:1527873140510};\\\", \\\"{x:956,y:513,t:1527873140527};\\\", \\\"{x:957,y:513,t:1527873141221};\\\", \\\"{x:960,y:513,t:1527873141230};\\\", \\\"{x:965,y:513,t:1527873141245};\\\", \\\"{x:971,y:515,t:1527873141261};\\\", \\\"{x:976,y:517,t:1527873141277};\\\", \\\"{x:980,y:519,t:1527873141294};\\\", \\\"{x:988,y:520,t:1527873141311};\\\", \\\"{x:996,y:523,t:1527873141328};\\\", \\\"{x:1006,y:526,t:1527873141344};\\\", \\\"{x:1025,y:534,t:1527873141361};\\\", \\\"{x:1046,y:541,t:1527873141377};\\\", \\\"{x:1072,y:548,t:1527873141394};\\\", \\\"{x:1096,y:556,t:1527873141412};\\\", \\\"{x:1113,y:563,t:1527873141428};\\\", \\\"{x:1130,y:571,t:1527873141445};\\\", \\\"{x:1153,y:584,t:1527873141461};\\\", \\\"{x:1173,y:600,t:1527873141477};\\\", \\\"{x:1205,y:624,t:1527873141494};\\\", \\\"{x:1219,y:634,t:1527873141512};\\\", \\\"{x:1220,y:634,t:1527873141965};\\\", \\\"{x:1221,y:634,t:1527873141981};\\\", \\\"{x:1222,y:634,t:1527873141995};\\\", \\\"{x:1226,y:636,t:1527873142012};\\\", \\\"{x:1227,y:638,t:1527873142028};\\\", \\\"{x:1232,y:641,t:1527873142044};\\\", \\\"{x:1241,y:647,t:1527873142061};\\\", \\\"{x:1249,y:653,t:1527873142079};\\\", \\\"{x:1254,y:658,t:1527873142095};\\\", \\\"{x:1260,y:662,t:1527873142111};\\\", \\\"{x:1267,y:668,t:1527873142129};\\\", \\\"{x:1275,y:675,t:1527873142145};\\\", \\\"{x:1290,y:685,t:1527873142160};\\\", \\\"{x:1308,y:697,t:1527873142178};\\\", \\\"{x:1329,y:708,t:1527873142195};\\\", \\\"{x:1344,y:716,t:1527873142210};\\\", \\\"{x:1348,y:719,t:1527873142228};\\\", \\\"{x:1351,y:719,t:1527873142244};\\\", \\\"{x:1353,y:719,t:1527873142300};\\\", \\\"{x:1354,y:719,t:1527873142333};\\\", \\\"{x:1355,y:717,t:1527873142365};\\\", \\\"{x:1355,y:715,t:1527873142377};\\\", \\\"{x:1355,y:713,t:1527873142395};\\\", \\\"{x:1355,y:711,t:1527873142412};\\\", \\\"{x:1355,y:710,t:1527873142428};\\\", \\\"{x:1355,y:708,t:1527873142446};\\\", \\\"{x:1355,y:706,t:1527873142462};\\\", \\\"{x:1355,y:705,t:1527873142478};\\\", \\\"{x:1355,y:703,t:1527873142496};\\\", \\\"{x:1355,y:702,t:1527873142512};\\\", \\\"{x:1356,y:701,t:1527873142528};\\\", \\\"{x:1357,y:700,t:1527873142545};\\\", \\\"{x:1358,y:699,t:1527873142589};\\\", \\\"{x:1359,y:699,t:1527873142597};\\\", \\\"{x:1359,y:698,t:1527873142612};\\\", \\\"{x:1359,y:697,t:1527873143350};\\\", \\\"{x:1359,y:696,t:1527873146358};\\\", \\\"{x:1358,y:696,t:1527873146678};\\\", \\\"{x:1357,y:696,t:1527873146741};\\\", \\\"{x:1357,y:697,t:1527873146781};\\\", \\\"{x:1356,y:697,t:1527873147012};\\\", \\\"{x:1355,y:697,t:1527873147596};\\\", \\\"{x:1354,y:699,t:1527873147604};\\\", \\\"{x:1354,y:700,t:1527873147620};\\\", \\\"{x:1354,y:702,t:1527873147636};\\\", \\\"{x:1354,y:703,t:1527873147649};\\\", \\\"{x:1354,y:706,t:1527873147666};\\\", \\\"{x:1354,y:707,t:1527873147683};\\\", \\\"{x:1354,y:709,t:1527873147699};\\\", \\\"{x:1354,y:713,t:1527873147716};\\\", \\\"{x:1354,y:714,t:1527873147733};\\\", \\\"{x:1354,y:716,t:1527873147749};\\\", \\\"{x:1354,y:718,t:1527873147766};\\\", \\\"{x:1354,y:721,t:1527873147783};\\\", \\\"{x:1354,y:725,t:1527873147799};\\\", \\\"{x:1354,y:729,t:1527873147817};\\\", \\\"{x:1354,y:731,t:1527873147834};\\\", \\\"{x:1354,y:735,t:1527873147850};\\\", \\\"{x:1354,y:739,t:1527873147866};\\\", \\\"{x:1354,y:742,t:1527873147884};\\\", \\\"{x:1354,y:743,t:1527873147900};\\\", \\\"{x:1355,y:746,t:1527873147916};\\\", \\\"{x:1356,y:747,t:1527873147933};\\\", \\\"{x:1356,y:748,t:1527873147949};\\\", \\\"{x:1356,y:749,t:1527873147966};\\\", \\\"{x:1356,y:751,t:1527873147983};\\\", \\\"{x:1356,y:752,t:1527873147999};\\\", \\\"{x:1356,y:753,t:1527873148016};\\\", \\\"{x:1356,y:755,t:1527873148033};\\\", \\\"{x:1356,y:758,t:1527873148050};\\\", \\\"{x:1356,y:760,t:1527873148066};\\\", \\\"{x:1356,y:761,t:1527873148083};\\\", \\\"{x:1356,y:763,t:1527873148141};\\\", \\\"{x:1356,y:764,t:1527873148197};\\\", \\\"{x:1356,y:765,t:1527873148229};\\\", \\\"{x:1356,y:766,t:1527873148261};\\\", \\\"{x:1356,y:767,t:1527873148269};\\\", \\\"{x:1356,y:768,t:1527873148283};\\\", \\\"{x:1356,y:782,t:1527873148301};\\\", \\\"{x:1356,y:796,t:1527873148317};\\\", \\\"{x:1356,y:806,t:1527873148333};\\\", \\\"{x:1356,y:812,t:1527873148351};\\\", \\\"{x:1356,y:816,t:1527873148367};\\\", \\\"{x:1356,y:820,t:1527873148384};\\\", \\\"{x:1356,y:826,t:1527873148401};\\\", \\\"{x:1356,y:832,t:1527873148417};\\\", \\\"{x:1357,y:839,t:1527873148434};\\\", \\\"{x:1361,y:843,t:1527873148451};\\\", \\\"{x:1365,y:848,t:1527873148467};\\\", \\\"{x:1369,y:854,t:1527873148484};\\\", \\\"{x:1374,y:859,t:1527873148501};\\\", \\\"{x:1383,y:871,t:1527873148517};\\\", \\\"{x:1389,y:878,t:1527873148534};\\\", \\\"{x:1395,y:884,t:1527873148550};\\\", \\\"{x:1398,y:888,t:1527873148566};\\\", \\\"{x:1400,y:891,t:1527873148583};\\\", \\\"{x:1400,y:893,t:1527873148600};\\\", \\\"{x:1400,y:894,t:1527873148628};\\\", \\\"{x:1400,y:895,t:1527873148660};\\\", \\\"{x:1400,y:896,t:1527873148669};\\\", \\\"{x:1400,y:898,t:1527873148684};\\\", \\\"{x:1399,y:898,t:1527873148700};\\\", \\\"{x:1399,y:899,t:1527873148717};\\\", \\\"{x:1397,y:899,t:1527873148733};\\\", \\\"{x:1396,y:899,t:1527873148773};\\\", \\\"{x:1396,y:900,t:1527873148788};\\\", \\\"{x:1395,y:900,t:1527873148805};\\\", \\\"{x:1394,y:901,t:1527873148817};\\\", \\\"{x:1393,y:901,t:1527873148834};\\\", \\\"{x:1392,y:901,t:1527873148851};\\\", \\\"{x:1391,y:902,t:1527873148868};\\\", \\\"{x:1390,y:902,t:1527873148885};\\\", \\\"{x:1388,y:902,t:1527873148942};\\\", \\\"{x:1387,y:902,t:1527873149013};\\\", \\\"{x:1386,y:902,t:1527873149750};\\\", \\\"{x:1386,y:904,t:1527873149757};\\\", \\\"{x:1386,y:905,t:1527873149768};\\\", \\\"{x:1388,y:906,t:1527873149784};\\\", \\\"{x:1390,y:907,t:1527873149802};\\\", \\\"{x:1392,y:908,t:1527873149818};\\\", \\\"{x:1396,y:909,t:1527873149834};\\\", \\\"{x:1401,y:910,t:1527873149852};\\\", \\\"{x:1407,y:910,t:1527873149868};\\\", \\\"{x:1420,y:911,t:1527873149885};\\\", \\\"{x:1427,y:913,t:1527873149901};\\\", \\\"{x:1435,y:913,t:1527873149918};\\\", \\\"{x:1442,y:914,t:1527873149935};\\\", \\\"{x:1449,y:915,t:1527873149952};\\\", \\\"{x:1457,y:917,t:1527873149969};\\\", \\\"{x:1459,y:918,t:1527873149984};\\\", \\\"{x:1460,y:918,t:1527873150003};\\\", \\\"{x:1461,y:919,t:1527873150019};\\\", \\\"{x:1461,y:920,t:1527873150037};\\\", \\\"{x:1461,y:921,t:1527873150052};\\\", \\\"{x:1461,y:922,t:1527873150068};\\\", \\\"{x:1461,y:923,t:1527873150084};\\\", \\\"{x:1461,y:924,t:1527873150102};\\\", \\\"{x:1461,y:926,t:1527873150119};\\\", \\\"{x:1459,y:927,t:1527873150136};\\\", \\\"{x:1456,y:927,t:1527873150152};\\\", \\\"{x:1452,y:927,t:1527873150169};\\\", \\\"{x:1450,y:927,t:1527873150186};\\\", \\\"{x:1449,y:927,t:1527873150202};\\\", \\\"{x:1449,y:926,t:1527873150246};\\\", \\\"{x:1449,y:925,t:1527873150270};\\\", \\\"{x:1449,y:924,t:1527873150286};\\\", \\\"{x:1449,y:922,t:1527873150302};\\\", \\\"{x:1449,y:921,t:1527873150319};\\\", \\\"{x:1449,y:918,t:1527873150335};\\\", \\\"{x:1449,y:916,t:1527873150352};\\\", \\\"{x:1449,y:914,t:1527873150369};\\\", \\\"{x:1449,y:913,t:1527873150389};\\\", \\\"{x:1449,y:912,t:1527873150402};\\\", \\\"{x:1449,y:909,t:1527873150419};\\\", \\\"{x:1450,y:906,t:1527873150436};\\\", \\\"{x:1450,y:905,t:1527873150452};\\\", \\\"{x:1451,y:902,t:1527873150470};\\\", \\\"{x:1451,y:898,t:1527873150486};\\\", \\\"{x:1451,y:895,t:1527873150502};\\\", \\\"{x:1452,y:892,t:1527873150519};\\\", \\\"{x:1452,y:888,t:1527873150535};\\\", \\\"{x:1453,y:884,t:1527873150553};\\\", \\\"{x:1454,y:879,t:1527873150568};\\\", \\\"{x:1454,y:873,t:1527873150585};\\\", \\\"{x:1454,y:864,t:1527873150603};\\\", \\\"{x:1455,y:853,t:1527873150619};\\\", \\\"{x:1455,y:840,t:1527873150636};\\\", \\\"{x:1455,y:822,t:1527873150653};\\\", \\\"{x:1452,y:811,t:1527873150669};\\\", \\\"{x:1451,y:797,t:1527873150685};\\\", \\\"{x:1450,y:785,t:1527873150703};\\\", \\\"{x:1450,y:777,t:1527873150718};\\\", \\\"{x:1450,y:768,t:1527873150735};\\\", \\\"{x:1448,y:757,t:1527873150752};\\\", \\\"{x:1447,y:744,t:1527873150768};\\\", \\\"{x:1447,y:729,t:1527873150785};\\\", \\\"{x:1447,y:717,t:1527873150802};\\\", \\\"{x:1447,y:706,t:1527873150818};\\\", \\\"{x:1446,y:697,t:1527873150835};\\\", \\\"{x:1445,y:686,t:1527873150852};\\\", \\\"{x:1444,y:683,t:1527873150869};\\\", \\\"{x:1444,y:682,t:1527873150892};\\\", \\\"{x:1444,y:680,t:1527873150916};\\\", \\\"{x:1444,y:679,t:1527873150925};\\\", \\\"{x:1444,y:676,t:1527873150935};\\\", \\\"{x:1444,y:673,t:1527873150952};\\\", \\\"{x:1445,y:668,t:1527873150969};\\\", \\\"{x:1446,y:668,t:1527873151044};\\\", \\\"{x:1447,y:667,t:1527873151052};\\\", \\\"{x:1449,y:665,t:1527873151069};\\\", \\\"{x:1451,y:663,t:1527873151085};\\\", \\\"{x:1453,y:660,t:1527873151102};\\\", \\\"{x:1454,y:658,t:1527873151119};\\\", \\\"{x:1454,y:652,t:1527873151135};\\\", \\\"{x:1455,y:646,t:1527873151152};\\\", \\\"{x:1456,y:644,t:1527873151170};\\\", \\\"{x:1458,y:640,t:1527873151185};\\\", \\\"{x:1459,y:638,t:1527873151202};\\\", \\\"{x:1460,y:637,t:1527873151220};\\\", \\\"{x:1461,y:636,t:1527873151236};\\\", \\\"{x:1461,y:637,t:1527873151381};\\\", \\\"{x:1461,y:638,t:1527873151390};\\\", \\\"{x:1461,y:640,t:1527873151404};\\\", \\\"{x:1461,y:641,t:1527873151419};\\\", \\\"{x:1461,y:645,t:1527873151437};\\\", \\\"{x:1461,y:649,t:1527873151453};\\\", \\\"{x:1461,y:650,t:1527873151469};\\\", \\\"{x:1461,y:652,t:1527873151487};\\\", \\\"{x:1462,y:654,t:1527873151503};\\\", \\\"{x:1462,y:655,t:1527873151520};\\\", \\\"{x:1462,y:656,t:1527873151566};\\\", \\\"{x:1463,y:657,t:1527873151582};\\\", \\\"{x:1463,y:658,t:1527873151598};\\\", \\\"{x:1463,y:659,t:1527873151605};\\\", \\\"{x:1463,y:662,t:1527873151620};\\\", \\\"{x:1463,y:665,t:1527873151638};\\\", \\\"{x:1463,y:669,t:1527873151653};\\\", \\\"{x:1463,y:674,t:1527873151670};\\\", \\\"{x:1463,y:680,t:1527873151686};\\\", \\\"{x:1464,y:688,t:1527873151705};\\\", \\\"{x:1464,y:694,t:1527873151720};\\\", \\\"{x:1464,y:699,t:1527873151737};\\\", \\\"{x:1464,y:703,t:1527873151753};\\\", \\\"{x:1464,y:709,t:1527873151769};\\\", \\\"{x:1464,y:712,t:1527873151787};\\\", \\\"{x:1464,y:718,t:1527873151804};\\\", \\\"{x:1464,y:724,t:1527873151820};\\\", \\\"{x:1464,y:732,t:1527873151837};\\\", \\\"{x:1465,y:739,t:1527873151854};\\\", \\\"{x:1467,y:748,t:1527873151870};\\\", \\\"{x:1469,y:756,t:1527873151887};\\\", \\\"{x:1473,y:768,t:1527873151905};\\\", \\\"{x:1477,y:781,t:1527873151920};\\\", \\\"{x:1479,y:791,t:1527873151937};\\\", \\\"{x:1482,y:799,t:1527873151954};\\\", \\\"{x:1482,y:805,t:1527873151970};\\\", \\\"{x:1482,y:809,t:1527873151987};\\\", \\\"{x:1482,y:817,t:1527873152004};\\\", \\\"{x:1483,y:824,t:1527873152020};\\\", \\\"{x:1484,y:831,t:1527873152040};\\\", \\\"{x:1485,y:836,t:1527873152053};\\\", \\\"{x:1485,y:838,t:1527873152069};\\\", \\\"{x:1485,y:841,t:1527873152086};\\\", \\\"{x:1485,y:843,t:1527873152104};\\\", \\\"{x:1485,y:848,t:1527873152120};\\\", \\\"{x:1485,y:852,t:1527873152136};\\\", \\\"{x:1486,y:855,t:1527873152154};\\\", \\\"{x:1487,y:855,t:1527873152365};\\\", \\\"{x:1487,y:854,t:1527873152381};\\\", \\\"{x:1487,y:853,t:1527873152389};\\\", \\\"{x:1487,y:852,t:1527873152404};\\\", \\\"{x:1487,y:851,t:1527873152420};\\\", \\\"{x:1487,y:850,t:1527873152550};\\\", \\\"{x:1487,y:849,t:1527873152589};\\\", \\\"{x:1487,y:848,t:1527873152629};\\\", \\\"{x:1487,y:847,t:1527873152638};\\\", \\\"{x:1487,y:846,t:1527873152677};\\\", \\\"{x:1487,y:845,t:1527873152734};\\\", \\\"{x:1487,y:844,t:1527873152741};\\\", \\\"{x:1487,y:843,t:1527873152765};\\\", \\\"{x:1486,y:842,t:1527873152773};\\\", \\\"{x:1486,y:841,t:1527873152788};\\\", \\\"{x:1486,y:840,t:1527873152804};\\\", \\\"{x:1486,y:839,t:1527873152821};\\\", \\\"{x:1485,y:839,t:1527873153366};\\\", \\\"{x:1482,y:838,t:1527873153373};\\\", \\\"{x:1474,y:837,t:1527873153388};\\\", \\\"{x:1441,y:830,t:1527873153405};\\\", \\\"{x:1384,y:821,t:1527873153421};\\\", \\\"{x:1297,y:806,t:1527873153438};\\\", \\\"{x:1216,y:789,t:1527873153455};\\\", \\\"{x:1147,y:775,t:1527873153472};\\\", \\\"{x:1097,y:762,t:1527873153487};\\\", \\\"{x:1066,y:752,t:1527873153505};\\\", \\\"{x:1047,y:744,t:1527873153521};\\\", \\\"{x:1034,y:740,t:1527873153538};\\\", \\\"{x:1024,y:738,t:1527873153555};\\\", \\\"{x:1012,y:736,t:1527873153572};\\\", \\\"{x:1003,y:735,t:1527873153588};\\\", \\\"{x:990,y:731,t:1527873153605};\\\", \\\"{x:978,y:726,t:1527873153621};\\\", \\\"{x:965,y:724,t:1527873153638};\\\", \\\"{x:955,y:720,t:1527873153654};\\\", \\\"{x:944,y:716,t:1527873153672};\\\", \\\"{x:932,y:711,t:1527873153688};\\\", \\\"{x:918,y:705,t:1527873153705};\\\", \\\"{x:889,y:698,t:1527873153722};\\\", \\\"{x:862,y:694,t:1527873153737};\\\", \\\"{x:833,y:688,t:1527873153755};\\\", \\\"{x:805,y:680,t:1527873153772};\\\", \\\"{x:766,y:664,t:1527873153789};\\\", \\\"{x:743,y:654,t:1527873153805};\\\", \\\"{x:724,y:646,t:1527873153821};\\\", \\\"{x:711,y:638,t:1527873153839};\\\", \\\"{x:704,y:633,t:1527873153855};\\\", \\\"{x:702,y:630,t:1527873153873};\\\", \\\"{x:699,y:627,t:1527873153888};\\\", \\\"{x:697,y:624,t:1527873153904};\\\", \\\"{x:696,y:620,t:1527873153918};\\\", \\\"{x:690,y:609,t:1527873153935};\\\", \\\"{x:678,y:600,t:1527873153952};\\\", \\\"{x:668,y:598,t:1527873153969};\\\", \\\"{x:661,y:597,t:1527873153987};\\\", \\\"{x:658,y:595,t:1527873154004};\\\", \\\"{x:657,y:595,t:1527873154020};\\\", \\\"{x:656,y:595,t:1527873154037};\\\", \\\"{x:652,y:594,t:1527873154054};\\\", \\\"{x:641,y:592,t:1527873154071};\\\", \\\"{x:623,y:590,t:1527873154087};\\\", \\\"{x:604,y:589,t:1527873154105};\\\", \\\"{x:588,y:586,t:1527873154120};\\\", \\\"{x:583,y:585,t:1527873154137};\\\", \\\"{x:582,y:585,t:1527873154154};\\\", \\\"{x:582,y:583,t:1527873154293};\\\", \\\"{x:583,y:581,t:1527873154316};\\\", \\\"{x:584,y:580,t:1527873154324};\\\", \\\"{x:586,y:578,t:1527873154341};\\\", \\\"{x:589,y:575,t:1527873154355};\\\", \\\"{x:593,y:572,t:1527873154370};\\\", \\\"{x:595,y:571,t:1527873154388};\\\", \\\"{x:600,y:567,t:1527873154406};\\\", \\\"{x:601,y:566,t:1527873154421};\\\", \\\"{x:603,y:565,t:1527873154439};\\\", \\\"{x:604,y:563,t:1527873154454};\\\", \\\"{x:608,y:561,t:1527873154472};\\\", \\\"{x:613,y:559,t:1527873154488};\\\", \\\"{x:615,y:558,t:1527873154504};\\\", \\\"{x:616,y:558,t:1527873154532};\\\", \\\"{x:616,y:559,t:1527873154668};\\\", \\\"{x:616,y:560,t:1527873154676};\\\", \\\"{x:616,y:563,t:1527873154710};\\\", \\\"{x:616,y:565,t:1527873154721};\\\", \\\"{x:616,y:571,t:1527873154738};\\\", \\\"{x:615,y:573,t:1527873154754};\\\", \\\"{x:615,y:574,t:1527873155541};\\\", \\\"{x:615,y:576,t:1527873155555};\\\", \\\"{x:644,y:594,t:1527873155572};\\\", \\\"{x:693,y:613,t:1527873155588};\\\", \\\"{x:747,y:629,t:1527873155606};\\\", \\\"{x:816,y:647,t:1527873155622};\\\", \\\"{x:869,y:665,t:1527873155638};\\\", \\\"{x:931,y:681,t:1527873155655};\\\", \\\"{x:980,y:702,t:1527873155672};\\\", \\\"{x:1038,y:726,t:1527873155688};\\\", \\\"{x:1096,y:752,t:1527873155705};\\\", \\\"{x:1153,y:774,t:1527873155721};\\\", \\\"{x:1206,y:788,t:1527873155738};\\\", \\\"{x:1256,y:804,t:1527873155755};\\\", \\\"{x:1289,y:814,t:1527873155772};\\\", \\\"{x:1341,y:831,t:1527873155789};\\\", \\\"{x:1372,y:840,t:1527873155805};\\\", \\\"{x:1400,y:846,t:1527873155823};\\\", \\\"{x:1420,y:849,t:1527873155839};\\\", \\\"{x:1436,y:851,t:1527873155856};\\\", \\\"{x:1443,y:851,t:1527873155873};\\\", \\\"{x:1445,y:851,t:1527873155888};\\\", \\\"{x:1450,y:851,t:1527873155905};\\\", \\\"{x:1455,y:850,t:1527873155923};\\\", \\\"{x:1464,y:848,t:1527873155939};\\\", \\\"{x:1475,y:842,t:1527873155955};\\\", \\\"{x:1493,y:834,t:1527873155973};\\\", \\\"{x:1506,y:829,t:1527873155989};\\\", \\\"{x:1519,y:825,t:1527873156005};\\\", \\\"{x:1529,y:823,t:1527873156022};\\\", \\\"{x:1539,y:819,t:1527873156038};\\\", \\\"{x:1546,y:818,t:1527873156056};\\\", \\\"{x:1550,y:818,t:1527873156073};\\\", \\\"{x:1551,y:818,t:1527873156089};\\\", \\\"{x:1553,y:818,t:1527873156109};\\\", \\\"{x:1553,y:819,t:1527873156124};\\\", \\\"{x:1554,y:823,t:1527873156139};\\\", \\\"{x:1555,y:833,t:1527873156156};\\\", \\\"{x:1559,y:852,t:1527873156174};\\\", \\\"{x:1560,y:860,t:1527873156190};\\\", \\\"{x:1560,y:866,t:1527873156205};\\\", \\\"{x:1560,y:872,t:1527873156223};\\\", \\\"{x:1563,y:877,t:1527873156240};\\\", \\\"{x:1563,y:883,t:1527873156256};\\\", \\\"{x:1563,y:888,t:1527873156272};\\\", \\\"{x:1563,y:895,t:1527873156290};\\\", \\\"{x:1563,y:901,t:1527873156306};\\\", \\\"{x:1563,y:907,t:1527873156322};\\\", \\\"{x:1563,y:912,t:1527873156340};\\\", \\\"{x:1563,y:917,t:1527873156356};\\\", \\\"{x:1562,y:925,t:1527873156373};\\\", \\\"{x:1561,y:929,t:1527873156389};\\\", \\\"{x:1559,y:933,t:1527873156406};\\\", \\\"{x:1559,y:934,t:1527873156423};\\\", \\\"{x:1558,y:936,t:1527873156440};\\\", \\\"{x:1558,y:940,t:1527873156457};\\\", \\\"{x:1557,y:940,t:1527873156486};\\\", \\\"{x:1556,y:940,t:1527873156549};\\\", \\\"{x:1555,y:940,t:1527873156565};\\\", \\\"{x:1555,y:938,t:1527873156581};\\\", \\\"{x:1553,y:936,t:1527873156590};\\\", \\\"{x:1552,y:932,t:1527873156606};\\\", \\\"{x:1551,y:926,t:1527873156622};\\\", \\\"{x:1549,y:918,t:1527873156639};\\\", \\\"{x:1546,y:909,t:1527873156656};\\\", \\\"{x:1544,y:900,t:1527873156672};\\\", \\\"{x:1541,y:888,t:1527873156689};\\\", \\\"{x:1537,y:877,t:1527873156706};\\\", \\\"{x:1532,y:863,t:1527873156722};\\\", \\\"{x:1526,y:850,t:1527873156739};\\\", \\\"{x:1522,y:834,t:1527873156757};\\\", \\\"{x:1521,y:826,t:1527873156772};\\\", \\\"{x:1521,y:818,t:1527873156789};\\\", \\\"{x:1521,y:810,t:1527873156806};\\\", \\\"{x:1521,y:803,t:1527873156822};\\\", \\\"{x:1520,y:797,t:1527873156840};\\\", \\\"{x:1520,y:792,t:1527873156857};\\\", \\\"{x:1519,y:788,t:1527873156872};\\\", \\\"{x:1518,y:784,t:1527873156890};\\\", \\\"{x:1516,y:781,t:1527873156907};\\\", \\\"{x:1516,y:780,t:1527873156923};\\\", \\\"{x:1516,y:777,t:1527873156940};\\\", \\\"{x:1515,y:774,t:1527873156957};\\\", \\\"{x:1514,y:774,t:1527873156988};\\\", \\\"{x:1514,y:773,t:1527873157086};\\\", \\\"{x:1513,y:773,t:1527873157093};\\\", \\\"{x:1512,y:773,t:1527873157180};\\\", \\\"{x:1511,y:773,t:1527873157189};\\\", \\\"{x:1510,y:773,t:1527873157206};\\\", \\\"{x:1505,y:774,t:1527873157223};\\\", \\\"{x:1504,y:774,t:1527873157239};\\\", \\\"{x:1503,y:774,t:1527873157260};\\\", \\\"{x:1501,y:774,t:1527873157285};\\\", \\\"{x:1500,y:774,t:1527873157292};\\\", \\\"{x:1497,y:774,t:1527873157306};\\\", \\\"{x:1484,y:775,t:1527873157323};\\\", \\\"{x:1470,y:776,t:1527873157339};\\\", \\\"{x:1448,y:777,t:1527873157356};\\\", \\\"{x:1423,y:779,t:1527873157374};\\\", \\\"{x:1382,y:779,t:1527873157390};\\\", \\\"{x:1327,y:779,t:1527873157406};\\\", \\\"{x:1262,y:781,t:1527873157424};\\\", \\\"{x:1198,y:781,t:1527873157440};\\\", \\\"{x:1152,y:784,t:1527873157457};\\\", \\\"{x:1106,y:786,t:1527873157474};\\\", \\\"{x:1072,y:786,t:1527873157490};\\\", \\\"{x:1035,y:786,t:1527873157507};\\\", \\\"{x:999,y:786,t:1527873157524};\\\", \\\"{x:951,y:780,t:1527873157540};\\\", \\\"{x:871,y:769,t:1527873157556};\\\", \\\"{x:829,y:764,t:1527873157573};\\\", \\\"{x:789,y:757,t:1527873157590};\\\", \\\"{x:760,y:754,t:1527873157606};\\\", \\\"{x:737,y:751,t:1527873157623};\\\", \\\"{x:719,y:748,t:1527873157640};\\\", \\\"{x:704,y:745,t:1527873157656};\\\", \\\"{x:695,y:745,t:1527873157674};\\\", \\\"{x:688,y:745,t:1527873157691};\\\", \\\"{x:683,y:746,t:1527873157706};\\\", \\\"{x:677,y:746,t:1527873157723};\\\", \\\"{x:667,y:746,t:1527873157740};\\\", \\\"{x:659,y:746,t:1527873157756};\\\", \\\"{x:646,y:746,t:1527873157773};\\\", \\\"{x:626,y:746,t:1527873157790};\\\", \\\"{x:600,y:746,t:1527873157806};\\\", \\\"{x:571,y:746,t:1527873157824};\\\", \\\"{x:551,y:745,t:1527873157841};\\\", \\\"{x:538,y:743,t:1527873157856};\\\", \\\"{x:528,y:741,t:1527873157873};\\\", \\\"{x:524,y:740,t:1527873157890};\\\", \\\"{x:523,y:740,t:1527873157907};\\\", \\\"{x:521,y:740,t:1527873157940};\\\", \\\"{x:521,y:739,t:1527873158533};\\\", \\\"{x:526,y:736,t:1527873158541};\\\", \\\"{x:548,y:729,t:1527873158558};\\\", \\\"{x:571,y:719,t:1527873158574};\\\", \\\"{x:593,y:708,t:1527873158591};\\\", \\\"{x:614,y:694,t:1527873158608};\\\", \\\"{x:634,y:681,t:1527873158625};\\\", \\\"{x:654,y:667,t:1527873158641};\\\", \\\"{x:680,y:648,t:1527873158657};\\\", \\\"{x:699,y:631,t:1527873158674};\\\", \\\"{x:712,y:614,t:1527873158690};\\\", \\\"{x:720,y:605,t:1527873158707};\\\", \\\"{x:733,y:593,t:1527873158724};\\\", \\\"{x:747,y:580,t:1527873158740};\\\", \\\"{x:765,y:563,t:1527873158757};\\\", \\\"{x:786,y:548,t:1527873158774};\\\", \\\"{x:804,y:534,t:1527873158790};\\\", \\\"{x:816,y:525,t:1527873158807};\\\", \\\"{x:821,y:519,t:1527873158824};\\\", \\\"{x:824,y:517,t:1527873158841};\\\" ] }, { \\\"rt\\\": 12296, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 357199, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:823,y:517,t:1527873159845};\\\", \\\"{x:821,y:517,t:1527873159859};\\\", \\\"{x:738,y:520,t:1527873159953};\\\", \\\"{x:722,y:520,t:1527873159975};\\\", \\\"{x:713,y:520,t:1527873159992};\\\", \\\"{x:709,y:520,t:1527873160008};\\\", \\\"{x:705,y:518,t:1527873160025};\\\", \\\"{x:701,y:517,t:1527873160042};\\\", \\\"{x:699,y:516,t:1527873160058};\\\", \\\"{x:696,y:515,t:1527873160075};\\\", \\\"{x:683,y:514,t:1527873160092};\\\", \\\"{x:672,y:510,t:1527873160108};\\\", \\\"{x:661,y:508,t:1527873160125};\\\", \\\"{x:648,y:504,t:1527873160143};\\\", \\\"{x:632,y:503,t:1527873160158};\\\", \\\"{x:614,y:500,t:1527873160176};\\\", \\\"{x:600,y:498,t:1527873160192};\\\", \\\"{x:587,y:496,t:1527873160208};\\\", \\\"{x:582,y:494,t:1527873160225};\\\", \\\"{x:579,y:494,t:1527873160242};\\\", \\\"{x:578,y:493,t:1527873160387};\\\", \\\"{x:578,y:492,t:1527873160419};\\\", \\\"{x:578,y:491,t:1527873160443};\\\", \\\"{x:579,y:491,t:1527873160468};\\\", \\\"{x:581,y:491,t:1527873160548};\\\", \\\"{x:587,y:491,t:1527873160559};\\\", \\\"{x:606,y:491,t:1527873160575};\\\", \\\"{x:632,y:495,t:1527873160592};\\\", \\\"{x:670,y:500,t:1527873160609};\\\", \\\"{x:698,y:505,t:1527873160625};\\\", \\\"{x:757,y:513,t:1527873160643};\\\", \\\"{x:820,y:518,t:1527873160660};\\\", \\\"{x:913,y:528,t:1527873160676};\\\", \\\"{x:1057,y:551,t:1527873160693};\\\", \\\"{x:1150,y:571,t:1527873160709};\\\", \\\"{x:1227,y:591,t:1527873160726};\\\", \\\"{x:1299,y:611,t:1527873160742};\\\", \\\"{x:1344,y:632,t:1527873160759};\\\", \\\"{x:1378,y:649,t:1527873160776};\\\", \\\"{x:1411,y:667,t:1527873160793};\\\", \\\"{x:1459,y:691,t:1527873160809};\\\", \\\"{x:1495,y:712,t:1527873160825};\\\", \\\"{x:1528,y:733,t:1527873160842};\\\", \\\"{x:1547,y:743,t:1527873160859};\\\", \\\"{x:1563,y:755,t:1527873160876};\\\", \\\"{x:1585,y:777,t:1527873160892};\\\", \\\"{x:1593,y:797,t:1527873160909};\\\", \\\"{x:1595,y:808,t:1527873160925};\\\", \\\"{x:1593,y:817,t:1527873160943};\\\", \\\"{x:1589,y:829,t:1527873160960};\\\", \\\"{x:1581,y:845,t:1527873160976};\\\", \\\"{x:1572,y:857,t:1527873160992};\\\", \\\"{x:1562,y:875,t:1527873161009};\\\", \\\"{x:1557,y:886,t:1527873161026};\\\", \\\"{x:1555,y:887,t:1527873161042};\\\", \\\"{x:1554,y:888,t:1527873161060};\\\", \\\"{x:1545,y:900,t:1527873161076};\\\", \\\"{x:1544,y:901,t:1527873161093};\\\", \\\"{x:1539,y:902,t:1527873161110};\\\", \\\"{x:1530,y:909,t:1527873161126};\\\", \\\"{x:1525,y:911,t:1527873161142};\\\", \\\"{x:1521,y:912,t:1527873161160};\\\", \\\"{x:1520,y:913,t:1527873161177};\\\", \\\"{x:1519,y:914,t:1527873161196};\\\", \\\"{x:1519,y:913,t:1527873161453};\\\", \\\"{x:1518,y:913,t:1527873161477};\\\", \\\"{x:1518,y:911,t:1527873161525};\\\", \\\"{x:1518,y:910,t:1527873161533};\\\", \\\"{x:1518,y:908,t:1527873161957};\\\", \\\"{x:1517,y:906,t:1527873161965};\\\", \\\"{x:1514,y:905,t:1527873161981};\\\", \\\"{x:1509,y:903,t:1527873161994};\\\", \\\"{x:1498,y:898,t:1527873162011};\\\", \\\"{x:1486,y:893,t:1527873162027};\\\", \\\"{x:1473,y:890,t:1527873162044};\\\", \\\"{x:1440,y:881,t:1527873162061};\\\", \\\"{x:1412,y:875,t:1527873162078};\\\", \\\"{x:1380,y:870,t:1527873162094};\\\", \\\"{x:1352,y:867,t:1527873162111};\\\", \\\"{x:1322,y:861,t:1527873162127};\\\", \\\"{x:1295,y:859,t:1527873162144};\\\", \\\"{x:1274,y:856,t:1527873162161};\\\", \\\"{x:1261,y:853,t:1527873162177};\\\", \\\"{x:1253,y:853,t:1527873162194};\\\", \\\"{x:1248,y:853,t:1527873162211};\\\", \\\"{x:1241,y:853,t:1527873162227};\\\", \\\"{x:1233,y:853,t:1527873162244};\\\", \\\"{x:1213,y:848,t:1527873162261};\\\", \\\"{x:1196,y:846,t:1527873162277};\\\", \\\"{x:1176,y:843,t:1527873162294};\\\", \\\"{x:1146,y:836,t:1527873162311};\\\", \\\"{x:1100,y:823,t:1527873162327};\\\", \\\"{x:1057,y:812,t:1527873162343};\\\", \\\"{x:1005,y:800,t:1527873162360};\\\", \\\"{x:938,y:791,t:1527873162377};\\\", \\\"{x:855,y:780,t:1527873162394};\\\", \\\"{x:766,y:767,t:1527873162410};\\\", \\\"{x:705,y:752,t:1527873162428};\\\", \\\"{x:643,y:733,t:1527873162445};\\\", \\\"{x:627,y:727,t:1527873162461};\\\", \\\"{x:618,y:720,t:1527873162477};\\\", \\\"{x:614,y:716,t:1527873162494};\\\", \\\"{x:609,y:709,t:1527873162511};\\\", \\\"{x:608,y:707,t:1527873162528};\\\", \\\"{x:605,y:702,t:1527873162544};\\\", \\\"{x:601,y:691,t:1527873162561};\\\", \\\"{x:600,y:675,t:1527873162578};\\\", \\\"{x:597,y:657,t:1527873162594};\\\", \\\"{x:597,y:642,t:1527873162610};\\\", \\\"{x:597,y:633,t:1527873162629};\\\", \\\"{x:597,y:626,t:1527873162646};\\\", \\\"{x:597,y:617,t:1527873162660};\\\", \\\"{x:600,y:608,t:1527873162678};\\\", \\\"{x:603,y:599,t:1527873162695};\\\", \\\"{x:608,y:588,t:1527873162712};\\\", \\\"{x:611,y:586,t:1527873162727};\\\", \\\"{x:612,y:584,t:1527873162745};\\\", \\\"{x:613,y:582,t:1527873162760};\\\", \\\"{x:613,y:581,t:1527873162779};\\\", \\\"{x:614,y:580,t:1527873162794};\\\", \\\"{x:614,y:578,t:1527873162810};\\\", \\\"{x:617,y:574,t:1527873162827};\\\", \\\"{x:619,y:570,t:1527873162843};\\\", \\\"{x:620,y:569,t:1527873162860};\\\", \\\"{x:621,y:568,t:1527873162878};\\\", \\\"{x:622,y:566,t:1527873162894};\\\", \\\"{x:623,y:566,t:1527873162911};\\\", \\\"{x:624,y:564,t:1527873162928};\\\", \\\"{x:626,y:562,t:1527873162945};\\\", \\\"{x:630,y:560,t:1527873162960};\\\", \\\"{x:634,y:558,t:1527873162977};\\\", \\\"{x:640,y:557,t:1527873162994};\\\", \\\"{x:649,y:555,t:1527873163011};\\\", \\\"{x:665,y:555,t:1527873163028};\\\", \\\"{x:690,y:555,t:1527873163044};\\\", \\\"{x:705,y:555,t:1527873163060};\\\", \\\"{x:717,y:555,t:1527873163077};\\\", \\\"{x:726,y:554,t:1527873163095};\\\", \\\"{x:732,y:553,t:1527873163111};\\\", \\\"{x:741,y:552,t:1527873163127};\\\", \\\"{x:755,y:550,t:1527873163144};\\\", \\\"{x:768,y:548,t:1527873163161};\\\", \\\"{x:783,y:545,t:1527873163177};\\\", \\\"{x:801,y:543,t:1527873163194};\\\", \\\"{x:814,y:540,t:1527873163210};\\\", \\\"{x:822,y:539,t:1527873163227};\\\", \\\"{x:826,y:538,t:1527873163245};\\\", \\\"{x:828,y:538,t:1527873163261};\\\", \\\"{x:830,y:537,t:1527873163277};\\\", \\\"{x:832,y:535,t:1527873163295};\\\", \\\"{x:833,y:533,t:1527873163311};\\\", \\\"{x:834,y:533,t:1527873163327};\\\", \\\"{x:835,y:532,t:1527873163344};\\\", \\\"{x:836,y:531,t:1527873163361};\\\", \\\"{x:838,y:528,t:1527873163378};\\\", \\\"{x:839,y:525,t:1527873163395};\\\", \\\"{x:841,y:522,t:1527873163411};\\\", \\\"{x:841,y:517,t:1527873163429};\\\", \\\"{x:842,y:515,t:1527873163444};\\\", \\\"{x:842,y:512,t:1527873163462};\\\", \\\"{x:842,y:510,t:1527873163478};\\\", \\\"{x:842,y:509,t:1527873163494};\\\", \\\"{x:843,y:507,t:1527873163516};\\\", \\\"{x:841,y:506,t:1527873164092};\\\", \\\"{x:836,y:506,t:1527873164100};\\\", \\\"{x:831,y:507,t:1527873164112};\\\", \\\"{x:827,y:508,t:1527873164129};\\\", \\\"{x:820,y:511,t:1527873164146};\\\", \\\"{x:810,y:513,t:1527873164163};\\\", \\\"{x:789,y:516,t:1527873164179};\\\", \\\"{x:734,y:523,t:1527873164196};\\\", \\\"{x:684,y:530,t:1527873164213};\\\", \\\"{x:626,y:537,t:1527873164230};\\\", \\\"{x:571,y:542,t:1527873164246};\\\", \\\"{x:524,y:547,t:1527873164262};\\\", \\\"{x:493,y:547,t:1527873164280};\\\", \\\"{x:464,y:548,t:1527873164295};\\\", \\\"{x:437,y:548,t:1527873164312};\\\", \\\"{x:405,y:548,t:1527873164329};\\\", \\\"{x:369,y:548,t:1527873164347};\\\", \\\"{x:339,y:548,t:1527873164362};\\\", \\\"{x:314,y:549,t:1527873164379};\\\", \\\"{x:295,y:551,t:1527873164396};\\\", \\\"{x:271,y:551,t:1527873164414};\\\", \\\"{x:260,y:551,t:1527873164429};\\\", \\\"{x:246,y:552,t:1527873164446};\\\", \\\"{x:236,y:553,t:1527873164463};\\\", \\\"{x:224,y:555,t:1527873164478};\\\", \\\"{x:217,y:557,t:1527873164496};\\\", \\\"{x:207,y:557,t:1527873164513};\\\", \\\"{x:201,y:558,t:1527873164529};\\\", \\\"{x:190,y:560,t:1527873164546};\\\", \\\"{x:185,y:560,t:1527873164562};\\\", \\\"{x:182,y:561,t:1527873164578};\\\", \\\"{x:179,y:561,t:1527873164596};\\\", \\\"{x:175,y:561,t:1527873164612};\\\", \\\"{x:170,y:561,t:1527873164629};\\\", \\\"{x:168,y:561,t:1527873164646};\\\", \\\"{x:167,y:561,t:1527873164668};\\\", \\\"{x:166,y:561,t:1527873164679};\\\", \\\"{x:165,y:561,t:1527873164695};\\\", \\\"{x:164,y:561,t:1527873164713};\\\", \\\"{x:162,y:561,t:1527873164729};\\\", \\\"{x:161,y:561,t:1527873164746};\\\", \\\"{x:161,y:560,t:1527873164763};\\\", \\\"{x:159,y:557,t:1527873164779};\\\", \\\"{x:158,y:555,t:1527873164796};\\\", \\\"{x:158,y:554,t:1527873164813};\\\", \\\"{x:157,y:552,t:1527873164828};\\\", \\\"{x:154,y:549,t:1527873164845};\\\", \\\"{x:150,y:546,t:1527873164862};\\\", \\\"{x:150,y:544,t:1527873164879};\\\", \\\"{x:149,y:543,t:1527873164895};\\\", \\\"{x:148,y:543,t:1527873164912};\\\", \\\"{x:148,y:542,t:1527873165116};\\\", \\\"{x:153,y:544,t:1527873165180};\\\", \\\"{x:165,y:546,t:1527873165195};\\\", \\\"{x:182,y:549,t:1527873165213};\\\", \\\"{x:203,y:552,t:1527873165230};\\\", \\\"{x:223,y:556,t:1527873165247};\\\", \\\"{x:241,y:558,t:1527873165262};\\\", \\\"{x:263,y:562,t:1527873165279};\\\", \\\"{x:286,y:568,t:1527873165296};\\\", \\\"{x:309,y:572,t:1527873165312};\\\", \\\"{x:329,y:574,t:1527873165330};\\\", \\\"{x:344,y:579,t:1527873165346};\\\", \\\"{x:353,y:582,t:1527873165362};\\\", \\\"{x:364,y:588,t:1527873165380};\\\", \\\"{x:377,y:592,t:1527873165395};\\\", \\\"{x:380,y:592,t:1527873165412};\\\", \\\"{x:379,y:592,t:1527873165443};\\\", \\\"{x:377,y:592,t:1527873165452};\\\", \\\"{x:366,y:591,t:1527873165462};\\\", \\\"{x:348,y:587,t:1527873165479};\\\", \\\"{x:321,y:580,t:1527873165497};\\\", \\\"{x:294,y:577,t:1527873165513};\\\", \\\"{x:265,y:573,t:1527873165531};\\\", \\\"{x:239,y:569,t:1527873165547};\\\", \\\"{x:223,y:566,t:1527873165563};\\\", \\\"{x:216,y:563,t:1527873165579};\\\", \\\"{x:214,y:563,t:1527873165597};\\\", \\\"{x:211,y:562,t:1527873165615};\\\", \\\"{x:209,y:561,t:1527873165629};\\\", \\\"{x:202,y:559,t:1527873165646};\\\", \\\"{x:196,y:558,t:1527873165662};\\\", \\\"{x:195,y:557,t:1527873165680};\\\", \\\"{x:193,y:556,t:1527873165697};\\\", \\\"{x:191,y:556,t:1527873165714};\\\", \\\"{x:190,y:555,t:1527873165732};\\\", \\\"{x:189,y:554,t:1527873165764};\\\", \\\"{x:188,y:554,t:1527873165780};\\\", \\\"{x:187,y:554,t:1527873165796};\\\", \\\"{x:184,y:553,t:1527873165814};\\\", \\\"{x:180,y:552,t:1527873165830};\\\", \\\"{x:179,y:551,t:1527873165847};\\\", \\\"{x:174,y:550,t:1527873165864};\\\", \\\"{x:168,y:548,t:1527873165880};\\\", \\\"{x:164,y:547,t:1527873165897};\\\", \\\"{x:160,y:547,t:1527873165914};\\\", \\\"{x:158,y:546,t:1527873165930};\\\", \\\"{x:157,y:546,t:1527873165965};\\\", \\\"{x:156,y:546,t:1527873166012};\\\", \\\"{x:161,y:546,t:1527873166413};\\\", \\\"{x:182,y:546,t:1527873166431};\\\", \\\"{x:205,y:546,t:1527873166448};\\\", \\\"{x:234,y:548,t:1527873166464};\\\", \\\"{x:267,y:553,t:1527873166481};\\\", \\\"{x:292,y:560,t:1527873166497};\\\", \\\"{x:316,y:567,t:1527873166514};\\\", \\\"{x:352,y:577,t:1527873166531};\\\", \\\"{x:402,y:590,t:1527873166546};\\\", \\\"{x:528,y:618,t:1527873166565};\\\", \\\"{x:628,y:634,t:1527873166581};\\\", \\\"{x:731,y:647,t:1527873166597};\\\", \\\"{x:835,y:674,t:1527873166613};\\\", \\\"{x:951,y:707,t:1527873166631};\\\", \\\"{x:1048,y:735,t:1527873166648};\\\", \\\"{x:1146,y:764,t:1527873166664};\\\", \\\"{x:1220,y:794,t:1527873166682};\\\", \\\"{x:1266,y:819,t:1527873166698};\\\", \\\"{x:1293,y:838,t:1527873166714};\\\", \\\"{x:1311,y:855,t:1527873166731};\\\", \\\"{x:1326,y:875,t:1527873166749};\\\", \\\"{x:1330,y:885,t:1527873166765};\\\", \\\"{x:1335,y:897,t:1527873166781};\\\", \\\"{x:1338,y:903,t:1527873166799};\\\", \\\"{x:1344,y:911,t:1527873166814};\\\", \\\"{x:1352,y:917,t:1527873166831};\\\", \\\"{x:1359,y:922,t:1527873166849};\\\", \\\"{x:1364,y:926,t:1527873166865};\\\", \\\"{x:1365,y:926,t:1527873166881};\\\", \\\"{x:1366,y:928,t:1527873166909};\\\", \\\"{x:1368,y:931,t:1527873166924};\\\", \\\"{x:1369,y:933,t:1527873166933};\\\", \\\"{x:1371,y:937,t:1527873166948};\\\", \\\"{x:1372,y:938,t:1527873166965};\\\", \\\"{x:1372,y:935,t:1527873167149};\\\", \\\"{x:1371,y:928,t:1527873167165};\\\", \\\"{x:1369,y:916,t:1527873167181};\\\", \\\"{x:1367,y:902,t:1527873167198};\\\", \\\"{x:1363,y:886,t:1527873167216};\\\", \\\"{x:1361,y:874,t:1527873167231};\\\", \\\"{x:1358,y:862,t:1527873167249};\\\", \\\"{x:1352,y:848,t:1527873167266};\\\", \\\"{x:1348,y:837,t:1527873167282};\\\", \\\"{x:1343,y:827,t:1527873167298};\\\", \\\"{x:1339,y:817,t:1527873167315};\\\", \\\"{x:1337,y:809,t:1527873167332};\\\", \\\"{x:1332,y:792,t:1527873167349};\\\", \\\"{x:1329,y:780,t:1527873167365};\\\", \\\"{x:1327,y:770,t:1527873167382};\\\", \\\"{x:1325,y:758,t:1527873167399};\\\", \\\"{x:1323,y:747,t:1527873167415};\\\", \\\"{x:1323,y:740,t:1527873167431};\\\", \\\"{x:1322,y:739,t:1527873167449};\\\", \\\"{x:1322,y:736,t:1527873167466};\\\", \\\"{x:1322,y:735,t:1527873167509};\\\", \\\"{x:1319,y:734,t:1527873168197};\\\", \\\"{x:1303,y:737,t:1527873168205};\\\", \\\"{x:1290,y:741,t:1527873168215};\\\", \\\"{x:1262,y:744,t:1527873168232};\\\", \\\"{x:1232,y:750,t:1527873168249};\\\", \\\"{x:1204,y:751,t:1527873168265};\\\", \\\"{x:1174,y:752,t:1527873168283};\\\", \\\"{x:1139,y:755,t:1527873168299};\\\", \\\"{x:1094,y:756,t:1527873168315};\\\", \\\"{x:1055,y:756,t:1527873168333};\\\", \\\"{x:1001,y:756,t:1527873168349};\\\", \\\"{x:970,y:757,t:1527873168366};\\\", \\\"{x:939,y:757,t:1527873168383};\\\", \\\"{x:909,y:757,t:1527873168399};\\\", \\\"{x:884,y:757,t:1527873168415};\\\", \\\"{x:861,y:759,t:1527873168432};\\\", \\\"{x:842,y:759,t:1527873168449};\\\", \\\"{x:826,y:759,t:1527873168465};\\\", \\\"{x:811,y:759,t:1527873168481};\\\", \\\"{x:794,y:759,t:1527873168499};\\\", \\\"{x:768,y:759,t:1527873168516};\\\", \\\"{x:753,y:759,t:1527873168532};\\\", \\\"{x:738,y:759,t:1527873168549};\\\", \\\"{x:726,y:759,t:1527873168565};\\\", \\\"{x:712,y:759,t:1527873168582};\\\", \\\"{x:699,y:759,t:1527873168599};\\\", \\\"{x:687,y:759,t:1527873168616};\\\", \\\"{x:673,y:759,t:1527873168631};\\\", \\\"{x:661,y:759,t:1527873168649};\\\", \\\"{x:647,y:759,t:1527873168666};\\\", \\\"{x:633,y:755,t:1527873168682};\\\", \\\"{x:620,y:753,t:1527873168699};\\\", \\\"{x:607,y:749,t:1527873168717};\\\", \\\"{x:601,y:747,t:1527873168732};\\\", \\\"{x:598,y:746,t:1527873168748};\\\", \\\"{x:594,y:746,t:1527873168766};\\\", \\\"{x:585,y:742,t:1527873168782};\\\", \\\"{x:567,y:736,t:1527873168799};\\\", \\\"{x:551,y:734,t:1527873168817};\\\", \\\"{x:535,y:731,t:1527873168832};\\\", \\\"{x:515,y:731,t:1527873168849};\\\", \\\"{x:507,y:731,t:1527873168861};\\\", \\\"{x:502,y:731,t:1527873168878};\\\", \\\"{x:499,y:731,t:1527873168895};\\\", \\\"{x:498,y:731,t:1527873168912};\\\", \\\"{x:498,y:732,t:1527873169141};\\\", \\\"{x:498,y:733,t:1527873169156};\\\", \\\"{x:498,y:734,t:1527873169164};\\\", \\\"{x:498,y:735,t:1527873169178};\\\", \\\"{x:498,y:736,t:1527873169195};\\\", \\\"{x:498,y:738,t:1527873169213};\\\", \\\"{x:499,y:739,t:1527873169285};\\\", \\\"{x:500,y:740,t:1527873169315};\\\", \\\"{x:500,y:741,t:1527873169339};\\\", \\\"{x:501,y:741,t:1527873169411};\\\", \\\"{x:502,y:741,t:1527873169436};\\\", \\\"{x:503,y:741,t:1527873170806};\\\", \\\"{x:503,y:740,t:1527873170813};\\\", \\\"{x:503,y:738,t:1527873170829};\\\", \\\"{x:504,y:736,t:1527873170845};\\\", \\\"{x:504,y:735,t:1527873170860};\\\", \\\"{x:505,y:733,t:1527873170876};\\\" ] }, { \\\"rt\\\": 10743, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 369244, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:732,t:1527873173675};\\\", \\\"{x:505,y:731,t:1527873173687};\\\", \\\"{x:505,y:730,t:1527873173703};\\\", \\\"{x:505,y:729,t:1527873173721};\\\", \\\"{x:505,y:726,t:1527873173738};\\\", \\\"{x:505,y:724,t:1527873173754};\\\", \\\"{x:506,y:721,t:1527873173770};\\\", \\\"{x:507,y:715,t:1527873173788};\\\", \\\"{x:508,y:709,t:1527873173804};\\\", \\\"{x:510,y:695,t:1527873173819};\\\", \\\"{x:516,y:676,t:1527873173836};\\\", \\\"{x:522,y:662,t:1527873173853};\\\", \\\"{x:526,y:649,t:1527873173870};\\\", \\\"{x:532,y:632,t:1527873173886};\\\", \\\"{x:537,y:611,t:1527873173904};\\\", \\\"{x:542,y:599,t:1527873173920};\\\", \\\"{x:545,y:589,t:1527873173936};\\\", \\\"{x:550,y:582,t:1527873173957};\\\", \\\"{x:553,y:578,t:1527873173974};\\\", \\\"{x:557,y:572,t:1527873173990};\\\", \\\"{x:560,y:565,t:1527873174007};\\\", \\\"{x:564,y:557,t:1527873174025};\\\", \\\"{x:568,y:550,t:1527873174041};\\\", \\\"{x:571,y:545,t:1527873174057};\\\", \\\"{x:573,y:541,t:1527873174074};\\\", \\\"{x:575,y:538,t:1527873174091};\\\", \\\"{x:576,y:538,t:1527873174108};\\\", \\\"{x:577,y:536,t:1527873174124};\\\", \\\"{x:577,y:535,t:1527873174141};\\\", \\\"{x:578,y:534,t:1527873174157};\\\", \\\"{x:579,y:534,t:1527873174174};\\\", \\\"{x:579,y:533,t:1527873174192};\\\", \\\"{x:580,y:533,t:1527873174208};\\\", \\\"{x:580,y:532,t:1527873174225};\\\", \\\"{x:581,y:531,t:1527873174761};\\\", \\\"{x:595,y:534,t:1527873174776};\\\", \\\"{x:623,y:540,t:1527873174794};\\\", \\\"{x:663,y:546,t:1527873174811};\\\", \\\"{x:717,y:550,t:1527873174827};\\\", \\\"{x:785,y:554,t:1527873174846};\\\", \\\"{x:874,y:563,t:1527873174861};\\\", \\\"{x:957,y:574,t:1527873174876};\\\", \\\"{x:1029,y:585,t:1527873174892};\\\", \\\"{x:1105,y:598,t:1527873174908};\\\", \\\"{x:1167,y:609,t:1527873174925};\\\", \\\"{x:1218,y:625,t:1527873174941};\\\", \\\"{x:1259,y:643,t:1527873174958};\\\", \\\"{x:1298,y:660,t:1527873174975};\\\", \\\"{x:1327,y:676,t:1527873174992};\\\", \\\"{x:1361,y:696,t:1527873175008};\\\", \\\"{x:1381,y:705,t:1527873175026};\\\", \\\"{x:1401,y:714,t:1527873175042};\\\", \\\"{x:1431,y:726,t:1527873175058};\\\", \\\"{x:1462,y:732,t:1527873175076};\\\", \\\"{x:1484,y:740,t:1527873175091};\\\", \\\"{x:1496,y:747,t:1527873175108};\\\", \\\"{x:1500,y:750,t:1527873175126};\\\", \\\"{x:1503,y:757,t:1527873175141};\\\", \\\"{x:1503,y:763,t:1527873175158};\\\", \\\"{x:1503,y:768,t:1527873175176};\\\", \\\"{x:1500,y:772,t:1527873175191};\\\", \\\"{x:1489,y:779,t:1527873175209};\\\", \\\"{x:1472,y:785,t:1527873175225};\\\", \\\"{x:1461,y:785,t:1527873175241};\\\", \\\"{x:1453,y:787,t:1527873175259};\\\", \\\"{x:1445,y:787,t:1527873175276};\\\", \\\"{x:1434,y:785,t:1527873175292};\\\", \\\"{x:1424,y:780,t:1527873175308};\\\", \\\"{x:1414,y:774,t:1527873175326};\\\", \\\"{x:1399,y:767,t:1527873175342};\\\", \\\"{x:1386,y:759,t:1527873175359};\\\", \\\"{x:1373,y:753,t:1527873175376};\\\", \\\"{x:1362,y:749,t:1527873175393};\\\", \\\"{x:1356,y:747,t:1527873175409};\\\", \\\"{x:1352,y:746,t:1527873175426};\\\", \\\"{x:1352,y:745,t:1527873175443};\\\", \\\"{x:1349,y:743,t:1527873175459};\\\", \\\"{x:1349,y:742,t:1527873175476};\\\", \\\"{x:1349,y:741,t:1527873175493};\\\", \\\"{x:1348,y:739,t:1527873175508};\\\", \\\"{x:1348,y:737,t:1527873175553};\\\", \\\"{x:1348,y:736,t:1527873175625};\\\", \\\"{x:1348,y:735,t:1527873175649};\\\", \\\"{x:1347,y:734,t:1527873175681};\\\", \\\"{x:1347,y:733,t:1527873175697};\\\", \\\"{x:1346,y:733,t:1527873175713};\\\", \\\"{x:1345,y:733,t:1527873175729};\\\", \\\"{x:1344,y:733,t:1527873175745};\\\", \\\"{x:1343,y:733,t:1527873175761};\\\", \\\"{x:1342,y:733,t:1527873175776};\\\", \\\"{x:1338,y:733,t:1527873175793};\\\", \\\"{x:1337,y:733,t:1527873175809};\\\", \\\"{x:1336,y:733,t:1527873175833};\\\", \\\"{x:1335,y:733,t:1527873175889};\\\", \\\"{x:1334,y:733,t:1527873175897};\\\", \\\"{x:1331,y:733,t:1527873175910};\\\", \\\"{x:1327,y:733,t:1527873175926};\\\", \\\"{x:1324,y:733,t:1527873175943};\\\", \\\"{x:1322,y:733,t:1527873175960};\\\", \\\"{x:1321,y:733,t:1527873175977};\\\", \\\"{x:1320,y:733,t:1527873176105};\\\", \\\"{x:1320,y:732,t:1527873176530};\\\", \\\"{x:1322,y:732,t:1527873176632};\\\", \\\"{x:1323,y:732,t:1527873176648};\\\", \\\"{x:1325,y:732,t:1527873176659};\\\", \\\"{x:1329,y:729,t:1527873176676};\\\", \\\"{x:1331,y:726,t:1527873176692};\\\", \\\"{x:1334,y:722,t:1527873176710};\\\", \\\"{x:1335,y:721,t:1527873176727};\\\", \\\"{x:1336,y:717,t:1527873176743};\\\", \\\"{x:1336,y:711,t:1527873176760};\\\", \\\"{x:1336,y:704,t:1527873176776};\\\", \\\"{x:1336,y:703,t:1527873176793};\\\", \\\"{x:1336,y:702,t:1527873176810};\\\", \\\"{x:1336,y:701,t:1527873176841};\\\", \\\"{x:1337,y:701,t:1527873176849};\\\", \\\"{x:1338,y:701,t:1527873176860};\\\", \\\"{x:1341,y:701,t:1527873176877};\\\", \\\"{x:1343,y:702,t:1527873176894};\\\", \\\"{x:1348,y:703,t:1527873176910};\\\", \\\"{x:1353,y:709,t:1527873176927};\\\", \\\"{x:1356,y:714,t:1527873176944};\\\", \\\"{x:1357,y:720,t:1527873176961};\\\", \\\"{x:1358,y:725,t:1527873176977};\\\", \\\"{x:1358,y:728,t:1527873176994};\\\", \\\"{x:1358,y:731,t:1527873177010};\\\", \\\"{x:1358,y:732,t:1527873177027};\\\", \\\"{x:1358,y:736,t:1527873177044};\\\", \\\"{x:1356,y:742,t:1527873177060};\\\", \\\"{x:1355,y:751,t:1527873177077};\\\", \\\"{x:1355,y:756,t:1527873177094};\\\", \\\"{x:1355,y:762,t:1527873177110};\\\", \\\"{x:1355,y:767,t:1527873177127};\\\", \\\"{x:1354,y:774,t:1527873177144};\\\", \\\"{x:1352,y:779,t:1527873177161};\\\", \\\"{x:1350,y:785,t:1527873177177};\\\", \\\"{x:1345,y:791,t:1527873177194};\\\", \\\"{x:1342,y:794,t:1527873177211};\\\", \\\"{x:1337,y:795,t:1527873177227};\\\", \\\"{x:1331,y:797,t:1527873177245};\\\", \\\"{x:1318,y:798,t:1527873177262};\\\", \\\"{x:1302,y:799,t:1527873177277};\\\", \\\"{x:1280,y:799,t:1527873177294};\\\", \\\"{x:1251,y:799,t:1527873177310};\\\", \\\"{x:1221,y:798,t:1527873177327};\\\", \\\"{x:1188,y:794,t:1527873177344};\\\", \\\"{x:1133,y:785,t:1527873177361};\\\", \\\"{x:1091,y:775,t:1527873177377};\\\", \\\"{x:1044,y:763,t:1527873177394};\\\", \\\"{x:996,y:748,t:1527873177411};\\\", \\\"{x:960,y:738,t:1527873177427};\\\", \\\"{x:928,y:727,t:1527873177444};\\\", \\\"{x:903,y:716,t:1527873177461};\\\", \\\"{x:880,y:705,t:1527873177477};\\\", \\\"{x:863,y:692,t:1527873177494};\\\", \\\"{x:844,y:679,t:1527873177511};\\\", \\\"{x:823,y:667,t:1527873177527};\\\", \\\"{x:801,y:657,t:1527873177544};\\\", \\\"{x:764,y:643,t:1527873177561};\\\", \\\"{x:738,y:637,t:1527873177576};\\\", \\\"{x:713,y:635,t:1527873177593};\\\", \\\"{x:688,y:632,t:1527873177610};\\\", \\\"{x:658,y:631,t:1527873177628};\\\", \\\"{x:630,y:624,t:1527873177644};\\\", \\\"{x:608,y:614,t:1527873177660};\\\", \\\"{x:581,y:604,t:1527873177678};\\\", \\\"{x:562,y:595,t:1527873177694};\\\", \\\"{x:553,y:591,t:1527873177711};\\\", \\\"{x:547,y:588,t:1527873177727};\\\", \\\"{x:541,y:587,t:1527873177743};\\\", \\\"{x:529,y:586,t:1527873177760};\\\", \\\"{x:519,y:586,t:1527873177777};\\\", \\\"{x:516,y:586,t:1527873177793};\\\", \\\"{x:512,y:584,t:1527873177811};\\\", \\\"{x:508,y:583,t:1527873177827};\\\", \\\"{x:502,y:580,t:1527873177843};\\\", \\\"{x:499,y:577,t:1527873177860};\\\", \\\"{x:493,y:576,t:1527873177879};\\\", \\\"{x:485,y:574,t:1527873177893};\\\", \\\"{x:477,y:571,t:1527873177910};\\\", \\\"{x:471,y:568,t:1527873177927};\\\", \\\"{x:464,y:567,t:1527873177944};\\\", \\\"{x:459,y:565,t:1527873177960};\\\", \\\"{x:453,y:564,t:1527873177977};\\\", \\\"{x:447,y:563,t:1527873177994};\\\", \\\"{x:439,y:562,t:1527873178011};\\\", \\\"{x:433,y:560,t:1527873178028};\\\", \\\"{x:430,y:560,t:1527873178044};\\\", \\\"{x:421,y:560,t:1527873178061};\\\", \\\"{x:414,y:560,t:1527873178077};\\\", \\\"{x:403,y:560,t:1527873178095};\\\", \\\"{x:389,y:560,t:1527873178110};\\\", \\\"{x:379,y:560,t:1527873178127};\\\", \\\"{x:368,y:560,t:1527873178144};\\\", \\\"{x:358,y:560,t:1527873178160};\\\", \\\"{x:348,y:560,t:1527873178177};\\\", \\\"{x:331,y:563,t:1527873178195};\\\", \\\"{x:307,y:566,t:1527873178210};\\\", \\\"{x:281,y:566,t:1527873178227};\\\", \\\"{x:254,y:566,t:1527873178245};\\\", \\\"{x:233,y:566,t:1527873178260};\\\", \\\"{x:217,y:567,t:1527873178277};\\\", \\\"{x:202,y:570,t:1527873178294};\\\", \\\"{x:191,y:571,t:1527873178310};\\\", \\\"{x:185,y:572,t:1527873178327};\\\", \\\"{x:181,y:573,t:1527873178344};\\\", \\\"{x:180,y:573,t:1527873178424};\\\", \\\"{x:179,y:573,t:1527873178455};\\\", \\\"{x:177,y:573,t:1527873178472};\\\", \\\"{x:176,y:571,t:1527873178487};\\\", \\\"{x:174,y:569,t:1527873178496};\\\", \\\"{x:174,y:568,t:1527873178512};\\\", \\\"{x:171,y:563,t:1527873178527};\\\", \\\"{x:167,y:559,t:1527873178545};\\\", \\\"{x:166,y:559,t:1527873178562};\\\", \\\"{x:165,y:557,t:1527873178577};\\\", \\\"{x:164,y:554,t:1527873178594};\\\", \\\"{x:163,y:549,t:1527873178611};\\\", \\\"{x:163,y:546,t:1527873178627};\\\", \\\"{x:162,y:541,t:1527873178644};\\\", \\\"{x:162,y:539,t:1527873178661};\\\", \\\"{x:162,y:538,t:1527873178678};\\\", \\\"{x:165,y:545,t:1527873179032};\\\", \\\"{x:172,y:551,t:1527873179044};\\\", \\\"{x:184,y:564,t:1527873179061};\\\", \\\"{x:202,y:578,t:1527873179078};\\\", \\\"{x:225,y:594,t:1527873179095};\\\", \\\"{x:254,y:615,t:1527873179111};\\\", \\\"{x:297,y:641,t:1527873179129};\\\", \\\"{x:338,y:659,t:1527873179144};\\\", \\\"{x:365,y:672,t:1527873179162};\\\", \\\"{x:391,y:686,t:1527873179178};\\\", \\\"{x:411,y:694,t:1527873179195};\\\", \\\"{x:426,y:703,t:1527873179211};\\\", \\\"{x:434,y:710,t:1527873179228};\\\", \\\"{x:437,y:714,t:1527873179245};\\\", \\\"{x:437,y:717,t:1527873179261};\\\", \\\"{x:439,y:720,t:1527873179278};\\\", \\\"{x:440,y:723,t:1527873179296};\\\", \\\"{x:444,y:729,t:1527873179312};\\\", \\\"{x:447,y:732,t:1527873179328};\\\", \\\"{x:450,y:732,t:1527873179345};\\\", \\\"{x:454,y:734,t:1527873179362};\\\", \\\"{x:465,y:741,t:1527873179378};\\\", \\\"{x:487,y:753,t:1527873179396};\\\", \\\"{x:513,y:765,t:1527873179413};\\\", \\\"{x:529,y:769,t:1527873179429};\\\", \\\"{x:537,y:769,t:1527873179446};\\\", \\\"{x:539,y:768,t:1527873179520};\\\", \\\"{x:539,y:765,t:1527873179528};\\\", \\\"{x:540,y:759,t:1527873179545};\\\", \\\"{x:540,y:755,t:1527873179562};\\\", \\\"{x:540,y:753,t:1527873179579};\\\", \\\"{x:540,y:750,t:1527873179595};\\\", \\\"{x:538,y:745,t:1527873179611};\\\", \\\"{x:535,y:742,t:1527873179628};\\\", \\\"{x:532,y:739,t:1527873179646};\\\", \\\"{x:530,y:736,t:1527873179662};\\\", \\\"{x:529,y:734,t:1527873179679};\\\", \\\"{x:527,y:732,t:1527873179696};\\\" ] }, { \\\"rt\\\": 40650, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 411100, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -B -B -Z -02 PM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:731,t:1527873187480};\\\", \\\"{x:532,y:729,t:1527873187497};\\\", \\\"{x:559,y:729,t:1527873187514};\\\", \\\"{x:585,y:729,t:1527873187530};\\\", \\\"{x:614,y:730,t:1527873187547};\\\", \\\"{x:636,y:731,t:1527873187564};\\\", \\\"{x:662,y:734,t:1527873187585};\\\", \\\"{x:676,y:734,t:1527873187601};\\\", \\\"{x:690,y:736,t:1527873187618};\\\", \\\"{x:704,y:736,t:1527873187635};\\\", \\\"{x:716,y:736,t:1527873187652};\\\", \\\"{x:731,y:736,t:1527873187668};\\\", \\\"{x:752,y:736,t:1527873187685};\\\", \\\"{x:771,y:736,t:1527873187702};\\\", \\\"{x:794,y:736,t:1527873187719};\\\", \\\"{x:821,y:736,t:1527873187735};\\\", \\\"{x:871,y:736,t:1527873187752};\\\", \\\"{x:908,y:736,t:1527873187768};\\\", \\\"{x:953,y:736,t:1527873187785};\\\", \\\"{x:1000,y:736,t:1527873187803};\\\", \\\"{x:1053,y:736,t:1527873187819};\\\", \\\"{x:1112,y:736,t:1527873187835};\\\", \\\"{x:1187,y:736,t:1527873187852};\\\", \\\"{x:1243,y:736,t:1527873187869};\\\", \\\"{x:1298,y:736,t:1527873187885};\\\", \\\"{x:1338,y:736,t:1527873187903};\\\", \\\"{x:1371,y:736,t:1527873187919};\\\", \\\"{x:1396,y:736,t:1527873187936};\\\", \\\"{x:1422,y:736,t:1527873187952};\\\", \\\"{x:1428,y:736,t:1527873187969};\\\", \\\"{x:1430,y:736,t:1527873187986};\\\", \\\"{x:1429,y:737,t:1527873188176};\\\", \\\"{x:1428,y:739,t:1527873188192};\\\", \\\"{x:1427,y:741,t:1527873188203};\\\", \\\"{x:1425,y:745,t:1527873188219};\\\", \\\"{x:1424,y:747,t:1527873188236};\\\", \\\"{x:1424,y:751,t:1527873188253};\\\", \\\"{x:1422,y:757,t:1527873188269};\\\", \\\"{x:1421,y:763,t:1527873188286};\\\", \\\"{x:1421,y:769,t:1527873188303};\\\", \\\"{x:1419,y:774,t:1527873188319};\\\", \\\"{x:1417,y:781,t:1527873188336};\\\", \\\"{x:1416,y:785,t:1527873188353};\\\", \\\"{x:1414,y:791,t:1527873188370};\\\", \\\"{x:1414,y:795,t:1527873188387};\\\", \\\"{x:1413,y:799,t:1527873188404};\\\", \\\"{x:1413,y:801,t:1527873188419};\\\", \\\"{x:1413,y:805,t:1527873188436};\\\", \\\"{x:1413,y:810,t:1527873188454};\\\", \\\"{x:1415,y:816,t:1527873188470};\\\", \\\"{x:1417,y:822,t:1527873188486};\\\", \\\"{x:1419,y:830,t:1527873188504};\\\", \\\"{x:1423,y:837,t:1527873188521};\\\", \\\"{x:1426,y:840,t:1527873188536};\\\", \\\"{x:1427,y:842,t:1527873188553};\\\", \\\"{x:1430,y:846,t:1527873188570};\\\", \\\"{x:1431,y:847,t:1527873188587};\\\", \\\"{x:1433,y:852,t:1527873188604};\\\", \\\"{x:1436,y:856,t:1527873188620};\\\", \\\"{x:1436,y:857,t:1527873188637};\\\", \\\"{x:1436,y:860,t:1527873188654};\\\", \\\"{x:1436,y:864,t:1527873188671};\\\", \\\"{x:1436,y:867,t:1527873188686};\\\", \\\"{x:1436,y:871,t:1527873188703};\\\", \\\"{x:1435,y:877,t:1527873188721};\\\", \\\"{x:1435,y:885,t:1527873188737};\\\", \\\"{x:1435,y:893,t:1527873188753};\\\", \\\"{x:1435,y:899,t:1527873188771};\\\", \\\"{x:1435,y:910,t:1527873188787};\\\", \\\"{x:1435,y:920,t:1527873188803};\\\", \\\"{x:1439,y:929,t:1527873188821};\\\", \\\"{x:1443,y:937,t:1527873188837};\\\", \\\"{x:1445,y:941,t:1527873188854};\\\", \\\"{x:1446,y:944,t:1527873188870};\\\", \\\"{x:1447,y:948,t:1527873188887};\\\", \\\"{x:1447,y:952,t:1527873188904};\\\", \\\"{x:1449,y:956,t:1527873188921};\\\", \\\"{x:1449,y:957,t:1527873188961};\\\", \\\"{x:1449,y:958,t:1527873188971};\\\", \\\"{x:1449,y:959,t:1527873188987};\\\", \\\"{x:1449,y:961,t:1527873189004};\\\", \\\"{x:1449,y:962,t:1527873189106};\\\", \\\"{x:1450,y:962,t:1527873189161};\\\", \\\"{x:1450,y:961,t:1527873189176};\\\", \\\"{x:1450,y:960,t:1527873189209};\\\", \\\"{x:1452,y:958,t:1527873189221};\\\", \\\"{x:1452,y:957,t:1527873189237};\\\", \\\"{x:1452,y:955,t:1527873189255};\\\", \\\"{x:1452,y:953,t:1527873189270};\\\", \\\"{x:1452,y:952,t:1527873189306};\\\", \\\"{x:1452,y:950,t:1527873189329};\\\", \\\"{x:1453,y:949,t:1527873189345};\\\", \\\"{x:1454,y:948,t:1527873189354};\\\", \\\"{x:1455,y:945,t:1527873189371};\\\", \\\"{x:1455,y:943,t:1527873189387};\\\", \\\"{x:1455,y:942,t:1527873189405};\\\", \\\"{x:1455,y:941,t:1527873189420};\\\", \\\"{x:1455,y:937,t:1527873189438};\\\", \\\"{x:1455,y:936,t:1527873189454};\\\", \\\"{x:1455,y:934,t:1527873189470};\\\", \\\"{x:1455,y:933,t:1527873189489};\\\", \\\"{x:1455,y:932,t:1527873189504};\\\", \\\"{x:1456,y:930,t:1527873189521};\\\", \\\"{x:1456,y:929,t:1527873189538};\\\", \\\"{x:1457,y:927,t:1527873189555};\\\", \\\"{x:1457,y:926,t:1527873189577};\\\", \\\"{x:1458,y:926,t:1527873189617};\\\", \\\"{x:1458,y:925,t:1527873189640};\\\", \\\"{x:1458,y:924,t:1527873189663};\\\", \\\"{x:1459,y:924,t:1527873189672};\\\", \\\"{x:1461,y:924,t:1527873189752};\\\", \\\"{x:1462,y:924,t:1527873189776};\\\", \\\"{x:1463,y:923,t:1527873189787};\\\", \\\"{x:1464,y:923,t:1527873189804};\\\", \\\"{x:1465,y:922,t:1527873189833};\\\", \\\"{x:1465,y:921,t:1527873189856};\\\", \\\"{x:1466,y:921,t:1527873189871};\\\", \\\"{x:1467,y:920,t:1527873189889};\\\", \\\"{x:1468,y:919,t:1527873189904};\\\", \\\"{x:1468,y:918,t:1527873189921};\\\", \\\"{x:1469,y:917,t:1527873189953};\\\", \\\"{x:1470,y:917,t:1527873190081};\\\", \\\"{x:1471,y:916,t:1527873190097};\\\", \\\"{x:1471,y:915,t:1527873190105};\\\", \\\"{x:1473,y:915,t:1527873190129};\\\", \\\"{x:1474,y:915,t:1527873190138};\\\", \\\"{x:1476,y:915,t:1527873190154};\\\", \\\"{x:1477,y:915,t:1527873190172};\\\", \\\"{x:1479,y:914,t:1527873190538};\\\", \\\"{x:1480,y:914,t:1527873190555};\\\", \\\"{x:1481,y:913,t:1527873190573};\\\", \\\"{x:1482,y:912,t:1527873190589};\\\", \\\"{x:1483,y:912,t:1527873190606};\\\", \\\"{x:1484,y:912,t:1527873190623};\\\", \\\"{x:1486,y:911,t:1527873190638};\\\", \\\"{x:1487,y:909,t:1527873190655};\\\", \\\"{x:1488,y:908,t:1527873190673};\\\", \\\"{x:1490,y:907,t:1527873190689};\\\", \\\"{x:1491,y:906,t:1527873190705};\\\", \\\"{x:1492,y:904,t:1527873190723};\\\", \\\"{x:1496,y:902,t:1527873190739};\\\", \\\"{x:1499,y:901,t:1527873190756};\\\", \\\"{x:1503,y:899,t:1527873190772};\\\", \\\"{x:1508,y:899,t:1527873190789};\\\", \\\"{x:1511,y:898,t:1527873190806};\\\", \\\"{x:1513,y:897,t:1527873190823};\\\", \\\"{x:1514,y:897,t:1527873190840};\\\", \\\"{x:1516,y:897,t:1527873190856};\\\", \\\"{x:1517,y:897,t:1527873190872};\\\", \\\"{x:1522,y:896,t:1527873190888};\\\", \\\"{x:1529,y:895,t:1527873190906};\\\", \\\"{x:1535,y:893,t:1527873190922};\\\", \\\"{x:1544,y:891,t:1527873190940};\\\", \\\"{x:1548,y:889,t:1527873190955};\\\", \\\"{x:1550,y:887,t:1527873190972};\\\", \\\"{x:1551,y:887,t:1527873191017};\\\", \\\"{x:1552,y:887,t:1527873191033};\\\", \\\"{x:1554,y:886,t:1527873191041};\\\", \\\"{x:1556,y:885,t:1527873191056};\\\", \\\"{x:1558,y:885,t:1527873191072};\\\", \\\"{x:1560,y:884,t:1527873191089};\\\", \\\"{x:1562,y:883,t:1527873191105};\\\", \\\"{x:1565,y:883,t:1527873191123};\\\", \\\"{x:1567,y:883,t:1527873191139};\\\", \\\"{x:1571,y:880,t:1527873191156};\\\", \\\"{x:1576,y:880,t:1527873191172};\\\", \\\"{x:1579,y:878,t:1527873191190};\\\", \\\"{x:1581,y:878,t:1527873191206};\\\", \\\"{x:1583,y:877,t:1527873191223};\\\", \\\"{x:1583,y:876,t:1527873191239};\\\", \\\"{x:1583,y:875,t:1527873191257};\\\", \\\"{x:1583,y:874,t:1527873191280};\\\", \\\"{x:1583,y:873,t:1527873191290};\\\", \\\"{x:1583,y:872,t:1527873191307};\\\", \\\"{x:1583,y:871,t:1527873191323};\\\", \\\"{x:1581,y:867,t:1527873191340};\\\", \\\"{x:1581,y:866,t:1527873191357};\\\", \\\"{x:1580,y:865,t:1527873191372};\\\", \\\"{x:1579,y:863,t:1527873191390};\\\", \\\"{x:1578,y:861,t:1527873191407};\\\", \\\"{x:1578,y:860,t:1527873191433};\\\", \\\"{x:1578,y:859,t:1527873191441};\\\", \\\"{x:1578,y:857,t:1527873191457};\\\", \\\"{x:1578,y:854,t:1527873191473};\\\", \\\"{x:1578,y:850,t:1527873191490};\\\", \\\"{x:1578,y:848,t:1527873191507};\\\", \\\"{x:1578,y:845,t:1527873191523};\\\", \\\"{x:1577,y:841,t:1527873191540};\\\", \\\"{x:1574,y:837,t:1527873191556};\\\", \\\"{x:1569,y:829,t:1527873191573};\\\", \\\"{x:1566,y:822,t:1527873191589};\\\", \\\"{x:1562,y:817,t:1527873191607};\\\", \\\"{x:1561,y:813,t:1527873191623};\\\", \\\"{x:1561,y:812,t:1527873191640};\\\", \\\"{x:1559,y:810,t:1527873191656};\\\", \\\"{x:1559,y:809,t:1527873191673};\\\", \\\"{x:1558,y:809,t:1527873191690};\\\", \\\"{x:1558,y:808,t:1527873191713};\\\", \\\"{x:1558,y:807,t:1527873191729};\\\", \\\"{x:1558,y:806,t:1527873191740};\\\", \\\"{x:1557,y:806,t:1527873191761};\\\", \\\"{x:1557,y:804,t:1527873191774};\\\", \\\"{x:1556,y:804,t:1527873191800};\\\", \\\"{x:1555,y:803,t:1527873191809};\\\", \\\"{x:1555,y:802,t:1527873191897};\\\", \\\"{x:1555,y:801,t:1527873191913};\\\", \\\"{x:1555,y:800,t:1527873191924};\\\", \\\"{x:1554,y:798,t:1527873191941};\\\", \\\"{x:1554,y:797,t:1527873191958};\\\", \\\"{x:1554,y:796,t:1527873191974};\\\", \\\"{x:1553,y:795,t:1527873191990};\\\", \\\"{x:1553,y:794,t:1527873192049};\\\", \\\"{x:1552,y:793,t:1527873192089};\\\", \\\"{x:1552,y:792,t:1527873192145};\\\", \\\"{x:1552,y:791,t:1527873192157};\\\", \\\"{x:1552,y:789,t:1527873192185};\\\", \\\"{x:1552,y:788,t:1527873192193};\\\", \\\"{x:1552,y:787,t:1527873192216};\\\", \\\"{x:1552,y:786,t:1527873192224};\\\", \\\"{x:1552,y:785,t:1527873192240};\\\", \\\"{x:1552,y:784,t:1527873192321};\\\", \\\"{x:1551,y:782,t:1527873192337};\\\", \\\"{x:1549,y:779,t:1527873192345};\\\", \\\"{x:1547,y:778,t:1527873192357};\\\", \\\"{x:1543,y:774,t:1527873192374};\\\", \\\"{x:1539,y:772,t:1527873192391};\\\", \\\"{x:1535,y:769,t:1527873192408};\\\", \\\"{x:1531,y:769,t:1527873192423};\\\", \\\"{x:1526,y:767,t:1527873192441};\\\", \\\"{x:1523,y:766,t:1527873192458};\\\", \\\"{x:1519,y:764,t:1527873192477};\\\", \\\"{x:1516,y:763,t:1527873192490};\\\", \\\"{x:1515,y:762,t:1527873192506};\\\", \\\"{x:1512,y:761,t:1527873192524};\\\", \\\"{x:1510,y:761,t:1527873192540};\\\", \\\"{x:1506,y:761,t:1527873192557};\\\", \\\"{x:1500,y:759,t:1527873192574};\\\", \\\"{x:1498,y:759,t:1527873192590};\\\", \\\"{x:1495,y:758,t:1527873192607};\\\", \\\"{x:1491,y:758,t:1527873192623};\\\", \\\"{x:1488,y:757,t:1527873192640};\\\", \\\"{x:1486,y:755,t:1527873192657};\\\", \\\"{x:1484,y:754,t:1527873192674};\\\", \\\"{x:1483,y:754,t:1527873192690};\\\", \\\"{x:1481,y:752,t:1527873192708};\\\", \\\"{x:1480,y:752,t:1527873192725};\\\", \\\"{x:1479,y:751,t:1527873192740};\\\", \\\"{x:1478,y:750,t:1527873192757};\\\", \\\"{x:1477,y:749,t:1527873192775};\\\", \\\"{x:1476,y:748,t:1527873192801};\\\", \\\"{x:1479,y:751,t:1527873192921};\\\", \\\"{x:1480,y:754,t:1527873192929};\\\", \\\"{x:1484,y:758,t:1527873192941};\\\", \\\"{x:1488,y:762,t:1527873192957};\\\", \\\"{x:1496,y:769,t:1527873192975};\\\", \\\"{x:1505,y:779,t:1527873192991};\\\", \\\"{x:1512,y:788,t:1527873193008};\\\", \\\"{x:1520,y:800,t:1527873193025};\\\", \\\"{x:1527,y:810,t:1527873193042};\\\", \\\"{x:1531,y:816,t:1527873193057};\\\", \\\"{x:1532,y:821,t:1527873193075};\\\", \\\"{x:1532,y:822,t:1527873193092};\\\", \\\"{x:1531,y:824,t:1527873193113};\\\", \\\"{x:1530,y:825,t:1527873193128};\\\", \\\"{x:1529,y:826,t:1527873193144};\\\", \\\"{x:1529,y:828,t:1527873193157};\\\", \\\"{x:1528,y:829,t:1527873193174};\\\", \\\"{x:1527,y:830,t:1527873193191};\\\", \\\"{x:1523,y:833,t:1527873193208};\\\", \\\"{x:1520,y:836,t:1527873193223};\\\", \\\"{x:1513,y:840,t:1527873193241};\\\", \\\"{x:1507,y:845,t:1527873193258};\\\", \\\"{x:1501,y:849,t:1527873193274};\\\", \\\"{x:1496,y:853,t:1527873193291};\\\", \\\"{x:1491,y:857,t:1527873193308};\\\", \\\"{x:1486,y:860,t:1527873193324};\\\", \\\"{x:1479,y:863,t:1527873193341};\\\", \\\"{x:1475,y:865,t:1527873193358};\\\", \\\"{x:1472,y:867,t:1527873193375};\\\", \\\"{x:1469,y:868,t:1527873193391};\\\", \\\"{x:1467,y:869,t:1527873193458};\\\", \\\"{x:1463,y:871,t:1527873193476};\\\", \\\"{x:1458,y:873,t:1527873193492};\\\", \\\"{x:1449,y:875,t:1527873193509};\\\", \\\"{x:1443,y:877,t:1527873193526};\\\", \\\"{x:1438,y:878,t:1527873193542};\\\", \\\"{x:1436,y:878,t:1527873193559};\\\", \\\"{x:1431,y:879,t:1527873193576};\\\", \\\"{x:1430,y:879,t:1527873193591};\\\", \\\"{x:1429,y:879,t:1527873193608};\\\", \\\"{x:1426,y:880,t:1527873193626};\\\", \\\"{x:1422,y:880,t:1527873193641};\\\", \\\"{x:1418,y:880,t:1527873193658};\\\", \\\"{x:1414,y:880,t:1527873193675};\\\", \\\"{x:1411,y:880,t:1527873193691};\\\", \\\"{x:1408,y:880,t:1527873193708};\\\", \\\"{x:1406,y:880,t:1527873193725};\\\", \\\"{x:1405,y:880,t:1527873193741};\\\", \\\"{x:1403,y:880,t:1527873193776};\\\", \\\"{x:1402,y:880,t:1527873193832};\\\", \\\"{x:1400,y:880,t:1527873193848};\\\", \\\"{x:1399,y:879,t:1527873193864};\\\", \\\"{x:1399,y:878,t:1527873193875};\\\", \\\"{x:1398,y:877,t:1527873193893};\\\", \\\"{x:1397,y:875,t:1527873193908};\\\", \\\"{x:1397,y:873,t:1527873193925};\\\", \\\"{x:1397,y:870,t:1527873193942};\\\", \\\"{x:1397,y:866,t:1527873193958};\\\", \\\"{x:1398,y:863,t:1527873193975};\\\", \\\"{x:1398,y:855,t:1527873193993};\\\", \\\"{x:1398,y:852,t:1527873194009};\\\", \\\"{x:1398,y:849,t:1527873194026};\\\", \\\"{x:1397,y:845,t:1527873194043};\\\", \\\"{x:1395,y:840,t:1527873194059};\\\", \\\"{x:1393,y:834,t:1527873194075};\\\", \\\"{x:1391,y:828,t:1527873194092};\\\", \\\"{x:1388,y:823,t:1527873194109};\\\", \\\"{x:1387,y:821,t:1527873194126};\\\", \\\"{x:1385,y:817,t:1527873194143};\\\", \\\"{x:1384,y:817,t:1527873194160};\\\", \\\"{x:1382,y:816,t:1527873194176};\\\", \\\"{x:1378,y:812,t:1527873194192};\\\", \\\"{x:1375,y:809,t:1527873194209};\\\", \\\"{x:1373,y:807,t:1527873194226};\\\", \\\"{x:1370,y:804,t:1527873194243};\\\", \\\"{x:1368,y:801,t:1527873194259};\\\", \\\"{x:1367,y:799,t:1527873194275};\\\", \\\"{x:1364,y:793,t:1527873194293};\\\", \\\"{x:1360,y:785,t:1527873194310};\\\", \\\"{x:1358,y:780,t:1527873194326};\\\", \\\"{x:1355,y:775,t:1527873194343};\\\", \\\"{x:1353,y:773,t:1527873194360};\\\", \\\"{x:1353,y:771,t:1527873194377};\\\", \\\"{x:1351,y:767,t:1527873194393};\\\", \\\"{x:1351,y:763,t:1527873194410};\\\", \\\"{x:1350,y:759,t:1527873194425};\\\", \\\"{x:1348,y:756,t:1527873194443};\\\", \\\"{x:1348,y:755,t:1527873194459};\\\", \\\"{x:1348,y:754,t:1527873194476};\\\", \\\"{x:1348,y:753,t:1527873194492};\\\", \\\"{x:1349,y:751,t:1527873194509};\\\", \\\"{x:1354,y:750,t:1527873194527};\\\", \\\"{x:1360,y:749,t:1527873194543};\\\", \\\"{x:1367,y:748,t:1527873194559};\\\", \\\"{x:1381,y:748,t:1527873194577};\\\", \\\"{x:1394,y:748,t:1527873194593};\\\", \\\"{x:1412,y:751,t:1527873194610};\\\", \\\"{x:1431,y:757,t:1527873194626};\\\", \\\"{x:1449,y:762,t:1527873194642};\\\", \\\"{x:1465,y:767,t:1527873194660};\\\", \\\"{x:1481,y:776,t:1527873194677};\\\", \\\"{x:1498,y:785,t:1527873194693};\\\", \\\"{x:1513,y:794,t:1527873194710};\\\", \\\"{x:1527,y:803,t:1527873194727};\\\", \\\"{x:1544,y:809,t:1527873194743};\\\", \\\"{x:1562,y:813,t:1527873194760};\\\", \\\"{x:1588,y:816,t:1527873194776};\\\", \\\"{x:1609,y:820,t:1527873194793};\\\", \\\"{x:1627,y:822,t:1527873194810};\\\", \\\"{x:1647,y:825,t:1527873194827};\\\", \\\"{x:1668,y:831,t:1527873194843};\\\", \\\"{x:1686,y:835,t:1527873194859};\\\", \\\"{x:1700,y:837,t:1527873194876};\\\", \\\"{x:1709,y:838,t:1527873194893};\\\", \\\"{x:1712,y:839,t:1527873194909};\\\", \\\"{x:1716,y:840,t:1527873194926};\\\", \\\"{x:1718,y:841,t:1527873194943};\\\", \\\"{x:1720,y:842,t:1527873194959};\\\", \\\"{x:1723,y:842,t:1527873194975};\\\", \\\"{x:1725,y:843,t:1527873194993};\\\", \\\"{x:1725,y:844,t:1527873195072};\\\", \\\"{x:1721,y:844,t:1527873203033};\\\", \\\"{x:1714,y:842,t:1527873203041};\\\", \\\"{x:1708,y:841,t:1527873203052};\\\", \\\"{x:1690,y:834,t:1527873203068};\\\", \\\"{x:1647,y:822,t:1527873203085};\\\", \\\"{x:1626,y:815,t:1527873203102};\\\", \\\"{x:1621,y:813,t:1527873203118};\\\", \\\"{x:1621,y:812,t:1527873203167};\\\", \\\"{x:1621,y:811,t:1527873203312};\\\", \\\"{x:1621,y:809,t:1527873203328};\\\", \\\"{x:1620,y:805,t:1527873203336};\\\", \\\"{x:1621,y:795,t:1527873203352};\\\", \\\"{x:1623,y:793,t:1527873203368};\\\", \\\"{x:1628,y:781,t:1527873203385};\\\", \\\"{x:1631,y:771,t:1527873203401};\\\", \\\"{x:1634,y:764,t:1527873203419};\\\", \\\"{x:1634,y:759,t:1527873203435};\\\", \\\"{x:1634,y:752,t:1527873203452};\\\", \\\"{x:1634,y:749,t:1527873203469};\\\", \\\"{x:1634,y:745,t:1527873203486};\\\", \\\"{x:1634,y:744,t:1527873203502};\\\", \\\"{x:1633,y:742,t:1527873203520};\\\", \\\"{x:1632,y:741,t:1527873203551};\\\", \\\"{x:1631,y:741,t:1527873203633};\\\", \\\"{x:1631,y:744,t:1527873203649};\\\", \\\"{x:1631,y:746,t:1527873203656};\\\", \\\"{x:1631,y:749,t:1527873203669};\\\", \\\"{x:1631,y:759,t:1527873203687};\\\", \\\"{x:1633,y:768,t:1527873203702};\\\", \\\"{x:1636,y:781,t:1527873203719};\\\", \\\"{x:1638,y:800,t:1527873203736};\\\", \\\"{x:1639,y:810,t:1527873203752};\\\", \\\"{x:1642,y:818,t:1527873203769};\\\", \\\"{x:1645,y:827,t:1527873203786};\\\", \\\"{x:1647,y:833,t:1527873203802};\\\", \\\"{x:1647,y:841,t:1527873203819};\\\", \\\"{x:1647,y:850,t:1527873203836};\\\", \\\"{x:1645,y:861,t:1527873203852};\\\", \\\"{x:1645,y:869,t:1527873203868};\\\", \\\"{x:1645,y:878,t:1527873203885};\\\", \\\"{x:1645,y:884,t:1527873203902};\\\", \\\"{x:1645,y:896,t:1527873203918};\\\", \\\"{x:1641,y:904,t:1527873203935};\\\", \\\"{x:1639,y:906,t:1527873203953};\\\", \\\"{x:1639,y:908,t:1527873203968};\\\", \\\"{x:1637,y:909,t:1527873203985};\\\", \\\"{x:1635,y:910,t:1527873204003};\\\", \\\"{x:1634,y:912,t:1527873204019};\\\", \\\"{x:1630,y:913,t:1527873204036};\\\", \\\"{x:1627,y:915,t:1527873204052};\\\", \\\"{x:1625,y:916,t:1527873204069};\\\", \\\"{x:1623,y:919,t:1527873204086};\\\", \\\"{x:1621,y:920,t:1527873204103};\\\", \\\"{x:1621,y:921,t:1527873204119};\\\", \\\"{x:1619,y:925,t:1527873204136};\\\", \\\"{x:1619,y:926,t:1527873204153};\\\", \\\"{x:1616,y:930,t:1527873204170};\\\", \\\"{x:1616,y:932,t:1527873204186};\\\", \\\"{x:1614,y:935,t:1527873204203};\\\", \\\"{x:1613,y:937,t:1527873204220};\\\", \\\"{x:1613,y:938,t:1527873204236};\\\", \\\"{x:1613,y:939,t:1527873204253};\\\", \\\"{x:1613,y:941,t:1527873204270};\\\", \\\"{x:1612,y:942,t:1527873204287};\\\", \\\"{x:1611,y:942,t:1527873204303};\\\", \\\"{x:1610,y:938,t:1527873204433};\\\", \\\"{x:1610,y:935,t:1527873204441};\\\", \\\"{x:1609,y:933,t:1527873204452};\\\", \\\"{x:1608,y:927,t:1527873204470};\\\", \\\"{x:1607,y:918,t:1527873204486};\\\", \\\"{x:1605,y:907,t:1527873204503};\\\", \\\"{x:1603,y:889,t:1527873204520};\\\", \\\"{x:1602,y:867,t:1527873204536};\\\", \\\"{x:1601,y:847,t:1527873204553};\\\", \\\"{x:1601,y:837,t:1527873204569};\\\", \\\"{x:1602,y:829,t:1527873204586};\\\", \\\"{x:1602,y:825,t:1527873204602};\\\", \\\"{x:1602,y:819,t:1527873204620};\\\", \\\"{x:1603,y:812,t:1527873204637};\\\", \\\"{x:1604,y:807,t:1527873204653};\\\", \\\"{x:1606,y:799,t:1527873204670};\\\", \\\"{x:1607,y:793,t:1527873204686};\\\", \\\"{x:1608,y:789,t:1527873204702};\\\", \\\"{x:1609,y:785,t:1527873204721};\\\", \\\"{x:1610,y:782,t:1527873204736};\\\", \\\"{x:1610,y:778,t:1527873204753};\\\", \\\"{x:1611,y:772,t:1527873204770};\\\", \\\"{x:1612,y:762,t:1527873204787};\\\", \\\"{x:1615,y:755,t:1527873204804};\\\", \\\"{x:1615,y:751,t:1527873204820};\\\", \\\"{x:1615,y:747,t:1527873204836};\\\", \\\"{x:1615,y:742,t:1527873204853};\\\", \\\"{x:1615,y:737,t:1527873204869};\\\", \\\"{x:1615,y:732,t:1527873204887};\\\", \\\"{x:1618,y:726,t:1527873204903};\\\", \\\"{x:1618,y:722,t:1527873204919};\\\", \\\"{x:1618,y:719,t:1527873204937};\\\", \\\"{x:1618,y:717,t:1527873204953};\\\", \\\"{x:1618,y:716,t:1527873204969};\\\", \\\"{x:1619,y:715,t:1527873204986};\\\", \\\"{x:1619,y:714,t:1527873205003};\\\", \\\"{x:1620,y:713,t:1527873205020};\\\", \\\"{x:1620,y:710,t:1527873205036};\\\", \\\"{x:1621,y:708,t:1527873205053};\\\", \\\"{x:1621,y:707,t:1527873205069};\\\", \\\"{x:1621,y:706,t:1527873205159};\\\", \\\"{x:1621,y:705,t:1527873205200};\\\", \\\"{x:1621,y:704,t:1527873205216};\\\", \\\"{x:1621,y:703,t:1527873205255};\\\", \\\"{x:1621,y:702,t:1527873206313};\\\", \\\"{x:1621,y:701,t:1527873206344};\\\", \\\"{x:1621,y:700,t:1527873206360};\\\", \\\"{x:1621,y:699,t:1527873206417};\\\", \\\"{x:1621,y:697,t:1527873206433};\\\", \\\"{x:1620,y:696,t:1527873206465};\\\", \\\"{x:1620,y:695,t:1527873206537};\\\", \\\"{x:1619,y:695,t:1527873206568};\\\", \\\"{x:1619,y:696,t:1527873207143};\\\", \\\"{x:1619,y:699,t:1527873207155};\\\", \\\"{x:1619,y:704,t:1527873207172};\\\", \\\"{x:1619,y:707,t:1527873207188};\\\", \\\"{x:1619,y:709,t:1527873207206};\\\", \\\"{x:1619,y:711,t:1527873207222};\\\", \\\"{x:1619,y:713,t:1527873207239};\\\", \\\"{x:1619,y:716,t:1527873207255};\\\", \\\"{x:1619,y:721,t:1527873207273};\\\", \\\"{x:1619,y:728,t:1527873207289};\\\", \\\"{x:1619,y:734,t:1527873207305};\\\", \\\"{x:1618,y:741,t:1527873207323};\\\", \\\"{x:1617,y:749,t:1527873207338};\\\", \\\"{x:1615,y:758,t:1527873207356};\\\", \\\"{x:1610,y:770,t:1527873207373};\\\", \\\"{x:1602,y:782,t:1527873207388};\\\", \\\"{x:1594,y:795,t:1527873207406};\\\", \\\"{x:1588,y:799,t:1527873207423};\\\", \\\"{x:1582,y:802,t:1527873207439};\\\", \\\"{x:1579,y:802,t:1527873207457};\\\", \\\"{x:1578,y:803,t:1527873207480};\\\", \\\"{x:1576,y:803,t:1527873207490};\\\", \\\"{x:1574,y:803,t:1527873207506};\\\", \\\"{x:1572,y:803,t:1527873207523};\\\", \\\"{x:1569,y:803,t:1527873207540};\\\", \\\"{x:1566,y:803,t:1527873207556};\\\", \\\"{x:1560,y:802,t:1527873207573};\\\", \\\"{x:1546,y:795,t:1527873207590};\\\", \\\"{x:1536,y:790,t:1527873207606};\\\", \\\"{x:1532,y:787,t:1527873207622};\\\", \\\"{x:1527,y:783,t:1527873207639};\\\", \\\"{x:1524,y:782,t:1527873207656};\\\", \\\"{x:1523,y:780,t:1527873207695};\\\", \\\"{x:1522,y:780,t:1527873207712};\\\", \\\"{x:1522,y:779,t:1527873207743};\\\", \\\"{x:1522,y:778,t:1527873207800};\\\", \\\"{x:1521,y:777,t:1527873207808};\\\", \\\"{x:1520,y:775,t:1527873207831};\\\", \\\"{x:1521,y:775,t:1527873207953};\\\", \\\"{x:1524,y:779,t:1527873207961};\\\", \\\"{x:1527,y:782,t:1527873207974};\\\", \\\"{x:1537,y:790,t:1527873207990};\\\", \\\"{x:1545,y:798,t:1527873208007};\\\", \\\"{x:1551,y:803,t:1527873208023};\\\", \\\"{x:1561,y:813,t:1527873208040};\\\", \\\"{x:1569,y:821,t:1527873208057};\\\", \\\"{x:1583,y:835,t:1527873208073};\\\", \\\"{x:1598,y:847,t:1527873208090};\\\", \\\"{x:1612,y:859,t:1527873208107};\\\", \\\"{x:1628,y:870,t:1527873208123};\\\", \\\"{x:1640,y:877,t:1527873208140};\\\", \\\"{x:1647,y:881,t:1527873208157};\\\", \\\"{x:1650,y:886,t:1527873208173};\\\", \\\"{x:1652,y:889,t:1527873208190};\\\", \\\"{x:1652,y:892,t:1527873208207};\\\", \\\"{x:1652,y:895,t:1527873208224};\\\", \\\"{x:1652,y:896,t:1527873208248};\\\", \\\"{x:1652,y:898,t:1527873208273};\\\", \\\"{x:1652,y:900,t:1527873208288};\\\", \\\"{x:1651,y:902,t:1527873208305};\\\", \\\"{x:1651,y:903,t:1527873208320};\\\", \\\"{x:1650,y:905,t:1527873208329};\\\", \\\"{x:1650,y:909,t:1527873208340};\\\", \\\"{x:1649,y:917,t:1527873208357};\\\", \\\"{x:1647,y:922,t:1527873208374};\\\", \\\"{x:1646,y:926,t:1527873208391};\\\", \\\"{x:1646,y:927,t:1527873208408};\\\", \\\"{x:1644,y:930,t:1527873208424};\\\", \\\"{x:1643,y:933,t:1527873208440};\\\", \\\"{x:1642,y:936,t:1527873208457};\\\", \\\"{x:1640,y:939,t:1527873208474};\\\", \\\"{x:1640,y:940,t:1527873208491};\\\", \\\"{x:1639,y:942,t:1527873208507};\\\", \\\"{x:1637,y:943,t:1527873208536};\\\", \\\"{x:1637,y:944,t:1527873208544};\\\", \\\"{x:1635,y:945,t:1527873208557};\\\", \\\"{x:1630,y:950,t:1527873208575};\\\", \\\"{x:1628,y:952,t:1527873208591};\\\", \\\"{x:1625,y:955,t:1527873208607};\\\", \\\"{x:1622,y:957,t:1527873208624};\\\", \\\"{x:1621,y:958,t:1527873208641};\\\", \\\"{x:1617,y:960,t:1527873208657};\\\", \\\"{x:1613,y:961,t:1527873208675};\\\", \\\"{x:1606,y:963,t:1527873208692};\\\", \\\"{x:1600,y:963,t:1527873208707};\\\", \\\"{x:1592,y:964,t:1527873208725};\\\", \\\"{x:1585,y:964,t:1527873208741};\\\", \\\"{x:1574,y:964,t:1527873208758};\\\", \\\"{x:1558,y:964,t:1527873208774};\\\", \\\"{x:1537,y:964,t:1527873208791};\\\", \\\"{x:1522,y:964,t:1527873208808};\\\", \\\"{x:1506,y:963,t:1527873208824};\\\", \\\"{x:1502,y:962,t:1527873208842};\\\", \\\"{x:1499,y:961,t:1527873208859};\\\", \\\"{x:1499,y:960,t:1527873208874};\\\", \\\"{x:1498,y:960,t:1527873208892};\\\", \\\"{x:1497,y:960,t:1527873208909};\\\", \\\"{x:1495,y:960,t:1527873208924};\\\", \\\"{x:1494,y:960,t:1527873208941};\\\", \\\"{x:1492,y:960,t:1527873208958};\\\", \\\"{x:1491,y:961,t:1527873208974};\\\", \\\"{x:1491,y:963,t:1527873208991};\\\", \\\"{x:1491,y:968,t:1527873209009};\\\", \\\"{x:1491,y:970,t:1527873209024};\\\", \\\"{x:1491,y:971,t:1527873209041};\\\", \\\"{x:1491,y:972,t:1527873209081};\\\", \\\"{x:1491,y:973,t:1527873209104};\\\", \\\"{x:1492,y:973,t:1527873209169};\\\", \\\"{x:1493,y:973,t:1527873209184};\\\", \\\"{x:1494,y:973,t:1527873209192};\\\", \\\"{x:1496,y:973,t:1527873209208};\\\", \\\"{x:1498,y:972,t:1527873209224};\\\", \\\"{x:1498,y:971,t:1527873209242};\\\", \\\"{x:1499,y:968,t:1527873209258};\\\", \\\"{x:1501,y:964,t:1527873209275};\\\", \\\"{x:1504,y:961,t:1527873209291};\\\", \\\"{x:1505,y:960,t:1527873209307};\\\", \\\"{x:1505,y:959,t:1527873209324};\\\", \\\"{x:1505,y:956,t:1527873209340};\\\", \\\"{x:1506,y:954,t:1527873209358};\\\", \\\"{x:1507,y:953,t:1527873209374};\\\", \\\"{x:1508,y:952,t:1527873209390};\\\", \\\"{x:1511,y:953,t:1527873209553};\\\", \\\"{x:1511,y:954,t:1527873209560};\\\", \\\"{x:1512,y:956,t:1527873209577};\\\", \\\"{x:1512,y:957,t:1527873209592};\\\", \\\"{x:1512,y:959,t:1527873209608};\\\", \\\"{x:1512,y:960,t:1527873209625};\\\", \\\"{x:1512,y:961,t:1527873209647};\\\", \\\"{x:1512,y:962,t:1527873209857};\\\", \\\"{x:1512,y:963,t:1527873209864};\\\", \\\"{x:1512,y:964,t:1527873209879};\\\", \\\"{x:1512,y:965,t:1527873209892};\\\", \\\"{x:1514,y:966,t:1527873209909};\\\", \\\"{x:1515,y:968,t:1527873209925};\\\", \\\"{x:1515,y:969,t:1527873209942};\\\", \\\"{x:1514,y:968,t:1527873210072};\\\", \\\"{x:1514,y:967,t:1527873210088};\\\", \\\"{x:1514,y:965,t:1527873210184};\\\", \\\"{x:1514,y:964,t:1527873210225};\\\", \\\"{x:1514,y:963,t:1527873210248};\\\", \\\"{x:1513,y:963,t:1527873211105};\\\", \\\"{x:1511,y:963,t:1527873211112};\\\", \\\"{x:1507,y:963,t:1527873211127};\\\", \\\"{x:1494,y:964,t:1527873211143};\\\", \\\"{x:1479,y:964,t:1527873211161};\\\", \\\"{x:1475,y:964,t:1527873211177};\\\", \\\"{x:1473,y:964,t:1527873211194};\\\", \\\"{x:1472,y:964,t:1527873211249};\\\", \\\"{x:1470,y:965,t:1527873211265};\\\", \\\"{x:1469,y:965,t:1527873211277};\\\", \\\"{x:1468,y:966,t:1527873211304};\\\", \\\"{x:1469,y:966,t:1527873211472};\\\", \\\"{x:1469,y:965,t:1527873211496};\\\", \\\"{x:1469,y:964,t:1527873211512};\\\", \\\"{x:1469,y:963,t:1527873211528};\\\", \\\"{x:1469,y:960,t:1527873211543};\\\", \\\"{x:1469,y:957,t:1527873211560};\\\", \\\"{x:1470,y:954,t:1527873211576};\\\", \\\"{x:1470,y:952,t:1527873211594};\\\", \\\"{x:1471,y:949,t:1527873211610};\\\", \\\"{x:1471,y:947,t:1527873211627};\\\", \\\"{x:1471,y:943,t:1527873211644};\\\", \\\"{x:1471,y:940,t:1527873211660};\\\", \\\"{x:1471,y:938,t:1527873211676};\\\", \\\"{x:1471,y:937,t:1527873211694};\\\", \\\"{x:1471,y:935,t:1527873211710};\\\", \\\"{x:1471,y:933,t:1527873211727};\\\", \\\"{x:1472,y:931,t:1527873211744};\\\", \\\"{x:1472,y:930,t:1527873211760};\\\", \\\"{x:1472,y:929,t:1527873211777};\\\", \\\"{x:1472,y:928,t:1527873211801};\\\", \\\"{x:1473,y:926,t:1527873211816};\\\", \\\"{x:1473,y:925,t:1527873211841};\\\", \\\"{x:1473,y:924,t:1527873211856};\\\", \\\"{x:1474,y:924,t:1527873211888};\\\", \\\"{x:1475,y:924,t:1527873211896};\\\", \\\"{x:1477,y:923,t:1527873211911};\\\", \\\"{x:1478,y:922,t:1527873211928};\\\", \\\"{x:1491,y:920,t:1527873211944};\\\", \\\"{x:1500,y:916,t:1527873211962};\\\", \\\"{x:1503,y:916,t:1527873211978};\\\", \\\"{x:1503,y:915,t:1527873211994};\\\", \\\"{x:1502,y:915,t:1527873212265};\\\", \\\"{x:1501,y:915,t:1527873212281};\\\", \\\"{x:1499,y:914,t:1527873212304};\\\", \\\"{x:1498,y:914,t:1527873212313};\\\", \\\"{x:1495,y:912,t:1527873212329};\\\", \\\"{x:1491,y:909,t:1527873212344};\\\", \\\"{x:1487,y:907,t:1527873212362};\\\", \\\"{x:1486,y:906,t:1527873212378};\\\", \\\"{x:1483,y:904,t:1527873212395};\\\", \\\"{x:1479,y:902,t:1527873212411};\\\", \\\"{x:1467,y:898,t:1527873212429};\\\", \\\"{x:1436,y:888,t:1527873212445};\\\", \\\"{x:1373,y:871,t:1527873212461};\\\", \\\"{x:1299,y:856,t:1527873212478};\\\", \\\"{x:1234,y:843,t:1527873212494};\\\", \\\"{x:1161,y:830,t:1527873212511};\\\", \\\"{x:1056,y:814,t:1527873212527};\\\", \\\"{x:986,y:804,t:1527873212545};\\\", \\\"{x:931,y:796,t:1527873212560};\\\", \\\"{x:889,y:784,t:1527873212578};\\\", \\\"{x:872,y:779,t:1527873212594};\\\", \\\"{x:865,y:775,t:1527873212610};\\\", \\\"{x:862,y:773,t:1527873212628};\\\", \\\"{x:857,y:770,t:1527873212645};\\\", \\\"{x:847,y:765,t:1527873212661};\\\", \\\"{x:838,y:756,t:1527873212678};\\\", \\\"{x:827,y:745,t:1527873212695};\\\", \\\"{x:820,y:737,t:1527873212711};\\\", \\\"{x:809,y:721,t:1527873212727};\\\", \\\"{x:797,y:710,t:1527873212745};\\\", \\\"{x:784,y:696,t:1527873212761};\\\", \\\"{x:775,y:686,t:1527873212778};\\\", \\\"{x:768,y:677,t:1527873212795};\\\", \\\"{x:760,y:668,t:1527873212812};\\\", \\\"{x:754,y:661,t:1527873212829};\\\", \\\"{x:749,y:657,t:1527873212845};\\\", \\\"{x:746,y:654,t:1527873212862};\\\", \\\"{x:744,y:653,t:1527873212878};\\\", \\\"{x:739,y:649,t:1527873212895};\\\", \\\"{x:728,y:642,t:1527873212911};\\\", \\\"{x:718,y:638,t:1527873212927};\\\", \\\"{x:712,y:636,t:1527873212945};\\\", \\\"{x:706,y:634,t:1527873212962};\\\", \\\"{x:703,y:633,t:1527873212978};\\\", \\\"{x:699,y:631,t:1527873212997};\\\", \\\"{x:694,y:628,t:1527873213011};\\\", \\\"{x:681,y:620,t:1527873213027};\\\", \\\"{x:671,y:616,t:1527873213039};\\\", \\\"{x:653,y:613,t:1527873213056};\\\", \\\"{x:651,y:613,t:1527873213071};\\\", \\\"{x:648,y:612,t:1527873213089};\\\", \\\"{x:648,y:611,t:1527873213105};\\\", \\\"{x:646,y:609,t:1527873213122};\\\", \\\"{x:641,y:606,t:1527873213139};\\\", \\\"{x:637,y:604,t:1527873213155};\\\", \\\"{x:636,y:603,t:1527873213172};\\\", \\\"{x:635,y:603,t:1527873213188};\\\", \\\"{x:633,y:601,t:1527873213206};\\\", \\\"{x:627,y:596,t:1527873213225};\\\", \\\"{x:622,y:593,t:1527873213240};\\\", \\\"{x:617,y:589,t:1527873213255};\\\", \\\"{x:615,y:588,t:1527873213271};\\\", \\\"{x:613,y:585,t:1527873213289};\\\", \\\"{x:612,y:585,t:1527873213305};\\\", \\\"{x:609,y:583,t:1527873213321};\\\", \\\"{x:609,y:582,t:1527873213339};\\\", \\\"{x:608,y:581,t:1527873213356};\\\", \\\"{x:607,y:580,t:1527873213383};\\\", \\\"{x:606,y:579,t:1527873213392};\\\", \\\"{x:606,y:578,t:1527873213415};\\\", \\\"{x:605,y:578,t:1527873213480};\\\", \\\"{x:605,y:577,t:1527873213496};\\\", \\\"{x:604,y:577,t:1527873213506};\\\", \\\"{x:603,y:576,t:1527873213523};\\\", \\\"{x:602,y:576,t:1527873214023};\\\", \\\"{x:603,y:578,t:1527873214039};\\\", \\\"{x:615,y:589,t:1527873214055};\\\", \\\"{x:627,y:596,t:1527873214073};\\\", \\\"{x:647,y:608,t:1527873214090};\\\", \\\"{x:684,y:621,t:1527873214106};\\\", \\\"{x:735,y:638,t:1527873214123};\\\", \\\"{x:807,y:660,t:1527873214139};\\\", \\\"{x:887,y:681,t:1527873214156};\\\", \\\"{x:968,y:703,t:1527873214173};\\\", \\\"{x:1051,y:728,t:1527873214190};\\\", \\\"{x:1126,y:750,t:1527873214206};\\\", \\\"{x:1195,y:777,t:1527873214223};\\\", \\\"{x:1278,y:810,t:1527873214239};\\\", \\\"{x:1331,y:833,t:1527873214256};\\\", \\\"{x:1366,y:848,t:1527873214273};\\\", \\\"{x:1392,y:866,t:1527873214290};\\\", \\\"{x:1409,y:876,t:1527873214306};\\\", \\\"{x:1421,y:883,t:1527873214322};\\\", \\\"{x:1432,y:891,t:1527873214340};\\\", \\\"{x:1440,y:896,t:1527873214357};\\\", \\\"{x:1450,y:901,t:1527873214373};\\\", \\\"{x:1458,y:906,t:1527873214390};\\\", \\\"{x:1463,y:908,t:1527873214407};\\\", \\\"{x:1466,y:909,t:1527873214423};\\\", \\\"{x:1473,y:909,t:1527873214440};\\\", \\\"{x:1481,y:909,t:1527873214457};\\\", \\\"{x:1487,y:909,t:1527873214474};\\\", \\\"{x:1489,y:907,t:1527873214491};\\\", \\\"{x:1490,y:904,t:1527873214507};\\\", \\\"{x:1490,y:901,t:1527873214524};\\\", \\\"{x:1490,y:895,t:1527873214541};\\\", \\\"{x:1492,y:890,t:1527873214557};\\\", \\\"{x:1494,y:880,t:1527873214573};\\\", \\\"{x:1496,y:874,t:1527873214591};\\\", \\\"{x:1497,y:872,t:1527873214607};\\\", \\\"{x:1497,y:870,t:1527873214624};\\\", \\\"{x:1498,y:869,t:1527873214640};\\\", \\\"{x:1498,y:867,t:1527873214657};\\\", \\\"{x:1500,y:865,t:1527873214674};\\\", \\\"{x:1500,y:862,t:1527873214691};\\\", \\\"{x:1500,y:859,t:1527873214708};\\\", \\\"{x:1501,y:857,t:1527873214724};\\\", \\\"{x:1502,y:855,t:1527873214740};\\\", \\\"{x:1503,y:854,t:1527873214758};\\\", \\\"{x:1503,y:853,t:1527873214817};\\\", \\\"{x:1503,y:852,t:1527873214832};\\\", \\\"{x:1503,y:851,t:1527873214840};\\\", \\\"{x:1502,y:849,t:1527873214857};\\\", \\\"{x:1501,y:846,t:1527873214873};\\\", \\\"{x:1500,y:845,t:1527873214889};\\\", \\\"{x:1499,y:844,t:1527873214907};\\\", \\\"{x:1498,y:843,t:1527873215089};\\\", \\\"{x:1497,y:843,t:1527873215096};\\\", \\\"{x:1496,y:843,t:1527873215143};\\\", \\\"{x:1496,y:844,t:1527873215157};\\\", \\\"{x:1495,y:846,t:1527873215174};\\\", \\\"{x:1494,y:850,t:1527873215191};\\\", \\\"{x:1493,y:851,t:1527873215206};\\\", \\\"{x:1493,y:853,t:1527873215231};\\\", \\\"{x:1493,y:854,t:1527873215247};\\\", \\\"{x:1493,y:855,t:1527873215263};\\\", \\\"{x:1493,y:856,t:1527873215274};\\\", \\\"{x:1491,y:857,t:1527873215291};\\\", \\\"{x:1489,y:861,t:1527873215308};\\\", \\\"{x:1487,y:864,t:1527873215325};\\\", \\\"{x:1486,y:865,t:1527873215352};\\\", \\\"{x:1485,y:865,t:1527873215865};\\\", \\\"{x:1485,y:864,t:1527873215905};\\\", \\\"{x:1485,y:863,t:1527873215929};\\\", \\\"{x:1485,y:862,t:1527873215985};\\\", \\\"{x:1485,y:861,t:1527873216312};\\\", \\\"{x:1485,y:860,t:1527873216326};\\\", \\\"{x:1485,y:858,t:1527873216342};\\\", \\\"{x:1485,y:857,t:1527873216384};\\\", \\\"{x:1486,y:857,t:1527873216416};\\\", \\\"{x:1486,y:856,t:1527873216489};\\\", \\\"{x:1485,y:856,t:1527873217009};\\\", \\\"{x:1482,y:858,t:1527873217025};\\\", \\\"{x:1480,y:859,t:1527873217043};\\\", \\\"{x:1478,y:860,t:1527873217059};\\\", \\\"{x:1476,y:861,t:1527873217076};\\\", \\\"{x:1473,y:863,t:1527873217092};\\\", \\\"{x:1464,y:867,t:1527873217110};\\\", \\\"{x:1453,y:870,t:1527873217126};\\\", \\\"{x:1447,y:872,t:1527873217143};\\\", \\\"{x:1437,y:874,t:1527873217160};\\\", \\\"{x:1425,y:878,t:1527873217176};\\\", \\\"{x:1410,y:888,t:1527873217192};\\\", \\\"{x:1403,y:895,t:1527873217210};\\\", \\\"{x:1400,y:899,t:1527873217226};\\\", \\\"{x:1398,y:903,t:1527873217242};\\\", \\\"{x:1394,y:911,t:1527873217259};\\\", \\\"{x:1389,y:921,t:1527873217275};\\\", \\\"{x:1385,y:933,t:1527873217292};\\\", \\\"{x:1382,y:939,t:1527873217309};\\\", \\\"{x:1381,y:942,t:1527873217326};\\\", \\\"{x:1380,y:946,t:1527873217343};\\\", \\\"{x:1378,y:950,t:1527873217360};\\\", \\\"{x:1378,y:953,t:1527873217376};\\\", \\\"{x:1376,y:958,t:1527873217393};\\\", \\\"{x:1375,y:961,t:1527873217410};\\\", \\\"{x:1374,y:963,t:1527873217426};\\\", \\\"{x:1374,y:964,t:1527873217443};\\\", \\\"{x:1373,y:966,t:1527873217460};\\\", \\\"{x:1371,y:967,t:1527873217476};\\\", \\\"{x:1370,y:969,t:1527873217493};\\\", \\\"{x:1369,y:969,t:1527873217553};\\\", \\\"{x:1368,y:966,t:1527873217688};\\\", \\\"{x:1367,y:963,t:1527873217697};\\\", \\\"{x:1367,y:960,t:1527873217710};\\\", \\\"{x:1366,y:951,t:1527873217727};\\\", \\\"{x:1366,y:938,t:1527873217742};\\\", \\\"{x:1362,y:917,t:1527873217759};\\\", \\\"{x:1361,y:908,t:1527873217776};\\\", \\\"{x:1359,y:896,t:1527873217792};\\\", \\\"{x:1354,y:883,t:1527873217809};\\\", \\\"{x:1352,y:870,t:1527873217826};\\\", \\\"{x:1352,y:863,t:1527873217842};\\\", \\\"{x:1352,y:857,t:1527873217859};\\\", \\\"{x:1353,y:851,t:1527873217875};\\\", \\\"{x:1353,y:847,t:1527873217893};\\\", \\\"{x:1353,y:843,t:1527873217909};\\\", \\\"{x:1353,y:840,t:1527873217926};\\\", \\\"{x:1355,y:832,t:1527873217944};\\\", \\\"{x:1355,y:828,t:1527873217959};\\\", \\\"{x:1355,y:822,t:1527873217976};\\\", \\\"{x:1355,y:819,t:1527873217993};\\\", \\\"{x:1355,y:817,t:1527873218009};\\\", \\\"{x:1355,y:815,t:1527873218026};\\\", \\\"{x:1355,y:812,t:1527873218044};\\\", \\\"{x:1355,y:807,t:1527873218059};\\\", \\\"{x:1355,y:801,t:1527873218076};\\\", \\\"{x:1355,y:797,t:1527873218093};\\\", \\\"{x:1355,y:795,t:1527873218110};\\\", \\\"{x:1355,y:793,t:1527873218126};\\\", \\\"{x:1355,y:788,t:1527873218143};\\\", \\\"{x:1355,y:787,t:1527873218159};\\\", \\\"{x:1355,y:781,t:1527873218176};\\\", \\\"{x:1355,y:778,t:1527873218194};\\\", \\\"{x:1355,y:777,t:1527873218210};\\\", \\\"{x:1355,y:774,t:1527873218226};\\\", \\\"{x:1355,y:772,t:1527873218243};\\\", \\\"{x:1355,y:770,t:1527873218260};\\\", \\\"{x:1355,y:769,t:1527873218277};\\\", \\\"{x:1355,y:768,t:1527873218296};\\\", \\\"{x:1355,y:767,t:1527873218310};\\\", \\\"{x:1355,y:766,t:1527873219369};\\\", \\\"{x:1355,y:765,t:1527873219378};\\\", \\\"{x:1355,y:762,t:1527873219394};\\\", \\\"{x:1355,y:757,t:1527873219411};\\\", \\\"{x:1354,y:745,t:1527873219428};\\\", \\\"{x:1353,y:735,t:1527873219445};\\\", \\\"{x:1351,y:726,t:1527873219460};\\\", \\\"{x:1349,y:718,t:1527873219478};\\\", \\\"{x:1348,y:713,t:1527873219495};\\\", \\\"{x:1348,y:712,t:1527873219511};\\\", \\\"{x:1348,y:711,t:1527873219528};\\\", \\\"{x:1348,y:708,t:1527873219545};\\\", \\\"{x:1347,y:707,t:1527873219560};\\\", \\\"{x:1347,y:704,t:1527873219577};\\\", \\\"{x:1346,y:703,t:1527873219594};\\\", \\\"{x:1345,y:701,t:1527873219611};\\\", \\\"{x:1344,y:701,t:1527873219628};\\\", \\\"{x:1338,y:700,t:1527873219645};\\\", \\\"{x:1327,y:700,t:1527873219661};\\\", \\\"{x:1312,y:700,t:1527873219677};\\\", \\\"{x:1301,y:699,t:1527873219695};\\\", \\\"{x:1291,y:699,t:1527873219710};\\\", \\\"{x:1281,y:699,t:1527873219728};\\\", \\\"{x:1273,y:699,t:1527873219745};\\\", \\\"{x:1261,y:697,t:1527873219761};\\\", \\\"{x:1240,y:690,t:1527873219777};\\\", \\\"{x:1215,y:683,t:1527873219794};\\\", \\\"{x:1183,y:676,t:1527873219810};\\\", \\\"{x:1133,y:668,t:1527873219827};\\\", \\\"{x:1077,y:662,t:1527873219844};\\\", \\\"{x:1016,y:662,t:1527873219861};\\\", \\\"{x:981,y:662,t:1527873219877};\\\", \\\"{x:958,y:662,t:1527873219894};\\\", \\\"{x:917,y:649,t:1527873219911};\\\", \\\"{x:883,y:632,t:1527873219927};\\\", \\\"{x:851,y:621,t:1527873219945};\\\", \\\"{x:828,y:614,t:1527873219961};\\\", \\\"{x:819,y:612,t:1527873219977};\\\", \\\"{x:814,y:609,t:1527873219993};\\\", \\\"{x:812,y:609,t:1527873220011};\\\", \\\"{x:811,y:608,t:1527873220031};\\\", \\\"{x:811,y:607,t:1527873220047};\\\", \\\"{x:810,y:606,t:1527873220060};\\\", \\\"{x:807,y:600,t:1527873220078};\\\", \\\"{x:803,y:588,t:1527873220095};\\\", \\\"{x:800,y:567,t:1527873220111};\\\", \\\"{x:799,y:551,t:1527873220128};\\\", \\\"{x:799,y:535,t:1527873220144};\\\", \\\"{x:799,y:527,t:1527873220161};\\\", \\\"{x:799,y:522,t:1527873220179};\\\", \\\"{x:800,y:518,t:1527873220195};\\\", \\\"{x:800,y:516,t:1527873220212};\\\", \\\"{x:801,y:513,t:1527873220229};\\\", \\\"{x:803,y:509,t:1527873220244};\\\", \\\"{x:803,y:508,t:1527873220262};\\\", \\\"{x:804,y:507,t:1527873220278};\\\", \\\"{x:807,y:504,t:1527873220295};\\\", \\\"{x:809,y:504,t:1527873220312};\\\", \\\"{x:813,y:504,t:1527873220328};\\\", \\\"{x:818,y:504,t:1527873220346};\\\", \\\"{x:822,y:503,t:1527873220362};\\\", \\\"{x:823,y:503,t:1527873220378};\\\", \\\"{x:825,y:503,t:1527873220395};\\\", \\\"{x:826,y:503,t:1527873220413};\\\", \\\"{x:827,y:503,t:1527873220448};\\\", \\\"{x:828,y:502,t:1527873220487};\\\", \\\"{x:829,y:502,t:1527873220520};\\\", \\\"{x:829,y:503,t:1527873221864};\\\", \\\"{x:826,y:510,t:1527873221877};\\\", \\\"{x:820,y:525,t:1527873221895};\\\", \\\"{x:814,y:541,t:1527873221910};\\\", \\\"{x:808,y:555,t:1527873221929};\\\", \\\"{x:803,y:567,t:1527873221946};\\\", \\\"{x:793,y:585,t:1527873221962};\\\", \\\"{x:777,y:613,t:1527873221980};\\\", \\\"{x:760,y:640,t:1527873221996};\\\", \\\"{x:736,y:672,t:1527873222013};\\\", \\\"{x:713,y:703,t:1527873222029};\\\", \\\"{x:698,y:719,t:1527873222046};\\\", \\\"{x:678,y:737,t:1527873222063};\\\", \\\"{x:660,y:749,t:1527873222079};\\\", \\\"{x:640,y:760,t:1527873222096};\\\", \\\"{x:622,y:771,t:1527873222113};\\\", \\\"{x:605,y:781,t:1527873222129};\\\", \\\"{x:594,y:785,t:1527873222146};\\\", \\\"{x:587,y:787,t:1527873222163};\\\", \\\"{x:580,y:789,t:1527873222179};\\\", \\\"{x:576,y:789,t:1527873222196};\\\", \\\"{x:572,y:790,t:1527873222214};\\\", \\\"{x:568,y:790,t:1527873222230};\\\", \\\"{x:567,y:790,t:1527873222246};\\\", \\\"{x:563,y:790,t:1527873222264};\\\", \\\"{x:563,y:788,t:1527873222279};\\\", \\\"{x:557,y:784,t:1527873222296};\\\", \\\"{x:553,y:781,t:1527873222314};\\\", \\\"{x:549,y:777,t:1527873222330};\\\", \\\"{x:545,y:773,t:1527873222347};\\\", \\\"{x:540,y:764,t:1527873222363};\\\", \\\"{x:537,y:756,t:1527873222379};\\\", \\\"{x:536,y:753,t:1527873222398};\\\", \\\"{x:533,y:747,t:1527873222413};\\\", \\\"{x:531,y:741,t:1527873222430};\\\", \\\"{x:529,y:736,t:1527873222446};\\\", \\\"{x:526,y:731,t:1527873222463};\\\", \\\"{x:526,y:729,t:1527873222480};\\\", \\\"{x:525,y:728,t:1527873222497};\\\", \\\"{x:525,y:727,t:1527873222513};\\\", \\\"{x:525,y:726,t:1527873222530};\\\", \\\"{x:524,y:725,t:1527873222547};\\\", \\\"{x:522,y:725,t:1527873222681};\\\", \\\"{x:521,y:725,t:1527873222697};\\\", \\\"{x:520,y:725,t:1527873222714};\\\", \\\"{x:519,y:725,t:1527873222731};\\\", \\\"{x:519,y:726,t:1527873222777};\\\", \\\"{x:519,y:727,t:1527873222784};\\\", \\\"{x:519,y:728,t:1527873222798};\\\", \\\"{x:519,y:729,t:1527873222815};\\\", \\\"{x:519,y:731,t:1527873222830};\\\", \\\"{x:519,y:732,t:1527873222848};\\\" ] }, { \\\"rt\\\": 22874, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 435264, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -02 PM-03 PM-03 PM-02 PM-03 PM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:728,t:1527873227711};\\\", \\\"{x:521,y:718,t:1527873227720};\\\", \\\"{x:523,y:713,t:1527873227734};\\\", \\\"{x:527,y:699,t:1527873227750};\\\", \\\"{x:543,y:668,t:1527873227767};\\\", \\\"{x:555,y:652,t:1527873227784};\\\", \\\"{x:565,y:638,t:1527873227800};\\\", \\\"{x:576,y:626,t:1527873227818};\\\", \\\"{x:588,y:614,t:1527873227834};\\\", \\\"{x:600,y:605,t:1527873227850};\\\", \\\"{x:612,y:596,t:1527873227867};\\\", \\\"{x:627,y:589,t:1527873227885};\\\", \\\"{x:643,y:583,t:1527873227900};\\\", \\\"{x:657,y:577,t:1527873227917};\\\", \\\"{x:674,y:572,t:1527873227934};\\\", \\\"{x:685,y:568,t:1527873227950};\\\", \\\"{x:701,y:564,t:1527873227967};\\\", \\\"{x:711,y:563,t:1527873227984};\\\", \\\"{x:724,y:560,t:1527873228001};\\\", \\\"{x:737,y:559,t:1527873228018};\\\", \\\"{x:753,y:556,t:1527873228034};\\\", \\\"{x:762,y:555,t:1527873228051};\\\", \\\"{x:776,y:553,t:1527873228067};\\\", \\\"{x:783,y:553,t:1527873228084};\\\", \\\"{x:789,y:551,t:1527873228100};\\\", \\\"{x:797,y:551,t:1527873228117};\\\", \\\"{x:812,y:551,t:1527873228134};\\\", \\\"{x:830,y:551,t:1527873228151};\\\", \\\"{x:864,y:551,t:1527873228168};\\\", \\\"{x:893,y:551,t:1527873228184};\\\", \\\"{x:923,y:552,t:1527873228200};\\\", \\\"{x:968,y:560,t:1527873228218};\\\", \\\"{x:1021,y:567,t:1527873228234};\\\", \\\"{x:1080,y:576,t:1527873228251};\\\", \\\"{x:1107,y:580,t:1527873228267};\\\", \\\"{x:1136,y:582,t:1527873228284};\\\", \\\"{x:1162,y:587,t:1527873228301};\\\", \\\"{x:1182,y:590,t:1527873228317};\\\", \\\"{x:1197,y:592,t:1527873228334};\\\", \\\"{x:1217,y:595,t:1527873228351};\\\", \\\"{x:1237,y:595,t:1527873228367};\\\", \\\"{x:1258,y:595,t:1527873228385};\\\", \\\"{x:1273,y:598,t:1527873228402};\\\", \\\"{x:1283,y:599,t:1527873228417};\\\", \\\"{x:1290,y:600,t:1527873228434};\\\", \\\"{x:1294,y:602,t:1527873228452};\\\", \\\"{x:1300,y:605,t:1527873228468};\\\", \\\"{x:1303,y:610,t:1527873228485};\\\", \\\"{x:1308,y:621,t:1527873228502};\\\", \\\"{x:1316,y:636,t:1527873228518};\\\", \\\"{x:1323,y:647,t:1527873228535};\\\", \\\"{x:1331,y:665,t:1527873228552};\\\", \\\"{x:1334,y:676,t:1527873228568};\\\", \\\"{x:1344,y:691,t:1527873228584};\\\", \\\"{x:1355,y:709,t:1527873228602};\\\", \\\"{x:1369,y:732,t:1527873228618};\\\", \\\"{x:1385,y:753,t:1527873228634};\\\", \\\"{x:1397,y:776,t:1527873228651};\\\", \\\"{x:1406,y:796,t:1527873228668};\\\", \\\"{x:1414,y:814,t:1527873228685};\\\", \\\"{x:1424,y:837,t:1527873228702};\\\", \\\"{x:1434,y:860,t:1527873228719};\\\", \\\"{x:1448,y:890,t:1527873228735};\\\", \\\"{x:1463,y:924,t:1527873228752};\\\", \\\"{x:1472,y:940,t:1527873228768};\\\", \\\"{x:1479,y:954,t:1527873228785};\\\", \\\"{x:1487,y:967,t:1527873228802};\\\", \\\"{x:1496,y:982,t:1527873228819};\\\", \\\"{x:1501,y:990,t:1527873228836};\\\", \\\"{x:1506,y:1000,t:1527873228852};\\\", \\\"{x:1509,y:1007,t:1527873228869};\\\", \\\"{x:1514,y:1020,t:1527873228885};\\\", \\\"{x:1519,y:1034,t:1527873228902};\\\", \\\"{x:1521,y:1045,t:1527873228919};\\\", \\\"{x:1524,y:1048,t:1527873228935};\\\", \\\"{x:1524,y:1049,t:1527873228952};\\\", \\\"{x:1525,y:1050,t:1527873228969};\\\", \\\"{x:1529,y:1055,t:1527873228985};\\\", \\\"{x:1535,y:1062,t:1527873229002};\\\", \\\"{x:1536,y:1063,t:1527873229019};\\\", \\\"{x:1538,y:1063,t:1527873229035};\\\", \\\"{x:1539,y:1063,t:1527873229052};\\\", \\\"{x:1542,y:1063,t:1527873229069};\\\", \\\"{x:1547,y:1060,t:1527873229087};\\\", \\\"{x:1552,y:1052,t:1527873229102};\\\", \\\"{x:1557,y:1046,t:1527873229120};\\\", \\\"{x:1564,y:1032,t:1527873229136};\\\", \\\"{x:1568,y:1018,t:1527873229152};\\\", \\\"{x:1574,y:1003,t:1527873229169};\\\", \\\"{x:1578,y:994,t:1527873229186};\\\", \\\"{x:1581,y:989,t:1527873229202};\\\", \\\"{x:1583,y:983,t:1527873229219};\\\", \\\"{x:1583,y:981,t:1527873229236};\\\", \\\"{x:1583,y:979,t:1527873229252};\\\", \\\"{x:1583,y:974,t:1527873229269};\\\", \\\"{x:1583,y:968,t:1527873229286};\\\", \\\"{x:1583,y:965,t:1527873229303};\\\", \\\"{x:1583,y:964,t:1527873229319};\\\", \\\"{x:1582,y:961,t:1527873229336};\\\", \\\"{x:1580,y:960,t:1527873229352};\\\", \\\"{x:1576,y:960,t:1527873229369};\\\", \\\"{x:1574,y:958,t:1527873229386};\\\", \\\"{x:1574,y:957,t:1527873229408};\\\", \\\"{x:1573,y:955,t:1527873229419};\\\", \\\"{x:1572,y:953,t:1527873229436};\\\", \\\"{x:1572,y:951,t:1527873229452};\\\", \\\"{x:1570,y:949,t:1527873229469};\\\", \\\"{x:1569,y:947,t:1527873229486};\\\", \\\"{x:1566,y:945,t:1527873229502};\\\", \\\"{x:1566,y:943,t:1527873229519};\\\", \\\"{x:1563,y:938,t:1527873229537};\\\", \\\"{x:1561,y:930,t:1527873229552};\\\", \\\"{x:1556,y:921,t:1527873229569};\\\", \\\"{x:1556,y:918,t:1527873229586};\\\", \\\"{x:1556,y:916,t:1527873229602};\\\", \\\"{x:1556,y:913,t:1527873229618};\\\", \\\"{x:1556,y:911,t:1527873229635};\\\", \\\"{x:1554,y:905,t:1527873229652};\\\", \\\"{x:1554,y:902,t:1527873229669};\\\", \\\"{x:1554,y:900,t:1527873229685};\\\", \\\"{x:1554,y:898,t:1527873229702};\\\", \\\"{x:1554,y:895,t:1527873229718};\\\", \\\"{x:1554,y:887,t:1527873229735};\\\", \\\"{x:1553,y:879,t:1527873229752};\\\", \\\"{x:1552,y:869,t:1527873229769};\\\", \\\"{x:1552,y:862,t:1527873229786};\\\", \\\"{x:1551,y:855,t:1527873229802};\\\", \\\"{x:1551,y:852,t:1527873229818};\\\", \\\"{x:1551,y:847,t:1527873229835};\\\", \\\"{x:1551,y:838,t:1527873229852};\\\", \\\"{x:1551,y:827,t:1527873229869};\\\", \\\"{x:1551,y:815,t:1527873229886};\\\", \\\"{x:1549,y:802,t:1527873229903};\\\", \\\"{x:1548,y:797,t:1527873229919};\\\", \\\"{x:1548,y:794,t:1527873229936};\\\", \\\"{x:1548,y:793,t:1527873229959};\\\", \\\"{x:1548,y:790,t:1527873230011};\\\", \\\"{x:1548,y:789,t:1527873230019};\\\", \\\"{x:1548,y:788,t:1527873230071};\\\", \\\"{x:1548,y:789,t:1527873230272};\\\", \\\"{x:1548,y:797,t:1527873230286};\\\", \\\"{x:1550,y:817,t:1527873230303};\\\", \\\"{x:1554,y:842,t:1527873230321};\\\", \\\"{x:1555,y:853,t:1527873230337};\\\", \\\"{x:1556,y:863,t:1527873230353};\\\", \\\"{x:1559,y:876,t:1527873230370};\\\", \\\"{x:1559,y:882,t:1527873230386};\\\", \\\"{x:1559,y:884,t:1527873230403};\\\", \\\"{x:1559,y:881,t:1527873230496};\\\", \\\"{x:1559,y:877,t:1527873230504};\\\", \\\"{x:1559,y:868,t:1527873230520};\\\", \\\"{x:1559,y:855,t:1527873230536};\\\", \\\"{x:1560,y:846,t:1527873230554};\\\", \\\"{x:1560,y:842,t:1527873230570};\\\", \\\"{x:1560,y:834,t:1527873230586};\\\", \\\"{x:1560,y:827,t:1527873230603};\\\", \\\"{x:1560,y:821,t:1527873230620};\\\", \\\"{x:1560,y:810,t:1527873230636};\\\", \\\"{x:1560,y:797,t:1527873230653};\\\", \\\"{x:1560,y:786,t:1527873230670};\\\", \\\"{x:1557,y:770,t:1527873230689};\\\", \\\"{x:1557,y:766,t:1527873230703};\\\", \\\"{x:1557,y:758,t:1527873230720};\\\", \\\"{x:1557,y:754,t:1527873230737};\\\", \\\"{x:1557,y:750,t:1527873230753};\\\", \\\"{x:1557,y:742,t:1527873230770};\\\", \\\"{x:1557,y:734,t:1527873230787};\\\", \\\"{x:1559,y:725,t:1527873230803};\\\", \\\"{x:1559,y:719,t:1527873230820};\\\", \\\"{x:1559,y:712,t:1527873230837};\\\", \\\"{x:1558,y:706,t:1527873230853};\\\", \\\"{x:1556,y:698,t:1527873230870};\\\", \\\"{x:1556,y:695,t:1527873230887};\\\", \\\"{x:1555,y:692,t:1527873230903};\\\", \\\"{x:1555,y:691,t:1527873230944};\\\", \\\"{x:1555,y:689,t:1527873230976};\\\", \\\"{x:1554,y:689,t:1527873231064};\\\", \\\"{x:1554,y:691,t:1527873231072};\\\", \\\"{x:1554,y:692,t:1527873231087};\\\", \\\"{x:1554,y:696,t:1527873231104};\\\", \\\"{x:1552,y:698,t:1527873231120};\\\", \\\"{x:1552,y:701,t:1527873231137};\\\", \\\"{x:1551,y:705,t:1527873231154};\\\", \\\"{x:1550,y:709,t:1527873231171};\\\", \\\"{x:1549,y:711,t:1527873231187};\\\", \\\"{x:1548,y:713,t:1527873231204};\\\", \\\"{x:1547,y:715,t:1527873231220};\\\", \\\"{x:1547,y:716,t:1527873231237};\\\", \\\"{x:1547,y:718,t:1527873231254};\\\", \\\"{x:1547,y:722,t:1527873231271};\\\", \\\"{x:1547,y:727,t:1527873231287};\\\", \\\"{x:1547,y:739,t:1527873231304};\\\", \\\"{x:1547,y:752,t:1527873231320};\\\", \\\"{x:1547,y:762,t:1527873231337};\\\", \\\"{x:1547,y:769,t:1527873231354};\\\", \\\"{x:1547,y:773,t:1527873231370};\\\", \\\"{x:1547,y:783,t:1527873231387};\\\", \\\"{x:1549,y:798,t:1527873231405};\\\", \\\"{x:1555,y:817,t:1527873231420};\\\", \\\"{x:1559,y:834,t:1527873231437};\\\", \\\"{x:1567,y:852,t:1527873231454};\\\", \\\"{x:1572,y:871,t:1527873231470};\\\", \\\"{x:1572,y:879,t:1527873231487};\\\", \\\"{x:1573,y:893,t:1527873231504};\\\", \\\"{x:1573,y:900,t:1527873231520};\\\", \\\"{x:1576,y:907,t:1527873231537};\\\", \\\"{x:1577,y:918,t:1527873231554};\\\", \\\"{x:1580,y:931,t:1527873231570};\\\", \\\"{x:1580,y:942,t:1527873231587};\\\", \\\"{x:1581,y:948,t:1527873231604};\\\", \\\"{x:1581,y:953,t:1527873231621};\\\", \\\"{x:1581,y:958,t:1527873231637};\\\", \\\"{x:1581,y:964,t:1527873231654};\\\", \\\"{x:1581,y:965,t:1527873231671};\\\", \\\"{x:1578,y:973,t:1527873231688};\\\", \\\"{x:1575,y:978,t:1527873231704};\\\", \\\"{x:1571,y:983,t:1527873231721};\\\", \\\"{x:1565,y:990,t:1527873231737};\\\", \\\"{x:1563,y:991,t:1527873231754};\\\", \\\"{x:1562,y:991,t:1527873231771};\\\", \\\"{x:1560,y:992,t:1527873231787};\\\", \\\"{x:1557,y:994,t:1527873231804};\\\", \\\"{x:1554,y:995,t:1527873231821};\\\", \\\"{x:1550,y:996,t:1527873231837};\\\", \\\"{x:1549,y:997,t:1527873231854};\\\", \\\"{x:1545,y:997,t:1527873231871};\\\", \\\"{x:1542,y:997,t:1527873231887};\\\", \\\"{x:1540,y:994,t:1527873231904};\\\", \\\"{x:1540,y:990,t:1527873231921};\\\", \\\"{x:1540,y:987,t:1527873231938};\\\", \\\"{x:1540,y:983,t:1527873231954};\\\", \\\"{x:1540,y:978,t:1527873231971};\\\", \\\"{x:1540,y:975,t:1527873231987};\\\", \\\"{x:1540,y:973,t:1527873232005};\\\", \\\"{x:1541,y:970,t:1527873232021};\\\", \\\"{x:1542,y:968,t:1527873232038};\\\", \\\"{x:1544,y:966,t:1527873232054};\\\", \\\"{x:1544,y:965,t:1527873232113};\\\", \\\"{x:1544,y:964,t:1527873232128};\\\", \\\"{x:1546,y:964,t:1527873232432};\\\", \\\"{x:1547,y:964,t:1527873232456};\\\", \\\"{x:1548,y:964,t:1527873238804};\\\", \\\"{x:1548,y:963,t:1527873238812};\\\", \\\"{x:1547,y:963,t:1527873238876};\\\", \\\"{x:1546,y:963,t:1527873238899};\\\", \\\"{x:1545,y:963,t:1527873238912};\\\", \\\"{x:1543,y:962,t:1527873238929};\\\", \\\"{x:1540,y:961,t:1527873238946};\\\", \\\"{x:1539,y:960,t:1527873238980};\\\", \\\"{x:1536,y:957,t:1527873238995};\\\", \\\"{x:1531,y:951,t:1527873239012};\\\", \\\"{x:1521,y:943,t:1527873239029};\\\", \\\"{x:1519,y:937,t:1527873239046};\\\", \\\"{x:1518,y:933,t:1527873239063};\\\", \\\"{x:1514,y:928,t:1527873239079};\\\", \\\"{x:1510,y:926,t:1527873239096};\\\", \\\"{x:1507,y:923,t:1527873239113};\\\", \\\"{x:1505,y:921,t:1527873239129};\\\", \\\"{x:1504,y:920,t:1527873239146};\\\", \\\"{x:1503,y:919,t:1527873239164};\\\", \\\"{x:1501,y:918,t:1527873239180};\\\", \\\"{x:1496,y:915,t:1527873239196};\\\", \\\"{x:1487,y:907,t:1527873239213};\\\", \\\"{x:1477,y:899,t:1527873239229};\\\", \\\"{x:1461,y:891,t:1527873239245};\\\", \\\"{x:1445,y:882,t:1527873239263};\\\", \\\"{x:1430,y:872,t:1527873239279};\\\", \\\"{x:1413,y:863,t:1527873239295};\\\", \\\"{x:1401,y:852,t:1527873239313};\\\", \\\"{x:1381,y:841,t:1527873239328};\\\", \\\"{x:1356,y:827,t:1527873239346};\\\", \\\"{x:1301,y:787,t:1527873239362};\\\", \\\"{x:1256,y:757,t:1527873239378};\\\", \\\"{x:1201,y:724,t:1527873239395};\\\", \\\"{x:1162,y:705,t:1527873239413};\\\", \\\"{x:1134,y:693,t:1527873239428};\\\", \\\"{x:1115,y:683,t:1527873239446};\\\", \\\"{x:1099,y:674,t:1527873239463};\\\", \\\"{x:1080,y:663,t:1527873239479};\\\", \\\"{x:1062,y:655,t:1527873239496};\\\", \\\"{x:1049,y:647,t:1527873239513};\\\", \\\"{x:1036,y:642,t:1527873239529};\\\", \\\"{x:1020,y:635,t:1527873239547};\\\", \\\"{x:1001,y:625,t:1527873239564};\\\", \\\"{x:990,y:620,t:1527873239579};\\\", \\\"{x:983,y:616,t:1527873239595};\\\", \\\"{x:976,y:611,t:1527873239613};\\\", \\\"{x:971,y:605,t:1527873239629};\\\", \\\"{x:963,y:597,t:1527873239646};\\\", \\\"{x:956,y:587,t:1527873239663};\\\", \\\"{x:948,y:579,t:1527873239681};\\\", \\\"{x:942,y:571,t:1527873239695};\\\", \\\"{x:939,y:567,t:1527873239712};\\\", \\\"{x:934,y:559,t:1527873239728};\\\", \\\"{x:929,y:553,t:1527873239744};\\\", \\\"{x:916,y:542,t:1527873239761};\\\", \\\"{x:895,y:526,t:1527873239780};\\\", \\\"{x:878,y:520,t:1527873239798};\\\", \\\"{x:861,y:514,t:1527873239814};\\\", \\\"{x:845,y:511,t:1527873239830};\\\", \\\"{x:838,y:510,t:1527873239847};\\\", \\\"{x:834,y:509,t:1527873239863};\\\", \\\"{x:833,y:508,t:1527873239880};\\\", \\\"{x:831,y:507,t:1527873239897};\\\", \\\"{x:828,y:506,t:1527873239913};\\\", \\\"{x:824,y:505,t:1527873239930};\\\", \\\"{x:818,y:505,t:1527873239947};\\\", \\\"{x:808,y:506,t:1527873239963};\\\", \\\"{x:792,y:516,t:1527873239980};\\\", \\\"{x:777,y:527,t:1527873239998};\\\", \\\"{x:764,y:536,t:1527873240013};\\\", \\\"{x:749,y:544,t:1527873240030};\\\", \\\"{x:736,y:552,t:1527873240048};\\\", \\\"{x:724,y:557,t:1527873240065};\\\", \\\"{x:715,y:559,t:1527873240081};\\\", \\\"{x:710,y:560,t:1527873240097};\\\", \\\"{x:700,y:561,t:1527873240114};\\\", \\\"{x:695,y:561,t:1527873240131};\\\", \\\"{x:685,y:561,t:1527873240148};\\\", \\\"{x:671,y:561,t:1527873240165};\\\", \\\"{x:650,y:561,t:1527873240181};\\\", \\\"{x:623,y:561,t:1527873240197};\\\", \\\"{x:605,y:561,t:1527873240214};\\\", \\\"{x:591,y:561,t:1527873240231};\\\", \\\"{x:585,y:561,t:1527873240248};\\\", \\\"{x:578,y:560,t:1527873240265};\\\", \\\"{x:558,y:559,t:1527873240280};\\\", \\\"{x:532,y:556,t:1527873240298};\\\", \\\"{x:485,y:556,t:1527873240315};\\\", \\\"{x:454,y:556,t:1527873240332};\\\", \\\"{x:427,y:555,t:1527873240347};\\\", \\\"{x:405,y:555,t:1527873240364};\\\", \\\"{x:385,y:555,t:1527873240381};\\\", \\\"{x:369,y:555,t:1527873240397};\\\", \\\"{x:363,y:555,t:1527873240414};\\\", \\\"{x:356,y:555,t:1527873240431};\\\", \\\"{x:352,y:555,t:1527873240447};\\\", \\\"{x:348,y:555,t:1527873240464};\\\", \\\"{x:342,y:555,t:1527873240481};\\\", \\\"{x:332,y:555,t:1527873240497};\\\", \\\"{x:312,y:560,t:1527873240515};\\\", \\\"{x:303,y:561,t:1527873240531};\\\", \\\"{x:289,y:567,t:1527873240548};\\\", \\\"{x:275,y:573,t:1527873240564};\\\", \\\"{x:260,y:580,t:1527873240582};\\\", \\\"{x:245,y:587,t:1527873240597};\\\", \\\"{x:231,y:593,t:1527873240614};\\\", \\\"{x:225,y:596,t:1527873240632};\\\", \\\"{x:221,y:598,t:1527873240648};\\\", \\\"{x:217,y:598,t:1527873240664};\\\", \\\"{x:216,y:598,t:1527873240681};\\\", \\\"{x:215,y:598,t:1527873240697};\\\", \\\"{x:209,y:598,t:1527873240714};\\\", \\\"{x:204,y:596,t:1527873240731};\\\", \\\"{x:200,y:593,t:1527873240748};\\\", \\\"{x:195,y:588,t:1527873240764};\\\", \\\"{x:193,y:584,t:1527873240781};\\\", \\\"{x:191,y:581,t:1527873240799};\\\", \\\"{x:189,y:577,t:1527873240814};\\\", \\\"{x:186,y:573,t:1527873240832};\\\", \\\"{x:183,y:568,t:1527873240848};\\\", \\\"{x:181,y:563,t:1527873240865};\\\", \\\"{x:180,y:559,t:1527873240882};\\\", \\\"{x:177,y:551,t:1527873240899};\\\", \\\"{x:174,y:547,t:1527873240915};\\\", \\\"{x:174,y:541,t:1527873240931};\\\", \\\"{x:174,y:539,t:1527873240949};\\\", \\\"{x:173,y:536,t:1527873240965};\\\", \\\"{x:173,y:535,t:1527873240982};\\\", \\\"{x:171,y:532,t:1527873240998};\\\", \\\"{x:170,y:532,t:1527873241043};\\\", \\\"{x:168,y:532,t:1527873241076};\\\", \\\"{x:167,y:532,t:1527873241083};\\\", \\\"{x:163,y:532,t:1527873241099};\\\", \\\"{x:162,y:532,t:1527873241155};\\\", \\\"{x:161,y:532,t:1527873241196};\\\", \\\"{x:163,y:534,t:1527873241876};\\\", \\\"{x:172,y:538,t:1527873241883};\\\", \\\"{x:202,y:549,t:1527873241901};\\\", \\\"{x:245,y:558,t:1527873241917};\\\", \\\"{x:301,y:570,t:1527873241934};\\\", \\\"{x:351,y:582,t:1527873241950};\\\", \\\"{x:422,y:598,t:1527873241966};\\\", \\\"{x:488,y:616,t:1527873241984};\\\", \\\"{x:556,y:628,t:1527873241999};\\\", \\\"{x:645,y:643,t:1527873242015};\\\", \\\"{x:737,y:655,t:1527873242032};\\\", \\\"{x:812,y:664,t:1527873242048};\\\", \\\"{x:894,y:682,t:1527873242065};\\\", \\\"{x:988,y:708,t:1527873242082};\\\", \\\"{x:1048,y:728,t:1527873242098};\\\", \\\"{x:1121,y:754,t:1527873242115};\\\", \\\"{x:1205,y:780,t:1527873242132};\\\", \\\"{x:1260,y:797,t:1527873242149};\\\", \\\"{x:1318,y:819,t:1527873242165};\\\", \\\"{x:1374,y:846,t:1527873242183};\\\", \\\"{x:1426,y:876,t:1527873242199};\\\", \\\"{x:1471,y:899,t:1527873242215};\\\", \\\"{x:1504,y:919,t:1527873242233};\\\", \\\"{x:1519,y:927,t:1527873242248};\\\", \\\"{x:1532,y:933,t:1527873242265};\\\", \\\"{x:1555,y:943,t:1527873242282};\\\", \\\"{x:1562,y:945,t:1527873242298};\\\", \\\"{x:1567,y:949,t:1527873242315};\\\", \\\"{x:1568,y:949,t:1527873242333};\\\", \\\"{x:1571,y:951,t:1527873242349};\\\", \\\"{x:1576,y:958,t:1527873242366};\\\", \\\"{x:1580,y:964,t:1527873242382};\\\", \\\"{x:1582,y:969,t:1527873242399};\\\", \\\"{x:1582,y:970,t:1527873242416};\\\", \\\"{x:1582,y:971,t:1527873242443};\\\", \\\"{x:1581,y:972,t:1527873242475};\\\", \\\"{x:1578,y:972,t:1527873242483};\\\", \\\"{x:1572,y:972,t:1527873242499};\\\", \\\"{x:1560,y:972,t:1527873242516};\\\", \\\"{x:1543,y:972,t:1527873242533};\\\", \\\"{x:1530,y:972,t:1527873242549};\\\", \\\"{x:1516,y:972,t:1527873242566};\\\", \\\"{x:1505,y:972,t:1527873242581};\\\", \\\"{x:1501,y:972,t:1527873242598};\\\", \\\"{x:1498,y:972,t:1527873242615};\\\", \\\"{x:1494,y:972,t:1527873242631};\\\", \\\"{x:1491,y:972,t:1527873242649};\\\", \\\"{x:1489,y:972,t:1527873242665};\\\", \\\"{x:1488,y:972,t:1527873242764};\\\", \\\"{x:1489,y:974,t:1527873242779};\\\", \\\"{x:1490,y:975,t:1527873242787};\\\", \\\"{x:1491,y:975,t:1527873242799};\\\", \\\"{x:1495,y:975,t:1527873242816};\\\", \\\"{x:1500,y:975,t:1527873242831};\\\", \\\"{x:1506,y:975,t:1527873242850};\\\", \\\"{x:1512,y:975,t:1527873242866};\\\", \\\"{x:1514,y:975,t:1527873242882};\\\", \\\"{x:1515,y:975,t:1527873242900};\\\", \\\"{x:1516,y:975,t:1527873242948};\\\", \\\"{x:1518,y:975,t:1527873242955};\\\", \\\"{x:1520,y:975,t:1527873242966};\\\", \\\"{x:1522,y:975,t:1527873242982};\\\", \\\"{x:1525,y:975,t:1527873242999};\\\", \\\"{x:1528,y:975,t:1527873243016};\\\", \\\"{x:1533,y:972,t:1527873243032};\\\", \\\"{x:1542,y:969,t:1527873243048};\\\", \\\"{x:1548,y:966,t:1527873243066};\\\", \\\"{x:1553,y:966,t:1527873243082};\\\", \\\"{x:1559,y:965,t:1527873243099};\\\", \\\"{x:1561,y:964,t:1527873243115};\\\", \\\"{x:1562,y:964,t:1527873243132};\\\", \\\"{x:1563,y:963,t:1527873243148};\\\", \\\"{x:1564,y:962,t:1527873243165};\\\", \\\"{x:1565,y:960,t:1527873243227};\\\", \\\"{x:1566,y:958,t:1527873243242};\\\", \\\"{x:1566,y:954,t:1527873243251};\\\", \\\"{x:1566,y:952,t:1527873243265};\\\", \\\"{x:1566,y:947,t:1527873243282};\\\", \\\"{x:1566,y:941,t:1527873243299};\\\", \\\"{x:1566,y:940,t:1527873243315};\\\", \\\"{x:1566,y:938,t:1527873243371};\\\", \\\"{x:1566,y:937,t:1527873243387};\\\", \\\"{x:1565,y:937,t:1527873243411};\\\", \\\"{x:1565,y:935,t:1527873243492};\\\", \\\"{x:1565,y:933,t:1527873243506};\\\", \\\"{x:1565,y:931,t:1527873243514};\\\", \\\"{x:1565,y:930,t:1527873243531};\\\", \\\"{x:1565,y:929,t:1527873248820};\\\", \\\"{x:1550,y:927,t:1527873248830};\\\", \\\"{x:1509,y:925,t:1527873248845};\\\", \\\"{x:1479,y:920,t:1527873248862};\\\", \\\"{x:1458,y:914,t:1527873248879};\\\", \\\"{x:1432,y:912,t:1527873248896};\\\", \\\"{x:1411,y:906,t:1527873248912};\\\", \\\"{x:1397,y:902,t:1527873248929};\\\", \\\"{x:1384,y:898,t:1527873248947};\\\", \\\"{x:1371,y:897,t:1527873248962};\\\", \\\"{x:1334,y:894,t:1527873248978};\\\", \\\"{x:1291,y:887,t:1527873248995};\\\", \\\"{x:1246,y:880,t:1527873249012};\\\", \\\"{x:1198,y:872,t:1527873249027};\\\", \\\"{x:1138,y:867,t:1527873249045};\\\", \\\"{x:1071,y:859,t:1527873249062};\\\", \\\"{x:1021,y:853,t:1527873249077};\\\", \\\"{x:983,y:848,t:1527873249095};\\\", \\\"{x:932,y:847,t:1527873249111};\\\", \\\"{x:886,y:845,t:1527873249128};\\\", \\\"{x:849,y:839,t:1527873249144};\\\", \\\"{x:810,y:833,t:1527873249162};\\\", \\\"{x:776,y:824,t:1527873249178};\\\", \\\"{x:712,y:813,t:1527873249194};\\\", \\\"{x:683,y:808,t:1527873249212};\\\", \\\"{x:654,y:805,t:1527873249228};\\\", \\\"{x:627,y:799,t:1527873249245};\\\", \\\"{x:610,y:795,t:1527873249262};\\\", \\\"{x:599,y:791,t:1527873249278};\\\", \\\"{x:597,y:790,t:1527873249295};\\\", \\\"{x:595,y:790,t:1527873249312};\\\", \\\"{x:594,y:788,t:1527873249363};\\\", \\\"{x:592,y:787,t:1527873249378};\\\", \\\"{x:586,y:782,t:1527873249395};\\\", \\\"{x:584,y:779,t:1527873249411};\\\", \\\"{x:580,y:774,t:1527873249428};\\\", \\\"{x:571,y:766,t:1527873249445};\\\", \\\"{x:563,y:761,t:1527873249463};\\\", \\\"{x:553,y:754,t:1527873249480};\\\", \\\"{x:547,y:752,t:1527873249495};\\\", \\\"{x:542,y:748,t:1527873249512};\\\", \\\"{x:540,y:747,t:1527873249522};\\\", \\\"{x:539,y:746,t:1527873249538};\\\", \\\"{x:537,y:745,t:1527873249554};\\\", \\\"{x:535,y:743,t:1527873249571};\\\", \\\"{x:531,y:741,t:1527873249588};\\\", \\\"{x:531,y:740,t:1527873249605};\\\", \\\"{x:530,y:739,t:1527873249622};\\\", \\\"{x:529,y:739,t:1527873249638};\\\", \\\"{x:528,y:738,t:1527873249666};\\\" ] }, { \\\"rt\\\": 31238, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 467765, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-M -04 PM-03 PM-X -02 PM-M -M -B -02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:738,t:1527873251138};\\\", \\\"{x:523,y:736,t:1527873251923};\\\", \\\"{x:513,y:715,t:1527873251941};\\\", \\\"{x:507,y:699,t:1527873251955};\\\", \\\"{x:503,y:690,t:1527873251974};\\\", \\\"{x:497,y:676,t:1527873251991};\\\", \\\"{x:486,y:653,t:1527873252006};\\\", \\\"{x:477,y:632,t:1527873252025};\\\", \\\"{x:470,y:609,t:1527873252040};\\\", \\\"{x:469,y:590,t:1527873252057};\\\", \\\"{x:465,y:568,t:1527873252074};\\\", \\\"{x:465,y:553,t:1527873252090};\\\", \\\"{x:463,y:540,t:1527873252107};\\\", \\\"{x:463,y:530,t:1527873252124};\\\", \\\"{x:460,y:518,t:1527873252140};\\\", \\\"{x:459,y:509,t:1527873252156};\\\", \\\"{x:457,y:506,t:1527873252174};\\\", \\\"{x:457,y:504,t:1527873252191};\\\", \\\"{x:456,y:502,t:1527873252208};\\\", \\\"{x:455,y:499,t:1527873252224};\\\", \\\"{x:455,y:497,t:1527873252241};\\\", \\\"{x:454,y:495,t:1527873252257};\\\", \\\"{x:454,y:494,t:1527873252274};\\\", \\\"{x:461,y:495,t:1527873255483};\\\", \\\"{x:502,y:510,t:1527873255494};\\\", \\\"{x:588,y:535,t:1527873255509};\\\", \\\"{x:662,y:564,t:1527873255527};\\\", \\\"{x:737,y:586,t:1527873255543};\\\", \\\"{x:812,y:608,t:1527873255560};\\\", \\\"{x:884,y:628,t:1527873255577};\\\", \\\"{x:955,y:653,t:1527873255593};\\\", \\\"{x:1025,y:680,t:1527873255610};\\\", \\\"{x:1060,y:694,t:1527873255626};\\\", \\\"{x:1094,y:709,t:1527873255643};\\\", \\\"{x:1119,y:720,t:1527873255660};\\\", \\\"{x:1134,y:731,t:1527873255677};\\\", \\\"{x:1155,y:750,t:1527873255693};\\\", \\\"{x:1169,y:767,t:1527873255710};\\\", \\\"{x:1180,y:782,t:1527873255726};\\\", \\\"{x:1202,y:798,t:1527873255743};\\\", \\\"{x:1227,y:817,t:1527873255760};\\\", \\\"{x:1265,y:837,t:1527873255777};\\\", \\\"{x:1309,y:857,t:1527873255794};\\\", \\\"{x:1378,y:882,t:1527873255810};\\\", \\\"{x:1421,y:897,t:1527873255828};\\\", \\\"{x:1460,y:914,t:1527873255845};\\\", \\\"{x:1489,y:926,t:1527873255860};\\\", \\\"{x:1513,y:937,t:1527873255877};\\\", \\\"{x:1536,y:946,t:1527873255894};\\\", \\\"{x:1557,y:956,t:1527873255910};\\\", \\\"{x:1572,y:964,t:1527873255927};\\\", \\\"{x:1587,y:969,t:1527873255944};\\\", \\\"{x:1601,y:973,t:1527873255960};\\\", \\\"{x:1609,y:975,t:1527873255977};\\\", \\\"{x:1614,y:976,t:1527873255994};\\\", \\\"{x:1615,y:977,t:1527873256010};\\\", \\\"{x:1614,y:977,t:1527873256092};\\\", \\\"{x:1608,y:977,t:1527873256099};\\\", \\\"{x:1601,y:977,t:1527873256111};\\\", \\\"{x:1589,y:977,t:1527873256129};\\\", \\\"{x:1585,y:977,t:1527873256145};\\\", \\\"{x:1580,y:977,t:1527873256161};\\\", \\\"{x:1556,y:975,t:1527873256179};\\\", \\\"{x:1545,y:967,t:1527873256195};\\\", \\\"{x:1528,y:959,t:1527873256211};\\\", \\\"{x:1513,y:954,t:1527873256229};\\\", \\\"{x:1511,y:951,t:1527873256245};\\\", \\\"{x:1507,y:946,t:1527873256261};\\\", \\\"{x:1505,y:943,t:1527873256279};\\\", \\\"{x:1505,y:938,t:1527873256295};\\\", \\\"{x:1503,y:928,t:1527873256312};\\\", \\\"{x:1501,y:919,t:1527873256328};\\\", \\\"{x:1496,y:911,t:1527873256346};\\\", \\\"{x:1494,y:904,t:1527873256362};\\\", \\\"{x:1485,y:889,t:1527873256379};\\\", \\\"{x:1482,y:881,t:1527873256395};\\\", \\\"{x:1481,y:874,t:1527873256411};\\\", \\\"{x:1480,y:867,t:1527873256428};\\\", \\\"{x:1480,y:863,t:1527873256445};\\\", \\\"{x:1480,y:858,t:1527873256462};\\\", \\\"{x:1483,y:855,t:1527873256479};\\\", \\\"{x:1485,y:851,t:1527873256496};\\\", \\\"{x:1487,y:849,t:1527873256512};\\\", \\\"{x:1489,y:847,t:1527873256528};\\\", \\\"{x:1489,y:846,t:1527873256545};\\\", \\\"{x:1493,y:840,t:1527873256563};\\\", \\\"{x:1493,y:838,t:1527873256579};\\\", \\\"{x:1493,y:837,t:1527873256595};\\\", \\\"{x:1493,y:834,t:1527873256612};\\\", \\\"{x:1494,y:832,t:1527873256629};\\\", \\\"{x:1494,y:831,t:1527873256646};\\\", \\\"{x:1494,y:829,t:1527873256663};\\\", \\\"{x:1494,y:828,t:1527873256679};\\\", \\\"{x:1494,y:826,t:1527873256696};\\\", \\\"{x:1494,y:825,t:1527873256712};\\\", \\\"{x:1494,y:824,t:1527873256739};\\\", \\\"{x:1493,y:824,t:1527873256835};\\\", \\\"{x:1492,y:824,t:1527873256867};\\\", \\\"{x:1491,y:824,t:1527873256883};\\\", \\\"{x:1490,y:824,t:1527873256896};\\\", \\\"{x:1489,y:825,t:1527873256912};\\\", \\\"{x:1488,y:826,t:1527873256929};\\\", \\\"{x:1487,y:827,t:1527873256946};\\\", \\\"{x:1486,y:828,t:1527873256965};\\\", \\\"{x:1486,y:829,t:1527873256979};\\\", \\\"{x:1485,y:831,t:1527873257010};\\\", \\\"{x:1484,y:832,t:1527873257042};\\\", \\\"{x:1483,y:834,t:1527873257066};\\\", \\\"{x:1483,y:835,t:1527873257090};\\\", \\\"{x:1482,y:837,t:1527873257106};\\\", \\\"{x:1482,y:838,t:1527873257114};\\\", \\\"{x:1482,y:840,t:1527873257129};\\\", \\\"{x:1482,y:845,t:1527873257145};\\\", \\\"{x:1482,y:851,t:1527873257163};\\\", \\\"{x:1482,y:860,t:1527873257179};\\\", \\\"{x:1482,y:865,t:1527873257196};\\\", \\\"{x:1480,y:871,t:1527873257213};\\\", \\\"{x:1478,y:877,t:1527873257229};\\\", \\\"{x:1475,y:881,t:1527873257246};\\\", \\\"{x:1474,y:885,t:1527873257263};\\\", \\\"{x:1471,y:887,t:1527873257280};\\\", \\\"{x:1471,y:889,t:1527873257296};\\\", \\\"{x:1469,y:890,t:1527873257313};\\\", \\\"{x:1466,y:894,t:1527873257330};\\\", \\\"{x:1465,y:897,t:1527873257347};\\\", \\\"{x:1464,y:902,t:1527873257364};\\\", \\\"{x:1464,y:904,t:1527873257381};\\\", \\\"{x:1464,y:908,t:1527873257397};\\\", \\\"{x:1464,y:911,t:1527873257413};\\\", \\\"{x:1464,y:914,t:1527873257430};\\\", \\\"{x:1464,y:916,t:1527873257447};\\\", \\\"{x:1464,y:919,t:1527873257463};\\\", \\\"{x:1464,y:922,t:1527873257480};\\\", \\\"{x:1464,y:925,t:1527873257497};\\\", \\\"{x:1464,y:927,t:1527873257513};\\\", \\\"{x:1464,y:931,t:1527873257530};\\\", \\\"{x:1464,y:933,t:1527873257547};\\\", \\\"{x:1464,y:934,t:1527873257563};\\\", \\\"{x:1464,y:936,t:1527873257587};\\\", \\\"{x:1464,y:938,t:1527873257603};\\\", \\\"{x:1464,y:940,t:1527873257614};\\\", \\\"{x:1465,y:950,t:1527873257631};\\\", \\\"{x:1468,y:959,t:1527873257648};\\\", \\\"{x:1471,y:966,t:1527873257665};\\\", \\\"{x:1472,y:969,t:1527873257681};\\\", \\\"{x:1473,y:970,t:1527873257697};\\\", \\\"{x:1473,y:971,t:1527873257714};\\\", \\\"{x:1474,y:972,t:1527873257730};\\\", \\\"{x:1474,y:973,t:1527873257748};\\\", \\\"{x:1474,y:974,t:1527873257764};\\\", \\\"{x:1475,y:975,t:1527873257781};\\\", \\\"{x:1476,y:976,t:1527873257797};\\\", \\\"{x:1477,y:977,t:1527873257819};\\\", \\\"{x:1478,y:978,t:1527873257859};\\\", \\\"{x:1480,y:978,t:1527873257875};\\\", \\\"{x:1480,y:977,t:1527873257883};\\\", \\\"{x:1481,y:977,t:1527873257897};\\\", \\\"{x:1484,y:974,t:1527873257914};\\\", \\\"{x:1485,y:974,t:1527873257932};\\\", \\\"{x:1485,y:973,t:1527873257948};\\\", \\\"{x:1486,y:973,t:1527873257965};\\\", \\\"{x:1486,y:972,t:1527873257981};\\\", \\\"{x:1486,y:971,t:1527873258003};\\\", \\\"{x:1487,y:970,t:1527873258027};\\\", \\\"{x:1486,y:970,t:1527873258083};\\\", \\\"{x:1484,y:970,t:1527873258098};\\\", \\\"{x:1480,y:970,t:1527873258115};\\\", \\\"{x:1475,y:970,t:1527873258131};\\\", \\\"{x:1468,y:970,t:1527873258149};\\\", \\\"{x:1459,y:967,t:1527873258166};\\\", \\\"{x:1449,y:967,t:1527873258182};\\\", \\\"{x:1442,y:966,t:1527873258199};\\\", \\\"{x:1437,y:966,t:1527873258216};\\\", \\\"{x:1432,y:966,t:1527873258232};\\\", \\\"{x:1428,y:966,t:1527873258249};\\\", \\\"{x:1422,y:966,t:1527873258266};\\\", \\\"{x:1417,y:966,t:1527873258281};\\\", \\\"{x:1410,y:966,t:1527873258299};\\\", \\\"{x:1408,y:966,t:1527873258316};\\\", \\\"{x:1407,y:966,t:1527873258333};\\\", \\\"{x:1405,y:966,t:1527873258349};\\\", \\\"{x:1403,y:966,t:1527873258426};\\\", \\\"{x:1402,y:965,t:1527873258442};\\\", \\\"{x:1402,y:964,t:1527873258450};\\\", \\\"{x:1401,y:964,t:1527873258466};\\\", \\\"{x:1400,y:963,t:1527873258482};\\\", \\\"{x:1399,y:963,t:1527873258506};\\\", \\\"{x:1397,y:963,t:1527873258530};\\\", \\\"{x:1396,y:963,t:1527873258538};\\\", \\\"{x:1394,y:963,t:1527873258554};\\\", \\\"{x:1393,y:963,t:1527873258570};\\\", \\\"{x:1391,y:963,t:1527873258587};\\\", \\\"{x:1390,y:963,t:1527873258603};\\\", \\\"{x:1388,y:963,t:1527873258635};\\\", \\\"{x:1387,y:963,t:1527873258651};\\\", \\\"{x:1385,y:963,t:1527873258683};\\\", \\\"{x:1384,y:963,t:1527873258723};\\\", \\\"{x:1384,y:962,t:1527873258764};\\\", \\\"{x:1384,y:961,t:1527873258772};\\\", \\\"{x:1384,y:959,t:1527873258782};\\\", \\\"{x:1384,y:955,t:1527873258799};\\\", \\\"{x:1385,y:952,t:1527873258817};\\\", \\\"{x:1386,y:950,t:1527873258833};\\\", \\\"{x:1386,y:949,t:1527873258859};\\\", \\\"{x:1386,y:948,t:1527873258867};\\\", \\\"{x:1386,y:947,t:1527873258884};\\\", \\\"{x:1388,y:943,t:1527873258900};\\\", \\\"{x:1388,y:940,t:1527873258916};\\\", \\\"{x:1388,y:938,t:1527873258933};\\\", \\\"{x:1388,y:937,t:1527873258949};\\\", \\\"{x:1388,y:936,t:1527873258967};\\\", \\\"{x:1388,y:935,t:1527873258983};\\\", \\\"{x:1388,y:934,t:1527873258999};\\\", \\\"{x:1388,y:933,t:1527873259019};\\\", \\\"{x:1388,y:931,t:1527873259034};\\\", \\\"{x:1388,y:928,t:1527873259051};\\\", \\\"{x:1388,y:927,t:1527873259075};\\\", \\\"{x:1388,y:926,t:1527873259083};\\\", \\\"{x:1388,y:925,t:1527873259100};\\\", \\\"{x:1388,y:922,t:1527873259117};\\\", \\\"{x:1388,y:920,t:1527873259133};\\\", \\\"{x:1388,y:918,t:1527873259151};\\\", \\\"{x:1388,y:917,t:1527873259167};\\\", \\\"{x:1388,y:916,t:1527873259184};\\\", \\\"{x:1387,y:916,t:1527873259201};\\\", \\\"{x:1387,y:915,t:1527873259226};\\\", \\\"{x:1387,y:914,t:1527873259233};\\\", \\\"{x:1387,y:913,t:1527873259250};\\\", \\\"{x:1387,y:909,t:1527873259267};\\\", \\\"{x:1386,y:907,t:1527873259283};\\\", \\\"{x:1385,y:904,t:1527873259300};\\\", \\\"{x:1385,y:903,t:1527873259316};\\\", \\\"{x:1385,y:902,t:1527873259333};\\\", \\\"{x:1385,y:901,t:1527873259353};\\\", \\\"{x:1385,y:900,t:1527873259377};\\\", \\\"{x:1385,y:899,t:1527873259409};\\\", \\\"{x:1385,y:898,t:1527873259418};\\\", \\\"{x:1384,y:897,t:1527873259434};\\\", \\\"{x:1384,y:896,t:1527873260427};\\\", \\\"{x:1384,y:894,t:1527873260475};\\\", \\\"{x:1381,y:889,t:1527873260486};\\\", \\\"{x:1376,y:878,t:1527873260502};\\\", \\\"{x:1374,y:873,t:1527873260520};\\\", \\\"{x:1372,y:867,t:1527873260537};\\\", \\\"{x:1370,y:862,t:1527873260552};\\\", \\\"{x:1367,y:856,t:1527873260570};\\\", \\\"{x:1364,y:847,t:1527873260587};\\\", \\\"{x:1364,y:843,t:1527873260603};\\\", \\\"{x:1363,y:837,t:1527873260620};\\\", \\\"{x:1363,y:833,t:1527873260636};\\\", \\\"{x:1362,y:828,t:1527873260652};\\\", \\\"{x:1360,y:824,t:1527873260670};\\\", \\\"{x:1359,y:820,t:1527873260686};\\\", \\\"{x:1357,y:815,t:1527873260703};\\\", \\\"{x:1355,y:809,t:1527873260719};\\\", \\\"{x:1353,y:806,t:1527873260736};\\\", \\\"{x:1352,y:803,t:1527873260754};\\\", \\\"{x:1348,y:796,t:1527873260769};\\\", \\\"{x:1345,y:789,t:1527873260787};\\\", \\\"{x:1343,y:786,t:1527873260804};\\\", \\\"{x:1340,y:782,t:1527873260820};\\\", \\\"{x:1338,y:780,t:1527873260837};\\\", \\\"{x:1337,y:777,t:1527873260854};\\\", \\\"{x:1336,y:775,t:1527873260870};\\\", \\\"{x:1334,y:773,t:1527873260886};\\\", \\\"{x:1333,y:770,t:1527873260904};\\\", \\\"{x:1332,y:768,t:1527873260921};\\\", \\\"{x:1331,y:766,t:1527873260937};\\\", \\\"{x:1330,y:764,t:1527873260954};\\\", \\\"{x:1330,y:762,t:1527873260970};\\\", \\\"{x:1330,y:761,t:1527873260986};\\\", \\\"{x:1330,y:762,t:1527873261195};\\\", \\\"{x:1330,y:764,t:1527873261204};\\\", \\\"{x:1329,y:767,t:1527873261221};\\\", \\\"{x:1328,y:769,t:1527873261237};\\\", \\\"{x:1327,y:772,t:1527873261255};\\\", \\\"{x:1326,y:774,t:1527873261270};\\\", \\\"{x:1326,y:776,t:1527873261288};\\\", \\\"{x:1326,y:777,t:1527873261305};\\\", \\\"{x:1326,y:779,t:1527873261323};\\\", \\\"{x:1325,y:779,t:1527873261419};\\\", \\\"{x:1325,y:777,t:1527873261451};\\\", \\\"{x:1325,y:776,t:1527873261459};\\\", \\\"{x:1326,y:776,t:1527873261472};\\\", \\\"{x:1329,y:772,t:1527873261488};\\\", \\\"{x:1331,y:770,t:1527873261505};\\\", \\\"{x:1332,y:768,t:1527873261522};\\\", \\\"{x:1332,y:767,t:1527873261538};\\\", \\\"{x:1334,y:766,t:1527873261554};\\\", \\\"{x:1334,y:764,t:1527873261571};\\\", \\\"{x:1336,y:762,t:1527873261589};\\\", \\\"{x:1337,y:762,t:1527873261605};\\\", \\\"{x:1337,y:760,t:1527873261622};\\\", \\\"{x:1339,y:759,t:1527873261639};\\\", \\\"{x:1340,y:759,t:1527873261852};\\\", \\\"{x:1341,y:759,t:1527873261875};\\\", \\\"{x:1344,y:758,t:1527873263267};\\\", \\\"{x:1345,y:756,t:1527873263274};\\\", \\\"{x:1354,y:743,t:1527873263291};\\\", \\\"{x:1362,y:729,t:1527873263308};\\\", \\\"{x:1368,y:715,t:1527873263325};\\\", \\\"{x:1370,y:708,t:1527873263342};\\\", \\\"{x:1372,y:703,t:1527873263357};\\\", \\\"{x:1372,y:702,t:1527873263375};\\\", \\\"{x:1373,y:699,t:1527873263392};\\\", \\\"{x:1373,y:697,t:1527873263409};\\\", \\\"{x:1373,y:694,t:1527873263425};\\\", \\\"{x:1372,y:692,t:1527873263442};\\\", \\\"{x:1371,y:690,t:1527873263459};\\\", \\\"{x:1370,y:689,t:1527873263475};\\\", \\\"{x:1369,y:688,t:1527873263499};\\\", \\\"{x:1368,y:688,t:1527873263523};\\\", \\\"{x:1366,y:688,t:1527873263531};\\\", \\\"{x:1362,y:688,t:1527873263547};\\\", \\\"{x:1359,y:688,t:1527873263559};\\\", \\\"{x:1350,y:690,t:1527873263575};\\\", \\\"{x:1342,y:694,t:1527873263592};\\\", \\\"{x:1338,y:695,t:1527873263608};\\\", \\\"{x:1336,y:697,t:1527873263626};\\\", \\\"{x:1335,y:697,t:1527873263731};\\\", \\\"{x:1333,y:699,t:1527873263787};\\\", \\\"{x:1333,y:700,t:1527873263835};\\\", \\\"{x:1332,y:700,t:1527873264060};\\\", \\\"{x:1312,y:700,t:1527873264076};\\\", \\\"{x:1273,y:696,t:1527873264093};\\\", \\\"{x:1212,y:679,t:1527873264112};\\\", \\\"{x:1167,y:664,t:1527873264126};\\\", \\\"{x:1122,y:650,t:1527873264142};\\\", \\\"{x:1064,y:637,t:1527873264160};\\\", \\\"{x:1017,y:623,t:1527873264176};\\\", \\\"{x:978,y:614,t:1527873264192};\\\", \\\"{x:962,y:608,t:1527873264210};\\\", \\\"{x:951,y:603,t:1527873264225};\\\", \\\"{x:941,y:597,t:1527873264242};\\\", \\\"{x:926,y:588,t:1527873264259};\\\", \\\"{x:912,y:582,t:1527873264276};\\\", \\\"{x:898,y:576,t:1527873264300};\\\", \\\"{x:890,y:569,t:1527873264317};\\\", \\\"{x:886,y:564,t:1527873264333};\\\", \\\"{x:886,y:560,t:1527873264350};\\\", \\\"{x:884,y:555,t:1527873264366};\\\", \\\"{x:882,y:549,t:1527873264383};\\\", \\\"{x:880,y:547,t:1527873264400};\\\", \\\"{x:880,y:545,t:1527873264416};\\\", \\\"{x:878,y:541,t:1527873264434};\\\", \\\"{x:876,y:536,t:1527873264451};\\\", \\\"{x:874,y:532,t:1527873264467};\\\", \\\"{x:872,y:529,t:1527873264483};\\\", \\\"{x:869,y:525,t:1527873264500};\\\", \\\"{x:867,y:523,t:1527873264517};\\\", \\\"{x:865,y:521,t:1527873264533};\\\", \\\"{x:863,y:520,t:1527873264550};\\\", \\\"{x:862,y:520,t:1527873264567};\\\", \\\"{x:861,y:520,t:1527873264583};\\\", \\\"{x:860,y:520,t:1527873264600};\\\", \\\"{x:858,y:519,t:1527873264642};\\\", \\\"{x:857,y:519,t:1527873264659};\\\", \\\"{x:856,y:519,t:1527873264668};\\\", \\\"{x:855,y:519,t:1527873264683};\\\", \\\"{x:853,y:519,t:1527873264700};\\\", \\\"{x:852,y:519,t:1527873264730};\\\", \\\"{x:851,y:519,t:1527873264738};\\\", \\\"{x:850,y:519,t:1527873264754};\\\", \\\"{x:849,y:519,t:1527873264778};\\\", \\\"{x:848,y:519,t:1527873264787};\\\", \\\"{x:846,y:519,t:1527873264803};\\\", \\\"{x:845,y:520,t:1527873264817};\\\", \\\"{x:844,y:520,t:1527873264834};\\\", \\\"{x:843,y:520,t:1527873264851};\\\", \\\"{x:842,y:521,t:1527873264915};\\\", \\\"{x:841,y:521,t:1527873264939};\\\", \\\"{x:840,y:522,t:1527873264971};\\\", \\\"{x:840,y:523,t:1527873264986};\\\", \\\"{x:839,y:523,t:1527873265000};\\\", \\\"{x:838,y:524,t:1527873265035};\\\", \\\"{x:837,y:525,t:1527873265075};\\\", \\\"{x:836,y:526,t:1527873265098};\\\", \\\"{x:835,y:526,t:1527873265115};\\\", \\\"{x:835,y:527,t:1527873265195};\\\", \\\"{x:834,y:528,t:1527873265211};\\\", \\\"{x:834,y:529,t:1527873265299};\\\", \\\"{x:834,y:530,t:1527873265451};\\\", \\\"{x:835,y:530,t:1527873265475};\\\", \\\"{x:836,y:530,t:1527873265490};\\\", \\\"{x:836,y:528,t:1527873265523};\\\", \\\"{x:836,y:527,t:1527873265564};\\\", \\\"{x:836,y:525,t:1527873265611};\\\", \\\"{x:836,y:524,t:1527873265642};\\\", \\\"{x:836,y:522,t:1527873265667};\\\", \\\"{x:835,y:520,t:1527873265691};\\\", \\\"{x:834,y:519,t:1527873265746};\\\", \\\"{x:833,y:517,t:1527873265779};\\\", \\\"{x:833,y:519,t:1527873266058};\\\", \\\"{x:838,y:523,t:1527873266067};\\\", \\\"{x:852,y:535,t:1527873266084};\\\", \\\"{x:876,y:548,t:1527873266101};\\\", \\\"{x:914,y:562,t:1527873266117};\\\", \\\"{x:959,y:585,t:1527873266136};\\\", \\\"{x:1022,y:608,t:1527873266152};\\\", \\\"{x:1085,y:636,t:1527873266168};\\\", \\\"{x:1139,y:663,t:1527873266185};\\\", \\\"{x:1200,y:704,t:1527873266201};\\\", \\\"{x:1265,y:752,t:1527873266218};\\\", \\\"{x:1292,y:774,t:1527873266235};\\\", \\\"{x:1311,y:789,t:1527873266251};\\\", \\\"{x:1326,y:803,t:1527873266268};\\\", \\\"{x:1336,y:815,t:1527873266285};\\\", \\\"{x:1343,y:825,t:1527873266302};\\\", \\\"{x:1350,y:836,t:1527873266319};\\\", \\\"{x:1359,y:847,t:1527873266336};\\\", \\\"{x:1367,y:852,t:1527873266352};\\\", \\\"{x:1372,y:853,t:1527873266369};\\\", \\\"{x:1376,y:853,t:1527873266386};\\\", \\\"{x:1382,y:853,t:1527873266402};\\\", \\\"{x:1393,y:855,t:1527873266419};\\\", \\\"{x:1397,y:855,t:1527873266436};\\\", \\\"{x:1399,y:854,t:1527873266452};\\\", \\\"{x:1399,y:849,t:1527873266468};\\\", \\\"{x:1399,y:843,t:1527873266486};\\\", \\\"{x:1397,y:837,t:1527873266502};\\\", \\\"{x:1393,y:829,t:1527873266519};\\\", \\\"{x:1390,y:824,t:1527873266536};\\\", \\\"{x:1388,y:822,t:1527873266552};\\\", \\\"{x:1386,y:817,t:1527873266568};\\\", \\\"{x:1385,y:812,t:1527873266586};\\\", \\\"{x:1384,y:808,t:1527873266602};\\\", \\\"{x:1381,y:798,t:1527873266619};\\\", \\\"{x:1377,y:788,t:1527873266636};\\\", \\\"{x:1377,y:783,t:1527873266652};\\\", \\\"{x:1376,y:778,t:1527873266669};\\\", \\\"{x:1374,y:773,t:1527873266686};\\\", \\\"{x:1373,y:770,t:1527873266702};\\\", \\\"{x:1372,y:768,t:1527873266719};\\\", \\\"{x:1372,y:764,t:1527873266736};\\\", \\\"{x:1372,y:760,t:1527873266752};\\\", \\\"{x:1370,y:755,t:1527873266769};\\\", \\\"{x:1369,y:753,t:1527873266786};\\\", \\\"{x:1369,y:752,t:1527873266802};\\\", \\\"{x:1369,y:751,t:1527873267163};\\\", \\\"{x:1369,y:749,t:1527873267171};\\\", \\\"{x:1369,y:746,t:1527873267186};\\\", \\\"{x:1369,y:740,t:1527873267203};\\\", \\\"{x:1369,y:738,t:1527873267219};\\\", \\\"{x:1369,y:736,t:1527873267236};\\\", \\\"{x:1369,y:735,t:1527873267252};\\\", \\\"{x:1369,y:734,t:1527873267268};\\\", \\\"{x:1368,y:732,t:1527873267286};\\\", \\\"{x:1366,y:729,t:1527873267302};\\\", \\\"{x:1366,y:727,t:1527873267318};\\\", \\\"{x:1363,y:723,t:1527873267336};\\\", \\\"{x:1361,y:718,t:1527873267352};\\\", \\\"{x:1358,y:713,t:1527873267369};\\\", \\\"{x:1357,y:710,t:1527873267385};\\\", \\\"{x:1355,y:707,t:1527873267402};\\\", \\\"{x:1355,y:706,t:1527873267434};\\\", \\\"{x:1355,y:705,t:1527873267458};\\\", \\\"{x:1355,y:704,t:1527873267468};\\\", \\\"{x:1355,y:703,t:1527873268291};\\\", \\\"{x:1354,y:703,t:1527873268303};\\\", \\\"{x:1354,y:706,t:1527873268320};\\\", \\\"{x:1354,y:709,t:1527873268336};\\\", \\\"{x:1352,y:711,t:1527873268353};\\\", \\\"{x:1352,y:713,t:1527873268386};\\\", \\\"{x:1352,y:714,t:1527873268419};\\\", \\\"{x:1352,y:716,t:1527873268436};\\\", \\\"{x:1352,y:718,t:1527873268454};\\\", \\\"{x:1352,y:719,t:1527873268470};\\\", \\\"{x:1352,y:720,t:1527873268487};\\\", \\\"{x:1351,y:720,t:1527873270988};\\\", \\\"{x:1351,y:719,t:1527873271010};\\\", \\\"{x:1350,y:719,t:1527873271275};\\\", \\\"{x:1349,y:720,t:1527873271291};\\\", \\\"{x:1349,y:723,t:1527873271304};\\\", \\\"{x:1349,y:732,t:1527873271321};\\\", \\\"{x:1355,y:752,t:1527873271339};\\\", \\\"{x:1360,y:769,t:1527873271355};\\\", \\\"{x:1368,y:787,t:1527873271371};\\\", \\\"{x:1379,y:806,t:1527873271388};\\\", \\\"{x:1389,y:824,t:1527873271404};\\\", \\\"{x:1404,y:845,t:1527873271421};\\\", \\\"{x:1419,y:865,t:1527873271438};\\\", \\\"{x:1438,y:888,t:1527873271454};\\\", \\\"{x:1451,y:907,t:1527873271471};\\\", \\\"{x:1463,y:929,t:1527873271488};\\\", \\\"{x:1471,y:944,t:1527873271505};\\\", \\\"{x:1480,y:957,t:1527873271522};\\\", \\\"{x:1493,y:973,t:1527873271539};\\\", \\\"{x:1496,y:977,t:1527873271554};\\\", \\\"{x:1497,y:978,t:1527873271570};\\\", \\\"{x:1498,y:979,t:1527873271588};\\\", \\\"{x:1498,y:980,t:1527873271643};\\\", \\\"{x:1500,y:981,t:1527873271654};\\\", \\\"{x:1501,y:982,t:1527873271674};\\\", \\\"{x:1502,y:983,t:1527873271689};\\\", \\\"{x:1503,y:984,t:1527873271704};\\\", \\\"{x:1502,y:984,t:1527873271867};\\\", \\\"{x:1500,y:984,t:1527873271875};\\\", \\\"{x:1499,y:984,t:1527873272107};\\\", \\\"{x:1499,y:983,t:1527873272122};\\\", \\\"{x:1499,y:982,t:1527873272266};\\\", \\\"{x:1499,y:981,t:1527873272281};\\\", \\\"{x:1499,y:980,t:1527873272337};\\\", \\\"{x:1499,y:979,t:1527873272354};\\\", \\\"{x:1499,y:977,t:1527873272371};\\\", \\\"{x:1499,y:975,t:1527873272388};\\\", \\\"{x:1499,y:974,t:1527873272405};\\\", \\\"{x:1498,y:971,t:1527873272421};\\\", \\\"{x:1497,y:969,t:1527873272438};\\\", \\\"{x:1495,y:967,t:1527873272456};\\\", \\\"{x:1493,y:965,t:1527873272471};\\\", \\\"{x:1493,y:964,t:1527873272491};\\\", \\\"{x:1493,y:962,t:1527873272515};\\\", \\\"{x:1492,y:961,t:1527873272523};\\\", \\\"{x:1491,y:958,t:1527873272538};\\\", \\\"{x:1489,y:957,t:1527873272556};\\\", \\\"{x:1489,y:954,t:1527873272571};\\\", \\\"{x:1488,y:954,t:1527873273476};\\\", \\\"{x:1487,y:954,t:1527873273499};\\\", \\\"{x:1486,y:954,t:1527873273652};\\\", \\\"{x:1485,y:954,t:1527873273667};\\\", \\\"{x:1484,y:954,t:1527873273716};\\\", \\\"{x:1483,y:955,t:1527873273738};\\\", \\\"{x:1482,y:955,t:1527873273771};\\\", \\\"{x:1480,y:955,t:1527873277059};\\\", \\\"{x:1473,y:955,t:1527873277073};\\\", \\\"{x:1424,y:943,t:1527873277091};\\\", \\\"{x:1354,y:922,t:1527873277107};\\\", \\\"{x:1269,y:899,t:1527873277124};\\\", \\\"{x:1198,y:871,t:1527873277141};\\\", \\\"{x:1135,y:849,t:1527873277157};\\\", \\\"{x:1094,y:823,t:1527873277173};\\\", \\\"{x:1050,y:798,t:1527873277190};\\\", \\\"{x:1008,y:770,t:1527873277207};\\\", \\\"{x:972,y:746,t:1527873277224};\\\", \\\"{x:948,y:730,t:1527873277240};\\\", \\\"{x:928,y:718,t:1527873277257};\\\", \\\"{x:908,y:703,t:1527873277272};\\\", \\\"{x:884,y:683,t:1527873277289};\\\", \\\"{x:868,y:669,t:1527873277307};\\\", \\\"{x:857,y:662,t:1527873277323};\\\", \\\"{x:846,y:656,t:1527873277339};\\\", \\\"{x:832,y:648,t:1527873277357};\\\", \\\"{x:812,y:638,t:1527873277373};\\\", \\\"{x:792,y:630,t:1527873277389};\\\", \\\"{x:770,y:621,t:1527873277407};\\\", \\\"{x:737,y:609,t:1527873277428};\\\", \\\"{x:720,y:599,t:1527873277444};\\\", \\\"{x:705,y:588,t:1527873277460};\\\", \\\"{x:691,y:578,t:1527873277476};\\\", \\\"{x:682,y:570,t:1527873277494};\\\", \\\"{x:675,y:561,t:1527873277511};\\\", \\\"{x:664,y:552,t:1527873277526};\\\", \\\"{x:648,y:541,t:1527873277543};\\\", \\\"{x:641,y:534,t:1527873277561};\\\", \\\"{x:637,y:529,t:1527873277577};\\\", \\\"{x:630,y:519,t:1527873277595};\\\", \\\"{x:626,y:514,t:1527873277610};\\\", \\\"{x:625,y:512,t:1527873277628};\\\", \\\"{x:623,y:509,t:1527873277644};\\\", \\\"{x:622,y:508,t:1527873277660};\\\", \\\"{x:621,y:506,t:1527873277677};\\\", \\\"{x:620,y:506,t:1527873277694};\\\", \\\"{x:619,y:506,t:1527873277746};\\\", \\\"{x:618,y:506,t:1527873277761};\\\", \\\"{x:617,y:506,t:1527873277778};\\\", \\\"{x:612,y:510,t:1527873277796};\\\", \\\"{x:611,y:515,t:1527873277812};\\\", \\\"{x:609,y:519,t:1527873277829};\\\", \\\"{x:607,y:520,t:1527873277845};\\\", \\\"{x:607,y:521,t:1527873278555};\\\", \\\"{x:606,y:521,t:1527873278563};\\\", \\\"{x:606,y:525,t:1527873278581};\\\", \\\"{x:606,y:527,t:1527873278596};\\\", \\\"{x:606,y:528,t:1527873278614};\\\", \\\"{x:606,y:530,t:1527873278859};\\\", \\\"{x:606,y:531,t:1527873278914};\\\", \\\"{x:605,y:532,t:1527873279188};\\\", \\\"{x:605,y:533,t:1527873279211};\\\", \\\"{x:604,y:533,t:1527873279218};\\\", \\\"{x:603,y:534,t:1527873279242};\\\", \\\"{x:601,y:534,t:1527873279258};\\\", \\\"{x:600,y:534,t:1527873279538};\\\", \\\"{x:600,y:535,t:1527873279561};\\\", \\\"{x:598,y:536,t:1527873279627};\\\", \\\"{x:597,y:537,t:1527873279667};\\\", \\\"{x:596,y:538,t:1527873279915};\\\", \\\"{x:595,y:538,t:1527873280011};\\\", \\\"{x:594,y:538,t:1527873280035};\\\", \\\"{x:593,y:539,t:1527873280053};\\\", \\\"{x:592,y:539,t:1527873280067};\\\", \\\"{x:591,y:540,t:1527873280113};\\\", \\\"{x:590,y:540,t:1527873280130};\\\", \\\"{x:589,y:541,t:1527873280145};\\\", \\\"{x:588,y:541,t:1527873280170};\\\", \\\"{x:587,y:542,t:1527873280193};\\\", \\\"{x:586,y:542,t:1527873280201};\\\", \\\"{x:585,y:543,t:1527873280218};\\\", \\\"{x:584,y:543,t:1527873280234};\\\", \\\"{x:584,y:544,t:1527873280246};\\\", \\\"{x:582,y:544,t:1527873280265};\\\", \\\"{x:581,y:544,t:1527873280290};\\\", \\\"{x:580,y:546,t:1527873280339};\\\", \\\"{x:579,y:546,t:1527873280347};\\\", \\\"{x:576,y:548,t:1527873280363};\\\", \\\"{x:570,y:555,t:1527873280380};\\\", \\\"{x:563,y:567,t:1527873280397};\\\", \\\"{x:552,y:580,t:1527873280415};\\\", \\\"{x:538,y:596,t:1527873280430};\\\", \\\"{x:524,y:615,t:1527873280446};\\\", \\\"{x:512,y:632,t:1527873280463};\\\", \\\"{x:504,y:643,t:1527873280480};\\\", \\\"{x:500,y:648,t:1527873280496};\\\", \\\"{x:496,y:652,t:1527873280513};\\\", \\\"{x:487,y:662,t:1527873280529};\\\", \\\"{x:482,y:672,t:1527873280547};\\\", \\\"{x:478,y:677,t:1527873280562};\\\", \\\"{x:473,y:683,t:1527873280579};\\\", \\\"{x:471,y:687,t:1527873280597};\\\", \\\"{x:469,y:695,t:1527873280613};\\\", \\\"{x:469,y:702,t:1527873280630};\\\", \\\"{x:469,y:708,t:1527873280647};\\\", \\\"{x:469,y:711,t:1527873280663};\\\", \\\"{x:469,y:718,t:1527873280680};\\\", \\\"{x:473,y:724,t:1527873280696};\\\", \\\"{x:477,y:734,t:1527873280714};\\\", \\\"{x:485,y:743,t:1527873280730};\\\", \\\"{x:486,y:744,t:1527873280747};\\\", \\\"{x:488,y:746,t:1527873280763};\\\", \\\"{x:489,y:746,t:1527873280843};\\\", \\\"{x:490,y:746,t:1527873280889};\\\", \\\"{x:491,y:748,t:1527873280906};\\\" ] }, { \\\"rt\\\": 55731, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 524748, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"On the x axis of the graph, look where 12 pm is. Go straight up from 12 pm and the shifts that are there start at 12 pm\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 9235, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 534990, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 11846, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 547858, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 15228, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 564400, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"ZAOCZ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2766}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":5,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":6,\"textContent\":\" \"},{\"nodeType\":1,\"id\":7,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":8,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":9,\"textContent\":\" \"},{\"nodeType\":8,\"id\":10},{\"nodeType\":3,\"id\":11,\"textContent\":\" \"},{\"nodeType\":1,\"id\":12,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":13,\"textContent\":\" \"},{\"nodeType\":1,\"id\":14,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":15,\"textContent\":\" \"},{\"nodeType\":1,\"id\":16,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":17,\"textContent\":\" \"},{\"nodeType\":1,\"id\":18,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":19,\"textContent\":\" \"},{\"nodeType\":1,\"id\":20,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":21,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":22,\"textContent\":\" \"},{\"nodeType\":8,\"id\":23},{\"nodeType\":3,\"id\":24,\"textContent\":\" \"},{\"nodeType\":1,\"id\":25,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":26,\"textContent\":\" \"},{\"nodeType\":1,\"id\":27,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":28,\"textContent\":\" \"},{\"nodeType\":1,\"id\":29,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":30,\"textContent\":\" \"},{\"nodeType\":1,\"id\":31,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":32,\"textContent\":\" \"},{\"nodeType\":1,\"id\":33,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":34,\"textContent\":\" \"},{\"nodeType\":1,\"id\":35,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":36,\"textContent\":\" \"},{\"nodeType\":1,\"id\":37,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":38,\"textContent\":\" \"},{\"nodeType\":8,\"id\":39},{\"nodeType\":3,\"id\":40,\"textContent\":\" \"},{\"nodeType\":1,\"id\":41,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":42,\"textContent\":\" \"},{\"nodeType\":8,\"id\":43},{\"nodeType\":3,\"id\":44,\"textContent\":\" \"},{\"nodeType\":8,\"id\":45},{\"nodeType\":3,\"id\":46,\"textContent\":\" \"},{\"nodeType\":1,\"id\":47,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":48,\"textContent\":\" \"},{\"nodeType\":1,\"id\":49,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":50,\"textContent\":\" \"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":52,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":53,\"textContent\":\" \"},{\"nodeType\":8,\"id\":54},{\"nodeType\":3,\"id\":55,\"textContent\":\" \"},{\"nodeType\":1,\"id\":56,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":57,\"textContent\":\" \"},{\"nodeType\":1,\"id\":58,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":59,\"textContent\":\" \"},{\"nodeType\":8,\"id\":60},{\"nodeType\":3,\"id\":61,\"textContent\":\" \"},{\"nodeType\":1,\"id\":62,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":63,\"textContent\":\" \"},{\"nodeType\":1,\"id\":64,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":65,\"textContent\":\" \"},{\"nodeType\":1,\"id\":66,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":67,\"textContent\":\" \"},{\"nodeType\":1,\"id\":68,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":69,\"textContent\":\" \"},{\"nodeType\":1,\"id\":70,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":71,\"textContent\":\" \"},{\"nodeType\":1,\"id\":72,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":73,\"textContent\":\" \"},{\"nodeType\":1,\"id\":74,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":75,\"textContent\":\" \"},{\"nodeType\":1,\"id\":76,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":77,\"textContent\":\"ZAOCZ\"}]},{\"nodeType\":3,\"id\":78,\"textContent\":\" \"},{\"nodeType\":1,\"id\":79,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":80,\"textContent\":\" \"},{\"nodeType\":8,\"id\":81},{\"nodeType\":3,\"id\":82,\"textContent\":\" \"},{\"nodeType\":1,\"id\":83,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":84,\"textContent\":\" \"},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":86,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":88,\"textContent\":\" \"},{\"nodeType\":8,\"id\":89},{\"nodeType\":3,\"id\":90,\"textContent\":\" \"},{\"nodeType\":8,\"id\":91},{\"nodeType\":3,\"id\":92,\"textContent\":\" \"},{\"nodeType\":1,\"id\":93,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":94,\"textContent\":\" \"},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":96,\"textContent\":\" \"},{\"nodeType\":1,\"id\":97,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":98,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":99,\"textContent\":\" \"},{\"nodeType\":1,\"id\":100,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":106,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":114,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":122,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":130,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":138,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":146,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":154,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":162,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":170,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":178,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":186,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":197,\"textContent\":\" \"},{\"nodeType\":1,\"id\":198,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":199,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":201,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":202,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":203,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":205,\"textContent\":\" \"},{\"nodeType\":1,\"id\":206,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":207,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":208,\"textContent\":\" \"},{\"nodeType\":1,\"id\":209,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":210,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":211,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":213,\"textContent\":\" \"},{\"nodeType\":1,\"id\":214,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":215,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":216,\"textContent\":\" \"},{\"nodeType\":1,\"id\":217,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":218,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":219,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":224,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":226,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":227,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":228,\"textContent\":\" \"},{\"nodeType\":1,\"id\":229,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":235,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":243,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":251,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":259,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":267,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":275,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":283,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":291,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":299,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":307,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":315,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":323,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":331,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":339,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":347,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":356,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":364,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":372,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":380,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":388,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":396,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":404,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":412,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":420,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":428,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":444,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":452,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":460,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":468,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":476,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":481,\"textContent\":\" \"},{\"nodeType\":1,\"id\":482,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":483,\"textContent\":\" \"},{\"nodeType\":1,\"id\":484,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":485,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":486,\"textContent\":\" \"},{\"nodeType\":1,\"id\":487,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":488,\"textContent\":\" \"},{\"nodeType\":1,\"id\":489,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":490,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":491,\"textContent\":\" \"},{\"nodeType\":1,\"id\":492,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":493,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":494,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":496,\"textContent\":\" \"},{\"nodeType\":1,\"id\":497,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":498,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":499,\"textContent\":\" \"},{\"nodeType\":1,\"id\":500,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":501,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":502,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":504,\"textContent\":\" \"},{\"nodeType\":1,\"id\":505,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":506,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":508,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":509,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":510,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":517,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":525,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":533,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":541,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":549,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":557,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":565,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":573,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":581,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":589,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":597,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":605,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":610,\"textContent\":\" \"},{\"nodeType\":1,\"id\":611,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":612,\"textContent\":\" \"},{\"nodeType\":1,\"id\":613,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":614,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":615,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":616,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":617,\"textContent\":\" \"},{\"nodeType\":1,\"id\":618,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":620,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":621,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":622,\"textContent\":\" \"},{\"nodeType\":1,\"id\":623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":624,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":625,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":628,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":630,\"textContent\":\" \"},{\"nodeType\":1,\"id\":631,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":632,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":633,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":636,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":638,\"textContent\":\" \"},{\"nodeType\":1,\"id\":639,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":640,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":641,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":644,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":645,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":646,\"textContent\":\" \"},{\"nodeType\":1,\"id\":647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":648,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":649,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":652,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":653,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":654,\"textContent\":\" \"},{\"nodeType\":1,\"id\":655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":656,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":657,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":659,\"textContent\":\" \"},{\"nodeType\":1,\"id\":660,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":662,\"textContent\":\" \"},{\"nodeType\":1,\"id\":663,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":664,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":665,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":667,\"textContent\":\" \"},{\"nodeType\":1,\"id\":668,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":670,\"textContent\":\" \"},{\"nodeType\":1,\"id\":671,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":672,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":673,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":675,\"textContent\":\" \"},{\"nodeType\":1,\"id\":676,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":677,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":678,\"textContent\":\" \"},{\"nodeType\":1,\"id\":679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":680,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":681,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":683,\"textContent\":\" \"},{\"nodeType\":1,\"id\":684,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":685,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":686,\"textContent\":\" \"},{\"nodeType\":1,\"id\":687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":688,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":689,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":691,\"textContent\":\" \"},{\"nodeType\":1,\"id\":692,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":694,\"textContent\":\" \"},{\"nodeType\":1,\"id\":695,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":696,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":697,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":699,\"textContent\":\" \"},{\"nodeType\":1,\"id\":700,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":702,\"textContent\":\" \"},{\"nodeType\":1,\"id\":703,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":704,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":705,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":707,\"textContent\":\" \"},{\"nodeType\":1,\"id\":708,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":710,\"textContent\":\" \"},{\"nodeType\":1,\"id\":711,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":712,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":713,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":715,\"textContent\":\" \"},{\"nodeType\":1,\"id\":716,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":718,\"textContent\":\" \"},{\"nodeType\":1,\"id\":719,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":720,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":723,\"textContent\":\" \"},{\"nodeType\":1,\"id\":724,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":725,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":726,\"textContent\":\" \"},{\"nodeType\":1,\"id\":727,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":728,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":731,\"textContent\":\" \"},{\"nodeType\":1,\"id\":732,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":733,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":734,\"textContent\":\" \"},{\"nodeType\":1,\"id\":735,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":736,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":737,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":741,\"textContent\":\" \"},{\"nodeType\":1,\"id\":742,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":743,\"textContent\":\" \"},{\"nodeType\":1,\"id\":744,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":745,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":746,\"textContent\":\" \"},{\"nodeType\":1,\"id\":747,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":749,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":750,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":751,\"textContent\":\" \"},{\"nodeType\":1,\"id\":752,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":753,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":754,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":757,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":758,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":759,\"textContent\":\" \"},{\"nodeType\":1,\"id\":760,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":761,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":762,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":765,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":766,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":767,\"textContent\":\" \"},{\"nodeType\":1,\"id\":768,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":769,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":770,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":773,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":774,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":775,\"textContent\":\" \"},{\"nodeType\":1,\"id\":776,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":777,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":778,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":781,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":782,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":783,\"textContent\":\" \"},{\"nodeType\":1,\"id\":784,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":785,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":786,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":789,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":790,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":791,\"textContent\":\" \"},{\"nodeType\":1,\"id\":792,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":793,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":794,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":797,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":798,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":799,\"textContent\":\" \"},{\"nodeType\":1,\"id\":800,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":801,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":802,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":805,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":806,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":807,\"textContent\":\" \"},{\"nodeType\":1,\"id\":808,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":809,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":810,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":812,\"textContent\":\" \"},{\"nodeType\":1,\"id\":813,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":814,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":815,\"textContent\":\" \"},{\"nodeType\":1,\"id\":816,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":817,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":818,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":820,\"textContent\":\" \"},{\"nodeType\":1,\"id\":821,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":822,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":823,\"textContent\":\" \"},{\"nodeType\":1,\"id\":824,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":825,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":826,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":828,\"textContent\":\" \"},{\"nodeType\":1,\"id\":829,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":830,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":831,\"textContent\":\" \"},{\"nodeType\":1,\"id\":832,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":833,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":834,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":836,\"textContent\":\" \"},{\"nodeType\":1,\"id\":837,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":838,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":839,\"textContent\":\" \"},{\"nodeType\":1,\"id\":840,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":841,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":842,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":844,\"textContent\":\" \"},{\"nodeType\":1,\"id\":845,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":846,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":847,\"textContent\":\" \"},{\"nodeType\":1,\"id\":848,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":849,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":850,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":852,\"textContent\":\" \"},{\"nodeType\":1,\"id\":853,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":854,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":855,\"textContent\":\" \"},{\"nodeType\":1,\"id\":856,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":857,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":858,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":860,\"textContent\":\" \"},{\"nodeType\":1,\"id\":861,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":862,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":863,\"textContent\":\" \"},{\"nodeType\":1,\"id\":864,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":865,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":866,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":868,\"textContent\":\" \"},{\"nodeType\":1,\"id\":869,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":870,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":871,\"textContent\":\" \"},{\"nodeType\":1,\"id\":872,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":873,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":874,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":876,\"textContent\":\" \"},{\"nodeType\":1,\"id\":877,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":878,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":879,\"textContent\":\" \"},{\"nodeType\":1,\"id\":880,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":881,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":882,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":884,\"textContent\":\" \"},{\"nodeType\":1,\"id\":885,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":886,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":887,\"textContent\":\" \"},{\"nodeType\":1,\"id\":888,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":889,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":890,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":894,\"textContent\":\" \"},{\"nodeType\":1,\"id\":895,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":896,\"textContent\":\" \"},{\"nodeType\":1,\"id\":897,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":898,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":899,\"textContent\":\" \"},{\"nodeType\":1,\"id\":900,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":902,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":903,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":904,\"textContent\":\" \"},{\"nodeType\":1,\"id\":905,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":906,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":907,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":910,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":911,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":912,\"textContent\":\" \"},{\"nodeType\":1,\"id\":913,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":914,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":915,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":918,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":919,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":920,\"textContent\":\" \"},{\"nodeType\":1,\"id\":921,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":922,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":923,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":926,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":927,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":928,\"textContent\":\" \"},{\"nodeType\":1,\"id\":929,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":930,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":931,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":934,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":935,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":936,\"textContent\":\" \"},{\"nodeType\":1,\"id\":937,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":938,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":939,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":942,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":943,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":944,\"textContent\":\" \"},{\"nodeType\":1,\"id\":945,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":946,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":947,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":950,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":951,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":952,\"textContent\":\" \"},{\"nodeType\":1,\"id\":953,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":954,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":955,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":958,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":959,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":960,\"textContent\":\" \"},{\"nodeType\":1,\"id\":961,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":962,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":963,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":965,\"textContent\":\" \"},{\"nodeType\":1,\"id\":966,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":967,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":968,\"textContent\":\" \"},{\"nodeType\":1,\"id\":969,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":970,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":971,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":973,\"textContent\":\" \"},{\"nodeType\":1,\"id\":974,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":975,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":976,\"textContent\":\" \"},{\"nodeType\":1,\"id\":977,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":978,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":979,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":981,\"textContent\":\" \"},{\"nodeType\":1,\"id\":982,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":983,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":984,\"textContent\":\" \"},{\"nodeType\":1,\"id\":985,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":986,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":987,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":989,\"textContent\":\" \"},{\"nodeType\":1,\"id\":990,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":991,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":992,\"textContent\":\" \"},{\"nodeType\":1,\"id\":993,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":994,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":995,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":997,\"textContent\":\" \"},{\"nodeType\":1,\"id\":998,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":999,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1000,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1001,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1002,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1003,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1005,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1006,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1007,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1008,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1009,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1010,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1011,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1013,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1014,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1015,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1016,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1017,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1018,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1019,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1021,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1022,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1023,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1024,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1025,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1026,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1027,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1029,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1030,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1031,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1032,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1033,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1034,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1035,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1037,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1038,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1039,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1040,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1041,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1042,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1043,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1047,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1048,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1049,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1050,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1051,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1052,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1053,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1055,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1056,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1057,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1058,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1059,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1060,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1063,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1064,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1065,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1066,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1067,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1068,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1071,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1072,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1073,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1074,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1075,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1076,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1079,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1080,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1081,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1082,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1083,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1084,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1087,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1088,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1089,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1090,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1091,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1092,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1095,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1096,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1097,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1098,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1099,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1100,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1103,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1104,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1105,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1106,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1107,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1108,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1111,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1112,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1113,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1114,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1115,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1116,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1119,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1120,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1121,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1122,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1123,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1124,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1131,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1139,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1147,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1155,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1163,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1171,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1179,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1187,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1195,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1201,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1202,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1203,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1204,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1205,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1206,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1208,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1209,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1210,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1211,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1212,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1213,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1216,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1217,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1218,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1219,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1220,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1221,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1224,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1225,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1226,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1227,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1228,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1229,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1232,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1233,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1235,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1236,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1237,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1239,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1240,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1241,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1242,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1243,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1244,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1245,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1247,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1248,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1249,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1250,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1251,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1252,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1253,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1256,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1257,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1258,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1259,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1260,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1261,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1263,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1264,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1265,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1266,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1267,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1268,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1269,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1271,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1272,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1273,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1275,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1276,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1277,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1279,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1280,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1281,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1282,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1283,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1284,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1285,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1288,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1289,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1291,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1292,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1293,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1295,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1296,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1297,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1299,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1300,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1301,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1303,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1304,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1305,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1307,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1308,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1309,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1311,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1312,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1313,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1314,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1315,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1316,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1317,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1319,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1320,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1321,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1322,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1323,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1324,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1325,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1327,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1328,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1329,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1330,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1331,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1332,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1333,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1335,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1336,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1337,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1338,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1339,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1340,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1341,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1343,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1344,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1345,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1346,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1347,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1348,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1349,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1354,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1355,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1356,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1357,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1359,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1360,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1361,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1362,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1363,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1364,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1365,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1366,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1368,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1369,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1370,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1371,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1372,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1373,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1374,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1376,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1377,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1378,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1379,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1380,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1381,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1382,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1384,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1385,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1386,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1387,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1388,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1389,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1390,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1392,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1393,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1394,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1395,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1396,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1397,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1398,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1400,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1401,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1402,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1403,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1404,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1405,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1406,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1408,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1409,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1410,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1411,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1412,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1413,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1414,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1416,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1417,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1418,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1419,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1420,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1421,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1422,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1424,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1425,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1426,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1427,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1428,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1429,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1430,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1432,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1433,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1434,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1435,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1436,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1437,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1438,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1440,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1441,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1442,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1443,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1444,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1445,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1446,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1448,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1449,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1450,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1451,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1452,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1453,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1454,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1456,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1457,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1458,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1459,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1460,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1461,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1462,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1464,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1465,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1466,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1467,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1468,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1469,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1470,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1472,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1473,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1474,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1475,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1476,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1477,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1478,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1481,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1482,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1483,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1484,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1485,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1486,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1488,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1489,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1490,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1491,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1492,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1493,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1494,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1496,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1497,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1498,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1499,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1500,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1501,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1502,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1507,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1508,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1509,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1510,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1512,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1513,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1514,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1515,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1516,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1517,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1518,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1519,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1521,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1522,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1523,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1524,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1525,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1526,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1527,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1529,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1530,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1531,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1532,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1533,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1534,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1535,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1537,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1538,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1539,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1540,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1541,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1542,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1543,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1545,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1546,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1547,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1548,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1549,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1550,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1551,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1553,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1554,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1555,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1556,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1557,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1558,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1559,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1561,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1562,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1563,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1564,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1565,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1566,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1567,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1569,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1570,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1571,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1572,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1573,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1574,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1575,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1577,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1578,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1579,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1580,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1581,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1582,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1583,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1585,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1586,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1587,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1588,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1589,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1590,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1591,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1594,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1595,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1596,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1597,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1598,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1599,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1602,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1603,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1604,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1605,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1606,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1607,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1610,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1611,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1612,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1613,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1614,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1615,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1617,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1618,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1619,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1620,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1621,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1622,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1623,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1625,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1626,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1627,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1628,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1629,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1630,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1631,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1633,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1634,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1635,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1636,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1637,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1638,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1639,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1641,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1642,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1643,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1644,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1645,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1646,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1647,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1649,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1650,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1651,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1652,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1654,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1655,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1659,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1660,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1662,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1663,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1664,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1665,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1671,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1687,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1695,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1703,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1711,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1719,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1735,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1738,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1739,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1740,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1741,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1742,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1743,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1744,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1746,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1747,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1748,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1749,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1750,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1751,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1752,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1754,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1755,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1756,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1757,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1758,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1759,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1760,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1762,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1763,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1764,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1765,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1766,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1767,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1768,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1770,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1771,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1772,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1773,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1774,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1775,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1776,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1778,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1779,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1780,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1781,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1782,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1783,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1784,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1786,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1787,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1788,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1789,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1790,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1791,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1792,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1794,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1795,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1796,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1797,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1798,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1799,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1800,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1802,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1803,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1804,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1805,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1806,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1807,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1808,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1812,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1813,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1815,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1816,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1817,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1818,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1824,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1832,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1840,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1848,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1856,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1864,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1872,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1880,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1888,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1891,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1892,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1893,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1894,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1895,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1896,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1897,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1899,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1900,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1901,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1902,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1903,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1904,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1905,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1907,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1908,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1909,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1910,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1911,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1912,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1913,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1915,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1916,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1917,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1918,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1919,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1920,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1921,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1923,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1924,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1925,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1926,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1927,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1928,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1929,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1931,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1932,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1933,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1934,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1935,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1936,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1937,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1939,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1940,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1941,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1942,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1943,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1944,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1945,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1947,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1948,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1949,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1950,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1951,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1952,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1953,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1955,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1956,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1957,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1958,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1959,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1960,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1961,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1965,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1966,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1968,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1969,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1970,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1971,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1977,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1985,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1993,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2001,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2009,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2017,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2025,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2033,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2041,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2044,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2045,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2046,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2047,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2048,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2049,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2050,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2052,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2053,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2054,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2055,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2056,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2057,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2058,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2060,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2061,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2062,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2063,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2064,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2065,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2066,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2068,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2069,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2070,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2071,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2072,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2073,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2074,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2076,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2077,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2078,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2079,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2080,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2081,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2082,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2084,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2085,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2086,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2087,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2088,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2089,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2090,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2092,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2093,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2094,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2095,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2096,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2097,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2098,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2105,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2113,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2119,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2121,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2122,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2123,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2124,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2126,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2128,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2129,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2130,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2131,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2132,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2136,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2137,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2138,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2139,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2140,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2141,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2144,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2145,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2146,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2147,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2148,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2149,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2152,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2153,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2154,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2155,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2156,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2157,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2160,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2161,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2162,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2163,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2164,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2165,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2168,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2169,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2170,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2171,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2172,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2173,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2176,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2177,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2178,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2179,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2180,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2181,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2184,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2185,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2186,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2187,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2188,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2189,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2192,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2193,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2194,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2195,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2196,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2197,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2200,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2201,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2202,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2203,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2204,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2205,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2208,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2209,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2210,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2211,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2212,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2213,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2216,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2217,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2218,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2219,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2220,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2221,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2224,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2225,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2226,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2227,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2228,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2229,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2232,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2233,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2235,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2236,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2237,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2239,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2240,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2241,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2242,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2243,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2244,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2245,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2247,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2248,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2249,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2250,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2251,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2252,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2253,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2256,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2257,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2258,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2259,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2260,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2261,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2263,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2264,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2265,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2266,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2267,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2268,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2269,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2274,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2275,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2276,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2277,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2279,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2282,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2283},{\"nodeType\":3,\"id\":2284,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2285},{\"nodeType\":3,\"id\":2286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2287,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2289,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2290,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2291,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2292,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2293,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2296,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2297},{\"nodeType\":3,\"id\":2298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2304,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2305,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2306,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2307,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2308,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2309,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2310,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2311,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2313,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2315,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2317,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2319,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2321,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2323,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2325,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2327,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2329,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2331,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2333,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2335,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2337,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2339,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2341,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2345,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2346,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2349,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2350,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2353,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2354,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2357,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2358,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2361,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2362,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2365,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2366,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2369,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2370,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2373,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2374,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2377,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2378,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2381,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2382,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2385,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2386,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2389,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2390,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2393,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2394,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2395,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2396,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2397,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2398,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2399,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2400,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2401,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2402,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2403,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2404,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2405,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2406,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2407,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2408,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2409,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2410,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2411,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2412,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2413,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2414,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2415,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2416,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2417,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2418,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2419,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2420,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2422,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2424,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2426,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2428,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2430,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2432,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2434,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2435,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2436,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2438,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2439,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2440,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2442,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2444,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2446,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2447,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2448,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2450,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2454,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2455,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2456,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2458,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2459,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2460,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2461,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2462,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2463,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2464,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2465,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2468,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2469,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2470,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2471,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2472,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2473,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2474,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2475,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2476,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2478,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2480,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2482,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2484,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2486,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2489,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2491,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2518,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2520,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2521,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2522,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2524,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2526,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2528,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2530,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2532,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2534,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2536,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2538,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2540,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2544,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2545,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2548,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2549,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2552,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2553,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2556,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2557,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2560,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2561,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2564,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2565,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2568,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2569,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2572,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2573,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2576,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2577,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2578,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2579,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2580,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2581,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2582,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2583,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2584,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2585,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2586,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2587,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2588,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2590,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2591},{\"nodeType\":3,\"id\":2592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2593,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2595,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2596,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 299, dom: 907, initialDom: 999",
  "javascriptErrors": []
}