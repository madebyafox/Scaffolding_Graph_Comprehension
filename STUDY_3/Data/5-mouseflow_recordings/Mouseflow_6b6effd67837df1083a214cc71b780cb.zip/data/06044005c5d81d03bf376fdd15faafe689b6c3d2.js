var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06044005c5d81d03bf376fdd15faafe689b6c3d2"] = {
  "startTime": "2018-06-04T19:18:40.3739013Z",
  "websitePageUrl": "/16",
  "visitTime": 133149,
  "engagementTime": 130371,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "6b6effd67837df1083a214cc71b780cb",
    "created": "2018-06-04T19:18:40.3739013+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=1N65C",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "f467079f7423013e80defbc54486c149",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/6b6effd67837df1083a214cc71b780cb/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 240,
      "e": 240,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 535,
      "y": 755
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 49225,
      "y": 41381,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 533,
      "y": 752
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 480,
      "y": 677
    },
    {
      "t": 3945,
      "e": 3945,
      "ty": 6,
      "x": 427,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 407,
      "y": 569
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 34836,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 397,
      "y": 544
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 33712,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 397,
      "y": 564
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 397,
      "y": 568
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 33712,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5640,
      "e": 5640,
      "ty": 3,
      "x": 397,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5641,
      "e": 5641,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5783,
      "e": 5783,
      "ty": 4,
      "x": 33712,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5783,
      "e": 5783,
      "ty": 5,
      "x": 397,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11037,
      "e": 10783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11348,
      "e": 11094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11349,
      "e": 11095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11419,
      "e": 11165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "O"
    },
    {
      "t": 11443,
      "e": 11189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "O"
    },
    {
      "t": 11523,
      "e": 11269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 11524,
      "e": 11270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11611,
      "e": 11357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On"
    },
    {
      "t": 11723,
      "e": 11469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11725,
      "e": 11471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11795,
      "e": 11541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On "
    },
    {
      "t": 11834,
      "e": 11580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11835,
      "e": 11581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11877,
      "e": 11623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On t"
    },
    {
      "t": 12002,
      "e": 11748,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On t"
    },
    {
      "t": 12003,
      "e": 11749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12003,
      "e": 11749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12083,
      "e": 11829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 12115,
      "e": 11861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12115,
      "e": 11861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12203,
      "e": 11949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12268,
      "e": 12014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12269,
      "e": 12015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12355,
      "e": 12101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12636,
      "e": 12382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 12636,
      "e": 12382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12708,
      "e": 12454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 13036,
      "e": 12782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 13037,
      "e": 12783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13123,
      "e": 12869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 13428,
      "e": 13174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13429,
      "e": 13175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13579,
      "e": 13325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13611,
      "e": 13357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 13611,
      "e": 13357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13731,
      "e": 13477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 13995,
      "e": 13741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13996,
      "e": 13742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14083,
      "e": 13829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 14236,
      "e": 13982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14236,
      "e": 13982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14291,
      "e": 14037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 14402,
      "e": 14148,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-acis"
    },
    {
      "t": 14419,
      "e": 14165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14419,
      "e": 14165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14499,
      "e": 14245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14602,
      "e": 14348,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-acis "
    },
    {
      "t": 14740,
      "e": 14486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 14741,
      "e": 14487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14819,
      "e": 14565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 14892,
      "e": 14638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14892,
      "e": 14638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14971,
      "e": 14717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 15356,
      "e": 15102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15444,
      "e": 15190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-acis f"
    },
    {
      "t": 15556,
      "e": 15302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15595,
      "e": 15341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-acis "
    },
    {
      "t": 15843,
      "e": 15589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15907,
      "e": 15653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-acis"
    },
    {
      "t": 16035,
      "e": 15781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16092,
      "e": 15838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-aci"
    },
    {
      "t": 16204,
      "e": 15950,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-aci"
    },
    {
      "t": 16211,
      "e": 15957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16283,
      "e": 16029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-ac"
    },
    {
      "t": 16395,
      "e": 16141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16442,
      "e": 16188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-a"
    },
    {
      "t": 18908,
      "e": 18654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 18908,
      "e": 18654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19027,
      "e": 18773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 19083,
      "e": 18829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19083,
      "e": 18829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19196,
      "e": 18942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 19884,
      "e": 19630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19885,
      "e": 19631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19995,
      "e": 19741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 20000,
      "e": 19746,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20171,
      "e": 19917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 20171,
      "e": 19917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20219,
      "e": 19965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 20364,
      "e": 20110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20364,
      "e": 20110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20476,
      "e": 20222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20524,
      "e": 20270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 20524,
      "e": 20270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20611,
      "e": 20357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 20643,
      "e": 20389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20643,
      "e": 20389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20723,
      "e": 20469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20867,
      "e": 20613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20868,
      "e": 20614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20995,
      "e": 20741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21027,
      "e": 20773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 21027,
      "e": 20773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21100,
      "e": 20846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 21173,
      "e": 20919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21173,
      "e": 20919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21267,
      "e": 21013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21348,
      "e": 21094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 21348,
      "e": 21094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21467,
      "e": 21213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 21635,
      "e": 21381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 21637,
      "e": 21383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21731,
      "e": 21477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 22756,
      "e": 22502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 22757,
      "e": 22503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22843,
      "e": 22589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 23004,
      "e": 22750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23004,
      "e": 22750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23090,
      "e": 22836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23204,
      "e": 22950,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. "
    },
    {
      "t": 23235,
      "e": 22981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23735,
      "e": 23481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23768,
      "e": 23514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23801,
      "e": 23547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23835,
      "e": 23581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23867,
      "e": 23613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23900,
      "e": 23646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23933,
      "e": 23679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23966,
      "e": 23712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23999,
      "e": 23745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24032,
      "e": 23778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24060,
      "e": 23806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 24061,
      "e": 23807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24115,
      "e": 23861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 24163,
      "e": 23909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24219,
      "e": 23965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24219,
      "e": 23965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24291,
      "e": 24037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 24403,
      "e": 24149,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Fi"
    },
    {
      "t": 24411,
      "e": 24157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24411,
      "e": 24157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24491,
      "e": 24237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 24492,
      "e": 24238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24499,
      "e": 24245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 24602,
      "e": 24348,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Find"
    },
    {
      "t": 24604,
      "e": 24350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24667,
      "e": 24413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24669,
      "e": 24415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24747,
      "e": 24493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24859,
      "e": 24605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24860,
      "e": 24606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24939,
      "e": 24685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25035,
      "e": 24781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25036,
      "e": 24782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25115,
      "e": 24861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25283,
      "e": 25029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25283,
      "e": 25029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25372,
      "e": 25118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25396,
      "e": 25142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25396,
      "e": 25142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25515,
      "e": 25261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25827,
      "e": 25573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26002,
      "e": 25748,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Find the"
    },
    {
      "t": 26327,
      "e": 26073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26360,
      "e": 26106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26392,
      "e": 26138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26425,
      "e": 26171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26458,
      "e": 26204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26492,
      "e": 26238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26524,
      "e": 26270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26557,
      "e": 26303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26590,
      "e": 26336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26623,
      "e": 26369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26656,
      "e": 26402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26690,
      "e": 26436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26722,
      "e": 26468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26724,
      "e": 26470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find"
    },
    {
      "t": 27571,
      "e": 27317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27572,
      "e": 27318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27699,
      "e": 27445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27772,
      "e": 27518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 27772,
      "e": 27518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27851,
      "e": 27597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 27963,
      "e": 27709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 27964,
      "e": 27710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28027,
      "e": 27773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 28203,
      "e": 27949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 28204,
      "e": 27950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28266,
      "e": 28012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 28371,
      "e": 28117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28371,
      "e": 28117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28450,
      "e": 28196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28531,
      "e": 28277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 28683,
      "e": 28429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28684,
      "e": 28430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28778,
      "e": 28524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 28786,
      "e": 28532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28916,
      "e": 28662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 28918,
      "e": 28664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29003,
      "e": 28749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 29084,
      "e": 28830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29084,
      "e": 28830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29139,
      "e": 28885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 29186,
      "e": 28932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29187,
      "e": 28933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29274,
      "e": 29020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 29395,
      "e": 29141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29396,
      "e": 29142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29467,
      "e": 29213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29876,
      "e": 29622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 29876,
      "e": 29622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29947,
      "e": 29693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 30003,
      "e": 29749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30004,
      "e": 29750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30059,
      "e": 29805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 30203,
      "e": 29949,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fi"
    },
    {
      "t": 30203,
      "e": 29949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30204,
      "e": 29950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30275,
      "e": 30021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 30331,
      "e": 30077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30331,
      "e": 30077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30395,
      "e": 30141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30419,
      "e": 30165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30420,
      "e": 30166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30500,
      "e": 30246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30563,
      "e": 30309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30564,
      "e": 30310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30635,
      "e": 30381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30691,
      "e": 30437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30692,
      "e": 30438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30762,
      "e": 30508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30843,
      "e": 30589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30843,
      "e": 30589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30899,
      "e": 30645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30964,
      "e": 30710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30964,
      "e": 30710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31050,
      "e": 30796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31813,
      "e": 31559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31813,
      "e": 31559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31875,
      "e": 31621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 32002,
      "e": 31748,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fine the l"
    },
    {
      "t": 32076,
      "e": 31822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32077,
      "e": 31823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32116,
      "e": 31862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32291,
      "e": 32037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32292,
      "e": 32038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32387,
      "e": 32133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 32859,
      "e": 32605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32924,
      "e": 32670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fine the li"
    },
    {
      "t": 33051,
      "e": 32797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33091,
      "e": 32837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fine the l"
    },
    {
      "t": 33202,
      "e": 32948,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fine the l"
    },
    {
      "t": 33202,
      "e": 32948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33267,
      "e": 33013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fine the "
    },
    {
      "t": 33402,
      "e": 33148,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fine the "
    },
    {
      "t": 33915,
      "e": 33661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33916,
      "e": 33662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34026,
      "e": 33772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 35868,
      "e": 35614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35870,
      "e": 35616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35955,
      "e": 35701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 36059,
      "e": 35805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 36059,
      "e": 35805,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36083,
      "e": 35829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 36202,
      "e": 35948,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fine the hor"
    },
    {
      "t": 38340,
      "e": 38086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 38341,
      "e": 38087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38442,
      "e": 38188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 38675,
      "e": 38421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 38676,
      "e": 38422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38731,
      "e": 38477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 38747,
      "e": 38493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38747,
      "e": 38493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38826,
      "e": 38572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 38979,
      "e": 38725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 38980,
      "e": 38726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39075,
      "e": 38821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 39099,
      "e": 38845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39100,
      "e": 38846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39187,
      "e": 38933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39259,
      "e": 39005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39260,
      "e": 39006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39362,
      "e": 39108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 39363,
      "e": 39109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39371,
      "e": 39117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 39443,
      "e": 39189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39604,
      "e": 39350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39605,
      "e": 39351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39706,
      "e": 39452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40001,
      "e": 39747,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40580,
      "e": 40326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 40580,
      "e": 40326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40674,
      "e": 40420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 40829,
      "e": 40575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40830,
      "e": 40576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40914,
      "e": 40660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 41066,
      "e": 40812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 41066,
      "e": 40812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41139,
      "e": 40885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 41234,
      "e": 40980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41235,
      "e": 40981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41347,
      "e": 41093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 41836,
      "e": 41582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41907,
      "e": 41653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fine the horizontal mov"
    },
    {
      "t": 42011,
      "e": 41757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42075,
      "e": 41821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fine the horizontal mo"
    },
    {
      "t": 42172,
      "e": 41918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42242,
      "e": 41988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fine the horizontal m"
    },
    {
      "t": 42363,
      "e": 42109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42419,
      "e": 42165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fine the horizontal "
    },
    {
      "t": 43171,
      "e": 42917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 43172,
      "e": 42918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43266,
      "e": 43012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 43467,
      "e": 43213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 43468,
      "e": 43214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43546,
      "e": 43292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 43642,
      "e": 43388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43643,
      "e": 43389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43707,
      "e": 43453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 43804,
      "e": 43550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43806,
      "e": 43552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43866,
      "e": 43612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 43874,
      "e": 43620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43874,
      "e": 43620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43938,
      "e": 43684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44164,
      "e": 43910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 44164,
      "e": 43910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44258,
      "e": 44004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 44379,
      "e": 44125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44380,
      "e": 44126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44459,
      "e": 44205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44723,
      "e": 44469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44724,
      "e": 44470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44804,
      "e": 44550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44948,
      "e": 44694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 44948,
      "e": 44694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45043,
      "e": 44789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 45067,
      "e": 44813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45067,
      "e": 44813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45195,
      "e": 44941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45410,
      "e": 45156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45411,
      "e": 45157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45506,
      "e": 45252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45563,
      "e": 45309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 45563,
      "e": 45309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45643,
      "e": 45389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 45794,
      "e": 45540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45794,
      "e": 45540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45907,
      "e": 45653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46515,
      "e": 46261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 46516,
      "e": 46262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46602,
      "e": 46348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 46706,
      "e": 46452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 46708,
      "e": 46454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46780,
      "e": 46526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 46788,
      "e": 46534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46788,
      "e": 46534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46874,
      "e": 46620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47004,
      "e": 46750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 47005,
      "e": 46751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47091,
      "e": 46837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 47195,
      "e": 46941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 47196,
      "e": 46942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47275,
      "e": 47021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 47404,
      "e": 47150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47404,
      "e": 47150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47474,
      "e": 47220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47474,
      "e": 47220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47474,
      "e": 47220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47563,
      "e": 47309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47635,
      "e": 47381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 47636,
      "e": 47382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47715,
      "e": 47461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 47779,
      "e": 47525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47780,
      "e": 47526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47883,
      "e": 47629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 47906,
      "e": 47652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47907,
      "e": 47653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48011,
      "e": 47757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48963,
      "e": 48709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 48964,
      "e": 48710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49051,
      "e": 48797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 49187,
      "e": 48933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 49188,
      "e": 48934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49266,
      "e": 49012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 49499,
      "e": 49245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49500,
      "e": 49246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49602,
      "e": 49246,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fine the horizontal connected to 12 on the x-a"
    },
    {
      "t": 49610,
      "e": 49254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 50915,
      "e": 50559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 50915,
      "e": 50559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50946,
      "e": 50590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "18"
    },
    {
      "t": 51010,
      "e": 50654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 51034,
      "e": 50678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51098,
      "e": 50742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51099,
      "e": 50743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51187,
      "e": 50831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 51307,
      "e": 50951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 51308,
      "e": 50952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51427,
      "e": 51071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 52101,
      "e": 51745,
      "ty": 2,
      "x": 398,
      "y": 570
    },
    {
      "t": 52201,
      "e": 51845,
      "ty": 2,
      "x": 530,
      "y": 524
    },
    {
      "t": 52251,
      "e": 51895,
      "ty": 41,
      "x": 48662,
      "y": 214,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52295,
      "e": 51939,
      "ty": 7,
      "x": 531,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52301,
      "e": 51945,
      "ty": 2,
      "x": 531,
      "y": 521
    },
    {
      "t": 52386,
      "e": 52030,
      "ty": 6,
      "x": 508,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52401,
      "e": 52045,
      "ty": 2,
      "x": 508,
      "y": 522
    },
    {
      "t": 52501,
      "e": 52145,
      "ty": 2,
      "x": 478,
      "y": 533
    },
    {
      "t": 52501,
      "e": 52145,
      "ty": 41,
      "x": 42817,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52601,
      "e": 52245,
      "ty": 2,
      "x": 471,
      "y": 533
    },
    {
      "t": 52701,
      "e": 52345,
      "ty": 2,
      "x": 465,
      "y": 533
    },
    {
      "t": 52751,
      "e": 52395,
      "ty": 41,
      "x": 41131,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52801,
      "e": 52445,
      "ty": 2,
      "x": 460,
      "y": 533
    },
    {
      "t": 52889,
      "e": 52533,
      "ty": 3,
      "x": 459,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52901,
      "e": 52545,
      "ty": 2,
      "x": 459,
      "y": 533
    },
    {
      "t": 52991,
      "e": 52635,
      "ty": 4,
      "x": 40681,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52991,
      "e": 52635,
      "ty": 5,
      "x": 459,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53001,
      "e": 52645,
      "ty": 41,
      "x": 40681,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53101,
      "e": 52745,
      "ty": 2,
      "x": 465,
      "y": 533
    },
    {
      "t": 53201,
      "e": 52845,
      "ty": 2,
      "x": 567,
      "y": 550
    },
    {
      "t": 53219,
      "e": 52863,
      "ty": 7,
      "x": 684,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53252,
      "e": 52896,
      "ty": 41,
      "x": 4356,
      "y": 29323,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 53301,
      "e": 52945,
      "ty": 2,
      "x": 926,
      "y": 554
    },
    {
      "t": 53401,
      "e": 53045,
      "ty": 2,
      "x": 939,
      "y": 556
    },
    {
      "t": 53502,
      "e": 53146,
      "ty": 41,
      "x": 10782,
      "y": 29938,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 54101,
      "e": 53745,
      "ty": 2,
      "x": 935,
      "y": 556
    },
    {
      "t": 54201,
      "e": 53845,
      "ty": 2,
      "x": 523,
      "y": 373
    },
    {
      "t": 54252,
      "e": 53896,
      "ty": 41,
      "x": 45852,
      "y": 20829,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 54301,
      "e": 53945,
      "ty": 2,
      "x": 402,
      "y": 430
    },
    {
      "t": 54372,
      "e": 54016,
      "ty": 6,
      "x": 319,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54401,
      "e": 54045,
      "ty": 2,
      "x": 310,
      "y": 541
    },
    {
      "t": 54501,
      "e": 54145,
      "ty": 2,
      "x": 313,
      "y": 558
    },
    {
      "t": 54501,
      "e": 54145,
      "ty": 41,
      "x": 24270,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54601,
      "e": 54245,
      "ty": 2,
      "x": 330,
      "y": 548
    },
    {
      "t": 54701,
      "e": 54345,
      "ty": 2,
      "x": 337,
      "y": 539
    },
    {
      "t": 54743,
      "e": 54387,
      "ty": 3,
      "x": 337,
      "y": 539,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54750,
      "e": 54394,
      "ty": 41,
      "x": 26967,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54846,
      "e": 54490,
      "ty": 4,
      "x": 26967,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54847,
      "e": 54491,
      "ty": 5,
      "x": 337,
      "y": 539,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54938,
      "e": 54582,
      "ty": 7,
      "x": 414,
      "y": 506,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55001,
      "e": 54645,
      "ty": 2,
      "x": 522,
      "y": 434
    },
    {
      "t": 55002,
      "e": 54646,
      "ty": 41,
      "x": 47763,
      "y": 23599,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 55595,
      "e": 55239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 55691,
      "e": 55335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55950,
      "e": 55594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56014,
      "e": 55658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then fin the horizontal connected to 12 on the x-axis"
    },
    {
      "t": 56134,
      "e": 55778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 56135,
      "e": 55779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56254,
      "e": 55898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal connected to 12 on the x-axis"
    },
    {
      "t": 56605,
      "e": 56249,
      "ty": 2,
      "x": 524,
      "y": 445
    },
    {
      "t": 56704,
      "e": 56348,
      "ty": 2,
      "x": 526,
      "y": 479
    },
    {
      "t": 56755,
      "e": 56399,
      "ty": 41,
      "x": 45290,
      "y": 1700,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 56803,
      "e": 56447,
      "ty": 2,
      "x": 470,
      "y": 494
    },
    {
      "t": 56876,
      "e": 56520,
      "ty": 6,
      "x": 461,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56903,
      "e": 56547,
      "ty": 2,
      "x": 461,
      "y": 526
    },
    {
      "t": 57003,
      "e": 56647,
      "ty": 2,
      "x": 461,
      "y": 530
    },
    {
      "t": 57004,
      "e": 56648,
      "ty": 41,
      "x": 40906,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57103,
      "e": 56747,
      "ty": 2,
      "x": 460,
      "y": 532
    },
    {
      "t": 57187,
      "e": 56831,
      "ty": 3,
      "x": 458,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57204,
      "e": 56848,
      "ty": 2,
      "x": 458,
      "y": 533
    },
    {
      "t": 57254,
      "e": 56898,
      "ty": 41,
      "x": 40569,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57290,
      "e": 56934,
      "ty": 4,
      "x": 40569,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57290,
      "e": 56934,
      "ty": 5,
      "x": 458,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57404,
      "e": 57048,
      "ty": 2,
      "x": 487,
      "y": 545
    },
    {
      "t": 57504,
      "e": 57148,
      "ty": 2,
      "x": 634,
      "y": 559
    },
    {
      "t": 57504,
      "e": 57148,
      "ty": 41,
      "x": 60353,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57604,
      "e": 57248,
      "ty": 2,
      "x": 613,
      "y": 559
    },
    {
      "t": 57704,
      "e": 57348,
      "ty": 2,
      "x": 374,
      "y": 559
    },
    {
      "t": 57754,
      "e": 57398,
      "ty": 41,
      "x": 31127,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57804,
      "e": 57448,
      "ty": 2,
      "x": 395,
      "y": 547
    },
    {
      "t": 57827,
      "e": 57471,
      "ty": 7,
      "x": 413,
      "y": 511,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57904,
      "e": 57548,
      "ty": 2,
      "x": 413,
      "y": 511
    },
    {
      "t": 58005,
      "e": 57649,
      "ty": 41,
      "x": 35511,
      "y": 38070,
      "ta": "#.strategy > p"
    },
    {
      "t": 58359,
      "e": 58003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 58360,
      "e": 58004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58454,
      "e": 58098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal lconnected to 12 on the x-axis"
    },
    {
      "t": 58646,
      "e": 58290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 58646,
      "e": 58290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58719,
      "e": 58291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal liconnected to 12 on the x-axis"
    },
    {
      "t": 58902,
      "e": 58474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 58902,
      "e": 58474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58999,
      "e": 58571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal linconnected to 12 on the x-axis"
    },
    {
      "t": 59021,
      "e": 58593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 59022,
      "e": 58594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59118,
      "e": 58690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal lineconnected to 12 on the x-axis"
    },
    {
      "t": 59166,
      "e": 58738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59166,
      "e": 58738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59254,
      "e": 58826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line connected to 12 on the x-axis"
    },
    {
      "t": 60679,
      "e": 60251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 60679,
      "e": 60251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60805,
      "e": 60377,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line gconnected to 12 on the x-axis"
    },
    {
      "t": 60807,
      "e": 60379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line gconnected to 12 on the x-axis"
    },
    {
      "t": 60822,
      "e": 60394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60822,
      "e": 60394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60886,
      "e": 60458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line goconnected to 12 on the x-axis"
    },
    {
      "t": 61007,
      "e": 60579,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line goconnected to 12 on the x-axis"
    },
    {
      "t": 61038,
      "e": 60610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 61039,
      "e": 60611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61109,
      "e": 60681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line goiconnected to 12 on the x-axis"
    },
    {
      "t": 61230,
      "e": 60802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 61230,
      "e": 60802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61319,
      "e": 60891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line goinconnected to 12 on the x-axis"
    },
    {
      "t": 61383,
      "e": 60955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 61384,
      "e": 60956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61463,
      "e": 60958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line goingconnected to 12 on the x-axis"
    },
    {
      "t": 61510,
      "e": 61005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61510,
      "e": 61005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61574,
      "e": 61069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going connected to 12 on the x-axis"
    },
    {
      "t": 61798,
      "e": 61293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 61799,
      "e": 61294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61886,
      "e": 61381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uconnected to 12 on the x-axis"
    },
    {
      "t": 62007,
      "e": 61502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 62007,
      "e": 61502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62110,
      "e": 61605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uoconnected to 12 on the x-axis"
    },
    {
      "t": 62238,
      "e": 61733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 62239,
      "e": 61734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62302,
      "e": 61797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uowconnected to 12 on the x-axis"
    },
    {
      "t": 62406,
      "e": 61901,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uowconnected to 12 on the x-axis"
    },
    {
      "t": 62478,
      "e": 61973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 62478,
      "e": 61973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62574,
      "e": 62069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uowaconnected to 12 on the x-axis"
    },
    {
      "t": 62638,
      "e": 62133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 62639,
      "e": 62134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62750,
      "e": 62245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uowarconnected to 12 on the x-axis"
    },
    {
      "t": 62862,
      "e": 62357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 62864,
      "e": 62359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62966,
      "e": 62461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uowardconnected to 12 on the x-axis"
    },
    {
      "t": 63079,
      "e": 62574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 63080,
      "e": 62575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63150,
      "e": 62575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uowardsconnected to 12 on the x-axis"
    },
    {
      "t": 63366,
      "e": 62791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 63445,
      "e": 62870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uowardconnected to 12 on the x-axis"
    },
    {
      "t": 63542,
      "e": 62967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 63599,
      "e": 63024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uowarconnected to 12 on the x-axis"
    },
    {
      "t": 63703,
      "e": 63128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 63751,
      "e": 63176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uowaconnected to 12 on the x-axis"
    },
    {
      "t": 63863,
      "e": 63288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 63918,
      "e": 63343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uowconnected to 12 on the x-axis"
    },
    {
      "t": 64022,
      "e": 63447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64078,
      "e": 63503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uoconnected to 12 on the x-axis"
    },
    {
      "t": 64207,
      "e": 63632,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uoconnected to 12 on the x-axis"
    },
    {
      "t": 64208,
      "e": 63633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64229,
      "e": 63654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uconnected to 12 on the x-axis"
    },
    {
      "t": 64407,
      "e": 63832,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going uconnected to 12 on the x-axis"
    },
    {
      "t": 64807,
      "e": 64232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 64808,
      "e": 64233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64942,
      "e": 64233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upconnected to 12 on the x-axis"
    },
    {
      "t": 64990,
      "e": 64281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 64990,
      "e": 64281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65070,
      "e": 64361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwconnected to 12 on the x-axis"
    },
    {
      "t": 65246,
      "e": 64537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 65247,
      "e": 64538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65327,
      "e": 64618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwaconnected to 12 on the x-axis"
    },
    {
      "t": 65359,
      "e": 64650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 65359,
      "e": 64650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65446,
      "e": 64737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwarconnected to 12 on the x-axis"
    },
    {
      "t": 65567,
      "e": 64858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 65567,
      "e": 64858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65646,
      "e": 64937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwardconnected to 12 on the x-axis"
    },
    {
      "t": 65694,
      "e": 64985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 65694,
      "e": 64985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65774,
      "e": 65065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwardsconnected to 12 on the x-axis"
    },
    {
      "t": 65871,
      "e": 65162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65872,
      "e": 65163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65958,
      "e": 65249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards connected to 12 on the x-axis"
    },
    {
      "t": 66071,
      "e": 65362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66071,
      "e": 65362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66158,
      "e": 65449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards tconnected to 12 on the x-axis"
    },
    {
      "t": 66190,
      "e": 65481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 66190,
      "e": 65481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66271,
      "e": 65482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards toconnected to 12 on the x-axis"
    },
    {
      "t": 66415,
      "e": 65626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66415,
      "e": 65626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66502,
      "e": 65713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to connected to 12 on the x-axis"
    },
    {
      "t": 66598,
      "e": 65809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66598,
      "e": 65809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66630,
      "e": 65841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to tconnected to 12 on the x-axis"
    },
    {
      "t": 66798,
      "e": 66009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 66799,
      "e": 66010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66909,
      "e": 66120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to thconnected to 12 on the x-axis"
    },
    {
      "t": 66982,
      "e": 66193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66982,
      "e": 66193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67062,
      "e": 66273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to theconnected to 12 on the x-axis"
    },
    {
      "t": 67167,
      "e": 66378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67167,
      "e": 66378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67246,
      "e": 66457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the connected to 12 on the x-axis"
    },
    {
      "t": 67926,
      "e": 67137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 67927,
      "e": 67138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68037,
      "e": 67248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the lconnected to 12 on the x-axis"
    },
    {
      "t": 68037,
      "e": 67248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68038,
      "e": 67249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68118,
      "e": 67329,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the leconnected to 12 on the x-axis"
    },
    {
      "t": 68294,
      "e": 67505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 68296,
      "e": 67507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68406,
      "e": 67507,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the lefconnected to 12 on the x-axis"
    },
    {
      "t": 68414,
      "e": 67515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the lefconnected to 12 on the x-axis"
    },
    {
      "t": 68710,
      "e": 67811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68711,
      "e": 67812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68813,
      "e": 67914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the leftconnected to 12 on the x-axis"
    },
    {
      "t": 68910,
      "e": 68011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68910,
      "e": 68011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68990,
      "e": 68091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left connected to 12 on the x-axis"
    },
    {
      "t": 69559,
      "e": 68660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 69798,
      "e": 68899,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 69799,
      "e": 68900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69885,
      "e": 68986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (connected to 12 on the x-axis"
    },
    {
      "t": 69982,
      "e": 69083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70158,
      "e": 69259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 70159,
      "e": 69260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70237,
      "e": 69338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (lconnected to 12 on the x-axis"
    },
    {
      "t": 70527,
      "e": 69628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 70527,
      "e": 69628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70597,
      "e": 69698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (liconnected to 12 on the x-axis"
    },
    {
      "t": 70751,
      "e": 69852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 70751,
      "e": 69852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70815,
      "e": 69854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (likconnected to 12 on the x-axis"
    },
    {
      "t": 72686,
      "e": 71725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 72687,
      "e": 71726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72789,
      "e": 71828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (likeconnected to 12 on the x-axis"
    },
    {
      "t": 72862,
      "e": 71901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72863,
      "e": 71902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72942,
      "e": 71981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like connected to 12 on the x-axis"
    },
    {
      "t": 72998,
      "e": 72037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 72999,
      "e": 72038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73118,
      "e": 72157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like aconnected to 12 on the x-axis"
    },
    {
      "t": 73126,
      "e": 72165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73127,
      "e": 72166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73198,
      "e": 72237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a connected to 12 on the x-axis"
    },
    {
      "t": 73574,
      "e": 72613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 73575,
      "e": 72614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73646,
      "e": 72685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a pconnected to 12 on the x-axis"
    },
    {
      "t": 73758,
      "e": 72797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 73759,
      "e": 72798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73797,
      "e": 72836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 73797,
      "e": 72836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73838,
      "e": 72877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a posconnected to 12 on the x-axis"
    },
    {
      "t": 73902,
      "e": 72941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74429,
      "e": 73468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 74429,
      "e": 73468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74518,
      "e": 73468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a posiconnected to 12 on the x-axis"
    },
    {
      "t": 74558,
      "e": 73508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 74558,
      "e": 73508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74631,
      "e": 73581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positconnected to 12 on the x-axis"
    },
    {
      "t": 75239,
      "e": 74189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 75240,
      "e": 74190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75326,
      "e": 74276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 75327,
      "e": 74277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75358,
      "e": 74308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positizconnected to 12 on the x-axis"
    },
    {
      "t": 75461,
      "e": 74411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76254,
      "e": 75204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76334,
      "e": 75284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positiconnected to 12 on the x-axis"
    },
    {
      "t": 76445,
      "e": 75395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 76446,
      "e": 75396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76527,
      "e": 75477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positivconnected to 12 on the x-axis"
    },
    {
      "t": 76741,
      "e": 75691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 76742,
      "e": 75692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76837,
      "e": 75787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positiveconnected to 12 on the x-axis"
    },
    {
      "t": 76926,
      "e": 75876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76927,
      "e": 75877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76998,
      "e": 75948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive connected to 12 on the x-axis"
    },
    {
      "t": 77446,
      "e": 75948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 77446,
      "e": 75948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77518,
      "e": 76020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive sconnected to 12 on the x-axis"
    },
    {
      "t": 77583,
      "e": 76085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 77583,
      "e": 76085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77662,
      "e": 76164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive slconnected to 12 on the x-axis"
    },
    {
      "t": 77799,
      "e": 76301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 77799,
      "e": 76301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77917,
      "e": 76419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive sloconnected to 12 on the x-axis"
    },
    {
      "t": 77974,
      "e": 76476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 77974,
      "e": 76476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78070,
      "e": 76572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive slopconnected to 12 on the x-axis"
    },
    {
      "t": 78135,
      "e": 76637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 78135,
      "e": 76637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78207,
      "e": 76709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive slopeconnected to 12 on the x-axis"
    },
    {
      "t": 79518,
      "e": 78020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 79518,
      "e": 78020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79606,
      "e": 78108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive slope0connected to 12 on the x-axis"
    },
    {
      "t": 79942,
      "e": 78444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79998,
      "e": 78444,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive slopeconnected to 12 on the x-axis"
    },
    {
      "t": 80046,
      "e": 78492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 80190,
      "e": 78636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 80191,
      "e": 78637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80269,
      "e": 78715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive slope)connected to 12 on the x-axis"
    },
    {
      "t": 80326,
      "e": 78772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80782,
      "e": 79228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80783,
      "e": 79229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80862,
      "e": 79308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive slope) connected to 12 on the x-axis"
    },
    {
      "t": 81104,
      "e": 79550,
      "ty": 2,
      "x": 785,
      "y": 509
    },
    {
      "t": 81203,
      "e": 79649,
      "ty": 2,
      "x": 786,
      "y": 508
    },
    {
      "t": 81254,
      "e": 79700,
      "ty": 41,
      "x": 4184,
      "y": 26696,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 81279,
      "e": 79725,
      "ty": 6,
      "x": 672,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81304,
      "e": 79750,
      "ty": 2,
      "x": 642,
      "y": 543
    },
    {
      "t": 81403,
      "e": 79849,
      "ty": 2,
      "x": 605,
      "y": 548
    },
    {
      "t": 81458,
      "e": 79904,
      "ty": 3,
      "x": 605,
      "y": 548,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81505,
      "e": 79951,
      "ty": 41,
      "x": 57093,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81546,
      "e": 79992,
      "ty": 4,
      "x": 57093,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81546,
      "e": 79992,
      "ty": 5,
      "x": 605,
      "y": 548,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81604,
      "e": 80050,
      "ty": 2,
      "x": 603,
      "y": 549
    },
    {
      "t": 81754,
      "e": 80200,
      "ty": 41,
      "x": 56868,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82478,
      "e": 80924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 82479,
      "e": 80925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82606,
      "e": 81052,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive slope) connected to 12 on the x-axis."
    },
    {
      "t": 82613,
      "e": 81059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 82767,
      "e": 81213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 82767,
      "e": 81213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82862,
      "e": 81308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 82870,
      "e": 81316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 83038,
      "e": 81484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 83039,
      "e": 81485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83141,
      "e": 81587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 83174,
      "e": 81620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 83182,
      "e": 81628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 83182,
      "e": 81628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83222,
      "e": 81668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 83326,
      "e": 81772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 83327,
      "e": 81773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83397,
      "e": 81843,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 83485,
      "e": 81931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 83485,
      "e": 81931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83574,
      "e": 82020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 83982,
      "e": 82428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 83983,
      "e": 82429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84102,
      "e": 82548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 84182,
      "e": 82628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 84183,
      "e": 82629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84285,
      "e": 82731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 84430,
      "e": 82876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 84431,
      "e": 82877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84517,
      "e": 82963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 85492,
      "e": 83938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 85566,
      "e": 83939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive slope) connected to 12 on the x-axis. All po"
    },
    {
      "t": 88334,
      "e": 86707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 88335,
      "e": 86708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88414,
      "e": 86787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 88534,
      "e": 86907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 88534,
      "e": 86907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88629,
      "e": 87002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 88693,
      "e": 87066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 88694,
      "e": 87067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88774,
      "e": 87147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 88966,
      "e": 87339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 88966,
      "e": 87339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89021,
      "e": 87394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 89070,
      "e": 87443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89070,
      "e": 87443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89174,
      "e": 87547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89278,
      "e": 87651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 89279,
      "e": 87652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89358,
      "e": 87731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 89430,
      "e": 87803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 89431,
      "e": 87804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89517,
      "e": 87890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 89638,
      "e": 88011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89638,
      "e": 88011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89726,
      "e": 88099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89807,
      "e": 88180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 89808,
      "e": 88181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89886,
      "e": 88259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 89917,
      "e": 88290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 89917,
      "e": 88290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90038,
      "e": 88411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 90038,
      "e": 88411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90045,
      "e": 88418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 90142,
      "e": 88515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 90197,
      "e": 88570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 90198,
      "e": 88571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90286,
      "e": 88659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 90310,
      "e": 88683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 90311,
      "e": 88684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90405,
      "e": 88778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 90454,
      "e": 88827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 90454,
      "e": 88827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90542,
      "e": 88915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 90694,
      "e": 89067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 90695,
      "e": 89068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90765,
      "e": 89138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 90853,
      "e": 89226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 90854,
      "e": 89227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90941,
      "e": 89314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 91008,
      "e": 89381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 91008,
      "e": 89381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91069,
      "e": 89442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 91109,
      "e": 89482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 91110,
      "e": 89483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91207,
      "e": 89580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 91310,
      "e": 89683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 91312,
      "e": 89685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91422,
      "e": 89795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 91469,
      "e": 89842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 91470,
      "e": 89843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91574,
      "e": 89947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 91638,
      "e": 90011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 91639,
      "e": 90012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91734,
      "e": 90107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 91766,
      "e": 90139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 91766,
      "e": 90139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91854,
      "e": 90227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 91966,
      "e": 90339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 91967,
      "e": 90340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92053,
      "e": 90426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 92238,
      "e": 90611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 92238,
      "e": 90611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92333,
      "e": 90706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 92982,
      "e": 91355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 92983,
      "e": 91356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93118,
      "e": 91491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 93215,
      "e": 91588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 93216,
      "e": 91589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93310,
      "e": 91683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 93478,
      "e": 91851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 93479,
      "e": 91852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93558,
      "e": 91931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 93662,
      "e": 92035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 93663,
      "e": 92036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93805,
      "e": 92178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 93862,
      "e": 92235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 93862,
      "e": 92235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93966,
      "e": 92339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 93982,
      "e": 92355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 93983,
      "e": 92356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94093,
      "e": 92466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 94805,
      "e": 93178,
      "ty": 2,
      "x": 589,
      "y": 562
    },
    {
      "t": 94856,
      "e": 93229,
      "ty": 7,
      "x": 489,
      "y": 622,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94905,
      "e": 93278,
      "ty": 2,
      "x": 402,
      "y": 651
    },
    {
      "t": 95004,
      "e": 93377,
      "ty": 2,
      "x": 333,
      "y": 631
    },
    {
      "t": 95005,
      "e": 93378,
      "ty": 41,
      "x": 6743,
      "y": 6072,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 95091,
      "e": 93464,
      "ty": 6,
      "x": 378,
      "y": 664,
      "ta": "#strategyButton"
    },
    {
      "t": 95104,
      "e": 93477,
      "ty": 2,
      "x": 378,
      "y": 664
    },
    {
      "t": 95186,
      "e": 93559,
      "ty": 7,
      "x": 454,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 95204,
      "e": 93577,
      "ty": 2,
      "x": 454,
      "y": 688
    },
    {
      "t": 95255,
      "e": 93628,
      "ty": 41,
      "x": 63384,
      "y": 43427,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 95339,
      "e": 93712,
      "ty": 6,
      "x": 454,
      "y": 686,
      "ta": "#strategyButton"
    },
    {
      "t": 95404,
      "e": 93777,
      "ty": 2,
      "x": 441,
      "y": 675
    },
    {
      "t": 95483,
      "e": 93856,
      "ty": 3,
      "x": 439,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 95485,
      "e": 93857,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive slope) connected to 12 on the x-axis. All points on this line start at 12."
    },
    {
      "t": 95487,
      "e": 93859,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95488,
      "e": 93860,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 95504,
      "e": 93876,
      "ty": 2,
      "x": 439,
      "y": 673
    },
    {
      "t": 95504,
      "e": 93876,
      "ty": 41,
      "x": 54834,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 95577,
      "e": 93949,
      "ty": 4,
      "x": 54834,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 95587,
      "e": 93959,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 95588,
      "e": 93960,
      "ty": 5,
      "x": 439,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 95593,
      "e": 93965,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 96596,
      "e": 94968,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 97204,
      "e": 95576,
      "ty": 2,
      "x": 735,
      "y": 687
    },
    {
      "t": 97225,
      "e": 95597,
      "ty": 6,
      "x": 978,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 97241,
      "e": 95613,
      "ty": 7,
      "x": 1122,
      "y": 653,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 97254,
      "e": 95626,
      "ty": 41,
      "x": 38363,
      "y": 35731,
      "ta": "html > body"
    },
    {
      "t": 97305,
      "e": 95677,
      "ty": 2,
      "x": 1209,
      "y": 603
    },
    {
      "t": 97404,
      "e": 95776,
      "ty": 2,
      "x": 1150,
      "y": 562
    },
    {
      "t": 97504,
      "e": 95876,
      "ty": 2,
      "x": 1068,
      "y": 553
    },
    {
      "t": 97504,
      "e": 95876,
      "ty": 41,
      "x": 56234,
      "y": 44394,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 97509,
      "e": 95881,
      "ty": 6,
      "x": 1056,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 97605,
      "e": 95977,
      "ty": 2,
      "x": 1031,
      "y": 563
    },
    {
      "t": 97619,
      "e": 95991,
      "ty": 3,
      "x": 1031,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 97619,
      "e": 95991,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 97706,
      "e": 96078,
      "ty": 4,
      "x": 48232,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 97707,
      "e": 96079,
      "ty": 5,
      "x": 1031,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 97754,
      "e": 96126,
      "ty": 41,
      "x": 48232,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 98918,
      "e": 97290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 98918,
      "e": 97290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99021,
      "e": 97393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 99182,
      "e": 97554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 99183,
      "e": 97555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 99245,
      "e": 97617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 100078,
      "e": 98450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 100079,
      "e": 98451,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 100079,
      "e": 98451,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 100080,
      "e": 98452,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100165,
      "e": 98537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 101974,
      "e": 100346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 102165,
      "e": 100537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 102166,
      "e": 100538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102317,
      "e": 100689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 102606,
      "e": 100978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 102607,
      "e": 100979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102804,
      "e": 101176,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 102810,
      "e": 101182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 102820,
      "e": 101192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "91"
    },
    {
      "t": 102877,
      "e": 101249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 102973,
      "e": 101345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 102973,
      "e": 101345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103101,
      "e": 101473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 103109,
      "e": 101481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 103881,
      "e": 102253,
      "ty": 7,
      "x": 1026,
      "y": 578,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103905,
      "e": 102277,
      "ty": 2,
      "x": 1020,
      "y": 600
    },
    {
      "t": 103931,
      "e": 102303,
      "ty": 6,
      "x": 1015,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103965,
      "e": 102337,
      "ty": 7,
      "x": 1017,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104005,
      "e": 102377,
      "ty": 2,
      "x": 1018,
      "y": 672
    },
    {
      "t": 104005,
      "e": 102377,
      "ty": 41,
      "x": 45420,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 104034,
      "e": 102406,
      "ty": 6,
      "x": 1018,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104105,
      "e": 102477,
      "ty": 2,
      "x": 1010,
      "y": 684
    },
    {
      "t": 104205,
      "e": 102577,
      "ty": 2,
      "x": 967,
      "y": 692
    },
    {
      "t": 104251,
      "e": 102623,
      "ty": 3,
      "x": 967,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104251,
      "e": 102623,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 104252,
      "e": 102624,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104252,
      "e": 102624,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104254,
      "e": 102626,
      "ty": 41,
      "x": 36632,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104337,
      "e": 102709,
      "ty": 4,
      "x": 36632,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104338,
      "e": 102710,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104338,
      "e": 102710,
      "ty": 5,
      "x": 967,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 104338,
      "e": 102710,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 104804,
      "e": 103176,
      "ty": 2,
      "x": 1005,
      "y": 706
    },
    {
      "t": 104905,
      "e": 103277,
      "ty": 2,
      "x": 1125,
      "y": 769
    },
    {
      "t": 105005,
      "e": 103377,
      "ty": 41,
      "x": 38466,
      "y": 42157,
      "ta": "html > body"
    },
    {
      "t": 105354,
      "e": 103726,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 105604,
      "e": 103976,
      "ty": 2,
      "x": 1126,
      "y": 769
    },
    {
      "t": 105704,
      "e": 104076,
      "ty": 2,
      "x": 1129,
      "y": 766
    },
    {
      "t": 105754,
      "e": 104126,
      "ty": 41,
      "x": 38604,
      "y": 41991,
      "ta": "html > body"
    },
    {
      "t": 105804,
      "e": 104176,
      "ty": 2,
      "x": 1130,
      "y": 765
    },
    {
      "t": 106004,
      "e": 104376,
      "ty": 2,
      "x": 1134,
      "y": 761
    },
    {
      "t": 106004,
      "e": 104376,
      "ty": 41,
      "x": 38776,
      "y": 41714,
      "ta": "html > body"
    },
    {
      "t": 106203,
      "e": 104575,
      "ty": 2,
      "x": 1082,
      "y": 662
    },
    {
      "t": 106254,
      "e": 104626,
      "ty": 41,
      "x": 27760,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 106304,
      "e": 104676,
      "ty": 2,
      "x": 511,
      "y": 0
    },
    {
      "t": 106404,
      "e": 104776,
      "ty": 2,
      "x": 478,
      "y": 0
    },
    {
      "t": 106504,
      "e": 104876,
      "ty": 2,
      "x": 759,
      "y": 165
    },
    {
      "t": 106504,
      "e": 104876,
      "ty": 41,
      "x": 25862,
      "y": 8697,
      "ta": "html > body"
    },
    {
      "t": 106604,
      "e": 104976,
      "ty": 2,
      "x": 911,
      "y": 243
    },
    {
      "t": 106704,
      "e": 105076,
      "ty": 2,
      "x": 919,
      "y": 254
    },
    {
      "t": 106755,
      "e": 105076,
      "ty": 41,
      "x": 21021,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 106803,
      "e": 105124,
      "ty": 2,
      "x": 898,
      "y": 254
    },
    {
      "t": 106904,
      "e": 105225,
      "ty": 2,
      "x": 894,
      "y": 253
    },
    {
      "t": 106921,
      "e": 105242,
      "ty": 3,
      "x": 894,
      "y": 253,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 107002,
      "e": 105323,
      "ty": 4,
      "x": 17224,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 107002,
      "e": 105323,
      "ty": 5,
      "x": 894,
      "y": 253,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 107004,
      "e": 105325,
      "ty": 41,
      "x": 17224,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 107104,
      "e": 105425,
      "ty": 2,
      "x": 880,
      "y": 250
    },
    {
      "t": 107203,
      "e": 105524,
      "ty": 2,
      "x": 867,
      "y": 248
    },
    {
      "t": 107254,
      "e": 105575,
      "ty": 41,
      "x": 37322,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 107404,
      "e": 105725,
      "ty": 2,
      "x": 864,
      "y": 248
    },
    {
      "t": 107504,
      "e": 105825,
      "ty": 2,
      "x": 821,
      "y": 252
    },
    {
      "t": 107504,
      "e": 105825,
      "ty": 41,
      "x": 0,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 107704,
      "e": 106025,
      "ty": 2,
      "x": 823,
      "y": 249
    },
    {
      "t": 107754,
      "e": 106075,
      "ty": 41,
      "x": 2930,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 107804,
      "e": 106125,
      "ty": 2,
      "x": 825,
      "y": 247
    },
    {
      "t": 107884,
      "e": 106205,
      "ty": 6,
      "x": 826,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 107903,
      "e": 106224,
      "ty": 2,
      "x": 826,
      "y": 241
    },
    {
      "t": 107978,
      "e": 106299,
      "ty": 3,
      "x": 827,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 107979,
      "e": 106300,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 108004,
      "e": 106325,
      "ty": 2,
      "x": 827,
      "y": 239
    },
    {
      "t": 108004,
      "e": 106325,
      "ty": 41,
      "x": 2914,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 108065,
      "e": 106386,
      "ty": 4,
      "x": 2914,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 108065,
      "e": 106386,
      "ty": 5,
      "x": 827,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 108066,
      "e": 106387,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 108204,
      "e": 106525,
      "ty": 2,
      "x": 830,
      "y": 241
    },
    {
      "t": 108218,
      "e": 106539,
      "ty": 7,
      "x": 839,
      "y": 251,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 108254,
      "e": 106575,
      "ty": 41,
      "x": 19480,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 108303,
      "e": 106624,
      "ty": 2,
      "x": 848,
      "y": 273
    },
    {
      "t": 108404,
      "e": 106725,
      "ty": 2,
      "x": 823,
      "y": 416
    },
    {
      "t": 108504,
      "e": 106825,
      "ty": 2,
      "x": 823,
      "y": 429
    },
    {
      "t": 108504,
      "e": 106825,
      "ty": 41,
      "x": 374,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 108604,
      "e": 106925,
      "ty": 2,
      "x": 823,
      "y": 426
    },
    {
      "t": 108704,
      "e": 107025,
      "ty": 2,
      "x": 825,
      "y": 408
    },
    {
      "t": 108754,
      "e": 107075,
      "ty": 41,
      "x": 4188,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 108802,
      "e": 107123,
      "ty": 3,
      "x": 825,
      "y": 407,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 108803,
      "e": 107124,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 108806,
      "e": 107127,
      "ty": 2,
      "x": 825,
      "y": 407
    },
    {
      "t": 108905,
      "e": 107226,
      "ty": 4,
      "x": 4188,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 108905,
      "e": 107226,
      "ty": 5,
      "x": 825,
      "y": 407,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 108905,
      "e": 107226,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 108906,
      "e": 107227,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 109004,
      "e": 107325,
      "ty": 41,
      "x": 4188,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 109254,
      "e": 107575,
      "ty": 41,
      "x": 10041,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 109285,
      "e": 107606,
      "ty": 6,
      "x": 832,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 109303,
      "e": 107624,
      "ty": 2,
      "x": 832,
      "y": 408
    },
    {
      "t": 109404,
      "e": 107725,
      "ty": 2,
      "x": 833,
      "y": 408
    },
    {
      "t": 109504,
      "e": 107825,
      "ty": 41,
      "x": 33161,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 109585,
      "e": 107906,
      "ty": 7,
      "x": 835,
      "y": 425,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 109604,
      "e": 107925,
      "ty": 2,
      "x": 847,
      "y": 441
    },
    {
      "t": 109704,
      "e": 108025,
      "ty": 2,
      "x": 926,
      "y": 652
    },
    {
      "t": 109754,
      "e": 108075,
      "ty": 41,
      "x": 27753,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 109804,
      "e": 108125,
      "ty": 2,
      "x": 932,
      "y": 764
    },
    {
      "t": 109904,
      "e": 108225,
      "ty": 2,
      "x": 926,
      "y": 779
    },
    {
      "t": 110004,
      "e": 108325,
      "ty": 2,
      "x": 883,
      "y": 831
    },
    {
      "t": 110004,
      "e": 108325,
      "ty": 41,
      "x": 14614,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 110104,
      "e": 108425,
      "ty": 2,
      "x": 863,
      "y": 853
    },
    {
      "t": 110204,
      "e": 108525,
      "ty": 2,
      "x": 844,
      "y": 839
    },
    {
      "t": 110254,
      "e": 108575,
      "ty": 41,
      "x": 15907,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 110304,
      "e": 108625,
      "ty": 2,
      "x": 844,
      "y": 834
    },
    {
      "t": 110404,
      "e": 108725,
      "ty": 2,
      "x": 846,
      "y": 827
    },
    {
      "t": 110504,
      "e": 108825,
      "ty": 2,
      "x": 840,
      "y": 818
    },
    {
      "t": 110504,
      "e": 108825,
      "ty": 41,
      "x": 10965,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 110515,
      "e": 108836,
      "ty": 6,
      "x": 839,
      "y": 818,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 110604,
      "e": 108925,
      "ty": 2,
      "x": 839,
      "y": 818
    },
    {
      "t": 110666,
      "e": 108987,
      "ty": 3,
      "x": 839,
      "y": 818,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 110668,
      "e": 108989,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 110668,
      "e": 108989,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 110755,
      "e": 109076,
      "ty": 41,
      "x": 63408,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 110762,
      "e": 109083,
      "ty": 4,
      "x": 63408,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 110762,
      "e": 109083,
      "ty": 5,
      "x": 839,
      "y": 818,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 110763,
      "e": 109084,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf",
      "v": "Humanities"
    },
    {
      "t": 111004,
      "e": 109325,
      "ty": 2,
      "x": 834,
      "y": 814
    },
    {
      "t": 111005,
      "e": 109326,
      "ty": 41,
      "x": 38202,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 111103,
      "e": 109424,
      "ty": 7,
      "x": 844,
      "y": 827,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 111104,
      "e": 109425,
      "ty": 2,
      "x": 844,
      "y": 827
    },
    {
      "t": 111204,
      "e": 109525,
      "ty": 2,
      "x": 885,
      "y": 909
    },
    {
      "t": 111254,
      "e": 109575,
      "ty": 41,
      "x": 58520,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 111305,
      "e": 109626,
      "ty": 2,
      "x": 866,
      "y": 956
    },
    {
      "t": 111404,
      "e": 109725,
      "ty": 2,
      "x": 861,
      "y": 960
    },
    {
      "t": 111504,
      "e": 109825,
      "ty": 2,
      "x": 843,
      "y": 950
    },
    {
      "t": 111504,
      "e": 109825,
      "ty": 41,
      "x": 5121,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 111605,
      "e": 109926,
      "ty": 2,
      "x": 836,
      "y": 954
    },
    {
      "t": 111704,
      "e": 110025,
      "ty": 2,
      "x": 835,
      "y": 955
    },
    {
      "t": 111707,
      "e": 110028,
      "ty": 6,
      "x": 835,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111754,
      "e": 110075,
      "ty": 3,
      "x": 835,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111756,
      "e": 110077,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 111757,
      "e": 110078,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111758,
      "e": 110079,
      "ty": 41,
      "x": 43243,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111804,
      "e": 110125,
      "ty": 2,
      "x": 835,
      "y": 957
    },
    {
      "t": 111849,
      "e": 110170,
      "ty": 4,
      "x": 43243,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111850,
      "e": 110171,
      "ty": 5,
      "x": 835,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111850,
      "e": 110171,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 111987,
      "e": 110308,
      "ty": 7,
      "x": 845,
      "y": 969,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 112004,
      "e": 110325,
      "ty": 2,
      "x": 855,
      "y": 981
    },
    {
      "t": 112004,
      "e": 110325,
      "ty": 41,
      "x": 33333,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 112037,
      "e": 110358,
      "ty": 6,
      "x": 871,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112104,
      "e": 110425,
      "ty": 2,
      "x": 892,
      "y": 1028
    },
    {
      "t": 112204,
      "e": 110525,
      "ty": 2,
      "x": 917,
      "y": 1033
    },
    {
      "t": 112254,
      "e": 110575,
      "ty": 41,
      "x": 45136,
      "y": 55605,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112304,
      "e": 110625,
      "ty": 2,
      "x": 918,
      "y": 1033
    },
    {
      "t": 112403,
      "e": 110724,
      "ty": 2,
      "x": 919,
      "y": 1030
    },
    {
      "t": 112449,
      "e": 110770,
      "ty": 3,
      "x": 919,
      "y": 1030,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112449,
      "e": 110770,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 112449,
      "e": 110770,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112504,
      "e": 110825,
      "ty": 41,
      "x": 46167,
      "y": 49647,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112545,
      "e": 110866,
      "ty": 4,
      "x": 46167,
      "y": 49647,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112546,
      "e": 110867,
      "ty": 5,
      "x": 919,
      "y": 1030,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112551,
      "e": 110872,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112553,
      "e": 110874,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 112555,
      "e": 110876,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 112754,
      "e": 111075,
      "ty": 41,
      "x": 31786,
      "y": 56117,
      "ta": "html > body"
    },
    {
      "t": 112804,
      "e": 111125,
      "ty": 2,
      "x": 969,
      "y": 1001
    },
    {
      "t": 112904,
      "e": 111225,
      "ty": 2,
      "x": 1344,
      "y": 798
    },
    {
      "t": 113004,
      "e": 111325,
      "ty": 2,
      "x": 1674,
      "y": 601
    },
    {
      "t": 113004,
      "e": 111325,
      "ty": 41,
      "x": 57373,
      "y": 32850,
      "ta": "html > body"
    },
    {
      "t": 113104,
      "e": 111425,
      "ty": 2,
      "x": 1690,
      "y": 577
    },
    {
      "t": 113254,
      "e": 111575,
      "ty": 41,
      "x": 57924,
      "y": 31521,
      "ta": "html > body"
    },
    {
      "t": 113865,
      "e": 112186,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 117608,
      "e": 115929,
      "ty": 2,
      "x": 1692,
      "y": 576
    },
    {
      "t": 117708,
      "e": 116029,
      "ty": 2,
      "x": 1693,
      "y": 575
    },
    {
      "t": 117758,
      "e": 116079,
      "ty": 41,
      "x": 58062,
      "y": 31410,
      "ta": "> div.masterdiv"
    },
    {
      "t": 117808,
      "e": 116129,
      "ty": 2,
      "x": 1694,
      "y": 575
    },
    {
      "t": 118508,
      "e": 116829,
      "ty": 2,
      "x": 1695,
      "y": 574
    },
    {
      "t": 118509,
      "e": 116830,
      "ty": 41,
      "x": 58096,
      "y": 31354,
      "ta": "> div.masterdiv"
    },
    {
      "t": 118808,
      "e": 117129,
      "ty": 2,
      "x": 1696,
      "y": 574
    },
    {
      "t": 119008,
      "e": 117329,
      "ty": 41,
      "x": 58130,
      "y": 31354,
      "ta": "> div.masterdiv"
    },
    {
      "t": 120008,
      "e": 118329,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120109,
      "e": 118430,
      "ty": 2,
      "x": 1697,
      "y": 574
    },
    {
      "t": 120259,
      "e": 118580,
      "ty": 41,
      "x": 58165,
      "y": 31354,
      "ta": "> div.masterdiv"
    },
    {
      "t": 120408,
      "e": 118729,
      "ty": 2,
      "x": 1698,
      "y": 574
    },
    {
      "t": 120508,
      "e": 118829,
      "ty": 2,
      "x": 1699,
      "y": 574
    },
    {
      "t": 120509,
      "e": 118830,
      "ty": 41,
      "x": 58234,
      "y": 31354,
      "ta": "> div.masterdiv"
    },
    {
      "t": 120908,
      "e": 119229,
      "ty": 2,
      "x": 1699,
      "y": 573
    },
    {
      "t": 121008,
      "e": 119329,
      "ty": 41,
      "x": 58234,
      "y": 31299,
      "ta": "> div.masterdiv"
    },
    {
      "t": 121409,
      "e": 119730,
      "ty": 2,
      "x": 1700,
      "y": 572
    },
    {
      "t": 121508,
      "e": 119829,
      "ty": 41,
      "x": 58268,
      "y": 31244,
      "ta": "> div.masterdiv"
    },
    {
      "t": 122608,
      "e": 120929,
      "ty": 2,
      "x": 1658,
      "y": 600
    },
    {
      "t": 122708,
      "e": 121029,
      "ty": 2,
      "x": 1569,
      "y": 671
    },
    {
      "t": 122759,
      "e": 121080,
      "ty": 41,
      "x": 60588,
      "y": 20196,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 122809,
      "e": 121130,
      "ty": 2,
      "x": 1487,
      "y": 727
    },
    {
      "t": 122909,
      "e": 121230,
      "ty": 2,
      "x": 1308,
      "y": 787
    },
    {
      "t": 123009,
      "e": 121330,
      "ty": 2,
      "x": 1169,
      "y": 813
    },
    {
      "t": 123009,
      "e": 121330,
      "ty": 41,
      "x": 43074,
      "y": 16987,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 123108,
      "e": 121429,
      "ty": 2,
      "x": 1062,
      "y": 839
    },
    {
      "t": 123208,
      "e": 121529,
      "ty": 2,
      "x": 1056,
      "y": 837
    },
    {
      "t": 123258,
      "e": 121579,
      "ty": 41,
      "x": 37515,
      "y": 45073,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 124508,
      "e": 122829,
      "ty": 41,
      "x": 37465,
      "y": 45073,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 124509,
      "e": 122830,
      "ty": 2,
      "x": 1055,
      "y": 837
    },
    {
      "t": 130007,
      "e": 127830,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130608,
      "e": 127830,
      "ty": 2,
      "x": 1038,
      "y": 870
    },
    {
      "t": 130708,
      "e": 127930,
      "ty": 2,
      "x": 841,
      "y": 1199
    },
    {
      "t": 130807,
      "e": 128029,
      "ty": 2,
      "x": 872,
      "y": 1181
    },
    {
      "t": 130908,
      "e": 128130,
      "ty": 2,
      "x": 936,
      "y": 1121
    },
    {
      "t": 130940,
      "e": 128162,
      "ty": 6,
      "x": 957,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 131007,
      "e": 128229,
      "ty": 2,
      "x": 978,
      "y": 1078
    },
    {
      "t": 131008,
      "e": 128230,
      "ty": 41,
      "x": 37409,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 131069,
      "e": 128291,
      "ty": 3,
      "x": 978,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 131070,
      "e": 128292,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 131173,
      "e": 128395,
      "ty": 4,
      "x": 37409,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 131174,
      "e": 128396,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 131175,
      "e": 128397,
      "ty": 5,
      "x": 978,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 131176,
      "e": 128398,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 132201,
      "e": 129423,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 133149,
      "e": 130371,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 184908, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 184915, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 7916, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 194168, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 11552, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"YANKEE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 206727, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 19801, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 227624, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 10254, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 238882, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 50254, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 290508, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -H -11 AM-F -Z -Z -F -F -F -K -F -A -A -A -H -H -H -J -J -O -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:986,y:1015,t:1528139557423};\\\", \\\"{x:326,y:983,t:1528139557526};\\\", \\\"{x:276,y:983,t:1528139557535};\\\", \\\"{x:184,y:982,t:1528139557552};\\\", \\\"{x:106,y:969,t:1528139557568};\\\", \\\"{x:42,y:961,t:1528139557584};\\\", \\\"{x:0,y:953,t:1528139557601};\\\", \\\"{x:0,y:948,t:1528139557619};\\\", \\\"{x:0,y:945,t:1528139557635};\\\", \\\"{x:0,y:943,t:1528139558047};\\\", \\\"{x:0,y:941,t:1528139558055};\\\", \\\"{x:2,y:940,t:1528139558069};\\\", \\\"{x:3,y:938,t:1528139558086};\\\", \\\"{x:4,y:937,t:1528139558102};\\\", \\\"{x:5,y:937,t:1528139558118};\\\", \\\"{x:6,y:935,t:1528139558136};\\\", \\\"{x:8,y:933,t:1528139558152};\\\", \\\"{x:10,y:931,t:1528139558169};\\\", \\\"{x:13,y:929,t:1528139558186};\\\", \\\"{x:15,y:927,t:1528139558202};\\\", \\\"{x:17,y:926,t:1528139558219};\\\", \\\"{x:21,y:925,t:1528139558236};\\\", \\\"{x:25,y:925,t:1528139558252};\\\", \\\"{x:36,y:925,t:1528139558268};\\\", \\\"{x:54,y:925,t:1528139558286};\\\", \\\"{x:60,y:927,t:1528139558303};\\\", \\\"{x:60,y:926,t:1528139558823};\\\", \\\"{x:59,y:925,t:1528139558839};\\\", \\\"{x:59,y:924,t:1528139558871};\\\", \\\"{x:58,y:923,t:1528139559616};\\\", \\\"{x:51,y:931,t:1528139559623};\\\", \\\"{x:50,y:937,t:1528139559637};\\\", \\\"{x:78,y:929,t:1528139560047};\\\", \\\"{x:122,y:915,t:1528139560055};\\\", \\\"{x:182,y:903,t:1528139560070};\\\", \\\"{x:397,y:873,t:1528139560087};\\\", \\\"{x:571,y:846,t:1528139560104};\\\", \\\"{x:751,y:821,t:1528139560120};\\\", \\\"{x:923,y:795,t:1528139560137};\\\", \\\"{x:1094,y:768,t:1528139560155};\\\", \\\"{x:1221,y:734,t:1528139560171};\\\", \\\"{x:1294,y:708,t:1528139560187};\\\", \\\"{x:1335,y:694,t:1528139560204};\\\", \\\"{x:1351,y:684,t:1528139560219};\\\", \\\"{x:1354,y:681,t:1528139560237};\\\", \\\"{x:1355,y:681,t:1528139560318};\\\", \\\"{x:1361,y:679,t:1528139560326};\\\", \\\"{x:1367,y:675,t:1528139560337};\\\", \\\"{x:1391,y:661,t:1528139560354};\\\", \\\"{x:1416,y:645,t:1528139560371};\\\", \\\"{x:1446,y:628,t:1528139560387};\\\", \\\"{x:1478,y:611,t:1528139560404};\\\", \\\"{x:1502,y:594,t:1528139560421};\\\", \\\"{x:1525,y:569,t:1528139560437};\\\", \\\"{x:1533,y:553,t:1528139560454};\\\", \\\"{x:1537,y:538,t:1528139560471};\\\", \\\"{x:1538,y:534,t:1528139560487};\\\", \\\"{x:1537,y:531,t:1528139560504};\\\", \\\"{x:1537,y:530,t:1528139560521};\\\", \\\"{x:1536,y:529,t:1528139560537};\\\", \\\"{x:1532,y:526,t:1528139560554};\\\", \\\"{x:1527,y:525,t:1528139560572};\\\", \\\"{x:1518,y:524,t:1528139560587};\\\", \\\"{x:1503,y:524,t:1528139560605};\\\", \\\"{x:1481,y:524,t:1528139560621};\\\", \\\"{x:1462,y:527,t:1528139560637};\\\", \\\"{x:1443,y:535,t:1528139560654};\\\", \\\"{x:1425,y:545,t:1528139560671};\\\", \\\"{x:1422,y:548,t:1528139560687};\\\", \\\"{x:1421,y:550,t:1528139560704};\\\", \\\"{x:1419,y:554,t:1528139560721};\\\", \\\"{x:1418,y:555,t:1528139560737};\\\", \\\"{x:1418,y:556,t:1528139560759};\\\", \\\"{x:1418,y:560,t:1528139563615};\\\", \\\"{x:1419,y:575,t:1528139563640};\\\", \\\"{x:1419,y:581,t:1528139563656};\\\", \\\"{x:1420,y:582,t:1528139563673};\\\", \\\"{x:1421,y:584,t:1528139563694};\\\", \\\"{x:1421,y:582,t:1528139563839};\\\", \\\"{x:1421,y:579,t:1528139563847};\\\", \\\"{x:1421,y:578,t:1528139563858};\\\", \\\"{x:1421,y:574,t:1528139563875};\\\", \\\"{x:1420,y:571,t:1528139563890};\\\", \\\"{x:1420,y:568,t:1528139563907};\\\", \\\"{x:1419,y:567,t:1528139563925};\\\", \\\"{x:1419,y:566,t:1528139563945};\\\", \\\"{x:1419,y:565,t:1528139563956};\\\", \\\"{x:1418,y:562,t:1528139563974};\\\", \\\"{x:1418,y:561,t:1528139563990};\\\", \\\"{x:1418,y:560,t:1528139564038};\\\", \\\"{x:1418,y:559,t:1528139564054};\\\", \\\"{x:1417,y:558,t:1528139579104};\\\", \\\"{x:1407,y:576,t:1528139581099};\\\", \\\"{x:1381,y:642,t:1528139581120};\\\", \\\"{x:1356,y:695,t:1528139581138};\\\", \\\"{x:1333,y:753,t:1528139581153};\\\", \\\"{x:1305,y:814,t:1528139581171};\\\", \\\"{x:1290,y:850,t:1528139581188};\\\", \\\"{x:1279,y:875,t:1528139581204};\\\", \\\"{x:1273,y:890,t:1528139581220};\\\", \\\"{x:1272,y:899,t:1528139581237};\\\", \\\"{x:1269,y:913,t:1528139581254};\\\", \\\"{x:1268,y:923,t:1528139581271};\\\", \\\"{x:1268,y:934,t:1528139581287};\\\", \\\"{x:1268,y:944,t:1528139581305};\\\", \\\"{x:1268,y:956,t:1528139581321};\\\", \\\"{x:1268,y:961,t:1528139581338};\\\", \\\"{x:1268,y:963,t:1528139581355};\\\", \\\"{x:1269,y:964,t:1528139581471};\\\", \\\"{x:1271,y:968,t:1528139581487};\\\", \\\"{x:1273,y:970,t:1528139581505};\\\", \\\"{x:1275,y:971,t:1528139581520};\\\", \\\"{x:1277,y:972,t:1528139581537};\\\", \\\"{x:1278,y:972,t:1528139581555};\\\", \\\"{x:1279,y:973,t:1528139581571};\\\", \\\"{x:1281,y:973,t:1528139581614};\\\", \\\"{x:1283,y:973,t:1528139581630};\\\", \\\"{x:1285,y:973,t:1528139581647};\\\", \\\"{x:1286,y:972,t:1528139581654};\\\", \\\"{x:1286,y:971,t:1528139581672};\\\", \\\"{x:1287,y:970,t:1528139581688};\\\", \\\"{x:1287,y:969,t:1528139581706};\\\", \\\"{x:1287,y:968,t:1528139581722};\\\", \\\"{x:1287,y:966,t:1528139581775};\\\", \\\"{x:1287,y:965,t:1528139581788};\\\", \\\"{x:1286,y:962,t:1528139581805};\\\", \\\"{x:1285,y:960,t:1528139581822};\\\", \\\"{x:1281,y:954,t:1528139581838};\\\", \\\"{x:1279,y:953,t:1528139581855};\\\", \\\"{x:1279,y:952,t:1528139581872};\\\", \\\"{x:1278,y:952,t:1528139581903};\\\", \\\"{x:1278,y:951,t:1528139582566};\\\", \\\"{x:1279,y:951,t:1528139582614};\\\", \\\"{x:1280,y:951,t:1528139582622};\\\", \\\"{x:1281,y:951,t:1528139582646};\\\", \\\"{x:1282,y:950,t:1528139582703};\\\", \\\"{x:1283,y:949,t:1528139583184};\\\", \\\"{x:1284,y:939,t:1528139583191};\\\", \\\"{x:1289,y:915,t:1528139583206};\\\", \\\"{x:1323,y:788,t:1528139583223};\\\", \\\"{x:1353,y:704,t:1528139583240};\\\", \\\"{x:1381,y:643,t:1528139583256};\\\", \\\"{x:1413,y:581,t:1528139583273};\\\", \\\"{x:1431,y:546,t:1528139583290};\\\", \\\"{x:1438,y:533,t:1528139583306};\\\", \\\"{x:1441,y:529,t:1528139583323};\\\", \\\"{x:1443,y:527,t:1528139583339};\\\", \\\"{x:1443,y:532,t:1528139583495};\\\", \\\"{x:1443,y:542,t:1528139583506};\\\", \\\"{x:1443,y:559,t:1528139583524};\\\", \\\"{x:1443,y:581,t:1528139583540};\\\", \\\"{x:1443,y:603,t:1528139583556};\\\", \\\"{x:1443,y:630,t:1528139583574};\\\", \\\"{x:1443,y:657,t:1528139583590};\\\", \\\"{x:1443,y:678,t:1528139583606};\\\", \\\"{x:1443,y:704,t:1528139583623};\\\", \\\"{x:1443,y:721,t:1528139583640};\\\", \\\"{x:1443,y:738,t:1528139583657};\\\", \\\"{x:1443,y:752,t:1528139583673};\\\", \\\"{x:1443,y:758,t:1528139583691};\\\", \\\"{x:1443,y:762,t:1528139583706};\\\", \\\"{x:1441,y:768,t:1528139583723};\\\", \\\"{x:1440,y:769,t:1528139583741};\\\", \\\"{x:1436,y:771,t:1528139583756};\\\", \\\"{x:1432,y:772,t:1528139583774};\\\", \\\"{x:1421,y:772,t:1528139583790};\\\", \\\"{x:1415,y:772,t:1528139583807};\\\", \\\"{x:1411,y:772,t:1528139583823};\\\", \\\"{x:1407,y:771,t:1528139583840};\\\", \\\"{x:1404,y:771,t:1528139583857};\\\", \\\"{x:1401,y:770,t:1528139583873};\\\", \\\"{x:1400,y:770,t:1528139583890};\\\", \\\"{x:1398,y:770,t:1528139583907};\\\", \\\"{x:1397,y:770,t:1528139583923};\\\", \\\"{x:1395,y:770,t:1528139583940};\\\", \\\"{x:1394,y:770,t:1528139583967};\\\", \\\"{x:1392,y:770,t:1528139584007};\\\", \\\"{x:1391,y:770,t:1528139584024};\\\", \\\"{x:1388,y:770,t:1528139584040};\\\", \\\"{x:1385,y:770,t:1528139584057};\\\", \\\"{x:1384,y:770,t:1528139584086};\\\", \\\"{x:1383,y:770,t:1528139584095};\\\", \\\"{x:1382,y:770,t:1528139584119};\\\", \\\"{x:1381,y:769,t:1528139584164};\\\", \\\"{x:1381,y:775,t:1528139586098};\\\", \\\"{x:1381,y:783,t:1528139586107};\\\", \\\"{x:1375,y:819,t:1528139586125};\\\", \\\"{x:1366,y:860,t:1528139586141};\\\", \\\"{x:1364,y:881,t:1528139586157};\\\", \\\"{x:1361,y:892,t:1528139586175};\\\", \\\"{x:1360,y:898,t:1528139586192};\\\", \\\"{x:1359,y:902,t:1528139586208};\\\", \\\"{x:1358,y:904,t:1528139586225};\\\", \\\"{x:1357,y:908,t:1528139586242};\\\", \\\"{x:1355,y:914,t:1528139586258};\\\", \\\"{x:1351,y:922,t:1528139586275};\\\", \\\"{x:1349,y:927,t:1528139586291};\\\", \\\"{x:1348,y:928,t:1528139586309};\\\", \\\"{x:1347,y:928,t:1528139586334};\\\", \\\"{x:1346,y:928,t:1528139586341};\\\", \\\"{x:1345,y:928,t:1528139586359};\\\", \\\"{x:1343,y:928,t:1528139586375};\\\", \\\"{x:1341,y:922,t:1528139586392};\\\", \\\"{x:1341,y:915,t:1528139586409};\\\", \\\"{x:1340,y:910,t:1528139586425};\\\", \\\"{x:1340,y:903,t:1528139586441};\\\", \\\"{x:1340,y:900,t:1528139586459};\\\", \\\"{x:1340,y:899,t:1528139586475};\\\", \\\"{x:1340,y:897,t:1528139586492};\\\", \\\"{x:1340,y:896,t:1528139586734};\\\", \\\"{x:1341,y:895,t:1528139586750};\\\", \\\"{x:1342,y:895,t:1528139586769};\\\", \\\"{x:1344,y:895,t:1528139586822};\\\", \\\"{x:1345,y:894,t:1528139586862};\\\", \\\"{x:1348,y:888,t:1528139587646};\\\", \\\"{x:1350,y:873,t:1528139587659};\\\", \\\"{x:1357,y:854,t:1528139587676};\\\", \\\"{x:1362,y:840,t:1528139587693};\\\", \\\"{x:1366,y:827,t:1528139587709};\\\", \\\"{x:1368,y:821,t:1528139587726};\\\", \\\"{x:1370,y:815,t:1528139587743};\\\", \\\"{x:1372,y:807,t:1528139587759};\\\", \\\"{x:1375,y:795,t:1528139587775};\\\", \\\"{x:1378,y:785,t:1528139587792};\\\", \\\"{x:1382,y:772,t:1528139587810};\\\", \\\"{x:1384,y:766,t:1528139587828};\\\", \\\"{x:1384,y:761,t:1528139587843};\\\", \\\"{x:1384,y:758,t:1528139587859};\\\", \\\"{x:1384,y:756,t:1528139587876};\\\", \\\"{x:1384,y:755,t:1528139587893};\\\", \\\"{x:1384,y:753,t:1528139587910};\\\", \\\"{x:1384,y:752,t:1528139587941};\\\", \\\"{x:1384,y:751,t:1528139587966};\\\", \\\"{x:1384,y:750,t:1528139587982};\\\", \\\"{x:1384,y:749,t:1528139588288};\\\", \\\"{x:1383,y:749,t:1528139588311};\\\", \\\"{x:1382,y:750,t:1528139588327};\\\", \\\"{x:1382,y:751,t:1528139588343};\\\", \\\"{x:1382,y:753,t:1528139588439};\\\", \\\"{x:1382,y:754,t:1528139588687};\\\", \\\"{x:1380,y:756,t:1528139588694};\\\", \\\"{x:1380,y:759,t:1528139588715};\\\", \\\"{x:1380,y:760,t:1528139588727};\\\", \\\"{x:1379,y:761,t:1528139588744};\\\", \\\"{x:1379,y:762,t:1528139588870};\\\", \\\"{x:1379,y:763,t:1528139588886};\\\", \\\"{x:1379,y:764,t:1528139588911};\\\", \\\"{x:1379,y:765,t:1528139588927};\\\", \\\"{x:1379,y:766,t:1528139588944};\\\", \\\"{x:1379,y:767,t:1528139591079};\\\", \\\"{x:1440,y:733,t:1528139591099};\\\", \\\"{x:1549,y:670,t:1528139591112};\\\", \\\"{x:1666,y:610,t:1528139591129};\\\", \\\"{x:1765,y:570,t:1528139591145};\\\", \\\"{x:1816,y:546,t:1528139591162};\\\", \\\"{x:1826,y:542,t:1528139591179};\\\", \\\"{x:1826,y:541,t:1528139591196};\\\", \\\"{x:1825,y:541,t:1528139591238};\\\", \\\"{x:1823,y:540,t:1528139591246};\\\", \\\"{x:1814,y:536,t:1528139591262};\\\", \\\"{x:1794,y:536,t:1528139591279};\\\", \\\"{x:1760,y:536,t:1528139591296};\\\", \\\"{x:1701,y:537,t:1528139591312};\\\", \\\"{x:1644,y:547,t:1528139591329};\\\", \\\"{x:1598,y:557,t:1528139591346};\\\", \\\"{x:1572,y:566,t:1528139591362};\\\", \\\"{x:1560,y:573,t:1528139591380};\\\", \\\"{x:1551,y:582,t:1528139591397};\\\", \\\"{x:1544,y:591,t:1528139591412};\\\", \\\"{x:1536,y:602,t:1528139591430};\\\", \\\"{x:1529,y:614,t:1528139591446};\\\", \\\"{x:1525,y:619,t:1528139591463};\\\", \\\"{x:1521,y:622,t:1528139591479};\\\", \\\"{x:1519,y:625,t:1528139591496};\\\", \\\"{x:1519,y:626,t:1528139591539};\\\", \\\"{x:1518,y:626,t:1528139591562};\\\", \\\"{x:1518,y:628,t:1528139591578};\\\", \\\"{x:1517,y:630,t:1528139591645};\\\", \\\"{x:1516,y:630,t:1528139591686};\\\", \\\"{x:1515,y:631,t:1528139591695};\\\", \\\"{x:1515,y:632,t:1528139591726};\\\", \\\"{x:1514,y:633,t:1528139591734};\\\", \\\"{x:1514,y:634,t:1528139591750};\\\", \\\"{x:1513,y:635,t:1528139591763};\\\", \\\"{x:1512,y:637,t:1528139591829};\\\", \\\"{x:1512,y:638,t:1528139591974};\\\", \\\"{x:1512,y:639,t:1528139592255};\\\", \\\"{x:1513,y:639,t:1528139592295};\\\", \\\"{x:1514,y:639,t:1528139592302};\\\", \\\"{x:1515,y:639,t:1528139592325};\\\", \\\"{x:1516,y:639,t:1528139592543};\\\", \\\"{x:1517,y:639,t:1528139592567};\\\", \\\"{x:1518,y:639,t:1528139592591};\\\", \\\"{x:1519,y:639,t:1528139592702};\\\", \\\"{x:1519,y:641,t:1528139592838};\\\", \\\"{x:1519,y:644,t:1528139592847};\\\", \\\"{x:1516,y:650,t:1528139592863};\\\", \\\"{x:1508,y:661,t:1528139592880};\\\", \\\"{x:1498,y:673,t:1528139592897};\\\", \\\"{x:1486,y:689,t:1528139592914};\\\", \\\"{x:1471,y:703,t:1528139592930};\\\", \\\"{x:1448,y:721,t:1528139592947};\\\", \\\"{x:1428,y:734,t:1528139592965};\\\", \\\"{x:1404,y:750,t:1528139592981};\\\", \\\"{x:1381,y:762,t:1528139592999};\\\", \\\"{x:1326,y:787,t:1528139593014};\\\", \\\"{x:1294,y:801,t:1528139593030};\\\", \\\"{x:1279,y:809,t:1528139593047};\\\", \\\"{x:1274,y:813,t:1528139593064};\\\", \\\"{x:1273,y:814,t:1528139593080};\\\", \\\"{x:1270,y:817,t:1528139593097};\\\", \\\"{x:1269,y:819,t:1528139593114};\\\", \\\"{x:1269,y:823,t:1528139593129};\\\", \\\"{x:1269,y:825,t:1528139593147};\\\", \\\"{x:1269,y:830,t:1528139593164};\\\", \\\"{x:1271,y:836,t:1528139593180};\\\", \\\"{x:1275,y:840,t:1528139593197};\\\", \\\"{x:1283,y:845,t:1528139593215};\\\", \\\"{x:1294,y:849,t:1528139593231};\\\", \\\"{x:1301,y:850,t:1528139593247};\\\", \\\"{x:1306,y:851,t:1528139593265};\\\", \\\"{x:1309,y:851,t:1528139593281};\\\", \\\"{x:1312,y:851,t:1528139593297};\\\", \\\"{x:1316,y:851,t:1528139593314};\\\", \\\"{x:1320,y:848,t:1528139593332};\\\", \\\"{x:1325,y:844,t:1528139593348};\\\", \\\"{x:1327,y:842,t:1528139593365};\\\", \\\"{x:1327,y:841,t:1528139593423};\\\", \\\"{x:1327,y:840,t:1528139593431};\\\", \\\"{x:1327,y:836,t:1528139593448};\\\", \\\"{x:1327,y:832,t:1528139593465};\\\", \\\"{x:1328,y:827,t:1528139593482};\\\", \\\"{x:1328,y:821,t:1528139593498};\\\", \\\"{x:1332,y:815,t:1528139593515};\\\", \\\"{x:1335,y:808,t:1528139593532};\\\", \\\"{x:1339,y:801,t:1528139593548};\\\", \\\"{x:1342,y:797,t:1528139593565};\\\", \\\"{x:1343,y:793,t:1528139593583};\\\", \\\"{x:1344,y:792,t:1528139593598};\\\", \\\"{x:1346,y:789,t:1528139593615};\\\", \\\"{x:1347,y:787,t:1528139593632};\\\", \\\"{x:1348,y:785,t:1528139593648};\\\", \\\"{x:1350,y:784,t:1528139593664};\\\", \\\"{x:1351,y:783,t:1528139593682};\\\", \\\"{x:1353,y:782,t:1528139593698};\\\", \\\"{x:1354,y:781,t:1528139593714};\\\", \\\"{x:1357,y:779,t:1528139593732};\\\", \\\"{x:1358,y:778,t:1528139593749};\\\", \\\"{x:1360,y:777,t:1528139593765};\\\", \\\"{x:1360,y:776,t:1528139593783};\\\", \\\"{x:1361,y:776,t:1528139593831};\\\", \\\"{x:1361,y:775,t:1528139593848};\\\", \\\"{x:1362,y:775,t:1528139594095};\\\", \\\"{x:1362,y:776,t:1528139594679};\\\", \\\"{x:1353,y:782,t:1528139594686};\\\", \\\"{x:1341,y:787,t:1528139594698};\\\", \\\"{x:1319,y:799,t:1528139594715};\\\", \\\"{x:1303,y:806,t:1528139594732};\\\", \\\"{x:1290,y:813,t:1528139594748};\\\", \\\"{x:1285,y:816,t:1528139594765};\\\", \\\"{x:1282,y:817,t:1528139594782};\\\", \\\"{x:1281,y:818,t:1528139594798};\\\", \\\"{x:1277,y:819,t:1528139594815};\\\", \\\"{x:1274,y:821,t:1528139594833};\\\", \\\"{x:1271,y:822,t:1528139594849};\\\", \\\"{x:1269,y:823,t:1528139594866};\\\", \\\"{x:1269,y:824,t:1528139595127};\\\", \\\"{x:1270,y:824,t:1528139595143};\\\", \\\"{x:1271,y:824,t:1528139595351};\\\", \\\"{x:1272,y:824,t:1528139595366};\\\", \\\"{x:1275,y:824,t:1528139595382};\\\", \\\"{x:1275,y:825,t:1528139595400};\\\", \\\"{x:1276,y:826,t:1528139595416};\\\", \\\"{x:1277,y:826,t:1528139595436};\\\", \\\"{x:1278,y:827,t:1528139595449};\\\", \\\"{x:1281,y:824,t:1528139596241};\\\", \\\"{x:1289,y:801,t:1528139596252};\\\", \\\"{x:1321,y:727,t:1528139596266};\\\", \\\"{x:1370,y:640,t:1528139596283};\\\", \\\"{x:1409,y:584,t:1528139596300};\\\", \\\"{x:1430,y:555,t:1528139596316};\\\", \\\"{x:1441,y:536,t:1528139596333};\\\", \\\"{x:1450,y:517,t:1528139596349};\\\", \\\"{x:1450,y:515,t:1528139596366};\\\", \\\"{x:1450,y:514,t:1528139596398};\\\", \\\"{x:1447,y:518,t:1528139596551};\\\", \\\"{x:1437,y:528,t:1528139596567};\\\", \\\"{x:1427,y:541,t:1528139596585};\\\", \\\"{x:1421,y:547,t:1528139596601};\\\", \\\"{x:1416,y:551,t:1528139596617};\\\", \\\"{x:1413,y:553,t:1528139596634};\\\", \\\"{x:1412,y:553,t:1528139596651};\\\", \\\"{x:1411,y:554,t:1528139596666};\\\", \\\"{x:1411,y:555,t:1528139596997};\\\", \\\"{x:1411,y:556,t:1528139597014};\\\", \\\"{x:1411,y:557,t:1528139597037};\\\", \\\"{x:1411,y:559,t:1528139597276};\\\", \\\"{x:1411,y:563,t:1528139597300};\\\", \\\"{x:1412,y:566,t:1528139597317};\\\", \\\"{x:1413,y:568,t:1528139597334};\\\", \\\"{x:1413,y:561,t:1528139598279};\\\", \\\"{x:1413,y:552,t:1528139598288};\\\", \\\"{x:1414,y:541,t:1528139598302};\\\", \\\"{x:1414,y:507,t:1528139598317};\\\", \\\"{x:1411,y:489,t:1528139598334};\\\", \\\"{x:1406,y:471,t:1528139598351};\\\", \\\"{x:1400,y:456,t:1528139598368};\\\", \\\"{x:1397,y:441,t:1528139598384};\\\", \\\"{x:1395,y:435,t:1528139598402};\\\", \\\"{x:1394,y:427,t:1528139598418};\\\", \\\"{x:1393,y:421,t:1528139598435};\\\", \\\"{x:1393,y:417,t:1528139598452};\\\", \\\"{x:1393,y:413,t:1528139598468};\\\", \\\"{x:1393,y:411,t:1528139598486};\\\", \\\"{x:1393,y:409,t:1528139598501};\\\", \\\"{x:1393,y:407,t:1528139598518};\\\", \\\"{x:1393,y:406,t:1528139598536};\\\", \\\"{x:1394,y:406,t:1528139598558};\\\", \\\"{x:1395,y:405,t:1528139598569};\\\", \\\"{x:1396,y:405,t:1528139598590};\\\", \\\"{x:1397,y:405,t:1528139598602};\\\", \\\"{x:1400,y:405,t:1528139598619};\\\", \\\"{x:1404,y:407,t:1528139598636};\\\", \\\"{x:1406,y:408,t:1528139598652};\\\", \\\"{x:1407,y:410,t:1528139598668};\\\", \\\"{x:1408,y:410,t:1528139598685};\\\", \\\"{x:1409,y:411,t:1528139598701};\\\", \\\"{x:1409,y:412,t:1528139598719};\\\", \\\"{x:1409,y:413,t:1528139598736};\\\", \\\"{x:1410,y:415,t:1528139598752};\\\", \\\"{x:1411,y:418,t:1528139598769};\\\", \\\"{x:1413,y:422,t:1528139598786};\\\", \\\"{x:1415,y:427,t:1528139598802};\\\", \\\"{x:1416,y:429,t:1528139598818};\\\", \\\"{x:1416,y:432,t:1528139599335};\\\", \\\"{x:1411,y:450,t:1528139599355};\\\", \\\"{x:1404,y:466,t:1528139599369};\\\", \\\"{x:1399,y:477,t:1528139599385};\\\", \\\"{x:1395,y:486,t:1528139599402};\\\", \\\"{x:1393,y:493,t:1528139599420};\\\", \\\"{x:1390,y:504,t:1528139599435};\\\", \\\"{x:1388,y:515,t:1528139599452};\\\", \\\"{x:1384,y:525,t:1528139599469};\\\", \\\"{x:1381,y:535,t:1528139599486};\\\", \\\"{x:1376,y:550,t:1528139599502};\\\", \\\"{x:1375,y:556,t:1528139599519};\\\", \\\"{x:1370,y:564,t:1528139599535};\\\", \\\"{x:1366,y:573,t:1528139599553};\\\", \\\"{x:1363,y:579,t:1528139599570};\\\", \\\"{x:1362,y:582,t:1528139599585};\\\", \\\"{x:1359,y:587,t:1528139599602};\\\", \\\"{x:1354,y:593,t:1528139599620};\\\", \\\"{x:1349,y:599,t:1528139599637};\\\", \\\"{x:1343,y:609,t:1528139599652};\\\", \\\"{x:1339,y:614,t:1528139599670};\\\", \\\"{x:1334,y:620,t:1528139599686};\\\", \\\"{x:1333,y:621,t:1528139599702};\\\", \\\"{x:1332,y:622,t:1528139599719};\\\", \\\"{x:1331,y:623,t:1528139599736};\\\", \\\"{x:1331,y:624,t:1528139599753};\\\", \\\"{x:1330,y:624,t:1528139599775};\\\", \\\"{x:1329,y:625,t:1528139599798};\\\", \\\"{x:1328,y:625,t:1528139599814};\\\", \\\"{x:1327,y:625,t:1528139599855};\\\", \\\"{x:1325,y:627,t:1528139599870};\\\", \\\"{x:1321,y:630,t:1528139599887};\\\", \\\"{x:1316,y:632,t:1528139599907};\\\", \\\"{x:1313,y:634,t:1528139599919};\\\", \\\"{x:1311,y:634,t:1528139599936};\\\", \\\"{x:1308,y:637,t:1528139600167};\\\", \\\"{x:1305,y:644,t:1528139600175};\\\", \\\"{x:1300,y:655,t:1528139600186};\\\", \\\"{x:1286,y:684,t:1528139600202};\\\", \\\"{x:1274,y:712,t:1528139600220};\\\", \\\"{x:1265,y:737,t:1528139600237};\\\", \\\"{x:1258,y:756,t:1528139600253};\\\", \\\"{x:1254,y:775,t:1528139600270};\\\", \\\"{x:1248,y:792,t:1528139600286};\\\", \\\"{x:1246,y:800,t:1528139600303};\\\", \\\"{x:1244,y:807,t:1528139600319};\\\", \\\"{x:1242,y:812,t:1528139600336};\\\", \\\"{x:1240,y:817,t:1528139600354};\\\", \\\"{x:1237,y:826,t:1528139600369};\\\", \\\"{x:1234,y:834,t:1528139600386};\\\", \\\"{x:1230,y:842,t:1528139600404};\\\", \\\"{x:1225,y:851,t:1528139600419};\\\", \\\"{x:1218,y:863,t:1528139600436};\\\", \\\"{x:1202,y:886,t:1528139600453};\\\", \\\"{x:1183,y:902,t:1528139600469};\\\", \\\"{x:1154,y:915,t:1528139600486};\\\", \\\"{x:1109,y:927,t:1528139600503};\\\", \\\"{x:1048,y:927,t:1528139600519};\\\", \\\"{x:965,y:917,t:1528139600536};\\\", \\\"{x:866,y:874,t:1528139600553};\\\", \\\"{x:761,y:807,t:1528139600569};\\\", \\\"{x:628,y:714,t:1528139600586};\\\", \\\"{x:506,y:634,t:1528139600604};\\\", \\\"{x:443,y:578,t:1528139600620};\\\", \\\"{x:408,y:532,t:1528139600636};\\\", \\\"{x:399,y:523,t:1528139600654};\\\", \\\"{x:410,y:533,t:1528139600910};\\\", \\\"{x:423,y:546,t:1528139600923};\\\", \\\"{x:484,y:588,t:1528139600938};\\\", \\\"{x:568,y:631,t:1528139600953};\\\", \\\"{x:690,y:669,t:1528139600971};\\\", \\\"{x:846,y:701,t:1528139600986};\\\", \\\"{x:1037,y:726,t:1528139601003};\\\", \\\"{x:1253,y:759,t:1528139601020};\\\", \\\"{x:1561,y:800,t:1528139601037};\\\", \\\"{x:1738,y:827,t:1528139601053};\\\", \\\"{x:1865,y:844,t:1528139601071};\\\", \\\"{x:1919,y:857,t:1528139601087};\\\", \\\"{x:1919,y:860,t:1528139601103};\\\", \\\"{x:1916,y:860,t:1528139601206};\\\", \\\"{x:1904,y:860,t:1528139601221};\\\", \\\"{x:1830,y:860,t:1528139601238};\\\", \\\"{x:1796,y:859,t:1528139601254};\\\", \\\"{x:1699,y:846,t:1528139601271};\\\", \\\"{x:1638,y:837,t:1528139601288};\\\", \\\"{x:1576,y:827,t:1528139601304};\\\", \\\"{x:1524,y:822,t:1528139601321};\\\", \\\"{x:1485,y:821,t:1528139601338};\\\", \\\"{x:1453,y:816,t:1528139601354};\\\", \\\"{x:1434,y:814,t:1528139601371};\\\", \\\"{x:1425,y:813,t:1528139601388};\\\", \\\"{x:1420,y:811,t:1528139601405};\\\", \\\"{x:1417,y:811,t:1528139601421};\\\", \\\"{x:1399,y:809,t:1528139601438};\\\", \\\"{x:1382,y:804,t:1528139601454};\\\", \\\"{x:1365,y:798,t:1528139601471};\\\", \\\"{x:1350,y:793,t:1528139601489};\\\", \\\"{x:1338,y:787,t:1528139601505};\\\", \\\"{x:1328,y:780,t:1528139601521};\\\", \\\"{x:1326,y:779,t:1528139601538};\\\", \\\"{x:1326,y:778,t:1528139601554};\\\", \\\"{x:1326,y:777,t:1528139601585};\\\", \\\"{x:1326,y:776,t:1528139601590};\\\", \\\"{x:1326,y:775,t:1528139601604};\\\", \\\"{x:1328,y:772,t:1528139601620};\\\", \\\"{x:1340,y:764,t:1528139601637};\\\", \\\"{x:1355,y:760,t:1528139601654};\\\", \\\"{x:1361,y:759,t:1528139601670};\\\", \\\"{x:1366,y:758,t:1528139601688};\\\", \\\"{x:1368,y:758,t:1528139601999};\\\", \\\"{x:1369,y:758,t:1528139602006};\\\", \\\"{x:1372,y:758,t:1528139602022};\\\", \\\"{x:1373,y:758,t:1528139602038};\\\", \\\"{x:1375,y:759,t:1528139602055};\\\", \\\"{x:1375,y:760,t:1528139602072};\\\", \\\"{x:1376,y:760,t:1528139602635};\\\", \\\"{x:1378,y:761,t:1528139602671};\\\", \\\"{x:1379,y:761,t:1528139602688};\\\", \\\"{x:1379,y:762,t:1528139602704};\\\", \\\"{x:1381,y:763,t:1528139602902};\\\", \\\"{x:1382,y:763,t:1528139602917};\\\", \\\"{x:1382,y:764,t:1528139602925};\\\", \\\"{x:1383,y:764,t:1528139602938};\\\", \\\"{x:1384,y:766,t:1528139602955};\\\", \\\"{x:1385,y:766,t:1528139602972};\\\", \\\"{x:1384,y:769,t:1528139604841};\\\", \\\"{x:1317,y:770,t:1528139604857};\\\", \\\"{x:1184,y:770,t:1528139604874};\\\", \\\"{x:991,y:751,t:1528139604889};\\\", \\\"{x:806,y:721,t:1528139604906};\\\", \\\"{x:631,y:688,t:1528139604923};\\\", \\\"{x:481,y:662,t:1528139604941};\\\", \\\"{x:393,y:642,t:1528139604958};\\\", \\\"{x:322,y:621,t:1528139604973};\\\", \\\"{x:306,y:616,t:1528139604990};\\\", \\\"{x:297,y:612,t:1528139605007};\\\", \\\"{x:287,y:607,t:1528139605024};\\\", \\\"{x:265,y:595,t:1528139605040};\\\", \\\"{x:200,y:569,t:1528139605057};\\\", \\\"{x:98,y:526,t:1528139605073};\\\", \\\"{x:2,y:492,t:1528139605091};\\\", \\\"{x:0,y:456,t:1528139605106};\\\", \\\"{x:0,y:441,t:1528139605124};\\\", \\\"{x:0,y:440,t:1528139605140};\\\", \\\"{x:0,y:439,t:1528139605165};\\\", \\\"{x:1,y:435,t:1528139605173};\\\", \\\"{x:20,y:429,t:1528139605190};\\\", \\\"{x:38,y:424,t:1528139605206};\\\", \\\"{x:64,y:424,t:1528139605224};\\\", \\\"{x:96,y:431,t:1528139605241};\\\", \\\"{x:150,y:458,t:1528139605256};\\\", \\\"{x:208,y:485,t:1528139605274};\\\", \\\"{x:254,y:511,t:1528139605291};\\\", \\\"{x:283,y:533,t:1528139605307};\\\", \\\"{x:295,y:544,t:1528139605324};\\\", \\\"{x:299,y:551,t:1528139605341};\\\", \\\"{x:301,y:557,t:1528139605357};\\\", \\\"{x:301,y:560,t:1528139605373};\\\", \\\"{x:301,y:562,t:1528139605390};\\\", \\\"{x:301,y:568,t:1528139605407};\\\", \\\"{x:301,y:573,t:1528139605424};\\\", \\\"{x:301,y:576,t:1528139605441};\\\", \\\"{x:301,y:578,t:1528139605457};\\\", \\\"{x:301,y:580,t:1528139605478};\\\", \\\"{x:302,y:580,t:1528139605490};\\\", \\\"{x:304,y:582,t:1528139605506};\\\", \\\"{x:311,y:586,t:1528139605524};\\\", \\\"{x:319,y:590,t:1528139605540};\\\", \\\"{x:341,y:598,t:1528139605557};\\\", \\\"{x:357,y:601,t:1528139605573};\\\", \\\"{x:373,y:605,t:1528139605591};\\\", \\\"{x:382,y:606,t:1528139605607};\\\", \\\"{x:385,y:606,t:1528139605623};\\\", \\\"{x:388,y:606,t:1528139605640};\\\", \\\"{x:389,y:606,t:1528139605658};\\\", \\\"{x:390,y:606,t:1528139605678};\\\", \\\"{x:392,y:606,t:1528139605691};\\\", \\\"{x:394,y:606,t:1528139605710};\\\", \\\"{x:393,y:606,t:1528139606518};\\\", \\\"{x:393,y:609,t:1528139606527};\\\", \\\"{x:398,y:627,t:1528139606543};\\\", \\\"{x:420,y:662,t:1528139606558};\\\", \\\"{x:457,y:713,t:1528139606575};\\\", \\\"{x:507,y:773,t:1528139606592};\\\", \\\"{x:564,y:834,t:1528139606607};\\\", \\\"{x:613,y:875,t:1528139606625};\\\", \\\"{x:635,y:887,t:1528139606642};\\\", \\\"{x:640,y:889,t:1528139606659};\\\", \\\"{x:640,y:887,t:1528139606719};\\\", \\\"{x:640,y:883,t:1528139606726};\\\", \\\"{x:639,y:869,t:1528139606742};\\\", \\\"{x:627,y:851,t:1528139606759};\\\", \\\"{x:608,y:830,t:1528139606776};\\\", \\\"{x:589,y:812,t:1528139606792};\\\", \\\"{x:570,y:796,t:1528139606809};\\\", \\\"{x:556,y:783,t:1528139606825};\\\", \\\"{x:546,y:774,t:1528139606843};\\\", \\\"{x:544,y:773,t:1528139606859};\\\", \\\"{x:542,y:770,t:1528139606876};\\\", \\\"{x:540,y:768,t:1528139606893};\\\", \\\"{x:538,y:765,t:1528139606909};\\\", \\\"{x:535,y:764,t:1528139606926};\\\", \\\"{x:534,y:763,t:1528139606941};\\\", \\\"{x:533,y:762,t:1528139606958};\\\" ] }, { \\\"rt\\\": 7836, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 299567, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:759,t:1528139610726};\\\", \\\"{x:614,y:754,t:1528139610747};\\\", \\\"{x:733,y:754,t:1528139610762};\\\", \\\"{x:879,y:754,t:1528139610777};\\\", \\\"{x:1045,y:754,t:1528139610795};\\\", \\\"{x:1247,y:754,t:1528139610811};\\\", \\\"{x:1443,y:754,t:1528139610828};\\\", \\\"{x:1623,y:752,t:1528139610844};\\\", \\\"{x:1782,y:741,t:1528139610861};\\\", \\\"{x:1919,y:704,t:1528139610877};\\\", \\\"{x:1919,y:678,t:1528139610895};\\\", \\\"{x:1919,y:656,t:1528139610911};\\\", \\\"{x:1919,y:640,t:1528139610927};\\\", \\\"{x:1919,y:627,t:1528139610945};\\\", \\\"{x:1919,y:618,t:1528139610962};\\\", \\\"{x:1919,y:606,t:1528139610978};\\\", \\\"{x:1919,y:603,t:1528139610994};\\\", \\\"{x:1919,y:601,t:1528139611012};\\\", \\\"{x:1919,y:599,t:1528139611070};\\\", \\\"{x:1914,y:596,t:1528139611078};\\\", \\\"{x:1895,y:594,t:1528139611095};\\\", \\\"{x:1877,y:592,t:1528139611112};\\\", \\\"{x:1861,y:591,t:1528139611129};\\\", \\\"{x:1839,y:591,t:1528139611145};\\\", \\\"{x:1821,y:593,t:1528139611162};\\\", \\\"{x:1804,y:598,t:1528139611179};\\\", \\\"{x:1787,y:603,t:1528139611195};\\\", \\\"{x:1771,y:605,t:1528139611212};\\\", \\\"{x:1764,y:607,t:1528139611229};\\\", \\\"{x:1762,y:608,t:1528139611245};\\\", \\\"{x:1759,y:608,t:1528139611263};\\\", \\\"{x:1757,y:608,t:1528139611279};\\\", \\\"{x:1753,y:608,t:1528139611295};\\\", \\\"{x:1749,y:608,t:1528139611312};\\\", \\\"{x:1745,y:608,t:1528139611329};\\\", \\\"{x:1742,y:608,t:1528139611345};\\\", \\\"{x:1739,y:608,t:1528139611362};\\\", \\\"{x:1737,y:608,t:1528139611379};\\\", \\\"{x:1734,y:607,t:1528139611396};\\\", \\\"{x:1729,y:603,t:1528139611413};\\\", \\\"{x:1722,y:599,t:1528139611430};\\\", \\\"{x:1707,y:587,t:1528139611445};\\\", \\\"{x:1673,y:564,t:1528139611462};\\\", \\\"{x:1642,y:546,t:1528139611480};\\\", \\\"{x:1608,y:529,t:1528139611495};\\\", \\\"{x:1579,y:517,t:1528139611512};\\\", \\\"{x:1556,y:507,t:1528139611529};\\\", \\\"{x:1536,y:499,t:1528139611546};\\\", \\\"{x:1521,y:489,t:1528139611562};\\\", \\\"{x:1514,y:485,t:1528139611579};\\\", \\\"{x:1508,y:482,t:1528139611596};\\\", \\\"{x:1504,y:480,t:1528139611613};\\\", \\\"{x:1501,y:478,t:1528139611630};\\\", \\\"{x:1500,y:478,t:1528139611646};\\\", \\\"{x:1497,y:478,t:1528139611662};\\\", \\\"{x:1495,y:478,t:1528139611679};\\\", \\\"{x:1493,y:479,t:1528139611696};\\\", \\\"{x:1490,y:482,t:1528139611712};\\\", \\\"{x:1484,y:495,t:1528139611729};\\\", \\\"{x:1479,y:512,t:1528139611746};\\\", \\\"{x:1476,y:523,t:1528139611762};\\\", \\\"{x:1476,y:529,t:1528139611780};\\\", \\\"{x:1476,y:531,t:1528139611797};\\\", \\\"{x:1479,y:534,t:1528139611812};\\\", \\\"{x:1481,y:534,t:1528139611830};\\\", \\\"{x:1496,y:534,t:1528139611846};\\\", \\\"{x:1516,y:532,t:1528139611863};\\\", \\\"{x:1545,y:520,t:1528139611879};\\\", \\\"{x:1581,y:505,t:1528139611896};\\\", \\\"{x:1603,y:493,t:1528139611913};\\\", \\\"{x:1614,y:488,t:1528139611929};\\\", \\\"{x:1617,y:485,t:1528139611947};\\\", \\\"{x:1618,y:484,t:1528139611963};\\\", \\\"{x:1618,y:483,t:1528139611980};\\\", \\\"{x:1619,y:482,t:1528139611996};\\\", \\\"{x:1619,y:480,t:1528139612013};\\\", \\\"{x:1619,y:477,t:1528139612029};\\\", \\\"{x:1619,y:473,t:1528139612047};\\\", \\\"{x:1619,y:470,t:1528139612063};\\\", \\\"{x:1619,y:465,t:1528139612079};\\\", \\\"{x:1619,y:462,t:1528139612097};\\\", \\\"{x:1619,y:456,t:1528139612113};\\\", \\\"{x:1618,y:452,t:1528139612130};\\\", \\\"{x:1618,y:448,t:1528139612146};\\\", \\\"{x:1618,y:447,t:1528139612163};\\\", \\\"{x:1618,y:443,t:1528139612179};\\\", \\\"{x:1618,y:440,t:1528139612196};\\\", \\\"{x:1618,y:438,t:1528139612214};\\\", \\\"{x:1618,y:435,t:1528139612230};\\\", \\\"{x:1619,y:431,t:1528139612259};\\\", \\\"{x:1619,y:430,t:1528139612279};\\\", \\\"{x:1619,y:429,t:1528139612296};\\\", \\\"{x:1619,y:428,t:1528139612313};\\\", \\\"{x:1618,y:428,t:1528139614247};\\\", \\\"{x:1547,y:451,t:1528139614267};\\\", \\\"{x:1413,y:476,t:1528139614280};\\\", \\\"{x:1227,y:506,t:1528139614296};\\\", \\\"{x:1007,y:533,t:1528139614314};\\\", \\\"{x:772,y:536,t:1528139614331};\\\", \\\"{x:562,y:536,t:1528139614348};\\\", \\\"{x:448,y:536,t:1528139614364};\\\", \\\"{x:384,y:536,t:1528139614381};\\\", \\\"{x:367,y:537,t:1528139614397};\\\", \\\"{x:366,y:537,t:1528139614453};\\\", \\\"{x:365,y:538,t:1528139614464};\\\", \\\"{x:361,y:541,t:1528139614480};\\\", \\\"{x:353,y:545,t:1528139614499};\\\", \\\"{x:344,y:553,t:1528139614515};\\\", \\\"{x:338,y:559,t:1528139614531};\\\", \\\"{x:336,y:561,t:1528139614548};\\\", \\\"{x:336,y:563,t:1528139614565};\\\", \\\"{x:336,y:567,t:1528139614580};\\\", \\\"{x:342,y:578,t:1528139614598};\\\", \\\"{x:355,y:588,t:1528139614615};\\\", \\\"{x:380,y:599,t:1528139614631};\\\", \\\"{x:412,y:609,t:1528139614648};\\\", \\\"{x:437,y:616,t:1528139614665};\\\", \\\"{x:452,y:619,t:1528139614681};\\\", \\\"{x:454,y:620,t:1528139614698};\\\", \\\"{x:454,y:621,t:1528139614750};\\\", \\\"{x:453,y:621,t:1528139614765};\\\", \\\"{x:446,y:621,t:1528139614781};\\\", \\\"{x:434,y:621,t:1528139614798};\\\", \\\"{x:422,y:621,t:1528139614815};\\\", \\\"{x:409,y:619,t:1528139614832};\\\", \\\"{x:402,y:617,t:1528139614850};\\\", \\\"{x:396,y:614,t:1528139614865};\\\", \\\"{x:390,y:611,t:1528139614881};\\\", \\\"{x:383,y:608,t:1528139614899};\\\", \\\"{x:378,y:606,t:1528139614915};\\\", \\\"{x:376,y:605,t:1528139614931};\\\", \\\"{x:377,y:606,t:1528139615045};\\\", \\\"{x:378,y:607,t:1528139615054};\\\", \\\"{x:379,y:609,t:1528139615065};\\\", \\\"{x:383,y:613,t:1528139615081};\\\", \\\"{x:386,y:616,t:1528139615098};\\\", \\\"{x:387,y:618,t:1528139615115};\\\", \\\"{x:388,y:620,t:1528139615132};\\\", \\\"{x:389,y:620,t:1528139615148};\\\", \\\"{x:389,y:621,t:1528139615165};\\\", \\\"{x:389,y:622,t:1528139615358};\\\", \\\"{x:389,y:623,t:1528139615366};\\\", \\\"{x:389,y:623,t:1528139615378};\\\", \\\"{x:389,y:627,t:1528139615399};\\\", \\\"{x:396,y:635,t:1528139615415};\\\", \\\"{x:410,y:648,t:1528139615432};\\\", \\\"{x:431,y:667,t:1528139615450};\\\", \\\"{x:471,y:713,t:1528139615465};\\\", \\\"{x:516,y:766,t:1528139615482};\\\", \\\"{x:562,y:820,t:1528139615499};\\\", \\\"{x:599,y:862,t:1528139615514};\\\", \\\"{x:626,y:895,t:1528139615532};\\\", \\\"{x:639,y:912,t:1528139615547};\\\", \\\"{x:646,y:919,t:1528139615565};\\\", \\\"{x:646,y:916,t:1528139615621};\\\", \\\"{x:646,y:904,t:1528139615632};\\\", \\\"{x:639,y:883,t:1528139615647};\\\", \\\"{x:622,y:857,t:1528139615665};\\\", \\\"{x:604,y:836,t:1528139615681};\\\", \\\"{x:588,y:818,t:1528139615698};\\\", \\\"{x:567,y:805,t:1528139615715};\\\", \\\"{x:551,y:794,t:1528139615732};\\\", \\\"{x:535,y:783,t:1528139615749};\\\", \\\"{x:521,y:776,t:1528139615765};\\\", \\\"{x:513,y:771,t:1528139615782};\\\", \\\"{x:512,y:770,t:1528139615798};\\\", \\\"{x:511,y:770,t:1528139615815};\\\", \\\"{x:511,y:769,t:1528139615831};\\\" ] }, { \\\"rt\\\": 11023, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 311798, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 PM-03 PM-C -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:768,t:1528139618602};\\\", \\\"{x:521,y:755,t:1528139618610};\\\", \\\"{x:539,y:738,t:1528139618622};\\\", \\\"{x:574,y:711,t:1528139618639};\\\", \\\"{x:602,y:690,t:1528139618655};\\\", \\\"{x:630,y:666,t:1528139618671};\\\", \\\"{x:650,y:645,t:1528139618688};\\\", \\\"{x:669,y:615,t:1528139618704};\\\", \\\"{x:681,y:593,t:1528139618722};\\\", \\\"{x:692,y:576,t:1528139618738};\\\", \\\"{x:696,y:568,t:1528139618754};\\\", \\\"{x:698,y:564,t:1528139618771};\\\", \\\"{x:699,y:563,t:1528139618787};\\\", \\\"{x:699,y:562,t:1528139618937};\\\", \\\"{x:695,y:562,t:1528139618945};\\\", \\\"{x:690,y:562,t:1528139618954};\\\", \\\"{x:683,y:559,t:1528139618971};\\\", \\\"{x:675,y:559,t:1528139618989};\\\", \\\"{x:671,y:558,t:1528139619004};\\\", \\\"{x:670,y:558,t:1528139619021};\\\", \\\"{x:670,y:557,t:1528139619409};\\\", \\\"{x:670,y:555,t:1528139619422};\\\", \\\"{x:694,y:552,t:1528139619438};\\\", \\\"{x:782,y:576,t:1528139619457};\\\", \\\"{x:904,y:612,t:1528139619472};\\\", \\\"{x:1144,y:669,t:1528139619488};\\\", \\\"{x:1329,y:701,t:1528139619505};\\\", \\\"{x:1518,y:735,t:1528139619523};\\\", \\\"{x:1692,y:762,t:1528139619539};\\\", \\\"{x:1844,y:806,t:1528139619555};\\\", \\\"{x:1919,y:837,t:1528139619573};\\\", \\\"{x:1919,y:863,t:1528139619588};\\\", \\\"{x:1919,y:877,t:1528139619605};\\\", \\\"{x:1919,y:885,t:1528139619621};\\\", \\\"{x:1919,y:891,t:1528139619639};\\\", \\\"{x:1919,y:893,t:1528139619655};\\\", \\\"{x:1918,y:898,t:1528139619671};\\\", \\\"{x:1911,y:910,t:1528139619688};\\\", \\\"{x:1905,y:920,t:1528139619705};\\\", \\\"{x:1899,y:930,t:1528139619721};\\\", \\\"{x:1893,y:943,t:1528139619738};\\\", \\\"{x:1887,y:955,t:1528139619756};\\\", \\\"{x:1884,y:963,t:1528139619772};\\\", \\\"{x:1880,y:968,t:1528139619789};\\\", \\\"{x:1875,y:976,t:1528139619806};\\\", \\\"{x:1871,y:981,t:1528139619822};\\\", \\\"{x:1868,y:985,t:1528139619839};\\\", \\\"{x:1862,y:991,t:1528139619855};\\\", \\\"{x:1848,y:999,t:1528139619873};\\\", \\\"{x:1843,y:1002,t:1528139619889};\\\", \\\"{x:1829,y:1008,t:1528139619906};\\\", \\\"{x:1816,y:1013,t:1528139619923};\\\", \\\"{x:1804,y:1018,t:1528139619939};\\\", \\\"{x:1789,y:1025,t:1528139619955};\\\", \\\"{x:1772,y:1033,t:1528139619972};\\\", \\\"{x:1759,y:1037,t:1528139619989};\\\", \\\"{x:1745,y:1038,t:1528139620005};\\\", \\\"{x:1731,y:1038,t:1528139620022};\\\", \\\"{x:1718,y:1038,t:1528139620039};\\\", \\\"{x:1709,y:1035,t:1528139620056};\\\", \\\"{x:1700,y:1033,t:1528139620073};\\\", \\\"{x:1698,y:1032,t:1528139620088};\\\", \\\"{x:1689,y:1029,t:1528139620106};\\\", \\\"{x:1686,y:1029,t:1528139620123};\\\", \\\"{x:1683,y:1028,t:1528139620139};\\\", \\\"{x:1679,y:1025,t:1528139620156};\\\", \\\"{x:1675,y:1024,t:1528139620173};\\\", \\\"{x:1672,y:1024,t:1528139620190};\\\", \\\"{x:1667,y:1024,t:1528139620206};\\\", \\\"{x:1664,y:1023,t:1528139620223};\\\", \\\"{x:1661,y:1023,t:1528139620240};\\\", \\\"{x:1657,y:1021,t:1528139620256};\\\", \\\"{x:1649,y:1019,t:1528139620273};\\\", \\\"{x:1646,y:1019,t:1528139620290};\\\", \\\"{x:1642,y:1018,t:1528139620306};\\\", \\\"{x:1640,y:1018,t:1528139620337};\\\", \\\"{x:1639,y:1018,t:1528139620386};\\\", \\\"{x:1639,y:1017,t:1528139620409};\\\", \\\"{x:1637,y:1017,t:1528139620433};\\\", \\\"{x:1636,y:1017,t:1528139620474};\\\", \\\"{x:1634,y:1017,t:1528139620513};\\\", \\\"{x:1633,y:1017,t:1528139620529};\\\", \\\"{x:1631,y:1017,t:1528139620545};\\\", \\\"{x:1630,y:1016,t:1528139620556};\\\", \\\"{x:1624,y:1014,t:1528139620573};\\\", \\\"{x:1613,y:1009,t:1528139620590};\\\", \\\"{x:1596,y:1003,t:1528139620606};\\\", \\\"{x:1578,y:995,t:1528139620623};\\\", \\\"{x:1562,y:984,t:1528139620640};\\\", \\\"{x:1536,y:959,t:1528139620658};\\\", \\\"{x:1527,y:949,t:1528139620673};\\\", \\\"{x:1488,y:904,t:1528139620690};\\\", \\\"{x:1460,y:879,t:1528139620707};\\\", \\\"{x:1437,y:857,t:1528139620723};\\\", \\\"{x:1423,y:845,t:1528139620740};\\\", \\\"{x:1412,y:834,t:1528139620757};\\\", \\\"{x:1405,y:827,t:1528139620773};\\\", \\\"{x:1397,y:817,t:1528139620790};\\\", \\\"{x:1391,y:811,t:1528139620807};\\\", \\\"{x:1383,y:802,t:1528139620823};\\\", \\\"{x:1379,y:799,t:1528139620840};\\\", \\\"{x:1374,y:794,t:1528139620857};\\\", \\\"{x:1372,y:792,t:1528139620873};\\\", \\\"{x:1371,y:791,t:1528139620890};\\\", \\\"{x:1373,y:789,t:1528139621010};\\\", \\\"{x:1392,y:780,t:1528139621023};\\\", \\\"{x:1452,y:754,t:1528139621040};\\\", \\\"{x:1514,y:728,t:1528139621058};\\\", \\\"{x:1533,y:722,t:1528139621073};\\\", \\\"{x:1540,y:719,t:1528139621090};\\\", \\\"{x:1541,y:718,t:1528139621129};\\\", \\\"{x:1542,y:716,t:1528139621146};\\\", \\\"{x:1543,y:711,t:1528139621157};\\\", \\\"{x:1543,y:699,t:1528139621174};\\\", \\\"{x:1548,y:684,t:1528139621190};\\\", \\\"{x:1554,y:657,t:1528139621207};\\\", \\\"{x:1557,y:639,t:1528139621224};\\\", \\\"{x:1557,y:627,t:1528139621240};\\\", \\\"{x:1557,y:610,t:1528139621257};\\\", \\\"{x:1554,y:604,t:1528139621273};\\\", \\\"{x:1552,y:599,t:1528139621290};\\\", \\\"{x:1549,y:595,t:1528139621307};\\\", \\\"{x:1546,y:592,t:1528139621324};\\\", \\\"{x:1543,y:590,t:1528139621340};\\\", \\\"{x:1539,y:590,t:1528139621357};\\\", \\\"{x:1537,y:589,t:1528139621374};\\\", \\\"{x:1534,y:589,t:1528139621390};\\\", \\\"{x:1530,y:589,t:1528139621406};\\\", \\\"{x:1525,y:590,t:1528139621423};\\\", \\\"{x:1514,y:596,t:1528139621440};\\\", \\\"{x:1500,y:603,t:1528139621456};\\\", \\\"{x:1487,y:610,t:1528139621473};\\\", \\\"{x:1472,y:618,t:1528139621490};\\\", \\\"{x:1460,y:626,t:1528139621506};\\\", \\\"{x:1447,y:635,t:1528139621524};\\\", \\\"{x:1433,y:643,t:1528139621540};\\\", \\\"{x:1421,y:649,t:1528139621556};\\\", \\\"{x:1412,y:656,t:1528139621573};\\\", \\\"{x:1405,y:667,t:1528139621591};\\\", \\\"{x:1402,y:675,t:1528139621607};\\\", \\\"{x:1401,y:685,t:1528139621624};\\\", \\\"{x:1403,y:704,t:1528139621641};\\\", \\\"{x:1414,y:726,t:1528139621657};\\\", \\\"{x:1438,y:755,t:1528139621674};\\\", \\\"{x:1486,y:790,t:1528139621690};\\\", \\\"{x:1565,y:832,t:1528139621706};\\\", \\\"{x:1669,y:875,t:1528139621723};\\\", \\\"{x:1771,y:901,t:1528139621740};\\\", \\\"{x:1879,y:913,t:1528139621756};\\\", \\\"{x:1919,y:915,t:1528139621773};\\\", \\\"{x:1919,y:913,t:1528139621817};\\\", \\\"{x:1919,y:911,t:1528139621833};\\\", \\\"{x:1919,y:910,t:1528139621840};\\\", \\\"{x:1919,y:895,t:1528139621857};\\\", \\\"{x:1919,y:871,t:1528139621874};\\\", \\\"{x:1909,y:830,t:1528139621890};\\\", \\\"{x:1887,y:782,t:1528139621908};\\\", \\\"{x:1857,y:733,t:1528139621924};\\\", \\\"{x:1825,y:690,t:1528139621941};\\\", \\\"{x:1799,y:656,t:1528139621958};\\\", \\\"{x:1783,y:631,t:1528139621974};\\\", \\\"{x:1776,y:616,t:1528139621991};\\\", \\\"{x:1765,y:600,t:1528139622008};\\\", \\\"{x:1755,y:577,t:1528139622024};\\\", \\\"{x:1744,y:557,t:1528139622041};\\\", \\\"{x:1742,y:552,t:1528139622058};\\\", \\\"{x:1741,y:551,t:1528139622074};\\\", \\\"{x:1741,y:550,t:1528139622226};\\\", \\\"{x:1736,y:550,t:1528139622242};\\\", \\\"{x:1723,y:557,t:1528139622258};\\\", \\\"{x:1705,y:574,t:1528139622275};\\\", \\\"{x:1684,y:595,t:1528139622291};\\\", \\\"{x:1663,y:612,t:1528139622308};\\\", \\\"{x:1635,y:640,t:1528139622325};\\\", \\\"{x:1610,y:661,t:1528139622341};\\\", \\\"{x:1589,y:678,t:1528139622358};\\\", \\\"{x:1563,y:698,t:1528139622375};\\\", \\\"{x:1543,y:715,t:1528139622391};\\\", \\\"{x:1527,y:723,t:1528139622408};\\\", \\\"{x:1516,y:730,t:1528139622424};\\\", \\\"{x:1493,y:739,t:1528139622442};\\\", \\\"{x:1482,y:742,t:1528139622458};\\\", \\\"{x:1477,y:745,t:1528139622477};\\\", \\\"{x:1473,y:747,t:1528139622491};\\\", \\\"{x:1467,y:753,t:1528139622508};\\\", \\\"{x:1456,y:767,t:1528139622525};\\\", \\\"{x:1436,y:786,t:1528139622541};\\\", \\\"{x:1405,y:805,t:1528139622558};\\\", \\\"{x:1369,y:820,t:1528139622575};\\\", \\\"{x:1352,y:822,t:1528139622591};\\\", \\\"{x:1346,y:822,t:1528139622609};\\\", \\\"{x:1344,y:822,t:1528139622625};\\\", \\\"{x:1341,y:824,t:1528139622642};\\\", \\\"{x:1327,y:828,t:1528139622658};\\\", \\\"{x:1305,y:836,t:1528139622677};\\\", \\\"{x:1271,y:842,t:1528139622691};\\\", \\\"{x:1239,y:845,t:1528139622708};\\\", \\\"{x:1211,y:845,t:1528139622725};\\\", \\\"{x:1194,y:845,t:1528139622741};\\\", \\\"{x:1190,y:845,t:1528139622759};\\\", \\\"{x:1194,y:844,t:1528139622937};\\\", \\\"{x:1195,y:843,t:1528139622946};\\\", \\\"{x:1200,y:841,t:1528139622958};\\\", \\\"{x:1203,y:839,t:1528139622975};\\\", \\\"{x:1206,y:838,t:1528139622992};\\\", \\\"{x:1207,y:838,t:1528139623025};\\\", \\\"{x:1207,y:837,t:1528139623049};\\\", \\\"{x:1208,y:837,t:1528139623058};\\\", \\\"{x:1209,y:836,t:1528139623090};\\\", \\\"{x:1210,y:836,t:1528139623097};\\\", \\\"{x:1211,y:836,t:1528139623210};\\\", \\\"{x:1211,y:835,t:1528139623234};\\\", \\\"{x:1212,y:835,t:1528139623316};\\\", \\\"{x:1213,y:835,t:1528139623368};\\\", \\\"{x:1214,y:835,t:1528139623393};\\\", \\\"{x:1215,y:834,t:1528139623408};\\\", \\\"{x:1216,y:834,t:1528139623441};\\\", \\\"{x:1217,y:833,t:1528139623488};\\\", \\\"{x:1218,y:833,t:1528139623504};\\\", \\\"{x:1219,y:833,t:1528139623528};\\\", \\\"{x:1221,y:832,t:1528139623547};\\\", \\\"{x:1219,y:832,t:1528139623957};\\\", \\\"{x:1219,y:833,t:1528139623991};\\\", \\\"{x:1218,y:833,t:1528139624169};\\\", \\\"{x:1103,y:802,t:1528139626110};\\\", \\\"{x:965,y:766,t:1528139626126};\\\", \\\"{x:869,y:730,t:1528139626143};\\\", \\\"{x:814,y:702,t:1528139626160};\\\", \\\"{x:806,y:696,t:1528139626176};\\\", \\\"{x:804,y:695,t:1528139626193};\\\", \\\"{x:801,y:690,t:1528139626211};\\\", \\\"{x:794,y:680,t:1528139626227};\\\", \\\"{x:788,y:671,t:1528139626243};\\\", \\\"{x:776,y:659,t:1528139626261};\\\", \\\"{x:767,y:648,t:1528139626277};\\\", \\\"{x:751,y:637,t:1528139626293};\\\", \\\"{x:724,y:627,t:1528139626310};\\\", \\\"{x:698,y:622,t:1528139626328};\\\", \\\"{x:669,y:619,t:1528139626343};\\\", \\\"{x:603,y:615,t:1528139626361};\\\", \\\"{x:550,y:615,t:1528139626377};\\\", \\\"{x:502,y:614,t:1528139626393};\\\", \\\"{x:473,y:612,t:1528139626411};\\\", \\\"{x:458,y:609,t:1528139626428};\\\", \\\"{x:444,y:606,t:1528139626443};\\\", \\\"{x:434,y:606,t:1528139626460};\\\", \\\"{x:420,y:604,t:1528139626478};\\\", \\\"{x:409,y:602,t:1528139626494};\\\", \\\"{x:393,y:599,t:1528139626510};\\\", \\\"{x:384,y:597,t:1528139626527};\\\", \\\"{x:381,y:597,t:1528139626544};\\\", \\\"{x:379,y:595,t:1528139626561};\\\", \\\"{x:378,y:595,t:1528139626650};\\\", \\\"{x:378,y:594,t:1528139626661};\\\", \\\"{x:380,y:594,t:1528139626677};\\\", \\\"{x:382,y:592,t:1528139626695};\\\", \\\"{x:385,y:591,t:1528139626711};\\\", \\\"{x:387,y:591,t:1528139627041};\\\", \\\"{x:394,y:592,t:1528139627049};\\\", \\\"{x:402,y:597,t:1528139627061};\\\", \\\"{x:422,y:608,t:1528139627078};\\\", \\\"{x:434,y:615,t:1528139627095};\\\", \\\"{x:446,y:622,t:1528139627111};\\\", \\\"{x:455,y:630,t:1528139627127};\\\", \\\"{x:465,y:639,t:1528139627144};\\\", \\\"{x:469,y:643,t:1528139627162};\\\", \\\"{x:473,y:647,t:1528139627178};\\\", \\\"{x:475,y:650,t:1528139627195};\\\", \\\"{x:480,y:657,t:1528139627213};\\\", \\\"{x:484,y:663,t:1528139627228};\\\", \\\"{x:486,y:666,t:1528139627245};\\\", \\\"{x:487,y:671,t:1528139627262};\\\", \\\"{x:489,y:676,t:1528139627278};\\\", \\\"{x:492,y:684,t:1528139627295};\\\", \\\"{x:493,y:691,t:1528139627313};\\\", \\\"{x:493,y:699,t:1528139627328};\\\", \\\"{x:494,y:717,t:1528139627345};\\\", \\\"{x:494,y:734,t:1528139627362};\\\", \\\"{x:494,y:748,t:1528139627379};\\\", \\\"{x:494,y:755,t:1528139627395};\\\", \\\"{x:494,y:759,t:1528139627411};\\\", \\\"{x:496,y:761,t:1528139627427};\\\", \\\"{x:496,y:762,t:1528139627445};\\\", \\\"{x:496,y:765,t:1528139627462};\\\", \\\"{x:497,y:768,t:1528139627478};\\\", \\\"{x:499,y:772,t:1528139627495};\\\", \\\"{x:501,y:775,t:1528139627512};\\\", \\\"{x:503,y:778,t:1528139627528};\\\", \\\"{x:507,y:783,t:1528139627545};\\\", \\\"{x:511,y:787,t:1528139627562};\\\", \\\"{x:512,y:789,t:1528139627579};\\\", \\\"{x:514,y:790,t:1528139627595};\\\", \\\"{x:515,y:790,t:1528139627616};\\\", \\\"{x:517,y:790,t:1528139627657};\\\", \\\"{x:519,y:790,t:1528139627673};\\\", \\\"{x:521,y:789,t:1528139627689};\\\", \\\"{x:522,y:786,t:1528139627697};\\\", \\\"{x:522,y:783,t:1528139627712};\\\", \\\"{x:522,y:773,t:1528139627729};\\\", \\\"{x:522,y:767,t:1528139627747};\\\", \\\"{x:522,y:763,t:1528139627761};\\\", \\\"{x:521,y:759,t:1528139627779};\\\", \\\"{x:520,y:756,t:1528139627795};\\\", \\\"{x:519,y:755,t:1528139627816};\\\", \\\"{x:518,y:755,t:1528139629313};\\\", \\\"{x:520,y:753,t:1528139629330};\\\", \\\"{x:524,y:749,t:1528139629347};\\\", \\\"{x:526,y:745,t:1528139629363};\\\", \\\"{x:527,y:745,t:1528139629380};\\\", \\\"{x:528,y:744,t:1528139629397};\\\" ] }, { \\\"rt\\\": 10808, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 323864, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:744,t:1528139631496};\\\", \\\"{x:530,y:743,t:1528139632065};\\\", \\\"{x:530,y:739,t:1528139632081};\\\", \\\"{x:532,y:733,t:1528139632100};\\\", \\\"{x:534,y:727,t:1528139632113};\\\", \\\"{x:537,y:719,t:1528139632131};\\\", \\\"{x:545,y:707,t:1528139632148};\\\", \\\"{x:557,y:697,t:1528139632164};\\\", \\\"{x:578,y:683,t:1528139632182};\\\", \\\"{x:622,y:662,t:1528139632199};\\\", \\\"{x:701,y:636,t:1528139632215};\\\", \\\"{x:826,y:616,t:1528139632232};\\\", \\\"{x:1078,y:589,t:1528139632248};\\\", \\\"{x:1291,y:589,t:1528139632264};\\\", \\\"{x:1515,y:589,t:1528139632282};\\\", \\\"{x:1735,y:561,t:1528139632299};\\\", \\\"{x:1906,y:539,t:1528139632315};\\\", \\\"{x:1919,y:535,t:1528139632332};\\\", \\\"{x:1919,y:537,t:1528139632360};\\\", \\\"{x:1919,y:543,t:1528139632368};\\\", \\\"{x:1919,y:550,t:1528139632382};\\\", \\\"{x:1919,y:569,t:1528139632398};\\\", \\\"{x:1919,y:594,t:1528139632416};\\\", \\\"{x:1919,y:634,t:1528139632432};\\\", \\\"{x:1919,y:658,t:1528139632448};\\\", \\\"{x:1919,y:682,t:1528139632466};\\\", \\\"{x:1919,y:708,t:1528139632483};\\\", \\\"{x:1919,y:728,t:1528139632499};\\\", \\\"{x:1919,y:745,t:1528139632516};\\\", \\\"{x:1919,y:762,t:1528139632533};\\\", \\\"{x:1915,y:780,t:1528139632549};\\\", \\\"{x:1903,y:795,t:1528139632567};\\\", \\\"{x:1881,y:811,t:1528139632584};\\\", \\\"{x:1862,y:824,t:1528139632600};\\\", \\\"{x:1845,y:837,t:1528139632616};\\\", \\\"{x:1830,y:846,t:1528139632633};\\\", \\\"{x:1809,y:857,t:1528139632649};\\\", \\\"{x:1801,y:863,t:1528139632666};\\\", \\\"{x:1796,y:865,t:1528139632682};\\\", \\\"{x:1792,y:868,t:1528139632699};\\\", \\\"{x:1789,y:869,t:1528139632717};\\\", \\\"{x:1787,y:869,t:1528139632732};\\\", \\\"{x:1784,y:871,t:1528139632749};\\\", \\\"{x:1778,y:875,t:1528139632767};\\\", \\\"{x:1771,y:879,t:1528139632783};\\\", \\\"{x:1763,y:883,t:1528139632799};\\\", \\\"{x:1754,y:886,t:1528139632816};\\\", \\\"{x:1736,y:890,t:1528139632834};\\\", \\\"{x:1716,y:895,t:1528139632849};\\\", \\\"{x:1698,y:899,t:1528139632867};\\\", \\\"{x:1681,y:905,t:1528139632883};\\\", \\\"{x:1666,y:912,t:1528139632900};\\\", \\\"{x:1656,y:918,t:1528139632917};\\\", \\\"{x:1646,y:926,t:1528139632934};\\\", \\\"{x:1638,y:933,t:1528139632949};\\\", \\\"{x:1636,y:939,t:1528139632967};\\\", \\\"{x:1633,y:946,t:1528139632984};\\\", \\\"{x:1630,y:952,t:1528139632999};\\\", \\\"{x:1628,y:960,t:1528139633016};\\\", \\\"{x:1624,y:979,t:1528139633033};\\\", \\\"{x:1623,y:989,t:1528139633050};\\\", \\\"{x:1623,y:994,t:1528139633066};\\\", \\\"{x:1622,y:995,t:1528139633083};\\\", \\\"{x:1620,y:995,t:1528139633185};\\\", \\\"{x:1619,y:994,t:1528139633200};\\\", \\\"{x:1617,y:989,t:1528139633216};\\\", \\\"{x:1613,y:981,t:1528139633234};\\\", \\\"{x:1612,y:977,t:1528139633249};\\\", \\\"{x:1610,y:972,t:1528139633266};\\\", \\\"{x:1609,y:968,t:1528139633284};\\\", \\\"{x:1609,y:967,t:1528139633300};\\\", \\\"{x:1609,y:966,t:1528139633316};\\\", \\\"{x:1609,y:965,t:1528139633333};\\\", \\\"{x:1609,y:964,t:1528139633481};\\\", \\\"{x:1610,y:964,t:1528139633521};\\\", \\\"{x:1610,y:963,t:1528139633534};\\\", \\\"{x:1611,y:963,t:1528139633561};\\\", \\\"{x:1612,y:963,t:1528139633569};\\\", \\\"{x:1613,y:962,t:1528139633586};\\\", \\\"{x:1614,y:962,t:1528139633602};\\\", \\\"{x:1615,y:962,t:1528139633616};\\\", \\\"{x:1616,y:962,t:1528139633634};\\\", \\\"{x:1617,y:961,t:1528139633688};\\\", \\\"{x:1619,y:960,t:1528139636777};\\\", \\\"{x:1611,y:936,t:1528139636787};\\\", \\\"{x:1518,y:849,t:1528139636803};\\\", \\\"{x:1418,y:775,t:1528139636819};\\\", \\\"{x:1303,y:712,t:1528139636836};\\\", \\\"{x:1177,y:658,t:1528139636852};\\\", \\\"{x:1071,y:623,t:1528139636869};\\\", \\\"{x:963,y:593,t:1528139636886};\\\", \\\"{x:874,y:568,t:1528139636902};\\\", \\\"{x:816,y:551,t:1528139636919};\\\", \\\"{x:742,y:535,t:1528139636936};\\\", \\\"{x:725,y:531,t:1528139636952};\\\", \\\"{x:664,y:514,t:1528139636969};\\\", \\\"{x:623,y:505,t:1528139636985};\\\", \\\"{x:559,y:486,t:1528139637002};\\\", \\\"{x:500,y:478,t:1528139637018};\\\", \\\"{x:458,y:472,t:1528139637035};\\\", \\\"{x:418,y:471,t:1528139637052};\\\", \\\"{x:383,y:469,t:1528139637068};\\\", \\\"{x:355,y:469,t:1528139637086};\\\", \\\"{x:339,y:471,t:1528139637102};\\\", \\\"{x:328,y:476,t:1528139637119};\\\", \\\"{x:319,y:484,t:1528139637136};\\\", \\\"{x:316,y:490,t:1528139637152};\\\", \\\"{x:316,y:496,t:1528139637170};\\\", \\\"{x:316,y:503,t:1528139637187};\\\", \\\"{x:316,y:506,t:1528139637202};\\\", \\\"{x:317,y:510,t:1528139637219};\\\", \\\"{x:319,y:515,t:1528139637236};\\\", \\\"{x:322,y:522,t:1528139637252};\\\", \\\"{x:326,y:530,t:1528139637270};\\\", \\\"{x:334,y:539,t:1528139637287};\\\", \\\"{x:340,y:546,t:1528139637304};\\\", \\\"{x:344,y:553,t:1528139637319};\\\", \\\"{x:350,y:558,t:1528139637336};\\\", \\\"{x:354,y:562,t:1528139637352};\\\", \\\"{x:361,y:567,t:1528139637370};\\\", \\\"{x:370,y:574,t:1528139637387};\\\", \\\"{x:377,y:579,t:1528139637403};\\\", \\\"{x:384,y:584,t:1528139637419};\\\", \\\"{x:387,y:586,t:1528139637436};\\\", \\\"{x:389,y:588,t:1528139637453};\\\", \\\"{x:391,y:590,t:1528139637469};\\\", \\\"{x:392,y:590,t:1528139637486};\\\", \\\"{x:393,y:590,t:1528139637503};\\\", \\\"{x:394,y:591,t:1528139637569};\\\", \\\"{x:394,y:592,t:1528139637665};\\\", \\\"{x:393,y:592,t:1528139637673};\\\", \\\"{x:391,y:592,t:1528139637687};\\\", \\\"{x:387,y:591,t:1528139637703};\\\", \\\"{x:380,y:587,t:1528139637721};\\\", \\\"{x:378,y:586,t:1528139637737};\\\", \\\"{x:376,y:585,t:1528139637754};\\\", \\\"{x:376,y:584,t:1528139637785};\\\", \\\"{x:381,y:584,t:1528139637977};\\\", \\\"{x:394,y:584,t:1528139637986};\\\", \\\"{x:455,y:584,t:1528139638005};\\\", \\\"{x:552,y:584,t:1528139638020};\\\", \\\"{x:660,y:584,t:1528139638037};\\\", \\\"{x:746,y:584,t:1528139638053};\\\", \\\"{x:781,y:585,t:1528139638069};\\\", \\\"{x:784,y:585,t:1528139638087};\\\", \\\"{x:784,y:587,t:1528139638103};\\\", \\\"{x:759,y:593,t:1528139638119};\\\", \\\"{x:703,y:601,t:1528139638137};\\\", \\\"{x:633,y:609,t:1528139638153};\\\", \\\"{x:574,y:619,t:1528139638171};\\\", \\\"{x:516,y:626,t:1528139638186};\\\", \\\"{x:469,y:632,t:1528139638204};\\\", \\\"{x:454,y:634,t:1528139638220};\\\", \\\"{x:449,y:636,t:1528139638237};\\\", \\\"{x:455,y:635,t:1528139638393};\\\", \\\"{x:467,y:630,t:1528139638403};\\\", \\\"{x:503,y:622,t:1528139638422};\\\", \\\"{x:570,y:605,t:1528139638437};\\\", \\\"{x:637,y:594,t:1528139638453};\\\", \\\"{x:679,y:589,t:1528139638470};\\\", \\\"{x:701,y:584,t:1528139638487};\\\", \\\"{x:710,y:583,t:1528139638504};\\\", \\\"{x:711,y:583,t:1528139638520};\\\", \\\"{x:712,y:582,t:1528139638568};\\\", \\\"{x:712,y:581,t:1528139638576};\\\", \\\"{x:711,y:579,t:1528139638587};\\\", \\\"{x:705,y:577,t:1528139638603};\\\", \\\"{x:699,y:575,t:1528139638620};\\\", \\\"{x:693,y:575,t:1528139638637};\\\", \\\"{x:680,y:575,t:1528139638653};\\\", \\\"{x:665,y:575,t:1528139638670};\\\", \\\"{x:654,y:575,t:1528139638686};\\\", \\\"{x:647,y:575,t:1528139638703};\\\", \\\"{x:637,y:577,t:1528139638721};\\\", \\\"{x:635,y:577,t:1528139638737};\\\", \\\"{x:635,y:578,t:1528139638754};\\\", \\\"{x:634,y:578,t:1528139638808};\\\", \\\"{x:633,y:579,t:1528139638832};\\\", \\\"{x:633,y:580,t:1528139638848};\\\", \\\"{x:633,y:581,t:1528139638896};\\\", \\\"{x:632,y:582,t:1528139638952};\\\", \\\"{x:632,y:583,t:1528139638969};\\\", \\\"{x:632,y:584,t:1528139639001};\\\", \\\"{x:632,y:585,t:1528139639016};\\\", \\\"{x:632,y:586,t:1528139639032};\\\", \\\"{x:632,y:587,t:1528139639065};\\\", \\\"{x:631,y:587,t:1528139639073};\\\", \\\"{x:631,y:588,t:1528139639089};\\\", \\\"{x:631,y:589,t:1528139639104};\\\", \\\"{x:630,y:589,t:1528139639465};\\\", \\\"{x:630,y:590,t:1528139639472};\\\", \\\"{x:629,y:590,t:1528139639488};\\\", \\\"{x:628,y:591,t:1528139639505};\\\", \\\"{x:627,y:592,t:1528139639521};\\\", \\\"{x:626,y:592,t:1528139639539};\\\", \\\"{x:624,y:593,t:1528139639555};\\\", \\\"{x:623,y:593,t:1528139639577};\\\", \\\"{x:622,y:593,t:1528139639593};\\\", \\\"{x:621,y:593,t:1528139639605};\\\", \\\"{x:616,y:596,t:1528139639622};\\\", \\\"{x:615,y:596,t:1528139639639};\\\", \\\"{x:615,y:597,t:1528139639856};\\\", \\\"{x:616,y:599,t:1528139639871};\\\", \\\"{x:616,y:603,t:1528139639888};\\\", \\\"{x:615,y:611,t:1528139639906};\\\", \\\"{x:610,y:625,t:1528139639922};\\\", \\\"{x:605,y:637,t:1528139639938};\\\", \\\"{x:599,y:649,t:1528139639956};\\\", \\\"{x:591,y:662,t:1528139639971};\\\", \\\"{x:586,y:672,t:1528139639988};\\\", \\\"{x:582,y:680,t:1528139640005};\\\", \\\"{x:580,y:683,t:1528139640021};\\\", \\\"{x:578,y:687,t:1528139640039};\\\", \\\"{x:577,y:691,t:1528139640055};\\\", \\\"{x:575,y:693,t:1528139640071};\\\", \\\"{x:571,y:699,t:1528139640088};\\\", \\\"{x:566,y:703,t:1528139640106};\\\", \\\"{x:559,y:708,t:1528139640122};\\\", \\\"{x:547,y:715,t:1528139640139};\\\", \\\"{x:537,y:718,t:1528139640155};\\\", \\\"{x:528,y:721,t:1528139640172};\\\", \\\"{x:519,y:723,t:1528139640188};\\\", \\\"{x:513,y:725,t:1528139640206};\\\", \\\"{x:508,y:727,t:1528139640222};\\\", \\\"{x:505,y:728,t:1528139640238};\\\", \\\"{x:503,y:729,t:1528139640255};\\\", \\\"{x:503,y:730,t:1528139640272};\\\", \\\"{x:503,y:732,t:1528139640306};\\\", \\\"{x:503,y:734,t:1528139640323};\\\", \\\"{x:503,y:737,t:1528139640340};\\\", \\\"{x:503,y:741,t:1528139640355};\\\", \\\"{x:504,y:744,t:1528139640372};\\\", \\\"{x:506,y:749,t:1528139640388};\\\", \\\"{x:508,y:751,t:1528139640405};\\\", \\\"{x:509,y:752,t:1528139640422};\\\", \\\"{x:511,y:752,t:1528139640680};\\\", \\\"{x:513,y:752,t:1528139640696};\\\", \\\"{x:516,y:752,t:1528139640706};\\\", \\\"{x:523,y:752,t:1528139640722};\\\", \\\"{x:541,y:752,t:1528139640739};\\\", \\\"{x:564,y:752,t:1528139640755};\\\", \\\"{x:596,y:752,t:1528139640772};\\\", \\\"{x:649,y:752,t:1528139640789};\\\", \\\"{x:683,y:752,t:1528139640805};\\\" ] }, { \\\"rt\\\": 16777, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 341973, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:682,y:757,t:1528139647386};\\\", \\\"{x:670,y:761,t:1528139647395};\\\", \\\"{x:594,y:778,t:1528139647410};\\\", \\\"{x:547,y:789,t:1528139647427};\\\", \\\"{x:541,y:791,t:1528139647444};\\\", \\\"{x:544,y:790,t:1528139647713};\\\", \\\"{x:546,y:790,t:1528139647728};\\\", \\\"{x:556,y:790,t:1528139647745};\\\", \\\"{x:566,y:790,t:1528139647763};\\\", \\\"{x:574,y:794,t:1528139647777};\\\", \\\"{x:578,y:796,t:1528139647795};\\\", \\\"{x:580,y:797,t:1528139647811};\\\", \\\"{x:581,y:798,t:1528139647828};\\\", \\\"{x:582,y:798,t:1528139647882};\\\", \\\"{x:583,y:798,t:1528139647895};\\\", \\\"{x:589,y:798,t:1528139647912};\\\", \\\"{x:603,y:798,t:1528139647928};\\\", \\\"{x:637,y:798,t:1528139647945};\\\", \\\"{x:679,y:798,t:1528139647962};\\\", \\\"{x:716,y:798,t:1528139647978};\\\", \\\"{x:772,y:790,t:1528139647995};\\\", \\\"{x:828,y:780,t:1528139648012};\\\", \\\"{x:888,y:767,t:1528139648028};\\\", \\\"{x:944,y:752,t:1528139648045};\\\", \\\"{x:991,y:738,t:1528139648062};\\\", \\\"{x:1034,y:725,t:1528139648078};\\\", \\\"{x:1067,y:716,t:1528139648095};\\\", \\\"{x:1102,y:704,t:1528139648112};\\\", \\\"{x:1163,y:689,t:1528139648129};\\\", \\\"{x:1201,y:679,t:1528139648145};\\\", \\\"{x:1248,y:667,t:1528139648162};\\\", \\\"{x:1298,y:653,t:1528139648179};\\\", \\\"{x:1352,y:637,t:1528139648195};\\\", \\\"{x:1405,y:619,t:1528139648213};\\\", \\\"{x:1452,y:598,t:1528139648229};\\\", \\\"{x:1495,y:575,t:1528139648245};\\\", \\\"{x:1540,y:543,t:1528139648262};\\\", \\\"{x:1568,y:517,t:1528139648279};\\\", \\\"{x:1581,y:498,t:1528139648295};\\\", \\\"{x:1593,y:479,t:1528139648312};\\\", \\\"{x:1600,y:463,t:1528139648329};\\\", \\\"{x:1600,y:460,t:1528139648345};\\\", \\\"{x:1600,y:459,t:1528139648474};\\\", \\\"{x:1591,y:459,t:1528139648481};\\\", \\\"{x:1579,y:459,t:1528139648495};\\\", \\\"{x:1550,y:467,t:1528139648512};\\\", \\\"{x:1499,y:480,t:1528139648529};\\\", \\\"{x:1476,y:487,t:1528139648546};\\\", \\\"{x:1455,y:492,t:1528139648562};\\\", \\\"{x:1442,y:495,t:1528139648579};\\\", \\\"{x:1438,y:497,t:1528139648596};\\\", \\\"{x:1435,y:497,t:1528139648612};\\\", \\\"{x:1432,y:500,t:1528139648629};\\\", \\\"{x:1426,y:505,t:1528139648646};\\\", \\\"{x:1423,y:509,t:1528139648663};\\\", \\\"{x:1414,y:514,t:1528139648679};\\\", \\\"{x:1408,y:517,t:1528139648696};\\\", \\\"{x:1401,y:519,t:1528139648713};\\\", \\\"{x:1396,y:520,t:1528139648729};\\\", \\\"{x:1394,y:520,t:1528139648747};\\\", \\\"{x:1390,y:520,t:1528139648762};\\\", \\\"{x:1382,y:520,t:1528139648779};\\\", \\\"{x:1375,y:520,t:1528139648796};\\\", \\\"{x:1369,y:520,t:1528139648812};\\\", \\\"{x:1363,y:520,t:1528139648830};\\\", \\\"{x:1358,y:520,t:1528139648847};\\\", \\\"{x:1352,y:520,t:1528139648862};\\\", \\\"{x:1346,y:520,t:1528139648878};\\\", \\\"{x:1338,y:520,t:1528139648896};\\\", \\\"{x:1329,y:520,t:1528139648912};\\\", \\\"{x:1324,y:520,t:1528139648928};\\\", \\\"{x:1323,y:520,t:1528139648946};\\\", \\\"{x:1322,y:520,t:1528139649162};\\\", \\\"{x:1321,y:520,t:1528139649169};\\\", \\\"{x:1321,y:519,t:1528139649178};\\\", \\\"{x:1320,y:518,t:1528139649195};\\\", \\\"{x:1319,y:517,t:1528139649212};\\\", \\\"{x:1318,y:516,t:1528139649232};\\\", \\\"{x:1318,y:515,t:1528139649248};\\\", \\\"{x:1317,y:514,t:1528139649280};\\\", \\\"{x:1317,y:513,t:1528139649344};\\\", \\\"{x:1316,y:513,t:1528139649352};\\\", \\\"{x:1316,y:512,t:1528139649369};\\\", \\\"{x:1316,y:511,t:1528139649379};\\\", \\\"{x:1316,y:510,t:1528139649408};\\\", \\\"{x:1316,y:509,t:1528139649425};\\\", \\\"{x:1316,y:508,t:1528139649466};\\\", \\\"{x:1316,y:507,t:1528139649489};\\\", \\\"{x:1316,y:506,t:1528139649497};\\\", \\\"{x:1316,y:505,t:1528139649529};\\\", \\\"{x:1316,y:504,t:1528139649546};\\\", \\\"{x:1316,y:503,t:1528139649585};\\\", \\\"{x:1316,y:502,t:1528139649640};\\\", \\\"{x:1316,y:501,t:1528139649662};\\\", \\\"{x:1316,y:500,t:1528139649688};\\\", \\\"{x:1316,y:499,t:1528139649719};\\\", \\\"{x:1315,y:498,t:1528139649736};\\\", \\\"{x:1315,y:497,t:1528139649752};\\\", \\\"{x:1315,y:498,t:1528139652233};\\\", \\\"{x:1315,y:500,t:1528139652248};\\\", \\\"{x:1315,y:504,t:1528139653124};\\\", \\\"{x:1318,y:520,t:1528139653149};\\\", \\\"{x:1320,y:528,t:1528139653166};\\\", \\\"{x:1323,y:540,t:1528139653182};\\\", \\\"{x:1324,y:557,t:1528139653198};\\\", \\\"{x:1324,y:570,t:1528139653216};\\\", \\\"{x:1325,y:591,t:1528139653231};\\\", \\\"{x:1325,y:609,t:1528139653249};\\\", \\\"{x:1325,y:625,t:1528139653266};\\\", \\\"{x:1325,y:639,t:1528139653281};\\\", \\\"{x:1325,y:648,t:1528139653299};\\\", \\\"{x:1325,y:652,t:1528139653316};\\\", \\\"{x:1325,y:653,t:1528139653333};\\\", \\\"{x:1325,y:655,t:1528139653409};\\\", \\\"{x:1325,y:653,t:1528139653497};\\\", \\\"{x:1325,y:651,t:1528139653513};\\\", \\\"{x:1325,y:650,t:1528139653521};\\\", \\\"{x:1323,y:648,t:1528139653533};\\\", \\\"{x:1321,y:644,t:1528139653550};\\\", \\\"{x:1320,y:642,t:1528139653566};\\\", \\\"{x:1320,y:640,t:1528139653583};\\\", \\\"{x:1319,y:638,t:1528139653599};\\\", \\\"{x:1318,y:636,t:1528139653616};\\\", \\\"{x:1317,y:633,t:1528139653637};\\\", \\\"{x:1316,y:632,t:1528139653649};\\\", \\\"{x:1316,y:630,t:1528139653666};\\\", \\\"{x:1315,y:629,t:1528139653682};\\\", \\\"{x:1314,y:627,t:1528139653704};\\\", \\\"{x:1313,y:626,t:1528139653720};\\\", \\\"{x:1313,y:625,t:1528139653736};\\\", \\\"{x:1313,y:624,t:1528139653750};\\\", \\\"{x:1313,y:623,t:1528139653783};\\\", \\\"{x:1312,y:622,t:1528139653816};\\\", \\\"{x:1312,y:623,t:1528139654105};\\\", \\\"{x:1311,y:625,t:1528139654120};\\\", \\\"{x:1311,y:626,t:1528139654133};\\\", \\\"{x:1311,y:627,t:1528139654150};\\\", \\\"{x:1311,y:628,t:1528139654167};\\\", \\\"{x:1311,y:629,t:1528139654183};\\\", \\\"{x:1310,y:630,t:1528139654199};\\\", \\\"{x:1304,y:633,t:1528139657028};\\\", \\\"{x:1157,y:644,t:1528139657052};\\\", \\\"{x:1021,y:644,t:1528139657069};\\\", \\\"{x:833,y:643,t:1528139657086};\\\", \\\"{x:656,y:618,t:1528139657102};\\\", \\\"{x:528,y:599,t:1528139657119};\\\", \\\"{x:427,y:586,t:1528139657136};\\\", \\\"{x:417,y:584,t:1528139657152};\\\", \\\"{x:422,y:587,t:1528139657305};\\\", \\\"{x:436,y:593,t:1528139657319};\\\", \\\"{x:540,y:611,t:1528139657337};\\\", \\\"{x:650,y:625,t:1528139657353};\\\", \\\"{x:770,y:631,t:1528139657369};\\\", \\\"{x:881,y:631,t:1528139657385};\\\", \\\"{x:956,y:631,t:1528139657402};\\\", \\\"{x:995,y:628,t:1528139657419};\\\", \\\"{x:1007,y:625,t:1528139657436};\\\", \\\"{x:1010,y:623,t:1528139657452};\\\", \\\"{x:1010,y:622,t:1528139657469};\\\", \\\"{x:1010,y:618,t:1528139657486};\\\", \\\"{x:1010,y:615,t:1528139657501};\\\", \\\"{x:1010,y:613,t:1528139657519};\\\", \\\"{x:1009,y:608,t:1528139657536};\\\", \\\"{x:1005,y:603,t:1528139657551};\\\", \\\"{x:995,y:593,t:1528139657569};\\\", \\\"{x:980,y:588,t:1528139657586};\\\", \\\"{x:953,y:582,t:1528139657602};\\\", \\\"{x:921,y:579,t:1528139657620};\\\", \\\"{x:884,y:572,t:1528139657636};\\\", \\\"{x:859,y:572,t:1528139657652};\\\", \\\"{x:847,y:572,t:1528139657669};\\\", \\\"{x:845,y:572,t:1528139657685};\\\", \\\"{x:843,y:572,t:1528139658016};\\\", \\\"{x:838,y:572,t:1528139658023};\\\", \\\"{x:829,y:579,t:1528139658036};\\\", \\\"{x:807,y:595,t:1528139658054};\\\", \\\"{x:777,y:616,t:1528139658069};\\\", \\\"{x:748,y:637,t:1528139658087};\\\", \\\"{x:729,y:654,t:1528139658103};\\\", \\\"{x:712,y:669,t:1528139658119};\\\", \\\"{x:689,y:691,t:1528139658137};\\\", \\\"{x:671,y:706,t:1528139658154};\\\", \\\"{x:643,y:726,t:1528139658170};\\\", \\\"{x:614,y:747,t:1528139658186};\\\", \\\"{x:600,y:757,t:1528139658203};\\\", \\\"{x:597,y:760,t:1528139658220};\\\", \\\"{x:596,y:760,t:1528139658236};\\\", \\\"{x:593,y:761,t:1528139658253};\\\", \\\"{x:586,y:761,t:1528139658270};\\\", \\\"{x:573,y:761,t:1528139658286};\\\", \\\"{x:565,y:761,t:1528139658303};\\\", \\\"{x:558,y:761,t:1528139658322};\\\", \\\"{x:554,y:761,t:1528139658337};\\\", \\\"{x:551,y:761,t:1528139658352};\\\", \\\"{x:549,y:761,t:1528139658370};\\\", \\\"{x:546,y:761,t:1528139658387};\\\", \\\"{x:545,y:761,t:1528139658403};\\\", \\\"{x:543,y:761,t:1528139658420};\\\", \\\"{x:542,y:761,t:1528139658437};\\\", \\\"{x:542,y:759,t:1528139659521};\\\", \\\"{x:542,y:757,t:1528139659537};\\\", \\\"{x:542,y:756,t:1528139659554};\\\" ] }, { \\\"rt\\\": 6013, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 349302, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:754,t:1528139660008};\\\", \\\"{x:542,y:753,t:1528139660160};\\\", \\\"{x:542,y:752,t:1528139660171};\\\", \\\"{x:542,y:751,t:1528139660188};\\\", \\\"{x:542,y:749,t:1528139660205};\\\", \\\"{x:542,y:748,t:1528139660221};\\\", \\\"{x:542,y:747,t:1528139660238};\\\", \\\"{x:542,y:746,t:1528139661162};\\\", \\\"{x:549,y:745,t:1528139661174};\\\", \\\"{x:566,y:737,t:1528139661191};\\\", \\\"{x:591,y:731,t:1528139661206};\\\", \\\"{x:632,y:731,t:1528139661222};\\\", \\\"{x:710,y:731,t:1528139661239};\\\", \\\"{x:801,y:731,t:1528139661255};\\\", \\\"{x:978,y:747,t:1528139661273};\\\", \\\"{x:1120,y:769,t:1528139661289};\\\", \\\"{x:1269,y:790,t:1528139661306};\\\", \\\"{x:1420,y:823,t:1528139661322};\\\", \\\"{x:1551,y:848,t:1528139661339};\\\", \\\"{x:1686,y:885,t:1528139661355};\\\", \\\"{x:1789,y:915,t:1528139661372};\\\", \\\"{x:1876,y:944,t:1528139661389};\\\", \\\"{x:1919,y:973,t:1528139661405};\\\", \\\"{x:1919,y:995,t:1528139661422};\\\", \\\"{x:1919,y:1015,t:1528139661439};\\\", \\\"{x:1919,y:1045,t:1528139661456};\\\", \\\"{x:1919,y:1061,t:1528139661472};\\\", \\\"{x:1919,y:1073,t:1528139661489};\\\", \\\"{x:1919,y:1083,t:1528139661507};\\\", \\\"{x:1919,y:1092,t:1528139661522};\\\", \\\"{x:1919,y:1097,t:1528139661539};\\\", \\\"{x:1919,y:1100,t:1528139661556};\\\", \\\"{x:1918,y:1100,t:1528139661657};\\\", \\\"{x:1913,y:1100,t:1528139661673};\\\", \\\"{x:1901,y:1097,t:1528139661690};\\\", \\\"{x:1890,y:1094,t:1528139661706};\\\", \\\"{x:1864,y:1086,t:1528139661722};\\\", \\\"{x:1831,y:1078,t:1528139661739};\\\", \\\"{x:1801,y:1071,t:1528139661756};\\\", \\\"{x:1746,y:1058,t:1528139661772};\\\", \\\"{x:1703,y:1049,t:1528139661789};\\\", \\\"{x:1665,y:1042,t:1528139661806};\\\", \\\"{x:1629,y:1037,t:1528139661822};\\\", \\\"{x:1601,y:1035,t:1528139661839};\\\", \\\"{x:1568,y:1029,t:1528139661856};\\\", \\\"{x:1555,y:1026,t:1528139661872};\\\", \\\"{x:1544,y:1024,t:1528139661889};\\\", \\\"{x:1537,y:1022,t:1528139661906};\\\", \\\"{x:1534,y:1021,t:1528139661922};\\\", \\\"{x:1533,y:1020,t:1528139661940};\\\", \\\"{x:1532,y:1020,t:1528139661969};\\\", \\\"{x:1531,y:1020,t:1528139662049};\\\", \\\"{x:1530,y:1020,t:1528139662065};\\\", \\\"{x:1529,y:1020,t:1528139662081};\\\", \\\"{x:1528,y:1020,t:1528139662090};\\\", \\\"{x:1527,y:1020,t:1528139662106};\\\", \\\"{x:1525,y:1020,t:1528139662123};\\\", \\\"{x:1524,y:1020,t:1528139662144};\\\", \\\"{x:1523,y:1020,t:1528139662168};\\\", \\\"{x:1522,y:1020,t:1528139662176};\\\", \\\"{x:1521,y:1020,t:1528139662200};\\\", \\\"{x:1520,y:1020,t:1528139662208};\\\", \\\"{x:1519,y:1020,t:1528139662223};\\\", \\\"{x:1517,y:1020,t:1528139662239};\\\", \\\"{x:1503,y:1010,t:1528139662256};\\\", \\\"{x:1478,y:989,t:1528139662273};\\\", \\\"{x:1409,y:929,t:1528139662289};\\\", \\\"{x:1314,y:832,t:1528139662306};\\\", \\\"{x:1219,y:741,t:1528139662323};\\\", \\\"{x:1134,y:668,t:1528139662339};\\\", \\\"{x:1046,y:599,t:1528139662357};\\\", \\\"{x:989,y:550,t:1528139662374};\\\", \\\"{x:963,y:520,t:1528139662389};\\\", \\\"{x:954,y:499,t:1528139662406};\\\", \\\"{x:948,y:485,t:1528139662423};\\\", \\\"{x:948,y:483,t:1528139662439};\\\", \\\"{x:947,y:482,t:1528139662456};\\\", \\\"{x:949,y:487,t:1528139662634};\\\", \\\"{x:971,y:510,t:1528139662656};\\\", \\\"{x:992,y:526,t:1528139662673};\\\", \\\"{x:1014,y:536,t:1528139662690};\\\", \\\"{x:1027,y:542,t:1528139662706};\\\", \\\"{x:1032,y:543,t:1528139662723};\\\", \\\"{x:1032,y:544,t:1528139662921};\\\", \\\"{x:1033,y:545,t:1528139662936};\\\", \\\"{x:1033,y:547,t:1528139663402};\\\", \\\"{x:1032,y:547,t:1528139663416};\\\", \\\"{x:1030,y:547,t:1528139663425};\\\", \\\"{x:1022,y:547,t:1528139663441};\\\", \\\"{x:1014,y:546,t:1528139663457};\\\", \\\"{x:1008,y:544,t:1528139663475};\\\", \\\"{x:999,y:543,t:1528139663491};\\\", \\\"{x:984,y:543,t:1528139663507};\\\", \\\"{x:969,y:543,t:1528139663525};\\\", \\\"{x:955,y:543,t:1528139663541};\\\", \\\"{x:945,y:543,t:1528139663558};\\\", \\\"{x:932,y:543,t:1528139663574};\\\", \\\"{x:912,y:543,t:1528139663591};\\\", \\\"{x:888,y:543,t:1528139663607};\\\", \\\"{x:857,y:543,t:1528139663625};\\\", \\\"{x:834,y:543,t:1528139663641};\\\", \\\"{x:809,y:543,t:1528139663657};\\\", \\\"{x:790,y:543,t:1528139663674};\\\", \\\"{x:780,y:543,t:1528139663690};\\\", \\\"{x:774,y:543,t:1528139663707};\\\", \\\"{x:770,y:543,t:1528139663724};\\\", \\\"{x:766,y:544,t:1528139663740};\\\", \\\"{x:762,y:545,t:1528139663757};\\\", \\\"{x:759,y:545,t:1528139663774};\\\", \\\"{x:754,y:545,t:1528139663792};\\\", \\\"{x:751,y:546,t:1528139663807};\\\", \\\"{x:746,y:546,t:1528139663824};\\\", \\\"{x:740,y:547,t:1528139663840};\\\", \\\"{x:726,y:550,t:1528139663857};\\\", \\\"{x:706,y:550,t:1528139663876};\\\", \\\"{x:677,y:550,t:1528139663891};\\\", \\\"{x:657,y:550,t:1528139663907};\\\", \\\"{x:639,y:550,t:1528139663924};\\\", \\\"{x:624,y:550,t:1528139663942};\\\", \\\"{x:619,y:549,t:1528139663958};\\\", \\\"{x:617,y:549,t:1528139663974};\\\", \\\"{x:616,y:547,t:1528139663991};\\\", \\\"{x:615,y:543,t:1528139664007};\\\", \\\"{x:614,y:535,t:1528139664024};\\\", \\\"{x:614,y:531,t:1528139664042};\\\", \\\"{x:614,y:527,t:1528139664058};\\\", \\\"{x:614,y:523,t:1528139664074};\\\", \\\"{x:614,y:520,t:1528139664091};\\\", \\\"{x:614,y:518,t:1528139664108};\\\", \\\"{x:615,y:516,t:1528139664125};\\\", \\\"{x:615,y:514,t:1528139664141};\\\", \\\"{x:615,y:511,t:1528139664157};\\\", \\\"{x:615,y:508,t:1528139664174};\\\", \\\"{x:615,y:506,t:1528139664191};\\\", \\\"{x:615,y:503,t:1528139664207};\\\", \\\"{x:615,y:500,t:1528139664224};\\\", \\\"{x:617,y:501,t:1528139664423};\\\", \\\"{x:635,y:513,t:1528139664442};\\\", \\\"{x:689,y:532,t:1528139664459};\\\", \\\"{x:759,y:542,t:1528139664475};\\\", \\\"{x:856,y:554,t:1528139664491};\\\", \\\"{x:939,y:565,t:1528139664509};\\\", \\\"{x:981,y:565,t:1528139664526};\\\", \\\"{x:1000,y:565,t:1528139664541};\\\", \\\"{x:1000,y:566,t:1528139664558};\\\", \\\"{x:1000,y:565,t:1528139664640};\\\", \\\"{x:994,y:562,t:1528139664648};\\\", \\\"{x:984,y:557,t:1528139664659};\\\", \\\"{x:963,y:552,t:1528139664676};\\\", \\\"{x:938,y:547,t:1528139664692};\\\", \\\"{x:912,y:543,t:1528139664708};\\\", \\\"{x:897,y:542,t:1528139664725};\\\", \\\"{x:892,y:541,t:1528139664741};\\\", \\\"{x:890,y:541,t:1528139664759};\\\", \\\"{x:889,y:541,t:1528139664777};\\\", \\\"{x:888,y:541,t:1528139664792};\\\", \\\"{x:886,y:541,t:1528139664809};\\\", \\\"{x:884,y:542,t:1528139664825};\\\", \\\"{x:881,y:543,t:1528139664842};\\\", \\\"{x:870,y:547,t:1528139664858};\\\", \\\"{x:861,y:549,t:1528139664877};\\\", \\\"{x:856,y:550,t:1528139664891};\\\", \\\"{x:855,y:550,t:1528139665135};\\\", \\\"{x:854,y:549,t:1528139665160};\\\", \\\"{x:853,y:549,t:1528139665175};\\\", \\\"{x:843,y:549,t:1528139665192};\\\", \\\"{x:824,y:549,t:1528139665208};\\\", \\\"{x:803,y:549,t:1528139665226};\\\", \\\"{x:781,y:549,t:1528139665242};\\\", \\\"{x:760,y:549,t:1528139665258};\\\", \\\"{x:736,y:549,t:1528139665276};\\\", \\\"{x:709,y:554,t:1528139665293};\\\", \\\"{x:692,y:558,t:1528139665310};\\\", \\\"{x:685,y:561,t:1528139665325};\\\", \\\"{x:683,y:563,t:1528139665343};\\\", \\\"{x:679,y:568,t:1528139665359};\\\", \\\"{x:673,y:575,t:1528139665375};\\\", \\\"{x:655,y:597,t:1528139665392};\\\", \\\"{x:639,y:624,t:1528139665410};\\\", \\\"{x:620,y:663,t:1528139665426};\\\", \\\"{x:586,y:726,t:1528139665443};\\\", \\\"{x:564,y:766,t:1528139665460};\\\", \\\"{x:554,y:779,t:1528139665475};\\\", \\\"{x:544,y:785,t:1528139665493};\\\", \\\"{x:529,y:791,t:1528139665510};\\\", \\\"{x:514,y:794,t:1528139665525};\\\", \\\"{x:501,y:796,t:1528139665542};\\\", \\\"{x:492,y:796,t:1528139665559};\\\", \\\"{x:487,y:796,t:1528139665575};\\\", \\\"{x:480,y:795,t:1528139665592};\\\", \\\"{x:477,y:794,t:1528139665610};\\\", \\\"{x:473,y:790,t:1528139665626};\\\", \\\"{x:467,y:784,t:1528139665643};\\\", \\\"{x:461,y:773,t:1528139665659};\\\", \\\"{x:457,y:764,t:1528139665676};\\\", \\\"{x:457,y:758,t:1528139665693};\\\", \\\"{x:457,y:752,t:1528139665711};\\\", \\\"{x:457,y:749,t:1528139665725};\\\", \\\"{x:459,y:744,t:1528139665742};\\\", \\\"{x:462,y:739,t:1528139665758};\\\", \\\"{x:466,y:734,t:1528139665776};\\\", \\\"{x:470,y:727,t:1528139665791};\\\", \\\"{x:473,y:724,t:1528139665808};\\\", \\\"{x:474,y:723,t:1528139665826};\\\", \\\"{x:475,y:722,t:1528139665848};\\\" ] }, { \\\"rt\\\": 31961, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 382504, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -H -O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:476,y:722,t:1528139672073};\\\", \\\"{x:512,y:721,t:1528139672088};\\\", \\\"{x:545,y:721,t:1528139672096};\\\", \\\"{x:592,y:721,t:1528139672110};\\\", \\\"{x:703,y:721,t:1528139672127};\\\", \\\"{x:893,y:728,t:1528139672148};\\\", \\\"{x:1031,y:750,t:1528139672165};\\\", \\\"{x:1175,y:771,t:1528139672181};\\\", \\\"{x:1306,y:792,t:1528139672197};\\\", \\\"{x:1406,y:808,t:1528139672215};\\\", \\\"{x:1470,y:817,t:1528139672230};\\\", \\\"{x:1498,y:821,t:1528139672247};\\\", \\\"{x:1499,y:821,t:1528139672265};\\\", \\\"{x:1500,y:821,t:1528139672304};\\\", \\\"{x:1500,y:817,t:1528139672315};\\\", \\\"{x:1499,y:813,t:1528139672331};\\\", \\\"{x:1498,y:810,t:1528139672352};\\\", \\\"{x:1497,y:809,t:1528139672365};\\\", \\\"{x:1494,y:806,t:1528139672382};\\\", \\\"{x:1489,y:802,t:1528139672398};\\\", \\\"{x:1479,y:797,t:1528139672415};\\\", \\\"{x:1459,y:791,t:1528139672432};\\\", \\\"{x:1445,y:787,t:1528139672448};\\\", \\\"{x:1428,y:782,t:1528139672464};\\\", \\\"{x:1412,y:778,t:1528139672482};\\\", \\\"{x:1391,y:772,t:1528139672497};\\\", \\\"{x:1367,y:765,t:1528139672514};\\\", \\\"{x:1335,y:755,t:1528139672532};\\\", \\\"{x:1311,y:752,t:1528139672547};\\\", \\\"{x:1286,y:747,t:1528139672565};\\\", \\\"{x:1264,y:742,t:1528139672582};\\\", \\\"{x:1234,y:737,t:1528139672597};\\\", \\\"{x:1189,y:730,t:1528139672615};\\\", \\\"{x:1141,y:721,t:1528139672632};\\\", \\\"{x:1129,y:719,t:1528139672648};\\\", \\\"{x:1093,y:704,t:1528139672665};\\\", \\\"{x:1080,y:696,t:1528139672683};\\\", \\\"{x:1074,y:693,t:1528139672700};\\\", \\\"{x:1073,y:691,t:1528139672715};\\\", \\\"{x:1073,y:689,t:1528139672732};\\\", \\\"{x:1072,y:686,t:1528139672750};\\\", \\\"{x:1072,y:683,t:1528139672765};\\\", \\\"{x:1071,y:678,t:1528139672782};\\\", \\\"{x:1071,y:674,t:1528139672799};\\\", \\\"{x:1071,y:668,t:1528139672815};\\\", \\\"{x:1071,y:663,t:1528139672832};\\\", \\\"{x:1071,y:660,t:1528139672849};\\\", \\\"{x:1071,y:656,t:1528139672866};\\\", \\\"{x:1071,y:653,t:1528139672882};\\\", \\\"{x:1071,y:649,t:1528139672899};\\\", \\\"{x:1070,y:646,t:1528139672915};\\\", \\\"{x:1070,y:642,t:1528139672932};\\\", \\\"{x:1069,y:638,t:1528139672950};\\\", \\\"{x:1068,y:636,t:1528139672965};\\\", \\\"{x:1067,y:634,t:1528139672982};\\\", \\\"{x:1067,y:632,t:1528139672999};\\\", \\\"{x:1066,y:630,t:1528139673015};\\\", \\\"{x:1065,y:628,t:1528139673033};\\\", \\\"{x:1065,y:627,t:1528139673065};\\\", \\\"{x:1065,y:626,t:1528139673081};\\\", \\\"{x:1065,y:625,t:1528139673121};\\\", \\\"{x:1065,y:624,t:1528139673439};\\\", \\\"{x:1065,y:623,t:1528139673455};\\\", \\\"{x:1067,y:623,t:1528139673480};\\\", \\\"{x:1068,y:622,t:1528139673504};\\\", \\\"{x:1070,y:622,t:1528139673585};\\\", \\\"{x:1076,y:623,t:1528139686603};\\\", \\\"{x:1112,y:653,t:1528139686614};\\\", \\\"{x:1251,y:749,t:1528139686630};\\\", \\\"{x:1424,y:853,t:1528139686647};\\\", \\\"{x:1604,y:945,t:1528139686664};\\\", \\\"{x:1781,y:1028,t:1528139686681};\\\", \\\"{x:1919,y:1084,t:1528139686697};\\\", \\\"{x:1919,y:1127,t:1528139686714};\\\", \\\"{x:1919,y:1130,t:1528139686729};\\\", \\\"{x:1919,y:1132,t:1528139686745};\\\", \\\"{x:1919,y:1130,t:1528139686819};\\\", \\\"{x:1919,y:1124,t:1528139686829};\\\", \\\"{x:1919,y:1108,t:1528139686846};\\\", \\\"{x:1911,y:1088,t:1528139686862};\\\", \\\"{x:1897,y:1066,t:1528139686879};\\\", \\\"{x:1878,y:1037,t:1528139686896};\\\", \\\"{x:1847,y:996,t:1528139686912};\\\", \\\"{x:1802,y:952,t:1528139686929};\\\", \\\"{x:1753,y:913,t:1528139686947};\\\", \\\"{x:1712,y:880,t:1528139686962};\\\", \\\"{x:1650,y:839,t:1528139686979};\\\", \\\"{x:1628,y:826,t:1528139686996};\\\", \\\"{x:1612,y:819,t:1528139687013};\\\", \\\"{x:1596,y:810,t:1528139687029};\\\", \\\"{x:1582,y:804,t:1528139687046};\\\", \\\"{x:1573,y:799,t:1528139687062};\\\", \\\"{x:1567,y:797,t:1528139687080};\\\", \\\"{x:1559,y:792,t:1528139687096};\\\", \\\"{x:1548,y:788,t:1528139687112};\\\", \\\"{x:1535,y:785,t:1528139687129};\\\", \\\"{x:1525,y:781,t:1528139687146};\\\", \\\"{x:1516,y:778,t:1528139687162};\\\", \\\"{x:1508,y:776,t:1528139687179};\\\", \\\"{x:1503,y:774,t:1528139687196};\\\", \\\"{x:1500,y:773,t:1528139687213};\\\", \\\"{x:1499,y:772,t:1528139687229};\\\", \\\"{x:1498,y:771,t:1528139687371};\\\", \\\"{x:1498,y:770,t:1528139687387};\\\", \\\"{x:1498,y:768,t:1528139687427};\\\", \\\"{x:1498,y:767,t:1528139687443};\\\", \\\"{x:1499,y:767,t:1528139687475};\\\", \\\"{x:1501,y:766,t:1528139687524};\\\", \\\"{x:1502,y:765,t:1528139687596};\\\", \\\"{x:1503,y:765,t:1528139687708};\\\", \\\"{x:1504,y:764,t:1528139687724};\\\", \\\"{x:1505,y:764,t:1528139687747};\\\", \\\"{x:1506,y:764,t:1528139687765};\\\", \\\"{x:1507,y:763,t:1528139687788};\\\", \\\"{x:1508,y:763,t:1528139687804};\\\", \\\"{x:1509,y:763,t:1528139687830};\\\", \\\"{x:1510,y:763,t:1528139687867};\\\", \\\"{x:1511,y:762,t:1528139687940};\\\", \\\"{x:1512,y:762,t:1528139688092};\\\", \\\"{x:1512,y:761,t:1528139688140};\\\", \\\"{x:1513,y:761,t:1528139688164};\\\", \\\"{x:1514,y:761,t:1528139688195};\\\", \\\"{x:1514,y:763,t:1528139688508};\\\", \\\"{x:1513,y:770,t:1528139688517};\\\", \\\"{x:1511,y:776,t:1528139688531};\\\", \\\"{x:1504,y:794,t:1528139688548};\\\", \\\"{x:1502,y:800,t:1528139688564};\\\", \\\"{x:1500,y:808,t:1528139688581};\\\", \\\"{x:1497,y:815,t:1528139688598};\\\", \\\"{x:1496,y:820,t:1528139688615};\\\", \\\"{x:1493,y:827,t:1528139688631};\\\", \\\"{x:1493,y:831,t:1528139688648};\\\", \\\"{x:1491,y:837,t:1528139688664};\\\", \\\"{x:1490,y:841,t:1528139688681};\\\", \\\"{x:1489,y:843,t:1528139688698};\\\", \\\"{x:1489,y:845,t:1528139688715};\\\", \\\"{x:1488,y:846,t:1528139688732};\\\", \\\"{x:1488,y:847,t:1528139688748};\\\", \\\"{x:1487,y:847,t:1528139688812};\\\", \\\"{x:1487,y:848,t:1528139688924};\\\", \\\"{x:1487,y:849,t:1528139688932};\\\", \\\"{x:1485,y:853,t:1528139688948};\\\", \\\"{x:1485,y:856,t:1528139688965};\\\", \\\"{x:1485,y:862,t:1528139688981};\\\", \\\"{x:1485,y:867,t:1528139688999};\\\", \\\"{x:1485,y:871,t:1528139689016};\\\", \\\"{x:1485,y:875,t:1528139689032};\\\", \\\"{x:1485,y:878,t:1528139689048};\\\", \\\"{x:1485,y:881,t:1528139689065};\\\", \\\"{x:1485,y:882,t:1528139689080};\\\", \\\"{x:1485,y:884,t:1528139689097};\\\", \\\"{x:1485,y:887,t:1528139689115};\\\", \\\"{x:1485,y:889,t:1528139689131};\\\", \\\"{x:1485,y:891,t:1528139689147};\\\", \\\"{x:1485,y:892,t:1528139689179};\\\", \\\"{x:1485,y:893,t:1528139689211};\\\", \\\"{x:1483,y:888,t:1528139690140};\\\", \\\"{x:1477,y:876,t:1528139690149};\\\", \\\"{x:1456,y:849,t:1528139690166};\\\", \\\"{x:1423,y:815,t:1528139690182};\\\", \\\"{x:1389,y:785,t:1528139690199};\\\", \\\"{x:1361,y:765,t:1528139690216};\\\", \\\"{x:1335,y:747,t:1528139690232};\\\", \\\"{x:1316,y:732,t:1528139690249};\\\", \\\"{x:1298,y:720,t:1528139690266};\\\", \\\"{x:1277,y:705,t:1528139690283};\\\", \\\"{x:1261,y:697,t:1528139690299};\\\", \\\"{x:1237,y:683,t:1528139690315};\\\", \\\"{x:1214,y:670,t:1528139690332};\\\", \\\"{x:1191,y:657,t:1528139690350};\\\", \\\"{x:1170,y:645,t:1528139690366};\\\", \\\"{x:1148,y:635,t:1528139690383};\\\", \\\"{x:1127,y:626,t:1528139690399};\\\", \\\"{x:1112,y:619,t:1528139690416};\\\", \\\"{x:1107,y:617,t:1528139690432};\\\", \\\"{x:1104,y:616,t:1528139690448};\\\", \\\"{x:1095,y:612,t:1528139690466};\\\", \\\"{x:1081,y:606,t:1528139690483};\\\", \\\"{x:1077,y:604,t:1528139690499};\\\", \\\"{x:1075,y:604,t:1528139690516};\\\", \\\"{x:1075,y:603,t:1528139690579};\\\", \\\"{x:1077,y:601,t:1528139690587};\\\", \\\"{x:1083,y:599,t:1528139690599};\\\", \\\"{x:1089,y:597,t:1528139690616};\\\", \\\"{x:1090,y:596,t:1528139690633};\\\", \\\"{x:1091,y:595,t:1528139690649};\\\", \\\"{x:1092,y:595,t:1528139690796};\\\", \\\"{x:1092,y:597,t:1528139690803};\\\", \\\"{x:1092,y:599,t:1528139690816};\\\", \\\"{x:1092,y:603,t:1528139690833};\\\", \\\"{x:1092,y:606,t:1528139690849};\\\", \\\"{x:1092,y:607,t:1528139690866};\\\", \\\"{x:1092,y:609,t:1528139691164};\\\", \\\"{x:1092,y:613,t:1528139691171};\\\", \\\"{x:1092,y:615,t:1528139691184};\\\", \\\"{x:1092,y:620,t:1528139691200};\\\", \\\"{x:1095,y:624,t:1528139691216};\\\", \\\"{x:1098,y:627,t:1528139691233};\\\", \\\"{x:1104,y:632,t:1528139691250};\\\", \\\"{x:1113,y:636,t:1528139691266};\\\", \\\"{x:1127,y:642,t:1528139691283};\\\", \\\"{x:1203,y:652,t:1528139691300};\\\", \\\"{x:1293,y:658,t:1528139691317};\\\", \\\"{x:1382,y:658,t:1528139691333};\\\", \\\"{x:1485,y:658,t:1528139691350};\\\", \\\"{x:1576,y:658,t:1528139691367};\\\", \\\"{x:1632,y:658,t:1528139691383};\\\", \\\"{x:1665,y:658,t:1528139691400};\\\", \\\"{x:1683,y:658,t:1528139691417};\\\", \\\"{x:1689,y:657,t:1528139691433};\\\", \\\"{x:1692,y:656,t:1528139691450};\\\", \\\"{x:1693,y:653,t:1528139691467};\\\", \\\"{x:1693,y:651,t:1528139691483};\\\", \\\"{x:1694,y:649,t:1528139691500};\\\", \\\"{x:1694,y:648,t:1528139691517};\\\", \\\"{x:1694,y:645,t:1528139691533};\\\", \\\"{x:1685,y:640,t:1528139691550};\\\", \\\"{x:1669,y:638,t:1528139691568};\\\", \\\"{x:1649,y:636,t:1528139691583};\\\", \\\"{x:1625,y:636,t:1528139691600};\\\", \\\"{x:1601,y:636,t:1528139691616};\\\", \\\"{x:1579,y:636,t:1528139691633};\\\", \\\"{x:1563,y:636,t:1528139691649};\\\", \\\"{x:1549,y:639,t:1528139691667};\\\", \\\"{x:1544,y:641,t:1528139691683};\\\", \\\"{x:1538,y:644,t:1528139691699};\\\", \\\"{x:1534,y:646,t:1528139691717};\\\", \\\"{x:1530,y:649,t:1528139691734};\\\", \\\"{x:1527,y:649,t:1528139691750};\\\", \\\"{x:1523,y:652,t:1528139691766};\\\", \\\"{x:1517,y:652,t:1528139691784};\\\", \\\"{x:1514,y:653,t:1528139691800};\\\", \\\"{x:1511,y:653,t:1528139691817};\\\", \\\"{x:1509,y:653,t:1528139691834};\\\", \\\"{x:1508,y:653,t:1528139691859};\\\", \\\"{x:1507,y:653,t:1528139691907};\\\", \\\"{x:1505,y:654,t:1528139692268};\\\", \\\"{x:1504,y:655,t:1528139692284};\\\", \\\"{x:1500,y:658,t:1528139692302};\\\", \\\"{x:1492,y:661,t:1528139692318};\\\", \\\"{x:1480,y:669,t:1528139692334};\\\", \\\"{x:1464,y:675,t:1528139692351};\\\", \\\"{x:1452,y:681,t:1528139692367};\\\", \\\"{x:1448,y:683,t:1528139692384};\\\", \\\"{x:1445,y:684,t:1528139692401};\\\", \\\"{x:1444,y:685,t:1528139692417};\\\", \\\"{x:1443,y:686,t:1528139692434};\\\", \\\"{x:1442,y:687,t:1528139692451};\\\", \\\"{x:1441,y:687,t:1528139692484};\\\", \\\"{x:1440,y:689,t:1528139692501};\\\", \\\"{x:1439,y:689,t:1528139692517};\\\", \\\"{x:1437,y:690,t:1528139692534};\\\", \\\"{x:1431,y:693,t:1528139692550};\\\", \\\"{x:1424,y:695,t:1528139692568};\\\", \\\"{x:1413,y:698,t:1528139692584};\\\", \\\"{x:1401,y:700,t:1528139692600};\\\", \\\"{x:1395,y:700,t:1528139692617};\\\", \\\"{x:1392,y:700,t:1528139692633};\\\", \\\"{x:1391,y:701,t:1528139692651};\\\", \\\"{x:1390,y:701,t:1528139692683};\\\", \\\"{x:1388,y:702,t:1528139692701};\\\", \\\"{x:1385,y:702,t:1528139692718};\\\", \\\"{x:1383,y:703,t:1528139692739};\\\", \\\"{x:1382,y:703,t:1528139692756};\\\", \\\"{x:1380,y:703,t:1528139692795};\\\", \\\"{x:1379,y:703,t:1528139692812};\\\", \\\"{x:1377,y:703,t:1528139692827};\\\", \\\"{x:1376,y:703,t:1528139692834};\\\", \\\"{x:1375,y:703,t:1528139692850};\\\", \\\"{x:1374,y:703,t:1528139692867};\\\", \\\"{x:1374,y:702,t:1528139693068};\\\", \\\"{x:1388,y:699,t:1528139693085};\\\", \\\"{x:1407,y:694,t:1528139693101};\\\", \\\"{x:1433,y:689,t:1528139693118};\\\", \\\"{x:1458,y:686,t:1528139693135};\\\", \\\"{x:1482,y:683,t:1528139693152};\\\", \\\"{x:1500,y:678,t:1528139693168};\\\", \\\"{x:1522,y:674,t:1528139693185};\\\", \\\"{x:1538,y:669,t:1528139693201};\\\", \\\"{x:1549,y:664,t:1528139693218};\\\", \\\"{x:1559,y:659,t:1528139693235};\\\", \\\"{x:1562,y:658,t:1528139693251};\\\", \\\"{x:1567,y:656,t:1528139693268};\\\", \\\"{x:1569,y:655,t:1528139693286};\\\", \\\"{x:1572,y:654,t:1528139693301};\\\", \\\"{x:1574,y:652,t:1528139693318};\\\", \\\"{x:1576,y:652,t:1528139693335};\\\", \\\"{x:1577,y:651,t:1528139693352};\\\", \\\"{x:1578,y:650,t:1528139693368};\\\", \\\"{x:1578,y:649,t:1528139693385};\\\", \\\"{x:1579,y:649,t:1528139693401};\\\", \\\"{x:1580,y:648,t:1528139693418};\\\", \\\"{x:1582,y:646,t:1528139693436};\\\", \\\"{x:1583,y:644,t:1528139693451};\\\", \\\"{x:1584,y:641,t:1528139693468};\\\", \\\"{x:1586,y:639,t:1528139693487};\\\", \\\"{x:1587,y:637,t:1528139693503};\\\", \\\"{x:1587,y:635,t:1528139693519};\\\", \\\"{x:1587,y:634,t:1528139693535};\\\", \\\"{x:1587,y:633,t:1528139693556};\\\", \\\"{x:1587,y:632,t:1528139693568};\\\", \\\"{x:1587,y:631,t:1528139693585};\\\", \\\"{x:1587,y:630,t:1528139693972};\\\", \\\"{x:1585,y:631,t:1528139693986};\\\", \\\"{x:1582,y:634,t:1528139694002};\\\", \\\"{x:1576,y:640,t:1528139694020};\\\", \\\"{x:1573,y:646,t:1528139694036};\\\", \\\"{x:1569,y:652,t:1528139694052};\\\", \\\"{x:1565,y:659,t:1528139694070};\\\", \\\"{x:1564,y:662,t:1528139694086};\\\", \\\"{x:1563,y:664,t:1528139694102};\\\", \\\"{x:1562,y:665,t:1528139694119};\\\", \\\"{x:1562,y:667,t:1528139694136};\\\", \\\"{x:1561,y:669,t:1528139694152};\\\", \\\"{x:1561,y:670,t:1528139694172};\\\", \\\"{x:1561,y:671,t:1528139694186};\\\", \\\"{x:1560,y:672,t:1528139694203};\\\", \\\"{x:1559,y:675,t:1528139694220};\\\", \\\"{x:1558,y:676,t:1528139694244};\\\", \\\"{x:1558,y:677,t:1528139694253};\\\", \\\"{x:1558,y:678,t:1528139694269};\\\", \\\"{x:1556,y:680,t:1528139694285};\\\", \\\"{x:1556,y:682,t:1528139694303};\\\", \\\"{x:1555,y:684,t:1528139694319};\\\", \\\"{x:1553,y:687,t:1528139694336};\\\", \\\"{x:1551,y:690,t:1528139694352};\\\", \\\"{x:1548,y:694,t:1528139694370};\\\", \\\"{x:1545,y:699,t:1528139694386};\\\", \\\"{x:1544,y:701,t:1528139694403};\\\", \\\"{x:1540,y:707,t:1528139694420};\\\", \\\"{x:1537,y:714,t:1528139694436};\\\", \\\"{x:1532,y:721,t:1528139694453};\\\", \\\"{x:1528,y:728,t:1528139694469};\\\", \\\"{x:1523,y:736,t:1528139694486};\\\", \\\"{x:1521,y:741,t:1528139694502};\\\", \\\"{x:1519,y:743,t:1528139694520};\\\", \\\"{x:1518,y:745,t:1528139694537};\\\", \\\"{x:1517,y:747,t:1528139694552};\\\", \\\"{x:1516,y:750,t:1528139694569};\\\", \\\"{x:1514,y:752,t:1528139694587};\\\", \\\"{x:1514,y:753,t:1528139694602};\\\", \\\"{x:1513,y:756,t:1528139694620};\\\", \\\"{x:1512,y:757,t:1528139694651};\\\", \\\"{x:1512,y:759,t:1528139695621};\\\", \\\"{x:1512,y:762,t:1528139695636};\\\", \\\"{x:1512,y:763,t:1528139695653};\\\", \\\"{x:1511,y:765,t:1528139695671};\\\", \\\"{x:1511,y:766,t:1528139695688};\\\", \\\"{x:1511,y:767,t:1528139695703};\\\", \\\"{x:1511,y:768,t:1528139695721};\\\", \\\"{x:1511,y:769,t:1528139695738};\\\", \\\"{x:1510,y:770,t:1528139695753};\\\", \\\"{x:1510,y:771,t:1528139695772};\\\", \\\"{x:1510,y:772,t:1528139695787};\\\", \\\"{x:1509,y:774,t:1528139695804};\\\", \\\"{x:1509,y:775,t:1528139695821};\\\", \\\"{x:1509,y:776,t:1528139695837};\\\", \\\"{x:1508,y:779,t:1528139695853};\\\", \\\"{x:1506,y:784,t:1528139695870};\\\", \\\"{x:1504,y:797,t:1528139695887};\\\", \\\"{x:1505,y:818,t:1528139695904};\\\", \\\"{x:1526,y:849,t:1528139695921};\\\", \\\"{x:1552,y:874,t:1528139695938};\\\", \\\"{x:1554,y:876,t:1528139695954};\\\", \\\"{x:1555,y:875,t:1528139696356};\\\", \\\"{x:1555,y:872,t:1528139696371};\\\", \\\"{x:1505,y:851,t:1528139696388};\\\", \\\"{x:1416,y:809,t:1528139696404};\\\", \\\"{x:1305,y:759,t:1528139696420};\\\", \\\"{x:1171,y:703,t:1528139696437};\\\", \\\"{x:988,y:620,t:1528139696454};\\\", \\\"{x:806,y:532,t:1528139696472};\\\", \\\"{x:624,y:456,t:1528139696488};\\\", \\\"{x:468,y:393,t:1528139696504};\\\", \\\"{x:349,y:336,t:1528139696520};\\\", \\\"{x:262,y:288,t:1528139696536};\\\", \\\"{x:211,y:255,t:1528139696554};\\\", \\\"{x:185,y:237,t:1528139696570};\\\", \\\"{x:166,y:225,t:1528139696587};\\\", \\\"{x:160,y:221,t:1528139696603};\\\", \\\"{x:158,y:221,t:1528139696620};\\\", \\\"{x:157,y:221,t:1528139696637};\\\", \\\"{x:149,y:221,t:1528139696654};\\\", \\\"{x:132,y:225,t:1528139696670};\\\", \\\"{x:96,y:252,t:1528139696686};\\\", \\\"{x:57,y:287,t:1528139696704};\\\", \\\"{x:19,y:326,t:1528139696721};\\\", \\\"{x:0,y:363,t:1528139696738};\\\", \\\"{x:0,y:388,t:1528139696755};\\\", \\\"{x:0,y:407,t:1528139696771};\\\", \\\"{x:0,y:429,t:1528139696787};\\\", \\\"{x:0,y:435,t:1528139696804};\\\", \\\"{x:0,y:437,t:1528139696820};\\\", \\\"{x:0,y:439,t:1528139696842};\\\", \\\"{x:3,y:439,t:1528139696854};\\\", \\\"{x:13,y:439,t:1528139696869};\\\", \\\"{x:32,y:436,t:1528139696887};\\\", \\\"{x:94,y:426,t:1528139696904};\\\", \\\"{x:190,y:418,t:1528139696920};\\\", \\\"{x:299,y:416,t:1528139696937};\\\", \\\"{x:377,y:416,t:1528139696953};\\\", \\\"{x:440,y:416,t:1528139696971};\\\", \\\"{x:461,y:417,t:1528139696987};\\\", \\\"{x:473,y:421,t:1528139697004};\\\", \\\"{x:484,y:427,t:1528139697021};\\\", \\\"{x:490,y:429,t:1528139697037};\\\", \\\"{x:493,y:429,t:1528139697053};\\\", \\\"{x:498,y:432,t:1528139697070};\\\", \\\"{x:511,y:438,t:1528139697087};\\\", \\\"{x:538,y:450,t:1528139697103};\\\", \\\"{x:596,y:473,t:1528139697121};\\\", \\\"{x:662,y:502,t:1528139697137};\\\", \\\"{x:731,y:531,t:1528139697154};\\\", \\\"{x:802,y:563,t:1528139697171};\\\", \\\"{x:819,y:573,t:1528139697187};\\\", \\\"{x:829,y:580,t:1528139697204};\\\", \\\"{x:832,y:583,t:1528139697221};\\\", \\\"{x:833,y:584,t:1528139697237};\\\", \\\"{x:833,y:586,t:1528139697255};\\\", \\\"{x:833,y:587,t:1528139697271};\\\", \\\"{x:836,y:592,t:1528139697288};\\\", \\\"{x:840,y:599,t:1528139697304};\\\", \\\"{x:843,y:602,t:1528139697321};\\\", \\\"{x:843,y:599,t:1528139697412};\\\", \\\"{x:843,y:596,t:1528139697420};\\\", \\\"{x:843,y:593,t:1528139697438};\\\", \\\"{x:843,y:592,t:1528139697455};\\\", \\\"{x:843,y:591,t:1528139697471};\\\", \\\"{x:843,y:590,t:1528139697487};\\\", \\\"{x:843,y:589,t:1528139697571};\\\", \\\"{x:843,y:587,t:1528139697587};\\\", \\\"{x:841,y:586,t:1528139697827};\\\", \\\"{x:827,y:586,t:1528139697837};\\\", \\\"{x:794,y:586,t:1528139697854};\\\", \\\"{x:748,y:589,t:1528139697872};\\\", \\\"{x:661,y:595,t:1528139697888};\\\", \\\"{x:618,y:595,t:1528139697905};\\\", \\\"{x:610,y:595,t:1528139697922};\\\", \\\"{x:609,y:595,t:1528139697938};\\\", \\\"{x:607,y:594,t:1528139698036};\\\", \\\"{x:605,y:593,t:1528139698044};\\\", \\\"{x:604,y:591,t:1528139698055};\\\", \\\"{x:603,y:590,t:1528139698072};\\\", \\\"{x:602,y:589,t:1528139698089};\\\", \\\"{x:602,y:588,t:1528139698130};\\\", \\\"{x:604,y:587,t:1528139698146};\\\", \\\"{x:605,y:587,t:1528139698162};\\\", \\\"{x:607,y:585,t:1528139698172};\\\", \\\"{x:608,y:585,t:1528139698189};\\\", \\\"{x:609,y:585,t:1528139698205};\\\", \\\"{x:612,y:583,t:1528139698222};\\\", \\\"{x:613,y:581,t:1528139698239};\\\", \\\"{x:614,y:581,t:1528139698255};\\\", \\\"{x:615,y:581,t:1528139698272};\\\", \\\"{x:616,y:580,t:1528139698395};\\\", \\\"{x:616,y:580,t:1528139698455};\\\", \\\"{x:616,y:582,t:1528139698515};\\\", \\\"{x:614,y:586,t:1528139698522};\\\", \\\"{x:613,y:599,t:1528139698539};\\\", \\\"{x:608,y:633,t:1528139698556};\\\", \\\"{x:598,y:684,t:1528139698572};\\\", \\\"{x:587,y:738,t:1528139698590};\\\", \\\"{x:579,y:779,t:1528139698606};\\\", \\\"{x:572,y:805,t:1528139698622};\\\", \\\"{x:566,y:821,t:1528139698639};\\\", \\\"{x:562,y:827,t:1528139698656};\\\", \\\"{x:561,y:828,t:1528139698673};\\\", \\\"{x:560,y:828,t:1528139698691};\\\", \\\"{x:559,y:828,t:1528139698706};\\\", \\\"{x:558,y:828,t:1528139698722};\\\", \\\"{x:554,y:828,t:1528139698740};\\\", \\\"{x:550,y:826,t:1528139698755};\\\", \\\"{x:544,y:821,t:1528139698772};\\\", \\\"{x:537,y:815,t:1528139698789};\\\", \\\"{x:533,y:812,t:1528139698807};\\\", \\\"{x:529,y:808,t:1528139698822};\\\", \\\"{x:527,y:802,t:1528139698839};\\\", \\\"{x:522,y:795,t:1528139698856};\\\", \\\"{x:518,y:785,t:1528139698873};\\\", \\\"{x:510,y:771,t:1528139698889};\\\", \\\"{x:506,y:763,t:1528139698907};\\\", \\\"{x:503,y:759,t:1528139698922};\\\", \\\"{x:500,y:753,t:1528139698940};\\\", \\\"{x:499,y:752,t:1528139698955};\\\", \\\"{x:496,y:748,t:1528139698973};\\\", \\\"{x:493,y:740,t:1528139698988};\\\", \\\"{x:489,y:735,t:1528139699006};\\\", \\\"{x:488,y:733,t:1528139699023};\\\", \\\"{x:488,y:732,t:1528139699355};\\\", \\\"{x:489,y:732,t:1528139699362};\\\", \\\"{x:491,y:731,t:1528139699373};\\\", \\\"{x:495,y:728,t:1528139699389};\\\", \\\"{x:497,y:727,t:1528139699406};\\\", \\\"{x:498,y:726,t:1528139699868};\\\", \\\"{x:498,y:724,t:1528139699883};\\\", \\\"{x:498,y:720,t:1528139699891};\\\", \\\"{x:498,y:714,t:1528139699907};\\\", \\\"{x:498,y:709,t:1528139699924};\\\", \\\"{x:497,y:704,t:1528139699941};\\\", \\\"{x:496,y:700,t:1528139699957};\\\", \\\"{x:494,y:695,t:1528139699974};\\\", \\\"{x:493,y:691,t:1528139699990};\\\", \\\"{x:492,y:689,t:1528139700007};\\\", \\\"{x:491,y:686,t:1528139700024};\\\", \\\"{x:490,y:685,t:1528139700067};\\\" ] }, { \\\"rt\\\": 91924, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 475648, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X -B -B -B -B -B -J -J -B -B -G -03 PM-03 PM-B -B -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:487,y:680,t:1528139700401};\\\", \\\"{x:487,y:676,t:1528139702956};\\\", \\\"{x:485,y:670,t:1528139702976};\\\", \\\"{x:484,y:670,t:1528139703539};\\\", \\\"{x:483,y:670,t:1528139703612};\\\", \\\"{x:491,y:669,t:1528139705555};\\\", \\\"{x:502,y:667,t:1528139705563};\\\", \\\"{x:555,y:657,t:1528139705594};\\\", \\\"{x:630,y:651,t:1528139705611};\\\", \\\"{x:694,y:651,t:1528139705628};\\\", \\\"{x:749,y:646,t:1528139705644};\\\", \\\"{x:803,y:635,t:1528139705661};\\\", \\\"{x:853,y:614,t:1528139705679};\\\", \\\"{x:899,y:588,t:1528139705695};\\\", \\\"{x:955,y:562,t:1528139705712};\\\", \\\"{x:996,y:545,t:1528139705728};\\\", \\\"{x:1020,y:540,t:1528139705744};\\\", \\\"{x:1040,y:536,t:1528139705762};\\\", \\\"{x:1060,y:533,t:1528139705778};\\\", \\\"{x:1081,y:529,t:1528139705795};\\\", \\\"{x:1094,y:528,t:1528139705812};\\\", \\\"{x:1108,y:527,t:1528139705829};\\\", \\\"{x:1121,y:527,t:1528139705845};\\\", \\\"{x:1139,y:527,t:1528139705861};\\\", \\\"{x:1147,y:527,t:1528139705878};\\\", \\\"{x:1152,y:527,t:1528139705895};\\\", \\\"{x:1166,y:527,t:1528139705912};\\\", \\\"{x:1176,y:527,t:1528139705928};\\\", \\\"{x:1178,y:527,t:1528139705946};\\\", \\\"{x:1185,y:529,t:1528139705962};\\\", \\\"{x:1194,y:534,t:1528139705978};\\\", \\\"{x:1208,y:540,t:1528139705995};\\\", \\\"{x:1208,y:543,t:1528139706011};\\\", \\\"{x:1206,y:549,t:1528139706028};\\\", \\\"{x:1195,y:556,t:1528139706046};\\\", \\\"{x:1174,y:563,t:1528139706062};\\\", \\\"{x:1147,y:564,t:1528139706079};\\\", \\\"{x:1124,y:561,t:1528139706096};\\\", \\\"{x:1101,y:552,t:1528139706111};\\\", \\\"{x:1086,y:544,t:1528139706129};\\\", \\\"{x:1080,y:538,t:1528139706146};\\\", \\\"{x:1076,y:532,t:1528139706162};\\\", \\\"{x:1074,y:528,t:1528139706179};\\\", \\\"{x:1074,y:527,t:1528139706196};\\\", \\\"{x:1074,y:524,t:1528139706214};\\\", \\\"{x:1074,y:521,t:1528139706229};\\\", \\\"{x:1074,y:515,t:1528139706246};\\\", \\\"{x:1074,y:511,t:1528139706262};\\\", \\\"{x:1074,y:509,t:1528139706279};\\\", \\\"{x:1074,y:506,t:1528139706296};\\\", \\\"{x:1074,y:503,t:1528139706313};\\\", \\\"{x:1074,y:502,t:1528139706329};\\\", \\\"{x:1074,y:500,t:1528139706345};\\\", \\\"{x:1074,y:498,t:1528139706362};\\\", \\\"{x:1075,y:497,t:1528139706379};\\\", \\\"{x:1079,y:498,t:1528139713060};\\\", \\\"{x:1093,y:520,t:1528139713070};\\\", \\\"{x:1141,y:575,t:1528139713087};\\\", \\\"{x:1206,y:638,t:1528139713104};\\\", \\\"{x:1283,y:703,t:1528139713120};\\\", \\\"{x:1362,y:759,t:1528139713137};\\\", \\\"{x:1426,y:803,t:1528139713155};\\\", \\\"{x:1477,y:830,t:1528139713173};\\\", \\\"{x:1507,y:842,t:1528139713186};\\\", \\\"{x:1515,y:845,t:1528139713203};\\\", \\\"{x:1522,y:849,t:1528139713219};\\\", \\\"{x:1535,y:855,t:1528139713237};\\\", \\\"{x:1547,y:858,t:1528139713254};\\\", \\\"{x:1555,y:858,t:1528139713269};\\\", \\\"{x:1558,y:859,t:1528139713286};\\\", \\\"{x:1554,y:856,t:1528139713347};\\\", \\\"{x:1542,y:848,t:1528139713355};\\\", \\\"{x:1512,y:833,t:1528139713370};\\\", \\\"{x:1478,y:817,t:1528139713387};\\\", \\\"{x:1458,y:807,t:1528139713405};\\\", \\\"{x:1441,y:798,t:1528139713420};\\\", \\\"{x:1427,y:791,t:1528139713436};\\\", \\\"{x:1421,y:787,t:1528139713454};\\\", \\\"{x:1418,y:784,t:1528139713471};\\\", \\\"{x:1416,y:783,t:1528139713486};\\\", \\\"{x:1415,y:781,t:1528139713504};\\\", \\\"{x:1414,y:780,t:1528139713521};\\\", \\\"{x:1413,y:779,t:1528139713537};\\\", \\\"{x:1412,y:778,t:1528139713554};\\\", \\\"{x:1404,y:777,t:1528139713572};\\\", \\\"{x:1403,y:777,t:1528139713587};\\\", \\\"{x:1400,y:775,t:1528139713604};\\\", \\\"{x:1395,y:775,t:1528139713621};\\\", \\\"{x:1386,y:775,t:1528139713638};\\\", \\\"{x:1375,y:775,t:1528139713654};\\\", \\\"{x:1363,y:775,t:1528139713672};\\\", \\\"{x:1353,y:774,t:1528139713689};\\\", \\\"{x:1348,y:774,t:1528139713704};\\\", \\\"{x:1348,y:772,t:1528139713892};\\\", \\\"{x:1348,y:770,t:1528139713908};\\\", \\\"{x:1349,y:769,t:1528139713921};\\\", \\\"{x:1349,y:767,t:1528139713939};\\\", \\\"{x:1349,y:765,t:1528139713955};\\\", \\\"{x:1349,y:764,t:1528139713971};\\\", \\\"{x:1349,y:763,t:1528139713987};\\\", \\\"{x:1349,y:762,t:1528139714005};\\\", \\\"{x:1349,y:761,t:1528139714419};\\\", \\\"{x:1349,y:760,t:1528139714435};\\\", \\\"{x:1349,y:759,t:1528139714444};\\\", \\\"{x:1349,y:758,t:1528139714455};\\\", \\\"{x:1349,y:757,t:1528139714492};\\\", \\\"{x:1349,y:756,t:1528139714507};\\\", \\\"{x:1349,y:758,t:1528139715740};\\\", \\\"{x:1349,y:759,t:1528139715773};\\\", \\\"{x:1349,y:761,t:1528139715790};\\\", \\\"{x:1349,y:762,t:1528139715827};\\\", \\\"{x:1338,y:769,t:1528139726668};\\\", \\\"{x:1282,y:775,t:1528139726685};\\\", \\\"{x:1232,y:781,t:1528139726702};\\\", \\\"{x:1190,y:781,t:1528139726719};\\\", \\\"{x:1157,y:781,t:1528139726737};\\\", \\\"{x:1138,y:781,t:1528139726752};\\\", \\\"{x:1116,y:781,t:1528139726770};\\\", \\\"{x:1086,y:781,t:1528139726787};\\\", \\\"{x:1085,y:781,t:1528139726803};\\\", \\\"{x:1095,y:781,t:1528139726851};\\\", \\\"{x:1112,y:779,t:1528139726859};\\\", \\\"{x:1138,y:777,t:1528139726869};\\\", \\\"{x:1227,y:777,t:1528139726886};\\\", \\\"{x:1338,y:777,t:1528139726902};\\\", \\\"{x:1470,y:777,t:1528139726920};\\\", \\\"{x:1581,y:777,t:1528139726937};\\\", \\\"{x:1651,y:777,t:1528139726953};\\\", \\\"{x:1670,y:777,t:1528139726970};\\\", \\\"{x:1668,y:776,t:1528139727020};\\\", \\\"{x:1650,y:775,t:1528139727037};\\\", \\\"{x:1622,y:772,t:1528139727054};\\\", \\\"{x:1578,y:767,t:1528139727070};\\\", \\\"{x:1532,y:765,t:1528139727086};\\\", \\\"{x:1480,y:761,t:1528139727104};\\\", \\\"{x:1438,y:755,t:1528139727120};\\\", \\\"{x:1407,y:755,t:1528139727136};\\\", \\\"{x:1382,y:754,t:1528139727154};\\\", \\\"{x:1362,y:754,t:1528139727170};\\\", \\\"{x:1354,y:754,t:1528139727187};\\\", \\\"{x:1353,y:754,t:1528139727627};\\\", \\\"{x:1351,y:754,t:1528139727637};\\\", \\\"{x:1350,y:755,t:1528139727667};\\\", \\\"{x:1349,y:755,t:1528139727723};\\\", \\\"{x:1349,y:757,t:1528139727947};\\\", \\\"{x:1349,y:758,t:1528139727988};\\\", \\\"{x:1349,y:759,t:1528139728004};\\\", \\\"{x:1349,y:760,t:1528139728020};\\\", \\\"{x:1349,y:761,t:1528139728043};\\\", \\\"{x:1348,y:761,t:1528139728054};\\\", \\\"{x:1348,y:762,t:1528139728091};\\\", \\\"{x:1347,y:763,t:1528139728172};\\\", \\\"{x:1346,y:764,t:1528139728188};\\\", \\\"{x:1335,y:768,t:1528139728206};\\\", \\\"{x:1321,y:774,t:1528139728221};\\\", \\\"{x:1301,y:781,t:1528139728238};\\\", \\\"{x:1280,y:787,t:1528139728255};\\\", \\\"{x:1263,y:794,t:1528139728272};\\\", \\\"{x:1247,y:799,t:1528139728288};\\\", \\\"{x:1243,y:801,t:1528139728305};\\\", \\\"{x:1242,y:801,t:1528139728322};\\\", \\\"{x:1241,y:801,t:1528139728337};\\\", \\\"{x:1240,y:803,t:1528139728355};\\\", \\\"{x:1239,y:804,t:1528139728371};\\\", \\\"{x:1238,y:804,t:1528139728387};\\\", \\\"{x:1236,y:806,t:1528139728404};\\\", \\\"{x:1234,y:807,t:1528139728421};\\\", \\\"{x:1232,y:809,t:1528139728438};\\\", \\\"{x:1231,y:810,t:1528139728454};\\\", \\\"{x:1229,y:811,t:1528139728471};\\\", \\\"{x:1228,y:812,t:1528139728487};\\\", \\\"{x:1227,y:813,t:1528139728505};\\\", \\\"{x:1224,y:815,t:1528139728522};\\\", \\\"{x:1222,y:817,t:1528139728538};\\\", \\\"{x:1219,y:818,t:1528139728555};\\\", \\\"{x:1219,y:819,t:1528139728572};\\\", \\\"{x:1218,y:820,t:1528139728589};\\\", \\\"{x:1217,y:821,t:1528139728619};\\\", \\\"{x:1216,y:822,t:1528139728627};\\\", \\\"{x:1215,y:823,t:1528139728639};\\\", \\\"{x:1213,y:825,t:1528139728667};\\\", \\\"{x:1215,y:825,t:1528139728811};\\\", \\\"{x:1219,y:824,t:1528139728823};\\\", \\\"{x:1231,y:819,t:1528139728839};\\\", \\\"{x:1249,y:814,t:1528139728855};\\\", \\\"{x:1274,y:810,t:1528139728871};\\\", \\\"{x:1297,y:808,t:1528139728889};\\\", \\\"{x:1313,y:803,t:1528139728905};\\\", \\\"{x:1322,y:800,t:1528139728922};\\\", \\\"{x:1332,y:795,t:1528139728939};\\\", \\\"{x:1334,y:793,t:1528139728955};\\\", \\\"{x:1336,y:792,t:1528139728972};\\\", \\\"{x:1337,y:791,t:1528139728989};\\\", \\\"{x:1338,y:788,t:1528139729005};\\\", \\\"{x:1339,y:786,t:1528139729021};\\\", \\\"{x:1341,y:783,t:1528139729039};\\\", \\\"{x:1342,y:780,t:1528139729056};\\\", \\\"{x:1344,y:778,t:1528139729072};\\\", \\\"{x:1345,y:777,t:1528139729089};\\\", \\\"{x:1345,y:776,t:1528139729106};\\\", \\\"{x:1345,y:775,t:1528139729123};\\\", \\\"{x:1345,y:773,t:1528139729156};\\\", \\\"{x:1346,y:772,t:1528139729173};\\\", \\\"{x:1347,y:772,t:1528139729189};\\\", \\\"{x:1347,y:770,t:1528139729219};\\\", \\\"{x:1347,y:769,t:1528139729235};\\\", \\\"{x:1347,y:767,t:1528139729259};\\\", \\\"{x:1347,y:766,t:1528139729291};\\\", \\\"{x:1347,y:765,t:1528139729556};\\\", \\\"{x:1345,y:767,t:1528139730979};\\\", \\\"{x:1341,y:773,t:1528139730991};\\\", \\\"{x:1334,y:784,t:1528139731008};\\\", \\\"{x:1330,y:792,t:1528139731025};\\\", \\\"{x:1327,y:798,t:1528139731041};\\\", \\\"{x:1325,y:802,t:1528139731058};\\\", \\\"{x:1323,y:809,t:1528139731075};\\\", \\\"{x:1320,y:819,t:1528139731091};\\\", \\\"{x:1316,y:831,t:1528139731108};\\\", \\\"{x:1312,y:845,t:1528139731125};\\\", \\\"{x:1309,y:854,t:1528139731141};\\\", \\\"{x:1306,y:863,t:1528139731157};\\\", \\\"{x:1304,y:873,t:1528139731175};\\\", \\\"{x:1301,y:882,t:1528139731191};\\\", \\\"{x:1300,y:891,t:1528139731207};\\\", \\\"{x:1298,y:902,t:1528139731225};\\\", \\\"{x:1296,y:909,t:1528139731242};\\\", \\\"{x:1293,y:916,t:1528139731258};\\\", \\\"{x:1291,y:925,t:1528139731275};\\\", \\\"{x:1289,y:929,t:1528139731291};\\\", \\\"{x:1286,y:936,t:1528139731308};\\\", \\\"{x:1284,y:940,t:1528139731325};\\\", \\\"{x:1282,y:944,t:1528139731342};\\\", \\\"{x:1281,y:945,t:1528139731358};\\\", \\\"{x:1278,y:947,t:1528139731375};\\\", \\\"{x:1276,y:948,t:1528139731392};\\\", \\\"{x:1275,y:948,t:1528139731407};\\\", \\\"{x:1274,y:949,t:1528139731425};\\\", \\\"{x:1274,y:950,t:1528139731442};\\\", \\\"{x:1273,y:950,t:1528139731458};\\\", \\\"{x:1271,y:951,t:1528139731474};\\\", \\\"{x:1270,y:951,t:1528139731492};\\\", \\\"{x:1270,y:952,t:1528139731508};\\\", \\\"{x:1268,y:953,t:1528139731525};\\\", \\\"{x:1268,y:954,t:1528139731555};\\\", \\\"{x:1267,y:954,t:1528139731571};\\\", \\\"{x:1266,y:955,t:1528139731595};\\\", \\\"{x:1265,y:955,t:1528139731611};\\\", \\\"{x:1265,y:956,t:1528139731627};\\\", \\\"{x:1264,y:957,t:1528139731651};\\\", \\\"{x:1263,y:957,t:1528139731708};\\\", \\\"{x:1261,y:955,t:1528139731939};\\\", \\\"{x:1257,y:952,t:1528139731947};\\\", \\\"{x:1253,y:948,t:1528139731959};\\\", \\\"{x:1245,y:940,t:1528139731976};\\\", \\\"{x:1236,y:933,t:1528139731992};\\\", \\\"{x:1234,y:930,t:1528139732009};\\\", \\\"{x:1233,y:928,t:1528139732025};\\\", \\\"{x:1231,y:921,t:1528139732041};\\\", \\\"{x:1226,y:901,t:1528139732058};\\\", \\\"{x:1222,y:880,t:1528139732075};\\\", \\\"{x:1215,y:862,t:1528139732092};\\\", \\\"{x:1210,y:845,t:1528139732108};\\\", \\\"{x:1206,y:829,t:1528139732125};\\\", \\\"{x:1200,y:816,t:1528139732142};\\\", \\\"{x:1194,y:804,t:1528139732158};\\\", \\\"{x:1189,y:792,t:1528139732175};\\\", \\\"{x:1187,y:785,t:1528139732193};\\\", \\\"{x:1187,y:781,t:1528139732208};\\\", \\\"{x:1187,y:778,t:1528139732225};\\\", \\\"{x:1187,y:771,t:1528139732243};\\\", \\\"{x:1188,y:767,t:1528139732259};\\\", \\\"{x:1196,y:763,t:1528139732276};\\\", \\\"{x:1210,y:758,t:1528139732293};\\\", \\\"{x:1225,y:754,t:1528139732308};\\\", \\\"{x:1233,y:753,t:1528139732326};\\\", \\\"{x:1238,y:752,t:1528139732343};\\\", \\\"{x:1239,y:752,t:1528139732359};\\\", \\\"{x:1240,y:752,t:1528139732435};\\\", \\\"{x:1241,y:752,t:1528139732443};\\\", \\\"{x:1246,y:752,t:1528139732459};\\\", \\\"{x:1253,y:752,t:1528139732476};\\\", \\\"{x:1262,y:752,t:1528139732493};\\\", \\\"{x:1276,y:752,t:1528139732510};\\\", \\\"{x:1291,y:752,t:1528139732525};\\\", \\\"{x:1310,y:752,t:1528139732542};\\\", \\\"{x:1327,y:752,t:1528139732559};\\\", \\\"{x:1341,y:752,t:1528139732575};\\\", \\\"{x:1347,y:752,t:1528139732593};\\\", \\\"{x:1351,y:752,t:1528139732610};\\\", \\\"{x:1352,y:752,t:1528139732625};\\\", \\\"{x:1352,y:751,t:1528139732748};\\\", \\\"{x:1354,y:750,t:1528139734116};\\\", \\\"{x:1360,y:742,t:1528139734128};\\\", \\\"{x:1375,y:715,t:1528139734145};\\\", \\\"{x:1390,y:688,t:1528139734161};\\\", \\\"{x:1401,y:671,t:1528139734178};\\\", \\\"{x:1409,y:658,t:1528139734195};\\\", \\\"{x:1413,y:647,t:1528139734211};\\\", \\\"{x:1420,y:634,t:1528139734228};\\\", \\\"{x:1425,y:618,t:1528139734245};\\\", \\\"{x:1426,y:610,t:1528139734262};\\\", \\\"{x:1428,y:607,t:1528139734278};\\\", \\\"{x:1428,y:604,t:1528139734295};\\\", \\\"{x:1428,y:603,t:1528139734312};\\\", \\\"{x:1428,y:602,t:1528139734331};\\\", \\\"{x:1428,y:600,t:1528139734940};\\\", \\\"{x:1428,y:598,t:1528139734947};\\\", \\\"{x:1428,y:595,t:1528139734963};\\\", \\\"{x:1428,y:593,t:1528139734979};\\\", \\\"{x:1428,y:591,t:1528139734996};\\\", \\\"{x:1428,y:590,t:1528139735012};\\\", \\\"{x:1428,y:588,t:1528139735030};\\\", \\\"{x:1428,y:587,t:1528139735046};\\\", \\\"{x:1428,y:585,t:1528139735075};\\\", \\\"{x:1428,y:584,t:1528139735091};\\\", \\\"{x:1428,y:582,t:1528139735107};\\\", \\\"{x:1428,y:581,t:1528139735123};\\\", \\\"{x:1428,y:579,t:1528139735131};\\\", \\\"{x:1428,y:577,t:1528139735147};\\\", \\\"{x:1428,y:576,t:1528139735163};\\\", \\\"{x:1428,y:574,t:1528139735179};\\\", \\\"{x:1427,y:572,t:1528139735196};\\\", \\\"{x:1427,y:571,t:1528139735220};\\\", \\\"{x:1427,y:569,t:1528139735229};\\\", \\\"{x:1426,y:568,t:1528139735246};\\\", \\\"{x:1426,y:567,t:1528139735264};\\\", \\\"{x:1426,y:566,t:1528139735279};\\\", \\\"{x:1425,y:564,t:1528139735296};\\\", \\\"{x:1425,y:563,t:1528139735364};\\\", \\\"{x:1424,y:563,t:1528139735492};\\\", \\\"{x:1423,y:563,t:1528139735515};\\\", \\\"{x:1422,y:563,t:1528139735530};\\\", \\\"{x:1421,y:563,t:1528139735555};\\\", \\\"{x:1420,y:563,t:1528139735571};\\\", \\\"{x:1419,y:563,t:1528139735603};\\\", \\\"{x:1418,y:563,t:1528139735643};\\\", \\\"{x:1417,y:563,t:1528139735659};\\\", \\\"{x:1416,y:563,t:1528139736430};\\\", \\\"{x:1414,y:572,t:1528139740015};\\\", \\\"{x:1407,y:592,t:1528139740022};\\\", \\\"{x:1401,y:628,t:1528139740038};\\\", \\\"{x:1401,y:653,t:1528139740055};\\\", \\\"{x:1401,y:679,t:1528139740072};\\\", \\\"{x:1401,y:696,t:1528139740089};\\\", \\\"{x:1403,y:711,t:1528139740105};\\\", \\\"{x:1409,y:731,t:1528139740121};\\\", \\\"{x:1414,y:748,t:1528139740139};\\\", \\\"{x:1421,y:766,t:1528139740154};\\\", \\\"{x:1426,y:778,t:1528139740172};\\\", \\\"{x:1430,y:787,t:1528139740189};\\\", \\\"{x:1434,y:798,t:1528139740206};\\\", \\\"{x:1445,y:811,t:1528139740222};\\\", \\\"{x:1454,y:823,t:1528139740238};\\\", \\\"{x:1458,y:828,t:1528139740255};\\\", \\\"{x:1461,y:833,t:1528139740271};\\\", \\\"{x:1466,y:839,t:1528139740288};\\\", \\\"{x:1473,y:847,t:1528139740305};\\\", \\\"{x:1481,y:854,t:1528139740321};\\\", \\\"{x:1490,y:860,t:1528139740338};\\\", \\\"{x:1502,y:870,t:1528139740355};\\\", \\\"{x:1511,y:877,t:1528139740371};\\\", \\\"{x:1518,y:882,t:1528139740388};\\\", \\\"{x:1530,y:887,t:1528139740406};\\\", \\\"{x:1536,y:891,t:1528139740421};\\\", \\\"{x:1537,y:893,t:1528139740438};\\\", \\\"{x:1537,y:895,t:1528139740456};\\\", \\\"{x:1537,y:900,t:1528139740471};\\\", \\\"{x:1540,y:907,t:1528139740488};\\\", \\\"{x:1543,y:915,t:1528139740506};\\\", \\\"{x:1549,y:925,t:1528139740522};\\\", \\\"{x:1554,y:930,t:1528139740538};\\\", \\\"{x:1557,y:933,t:1528139740555};\\\", \\\"{x:1558,y:934,t:1528139740572};\\\", \\\"{x:1559,y:936,t:1528139740589};\\\", \\\"{x:1559,y:938,t:1528139740606};\\\", \\\"{x:1560,y:939,t:1528139740623};\\\", \\\"{x:1560,y:940,t:1528139740639};\\\", \\\"{x:1560,y:941,t:1528139740734};\\\", \\\"{x:1561,y:941,t:1528139740750};\\\", \\\"{x:1561,y:942,t:1528139740758};\\\", \\\"{x:1561,y:943,t:1528139740774};\\\", \\\"{x:1561,y:944,t:1528139740855};\\\", \\\"{x:1561,y:949,t:1528139740873};\\\", \\\"{x:1559,y:963,t:1528139740890};\\\", \\\"{x:1546,y:982,t:1528139740906};\\\", \\\"{x:1532,y:1004,t:1528139740924};\\\", \\\"{x:1521,y:1022,t:1528139740940};\\\", \\\"{x:1515,y:1032,t:1528139740956};\\\", \\\"{x:1512,y:1035,t:1528139740972};\\\", \\\"{x:1511,y:1035,t:1528139741103};\\\", \\\"{x:1513,y:1029,t:1528139741110};\\\", \\\"{x:1515,y:1025,t:1528139741123};\\\", \\\"{x:1521,y:1015,t:1528139741139};\\\", \\\"{x:1529,y:1006,t:1528139741157};\\\", \\\"{x:1534,y:998,t:1528139741173};\\\", \\\"{x:1540,y:991,t:1528139741190};\\\", \\\"{x:1542,y:988,t:1528139741206};\\\", \\\"{x:1542,y:986,t:1528139741223};\\\", \\\"{x:1543,y:986,t:1528139741240};\\\", \\\"{x:1543,y:985,t:1528139741431};\\\", \\\"{x:1543,y:982,t:1528139741455};\\\", \\\"{x:1543,y:980,t:1528139741462};\\\", \\\"{x:1543,y:979,t:1528139741473};\\\", \\\"{x:1543,y:977,t:1528139741489};\\\", \\\"{x:1543,y:975,t:1528139741506};\\\", \\\"{x:1543,y:974,t:1528139741523};\\\", \\\"{x:1543,y:972,t:1528139741539};\\\", \\\"{x:1543,y:971,t:1528139741556};\\\", \\\"{x:1543,y:970,t:1528139741573};\\\", \\\"{x:1543,y:969,t:1528139741597};\\\", \\\"{x:1543,y:968,t:1528139741751};\\\", \\\"{x:1543,y:967,t:1528139741799};\\\", \\\"{x:1543,y:966,t:1528139741822};\\\", \\\"{x:1543,y:965,t:1528139741862};\\\", \\\"{x:1543,y:964,t:1528139741874};\\\", \\\"{x:1543,y:963,t:1528139741894};\\\", \\\"{x:1543,y:962,t:1528139741943};\\\", \\\"{x:1543,y:961,t:1528139741982};\\\", \\\"{x:1543,y:960,t:1528139750079};\\\", \\\"{x:1541,y:953,t:1528139751855};\\\", \\\"{x:1536,y:949,t:1528139751868};\\\", \\\"{x:1528,y:941,t:1528139751885};\\\", \\\"{x:1515,y:881,t:1528139751902};\\\", \\\"{x:1506,y:859,t:1528139751918};\\\", \\\"{x:1502,y:847,t:1528139751935};\\\", \\\"{x:1501,y:835,t:1528139751952};\\\", \\\"{x:1500,y:829,t:1528139751969};\\\", \\\"{x:1499,y:823,t:1528139751985};\\\", \\\"{x:1498,y:818,t:1528139752002};\\\", \\\"{x:1498,y:815,t:1528139752019};\\\", \\\"{x:1498,y:811,t:1528139752035};\\\", \\\"{x:1497,y:807,t:1528139752053};\\\", \\\"{x:1495,y:802,t:1528139752069};\\\", \\\"{x:1491,y:798,t:1528139752086};\\\", \\\"{x:1481,y:794,t:1528139752102};\\\", \\\"{x:1472,y:789,t:1528139752119};\\\", \\\"{x:1461,y:786,t:1528139752136};\\\", \\\"{x:1449,y:785,t:1528139752152};\\\", \\\"{x:1435,y:784,t:1528139752169};\\\", \\\"{x:1425,y:784,t:1528139752186};\\\", \\\"{x:1411,y:784,t:1528139752202};\\\", \\\"{x:1403,y:784,t:1528139752218};\\\", \\\"{x:1399,y:784,t:1528139752236};\\\", \\\"{x:1398,y:784,t:1528139752252};\\\", \\\"{x:1397,y:784,t:1528139752270};\\\", \\\"{x:1396,y:784,t:1528139752286};\\\", \\\"{x:1394,y:784,t:1528139752302};\\\", \\\"{x:1391,y:784,t:1528139752320};\\\", \\\"{x:1389,y:784,t:1528139752337};\\\", \\\"{x:1388,y:784,t:1528139752352};\\\", \\\"{x:1387,y:784,t:1528139752369};\\\", \\\"{x:1386,y:784,t:1528139752386};\\\", \\\"{x:1385,y:783,t:1528139752402};\\\", \\\"{x:1382,y:783,t:1528139752419};\\\", \\\"{x:1380,y:782,t:1528139752436};\\\", \\\"{x:1375,y:781,t:1528139752452};\\\", \\\"{x:1371,y:779,t:1528139752469};\\\", \\\"{x:1359,y:772,t:1528139752486};\\\", \\\"{x:1350,y:765,t:1528139752503};\\\", \\\"{x:1340,y:758,t:1528139752520};\\\", \\\"{x:1335,y:754,t:1528139752536};\\\", \\\"{x:1334,y:753,t:1528139752552};\\\", \\\"{x:1333,y:752,t:1528139752569};\\\", \\\"{x:1334,y:752,t:1528139752750};\\\", \\\"{x:1335,y:752,t:1528139752759};\\\", \\\"{x:1337,y:752,t:1528139752770};\\\", \\\"{x:1340,y:755,t:1528139752787};\\\", \\\"{x:1343,y:758,t:1528139752803};\\\", \\\"{x:1343,y:759,t:1528139752819};\\\", \\\"{x:1343,y:763,t:1528139757759};\\\", \\\"{x:1340,y:780,t:1528139757776};\\\", \\\"{x:1335,y:793,t:1528139757792};\\\", \\\"{x:1331,y:804,t:1528139757809};\\\", \\\"{x:1326,y:814,t:1528139757825};\\\", \\\"{x:1324,y:824,t:1528139757843};\\\", \\\"{x:1317,y:839,t:1528139757859};\\\", \\\"{x:1311,y:853,t:1528139757875};\\\", \\\"{x:1306,y:865,t:1528139757893};\\\", \\\"{x:1300,y:877,t:1528139757909};\\\", \\\"{x:1291,y:892,t:1528139757926};\\\", \\\"{x:1287,y:901,t:1528139757942};\\\", \\\"{x:1284,y:907,t:1528139757960};\\\", \\\"{x:1282,y:915,t:1528139757976};\\\", \\\"{x:1278,y:921,t:1528139757992};\\\", \\\"{x:1278,y:923,t:1528139758009};\\\", \\\"{x:1277,y:927,t:1528139758025};\\\", \\\"{x:1276,y:929,t:1528139758042};\\\", \\\"{x:1275,y:931,t:1528139758059};\\\", \\\"{x:1275,y:933,t:1528139758076};\\\", \\\"{x:1274,y:935,t:1528139758092};\\\", \\\"{x:1274,y:938,t:1528139758109};\\\", \\\"{x:1272,y:943,t:1528139758126};\\\", \\\"{x:1271,y:946,t:1528139758142};\\\", \\\"{x:1270,y:949,t:1528139758159};\\\", \\\"{x:1268,y:953,t:1528139758176};\\\", \\\"{x:1267,y:956,t:1528139758193};\\\", \\\"{x:1265,y:961,t:1528139758210};\\\", \\\"{x:1263,y:965,t:1528139758227};\\\", \\\"{x:1261,y:968,t:1528139758242};\\\", \\\"{x:1259,y:971,t:1528139758260};\\\", \\\"{x:1256,y:975,t:1528139758276};\\\", \\\"{x:1255,y:976,t:1528139758293};\\\", \\\"{x:1253,y:978,t:1528139758310};\\\", \\\"{x:1251,y:980,t:1528139758326};\\\", \\\"{x:1248,y:981,t:1528139758343};\\\", \\\"{x:1247,y:981,t:1528139758360};\\\", \\\"{x:1246,y:982,t:1528139758376};\\\", \\\"{x:1245,y:982,t:1528139758393};\\\", \\\"{x:1245,y:983,t:1528139758410};\\\", \\\"{x:1244,y:983,t:1528139758591};\\\", \\\"{x:1244,y:982,t:1528139758606};\\\", \\\"{x:1244,y:981,t:1528139759430};\\\", \\\"{x:1244,y:978,t:1528139760574};\\\", \\\"{x:1244,y:976,t:1528139760581};\\\", \\\"{x:1244,y:974,t:1528139760595};\\\", \\\"{x:1244,y:971,t:1528139760613};\\\", \\\"{x:1244,y:969,t:1528139760629};\\\", \\\"{x:1244,y:968,t:1528139760645};\\\", \\\"{x:1244,y:965,t:1528139762382};\\\", \\\"{x:1241,y:933,t:1528139762397};\\\", \\\"{x:1231,y:894,t:1528139762414};\\\", \\\"{x:1222,y:840,t:1528139762430};\\\", \\\"{x:1215,y:817,t:1528139762447};\\\", \\\"{x:1206,y:794,t:1528139762465};\\\", \\\"{x:1199,y:772,t:1528139762481};\\\", \\\"{x:1195,y:757,t:1528139762497};\\\", \\\"{x:1193,y:748,t:1528139762514};\\\", \\\"{x:1191,y:738,t:1528139762531};\\\", \\\"{x:1189,y:734,t:1528139762547};\\\", \\\"{x:1188,y:730,t:1528139762564};\\\", \\\"{x:1187,y:726,t:1528139762581};\\\", \\\"{x:1186,y:723,t:1528139762598};\\\", \\\"{x:1186,y:721,t:1528139762614};\\\", \\\"{x:1186,y:720,t:1528139762637};\\\", \\\"{x:1186,y:728,t:1528139762814};\\\", \\\"{x:1186,y:752,t:1528139762832};\\\", \\\"{x:1189,y:774,t:1528139762848};\\\", \\\"{x:1194,y:792,t:1528139762864};\\\", \\\"{x:1199,y:805,t:1528139762882};\\\", \\\"{x:1200,y:811,t:1528139762898};\\\", \\\"{x:1202,y:814,t:1528139762914};\\\", \\\"{x:1202,y:815,t:1528139762931};\\\", \\\"{x:1202,y:813,t:1528139763159};\\\", \\\"{x:1202,y:805,t:1528139763166};\\\", \\\"{x:1200,y:793,t:1528139763182};\\\", \\\"{x:1196,y:781,t:1528139763198};\\\", \\\"{x:1193,y:772,t:1528139763216};\\\", \\\"{x:1191,y:766,t:1528139763232};\\\", \\\"{x:1189,y:759,t:1528139763249};\\\", \\\"{x:1188,y:756,t:1528139763266};\\\", \\\"{x:1188,y:754,t:1528139763282};\\\", \\\"{x:1187,y:753,t:1528139763299};\\\", \\\"{x:1187,y:756,t:1528139763455};\\\", \\\"{x:1187,y:760,t:1528139763466};\\\", \\\"{x:1187,y:768,t:1528139763482};\\\", \\\"{x:1187,y:781,t:1528139763498};\\\", \\\"{x:1189,y:794,t:1528139763515};\\\", \\\"{x:1192,y:807,t:1528139763532};\\\", \\\"{x:1196,y:816,t:1528139763548};\\\", \\\"{x:1199,y:822,t:1528139763565};\\\", \\\"{x:1200,y:825,t:1528139763582};\\\", \\\"{x:1200,y:827,t:1528139763598};\\\", \\\"{x:1201,y:829,t:1528139763616};\\\", \\\"{x:1202,y:830,t:1528139763632};\\\", \\\"{x:1202,y:831,t:1528139763649};\\\", \\\"{x:1203,y:833,t:1528139763665};\\\", \\\"{x:1203,y:834,t:1528139763682};\\\", \\\"{x:1204,y:835,t:1528139763698};\\\", \\\"{x:1204,y:836,t:1528139763716};\\\", \\\"{x:1205,y:837,t:1528139763732};\\\", \\\"{x:1206,y:839,t:1528139763750};\\\", \\\"{x:1207,y:840,t:1528139763766};\\\", \\\"{x:1208,y:840,t:1528139763782};\\\", \\\"{x:1208,y:841,t:1528139763822};\\\", \\\"{x:1209,y:841,t:1528139763863};\\\", \\\"{x:1209,y:842,t:1528139763870};\\\", \\\"{x:1210,y:842,t:1528139763918};\\\", \\\"{x:1210,y:846,t:1528139776294};\\\", \\\"{x:1217,y:869,t:1528139776302};\\\", \\\"{x:1232,y:881,t:1528139776314};\\\", \\\"{x:1221,y:872,t:1528139776935};\\\", \\\"{x:1155,y:828,t:1528139776947};\\\", \\\"{x:988,y:734,t:1528139776964};\\\", \\\"{x:810,y:644,t:1528139776981};\\\", \\\"{x:606,y:542,t:1528139776999};\\\", \\\"{x:541,y:503,t:1528139777015};\\\", \\\"{x:523,y:489,t:1528139777030};\\\", \\\"{x:505,y:472,t:1528139777056};\\\", \\\"{x:499,y:465,t:1528139777072};\\\", \\\"{x:496,y:460,t:1528139777088};\\\", \\\"{x:495,y:460,t:1528139777105};\\\", \\\"{x:494,y:458,t:1528139777122};\\\", \\\"{x:493,y:457,t:1528139777138};\\\", \\\"{x:492,y:456,t:1528139777156};\\\", \\\"{x:488,y:454,t:1528139777172};\\\", \\\"{x:484,y:451,t:1528139777189};\\\", \\\"{x:482,y:450,t:1528139777205};\\\", \\\"{x:481,y:450,t:1528139777222};\\\", \\\"{x:480,y:450,t:1528139777239};\\\", \\\"{x:478,y:450,t:1528139777256};\\\", \\\"{x:460,y:464,t:1528139777272};\\\", \\\"{x:443,y:488,t:1528139777290};\\\", \\\"{x:429,y:505,t:1528139777306};\\\", \\\"{x:423,y:517,t:1528139777322};\\\", \\\"{x:419,y:528,t:1528139777341};\\\", \\\"{x:415,y:540,t:1528139777357};\\\", \\\"{x:411,y:553,t:1528139777373};\\\", \\\"{x:409,y:560,t:1528139777389};\\\", \\\"{x:408,y:564,t:1528139777407};\\\", \\\"{x:408,y:567,t:1528139777422};\\\", \\\"{x:407,y:568,t:1528139777440};\\\", \\\"{x:405,y:569,t:1528139777456};\\\", \\\"{x:403,y:569,t:1528139777473};\\\", \\\"{x:399,y:567,t:1528139777490};\\\", \\\"{x:395,y:562,t:1528139777506};\\\", \\\"{x:392,y:557,t:1528139777522};\\\", \\\"{x:389,y:552,t:1528139777540};\\\", \\\"{x:386,y:546,t:1528139777557};\\\", \\\"{x:384,y:545,t:1528139777572};\\\", \\\"{x:383,y:545,t:1528139777613};\\\", \\\"{x:382,y:545,t:1528139777623};\\\", \\\"{x:380,y:545,t:1528139777640};\\\", \\\"{x:374,y:545,t:1528139777655};\\\", \\\"{x:361,y:546,t:1528139777673};\\\", \\\"{x:344,y:548,t:1528139777690};\\\", \\\"{x:321,y:548,t:1528139777706};\\\", \\\"{x:292,y:546,t:1528139777722};\\\", \\\"{x:263,y:541,t:1528139777740};\\\", \\\"{x:229,y:537,t:1528139777757};\\\", \\\"{x:208,y:532,t:1528139777773};\\\", \\\"{x:192,y:527,t:1528139777789};\\\", \\\"{x:179,y:522,t:1528139777806};\\\", \\\"{x:171,y:518,t:1528139777823};\\\", \\\"{x:166,y:515,t:1528139777840};\\\", \\\"{x:162,y:513,t:1528139777857};\\\", \\\"{x:158,y:510,t:1528139777872};\\\", \\\"{x:154,y:507,t:1528139777889};\\\", \\\"{x:149,y:502,t:1528139777907};\\\", \\\"{x:146,y:500,t:1528139777922};\\\", \\\"{x:144,y:498,t:1528139777939};\\\", \\\"{x:143,y:497,t:1528139777956};\\\", \\\"{x:142,y:497,t:1528139777973};\\\", \\\"{x:143,y:497,t:1528139778430};\\\", \\\"{x:146,y:499,t:1528139778439};\\\", \\\"{x:149,y:503,t:1528139778457};\\\", \\\"{x:156,y:510,t:1528139778475};\\\", \\\"{x:168,y:518,t:1528139778491};\\\", \\\"{x:188,y:527,t:1528139778507};\\\", \\\"{x:226,y:544,t:1528139778523};\\\", \\\"{x:335,y:579,t:1528139778541};\\\", \\\"{x:433,y:596,t:1528139778557};\\\", \\\"{x:545,y:614,t:1528139778573};\\\", \\\"{x:661,y:629,t:1528139778589};\\\", \\\"{x:772,y:645,t:1528139778607};\\\", \\\"{x:852,y:656,t:1528139778624};\\\", \\\"{x:888,y:658,t:1528139778640};\\\", \\\"{x:898,y:658,t:1528139778656};\\\", \\\"{x:899,y:658,t:1528139778733};\\\", \\\"{x:899,y:656,t:1528139778741};\\\", \\\"{x:899,y:650,t:1528139778757};\\\", \\\"{x:898,y:644,t:1528139778773};\\\", \\\"{x:896,y:638,t:1528139778791};\\\", \\\"{x:890,y:628,t:1528139778808};\\\", \\\"{x:879,y:616,t:1528139778824};\\\", \\\"{x:863,y:604,t:1528139778841};\\\", \\\"{x:842,y:592,t:1528139778857};\\\", \\\"{x:821,y:582,t:1528139778873};\\\", \\\"{x:795,y:574,t:1528139778890};\\\", \\\"{x:766,y:566,t:1528139778907};\\\", \\\"{x:741,y:563,t:1528139778924};\\\", \\\"{x:704,y:558,t:1528139778942};\\\", \\\"{x:671,y:554,t:1528139778958};\\\", \\\"{x:642,y:549,t:1528139778974};\\\", \\\"{x:620,y:549,t:1528139778991};\\\", \\\"{x:598,y:549,t:1528139779008};\\\", \\\"{x:582,y:549,t:1528139779024};\\\", \\\"{x:568,y:548,t:1528139779041};\\\", \\\"{x:564,y:548,t:1528139779057};\\\", \\\"{x:563,y:548,t:1528139779073};\\\", \\\"{x:562,y:548,t:1528139779141};\\\", \\\"{x:558,y:548,t:1528139779157};\\\", \\\"{x:541,y:545,t:1528139779174};\\\", \\\"{x:512,y:545,t:1528139779191};\\\", \\\"{x:482,y:542,t:1528139779209};\\\", \\\"{x:455,y:539,t:1528139779223};\\\", \\\"{x:441,y:536,t:1528139779241};\\\", \\\"{x:431,y:532,t:1528139779257};\\\", \\\"{x:427,y:531,t:1528139779274};\\\", \\\"{x:423,y:528,t:1528139779290};\\\", \\\"{x:420,y:526,t:1528139779307};\\\", \\\"{x:416,y:519,t:1528139779325};\\\", \\\"{x:413,y:514,t:1528139779341};\\\", \\\"{x:411,y:511,t:1528139779358};\\\", \\\"{x:407,y:507,t:1528139779374};\\\", \\\"{x:405,y:504,t:1528139779390};\\\", \\\"{x:403,y:501,t:1528139779408};\\\", \\\"{x:401,y:499,t:1528139779424};\\\", \\\"{x:400,y:496,t:1528139779441};\\\", \\\"{x:398,y:495,t:1528139779457};\\\", \\\"{x:395,y:492,t:1528139779473};\\\", \\\"{x:394,y:490,t:1528139779490};\\\", \\\"{x:392,y:489,t:1528139779508};\\\", \\\"{x:391,y:489,t:1528139779524};\\\", \\\"{x:391,y:490,t:1528139780972};\\\", \\\"{x:391,y:491,t:1528139782070};\\\", \\\"{x:391,y:492,t:1528139782077};\\\", \\\"{x:391,y:493,t:1528139782126};\\\", \\\"{x:391,y:494,t:1528139782198};\\\", \\\"{x:391,y:495,t:1528139782309};\\\", \\\"{x:391,y:496,t:1528139782534};\\\", \\\"{x:391,y:497,t:1528139782662};\\\", \\\"{x:385,y:500,t:1528139782677};\\\", \\\"{x:365,y:507,t:1528139782695};\\\", \\\"{x:327,y:513,t:1528139782710};\\\", \\\"{x:292,y:520,t:1528139782728};\\\", \\\"{x:277,y:524,t:1528139782744};\\\", \\\"{x:267,y:524,t:1528139782759};\\\", \\\"{x:256,y:524,t:1528139782777};\\\", \\\"{x:253,y:524,t:1528139782793};\\\", \\\"{x:252,y:524,t:1528139782809};\\\", \\\"{x:252,y:525,t:1528139782910};\\\", \\\"{x:252,y:528,t:1528139782926};\\\", \\\"{x:260,y:531,t:1528139782944};\\\", \\\"{x:270,y:533,t:1528139782961};\\\", \\\"{x:283,y:533,t:1528139782978};\\\", \\\"{x:297,y:538,t:1528139782994};\\\", \\\"{x:296,y:542,t:1528139789678};\\\", \\\"{x:290,y:552,t:1528139789685};\\\", \\\"{x:290,y:556,t:1528139789702};\\\", \\\"{x:303,y:582,t:1528139789717};\\\", \\\"{x:303,y:584,t:1528139789733};\\\", \\\"{x:301,y:584,t:1528139789982};\\\", \\\"{x:277,y:569,t:1528139789999};\\\", \\\"{x:246,y:552,t:1528139790017};\\\", \\\"{x:226,y:538,t:1528139790031};\\\", \\\"{x:215,y:528,t:1528139790048};\\\", \\\"{x:207,y:519,t:1528139790066};\\\", \\\"{x:204,y:511,t:1528139790082};\\\", \\\"{x:203,y:508,t:1528139790099};\\\", \\\"{x:203,y:507,t:1528139790116};\\\", \\\"{x:203,y:505,t:1528139790133};\\\", \\\"{x:203,y:503,t:1528139790149};\\\", \\\"{x:207,y:501,t:1528139790166};\\\", \\\"{x:212,y:499,t:1528139790183};\\\", \\\"{x:218,y:497,t:1528139790199};\\\", \\\"{x:224,y:494,t:1528139790217};\\\", \\\"{x:240,y:490,t:1528139790233};\\\", \\\"{x:300,y:490,t:1528139790250};\\\", \\\"{x:402,y:497,t:1528139790267};\\\", \\\"{x:512,y:511,t:1528139790284};\\\", \\\"{x:603,y:520,t:1528139790300};\\\", \\\"{x:676,y:533,t:1528139790316};\\\", \\\"{x:737,y:542,t:1528139790334};\\\", \\\"{x:745,y:542,t:1528139790350};\\\", \\\"{x:743,y:542,t:1528139790477};\\\", \\\"{x:739,y:542,t:1528139790485};\\\", \\\"{x:734,y:540,t:1528139790499};\\\", \\\"{x:718,y:534,t:1528139790518};\\\", \\\"{x:693,y:526,t:1528139790532};\\\", \\\"{x:678,y:523,t:1528139790550};\\\", \\\"{x:671,y:519,t:1528139790567};\\\", \\\"{x:668,y:518,t:1528139790583};\\\", \\\"{x:667,y:518,t:1528139790600};\\\", \\\"{x:664,y:517,t:1528139790616};\\\", \\\"{x:660,y:516,t:1528139790633};\\\", \\\"{x:655,y:515,t:1528139790650};\\\", \\\"{x:651,y:513,t:1528139790667};\\\", \\\"{x:647,y:513,t:1528139790683};\\\", \\\"{x:642,y:512,t:1528139790700};\\\", \\\"{x:639,y:510,t:1528139790717};\\\", \\\"{x:638,y:510,t:1528139790733};\\\", \\\"{x:637,y:509,t:1528139790773};\\\", \\\"{x:636,y:508,t:1528139790797};\\\", \\\"{x:635,y:508,t:1528139790812};\\\", \\\"{x:634,y:508,t:1528139790829};\\\", \\\"{x:633,y:507,t:1528139790837};\\\", \\\"{x:632,y:506,t:1528139790850};\\\", \\\"{x:631,y:506,t:1528139791068};\\\", \\\"{x:630,y:506,t:1528139791084};\\\", \\\"{x:628,y:509,t:1528139791100};\\\", \\\"{x:624,y:519,t:1528139791116};\\\", \\\"{x:622,y:531,t:1528139791134};\\\", \\\"{x:618,y:549,t:1528139791150};\\\", \\\"{x:611,y:571,t:1528139791168};\\\", \\\"{x:603,y:598,t:1528139791183};\\\", \\\"{x:599,y:631,t:1528139791200};\\\", \\\"{x:592,y:676,t:1528139791218};\\\", \\\"{x:580,y:718,t:1528139791234};\\\", \\\"{x:578,y:735,t:1528139791250};\\\", \\\"{x:578,y:740,t:1528139791267};\\\", \\\"{x:578,y:744,t:1528139791284};\\\", \\\"{x:577,y:746,t:1528139791300};\\\", \\\"{x:577,y:747,t:1528139791317};\\\", \\\"{x:576,y:750,t:1528139791334};\\\", \\\"{x:573,y:751,t:1528139791350};\\\", \\\"{x:567,y:754,t:1528139791367};\\\", \\\"{x:562,y:756,t:1528139791385};\\\", \\\"{x:550,y:757,t:1528139791400};\\\", \\\"{x:535,y:757,t:1528139791417};\\\", \\\"{x:527,y:757,t:1528139791435};\\\", \\\"{x:523,y:756,t:1528139791450};\\\", \\\"{x:520,y:753,t:1528139791468};\\\", \\\"{x:515,y:750,t:1528139791484};\\\", \\\"{x:512,y:747,t:1528139791501};\\\", \\\"{x:510,y:743,t:1528139791517};\\\", \\\"{x:509,y:742,t:1528139791535};\\\", \\\"{x:508,y:741,t:1528139791551};\\\", \\\"{x:508,y:740,t:1528139791568};\\\", \\\"{x:508,y:739,t:1528139791584};\\\" ] }, { \\\"rt\\\": 45863, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 523079, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -X -M -J -J -I -E -X -B -B -10 AM-09 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:737,t:1528139798609};\\\", \\\"{x:517,y:730,t:1528139798617};\\\", \\\"{x:537,y:726,t:1528139798631};\\\", \\\"{x:619,y:709,t:1528139798649};\\\", \\\"{x:716,y:696,t:1528139798663};\\\", \\\"{x:853,y:677,t:1528139798680};\\\", \\\"{x:894,y:671,t:1528139798693};\\\", \\\"{x:952,y:665,t:1528139798710};\\\", \\\"{x:992,y:662,t:1528139798727};\\\", \\\"{x:1022,y:657,t:1528139798743};\\\", \\\"{x:1054,y:652,t:1528139798760};\\\", \\\"{x:1074,y:650,t:1528139798776};\\\", \\\"{x:1100,y:650,t:1528139798793};\\\", \\\"{x:1161,y:650,t:1528139798810};\\\", \\\"{x:1269,y:650,t:1528139798827};\\\", \\\"{x:1377,y:650,t:1528139798843};\\\", \\\"{x:1480,y:650,t:1528139798860};\\\", \\\"{x:1546,y:644,t:1528139798877};\\\", \\\"{x:1566,y:636,t:1528139798894};\\\", \\\"{x:1575,y:630,t:1528139798911};\\\", \\\"{x:1587,y:624,t:1528139798927};\\\", \\\"{x:1610,y:618,t:1528139798944};\\\", \\\"{x:1613,y:617,t:1528139798961};\\\", \\\"{x:1610,y:618,t:1528139799289};\\\", \\\"{x:1609,y:618,t:1528139799305};\\\", \\\"{x:1606,y:619,t:1528139799313};\\\", \\\"{x:1606,y:620,t:1528139799346};\\\", \\\"{x:1602,y:622,t:1528139800016};\\\", \\\"{x:1596,y:627,t:1528139800029};\\\", \\\"{x:1582,y:632,t:1528139800048};\\\", \\\"{x:1572,y:637,t:1528139800062};\\\", \\\"{x:1567,y:639,t:1528139800078};\\\", \\\"{x:1563,y:642,t:1528139800095};\\\", \\\"{x:1562,y:642,t:1528139800111};\\\", \\\"{x:1560,y:645,t:1528139800128};\\\", \\\"{x:1557,y:648,t:1528139800145};\\\", \\\"{x:1552,y:654,t:1528139800161};\\\", \\\"{x:1547,y:660,t:1528139800178};\\\", \\\"{x:1545,y:661,t:1528139800195};\\\", \\\"{x:1540,y:667,t:1528139800211};\\\", \\\"{x:1535,y:673,t:1528139800228};\\\", \\\"{x:1529,y:680,t:1528139800246};\\\", \\\"{x:1524,y:686,t:1528139800261};\\\", \\\"{x:1517,y:693,t:1528139800279};\\\", \\\"{x:1511,y:701,t:1528139800295};\\\", \\\"{x:1502,y:708,t:1528139800311};\\\", \\\"{x:1494,y:717,t:1528139800329};\\\", \\\"{x:1488,y:726,t:1528139800346};\\\", \\\"{x:1482,y:738,t:1528139800363};\\\", \\\"{x:1481,y:754,t:1528139800379};\\\", \\\"{x:1477,y:769,t:1528139800396};\\\", \\\"{x:1473,y:782,t:1528139800413};\\\", \\\"{x:1471,y:789,t:1528139800428};\\\", \\\"{x:1471,y:791,t:1528139800446};\\\", \\\"{x:1471,y:790,t:1528139801097};\\\", \\\"{x:1471,y:789,t:1528139801121};\\\", \\\"{x:1471,y:787,t:1528139801137};\\\", \\\"{x:1472,y:787,t:1528139801161};\\\", \\\"{x:1473,y:786,t:1528139801169};\\\", \\\"{x:1474,y:785,t:1528139801180};\\\", \\\"{x:1481,y:784,t:1528139801197};\\\", \\\"{x:1495,y:783,t:1528139801213};\\\", \\\"{x:1515,y:783,t:1528139801230};\\\", \\\"{x:1542,y:783,t:1528139801247};\\\", \\\"{x:1575,y:779,t:1528139801262};\\\", \\\"{x:1611,y:775,t:1528139801280};\\\", \\\"{x:1655,y:763,t:1528139801297};\\\", \\\"{x:1673,y:756,t:1528139801313};\\\", \\\"{x:1685,y:748,t:1528139801329};\\\", \\\"{x:1691,y:744,t:1528139801347};\\\", \\\"{x:1694,y:740,t:1528139801363};\\\", \\\"{x:1698,y:736,t:1528139801380};\\\", \\\"{x:1699,y:733,t:1528139801396};\\\", \\\"{x:1699,y:728,t:1528139801413};\\\", \\\"{x:1699,y:721,t:1528139801430};\\\", \\\"{x:1698,y:713,t:1528139801446};\\\", \\\"{x:1691,y:703,t:1528139801464};\\\", \\\"{x:1686,y:694,t:1528139801480};\\\", \\\"{x:1674,y:682,t:1528139801497};\\\", \\\"{x:1663,y:672,t:1528139801513};\\\", \\\"{x:1648,y:661,t:1528139801530};\\\", \\\"{x:1635,y:650,t:1528139801547};\\\", \\\"{x:1627,y:641,t:1528139801564};\\\", \\\"{x:1620,y:626,t:1528139801580};\\\", \\\"{x:1617,y:608,t:1528139801597};\\\", \\\"{x:1615,y:598,t:1528139801613};\\\", \\\"{x:1615,y:592,t:1528139801629};\\\", \\\"{x:1614,y:586,t:1528139801647};\\\", \\\"{x:1614,y:581,t:1528139801663};\\\", \\\"{x:1614,y:578,t:1528139801680};\\\", \\\"{x:1614,y:573,t:1528139801696};\\\", \\\"{x:1614,y:572,t:1528139801714};\\\", \\\"{x:1614,y:571,t:1528139801994};\\\", \\\"{x:1610,y:567,t:1528139802001};\\\", \\\"{x:1607,y:564,t:1528139802013};\\\", \\\"{x:1603,y:559,t:1528139802030};\\\", \\\"{x:1602,y:556,t:1528139802046};\\\", \\\"{x:1599,y:552,t:1528139802063};\\\", \\\"{x:1595,y:545,t:1528139802080};\\\", \\\"{x:1593,y:541,t:1528139802096};\\\", \\\"{x:1591,y:537,t:1528139802113};\\\", \\\"{x:1589,y:535,t:1528139802131};\\\", \\\"{x:1588,y:533,t:1528139802146};\\\", \\\"{x:1586,y:531,t:1528139802163};\\\", \\\"{x:1585,y:530,t:1528139802181};\\\", \\\"{x:1585,y:528,t:1528139802198};\\\", \\\"{x:1584,y:527,t:1528139802225};\\\", \\\"{x:1583,y:527,t:1528139802321};\\\", \\\"{x:1582,y:527,t:1528139802553};\\\", \\\"{x:1580,y:527,t:1528139802568};\\\", \\\"{x:1578,y:527,t:1528139802581};\\\", \\\"{x:1576,y:529,t:1528139802597};\\\", \\\"{x:1572,y:534,t:1528139802614};\\\", \\\"{x:1569,y:539,t:1528139802630};\\\", \\\"{x:1566,y:543,t:1528139802647};\\\", \\\"{x:1557,y:556,t:1528139802664};\\\", \\\"{x:1550,y:568,t:1528139802680};\\\", \\\"{x:1543,y:582,t:1528139802697};\\\", \\\"{x:1536,y:600,t:1528139802714};\\\", \\\"{x:1530,y:623,t:1528139802730};\\\", \\\"{x:1526,y:645,t:1528139802748};\\\", \\\"{x:1519,y:670,t:1528139802764};\\\", \\\"{x:1515,y:691,t:1528139802781};\\\", \\\"{x:1511,y:710,t:1528139802798};\\\", \\\"{x:1510,y:726,t:1528139802815};\\\", \\\"{x:1508,y:741,t:1528139802831};\\\", \\\"{x:1505,y:755,t:1528139802847};\\\", \\\"{x:1501,y:771,t:1528139802864};\\\", \\\"{x:1500,y:780,t:1528139802880};\\\", \\\"{x:1499,y:788,t:1528139802898};\\\", \\\"{x:1496,y:798,t:1528139802914};\\\", \\\"{x:1494,y:804,t:1528139802932};\\\", \\\"{x:1492,y:810,t:1528139802948};\\\", \\\"{x:1490,y:817,t:1528139802965};\\\", \\\"{x:1488,y:821,t:1528139802982};\\\", \\\"{x:1485,y:828,t:1528139802998};\\\", \\\"{x:1482,y:833,t:1528139803015};\\\", \\\"{x:1479,y:840,t:1528139803033};\\\", \\\"{x:1474,y:848,t:1528139803047};\\\", \\\"{x:1467,y:857,t:1528139803065};\\\", \\\"{x:1464,y:862,t:1528139803081};\\\", \\\"{x:1459,y:866,t:1528139803098};\\\", \\\"{x:1451,y:871,t:1528139803114};\\\", \\\"{x:1442,y:875,t:1528139803132};\\\", \\\"{x:1430,y:880,t:1528139803148};\\\", \\\"{x:1417,y:882,t:1528139803165};\\\", \\\"{x:1401,y:885,t:1528139803182};\\\", \\\"{x:1381,y:887,t:1528139803198};\\\", \\\"{x:1357,y:891,t:1528139803215};\\\", \\\"{x:1333,y:893,t:1528139803231};\\\", \\\"{x:1289,y:893,t:1528139803249};\\\", \\\"{x:1263,y:893,t:1528139803265};\\\", \\\"{x:1243,y:893,t:1528139803281};\\\", \\\"{x:1229,y:891,t:1528139803299};\\\", \\\"{x:1218,y:887,t:1528139803315};\\\", \\\"{x:1211,y:884,t:1528139803332};\\\", \\\"{x:1209,y:880,t:1528139803349};\\\", \\\"{x:1207,y:875,t:1528139803365};\\\", \\\"{x:1205,y:871,t:1528139803382};\\\", \\\"{x:1204,y:867,t:1528139803398};\\\", \\\"{x:1204,y:863,t:1528139803414};\\\", \\\"{x:1203,y:859,t:1528139803431};\\\", \\\"{x:1203,y:856,t:1528139803448};\\\", \\\"{x:1203,y:854,t:1528139803464};\\\", \\\"{x:1203,y:853,t:1528139803481};\\\", \\\"{x:1203,y:852,t:1528139803498};\\\", \\\"{x:1203,y:850,t:1528139803514};\\\", \\\"{x:1203,y:848,t:1528139803531};\\\", \\\"{x:1203,y:845,t:1528139803548};\\\", \\\"{x:1204,y:844,t:1528139803565};\\\", \\\"{x:1204,y:842,t:1528139803582};\\\", \\\"{x:1205,y:842,t:1528139803598};\\\", \\\"{x:1205,y:841,t:1528139803615};\\\", \\\"{x:1205,y:839,t:1528139803631};\\\", \\\"{x:1205,y:837,t:1528139803648};\\\", \\\"{x:1205,y:835,t:1528139803666};\\\", \\\"{x:1205,y:833,t:1528139803681};\\\", \\\"{x:1206,y:832,t:1528139803699};\\\", \\\"{x:1206,y:831,t:1528139803745};\\\", \\\"{x:1207,y:831,t:1528139804497};\\\", \\\"{x:1208,y:830,t:1528139804529};\\\", \\\"{x:1209,y:830,t:1528139804553};\\\", \\\"{x:1210,y:829,t:1528139804592};\\\", \\\"{x:1211,y:829,t:1528139806633};\\\", \\\"{x:1210,y:821,t:1528139806641};\\\", \\\"{x:1203,y:814,t:1528139806652};\\\", \\\"{x:1195,y:800,t:1528139806668};\\\", \\\"{x:1187,y:785,t:1528139806685};\\\", \\\"{x:1181,y:779,t:1528139806702};\\\", \\\"{x:1179,y:775,t:1528139806718};\\\", \\\"{x:1178,y:774,t:1528139806737};\\\", \\\"{x:1178,y:773,t:1528139806769};\\\", \\\"{x:1178,y:772,t:1528139806922};\\\", \\\"{x:1178,y:771,t:1528139807041};\\\", \\\"{x:1178,y:770,t:1528139807052};\\\", \\\"{x:1178,y:767,t:1528139807069};\\\", \\\"{x:1178,y:766,t:1528139807101};\\\", \\\"{x:1178,y:764,t:1528139807119};\\\", \\\"{x:1178,y:763,t:1528139807137};\\\", \\\"{x:1179,y:759,t:1528139810209};\\\", \\\"{x:1181,y:748,t:1528139810223};\\\", \\\"{x:1187,y:728,t:1528139810238};\\\", \\\"{x:1208,y:677,t:1528139810255};\\\", \\\"{x:1231,y:621,t:1528139810272};\\\", \\\"{x:1255,y:580,t:1528139810289};\\\", \\\"{x:1272,y:550,t:1528139810305};\\\", \\\"{x:1282,y:535,t:1528139810322};\\\", \\\"{x:1284,y:526,t:1528139810339};\\\", \\\"{x:1288,y:519,t:1528139810355};\\\", \\\"{x:1292,y:513,t:1528139810371};\\\", \\\"{x:1294,y:507,t:1528139810390};\\\", \\\"{x:1295,y:504,t:1528139810405};\\\", \\\"{x:1295,y:503,t:1528139810421};\\\", \\\"{x:1296,y:501,t:1528139810439};\\\", \\\"{x:1297,y:500,t:1528139810455};\\\", \\\"{x:1297,y:501,t:1528139810594};\\\", \\\"{x:1297,y:506,t:1528139810605};\\\", \\\"{x:1297,y:515,t:1528139810622};\\\", \\\"{x:1297,y:524,t:1528139810639};\\\", \\\"{x:1296,y:532,t:1528139810655};\\\", \\\"{x:1296,y:540,t:1528139810672};\\\", \\\"{x:1294,y:545,t:1528139810688};\\\", \\\"{x:1293,y:548,t:1528139810706};\\\", \\\"{x:1293,y:549,t:1528139810723};\\\", \\\"{x:1293,y:551,t:1528139810739};\\\", \\\"{x:1292,y:553,t:1528139810756};\\\", \\\"{x:1292,y:554,t:1528139810772};\\\", \\\"{x:1291,y:555,t:1528139810791};\\\", \\\"{x:1291,y:556,t:1528139810809};\\\", \\\"{x:1290,y:556,t:1528139810822};\\\", \\\"{x:1290,y:557,t:1528139810841};\\\", \\\"{x:1288,y:558,t:1528139810873};\\\", \\\"{x:1287,y:558,t:1528139810889};\\\", \\\"{x:1285,y:559,t:1528139810913};\\\", \\\"{x:1285,y:560,t:1528139810939};\\\", \\\"{x:1284,y:560,t:1528139810956};\\\", \\\"{x:1283,y:560,t:1528139810977};\\\", \\\"{x:1282,y:561,t:1528139810993};\\\", \\\"{x:1281,y:561,t:1528139811016};\\\", \\\"{x:1281,y:562,t:1528139811033};\\\", \\\"{x:1280,y:562,t:1528139811048};\\\", \\\"{x:1279,y:563,t:1528139811081};\\\", \\\"{x:1275,y:564,t:1528139821202};\\\", \\\"{x:1236,y:564,t:1528139821215};\\\", \\\"{x:1048,y:564,t:1528139821231};\\\", \\\"{x:962,y:564,t:1528139821249};\\\", \\\"{x:874,y:559,t:1528139821264};\\\", \\\"{x:775,y:548,t:1528139821283};\\\", \\\"{x:651,y:535,t:1528139821300};\\\", \\\"{x:537,y:517,t:1528139821315};\\\", \\\"{x:454,y:506,t:1528139821328};\\\", \\\"{x:430,y:502,t:1528139821345};\\\", \\\"{x:428,y:502,t:1528139821361};\\\", \\\"{x:427,y:500,t:1528139821448};\\\", \\\"{x:436,y:494,t:1528139821462};\\\", \\\"{x:490,y:486,t:1528139821478};\\\", \\\"{x:579,y:486,t:1528139821495};\\\", \\\"{x:685,y:484,t:1528139821511};\\\", \\\"{x:730,y:484,t:1528139821529};\\\", \\\"{x:752,y:484,t:1528139821545};\\\", \\\"{x:754,y:484,t:1528139821562};\\\", \\\"{x:755,y:484,t:1528139821673};\\\", \\\"{x:755,y:485,t:1528139821689};\\\", \\\"{x:753,y:487,t:1528139821698};\\\", \\\"{x:749,y:489,t:1528139821712};\\\", \\\"{x:740,y:493,t:1528139821729};\\\", \\\"{x:726,y:497,t:1528139821745};\\\", \\\"{x:711,y:501,t:1528139821763};\\\", \\\"{x:696,y:503,t:1528139821779};\\\", \\\"{x:682,y:504,t:1528139821795};\\\", \\\"{x:668,y:507,t:1528139821811};\\\", \\\"{x:658,y:508,t:1528139821829};\\\", \\\"{x:646,y:512,t:1528139821845};\\\", \\\"{x:640,y:513,t:1528139821861};\\\", \\\"{x:634,y:514,t:1528139821879};\\\", \\\"{x:632,y:514,t:1528139821895};\\\", \\\"{x:631,y:514,t:1528139821912};\\\", \\\"{x:630,y:514,t:1528139821929};\\\", \\\"{x:628,y:514,t:1528139821945};\\\", \\\"{x:625,y:514,t:1528139821962};\\\", \\\"{x:624,y:514,t:1528139821979};\\\", \\\"{x:622,y:514,t:1528139821995};\\\", \\\"{x:621,y:514,t:1528139822013};\\\", \\\"{x:619,y:514,t:1528139822030};\\\", \\\"{x:618,y:514,t:1528139822045};\\\", \\\"{x:617,y:514,t:1528139822063};\\\", \\\"{x:617,y:513,t:1528139822114};\\\", \\\"{x:616,y:512,t:1528139822129};\\\", \\\"{x:615,y:512,t:1528139822296};\\\", \\\"{x:633,y:515,t:1528139833017};\\\", \\\"{x:675,y:527,t:1528139833024};\\\", \\\"{x:801,y:559,t:1528139833053};\\\", \\\"{x:866,y:571,t:1528139833070};\\\", \\\"{x:930,y:571,t:1528139833086};\\\", \\\"{x:970,y:576,t:1528139833105};\\\", \\\"{x:976,y:576,t:1528139833121};\\\", \\\"{x:977,y:576,t:1528139833224};\\\", \\\"{x:979,y:576,t:1528139833239};\\\", \\\"{x:1002,y:577,t:1528139833256};\\\", \\\"{x:1043,y:589,t:1528139833272};\\\", \\\"{x:1117,y:607,t:1528139833288};\\\", \\\"{x:1210,y:628,t:1528139833306};\\\", \\\"{x:1317,y:667,t:1528139833322};\\\", \\\"{x:1441,y:720,t:1528139833339};\\\", \\\"{x:1553,y:784,t:1528139833356};\\\", \\\"{x:1643,y:834,t:1528139833373};\\\", \\\"{x:1670,y:859,t:1528139833393};\\\", \\\"{x:1697,y:887,t:1528139833406};\\\", \\\"{x:1711,y:900,t:1528139833422};\\\", \\\"{x:1715,y:904,t:1528139833439};\\\", \\\"{x:1713,y:904,t:1528139833536};\\\", \\\"{x:1700,y:901,t:1528139833544};\\\", \\\"{x:1689,y:896,t:1528139833556};\\\", \\\"{x:1642,y:878,t:1528139833573};\\\", \\\"{x:1567,y:856,t:1528139833590};\\\", \\\"{x:1482,y:835,t:1528139833607};\\\", \\\"{x:1362,y:800,t:1528139833624};\\\", \\\"{x:1320,y:788,t:1528139833639};\\\", \\\"{x:1311,y:784,t:1528139833656};\\\", \\\"{x:1310,y:784,t:1528139833753};\\\", \\\"{x:1310,y:783,t:1528139833761};\\\", \\\"{x:1310,y:781,t:1528139833774};\\\", \\\"{x:1313,y:776,t:1528139833791};\\\", \\\"{x:1318,y:769,t:1528139833809};\\\", \\\"{x:1323,y:766,t:1528139833825};\\\", \\\"{x:1325,y:765,t:1528139833841};\\\", \\\"{x:1328,y:763,t:1528139833858};\\\", \\\"{x:1329,y:762,t:1528139833876};\\\", \\\"{x:1330,y:762,t:1528139833892};\\\", \\\"{x:1331,y:762,t:1528139833912};\\\", \\\"{x:1332,y:761,t:1528139833925};\\\", \\\"{x:1333,y:761,t:1528139833945};\\\", \\\"{x:1334,y:760,t:1528139833958};\\\", \\\"{x:1335,y:760,t:1528139833975};\\\", \\\"{x:1337,y:759,t:1528139834001};\\\", \\\"{x:1338,y:759,t:1528139834016};\\\", \\\"{x:1340,y:758,t:1528139834033};\\\", \\\"{x:1340,y:757,t:1528139834043};\\\", \\\"{x:1342,y:757,t:1528139834059};\\\", \\\"{x:1344,y:756,t:1528139834075};\\\", \\\"{x:1344,y:758,t:1528139834305};\\\", \\\"{x:1343,y:763,t:1528139834312};\\\", \\\"{x:1340,y:770,t:1528139834326};\\\", \\\"{x:1332,y:783,t:1528139834342};\\\", \\\"{x:1322,y:800,t:1528139834360};\\\", \\\"{x:1318,y:809,t:1528139834376};\\\", \\\"{x:1314,y:816,t:1528139834393};\\\", \\\"{x:1309,y:824,t:1528139834410};\\\", \\\"{x:1305,y:832,t:1528139834427};\\\", \\\"{x:1301,y:842,t:1528139834444};\\\", \\\"{x:1297,y:848,t:1528139834460};\\\", \\\"{x:1296,y:854,t:1528139834477};\\\", \\\"{x:1294,y:857,t:1528139834494};\\\", \\\"{x:1293,y:860,t:1528139834511};\\\", \\\"{x:1292,y:862,t:1528139834527};\\\", \\\"{x:1290,y:868,t:1528139834545};\\\", \\\"{x:1290,y:871,t:1528139834560};\\\", \\\"{x:1289,y:875,t:1528139834577};\\\", \\\"{x:1287,y:880,t:1528139834594};\\\", \\\"{x:1286,y:885,t:1528139834611};\\\", \\\"{x:1285,y:887,t:1528139834628};\\\", \\\"{x:1283,y:891,t:1528139834644};\\\", \\\"{x:1281,y:895,t:1528139834661};\\\", \\\"{x:1279,y:901,t:1528139834678};\\\", \\\"{x:1276,y:907,t:1528139834695};\\\", \\\"{x:1273,y:916,t:1528139834711};\\\", \\\"{x:1269,y:924,t:1528139834729};\\\", \\\"{x:1267,y:928,t:1528139834745};\\\", \\\"{x:1262,y:936,t:1528139834762};\\\", \\\"{x:1259,y:941,t:1528139834778};\\\", \\\"{x:1257,y:945,t:1528139834795};\\\", \\\"{x:1254,y:950,t:1528139834812};\\\", \\\"{x:1251,y:954,t:1528139834828};\\\", \\\"{x:1249,y:957,t:1528139834845};\\\", \\\"{x:1247,y:960,t:1528139834862};\\\", \\\"{x:1247,y:961,t:1528139834879};\\\", \\\"{x:1246,y:962,t:1528139834895};\\\", \\\"{x:1244,y:964,t:1528139834913};\\\", \\\"{x:1243,y:965,t:1528139834937};\\\", \\\"{x:1243,y:967,t:1528139834976};\\\", \\\"{x:1241,y:967,t:1528139835625};\\\", \\\"{x:1237,y:969,t:1528139835632};\\\", \\\"{x:1207,y:970,t:1528139835648};\\\", \\\"{x:1148,y:970,t:1528139835666};\\\", \\\"{x:1054,y:970,t:1528139835683};\\\", \\\"{x:909,y:964,t:1528139835699};\\\", \\\"{x:766,y:932,t:1528139835715};\\\", \\\"{x:718,y:899,t:1528139835732};\\\", \\\"{x:710,y:892,t:1528139835749};\\\", \\\"{x:709,y:891,t:1528139835766};\\\", \\\"{x:708,y:886,t:1528139835782};\\\", \\\"{x:703,y:875,t:1528139835799};\\\", \\\"{x:690,y:849,t:1528139835816};\\\", \\\"{x:674,y:821,t:1528139835832};\\\", \\\"{x:657,y:795,t:1528139835848};\\\", \\\"{x:631,y:770,t:1528139835866};\\\", \\\"{x:596,y:749,t:1528139835882};\\\", \\\"{x:573,y:737,t:1528139835899};\\\", \\\"{x:564,y:734,t:1528139835917};\\\", \\\"{x:563,y:733,t:1528139835933};\\\", \\\"{x:563,y:732,t:1528139835949};\\\", \\\"{x:563,y:721,t:1528139835973};\\\", \\\"{x:572,y:711,t:1528139835991};\\\", \\\"{x:572,y:709,t:1528139836648};\\\", \\\"{x:572,y:705,t:1528139836658};\\\", \\\"{x:567,y:694,t:1528139836674};\\\", \\\"{x:560,y:678,t:1528139836691};\\\", \\\"{x:545,y:656,t:1528139836708};\\\", \\\"{x:519,y:628,t:1528139836725};\\\", \\\"{x:481,y:598,t:1528139836741};\\\", \\\"{x:434,y:565,t:1528139836758};\\\", \\\"{x:389,y:535,t:1528139836775};\\\", \\\"{x:356,y:516,t:1528139836791};\\\", \\\"{x:329,y:497,t:1528139836808};\\\", \\\"{x:312,y:478,t:1528139836824};\\\", \\\"{x:300,y:466,t:1528139836840};\\\", \\\"{x:297,y:460,t:1528139836858};\\\", \\\"{x:296,y:459,t:1528139836874};\\\", \\\"{x:297,y:463,t:1528139837048};\\\", \\\"{x:301,y:474,t:1528139837057};\\\", \\\"{x:312,y:497,t:1528139837075};\\\", \\\"{x:321,y:513,t:1528139837090};\\\", \\\"{x:331,y:531,t:1528139837108};\\\", \\\"{x:341,y:546,t:1528139837124};\\\", \\\"{x:345,y:554,t:1528139837140};\\\", \\\"{x:347,y:559,t:1528139837158};\\\", \\\"{x:347,y:560,t:1528139837174};\\\", \\\"{x:347,y:562,t:1528139837191};\\\", \\\"{x:348,y:564,t:1528139837208};\\\", \\\"{x:348,y:565,t:1528139837224};\\\", \\\"{x:348,y:566,t:1528139837241};\\\", \\\"{x:348,y:568,t:1528139837257};\\\", \\\"{x:336,y:569,t:1528139837275};\\\", \\\"{x:312,y:571,t:1528139837292};\\\", \\\"{x:273,y:571,t:1528139837307};\\\", \\\"{x:220,y:571,t:1528139837326};\\\", \\\"{x:175,y:567,t:1528139837343};\\\", \\\"{x:135,y:560,t:1528139837358};\\\", \\\"{x:115,y:553,t:1528139837375};\\\", \\\"{x:109,y:550,t:1528139837392};\\\", \\\"{x:108,y:549,t:1528139837408};\\\", \\\"{x:108,y:545,t:1528139837425};\\\", \\\"{x:108,y:542,t:1528139837442};\\\", \\\"{x:108,y:537,t:1528139837458};\\\", \\\"{x:108,y:528,t:1528139837475};\\\", \\\"{x:113,y:515,t:1528139837493};\\\", \\\"{x:117,y:506,t:1528139837508};\\\", \\\"{x:121,y:499,t:1528139837524};\\\", \\\"{x:123,y:495,t:1528139837542};\\\", \\\"{x:126,y:492,t:1528139837559};\\\", \\\"{x:128,y:491,t:1528139837574};\\\", \\\"{x:130,y:490,t:1528139837592};\\\", \\\"{x:131,y:490,t:1528139837880};\\\", \\\"{x:134,y:490,t:1528139837892};\\\", \\\"{x:135,y:490,t:1528139837920};\\\", \\\"{x:136,y:490,t:1528139837936};\\\", \\\"{x:137,y:490,t:1528139837944};\\\", \\\"{x:138,y:491,t:1528139837959};\\\", \\\"{x:146,y:495,t:1528139837976};\\\", \\\"{x:154,y:499,t:1528139837993};\\\", \\\"{x:168,y:504,t:1528139838009};\\\", \\\"{x:188,y:507,t:1528139838025};\\\", \\\"{x:202,y:509,t:1528139838041};\\\", \\\"{x:204,y:509,t:1528139838059};\\\", \\\"{x:202,y:509,t:1528139838176};\\\", \\\"{x:186,y:504,t:1528139838192};\\\", \\\"{x:169,y:498,t:1528139838208};\\\", \\\"{x:153,y:496,t:1528139838226};\\\", \\\"{x:145,y:494,t:1528139838242};\\\", \\\"{x:144,y:494,t:1528139838258};\\\", \\\"{x:145,y:494,t:1528139838505};\\\", \\\"{x:147,y:494,t:1528139838512};\\\", \\\"{x:149,y:494,t:1528139838528};\\\", \\\"{x:150,y:496,t:1528139838542};\\\", \\\"{x:151,y:497,t:1528139838559};\\\", \\\"{x:156,y:499,t:1528139838577};\\\", \\\"{x:156,y:500,t:1528139838591};\\\", \\\"{x:157,y:501,t:1528139838623};\\\", \\\"{x:159,y:503,t:1528139838920};\\\", \\\"{x:163,y:508,t:1528139838928};\\\", \\\"{x:167,y:514,t:1528139838943};\\\", \\\"{x:180,y:528,t:1528139838959};\\\", \\\"{x:210,y:563,t:1528139838976};\\\", \\\"{x:249,y:605,t:1528139838994};\\\", \\\"{x:302,y:654,t:1528139839010};\\\", \\\"{x:377,y:723,t:1528139839026};\\\", \\\"{x:449,y:787,t:1528139839043};\\\", \\\"{x:517,y:847,t:1528139839059};\\\", \\\"{x:586,y:902,t:1528139839076};\\\", \\\"{x:633,y:934,t:1528139839093};\\\", \\\"{x:651,y:949,t:1528139839109};\\\", \\\"{x:660,y:958,t:1528139839126};\\\", \\\"{x:662,y:962,t:1528139839143};\\\", \\\"{x:663,y:962,t:1528139839160};\\\", \\\"{x:663,y:963,t:1528139839192};\\\", \\\"{x:664,y:963,t:1528139839216};\\\", \\\"{x:665,y:962,t:1528139839232};\\\", \\\"{x:665,y:958,t:1528139839243};\\\", \\\"{x:665,y:945,t:1528139839260};\\\", \\\"{x:661,y:925,t:1528139839275};\\\", \\\"{x:652,y:902,t:1528139839292};\\\", \\\"{x:636,y:878,t:1528139839310};\\\", \\\"{x:619,y:854,t:1528139839326};\\\", \\\"{x:604,y:835,t:1528139839343};\\\", \\\"{x:586,y:814,t:1528139839360};\\\", \\\"{x:578,y:803,t:1528139839376};\\\", \\\"{x:570,y:792,t:1528139839393};\\\", \\\"{x:564,y:783,t:1528139839409};\\\", \\\"{x:560,y:776,t:1528139839425};\\\", \\\"{x:557,y:773,t:1528139839443};\\\", \\\"{x:554,y:770,t:1528139839459};\\\", \\\"{x:550,y:764,t:1528139839475};\\\", \\\"{x:546,y:760,t:1528139839493};\\\", \\\"{x:542,y:755,t:1528139839510};\\\", \\\"{x:536,y:750,t:1528139839526};\\\", \\\"{x:534,y:748,t:1528139839543};\\\", \\\"{x:533,y:746,t:1528139839559};\\\", \\\"{x:532,y:743,t:1528139839576};\\\" ] }, { \\\"rt\\\": 11537, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 535890, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:741,t:1528139843496};\\\", \\\"{x:590,y:741,t:1528139843510};\\\", \\\"{x:785,y:709,t:1528139843528};\\\", \\\"{x:856,y:699,t:1528139843542};\\\", \\\"{x:1010,y:688,t:1528139843562};\\\", \\\"{x:1053,y:688,t:1528139843580};\\\", \\\"{x:1072,y:688,t:1528139843596};\\\", \\\"{x:1083,y:688,t:1528139843613};\\\", \\\"{x:1087,y:688,t:1528139843630};\\\", \\\"{x:1089,y:688,t:1528139843646};\\\", \\\"{x:1093,y:688,t:1528139843663};\\\", \\\"{x:1102,y:688,t:1528139843680};\\\", \\\"{x:1133,y:688,t:1528139843696};\\\", \\\"{x:1197,y:680,t:1528139843714};\\\", \\\"{x:1259,y:676,t:1528139843730};\\\", \\\"{x:1315,y:668,t:1528139843747};\\\", \\\"{x:1348,y:663,t:1528139843763};\\\", \\\"{x:1366,y:661,t:1528139843780};\\\", \\\"{x:1370,y:660,t:1528139843797};\\\", \\\"{x:1371,y:660,t:1528139843824};\\\", \\\"{x:1373,y:660,t:1528139843832};\\\", \\\"{x:1375,y:660,t:1528139843847};\\\", \\\"{x:1383,y:664,t:1528139843863};\\\", \\\"{x:1413,y:686,t:1528139843880};\\\", \\\"{x:1456,y:713,t:1528139843897};\\\", \\\"{x:1500,y:731,t:1528139843914};\\\", \\\"{x:1532,y:744,t:1528139843930};\\\", \\\"{x:1545,y:752,t:1528139843947};\\\", \\\"{x:1548,y:753,t:1528139843963};\\\", \\\"{x:1546,y:753,t:1528139844017};\\\", \\\"{x:1542,y:753,t:1528139844031};\\\", \\\"{x:1525,y:753,t:1528139844048};\\\", \\\"{x:1505,y:753,t:1528139844064};\\\", \\\"{x:1472,y:757,t:1528139844080};\\\", \\\"{x:1456,y:758,t:1528139844097};\\\", \\\"{x:1442,y:758,t:1528139844114};\\\", \\\"{x:1435,y:758,t:1528139844131};\\\", \\\"{x:1428,y:758,t:1528139844147};\\\", \\\"{x:1422,y:758,t:1528139844165};\\\", \\\"{x:1417,y:757,t:1528139844181};\\\", \\\"{x:1412,y:756,t:1528139844197};\\\", \\\"{x:1407,y:754,t:1528139844215};\\\", \\\"{x:1404,y:752,t:1528139844231};\\\", \\\"{x:1401,y:752,t:1528139844247};\\\", \\\"{x:1398,y:750,t:1528139844264};\\\", \\\"{x:1397,y:749,t:1528139844281};\\\", \\\"{x:1393,y:747,t:1528139844297};\\\", \\\"{x:1391,y:746,t:1528139844314};\\\", \\\"{x:1386,y:742,t:1528139844330};\\\", \\\"{x:1381,y:739,t:1528139844348};\\\", \\\"{x:1379,y:738,t:1528139844364};\\\", \\\"{x:1376,y:735,t:1528139844381};\\\", \\\"{x:1373,y:734,t:1528139844397};\\\", \\\"{x:1368,y:731,t:1528139844414};\\\", \\\"{x:1366,y:730,t:1528139844430};\\\", \\\"{x:1364,y:728,t:1528139844447};\\\", \\\"{x:1361,y:726,t:1528139844465};\\\", \\\"{x:1359,y:724,t:1528139844480};\\\", \\\"{x:1357,y:722,t:1528139844498};\\\", \\\"{x:1357,y:721,t:1528139844515};\\\", \\\"{x:1356,y:721,t:1528139844545};\\\", \\\"{x:1355,y:721,t:1528139844553};\\\", \\\"{x:1356,y:722,t:1528139844601};\\\", \\\"{x:1360,y:725,t:1528139844614};\\\", \\\"{x:1370,y:733,t:1528139844631};\\\", \\\"{x:1385,y:751,t:1528139844647};\\\", \\\"{x:1405,y:785,t:1528139844664};\\\", \\\"{x:1425,y:820,t:1528139844682};\\\", \\\"{x:1449,y:861,t:1528139844697};\\\", \\\"{x:1463,y:883,t:1528139844715};\\\", \\\"{x:1472,y:905,t:1528139844732};\\\", \\\"{x:1481,y:923,t:1528139844748};\\\", \\\"{x:1485,y:939,t:1528139844765};\\\", \\\"{x:1486,y:954,t:1528139844782};\\\", \\\"{x:1488,y:967,t:1528139844798};\\\", \\\"{x:1488,y:976,t:1528139844815};\\\", \\\"{x:1488,y:982,t:1528139844831};\\\", \\\"{x:1491,y:993,t:1528139844848};\\\", \\\"{x:1492,y:1002,t:1528139844864};\\\", \\\"{x:1492,y:1003,t:1528139844881};\\\", \\\"{x:1492,y:1002,t:1528139845024};\\\", \\\"{x:1492,y:1000,t:1528139845040};\\\", \\\"{x:1492,y:998,t:1528139845048};\\\", \\\"{x:1491,y:995,t:1528139845064};\\\", \\\"{x:1490,y:991,t:1528139845081};\\\", \\\"{x:1489,y:988,t:1528139845098};\\\", \\\"{x:1489,y:987,t:1528139845115};\\\", \\\"{x:1489,y:985,t:1528139845132};\\\", \\\"{x:1488,y:985,t:1528139845149};\\\", \\\"{x:1487,y:984,t:1528139845176};\\\", \\\"{x:1487,y:983,t:1528139845192};\\\", \\\"{x:1487,y:982,t:1528139845208};\\\", \\\"{x:1486,y:981,t:1528139845240};\\\", \\\"{x:1486,y:980,t:1528139845248};\\\", \\\"{x:1485,y:979,t:1528139845280};\\\", \\\"{x:1484,y:978,t:1528139845304};\\\", \\\"{x:1484,y:977,t:1528139845320};\\\", \\\"{x:1483,y:976,t:1528139845331};\\\", \\\"{x:1482,y:975,t:1528139845361};\\\", \\\"{x:1482,y:973,t:1528139845376};\\\", \\\"{x:1481,y:973,t:1528139845385};\\\", \\\"{x:1481,y:972,t:1528139845409};\\\", \\\"{x:1481,y:971,t:1528139845464};\\\", \\\"{x:1481,y:970,t:1528139845479};\\\", \\\"{x:1480,y:970,t:1528139845503};\\\", \\\"{x:1478,y:969,t:1528139850145};\\\", \\\"{x:1473,y:969,t:1528139850153};\\\", \\\"{x:1461,y:963,t:1528139850169};\\\", \\\"{x:1456,y:961,t:1528139850186};\\\", \\\"{x:1455,y:961,t:1528139850208};\\\", \\\"{x:1454,y:961,t:1528139850305};\\\", \\\"{x:1453,y:960,t:1528139850441};\\\", \\\"{x:1451,y:957,t:1528139850453};\\\", \\\"{x:1424,y:945,t:1528139850470};\\\", \\\"{x:1358,y:916,t:1528139850486};\\\", \\\"{x:1259,y:878,t:1528139850503};\\\", \\\"{x:1095,y:825,t:1528139850520};\\\", \\\"{x:991,y:786,t:1528139850536};\\\", \\\"{x:917,y:754,t:1528139850553};\\\", \\\"{x:857,y:721,t:1528139850570};\\\", \\\"{x:817,y:692,t:1528139850586};\\\", \\\"{x:772,y:660,t:1528139850603};\\\", \\\"{x:749,y:643,t:1528139850619};\\\", \\\"{x:733,y:631,t:1528139850638};\\\", \\\"{x:716,y:619,t:1528139850653};\\\", \\\"{x:709,y:612,t:1528139850668};\\\", \\\"{x:706,y:608,t:1528139850685};\\\", \\\"{x:701,y:601,t:1528139850702};\\\", \\\"{x:694,y:586,t:1528139850720};\\\", \\\"{x:692,y:582,t:1528139850735};\\\", \\\"{x:692,y:578,t:1528139851057};\\\", \\\"{x:692,y:574,t:1528139851069};\\\", \\\"{x:692,y:564,t:1528139851085};\\\", \\\"{x:690,y:553,t:1528139851104};\\\", \\\"{x:684,y:542,t:1528139851119};\\\", \\\"{x:675,y:533,t:1528139851135};\\\", \\\"{x:670,y:530,t:1528139851152};\\\", \\\"{x:669,y:529,t:1528139851175};\\\", \\\"{x:667,y:529,t:1528139851247};\\\", \\\"{x:664,y:528,t:1528139851256};\\\", \\\"{x:663,y:528,t:1528139851269};\\\", \\\"{x:658,y:528,t:1528139851286};\\\", \\\"{x:650,y:528,t:1528139851302};\\\", \\\"{x:627,y:527,t:1528139851319};\\\", \\\"{x:614,y:523,t:1528139851336};\\\", \\\"{x:606,y:520,t:1528139851352};\\\", \\\"{x:595,y:516,t:1528139851370};\\\", \\\"{x:590,y:513,t:1528139851386};\\\", \\\"{x:586,y:511,t:1528139851402};\\\", \\\"{x:584,y:509,t:1528139851419};\\\", \\\"{x:582,y:507,t:1528139851436};\\\", \\\"{x:581,y:504,t:1528139851452};\\\", \\\"{x:579,y:503,t:1528139851469};\\\", \\\"{x:579,y:501,t:1528139851486};\\\", \\\"{x:578,y:501,t:1528139851502};\\\", \\\"{x:578,y:500,t:1528139851527};\\\", \\\"{x:579,y:500,t:1528139851536};\\\", \\\"{x:582,y:498,t:1528139851553};\\\", \\\"{x:588,y:497,t:1528139851569};\\\", \\\"{x:595,y:497,t:1528139851587};\\\", \\\"{x:600,y:497,t:1528139851604};\\\", \\\"{x:601,y:497,t:1528139851620};\\\", \\\"{x:602,y:497,t:1528139851647};\\\", \\\"{x:603,y:497,t:1528139851664};\\\", \\\"{x:603,y:498,t:1528139851823};\\\", \\\"{x:603,y:506,t:1528139851836};\\\", \\\"{x:603,y:511,t:1528139851839};\\\", \\\"{x:603,y:521,t:1528139851854};\\\", \\\"{x:601,y:539,t:1528139851869};\\\", \\\"{x:600,y:558,t:1528139851887};\\\", \\\"{x:599,y:592,t:1528139851903};\\\", \\\"{x:599,y:615,t:1528139851920};\\\", \\\"{x:592,y:657,t:1528139851937};\\\", \\\"{x:579,y:714,t:1528139851953};\\\", \\\"{x:566,y:769,t:1528139851969};\\\", \\\"{x:556,y:804,t:1528139851986};\\\", \\\"{x:552,y:815,t:1528139852003};\\\", \\\"{x:552,y:817,t:1528139852020};\\\", \\\"{x:550,y:820,t:1528139852036};\\\", \\\"{x:547,y:822,t:1528139852053};\\\", \\\"{x:542,y:825,t:1528139852070};\\\", \\\"{x:540,y:827,t:1528139852086};\\\", \\\"{x:539,y:828,t:1528139852103};\\\", \\\"{x:537,y:828,t:1528139852143};\\\", \\\"{x:535,y:828,t:1528139852153};\\\", \\\"{x:528,y:822,t:1528139852171};\\\", \\\"{x:521,y:813,t:1528139852187};\\\", \\\"{x:517,y:805,t:1528139852204};\\\", \\\"{x:512,y:793,t:1528139852220};\\\", \\\"{x:509,y:784,t:1528139852237};\\\", \\\"{x:507,y:775,t:1528139852254};\\\", \\\"{x:505,y:767,t:1528139852271};\\\", \\\"{x:505,y:759,t:1528139852288};\\\", \\\"{x:505,y:754,t:1528139852304};\\\", \\\"{x:505,y:751,t:1528139852320};\\\", \\\"{x:505,y:749,t:1528139852337};\\\", \\\"{x:505,y:748,t:1528139852353};\\\", \\\"{x:505,y:747,t:1528139852370};\\\" ] }, { \\\"rt\\\": 7300, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 544441, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-12 PM-M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:745,t:1528139855073};\\\", \\\"{x:513,y:739,t:1528139855085};\\\", \\\"{x:633,y:708,t:1528139855111};\\\", \\\"{x:666,y:706,t:1528139855118};\\\", \\\"{x:803,y:709,t:1528139855139};\\\", \\\"{x:921,y:736,t:1528139855155};\\\", \\\"{x:1045,y:768,t:1528139855172};\\\", \\\"{x:1167,y:803,t:1528139855189};\\\", \\\"{x:1283,y:837,t:1528139855206};\\\", \\\"{x:1375,y:864,t:1528139855223};\\\", \\\"{x:1459,y:890,t:1528139855239};\\\", \\\"{x:1485,y:902,t:1528139855256};\\\", \\\"{x:1497,y:907,t:1528139855273};\\\", \\\"{x:1499,y:908,t:1528139855290};\\\", \\\"{x:1500,y:908,t:1528139855306};\\\", \\\"{x:1501,y:910,t:1528139855351};\\\", \\\"{x:1500,y:913,t:1528139855359};\\\", \\\"{x:1500,y:917,t:1528139855373};\\\", \\\"{x:1494,y:928,t:1528139855389};\\\", \\\"{x:1485,y:937,t:1528139855407};\\\", \\\"{x:1475,y:945,t:1528139855422};\\\", \\\"{x:1461,y:953,t:1528139855439};\\\", \\\"{x:1452,y:958,t:1528139855455};\\\", \\\"{x:1442,y:963,t:1528139855473};\\\", \\\"{x:1437,y:966,t:1528139855489};\\\", \\\"{x:1433,y:968,t:1528139855506};\\\", \\\"{x:1430,y:970,t:1528139855523};\\\", \\\"{x:1426,y:972,t:1528139855539};\\\", \\\"{x:1424,y:974,t:1528139855560};\\\", \\\"{x:1423,y:974,t:1528139855573};\\\", \\\"{x:1421,y:975,t:1528139855590};\\\", \\\"{x:1419,y:975,t:1528139855606};\\\", \\\"{x:1418,y:977,t:1528139855623};\\\", \\\"{x:1417,y:977,t:1528139855640};\\\", \\\"{x:1415,y:978,t:1528139855657};\\\", \\\"{x:1413,y:980,t:1528139855674};\\\", \\\"{x:1409,y:981,t:1528139855690};\\\", \\\"{x:1406,y:983,t:1528139855707};\\\", \\\"{x:1404,y:983,t:1528139855724};\\\", \\\"{x:1403,y:984,t:1528139855740};\\\", \\\"{x:1400,y:985,t:1528139855757};\\\", \\\"{x:1398,y:985,t:1528139855774};\\\", \\\"{x:1394,y:985,t:1528139855790};\\\", \\\"{x:1389,y:985,t:1528139855807};\\\", \\\"{x:1378,y:985,t:1528139855824};\\\", \\\"{x:1369,y:982,t:1528139855840};\\\", \\\"{x:1366,y:981,t:1528139855858};\\\", \\\"{x:1364,y:979,t:1528139855874};\\\", \\\"{x:1360,y:979,t:1528139855890};\\\", \\\"{x:1357,y:978,t:1528139855907};\\\", \\\"{x:1353,y:978,t:1528139855924};\\\", \\\"{x:1351,y:978,t:1528139855940};\\\", \\\"{x:1350,y:978,t:1528139855957};\\\", \\\"{x:1348,y:978,t:1528139855974};\\\", \\\"{x:1346,y:978,t:1528139855992};\\\", \\\"{x:1345,y:978,t:1528139856008};\\\", \\\"{x:1343,y:978,t:1528139856024};\\\", \\\"{x:1342,y:978,t:1528139856041};\\\", \\\"{x:1341,y:978,t:1528139856057};\\\", \\\"{x:1340,y:978,t:1528139856113};\\\", \\\"{x:1339,y:976,t:1528139856284};\\\", \\\"{x:1340,y:972,t:1528139856295};\\\", \\\"{x:1346,y:963,t:1528139856312};\\\", \\\"{x:1354,y:955,t:1528139856328};\\\", \\\"{x:1359,y:948,t:1528139856345};\\\", \\\"{x:1363,y:944,t:1528139856362};\\\", \\\"{x:1364,y:942,t:1528139856378};\\\", \\\"{x:1365,y:941,t:1528139856395};\\\", \\\"{x:1366,y:939,t:1528139856412};\\\", \\\"{x:1366,y:938,t:1528139856428};\\\", \\\"{x:1368,y:936,t:1528139856445};\\\", \\\"{x:1368,y:935,t:1528139856476};\\\", \\\"{x:1369,y:934,t:1528139856492};\\\", \\\"{x:1369,y:933,t:1528139856509};\\\", \\\"{x:1370,y:931,t:1528139856516};\\\", \\\"{x:1370,y:930,t:1528139856528};\\\", \\\"{x:1372,y:927,t:1528139856545};\\\", \\\"{x:1372,y:923,t:1528139856562};\\\", \\\"{x:1375,y:918,t:1528139856578};\\\", \\\"{x:1376,y:913,t:1528139856595};\\\", \\\"{x:1377,y:905,t:1528139856612};\\\", \\\"{x:1379,y:900,t:1528139856630};\\\", \\\"{x:1381,y:896,t:1528139856644};\\\", \\\"{x:1383,y:888,t:1528139856662};\\\", \\\"{x:1386,y:883,t:1528139856679};\\\", \\\"{x:1389,y:876,t:1528139856694};\\\", \\\"{x:1394,y:867,t:1528139856712};\\\", \\\"{x:1400,y:856,t:1528139856728};\\\", \\\"{x:1406,y:841,t:1528139856745};\\\", \\\"{x:1412,y:826,t:1528139856762};\\\", \\\"{x:1420,y:803,t:1528139856779};\\\", \\\"{x:1432,y:764,t:1528139856795};\\\", \\\"{x:1490,y:641,t:1528139856812};\\\", \\\"{x:1532,y:567,t:1528139856829};\\\", \\\"{x:1570,y:499,t:1528139856844};\\\", \\\"{x:1585,y:467,t:1528139856862};\\\", \\\"{x:1593,y:446,t:1528139856879};\\\", \\\"{x:1598,y:434,t:1528139856895};\\\", \\\"{x:1600,y:432,t:1528139856911};\\\", \\\"{x:1601,y:430,t:1528139856928};\\\", \\\"{x:1597,y:433,t:1528139857181};\\\", \\\"{x:1569,y:450,t:1528139857195};\\\", \\\"{x:1515,y:482,t:1528139857213};\\\", \\\"{x:1435,y:516,t:1528139857229};\\\", \\\"{x:1329,y:551,t:1528139857246};\\\", \\\"{x:1207,y:572,t:1528139857263};\\\", \\\"{x:1058,y:589,t:1528139857278};\\\", \\\"{x:927,y:589,t:1528139857297};\\\", \\\"{x:786,y:589,t:1528139857312};\\\", \\\"{x:662,y:589,t:1528139857329};\\\", \\\"{x:554,y:589,t:1528139857345};\\\", \\\"{x:473,y:591,t:1528139857361};\\\", \\\"{x:420,y:597,t:1528139857379};\\\", \\\"{x:385,y:604,t:1528139857394};\\\", \\\"{x:357,y:617,t:1528139857411};\\\", \\\"{x:348,y:622,t:1528139857428};\\\", \\\"{x:343,y:630,t:1528139857444};\\\", \\\"{x:339,y:638,t:1528139857462};\\\", \\\"{x:336,y:645,t:1528139857479};\\\", \\\"{x:335,y:650,t:1528139857494};\\\", \\\"{x:335,y:654,t:1528139857511};\\\", \\\"{x:335,y:660,t:1528139857528};\\\", \\\"{x:336,y:664,t:1528139857546};\\\", \\\"{x:337,y:667,t:1528139857562};\\\", \\\"{x:338,y:669,t:1528139857578};\\\", \\\"{x:340,y:673,t:1528139857596};\\\", \\\"{x:347,y:677,t:1528139857611};\\\", \\\"{x:356,y:680,t:1528139857629};\\\", \\\"{x:373,y:680,t:1528139857644};\\\", \\\"{x:399,y:673,t:1528139857661};\\\", \\\"{x:439,y:651,t:1528139857679};\\\", \\\"{x:478,y:627,t:1528139857696};\\\", \\\"{x:507,y:606,t:1528139857712};\\\", \\\"{x:524,y:589,t:1528139857729};\\\", \\\"{x:531,y:578,t:1528139857744};\\\", \\\"{x:533,y:572,t:1528139857762};\\\", \\\"{x:534,y:567,t:1528139857778};\\\", \\\"{x:535,y:565,t:1528139857796};\\\", \\\"{x:535,y:564,t:1528139857811};\\\", \\\"{x:535,y:562,t:1528139857829};\\\", \\\"{x:536,y:565,t:1528139857932};\\\", \\\"{x:537,y:569,t:1528139857945};\\\", \\\"{x:540,y:579,t:1528139857961};\\\", \\\"{x:543,y:591,t:1528139857978};\\\", \\\"{x:543,y:603,t:1528139857995};\\\", \\\"{x:539,y:609,t:1528139858011};\\\", \\\"{x:525,y:614,t:1528139858028};\\\", \\\"{x:509,y:616,t:1528139858045};\\\", \\\"{x:486,y:616,t:1528139858062};\\\", \\\"{x:468,y:616,t:1528139858078};\\\", \\\"{x:461,y:613,t:1528139858095};\\\", \\\"{x:457,y:611,t:1528139858111};\\\", \\\"{x:455,y:610,t:1528139858129};\\\", \\\"{x:453,y:608,t:1528139858146};\\\", \\\"{x:447,y:604,t:1528139858162};\\\", \\\"{x:444,y:603,t:1528139858179};\\\", \\\"{x:434,y:597,t:1528139858197};\\\", \\\"{x:427,y:594,t:1528139858212};\\\", \\\"{x:419,y:590,t:1528139858229};\\\", \\\"{x:413,y:586,t:1528139858246};\\\", \\\"{x:406,y:583,t:1528139858262};\\\", \\\"{x:403,y:581,t:1528139858278};\\\", \\\"{x:398,y:578,t:1528139858295};\\\", \\\"{x:394,y:577,t:1528139858312};\\\", \\\"{x:390,y:575,t:1528139858328};\\\", \\\"{x:385,y:571,t:1528139858346};\\\", \\\"{x:382,y:570,t:1528139858362};\\\", \\\"{x:380,y:568,t:1528139858379};\\\", \\\"{x:380,y:567,t:1528139858396};\\\", \\\"{x:379,y:565,t:1528139858414};\\\", \\\"{x:379,y:563,t:1528139858428};\\\", \\\"{x:379,y:562,t:1528139858446};\\\", \\\"{x:379,y:559,t:1528139858462};\\\", \\\"{x:379,y:556,t:1528139858479};\\\", \\\"{x:380,y:555,t:1528139858499};\\\", \\\"{x:380,y:553,t:1528139858513};\\\", \\\"{x:381,y:553,t:1528139858528};\\\", \\\"{x:381,y:552,t:1528139858545};\\\", \\\"{x:381,y:553,t:1528139858756};\\\", \\\"{x:381,y:560,t:1528139858765};\\\", \\\"{x:384,y:581,t:1528139858779};\\\", \\\"{x:387,y:598,t:1528139858796};\\\", \\\"{x:387,y:616,t:1528139858813};\\\", \\\"{x:390,y:626,t:1528139858829};\\\", \\\"{x:390,y:632,t:1528139858846};\\\", \\\"{x:390,y:634,t:1528139858862};\\\", \\\"{x:390,y:635,t:1528139858879};\\\", \\\"{x:390,y:633,t:1528139859068};\\\", \\\"{x:390,y:631,t:1528139859081};\\\", \\\"{x:388,y:623,t:1528139859097};\\\", \\\"{x:388,y:621,t:1528139859112};\\\", \\\"{x:388,y:620,t:1528139859130};\\\", \\\"{x:388,y:618,t:1528139859146};\\\", \\\"{x:387,y:615,t:1528139859163};\\\", \\\"{x:387,y:611,t:1528139859179};\\\", \\\"{x:387,y:610,t:1528139859196};\\\", \\\"{x:385,y:603,t:1528139859419};\\\", \\\"{x:382,y:594,t:1528139859430};\\\", \\\"{x:375,y:567,t:1528139859447};\\\", \\\"{x:372,y:547,t:1528139859463};\\\", \\\"{x:368,y:536,t:1528139859479};\\\", \\\"{x:366,y:526,t:1528139859497};\\\", \\\"{x:365,y:523,t:1528139859514};\\\", \\\"{x:365,y:519,t:1528139859529};\\\", \\\"{x:365,y:518,t:1528139859547};\\\", \\\"{x:364,y:517,t:1528139859564};\\\", \\\"{x:365,y:517,t:1528139859701};\\\", \\\"{x:365,y:520,t:1528139859715};\\\", \\\"{x:367,y:526,t:1528139859730};\\\", \\\"{x:370,y:532,t:1528139859746};\\\", \\\"{x:373,y:539,t:1528139859763};\\\", \\\"{x:373,y:540,t:1528139859779};\\\", \\\"{x:374,y:541,t:1528139859797};\\\", \\\"{x:374,y:543,t:1528139859995};\\\", \\\"{x:375,y:551,t:1528139860003};\\\", \\\"{x:378,y:560,t:1528139860014};\\\", \\\"{x:382,y:589,t:1528139860031};\\\", \\\"{x:388,y:615,t:1528139860047};\\\", \\\"{x:397,y:643,t:1528139860064};\\\", \\\"{x:410,y:670,t:1528139860081};\\\", \\\"{x:424,y:694,t:1528139860096};\\\", \\\"{x:437,y:713,t:1528139860113};\\\", \\\"{x:449,y:731,t:1528139860131};\\\", \\\"{x:459,y:741,t:1528139860146};\\\", \\\"{x:468,y:751,t:1528139860163};\\\", \\\"{x:473,y:755,t:1528139860180};\\\", \\\"{x:474,y:756,t:1528139860196};\\\", \\\"{x:475,y:756,t:1528139860213};\\\", \\\"{x:476,y:756,t:1528139860231};\\\", \\\"{x:478,y:756,t:1528139860247};\\\", \\\"{x:486,y:752,t:1528139860264};\\\", \\\"{x:492,y:745,t:1528139860280};\\\", \\\"{x:495,y:740,t:1528139860297};\\\", \\\"{x:498,y:735,t:1528139860314};\\\", \\\"{x:500,y:733,t:1528139860330};\\\", \\\"{x:503,y:725,t:1528139860347};\\\", \\\"{x:503,y:722,t:1528139860363};\\\", \\\"{x:505,y:719,t:1528139860381};\\\", \\\"{x:505,y:718,t:1528139860467};\\\", \\\"{x:505,y:718,t:1528139860556};\\\", \\\"{x:505,y:719,t:1528139860868};\\\", \\\"{x:505,y:721,t:1528139860882};\\\", \\\"{x:504,y:725,t:1528139860897};\\\", \\\"{x:504,y:729,t:1528139860915};\\\", \\\"{x:502,y:733,t:1528139860931};\\\" ] }, { \\\"rt\\\": 6159, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 551910, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:734,t:1528139863501};\\\", \\\"{x:527,y:735,t:1528139863508};\\\", \\\"{x:560,y:746,t:1528139863518};\\\", \\\"{x:660,y:771,t:1528139863537};\\\", \\\"{x:793,y:793,t:1528139863552};\\\", \\\"{x:952,y:823,t:1528139863567};\\\", \\\"{x:1105,y:859,t:1528139863583};\\\", \\\"{x:1236,y:882,t:1528139863600};\\\", \\\"{x:1333,y:894,t:1528139863617};\\\", \\\"{x:1373,y:901,t:1528139863634};\\\", \\\"{x:1391,y:904,t:1528139863650};\\\", \\\"{x:1395,y:905,t:1528139863667};\\\", \\\"{x:1396,y:905,t:1528139863772};\\\", \\\"{x:1397,y:908,t:1528139863783};\\\", \\\"{x:1398,y:911,t:1528139863800};\\\", \\\"{x:1400,y:914,t:1528139863817};\\\", \\\"{x:1400,y:917,t:1528139863834};\\\", \\\"{x:1400,y:919,t:1528139863850};\\\", \\\"{x:1400,y:923,t:1528139863868};\\\", \\\"{x:1399,y:928,t:1528139863883};\\\", \\\"{x:1394,y:937,t:1528139863900};\\\", \\\"{x:1390,y:943,t:1528139863917};\\\", \\\"{x:1387,y:946,t:1528139863933};\\\", \\\"{x:1384,y:949,t:1528139863950};\\\", \\\"{x:1382,y:951,t:1528139863968};\\\", \\\"{x:1380,y:953,t:1528139863983};\\\", \\\"{x:1377,y:956,t:1528139864000};\\\", \\\"{x:1375,y:959,t:1528139864017};\\\", \\\"{x:1373,y:960,t:1528139864033};\\\", \\\"{x:1372,y:962,t:1528139864050};\\\", \\\"{x:1371,y:963,t:1528139864067};\\\", \\\"{x:1370,y:965,t:1528139864084};\\\", \\\"{x:1369,y:966,t:1528139864100};\\\", \\\"{x:1368,y:967,t:1528139864132};\\\", \\\"{x:1367,y:963,t:1528139864364};\\\", \\\"{x:1364,y:953,t:1528139864372};\\\", \\\"{x:1363,y:944,t:1528139864384};\\\", \\\"{x:1358,y:918,t:1528139864400};\\\", \\\"{x:1356,y:887,t:1528139864417};\\\", \\\"{x:1355,y:859,t:1528139864434};\\\", \\\"{x:1355,y:832,t:1528139864450};\\\", \\\"{x:1355,y:810,t:1528139864467};\\\", \\\"{x:1355,y:783,t:1528139864484};\\\", \\\"{x:1359,y:768,t:1528139864501};\\\", \\\"{x:1360,y:757,t:1528139864517};\\\", \\\"{x:1360,y:751,t:1528139864534};\\\", \\\"{x:1361,y:745,t:1528139864551};\\\", \\\"{x:1361,y:744,t:1528139864716};\\\", \\\"{x:1360,y:737,t:1528139864735};\\\", \\\"{x:1358,y:732,t:1528139864752};\\\", \\\"{x:1356,y:727,t:1528139864767};\\\", \\\"{x:1354,y:723,t:1528139864784};\\\", \\\"{x:1354,y:720,t:1528139864801};\\\", \\\"{x:1354,y:718,t:1528139864817};\\\", \\\"{x:1354,y:715,t:1528139864834};\\\", \\\"{x:1354,y:714,t:1528139864852};\\\", \\\"{x:1354,y:712,t:1528139864884};\\\", \\\"{x:1354,y:711,t:1528139864916};\\\", \\\"{x:1354,y:709,t:1528139864934};\\\", \\\"{x:1354,y:708,t:1528139864951};\\\", \\\"{x:1354,y:704,t:1528139864968};\\\", \\\"{x:1354,y:699,t:1528139864984};\\\", \\\"{x:1354,y:690,t:1528139865001};\\\", \\\"{x:1354,y:678,t:1528139865017};\\\", \\\"{x:1357,y:660,t:1528139865035};\\\", \\\"{x:1367,y:640,t:1528139865051};\\\", \\\"{x:1389,y:609,t:1528139865068};\\\", \\\"{x:1407,y:590,t:1528139865084};\\\", \\\"{x:1422,y:580,t:1528139865101};\\\", \\\"{x:1437,y:573,t:1528139865118};\\\", \\\"{x:1443,y:569,t:1528139865134};\\\", \\\"{x:1449,y:568,t:1528139865151};\\\", \\\"{x:1451,y:567,t:1528139865168};\\\", \\\"{x:1443,y:567,t:1528139865356};\\\", \\\"{x:1418,y:568,t:1528139865368};\\\", \\\"{x:1335,y:579,t:1528139865385};\\\", \\\"{x:1211,y:590,t:1528139865401};\\\", \\\"{x:1073,y:590,t:1528139865418};\\\", \\\"{x:926,y:590,t:1528139865436};\\\", \\\"{x:757,y:590,t:1528139865451};\\\", \\\"{x:698,y:593,t:1528139865468};\\\", \\\"{x:669,y:593,t:1528139865485};\\\", \\\"{x:650,y:593,t:1528139865500};\\\", \\\"{x:628,y:593,t:1528139865517};\\\", \\\"{x:603,y:593,t:1528139865535};\\\", \\\"{x:570,y:593,t:1528139865551};\\\", \\\"{x:531,y:593,t:1528139865567};\\\", \\\"{x:500,y:593,t:1528139865585};\\\", \\\"{x:473,y:593,t:1528139865601};\\\", \\\"{x:458,y:593,t:1528139865617};\\\", \\\"{x:455,y:593,t:1528139865635};\\\", \\\"{x:454,y:593,t:1528139865683};\\\", \\\"{x:454,y:590,t:1528139865700};\\\", \\\"{x:454,y:587,t:1528139865707};\\\", \\\"{x:454,y:582,t:1528139865718};\\\", \\\"{x:454,y:576,t:1528139865736};\\\", \\\"{x:454,y:571,t:1528139865752};\\\", \\\"{x:454,y:568,t:1528139865768};\\\", \\\"{x:454,y:566,t:1528139865785};\\\", \\\"{x:452,y:560,t:1528139865802};\\\", \\\"{x:444,y:556,t:1528139865818};\\\", \\\"{x:410,y:550,t:1528139865835};\\\", \\\"{x:383,y:548,t:1528139865852};\\\", \\\"{x:361,y:548,t:1528139865867};\\\", \\\"{x:341,y:548,t:1528139865885};\\\", \\\"{x:332,y:548,t:1528139865902};\\\", \\\"{x:331,y:548,t:1528139865918};\\\", \\\"{x:329,y:548,t:1528139865935};\\\", \\\"{x:328,y:548,t:1528139865952};\\\", \\\"{x:327,y:548,t:1528139865968};\\\", \\\"{x:326,y:548,t:1528139866028};\\\", \\\"{x:324,y:549,t:1528139866051};\\\", \\\"{x:321,y:552,t:1528139866069};\\\", \\\"{x:316,y:556,t:1528139866087};\\\", \\\"{x:310,y:562,t:1528139866102};\\\", \\\"{x:301,y:566,t:1528139866119};\\\", \\\"{x:289,y:571,t:1528139866135};\\\", \\\"{x:277,y:572,t:1528139866152};\\\", \\\"{x:261,y:575,t:1528139866170};\\\", \\\"{x:245,y:577,t:1528139866185};\\\", \\\"{x:224,y:577,t:1528139866202};\\\", \\\"{x:206,y:577,t:1528139866218};\\\", \\\"{x:198,y:577,t:1528139866235};\\\", \\\"{x:195,y:577,t:1528139866252};\\\", \\\"{x:193,y:577,t:1528139866364};\\\", \\\"{x:192,y:576,t:1528139866371};\\\", \\\"{x:191,y:576,t:1528139866385};\\\", \\\"{x:191,y:574,t:1528139866402};\\\", \\\"{x:190,y:573,t:1528139866418};\\\", \\\"{x:188,y:573,t:1528139866475};\\\", \\\"{x:187,y:574,t:1528139866486};\\\", \\\"{x:183,y:582,t:1528139866502};\\\", \\\"{x:180,y:593,t:1528139866520};\\\", \\\"{x:178,y:605,t:1528139866538};\\\", \\\"{x:178,y:617,t:1528139866552};\\\", \\\"{x:185,y:631,t:1528139866569};\\\", \\\"{x:198,y:646,t:1528139866586};\\\", \\\"{x:214,y:659,t:1528139866601};\\\", \\\"{x:260,y:674,t:1528139866619};\\\", \\\"{x:302,y:678,t:1528139866635};\\\", \\\"{x:336,y:683,t:1528139866651};\\\", \\\"{x:363,y:683,t:1528139866668};\\\", \\\"{x:378,y:683,t:1528139866685};\\\", \\\"{x:386,y:678,t:1528139866702};\\\", \\\"{x:392,y:672,t:1528139866718};\\\", \\\"{x:400,y:663,t:1528139866737};\\\", \\\"{x:413,y:648,t:1528139866752};\\\", \\\"{x:431,y:632,t:1528139866769};\\\", \\\"{x:451,y:618,t:1528139866787};\\\", \\\"{x:482,y:601,t:1528139866802};\\\", \\\"{x:505,y:591,t:1528139866819};\\\", \\\"{x:532,y:581,t:1528139866836};\\\", \\\"{x:552,y:577,t:1528139866852};\\\", \\\"{x:569,y:573,t:1528139866869};\\\", \\\"{x:579,y:571,t:1528139866886};\\\", \\\"{x:588,y:570,t:1528139866902};\\\", \\\"{x:596,y:569,t:1528139866918};\\\", \\\"{x:604,y:568,t:1528139866937};\\\", \\\"{x:610,y:568,t:1528139866952};\\\", \\\"{x:618,y:568,t:1528139866969};\\\", \\\"{x:625,y:568,t:1528139866986};\\\", \\\"{x:633,y:568,t:1528139867003};\\\", \\\"{x:642,y:570,t:1528139867019};\\\", \\\"{x:661,y:572,t:1528139867037};\\\", \\\"{x:683,y:572,t:1528139867052};\\\", \\\"{x:709,y:572,t:1528139867069};\\\", \\\"{x:739,y:572,t:1528139867086};\\\", \\\"{x:772,y:572,t:1528139867102};\\\", \\\"{x:804,y:572,t:1528139867119};\\\", \\\"{x:831,y:572,t:1528139867136};\\\", \\\"{x:852,y:570,t:1528139867152};\\\", \\\"{x:868,y:568,t:1528139867168};\\\", \\\"{x:876,y:567,t:1528139867186};\\\", \\\"{x:879,y:565,t:1528139867202};\\\", \\\"{x:881,y:564,t:1528139867219};\\\", \\\"{x:882,y:562,t:1528139867236};\\\", \\\"{x:883,y:559,t:1528139867253};\\\", \\\"{x:883,y:555,t:1528139867269};\\\", \\\"{x:883,y:552,t:1528139867286};\\\", \\\"{x:883,y:546,t:1528139867302};\\\", \\\"{x:876,y:539,t:1528139867320};\\\", \\\"{x:870,y:534,t:1528139867336};\\\", \\\"{x:865,y:530,t:1528139867354};\\\", \\\"{x:860,y:527,t:1528139867370};\\\", \\\"{x:854,y:526,t:1528139867386};\\\", \\\"{x:848,y:523,t:1528139867403};\\\", \\\"{x:846,y:523,t:1528139867419};\\\", \\\"{x:845,y:523,t:1528139867468};\\\", \\\"{x:844,y:525,t:1528139867527};\\\", \\\"{x:844,y:526,t:1528139867535};\\\", \\\"{x:844,y:528,t:1528139867553};\\\", \\\"{x:844,y:529,t:1528139867570};\\\", \\\"{x:844,y:530,t:1528139867587};\\\", \\\"{x:844,y:531,t:1528139867620};\\\", \\\"{x:844,y:533,t:1528139867636};\\\", \\\"{x:843,y:534,t:1528139867653};\\\", \\\"{x:843,y:535,t:1528139867922};\\\", \\\"{x:841,y:539,t:1528139867979};\\\", \\\"{x:837,y:544,t:1528139867987};\\\", \\\"{x:833,y:550,t:1528139868003};\\\", \\\"{x:821,y:563,t:1528139868020};\\\", \\\"{x:805,y:579,t:1528139868037};\\\", \\\"{x:783,y:596,t:1528139868053};\\\", \\\"{x:757,y:614,t:1528139868070};\\\", \\\"{x:725,y:637,t:1528139868087};\\\", \\\"{x:702,y:656,t:1528139868104};\\\", \\\"{x:674,y:680,t:1528139868119};\\\", \\\"{x:649,y:698,t:1528139868137};\\\", \\\"{x:618,y:720,t:1528139868153};\\\", \\\"{x:585,y:740,t:1528139868170};\\\", \\\"{x:549,y:755,t:1528139868187};\\\", \\\"{x:540,y:758,t:1528139868203};\\\", \\\"{x:536,y:758,t:1528139868220};\\\", \\\"{x:533,y:758,t:1528139868237};\\\", \\\"{x:531,y:758,t:1528139868253};\\\", \\\"{x:529,y:758,t:1528139868270};\\\", \\\"{x:526,y:757,t:1528139868288};\\\", \\\"{x:522,y:753,t:1528139868305};\\\", \\\"{x:517,y:747,t:1528139868320};\\\", \\\"{x:512,y:742,t:1528139868337};\\\", \\\"{x:508,y:736,t:1528139868353};\\\", \\\"{x:505,y:732,t:1528139868370};\\\", \\\"{x:502,y:727,t:1528139868386};\\\", \\\"{x:501,y:726,t:1528139868404};\\\", \\\"{x:501,y:725,t:1528139868419};\\\" ] }, { \\\"rt\\\": 11957, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 565136, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 3, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-01 PM-Z -Z -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:721,t:1528139872411};\\\", \\\"{x:507,y:711,t:1528139872424};\\\", \\\"{x:612,y:691,t:1528139872439};\\\", \\\"{x:839,y:667,t:1528139872461};\\\", \\\"{x:928,y:667,t:1528139872473};\\\", \\\"{x:1094,y:661,t:1528139872490};\\\", \\\"{x:1287,y:653,t:1528139872507};\\\", \\\"{x:1376,y:653,t:1528139872523};\\\", \\\"{x:1434,y:653,t:1528139872540};\\\", \\\"{x:1463,y:653,t:1528139872557};\\\", \\\"{x:1480,y:653,t:1528139872573};\\\", \\\"{x:1490,y:653,t:1528139872590};\\\", \\\"{x:1501,y:653,t:1528139872607};\\\", \\\"{x:1517,y:653,t:1528139872623};\\\", \\\"{x:1543,y:658,t:1528139872640};\\\", \\\"{x:1573,y:663,t:1528139872657};\\\", \\\"{x:1608,y:667,t:1528139872673};\\\", \\\"{x:1640,y:673,t:1528139872691};\\\", \\\"{x:1675,y:682,t:1528139872707};\\\", \\\"{x:1691,y:686,t:1528139872725};\\\", \\\"{x:1701,y:692,t:1528139872741};\\\", \\\"{x:1714,y:699,t:1528139872758};\\\", \\\"{x:1722,y:710,t:1528139872774};\\\", \\\"{x:1728,y:722,t:1528139872790};\\\", \\\"{x:1730,y:730,t:1528139872808};\\\", \\\"{x:1731,y:739,t:1528139872825};\\\", \\\"{x:1731,y:747,t:1528139872840};\\\", \\\"{x:1731,y:756,t:1528139872857};\\\", \\\"{x:1731,y:767,t:1528139872874};\\\", \\\"{x:1722,y:786,t:1528139872890};\\\", \\\"{x:1704,y:815,t:1528139872907};\\\", \\\"{x:1693,y:829,t:1528139872924};\\\", \\\"{x:1678,y:842,t:1528139872941};\\\", \\\"{x:1666,y:851,t:1528139872957};\\\", \\\"{x:1655,y:859,t:1528139872974};\\\", \\\"{x:1645,y:865,t:1528139872990};\\\", \\\"{x:1631,y:872,t:1528139873007};\\\", \\\"{x:1616,y:877,t:1528139873025};\\\", \\\"{x:1603,y:882,t:1528139873041};\\\", \\\"{x:1585,y:888,t:1528139873058};\\\", \\\"{x:1566,y:897,t:1528139873075};\\\", \\\"{x:1550,y:904,t:1528139873091};\\\", \\\"{x:1526,y:915,t:1528139873108};\\\", \\\"{x:1513,y:920,t:1528139873124};\\\", \\\"{x:1504,y:921,t:1528139873142};\\\", \\\"{x:1498,y:924,t:1528139873158};\\\", \\\"{x:1495,y:924,t:1528139873175};\\\", \\\"{x:1489,y:925,t:1528139873191};\\\", \\\"{x:1484,y:925,t:1528139873207};\\\", \\\"{x:1476,y:926,t:1528139873224};\\\", \\\"{x:1469,y:926,t:1528139873242};\\\", \\\"{x:1464,y:926,t:1528139873257};\\\", \\\"{x:1459,y:926,t:1528139873274};\\\", \\\"{x:1456,y:926,t:1528139873292};\\\", \\\"{x:1454,y:926,t:1528139873308};\\\", \\\"{x:1453,y:926,t:1528139873332};\\\", \\\"{x:1452,y:925,t:1528139873372};\\\", \\\"{x:1450,y:924,t:1528139873388};\\\", \\\"{x:1449,y:923,t:1528139873396};\\\", \\\"{x:1448,y:921,t:1528139873408};\\\", \\\"{x:1446,y:920,t:1528139873425};\\\", \\\"{x:1444,y:918,t:1528139873442};\\\", \\\"{x:1442,y:917,t:1528139873458};\\\", \\\"{x:1441,y:916,t:1528139873475};\\\", \\\"{x:1439,y:915,t:1528139873492};\\\", \\\"{x:1438,y:914,t:1528139873507};\\\", \\\"{x:1437,y:913,t:1528139873524};\\\", \\\"{x:1436,y:912,t:1528139873541};\\\", \\\"{x:1435,y:912,t:1528139873558};\\\", \\\"{x:1434,y:911,t:1528139873575};\\\", \\\"{x:1432,y:910,t:1528139873596};\\\", \\\"{x:1431,y:909,t:1528139873620};\\\", \\\"{x:1430,y:909,t:1528139873636};\\\", \\\"{x:1429,y:909,t:1528139873644};\\\", \\\"{x:1428,y:909,t:1528139873660};\\\", \\\"{x:1427,y:909,t:1528139873674};\\\", \\\"{x:1425,y:909,t:1528139873692};\\\", \\\"{x:1423,y:909,t:1528139873708};\\\", \\\"{x:1420,y:909,t:1528139873725};\\\", \\\"{x:1417,y:909,t:1528139873742};\\\", \\\"{x:1414,y:909,t:1528139873758};\\\", \\\"{x:1410,y:909,t:1528139873775};\\\", \\\"{x:1407,y:909,t:1528139873792};\\\", \\\"{x:1402,y:909,t:1528139873808};\\\", \\\"{x:1395,y:910,t:1528139873825};\\\", \\\"{x:1381,y:916,t:1528139873841};\\\", \\\"{x:1370,y:922,t:1528139873859};\\\", \\\"{x:1362,y:927,t:1528139873875};\\\", \\\"{x:1351,y:935,t:1528139873892};\\\", \\\"{x:1348,y:940,t:1528139873908};\\\", \\\"{x:1345,y:944,t:1528139873925};\\\", \\\"{x:1343,y:950,t:1528139873941};\\\", \\\"{x:1342,y:952,t:1528139873959};\\\", \\\"{x:1341,y:955,t:1528139873975};\\\", \\\"{x:1341,y:959,t:1528139873991};\\\", \\\"{x:1341,y:962,t:1528139874009};\\\", \\\"{x:1341,y:966,t:1528139874025};\\\", \\\"{x:1341,y:968,t:1528139874042};\\\", \\\"{x:1342,y:971,t:1528139874059};\\\", \\\"{x:1344,y:973,t:1528139874075};\\\", \\\"{x:1348,y:975,t:1528139874091};\\\", \\\"{x:1349,y:976,t:1528139874108};\\\", \\\"{x:1362,y:977,t:1528139874126};\\\", \\\"{x:1379,y:977,t:1528139874143};\\\", \\\"{x:1396,y:977,t:1528139874159};\\\", \\\"{x:1411,y:970,t:1528139874176};\\\", \\\"{x:1428,y:959,t:1528139874192};\\\", \\\"{x:1449,y:947,t:1528139874209};\\\", \\\"{x:1471,y:929,t:1528139874226};\\\", \\\"{x:1499,y:902,t:1528139874242};\\\", \\\"{x:1523,y:872,t:1528139874258};\\\", \\\"{x:1546,y:842,t:1528139874276};\\\", \\\"{x:1556,y:819,t:1528139874292};\\\", \\\"{x:1564,y:792,t:1528139874309};\\\", \\\"{x:1568,y:764,t:1528139874326};\\\", \\\"{x:1569,y:733,t:1528139874342};\\\", \\\"{x:1569,y:702,t:1528139874358};\\\", \\\"{x:1569,y:678,t:1528139874376};\\\", \\\"{x:1569,y:659,t:1528139874392};\\\", \\\"{x:1569,y:641,t:1528139874409};\\\", \\\"{x:1569,y:630,t:1528139874426};\\\", \\\"{x:1569,y:621,t:1528139874442};\\\", \\\"{x:1569,y:619,t:1528139874459};\\\", \\\"{x:1569,y:620,t:1528139874669};\\\", \\\"{x:1573,y:626,t:1528139874676};\\\", \\\"{x:1579,y:637,t:1528139874692};\\\", \\\"{x:1587,y:652,t:1528139874709};\\\", \\\"{x:1595,y:664,t:1528139874726};\\\", \\\"{x:1602,y:675,t:1528139874743};\\\", \\\"{x:1602,y:678,t:1528139874759};\\\", \\\"{x:1603,y:680,t:1528139874775};\\\", \\\"{x:1603,y:681,t:1528139874908};\\\", \\\"{x:1604,y:681,t:1528139874926};\\\", \\\"{x:1605,y:681,t:1528139874943};\\\", \\\"{x:1606,y:682,t:1528139874959};\\\", \\\"{x:1609,y:684,t:1528139874975};\\\", \\\"{x:1611,y:685,t:1528139874993};\\\", \\\"{x:1616,y:686,t:1528139875009};\\\", \\\"{x:1616,y:687,t:1528139875025};\\\", \\\"{x:1617,y:687,t:1528139875061};\\\", \\\"{x:1618,y:687,t:1528139875076};\\\", \\\"{x:1618,y:689,t:1528139875108};\\\", \\\"{x:1618,y:691,t:1528139875164};\\\", \\\"{x:1618,y:692,t:1528139875215};\\\", \\\"{x:1617,y:692,t:1528139875250};\\\", \\\"{x:1617,y:693,t:1528139876275};\\\", \\\"{x:1615,y:704,t:1528139876294};\\\", \\\"{x:1612,y:715,t:1528139876309};\\\", \\\"{x:1608,y:726,t:1528139876327};\\\", \\\"{x:1606,y:732,t:1528139876344};\\\", \\\"{x:1605,y:736,t:1528139876359};\\\", \\\"{x:1604,y:740,t:1528139876376};\\\", \\\"{x:1604,y:745,t:1528139876394};\\\", \\\"{x:1601,y:752,t:1528139876410};\\\", \\\"{x:1600,y:757,t:1528139876427};\\\", \\\"{x:1596,y:766,t:1528139876444};\\\", \\\"{x:1594,y:775,t:1528139876461};\\\", \\\"{x:1591,y:785,t:1528139876476};\\\", \\\"{x:1588,y:794,t:1528139876494};\\\", \\\"{x:1586,y:804,t:1528139876510};\\\", \\\"{x:1583,y:811,t:1528139876527};\\\", \\\"{x:1580,y:816,t:1528139876543};\\\", \\\"{x:1578,y:822,t:1528139876560};\\\", \\\"{x:1574,y:831,t:1528139876577};\\\", \\\"{x:1569,y:842,t:1528139876594};\\\", \\\"{x:1564,y:854,t:1528139876611};\\\", \\\"{x:1559,y:864,t:1528139876626};\\\", \\\"{x:1552,y:880,t:1528139876643};\\\", \\\"{x:1547,y:893,t:1528139876660};\\\", \\\"{x:1542,y:906,t:1528139876677};\\\", \\\"{x:1537,y:918,t:1528139876694};\\\", \\\"{x:1528,y:933,t:1528139876711};\\\", \\\"{x:1519,y:945,t:1528139876727};\\\", \\\"{x:1515,y:951,t:1528139876744};\\\", \\\"{x:1511,y:956,t:1528139876761};\\\", \\\"{x:1508,y:959,t:1528139876777};\\\", \\\"{x:1506,y:961,t:1528139876794};\\\", \\\"{x:1503,y:963,t:1528139876811};\\\", \\\"{x:1501,y:965,t:1528139876827};\\\", \\\"{x:1498,y:967,t:1528139876843};\\\", \\\"{x:1495,y:968,t:1528139876860};\\\", \\\"{x:1492,y:969,t:1528139876876};\\\", \\\"{x:1490,y:970,t:1528139876893};\\\", \\\"{x:1486,y:968,t:1528139877941};\\\", \\\"{x:1471,y:950,t:1528139877948};\\\", \\\"{x:1428,y:913,t:1528139877961};\\\", \\\"{x:1304,y:810,t:1528139877978};\\\", \\\"{x:1139,y:702,t:1528139877994};\\\", \\\"{x:825,y:548,t:1528139878011};\\\", \\\"{x:611,y:461,t:1528139878027};\\\", \\\"{x:438,y:391,t:1528139878045};\\\", \\\"{x:314,y:341,t:1528139878061};\\\", \\\"{x:256,y:318,t:1528139878078};\\\", \\\"{x:246,y:313,t:1528139878095};\\\", \\\"{x:246,y:315,t:1528139878323};\\\", \\\"{x:246,y:324,t:1528139878331};\\\", \\\"{x:248,y:339,t:1528139878346};\\\", \\\"{x:267,y:383,t:1528139878361};\\\", \\\"{x:299,y:445,t:1528139878379};\\\", \\\"{x:383,y:552,t:1528139878397};\\\", \\\"{x:443,y:600,t:1528139878412};\\\", \\\"{x:482,y:623,t:1528139878428};\\\", \\\"{x:498,y:630,t:1528139878445};\\\", \\\"{x:503,y:633,t:1528139878461};\\\", \\\"{x:504,y:633,t:1528139878478};\\\", \\\"{x:505,y:633,t:1528139878531};\\\", \\\"{x:507,y:632,t:1528139878545};\\\", \\\"{x:512,y:621,t:1528139878561};\\\", \\\"{x:520,y:607,t:1528139878578};\\\", \\\"{x:535,y:580,t:1528139878596};\\\", \\\"{x:543,y:564,t:1528139878612};\\\", \\\"{x:555,y:542,t:1528139878630};\\\", \\\"{x:566,y:524,t:1528139878646};\\\", \\\"{x:579,y:509,t:1528139878663};\\\", \\\"{x:589,y:501,t:1528139878678};\\\", \\\"{x:595,y:495,t:1528139878695};\\\", \\\"{x:598,y:493,t:1528139878711};\\\", \\\"{x:601,y:490,t:1528139878729};\\\", \\\"{x:603,y:488,t:1528139878746};\\\", \\\"{x:604,y:487,t:1528139878762};\\\", \\\"{x:605,y:487,t:1528139878827};\\\", \\\"{x:604,y:492,t:1528139879164};\\\", \\\"{x:596,y:505,t:1528139879179};\\\", \\\"{x:589,y:514,t:1528139879197};\\\", \\\"{x:585,y:519,t:1528139879213};\\\", \\\"{x:584,y:523,t:1528139879230};\\\", \\\"{x:584,y:524,t:1528139879245};\\\", \\\"{x:584,y:525,t:1528139879264};\\\", \\\"{x:584,y:526,t:1528139879280};\\\", \\\"{x:584,y:527,t:1528139879295};\\\", \\\"{x:591,y:527,t:1528139879312};\\\", \\\"{x:614,y:527,t:1528139879329};\\\", \\\"{x:663,y:523,t:1528139879347};\\\", \\\"{x:719,y:515,t:1528139879363};\\\", \\\"{x:773,y:505,t:1528139879379};\\\", \\\"{x:788,y:502,t:1528139879396};\\\", \\\"{x:791,y:501,t:1528139879412};\\\", \\\"{x:791,y:500,t:1528139879482};\\\", \\\"{x:792,y:500,t:1528139879495};\\\", \\\"{x:794,y:498,t:1528139879512};\\\", \\\"{x:795,y:497,t:1528139879530};\\\", \\\"{x:796,y:496,t:1528139879546};\\\", \\\"{x:796,y:495,t:1528139879612};\\\", \\\"{x:797,y:494,t:1528139879629};\\\", \\\"{x:798,y:494,t:1528139879645};\\\", \\\"{x:800,y:493,t:1528139879662};\\\", \\\"{x:801,y:492,t:1528139879683};\\\", \\\"{x:802,y:492,t:1528139879696};\\\", \\\"{x:803,y:491,t:1528139879712};\\\", \\\"{x:805,y:491,t:1528139879729};\\\", \\\"{x:808,y:491,t:1528139879745};\\\", \\\"{x:812,y:491,t:1528139879762};\\\", \\\"{x:815,y:491,t:1528139879780};\\\", \\\"{x:817,y:491,t:1528139879796};\\\", \\\"{x:819,y:491,t:1528139879812};\\\", \\\"{x:820,y:491,t:1528139879829};\\\", \\\"{x:814,y:494,t:1528139879972};\\\", \\\"{x:803,y:499,t:1528139879979};\\\", \\\"{x:764,y:510,t:1528139879995};\\\", \\\"{x:720,y:516,t:1528139880014};\\\", \\\"{x:689,y:517,t:1528139880029};\\\", \\\"{x:667,y:517,t:1528139880045};\\\", \\\"{x:659,y:517,t:1528139880062};\\\", \\\"{x:658,y:517,t:1528139880079};\\\", \\\"{x:657,y:517,t:1528139880098};\\\", \\\"{x:656,y:517,t:1528139880113};\\\", \\\"{x:652,y:516,t:1528139880129};\\\", \\\"{x:648,y:515,t:1528139880145};\\\", \\\"{x:645,y:512,t:1528139880162};\\\", \\\"{x:633,y:510,t:1528139880179};\\\", \\\"{x:627,y:509,t:1528139880196};\\\", \\\"{x:624,y:509,t:1528139880213};\\\", \\\"{x:621,y:509,t:1528139880229};\\\", \\\"{x:620,y:509,t:1528139880247};\\\", \\\"{x:621,y:509,t:1528139880515};\\\", \\\"{x:634,y:509,t:1528139880531};\\\", \\\"{x:675,y:509,t:1528139880547};\\\", \\\"{x:788,y:506,t:1528139880564};\\\", \\\"{x:840,y:501,t:1528139880581};\\\", \\\"{x:862,y:499,t:1528139880597};\\\", \\\"{x:868,y:497,t:1528139880614};\\\", \\\"{x:867,y:497,t:1528139880813};\\\", \\\"{x:864,y:497,t:1528139880830};\\\", \\\"{x:858,y:497,t:1528139880847};\\\", \\\"{x:852,y:497,t:1528139880864};\\\", \\\"{x:846,y:497,t:1528139880881};\\\", \\\"{x:844,y:497,t:1528139880898};\\\", \\\"{x:843,y:497,t:1528139880914};\\\", \\\"{x:843,y:498,t:1528139880930};\\\", \\\"{x:836,y:499,t:1528139881107};\\\", \\\"{x:828,y:509,t:1528139881115};\\\", \\\"{x:801,y:531,t:1528139881131};\\\", \\\"{x:772,y:553,t:1528139881147};\\\", \\\"{x:750,y:570,t:1528139881164};\\\", \\\"{x:734,y:580,t:1528139881181};\\\", \\\"{x:717,y:595,t:1528139881198};\\\", \\\"{x:693,y:615,t:1528139881215};\\\", \\\"{x:672,y:634,t:1528139881231};\\\", \\\"{x:647,y:653,t:1528139881247};\\\", \\\"{x:628,y:667,t:1528139881264};\\\", \\\"{x:611,y:676,t:1528139881281};\\\", \\\"{x:599,y:683,t:1528139881297};\\\", \\\"{x:593,y:687,t:1528139881315};\\\", \\\"{x:590,y:689,t:1528139881331};\\\", \\\"{x:588,y:689,t:1528139881347};\\\", \\\"{x:587,y:692,t:1528139881365};\\\", \\\"{x:584,y:692,t:1528139881380};\\\", \\\"{x:583,y:694,t:1528139881397};\\\", \\\"{x:582,y:694,t:1528139881427};\\\", \\\"{x:581,y:694,t:1528139881452};\\\", \\\"{x:580,y:695,t:1528139881468};\\\", \\\"{x:577,y:697,t:1528139881481};\\\", \\\"{x:572,y:702,t:1528139881497};\\\", \\\"{x:564,y:708,t:1528139881515};\\\", \\\"{x:554,y:717,t:1528139881531};\\\", \\\"{x:547,y:723,t:1528139881548};\\\", \\\"{x:545,y:724,t:1528139881565};\\\", \\\"{x:543,y:725,t:1528139881580};\\\", \\\"{x:542,y:726,t:1528139881597};\\\", \\\"{x:538,y:728,t:1528139881613};\\\", \\\"{x:536,y:729,t:1528139881630};\\\" ] }, { \\\"rt\\\": 9780, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 576181, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:728,t:1528139883571};\\\", \\\"{x:541,y:727,t:1528139883582};\\\", \\\"{x:549,y:723,t:1528139883600};\\\", \\\"{x:553,y:719,t:1528139883617};\\\", \\\"{x:562,y:713,t:1528139883632};\\\", \\\"{x:570,y:704,t:1528139883649};\\\", \\\"{x:581,y:694,t:1528139883666};\\\", \\\"{x:592,y:682,t:1528139883682};\\\", \\\"{x:612,y:664,t:1528139883699};\\\", \\\"{x:619,y:659,t:1528139883716};\\\", \\\"{x:624,y:653,t:1528139883733};\\\", \\\"{x:627,y:647,t:1528139883749};\\\", \\\"{x:629,y:643,t:1528139883766};\\\", \\\"{x:630,y:641,t:1528139883782};\\\", \\\"{x:632,y:634,t:1528139883800};\\\", \\\"{x:634,y:628,t:1528139883817};\\\", \\\"{x:634,y:620,t:1528139883832};\\\", \\\"{x:634,y:614,t:1528139883849};\\\", \\\"{x:633,y:611,t:1528139883865};\\\", \\\"{x:632,y:610,t:1528139883882};\\\", \\\"{x:631,y:610,t:1528139883915};\\\", \\\"{x:631,y:613,t:1528139884003};\\\", \\\"{x:617,y:629,t:1528139884018};\\\", \\\"{x:583,y:699,t:1528139884033};\\\", \\\"{x:573,y:809,t:1528139884050};\\\", \\\"{x:625,y:935,t:1528139884065};\\\", \\\"{x:629,y:954,t:1528139884082};\\\", \\\"{x:632,y:954,t:1528139884836};\\\", \\\"{x:673,y:944,t:1528139884849};\\\", \\\"{x:814,y:909,t:1528139884865};\\\", \\\"{x:1028,y:879,t:1528139884882};\\\", \\\"{x:1189,y:857,t:1528139884899};\\\", \\\"{x:1311,y:838,t:1528139884916};\\\", \\\"{x:1367,y:835,t:1528139884933};\\\", \\\"{x:1387,y:835,t:1528139884948};\\\", \\\"{x:1393,y:835,t:1528139884966};\\\", \\\"{x:1394,y:835,t:1528139884982};\\\", \\\"{x:1396,y:835,t:1528139884998};\\\", \\\"{x:1397,y:835,t:1528139885016};\\\", \\\"{x:1397,y:836,t:1528139885033};\\\", \\\"{x:1398,y:837,t:1528139885049};\\\", \\\"{x:1401,y:843,t:1528139885066};\\\", \\\"{x:1410,y:851,t:1528139885083};\\\", \\\"{x:1432,y:860,t:1528139885099};\\\", \\\"{x:1475,y:872,t:1528139885116};\\\", \\\"{x:1495,y:875,t:1528139885133};\\\", \\\"{x:1514,y:880,t:1528139885149};\\\", \\\"{x:1559,y:892,t:1528139885166};\\\", \\\"{x:1589,y:899,t:1528139885183};\\\", \\\"{x:1599,y:902,t:1528139885199};\\\", \\\"{x:1600,y:902,t:1528139885215};\\\", \\\"{x:1600,y:903,t:1528139885244};\\\", \\\"{x:1600,y:905,t:1528139885259};\\\", \\\"{x:1600,y:906,t:1528139885268};\\\", \\\"{x:1594,y:913,t:1528139885284};\\\", \\\"{x:1590,y:916,t:1528139885299};\\\", \\\"{x:1575,y:927,t:1528139885316};\\\", \\\"{x:1567,y:938,t:1528139885333};\\\", \\\"{x:1563,y:948,t:1528139885349};\\\", \\\"{x:1556,y:959,t:1528139885366};\\\", \\\"{x:1550,y:968,t:1528139885383};\\\", \\\"{x:1548,y:975,t:1528139885400};\\\", \\\"{x:1548,y:979,t:1528139885416};\\\", \\\"{x:1548,y:982,t:1528139885433};\\\", \\\"{x:1548,y:983,t:1528139885449};\\\", \\\"{x:1548,y:984,t:1528139885466};\\\", \\\"{x:1548,y:985,t:1528139885484};\\\", \\\"{x:1548,y:982,t:1528139885629};\\\", \\\"{x:1548,y:979,t:1528139885636};\\\", \\\"{x:1548,y:978,t:1528139885649};\\\", \\\"{x:1548,y:974,t:1528139885666};\\\", \\\"{x:1548,y:971,t:1528139885682};\\\", \\\"{x:1548,y:967,t:1528139885700};\\\", \\\"{x:1547,y:966,t:1528139885724};\\\", \\\"{x:1546,y:966,t:1528139885788};\\\", \\\"{x:1545,y:964,t:1528139888077};\\\", \\\"{x:1529,y:957,t:1528139888084};\\\", \\\"{x:1494,y:942,t:1528139888098};\\\", \\\"{x:1369,y:902,t:1528139888116};\\\", \\\"{x:1252,y:869,t:1528139888132};\\\", \\\"{x:1111,y:826,t:1528139888148};\\\", \\\"{x:983,y:800,t:1528139888166};\\\", \\\"{x:873,y:790,t:1528139888182};\\\", \\\"{x:823,y:790,t:1528139888199};\\\", \\\"{x:821,y:789,t:1528139888500};\\\", \\\"{x:814,y:774,t:1528139888516};\\\", \\\"{x:800,y:753,t:1528139888531};\\\", \\\"{x:782,y:737,t:1528139888548};\\\", \\\"{x:762,y:714,t:1528139888565};\\\", \\\"{x:743,y:693,t:1528139888581};\\\", \\\"{x:725,y:679,t:1528139888598};\\\", \\\"{x:717,y:671,t:1528139888615};\\\", \\\"{x:707,y:662,t:1528139888631};\\\", \\\"{x:693,y:652,t:1528139888648};\\\", \\\"{x:684,y:646,t:1528139888665};\\\", \\\"{x:676,y:640,t:1528139888682};\\\", \\\"{x:672,y:637,t:1528139888699};\\\", \\\"{x:657,y:624,t:1528139888716};\\\", \\\"{x:642,y:615,t:1528139888733};\\\", \\\"{x:626,y:605,t:1528139888754};\\\", \\\"{x:617,y:597,t:1528139888770};\\\", \\\"{x:605,y:587,t:1528139888787};\\\", \\\"{x:594,y:578,t:1528139888803};\\\", \\\"{x:585,y:570,t:1528139888819};\\\", \\\"{x:579,y:564,t:1528139888837};\\\", \\\"{x:578,y:561,t:1528139888854};\\\", \\\"{x:578,y:560,t:1528139888882};\\\", \\\"{x:580,y:560,t:1528139889156};\\\", \\\"{x:584,y:562,t:1528139889170};\\\", \\\"{x:586,y:563,t:1528139889188};\\\", \\\"{x:588,y:565,t:1528139889204};\\\", \\\"{x:589,y:565,t:1528139889220};\\\", \\\"{x:590,y:565,t:1528139889237};\\\", \\\"{x:591,y:578,t:1528139889852};\\\", \\\"{x:591,y:592,t:1528139889860};\\\", \\\"{x:591,y:605,t:1528139889873};\\\", \\\"{x:589,y:630,t:1528139889887};\\\", \\\"{x:584,y:655,t:1528139889904};\\\", \\\"{x:577,y:676,t:1528139889921};\\\", \\\"{x:572,y:696,t:1528139889937};\\\", \\\"{x:564,y:717,t:1528139889954};\\\", \\\"{x:560,y:729,t:1528139889971};\\\", \\\"{x:556,y:740,t:1528139889988};\\\", \\\"{x:551,y:746,t:1528139890004};\\\", \\\"{x:548,y:752,t:1528139890021};\\\", \\\"{x:547,y:754,t:1528139890038};\\\", \\\"{x:544,y:756,t:1528139890055};\\\", \\\"{x:540,y:760,t:1528139890070};\\\", \\\"{x:538,y:761,t:1528139890087};\\\", \\\"{x:533,y:763,t:1528139890104};\\\", \\\"{x:531,y:764,t:1528139890121};\\\", \\\"{x:531,y:765,t:1528139890137};\\\", \\\"{x:528,y:765,t:1528139890154};\\\", \\\"{x:526,y:767,t:1528139890171};\\\", \\\"{x:525,y:767,t:1528139890188};\\\", \\\"{x:524,y:768,t:1528139890205};\\\", \\\"{x:523,y:769,t:1528139890221};\\\", \\\"{x:521,y:770,t:1528139890238};\\\", \\\"{x:521,y:771,t:1528139890255};\\\", \\\"{x:519,y:771,t:1528139890291};\\\", \\\"{x:517,y:770,t:1528139890308};\\\", \\\"{x:517,y:768,t:1528139890321};\\\", \\\"{x:514,y:751,t:1528139890338};\\\", \\\"{x:509,y:712,t:1528139890355};\\\", \\\"{x:509,y:684,t:1528139890372};\\\", \\\"{x:509,y:665,t:1528139890388};\\\", \\\"{x:515,y:650,t:1528139890405};\\\", \\\"{x:519,y:643,t:1528139890422};\\\", \\\"{x:524,y:639,t:1528139890437};\\\", \\\"{x:530,y:634,t:1528139890455};\\\", \\\"{x:535,y:630,t:1528139890473};\\\", \\\"{x:541,y:627,t:1528139890488};\\\", \\\"{x:550,y:622,t:1528139890505};\\\", \\\"{x:556,y:618,t:1528139890522};\\\", \\\"{x:564,y:613,t:1528139890539};\\\", \\\"{x:565,y:612,t:1528139890555};\\\", \\\"{x:567,y:610,t:1528139890572};\\\", \\\"{x:568,y:609,t:1528139890595};\\\", \\\"{x:570,y:607,t:1528139890619};\\\", \\\"{x:571,y:606,t:1528139890628};\\\", \\\"{x:571,y:605,t:1528139890639};\\\", \\\"{x:572,y:603,t:1528139890656};\\\", \\\"{x:574,y:601,t:1528139890673};\\\", \\\"{x:574,y:598,t:1528139890691};\\\", \\\"{x:575,y:595,t:1528139890706};\\\", \\\"{x:577,y:589,t:1528139890722};\\\", \\\"{x:579,y:582,t:1528139890739};\\\", \\\"{x:580,y:579,t:1528139890755};\\\", \\\"{x:582,y:575,t:1528139890772};\\\", \\\"{x:582,y:573,t:1528139890787};\\\", \\\"{x:583,y:573,t:1528139890805};\\\", \\\"{x:585,y:571,t:1528139890822};\\\", \\\"{x:586,y:570,t:1528139890839};\\\", \\\"{x:588,y:570,t:1528139890855};\\\", \\\"{x:592,y:569,t:1528139890872};\\\", \\\"{x:592,y:568,t:1528139890889};\\\", \\\"{x:593,y:568,t:1528139890948};\\\", \\\"{x:594,y:568,t:1528139890964};\\\", \\\"{x:595,y:568,t:1528139890972};\\\", \\\"{x:597,y:568,t:1528139890989};\\\", \\\"{x:597,y:568,t:1528139891100};\\\", \\\"{x:597,y:569,t:1528139891204};\\\", \\\"{x:597,y:576,t:1528139891212};\\\", \\\"{x:597,y:582,t:1528139891222};\\\", \\\"{x:597,y:594,t:1528139891240};\\\", \\\"{x:597,y:605,t:1528139891256};\\\", \\\"{x:597,y:615,t:1528139891271};\\\", \\\"{x:597,y:626,t:1528139891288};\\\", \\\"{x:597,y:638,t:1528139891305};\\\", \\\"{x:597,y:652,t:1528139891321};\\\", \\\"{x:595,y:671,t:1528139891339};\\\", \\\"{x:594,y:678,t:1528139891356};\\\", \\\"{x:593,y:683,t:1528139891371};\\\", \\\"{x:592,y:686,t:1528139891389};\\\", \\\"{x:592,y:690,t:1528139891406};\\\", \\\"{x:590,y:695,t:1528139891422};\\\", \\\"{x:591,y:688,t:1528139891508};\\\", \\\"{x:592,y:677,t:1528139891522};\\\", \\\"{x:600,y:640,t:1528139891539};\\\", \\\"{x:602,y:622,t:1528139891556};\\\", \\\"{x:603,y:615,t:1528139891572};\\\", \\\"{x:604,y:611,t:1528139891589};\\\", \\\"{x:604,y:610,t:1528139891605};\\\", \\\"{x:605,y:609,t:1528139891623};\\\", \\\"{x:605,y:608,t:1528139891675};\\\", \\\"{x:605,y:605,t:1528139891716};\\\", \\\"{x:605,y:604,t:1528139891723};\\\", \\\"{x:606,y:597,t:1528139891740};\\\", \\\"{x:606,y:588,t:1528139891756};\\\", \\\"{x:608,y:581,t:1528139891773};\\\", \\\"{x:608,y:577,t:1528139891788};\\\", \\\"{x:609,y:576,t:1528139891842};\\\", \\\"{x:608,y:576,t:1528139892107};\\\", \\\"{x:602,y:591,t:1528139892123};\\\", \\\"{x:598,y:602,t:1528139892140};\\\", \\\"{x:594,y:613,t:1528139892155};\\\", \\\"{x:593,y:623,t:1528139892173};\\\", \\\"{x:589,y:634,t:1528139892190};\\\", \\\"{x:585,y:642,t:1528139892206};\\\", \\\"{x:580,y:653,t:1528139892222};\\\", \\\"{x:575,y:667,t:1528139892240};\\\", \\\"{x:567,y:688,t:1528139892256};\\\", \\\"{x:557,y:709,t:1528139892273};\\\", \\\"{x:550,y:731,t:1528139892291};\\\", \\\"{x:545,y:744,t:1528139892306};\\\", \\\"{x:542,y:749,t:1528139892323};\\\", \\\"{x:542,y:751,t:1528139892340};\\\", \\\"{x:541,y:752,t:1528139892356};\\\", \\\"{x:540,y:753,t:1528139892373};\\\", \\\"{x:538,y:755,t:1528139892390};\\\", \\\"{x:536,y:756,t:1528139892406};\\\", \\\"{x:536,y:757,t:1528139892423};\\\", \\\"{x:535,y:757,t:1528139892588};\\\", \\\"{x:534,y:755,t:1528139892595};\\\", \\\"{x:532,y:753,t:1528139892607};\\\", \\\"{x:531,y:748,t:1528139892623};\\\", \\\"{x:528,y:742,t:1528139892640};\\\", \\\"{x:527,y:739,t:1528139892657};\\\", \\\"{x:527,y:737,t:1528139892673};\\\", \\\"{x:526,y:737,t:1528139892731};\\\" ] }, { \\\"rt\\\": 25309, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 602700, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-I -05 PM-04 PM-03 PM-02 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:531,y:722,t:1528139895662};\\\", \\\"{x:556,y:659,t:1528139895675};\\\", \\\"{x:601,y:555,t:1528139895692};\\\", \\\"{x:655,y:428,t:1528139895709};\\\", \\\"{x:718,y:295,t:1528139895726};\\\", \\\"{x:787,y:193,t:1528139895741};\\\", \\\"{x:825,y:140,t:1528139895759};\\\", \\\"{x:830,y:133,t:1528139895776};\\\", \\\"{x:826,y:133,t:1528139895859};\\\", \\\"{x:815,y:134,t:1528139895876};\\\", \\\"{x:813,y:134,t:1528139895988};\\\", \\\"{x:813,y:135,t:1528139895996};\\\", \\\"{x:812,y:135,t:1528139896009};\\\", \\\"{x:809,y:137,t:1528139896026};\\\", \\\"{x:809,y:138,t:1528139896516};\\\", \\\"{x:809,y:139,t:1528139896532};\\\", \\\"{x:809,y:140,t:1528139897276};\\\", \\\"{x:806,y:142,t:1528139897283};\\\", \\\"{x:803,y:144,t:1528139897294};\\\", \\\"{x:798,y:146,t:1528139897310};\\\", \\\"{x:793,y:150,t:1528139897328};\\\", \\\"{x:783,y:157,t:1528139897344};\\\", \\\"{x:775,y:164,t:1528139897360};\\\", \\\"{x:768,y:170,t:1528139897377};\\\", \\\"{x:762,y:176,t:1528139897394};\\\", \\\"{x:757,y:181,t:1528139897410};\\\", \\\"{x:747,y:193,t:1528139897428};\\\", \\\"{x:742,y:204,t:1528139897445};\\\", \\\"{x:736,y:216,t:1528139897461};\\\", \\\"{x:732,y:231,t:1528139897478};\\\", \\\"{x:725,y:247,t:1528139897495};\\\", \\\"{x:721,y:261,t:1528139897511};\\\", \\\"{x:721,y:270,t:1528139897528};\\\", \\\"{x:721,y:274,t:1528139897545};\\\", \\\"{x:721,y:276,t:1528139897561};\\\", \\\"{x:721,y:277,t:1528139897578};\\\", \\\"{x:721,y:278,t:1528139897594};\\\", \\\"{x:722,y:278,t:1528139897724};\\\", \\\"{x:723,y:279,t:1528139897747};\\\", \\\"{x:724,y:281,t:1528139898116};\\\", \\\"{x:729,y:283,t:1528139898128};\\\", \\\"{x:732,y:285,t:1528139898144};\\\", \\\"{x:733,y:285,t:1528139898162};\\\", \\\"{x:735,y:286,t:1528139898177};\\\", \\\"{x:736,y:287,t:1528139898195};\\\", \\\"{x:737,y:288,t:1528139898228};\\\", \\\"{x:737,y:289,t:1528139898259};\\\", \\\"{x:737,y:290,t:1528139898308};\\\", \\\"{x:738,y:290,t:1528139898316};\\\", \\\"{x:739,y:290,t:1528139898331};\\\", \\\"{x:741,y:290,t:1528139898347};\\\", \\\"{x:742,y:290,t:1528139898361};\\\", \\\"{x:743,y:289,t:1528139898379};\\\", \\\"{x:744,y:289,t:1528139898428};\\\", \\\"{x:744,y:288,t:1528139899596};\\\", \\\"{x:744,y:284,t:1528139899612};\\\", \\\"{x:744,y:282,t:1528139899630};\\\", \\\"{x:744,y:280,t:1528139899645};\\\", \\\"{x:742,y:279,t:1528139899683};\\\", \\\"{x:741,y:278,t:1528139899696};\\\", \\\"{x:725,y:272,t:1528139899713};\\\", \\\"{x:682,y:257,t:1528139899730};\\\", \\\"{x:649,y:250,t:1528139899746};\\\", \\\"{x:641,y:244,t:1528139899763};\\\", \\\"{x:642,y:246,t:1528139900244};\\\", \\\"{x:647,y:252,t:1528139900251};\\\", \\\"{x:659,y:263,t:1528139900263};\\\", \\\"{x:708,y:328,t:1528139900280};\\\", \\\"{x:775,y:418,t:1528139900297};\\\", \\\"{x:864,y:540,t:1528139900314};\\\", \\\"{x:966,y:687,t:1528139900330};\\\", \\\"{x:1163,y:987,t:1528139900363};\\\", \\\"{x:1250,y:1161,t:1528139900379};\\\", \\\"{x:1279,y:1199,t:1528139900396};\\\", \\\"{x:1291,y:1199,t:1528139900413};\\\", \\\"{x:1294,y:1199,t:1528139900429};\\\", \\\"{x:1296,y:1199,t:1528139900523};\\\", \\\"{x:1301,y:1192,t:1528139900530};\\\", \\\"{x:1310,y:1173,t:1528139900546};\\\", \\\"{x:1326,y:1139,t:1528139900562};\\\", \\\"{x:1338,y:1120,t:1528139900580};\\\", \\\"{x:1348,y:1103,t:1528139900596};\\\", \\\"{x:1361,y:1085,t:1528139900614};\\\", \\\"{x:1378,y:1069,t:1528139900630};\\\", \\\"{x:1393,y:1054,t:1528139900646};\\\", \\\"{x:1411,y:1038,t:1528139900664};\\\", \\\"{x:1429,y:1021,t:1528139900680};\\\", \\\"{x:1450,y:1002,t:1528139900696};\\\", \\\"{x:1472,y:981,t:1528139900714};\\\", \\\"{x:1493,y:962,t:1528139900730};\\\", \\\"{x:1513,y:945,t:1528139900746};\\\", \\\"{x:1541,y:926,t:1528139900763};\\\", \\\"{x:1556,y:918,t:1528139900780};\\\", \\\"{x:1561,y:916,t:1528139900797};\\\", \\\"{x:1560,y:916,t:1528139900988};\\\", \\\"{x:1556,y:917,t:1528139900997};\\\", \\\"{x:1554,y:918,t:1528139901014};\\\", \\\"{x:1550,y:923,t:1528139901031};\\\", \\\"{x:1545,y:930,t:1528139901047};\\\", \\\"{x:1543,y:937,t:1528139901063};\\\", \\\"{x:1538,y:945,t:1528139901081};\\\", \\\"{x:1536,y:952,t:1528139901096};\\\", \\\"{x:1533,y:957,t:1528139901114};\\\", \\\"{x:1531,y:960,t:1528139901130};\\\", \\\"{x:1528,y:963,t:1528139901147};\\\", \\\"{x:1524,y:965,t:1528139901164};\\\", \\\"{x:1521,y:967,t:1528139901180};\\\", \\\"{x:1518,y:968,t:1528139901196};\\\", \\\"{x:1515,y:968,t:1528139901213};\\\", \\\"{x:1514,y:968,t:1528139901230};\\\", \\\"{x:1512,y:968,t:1528139901247};\\\", \\\"{x:1511,y:967,t:1528139901263};\\\", \\\"{x:1508,y:967,t:1528139901280};\\\", \\\"{x:1507,y:966,t:1528139901297};\\\", \\\"{x:1505,y:965,t:1528139901313};\\\", \\\"{x:1505,y:964,t:1528139901330};\\\", \\\"{x:1503,y:964,t:1528139901347};\\\", \\\"{x:1502,y:963,t:1528139901363};\\\", \\\"{x:1501,y:963,t:1528139901380};\\\", \\\"{x:1500,y:962,t:1528139901397};\\\", \\\"{x:1499,y:962,t:1528139901413};\\\", \\\"{x:1497,y:962,t:1528139901431};\\\", \\\"{x:1496,y:962,t:1528139901447};\\\", \\\"{x:1495,y:962,t:1528139901463};\\\", \\\"{x:1494,y:962,t:1528139901481};\\\", \\\"{x:1492,y:962,t:1528139901497};\\\", \\\"{x:1490,y:963,t:1528139901513};\\\", \\\"{x:1488,y:963,t:1528139901531};\\\", \\\"{x:1488,y:964,t:1528139901548};\\\", \\\"{x:1486,y:966,t:1528139901563};\\\", \\\"{x:1485,y:966,t:1528139901588};\\\", \\\"{x:1484,y:966,t:1528139901627};\\\", \\\"{x:1483,y:966,t:1528139902388};\\\", \\\"{x:1483,y:967,t:1528139902411};\\\", \\\"{x:1482,y:968,t:1528139902419};\\\", \\\"{x:1481,y:968,t:1528139902450};\\\", \\\"{x:1480,y:969,t:1528139902483};\\\", \\\"{x:1481,y:969,t:1528139903052};\\\", \\\"{x:1483,y:969,t:1528139903067};\\\", \\\"{x:1484,y:968,t:1528139910213};\\\", \\\"{x:1482,y:958,t:1528139910220};\\\", \\\"{x:1447,y:933,t:1528139910238};\\\", \\\"{x:1398,y:905,t:1528139910254};\\\", \\\"{x:1330,y:869,t:1528139910270};\\\", \\\"{x:1263,y:836,t:1528139910288};\\\", \\\"{x:1202,y:810,t:1528139910304};\\\", \\\"{x:1153,y:780,t:1528139910320};\\\", \\\"{x:1134,y:767,t:1528139910338};\\\", \\\"{x:1124,y:759,t:1528139910354};\\\", \\\"{x:1119,y:754,t:1528139910370};\\\", \\\"{x:1117,y:750,t:1528139910387};\\\", \\\"{x:1117,y:749,t:1528139910404};\\\", \\\"{x:1117,y:748,t:1528139910428};\\\", \\\"{x:1117,y:751,t:1528139910595};\\\", \\\"{x:1119,y:756,t:1528139910604};\\\", \\\"{x:1129,y:766,t:1528139910621};\\\", \\\"{x:1137,y:773,t:1528139910637};\\\", \\\"{x:1142,y:776,t:1528139910654};\\\", \\\"{x:1147,y:778,t:1528139910671};\\\", \\\"{x:1148,y:778,t:1528139910699};\\\", \\\"{x:1149,y:778,t:1528139910723};\\\", \\\"{x:1150,y:778,t:1528139910737};\\\", \\\"{x:1151,y:778,t:1528139910755};\\\", \\\"{x:1152,y:778,t:1528139910804};\\\", \\\"{x:1153,y:778,t:1528139910821};\\\", \\\"{x:1156,y:776,t:1528139910837};\\\", \\\"{x:1157,y:776,t:1528139910859};\\\", \\\"{x:1159,y:775,t:1528139910875};\\\", \\\"{x:1160,y:775,t:1528139910889};\\\", \\\"{x:1164,y:774,t:1528139910904};\\\", \\\"{x:1166,y:772,t:1528139910920};\\\", \\\"{x:1171,y:771,t:1528139910937};\\\", \\\"{x:1175,y:769,t:1528139910954};\\\", \\\"{x:1184,y:765,t:1528139910971};\\\", \\\"{x:1186,y:765,t:1528139910987};\\\", \\\"{x:1187,y:765,t:1528139911004};\\\", \\\"{x:1188,y:765,t:1528139911034};\\\", \\\"{x:1189,y:765,t:1528139911083};\\\", \\\"{x:1191,y:765,t:1528139911508};\\\", \\\"{x:1203,y:771,t:1528139911521};\\\", \\\"{x:1247,y:789,t:1528139911538};\\\", \\\"{x:1339,y:829,t:1528139911555};\\\", \\\"{x:1413,y:861,t:1528139911571};\\\", \\\"{x:1504,y:899,t:1528139911588};\\\", \\\"{x:1592,y:934,t:1528139911606};\\\", \\\"{x:1653,y:959,t:1528139911622};\\\", \\\"{x:1674,y:971,t:1528139911638};\\\", \\\"{x:1676,y:973,t:1528139911655};\\\", \\\"{x:1676,y:975,t:1528139911707};\\\", \\\"{x:1673,y:975,t:1528139911721};\\\", \\\"{x:1662,y:976,t:1528139911739};\\\", \\\"{x:1634,y:980,t:1528139911756};\\\", \\\"{x:1615,y:982,t:1528139911772};\\\", \\\"{x:1593,y:983,t:1528139911789};\\\", \\\"{x:1571,y:983,t:1528139911805};\\\", \\\"{x:1551,y:983,t:1528139911822};\\\", \\\"{x:1537,y:983,t:1528139911838};\\\", \\\"{x:1524,y:983,t:1528139911856};\\\", \\\"{x:1516,y:983,t:1528139911873};\\\", \\\"{x:1506,y:983,t:1528139911889};\\\", \\\"{x:1497,y:981,t:1528139911906};\\\", \\\"{x:1490,y:980,t:1528139911922};\\\", \\\"{x:1484,y:980,t:1528139911938};\\\", \\\"{x:1474,y:980,t:1528139911955};\\\", \\\"{x:1470,y:979,t:1528139911971};\\\", \\\"{x:1469,y:978,t:1528139912028};\\\", \\\"{x:1469,y:977,t:1528139912091};\\\", \\\"{x:1470,y:976,t:1528139912106};\\\", \\\"{x:1474,y:972,t:1528139912122};\\\", \\\"{x:1482,y:970,t:1528139912138};\\\", \\\"{x:1491,y:966,t:1528139912156};\\\", \\\"{x:1492,y:965,t:1528139912172};\\\", \\\"{x:1492,y:963,t:1528139912260};\\\", \\\"{x:1492,y:962,t:1528139912292};\\\", \\\"{x:1492,y:961,t:1528139912307};\\\", \\\"{x:1491,y:961,t:1528139912322};\\\", \\\"{x:1490,y:960,t:1528139912395};\\\", \\\"{x:1490,y:959,t:1528139912604};\\\", \\\"{x:1490,y:957,t:1528139912619};\\\", \\\"{x:1489,y:957,t:1528139912627};\\\", \\\"{x:1489,y:955,t:1528139912639};\\\", \\\"{x:1488,y:952,t:1528139912656};\\\", \\\"{x:1488,y:950,t:1528139912672};\\\", \\\"{x:1488,y:946,t:1528139912690};\\\", \\\"{x:1487,y:942,t:1528139912705};\\\", \\\"{x:1487,y:938,t:1528139912723};\\\", \\\"{x:1487,y:933,t:1528139912739};\\\", \\\"{x:1487,y:930,t:1528139912756};\\\", \\\"{x:1487,y:928,t:1528139912772};\\\", \\\"{x:1487,y:924,t:1528139912790};\\\", \\\"{x:1487,y:919,t:1528139912806};\\\", \\\"{x:1487,y:915,t:1528139912822};\\\", \\\"{x:1487,y:911,t:1528139912839};\\\", \\\"{x:1487,y:908,t:1528139912857};\\\", \\\"{x:1487,y:903,t:1528139912873};\\\", \\\"{x:1487,y:900,t:1528139912889};\\\", \\\"{x:1487,y:895,t:1528139912907};\\\", \\\"{x:1487,y:889,t:1528139912923};\\\", \\\"{x:1487,y:881,t:1528139912939};\\\", \\\"{x:1487,y:875,t:1528139912956};\\\", \\\"{x:1486,y:870,t:1528139912972};\\\", \\\"{x:1485,y:866,t:1528139912989};\\\", \\\"{x:1485,y:863,t:1528139913007};\\\", \\\"{x:1485,y:861,t:1528139913022};\\\", \\\"{x:1485,y:859,t:1528139913040};\\\", \\\"{x:1485,y:858,t:1528139913056};\\\", \\\"{x:1485,y:857,t:1528139913072};\\\", \\\"{x:1484,y:856,t:1528139913089};\\\", \\\"{x:1484,y:854,t:1528139913107};\\\", \\\"{x:1484,y:853,t:1528139913123};\\\", \\\"{x:1484,y:851,t:1528139913140};\\\", \\\"{x:1484,y:850,t:1528139913156};\\\", \\\"{x:1484,y:848,t:1528139913172};\\\", \\\"{x:1484,y:847,t:1528139913189};\\\", \\\"{x:1484,y:845,t:1528139913206};\\\", \\\"{x:1484,y:842,t:1528139913222};\\\", \\\"{x:1484,y:841,t:1528139913239};\\\", \\\"{x:1484,y:840,t:1528139913256};\\\", \\\"{x:1484,y:839,t:1528139913272};\\\", \\\"{x:1484,y:838,t:1528139913289};\\\", \\\"{x:1484,y:836,t:1528139913307};\\\", \\\"{x:1484,y:834,t:1528139913324};\\\", \\\"{x:1484,y:833,t:1528139913339};\\\", \\\"{x:1484,y:832,t:1528139913363};\\\", \\\"{x:1484,y:830,t:1528139913516};\\\", \\\"{x:1474,y:830,t:1528139916640};\\\", \\\"{x:1449,y:830,t:1528139916646};\\\", \\\"{x:1401,y:826,t:1528139916661};\\\", \\\"{x:1203,y:796,t:1528139916678};\\\", \\\"{x:1034,y:776,t:1528139916696};\\\", \\\"{x:859,y:761,t:1528139916712};\\\", \\\"{x:722,y:755,t:1528139916728};\\\", \\\"{x:625,y:743,t:1528139916745};\\\", \\\"{x:566,y:735,t:1528139916761};\\\", \\\"{x:551,y:733,t:1528139916778};\\\", \\\"{x:550,y:733,t:1528139916796};\\\", \\\"{x:550,y:731,t:1528139916847};\\\", \\\"{x:545,y:725,t:1528139916861};\\\", \\\"{x:536,y:700,t:1528139916878};\\\", \\\"{x:531,y:670,t:1528139916896};\\\", \\\"{x:529,y:610,t:1528139916912};\\\", \\\"{x:529,y:497,t:1528139916928};\\\", \\\"{x:570,y:385,t:1528139916945};\\\", \\\"{x:613,y:326,t:1528139916962};\\\", \\\"{x:645,y:292,t:1528139916979};\\\", \\\"{x:678,y:277,t:1528139916996};\\\", \\\"{x:697,y:270,t:1528139917011};\\\", \\\"{x:698,y:269,t:1528139917029};\\\", \\\"{x:698,y:271,t:1528139917094};\\\", \\\"{x:700,y:281,t:1528139917112};\\\", \\\"{x:701,y:290,t:1528139917128};\\\", \\\"{x:701,y:303,t:1528139917145};\\\", \\\"{x:701,y:321,t:1528139917162};\\\", \\\"{x:701,y:339,t:1528139917179};\\\", \\\"{x:701,y:358,t:1528139917196};\\\", \\\"{x:701,y:384,t:1528139917212};\\\", \\\"{x:694,y:408,t:1528139917229};\\\", \\\"{x:689,y:427,t:1528139917246};\\\", \\\"{x:681,y:455,t:1528139917262};\\\", \\\"{x:676,y:473,t:1528139917278};\\\", \\\"{x:671,y:490,t:1528139917296};\\\", \\\"{x:666,y:508,t:1528139917314};\\\", \\\"{x:665,y:521,t:1528139917328};\\\", \\\"{x:662,y:535,t:1528139917345};\\\", \\\"{x:659,y:550,t:1528139917363};\\\", \\\"{x:656,y:557,t:1528139917380};\\\", \\\"{x:653,y:563,t:1528139917395};\\\", \\\"{x:652,y:565,t:1528139917412};\\\", \\\"{x:647,y:567,t:1528139917429};\\\", \\\"{x:643,y:569,t:1528139917446};\\\", \\\"{x:638,y:570,t:1528139917464};\\\", \\\"{x:633,y:570,t:1528139917480};\\\", \\\"{x:628,y:570,t:1528139917496};\\\", \\\"{x:622,y:570,t:1528139917513};\\\", \\\"{x:617,y:571,t:1528139917530};\\\", \\\"{x:614,y:572,t:1528139917547};\\\", \\\"{x:612,y:573,t:1528139917563};\\\", \\\"{x:611,y:574,t:1528139917580};\\\", \\\"{x:610,y:575,t:1528139917598};\\\", \\\"{x:610,y:577,t:1528139917640};\\\", \\\"{x:610,y:578,t:1528139917646};\\\", \\\"{x:610,y:579,t:1528139917663};\\\", \\\"{x:610,y:581,t:1528139917680};\\\", \\\"{x:610,y:582,t:1528139917710};\\\", \\\"{x:609,y:583,t:1528139917950};\\\", \\\"{x:601,y:583,t:1528139917963};\\\", \\\"{x:581,y:583,t:1528139917981};\\\", \\\"{x:555,y:583,t:1528139917997};\\\", \\\"{x:534,y:587,t:1528139918013};\\\", \\\"{x:530,y:589,t:1528139918030};\\\", \\\"{x:528,y:589,t:1528139918047};\\\", \\\"{x:526,y:589,t:1528139918358};\\\", \\\"{x:524,y:589,t:1528139918365};\\\", \\\"{x:520,y:589,t:1528139918382};\\\", \\\"{x:510,y:589,t:1528139918397};\\\", \\\"{x:469,y:589,t:1528139918416};\\\", \\\"{x:447,y:589,t:1528139918430};\\\", \\\"{x:427,y:586,t:1528139918447};\\\", \\\"{x:410,y:584,t:1528139918464};\\\", \\\"{x:400,y:583,t:1528139918479};\\\", \\\"{x:393,y:582,t:1528139918497};\\\", \\\"{x:390,y:582,t:1528139918514};\\\", \\\"{x:384,y:582,t:1528139918530};\\\", \\\"{x:379,y:582,t:1528139918547};\\\", \\\"{x:377,y:582,t:1528139918564};\\\", \\\"{x:376,y:582,t:1528139918580};\\\", \\\"{x:375,y:582,t:1528139918597};\\\", \\\"{x:375,y:580,t:1528139918797};\\\", \\\"{x:380,y:590,t:1528139918814};\\\", \\\"{x:391,y:608,t:1528139918831};\\\", \\\"{x:405,y:634,t:1528139918847};\\\", \\\"{x:431,y:676,t:1528139918864};\\\", \\\"{x:460,y:720,t:1528139918881};\\\", \\\"{x:482,y:758,t:1528139918897};\\\", \\\"{x:499,y:786,t:1528139918914};\\\", \\\"{x:508,y:800,t:1528139918931};\\\", \\\"{x:512,y:807,t:1528139918947};\\\", \\\"{x:514,y:806,t:1528139919070};\\\", \\\"{x:514,y:801,t:1528139919083};\\\", \\\"{x:516,y:790,t:1528139919097};\\\", \\\"{x:518,y:778,t:1528139919114};\\\", \\\"{x:519,y:764,t:1528139919131};\\\", \\\"{x:521,y:759,t:1528139919148};\\\", \\\"{x:521,y:756,t:1528139919164};\\\", \\\"{x:522,y:756,t:1528139919942};\\\" ] }, { \\\"rt\\\": 95341, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 699308, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"On the x-axis, find 12. Then find the horizontal line going upwards to the left (like a positive slope) connected to 12 on the x-axis. All points on this line start at 12.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7743, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 708058, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 7197, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Humanities\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 716273, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 17316, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 734895, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"1N65C\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"1N65C\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 1278, dom: 1651, initialDom: 1714",
  "javascriptErrors": []
}