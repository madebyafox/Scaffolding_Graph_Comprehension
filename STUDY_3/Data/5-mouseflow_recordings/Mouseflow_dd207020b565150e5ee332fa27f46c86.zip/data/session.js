var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "dd207020b565150e5ee332fa27f46c86",
  "created": "2018-05-21T10:11:14.7758102-07:00",
  "lastActivity": "2018-05-21T10:11:31.5548102-07:00",
  "pageViews": [
    {
      "id": "0521145553dc83a38c4e3c2ebfc51078fac01e6f",
      "startTime": "2018-05-21T10:11:14.7758102-07:00",
      "endTime": "2018-05-21T10:11:31.5548102-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 16779,
      "engagementTime": 16779,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 16779,
  "engagementTime": 16779,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DOQRP",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d2001f9e751b02533e61255dc6738b2c",
  "gdpr": false
}