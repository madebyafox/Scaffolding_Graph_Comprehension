var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b5028ab3cd3b06a3e07f5c30b7461818",
  "created": "2018-05-24T12:10:31.9341986-07:00",
  "lastActivity": "2018-05-24T12:10:41.6977315-07:00",
  "pageViews": [
    {
      "id": "05243157f830bf5a29e1882ae4c2039ee0b58c93",
      "startTime": "2018-05-24T12:10:31.9509991-07:00",
      "endTime": "2018-05-24T12:10:41.6977315-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 9873,
      "engagementTime": 9830,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 9873,
  "engagementTime": 9830,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=XKNWZ",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "99f337814e5af7531006e73b605f3fc1",
  "gdpr": false
}