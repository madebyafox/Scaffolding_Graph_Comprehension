var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0ca4db4c531b798e85f69e4f505c074e",
  "created": "2018-05-29T10:05:34.880488-07:00",
  "lastActivity": "2018-05-29T10:06:02.688488-07:00",
  "pageViews": [
    {
      "id": "052935794adc627e4228b08dcc3bb8f4e8dd8bc4",
      "startTime": "2018-05-29T10:05:34.880488-07:00",
      "endTime": "2018-05-29T10:06:02.688488-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 27808,
      "engagementTime": 27710,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 27808,
  "engagementTime": 27710,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=AZKMW",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "06f73e5da162a5e776b2ca01a07b50b1",
  "gdpr": false
}