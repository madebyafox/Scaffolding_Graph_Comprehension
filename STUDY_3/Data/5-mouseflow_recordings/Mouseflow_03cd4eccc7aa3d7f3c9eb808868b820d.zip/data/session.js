var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "03cd4eccc7aa3d7f3c9eb808868b820d",
  "created": "2018-05-21T09:08:35.8544564-07:00",
  "lastActivity": "2018-05-21T09:08:48.8593596-07:00",
  "pageViews": [
    {
      "id": "05213529032f91c77b21aeab7e300d5d060a4f50",
      "startTime": "2018-05-21T09:08:36.0263603-07:00",
      "endTime": "2018-05-21T09:08:48.8593596-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 12942,
      "engagementTime": 12942,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 12942,
  "engagementTime": 12942,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=781AU",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2cf9a9e706c21d076bfa7c5dfb7518ad",
  "gdpr": false
}