var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2191eb325a12b6103c8b3f7a261fc993",
  "created": "2018-05-29T12:10:47.7023667-07:00",
  "lastActivity": "2018-05-29T12:11:16.1174797-07:00",
  "pageViews": [
    {
      "id": "052947239db9d3afebd8a130cc3da2eb8c608a1c",
      "startTime": "2018-05-29T12:10:47.8694797-07:00",
      "endTime": "2018-05-29T12:11:16.1174797-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 28248,
      "engagementTime": 28248,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 28248,
  "engagementTime": 28248,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=BWVFU",
    "CONDITION=114\n114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a0bd5c368921150089c684875f196ca2",
  "gdpr": false
}