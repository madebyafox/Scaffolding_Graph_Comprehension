var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6395bc2968a00cda05d6974cc6deecf1",
  "created": "2018-05-25T09:19:11.2204224-07:00",
  "lastActivity": "2018-05-25T09:19:32.5585498-07:00",
  "pageViews": [
    {
      "id": "05251154da61a7cbd4703d7e8c7b0dfb27127a65",
      "startTime": "2018-05-25T09:19:11.4733062-07:00",
      "endTime": "2018-05-25T09:19:32.5585498-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 21227,
      "engagementTime": 16877,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 21227,
  "engagementTime": 16877,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MW3RC",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6644d910c4bd484911d5a03d408248e1",
  "gdpr": false
}