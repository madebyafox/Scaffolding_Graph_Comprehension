var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f5058e2722fdb89aa8cfa472ce3a1f36",
  "created": "2018-05-25T10:19:48.2501111-07:00",
  "lastActivity": "2018-05-25T10:20:10.2831818-07:00",
  "pageViews": [
    {
      "id": "05254871293aa348506718ee3b4c6cd390be85eb",
      "startTime": "2018-05-25T10:19:48.2851818-07:00",
      "endTime": "2018-05-25T10:20:10.2831818-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 21998,
      "engagementTime": 16544,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 21998,
  "engagementTime": 16544,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=YC7SX",
    "CONDITION=115-late",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "370c1bc6ea2596ec033b353a1735a553",
  "gdpr": false
}