var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "98e4f2db1eed9846808102eb372dd3db",
  "created": "2018-06-01T11:11:03.6816707-07:00",
  "lastActivity": "2018-06-01T11:11:35.8859943-07:00",
  "pageViews": [
    {
      "id": "06010339ac60ce85fb603e69074e9956c292036f",
      "startTime": "2018-06-01T11:11:03.717909-07:00",
      "endTime": "2018-06-01T11:11:35.8859943-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 32180,
      "engagementTime": 32080,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 32180,
  "engagementTime": 32080,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=AG2V3",
    "CONDITION=311",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d0cc96f5bb8e872e1f66f0e2622dfafa",
  "gdpr": false
}