var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9bc645ed3805dc006a078ddb6a4271e7",
  "created": "2018-05-29T15:18:24.8178608-07:00",
  "lastActivity": "2018-05-29T15:20:54.8953804-07:00",
  "pageViews": [
    {
      "id": "0529240828c68a9c8df0c2a7f6525553bf8271d6",
      "startTime": "2018-05-29T15:18:24.8178608-07:00",
      "endTime": "2018-05-29T15:20:54.8953804-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 150090,
      "engagementTime": 149458,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 150090,
  "engagementTime": 149458,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=9PKA7",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "fdb43adf0d866188ac191ac5c7b94922",
  "gdpr": false
}