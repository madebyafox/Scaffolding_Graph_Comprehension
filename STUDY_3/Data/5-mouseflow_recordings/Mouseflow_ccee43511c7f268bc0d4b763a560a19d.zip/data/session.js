var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ccee43511c7f268bc0d4b763a560a19d",
  "created": "2018-05-25T11:15:58.8900747-07:00",
  "lastActivity": "2018-05-25T11:17:01.3214893-07:00",
  "pageViews": [
    {
      "id": "05255858b161ce830074965fac4ff4bb3a55f33d",
      "startTime": "2018-05-25T11:15:58.9044893-07:00",
      "endTime": "2018-05-25T11:17:01.3214893-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 62417,
      "engagementTime": 59951,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 62417,
  "engagementTime": 59951,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=5ZEGW",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3bd33a34ed714bbd60b0ecff54217b08",
  "gdpr": false
}