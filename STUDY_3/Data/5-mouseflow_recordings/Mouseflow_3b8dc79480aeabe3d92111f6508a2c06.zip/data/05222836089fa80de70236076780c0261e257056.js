var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05222836089fa80de70236076780c0261e257056"] = {
  "startTime": "2018-05-22T20:17:28.0069208Z",
  "websitePageUrl": "/16",
  "visitTime": 99658,
  "engagementTime": 86909,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "3b8dc79480aeabe3d92111f6508a2c06",
    "created": "2018-05-22T20:17:27.8667158+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=DM4T0",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "e13cf9eb7dc61e7dc0d53514f72ca189",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/3b8dc79480aeabe3d92111f6508a2c06/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 232,
      "e": 232,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 232,
      "e": 232,
      "ty": 1,
      "x": 8,
      "y": 0
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 499,
      "y": 682
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 533,
      "y": 604
    },
    {
      "t": 913,
      "e": 913,
      "ty": 6,
      "x": 534,
      "y": 599,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 542,
      "y": 582
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 50011,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1188,
      "e": 1188,
      "ty": 3,
      "x": 542,
      "y": 582,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1188,
      "e": 1188,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1332,
      "e": 1332,
      "ty": 4,
      "x": 50011,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1333,
      "e": 1333,
      "ty": 5,
      "x": 542,
      "y": 582,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 587,
      "y": 597
    },
    {
      "t": 1915,
      "e": 1915,
      "ty": 7,
      "x": 660,
      "y": 639,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 955,
      "y": 823
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 11910,
      "y": 49061,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 1063,
      "y": 930
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 1177,
      "y": 993
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 31500,
      "y": 61738,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 1239,
      "y": 1000
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 1226,
      "y": 994
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 31006,
      "y": 61309,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 1169,
      "y": 984
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 1151,
      "y": 980
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 29270,
      "y": 45311,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 1148,
      "y": 965
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 1148,
      "y": 962
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 25510,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 1148,
      "y": 955
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 1148,
      "y": 949
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 25510,
      "y": 58014,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 1148,
      "y": 948
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 1146,
      "y": 928
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 2,
      "x": 1139,
      "y": 884
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 24876,
      "y": 53430,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3600,
      "e": 3600,
      "ty": 2,
      "x": 1128,
      "y": 820
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 1127,
      "y": 787
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 24030,
      "y": 45981,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 1127,
      "y": 773
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 1130,
      "y": 763
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 1131,
      "y": 759
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 24312,
      "y": 44477,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 1132,
      "y": 761
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 24382,
      "y": 44621,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4600,
      "e": 4600,
      "ty": 2,
      "x": 1136,
      "y": 761
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 1139,
      "y": 761
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 24946,
      "y": 44549,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1140,
      "y": 760
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1144,
      "y": 759
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 1146,
      "y": 753
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 25369,
      "y": 44048,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 666,
      "y": 639
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 485,
      "y": 607
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 43604,
      "y": 62883,
      "ta": "#.strategy"
    },
    {
      "t": 5365,
      "e": 5365,
      "ty": 6,
      "x": 495,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 501,
      "y": 601
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 507,
      "y": 598
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 41,
      "x": 46077,
      "y": 60895,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 509,
      "y": 597
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 46302,
      "y": 60086,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6273,
      "e": 6273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6417,
      "e": 6417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 6417,
      "e": 6417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6520,
      "e": 6520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 6535,
      "e": 6535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 6617,
      "e": 6617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 6617,
      "e": 6617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6688,
      "e": 6688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 6689,
      "e": 6689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6753,
      "e": 6753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 6824,
      "e": 6824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 6848,
      "e": 6848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 6849,
      "e": 6849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7004,
      "e": 7004,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Youo"
    },
    {
      "t": 7120,
      "e": 7120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Youo"
    },
    {
      "t": 7393,
      "e": 7393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 7473,
      "e": 7473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 7560,
      "e": 7560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 7608,
      "e": 7608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Yo"
    },
    {
      "t": 7688,
      "e": 7688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 7728,
      "e": 7728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 7816,
      "e": 7816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 7848,
      "e": 7848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 7936,
      "e": 7936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8024,
      "e": 8024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 8440,
      "e": 8440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8865,
      "e": 8865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 8865,
      "e": 8865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8943,
      "e": 8943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "E"
    },
    {
      "t": 8943,
      "e": 8943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "E"
    },
    {
      "t": 9121,
      "e": 9121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 9121,
      "e": 9121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9184,
      "e": 9184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 9185,
      "e": 9185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9248,
      "e": 9248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eve"
    },
    {
      "t": 9305,
      "e": 9305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 9305,
      "e": 9305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9312,
      "e": 9312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Even"
    },
    {
      "t": 9400,
      "e": 9400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9497,
      "e": 9497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9497,
      "e": 9497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9584,
      "e": 9584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 9584,
      "e": 9584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9624,
      "e": 9624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 9680,
      "e": 9680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9720,
      "e": 9720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9720,
      "e": 9720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9847,
      "e": 9847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9927,
      "e": 9927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9927,
      "e": 9927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10031,
      "e": 10031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 10031,
      "e": 10031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10047,
      "e": 10047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 10136,
      "e": 10136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10136,
      "e": 10136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10168,
      "e": 10168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10168,
      "e": 10168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10192,
      "e": 10192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 10248,
      "e": 10248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10248,
      "e": 10248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10260,
      "e": 10260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10288,
      "e": 10288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10368,
      "e": 10368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 10368,
      "e": 10368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10407,
      "e": 10407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 10448,
      "e": 10448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10448,
      "e": 10448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10472,
      "e": 10472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10552,
      "e": 10552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10553,
      "e": 10553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10560,
      "e": 10560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 10632,
      "e": 10632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 10632,
      "e": 10632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10696,
      "e": 10696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 10728,
      "e": 10728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10808,
      "e": 10808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10809,
      "e": 10809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10880,
      "e": 10880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10880,
      "e": 10880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10935,
      "e": 10935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 10952,
      "e": 10952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10952,
      "e": 10952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11000,
      "e": 11000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 11081,
      "e": 11081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11088,
      "e": 11088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11089,
      "e": 11089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11152,
      "e": 11152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11152,
      "e": 11152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11207,
      "e": 11207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 11240,
      "e": 11240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11657,
      "e": 11657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 11657,
      "e": 11657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11752,
      "e": 11752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 11872,
      "e": 11872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 11873,
      "e": 11873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11968,
      "e": 11968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 11968,
      "e": 11968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11976,
      "e": 11976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2p"
    },
    {
      "t": 12056,
      "e": 12056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12161,
      "e": 12161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 12161,
      "e": 12161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12247,
      "e": 12247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12248,
      "e": 12248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12304,
      "e": 12304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m "
    },
    {
      "t": 12327,
      "e": 12327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13200,
      "e": 13200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13239,
      "e": 13239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm"
    },
    {
      "t": 13327,
      "e": 13327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13384,
      "e": 13384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p"
    },
    {
      "t": 14048,
      "e": 14048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 14049,
      "e": 14049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14203,
      "e": 14203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p."
    },
    {
      "t": 14207,
      "e": 14207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 14224,
      "e": 14224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 14224,
      "e": 14224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14304,
      "e": 14304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 14304,
      "e": 14304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14335,
      "e": 14335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m."
    },
    {
      "t": 14440,
      "e": 14440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14696,
      "e": 14696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14736,
      "e": 14736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m"
    },
    {
      "t": 14768,
      "e": 14768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14951,
      "e": 14951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p."
    },
    {
      "t": 15040,
      "e": 15040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15088,
      "e": 15088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p"
    },
    {
      "t": 15202,
      "e": 15202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p"
    },
    {
      "t": 15792,
      "e": 15792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 15793,
      "e": 15793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16024,
      "e": 16024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 16112,
      "e": 16112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 16114,
      "e": 16114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16239,
      "e": 16239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 16240,
      "e": 16240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16256,
      "e": 16256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m."
    },
    {
      "t": 16335,
      "e": 16335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16336,
      "e": 16336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16351,
      "e": 16351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16456,
      "e": 16456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16632,
      "e": 16632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16655,
      "e": 16655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m."
    },
    {
      "t": 16803,
      "e": 16803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m."
    },
    {
      "t": 16888,
      "e": 16888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16889,
      "e": 16889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16959,
      "e": 16959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17039,
      "e": 17039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17095,
      "e": 17095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m."
    },
    {
      "t": 17199,
      "e": 17199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17272,
      "e": 17200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m"
    },
    {
      "t": 17280,
      "e": 17208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17280,
      "e": 17208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17351,
      "e": 17279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17351,
      "e": 17279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17399,
      "e": 17327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 17480,
      "e": 17408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 17480,
      "e": 17408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17495,
      "e": 17423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 17568,
      "e": 17496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17752,
      "e": 17680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17753,
      "e": 17681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17855,
      "e": 17783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 17887,
      "e": 17815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17888,
      "e": 17816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17968,
      "e": 17896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18112,
      "e": 18040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18113,
      "e": 18041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18152,
      "e": 18080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 18239,
      "e": 18167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18239,
      "e": 18167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18312,
      "e": 18240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 18425,
      "e": 18353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 18425,
      "e": 18353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18495,
      "e": 18423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18495,
      "e": 18423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18551,
      "e": 18479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 18592,
      "e": 18520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18623,
      "e": 18551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 18624,
      "e": 18552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18704,
      "e": 18632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18705,
      "e": 18633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18743,
      "e": 18671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 18879,
      "e": 18807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18888,
      "e": 18816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18888,
      "e": 18816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18960,
      "e": 18888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18960,
      "e": 18888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19024,
      "e": 18952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 19072,
      "e": 19000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19160,
      "e": 19088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 19161,
      "e": 19089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19255,
      "e": 19183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19255,
      "e": 19183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19263,
      "e": 19191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 19352,
      "e": 19280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 19352,
      "e": 19280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19384,
      "e": 19312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 19408,
      "e": 19336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19409,
      "e": 19337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19416,
      "e": 19344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 19504,
      "e": 19432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19504,
      "e": 19432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19512,
      "e": 19440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19575,
      "e": 19503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19776,
      "e": 19704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19847,
      "e": 19775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated wi"
    },
    {
      "t": 20023,
      "e": 19951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20079,
      "e": 20007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated w"
    },
    {
      "t": 20176,
      "e": 20104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20263,
      "e": 20191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated "
    },
    {
      "t": 20343,
      "e": 20271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 20344,
      "e": 20272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20440,
      "e": 20368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 20512,
      "e": 20440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 20513,
      "e": 20441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20640,
      "e": 20568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20640,
      "e": 20568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20664,
      "e": 20592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 20760,
      "e": 20688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20761,
      "e": 20689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20791,
      "e": 20719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20815,
      "e": 20743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20816,
      "e": 20744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20840,
      "e": 20768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 20961,
      "e": 20889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20968,
      "e": 20896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20971,
      "e": 20899,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21039,
      "e": 20967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21040,
      "e": 20968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21063,
      "e": 20991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 21152,
      "e": 21080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21624,
      "e": 21552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 21625,
      "e": 21553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21696,
      "e": 21624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 21704,
      "e": 21632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21705,
      "e": 21633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21807,
      "e": 21735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21808,
      "e": 21736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21816,
      "e": 21744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||la"
    },
    {
      "t": 21896,
      "e": 21824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21960,
      "e": 21888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 21961,
      "e": 21889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22072,
      "e": 22000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 22073,
      "e": 22001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22079,
      "e": 22007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ck"
    },
    {
      "t": 22184,
      "e": 22112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22192,
      "e": 22120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22192,
      "e": 22120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22280,
      "e": 22208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 22280,
      "e": 22208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22304,
      "e": 22232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| d"
    },
    {
      "t": 22377,
      "e": 22305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22377,
      "e": 22305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22383,
      "e": 22311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 22455,
      "e": 22383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22471,
      "e": 22399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 22471,
      "e": 22399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22559,
      "e": 22487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22559,
      "e": 22487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22583,
      "e": 22511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gs"
    },
    {
      "t": 22656,
      "e": 22584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22832,
      "e": 22760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22896,
      "e": 22761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dog"
    },
    {
      "t": 23002,
      "e": 22867,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dog"
    },
    {
      "t": 23007,
      "e": 22872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23055,
      "e": 22920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black do"
    },
    {
      "t": 23088,
      "e": 22953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23088,
      "e": 22953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23151,
      "e": 23016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23152,
      "e": 23017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23191,
      "e": 23056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 23247,
      "e": 23112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 23247,
      "e": 23112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23255,
      "e": 23120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 23352,
      "e": 23217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23352,
      "e": 23217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23367,
      "e": 23232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23407,
      "e": 23272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 23407,
      "e": 23272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23463,
      "e": 23328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 23519,
      "e": 23384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23520,
      "e": 23385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23520,
      "e": 23385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23583,
      "e": 23448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23584,
      "e": 23449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23624,
      "e": 23489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 23672,
      "e": 23537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 23674,
      "e": 23539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23687,
      "e": 23552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 23759,
      "e": 23624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23760,
      "e": 23625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23807,
      "e": 23672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 23831,
      "e": 23696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23831,
      "e": 23696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23872,
      "e": 23737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23935,
      "e": 23800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23968,
      "e": 23833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 23969,
      "e": 23834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24128,
      "e": 23993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 24128,
      "e": 23993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24136,
      "e": 24001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||cy"
    },
    {
      "t": 24280,
      "e": 24145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24663,
      "e": 24528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24728,
      "e": 24593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dots, which c"
    },
    {
      "t": 24800,
      "e": 24665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24863,
      "e": 24728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dots, which "
    },
    {
      "t": 24864,
      "e": 24729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 24864,
      "e": 24729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24959,
      "e": 24824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 25007,
      "e": 24872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 25007,
      "e": 24872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25119,
      "e": 24984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 25256,
      "e": 25121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 25256,
      "e": 25121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25335,
      "e": 25200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 25335,
      "e": 25200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25367,
      "e": 25232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||mb"
    },
    {
      "t": 25423,
      "e": 25288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25432,
      "e": 25297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25432,
      "e": 25297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25512,
      "e": 25377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25608,
      "e": 25473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25609,
      "e": 25474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25695,
      "e": 25560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25695,
      "e": 25560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25751,
      "e": 25616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 25759,
      "e": 25624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 25760,
      "e": 25625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25832,
      "e": 25697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 25887,
      "e": 25752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25944,
      "e": 25809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25945,
      "e": 25810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26039,
      "e": 25904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26039,
      "e": 25904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26056,
      "e": 25921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 26111,
      "e": 25976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26184,
      "e": 26049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 26185,
      "e": 26050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26248,
      "e": 26113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 26344,
      "e": 26209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26344,
      "e": 26209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26416,
      "e": 26281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26432,
      "e": 26297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 26432,
      "e": 26297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26576,
      "e": 26441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 26801,
      "e": 26666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26802,
      "e": 26667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26848,
      "e": 26713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27223,
      "e": 27088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27225,
      "e": 27090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27264,
      "e": 27129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 27352,
      "e": 27217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27353,
      "e": 27218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27431,
      "e": 27296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 27503,
      "e": 27368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27504,
      "e": 27369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27552,
      "e": 27370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27624,
      "e": 27442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27624,
      "e": 27442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27703,
      "e": 27521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 27703,
      "e": 27521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27743,
      "e": 27561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27743,
      "e": 27561,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27767,
      "e": 27585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng "
    },
    {
      "t": 27775,
      "e": 27593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27912,
      "e": 27730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27913,
      "e": 27731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27919,
      "e": 27737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27983,
      "e": 27801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27983,
      "e": 27801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28023,
      "e": 27841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 28032,
      "e": 27850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28128,
      "e": 27946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 28128,
      "e": 27946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28207,
      "e": 28025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28207,
      "e": 28025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28247,
      "e": 28065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||me"
    },
    {
      "t": 28295,
      "e": 28113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28403,
      "e": 28221,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dots, which symbolize beginning time"
    },
    {
      "t": 28424,
      "e": 28242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 28425,
      "e": 28243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28522,
      "e": 28340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28522,
      "e": 28340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28570,
      "e": 28388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||. "
    },
    {
      "t": 28602,
      "e": 28420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33003,
      "e": 32821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 33130,
      "e": 32948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33131,
      "e": 32949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33251,
      "e": 33069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 33259,
      "e": 33077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33307,
      "e": 33125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33308,
      "e": 33126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33379,
      "e": 33197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33474,
      "e": 33292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 33475,
      "e": 33293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33603,
      "e": 33421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 33611,
      "e": 33429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 33611,
      "e": 33429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33690,
      "e": 33508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 33806,
      "e": 33624,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dots, which symbolize beginning time. Simp"
    },
    {
      "t": 33810,
      "e": 33628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 33810,
      "e": 33628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33834,
      "e": 33652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 33834,
      "e": 33652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33954,
      "e": 33772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ly"
    },
    {
      "t": 33961,
      "e": 33779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33962,
      "e": 33780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34002,
      "e": 33820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34042,
      "e": 33860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34091,
      "e": 33909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 34091,
      "e": 33909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34162,
      "e": 33980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 34267,
      "e": 34085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34268,
      "e": 34086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34406,
      "e": 34224,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dots, which symbolize beginning time. Simply lo"
    },
    {
      "t": 34418,
      "e": 34236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 34507,
      "e": 34325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 34507,
      "e": 34325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34594,
      "e": 34412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34595,
      "e": 34413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34643,
      "e": 34461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 34714,
      "e": 34532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34819,
      "e": 34637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34820,
      "e": 34638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34931,
      "e": 34749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34932,
      "e": 34750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34986,
      "e": 34804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 35002,
      "e": 34820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35002,
      "e": 34820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35042,
      "e": 34860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35130,
      "e": 34948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35131,
      "e": 34949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35179,
      "e": 34997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 35218,
      "e": 35036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35220,
      "e": 35038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35235,
      "e": 35053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 35306,
      "e": 35124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35362,
      "e": 35180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35363,
      "e": 35181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35418,
      "e": 35236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35419,
      "e": 35237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35467,
      "e": 35285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 35523,
      "e": 35341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35675,
      "e": 35493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 35676,
      "e": 35494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35809,
      "e": 35496,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dots, which symbolize beginning time. Simply locate the l"
    },
    {
      "t": 35812,
      "e": 35499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36011,
      "e": 35698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36082,
      "e": 35769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dots, which symbolize beginning time. Simply locate the "
    },
    {
      "t": 36122,
      "e": 35809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 36122,
      "e": 35809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36194,
      "e": 35881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 36275,
      "e": 35962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36276,
      "e": 35963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36371,
      "e": 36058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36379,
      "e": 36066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36380,
      "e": 36067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36523,
      "e": 36210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 36523,
      "e": 36210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36538,
      "e": 36225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ac"
    },
    {
      "t": 36602,
      "e": 36289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 36602,
      "e": 36289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36618,
      "e": 36305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 36690,
      "e": 36377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36699,
      "e": 36386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36699,
      "e": 36386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36794,
      "e": 36481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36802,
      "e": 36489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 36804,
      "e": 36491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36874,
      "e": 36561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 36883,
      "e": 36570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 36883,
      "e": 36570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36986,
      "e": 36673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 37034,
      "e": 36721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37035,
      "e": 36722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37123,
      "e": 36810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37124,
      "e": 36811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37154,
      "e": 36841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 37242,
      "e": 36929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37555,
      "e": 37242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37555,
      "e": 37242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37650,
      "e": 37337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37666,
      "e": 37353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37666,
      "e": 37353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37730,
      "e": 37417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37730,
      "e": 37417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37803,
      "e": 37490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37803,
      "e": 37490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37818,
      "e": 37505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hat"
    },
    {
      "t": 37858,
      "e": 37545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37859,
      "e": 37546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37898,
      "e": 37585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37938,
      "e": 37625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37970,
      "e": 37657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38091,
      "e": 37778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 38092,
      "e": 37779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38186,
      "e": 37873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38186,
      "e": 37873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38210,
      "e": 37897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 38218,
      "e": 37905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38218,
      "e": 37905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38274,
      "e": 37961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38339,
      "e": 38026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43323,
      "e": 43010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 43323,
      "e": 43010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43403,
      "e": 43090,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 43539,
      "e": 43226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43539,
      "e": 43226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43610,
      "e": 43297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 43610,
      "e": 43297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43666,
      "e": 43353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 43674,
      "e": 43361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43738,
      "e": 43425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43739,
      "e": 43426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43810,
      "e": 43497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43810,
      "e": 43497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43826,
      "e": 43513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 43890,
      "e": 43577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43946,
      "e": 43633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 43947,
      "e": 43634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44034,
      "e": 43721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 44090,
      "e": 43777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 44090,
      "e": 43777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44130,
      "e": 43817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 44219,
      "e": 43906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44219,
      "e": 43906,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44314,
      "e": 44001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 44635,
      "e": 44322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44682,
      "e": 44369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dots, which symbolize beginning time. Simply locate the black dot that is verticl"
    },
    {
      "t": 44762,
      "e": 44449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44811,
      "e": 44450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dots, which symbolize beginning time. Simply locate the black dot that is vertic"
    },
    {
      "t": 44842,
      "e": 44481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44842,
      "e": 44481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44963,
      "e": 44602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 44979,
      "e": 44618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 44979,
      "e": 44618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45082,
      "e": 44721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45082,
      "e": 44721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45122,
      "e": 44761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 45154,
      "e": 44793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45154,
      "e": 44793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45186,
      "e": 44825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45242,
      "e": 44881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 45243,
      "e": 44882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45251,
      "e": 44890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 45331,
      "e": 44970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45331,
      "e": 44970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45346,
      "e": 44985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45395,
      "e": 45034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45395,
      "e": 45034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45434,
      "e": 45073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45482,
      "e": 45121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45859,
      "e": 45498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45930,
      "e": 45569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dots, which symbolize beginning time. Simply locate the black dot that is vertical to "
    },
    {
      "t": 46114,
      "e": 45753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46116,
      "e": 45755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46194,
      "e": 45833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 46194,
      "e": 45833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46217,
      "e": 45856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 46314,
      "e": 45953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 46315,
      "e": 45954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46330,
      "e": 45969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 46403,
      "e": 46042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46403,
      "e": 46042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46442,
      "e": 46081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46514,
      "e": 46153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46916,
      "e": 46555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46916,
      "e": 46555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47010,
      "e": 46649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 47010,
      "e": 46649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47058,
      "e": 46697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 47074,
      "e": 46713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47186,
      "e": 46825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 47187,
      "e": 46826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47250,
      "e": 46889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47250,
      "e": 46889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47290,
      "e": 46929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||me"
    },
    {
      "t": 47330,
      "e": 46969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47330,
      "e": 46969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47338,
      "e": 46977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47418,
      "e": 47057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 47467,
      "e": 47106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47483,
      "e": 47122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "222"
    },
    {
      "t": 47483,
      "e": 47122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47570,
      "e": 47209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\""
    },
    {
      "t": 47602,
      "e": 47241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47716,
      "e": 47355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 47718,
      "e": 47357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47794,
      "e": 47433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 47906,
      "e": 47545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 47907,
      "e": 47546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48009,
      "e": 47648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 48435,
      "e": 48074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48436,
      "e": 48075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48522,
      "e": 48161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 48578,
      "e": 48217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48618,
      "e": 48257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 48618,
      "e": 48257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48691,
      "e": 48330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 48786,
      "e": 48425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 48787,
      "e": 48426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48882,
      "e": 48521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 48978,
      "e": 48617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "222"
    },
    {
      "t": 48979,
      "e": 48618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49091,
      "e": 48730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\""
    },
    {
      "t": 49099,
      "e": 48738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49218,
      "e": 48857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49219,
      "e": 48858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49331,
      "e": 48970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50004,
      "e": 49643,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50088,
      "e": 49727,
      "ty": 7,
      "x": 486,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50104,
      "e": 49743,
      "ty": 2,
      "x": 486,
      "y": 606
    },
    {
      "t": 50172,
      "e": 49811,
      "ty": 6,
      "x": 417,
      "y": 664,
      "ta": "#strategyButton"
    },
    {
      "t": 50204,
      "e": 49843,
      "ty": 2,
      "x": 414,
      "y": 668
    },
    {
      "t": 50255,
      "e": 49894,
      "ty": 41,
      "x": 40635,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 50304,
      "e": 49943,
      "ty": 2,
      "x": 413,
      "y": 670
    },
    {
      "t": 51146,
      "e": 50785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 51265,
      "e": 50904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51442,
      "e": 51081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 51546,
      "e": 51185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51979,
      "e": 51618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 51979,
      "e": 51618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52114,
      "e": 51753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dots, which symbolize beginning time. Simply locate the black dot that is vertical to the time \"12 PM.\" "
    },
    {
      "t": 52342,
      "e": 51981,
      "ty": 7,
      "x": 454,
      "y": 651,
      "ta": "#strategyButton"
    },
    {
      "t": 52404,
      "e": 52043,
      "ty": 2,
      "x": 553,
      "y": 608
    },
    {
      "t": 52504,
      "e": 52143,
      "ty": 2,
      "x": 557,
      "y": 606
    },
    {
      "t": 52505,
      "e": 52144,
      "ty": 41,
      "x": 51698,
      "y": 62323,
      "ta": "#.strategy"
    },
    {
      "t": 52604,
      "e": 52243,
      "ty": 2,
      "x": 495,
      "y": 624
    },
    {
      "t": 52705,
      "e": 52344,
      "ty": 2,
      "x": 472,
      "y": 630
    },
    {
      "t": 52754,
      "e": 52393,
      "ty": 41,
      "x": 41805,
      "y": 34567,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 52804,
      "e": 52443,
      "ty": 2,
      "x": 467,
      "y": 632
    },
    {
      "t": 52825,
      "e": 52464,
      "ty": 6,
      "x": 419,
      "y": 659,
      "ta": "#strategyButton"
    },
    {
      "t": 52841,
      "e": 52480,
      "ty": 7,
      "x": 377,
      "y": 696,
      "ta": "#strategyButton"
    },
    {
      "t": 52904,
      "e": 52543,
      "ty": 2,
      "x": 343,
      "y": 736
    },
    {
      "t": 53005,
      "e": 52644,
      "ty": 41,
      "x": 27642,
      "y": 40329,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 53104,
      "e": 52743,
      "ty": 2,
      "x": 355,
      "y": 716
    },
    {
      "t": 53158,
      "e": 52797,
      "ty": 6,
      "x": 384,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 53204,
      "e": 52843,
      "ty": 2,
      "x": 388,
      "y": 684
    },
    {
      "t": 53223,
      "e": 52862,
      "ty": 3,
      "x": 388,
      "y": 684,
      "ta": "#strategyButton"
    },
    {
      "t": 53223,
      "e": 52862,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p.m are indicated by the black dots, which symbolize beginning time. Simply locate the black dot that is vertical to the time \"12 PM.\" "
    },
    {
      "t": 53224,
      "e": 52863,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53225,
      "e": 52864,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 53254,
      "e": 52893,
      "ty": 41,
      "x": 26981,
      "y": 56409,
      "ta": "#strategyButton"
    },
    {
      "t": 53327,
      "e": 52966,
      "ty": 4,
      "x": 26981,
      "y": 56409,
      "ta": "#strategyButton"
    },
    {
      "t": 53344,
      "e": 52983,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 53346,
      "e": 52985,
      "ty": 5,
      "x": 388,
      "y": 684,
      "ta": "#strategyButton"
    },
    {
      "t": 53354,
      "e": 52993,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 54352,
      "e": 53991,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 54904,
      "e": 54543,
      "ty": 2,
      "x": 550,
      "y": 641
    },
    {
      "t": 55005,
      "e": 54644,
      "ty": 2,
      "x": 797,
      "y": 591
    },
    {
      "t": 55005,
      "e": 54644,
      "ty": 41,
      "x": 27171,
      "y": 32296,
      "ta": "html > body"
    },
    {
      "t": 55103,
      "e": 54742,
      "ty": 2,
      "x": 814,
      "y": 587
    },
    {
      "t": 55204,
      "e": 54843,
      "ty": 2,
      "x": 814,
      "y": 586
    },
    {
      "t": 55255,
      "e": 54894,
      "ty": 41,
      "x": 1946,
      "y": 0,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 55293,
      "e": 54932,
      "ty": 6,
      "x": 835,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55304,
      "e": 54943,
      "ty": 2,
      "x": 835,
      "y": 570
    },
    {
      "t": 55343,
      "e": 54982,
      "ty": 3,
      "x": 841,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55343,
      "e": 54982,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55404,
      "e": 55043,
      "ty": 2,
      "x": 841,
      "y": 566
    },
    {
      "t": 55454,
      "e": 55093,
      "ty": 4,
      "x": 7137,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55455,
      "e": 55094,
      "ty": 5,
      "x": 841,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55505,
      "e": 55144,
      "ty": 41,
      "x": 7137,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56163,
      "e": 55802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 56163,
      "e": 55802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56274,
      "e": 55913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 56283,
      "e": 55922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 56283,
      "e": 55922,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56406,
      "e": 56045,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 56410,
      "e": 56049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 56547,
      "e": 56186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 56547,
      "e": 56186,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 56548,
      "e": 56187,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56550,
      "e": 56189,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56690,
      "e": 56329,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 57203,
      "e": 56842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 57522,
      "e": 57161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 57522,
      "e": 57161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57627,
      "e": 57266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 58131,
      "e": 57770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 58235,
      "e": 57874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 58634,
      "e": 58273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 58636,
      "e": 58275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58689,
      "e": 58328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 58689,
      "e": 58328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58777,
      "e": 58416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 58793,
      "e": 58432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 58915,
      "e": 58554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 58915,
      "e": 58554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59001,
      "e": 58640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 59066,
      "e": 58705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 59631,
      "e": 59270,
      "ty": 7,
      "x": 849,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59662,
      "e": 59301,
      "ty": 6,
      "x": 869,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59680,
      "e": 59319,
      "ty": 7,
      "x": 877,
      "y": 689,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59703,
      "e": 59342,
      "ty": 2,
      "x": 886,
      "y": 710
    },
    {
      "t": 59754,
      "e": 59343,
      "ty": 41,
      "x": 30718,
      "y": 40495,
      "ta": "html > body"
    },
    {
      "t": 59803,
      "e": 59392,
      "ty": 2,
      "x": 901,
      "y": 740
    },
    {
      "t": 59903,
      "e": 59492,
      "ty": 2,
      "x": 906,
      "y": 737
    },
    {
      "t": 60004,
      "e": 59593,
      "ty": 2,
      "x": 931,
      "y": 716
    },
    {
      "t": 60004,
      "e": 59593,
      "ty": 41,
      "x": 31786,
      "y": 39221,
      "ta": "html > body"
    },
    {
      "t": 60104,
      "e": 59693,
      "ty": 2,
      "x": 932,
      "y": 715
    },
    {
      "t": 60203,
      "e": 59792,
      "ty": 2,
      "x": 934,
      "y": 710
    },
    {
      "t": 60253,
      "e": 59842,
      "ty": 41,
      "x": 31889,
      "y": 38833,
      "ta": "html > body"
    },
    {
      "t": 60303,
      "e": 59892,
      "ty": 2,
      "x": 934,
      "y": 709
    },
    {
      "t": 60405,
      "e": 59994,
      "ty": 3,
      "x": 934,
      "y": 709,
      "ta": "html > body"
    },
    {
      "t": 60406,
      "e": 59995,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 60406,
      "e": 59995,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60534,
      "e": 60123,
      "ty": 4,
      "x": 31889,
      "y": 38833,
      "ta": "html > body"
    },
    {
      "t": 60534,
      "e": 60123,
      "ty": 5,
      "x": 934,
      "y": 709,
      "ta": "html > body"
    },
    {
      "t": 60615,
      "e": 60204,
      "ty": 6,
      "x": 934,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60704,
      "e": 60293,
      "ty": 2,
      "x": 946,
      "y": 699
    },
    {
      "t": 60751,
      "e": 60340,
      "ty": 3,
      "x": 947,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60751,
      "e": 60340,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60754,
      "e": 60343,
      "ty": 41,
      "x": 26325,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60803,
      "e": 60392,
      "ty": 2,
      "x": 947,
      "y": 698
    },
    {
      "t": 60878,
      "e": 60467,
      "ty": 4,
      "x": 26325,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60879,
      "e": 60468,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60880,
      "e": 60469,
      "ty": 5,
      "x": 947,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60880,
      "e": 60469,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 61901,
      "e": 61490,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 62504,
      "e": 62093,
      "ty": 2,
      "x": 860,
      "y": 631
    },
    {
      "t": 62504,
      "e": 62093,
      "ty": 41,
      "x": 9155,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 62603,
      "e": 62192,
      "ty": 2,
      "x": 804,
      "y": 578
    },
    {
      "t": 62704,
      "e": 62293,
      "ty": 2,
      "x": 965,
      "y": 425
    },
    {
      "t": 62754,
      "e": 62343,
      "ty": 41,
      "x": 47839,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 62803,
      "e": 62392,
      "ty": 2,
      "x": 1025,
      "y": 377
    },
    {
      "t": 62904,
      "e": 62493,
      "ty": 2,
      "x": 994,
      "y": 331
    },
    {
      "t": 63004,
      "e": 62593,
      "ty": 2,
      "x": 911,
      "y": 269
    },
    {
      "t": 63004,
      "e": 62593,
      "ty": 41,
      "x": 21259,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 63104,
      "e": 62693,
      "ty": 2,
      "x": 880,
      "y": 247
    },
    {
      "t": 63203,
      "e": 62792,
      "ty": 2,
      "x": 879,
      "y": 247
    },
    {
      "t": 63254,
      "e": 62843,
      "ty": 41,
      "x": 47148,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 63304,
      "e": 62893,
      "ty": 2,
      "x": 882,
      "y": 251
    },
    {
      "t": 63403,
      "e": 62992,
      "ty": 2,
      "x": 892,
      "y": 269
    },
    {
      "t": 63503,
      "e": 63092,
      "ty": 2,
      "x": 896,
      "y": 277
    },
    {
      "t": 63503,
      "e": 63092,
      "ty": 41,
      "x": 17699,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 63604,
      "e": 63193,
      "ty": 2,
      "x": 906,
      "y": 289
    },
    {
      "t": 63687,
      "e": 63276,
      "ty": 3,
      "x": 906,
      "y": 290,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 63704,
      "e": 63293,
      "ty": 2,
      "x": 906,
      "y": 291
    },
    {
      "t": 63754,
      "e": 63343,
      "ty": 41,
      "x": 26506,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 63789,
      "e": 63378,
      "ty": 4,
      "x": 26506,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 63790,
      "e": 63379,
      "ty": 5,
      "x": 906,
      "y": 291,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 63791,
      "e": 63380,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 63791,
      "e": 63380,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 63904,
      "e": 63493,
      "ty": 2,
      "x": 906,
      "y": 311
    },
    {
      "t": 64004,
      "e": 63593,
      "ty": 2,
      "x": 904,
      "y": 314
    },
    {
      "t": 64004,
      "e": 63593,
      "ty": 41,
      "x": 19597,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 64304,
      "e": 63893,
      "ty": 2,
      "x": 904,
      "y": 316
    },
    {
      "t": 64403,
      "e": 63992,
      "ty": 2,
      "x": 897,
      "y": 351
    },
    {
      "t": 64503,
      "e": 64092,
      "ty": 2,
      "x": 876,
      "y": 387
    },
    {
      "t": 64504,
      "e": 64093,
      "ty": 41,
      "x": 12952,
      "y": 8665,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 64604,
      "e": 64193,
      "ty": 2,
      "x": 871,
      "y": 399
    },
    {
      "t": 64704,
      "e": 64293,
      "ty": 2,
      "x": 869,
      "y": 404
    },
    {
      "t": 64754,
      "e": 64343,
      "ty": 41,
      "x": 11291,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 64830,
      "e": 64419,
      "ty": 3,
      "x": 869,
      "y": 404,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 64832,
      "e": 64421,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 64910,
      "e": 64499,
      "ty": 4,
      "x": 11291,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 64910,
      "e": 64499,
      "ty": 5,
      "x": 869,
      "y": 404,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 65104,
      "e": 64693,
      "ty": 2,
      "x": 869,
      "y": 413
    },
    {
      "t": 65203,
      "e": 64792,
      "ty": 2,
      "x": 888,
      "y": 468
    },
    {
      "t": 65254,
      "e": 64843,
      "ty": 41,
      "x": 18885,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 65304,
      "e": 64893,
      "ty": 2,
      "x": 905,
      "y": 512
    },
    {
      "t": 65403,
      "e": 64992,
      "ty": 2,
      "x": 919,
      "y": 552
    },
    {
      "t": 65504,
      "e": 65093,
      "ty": 2,
      "x": 895,
      "y": 510
    },
    {
      "t": 65504,
      "e": 65093,
      "ty": 41,
      "x": 17461,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 65604,
      "e": 65093,
      "ty": 2,
      "x": 860,
      "y": 440
    },
    {
      "t": 65703,
      "e": 65192,
      "ty": 2,
      "x": 858,
      "y": 425
    },
    {
      "t": 65754,
      "e": 65243,
      "ty": 41,
      "x": 42818,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 65804,
      "e": 65293,
      "ty": 2,
      "x": 858,
      "y": 423
    },
    {
      "t": 65904,
      "e": 65393,
      "ty": 2,
      "x": 863,
      "y": 408
    },
    {
      "t": 65919,
      "e": 65408,
      "ty": 3,
      "x": 863,
      "y": 408,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 66004,
      "e": 65493,
      "ty": 41,
      "x": 48671,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 66021,
      "e": 65510,
      "ty": 4,
      "x": 48671,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 66022,
      "e": 65511,
      "ty": 5,
      "x": 863,
      "y": 408,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 66022,
      "e": 65511,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 66023,
      "e": 65512,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 66203,
      "e": 65692,
      "ty": 2,
      "x": 874,
      "y": 446
    },
    {
      "t": 66253,
      "e": 65742,
      "ty": 41,
      "x": 17699,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 66304,
      "e": 65793,
      "ty": 2,
      "x": 925,
      "y": 562
    },
    {
      "t": 66404,
      "e": 65893,
      "ty": 2,
      "x": 951,
      "y": 635
    },
    {
      "t": 66503,
      "e": 65992,
      "ty": 2,
      "x": 953,
      "y": 653
    },
    {
      "t": 66504,
      "e": 65993,
      "ty": 41,
      "x": 31226,
      "y": 10290,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 66603,
      "e": 66092,
      "ty": 2,
      "x": 954,
      "y": 692
    },
    {
      "t": 66703,
      "e": 66192,
      "ty": 2,
      "x": 954,
      "y": 696
    },
    {
      "t": 66754,
      "e": 66243,
      "ty": 41,
      "x": 33407,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 66863,
      "e": 66352,
      "ty": 3,
      "x": 954,
      "y": 696,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 66863,
      "e": 66352,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 66966,
      "e": 66455,
      "ty": 4,
      "x": 33407,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 66966,
      "e": 66455,
      "ty": 5,
      "x": 954,
      "y": 696,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 66966,
      "e": 66455,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66966,
      "e": 66455,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 67204,
      "e": 66693,
      "ty": 2,
      "x": 955,
      "y": 709
    },
    {
      "t": 67254,
      "e": 66743,
      "ty": 41,
      "x": 31701,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 67304,
      "e": 66793,
      "ty": 2,
      "x": 955,
      "y": 726
    },
    {
      "t": 67404,
      "e": 66893,
      "ty": 2,
      "x": 955,
      "y": 737
    },
    {
      "t": 67503,
      "e": 66992,
      "ty": 2,
      "x": 944,
      "y": 774
    },
    {
      "t": 67503,
      "e": 66992,
      "ty": 41,
      "x": 29090,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 67604,
      "e": 67093,
      "ty": 2,
      "x": 919,
      "y": 932
    },
    {
      "t": 67704,
      "e": 67193,
      "ty": 2,
      "x": 918,
      "y": 1001
    },
    {
      "t": 67754,
      "e": 67243,
      "ty": 41,
      "x": 22920,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 68004,
      "e": 67493,
      "ty": 2,
      "x": 923,
      "y": 983
    },
    {
      "t": 68004,
      "e": 67493,
      "ty": 41,
      "x": 24107,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 68104,
      "e": 67593,
      "ty": 2,
      "x": 918,
      "y": 925
    },
    {
      "t": 68204,
      "e": 67693,
      "ty": 2,
      "x": 918,
      "y": 892
    },
    {
      "t": 68254,
      "e": 67743,
      "ty": 41,
      "x": 22920,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 68304,
      "e": 67793,
      "ty": 2,
      "x": 918,
      "y": 888
    },
    {
      "t": 68904,
      "e": 68393,
      "ty": 2,
      "x": 910,
      "y": 926
    },
    {
      "t": 69004,
      "e": 68493,
      "ty": 2,
      "x": 898,
      "y": 943
    },
    {
      "t": 69004,
      "e": 68493,
      "ty": 41,
      "x": 18173,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 69104,
      "e": 68593,
      "ty": 2,
      "x": 897,
      "y": 944
    },
    {
      "t": 69254,
      "e": 68743,
      "ty": 41,
      "x": 16987,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 69305,
      "e": 68794,
      "ty": 2,
      "x": 891,
      "y": 953
    },
    {
      "t": 69383,
      "e": 68872,
      "ty": 3,
      "x": 889,
      "y": 959,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 69385,
      "e": 68874,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 69403,
      "e": 68892,
      "ty": 2,
      "x": 889,
      "y": 959
    },
    {
      "t": 69486,
      "e": 68892,
      "ty": 4,
      "x": 54665,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 69487,
      "e": 68893,
      "ty": 5,
      "x": 889,
      "y": 959,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 69487,
      "e": 68893,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69488,
      "e": 68894,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 69504,
      "e": 68910,
      "ty": 41,
      "x": 54665,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 69604,
      "e": 69010,
      "ty": 2,
      "x": 891,
      "y": 973
    },
    {
      "t": 69704,
      "e": 69110,
      "ty": 2,
      "x": 900,
      "y": 1001
    },
    {
      "t": 69705,
      "e": 69111,
      "ty": 6,
      "x": 903,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69754,
      "e": 69160,
      "ty": 41,
      "x": 40498,
      "y": 15887,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69804,
      "e": 69210,
      "ty": 2,
      "x": 916,
      "y": 1025
    },
    {
      "t": 69879,
      "e": 69285,
      "ty": 3,
      "x": 921,
      "y": 1030,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69880,
      "e": 69286,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69880,
      "e": 69286,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69904,
      "e": 69310,
      "ty": 2,
      "x": 921,
      "y": 1030
    },
    {
      "t": 69974,
      "e": 69380,
      "ty": 4,
      "x": 47198,
      "y": 49647,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69974,
      "e": 69380,
      "ty": 5,
      "x": 921,
      "y": 1030,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69977,
      "e": 69383,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69977,
      "e": 69383,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 69978,
      "e": 69384,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 70004,
      "e": 69410,
      "ty": 41,
      "x": 31441,
      "y": 56616,
      "ta": "html > body"
    },
    {
      "t": 70504,
      "e": 69910,
      "ty": 2,
      "x": 908,
      "y": 1002
    },
    {
      "t": 70505,
      "e": 69911,
      "ty": 41,
      "x": 30993,
      "y": 55064,
      "ta": "html > body"
    },
    {
      "t": 70604,
      "e": 70010,
      "ty": 2,
      "x": 864,
      "y": 878
    },
    {
      "t": 70704,
      "e": 70110,
      "ty": 2,
      "x": 860,
      "y": 851
    },
    {
      "t": 70754,
      "e": 70160,
      "ty": 41,
      "x": 29340,
      "y": 46699,
      "ta": "html > body"
    },
    {
      "t": 71004,
      "e": 70410,
      "ty": 2,
      "x": 860,
      "y": 850
    },
    {
      "t": 71004,
      "e": 70410,
      "ty": 41,
      "x": 29340,
      "y": 46644,
      "ta": "html > body"
    },
    {
      "t": 71104,
      "e": 70510,
      "ty": 2,
      "x": 818,
      "y": 763
    },
    {
      "t": 71204,
      "e": 70610,
      "ty": 2,
      "x": 764,
      "y": 658
    },
    {
      "t": 71254,
      "e": 70660,
      "ty": 41,
      "x": 24554,
      "y": 34346,
      "ta": "html > body"
    },
    {
      "t": 71304,
      "e": 70710,
      "ty": 2,
      "x": 692,
      "y": 614
    },
    {
      "t": 71331,
      "e": 70737,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 71404,
      "e": 70810,
      "ty": 2,
      "x": 673,
      "y": 607
    },
    {
      "t": 71504,
      "e": 70910,
      "ty": 41,
      "x": 18672,
      "y": 48572,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 72004,
      "e": 71410,
      "ty": 2,
      "x": 739,
      "y": 757
    },
    {
      "t": 72005,
      "e": 71411,
      "ty": 41,
      "x": 21919,
      "y": 51793,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 72104,
      "e": 71510,
      "ty": 2,
      "x": 857,
      "y": 965
    },
    {
      "t": 72203,
      "e": 71609,
      "ty": 2,
      "x": 858,
      "y": 967
    },
    {
      "t": 72254,
      "e": 71660,
      "ty": 41,
      "x": 27774,
      "y": 58216,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73504,
      "e": 72910,
      "ty": 2,
      "x": 858,
      "y": 966
    },
    {
      "t": 73505,
      "e": 72911,
      "ty": 41,
      "x": 27774,
      "y": 58147,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73604,
      "e": 73010,
      "ty": 2,
      "x": 858,
      "y": 962
    },
    {
      "t": 73704,
      "e": 73110,
      "ty": 2,
      "x": 858,
      "y": 961
    },
    {
      "t": 73754,
      "e": 73160,
      "ty": 41,
      "x": 27774,
      "y": 57800,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 80004,
      "e": 78160,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90909,
      "e": 78160,
      "ty": 2,
      "x": 858,
      "y": 956
    },
    {
      "t": 91008,
      "e": 78259,
      "ty": 2,
      "x": 857,
      "y": 952
    },
    {
      "t": 91008,
      "e": 78259,
      "ty": 41,
      "x": 27724,
      "y": 57177,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93759,
      "e": 81010,
      "ty": 41,
      "x": 27675,
      "y": 57177,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93808,
      "e": 81059,
      "ty": 2,
      "x": 856,
      "y": 949
    },
    {
      "t": 93908,
      "e": 81159,
      "ty": 2,
      "x": 856,
      "y": 948
    },
    {
      "t": 94009,
      "e": 81260,
      "ty": 41,
      "x": 27675,
      "y": 56900,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 95009,
      "e": 82260,
      "ty": 2,
      "x": 885,
      "y": 977
    },
    {
      "t": 95009,
      "e": 82260,
      "ty": 41,
      "x": 29102,
      "y": 58908,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 95108,
      "e": 82359,
      "ty": 2,
      "x": 937,
      "y": 1063
    },
    {
      "t": 95128,
      "e": 82379,
      "ty": 6,
      "x": 945,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 95208,
      "e": 82459,
      "ty": 2,
      "x": 948,
      "y": 1077
    },
    {
      "t": 95259,
      "e": 82510,
      "ty": 41,
      "x": 24302,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 95309,
      "e": 82560,
      "ty": 2,
      "x": 959,
      "y": 1085
    },
    {
      "t": 95408,
      "e": 82659,
      "ty": 2,
      "x": 983,
      "y": 1098
    },
    {
      "t": 95508,
      "e": 82759,
      "ty": 2,
      "x": 986,
      "y": 1100
    },
    {
      "t": 95509,
      "e": 82760,
      "ty": 41,
      "x": 41778,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 96435,
      "e": 83686,
      "ty": 3,
      "x": 986,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 96437,
      "e": 83688,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 96691,
      "e": 83942,
      "ty": 4,
      "x": 41778,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 96692,
      "e": 83943,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 96693,
      "e": 83944,
      "ty": 5,
      "x": 986,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 96694,
      "e": 83945,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 97108,
      "e": 84359,
      "ty": 2,
      "x": 986,
      "y": 1096
    },
    {
      "t": 97209,
      "e": 84460,
      "ty": 2,
      "x": 960,
      "y": 1046
    },
    {
      "t": 97258,
      "e": 84509,
      "ty": 41,
      "x": 32061,
      "y": 54677,
      "ta": "html > body"
    },
    {
      "t": 97309,
      "e": 84560,
      "ty": 2,
      "x": 904,
      "y": 929
    },
    {
      "t": 97409,
      "e": 84660,
      "ty": 2,
      "x": 843,
      "y": 831
    },
    {
      "t": 97508,
      "e": 84759,
      "ty": 2,
      "x": 827,
      "y": 811
    },
    {
      "t": 97509,
      "e": 84760,
      "ty": 41,
      "x": 28204,
      "y": 44484,
      "ta": "html > body"
    },
    {
      "t": 97733,
      "e": 84984,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 98877,
      "e": 86128,
      "ty": 2,
      "x": 884,
      "y": 741
    },
    {
      "t": 98908,
      "e": 86159,
      "ty": 2,
      "x": 890,
      "y": 735
    },
    {
      "t": 99008,
      "e": 86259,
      "ty": 2,
      "x": 915,
      "y": 706
    },
    {
      "t": 99009,
      "e": 86260,
      "ty": 41,
      "x": 31264,
      "y": 32785,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 99609,
      "e": 86860,
      "ty": 1,
      "x": 8,
      "y": 1
    },
    {
      "t": 99658,
      "e": 86909,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 79681, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 79686, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 44465, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 125474, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 7201, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"golf\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 133685, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 16370, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 151144, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 12170, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 164317, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 70053, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 235733, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-11 AM-11 AM-11 AM-11 AM-F -F -F -A -12 PM-11 AM-F -A -11 AM-11 AM-O -O -O -11 AM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:876,y:1029,t:1527019544835};\\\", \\\"{x:877,y:1025,t:1527019544842};\\\", \\\"{x:887,y:1021,t:1527019544856};\\\", \\\"{x:916,y:1009,t:1527019544872};\\\", \\\"{x:941,y:997,t:1527019544890};\\\", \\\"{x:980,y:984,t:1527019544907};\\\", \\\"{x:1000,y:974,t:1527019544923};\\\", \\\"{x:1015,y:968,t:1527019544940};\\\", \\\"{x:1032,y:959,t:1527019544957};\\\", \\\"{x:1048,y:953,t:1527019544973};\\\", \\\"{x:1049,y:953,t:1527019544990};\\\", \\\"{x:1051,y:952,t:1527019545395};\\\", \\\"{x:1052,y:952,t:1527019545410};\\\", \\\"{x:1053,y:952,t:1527019545423};\\\", \\\"{x:1060,y:951,t:1527019545440};\\\", \\\"{x:1065,y:950,t:1527019545457};\\\", \\\"{x:1070,y:948,t:1527019545474};\\\", \\\"{x:1072,y:947,t:1527019545490};\\\", \\\"{x:1075,y:946,t:1527019545506};\\\", \\\"{x:1076,y:945,t:1527019545523};\\\", \\\"{x:1076,y:944,t:1527019545540};\\\", \\\"{x:1077,y:943,t:1527019545557};\\\", \\\"{x:1078,y:942,t:1527019545574};\\\", \\\"{x:1079,y:940,t:1527019545591};\\\", \\\"{x:1082,y:940,t:1527019546658};\\\", \\\"{x:1093,y:944,t:1527019546674};\\\", \\\"{x:1106,y:952,t:1527019546691};\\\", \\\"{x:1121,y:957,t:1527019546708};\\\", \\\"{x:1134,y:961,t:1527019546724};\\\", \\\"{x:1145,y:962,t:1527019546740};\\\", \\\"{x:1154,y:963,t:1527019546758};\\\", \\\"{x:1160,y:964,t:1527019546774};\\\", \\\"{x:1168,y:964,t:1527019546790};\\\", \\\"{x:1176,y:964,t:1527019546807};\\\", \\\"{x:1182,y:964,t:1527019546824};\\\", \\\"{x:1187,y:964,t:1527019546840};\\\", \\\"{x:1191,y:964,t:1527019546857};\\\", \\\"{x:1193,y:964,t:1527019546874};\\\", \\\"{x:1195,y:964,t:1527019546897};\\\", \\\"{x:1197,y:964,t:1527019546907};\\\", \\\"{x:1199,y:966,t:1527019546924};\\\", \\\"{x:1205,y:969,t:1527019546941};\\\", \\\"{x:1210,y:971,t:1527019546957};\\\", \\\"{x:1217,y:975,t:1527019546974};\\\", \\\"{x:1232,y:981,t:1527019546991};\\\", \\\"{x:1249,y:990,t:1527019547008};\\\", \\\"{x:1263,y:997,t:1527019547024};\\\", \\\"{x:1277,y:1004,t:1527019547041};\\\", \\\"{x:1281,y:1006,t:1527019547057};\\\", \\\"{x:1283,y:1008,t:1527019547074};\\\", \\\"{x:1284,y:1008,t:1527019547091};\\\", \\\"{x:1284,y:1009,t:1527019547108};\\\", \\\"{x:1284,y:1008,t:1527019547202};\\\", \\\"{x:1284,y:1007,t:1527019547209};\\\", \\\"{x:1283,y:1004,t:1527019547224};\\\", \\\"{x:1281,y:1002,t:1527019547241};\\\", \\\"{x:1281,y:1001,t:1527019547257};\\\", \\\"{x:1280,y:997,t:1527019547274};\\\", \\\"{x:1278,y:994,t:1527019547292};\\\", \\\"{x:1278,y:990,t:1527019547307};\\\", \\\"{x:1274,y:983,t:1527019547324};\\\", \\\"{x:1273,y:980,t:1527019547341};\\\", \\\"{x:1273,y:979,t:1527019547357};\\\", \\\"{x:1272,y:976,t:1527019547374};\\\", \\\"{x:1272,y:975,t:1527019547391};\\\", \\\"{x:1272,y:973,t:1527019547408};\\\", \\\"{x:1272,y:969,t:1527019547424};\\\", \\\"{x:1271,y:965,t:1527019547441};\\\", \\\"{x:1271,y:963,t:1527019547458};\\\", \\\"{x:1271,y:961,t:1527019547474};\\\", \\\"{x:1271,y:960,t:1527019547491};\\\", \\\"{x:1271,y:959,t:1527019547508};\\\", \\\"{x:1271,y:958,t:1527019547525};\\\", \\\"{x:1271,y:957,t:1527019547541};\\\", \\\"{x:1271,y:955,t:1527019547558};\\\", \\\"{x:1271,y:954,t:1527019547575};\\\", \\\"{x:1271,y:952,t:1527019547592};\\\", \\\"{x:1271,y:950,t:1527019547609};\\\", \\\"{x:1271,y:949,t:1527019547624};\\\", \\\"{x:1271,y:947,t:1527019547642};\\\", \\\"{x:1271,y:945,t:1527019547658};\\\", \\\"{x:1272,y:944,t:1527019547674};\\\", \\\"{x:1272,y:942,t:1527019547692};\\\", \\\"{x:1272,y:941,t:1527019547709};\\\", \\\"{x:1272,y:939,t:1527019547724};\\\", \\\"{x:1272,y:938,t:1527019547742};\\\", \\\"{x:1273,y:936,t:1527019547759};\\\", \\\"{x:1273,y:933,t:1527019547775};\\\", \\\"{x:1274,y:931,t:1527019547792};\\\", \\\"{x:1274,y:928,t:1527019547809};\\\", \\\"{x:1274,y:926,t:1527019547825};\\\", \\\"{x:1274,y:923,t:1527019547842};\\\", \\\"{x:1274,y:920,t:1527019547858};\\\", \\\"{x:1275,y:915,t:1527019547875};\\\", \\\"{x:1275,y:911,t:1527019547892};\\\", \\\"{x:1275,y:909,t:1527019547909};\\\", \\\"{x:1275,y:906,t:1527019547926};\\\", \\\"{x:1275,y:905,t:1527019547942};\\\", \\\"{x:1275,y:904,t:1527019547959};\\\", \\\"{x:1275,y:903,t:1527019547975};\\\", \\\"{x:1275,y:900,t:1527019547992};\\\", \\\"{x:1275,y:897,t:1527019548009};\\\", \\\"{x:1275,y:893,t:1527019548025};\\\", \\\"{x:1275,y:890,t:1527019548042};\\\", \\\"{x:1275,y:886,t:1527019548059};\\\", \\\"{x:1275,y:881,t:1527019548076};\\\", \\\"{x:1275,y:878,t:1527019548092};\\\", \\\"{x:1275,y:874,t:1527019548109};\\\", \\\"{x:1275,y:870,t:1527019548126};\\\", \\\"{x:1275,y:867,t:1527019548142};\\\", \\\"{x:1275,y:864,t:1527019548159};\\\", \\\"{x:1275,y:861,t:1527019548175};\\\", \\\"{x:1275,y:859,t:1527019548192};\\\", \\\"{x:1275,y:858,t:1527019548209};\\\", \\\"{x:1275,y:855,t:1527019548227};\\\", \\\"{x:1275,y:852,t:1527019548242};\\\", \\\"{x:1275,y:849,t:1527019548259};\\\", \\\"{x:1275,y:848,t:1527019548275};\\\", \\\"{x:1275,y:845,t:1527019548292};\\\", \\\"{x:1275,y:842,t:1527019548308};\\\", \\\"{x:1274,y:838,t:1527019548326};\\\", \\\"{x:1274,y:835,t:1527019548342};\\\", \\\"{x:1273,y:831,t:1527019548359};\\\", \\\"{x:1273,y:828,t:1527019548376};\\\", \\\"{x:1273,y:827,t:1527019548393};\\\", \\\"{x:1272,y:823,t:1527019548409};\\\", \\\"{x:1271,y:818,t:1527019548426};\\\", \\\"{x:1270,y:815,t:1527019548442};\\\", \\\"{x:1270,y:812,t:1527019548459};\\\", \\\"{x:1269,y:809,t:1527019548476};\\\", \\\"{x:1269,y:806,t:1527019548493};\\\", \\\"{x:1269,y:802,t:1527019548509};\\\", \\\"{x:1269,y:798,t:1527019548526};\\\", \\\"{x:1267,y:793,t:1527019548543};\\\", \\\"{x:1266,y:790,t:1527019548558};\\\", \\\"{x:1266,y:786,t:1527019548576};\\\", \\\"{x:1266,y:783,t:1527019548593};\\\", \\\"{x:1266,y:777,t:1527019548609};\\\", \\\"{x:1265,y:771,t:1527019548625};\\\", \\\"{x:1265,y:765,t:1527019548642};\\\", \\\"{x:1265,y:760,t:1527019548659};\\\", \\\"{x:1265,y:756,t:1527019548676};\\\", \\\"{x:1265,y:751,t:1527019548692};\\\", \\\"{x:1265,y:746,t:1527019548708};\\\", \\\"{x:1265,y:742,t:1527019548726};\\\", \\\"{x:1265,y:736,t:1527019548743};\\\", \\\"{x:1265,y:730,t:1527019548759};\\\", \\\"{x:1265,y:723,t:1527019548776};\\\", \\\"{x:1265,y:718,t:1527019548793};\\\", \\\"{x:1265,y:712,t:1527019548809};\\\", \\\"{x:1266,y:703,t:1527019548825};\\\", \\\"{x:1267,y:699,t:1527019548843};\\\", \\\"{x:1267,y:696,t:1527019548860};\\\", \\\"{x:1268,y:694,t:1527019548876};\\\", \\\"{x:1268,y:693,t:1527019548893};\\\", \\\"{x:1268,y:690,t:1527019548909};\\\", \\\"{x:1268,y:687,t:1527019548926};\\\", \\\"{x:1268,y:684,t:1527019548942};\\\", \\\"{x:1268,y:681,t:1527019548960};\\\", \\\"{x:1268,y:679,t:1527019548976};\\\", \\\"{x:1268,y:676,t:1527019548993};\\\", \\\"{x:1270,y:670,t:1527019549010};\\\", \\\"{x:1270,y:669,t:1527019549026};\\\", \\\"{x:1270,y:663,t:1527019549043};\\\", \\\"{x:1270,y:660,t:1527019549060};\\\", \\\"{x:1271,y:655,t:1527019549076};\\\", \\\"{x:1272,y:652,t:1527019549093};\\\", \\\"{x:1272,y:647,t:1527019549109};\\\", \\\"{x:1272,y:645,t:1527019549126};\\\", \\\"{x:1272,y:641,t:1527019549143};\\\", \\\"{x:1274,y:634,t:1527019549159};\\\", \\\"{x:1274,y:630,t:1527019549176};\\\", \\\"{x:1274,y:625,t:1527019549193};\\\", \\\"{x:1275,y:618,t:1527019549210};\\\", \\\"{x:1276,y:615,t:1527019549225};\\\", \\\"{x:1277,y:613,t:1527019549243};\\\", \\\"{x:1277,y:609,t:1527019549260};\\\", \\\"{x:1277,y:604,t:1527019549276};\\\", \\\"{x:1277,y:599,t:1527019549293};\\\", \\\"{x:1277,y:594,t:1527019549310};\\\", \\\"{x:1277,y:591,t:1527019549327};\\\", \\\"{x:1277,y:589,t:1527019549343};\\\", \\\"{x:1277,y:586,t:1527019549359};\\\", \\\"{x:1277,y:583,t:1527019549377};\\\", \\\"{x:1277,y:581,t:1527019549393};\\\", \\\"{x:1277,y:575,t:1527019549410};\\\", \\\"{x:1277,y:572,t:1527019549426};\\\", \\\"{x:1277,y:570,t:1527019549443};\\\", \\\"{x:1277,y:567,t:1527019549460};\\\", \\\"{x:1277,y:566,t:1527019549477};\\\", \\\"{x:1277,y:564,t:1527019549493};\\\", \\\"{x:1277,y:563,t:1527019549514};\\\", \\\"{x:1277,y:562,t:1527019549546};\\\", \\\"{x:1278,y:562,t:1527019549995};\\\", \\\"{x:1278,y:563,t:1527019550010};\\\", \\\"{x:1279,y:571,t:1527019550028};\\\", \\\"{x:1280,y:583,t:1527019550044};\\\", \\\"{x:1283,y:597,t:1527019550060};\\\", \\\"{x:1284,y:610,t:1527019550077};\\\", \\\"{x:1287,y:624,t:1527019550093};\\\", \\\"{x:1289,y:638,t:1527019550110};\\\", \\\"{x:1290,y:652,t:1527019550127};\\\", \\\"{x:1293,y:665,t:1527019550144};\\\", \\\"{x:1294,y:677,t:1527019550161};\\\", \\\"{x:1295,y:689,t:1527019550177};\\\", \\\"{x:1297,y:703,t:1527019550194};\\\", \\\"{x:1298,y:712,t:1527019550210};\\\", \\\"{x:1299,y:721,t:1527019550227};\\\", \\\"{x:1299,y:728,t:1527019550244};\\\", \\\"{x:1299,y:736,t:1527019550260};\\\", \\\"{x:1301,y:748,t:1527019550277};\\\", \\\"{x:1302,y:762,t:1527019550293};\\\", \\\"{x:1304,y:780,t:1527019550311};\\\", \\\"{x:1304,y:798,t:1527019550327};\\\", \\\"{x:1304,y:821,t:1527019550343};\\\", \\\"{x:1304,y:844,t:1527019550360};\\\", \\\"{x:1304,y:867,t:1527019550376};\\\", \\\"{x:1304,y:898,t:1527019550393};\\\", \\\"{x:1302,y:919,t:1527019550410};\\\", \\\"{x:1301,y:933,t:1527019550427};\\\", \\\"{x:1300,y:942,t:1527019550443};\\\", \\\"{x:1299,y:950,t:1527019550460};\\\", \\\"{x:1297,y:956,t:1527019550477};\\\", \\\"{x:1297,y:960,t:1527019550493};\\\", \\\"{x:1297,y:964,t:1527019550510};\\\", \\\"{x:1296,y:967,t:1527019550527};\\\", \\\"{x:1294,y:972,t:1527019550544};\\\", \\\"{x:1292,y:979,t:1527019550560};\\\", \\\"{x:1289,y:983,t:1527019550577};\\\", \\\"{x:1288,y:992,t:1527019550595};\\\", \\\"{x:1285,y:995,t:1527019550611};\\\", \\\"{x:1284,y:997,t:1527019550627};\\\", \\\"{x:1283,y:998,t:1527019550644};\\\", \\\"{x:1282,y:998,t:1527019550661};\\\", \\\"{x:1282,y:995,t:1527019550858};\\\", \\\"{x:1282,y:993,t:1527019550866};\\\", \\\"{x:1282,y:991,t:1527019550882};\\\", \\\"{x:1281,y:990,t:1527019550897};\\\", \\\"{x:1281,y:988,t:1527019551067};\\\", \\\"{x:1280,y:987,t:1527019551106};\\\", \\\"{x:1280,y:986,t:1527019551137};\\\", \\\"{x:1280,y:985,t:1527019553322};\\\", \\\"{x:1279,y:984,t:1527019553330};\\\", \\\"{x:1279,y:983,t:1527019553362};\\\", \\\"{x:1279,y:982,t:1527019553379};\\\", \\\"{x:1278,y:981,t:1527019553396};\\\", \\\"{x:1278,y:980,t:1527019553938};\\\", \\\"{x:1278,y:979,t:1527019553946};\\\", \\\"{x:1278,y:978,t:1527019553963};\\\", \\\"{x:1278,y:976,t:1527019554082};\\\", \\\"{x:1279,y:976,t:1527019554098};\\\", \\\"{x:1280,y:976,t:1527019554121};\\\", \\\"{x:1280,y:975,t:1527019554129};\\\", \\\"{x:1281,y:974,t:1527019554682};\\\", \\\"{x:1282,y:973,t:1527019555026};\\\", \\\"{x:1282,y:971,t:1527019556030};\\\", \\\"{x:1282,y:969,t:1527019556037};\\\", \\\"{x:1282,y:968,t:1527019556053};\\\", \\\"{x:1282,y:966,t:1527019556069};\\\", \\\"{x:1282,y:965,t:1527019556085};\\\", \\\"{x:1283,y:963,t:1527019556102};\\\", \\\"{x:1283,y:962,t:1527019556119};\\\", \\\"{x:1283,y:961,t:1527019556534};\\\", \\\"{x:1284,y:959,t:1527019556541};\\\", \\\"{x:1285,y:959,t:1527019556552};\\\", \\\"{x:1286,y:956,t:1527019556569};\\\", \\\"{x:1288,y:953,t:1527019556586};\\\", \\\"{x:1288,y:952,t:1527019556602};\\\", \\\"{x:1290,y:950,t:1527019556619};\\\", \\\"{x:1291,y:949,t:1527019556636};\\\", \\\"{x:1292,y:947,t:1527019556652};\\\", \\\"{x:1292,y:946,t:1527019556670};\\\", \\\"{x:1294,y:943,t:1527019556685};\\\", \\\"{x:1295,y:941,t:1527019556702};\\\", \\\"{x:1295,y:940,t:1527019556719};\\\", \\\"{x:1296,y:939,t:1527019556736};\\\", \\\"{x:1297,y:938,t:1527019556752};\\\", \\\"{x:1298,y:937,t:1527019556769};\\\", \\\"{x:1299,y:935,t:1527019556787};\\\", \\\"{x:1300,y:932,t:1527019556802};\\\", \\\"{x:1301,y:931,t:1527019556819};\\\", \\\"{x:1302,y:930,t:1527019556836};\\\", \\\"{x:1303,y:928,t:1527019556853};\\\", \\\"{x:1304,y:927,t:1527019556869};\\\", \\\"{x:1305,y:926,t:1527019556887};\\\", \\\"{x:1305,y:924,t:1527019556903};\\\", \\\"{x:1305,y:923,t:1527019556919};\\\", \\\"{x:1307,y:922,t:1527019556936};\\\", \\\"{x:1307,y:921,t:1527019556953};\\\", \\\"{x:1309,y:918,t:1527019557110};\\\", \\\"{x:1309,y:917,t:1527019557119};\\\", \\\"{x:1311,y:915,t:1527019557136};\\\", \\\"{x:1312,y:912,t:1527019557152};\\\", \\\"{x:1313,y:909,t:1527019557168};\\\", \\\"{x:1314,y:909,t:1527019557185};\\\", \\\"{x:1315,y:907,t:1527019557202};\\\", \\\"{x:1315,y:906,t:1527019557219};\\\", \\\"{x:1317,y:905,t:1527019557236};\\\", \\\"{x:1317,y:904,t:1527019557269};\\\", \\\"{x:1317,y:903,t:1527019557317};\\\", \\\"{x:1318,y:902,t:1527019557364};\\\", \\\"{x:1315,y:902,t:1527019557541};\\\", \\\"{x:1312,y:902,t:1527019557552};\\\", \\\"{x:1308,y:904,t:1527019557569};\\\", \\\"{x:1306,y:905,t:1527019557586};\\\", \\\"{x:1303,y:907,t:1527019557602};\\\", \\\"{x:1301,y:908,t:1527019557620};\\\", \\\"{x:1300,y:910,t:1527019557635};\\\", \\\"{x:1300,y:914,t:1527019557652};\\\", \\\"{x:1300,y:919,t:1527019557670};\\\", \\\"{x:1300,y:924,t:1527019557685};\\\", \\\"{x:1300,y:928,t:1527019557703};\\\", \\\"{x:1300,y:932,t:1527019557720};\\\", \\\"{x:1300,y:938,t:1527019557735};\\\", \\\"{x:1301,y:942,t:1527019557752};\\\", \\\"{x:1301,y:947,t:1527019557770};\\\", \\\"{x:1302,y:950,t:1527019557786};\\\", \\\"{x:1303,y:954,t:1527019557803};\\\", \\\"{x:1303,y:960,t:1527019557819};\\\", \\\"{x:1303,y:962,t:1527019557837};\\\", \\\"{x:1303,y:963,t:1527019557853};\\\", \\\"{x:1303,y:966,t:1527019557871};\\\", \\\"{x:1303,y:967,t:1527019557887};\\\", \\\"{x:1303,y:968,t:1527019557903};\\\", \\\"{x:1302,y:970,t:1527019557919};\\\", \\\"{x:1300,y:970,t:1527019557937};\\\", \\\"{x:1300,y:971,t:1527019557953};\\\", \\\"{x:1298,y:971,t:1527019557970};\\\", \\\"{x:1296,y:973,t:1527019557998};\\\", \\\"{x:1295,y:973,t:1527019558086};\\\", \\\"{x:1294,y:974,t:1527019558103};\\\", \\\"{x:1293,y:974,t:1527019558422};\\\", \\\"{x:1293,y:973,t:1527019558437};\\\", \\\"{x:1293,y:966,t:1527019558454};\\\", \\\"{x:1293,y:962,t:1527019558470};\\\", \\\"{x:1293,y:958,t:1527019558487};\\\", \\\"{x:1293,y:955,t:1527019558504};\\\", \\\"{x:1293,y:951,t:1527019558520};\\\", \\\"{x:1293,y:949,t:1527019558537};\\\", \\\"{x:1293,y:948,t:1527019558557};\\\", \\\"{x:1293,y:947,t:1527019558570};\\\", \\\"{x:1293,y:946,t:1527019558590};\\\", \\\"{x:1293,y:945,t:1527019558622};\\\", \\\"{x:1293,y:944,t:1527019558637};\\\", \\\"{x:1293,y:943,t:1527019558654};\\\", \\\"{x:1293,y:942,t:1527019558670};\\\", \\\"{x:1293,y:941,t:1527019558694};\\\", \\\"{x:1291,y:942,t:1527019558822};\\\", \\\"{x:1290,y:944,t:1527019558837};\\\", \\\"{x:1285,y:954,t:1527019558854};\\\", \\\"{x:1283,y:961,t:1527019558871};\\\", \\\"{x:1280,y:971,t:1527019558887};\\\", \\\"{x:1278,y:977,t:1527019558904};\\\", \\\"{x:1277,y:980,t:1527019558921};\\\", \\\"{x:1277,y:981,t:1527019558937};\\\", \\\"{x:1278,y:981,t:1527019559166};\\\", \\\"{x:1280,y:980,t:1527019559174};\\\", \\\"{x:1281,y:979,t:1527019559187};\\\", \\\"{x:1283,y:977,t:1527019559204};\\\", \\\"{x:1284,y:975,t:1527019559221};\\\", \\\"{x:1285,y:971,t:1527019559238};\\\", \\\"{x:1287,y:968,t:1527019559255};\\\", \\\"{x:1287,y:967,t:1527019559271};\\\", \\\"{x:1287,y:965,t:1527019559288};\\\", \\\"{x:1287,y:964,t:1527019559518};\\\", \\\"{x:1287,y:963,t:1527019559526};\\\", \\\"{x:1288,y:962,t:1527019559538};\\\", \\\"{x:1290,y:961,t:1527019559555};\\\", \\\"{x:1292,y:960,t:1527019559571};\\\", \\\"{x:1294,y:958,t:1527019559588};\\\", \\\"{x:1297,y:954,t:1527019559604};\\\", \\\"{x:1300,y:948,t:1527019559621};\\\", \\\"{x:1302,y:947,t:1527019559638};\\\", \\\"{x:1302,y:945,t:1527019560134};\\\", \\\"{x:1302,y:939,t:1527019560142};\\\", \\\"{x:1307,y:932,t:1527019560155};\\\", \\\"{x:1307,y:917,t:1527019560173};\\\", \\\"{x:1308,y:903,t:1527019560188};\\\", \\\"{x:1311,y:888,t:1527019560206};\\\", \\\"{x:1312,y:873,t:1527019560222};\\\", \\\"{x:1316,y:857,t:1527019560238};\\\", \\\"{x:1317,y:845,t:1527019560255};\\\", \\\"{x:1319,y:833,t:1527019560272};\\\", \\\"{x:1320,y:824,t:1527019560288};\\\", \\\"{x:1321,y:817,t:1527019560305};\\\", \\\"{x:1321,y:814,t:1527019560322};\\\", \\\"{x:1321,y:812,t:1527019560338};\\\", \\\"{x:1322,y:811,t:1527019560355};\\\", \\\"{x:1322,y:808,t:1527019560372};\\\", \\\"{x:1324,y:805,t:1527019560388};\\\", \\\"{x:1328,y:800,t:1527019560405};\\\", \\\"{x:1338,y:790,t:1527019560422};\\\", \\\"{x:1344,y:785,t:1527019560439};\\\", \\\"{x:1350,y:780,t:1527019560455};\\\", \\\"{x:1354,y:776,t:1527019560472};\\\", \\\"{x:1356,y:774,t:1527019560488};\\\", \\\"{x:1359,y:771,t:1527019560505};\\\", \\\"{x:1361,y:770,t:1527019560522};\\\", \\\"{x:1364,y:769,t:1527019560538};\\\", \\\"{x:1366,y:767,t:1527019560555};\\\", \\\"{x:1367,y:766,t:1527019560573};\\\", \\\"{x:1369,y:765,t:1527019560588};\\\", \\\"{x:1371,y:765,t:1527019560606};\\\", \\\"{x:1371,y:764,t:1527019560623};\\\", \\\"{x:1373,y:764,t:1527019560639};\\\", \\\"{x:1374,y:763,t:1527019560662};\\\", \\\"{x:1375,y:762,t:1527019560673};\\\", \\\"{x:1378,y:761,t:1527019560693};\\\", \\\"{x:1381,y:759,t:1527019560705};\\\", \\\"{x:1383,y:757,t:1527019560734};\\\", \\\"{x:1384,y:757,t:1527019560750};\\\", \\\"{x:1382,y:757,t:1527019561623};\\\", \\\"{x:1359,y:757,t:1527019561640};\\\", \\\"{x:1314,y:757,t:1527019561656};\\\", \\\"{x:1239,y:757,t:1527019561673};\\\", \\\"{x:1159,y:749,t:1527019561689};\\\", \\\"{x:1074,y:738,t:1527019561706};\\\", \\\"{x:991,y:729,t:1527019561723};\\\", \\\"{x:916,y:720,t:1527019561739};\\\", \\\"{x:859,y:710,t:1527019561756};\\\", \\\"{x:835,y:706,t:1527019561773};\\\", \\\"{x:832,y:704,t:1527019561789};\\\", \\\"{x:831,y:703,t:1527019561806};\\\", \\\"{x:830,y:702,t:1527019561861};\\\", \\\"{x:828,y:702,t:1527019561873};\\\", \\\"{x:819,y:699,t:1527019561889};\\\", \\\"{x:804,y:695,t:1527019561906};\\\", \\\"{x:782,y:688,t:1527019561923};\\\", \\\"{x:753,y:680,t:1527019561939};\\\", \\\"{x:713,y:669,t:1527019561957};\\\", \\\"{x:648,y:654,t:1527019561974};\\\", \\\"{x:622,y:646,t:1527019561991};\\\", \\\"{x:603,y:637,t:1527019562006};\\\", \\\"{x:586,y:631,t:1527019562022};\\\", \\\"{x:567,y:621,t:1527019562040};\\\", \\\"{x:548,y:614,t:1527019562057};\\\", \\\"{x:534,y:610,t:1527019562074};\\\", \\\"{x:526,y:608,t:1527019562090};\\\", \\\"{x:518,y:605,t:1527019562108};\\\", \\\"{x:510,y:600,t:1527019562123};\\\", \\\"{x:491,y:593,t:1527019562142};\\\", \\\"{x:481,y:589,t:1527019562158};\\\", \\\"{x:474,y:587,t:1527019562173};\\\", \\\"{x:466,y:584,t:1527019562191};\\\", \\\"{x:457,y:582,t:1527019562208};\\\", \\\"{x:447,y:578,t:1527019562224};\\\", \\\"{x:435,y:576,t:1527019562241};\\\", \\\"{x:425,y:572,t:1527019562258};\\\", \\\"{x:419,y:570,t:1527019562273};\\\", \\\"{x:416,y:569,t:1527019562291};\\\", \\\"{x:413,y:569,t:1527019562307};\\\", \\\"{x:413,y:568,t:1527019562323};\\\", \\\"{x:412,y:568,t:1527019562341};\\\", \\\"{x:411,y:568,t:1527019562357};\\\", \\\"{x:410,y:567,t:1527019562374};\\\", \\\"{x:410,y:566,t:1527019562391};\\\", \\\"{x:409,y:565,t:1527019562408};\\\", \\\"{x:409,y:564,t:1527019562425};\\\", \\\"{x:407,y:564,t:1527019562441};\\\", \\\"{x:407,y:563,t:1527019562458};\\\", \\\"{x:407,y:562,t:1527019562485};\\\", \\\"{x:407,y:561,t:1527019562493};\\\", \\\"{x:407,y:560,t:1527019562518};\\\", \\\"{x:408,y:560,t:1527019565430};\\\", \\\"{x:409,y:560,t:1527019567941};\\\", \\\"{x:410,y:560,t:1527019567974};\\\", \\\"{x:409,y:561,t:1527019573318};\\\", \\\"{x:409,y:562,t:1527019574157};\\\", \\\"{x:409,y:563,t:1527019574358};\\\", \\\"{x:409,y:564,t:1527019575326};\\\", \\\"{x:409,y:566,t:1527019575334};\\\", \\\"{x:408,y:568,t:1527019575381};\\\", \\\"{x:407,y:569,t:1527019575454};\\\", \\\"{x:407,y:571,t:1527019575512};\\\", \\\"{x:406,y:572,t:1527019575540};\\\", \\\"{x:406,y:574,t:1527019581166};\\\", \\\"{x:406,y:577,t:1527019581173};\\\", \\\"{x:420,y:586,t:1527019581190};\\\", \\\"{x:435,y:595,t:1527019581205};\\\", \\\"{x:448,y:605,t:1527019581222};\\\", \\\"{x:469,y:618,t:1527019581239};\\\", \\\"{x:491,y:629,t:1527019581255};\\\", \\\"{x:514,y:641,t:1527019581272};\\\", \\\"{x:537,y:652,t:1527019581289};\\\", \\\"{x:563,y:663,t:1527019581306};\\\", \\\"{x:588,y:675,t:1527019581322};\\\", \\\"{x:608,y:682,t:1527019581339};\\\", \\\"{x:636,y:692,t:1527019581356};\\\", \\\"{x:654,y:698,t:1527019581372};\\\", \\\"{x:678,y:706,t:1527019581389};\\\", \\\"{x:702,y:714,t:1527019581405};\\\", \\\"{x:735,y:722,t:1527019581422};\\\", \\\"{x:771,y:733,t:1527019581439};\\\", \\\"{x:810,y:743,t:1527019581457};\\\", \\\"{x:862,y:756,t:1527019581472};\\\", \\\"{x:926,y:773,t:1527019581489};\\\", \\\"{x:989,y:786,t:1527019581506};\\\", \\\"{x:1044,y:794,t:1527019581522};\\\", \\\"{x:1094,y:807,t:1527019581540};\\\", \\\"{x:1162,y:820,t:1527019581557};\\\", \\\"{x:1192,y:829,t:1527019581573};\\\", \\\"{x:1219,y:836,t:1527019581590};\\\", \\\"{x:1249,y:847,t:1527019581607};\\\", \\\"{x:1270,y:856,t:1527019581622};\\\", \\\"{x:1289,y:863,t:1527019581639};\\\", \\\"{x:1306,y:872,t:1527019581656};\\\", \\\"{x:1321,y:878,t:1527019581673};\\\", \\\"{x:1338,y:887,t:1527019581689};\\\", \\\"{x:1353,y:896,t:1527019581707};\\\", \\\"{x:1365,y:904,t:1527019581723};\\\", \\\"{x:1374,y:910,t:1527019581740};\\\", \\\"{x:1383,y:924,t:1527019581757};\\\", \\\"{x:1385,y:927,t:1527019581773};\\\", \\\"{x:1385,y:933,t:1527019581789};\\\", \\\"{x:1385,y:942,t:1527019581806};\\\", \\\"{x:1382,y:952,t:1527019581823};\\\", \\\"{x:1377,y:961,t:1527019581839};\\\", \\\"{x:1368,y:972,t:1527019581857};\\\", \\\"{x:1362,y:977,t:1527019581873};\\\", \\\"{x:1352,y:981,t:1527019581890};\\\", \\\"{x:1339,y:987,t:1527019581908};\\\", \\\"{x:1328,y:988,t:1527019581923};\\\", \\\"{x:1316,y:990,t:1527019581940};\\\", \\\"{x:1294,y:990,t:1527019581957};\\\", \\\"{x:1280,y:990,t:1527019581973};\\\", \\\"{x:1276,y:990,t:1527019581990};\\\", \\\"{x:1274,y:990,t:1527019582007};\\\", \\\"{x:1272,y:990,t:1527019582029};\\\", \\\"{x:1272,y:989,t:1527019582085};\\\", \\\"{x:1271,y:988,t:1527019582093};\\\", \\\"{x:1271,y:987,t:1527019582107};\\\", \\\"{x:1271,y:985,t:1527019582124};\\\", \\\"{x:1271,y:982,t:1527019582140};\\\", \\\"{x:1271,y:978,t:1527019582157};\\\", \\\"{x:1271,y:975,t:1527019582173};\\\", \\\"{x:1271,y:972,t:1527019582189};\\\", \\\"{x:1271,y:969,t:1527019582207};\\\", \\\"{x:1272,y:967,t:1527019582224};\\\", \\\"{x:1272,y:965,t:1527019582240};\\\", \\\"{x:1274,y:964,t:1527019582257};\\\", \\\"{x:1274,y:963,t:1527019582274};\\\", \\\"{x:1274,y:961,t:1527019582293};\\\", \\\"{x:1276,y:961,t:1527019582324};\\\", \\\"{x:1277,y:959,t:1527019582340};\\\", \\\"{x:1279,y:958,t:1527019582356};\\\", \\\"{x:1280,y:956,t:1527019582373};\\\", \\\"{x:1282,y:955,t:1527019582390};\\\", \\\"{x:1283,y:953,t:1527019582406};\\\", \\\"{x:1284,y:951,t:1527019582423};\\\", \\\"{x:1286,y:949,t:1527019582440};\\\", \\\"{x:1288,y:947,t:1527019582456};\\\", \\\"{x:1291,y:942,t:1527019582473};\\\", \\\"{x:1294,y:937,t:1527019582490};\\\", \\\"{x:1296,y:933,t:1527019582506};\\\", \\\"{x:1300,y:925,t:1527019582524};\\\", \\\"{x:1304,y:914,t:1527019582541};\\\", \\\"{x:1309,y:903,t:1527019582556};\\\", \\\"{x:1310,y:895,t:1527019582573};\\\", \\\"{x:1314,y:884,t:1527019582590};\\\", \\\"{x:1316,y:875,t:1527019582606};\\\", \\\"{x:1319,y:864,t:1527019582623};\\\", \\\"{x:1323,y:854,t:1527019582640};\\\", \\\"{x:1326,y:845,t:1527019582657};\\\", \\\"{x:1329,y:834,t:1527019582674};\\\", \\\"{x:1332,y:824,t:1527019582691};\\\", \\\"{x:1339,y:805,t:1527019582709};\\\", \\\"{x:1343,y:798,t:1527019582723};\\\", \\\"{x:1346,y:784,t:1527019582740};\\\", \\\"{x:1349,y:775,t:1527019582756};\\\", \\\"{x:1352,y:765,t:1527019582774};\\\", \\\"{x:1355,y:754,t:1527019582790};\\\", \\\"{x:1358,y:745,t:1527019582807};\\\", \\\"{x:1361,y:736,t:1527019582824};\\\", \\\"{x:1363,y:729,t:1527019582841};\\\", \\\"{x:1369,y:715,t:1527019582858};\\\", \\\"{x:1372,y:709,t:1527019582874};\\\", \\\"{x:1375,y:702,t:1527019582891};\\\", \\\"{x:1378,y:694,t:1527019582909};\\\", \\\"{x:1379,y:692,t:1527019582924};\\\", \\\"{x:1383,y:686,t:1527019582941};\\\", \\\"{x:1386,y:681,t:1527019582957};\\\", \\\"{x:1388,y:677,t:1527019582974};\\\", \\\"{x:1391,y:673,t:1527019582990};\\\", \\\"{x:1392,y:670,t:1527019583008};\\\", \\\"{x:1395,y:667,t:1527019583024};\\\", \\\"{x:1397,y:664,t:1527019583040};\\\", \\\"{x:1400,y:659,t:1527019583057};\\\", \\\"{x:1403,y:655,t:1527019583073};\\\", \\\"{x:1408,y:649,t:1527019583091};\\\", \\\"{x:1412,y:641,t:1527019583109};\\\", \\\"{x:1415,y:637,t:1527019583123};\\\", \\\"{x:1420,y:629,t:1527019583142};\\\", \\\"{x:1423,y:625,t:1527019583158};\\\", \\\"{x:1424,y:623,t:1527019583174};\\\", \\\"{x:1427,y:619,t:1527019583191};\\\", \\\"{x:1429,y:616,t:1527019583208};\\\", \\\"{x:1431,y:613,t:1527019583225};\\\", \\\"{x:1432,y:611,t:1527019583241};\\\", \\\"{x:1433,y:611,t:1527019583258};\\\", \\\"{x:1434,y:610,t:1527019583275};\\\", \\\"{x:1433,y:609,t:1527019583390};\\\", \\\"{x:1409,y:619,t:1527019583408};\\\", \\\"{x:1354,y:641,t:1527019583425};\\\", \\\"{x:1285,y:670,t:1527019583441};\\\", \\\"{x:1202,y:693,t:1527019583458};\\\", \\\"{x:1105,y:718,t:1527019583475};\\\", \\\"{x:995,y:728,t:1527019583491};\\\", \\\"{x:856,y:730,t:1527019583509};\\\", \\\"{x:787,y:730,t:1527019583525};\\\", \\\"{x:742,y:725,t:1527019583541};\\\", \\\"{x:713,y:718,t:1527019583557};\\\", \\\"{x:692,y:712,t:1527019583575};\\\", \\\"{x:673,y:709,t:1527019583591};\\\", \\\"{x:656,y:704,t:1527019583608};\\\", \\\"{x:635,y:699,t:1527019583625};\\\", \\\"{x:609,y:697,t:1527019583642};\\\", \\\"{x:580,y:694,t:1527019583657};\\\", \\\"{x:560,y:692,t:1527019583674};\\\", \\\"{x:547,y:688,t:1527019583691};\\\", \\\"{x:540,y:686,t:1527019583707};\\\", \\\"{x:532,y:677,t:1527019583724};\\\", \\\"{x:526,y:670,t:1527019583741};\\\", \\\"{x:521,y:662,t:1527019583757};\\\", \\\"{x:512,y:649,t:1527019583774};\\\", \\\"{x:503,y:639,t:1527019583791};\\\", \\\"{x:490,y:629,t:1527019583808};\\\", \\\"{x:476,y:618,t:1527019583825};\\\", \\\"{x:469,y:610,t:1527019583842};\\\", \\\"{x:462,y:602,t:1527019583857};\\\", \\\"{x:457,y:595,t:1527019583874};\\\", \\\"{x:452,y:591,t:1527019583891};\\\", \\\"{x:448,y:585,t:1527019583908};\\\", \\\"{x:440,y:578,t:1527019583925};\\\", \\\"{x:435,y:576,t:1527019583941};\\\", \\\"{x:433,y:575,t:1527019583958};\\\", \\\"{x:429,y:573,t:1527019583975};\\\", \\\"{x:424,y:570,t:1527019583991};\\\", \\\"{x:421,y:568,t:1527019584007};\\\", \\\"{x:413,y:564,t:1527019584024};\\\", \\\"{x:407,y:560,t:1527019584041};\\\", \\\"{x:401,y:557,t:1527019584057};\\\", \\\"{x:398,y:556,t:1527019584074};\\\", \\\"{x:400,y:556,t:1527019584364};\\\", \\\"{x:401,y:557,t:1527019584374};\\\", \\\"{x:407,y:560,t:1527019584391};\\\", \\\"{x:412,y:563,t:1527019584408};\\\", \\\"{x:418,y:569,t:1527019584424};\\\", \\\"{x:422,y:578,t:1527019584442};\\\", \\\"{x:423,y:593,t:1527019584459};\\\", \\\"{x:423,y:609,t:1527019584475};\\\", \\\"{x:424,y:630,t:1527019584492};\\\", \\\"{x:424,y:664,t:1527019584509};\\\", \\\"{x:422,y:683,t:1527019584526};\\\", \\\"{x:422,y:701,t:1527019584541};\\\", \\\"{x:419,y:718,t:1527019584558};\\\", \\\"{x:417,y:731,t:1527019584576};\\\", \\\"{x:414,y:742,t:1527019584591};\\\", \\\"{x:410,y:754,t:1527019584609};\\\", \\\"{x:408,y:759,t:1527019584626};\\\", \\\"{x:407,y:761,t:1527019584642};\\\", \\\"{x:406,y:763,t:1527019584658};\\\", \\\"{x:404,y:764,t:1527019584676};\\\", \\\"{x:403,y:764,t:1527019584717};\\\", \\\"{x:404,y:764,t:1527019585813};\\\", \\\"{x:413,y:759,t:1527019585826};\\\", \\\"{x:457,y:741,t:1527019585843};\\\", \\\"{x:526,y:723,t:1527019585861};\\\", \\\"{x:654,y:708,t:1527019585876};\\\", \\\"{x:745,y:699,t:1527019585892};\\\", \\\"{x:833,y:691,t:1527019585909};\\\", \\\"{x:908,y:691,t:1527019585926};\\\", \\\"{x:980,y:691,t:1527019585943};\\\", \\\"{x:1044,y:691,t:1527019585959};\\\", \\\"{x:1092,y:691,t:1527019585976};\\\", \\\"{x:1114,y:691,t:1527019585993};\\\", \\\"{x:1118,y:691,t:1527019586010};\\\", \\\"{x:1119,y:691,t:1527019586101};\\\", \\\"{x:1127,y:693,t:1527019586111};\\\", \\\"{x:1151,y:703,t:1527019586127};\\\", \\\"{x:1181,y:712,t:1527019586144};\\\", \\\"{x:1220,y:717,t:1527019586161};\\\", \\\"{x:1264,y:720,t:1527019586177};\\\", \\\"{x:1316,y:726,t:1527019586194};\\\", \\\"{x:1364,y:726,t:1527019586211};\\\", \\\"{x:1397,y:730,t:1527019586227};\\\", \\\"{x:1415,y:730,t:1527019586244};\\\", \\\"{x:1427,y:731,t:1527019586261};\\\", \\\"{x:1428,y:731,t:1527019586277};\\\", \\\"{x:1428,y:733,t:1527019586341};\\\", \\\"{x:1428,y:735,t:1527019586349};\\\", \\\"{x:1427,y:738,t:1527019586361};\\\", \\\"{x:1420,y:744,t:1527019586378};\\\", \\\"{x:1412,y:749,t:1527019586395};\\\", \\\"{x:1403,y:754,t:1527019586414};\\\", \\\"{x:1392,y:761,t:1527019586427};\\\", \\\"{x:1383,y:766,t:1527019586444};\\\", \\\"{x:1376,y:772,t:1527019586462};\\\", \\\"{x:1367,y:776,t:1527019586477};\\\", \\\"{x:1360,y:781,t:1527019586494};\\\", \\\"{x:1357,y:783,t:1527019586511};\\\", \\\"{x:1354,y:784,t:1527019586528};\\\", \\\"{x:1352,y:786,t:1527019586544};\\\", \\\"{x:1351,y:787,t:1527019586564};\\\", \\\"{x:1350,y:787,t:1527019586580};\\\", \\\"{x:1349,y:788,t:1527019586595};\\\", \\\"{x:1347,y:789,t:1527019586612};\\\", \\\"{x:1346,y:790,t:1527019586628};\\\", \\\"{x:1345,y:790,t:1527019586645};\\\", \\\"{x:1343,y:790,t:1527019586662};\\\", \\\"{x:1342,y:791,t:1527019586846};\\\", \\\"{x:1339,y:793,t:1527019586863};\\\", \\\"{x:1331,y:795,t:1527019586879};\\\", \\\"{x:1329,y:796,t:1527019586896};\\\", \\\"{x:1326,y:796,t:1527019586912};\\\", \\\"{x:1324,y:796,t:1527019586929};\\\", \\\"{x:1323,y:793,t:1527019587004};\\\", \\\"{x:1323,y:791,t:1527019587012};\\\", \\\"{x:1322,y:786,t:1527019587030};\\\", \\\"{x:1322,y:778,t:1527019587047};\\\", \\\"{x:1322,y:774,t:1527019587063};\\\", \\\"{x:1322,y:770,t:1527019587079};\\\", \\\"{x:1322,y:767,t:1527019587096};\\\", \\\"{x:1322,y:765,t:1527019587112};\\\", \\\"{x:1321,y:764,t:1527019587129};\\\", \\\"{x:1320,y:764,t:1527019587238};\\\", \\\"{x:1318,y:764,t:1527019587247};\\\", \\\"{x:1314,y:765,t:1527019587263};\\\", \\\"{x:1312,y:765,t:1527019587279};\\\", \\\"{x:1311,y:765,t:1527019587297};\\\", \\\"{x:1310,y:766,t:1527019587314};\\\", \\\"{x:1309,y:767,t:1527019587341};\\\", \\\"{x:1308,y:768,t:1527019587365};\\\", \\\"{x:1307,y:773,t:1527019587381};\\\", \\\"{x:1306,y:777,t:1527019587397};\\\", \\\"{x:1304,y:784,t:1527019587413};\\\", \\\"{x:1303,y:791,t:1527019587430};\\\", \\\"{x:1302,y:803,t:1527019587448};\\\", \\\"{x:1300,y:819,t:1527019587464};\\\", \\\"{x:1300,y:838,t:1527019587481};\\\", \\\"{x:1300,y:857,t:1527019587497};\\\", \\\"{x:1300,y:873,t:1527019587514};\\\", \\\"{x:1300,y:887,t:1527019587530};\\\", \\\"{x:1300,y:903,t:1527019587548};\\\", \\\"{x:1300,y:925,t:1527019587565};\\\", \\\"{x:1300,y:936,t:1527019587581};\\\", \\\"{x:1300,y:946,t:1527019587598};\\\", \\\"{x:1300,y:955,t:1527019587615};\\\", \\\"{x:1300,y:967,t:1527019587631};\\\", \\\"{x:1300,y:976,t:1527019587648};\\\", \\\"{x:1300,y:984,t:1527019587665};\\\", \\\"{x:1299,y:989,t:1527019587682};\\\", \\\"{x:1298,y:992,t:1527019587698};\\\", \\\"{x:1296,y:997,t:1527019587715};\\\", \\\"{x:1295,y:999,t:1527019587731};\\\", \\\"{x:1292,y:1004,t:1527019587748};\\\", \\\"{x:1291,y:1005,t:1527019587764};\\\", \\\"{x:1290,y:1005,t:1527019587789};\\\", \\\"{x:1289,y:1005,t:1527019587805};\\\", \\\"{x:1288,y:1004,t:1527019587934};\\\", \\\"{x:1288,y:1003,t:1527019587949};\\\", \\\"{x:1288,y:998,t:1527019587966};\\\", \\\"{x:1287,y:994,t:1527019587982};\\\", \\\"{x:1286,y:992,t:1527019587999};\\\", \\\"{x:1286,y:989,t:1527019588016};\\\", \\\"{x:1285,y:985,t:1527019588033};\\\", \\\"{x:1283,y:981,t:1527019588049};\\\", \\\"{x:1282,y:978,t:1527019588066};\\\", \\\"{x:1281,y:977,t:1527019588083};\\\", \\\"{x:1281,y:976,t:1527019588099};\\\", \\\"{x:1281,y:975,t:1527019588116};\\\", \\\"{x:1281,y:973,t:1527019588133};\\\", \\\"{x:1281,y:970,t:1527019588149};\\\", \\\"{x:1281,y:969,t:1527019588166};\\\", \\\"{x:1280,y:966,t:1527019588183};\\\", \\\"{x:1280,y:964,t:1527019588200};\\\", \\\"{x:1280,y:963,t:1527019588216};\\\", \\\"{x:1280,y:962,t:1527019588245};\\\", \\\"{x:1280,y:961,t:1527019588310};\\\", \\\"{x:1280,y:960,t:1527019588421};\\\", \\\"{x:1280,y:959,t:1527019588437};\\\", \\\"{x:1282,y:959,t:1527019588461};\\\", \\\"{x:1282,y:957,t:1527019588469};\\\", \\\"{x:1283,y:955,t:1527019588484};\\\", \\\"{x:1283,y:954,t:1527019588501};\\\", \\\"{x:1283,y:953,t:1527019588941};\\\", \\\"{x:1284,y:952,t:1527019588952};\\\", \\\"{x:1284,y:951,t:1527019588989};\\\", \\\"{x:1284,y:950,t:1527019589021};\\\", \\\"{x:1284,y:949,t:1527019589045};\\\", \\\"{x:1284,y:948,t:1527019589053};\\\", \\\"{x:1284,y:947,t:1527019589069};\\\", \\\"{x:1284,y:946,t:1527019589101};\\\", \\\"{x:1284,y:945,t:1527019589119};\\\", \\\"{x:1284,y:944,t:1527019589136};\\\", \\\"{x:1284,y:943,t:1527019589181};\\\", \\\"{x:1284,y:942,t:1527019589197};\\\", \\\"{x:1283,y:941,t:1527019589213};\\\", \\\"{x:1282,y:941,t:1527019589221};\\\", \\\"{x:1282,y:940,t:1527019589237};\\\", \\\"{x:1282,y:939,t:1527019589261};\\\", \\\"{x:1282,y:938,t:1527019589285};\\\", \\\"{x:1281,y:938,t:1527019589303};\\\", \\\"{x:1281,y:937,t:1527019589318};\\\", \\\"{x:1281,y:936,t:1527019589335};\\\", \\\"{x:1281,y:935,t:1527019589356};\\\", \\\"{x:1281,y:934,t:1527019589372};\\\", \\\"{x:1281,y:933,t:1527019589385};\\\", \\\"{x:1281,y:932,t:1527019589402};\\\", \\\"{x:1279,y:931,t:1527019589420};\\\", \\\"{x:1279,y:930,t:1527019589436};\\\", \\\"{x:1279,y:928,t:1527019589453};\\\", \\\"{x:1279,y:927,t:1527019589470};\\\", \\\"{x:1278,y:926,t:1527019589492};\\\", \\\"{x:1278,y:925,t:1527019589509};\\\", \\\"{x:1278,y:924,t:1527019589519};\\\", \\\"{x:1276,y:922,t:1527019589537};\\\", \\\"{x:1276,y:921,t:1527019589553};\\\", \\\"{x:1275,y:920,t:1527019589570};\\\", \\\"{x:1275,y:919,t:1527019589587};\\\", \\\"{x:1275,y:917,t:1527019589604};\\\", \\\"{x:1274,y:916,t:1527019589620};\\\", \\\"{x:1274,y:914,t:1527019589637};\\\", \\\"{x:1274,y:913,t:1527019589654};\\\", \\\"{x:1274,y:910,t:1527019589670};\\\", \\\"{x:1273,y:909,t:1527019589687};\\\", \\\"{x:1273,y:907,t:1527019589704};\\\", \\\"{x:1273,y:905,t:1527019589721};\\\", \\\"{x:1273,y:903,t:1527019589737};\\\", \\\"{x:1273,y:901,t:1527019589755};\\\", \\\"{x:1273,y:899,t:1527019589771};\\\", \\\"{x:1273,y:896,t:1527019589787};\\\", \\\"{x:1273,y:895,t:1527019589804};\\\", \\\"{x:1273,y:892,t:1527019589820};\\\", \\\"{x:1273,y:891,t:1527019589837};\\\", \\\"{x:1273,y:889,t:1527019589854};\\\", \\\"{x:1273,y:887,t:1527019589871};\\\", \\\"{x:1273,y:886,t:1527019589889};\\\", \\\"{x:1273,y:884,t:1527019589904};\\\", \\\"{x:1273,y:883,t:1527019589921};\\\", \\\"{x:1273,y:881,t:1527019589938};\\\", \\\"{x:1273,y:878,t:1527019589955};\\\", \\\"{x:1273,y:876,t:1527019589971};\\\", \\\"{x:1273,y:874,t:1527019589988};\\\", \\\"{x:1273,y:872,t:1527019590005};\\\", \\\"{x:1273,y:871,t:1527019590021};\\\", \\\"{x:1273,y:870,t:1527019590038};\\\", \\\"{x:1273,y:869,t:1527019590055};\\\", \\\"{x:1273,y:867,t:1527019590072};\\\", \\\"{x:1273,y:866,t:1527019590088};\\\", \\\"{x:1273,y:864,t:1527019590105};\\\", \\\"{x:1273,y:862,t:1527019590121};\\\", \\\"{x:1273,y:861,t:1527019590140};\\\", \\\"{x:1273,y:860,t:1527019590155};\\\", \\\"{x:1273,y:858,t:1527019590172};\\\", \\\"{x:1273,y:856,t:1527019590187};\\\", \\\"{x:1273,y:855,t:1527019590204};\\\", \\\"{x:1273,y:853,t:1527019590221};\\\", \\\"{x:1273,y:851,t:1527019590239};\\\", \\\"{x:1273,y:849,t:1527019590255};\\\", \\\"{x:1273,y:845,t:1527019590272};\\\", \\\"{x:1273,y:844,t:1527019590289};\\\", \\\"{x:1273,y:841,t:1527019590304};\\\", \\\"{x:1273,y:840,t:1527019590321};\\\", \\\"{x:1273,y:839,t:1527019590338};\\\", \\\"{x:1273,y:837,t:1527019590356};\\\", \\\"{x:1273,y:836,t:1527019590381};\\\", \\\"{x:1274,y:834,t:1527019590388};\\\", \\\"{x:1274,y:833,t:1527019590421};\\\", \\\"{x:1274,y:832,t:1527019590439};\\\", \\\"{x:1274,y:831,t:1527019590456};\\\", \\\"{x:1274,y:830,t:1527019590534};\\\", \\\"{x:1274,y:829,t:1527019590573};\\\", \\\"{x:1274,y:831,t:1527019591342};\\\", \\\"{x:1277,y:856,t:1527019591358};\\\", \\\"{x:1282,y:881,t:1527019591376};\\\", \\\"{x:1286,y:903,t:1527019591392};\\\", \\\"{x:1294,y:918,t:1527019591410};\\\", \\\"{x:1299,y:930,t:1527019591424};\\\", \\\"{x:1303,y:938,t:1527019591442};\\\", \\\"{x:1305,y:942,t:1527019591459};\\\", \\\"{x:1306,y:943,t:1527019591475};\\\", \\\"{x:1307,y:943,t:1527019591524};\\\", \\\"{x:1309,y:943,t:1527019591541};\\\", \\\"{x:1314,y:941,t:1527019591548};\\\", \\\"{x:1315,y:939,t:1527019591558};\\\", \\\"{x:1323,y:927,t:1527019591576};\\\", \\\"{x:1329,y:914,t:1527019591591};\\\", \\\"{x:1335,y:900,t:1527019591609};\\\", \\\"{x:1339,y:887,t:1527019591625};\\\", \\\"{x:1345,y:870,t:1527019591642};\\\", \\\"{x:1347,y:850,t:1527019591659};\\\", \\\"{x:1350,y:833,t:1527019591676};\\\", \\\"{x:1354,y:811,t:1527019591693};\\\", \\\"{x:1357,y:799,t:1527019591709};\\\", \\\"{x:1361,y:788,t:1527019591726};\\\", \\\"{x:1363,y:781,t:1527019591743};\\\", \\\"{x:1364,y:775,t:1527019591758};\\\", \\\"{x:1365,y:769,t:1527019591775};\\\", \\\"{x:1368,y:763,t:1527019591793};\\\", \\\"{x:1369,y:757,t:1527019591810};\\\", \\\"{x:1371,y:752,t:1527019591826};\\\", \\\"{x:1373,y:746,t:1527019591843};\\\", \\\"{x:1374,y:743,t:1527019591861};\\\", \\\"{x:1376,y:739,t:1527019591876};\\\", \\\"{x:1379,y:734,t:1527019591893};\\\", \\\"{x:1379,y:733,t:1527019591910};\\\", \\\"{x:1380,y:731,t:1527019591927};\\\", \\\"{x:1383,y:728,t:1527019591943};\\\", \\\"{x:1385,y:727,t:1527019591960};\\\", \\\"{x:1387,y:725,t:1527019591977};\\\", \\\"{x:1389,y:723,t:1527019591994};\\\", \\\"{x:1391,y:720,t:1527019592010};\\\", \\\"{x:1393,y:717,t:1527019592027};\\\", \\\"{x:1395,y:715,t:1527019592044};\\\", \\\"{x:1400,y:708,t:1527019592060};\\\", \\\"{x:1410,y:695,t:1527019592077};\\\", \\\"{x:1416,y:681,t:1527019592094};\\\", \\\"{x:1425,y:670,t:1527019592110};\\\", \\\"{x:1433,y:658,t:1527019592127};\\\", \\\"{x:1440,y:648,t:1527019592145};\\\", \\\"{x:1446,y:637,t:1527019592161};\\\", \\\"{x:1451,y:628,t:1527019592177};\\\", \\\"{x:1455,y:622,t:1527019592194};\\\", \\\"{x:1459,y:615,t:1527019592211};\\\", \\\"{x:1463,y:609,t:1527019592227};\\\", \\\"{x:1464,y:605,t:1527019592244};\\\", \\\"{x:1470,y:597,t:1527019592261};\\\", \\\"{x:1473,y:590,t:1527019592278};\\\", \\\"{x:1475,y:587,t:1527019592294};\\\", \\\"{x:1477,y:584,t:1527019592311};\\\", \\\"{x:1478,y:583,t:1527019592327};\\\", \\\"{x:1476,y:583,t:1527019592404};\\\", \\\"{x:1468,y:584,t:1527019592411};\\\", \\\"{x:1455,y:590,t:1527019592427};\\\", \\\"{x:1410,y:607,t:1527019592444};\\\", \\\"{x:1357,y:630,t:1527019592461};\\\", \\\"{x:1307,y:651,t:1527019592478};\\\", \\\"{x:1258,y:669,t:1527019592494};\\\", \\\"{x:1195,y:685,t:1527019592512};\\\", \\\"{x:1134,y:704,t:1527019592528};\\\", \\\"{x:1072,y:712,t:1527019592545};\\\", \\\"{x:1008,y:720,t:1527019592561};\\\", \\\"{x:945,y:725,t:1527019592578};\\\", \\\"{x:898,y:725,t:1527019592594};\\\", \\\"{x:847,y:725,t:1527019592612};\\\", \\\"{x:795,y:725,t:1527019592628};\\\", \\\"{x:776,y:729,t:1527019592645};\\\", \\\"{x:768,y:729,t:1527019592662};\\\", \\\"{x:764,y:730,t:1527019592678};\\\", \\\"{x:762,y:730,t:1527019592749};\\\", \\\"{x:759,y:730,t:1527019592764};\\\", \\\"{x:757,y:730,t:1527019592779};\\\", \\\"{x:746,y:732,t:1527019592796};\\\", \\\"{x:726,y:734,t:1527019592812};\\\", \\\"{x:695,y:735,t:1527019592828};\\\", \\\"{x:673,y:735,t:1527019592846};\\\", \\\"{x:647,y:735,t:1527019592862};\\\", \\\"{x:622,y:735,t:1527019592879};\\\", \\\"{x:600,y:735,t:1527019592896};\\\", \\\"{x:585,y:735,t:1527019592913};\\\", \\\"{x:580,y:735,t:1527019592929};\\\", \\\"{x:579,y:735,t:1527019592948};\\\", \\\"{x:578,y:735,t:1527019593077};\\\", \\\"{x:574,y:735,t:1527019593085};\\\", \\\"{x:568,y:735,t:1527019593096};\\\", \\\"{x:556,y:735,t:1527019593113};\\\", \\\"{x:543,y:735,t:1527019593131};\\\", \\\"{x:533,y:732,t:1527019593146};\\\", \\\"{x:521,y:731,t:1527019593163};\\\", \\\"{x:510,y:729,t:1527019593182};\\\", \\\"{x:508,y:729,t:1527019593199};\\\", \\\"{x:510,y:729,t:1527019600676};\\\", \\\"{x:511,y:729,t:1527019600692};\\\", \\\"{x:515,y:732,t:1527019600708};\\\", \\\"{x:520,y:737,t:1527019600725};\\\", \\\"{x:525,y:741,t:1527019600740};\\\", \\\"{x:535,y:749,t:1527019600757};\\\", \\\"{x:540,y:753,t:1527019600771};\\\", \\\"{x:560,y:771,t:1527019600788};\\\", \\\"{x:577,y:784,t:1527019600804};\\\", \\\"{x:594,y:799,t:1527019600821};\\\", \\\"{x:616,y:811,t:1527019600838};\\\", \\\"{x:635,y:822,t:1527019600855};\\\", \\\"{x:661,y:838,t:1527019600870};\\\", \\\"{x:687,y:850,t:1527019600887};\\\", \\\"{x:710,y:859,t:1527019600905};\\\", \\\"{x:732,y:868,t:1527019600920};\\\", \\\"{x:752,y:877,t:1527019600937};\\\", \\\"{x:778,y:889,t:1527019600955};\\\", \\\"{x:801,y:898,t:1527019600971};\\\", \\\"{x:847,y:910,t:1527019600988};\\\", \\\"{x:887,y:922,t:1527019601005};\\\", \\\"{x:933,y:931,t:1527019601020};\\\", \\\"{x:984,y:942,t:1527019601039};\\\", \\\"{x:1040,y:950,t:1527019601055};\\\", \\\"{x:1080,y:952,t:1527019601071};\\\", \\\"{x:1117,y:952,t:1527019601088};\\\", \\\"{x:1156,y:952,t:1527019601105};\\\", \\\"{x:1201,y:952,t:1527019601122};\\\", \\\"{x:1250,y:948,t:1527019601138};\\\", \\\"{x:1282,y:943,t:1527019601155};\\\", \\\"{x:1320,y:937,t:1527019601173};\\\", \\\"{x:1342,y:935,t:1527019601189};\\\", \\\"{x:1365,y:933,t:1527019601205};\\\", \\\"{x:1394,y:933,t:1527019601222};\\\", \\\"{x:1421,y:933,t:1527019601238};\\\", \\\"{x:1444,y:933,t:1527019601256};\\\", \\\"{x:1453,y:933,t:1527019601272};\\\", \\\"{x:1454,y:933,t:1527019601289};\\\", \\\"{x:1452,y:933,t:1527019601365};\\\", \\\"{x:1448,y:935,t:1527019601373};\\\", \\\"{x:1440,y:938,t:1527019601388};\\\", \\\"{x:1434,y:940,t:1527019601406};\\\", \\\"{x:1431,y:942,t:1527019601423};\\\", \\\"{x:1423,y:945,t:1527019601439};\\\", \\\"{x:1415,y:949,t:1527019601456};\\\", \\\"{x:1405,y:951,t:1527019601473};\\\", \\\"{x:1393,y:955,t:1527019601488};\\\", \\\"{x:1381,y:957,t:1527019601506};\\\", \\\"{x:1378,y:958,t:1527019601522};\\\", \\\"{x:1374,y:959,t:1527019601538};\\\", \\\"{x:1370,y:960,t:1527019601555};\\\", \\\"{x:1361,y:963,t:1527019601573};\\\", \\\"{x:1353,y:965,t:1527019601589};\\\", \\\"{x:1343,y:967,t:1527019601606};\\\", \\\"{x:1333,y:968,t:1527019601623};\\\", \\\"{x:1319,y:968,t:1527019601640};\\\", \\\"{x:1301,y:968,t:1527019601656};\\\", \\\"{x:1289,y:968,t:1527019601673};\\\", \\\"{x:1280,y:968,t:1527019601690};\\\", \\\"{x:1275,y:968,t:1527019601706};\\\", \\\"{x:1273,y:968,t:1527019601723};\\\", \\\"{x:1271,y:968,t:1527019601740};\\\", \\\"{x:1273,y:968,t:1527019601989};\\\", \\\"{x:1274,y:967,t:1527019602006};\\\", \\\"{x:1277,y:966,t:1527019602022};\\\", \\\"{x:1278,y:965,t:1527019602040};\\\", \\\"{x:1281,y:964,t:1527019602056};\\\", \\\"{x:1285,y:963,t:1527019602073};\\\", \\\"{x:1288,y:962,t:1527019602090};\\\", \\\"{x:1292,y:961,t:1527019602107};\\\", \\\"{x:1295,y:960,t:1527019602122};\\\", \\\"{x:1299,y:960,t:1527019602140};\\\", \\\"{x:1314,y:957,t:1527019602157};\\\", \\\"{x:1326,y:956,t:1527019602172};\\\", \\\"{x:1337,y:954,t:1527019602190};\\\", \\\"{x:1343,y:951,t:1527019602206};\\\", \\\"{x:1346,y:951,t:1527019602223};\\\", \\\"{x:1347,y:951,t:1527019602239};\\\", \\\"{x:1348,y:950,t:1527019602277};\\\", \\\"{x:1349,y:950,t:1527019602301};\\\", \\\"{x:1351,y:949,t:1527019602315};\\\", \\\"{x:1351,y:948,t:1527019602452};\\\", \\\"{x:1350,y:947,t:1527019602460};\\\", \\\"{x:1350,y:946,t:1527019602472};\\\", \\\"{x:1348,y:945,t:1527019602489};\\\", \\\"{x:1347,y:945,t:1527019602506};\\\", \\\"{x:1346,y:944,t:1527019602532};\\\", \\\"{x:1344,y:943,t:1527019602581};\\\", \\\"{x:1343,y:942,t:1527019602605};\\\", \\\"{x:1341,y:941,t:1527019602621};\\\", \\\"{x:1340,y:940,t:1527019602628};\\\", \\\"{x:1339,y:939,t:1527019602639};\\\", \\\"{x:1334,y:937,t:1527019602657};\\\", \\\"{x:1329,y:935,t:1527019602673};\\\", \\\"{x:1325,y:932,t:1527019602689};\\\", \\\"{x:1323,y:931,t:1527019602707};\\\", \\\"{x:1321,y:930,t:1527019602724};\\\", \\\"{x:1319,y:928,t:1527019602740};\\\", \\\"{x:1318,y:927,t:1527019602765};\\\", \\\"{x:1317,y:926,t:1527019602773};\\\", \\\"{x:1315,y:925,t:1527019602790};\\\", \\\"{x:1314,y:923,t:1527019602806};\\\", \\\"{x:1310,y:918,t:1527019602824};\\\", \\\"{x:1310,y:917,t:1527019602840};\\\", \\\"{x:1309,y:915,t:1527019602857};\\\", \\\"{x:1308,y:914,t:1527019602874};\\\", \\\"{x:1306,y:912,t:1527019602890};\\\", \\\"{x:1306,y:911,t:1527019602907};\\\", \\\"{x:1304,y:907,t:1527019602924};\\\", \\\"{x:1302,y:903,t:1527019602940};\\\", \\\"{x:1300,y:901,t:1527019602957};\\\", \\\"{x:1300,y:900,t:1527019602973};\\\", \\\"{x:1299,y:898,t:1527019602991};\\\", \\\"{x:1298,y:895,t:1527019603006};\\\", \\\"{x:1295,y:891,t:1527019603023};\\\", \\\"{x:1295,y:888,t:1527019603040};\\\", \\\"{x:1292,y:884,t:1527019603056};\\\", \\\"{x:1288,y:878,t:1527019603074};\\\", \\\"{x:1287,y:875,t:1527019603091};\\\", \\\"{x:1285,y:872,t:1527019603107};\\\", \\\"{x:1282,y:867,t:1527019603124};\\\", \\\"{x:1278,y:859,t:1527019603141};\\\", \\\"{x:1276,y:855,t:1527019603156};\\\", \\\"{x:1276,y:853,t:1527019603173};\\\", \\\"{x:1274,y:851,t:1527019603190};\\\", \\\"{x:1274,y:849,t:1527019603207};\\\", \\\"{x:1272,y:846,t:1527019603223};\\\", \\\"{x:1271,y:842,t:1527019603240};\\\", \\\"{x:1269,y:839,t:1527019603256};\\\", \\\"{x:1267,y:834,t:1527019603273};\\\", \\\"{x:1265,y:828,t:1527019603290};\\\", \\\"{x:1263,y:824,t:1527019603307};\\\", \\\"{x:1262,y:820,t:1527019603323};\\\", \\\"{x:1259,y:814,t:1527019603341};\\\", \\\"{x:1259,y:812,t:1527019603357};\\\", \\\"{x:1257,y:809,t:1527019603374};\\\", \\\"{x:1256,y:807,t:1527019603391};\\\", \\\"{x:1256,y:806,t:1527019603407};\\\", \\\"{x:1255,y:805,t:1527019603424};\\\", \\\"{x:1255,y:804,t:1527019603441};\\\", \\\"{x:1255,y:803,t:1527019603458};\\\", \\\"{x:1255,y:802,t:1527019603477};\\\", \\\"{x:1255,y:801,t:1527019603613};\\\", \\\"{x:1255,y:798,t:1527019603623};\\\", \\\"{x:1258,y:795,t:1527019603641};\\\", \\\"{x:1258,y:794,t:1527019603658};\\\", \\\"{x:1259,y:794,t:1527019603997};\\\", \\\"{x:1264,y:799,t:1527019604008};\\\", \\\"{x:1270,y:812,t:1527019604025};\\\", \\\"{x:1279,y:835,t:1527019604041};\\\", \\\"{x:1287,y:857,t:1527019604058};\\\", \\\"{x:1293,y:881,t:1527019604074};\\\", \\\"{x:1300,y:906,t:1527019604091};\\\", \\\"{x:1306,y:930,t:1527019604107};\\\", \\\"{x:1310,y:960,t:1527019604124};\\\", \\\"{x:1311,y:977,t:1527019604140};\\\", \\\"{x:1311,y:986,t:1527019604157};\\\", \\\"{x:1309,y:996,t:1527019604175};\\\", \\\"{x:1304,y:1003,t:1527019604191};\\\", \\\"{x:1299,y:1008,t:1527019604207};\\\", \\\"{x:1295,y:1011,t:1527019604225};\\\", \\\"{x:1293,y:1014,t:1527019604241};\\\", \\\"{x:1292,y:1014,t:1527019604284};\\\", \\\"{x:1291,y:1014,t:1527019604445};\\\", \\\"{x:1291,y:1013,t:1527019604457};\\\", \\\"{x:1290,y:1008,t:1527019604475};\\\", \\\"{x:1288,y:1001,t:1527019604491};\\\", \\\"{x:1284,y:987,t:1527019604508};\\\", \\\"{x:1274,y:950,t:1527019604523};\\\", \\\"{x:1265,y:920,t:1527019604541};\\\", \\\"{x:1261,y:891,t:1527019604557};\\\", \\\"{x:1255,y:866,t:1527019604574};\\\", \\\"{x:1251,y:848,t:1527019604591};\\\", \\\"{x:1249,y:840,t:1527019604607};\\\", \\\"{x:1249,y:837,t:1527019604624};\\\", \\\"{x:1248,y:836,t:1527019604641};\\\", \\\"{x:1248,y:834,t:1527019604757};\\\", \\\"{x:1248,y:833,t:1527019604774};\\\", \\\"{x:1248,y:830,t:1527019604792};\\\", \\\"{x:1250,y:832,t:1527019604933};\\\", \\\"{x:1252,y:837,t:1527019604942};\\\", \\\"{x:1258,y:850,t:1527019604958};\\\", \\\"{x:1261,y:859,t:1527019604974};\\\", \\\"{x:1265,y:866,t:1527019604991};\\\", \\\"{x:1266,y:871,t:1527019605008};\\\", \\\"{x:1268,y:877,t:1527019605024};\\\", \\\"{x:1268,y:883,t:1527019605041};\\\", \\\"{x:1268,y:885,t:1527019605059};\\\", \\\"{x:1268,y:888,t:1527019605074};\\\", \\\"{x:1268,y:889,t:1527019605091};\\\", \\\"{x:1268,y:894,t:1527019605110};\\\", \\\"{x:1268,y:898,t:1527019605124};\\\", \\\"{x:1268,y:901,t:1527019605141};\\\", \\\"{x:1266,y:906,t:1527019605159};\\\", \\\"{x:1265,y:910,t:1527019605174};\\\", \\\"{x:1260,y:915,t:1527019605191};\\\", \\\"{x:1256,y:922,t:1527019605209};\\\", \\\"{x:1253,y:928,t:1527019605224};\\\", \\\"{x:1251,y:931,t:1527019605242};\\\", \\\"{x:1249,y:932,t:1527019605259};\\\", \\\"{x:1249,y:933,t:1527019605541};\\\", \\\"{x:1249,y:934,t:1527019605558};\\\", \\\"{x:1248,y:937,t:1527019605576};\\\", \\\"{x:1248,y:940,t:1527019605598};\\\", \\\"{x:1248,y:943,t:1527019605607};\\\", \\\"{x:1248,y:945,t:1527019605625};\\\", \\\"{x:1248,y:948,t:1527019605641};\\\", \\\"{x:1248,y:951,t:1527019605658};\\\", \\\"{x:1248,y:947,t:1527019605789};\\\", \\\"{x:1247,y:941,t:1527019605796};\\\", \\\"{x:1245,y:933,t:1527019605808};\\\", \\\"{x:1245,y:914,t:1527019605825};\\\", \\\"{x:1245,y:884,t:1527019605842};\\\", \\\"{x:1248,y:849,t:1527019605859};\\\", \\\"{x:1251,y:811,t:1527019605875};\\\", \\\"{x:1251,y:777,t:1527019605892};\\\", \\\"{x:1251,y:767,t:1527019605909};\\\", \\\"{x:1251,y:757,t:1527019605925};\\\", \\\"{x:1251,y:751,t:1527019605942};\\\", \\\"{x:1251,y:747,t:1527019605959};\\\", \\\"{x:1251,y:740,t:1527019605975};\\\", \\\"{x:1250,y:737,t:1527019605992};\\\", \\\"{x:1249,y:732,t:1527019606009};\\\", \\\"{x:1249,y:728,t:1527019606026};\\\", \\\"{x:1248,y:719,t:1527019606042};\\\", \\\"{x:1247,y:705,t:1527019606058};\\\", \\\"{x:1247,y:692,t:1527019606075};\\\", \\\"{x:1247,y:680,t:1527019606092};\\\", \\\"{x:1247,y:674,t:1527019606110};\\\", \\\"{x:1247,y:665,t:1527019606125};\\\", \\\"{x:1247,y:657,t:1527019606143};\\\", \\\"{x:1247,y:650,t:1527019606159};\\\", \\\"{x:1247,y:645,t:1527019606176};\\\", \\\"{x:1247,y:639,t:1527019606192};\\\", \\\"{x:1247,y:635,t:1527019606209};\\\", \\\"{x:1247,y:629,t:1527019606226};\\\", \\\"{x:1248,y:624,t:1527019606242};\\\", \\\"{x:1248,y:622,t:1527019606258};\\\", \\\"{x:1247,y:623,t:1527019606412};\\\", \\\"{x:1247,y:624,t:1527019606425};\\\", \\\"{x:1247,y:630,t:1527019606443};\\\", \\\"{x:1247,y:635,t:1527019606459};\\\", \\\"{x:1246,y:639,t:1527019606476};\\\", \\\"{x:1246,y:643,t:1527019606492};\\\", \\\"{x:1246,y:645,t:1527019606509};\\\", \\\"{x:1246,y:648,t:1527019606526};\\\", \\\"{x:1246,y:650,t:1527019606543};\\\", \\\"{x:1246,y:655,t:1527019606560};\\\", \\\"{x:1246,y:660,t:1527019606575};\\\", \\\"{x:1246,y:666,t:1527019606593};\\\", \\\"{x:1246,y:671,t:1527019606610};\\\", \\\"{x:1246,y:677,t:1527019606626};\\\", \\\"{x:1246,y:681,t:1527019606643};\\\", \\\"{x:1246,y:686,t:1527019606659};\\\", \\\"{x:1246,y:692,t:1527019606676};\\\", \\\"{x:1246,y:702,t:1527019606693};\\\", \\\"{x:1246,y:708,t:1527019606710};\\\", \\\"{x:1246,y:715,t:1527019606726};\\\", \\\"{x:1246,y:720,t:1527019606743};\\\", \\\"{x:1246,y:726,t:1527019606760};\\\", \\\"{x:1246,y:735,t:1527019606777};\\\", \\\"{x:1246,y:744,t:1527019606792};\\\", \\\"{x:1247,y:756,t:1527019606810};\\\", \\\"{x:1248,y:762,t:1527019606827};\\\", \\\"{x:1248,y:768,t:1527019606843};\\\", \\\"{x:1250,y:776,t:1527019606860};\\\", \\\"{x:1254,y:794,t:1527019606876};\\\", \\\"{x:1256,y:803,t:1527019606892};\\\", \\\"{x:1259,y:817,t:1527019606910};\\\", \\\"{x:1265,y:834,t:1527019606927};\\\", \\\"{x:1272,y:855,t:1527019606943};\\\", \\\"{x:1279,y:874,t:1527019606960};\\\", \\\"{x:1284,y:890,t:1527019606977};\\\", \\\"{x:1292,y:906,t:1527019606993};\\\", \\\"{x:1297,y:918,t:1527019607009};\\\", \\\"{x:1301,y:928,t:1527019607026};\\\", \\\"{x:1302,y:935,t:1527019607042};\\\", \\\"{x:1304,y:940,t:1527019607060};\\\", \\\"{x:1305,y:947,t:1527019607076};\\\", \\\"{x:1305,y:952,t:1527019607093};\\\", \\\"{x:1305,y:956,t:1527019607110};\\\", \\\"{x:1305,y:960,t:1527019607126};\\\", \\\"{x:1305,y:963,t:1527019607142};\\\", \\\"{x:1305,y:966,t:1527019607160};\\\", \\\"{x:1305,y:969,t:1527019607177};\\\", \\\"{x:1305,y:975,t:1527019607193};\\\", \\\"{x:1301,y:980,t:1527019607210};\\\", \\\"{x:1299,y:984,t:1527019607226};\\\", \\\"{x:1298,y:985,t:1527019607244};\\\", \\\"{x:1297,y:986,t:1527019607325};\\\", \\\"{x:1295,y:986,t:1527019607365};\\\", \\\"{x:1295,y:983,t:1527019607377};\\\", \\\"{x:1292,y:979,t:1527019607393};\\\", \\\"{x:1292,y:977,t:1527019607409};\\\", \\\"{x:1289,y:974,t:1527019607427};\\\", \\\"{x:1288,y:969,t:1527019607443};\\\", \\\"{x:1287,y:966,t:1527019607460};\\\", \\\"{x:1284,y:960,t:1527019607477};\\\", \\\"{x:1283,y:956,t:1527019607494};\\\", \\\"{x:1282,y:952,t:1527019607510};\\\", \\\"{x:1282,y:950,t:1527019607527};\\\", \\\"{x:1282,y:948,t:1527019607543};\\\", \\\"{x:1282,y:946,t:1527019607559};\\\", \\\"{x:1282,y:944,t:1527019607580};\\\", \\\"{x:1282,y:943,t:1527019607593};\\\", \\\"{x:1282,y:940,t:1527019607609};\\\", \\\"{x:1282,y:936,t:1527019607627};\\\", \\\"{x:1282,y:932,t:1527019607644};\\\", \\\"{x:1282,y:928,t:1527019607660};\\\", \\\"{x:1281,y:921,t:1527019607676};\\\", \\\"{x:1281,y:916,t:1527019607693};\\\", \\\"{x:1281,y:911,t:1527019607711};\\\", \\\"{x:1281,y:907,t:1527019607727};\\\", \\\"{x:1281,y:903,t:1527019607743};\\\", \\\"{x:1281,y:900,t:1527019607760};\\\", \\\"{x:1281,y:897,t:1527019607776};\\\", \\\"{x:1281,y:896,t:1527019607793};\\\", \\\"{x:1281,y:893,t:1527019607810};\\\", \\\"{x:1281,y:889,t:1527019607826};\\\", \\\"{x:1281,y:886,t:1527019607843};\\\", \\\"{x:1281,y:878,t:1527019607859};\\\", \\\"{x:1281,y:874,t:1527019607876};\\\", \\\"{x:1281,y:869,t:1527019607893};\\\", \\\"{x:1281,y:867,t:1527019607910};\\\", \\\"{x:1281,y:864,t:1527019607926};\\\", \\\"{x:1281,y:861,t:1527019607943};\\\", \\\"{x:1280,y:858,t:1527019607960};\\\", \\\"{x:1280,y:855,t:1527019607976};\\\", \\\"{x:1280,y:854,t:1527019607994};\\\", \\\"{x:1280,y:851,t:1527019608010};\\\", \\\"{x:1278,y:847,t:1527019608026};\\\", \\\"{x:1278,y:845,t:1527019608045};\\\", \\\"{x:1278,y:840,t:1527019608060};\\\", \\\"{x:1278,y:833,t:1527019608076};\\\", \\\"{x:1278,y:828,t:1527019608094};\\\", \\\"{x:1278,y:823,t:1527019608111};\\\", \\\"{x:1278,y:818,t:1527019608127};\\\", \\\"{x:1278,y:811,t:1527019608144};\\\", \\\"{x:1278,y:805,t:1527019608161};\\\", \\\"{x:1278,y:798,t:1527019608178};\\\", \\\"{x:1278,y:791,t:1527019608194};\\\", \\\"{x:1278,y:777,t:1527019608211};\\\", \\\"{x:1278,y:767,t:1527019608228};\\\", \\\"{x:1278,y:756,t:1527019608243};\\\", \\\"{x:1278,y:743,t:1527019608260};\\\", \\\"{x:1278,y:736,t:1527019608277};\\\", \\\"{x:1278,y:726,t:1527019608294};\\\", \\\"{x:1277,y:713,t:1527019608311};\\\", \\\"{x:1277,y:703,t:1527019608328};\\\", \\\"{x:1276,y:695,t:1527019608344};\\\", \\\"{x:1276,y:691,t:1527019608361};\\\", \\\"{x:1276,y:685,t:1527019608377};\\\", \\\"{x:1276,y:680,t:1527019608394};\\\", \\\"{x:1276,y:673,t:1527019608410};\\\", \\\"{x:1274,y:666,t:1527019608428};\\\", \\\"{x:1274,y:660,t:1527019608444};\\\", \\\"{x:1274,y:655,t:1527019608460};\\\", \\\"{x:1274,y:649,t:1527019608478};\\\", \\\"{x:1274,y:642,t:1527019608493};\\\", \\\"{x:1274,y:636,t:1527019608510};\\\", \\\"{x:1274,y:631,t:1527019608528};\\\", \\\"{x:1274,y:624,t:1527019608543};\\\", \\\"{x:1274,y:615,t:1527019608560};\\\", \\\"{x:1274,y:610,t:1527019608577};\\\", \\\"{x:1274,y:606,t:1527019608594};\\\", \\\"{x:1274,y:600,t:1527019608611};\\\", \\\"{x:1274,y:596,t:1527019608628};\\\", \\\"{x:1274,y:592,t:1527019608644};\\\", \\\"{x:1274,y:588,t:1527019608661};\\\", \\\"{x:1274,y:584,t:1527019608678};\\\", \\\"{x:1274,y:581,t:1527019608694};\\\", \\\"{x:1274,y:574,t:1527019608711};\\\", \\\"{x:1274,y:569,t:1527019608727};\\\", \\\"{x:1274,y:567,t:1527019608744};\\\", \\\"{x:1274,y:564,t:1527019608760};\\\", \\\"{x:1274,y:561,t:1527019608777};\\\", \\\"{x:1274,y:560,t:1527019608794};\\\", \\\"{x:1274,y:558,t:1527019608810};\\\", \\\"{x:1274,y:557,t:1527019608828};\\\", \\\"{x:1274,y:556,t:1527019608844};\\\", \\\"{x:1275,y:554,t:1527019608941};\\\", \\\"{x:1276,y:554,t:1527019608956};\\\", \\\"{x:1277,y:554,t:1527019608972};\\\", \\\"{x:1278,y:553,t:1527019608980};\\\", \\\"{x:1279,y:553,t:1527019608997};\\\", \\\"{x:1280,y:553,t:1527019609020};\\\", \\\"{x:1282,y:552,t:1527019609036};\\\", \\\"{x:1282,y:551,t:1527019609052};\\\", \\\"{x:1279,y:555,t:1527019611813};\\\", \\\"{x:1253,y:570,t:1527019611829};\\\", \\\"{x:1201,y:591,t:1527019611847};\\\", \\\"{x:1147,y:607,t:1527019611863};\\\", \\\"{x:1091,y:617,t:1527019611880};\\\", \\\"{x:1024,y:625,t:1527019611897};\\\", \\\"{x:960,y:634,t:1527019611913};\\\", \\\"{x:891,y:644,t:1527019611929};\\\", \\\"{x:824,y:653,t:1527019611947};\\\", \\\"{x:746,y:665,t:1527019611964};\\\", \\\"{x:734,y:666,t:1527019611980};\\\", \\\"{x:718,y:669,t:1527019611996};\\\", \\\"{x:717,y:670,t:1527019612014};\\\", \\\"{x:716,y:670,t:1527019612060};\\\", \\\"{x:715,y:670,t:1527019612068};\\\", \\\"{x:712,y:671,t:1527019612080};\\\", \\\"{x:700,y:677,t:1527019612097};\\\", \\\"{x:690,y:682,t:1527019612113};\\\", \\\"{x:673,y:690,t:1527019612129};\\\", \\\"{x:650,y:697,t:1527019612147};\\\", \\\"{x:628,y:704,t:1527019612163};\\\", \\\"{x:608,y:709,t:1527019612180};\\\", \\\"{x:590,y:718,t:1527019612196};\\\", \\\"{x:584,y:721,t:1527019612214};\\\", \\\"{x:578,y:723,t:1527019612230};\\\", \\\"{x:573,y:725,t:1527019612247};\\\", \\\"{x:570,y:727,t:1527019612263};\\\", \\\"{x:565,y:728,t:1527019612280};\\\", \\\"{x:561,y:730,t:1527019612297};\\\", \\\"{x:560,y:730,t:1527019612396};\\\", \\\"{x:557,y:730,t:1527019612403};\\\", \\\"{x:556,y:731,t:1527019612413};\\\", \\\"{x:553,y:733,t:1527019612430};\\\" ] }, { \\\"rt\\\": 8193, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 245511, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -12 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:552,y:733,t:1527019614620};\\\", \\\"{x:551,y:732,t:1527019614636};\\\", \\\"{x:551,y:731,t:1527019614660};\\\", \\\"{x:550,y:730,t:1527019614716};\\\", \\\"{x:550,y:729,t:1527019615021};\\\", \\\"{x:554,y:728,t:1527019615032};\\\", \\\"{x:566,y:722,t:1527019615049};\\\", \\\"{x:579,y:715,t:1527019615065};\\\", \\\"{x:594,y:707,t:1527019615082};\\\", \\\"{x:619,y:694,t:1527019615099};\\\", \\\"{x:635,y:687,t:1527019615115};\\\", \\\"{x:652,y:679,t:1527019615132};\\\", \\\"{x:667,y:673,t:1527019615149};\\\", \\\"{x:678,y:670,t:1527019615165};\\\", \\\"{x:691,y:666,t:1527019615182};\\\", \\\"{x:704,y:665,t:1527019615199};\\\", \\\"{x:714,y:663,t:1527019615215};\\\", \\\"{x:720,y:662,t:1527019615232};\\\", \\\"{x:729,y:661,t:1527019615249};\\\", \\\"{x:732,y:661,t:1527019615265};\\\", \\\"{x:733,y:660,t:1527019615282};\\\", \\\"{x:734,y:659,t:1527019615300};\\\", \\\"{x:733,y:659,t:1527019615668};\\\", \\\"{x:732,y:660,t:1527019615682};\\\", \\\"{x:731,y:660,t:1527019615716};\\\", \\\"{x:728,y:663,t:1527019615733};\\\", \\\"{x:727,y:664,t:1527019615749};\\\", \\\"{x:726,y:665,t:1527019615767};\\\", \\\"{x:732,y:666,t:1527019615876};\\\", \\\"{x:741,y:667,t:1527019615884};\\\", \\\"{x:785,y:674,t:1527019615900};\\\", \\\"{x:873,y:684,t:1527019615916};\\\", \\\"{x:965,y:684,t:1527019615934};\\\", \\\"{x:1120,y:684,t:1527019615962};\\\", \\\"{x:1170,y:684,t:1527019615966};\\\", \\\"{x:1243,y:670,t:1527019615983};\\\", \\\"{x:1297,y:661,t:1527019615999};\\\", \\\"{x:1326,y:656,t:1527019616016};\\\", \\\"{x:1335,y:655,t:1527019616037};\\\", \\\"{x:1339,y:655,t:1527019616053};\\\", \\\"{x:1342,y:655,t:1527019616272};\\\", \\\"{x:1346,y:655,t:1527019616287};\\\", \\\"{x:1364,y:647,t:1527019616304};\\\", \\\"{x:1376,y:641,t:1527019616320};\\\", \\\"{x:1396,y:633,t:1527019616338};\\\", \\\"{x:1414,y:630,t:1527019616354};\\\", \\\"{x:1433,y:624,t:1527019616371};\\\", \\\"{x:1443,y:620,t:1527019616388};\\\", \\\"{x:1449,y:618,t:1527019616404};\\\", \\\"{x:1452,y:618,t:1527019616420};\\\", \\\"{x:1453,y:617,t:1527019616438};\\\", \\\"{x:1451,y:618,t:1527019616570};\\\", \\\"{x:1436,y:624,t:1527019616587};\\\", \\\"{x:1423,y:630,t:1527019616605};\\\", \\\"{x:1416,y:633,t:1527019616621};\\\", \\\"{x:1410,y:635,t:1527019616638};\\\", \\\"{x:1409,y:636,t:1527019616655};\\\", \\\"{x:1405,y:638,t:1527019616671};\\\", \\\"{x:1404,y:639,t:1527019616688};\\\", \\\"{x:1403,y:639,t:1527019617080};\\\", \\\"{x:1403,y:631,t:1527019617088};\\\", \\\"{x:1428,y:596,t:1527019617104};\\\", \\\"{x:1460,y:565,t:1527019617120};\\\", \\\"{x:1505,y:535,t:1527019617138};\\\", \\\"{x:1542,y:517,t:1527019617155};\\\", \\\"{x:1565,y:502,t:1527019617171};\\\", \\\"{x:1578,y:493,t:1527019617187};\\\", \\\"{x:1593,y:484,t:1527019617205};\\\", \\\"{x:1602,y:479,t:1527019617222};\\\", \\\"{x:1606,y:477,t:1527019617238};\\\", \\\"{x:1609,y:476,t:1527019617255};\\\", \\\"{x:1611,y:475,t:1527019617271};\\\", \\\"{x:1613,y:475,t:1527019617288};\\\", \\\"{x:1614,y:474,t:1527019617305};\\\", \\\"{x:1614,y:471,t:1527019617375};\\\", \\\"{x:1616,y:466,t:1527019617387};\\\", \\\"{x:1616,y:460,t:1527019617404};\\\", \\\"{x:1617,y:454,t:1527019617421};\\\", \\\"{x:1617,y:450,t:1527019617437};\\\", \\\"{x:1618,y:446,t:1527019617454};\\\", \\\"{x:1619,y:442,t:1527019617471};\\\", \\\"{x:1619,y:439,t:1527019617487};\\\", \\\"{x:1619,y:437,t:1527019617511};\\\", \\\"{x:1619,y:436,t:1527019617526};\\\", \\\"{x:1619,y:435,t:1527019617550};\\\", \\\"{x:1619,y:434,t:1527019617567};\\\", \\\"{x:1619,y:433,t:1527019617584};\\\", \\\"{x:1618,y:432,t:1527019618192};\\\", \\\"{x:1617,y:432,t:1527019618224};\\\", \\\"{x:1616,y:432,t:1527019618728};\\\", \\\"{x:1616,y:434,t:1527019618738};\\\", \\\"{x:1613,y:439,t:1527019618758};\\\", \\\"{x:1612,y:446,t:1527019618772};\\\", \\\"{x:1610,y:450,t:1527019618789};\\\", \\\"{x:1609,y:457,t:1527019618806};\\\", \\\"{x:1606,y:465,t:1527019618822};\\\", \\\"{x:1605,y:470,t:1527019618839};\\\", \\\"{x:1604,y:479,t:1527019618855};\\\", \\\"{x:1602,y:486,t:1527019618872};\\\", \\\"{x:1600,y:492,t:1527019618889};\\\", \\\"{x:1598,y:498,t:1527019618906};\\\", \\\"{x:1594,y:506,t:1527019618922};\\\", \\\"{x:1592,y:511,t:1527019618939};\\\", \\\"{x:1591,y:517,t:1527019618957};\\\", \\\"{x:1589,y:524,t:1527019618972};\\\", \\\"{x:1588,y:529,t:1527019618989};\\\", \\\"{x:1585,y:536,t:1527019619006};\\\", \\\"{x:1583,y:543,t:1527019619022};\\\", \\\"{x:1580,y:549,t:1527019619039};\\\", \\\"{x:1575,y:559,t:1527019619056};\\\", \\\"{x:1573,y:570,t:1527019619072};\\\", \\\"{x:1570,y:580,t:1527019619089};\\\", \\\"{x:1565,y:593,t:1527019619106};\\\", \\\"{x:1561,y:605,t:1527019619123};\\\", \\\"{x:1556,y:617,t:1527019619139};\\\", \\\"{x:1552,y:627,t:1527019619156};\\\", \\\"{x:1548,y:639,t:1527019619173};\\\", \\\"{x:1544,y:648,t:1527019619189};\\\", \\\"{x:1541,y:655,t:1527019619206};\\\", \\\"{x:1537,y:665,t:1527019619223};\\\", \\\"{x:1532,y:676,t:1527019619239};\\\", \\\"{x:1523,y:695,t:1527019619256};\\\", \\\"{x:1519,y:702,t:1527019619272};\\\", \\\"{x:1517,y:707,t:1527019619289};\\\", \\\"{x:1513,y:715,t:1527019619306};\\\", \\\"{x:1510,y:721,t:1527019619323};\\\", \\\"{x:1509,y:726,t:1527019619339};\\\", \\\"{x:1507,y:731,t:1527019619355};\\\", \\\"{x:1505,y:734,t:1527019619373};\\\", \\\"{x:1503,y:736,t:1527019619388};\\\", \\\"{x:1502,y:740,t:1527019619406};\\\", \\\"{x:1499,y:744,t:1527019619423};\\\", \\\"{x:1496,y:748,t:1527019619439};\\\", \\\"{x:1493,y:754,t:1527019619456};\\\", \\\"{x:1491,y:756,t:1527019619473};\\\", \\\"{x:1488,y:760,t:1527019619489};\\\", \\\"{x:1485,y:763,t:1527019619506};\\\", \\\"{x:1484,y:765,t:1527019619524};\\\", \\\"{x:1481,y:768,t:1527019619539};\\\", \\\"{x:1478,y:772,t:1527019619556};\\\", \\\"{x:1474,y:776,t:1527019619573};\\\", \\\"{x:1473,y:778,t:1527019619589};\\\", \\\"{x:1471,y:780,t:1527019619606};\\\", \\\"{x:1468,y:784,t:1527019619623};\\\", \\\"{x:1464,y:788,t:1527019619639};\\\", \\\"{x:1460,y:791,t:1527019619656};\\\", \\\"{x:1459,y:793,t:1527019619673};\\\", \\\"{x:1457,y:794,t:1527019619690};\\\", \\\"{x:1456,y:795,t:1527019619706};\\\", \\\"{x:1453,y:798,t:1527019619723};\\\", \\\"{x:1453,y:799,t:1527019619740};\\\", \\\"{x:1451,y:801,t:1527019619756};\\\", \\\"{x:1450,y:803,t:1527019619773};\\\", \\\"{x:1448,y:804,t:1527019619790};\\\", \\\"{x:1446,y:806,t:1527019619806};\\\", \\\"{x:1442,y:810,t:1527019619823};\\\", \\\"{x:1420,y:830,t:1527019619840};\\\", \\\"{x:1412,y:837,t:1527019619856};\\\", \\\"{x:1405,y:844,t:1527019619873};\\\", \\\"{x:1402,y:847,t:1527019619890};\\\", \\\"{x:1400,y:849,t:1527019619906};\\\", \\\"{x:1396,y:855,t:1527019619923};\\\", \\\"{x:1394,y:858,t:1527019619940};\\\", \\\"{x:1388,y:866,t:1527019619956};\\\", \\\"{x:1383,y:876,t:1527019619973};\\\", \\\"{x:1379,y:883,t:1527019619990};\\\", \\\"{x:1378,y:886,t:1527019620006};\\\", \\\"{x:1375,y:893,t:1527019620023};\\\", \\\"{x:1369,y:909,t:1527019620039};\\\", \\\"{x:1364,y:923,t:1527019620055};\\\", \\\"{x:1359,y:937,t:1527019620072};\\\", \\\"{x:1356,y:947,t:1527019620089};\\\", \\\"{x:1352,y:956,t:1527019620105};\\\", \\\"{x:1349,y:962,t:1527019620122};\\\", \\\"{x:1346,y:967,t:1527019620139};\\\", \\\"{x:1344,y:970,t:1527019620155};\\\", \\\"{x:1343,y:972,t:1527019620172};\\\", \\\"{x:1341,y:975,t:1527019620189};\\\", \\\"{x:1338,y:976,t:1527019620206};\\\", \\\"{x:1332,y:977,t:1527019620222};\\\", \\\"{x:1300,y:977,t:1527019620239};\\\", \\\"{x:1257,y:977,t:1527019620257};\\\", \\\"{x:1175,y:963,t:1527019620272};\\\", \\\"{x:1074,y:941,t:1527019620289};\\\", \\\"{x:969,y:911,t:1527019620306};\\\", \\\"{x:895,y:881,t:1527019620322};\\\", \\\"{x:851,y:855,t:1527019620339};\\\", \\\"{x:821,y:832,t:1527019620356};\\\", \\\"{x:806,y:817,t:1527019620372};\\\", \\\"{x:787,y:802,t:1527019620389};\\\", \\\"{x:773,y:791,t:1527019620406};\\\", \\\"{x:755,y:780,t:1527019620422};\\\", \\\"{x:725,y:766,t:1527019620439};\\\", \\\"{x:703,y:758,t:1527019620456};\\\", \\\"{x:685,y:749,t:1527019620472};\\\", \\\"{x:675,y:743,t:1527019620489};\\\", \\\"{x:663,y:737,t:1527019620506};\\\", \\\"{x:649,y:730,t:1527019620522};\\\", \\\"{x:629,y:723,t:1527019620539};\\\", \\\"{x:608,y:719,t:1527019620556};\\\", \\\"{x:581,y:716,t:1527019620572};\\\", \\\"{x:553,y:712,t:1527019620589};\\\", \\\"{x:516,y:707,t:1527019620606};\\\", \\\"{x:446,y:693,t:1527019620624};\\\", \\\"{x:401,y:680,t:1527019620641};\\\", \\\"{x:368,y:667,t:1527019620657};\\\", \\\"{x:343,y:653,t:1527019620673};\\\", \\\"{x:327,y:641,t:1527019620692};\\\", \\\"{x:319,y:633,t:1527019620707};\\\", \\\"{x:317,y:626,t:1527019620724};\\\", \\\"{x:317,y:618,t:1527019620742};\\\", \\\"{x:315,y:607,t:1527019620758};\\\", \\\"{x:312,y:600,t:1527019620774};\\\", \\\"{x:311,y:595,t:1527019620790};\\\", \\\"{x:311,y:592,t:1527019620807};\\\", \\\"{x:311,y:586,t:1527019620824};\\\", \\\"{x:316,y:581,t:1527019620841};\\\", \\\"{x:327,y:576,t:1527019620857};\\\", \\\"{x:338,y:572,t:1527019620875};\\\", \\\"{x:345,y:569,t:1527019620891};\\\", \\\"{x:348,y:568,t:1527019620906};\\\", \\\"{x:349,y:568,t:1527019620959};\\\", \\\"{x:350,y:567,t:1527019620974};\\\", \\\"{x:351,y:567,t:1527019620991};\\\", \\\"{x:354,y:567,t:1527019621007};\\\", \\\"{x:356,y:567,t:1527019621023};\\\", \\\"{x:359,y:567,t:1527019621041};\\\", \\\"{x:362,y:569,t:1527019621057};\\\", \\\"{x:369,y:571,t:1527019621074};\\\", \\\"{x:371,y:572,t:1527019621091};\\\", \\\"{x:373,y:573,t:1527019621107};\\\", \\\"{x:374,y:574,t:1527019621302};\\\", \\\"{x:375,y:576,t:1527019621311};\\\", \\\"{x:376,y:577,t:1527019621324};\\\", \\\"{x:377,y:579,t:1527019621340};\\\", \\\"{x:378,y:584,t:1527019621358};\\\", \\\"{x:381,y:589,t:1527019621374};\\\", \\\"{x:382,y:594,t:1527019621391};\\\", \\\"{x:383,y:595,t:1527019621646};\\\", \\\"{x:384,y:595,t:1527019621658};\\\", \\\"{x:387,y:594,t:1527019621675};\\\", \\\"{x:387,y:594,t:1527019621730};\\\", \\\"{x:388,y:594,t:1527019621750};\\\", \\\"{x:391,y:594,t:1527019621766};\\\", \\\"{x:395,y:597,t:1527019621774};\\\", \\\"{x:407,y:615,t:1527019621791};\\\", \\\"{x:427,y:639,t:1527019621809};\\\", \\\"{x:455,y:669,t:1527019621825};\\\", \\\"{x:483,y:707,t:1527019621842};\\\", \\\"{x:507,y:734,t:1527019621858};\\\", \\\"{x:522,y:750,t:1527019621875};\\\", \\\"{x:535,y:762,t:1527019621891};\\\", \\\"{x:545,y:774,t:1527019621908};\\\", \\\"{x:554,y:779,t:1527019621925};\\\", \\\"{x:556,y:781,t:1527019621942};\\\", \\\"{x:557,y:781,t:1527019622039};\\\", \\\"{x:557,y:780,t:1527019622047};\\\", \\\"{x:557,y:778,t:1527019622058};\\\", \\\"{x:557,y:773,t:1527019622075};\\\", \\\"{x:557,y:768,t:1527019622092};\\\", \\\"{x:555,y:760,t:1527019622108};\\\", \\\"{x:552,y:754,t:1527019622125};\\\", \\\"{x:549,y:747,t:1527019622142};\\\", \\\"{x:548,y:744,t:1527019622158};\\\", \\\"{x:546,y:740,t:1527019622175};\\\", \\\"{x:545,y:737,t:1527019622192};\\\", \\\"{x:544,y:734,t:1527019622208};\\\", \\\"{x:542,y:733,t:1527019622225};\\\", \\\"{x:542,y:731,t:1527019622242};\\\", \\\"{x:542,y:730,t:1527019622258};\\\", \\\"{x:542,y:729,t:1527019622275};\\\", \\\"{x:542,y:728,t:1527019622303};\\\", \\\"{x:542,y:727,t:1527019622319};\\\", \\\"{x:542,y:726,t:1527019622335};\\\", \\\"{x:542,y:725,t:1527019622719};\\\", \\\"{x:542,y:724,t:1527019622726};\\\", \\\"{x:542,y:722,t:1527019622742};\\\", \\\"{x:542,y:717,t:1527019622759};\\\", \\\"{x:542,y:712,t:1527019622776};\\\", \\\"{x:542,y:710,t:1527019622792};\\\", \\\"{x:542,y:707,t:1527019622809};\\\", \\\"{x:542,y:705,t:1527019622826};\\\", \\\"{x:542,y:701,t:1527019622842};\\\", \\\"{x:542,y:700,t:1527019622859};\\\", \\\"{x:542,y:699,t:1527019622879};\\\", \\\"{x:542,y:698,t:1527019622903};\\\", \\\"{x:542,y:697,t:1527019622918};\\\", \\\"{x:542,y:696,t:1527019622943};\\\", \\\"{x:542,y:695,t:1527019622959};\\\", \\\"{x:542,y:694,t:1527019622976};\\\", \\\"{x:542,y:693,t:1527019622992};\\\", \\\"{x:542,y:692,t:1527019623009};\\\", \\\"{x:542,y:691,t:1527019623026};\\\", \\\"{x:542,y:690,t:1527019623042};\\\", \\\"{x:542,y:689,t:1527019623059};\\\" ] }, { \\\"rt\\\": 18791, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 265502, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -11 AM-10 AM-09 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:688,t:1527019624376};\\\", \\\"{x:579,y:674,t:1527019624393};\\\", \\\"{x:608,y:663,t:1527019624400};\\\", \\\"{x:641,y:654,t:1527019624410};\\\", \\\"{x:702,y:639,t:1527019624428};\\\", \\\"{x:755,y:631,t:1527019624444};\\\", \\\"{x:808,y:631,t:1527019624460};\\\", \\\"{x:872,y:631,t:1527019624477};\\\", \\\"{x:958,y:631,t:1527019624493};\\\", \\\"{x:1039,y:631,t:1527019624511};\\\", \\\"{x:1120,y:623,t:1527019624527};\\\", \\\"{x:1144,y:622,t:1527019624543};\\\", \\\"{x:1165,y:617,t:1527019624560};\\\", \\\"{x:1183,y:616,t:1527019624577};\\\", \\\"{x:1196,y:613,t:1527019624593};\\\", \\\"{x:1201,y:613,t:1527019624611};\\\", \\\"{x:1204,y:612,t:1527019624628};\\\", \\\"{x:1211,y:612,t:1527019624644};\\\", \\\"{x:1220,y:610,t:1527019624661};\\\", \\\"{x:1229,y:608,t:1527019624678};\\\", \\\"{x:1233,y:607,t:1527019624694};\\\", \\\"{x:1234,y:606,t:1527019624710};\\\", \\\"{x:1241,y:605,t:1527019624728};\\\", \\\"{x:1249,y:602,t:1527019624745};\\\", \\\"{x:1253,y:601,t:1527019624761};\\\", \\\"{x:1264,y:597,t:1527019624778};\\\", \\\"{x:1270,y:597,t:1527019624795};\\\", \\\"{x:1273,y:595,t:1527019624810};\\\", \\\"{x:1275,y:595,t:1527019624827};\\\", \\\"{x:1277,y:594,t:1527019624844};\\\", \\\"{x:1279,y:594,t:1527019624860};\\\", \\\"{x:1285,y:593,t:1527019624877};\\\", \\\"{x:1294,y:592,t:1527019624894};\\\", \\\"{x:1311,y:591,t:1527019624911};\\\", \\\"{x:1331,y:591,t:1527019624927};\\\", \\\"{x:1343,y:591,t:1527019624944};\\\", \\\"{x:1360,y:591,t:1527019624961};\\\", \\\"{x:1375,y:591,t:1527019624977};\\\", \\\"{x:1387,y:591,t:1527019624994};\\\", \\\"{x:1401,y:588,t:1527019625011};\\\", \\\"{x:1412,y:586,t:1527019625027};\\\", \\\"{x:1419,y:586,t:1527019625044};\\\", \\\"{x:1421,y:584,t:1527019625060};\\\", \\\"{x:1425,y:584,t:1527019625078};\\\", \\\"{x:1429,y:584,t:1527019625094};\\\", \\\"{x:1435,y:582,t:1527019625111};\\\", \\\"{x:1451,y:573,t:1527019625127};\\\", \\\"{x:1469,y:562,t:1527019625144};\\\", \\\"{x:1493,y:545,t:1527019625160};\\\", \\\"{x:1510,y:535,t:1527019625177};\\\", \\\"{x:1513,y:534,t:1527019625194};\\\", \\\"{x:1514,y:535,t:1527019625296};\\\", \\\"{x:1529,y:552,t:1527019625312};\\\", \\\"{x:1540,y:558,t:1527019625328};\\\", \\\"{x:1541,y:558,t:1527019625345};\\\", \\\"{x:1538,y:562,t:1527019625760};\\\", \\\"{x:1529,y:567,t:1527019625768};\\\", \\\"{x:1519,y:572,t:1527019625778};\\\", \\\"{x:1497,y:584,t:1527019625795};\\\", \\\"{x:1466,y:601,t:1527019625812};\\\", \\\"{x:1440,y:610,t:1527019625829};\\\", \\\"{x:1415,y:622,t:1527019625845};\\\", \\\"{x:1386,y:629,t:1527019625862};\\\", \\\"{x:1358,y:637,t:1527019625878};\\\", \\\"{x:1330,y:644,t:1527019625895};\\\", \\\"{x:1308,y:650,t:1527019625912};\\\", \\\"{x:1307,y:651,t:1527019625929};\\\", \\\"{x:1306,y:652,t:1527019625952};\\\", \\\"{x:1306,y:653,t:1527019626032};\\\", \\\"{x:1306,y:659,t:1527019626045};\\\", \\\"{x:1308,y:675,t:1527019626062};\\\", \\\"{x:1314,y:693,t:1527019626079};\\\", \\\"{x:1319,y:709,t:1527019626095};\\\", \\\"{x:1326,y:727,t:1527019626112};\\\", \\\"{x:1332,y:740,t:1527019626129};\\\", \\\"{x:1341,y:755,t:1527019626145};\\\", \\\"{x:1350,y:771,t:1527019626161};\\\", \\\"{x:1359,y:787,t:1527019626178};\\\", \\\"{x:1366,y:801,t:1527019626194};\\\", \\\"{x:1373,y:817,t:1527019626211};\\\", \\\"{x:1379,y:833,t:1527019626229};\\\", \\\"{x:1385,y:846,t:1527019626244};\\\", \\\"{x:1387,y:854,t:1527019626261};\\\", \\\"{x:1387,y:855,t:1527019626287};\\\", \\\"{x:1387,y:856,t:1527019626592};\\\", \\\"{x:1387,y:857,t:1527019626600};\\\", \\\"{x:1385,y:858,t:1527019626612};\\\", \\\"{x:1382,y:858,t:1527019626629};\\\", \\\"{x:1377,y:859,t:1527019626646};\\\", \\\"{x:1374,y:861,t:1527019626662};\\\", \\\"{x:1367,y:864,t:1527019626679};\\\", \\\"{x:1343,y:870,t:1527019626695};\\\", \\\"{x:1319,y:876,t:1527019626712};\\\", \\\"{x:1281,y:884,t:1527019626729};\\\", \\\"{x:1239,y:890,t:1527019626746};\\\", \\\"{x:1192,y:897,t:1527019626763};\\\", \\\"{x:1164,y:900,t:1527019626779};\\\", \\\"{x:1142,y:900,t:1527019626796};\\\", \\\"{x:1127,y:900,t:1527019626813};\\\", \\\"{x:1121,y:900,t:1527019626829};\\\", \\\"{x:1119,y:900,t:1527019626846};\\\", \\\"{x:1119,y:899,t:1527019626953};\\\", \\\"{x:1119,y:897,t:1527019626963};\\\", \\\"{x:1122,y:893,t:1527019626980};\\\", \\\"{x:1126,y:890,t:1527019626996};\\\", \\\"{x:1129,y:887,t:1527019627013};\\\", \\\"{x:1132,y:885,t:1527019627029};\\\", \\\"{x:1136,y:882,t:1527019627047};\\\", \\\"{x:1137,y:882,t:1527019627063};\\\", \\\"{x:1140,y:879,t:1527019627079};\\\", \\\"{x:1147,y:876,t:1527019627096};\\\", \\\"{x:1155,y:874,t:1527019627113};\\\", \\\"{x:1159,y:872,t:1527019627129};\\\", \\\"{x:1167,y:868,t:1527019627146};\\\", \\\"{x:1170,y:867,t:1527019627163};\\\", \\\"{x:1178,y:862,t:1527019627179};\\\", \\\"{x:1182,y:860,t:1527019627196};\\\", \\\"{x:1183,y:859,t:1527019627213};\\\", \\\"{x:1188,y:857,t:1527019627229};\\\", \\\"{x:1190,y:855,t:1527019627247};\\\", \\\"{x:1194,y:853,t:1527019627263};\\\", \\\"{x:1197,y:851,t:1527019627279};\\\", \\\"{x:1198,y:850,t:1527019627296};\\\", \\\"{x:1199,y:849,t:1527019627313};\\\", \\\"{x:1200,y:849,t:1527019627343};\\\", \\\"{x:1200,y:848,t:1527019627601};\\\", \\\"{x:1202,y:847,t:1527019627613};\\\", \\\"{x:1203,y:846,t:1527019627630};\\\", \\\"{x:1203,y:844,t:1527019627646};\\\", \\\"{x:1204,y:843,t:1527019627663};\\\", \\\"{x:1206,y:840,t:1527019627680};\\\", \\\"{x:1207,y:839,t:1527019627703};\\\", \\\"{x:1207,y:838,t:1527019627719};\\\", \\\"{x:1207,y:837,t:1527019627736};\\\", \\\"{x:1207,y:836,t:1527019627783};\\\", \\\"{x:1207,y:835,t:1527019627799};\\\", \\\"{x:1209,y:833,t:1527019627815};\\\", \\\"{x:1209,y:834,t:1527019628560};\\\", \\\"{x:1212,y:835,t:1527019628570};\\\", \\\"{x:1216,y:835,t:1527019628580};\\\", \\\"{x:1217,y:835,t:1527019628614};\\\", \\\"{x:1218,y:835,t:1527019629593};\\\", \\\"{x:1219,y:835,t:1527019629600};\\\", \\\"{x:1219,y:836,t:1527019629936};\\\", \\\"{x:1219,y:839,t:1527019629949};\\\", \\\"{x:1212,y:847,t:1527019629966};\\\", \\\"{x:1203,y:851,t:1527019629981};\\\", \\\"{x:1198,y:851,t:1527019629998};\\\", \\\"{x:1197,y:851,t:1527019630015};\\\", \\\"{x:1197,y:850,t:1527019630656};\\\", \\\"{x:1198,y:849,t:1527019630665};\\\", \\\"{x:1199,y:849,t:1527019630682};\\\", \\\"{x:1200,y:848,t:1527019630699};\\\", \\\"{x:1201,y:847,t:1527019630715};\\\", \\\"{x:1202,y:846,t:1527019630732};\\\", \\\"{x:1203,y:845,t:1527019630748};\\\", \\\"{x:1204,y:844,t:1527019630848};\\\", \\\"{x:1206,y:844,t:1527019630872};\\\", \\\"{x:1207,y:843,t:1527019630882};\\\", \\\"{x:1209,y:843,t:1527019630900};\\\", \\\"{x:1211,y:840,t:1527019630915};\\\", \\\"{x:1212,y:839,t:1527019630933};\\\", \\\"{x:1214,y:837,t:1527019631832};\\\", \\\"{x:1216,y:834,t:1527019631850};\\\", \\\"{x:1216,y:833,t:1527019631867};\\\", \\\"{x:1217,y:833,t:1527019633136};\\\", \\\"{x:1218,y:833,t:1527019633400};\\\", \\\"{x:1218,y:835,t:1527019636729};\\\", \\\"{x:1218,y:845,t:1527019636736};\\\", \\\"{x:1218,y:867,t:1527019636752};\\\", \\\"{x:1218,y:886,t:1527019636770};\\\", \\\"{x:1218,y:897,t:1527019636786};\\\", \\\"{x:1218,y:905,t:1527019636803};\\\", \\\"{x:1218,y:912,t:1527019636819};\\\", \\\"{x:1218,y:915,t:1527019636836};\\\", \\\"{x:1217,y:917,t:1527019636852};\\\", \\\"{x:1217,y:920,t:1527019636869};\\\", \\\"{x:1217,y:923,t:1527019636886};\\\", \\\"{x:1217,y:926,t:1527019636903};\\\", \\\"{x:1218,y:929,t:1527019636919};\\\", \\\"{x:1218,y:931,t:1527019636936};\\\", \\\"{x:1218,y:933,t:1527019636952};\\\", \\\"{x:1218,y:934,t:1527019636970};\\\", \\\"{x:1219,y:938,t:1527019636987};\\\", \\\"{x:1219,y:941,t:1527019637002};\\\", \\\"{x:1219,y:945,t:1527019637020};\\\", \\\"{x:1219,y:949,t:1527019637036};\\\", \\\"{x:1219,y:953,t:1527019637053};\\\", \\\"{x:1219,y:957,t:1527019637070};\\\", \\\"{x:1219,y:961,t:1527019637086};\\\", \\\"{x:1220,y:965,t:1527019637103};\\\", \\\"{x:1221,y:965,t:1527019637176};\\\", \\\"{x:1222,y:965,t:1527019637187};\\\", \\\"{x:1224,y:962,t:1527019637203};\\\", \\\"{x:1226,y:957,t:1527019637219};\\\", \\\"{x:1228,y:953,t:1527019637237};\\\", \\\"{x:1230,y:947,t:1527019637253};\\\", \\\"{x:1234,y:940,t:1527019637270};\\\", \\\"{x:1237,y:935,t:1527019637286};\\\", \\\"{x:1239,y:930,t:1527019637303};\\\", \\\"{x:1239,y:929,t:1527019637320};\\\", \\\"{x:1240,y:928,t:1527019637336};\\\", \\\"{x:1241,y:926,t:1527019637360};\\\", \\\"{x:1241,y:925,t:1527019637383};\\\", \\\"{x:1241,y:924,t:1527019637399};\\\", \\\"{x:1242,y:922,t:1527019637407};\\\", \\\"{x:1243,y:921,t:1527019637424};\\\", \\\"{x:1243,y:919,t:1527019637436};\\\", \\\"{x:1244,y:917,t:1527019637453};\\\", \\\"{x:1245,y:914,t:1527019637469};\\\", \\\"{x:1248,y:909,t:1527019637486};\\\", \\\"{x:1252,y:902,t:1527019637504};\\\", \\\"{x:1255,y:895,t:1527019637519};\\\", \\\"{x:1256,y:891,t:1527019637537};\\\", \\\"{x:1260,y:885,t:1527019637553};\\\", \\\"{x:1263,y:879,t:1527019637569};\\\", \\\"{x:1265,y:877,t:1527019637586};\\\", \\\"{x:1265,y:873,t:1527019637603};\\\", \\\"{x:1267,y:869,t:1527019637620};\\\", \\\"{x:1269,y:864,t:1527019637636};\\\", \\\"{x:1271,y:859,t:1527019637654};\\\", \\\"{x:1273,y:855,t:1527019637671};\\\", \\\"{x:1275,y:852,t:1527019637687};\\\", \\\"{x:1277,y:848,t:1527019637704};\\\", \\\"{x:1278,y:847,t:1527019637721};\\\", \\\"{x:1279,y:845,t:1527019637737};\\\", \\\"{x:1279,y:842,t:1527019637753};\\\", \\\"{x:1281,y:839,t:1527019637770};\\\", \\\"{x:1282,y:837,t:1527019637786};\\\", \\\"{x:1284,y:832,t:1527019637804};\\\", \\\"{x:1287,y:827,t:1527019637821};\\\", \\\"{x:1290,y:821,t:1527019637837};\\\", \\\"{x:1293,y:816,t:1527019637853};\\\", \\\"{x:1296,y:811,t:1527019637870};\\\", \\\"{x:1299,y:807,t:1527019637887};\\\", \\\"{x:1301,y:803,t:1527019637904};\\\", \\\"{x:1302,y:801,t:1527019637921};\\\", \\\"{x:1302,y:800,t:1527019637936};\\\", \\\"{x:1303,y:799,t:1527019637953};\\\", \\\"{x:1304,y:798,t:1527019637975};\\\", \\\"{x:1305,y:797,t:1527019637986};\\\", \\\"{x:1305,y:796,t:1527019638008};\\\", \\\"{x:1306,y:793,t:1527019638032};\\\", \\\"{x:1308,y:793,t:1527019638055};\\\", \\\"{x:1308,y:792,t:1527019638070};\\\", \\\"{x:1309,y:789,t:1527019638086};\\\", \\\"{x:1314,y:786,t:1527019638104};\\\", \\\"{x:1318,y:782,t:1527019638120};\\\", \\\"{x:1329,y:775,t:1527019638137};\\\", \\\"{x:1338,y:770,t:1527019638153};\\\", \\\"{x:1338,y:769,t:1527019638656};\\\", \\\"{x:1338,y:771,t:1527019638703};\\\", \\\"{x:1336,y:788,t:1527019638721};\\\", \\\"{x:1331,y:815,t:1527019638738};\\\", \\\"{x:1323,y:840,t:1527019638754};\\\", \\\"{x:1312,y:871,t:1527019638771};\\\", \\\"{x:1300,y:897,t:1527019638787};\\\", \\\"{x:1288,y:920,t:1527019638805};\\\", \\\"{x:1279,y:937,t:1527019638821};\\\", \\\"{x:1273,y:953,t:1527019638838};\\\", \\\"{x:1269,y:961,t:1527019638854};\\\", \\\"{x:1266,y:966,t:1527019638870};\\\", \\\"{x:1264,y:971,t:1527019638888};\\\", \\\"{x:1263,y:973,t:1527019638903};\\\", \\\"{x:1262,y:974,t:1527019638920};\\\", \\\"{x:1261,y:976,t:1527019638938};\\\", \\\"{x:1260,y:977,t:1527019638954};\\\", \\\"{x:1258,y:979,t:1527019638970};\\\", \\\"{x:1256,y:980,t:1527019638987};\\\", \\\"{x:1252,y:981,t:1527019639004};\\\", \\\"{x:1239,y:981,t:1527019639020};\\\", \\\"{x:1220,y:981,t:1527019639037};\\\", \\\"{x:1199,y:981,t:1527019639054};\\\", \\\"{x:1180,y:981,t:1527019639071};\\\", \\\"{x:1161,y:981,t:1527019639088};\\\", \\\"{x:1152,y:979,t:1527019639105};\\\", \\\"{x:1149,y:977,t:1527019639120};\\\", \\\"{x:1149,y:976,t:1527019639143};\\\", \\\"{x:1149,y:975,t:1527019639160};\\\", \\\"{x:1149,y:973,t:1527019639171};\\\", \\\"{x:1149,y:968,t:1527019639188};\\\", \\\"{x:1149,y:965,t:1527019639204};\\\", \\\"{x:1150,y:963,t:1527019639222};\\\", \\\"{x:1152,y:961,t:1527019639238};\\\", \\\"{x:1156,y:958,t:1527019639255};\\\", \\\"{x:1164,y:955,t:1527019639272};\\\", \\\"{x:1174,y:953,t:1527019639288};\\\", \\\"{x:1184,y:950,t:1527019639305};\\\", \\\"{x:1195,y:950,t:1527019639321};\\\", \\\"{x:1206,y:949,t:1527019639338};\\\", \\\"{x:1213,y:948,t:1527019639354};\\\", \\\"{x:1217,y:945,t:1527019639372};\\\", \\\"{x:1220,y:944,t:1527019639387};\\\", \\\"{x:1223,y:938,t:1527019639404};\\\", \\\"{x:1225,y:933,t:1527019639421};\\\", \\\"{x:1228,y:925,t:1527019639438};\\\", \\\"{x:1234,y:913,t:1527019639455};\\\", \\\"{x:1242,y:895,t:1527019639471};\\\", \\\"{x:1248,y:880,t:1527019639487};\\\", \\\"{x:1255,y:864,t:1527019639505};\\\", \\\"{x:1264,y:845,t:1527019639521};\\\", \\\"{x:1272,y:825,t:1527019639538};\\\", \\\"{x:1279,y:808,t:1527019639555};\\\", \\\"{x:1287,y:791,t:1527019639571};\\\", \\\"{x:1293,y:775,t:1527019639587};\\\", \\\"{x:1298,y:762,t:1527019639605};\\\", \\\"{x:1303,y:750,t:1527019639621};\\\", \\\"{x:1310,y:739,t:1527019639637};\\\", \\\"{x:1315,y:729,t:1527019639655};\\\", \\\"{x:1320,y:719,t:1527019639671};\\\", \\\"{x:1322,y:715,t:1527019639688};\\\", \\\"{x:1323,y:713,t:1527019639705};\\\", \\\"{x:1324,y:711,t:1527019639721};\\\", \\\"{x:1324,y:710,t:1527019639739};\\\", \\\"{x:1325,y:709,t:1527019639755};\\\", \\\"{x:1327,y:706,t:1527019639772};\\\", \\\"{x:1329,y:704,t:1527019639789};\\\", \\\"{x:1330,y:703,t:1527019639805};\\\", \\\"{x:1331,y:702,t:1527019639821};\\\", \\\"{x:1332,y:700,t:1527019639839};\\\", \\\"{x:1333,y:699,t:1527019639855};\\\", \\\"{x:1334,y:696,t:1527019639872};\\\", \\\"{x:1336,y:692,t:1527019639888};\\\", \\\"{x:1338,y:689,t:1527019639905};\\\", \\\"{x:1340,y:685,t:1527019639921};\\\", \\\"{x:1344,y:678,t:1527019639938};\\\", \\\"{x:1349,y:671,t:1527019639954};\\\", \\\"{x:1354,y:663,t:1527019639972};\\\", \\\"{x:1362,y:652,t:1527019639988};\\\", \\\"{x:1366,y:645,t:1527019640005};\\\", \\\"{x:1369,y:639,t:1527019640021};\\\", \\\"{x:1372,y:632,t:1527019640039};\\\", \\\"{x:1376,y:624,t:1527019640055};\\\", \\\"{x:1381,y:611,t:1527019640071};\\\", \\\"{x:1385,y:605,t:1527019640089};\\\", \\\"{x:1386,y:598,t:1527019640104};\\\", \\\"{x:1389,y:592,t:1527019640121};\\\", \\\"{x:1390,y:586,t:1527019640139};\\\", \\\"{x:1393,y:581,t:1527019640155};\\\", \\\"{x:1394,y:579,t:1527019640176};\\\", \\\"{x:1393,y:579,t:1527019640232};\\\", \\\"{x:1388,y:579,t:1527019640239};\\\", \\\"{x:1376,y:584,t:1527019640255};\\\", \\\"{x:1336,y:596,t:1527019640271};\\\", \\\"{x:1283,y:610,t:1527019640288};\\\", \\\"{x:1213,y:621,t:1527019640306};\\\", \\\"{x:1131,y:628,t:1527019640322};\\\", \\\"{x:1051,y:628,t:1527019640339};\\\", \\\"{x:978,y:628,t:1527019640355};\\\", \\\"{x:916,y:628,t:1527019640371};\\\", \\\"{x:860,y:620,t:1527019640388};\\\", \\\"{x:813,y:614,t:1527019640405};\\\", \\\"{x:782,y:610,t:1527019640423};\\\", \\\"{x:757,y:610,t:1527019640438};\\\", \\\"{x:720,y:610,t:1527019640455};\\\", \\\"{x:698,y:607,t:1527019640471};\\\", \\\"{x:672,y:603,t:1527019640489};\\\", \\\"{x:643,y:601,t:1527019640507};\\\", \\\"{x:590,y:601,t:1527019640523};\\\", \\\"{x:523,y:601,t:1527019640540};\\\", \\\"{x:437,y:601,t:1527019640557};\\\", \\\"{x:353,y:601,t:1527019640574};\\\", \\\"{x:299,y:598,t:1527019640590};\\\", \\\"{x:247,y:589,t:1527019640607};\\\", \\\"{x:230,y:584,t:1527019640624};\\\", \\\"{x:228,y:584,t:1527019640640};\\\", \\\"{x:227,y:584,t:1527019640663};\\\", \\\"{x:227,y:583,t:1527019640703};\\\", \\\"{x:231,y:581,t:1527019640712};\\\", \\\"{x:237,y:579,t:1527019640723};\\\", \\\"{x:250,y:574,t:1527019640741};\\\", \\\"{x:266,y:566,t:1527019640756};\\\", \\\"{x:282,y:559,t:1527019640774};\\\", \\\"{x:298,y:551,t:1527019640790};\\\", \\\"{x:316,y:543,t:1527019640807};\\\", \\\"{x:320,y:542,t:1527019640824};\\\", \\\"{x:322,y:539,t:1527019640839};\\\", \\\"{x:323,y:539,t:1527019640856};\\\", \\\"{x:324,y:539,t:1527019640874};\\\", \\\"{x:326,y:538,t:1527019640890};\\\", \\\"{x:327,y:538,t:1527019640907};\\\", \\\"{x:329,y:536,t:1527019640925};\\\", \\\"{x:332,y:535,t:1527019640940};\\\", \\\"{x:338,y:532,t:1527019640957};\\\", \\\"{x:346,y:527,t:1527019640974};\\\", \\\"{x:356,y:523,t:1527019640991};\\\", \\\"{x:360,y:522,t:1527019641007};\\\", \\\"{x:365,y:519,t:1527019641024};\\\", \\\"{x:373,y:517,t:1527019641041};\\\", \\\"{x:380,y:515,t:1527019641057};\\\", \\\"{x:382,y:514,t:1527019641074};\\\", \\\"{x:384,y:513,t:1527019641091};\\\", \\\"{x:385,y:513,t:1527019641107};\\\", \\\"{x:385,y:512,t:1527019641235};\\\", \\\"{x:397,y:507,t:1527019641258};\\\", \\\"{x:411,y:506,t:1527019641274};\\\", \\\"{x:433,y:504,t:1527019641291};\\\", \\\"{x:461,y:504,t:1527019641306};\\\", \\\"{x:484,y:504,t:1527019641324};\\\", \\\"{x:502,y:504,t:1527019641341};\\\", \\\"{x:512,y:504,t:1527019641356};\\\", \\\"{x:518,y:504,t:1527019641374};\\\", \\\"{x:527,y:505,t:1527019641391};\\\", \\\"{x:540,y:509,t:1527019641408};\\\", \\\"{x:565,y:516,t:1527019641424};\\\", \\\"{x:591,y:524,t:1527019641441};\\\", \\\"{x:616,y:528,t:1527019641457};\\\", \\\"{x:633,y:532,t:1527019641474};\\\", \\\"{x:643,y:533,t:1527019641491};\\\", \\\"{x:647,y:533,t:1527019641507};\\\", \\\"{x:649,y:534,t:1527019641524};\\\", \\\"{x:649,y:535,t:1527019641541};\\\", \\\"{x:651,y:535,t:1527019641558};\\\", \\\"{x:652,y:536,t:1527019641574};\\\", \\\"{x:653,y:536,t:1527019641680};\\\", \\\"{x:652,y:538,t:1527019641692};\\\", \\\"{x:650,y:538,t:1527019641708};\\\", \\\"{x:645,y:541,t:1527019641724};\\\", \\\"{x:641,y:544,t:1527019641741};\\\", \\\"{x:640,y:546,t:1527019641757};\\\", \\\"{x:637,y:548,t:1527019641774};\\\", \\\"{x:635,y:548,t:1527019641791};\\\", \\\"{x:633,y:552,t:1527019641982};\\\", \\\"{x:628,y:562,t:1527019641991};\\\", \\\"{x:614,y:595,t:1527019642009};\\\", \\\"{x:595,y:637,t:1527019642026};\\\", \\\"{x:581,y:666,t:1527019642041};\\\", \\\"{x:571,y:686,t:1527019642058};\\\", \\\"{x:565,y:702,t:1527019642075};\\\", \\\"{x:560,y:714,t:1527019642091};\\\", \\\"{x:556,y:721,t:1527019642107};\\\", \\\"{x:553,y:725,t:1527019642124};\\\", \\\"{x:552,y:726,t:1527019642141};\\\", \\\"{x:551,y:725,t:1527019642207};\\\", \\\"{x:550,y:724,t:1527019642215};\\\", \\\"{x:549,y:723,t:1527019642224};\\\", \\\"{x:548,y:723,t:1527019642241};\\\", \\\"{x:547,y:722,t:1527019642278};\\\", \\\"{x:544,y:722,t:1527019642295};\\\", \\\"{x:543,y:722,t:1527019642308};\\\", \\\"{x:538,y:722,t:1527019642324};\\\", \\\"{x:535,y:722,t:1527019642341};\\\", \\\"{x:535,y:721,t:1527019642886};\\\", \\\"{x:536,y:720,t:1527019642910};\\\", \\\"{x:538,y:720,t:1527019642959};\\\", \\\"{x:539,y:719,t:1527019642975};\\\", \\\"{x:540,y:718,t:1527019643007};\\\", \\\"{x:540,y:717,t:1527019643024};\\\", \\\"{x:541,y:717,t:1527019643039};\\\", \\\"{x:542,y:716,t:1527019643047};\\\", \\\"{x:542,y:715,t:1527019643087};\\\", \\\"{x:542,y:714,t:1527019643103};\\\", \\\"{x:543,y:713,t:1527019643111};\\\", \\\"{x:543,y:712,t:1527019643135};\\\", \\\"{x:544,y:712,t:1527019643151};\\\", \\\"{x:544,y:711,t:1527019643167};\\\", \\\"{x:545,y:710,t:1527019643183};\\\", \\\"{x:545,y:708,t:1527019643255};\\\", \\\"{x:545,y:707,t:1527019643303};\\\" ] }, { \\\"rt\\\": 21919, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 288719, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-D -D -E -04 PM-D -D -12 PM-12 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:702,t:1527019644360};\\\", \\\"{x:572,y:678,t:1527019644376};\\\", \\\"{x:635,y:643,t:1527019644393};\\\", \\\"{x:714,y:610,t:1527019644411};\\\", \\\"{x:814,y:580,t:1527019644426};\\\", \\\"{x:922,y:552,t:1527019644443};\\\", \\\"{x:1022,y:536,t:1527019644460};\\\", \\\"{x:1129,y:524,t:1527019644477};\\\", \\\"{x:1272,y:523,t:1527019644493};\\\", \\\"{x:1404,y:538,t:1527019644510};\\\", \\\"{x:1499,y:542,t:1527019644526};\\\", \\\"{x:1529,y:549,t:1527019644543};\\\", \\\"{x:1529,y:550,t:1527019644560};\\\", \\\"{x:1526,y:552,t:1527019644768};\\\", \\\"{x:1524,y:556,t:1527019644777};\\\", \\\"{x:1521,y:560,t:1527019644793};\\\", \\\"{x:1516,y:569,t:1527019644810};\\\", \\\"{x:1512,y:584,t:1527019644828};\\\", \\\"{x:1505,y:606,t:1527019644843};\\\", \\\"{x:1499,y:640,t:1527019644861};\\\", \\\"{x:1493,y:690,t:1527019644878};\\\", \\\"{x:1489,y:752,t:1527019644894};\\\", \\\"{x:1486,y:812,t:1527019644911};\\\", \\\"{x:1483,y:824,t:1527019644927};\\\", \\\"{x:1482,y:825,t:1527019645272};\\\", \\\"{x:1481,y:825,t:1527019645279};\\\", \\\"{x:1480,y:826,t:1527019645384};\\\", \\\"{x:1479,y:826,t:1527019645395};\\\", \\\"{x:1478,y:827,t:1527019645411};\\\", \\\"{x:1476,y:828,t:1527019645428};\\\", \\\"{x:1474,y:828,t:1527019645445};\\\", \\\"{x:1472,y:829,t:1527019645461};\\\", \\\"{x:1471,y:830,t:1527019645592};\\\", \\\"{x:1471,y:832,t:1527019645616};\\\", \\\"{x:1468,y:840,t:1527019645628};\\\", \\\"{x:1468,y:854,t:1527019645645};\\\", \\\"{x:1473,y:874,t:1527019645661};\\\", \\\"{x:1484,y:895,t:1527019645678};\\\", \\\"{x:1498,y:911,t:1527019645695};\\\", \\\"{x:1529,y:930,t:1527019645712};\\\", \\\"{x:1551,y:939,t:1527019645728};\\\", \\\"{x:1570,y:946,t:1527019645745};\\\", \\\"{x:1588,y:952,t:1527019645762};\\\", \\\"{x:1601,y:957,t:1527019645777};\\\", \\\"{x:1608,y:959,t:1527019645794};\\\", \\\"{x:1611,y:960,t:1527019645812};\\\", \\\"{x:1612,y:960,t:1527019645828};\\\", \\\"{x:1609,y:960,t:1527019646000};\\\", \\\"{x:1602,y:961,t:1527019646012};\\\", \\\"{x:1586,y:966,t:1527019646029};\\\", \\\"{x:1571,y:970,t:1527019646044};\\\", \\\"{x:1556,y:974,t:1527019646062};\\\", \\\"{x:1547,y:974,t:1527019646079};\\\", \\\"{x:1535,y:974,t:1527019646095};\\\", \\\"{x:1531,y:974,t:1527019646112};\\\", \\\"{x:1531,y:973,t:1527019646143};\\\", \\\"{x:1531,y:972,t:1527019646151};\\\", \\\"{x:1531,y:971,t:1527019646161};\\\", \\\"{x:1534,y:966,t:1527019646180};\\\", \\\"{x:1538,y:963,t:1527019646195};\\\", \\\"{x:1543,y:963,t:1527019646212};\\\", \\\"{x:1554,y:960,t:1527019646230};\\\", \\\"{x:1561,y:959,t:1527019646245};\\\", \\\"{x:1573,y:958,t:1527019646261};\\\", \\\"{x:1583,y:958,t:1527019646279};\\\", \\\"{x:1592,y:958,t:1527019646295};\\\", \\\"{x:1603,y:958,t:1527019646312};\\\", \\\"{x:1607,y:958,t:1527019646328};\\\", \\\"{x:1608,y:958,t:1527019646448};\\\", \\\"{x:1608,y:957,t:1527019646479};\\\", \\\"{x:1610,y:954,t:1527019646496};\\\", \\\"{x:1611,y:953,t:1527019646511};\\\", \\\"{x:1614,y:951,t:1527019646528};\\\", \\\"{x:1615,y:949,t:1527019646545};\\\", \\\"{x:1617,y:947,t:1527019646561};\\\", \\\"{x:1618,y:946,t:1527019646578};\\\", \\\"{x:1621,y:943,t:1527019646595};\\\", \\\"{x:1622,y:942,t:1527019646611};\\\", \\\"{x:1624,y:940,t:1527019646628};\\\", \\\"{x:1625,y:939,t:1527019646646};\\\", \\\"{x:1627,y:937,t:1527019646661};\\\", \\\"{x:1628,y:936,t:1527019646687};\\\", \\\"{x:1629,y:936,t:1527019646696};\\\", \\\"{x:1629,y:935,t:1527019646712};\\\", \\\"{x:1630,y:934,t:1527019646728};\\\", \\\"{x:1631,y:933,t:1527019646751};\\\", \\\"{x:1632,y:932,t:1527019646864};\\\", \\\"{x:1632,y:931,t:1527019646878};\\\", \\\"{x:1633,y:930,t:1527019646896};\\\", \\\"{x:1633,y:928,t:1527019646913};\\\", \\\"{x:1635,y:927,t:1527019646928};\\\", \\\"{x:1636,y:925,t:1527019646945};\\\", \\\"{x:1638,y:923,t:1527019646961};\\\", \\\"{x:1640,y:920,t:1527019646978};\\\", \\\"{x:1644,y:916,t:1527019646995};\\\", \\\"{x:1646,y:914,t:1527019647012};\\\", \\\"{x:1647,y:911,t:1527019647028};\\\", \\\"{x:1649,y:909,t:1527019647045};\\\", \\\"{x:1649,y:906,t:1527019647063};\\\", \\\"{x:1651,y:903,t:1527019647078};\\\", \\\"{x:1654,y:897,t:1527019647095};\\\", \\\"{x:1657,y:892,t:1527019647112};\\\", \\\"{x:1657,y:890,t:1527019647128};\\\", \\\"{x:1660,y:885,t:1527019647145};\\\", \\\"{x:1660,y:882,t:1527019647162};\\\", \\\"{x:1661,y:879,t:1527019647178};\\\", \\\"{x:1663,y:877,t:1527019647196};\\\", \\\"{x:1663,y:874,t:1527019647212};\\\", \\\"{x:1664,y:871,t:1527019647229};\\\", \\\"{x:1666,y:867,t:1527019647245};\\\", \\\"{x:1667,y:862,t:1527019647262};\\\", \\\"{x:1669,y:858,t:1527019647279};\\\", \\\"{x:1672,y:852,t:1527019647296};\\\", \\\"{x:1672,y:850,t:1527019647312};\\\", \\\"{x:1674,y:849,t:1527019647329};\\\", \\\"{x:1674,y:847,t:1527019647346};\\\", \\\"{x:1675,y:846,t:1527019647376};\\\", \\\"{x:1675,y:844,t:1527019647383};\\\", \\\"{x:1677,y:841,t:1527019647407};\\\", \\\"{x:1677,y:840,t:1527019647432};\\\", \\\"{x:1678,y:840,t:1527019647463};\\\", \\\"{x:1678,y:841,t:1527019647624};\\\", \\\"{x:1677,y:841,t:1527019647639};\\\", \\\"{x:1677,y:842,t:1527019647656};\\\", \\\"{x:1675,y:842,t:1527019647704};\\\", \\\"{x:1674,y:843,t:1527019647713};\\\", \\\"{x:1673,y:844,t:1527019647730};\\\", \\\"{x:1670,y:845,t:1527019647746};\\\", \\\"{x:1669,y:845,t:1527019647762};\\\", \\\"{x:1665,y:847,t:1527019647779};\\\", \\\"{x:1663,y:848,t:1527019647799};\\\", \\\"{x:1662,y:848,t:1527019647848};\\\", \\\"{x:1661,y:848,t:1527019647863};\\\", \\\"{x:1653,y:856,t:1527019647879};\\\", \\\"{x:1642,y:866,t:1527019647897};\\\", \\\"{x:1629,y:877,t:1527019647913};\\\", \\\"{x:1615,y:887,t:1527019647929};\\\", \\\"{x:1603,y:897,t:1527019647947};\\\", \\\"{x:1592,y:907,t:1527019647963};\\\", \\\"{x:1586,y:911,t:1527019647980};\\\", \\\"{x:1581,y:913,t:1527019647997};\\\", \\\"{x:1579,y:915,t:1527019648013};\\\", \\\"{x:1578,y:915,t:1527019648029};\\\", \\\"{x:1578,y:914,t:1527019648111};\\\", \\\"{x:1582,y:909,t:1527019648130};\\\", \\\"{x:1584,y:907,t:1527019648147};\\\", \\\"{x:1587,y:902,t:1527019648162};\\\", \\\"{x:1591,y:896,t:1527019648180};\\\", \\\"{x:1592,y:894,t:1527019648197};\\\", \\\"{x:1595,y:890,t:1527019648212};\\\", \\\"{x:1598,y:886,t:1527019648229};\\\", \\\"{x:1601,y:882,t:1527019648246};\\\", \\\"{x:1602,y:880,t:1527019648262};\\\", \\\"{x:1603,y:877,t:1527019648279};\\\", \\\"{x:1603,y:876,t:1527019648297};\\\", \\\"{x:1603,y:875,t:1527019648318};\\\", \\\"{x:1603,y:874,t:1527019648343};\\\", \\\"{x:1603,y:873,t:1527019648359};\\\", \\\"{x:1603,y:872,t:1527019648375};\\\", \\\"{x:1604,y:872,t:1527019648383};\\\", \\\"{x:1604,y:871,t:1527019648396};\\\", \\\"{x:1604,y:870,t:1527019648423};\\\", \\\"{x:1605,y:870,t:1527019648431};\\\", \\\"{x:1605,y:876,t:1527019648559};\\\", \\\"{x:1606,y:885,t:1527019648567};\\\", \\\"{x:1607,y:892,t:1527019648580};\\\", \\\"{x:1610,y:907,t:1527019648597};\\\", \\\"{x:1612,y:921,t:1527019648614};\\\", \\\"{x:1615,y:931,t:1527019648630};\\\", \\\"{x:1615,y:939,t:1527019648647};\\\", \\\"{x:1618,y:947,t:1527019648664};\\\", \\\"{x:1618,y:948,t:1527019648680};\\\", \\\"{x:1619,y:950,t:1527019648697};\\\", \\\"{x:1619,y:951,t:1527019648824};\\\", \\\"{x:1619,y:953,t:1527019648847};\\\", \\\"{x:1619,y:955,t:1527019648864};\\\", \\\"{x:1619,y:958,t:1527019648880};\\\", \\\"{x:1619,y:961,t:1527019648897};\\\", \\\"{x:1618,y:965,t:1527019648914};\\\", \\\"{x:1618,y:966,t:1527019648931};\\\", \\\"{x:1618,y:967,t:1527019648947};\\\", \\\"{x:1617,y:967,t:1527019649215};\\\", \\\"{x:1617,y:966,t:1527019649319};\\\", \\\"{x:1617,y:965,t:1527019649352};\\\", \\\"{x:1616,y:964,t:1527019649367};\\\", \\\"{x:1615,y:963,t:1527019649400};\\\", \\\"{x:1615,y:962,t:1527019649415};\\\", \\\"{x:1614,y:962,t:1527019649431};\\\", \\\"{x:1614,y:960,t:1527019649448};\\\", \\\"{x:1614,y:959,t:1527019649464};\\\", \\\"{x:1614,y:958,t:1527019649528};\\\", \\\"{x:1614,y:957,t:1527019649544};\\\", \\\"{x:1612,y:954,t:1527019649560};\\\", \\\"{x:1612,y:953,t:1527019649640};\\\", \\\"{x:1612,y:952,t:1527019649656};\\\", \\\"{x:1612,y:951,t:1527019649663};\\\", \\\"{x:1612,y:950,t:1527019649681};\\\", \\\"{x:1611,y:948,t:1527019649699};\\\", \\\"{x:1611,y:947,t:1527019649720};\\\", \\\"{x:1611,y:946,t:1527019649735};\\\", \\\"{x:1611,y:945,t:1527019649748};\\\", \\\"{x:1611,y:944,t:1527019649764};\\\", \\\"{x:1611,y:941,t:1527019649781};\\\", \\\"{x:1611,y:938,t:1527019649798};\\\", \\\"{x:1611,y:934,t:1527019649815};\\\", \\\"{x:1611,y:931,t:1527019649831};\\\", \\\"{x:1611,y:930,t:1527019649848};\\\", \\\"{x:1611,y:928,t:1527019649865};\\\", \\\"{x:1611,y:926,t:1527019649880};\\\", \\\"{x:1611,y:923,t:1527019649899};\\\", \\\"{x:1611,y:921,t:1527019649914};\\\", \\\"{x:1611,y:917,t:1527019649931};\\\", \\\"{x:1611,y:915,t:1527019649948};\\\", \\\"{x:1611,y:913,t:1527019649965};\\\", \\\"{x:1611,y:911,t:1527019649981};\\\", \\\"{x:1611,y:909,t:1527019649997};\\\", \\\"{x:1611,y:907,t:1527019650015};\\\", \\\"{x:1611,y:905,t:1527019650031};\\\", \\\"{x:1611,y:904,t:1527019650048};\\\", \\\"{x:1611,y:902,t:1527019650065};\\\", \\\"{x:1611,y:899,t:1527019650081};\\\", \\\"{x:1611,y:898,t:1527019650103};\\\", \\\"{x:1611,y:896,t:1527019650128};\\\", \\\"{x:1611,y:895,t:1527019650151};\\\", \\\"{x:1611,y:893,t:1527019650183};\\\", \\\"{x:1611,y:892,t:1527019650199};\\\", \\\"{x:1611,y:889,t:1527019650215};\\\", \\\"{x:1611,y:887,t:1527019650232};\\\", \\\"{x:1611,y:884,t:1527019650248};\\\", \\\"{x:1611,y:882,t:1527019650265};\\\", \\\"{x:1611,y:877,t:1527019650282};\\\", \\\"{x:1610,y:873,t:1527019650299};\\\", \\\"{x:1610,y:869,t:1527019650315};\\\", \\\"{x:1609,y:864,t:1527019650331};\\\", \\\"{x:1608,y:860,t:1527019650348};\\\", \\\"{x:1608,y:856,t:1527019650364};\\\", \\\"{x:1608,y:853,t:1527019650382};\\\", \\\"{x:1608,y:848,t:1527019650398};\\\", \\\"{x:1608,y:843,t:1527019650415};\\\", \\\"{x:1608,y:838,t:1527019650432};\\\", \\\"{x:1608,y:835,t:1527019650447};\\\", \\\"{x:1608,y:832,t:1527019650465};\\\", \\\"{x:1608,y:830,t:1527019650482};\\\", \\\"{x:1608,y:828,t:1527019650499};\\\", \\\"{x:1608,y:827,t:1527019650515};\\\", \\\"{x:1607,y:825,t:1527019650532};\\\", \\\"{x:1607,y:823,t:1527019650548};\\\", \\\"{x:1607,y:821,t:1527019650565};\\\", \\\"{x:1607,y:820,t:1527019650582};\\\", \\\"{x:1607,y:818,t:1527019650598};\\\", \\\"{x:1607,y:814,t:1527019650615};\\\", \\\"{x:1607,y:810,t:1527019650631};\\\", \\\"{x:1607,y:806,t:1527019650648};\\\", \\\"{x:1607,y:799,t:1527019650664};\\\", \\\"{x:1607,y:792,t:1527019650682};\\\", \\\"{x:1607,y:784,t:1527019650699};\\\", \\\"{x:1605,y:777,t:1527019650715};\\\", \\\"{x:1605,y:770,t:1527019650732};\\\", \\\"{x:1604,y:764,t:1527019650749};\\\", \\\"{x:1604,y:758,t:1527019650765};\\\", \\\"{x:1604,y:752,t:1527019650782};\\\", \\\"{x:1604,y:747,t:1527019650799};\\\", \\\"{x:1604,y:743,t:1527019650815};\\\", \\\"{x:1604,y:741,t:1527019650832};\\\", \\\"{x:1604,y:737,t:1527019650849};\\\", \\\"{x:1604,y:733,t:1527019650865};\\\", \\\"{x:1604,y:730,t:1527019650881};\\\", \\\"{x:1604,y:726,t:1527019650899};\\\", \\\"{x:1604,y:722,t:1527019650915};\\\", \\\"{x:1604,y:717,t:1527019650932};\\\", \\\"{x:1604,y:713,t:1527019650949};\\\", \\\"{x:1604,y:707,t:1527019650965};\\\", \\\"{x:1604,y:702,t:1527019650981};\\\", \\\"{x:1605,y:696,t:1527019650999};\\\", \\\"{x:1605,y:693,t:1527019651015};\\\", \\\"{x:1605,y:688,t:1527019651032};\\\", \\\"{x:1606,y:681,t:1527019651049};\\\", \\\"{x:1609,y:670,t:1527019651065};\\\", \\\"{x:1610,y:652,t:1527019651082};\\\", \\\"{x:1612,y:633,t:1527019651099};\\\", \\\"{x:1615,y:612,t:1527019651115};\\\", \\\"{x:1616,y:594,t:1527019651132};\\\", \\\"{x:1618,y:575,t:1527019651149};\\\", \\\"{x:1619,y:557,t:1527019651165};\\\", \\\"{x:1619,y:539,t:1527019651182};\\\", \\\"{x:1619,y:510,t:1527019651199};\\\", \\\"{x:1619,y:494,t:1527019651216};\\\", \\\"{x:1619,y:477,t:1527019651232};\\\", \\\"{x:1619,y:461,t:1527019651249};\\\", \\\"{x:1619,y:447,t:1527019651266};\\\", \\\"{x:1619,y:436,t:1527019651282};\\\", \\\"{x:1618,y:425,t:1527019651301};\\\", \\\"{x:1618,y:420,t:1527019651317};\\\", \\\"{x:1617,y:416,t:1527019651332};\\\", \\\"{x:1616,y:415,t:1527019651349};\\\", \\\"{x:1616,y:414,t:1527019651365};\\\", \\\"{x:1616,y:413,t:1527019651382};\\\", \\\"{x:1616,y:414,t:1527019651576};\\\", \\\"{x:1616,y:422,t:1527019651583};\\\", \\\"{x:1618,y:438,t:1527019651599};\\\", \\\"{x:1622,y:452,t:1527019651615};\\\", \\\"{x:1626,y:463,t:1527019651632};\\\", \\\"{x:1630,y:477,t:1527019651649};\\\", \\\"{x:1633,y:487,t:1527019651666};\\\", \\\"{x:1636,y:493,t:1527019651682};\\\", \\\"{x:1636,y:497,t:1527019651699};\\\", \\\"{x:1639,y:500,t:1527019651716};\\\", \\\"{x:1642,y:504,t:1527019651733};\\\", \\\"{x:1644,y:509,t:1527019651749};\\\", \\\"{x:1648,y:514,t:1527019651765};\\\", \\\"{x:1652,y:521,t:1527019651782};\\\", \\\"{x:1656,y:529,t:1527019651798};\\\", \\\"{x:1661,y:536,t:1527019651815};\\\", \\\"{x:1665,y:544,t:1527019651832};\\\", \\\"{x:1671,y:555,t:1527019651849};\\\", \\\"{x:1675,y:562,t:1527019651865};\\\", \\\"{x:1677,y:564,t:1527019651882};\\\", \\\"{x:1678,y:565,t:1527019651898};\\\", \\\"{x:1678,y:566,t:1527019651916};\\\", \\\"{x:1679,y:567,t:1527019652048};\\\", \\\"{x:1680,y:567,t:1527019652087};\\\", \\\"{x:1681,y:568,t:1527019652367};\\\", \\\"{x:1681,y:573,t:1527019652384};\\\", \\\"{x:1681,y:590,t:1527019652399};\\\", \\\"{x:1681,y:609,t:1527019652416};\\\", \\\"{x:1681,y:632,t:1527019652433};\\\", \\\"{x:1679,y:654,t:1527019652450};\\\", \\\"{x:1677,y:681,t:1527019652466};\\\", \\\"{x:1674,y:709,t:1527019652483};\\\", \\\"{x:1671,y:736,t:1527019652499};\\\", \\\"{x:1669,y:760,t:1527019652516};\\\", \\\"{x:1666,y:784,t:1527019652533};\\\", \\\"{x:1662,y:803,t:1527019652550};\\\", \\\"{x:1660,y:827,t:1527019652566};\\\", \\\"{x:1655,y:861,t:1527019652584};\\\", \\\"{x:1650,y:881,t:1527019652599};\\\", \\\"{x:1645,y:898,t:1527019652617};\\\", \\\"{x:1640,y:912,t:1527019652633};\\\", \\\"{x:1635,y:924,t:1527019652650};\\\", \\\"{x:1628,y:935,t:1527019652667};\\\", \\\"{x:1622,y:945,t:1527019652683};\\\", \\\"{x:1616,y:954,t:1527019652700};\\\", \\\"{x:1612,y:959,t:1527019652717};\\\", \\\"{x:1606,y:966,t:1527019652733};\\\", \\\"{x:1599,y:971,t:1527019652750};\\\", \\\"{x:1593,y:978,t:1527019652767};\\\", \\\"{x:1586,y:982,t:1527019652783};\\\", \\\"{x:1579,y:984,t:1527019652799};\\\", \\\"{x:1575,y:987,t:1527019652817};\\\", \\\"{x:1573,y:987,t:1527019652833};\\\", \\\"{x:1572,y:987,t:1527019652850};\\\", \\\"{x:1572,y:986,t:1527019652975};\\\", \\\"{x:1571,y:983,t:1527019652991};\\\", \\\"{x:1571,y:981,t:1527019653001};\\\", \\\"{x:1570,y:979,t:1527019653017};\\\", \\\"{x:1569,y:975,t:1527019653033};\\\", \\\"{x:1569,y:974,t:1527019653279};\\\", \\\"{x:1569,y:973,t:1527019653287};\\\", \\\"{x:1570,y:971,t:1527019653303};\\\", \\\"{x:1572,y:970,t:1527019653317};\\\", \\\"{x:1572,y:969,t:1527019653334};\\\", \\\"{x:1574,y:966,t:1527019653350};\\\", \\\"{x:1577,y:964,t:1527019653367};\\\", \\\"{x:1579,y:962,t:1527019653384};\\\", \\\"{x:1580,y:962,t:1527019653400};\\\", \\\"{x:1583,y:960,t:1527019653417};\\\", \\\"{x:1585,y:960,t:1527019653433};\\\", \\\"{x:1590,y:960,t:1527019653450};\\\", \\\"{x:1595,y:959,t:1527019653467};\\\", \\\"{x:1599,y:959,t:1527019653484};\\\", \\\"{x:1603,y:958,t:1527019653500};\\\", \\\"{x:1608,y:957,t:1527019653517};\\\", \\\"{x:1611,y:957,t:1527019653534};\\\", \\\"{x:1613,y:956,t:1527019653551};\\\", \\\"{x:1614,y:955,t:1527019653567};\\\", \\\"{x:1616,y:955,t:1527019653584};\\\", \\\"{x:1620,y:953,t:1527019653601};\\\", \\\"{x:1623,y:950,t:1527019653617};\\\", \\\"{x:1625,y:948,t:1527019653634};\\\", \\\"{x:1628,y:946,t:1527019653651};\\\", \\\"{x:1629,y:945,t:1527019653667};\\\", \\\"{x:1629,y:943,t:1527019653684};\\\", \\\"{x:1630,y:942,t:1527019653701};\\\", \\\"{x:1631,y:941,t:1527019653717};\\\", \\\"{x:1632,y:938,t:1527019653733};\\\", \\\"{x:1634,y:935,t:1527019653750};\\\", \\\"{x:1635,y:933,t:1527019653766};\\\", \\\"{x:1636,y:932,t:1527019653784};\\\", \\\"{x:1636,y:931,t:1527019653814};\\\", \\\"{x:1637,y:931,t:1527019653831};\\\", \\\"{x:1637,y:930,t:1527019653839};\\\", \\\"{x:1637,y:928,t:1527019653863};\\\", \\\"{x:1638,y:926,t:1527019653871};\\\", \\\"{x:1638,y:924,t:1527019653895};\\\", \\\"{x:1638,y:922,t:1527019653911};\\\", \\\"{x:1639,y:921,t:1527019653919};\\\", \\\"{x:1640,y:919,t:1527019653934};\\\", \\\"{x:1642,y:914,t:1527019653951};\\\", \\\"{x:1645,y:908,t:1527019653967};\\\", \\\"{x:1650,y:901,t:1527019653984};\\\", \\\"{x:1653,y:896,t:1527019654001};\\\", \\\"{x:1656,y:888,t:1527019654018};\\\", \\\"{x:1661,y:881,t:1527019654034};\\\", \\\"{x:1666,y:870,t:1527019654051};\\\", \\\"{x:1673,y:861,t:1527019654068};\\\", \\\"{x:1676,y:855,t:1527019654084};\\\", \\\"{x:1680,y:851,t:1527019654101};\\\", \\\"{x:1680,y:849,t:1527019654117};\\\", \\\"{x:1681,y:847,t:1527019654134};\\\", \\\"{x:1681,y:846,t:1527019654174};\\\", \\\"{x:1681,y:845,t:1527019654206};\\\", \\\"{x:1681,y:844,t:1527019654231};\\\", \\\"{x:1682,y:844,t:1527019654255};\\\", \\\"{x:1683,y:843,t:1527019654743};\\\", \\\"{x:1682,y:841,t:1527019654751};\\\", \\\"{x:1680,y:840,t:1527019654775};\\\", \\\"{x:1679,y:839,t:1527019654815};\\\", \\\"{x:1678,y:839,t:1527019654823};\\\", \\\"{x:1677,y:838,t:1527019654839};\\\", \\\"{x:1676,y:837,t:1527019654864};\\\", \\\"{x:1674,y:837,t:1527019654871};\\\", \\\"{x:1673,y:837,t:1527019654885};\\\", \\\"{x:1670,y:835,t:1527019654901};\\\", \\\"{x:1668,y:834,t:1527019654918};\\\", \\\"{x:1666,y:832,t:1527019654936};\\\", \\\"{x:1664,y:831,t:1527019654951};\\\", \\\"{x:1663,y:830,t:1527019654968};\\\", \\\"{x:1660,y:827,t:1527019654985};\\\", \\\"{x:1656,y:823,t:1527019655002};\\\", \\\"{x:1648,y:818,t:1527019655018};\\\", \\\"{x:1645,y:816,t:1527019655035};\\\", \\\"{x:1643,y:814,t:1527019655052};\\\", \\\"{x:1641,y:812,t:1527019655068};\\\", \\\"{x:1639,y:810,t:1527019655085};\\\", \\\"{x:1638,y:808,t:1527019655102};\\\", \\\"{x:1637,y:805,t:1527019655118};\\\", \\\"{x:1636,y:801,t:1527019655135};\\\", \\\"{x:1635,y:799,t:1527019655151};\\\", \\\"{x:1635,y:797,t:1527019655168};\\\", \\\"{x:1635,y:794,t:1527019655185};\\\", \\\"{x:1635,y:788,t:1527019655202};\\\", \\\"{x:1637,y:784,t:1527019655218};\\\", \\\"{x:1639,y:781,t:1527019655235};\\\", \\\"{x:1641,y:777,t:1527019655252};\\\", \\\"{x:1642,y:775,t:1527019655268};\\\", \\\"{x:1643,y:772,t:1527019655285};\\\", \\\"{x:1644,y:771,t:1527019655302};\\\", \\\"{x:1644,y:770,t:1527019655471};\\\", \\\"{x:1643,y:776,t:1527019655485};\\\", \\\"{x:1633,y:804,t:1527019655502};\\\", \\\"{x:1626,y:831,t:1527019655519};\\\", \\\"{x:1613,y:879,t:1527019655535};\\\", \\\"{x:1607,y:901,t:1527019655552};\\\", \\\"{x:1603,y:912,t:1527019655569};\\\", \\\"{x:1602,y:919,t:1527019655585};\\\", \\\"{x:1601,y:922,t:1527019655602};\\\", \\\"{x:1600,y:927,t:1527019655619};\\\", \\\"{x:1597,y:936,t:1527019655635};\\\", \\\"{x:1596,y:946,t:1527019655652};\\\", \\\"{x:1595,y:955,t:1527019655669};\\\", \\\"{x:1594,y:958,t:1527019655685};\\\", \\\"{x:1594,y:960,t:1527019655703};\\\", \\\"{x:1595,y:960,t:1527019655751};\\\", \\\"{x:1599,y:959,t:1527019655769};\\\", \\\"{x:1604,y:957,t:1527019655785};\\\", \\\"{x:1610,y:954,t:1527019655802};\\\", \\\"{x:1615,y:951,t:1527019655819};\\\", \\\"{x:1616,y:950,t:1527019655835};\\\", \\\"{x:1616,y:947,t:1527019655903};\\\", \\\"{x:1616,y:942,t:1527019655919};\\\", \\\"{x:1616,y:936,t:1527019655936};\\\", \\\"{x:1616,y:931,t:1527019655952};\\\", \\\"{x:1616,y:928,t:1527019655970};\\\", \\\"{x:1616,y:923,t:1527019655986};\\\", \\\"{x:1616,y:921,t:1527019656002};\\\", \\\"{x:1616,y:918,t:1527019656019};\\\", \\\"{x:1616,y:915,t:1527019656036};\\\", \\\"{x:1616,y:913,t:1527019656052};\\\", \\\"{x:1616,y:909,t:1527019656069};\\\", \\\"{x:1616,y:906,t:1527019656086};\\\", \\\"{x:1616,y:902,t:1527019656102};\\\", \\\"{x:1616,y:896,t:1527019656119};\\\", \\\"{x:1616,y:892,t:1527019656136};\\\", \\\"{x:1616,y:888,t:1527019656152};\\\", \\\"{x:1616,y:885,t:1527019656169};\\\", \\\"{x:1616,y:881,t:1527019656186};\\\", \\\"{x:1616,y:878,t:1527019656202};\\\", \\\"{x:1616,y:875,t:1527019656219};\\\", \\\"{x:1615,y:870,t:1527019656236};\\\", \\\"{x:1615,y:867,t:1527019656252};\\\", \\\"{x:1613,y:863,t:1527019656270};\\\", \\\"{x:1613,y:861,t:1527019656286};\\\", \\\"{x:1611,y:859,t:1527019656302};\\\", \\\"{x:1611,y:856,t:1527019656319};\\\", \\\"{x:1611,y:854,t:1527019656336};\\\", \\\"{x:1611,y:852,t:1527019656352};\\\", \\\"{x:1611,y:850,t:1527019656369};\\\", \\\"{x:1613,y:845,t:1527019656386};\\\", \\\"{x:1613,y:841,t:1527019656403};\\\", \\\"{x:1608,y:834,t:1527019656419};\\\", \\\"{x:1607,y:834,t:1527019656855};\\\", \\\"{x:1606,y:832,t:1527019656870};\\\", \\\"{x:1605,y:827,t:1527019656886};\\\", \\\"{x:1605,y:815,t:1527019656903};\\\", \\\"{x:1606,y:806,t:1527019656920};\\\", \\\"{x:1607,y:798,t:1527019656936};\\\", \\\"{x:1608,y:790,t:1527019656953};\\\", \\\"{x:1609,y:785,t:1527019656970};\\\", \\\"{x:1609,y:780,t:1527019656986};\\\", \\\"{x:1611,y:773,t:1527019657003};\\\", \\\"{x:1611,y:767,t:1527019657020};\\\", \\\"{x:1612,y:760,t:1527019657036};\\\", \\\"{x:1616,y:749,t:1527019657053};\\\", \\\"{x:1617,y:742,t:1527019657070};\\\", \\\"{x:1621,y:731,t:1527019657086};\\\", \\\"{x:1622,y:719,t:1527019657103};\\\", \\\"{x:1625,y:711,t:1527019657119};\\\", \\\"{x:1625,y:704,t:1527019657136};\\\", \\\"{x:1627,y:698,t:1527019657153};\\\", \\\"{x:1629,y:692,t:1527019657170};\\\", \\\"{x:1633,y:686,t:1527019657186};\\\", \\\"{x:1634,y:685,t:1527019657203};\\\", \\\"{x:1634,y:684,t:1527019657487};\\\", \\\"{x:1634,y:681,t:1527019657647};\\\", \\\"{x:1632,y:678,t:1527019657655};\\\", \\\"{x:1632,y:675,t:1527019657671};\\\", \\\"{x:1628,y:660,t:1527019657687};\\\", \\\"{x:1624,y:649,t:1527019657703};\\\", \\\"{x:1624,y:641,t:1527019657720};\\\", \\\"{x:1623,y:627,t:1527019657737};\\\", \\\"{x:1623,y:611,t:1527019657753};\\\", \\\"{x:1621,y:593,t:1527019657770};\\\", \\\"{x:1616,y:576,t:1527019657788};\\\", \\\"{x:1613,y:564,t:1527019657803};\\\", \\\"{x:1613,y:558,t:1527019657820};\\\", \\\"{x:1614,y:554,t:1527019657837};\\\", \\\"{x:1617,y:547,t:1527019657854};\\\", \\\"{x:1619,y:545,t:1527019657870};\\\", \\\"{x:1619,y:543,t:1527019658055};\\\", \\\"{x:1617,y:539,t:1527019658070};\\\", \\\"{x:1616,y:530,t:1527019658087};\\\", \\\"{x:1615,y:514,t:1527019658105};\\\", \\\"{x:1615,y:495,t:1527019658120};\\\", \\\"{x:1615,y:478,t:1527019658137};\\\", \\\"{x:1615,y:463,t:1527019658154};\\\", \\\"{x:1615,y:448,t:1527019658170};\\\", \\\"{x:1613,y:437,t:1527019658187};\\\", \\\"{x:1612,y:430,t:1527019658204};\\\", \\\"{x:1610,y:423,t:1527019658222};\\\", \\\"{x:1609,y:421,t:1527019658238};\\\", \\\"{x:1608,y:419,t:1527019658254};\\\", \\\"{x:1606,y:416,t:1527019658271};\\\", \\\"{x:1606,y:415,t:1527019658287};\\\", \\\"{x:1605,y:415,t:1527019658360};\\\", \\\"{x:1605,y:416,t:1527019658551};\\\", \\\"{x:1604,y:423,t:1527019658559};\\\", \\\"{x:1602,y:430,t:1527019658571};\\\", \\\"{x:1599,y:442,t:1527019658587};\\\", \\\"{x:1595,y:455,t:1527019658604};\\\", \\\"{x:1592,y:465,t:1527019658621};\\\", \\\"{x:1591,y:472,t:1527019658637};\\\", \\\"{x:1590,y:481,t:1527019658654};\\\", \\\"{x:1587,y:492,t:1527019658672};\\\", \\\"{x:1587,y:498,t:1527019658688};\\\", \\\"{x:1586,y:502,t:1527019658705};\\\", \\\"{x:1586,y:508,t:1527019658722};\\\", \\\"{x:1584,y:515,t:1527019658738};\\\", \\\"{x:1582,y:525,t:1527019658754};\\\", \\\"{x:1579,y:535,t:1527019658771};\\\", \\\"{x:1576,y:547,t:1527019658788};\\\", \\\"{x:1571,y:565,t:1527019658805};\\\", \\\"{x:1565,y:589,t:1527019658822};\\\", \\\"{x:1560,y:612,t:1527019658838};\\\", \\\"{x:1549,y:639,t:1527019658855};\\\", \\\"{x:1533,y:675,t:1527019658872};\\\", \\\"{x:1523,y:697,t:1527019658888};\\\", \\\"{x:1514,y:716,t:1527019658904};\\\", \\\"{x:1506,y:732,t:1527019658921};\\\", \\\"{x:1499,y:744,t:1527019658938};\\\", \\\"{x:1490,y:760,t:1527019658955};\\\", \\\"{x:1473,y:798,t:1527019658971};\\\", \\\"{x:1444,y:847,t:1527019658988};\\\", \\\"{x:1409,y:905,t:1527019659005};\\\", \\\"{x:1373,y:958,t:1527019659021};\\\", \\\"{x:1343,y:1000,t:1527019659038};\\\", \\\"{x:1321,y:1031,t:1527019659054};\\\", \\\"{x:1309,y:1049,t:1527019659070};\\\", \\\"{x:1308,y:1051,t:1527019659088};\\\", \\\"{x:1309,y:1050,t:1527019659271};\\\", \\\"{x:1321,y:1032,t:1527019659288};\\\", \\\"{x:1338,y:1013,t:1527019659305};\\\", \\\"{x:1352,y:996,t:1527019659321};\\\", \\\"{x:1364,y:983,t:1527019659338};\\\", \\\"{x:1368,y:976,t:1527019659355};\\\", \\\"{x:1371,y:970,t:1527019659371};\\\", \\\"{x:1372,y:968,t:1527019659388};\\\", \\\"{x:1372,y:967,t:1527019659480};\\\", \\\"{x:1371,y:967,t:1527019659503};\\\", \\\"{x:1369,y:967,t:1527019659519};\\\", \\\"{x:1368,y:968,t:1527019659527};\\\", \\\"{x:1365,y:970,t:1527019659544};\\\", \\\"{x:1363,y:971,t:1527019659559};\\\", \\\"{x:1362,y:972,t:1527019659615};\\\", \\\"{x:1361,y:972,t:1527019659671};\\\", \\\"{x:1358,y:972,t:1527019659767};\\\", \\\"{x:1357,y:973,t:1527019659783};\\\", \\\"{x:1354,y:974,t:1527019659791};\\\", \\\"{x:1351,y:975,t:1527019659805};\\\", \\\"{x:1343,y:975,t:1527019659822};\\\", \\\"{x:1328,y:975,t:1527019659838};\\\", \\\"{x:1269,y:970,t:1527019659856};\\\", \\\"{x:1185,y:955,t:1527019659872};\\\", \\\"{x:1085,y:929,t:1527019659888};\\\", \\\"{x:970,y:905,t:1527019659905};\\\", \\\"{x:860,y:878,t:1527019659921};\\\", \\\"{x:758,y:848,t:1527019659938};\\\", \\\"{x:675,y:826,t:1527019659955};\\\", \\\"{x:606,y:799,t:1527019659971};\\\", \\\"{x:566,y:778,t:1527019659988};\\\", \\\"{x:550,y:767,t:1527019660005};\\\", \\\"{x:543,y:762,t:1527019660023};\\\", \\\"{x:539,y:758,t:1527019660038};\\\", \\\"{x:537,y:753,t:1527019660055};\\\", \\\"{x:534,y:749,t:1527019660072};\\\", \\\"{x:530,y:744,t:1527019660088};\\\", \\\"{x:524,y:735,t:1527019660106};\\\", \\\"{x:518,y:728,t:1527019660122};\\\", \\\"{x:510,y:719,t:1527019660138};\\\", \\\"{x:503,y:708,t:1527019660154};\\\", \\\"{x:496,y:696,t:1527019660170};\\\", \\\"{x:490,y:685,t:1527019660186};\\\", \\\"{x:484,y:673,t:1527019660206};\\\", \\\"{x:470,y:655,t:1527019660222};\\\", \\\"{x:459,y:641,t:1527019660239};\\\", \\\"{x:450,y:628,t:1527019660255};\\\", \\\"{x:444,y:620,t:1527019660272};\\\", \\\"{x:441,y:616,t:1527019660289};\\\", \\\"{x:440,y:613,t:1527019660305};\\\", \\\"{x:437,y:608,t:1527019660323};\\\", \\\"{x:437,y:602,t:1527019660339};\\\", \\\"{x:434,y:595,t:1527019660356};\\\", \\\"{x:432,y:587,t:1527019660373};\\\", \\\"{x:430,y:578,t:1527019660390};\\\", \\\"{x:426,y:571,t:1527019660407};\\\", \\\"{x:425,y:566,t:1527019660422};\\\", \\\"{x:424,y:563,t:1527019660439};\\\", \\\"{x:423,y:562,t:1527019660455};\\\", \\\"{x:423,y:561,t:1527019660472};\\\", \\\"{x:422,y:560,t:1527019660489};\\\", \\\"{x:422,y:559,t:1527019660639};\\\", \\\"{x:414,y:559,t:1527019660657};\\\", \\\"{x:400,y:563,t:1527019660673};\\\", \\\"{x:386,y:569,t:1527019660689};\\\", \\\"{x:376,y:573,t:1527019660706};\\\", \\\"{x:373,y:575,t:1527019660723};\\\", \\\"{x:368,y:577,t:1527019660739};\\\", \\\"{x:363,y:579,t:1527019660756};\\\", \\\"{x:343,y:582,t:1527019660773};\\\", \\\"{x:320,y:588,t:1527019660789};\\\", \\\"{x:286,y:598,t:1527019660806};\\\", \\\"{x:264,y:604,t:1527019660823};\\\", \\\"{x:249,y:609,t:1527019660839};\\\", \\\"{x:239,y:609,t:1527019660857};\\\", \\\"{x:237,y:609,t:1527019660873};\\\", \\\"{x:241,y:609,t:1527019660934};\\\", \\\"{x:246,y:606,t:1527019660943};\\\", \\\"{x:255,y:603,t:1527019660956};\\\", \\\"{x:284,y:593,t:1527019660976};\\\", \\\"{x:360,y:569,t:1527019660990};\\\", \\\"{x:500,y:547,t:1527019661006};\\\", \\\"{x:597,y:536,t:1527019661024};\\\", \\\"{x:686,y:520,t:1527019661040};\\\", \\\"{x:745,y:512,t:1527019661057};\\\", \\\"{x:775,y:508,t:1527019661073};\\\", \\\"{x:783,y:506,t:1527019661089};\\\", \\\"{x:788,y:505,t:1527019661107};\\\", \\\"{x:794,y:502,t:1527019661123};\\\", \\\"{x:799,y:501,t:1527019661139};\\\", \\\"{x:806,y:499,t:1527019661156};\\\", \\\"{x:809,y:498,t:1527019661174};\\\", \\\"{x:810,y:498,t:1527019661198};\\\", \\\"{x:809,y:498,t:1527019661279};\\\", \\\"{x:804,y:498,t:1527019661290};\\\", \\\"{x:790,y:503,t:1527019661307};\\\", \\\"{x:777,y:511,t:1527019661325};\\\", \\\"{x:761,y:520,t:1527019661340};\\\", \\\"{x:737,y:528,t:1527019661357};\\\", \\\"{x:718,y:536,t:1527019661374};\\\", \\\"{x:710,y:541,t:1527019661390};\\\", \\\"{x:709,y:542,t:1527019661407};\\\", \\\"{x:709,y:543,t:1527019661438};\\\", \\\"{x:709,y:545,t:1527019661446};\\\", \\\"{x:709,y:547,t:1527019661457};\\\", \\\"{x:709,y:550,t:1527019661474};\\\", \\\"{x:709,y:556,t:1527019661490};\\\", \\\"{x:709,y:565,t:1527019661507};\\\", \\\"{x:706,y:585,t:1527019661524};\\\", \\\"{x:702,y:602,t:1527019661539};\\\", \\\"{x:697,y:619,t:1527019661558};\\\", \\\"{x:690,y:628,t:1527019661574};\\\", \\\"{x:680,y:633,t:1527019661589};\\\", \\\"{x:670,y:635,t:1527019661607};\\\", \\\"{x:663,y:637,t:1527019661624};\\\", \\\"{x:658,y:637,t:1527019661640};\\\", \\\"{x:652,y:637,t:1527019661657};\\\", \\\"{x:646,y:637,t:1527019661673};\\\", \\\"{x:633,y:637,t:1527019661691};\\\", \\\"{x:615,y:635,t:1527019661706};\\\", \\\"{x:596,y:633,t:1527019661724};\\\", \\\"{x:574,y:633,t:1527019661739};\\\", \\\"{x:554,y:633,t:1527019661757};\\\", \\\"{x:544,y:633,t:1527019661774};\\\", \\\"{x:540,y:633,t:1527019661791};\\\", \\\"{x:543,y:633,t:1527019661831};\\\", \\\"{x:552,y:632,t:1527019661841};\\\", \\\"{x:581,y:626,t:1527019661858};\\\", \\\"{x:641,y:622,t:1527019661874};\\\", \\\"{x:730,y:620,t:1527019661892};\\\", \\\"{x:833,y:620,t:1527019661907};\\\", \\\"{x:905,y:620,t:1527019661923};\\\", \\\"{x:941,y:620,t:1527019661941};\\\", \\\"{x:953,y:619,t:1527019661958};\\\", \\\"{x:954,y:619,t:1527019661982};\\\", \\\"{x:954,y:618,t:1527019662046};\\\", \\\"{x:953,y:618,t:1527019662057};\\\", \\\"{x:952,y:617,t:1527019662074};\\\", \\\"{x:951,y:616,t:1527019662090};\\\", \\\"{x:948,y:615,t:1527019662108};\\\", \\\"{x:946,y:614,t:1527019662123};\\\", \\\"{x:944,y:614,t:1527019662141};\\\", \\\"{x:942,y:613,t:1527019662158};\\\", \\\"{x:941,y:613,t:1527019662174};\\\", \\\"{x:936,y:613,t:1527019662190};\\\", \\\"{x:934,y:613,t:1527019662208};\\\", \\\"{x:932,y:613,t:1527019662224};\\\", \\\"{x:930,y:613,t:1527019662254};\\\", \\\"{x:928,y:613,t:1527019662263};\\\", \\\"{x:924,y:613,t:1527019662274};\\\", \\\"{x:918,y:613,t:1527019662291};\\\", \\\"{x:908,y:613,t:1527019662308};\\\", \\\"{x:899,y:613,t:1527019662324};\\\", \\\"{x:884,y:613,t:1527019662341};\\\", \\\"{x:866,y:613,t:1527019662358};\\\", \\\"{x:849,y:613,t:1527019662374};\\\", \\\"{x:842,y:613,t:1527019662391};\\\", \\\"{x:841,y:612,t:1527019662432};\\\", \\\"{x:842,y:611,t:1527019662567};\\\", \\\"{x:843,y:610,t:1527019662574};\\\", \\\"{x:845,y:610,t:1527019662590};\\\", \\\"{x:847,y:608,t:1527019662608};\\\", \\\"{x:850,y:607,t:1527019662625};\\\", \\\"{x:851,y:606,t:1527019662641};\\\", \\\"{x:848,y:606,t:1527019662695};\\\", \\\"{x:843,y:606,t:1527019662709};\\\", \\\"{x:823,y:616,t:1527019662726};\\\", \\\"{x:792,y:627,t:1527019662741};\\\", \\\"{x:741,y:642,t:1527019662758};\\\", \\\"{x:598,y:678,t:1527019662774};\\\", \\\"{x:485,y:704,t:1527019662792};\\\", \\\"{x:391,y:716,t:1527019662808};\\\", \\\"{x:328,y:721,t:1527019662825};\\\", \\\"{x:295,y:721,t:1527019662841};\\\", \\\"{x:284,y:721,t:1527019662858};\\\", \\\"{x:282,y:721,t:1527019662874};\\\", \\\"{x:284,y:718,t:1527019662902};\\\", \\\"{x:297,y:715,t:1527019662910};\\\", \\\"{x:318,y:703,t:1527019662925};\\\", \\\"{x:398,y:683,t:1527019662942};\\\", \\\"{x:555,y:645,t:1527019662958};\\\", \\\"{x:654,y:633,t:1527019662974};\\\", \\\"{x:727,y:622,t:1527019662992};\\\", \\\"{x:761,y:616,t:1527019663007};\\\", \\\"{x:773,y:612,t:1527019663026};\\\", \\\"{x:776,y:611,t:1527019663041};\\\", \\\"{x:777,y:610,t:1527019663057};\\\", \\\"{x:777,y:609,t:1527019663158};\\\", \\\"{x:778,y:608,t:1527019663175};\\\", \\\"{x:779,y:606,t:1527019663192};\\\", \\\"{x:780,y:604,t:1527019663209};\\\", \\\"{x:782,y:603,t:1527019663254};\\\", \\\"{x:782,y:602,t:1527019663263};\\\", \\\"{x:783,y:601,t:1527019663275};\\\", \\\"{x:789,y:598,t:1527019663292};\\\", \\\"{x:795,y:596,t:1527019663309};\\\", \\\"{x:798,y:594,t:1527019663325};\\\", \\\"{x:806,y:592,t:1527019663342};\\\", \\\"{x:821,y:592,t:1527019663359};\\\", \\\"{x:837,y:592,t:1527019663376};\\\", \\\"{x:854,y:592,t:1527019663392};\\\", \\\"{x:868,y:592,t:1527019663408};\\\", \\\"{x:883,y:593,t:1527019663426};\\\", \\\"{x:904,y:595,t:1527019663441};\\\", \\\"{x:923,y:598,t:1527019663457};\\\", \\\"{x:931,y:599,t:1527019663475};\\\", \\\"{x:933,y:599,t:1527019663526};\\\", \\\"{x:934,y:599,t:1527019663542};\\\", \\\"{x:935,y:599,t:1527019663582};\\\", \\\"{x:935,y:599,t:1527019663632};\\\", \\\"{x:934,y:599,t:1527019663687};\\\", \\\"{x:933,y:599,t:1527019663694};\\\", \\\"{x:932,y:599,t:1527019663709};\\\", \\\"{x:930,y:599,t:1527019663725};\\\", \\\"{x:928,y:599,t:1527019663741};\\\", \\\"{x:927,y:599,t:1527019663759};\\\", \\\"{x:925,y:599,t:1527019663776};\\\", \\\"{x:921,y:601,t:1527019663792};\\\", \\\"{x:920,y:602,t:1527019663809};\\\", \\\"{x:919,y:602,t:1527019663839};\\\", \\\"{x:918,y:602,t:1527019663846};\\\", \\\"{x:916,y:602,t:1527019663887};\\\", \\\"{x:914,y:603,t:1527019663895};\\\", \\\"{x:911,y:603,t:1527019663909};\\\", \\\"{x:905,y:605,t:1527019663926};\\\", \\\"{x:899,y:605,t:1527019663942};\\\", \\\"{x:887,y:605,t:1527019663958};\\\", \\\"{x:872,y:605,t:1527019663976};\\\", \\\"{x:857,y:605,t:1527019663992};\\\", \\\"{x:843,y:605,t:1527019664009};\\\", \\\"{x:839,y:605,t:1527019664024};\\\", \\\"{x:838,y:605,t:1527019664041};\\\", \\\"{x:832,y:610,t:1527019664424};\\\", \\\"{x:808,y:627,t:1527019664443};\\\", \\\"{x:780,y:643,t:1527019664459};\\\", \\\"{x:755,y:660,t:1527019664476};\\\", \\\"{x:716,y:679,t:1527019664492};\\\", \\\"{x:656,y:699,t:1527019664510};\\\", \\\"{x:609,y:711,t:1527019664525};\\\", \\\"{x:561,y:720,t:1527019664543};\\\", \\\"{x:534,y:720,t:1527019664560};\\\", \\\"{x:489,y:724,t:1527019664575};\\\", \\\"{x:450,y:732,t:1527019664593};\\\", \\\"{x:443,y:734,t:1527019664609};\\\", \\\"{x:442,y:735,t:1527019664626};\\\", \\\"{x:443,y:735,t:1527019664743};\\\", \\\"{x:446,y:734,t:1527019664760};\\\", \\\"{x:449,y:733,t:1527019664777};\\\", \\\"{x:459,y:732,t:1527019664792};\\\", \\\"{x:471,y:730,t:1527019664810};\\\", \\\"{x:484,y:727,t:1527019664826};\\\", \\\"{x:496,y:726,t:1527019664843};\\\", \\\"{x:504,y:725,t:1527019664859};\\\", \\\"{x:505,y:725,t:1527019664875};\\\", \\\"{x:506,y:724,t:1527019666455};\\\" ] }, { \\\"rt\\\": 240581, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 530524, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -I -A -A -I -O -0-A -03 PM-03 PM-O -O -O -F -03 PM-03 PM-03 PM-A -A -03 PM-I -12 PM-03 PM-U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:721,t:1527019667609};\\\", \\\"{x:506,y:712,t:1527019667624};\\\", \\\"{x:506,y:710,t:1527019667629};\\\", \\\"{x:506,y:707,t:1527019667644};\\\", \\\"{x:506,y:704,t:1527019667662};\\\", \\\"{x:506,y:703,t:1527019667678};\\\", \\\"{x:506,y:701,t:1527019668183};\\\", \\\"{x:506,y:700,t:1527019668198};\\\", \\\"{x:506,y:699,t:1527019668223};\\\", \\\"{x:506,y:698,t:1527019668247};\\\", \\\"{x:506,y:697,t:1527019668286};\\\", \\\"{x:506,y:696,t:1527019668302};\\\", \\\"{x:506,y:695,t:1527019668326};\\\", \\\"{x:506,y:694,t:1527019669951};\\\", \\\"{x:505,y:693,t:1527019671559};\\\", \\\"{x:514,y:685,t:1527019675359};\\\", \\\"{x:537,y:678,t:1527019675368};\\\", \\\"{x:597,y:654,t:1527019675386};\\\", \\\"{x:675,y:633,t:1527019675401};\\\", \\\"{x:765,y:612,t:1527019675418};\\\", \\\"{x:855,y:597,t:1527019675433};\\\", \\\"{x:947,y:593,t:1527019675452};\\\", \\\"{x:1039,y:593,t:1527019675468};\\\", \\\"{x:1160,y:593,t:1527019675484};\\\", \\\"{x:1225,y:593,t:1527019675501};\\\", \\\"{x:1225,y:592,t:1527019675527};\\\", \\\"{x:1227,y:592,t:1527019675895};\\\", \\\"{x:1228,y:592,t:1527019675918};\\\", \\\"{x:1230,y:591,t:1527019675934};\\\", \\\"{x:1233,y:589,t:1527019675952};\\\", \\\"{x:1235,y:586,t:1527019675969};\\\", \\\"{x:1239,y:585,t:1527019675984};\\\", \\\"{x:1241,y:584,t:1527019676001};\\\", \\\"{x:1246,y:583,t:1527019676019};\\\", \\\"{x:1250,y:581,t:1527019676035};\\\", \\\"{x:1253,y:580,t:1527019676057};\\\", \\\"{x:1256,y:579,t:1527019676073};\\\", \\\"{x:1260,y:577,t:1527019676089};\\\", \\\"{x:1265,y:576,t:1527019676106};\\\", \\\"{x:1272,y:574,t:1527019676123};\\\", \\\"{x:1280,y:571,t:1527019676152};\\\", \\\"{x:1284,y:570,t:1527019676156};\\\", \\\"{x:1290,y:568,t:1527019676172};\\\", \\\"{x:1297,y:567,t:1527019676188};\\\", \\\"{x:1302,y:565,t:1527019676206};\\\", \\\"{x:1308,y:563,t:1527019676222};\\\", \\\"{x:1317,y:561,t:1527019676238};\\\", \\\"{x:1323,y:559,t:1527019676256};\\\", \\\"{x:1327,y:558,t:1527019676272};\\\", \\\"{x:1331,y:557,t:1527019676288};\\\", \\\"{x:1332,y:556,t:1527019676306};\\\", \\\"{x:1328,y:558,t:1527019676627};\\\", \\\"{x:1327,y:558,t:1527019676639};\\\", \\\"{x:1322,y:562,t:1527019676656};\\\", \\\"{x:1317,y:563,t:1527019676674};\\\", \\\"{x:1315,y:565,t:1527019676690};\\\", \\\"{x:1312,y:565,t:1527019676706};\\\", \\\"{x:1313,y:564,t:1527019676898};\\\", \\\"{x:1314,y:563,t:1527019676906};\\\", \\\"{x:1317,y:556,t:1527019676922};\\\", \\\"{x:1318,y:552,t:1527019676939};\\\", \\\"{x:1318,y:549,t:1527019676955};\\\", \\\"{x:1320,y:544,t:1527019676973};\\\", \\\"{x:1320,y:542,t:1527019676988};\\\", \\\"{x:1320,y:539,t:1527019677006};\\\", \\\"{x:1320,y:537,t:1527019677023};\\\", \\\"{x:1320,y:534,t:1527019677039};\\\", \\\"{x:1320,y:529,t:1527019677056};\\\", \\\"{x:1321,y:526,t:1527019677073};\\\", \\\"{x:1321,y:522,t:1527019677089};\\\", \\\"{x:1321,y:520,t:1527019677105};\\\", \\\"{x:1321,y:515,t:1527019677122};\\\", \\\"{x:1321,y:510,t:1527019677139};\\\", \\\"{x:1321,y:508,t:1527019677156};\\\", \\\"{x:1321,y:505,t:1527019677173};\\\", \\\"{x:1321,y:504,t:1527019677189};\\\", \\\"{x:1321,y:502,t:1527019677206};\\\", \\\"{x:1321,y:501,t:1527019677227};\\\", \\\"{x:1322,y:499,t:1527019677243};\\\", \\\"{x:1321,y:499,t:1527019677396};\\\", \\\"{x:1320,y:499,t:1527019677411};\\\", \\\"{x:1317,y:499,t:1527019677425};\\\", \\\"{x:1315,y:500,t:1527019677439};\\\", \\\"{x:1314,y:500,t:1527019677455};\\\", \\\"{x:1313,y:501,t:1527019677472};\\\", \\\"{x:1311,y:502,t:1527019677491};\\\", \\\"{x:1311,y:503,t:1527019677514};\\\", \\\"{x:1310,y:504,t:1527019677538};\\\", \\\"{x:1308,y:506,t:1527019677555};\\\", \\\"{x:1306,y:507,t:1527019677573};\\\", \\\"{x:1303,y:511,t:1527019677589};\\\", \\\"{x:1301,y:514,t:1527019677605};\\\", \\\"{x:1298,y:518,t:1527019677622};\\\", \\\"{x:1296,y:520,t:1527019677639};\\\", \\\"{x:1294,y:523,t:1527019677655};\\\", \\\"{x:1293,y:524,t:1527019677673};\\\", \\\"{x:1292,y:525,t:1527019677688};\\\", \\\"{x:1291,y:527,t:1527019677705};\\\", \\\"{x:1289,y:529,t:1527019677722};\\\", \\\"{x:1289,y:530,t:1527019677738};\\\", \\\"{x:1287,y:531,t:1527019677762};\\\", \\\"{x:1287,y:532,t:1527019677794};\\\", \\\"{x:1286,y:534,t:1527019677810};\\\", \\\"{x:1286,y:535,t:1527019677834};\\\", \\\"{x:1284,y:537,t:1527019677850};\\\", \\\"{x:1284,y:539,t:1527019677866};\\\", \\\"{x:1283,y:539,t:1527019677874};\\\", \\\"{x:1283,y:540,t:1527019677889};\\\", \\\"{x:1283,y:541,t:1527019677905};\\\", \\\"{x:1281,y:543,t:1527019677923};\\\", \\\"{x:1281,y:545,t:1527019677939};\\\", \\\"{x:1281,y:546,t:1527019677956};\\\", \\\"{x:1280,y:547,t:1527019677973};\\\", \\\"{x:1279,y:548,t:1527019677988};\\\", \\\"{x:1278,y:550,t:1527019678005};\\\", \\\"{x:1278,y:551,t:1527019678026};\\\", \\\"{x:1278,y:552,t:1527019678042};\\\", \\\"{x:1277,y:554,t:1527019678055};\\\", \\\"{x:1276,y:558,t:1527019678073};\\\", \\\"{x:1274,y:562,t:1527019678089};\\\", \\\"{x:1273,y:564,t:1527019678106};\\\", \\\"{x:1272,y:566,t:1527019678123};\\\", \\\"{x:1271,y:567,t:1527019678139};\\\", \\\"{x:1271,y:568,t:1527019678156};\\\", \\\"{x:1270,y:570,t:1527019678173};\\\", \\\"{x:1270,y:572,t:1527019678189};\\\", \\\"{x:1270,y:575,t:1527019678205};\\\", \\\"{x:1268,y:581,t:1527019678223};\\\", \\\"{x:1267,y:585,t:1527019678238};\\\", \\\"{x:1266,y:589,t:1527019678255};\\\", \\\"{x:1266,y:591,t:1527019678272};\\\", \\\"{x:1266,y:593,t:1527019678289};\\\", \\\"{x:1264,y:598,t:1527019678305};\\\", \\\"{x:1264,y:602,t:1527019678322};\\\", \\\"{x:1263,y:606,t:1527019678338};\\\", \\\"{x:1263,y:607,t:1527019678356};\\\", \\\"{x:1263,y:609,t:1527019678372};\\\", \\\"{x:1263,y:610,t:1527019678402};\\\", \\\"{x:1262,y:612,t:1527019678426};\\\", \\\"{x:1262,y:613,t:1527019678450};\\\", \\\"{x:1261,y:614,t:1527019678466};\\\", \\\"{x:1260,y:616,t:1527019678483};\\\", \\\"{x:1260,y:618,t:1527019678506};\\\", \\\"{x:1259,y:619,t:1527019678522};\\\", \\\"{x:1258,y:620,t:1527019678538};\\\", \\\"{x:1258,y:621,t:1527019678563};\\\", \\\"{x:1257,y:621,t:1527019678572};\\\", \\\"{x:1257,y:622,t:1527019678588};\\\", \\\"{x:1256,y:624,t:1527019678618};\\\", \\\"{x:1255,y:625,t:1527019678626};\\\", \\\"{x:1255,y:626,t:1527019678638};\\\", \\\"{x:1254,y:627,t:1527019678656};\\\", \\\"{x:1253,y:631,t:1527019678673};\\\", \\\"{x:1251,y:634,t:1527019678689};\\\", \\\"{x:1250,y:637,t:1527019678707};\\\", \\\"{x:1247,y:643,t:1527019678722};\\\", \\\"{x:1246,y:644,t:1527019678739};\\\", \\\"{x:1245,y:649,t:1527019678755};\\\", \\\"{x:1243,y:653,t:1527019678772};\\\", \\\"{x:1243,y:656,t:1527019678788};\\\", \\\"{x:1239,y:662,t:1527019678805};\\\", \\\"{x:1239,y:665,t:1527019678823};\\\", \\\"{x:1238,y:671,t:1527019678838};\\\", \\\"{x:1236,y:674,t:1527019678855};\\\", \\\"{x:1233,y:680,t:1527019678872};\\\", \\\"{x:1230,y:687,t:1527019678890};\\\", \\\"{x:1225,y:694,t:1527019678906};\\\", \\\"{x:1224,y:696,t:1527019678923};\\\", \\\"{x:1223,y:697,t:1527019678947};\\\", \\\"{x:1222,y:699,t:1527019678956};\\\", \\\"{x:1222,y:700,t:1527019678979};\\\", \\\"{x:1221,y:701,t:1527019678995};\\\", \\\"{x:1220,y:702,t:1527019679083};\\\", \\\"{x:1220,y:703,t:1527019679132};\\\", \\\"{x:1219,y:703,t:1527019679659};\\\", \\\"{x:1217,y:703,t:1527019679672};\\\", \\\"{x:1216,y:703,t:1527019679691};\\\", \\\"{x:1215,y:703,t:1527019679706};\\\", \\\"{x:1212,y:703,t:1527019679723};\\\", \\\"{x:1211,y:702,t:1527019679747};\\\", \\\"{x:1210,y:702,t:1527019681218};\\\", \\\"{x:1210,y:700,t:1527019681226};\\\", \\\"{x:1210,y:698,t:1527019681239};\\\", \\\"{x:1213,y:695,t:1527019681255};\\\", \\\"{x:1214,y:693,t:1527019681274};\\\", \\\"{x:1215,y:692,t:1527019681288};\\\", \\\"{x:1215,y:691,t:1527019681306};\\\", \\\"{x:1215,y:690,t:1527019681322};\\\", \\\"{x:1220,y:683,t:1527019681587};\\\", \\\"{x:1231,y:671,t:1527019681594};\\\", \\\"{x:1241,y:657,t:1527019681606};\\\", \\\"{x:1269,y:622,t:1527019681622};\\\", \\\"{x:1288,y:600,t:1527019681639};\\\", \\\"{x:1302,y:581,t:1527019681656};\\\", \\\"{x:1309,y:567,t:1527019681672};\\\", \\\"{x:1313,y:559,t:1527019681689};\\\", \\\"{x:1316,y:553,t:1527019681705};\\\", \\\"{x:1317,y:551,t:1527019681722};\\\", \\\"{x:1317,y:550,t:1527019681738};\\\", \\\"{x:1317,y:548,t:1527019681850};\\\", \\\"{x:1317,y:547,t:1527019681858};\\\", \\\"{x:1317,y:544,t:1527019681872};\\\", \\\"{x:1316,y:541,t:1527019681888};\\\", \\\"{x:1315,y:534,t:1527019681906};\\\", \\\"{x:1314,y:529,t:1527019681922};\\\", \\\"{x:1312,y:525,t:1527019681939};\\\", \\\"{x:1312,y:524,t:1527019681955};\\\", \\\"{x:1312,y:522,t:1527019681978};\\\", \\\"{x:1312,y:517,t:1527019682731};\\\", \\\"{x:1312,y:513,t:1527019682738};\\\", \\\"{x:1312,y:506,t:1527019682756};\\\", \\\"{x:1312,y:498,t:1527019682773};\\\", \\\"{x:1314,y:493,t:1527019682789};\\\", \\\"{x:1314,y:490,t:1527019682806};\\\", \\\"{x:1314,y:488,t:1527019682821};\\\", \\\"{x:1315,y:487,t:1527019682838};\\\", \\\"{x:1315,y:486,t:1527019682858};\\\", \\\"{x:1315,y:485,t:1527019682874};\\\", \\\"{x:1316,y:483,t:1527019682889};\\\", \\\"{x:1317,y:482,t:1527019682914};\\\", \\\"{x:1317,y:483,t:1527019683100};\\\", \\\"{x:1317,y:485,t:1527019683107};\\\", \\\"{x:1317,y:489,t:1527019683122};\\\", \\\"{x:1317,y:506,t:1527019683139};\\\", \\\"{x:1316,y:514,t:1527019683156};\\\", \\\"{x:1316,y:519,t:1527019683172};\\\", \\\"{x:1316,y:525,t:1527019683189};\\\", \\\"{x:1316,y:532,t:1527019683206};\\\", \\\"{x:1316,y:539,t:1527019683223};\\\", \\\"{x:1316,y:546,t:1527019683239};\\\", \\\"{x:1316,y:553,t:1527019683256};\\\", \\\"{x:1316,y:561,t:1527019683272};\\\", \\\"{x:1316,y:569,t:1527019683289};\\\", \\\"{x:1316,y:574,t:1527019683306};\\\", \\\"{x:1316,y:580,t:1527019683322};\\\", \\\"{x:1316,y:592,t:1527019683339};\\\", \\\"{x:1316,y:599,t:1527019683356};\\\", \\\"{x:1316,y:604,t:1527019683373};\\\", \\\"{x:1316,y:609,t:1527019683390};\\\", \\\"{x:1316,y:615,t:1527019683406};\\\", \\\"{x:1316,y:622,t:1527019683423};\\\", \\\"{x:1316,y:629,t:1527019683439};\\\", \\\"{x:1316,y:638,t:1527019683456};\\\", \\\"{x:1316,y:652,t:1527019683472};\\\", \\\"{x:1316,y:665,t:1527019683489};\\\", \\\"{x:1316,y:674,t:1527019683506};\\\", \\\"{x:1316,y:683,t:1527019683523};\\\", \\\"{x:1316,y:696,t:1527019683539};\\\", \\\"{x:1316,y:705,t:1527019683557};\\\", \\\"{x:1316,y:713,t:1527019683572};\\\", \\\"{x:1316,y:722,t:1527019683590};\\\", \\\"{x:1316,y:729,t:1527019683606};\\\", \\\"{x:1316,y:736,t:1527019683622};\\\", \\\"{x:1316,y:746,t:1527019683639};\\\", \\\"{x:1316,y:755,t:1527019683656};\\\", \\\"{x:1316,y:763,t:1527019683673};\\\", \\\"{x:1316,y:767,t:1527019683689};\\\", \\\"{x:1316,y:771,t:1527019683707};\\\", \\\"{x:1316,y:777,t:1527019683722};\\\", \\\"{x:1316,y:790,t:1527019683739};\\\", \\\"{x:1316,y:798,t:1527019683756};\\\", \\\"{x:1316,y:806,t:1527019683772};\\\", \\\"{x:1316,y:809,t:1527019683789};\\\", \\\"{x:1316,y:813,t:1527019683806};\\\", \\\"{x:1316,y:817,t:1527019683822};\\\", \\\"{x:1316,y:821,t:1527019683839};\\\", \\\"{x:1316,y:826,t:1527019683855};\\\", \\\"{x:1316,y:829,t:1527019683872};\\\", \\\"{x:1316,y:832,t:1527019683889};\\\", \\\"{x:1316,y:835,t:1527019683906};\\\", \\\"{x:1316,y:838,t:1527019683922};\\\", \\\"{x:1316,y:842,t:1527019683939};\\\", \\\"{x:1316,y:849,t:1527019683956};\\\", \\\"{x:1316,y:854,t:1527019683972};\\\", \\\"{x:1316,y:859,t:1527019683989};\\\", \\\"{x:1316,y:865,t:1527019684005};\\\", \\\"{x:1316,y:871,t:1527019684022};\\\", \\\"{x:1316,y:877,t:1527019684039};\\\", \\\"{x:1316,y:884,t:1527019684056};\\\", \\\"{x:1316,y:891,t:1527019684072};\\\", \\\"{x:1316,y:900,t:1527019684089};\\\", \\\"{x:1315,y:916,t:1527019684105};\\\", \\\"{x:1315,y:929,t:1527019684122};\\\", \\\"{x:1315,y:939,t:1527019684139};\\\", \\\"{x:1315,y:943,t:1527019684155};\\\", \\\"{x:1315,y:948,t:1527019684173};\\\", \\\"{x:1315,y:952,t:1527019684190};\\\", \\\"{x:1315,y:954,t:1527019684207};\\\", \\\"{x:1315,y:956,t:1527019684222};\\\", \\\"{x:1315,y:959,t:1527019684240};\\\", \\\"{x:1315,y:960,t:1527019684255};\\\", \\\"{x:1315,y:964,t:1527019684272};\\\", \\\"{x:1315,y:967,t:1527019684290};\\\", \\\"{x:1316,y:970,t:1527019684305};\\\", \\\"{x:1317,y:976,t:1527019684322};\\\", \\\"{x:1318,y:981,t:1527019684338};\\\", \\\"{x:1319,y:981,t:1527019684356};\\\", \\\"{x:1319,y:979,t:1527019684603};\\\", \\\"{x:1319,y:978,t:1527019684611};\\\", \\\"{x:1319,y:976,t:1527019684622};\\\", \\\"{x:1319,y:970,t:1527019684639};\\\", \\\"{x:1319,y:960,t:1527019684655};\\\", \\\"{x:1319,y:943,t:1527019684672};\\\", \\\"{x:1319,y:910,t:1527019684689};\\\", \\\"{x:1319,y:866,t:1527019684705};\\\", \\\"{x:1319,y:815,t:1527019684723};\\\", \\\"{x:1319,y:729,t:1527019684739};\\\", \\\"{x:1319,y:676,t:1527019684757};\\\", \\\"{x:1319,y:636,t:1527019684773};\\\", \\\"{x:1319,y:611,t:1527019684789};\\\", \\\"{x:1319,y:588,t:1527019684805};\\\", \\\"{x:1319,y:571,t:1527019684822};\\\", \\\"{x:1319,y:557,t:1527019684839};\\\", \\\"{x:1319,y:537,t:1527019684855};\\\", \\\"{x:1319,y:521,t:1527019684873};\\\", \\\"{x:1319,y:509,t:1527019684889};\\\", \\\"{x:1319,y:501,t:1527019684905};\\\", \\\"{x:1319,y:497,t:1527019684922};\\\", \\\"{x:1319,y:493,t:1527019684938};\\\", \\\"{x:1318,y:493,t:1527019687019};\\\", \\\"{x:1316,y:493,t:1527019687027};\\\", \\\"{x:1310,y:502,t:1527019687040};\\\", \\\"{x:1303,y:518,t:1527019687056};\\\", \\\"{x:1292,y:533,t:1527019687072};\\\", \\\"{x:1283,y:544,t:1527019687090};\\\", \\\"{x:1277,y:554,t:1527019687105};\\\", \\\"{x:1272,y:561,t:1527019687123};\\\", \\\"{x:1270,y:566,t:1527019687139};\\\", \\\"{x:1268,y:569,t:1527019687156};\\\", \\\"{x:1263,y:577,t:1527019687173};\\\", \\\"{x:1259,y:584,t:1527019687189};\\\", \\\"{x:1254,y:592,t:1527019687205};\\\", \\\"{x:1252,y:598,t:1527019687223};\\\", \\\"{x:1250,y:601,t:1527019687239};\\\", \\\"{x:1249,y:602,t:1527019687255};\\\", \\\"{x:1248,y:603,t:1527019687331};\\\", \\\"{x:1247,y:605,t:1527019687339};\\\", \\\"{x:1246,y:609,t:1527019687356};\\\", \\\"{x:1243,y:616,t:1527019687373};\\\", \\\"{x:1240,y:624,t:1527019687390};\\\", \\\"{x:1237,y:628,t:1527019687405};\\\", \\\"{x:1236,y:634,t:1527019687423};\\\", \\\"{x:1234,y:639,t:1527019687439};\\\", \\\"{x:1233,y:644,t:1527019687455};\\\", \\\"{x:1231,y:649,t:1527019687472};\\\", \\\"{x:1230,y:653,t:1527019687489};\\\", \\\"{x:1230,y:657,t:1527019687505};\\\", \\\"{x:1227,y:663,t:1527019687522};\\\", \\\"{x:1227,y:666,t:1527019687539};\\\", \\\"{x:1226,y:669,t:1527019687555};\\\", \\\"{x:1225,y:671,t:1527019687572};\\\", \\\"{x:1225,y:674,t:1527019687588};\\\", \\\"{x:1224,y:675,t:1527019687606};\\\", \\\"{x:1224,y:676,t:1527019687622};\\\", \\\"{x:1223,y:677,t:1527019687640};\\\", \\\"{x:1223,y:679,t:1527019687659};\\\", \\\"{x:1223,y:680,t:1527019687674};\\\", \\\"{x:1223,y:682,t:1527019687691};\\\", \\\"{x:1222,y:683,t:1527019687705};\\\", \\\"{x:1222,y:685,t:1527019687723};\\\", \\\"{x:1221,y:687,t:1527019687739};\\\", \\\"{x:1221,y:689,t:1527019687755};\\\", \\\"{x:1220,y:689,t:1527019687772};\\\", \\\"{x:1219,y:690,t:1527019687789};\\\", \\\"{x:1219,y:692,t:1527019687806};\\\", \\\"{x:1219,y:693,t:1527019687823};\\\", \\\"{x:1219,y:695,t:1527019687839};\\\", \\\"{x:1217,y:697,t:1527019687855};\\\", \\\"{x:1217,y:698,t:1527019687875};\\\", \\\"{x:1217,y:699,t:1527019687889};\\\", \\\"{x:1217,y:700,t:1527019687914};\\\", \\\"{x:1216,y:701,t:1527019687947};\\\", \\\"{x:1216,y:702,t:1527019687963};\\\", \\\"{x:1216,y:703,t:1527019687986};\\\", \\\"{x:1215,y:705,t:1527019688002};\\\", \\\"{x:1214,y:705,t:1527019688011};\\\", \\\"{x:1214,y:706,t:1527019688022};\\\", \\\"{x:1213,y:707,t:1527019688039};\\\", \\\"{x:1213,y:709,t:1527019688056};\\\", \\\"{x:1210,y:712,t:1527019688073};\\\", \\\"{x:1210,y:713,t:1527019688090};\\\", \\\"{x:1210,y:714,t:1527019688106};\\\", \\\"{x:1210,y:715,t:1527019688123};\\\", \\\"{x:1208,y:717,t:1527019688387};\\\", \\\"{x:1206,y:722,t:1527019688394};\\\", \\\"{x:1205,y:722,t:1527019688411};\\\", \\\"{x:1205,y:723,t:1527019688423};\\\", \\\"{x:1204,y:723,t:1527019689187};\\\", \\\"{x:1204,y:725,t:1527019689347};\\\", \\\"{x:1204,y:726,t:1527019689363};\\\", \\\"{x:1204,y:727,t:1527019689434};\\\", \\\"{x:1204,y:725,t:1527019693115};\\\", \\\"{x:1205,y:715,t:1527019693122};\\\", \\\"{x:1211,y:699,t:1527019693139};\\\", \\\"{x:1222,y:668,t:1527019693156};\\\", \\\"{x:1231,y:648,t:1527019693173};\\\", \\\"{x:1237,y:636,t:1527019693188};\\\", \\\"{x:1238,y:632,t:1527019693205};\\\", \\\"{x:1238,y:630,t:1527019693223};\\\", \\\"{x:1240,y:628,t:1527019693239};\\\", \\\"{x:1239,y:636,t:1527019694315};\\\", \\\"{x:1235,y:650,t:1527019694323};\\\", \\\"{x:1224,y:693,t:1527019694339};\\\", \\\"{x:1214,y:737,t:1527019694355};\\\", \\\"{x:1210,y:767,t:1527019694372};\\\", \\\"{x:1200,y:803,t:1527019694389};\\\", \\\"{x:1190,y:842,t:1527019694405};\\\", \\\"{x:1173,y:878,t:1527019694422};\\\", \\\"{x:1168,y:897,t:1527019694438};\\\", \\\"{x:1164,y:909,t:1527019694456};\\\", \\\"{x:1162,y:914,t:1527019694472};\\\", \\\"{x:1160,y:918,t:1527019694489};\\\", \\\"{x:1158,y:921,t:1527019694505};\\\", \\\"{x:1158,y:922,t:1527019694521};\\\", \\\"{x:1157,y:926,t:1527019694538};\\\", \\\"{x:1150,y:933,t:1527019694555};\\\", \\\"{x:1142,y:940,t:1527019694571};\\\", \\\"{x:1136,y:944,t:1527019694587};\\\", \\\"{x:1121,y:949,t:1527019694605};\\\", \\\"{x:1100,y:957,t:1527019694621};\\\", \\\"{x:1083,y:961,t:1527019694638};\\\", \\\"{x:1070,y:965,t:1527019694655};\\\", \\\"{x:1063,y:967,t:1527019694671};\\\", \\\"{x:1058,y:968,t:1527019694688};\\\", \\\"{x:1057,y:969,t:1527019694705};\\\", \\\"{x:1063,y:964,t:1527019695147};\\\", \\\"{x:1069,y:958,t:1527019695157};\\\", \\\"{x:1083,y:947,t:1527019695171};\\\", \\\"{x:1092,y:937,t:1527019695189};\\\", \\\"{x:1101,y:925,t:1527019695205};\\\", \\\"{x:1111,y:912,t:1527019695221};\\\", \\\"{x:1116,y:908,t:1527019695239};\\\", \\\"{x:1117,y:907,t:1527019695603};\\\", \\\"{x:1120,y:898,t:1527019695611};\\\", \\\"{x:1123,y:884,t:1527019695622};\\\", \\\"{x:1128,y:872,t:1527019695639};\\\", \\\"{x:1133,y:862,t:1527019695656};\\\", \\\"{x:1139,y:851,t:1527019695671};\\\", \\\"{x:1142,y:844,t:1527019695689};\\\", \\\"{x:1145,y:835,t:1527019695706};\\\", \\\"{x:1154,y:811,t:1527019695723};\\\", \\\"{x:1164,y:788,t:1527019695738};\\\", \\\"{x:1170,y:772,t:1527019695755};\\\", \\\"{x:1174,y:762,t:1527019695771};\\\", \\\"{x:1179,y:752,t:1527019695788};\\\", \\\"{x:1183,y:744,t:1527019695805};\\\", \\\"{x:1184,y:737,t:1527019695821};\\\", \\\"{x:1187,y:731,t:1527019695838};\\\", \\\"{x:1192,y:722,t:1527019695855};\\\", \\\"{x:1196,y:712,t:1527019695872};\\\", \\\"{x:1201,y:699,t:1527019695888};\\\", \\\"{x:1207,y:687,t:1527019695905};\\\", \\\"{x:1208,y:684,t:1527019695921};\\\", \\\"{x:1209,y:682,t:1527019695938};\\\", \\\"{x:1210,y:681,t:1527019695956};\\\", \\\"{x:1210,y:679,t:1527019695972};\\\", \\\"{x:1214,y:673,t:1527019695988};\\\", \\\"{x:1219,y:665,t:1527019696005};\\\", \\\"{x:1229,y:651,t:1527019696021};\\\", \\\"{x:1234,y:645,t:1527019696039};\\\", \\\"{x:1236,y:642,t:1527019696055};\\\", \\\"{x:1234,y:642,t:1527019698187};\\\", \\\"{x:1228,y:645,t:1527019698194};\\\", \\\"{x:1223,y:657,t:1527019698205};\\\", \\\"{x:1208,y:694,t:1527019698222};\\\", \\\"{x:1191,y:763,t:1527019698239};\\\", \\\"{x:1180,y:846,t:1527019698254};\\\", \\\"{x:1158,y:948,t:1527019698272};\\\", \\\"{x:1154,y:1040,t:1527019698289};\\\", \\\"{x:1171,y:1099,t:1527019698305};\\\", \\\"{x:1186,y:1135,t:1527019698322};\\\", \\\"{x:1204,y:1171,t:1527019698338};\\\", \\\"{x:1217,y:1193,t:1527019698355};\\\", \\\"{x:1235,y:1199,t:1527019698371};\\\", \\\"{x:1247,y:1199,t:1527019698387};\\\", \\\"{x:1257,y:1199,t:1527019698404};\\\", \\\"{x:1262,y:1199,t:1527019698421};\\\", \\\"{x:1265,y:1199,t:1527019698436};\\\", \\\"{x:1266,y:1199,t:1527019698731};\\\", \\\"{x:1269,y:1199,t:1527019698738};\\\", \\\"{x:1270,y:1198,t:1527019698747};\\\", \\\"{x:1308,y:1188,t:1527019699187};\\\", \\\"{x:1302,y:1188,t:1527019699371};\\\", \\\"{x:1288,y:1183,t:1527019699378};\\\", \\\"{x:1271,y:1178,t:1527019699392};\\\", \\\"{x:1221,y:1154,t:1527019699409};\\\", \\\"{x:1167,y:1125,t:1527019699425};\\\", \\\"{x:1106,y:1083,t:1527019699442};\\\", \\\"{x:1012,y:1008,t:1527019699458};\\\", \\\"{x:959,y:940,t:1527019699476};\\\", \\\"{x:919,y:849,t:1527019699491};\\\", \\\"{x:894,y:778,t:1527019699509};\\\", \\\"{x:884,y:727,t:1527019699524};\\\", \\\"{x:881,y:695,t:1527019699542};\\\", \\\"{x:884,y:668,t:1527019699559};\\\", \\\"{x:892,y:644,t:1527019699575};\\\", \\\"{x:903,y:624,t:1527019699593};\\\", \\\"{x:911,y:609,t:1527019699608};\\\", \\\"{x:921,y:597,t:1527019699625};\\\", \\\"{x:924,y:595,t:1527019699642};\\\", \\\"{x:928,y:592,t:1527019699658};\\\", \\\"{x:932,y:589,t:1527019699675};\\\", \\\"{x:935,y:588,t:1527019699692};\\\", \\\"{x:937,y:587,t:1527019699708};\\\", \\\"{x:940,y:585,t:1527019699725};\\\", \\\"{x:942,y:584,t:1527019699741};\\\", \\\"{x:943,y:587,t:1527019699962};\\\", \\\"{x:945,y:594,t:1527019699977};\\\", \\\"{x:948,y:612,t:1527019699993};\\\", \\\"{x:948,y:631,t:1527019700009};\\\", \\\"{x:945,y:644,t:1527019700025};\\\", \\\"{x:933,y:648,t:1527019700041};\\\", \\\"{x:932,y:648,t:1527019700065};\\\", \\\"{x:931,y:647,t:1527019702867};\\\", \\\"{x:936,y:638,t:1527019702878};\\\", \\\"{x:974,y:609,t:1527019702894};\\\", \\\"{x:1024,y:575,t:1527019702911};\\\", \\\"{x:1073,y:548,t:1527019702928};\\\", \\\"{x:1112,y:524,t:1527019702945};\\\", \\\"{x:1142,y:508,t:1527019702961};\\\", \\\"{x:1174,y:491,t:1527019702978};\\\", \\\"{x:1190,y:484,t:1527019702994};\\\", \\\"{x:1203,y:475,t:1527019703010};\\\", \\\"{x:1214,y:471,t:1527019703028};\\\", \\\"{x:1224,y:468,t:1527019703045};\\\", \\\"{x:1233,y:464,t:1527019703061};\\\", \\\"{x:1245,y:460,t:1527019703078};\\\", \\\"{x:1256,y:457,t:1527019703095};\\\", \\\"{x:1265,y:455,t:1527019703111};\\\", \\\"{x:1271,y:453,t:1527019703128};\\\", \\\"{x:1277,y:451,t:1527019703145};\\\", \\\"{x:1281,y:451,t:1527019703161};\\\", \\\"{x:1285,y:450,t:1527019703178};\\\", \\\"{x:1288,y:450,t:1527019703195};\\\", \\\"{x:1290,y:450,t:1527019703211};\\\", \\\"{x:1292,y:450,t:1527019703228};\\\", \\\"{x:1294,y:450,t:1527019703244};\\\", \\\"{x:1298,y:450,t:1527019703261};\\\", \\\"{x:1301,y:451,t:1527019703278};\\\", \\\"{x:1303,y:452,t:1527019703295};\\\", \\\"{x:1307,y:456,t:1527019703312};\\\", \\\"{x:1310,y:462,t:1527019703328};\\\", \\\"{x:1314,y:467,t:1527019703345};\\\", \\\"{x:1317,y:475,t:1527019703362};\\\", \\\"{x:1317,y:479,t:1527019703378};\\\", \\\"{x:1318,y:483,t:1527019703395};\\\", \\\"{x:1320,y:487,t:1527019703412};\\\", \\\"{x:1320,y:494,t:1527019703428};\\\", \\\"{x:1321,y:501,t:1527019703445};\\\", \\\"{x:1322,y:507,t:1527019703462};\\\", \\\"{x:1324,y:509,t:1527019703478};\\\", \\\"{x:1324,y:513,t:1527019703495};\\\", \\\"{x:1324,y:516,t:1527019703512};\\\", \\\"{x:1324,y:517,t:1527019703539};\\\", \\\"{x:1323,y:518,t:1527019703930};\\\", \\\"{x:1320,y:521,t:1527019703945};\\\", \\\"{x:1308,y:530,t:1527019703962};\\\", \\\"{x:1282,y:560,t:1527019703978};\\\", \\\"{x:1276,y:579,t:1527019703995};\\\", \\\"{x:1273,y:592,t:1527019704011};\\\", \\\"{x:1270,y:600,t:1527019704029};\\\", \\\"{x:1270,y:602,t:1527019704045};\\\", \\\"{x:1267,y:607,t:1527019704062};\\\", \\\"{x:1264,y:612,t:1527019704079};\\\", \\\"{x:1263,y:618,t:1527019704095};\\\", \\\"{x:1260,y:623,t:1527019704112};\\\", \\\"{x:1259,y:629,t:1527019704129};\\\", \\\"{x:1257,y:635,t:1527019704145};\\\", \\\"{x:1250,y:649,t:1527019704163};\\\", \\\"{x:1245,y:659,t:1527019704178};\\\", \\\"{x:1242,y:670,t:1527019704196};\\\", \\\"{x:1240,y:676,t:1527019704212};\\\", \\\"{x:1240,y:680,t:1527019704229};\\\", \\\"{x:1238,y:682,t:1527019704246};\\\", \\\"{x:1238,y:683,t:1527019704262};\\\", \\\"{x:1237,y:687,t:1527019704278};\\\", \\\"{x:1236,y:692,t:1527019704296};\\\", \\\"{x:1232,y:703,t:1527019704312};\\\", \\\"{x:1232,y:708,t:1527019704329};\\\", \\\"{x:1229,y:716,t:1527019704346};\\\", \\\"{x:1228,y:720,t:1527019704363};\\\", \\\"{x:1228,y:725,t:1527019704379};\\\", \\\"{x:1225,y:732,t:1527019704396};\\\", \\\"{x:1225,y:735,t:1527019704411};\\\", \\\"{x:1224,y:739,t:1527019704429};\\\", \\\"{x:1224,y:741,t:1527019704446};\\\", \\\"{x:1224,y:745,t:1527019704462};\\\", \\\"{x:1224,y:751,t:1527019704479};\\\", \\\"{x:1224,y:757,t:1527019704496};\\\", \\\"{x:1224,y:761,t:1527019704512};\\\", \\\"{x:1224,y:764,t:1527019704529};\\\", \\\"{x:1224,y:767,t:1527019704547};\\\", \\\"{x:1224,y:770,t:1527019704563};\\\", \\\"{x:1224,y:774,t:1527019704578};\\\", \\\"{x:1225,y:778,t:1527019704595};\\\", \\\"{x:1227,y:780,t:1527019704612};\\\", \\\"{x:1228,y:780,t:1527019704629};\\\", \\\"{x:1228,y:781,t:1527019704794};\\\", \\\"{x:1233,y:781,t:1527019704813};\\\", \\\"{x:1239,y:781,t:1527019704829};\\\", \\\"{x:1241,y:780,t:1527019704846};\\\", \\\"{x:1245,y:778,t:1527019704863};\\\", \\\"{x:1249,y:776,t:1527019704879};\\\", \\\"{x:1252,y:775,t:1527019704896};\\\", \\\"{x:1256,y:775,t:1527019704913};\\\", \\\"{x:1259,y:775,t:1527019704929};\\\", \\\"{x:1268,y:773,t:1527019704946};\\\", \\\"{x:1273,y:772,t:1527019704962};\\\", \\\"{x:1276,y:772,t:1527019704978};\\\", \\\"{x:1280,y:771,t:1527019704996};\\\", \\\"{x:1283,y:771,t:1527019705012};\\\", \\\"{x:1286,y:771,t:1527019705029};\\\", \\\"{x:1289,y:769,t:1527019705046};\\\", \\\"{x:1290,y:769,t:1527019705063};\\\", \\\"{x:1294,y:768,t:1527019705079};\\\", \\\"{x:1297,y:768,t:1527019705096};\\\", \\\"{x:1303,y:767,t:1527019705113};\\\", \\\"{x:1314,y:765,t:1527019705131};\\\", \\\"{x:1316,y:765,t:1527019705146};\\\", \\\"{x:1316,y:767,t:1527019706210};\\\", \\\"{x:1316,y:771,t:1527019706218};\\\", \\\"{x:1316,y:773,t:1527019706230};\\\", \\\"{x:1322,y:783,t:1527019706247};\\\", \\\"{x:1326,y:788,t:1527019706264};\\\", \\\"{x:1334,y:795,t:1527019706280};\\\", \\\"{x:1336,y:796,t:1527019706297};\\\", \\\"{x:1337,y:796,t:1527019706314};\\\", \\\"{x:1338,y:796,t:1527019706330};\\\", \\\"{x:1337,y:797,t:1527019706865};\\\", \\\"{x:1337,y:798,t:1527019706881};\\\", \\\"{x:1335,y:798,t:1527019706921};\\\", \\\"{x:1334,y:798,t:1527019706930};\\\", \\\"{x:1328,y:798,t:1527019706946};\\\", \\\"{x:1323,y:798,t:1527019706963};\\\", \\\"{x:1316,y:798,t:1527019706981};\\\", \\\"{x:1312,y:798,t:1527019706998};\\\", \\\"{x:1308,y:798,t:1527019707014};\\\", \\\"{x:1303,y:799,t:1527019707030};\\\", \\\"{x:1297,y:800,t:1527019707048};\\\", \\\"{x:1288,y:802,t:1527019707064};\\\", \\\"{x:1281,y:802,t:1527019707080};\\\", \\\"{x:1272,y:804,t:1527019707098};\\\", \\\"{x:1268,y:804,t:1527019707114};\\\", \\\"{x:1266,y:804,t:1527019707130};\\\", \\\"{x:1264,y:805,t:1527019707147};\\\", \\\"{x:1263,y:805,t:1527019709859};\\\", \\\"{x:1262,y:805,t:1527019714051};\\\", \\\"{x:1261,y:805,t:1527019714066};\\\", \\\"{x:1260,y:805,t:1527019714106};\\\", \\\"{x:1259,y:805,t:1527019717442};\\\", \\\"{x:1259,y:803,t:1527019717455};\\\", \\\"{x:1257,y:797,t:1527019717472};\\\", \\\"{x:1256,y:793,t:1527019717489};\\\", \\\"{x:1254,y:790,t:1527019717505};\\\", \\\"{x:1254,y:788,t:1527019717522};\\\", \\\"{x:1253,y:788,t:1527019718770};\\\", \\\"{x:1250,y:784,t:1527019720114};\\\", \\\"{x:1249,y:783,t:1527019720123};\\\", \\\"{x:1247,y:779,t:1527019720140};\\\", \\\"{x:1244,y:775,t:1527019720158};\\\", \\\"{x:1243,y:773,t:1527019720173};\\\", \\\"{x:1242,y:771,t:1527019720202};\\\", \\\"{x:1242,y:770,t:1527019720210};\\\", \\\"{x:1241,y:769,t:1527019720225};\\\", \\\"{x:1240,y:768,t:1527019720242};\\\", \\\"{x:1239,y:768,t:1527019720562};\\\", \\\"{x:1238,y:768,t:1527019720578};\\\", \\\"{x:1237,y:768,t:1527019720594};\\\", \\\"{x:1236,y:767,t:1527019720618};\\\", \\\"{x:1235,y:766,t:1527019720634};\\\", \\\"{x:1234,y:766,t:1527019720650};\\\", \\\"{x:1234,y:765,t:1527019720666};\\\", \\\"{x:1234,y:764,t:1527019720738};\\\", \\\"{x:1234,y:763,t:1527019720842};\\\", \\\"{x:1234,y:762,t:1527019721307};\\\", \\\"{x:1234,y:761,t:1527019721314};\\\", \\\"{x:1235,y:758,t:1527019721325};\\\", \\\"{x:1236,y:753,t:1527019721341};\\\", \\\"{x:1237,y:748,t:1527019721358};\\\", \\\"{x:1237,y:743,t:1527019721374};\\\", \\\"{x:1237,y:742,t:1527019721392};\\\", \\\"{x:1238,y:741,t:1527019721562};\\\", \\\"{x:1238,y:740,t:1527019721574};\\\", \\\"{x:1238,y:735,t:1527019721591};\\\", \\\"{x:1238,y:731,t:1527019721608};\\\", \\\"{x:1237,y:729,t:1527019721625};\\\", \\\"{x:1237,y:728,t:1527019722186};\\\", \\\"{x:1237,y:725,t:1527019723138};\\\", \\\"{x:1237,y:722,t:1527019723146};\\\", \\\"{x:1237,y:721,t:1527019723160};\\\", \\\"{x:1237,y:720,t:1527019723177};\\\", \\\"{x:1237,y:719,t:1527019723192};\\\", \\\"{x:1236,y:719,t:1527019723250};\\\", \\\"{x:1235,y:719,t:1527019723266};\\\", \\\"{x:1234,y:719,t:1527019723277};\\\", \\\"{x:1232,y:719,t:1527019723906};\\\", \\\"{x:1231,y:719,t:1527019723922};\\\", \\\"{x:1230,y:719,t:1527019723930};\\\", \\\"{x:1229,y:719,t:1527019723943};\\\", \\\"{x:1228,y:719,t:1527019723960};\\\", \\\"{x:1226,y:719,t:1527019723975};\\\", \\\"{x:1225,y:719,t:1527019723993};\\\", \\\"{x:1224,y:719,t:1527019724009};\\\", \\\"{x:1223,y:719,t:1527019724226};\\\", \\\"{x:1222,y:719,t:1527019724290};\\\", \\\"{x:1221,y:719,t:1527019724331};\\\", \\\"{x:1220,y:719,t:1527019724354};\\\", \\\"{x:1220,y:718,t:1527019724370};\\\", \\\"{x:1219,y:718,t:1527019724386};\\\", \\\"{x:1219,y:717,t:1527019724402};\\\", \\\"{x:1218,y:716,t:1527019724418};\\\", \\\"{x:1218,y:715,t:1527019724457};\\\", \\\"{x:1217,y:715,t:1527019724778};\\\", \\\"{x:1213,y:716,t:1527019724794};\\\", \\\"{x:1205,y:720,t:1527019724810};\\\", \\\"{x:1202,y:721,t:1527019724827};\\\", \\\"{x:1201,y:722,t:1527019724844};\\\", \\\"{x:1200,y:723,t:1527019724861};\\\", \\\"{x:1199,y:724,t:1527019724878};\\\", \\\"{x:1198,y:724,t:1527019724894};\\\", \\\"{x:1198,y:725,t:1527019724930};\\\", \\\"{x:1197,y:726,t:1527019725018};\\\", \\\"{x:1196,y:726,t:1527019725034};\\\", \\\"{x:1195,y:727,t:1527019725044};\\\", \\\"{x:1194,y:727,t:1527019725061};\\\", \\\"{x:1192,y:728,t:1527019725081};\\\", \\\"{x:1191,y:728,t:1527019727849};\\\", \\\"{x:1190,y:730,t:1527019727862};\\\", \\\"{x:1189,y:732,t:1527019727879};\\\", \\\"{x:1187,y:733,t:1527019727896};\\\", \\\"{x:1186,y:736,t:1527019727912};\\\", \\\"{x:1185,y:737,t:1527019727929};\\\", \\\"{x:1183,y:738,t:1527019729042};\\\", \\\"{x:1182,y:739,t:1527019729050};\\\", \\\"{x:1181,y:740,t:1527019729063};\\\", \\\"{x:1180,y:741,t:1527019729139};\\\", \\\"{x:1179,y:741,t:1527019730570};\\\", \\\"{x:1178,y:741,t:1527019730581};\\\", \\\"{x:1176,y:741,t:1527019730598};\\\", \\\"{x:1173,y:741,t:1527019730615};\\\", \\\"{x:1172,y:742,t:1527019730714};\\\", \\\"{x:1171,y:742,t:1527019730732};\\\", \\\"{x:1170,y:743,t:1527019731282};\\\", \\\"{x:1167,y:743,t:1527019731299};\\\", \\\"{x:1165,y:744,t:1527019731315};\\\", \\\"{x:1164,y:746,t:1527019731332};\\\", \\\"{x:1163,y:747,t:1527019731349};\\\", \\\"{x:1162,y:747,t:1527019731366};\\\", \\\"{x:1161,y:748,t:1527019731986};\\\", \\\"{x:1161,y:749,t:1527019731999};\\\", \\\"{x:1160,y:749,t:1527019737126};\\\", \\\"{x:1160,y:747,t:1527019737172};\\\", \\\"{x:1160,y:746,t:1527019737190};\\\", \\\"{x:1160,y:744,t:1527019737206};\\\", \\\"{x:1159,y:743,t:1527019737223};\\\", \\\"{x:1159,y:742,t:1527019737269};\\\", \\\"{x:1158,y:742,t:1527019737276};\\\", \\\"{x:1157,y:742,t:1527019740670};\\\", \\\"{x:1156,y:742,t:1527019740718};\\\", \\\"{x:1155,y:742,t:1527019740741};\\\", \\\"{x:1154,y:742,t:1527019740789};\\\", \\\"{x:1154,y:743,t:1527019740821};\\\", \\\"{x:1152,y:744,t:1527019740837};\\\", \\\"{x:1151,y:744,t:1527019743404};\\\", \\\"{x:1149,y:747,t:1527019743411};\\\", \\\"{x:1146,y:748,t:1527019743426};\\\", \\\"{x:1138,y:754,t:1527019743443};\\\", \\\"{x:1134,y:756,t:1527019743461};\\\", \\\"{x:1133,y:757,t:1527019743476};\\\", \\\"{x:1133,y:758,t:1527019743965};\\\", \\\"{x:1133,y:760,t:1527019744012};\\\", \\\"{x:1132,y:761,t:1527019744076};\\\", \\\"{x:1132,y:762,t:1527019744100};\\\", \\\"{x:1132,y:763,t:1527019744111};\\\", \\\"{x:1132,y:764,t:1527019744128};\\\", \\\"{x:1132,y:766,t:1527019744145};\\\", \\\"{x:1131,y:767,t:1527019744161};\\\", \\\"{x:1131,y:768,t:1527019744178};\\\", \\\"{x:1131,y:770,t:1527019744194};\\\", \\\"{x:1129,y:770,t:1527019750037};\\\", \\\"{x:1129,y:771,t:1527019750050};\\\", \\\"{x:1128,y:772,t:1527019750065};\\\", \\\"{x:1127,y:773,t:1527019750083};\\\", \\\"{x:1126,y:774,t:1527019750141};\\\", \\\"{x:1126,y:775,t:1527019750165};\\\", \\\"{x:1125,y:776,t:1527019750221};\\\", \\\"{x:1124,y:776,t:1527019750260};\\\", \\\"{x:1123,y:776,t:1527019750276};\\\", \\\"{x:1122,y:776,t:1527019750381};\\\", \\\"{x:1121,y:777,t:1527019761957};\\\", \\\"{x:1121,y:776,t:1527019766347};\\\", \\\"{x:1122,y:776,t:1527019766361};\\\", \\\"{x:1124,y:775,t:1527019766378};\\\", \\\"{x:1125,y:775,t:1527019766395};\\\", \\\"{x:1126,y:774,t:1527019766411};\\\", \\\"{x:1131,y:772,t:1527019766427};\\\", \\\"{x:1132,y:771,t:1527019766445};\\\", \\\"{x:1133,y:771,t:1527019766461};\\\", \\\"{x:1133,y:772,t:1527019766516};\\\", \\\"{x:1134,y:772,t:1527019766636};\\\", \\\"{x:1135,y:772,t:1527019766646};\\\", \\\"{x:1137,y:772,t:1527019766709};\\\", \\\"{x:1139,y:771,t:1527019766716};\\\", \\\"{x:1142,y:768,t:1527019766728};\\\", \\\"{x:1148,y:763,t:1527019766746};\\\", \\\"{x:1149,y:763,t:1527019766761};\\\", \\\"{x:1150,y:763,t:1527019766955};\\\", \\\"{x:1152,y:761,t:1527019766963};\\\", \\\"{x:1153,y:761,t:1527019767036};\\\", \\\"{x:1155,y:759,t:1527019767060};\\\", \\\"{x:1157,y:757,t:1527019767067};\\\", \\\"{x:1158,y:756,t:1527019767078};\\\", \\\"{x:1161,y:754,t:1527019774405};\\\", \\\"{x:1164,y:753,t:1527019774417};\\\", \\\"{x:1175,y:748,t:1527019774435};\\\", \\\"{x:1181,y:744,t:1527019774450};\\\", \\\"{x:1186,y:743,t:1527019774468};\\\", \\\"{x:1192,y:739,t:1527019774485};\\\", \\\"{x:1197,y:731,t:1527019774500};\\\", \\\"{x:1207,y:715,t:1527019774518};\\\", \\\"{x:1224,y:692,t:1527019774535};\\\", \\\"{x:1241,y:672,t:1527019774551};\\\", \\\"{x:1259,y:657,t:1527019774568};\\\", \\\"{x:1273,y:650,t:1527019774585};\\\", \\\"{x:1279,y:647,t:1527019774601};\\\", \\\"{x:1279,y:646,t:1527019774618};\\\", \\\"{x:1276,y:646,t:1527019774634};\\\", \\\"{x:1214,y:612,t:1527019774651};\\\", \\\"{x:1135,y:565,t:1527019774668};\\\", \\\"{x:1128,y:561,t:1527019774684};\\\", \\\"{x:1129,y:559,t:1527019774700};\\\", \\\"{x:1134,y:556,t:1527019774718};\\\", \\\"{x:1135,y:555,t:1527019774735};\\\", \\\"{x:1137,y:554,t:1527019774750};\\\", \\\"{x:1142,y:550,t:1527019774767};\\\", \\\"{x:1146,y:545,t:1527019774784};\\\", \\\"{x:1152,y:534,t:1527019774801};\\\", \\\"{x:1160,y:518,t:1527019774818};\\\", \\\"{x:1162,y:507,t:1527019774835};\\\", \\\"{x:1164,y:501,t:1527019774850};\\\", \\\"{x:1169,y:480,t:1527019774868};\\\", \\\"{x:1172,y:471,t:1527019774884};\\\", \\\"{x:1174,y:464,t:1527019774901};\\\", \\\"{x:1179,y:456,t:1527019774918};\\\", \\\"{x:1180,y:454,t:1527019774935};\\\", \\\"{x:1181,y:454,t:1527019774981};\\\", \\\"{x:1182,y:452,t:1527019775044};\\\", \\\"{x:1185,y:451,t:1527019775052};\\\", \\\"{x:1194,y:447,t:1527019775068};\\\", \\\"{x:1211,y:440,t:1527019775084};\\\", \\\"{x:1233,y:431,t:1527019775102};\\\", \\\"{x:1276,y:425,t:1527019775118};\\\", \\\"{x:1325,y:428,t:1527019775134};\\\", \\\"{x:1380,y:451,t:1527019775152};\\\", \\\"{x:1427,y:482,t:1527019775168};\\\", \\\"{x:1481,y:501,t:1527019775185};\\\", \\\"{x:1567,y:512,t:1527019775201};\\\", \\\"{x:1581,y:516,t:1527019775218};\\\", \\\"{x:1578,y:519,t:1527019775726};\\\", \\\"{x:1567,y:521,t:1527019775735};\\\", \\\"{x:1545,y:525,t:1527019775752};\\\", \\\"{x:1529,y:527,t:1527019775769};\\\", \\\"{x:1518,y:530,t:1527019775785};\\\", \\\"{x:1512,y:531,t:1527019775802};\\\", \\\"{x:1510,y:532,t:1527019775819};\\\", \\\"{x:1505,y:534,t:1527019775835};\\\", \\\"{x:1499,y:537,t:1527019775852};\\\", \\\"{x:1495,y:538,t:1527019775868};\\\", \\\"{x:1492,y:542,t:1527019775886};\\\", \\\"{x:1489,y:551,t:1527019775901};\\\", \\\"{x:1484,y:573,t:1527019775918};\\\", \\\"{x:1481,y:611,t:1527019775935};\\\", \\\"{x:1481,y:661,t:1527019775951};\\\", \\\"{x:1481,y:714,t:1527019775968};\\\", \\\"{x:1481,y:770,t:1527019775985};\\\", \\\"{x:1496,y:831,t:1527019776001};\\\", \\\"{x:1525,y:895,t:1527019776018};\\\", \\\"{x:1553,y:948,t:1527019776035};\\\", \\\"{x:1567,y:971,t:1527019776051};\\\", \\\"{x:1573,y:980,t:1527019776068};\\\", \\\"{x:1574,y:985,t:1527019776085};\\\", \\\"{x:1573,y:985,t:1527019776260};\\\", \\\"{x:1570,y:985,t:1527019776269};\\\", \\\"{x:1565,y:985,t:1527019776285};\\\", \\\"{x:1555,y:984,t:1527019776303};\\\", \\\"{x:1548,y:983,t:1527019776318};\\\", \\\"{x:1544,y:982,t:1527019776335};\\\", \\\"{x:1541,y:981,t:1527019776352};\\\", \\\"{x:1540,y:980,t:1527019776369};\\\", \\\"{x:1537,y:979,t:1527019776386};\\\", \\\"{x:1534,y:979,t:1527019776403};\\\", \\\"{x:1533,y:979,t:1527019776419};\\\", \\\"{x:1531,y:978,t:1527019776436};\\\", \\\"{x:1528,y:978,t:1527019776451};\\\", \\\"{x:1523,y:978,t:1527019776469};\\\", \\\"{x:1522,y:978,t:1527019776485};\\\", \\\"{x:1521,y:978,t:1527019777029};\\\", \\\"{x:1518,y:978,t:1527019777035};\\\", \\\"{x:1507,y:972,t:1527019777053};\\\", \\\"{x:1491,y:961,t:1527019777070};\\\", \\\"{x:1466,y:940,t:1527019777085};\\\", \\\"{x:1425,y:891,t:1527019777103};\\\", \\\"{x:1368,y:820,t:1527019777119};\\\", \\\"{x:1301,y:730,t:1527019777136};\\\", \\\"{x:1244,y:652,t:1527019777152};\\\", \\\"{x:1214,y:578,t:1527019777170};\\\", \\\"{x:1198,y:537,t:1527019777186};\\\", \\\"{x:1195,y:521,t:1527019777203};\\\", \\\"{x:1195,y:514,t:1527019777220};\\\", \\\"{x:1195,y:507,t:1527019777236};\\\", \\\"{x:1195,y:503,t:1527019777253};\\\", \\\"{x:1195,y:499,t:1527019777270};\\\", \\\"{x:1195,y:498,t:1527019777287};\\\", \\\"{x:1195,y:496,t:1527019777303};\\\", \\\"{x:1196,y:496,t:1527019777413};\\\", \\\"{x:1198,y:496,t:1527019777420};\\\", \\\"{x:1201,y:496,t:1527019777444};\\\", \\\"{x:1202,y:496,t:1527019777452};\\\", \\\"{x:1204,y:496,t:1527019777470};\\\", \\\"{x:1206,y:496,t:1527019777487};\\\", \\\"{x:1209,y:496,t:1527019777503};\\\", \\\"{x:1216,y:496,t:1527019777520};\\\", \\\"{x:1226,y:495,t:1527019777537};\\\", \\\"{x:1234,y:495,t:1527019777553};\\\", \\\"{x:1238,y:495,t:1527019777570};\\\", \\\"{x:1239,y:495,t:1527019777586};\\\", \\\"{x:1244,y:493,t:1527019777603};\\\", \\\"{x:1278,y:479,t:1527019777619};\\\", \\\"{x:1308,y:466,t:1527019777637};\\\", \\\"{x:1315,y:465,t:1527019777652};\\\", \\\"{x:1316,y:469,t:1527019777669};\\\", \\\"{x:1309,y:488,t:1527019777687};\\\", \\\"{x:1303,y:514,t:1527019777703};\\\", \\\"{x:1308,y:530,t:1527019777720};\\\", \\\"{x:1312,y:534,t:1527019777736};\\\", \\\"{x:1320,y:535,t:1527019777753};\\\", \\\"{x:1328,y:536,t:1527019777769};\\\", \\\"{x:1332,y:538,t:1527019777786};\\\", \\\"{x:1334,y:542,t:1527019778812};\\\", \\\"{x:1337,y:551,t:1527019778821};\\\", \\\"{x:1343,y:566,t:1527019778838};\\\", \\\"{x:1348,y:578,t:1527019778853};\\\", \\\"{x:1352,y:586,t:1527019778870};\\\", \\\"{x:1354,y:591,t:1527019778888};\\\", \\\"{x:1356,y:593,t:1527019778904};\\\", \\\"{x:1355,y:588,t:1527019779059};\\\", \\\"{x:1352,y:580,t:1527019779070};\\\", \\\"{x:1344,y:562,t:1527019779088};\\\", \\\"{x:1338,y:548,t:1527019779103};\\\", \\\"{x:1333,y:539,t:1527019779121};\\\", \\\"{x:1329,y:532,t:1527019779138};\\\", \\\"{x:1327,y:528,t:1527019779154};\\\", \\\"{x:1326,y:526,t:1527019779171};\\\", \\\"{x:1326,y:525,t:1527019779187};\\\", \\\"{x:1326,y:524,t:1527019779203};\\\", \\\"{x:1325,y:521,t:1527019779347};\\\", \\\"{x:1322,y:517,t:1527019779355};\\\", \\\"{x:1322,y:515,t:1527019779370};\\\", \\\"{x:1318,y:508,t:1527019779387};\\\", \\\"{x:1316,y:505,t:1527019779404};\\\", \\\"{x:1315,y:504,t:1527019779420};\\\", \\\"{x:1314,y:503,t:1527019779438};\\\", \\\"{x:1313,y:503,t:1527019779595};\\\", \\\"{x:1310,y:509,t:1527019779604};\\\", \\\"{x:1305,y:532,t:1527019779621};\\\", \\\"{x:1297,y:564,t:1527019779637};\\\", \\\"{x:1293,y:588,t:1527019779654};\\\", \\\"{x:1289,y:610,t:1527019779671};\\\", \\\"{x:1288,y:623,t:1527019779687};\\\", \\\"{x:1287,y:630,t:1527019779705};\\\", \\\"{x:1285,y:634,t:1527019779722};\\\", \\\"{x:1285,y:635,t:1527019779739};\\\", \\\"{x:1284,y:635,t:1527019779827};\\\", \\\"{x:1282,y:638,t:1527019779837};\\\", \\\"{x:1277,y:643,t:1527019779854};\\\", \\\"{x:1273,y:648,t:1527019779871};\\\", \\\"{x:1268,y:654,t:1527019779887};\\\", \\\"{x:1259,y:660,t:1527019779904};\\\", \\\"{x:1252,y:666,t:1527019779921};\\\", \\\"{x:1247,y:669,t:1527019779937};\\\", \\\"{x:1242,y:673,t:1527019779955};\\\", \\\"{x:1239,y:677,t:1527019779971};\\\", \\\"{x:1236,y:679,t:1527019779988};\\\", \\\"{x:1235,y:679,t:1527019780020};\\\", \\\"{x:1234,y:679,t:1527019780435};\\\", \\\"{x:1235,y:679,t:1527019780483};\\\", \\\"{x:1236,y:678,t:1527019780491};\\\", \\\"{x:1238,y:676,t:1527019780504};\\\", \\\"{x:1240,y:673,t:1527019780521};\\\", \\\"{x:1244,y:668,t:1527019780539};\\\", \\\"{x:1247,y:664,t:1527019780555};\\\", \\\"{x:1250,y:660,t:1527019780571};\\\", \\\"{x:1251,y:656,t:1527019780589};\\\", \\\"{x:1252,y:654,t:1527019780606};\\\", \\\"{x:1253,y:651,t:1527019780621};\\\", \\\"{x:1253,y:650,t:1527019780638};\\\", \\\"{x:1254,y:648,t:1527019780659};\\\", \\\"{x:1254,y:646,t:1527019781132};\\\", \\\"{x:1254,y:645,t:1527019781140};\\\", \\\"{x:1254,y:644,t:1527019781156};\\\", \\\"{x:1254,y:642,t:1527019781172};\\\", \\\"{x:1254,y:641,t:1527019781189};\\\", \\\"{x:1254,y:640,t:1527019783595};\\\", \\\"{x:1256,y:640,t:1527019783707};\\\", \\\"{x:1256,y:641,t:1527019783723};\\\", \\\"{x:1256,y:642,t:1527019783741};\\\", \\\"{x:1258,y:645,t:1527019783757};\\\", \\\"{x:1258,y:647,t:1527019783773};\\\", \\\"{x:1258,y:651,t:1527019783791};\\\", \\\"{x:1261,y:655,t:1527019783808};\\\", \\\"{x:1262,y:663,t:1527019783823};\\\", \\\"{x:1266,y:671,t:1527019783840};\\\", \\\"{x:1271,y:683,t:1527019783858};\\\", \\\"{x:1276,y:696,t:1527019783874};\\\", \\\"{x:1282,y:709,t:1527019783890};\\\", \\\"{x:1291,y:733,t:1527019783907};\\\", \\\"{x:1297,y:748,t:1527019783925};\\\", \\\"{x:1302,y:760,t:1527019783941};\\\", \\\"{x:1306,y:771,t:1527019783957};\\\", \\\"{x:1309,y:778,t:1527019783975};\\\", \\\"{x:1312,y:784,t:1527019783990};\\\", \\\"{x:1314,y:791,t:1527019784007};\\\", \\\"{x:1315,y:797,t:1527019784025};\\\", \\\"{x:1318,y:806,t:1527019784040};\\\", \\\"{x:1324,y:816,t:1527019784058};\\\", \\\"{x:1331,y:828,t:1527019784075};\\\", \\\"{x:1337,y:838,t:1527019784091};\\\", \\\"{x:1347,y:852,t:1527019784107};\\\", \\\"{x:1352,y:860,t:1527019784124};\\\", \\\"{x:1359,y:870,t:1527019784141};\\\", \\\"{x:1367,y:877,t:1527019784157};\\\", \\\"{x:1371,y:884,t:1527019784175};\\\", \\\"{x:1375,y:889,t:1527019784191};\\\", \\\"{x:1380,y:895,t:1527019784208};\\\", \\\"{x:1386,y:900,t:1527019784225};\\\", \\\"{x:1392,y:907,t:1527019784240};\\\", \\\"{x:1395,y:910,t:1527019784258};\\\", \\\"{x:1397,y:913,t:1527019784275};\\\", \\\"{x:1400,y:916,t:1527019784291};\\\", \\\"{x:1402,y:917,t:1527019784308};\\\", \\\"{x:1404,y:919,t:1527019784324};\\\", \\\"{x:1405,y:921,t:1527019784342};\\\", \\\"{x:1407,y:923,t:1527019784358};\\\", \\\"{x:1409,y:923,t:1527019784375};\\\", \\\"{x:1410,y:924,t:1527019784392};\\\", \\\"{x:1414,y:926,t:1527019784408};\\\", \\\"{x:1418,y:929,t:1527019784425};\\\", \\\"{x:1420,y:931,t:1527019784442};\\\", \\\"{x:1424,y:936,t:1527019784458};\\\", \\\"{x:1426,y:938,t:1527019784475};\\\", \\\"{x:1431,y:943,t:1527019784492};\\\", \\\"{x:1431,y:944,t:1527019784508};\\\", \\\"{x:1431,y:946,t:1527019784525};\\\", \\\"{x:1432,y:948,t:1527019784542};\\\", \\\"{x:1432,y:949,t:1527019784668};\\\", \\\"{x:1430,y:945,t:1527019784756};\\\", \\\"{x:1426,y:940,t:1527019784764};\\\", \\\"{x:1420,y:930,t:1527019784776};\\\", \\\"{x:1398,y:904,t:1527019784792};\\\", \\\"{x:1375,y:876,t:1527019784809};\\\", \\\"{x:1354,y:847,t:1527019784825};\\\", \\\"{x:1333,y:819,t:1527019784843};\\\", \\\"{x:1315,y:790,t:1527019784859};\\\", \\\"{x:1307,y:773,t:1527019784875};\\\", \\\"{x:1300,y:759,t:1527019784892};\\\", \\\"{x:1299,y:754,t:1527019784909};\\\", \\\"{x:1296,y:750,t:1527019784925};\\\", \\\"{x:1296,y:747,t:1527019784942};\\\", \\\"{x:1296,y:745,t:1527019784959};\\\", \\\"{x:1296,y:741,t:1527019784975};\\\", \\\"{x:1296,y:734,t:1527019784992};\\\", \\\"{x:1296,y:729,t:1527019785009};\\\", \\\"{x:1296,y:725,t:1527019785025};\\\", \\\"{x:1296,y:719,t:1527019785042};\\\", \\\"{x:1293,y:711,t:1527019785059};\\\", \\\"{x:1291,y:700,t:1527019785075};\\\", \\\"{x:1285,y:685,t:1527019785091};\\\", \\\"{x:1276,y:672,t:1527019785109};\\\", \\\"{x:1271,y:663,t:1527019785125};\\\", \\\"{x:1267,y:655,t:1527019785143};\\\", \\\"{x:1262,y:647,t:1527019785159};\\\", \\\"{x:1259,y:641,t:1527019785175};\\\", \\\"{x:1257,y:638,t:1527019785192};\\\", \\\"{x:1256,y:636,t:1527019785209};\\\", \\\"{x:1254,y:634,t:1527019785225};\\\", \\\"{x:1253,y:632,t:1527019785242};\\\", \\\"{x:1253,y:631,t:1527019785258};\\\", \\\"{x:1252,y:631,t:1527019790052};\\\", \\\"{x:1251,y:631,t:1527019795603};\\\", \\\"{x:1250,y:631,t:1527019795616};\\\", \\\"{x:1249,y:631,t:1527019795659};\\\", \\\"{x:1248,y:631,t:1527019799399};\\\", \\\"{x:1247,y:631,t:1527019799439};\\\", \\\"{x:1245,y:632,t:1527019799457};\\\", \\\"{x:1243,y:632,t:1527019799473};\\\", \\\"{x:1240,y:632,t:1527019799490};\\\", \\\"{x:1239,y:633,t:1527019799506};\\\", \\\"{x:1238,y:633,t:1527019799558};\\\", \\\"{x:1238,y:634,t:1527019801271};\\\", \\\"{x:1242,y:636,t:1527019801278};\\\", \\\"{x:1244,y:637,t:1527019801291};\\\", \\\"{x:1247,y:638,t:1527019801308};\\\", \\\"{x:1248,y:639,t:1527019801324};\\\", \\\"{x:1248,y:640,t:1527019801550};\\\", \\\"{x:1248,y:643,t:1527019801558};\\\", \\\"{x:1247,y:644,t:1527019801574};\\\", \\\"{x:1246,y:650,t:1527019801590};\\\", \\\"{x:1246,y:651,t:1527019801608};\\\", \\\"{x:1246,y:652,t:1527019802345};\\\", \\\"{x:1249,y:653,t:1527019802359};\\\", \\\"{x:1285,y:640,t:1527019802376};\\\", \\\"{x:1298,y:635,t:1527019802393};\\\", \\\"{x:1309,y:629,t:1527019802408};\\\", \\\"{x:1322,y:626,t:1527019802425};\\\", \\\"{x:1327,y:626,t:1527019802443};\\\", \\\"{x:1332,y:626,t:1527019802458};\\\", \\\"{x:1339,y:628,t:1527019802475};\\\", \\\"{x:1351,y:633,t:1527019802492};\\\", \\\"{x:1368,y:637,t:1527019802509};\\\", \\\"{x:1378,y:638,t:1527019802525};\\\", \\\"{x:1385,y:638,t:1527019802543};\\\", \\\"{x:1387,y:638,t:1527019802559};\\\", \\\"{x:1387,y:639,t:1527019802696};\\\", \\\"{x:1387,y:640,t:1527019802712};\\\", \\\"{x:1386,y:641,t:1527019802726};\\\", \\\"{x:1378,y:646,t:1527019802742};\\\", \\\"{x:1369,y:650,t:1527019802759};\\\", \\\"{x:1362,y:653,t:1527019802775};\\\", \\\"{x:1358,y:654,t:1527019802793};\\\", \\\"{x:1356,y:654,t:1527019802810};\\\", \\\"{x:1356,y:650,t:1527019802826};\\\", \\\"{x:1356,y:646,t:1527019802843};\\\", \\\"{x:1356,y:645,t:1527019802860};\\\", \\\"{x:1356,y:643,t:1527019803072};\\\", \\\"{x:1353,y:643,t:1527019803112};\\\", \\\"{x:1351,y:643,t:1527019803125};\\\", \\\"{x:1346,y:643,t:1527019803143};\\\", \\\"{x:1340,y:643,t:1527019803159};\\\", \\\"{x:1335,y:643,t:1527019803176};\\\", \\\"{x:1329,y:644,t:1527019803193};\\\", \\\"{x:1322,y:646,t:1527019803210};\\\", \\\"{x:1316,y:646,t:1527019803226};\\\", \\\"{x:1310,y:647,t:1527019803243};\\\", \\\"{x:1305,y:647,t:1527019803259};\\\", \\\"{x:1303,y:647,t:1527019803276};\\\", \\\"{x:1300,y:647,t:1527019803293};\\\", \\\"{x:1293,y:647,t:1527019803310};\\\", \\\"{x:1282,y:647,t:1527019803327};\\\", \\\"{x:1268,y:647,t:1527019803343};\\\", \\\"{x:1251,y:647,t:1527019803360};\\\", \\\"{x:1247,y:647,t:1527019803377};\\\", \\\"{x:1243,y:647,t:1527019803393};\\\", \\\"{x:1243,y:648,t:1527019803410};\\\", \\\"{x:1244,y:648,t:1527019803832};\\\", \\\"{x:1245,y:651,t:1527019803936};\\\", \\\"{x:1245,y:654,t:1527019803944};\\\", \\\"{x:1247,y:658,t:1527019803960};\\\", \\\"{x:1249,y:662,t:1527019803978};\\\", \\\"{x:1255,y:665,t:1527019803994};\\\", \\\"{x:1258,y:665,t:1527019804010};\\\", \\\"{x:1259,y:665,t:1527019804040};\\\", \\\"{x:1259,y:662,t:1527019804119};\\\", \\\"{x:1259,y:661,t:1527019804127};\\\", \\\"{x:1258,y:655,t:1527019804142};\\\", \\\"{x:1258,y:652,t:1527019804161};\\\", \\\"{x:1258,y:650,t:1527019804183};\\\", \\\"{x:1258,y:649,t:1527019804193};\\\", \\\"{x:1258,y:648,t:1527019804231};\\\", \\\"{x:1257,y:648,t:1527019804320};\\\", \\\"{x:1255,y:648,t:1527019804329};\\\", \\\"{x:1254,y:648,t:1527019804344};\\\", \\\"{x:1254,y:649,t:1527019804367};\\\", \\\"{x:1253,y:649,t:1527019804383};\\\", \\\"{x:1252,y:649,t:1527019804399};\\\", \\\"{x:1251,y:649,t:1527019805152};\\\", \\\"{x:1251,y:648,t:1527019805167};\\\", \\\"{x:1251,y:646,t:1527019805177};\\\", \\\"{x:1251,y:645,t:1527019805195};\\\", \\\"{x:1251,y:642,t:1527019805210};\\\", \\\"{x:1251,y:640,t:1527019805228};\\\", \\\"{x:1251,y:639,t:1527019805245};\\\", \\\"{x:1251,y:637,t:1527019805260};\\\", \\\"{x:1251,y:636,t:1527019805277};\\\", \\\"{x:1251,y:633,t:1527019806143};\\\", \\\"{x:1251,y:617,t:1527019806162};\\\", \\\"{x:1257,y:599,t:1527019806179};\\\", \\\"{x:1266,y:575,t:1527019806195};\\\", \\\"{x:1282,y:556,t:1527019806211};\\\", \\\"{x:1302,y:540,t:1527019806228};\\\", \\\"{x:1321,y:527,t:1527019806244};\\\", \\\"{x:1335,y:519,t:1527019806261};\\\", \\\"{x:1342,y:515,t:1527019806279};\\\", \\\"{x:1346,y:513,t:1527019806294};\\\", \\\"{x:1348,y:512,t:1527019806311};\\\", \\\"{x:1347,y:512,t:1527019806439};\\\", \\\"{x:1345,y:512,t:1527019806455};\\\", \\\"{x:1343,y:512,t:1527019806463};\\\", \\\"{x:1341,y:513,t:1527019806478};\\\", \\\"{x:1340,y:513,t:1527019806495};\\\", \\\"{x:1339,y:513,t:1527019806511};\\\", \\\"{x:1338,y:513,t:1527019806528};\\\", \\\"{x:1337,y:513,t:1527019806591};\\\", \\\"{x:1336,y:513,t:1527019806631};\\\", \\\"{x:1335,y:513,t:1527019806647};\\\", \\\"{x:1334,y:513,t:1527019806687};\\\", \\\"{x:1333,y:514,t:1527019806751};\\\", \\\"{x:1332,y:515,t:1527019806790};\\\", \\\"{x:1332,y:516,t:1527019806799};\\\", \\\"{x:1332,y:519,t:1527019806812};\\\", \\\"{x:1331,y:528,t:1527019806828};\\\", \\\"{x:1330,y:536,t:1527019806845};\\\", \\\"{x:1327,y:547,t:1527019806862};\\\", \\\"{x:1327,y:562,t:1527019806879};\\\", \\\"{x:1327,y:580,t:1527019806895};\\\", \\\"{x:1327,y:595,t:1527019806912};\\\", \\\"{x:1328,y:612,t:1527019806929};\\\", \\\"{x:1332,y:630,t:1527019806945};\\\", \\\"{x:1339,y:650,t:1527019806963};\\\", \\\"{x:1343,y:664,t:1527019806979};\\\", \\\"{x:1346,y:671,t:1527019806996};\\\", \\\"{x:1348,y:678,t:1527019807012};\\\", \\\"{x:1351,y:684,t:1527019807029};\\\", \\\"{x:1353,y:689,t:1527019807045};\\\", \\\"{x:1356,y:695,t:1527019807063};\\\", \\\"{x:1358,y:702,t:1527019807079};\\\", \\\"{x:1362,y:715,t:1527019807095};\\\", \\\"{x:1366,y:727,t:1527019807113};\\\", \\\"{x:1369,y:736,t:1527019807128};\\\", \\\"{x:1371,y:742,t:1527019807145};\\\", \\\"{x:1372,y:746,t:1527019807162};\\\", \\\"{x:1374,y:747,t:1527019807179};\\\", \\\"{x:1374,y:748,t:1527019807263};\\\", \\\"{x:1375,y:748,t:1527019807295};\\\", \\\"{x:1376,y:748,t:1527019807313};\\\", \\\"{x:1379,y:748,t:1527019807329};\\\", \\\"{x:1380,y:747,t:1527019807345};\\\", \\\"{x:1381,y:747,t:1527019807375};\\\", \\\"{x:1382,y:747,t:1527019807391};\\\", \\\"{x:1383,y:747,t:1527019807406};\\\", \\\"{x:1385,y:747,t:1527019807414};\\\", \\\"{x:1386,y:747,t:1527019807429};\\\", \\\"{x:1389,y:747,t:1527019807446};\\\", \\\"{x:1394,y:747,t:1527019807462};\\\", \\\"{x:1401,y:749,t:1527019807479};\\\", \\\"{x:1405,y:751,t:1527019807496};\\\", \\\"{x:1412,y:755,t:1527019807512};\\\", \\\"{x:1422,y:763,t:1527019807529};\\\", \\\"{x:1431,y:771,t:1527019807546};\\\", \\\"{x:1443,y:785,t:1527019807562};\\\", \\\"{x:1454,y:797,t:1527019807579};\\\", \\\"{x:1466,y:810,t:1527019807595};\\\", \\\"{x:1473,y:818,t:1527019807613};\\\", \\\"{x:1481,y:831,t:1527019807630};\\\", \\\"{x:1489,y:842,t:1527019807646};\\\", \\\"{x:1495,y:854,t:1527019807662};\\\", \\\"{x:1503,y:868,t:1527019807679};\\\", \\\"{x:1508,y:876,t:1527019807696};\\\", \\\"{x:1512,y:885,t:1527019807713};\\\", \\\"{x:1515,y:892,t:1527019807730};\\\", \\\"{x:1518,y:898,t:1527019807745};\\\", \\\"{x:1521,y:905,t:1527019807762};\\\", \\\"{x:1522,y:908,t:1527019807780};\\\", \\\"{x:1523,y:912,t:1527019807795};\\\", \\\"{x:1525,y:919,t:1527019807813};\\\", \\\"{x:1527,y:924,t:1527019807829};\\\", \\\"{x:1531,y:935,t:1527019807845};\\\", \\\"{x:1535,y:944,t:1527019807862};\\\", \\\"{x:1540,y:954,t:1527019807879};\\\", \\\"{x:1544,y:961,t:1527019807895};\\\", \\\"{x:1547,y:970,t:1527019807913};\\\", \\\"{x:1552,y:978,t:1527019807930};\\\", \\\"{x:1554,y:982,t:1527019807946};\\\", \\\"{x:1556,y:986,t:1527019807962};\\\", \\\"{x:1557,y:988,t:1527019807980};\\\", \\\"{x:1559,y:990,t:1527019807996};\\\", \\\"{x:1560,y:992,t:1527019808012};\\\", \\\"{x:1561,y:993,t:1527019808029};\\\", \\\"{x:1561,y:992,t:1527019808103};\\\", \\\"{x:1561,y:988,t:1527019808113};\\\", \\\"{x:1561,y:971,t:1527019808129};\\\", \\\"{x:1555,y:944,t:1527019808147};\\\", \\\"{x:1550,y:913,t:1527019808162};\\\", \\\"{x:1544,y:875,t:1527019808179};\\\", \\\"{x:1535,y:827,t:1527019808197};\\\", \\\"{x:1524,y:787,t:1527019808213};\\\", \\\"{x:1509,y:751,t:1527019808229};\\\", \\\"{x:1498,y:733,t:1527019808247};\\\", \\\"{x:1488,y:714,t:1527019808263};\\\", \\\"{x:1483,y:706,t:1527019808279};\\\", \\\"{x:1480,y:701,t:1527019808297};\\\", \\\"{x:1476,y:694,t:1527019808312};\\\", \\\"{x:1470,y:684,t:1527019808330};\\\", \\\"{x:1459,y:669,t:1527019808346};\\\", \\\"{x:1450,y:659,t:1527019808362};\\\", \\\"{x:1440,y:651,t:1527019808379};\\\", \\\"{x:1435,y:648,t:1527019808397};\\\", \\\"{x:1435,y:647,t:1527019808412};\\\", \\\"{x:1433,y:648,t:1527019808471};\\\", \\\"{x:1433,y:654,t:1527019808480};\\\", \\\"{x:1432,y:671,t:1527019808496};\\\", \\\"{x:1432,y:688,t:1527019808513};\\\", \\\"{x:1433,y:708,t:1527019808530};\\\", \\\"{x:1439,y:731,t:1527019808546};\\\", \\\"{x:1447,y:758,t:1527019808564};\\\", \\\"{x:1452,y:779,t:1527019808579};\\\", \\\"{x:1461,y:796,t:1527019808597};\\\", \\\"{x:1467,y:808,t:1527019808613};\\\", \\\"{x:1477,y:821,t:1527019808630};\\\", \\\"{x:1490,y:838,t:1527019808646};\\\", \\\"{x:1499,y:852,t:1527019808662};\\\", \\\"{x:1510,y:867,t:1527019808680};\\\", \\\"{x:1522,y:885,t:1527019808696};\\\", \\\"{x:1540,y:905,t:1527019808714};\\\", \\\"{x:1551,y:922,t:1527019808730};\\\", \\\"{x:1560,y:933,t:1527019808746};\\\", \\\"{x:1563,y:936,t:1527019808763};\\\", \\\"{x:1565,y:939,t:1527019808780};\\\", \\\"{x:1566,y:939,t:1527019808797};\\\", \\\"{x:1567,y:940,t:1527019808814};\\\", \\\"{x:1568,y:942,t:1527019808830};\\\", \\\"{x:1568,y:945,t:1527019808847};\\\", \\\"{x:1568,y:947,t:1527019808863};\\\", \\\"{x:1568,y:949,t:1527019808880};\\\", \\\"{x:1568,y:950,t:1527019808897};\\\", \\\"{x:1568,y:954,t:1527019808914};\\\", \\\"{x:1568,y:956,t:1527019808931};\\\", \\\"{x:1567,y:960,t:1527019808946};\\\", \\\"{x:1566,y:962,t:1527019808964};\\\", \\\"{x:1564,y:963,t:1527019808981};\\\", \\\"{x:1563,y:964,t:1527019808996};\\\", \\\"{x:1559,y:967,t:1527019809014};\\\", \\\"{x:1558,y:967,t:1527019809030};\\\", \\\"{x:1557,y:967,t:1527019809096};\\\", \\\"{x:1555,y:968,t:1527019809111};\\\", \\\"{x:1553,y:969,t:1527019809152};\\\", \\\"{x:1552,y:969,t:1527019809183};\\\", \\\"{x:1551,y:969,t:1527019809328};\\\", \\\"{x:1550,y:966,t:1527019809336};\\\", \\\"{x:1550,y:964,t:1527019809347};\\\", \\\"{x:1548,y:959,t:1527019809364};\\\", \\\"{x:1545,y:952,t:1527019809381};\\\", \\\"{x:1544,y:945,t:1527019809398};\\\", \\\"{x:1541,y:937,t:1527019809414};\\\", \\\"{x:1533,y:918,t:1527019809431};\\\", \\\"{x:1526,y:906,t:1527019809447};\\\", \\\"{x:1519,y:895,t:1527019809464};\\\", \\\"{x:1510,y:877,t:1527019809481};\\\", \\\"{x:1499,y:857,t:1527019809498};\\\", \\\"{x:1489,y:840,t:1527019809514};\\\", \\\"{x:1476,y:818,t:1527019809531};\\\", \\\"{x:1465,y:798,t:1527019809548};\\\", \\\"{x:1455,y:781,t:1527019809565};\\\", \\\"{x:1449,y:767,t:1527019809581};\\\", \\\"{x:1441,y:755,t:1527019809598};\\\", \\\"{x:1437,y:746,t:1527019809614};\\\", \\\"{x:1429,y:733,t:1527019809631};\\\", \\\"{x:1423,y:723,t:1527019809647};\\\", \\\"{x:1419,y:715,t:1527019809664};\\\", \\\"{x:1415,y:709,t:1527019809681};\\\", \\\"{x:1410,y:700,t:1527019809698};\\\", \\\"{x:1406,y:692,t:1527019809714};\\\", \\\"{x:1402,y:686,t:1527019809731};\\\", \\\"{x:1397,y:679,t:1527019809748};\\\", \\\"{x:1392,y:673,t:1527019809765};\\\", \\\"{x:1388,y:668,t:1527019809780};\\\", \\\"{x:1387,y:666,t:1527019809798};\\\", \\\"{x:1385,y:664,t:1527019809814};\\\", \\\"{x:1385,y:662,t:1527019812096};\\\", \\\"{x:1381,y:655,t:1527019812104};\\\", \\\"{x:1377,y:647,t:1527019812117};\\\", \\\"{x:1369,y:631,t:1527019812133};\\\", \\\"{x:1362,y:621,t:1527019812149};\\\", \\\"{x:1359,y:612,t:1527019812167};\\\", \\\"{x:1351,y:594,t:1527019812183};\\\", \\\"{x:1348,y:586,t:1527019812199};\\\", \\\"{x:1346,y:581,t:1527019812216};\\\", \\\"{x:1343,y:571,t:1527019812233};\\\", \\\"{x:1341,y:563,t:1527019812250};\\\", \\\"{x:1339,y:557,t:1527019812266};\\\", \\\"{x:1338,y:552,t:1527019812283};\\\", \\\"{x:1336,y:547,t:1527019812299};\\\", \\\"{x:1335,y:543,t:1527019812316};\\\", \\\"{x:1334,y:539,t:1527019812333};\\\", \\\"{x:1333,y:535,t:1527019812350};\\\", \\\"{x:1333,y:533,t:1527019812366};\\\", \\\"{x:1331,y:529,t:1527019812384};\\\", \\\"{x:1330,y:524,t:1527019812399};\\\", \\\"{x:1329,y:521,t:1527019812416};\\\", \\\"{x:1329,y:520,t:1527019812433};\\\", \\\"{x:1327,y:519,t:1527019812520};\\\", \\\"{x:1325,y:519,t:1527019812533};\\\", \\\"{x:1319,y:527,t:1527019812550};\\\", \\\"{x:1314,y:540,t:1527019812565};\\\", \\\"{x:1306,y:565,t:1527019812583};\\\", \\\"{x:1302,y:577,t:1527019812600};\\\", \\\"{x:1299,y:589,t:1527019812616};\\\", \\\"{x:1297,y:598,t:1527019812633};\\\", \\\"{x:1297,y:609,t:1527019812649};\\\", \\\"{x:1296,y:618,t:1527019812667};\\\", \\\"{x:1295,y:623,t:1527019812682};\\\", \\\"{x:1295,y:625,t:1527019812699};\\\", \\\"{x:1295,y:623,t:1527019812815};\\\", \\\"{x:1295,y:612,t:1527019812823};\\\", \\\"{x:1295,y:602,t:1527019812833};\\\", \\\"{x:1295,y:584,t:1527019812850};\\\", \\\"{x:1296,y:572,t:1527019812867};\\\", \\\"{x:1299,y:556,t:1527019812883};\\\", \\\"{x:1299,y:548,t:1527019812900};\\\", \\\"{x:1299,y:540,t:1527019812917};\\\", \\\"{x:1299,y:537,t:1527019812933};\\\", \\\"{x:1299,y:533,t:1527019812950};\\\", \\\"{x:1300,y:529,t:1527019812967};\\\", \\\"{x:1300,y:527,t:1527019812983};\\\", \\\"{x:1300,y:525,t:1527019813000};\\\", \\\"{x:1300,y:524,t:1527019813017};\\\", \\\"{x:1301,y:524,t:1527019813033};\\\", \\\"{x:1301,y:522,t:1527019813049};\\\", \\\"{x:1302,y:520,t:1527019813066};\\\", \\\"{x:1303,y:517,t:1527019813082};\\\", \\\"{x:1304,y:514,t:1527019813100};\\\", \\\"{x:1306,y:511,t:1527019813116};\\\", \\\"{x:1307,y:509,t:1527019813134};\\\", \\\"{x:1307,y:507,t:1527019813149};\\\", \\\"{x:1309,y:505,t:1527019813166};\\\", \\\"{x:1309,y:504,t:1527019813184};\\\", \\\"{x:1309,y:509,t:1527019813680};\\\", \\\"{x:1308,y:518,t:1527019813688};\\\", \\\"{x:1308,y:527,t:1527019813701};\\\", \\\"{x:1306,y:540,t:1527019813717};\\\", \\\"{x:1306,y:549,t:1527019813734};\\\", \\\"{x:1306,y:556,t:1527019813751};\\\", \\\"{x:1306,y:563,t:1527019813767};\\\", \\\"{x:1306,y:573,t:1527019813784};\\\", \\\"{x:1304,y:586,t:1527019813801};\\\", \\\"{x:1304,y:599,t:1527019813817};\\\", \\\"{x:1304,y:611,t:1527019813834};\\\", \\\"{x:1304,y:620,t:1527019813851};\\\", \\\"{x:1304,y:624,t:1527019813867};\\\", \\\"{x:1304,y:629,t:1527019813884};\\\", \\\"{x:1304,y:633,t:1527019813901};\\\", \\\"{x:1304,y:637,t:1527019813917};\\\", \\\"{x:1304,y:642,t:1527019813934};\\\", \\\"{x:1304,y:650,t:1527019813952};\\\", \\\"{x:1304,y:653,t:1527019813967};\\\", \\\"{x:1304,y:655,t:1527019813984};\\\", \\\"{x:1304,y:659,t:1527019814001};\\\", \\\"{x:1305,y:664,t:1527019814017};\\\", \\\"{x:1305,y:667,t:1527019814034};\\\", \\\"{x:1305,y:671,t:1527019814051};\\\", \\\"{x:1307,y:673,t:1527019814068};\\\", \\\"{x:1307,y:676,t:1527019814084};\\\", \\\"{x:1307,y:681,t:1527019814101};\\\", \\\"{x:1307,y:684,t:1527019814118};\\\", \\\"{x:1308,y:690,t:1527019814134};\\\", \\\"{x:1309,y:700,t:1527019814151};\\\", \\\"{x:1311,y:708,t:1527019814168};\\\", \\\"{x:1312,y:716,t:1527019814184};\\\", \\\"{x:1313,y:724,t:1527019814201};\\\", \\\"{x:1313,y:729,t:1527019814219};\\\", \\\"{x:1315,y:736,t:1527019814234};\\\", \\\"{x:1315,y:740,t:1527019814251};\\\", \\\"{x:1316,y:746,t:1527019814268};\\\", \\\"{x:1316,y:752,t:1527019814284};\\\", \\\"{x:1317,y:758,t:1527019814302};\\\", \\\"{x:1319,y:761,t:1527019814318};\\\", \\\"{x:1319,y:766,t:1527019814334};\\\", \\\"{x:1321,y:773,t:1527019814352};\\\", \\\"{x:1323,y:780,t:1527019814367};\\\", \\\"{x:1323,y:785,t:1527019814385};\\\", \\\"{x:1324,y:793,t:1527019814401};\\\", \\\"{x:1324,y:799,t:1527019814418};\\\", \\\"{x:1324,y:804,t:1527019814434};\\\", \\\"{x:1324,y:808,t:1527019814451};\\\", \\\"{x:1324,y:809,t:1527019814469};\\\", \\\"{x:1324,y:811,t:1527019814484};\\\", \\\"{x:1324,y:814,t:1527019814501};\\\", \\\"{x:1324,y:817,t:1527019814518};\\\", \\\"{x:1324,y:820,t:1527019814535};\\\", \\\"{x:1324,y:822,t:1527019814551};\\\", \\\"{x:1324,y:824,t:1527019814568};\\\", \\\"{x:1324,y:828,t:1527019814585};\\\", \\\"{x:1324,y:829,t:1527019814601};\\\", \\\"{x:1324,y:831,t:1527019814618};\\\", \\\"{x:1324,y:833,t:1527019814635};\\\", \\\"{x:1324,y:834,t:1527019814655};\\\", \\\"{x:1324,y:835,t:1527019814671};\\\", \\\"{x:1324,y:836,t:1527019814685};\\\", \\\"{x:1324,y:838,t:1527019814701};\\\", \\\"{x:1323,y:842,t:1527019814718};\\\", \\\"{x:1322,y:849,t:1527019814735};\\\", \\\"{x:1322,y:852,t:1527019814751};\\\", \\\"{x:1322,y:854,t:1527019814768};\\\", \\\"{x:1322,y:855,t:1527019814785};\\\", \\\"{x:1321,y:858,t:1527019814801};\\\", \\\"{x:1320,y:858,t:1527019814818};\\\", \\\"{x:1320,y:861,t:1527019814835};\\\", \\\"{x:1320,y:863,t:1527019814851};\\\", \\\"{x:1320,y:865,t:1527019814868};\\\", \\\"{x:1320,y:868,t:1527019814885};\\\", \\\"{x:1319,y:871,t:1527019814901};\\\", \\\"{x:1318,y:875,t:1527019814918};\\\", \\\"{x:1318,y:878,t:1527019814935};\\\", \\\"{x:1317,y:882,t:1527019814951};\\\", \\\"{x:1316,y:887,t:1527019814969};\\\", \\\"{x:1316,y:888,t:1527019814985};\\\", \\\"{x:1316,y:891,t:1527019815001};\\\", \\\"{x:1315,y:894,t:1527019815018};\\\", \\\"{x:1315,y:899,t:1527019815035};\\\", \\\"{x:1315,y:904,t:1527019815052};\\\", \\\"{x:1314,y:909,t:1527019815068};\\\", \\\"{x:1314,y:913,t:1527019815085};\\\", \\\"{x:1314,y:918,t:1527019815102};\\\", \\\"{x:1314,y:923,t:1527019815118};\\\", \\\"{x:1314,y:934,t:1527019815135};\\\", \\\"{x:1314,y:942,t:1527019815151};\\\", \\\"{x:1316,y:953,t:1527019815168};\\\", \\\"{x:1318,y:958,t:1527019815185};\\\", \\\"{x:1318,y:960,t:1527019815203};\\\", \\\"{x:1318,y:962,t:1527019815218};\\\", \\\"{x:1319,y:963,t:1527019815235};\\\", \\\"{x:1320,y:965,t:1527019815252};\\\", \\\"{x:1320,y:966,t:1527019815271};\\\", \\\"{x:1320,y:968,t:1527019815286};\\\", \\\"{x:1320,y:970,t:1527019815303};\\\", \\\"{x:1320,y:972,t:1527019815317};\\\", \\\"{x:1321,y:977,t:1527019815335};\\\", \\\"{x:1321,y:981,t:1527019815351};\\\", \\\"{x:1322,y:983,t:1527019815367};\\\", \\\"{x:1323,y:984,t:1527019815385};\\\", \\\"{x:1323,y:985,t:1527019815401};\\\", \\\"{x:1323,y:986,t:1527019815872};\\\", \\\"{x:1323,y:985,t:1527019816110};\\\", \\\"{x:1323,y:984,t:1527019816175};\\\", \\\"{x:1323,y:983,t:1527019816311};\\\", \\\"{x:1322,y:981,t:1527019816351};\\\", \\\"{x:1322,y:980,t:1527019816479};\\\", \\\"{x:1321,y:979,t:1527019817216};\\\", \\\"{x:1319,y:978,t:1527019817616};\\\", \\\"{x:1319,y:977,t:1527019817623};\\\", \\\"{x:1317,y:975,t:1527019817639};\\\", \\\"{x:1316,y:972,t:1527019817655};\\\", \\\"{x:1315,y:971,t:1527019817671};\\\", \\\"{x:1315,y:968,t:1527019818296};\\\", \\\"{x:1314,y:966,t:1527019818304};\\\", \\\"{x:1314,y:962,t:1527019818322};\\\", \\\"{x:1314,y:957,t:1527019818337};\\\", \\\"{x:1314,y:952,t:1527019818355};\\\", \\\"{x:1318,y:943,t:1527019818371};\\\", \\\"{x:1323,y:931,t:1527019818387};\\\", \\\"{x:1330,y:913,t:1527019818404};\\\", \\\"{x:1335,y:894,t:1527019818422};\\\", \\\"{x:1342,y:867,t:1527019818437};\\\", \\\"{x:1355,y:839,t:1527019818454};\\\", \\\"{x:1364,y:816,t:1527019818471};\\\", \\\"{x:1369,y:805,t:1527019818487};\\\", \\\"{x:1372,y:797,t:1527019818504};\\\", \\\"{x:1373,y:792,t:1527019818521};\\\", \\\"{x:1376,y:788,t:1527019818537};\\\", \\\"{x:1378,y:782,t:1527019818554};\\\", \\\"{x:1385,y:774,t:1527019818572};\\\", \\\"{x:1390,y:766,t:1527019818587};\\\", \\\"{x:1393,y:761,t:1527019818605};\\\", \\\"{x:1396,y:756,t:1527019818622};\\\", \\\"{x:1399,y:753,t:1527019818637};\\\", \\\"{x:1401,y:750,t:1527019818654};\\\", \\\"{x:1406,y:743,t:1527019818672};\\\", \\\"{x:1407,y:741,t:1527019818687};\\\", \\\"{x:1410,y:737,t:1527019818705};\\\", \\\"{x:1412,y:735,t:1527019818722};\\\", \\\"{x:1413,y:734,t:1527019818737};\\\", \\\"{x:1413,y:733,t:1527019818759};\\\", \\\"{x:1413,y:732,t:1527019818772};\\\", \\\"{x:1414,y:731,t:1527019818789};\\\", \\\"{x:1414,y:729,t:1527019818805};\\\", \\\"{x:1415,y:728,t:1527019818822};\\\", \\\"{x:1416,y:726,t:1527019818839};\\\", \\\"{x:1416,y:723,t:1527019818855};\\\", \\\"{x:1416,y:718,t:1527019818871};\\\", \\\"{x:1416,y:715,t:1527019818889};\\\", \\\"{x:1416,y:712,t:1527019818905};\\\", \\\"{x:1416,y:707,t:1527019818922};\\\", \\\"{x:1416,y:703,t:1527019818938};\\\", \\\"{x:1416,y:700,t:1527019818954};\\\", \\\"{x:1416,y:697,t:1527019818971};\\\", \\\"{x:1416,y:696,t:1527019818988};\\\", \\\"{x:1416,y:695,t:1527019819004};\\\", \\\"{x:1415,y:694,t:1527019819023};\\\", \\\"{x:1414,y:694,t:1527019819647};\\\", \\\"{x:1414,y:695,t:1527019819663};\\\", \\\"{x:1414,y:696,t:1527019819671};\\\", \\\"{x:1414,y:697,t:1527019819689};\\\", \\\"{x:1414,y:701,t:1527019819705};\\\", \\\"{x:1414,y:703,t:1527019819722};\\\", \\\"{x:1414,y:706,t:1527019819738};\\\", \\\"{x:1414,y:710,t:1527019819755};\\\", \\\"{x:1415,y:714,t:1527019819773};\\\", \\\"{x:1417,y:720,t:1527019819788};\\\", \\\"{x:1418,y:724,t:1527019819805};\\\", \\\"{x:1420,y:729,t:1527019819823};\\\", \\\"{x:1422,y:735,t:1527019819839};\\\", \\\"{x:1425,y:742,t:1527019819855};\\\", \\\"{x:1426,y:746,t:1527019819872};\\\", \\\"{x:1427,y:749,t:1527019819888};\\\", \\\"{x:1428,y:749,t:1527019820104};\\\", \\\"{x:1429,y:750,t:1527019820111};\\\", \\\"{x:1432,y:752,t:1527019820122};\\\", \\\"{x:1440,y:757,t:1527019820140};\\\", \\\"{x:1448,y:760,t:1527019820155};\\\", \\\"{x:1452,y:762,t:1527019820172};\\\", \\\"{x:1456,y:765,t:1527019820189};\\\", \\\"{x:1456,y:766,t:1527019820408};\\\", \\\"{x:1455,y:767,t:1527019820422};\\\", \\\"{x:1452,y:769,t:1527019820439};\\\", \\\"{x:1450,y:769,t:1527019820455};\\\", \\\"{x:1449,y:769,t:1527019820472};\\\", \\\"{x:1447,y:771,t:1527019820489};\\\", \\\"{x:1446,y:772,t:1527019820505};\\\", \\\"{x:1444,y:772,t:1527019820522};\\\", \\\"{x:1443,y:772,t:1527019820712};\\\", \\\"{x:1443,y:771,t:1527019820730};\\\", \\\"{x:1443,y:770,t:1527019820991};\\\", \\\"{x:1443,y:769,t:1527019821006};\\\", \\\"{x:1445,y:768,t:1527019821023};\\\", \\\"{x:1449,y:766,t:1527019821039};\\\", \\\"{x:1449,y:765,t:1527019821063};\\\", \\\"{x:1449,y:764,t:1527019830927};\\\", \\\"{x:1448,y:762,t:1527019831190};\\\", \\\"{x:1446,y:761,t:1527019831198};\\\", \\\"{x:1446,y:760,t:1527019831213};\\\", \\\"{x:1445,y:758,t:1527019831230};\\\", \\\"{x:1443,y:758,t:1527019831247};\\\", \\\"{x:1443,y:756,t:1527019832487};\\\", \\\"{x:1442,y:754,t:1527019832497};\\\", \\\"{x:1438,y:747,t:1527019832514};\\\", \\\"{x:1434,y:740,t:1527019832531};\\\", \\\"{x:1433,y:738,t:1527019832547};\\\", \\\"{x:1433,y:736,t:1527019832565};\\\", \\\"{x:1431,y:734,t:1527019832582};\\\", \\\"{x:1430,y:733,t:1527019832662};\\\", \\\"{x:1430,y:732,t:1527019832670};\\\", \\\"{x:1429,y:730,t:1527019832694};\\\", \\\"{x:1429,y:729,t:1527019832710};\\\", \\\"{x:1427,y:727,t:1527019832718};\\\", \\\"{x:1426,y:724,t:1527019832732};\\\", \\\"{x:1424,y:720,t:1527019832748};\\\", \\\"{x:1423,y:717,t:1527019832764};\\\", \\\"{x:1420,y:712,t:1527019832782};\\\", \\\"{x:1419,y:710,t:1527019832798};\\\", \\\"{x:1417,y:707,t:1527019832814};\\\", \\\"{x:1416,y:705,t:1527019832863};\\\", \\\"{x:1414,y:705,t:1527019834822};\\\", \\\"{x:1413,y:705,t:1527019835310};\\\", \\\"{x:1412,y:705,t:1527019836080};\\\", \\\"{x:1412,y:706,t:1527019841175};\\\", \\\"{x:1411,y:706,t:1527019841263};\\\", \\\"{x:1410,y:706,t:1527019841271};\\\", \\\"{x:1409,y:709,t:1527019841783};\\\", \\\"{x:1409,y:716,t:1527019841791};\\\", \\\"{x:1409,y:722,t:1527019841805};\\\", \\\"{x:1410,y:737,t:1527019841821};\\\", \\\"{x:1413,y:746,t:1527019841838};\\\", \\\"{x:1416,y:757,t:1527019841855};\\\", \\\"{x:1420,y:765,t:1527019841872};\\\", \\\"{x:1425,y:774,t:1527019841888};\\\", \\\"{x:1431,y:782,t:1527019841906};\\\", \\\"{x:1437,y:791,t:1527019841922};\\\", \\\"{x:1441,y:799,t:1527019841938};\\\", \\\"{x:1450,y:814,t:1527019841955};\\\", \\\"{x:1461,y:831,t:1527019841973};\\\", \\\"{x:1473,y:852,t:1527019841988};\\\", \\\"{x:1484,y:871,t:1527019842005};\\\", \\\"{x:1493,y:884,t:1527019842022};\\\", \\\"{x:1499,y:896,t:1527019842038};\\\", \\\"{x:1502,y:903,t:1527019842055};\\\", \\\"{x:1502,y:904,t:1527019842072};\\\", \\\"{x:1502,y:905,t:1527019842088};\\\", \\\"{x:1502,y:906,t:1527019842105};\\\", \\\"{x:1502,y:911,t:1527019842123};\\\", \\\"{x:1506,y:917,t:1527019842138};\\\", \\\"{x:1508,y:924,t:1527019842155};\\\", \\\"{x:1512,y:932,t:1527019842172};\\\", \\\"{x:1515,y:937,t:1527019842188};\\\", \\\"{x:1518,y:943,t:1527019842205};\\\", \\\"{x:1521,y:949,t:1527019842222};\\\", \\\"{x:1524,y:953,t:1527019842239};\\\", \\\"{x:1528,y:959,t:1527019842255};\\\", \\\"{x:1530,y:960,t:1527019842272};\\\", \\\"{x:1533,y:963,t:1527019842288};\\\", \\\"{x:1534,y:963,t:1527019842306};\\\", \\\"{x:1536,y:964,t:1527019842322};\\\", \\\"{x:1537,y:965,t:1527019842338};\\\", \\\"{x:1537,y:966,t:1527019842355};\\\", \\\"{x:1538,y:966,t:1527019842382};\\\", \\\"{x:1539,y:967,t:1527019842398};\\\", \\\"{x:1540,y:969,t:1527019842423};\\\", \\\"{x:1541,y:969,t:1527019842447};\\\", \\\"{x:1542,y:971,t:1527019842455};\\\", \\\"{x:1543,y:972,t:1527019842478};\\\", \\\"{x:1541,y:972,t:1527019842767};\\\", \\\"{x:1539,y:971,t:1527019842774};\\\", \\\"{x:1539,y:970,t:1527019842789};\\\", \\\"{x:1536,y:968,t:1527019842806};\\\", \\\"{x:1533,y:965,t:1527019842822};\\\", \\\"{x:1529,y:960,t:1527019842840};\\\", \\\"{x:1526,y:955,t:1527019842857};\\\", \\\"{x:1525,y:953,t:1527019842872};\\\", \\\"{x:1524,y:952,t:1527019842889};\\\", \\\"{x:1524,y:951,t:1527019842906};\\\", \\\"{x:1523,y:950,t:1527019842922};\\\", \\\"{x:1522,y:949,t:1527019843006};\\\", \\\"{x:1521,y:949,t:1527019843022};\\\", \\\"{x:1519,y:947,t:1527019843039};\\\", \\\"{x:1519,y:946,t:1527019843056};\\\", \\\"{x:1518,y:945,t:1527019843072};\\\", \\\"{x:1516,y:944,t:1527019843088};\\\", \\\"{x:1514,y:942,t:1527019843886};\\\", \\\"{x:1513,y:942,t:1527019843894};\\\", \\\"{x:1512,y:942,t:1527019843906};\\\", \\\"{x:1509,y:940,t:1527019843923};\\\", \\\"{x:1506,y:939,t:1527019843939};\\\", \\\"{x:1505,y:938,t:1527019843955};\\\", \\\"{x:1504,y:937,t:1527019843972};\\\", \\\"{x:1504,y:936,t:1527019845087};\\\", \\\"{x:1502,y:934,t:1527019845095};\\\", \\\"{x:1502,y:933,t:1527019845107};\\\", \\\"{x:1499,y:931,t:1527019845125};\\\", \\\"{x:1498,y:930,t:1527019845141};\\\", \\\"{x:1497,y:930,t:1527019845157};\\\", \\\"{x:1494,y:927,t:1527019845174};\\\", \\\"{x:1494,y:926,t:1527019845190};\\\", \\\"{x:1492,y:924,t:1527019845206};\\\", \\\"{x:1491,y:922,t:1527019845224};\\\", \\\"{x:1487,y:915,t:1527019845241};\\\", \\\"{x:1483,y:903,t:1527019845256};\\\", \\\"{x:1472,y:877,t:1527019845274};\\\", \\\"{x:1466,y:857,t:1527019845291};\\\", \\\"{x:1459,y:841,t:1527019845307};\\\", \\\"{x:1454,y:829,t:1527019845324};\\\", \\\"{x:1450,y:821,t:1527019845341};\\\", \\\"{x:1449,y:818,t:1527019845357};\\\", \\\"{x:1447,y:814,t:1527019845374};\\\", \\\"{x:1445,y:811,t:1527019845390};\\\", \\\"{x:1444,y:806,t:1527019845407};\\\", \\\"{x:1443,y:804,t:1527019845424};\\\", \\\"{x:1442,y:799,t:1527019845442};\\\", \\\"{x:1442,y:796,t:1527019845457};\\\", \\\"{x:1440,y:794,t:1527019845474};\\\", \\\"{x:1440,y:793,t:1527019845494};\\\", \\\"{x:1440,y:792,t:1527019845510};\\\", \\\"{x:1440,y:791,t:1527019845526};\\\", \\\"{x:1440,y:790,t:1527019845541};\\\", \\\"{x:1436,y:785,t:1527019845557};\\\", \\\"{x:1433,y:775,t:1527019845574};\\\", \\\"{x:1431,y:769,t:1527019845590};\\\", \\\"{x:1430,y:764,t:1527019845607};\\\", \\\"{x:1428,y:759,t:1527019845624};\\\", \\\"{x:1427,y:756,t:1527019845640};\\\", \\\"{x:1426,y:751,t:1527019845658};\\\", \\\"{x:1425,y:747,t:1527019845673};\\\", \\\"{x:1423,y:744,t:1527019845691};\\\", \\\"{x:1422,y:741,t:1527019845707};\\\", \\\"{x:1422,y:740,t:1527019845724};\\\", \\\"{x:1421,y:739,t:1527019845741};\\\", \\\"{x:1422,y:739,t:1527019846143};\\\", \\\"{x:1425,y:745,t:1527019846158};\\\", \\\"{x:1427,y:747,t:1527019846174};\\\", \\\"{x:1429,y:750,t:1527019846191};\\\", \\\"{x:1431,y:753,t:1527019846208};\\\", \\\"{x:1432,y:755,t:1527019846225};\\\", \\\"{x:1435,y:758,t:1527019846241};\\\", \\\"{x:1436,y:759,t:1527019846258};\\\", \\\"{x:1436,y:760,t:1527019846275};\\\", \\\"{x:1437,y:760,t:1527019846291};\\\", \\\"{x:1437,y:761,t:1527019846308};\\\", \\\"{x:1438,y:762,t:1527019846325};\\\", \\\"{x:1439,y:762,t:1527019846341};\\\", \\\"{x:1439,y:763,t:1527019846358};\\\", \\\"{x:1440,y:763,t:1527019846415};\\\", \\\"{x:1441,y:763,t:1527019846431};\\\", \\\"{x:1442,y:763,t:1527019846441};\\\", \\\"{x:1445,y:763,t:1527019846458};\\\", \\\"{x:1448,y:763,t:1527019846475};\\\", \\\"{x:1450,y:763,t:1527019846494};\\\", \\\"{x:1451,y:763,t:1527019846507};\\\", \\\"{x:1451,y:762,t:1527019850958};\\\", \\\"{x:1446,y:752,t:1527019869699};\\\", \\\"{x:1444,y:742,t:1527019869713};\\\", \\\"{x:1429,y:710,t:1527019869730};\\\", \\\"{x:1409,y:675,t:1527019869746};\\\", \\\"{x:1397,y:656,t:1527019869763};\\\", \\\"{x:1390,y:640,t:1527019869780};\\\", \\\"{x:1385,y:627,t:1527019869796};\\\", \\\"{x:1381,y:616,t:1527019869813};\\\", \\\"{x:1378,y:608,t:1527019869831};\\\", \\\"{x:1376,y:598,t:1527019869846};\\\", \\\"{x:1372,y:586,t:1527019869863};\\\", \\\"{x:1367,y:574,t:1527019869880};\\\", \\\"{x:1361,y:564,t:1527019869896};\\\", \\\"{x:1359,y:559,t:1527019869913};\\\", \\\"{x:1358,y:557,t:1527019869929};\\\", \\\"{x:1358,y:556,t:1527019869946};\\\", \\\"{x:1358,y:554,t:1527019869963};\\\", \\\"{x:1357,y:551,t:1527019869980};\\\", \\\"{x:1355,y:546,t:1527019869995};\\\", \\\"{x:1355,y:543,t:1527019870013};\\\", \\\"{x:1353,y:538,t:1527019870030};\\\", \\\"{x:1351,y:533,t:1527019870046};\\\", \\\"{x:1350,y:530,t:1527019870063};\\\", \\\"{x:1348,y:526,t:1527019870080};\\\", \\\"{x:1347,y:523,t:1527019870096};\\\", \\\"{x:1344,y:518,t:1527019870113};\\\", \\\"{x:1339,y:512,t:1527019870129};\\\", \\\"{x:1337,y:510,t:1527019870146};\\\", \\\"{x:1335,y:508,t:1527019870163};\\\", \\\"{x:1335,y:507,t:1527019870180};\\\", \\\"{x:1333,y:505,t:1527019870197};\\\", \\\"{x:1332,y:503,t:1527019870213};\\\", \\\"{x:1331,y:502,t:1527019870230};\\\", \\\"{x:1330,y:502,t:1527019870247};\\\", \\\"{x:1329,y:501,t:1527019870263};\\\", \\\"{x:1328,y:501,t:1527019870281};\\\", \\\"{x:1327,y:501,t:1527019870297};\\\", \\\"{x:1327,y:500,t:1527019870313};\\\", \\\"{x:1326,y:499,t:1527019870330};\\\", \\\"{x:1325,y:499,t:1527019870354};\\\", \\\"{x:1324,y:499,t:1527019870379};\\\", \\\"{x:1324,y:500,t:1527019870547};\\\", \\\"{x:1319,y:506,t:1527019870564};\\\", \\\"{x:1314,y:517,t:1527019870581};\\\", \\\"{x:1311,y:522,t:1527019870597};\\\", \\\"{x:1311,y:524,t:1527019870613};\\\", \\\"{x:1310,y:528,t:1527019870630};\\\", \\\"{x:1309,y:532,t:1527019870647};\\\", \\\"{x:1309,y:535,t:1527019870665};\\\", \\\"{x:1307,y:540,t:1527019870680};\\\", \\\"{x:1306,y:543,t:1527019870698};\\\", \\\"{x:1306,y:546,t:1527019870715};\\\", \\\"{x:1306,y:548,t:1527019870730};\\\", \\\"{x:1306,y:550,t:1527019870747};\\\", \\\"{x:1306,y:554,t:1527019870764};\\\", \\\"{x:1305,y:557,t:1527019870781};\\\", \\\"{x:1305,y:560,t:1527019870798};\\\", \\\"{x:1305,y:563,t:1527019870815};\\\", \\\"{x:1305,y:567,t:1527019870831};\\\", \\\"{x:1305,y:570,t:1527019870847};\\\", \\\"{x:1305,y:575,t:1527019870864};\\\", \\\"{x:1305,y:580,t:1527019870881};\\\", \\\"{x:1305,y:584,t:1527019870898};\\\", \\\"{x:1305,y:587,t:1527019870915};\\\", \\\"{x:1305,y:590,t:1527019870930};\\\", \\\"{x:1305,y:592,t:1527019870947};\\\", \\\"{x:1305,y:594,t:1527019870965};\\\", \\\"{x:1305,y:596,t:1527019870980};\\\", \\\"{x:1305,y:598,t:1527019870997};\\\", \\\"{x:1305,y:601,t:1527019871015};\\\", \\\"{x:1305,y:604,t:1527019871030};\\\", \\\"{x:1305,y:607,t:1527019871048};\\\", \\\"{x:1305,y:610,t:1527019871064};\\\", \\\"{x:1305,y:613,t:1527019871081};\\\", \\\"{x:1305,y:614,t:1527019871097};\\\", \\\"{x:1305,y:620,t:1527019871115};\\\", \\\"{x:1305,y:624,t:1527019871130};\\\", \\\"{x:1305,y:627,t:1527019871147};\\\", \\\"{x:1305,y:631,t:1527019871165};\\\", \\\"{x:1305,y:633,t:1527019871182};\\\", \\\"{x:1305,y:635,t:1527019871197};\\\", \\\"{x:1306,y:640,t:1527019871215};\\\", \\\"{x:1306,y:644,t:1527019871232};\\\", \\\"{x:1307,y:649,t:1527019871248};\\\", \\\"{x:1308,y:654,t:1527019871265};\\\", \\\"{x:1308,y:657,t:1527019871281};\\\", \\\"{x:1308,y:661,t:1527019871297};\\\", \\\"{x:1308,y:666,t:1527019871314};\\\", \\\"{x:1308,y:669,t:1527019871332};\\\", \\\"{x:1308,y:672,t:1527019871347};\\\", \\\"{x:1309,y:674,t:1527019871364};\\\", \\\"{x:1310,y:676,t:1527019871381};\\\", \\\"{x:1310,y:677,t:1527019871398};\\\", \\\"{x:1310,y:679,t:1527019871434};\\\", \\\"{x:1310,y:681,t:1527019871447};\\\", \\\"{x:1310,y:684,t:1527019871464};\\\", \\\"{x:1309,y:693,t:1527019871482};\\\", \\\"{x:1309,y:694,t:1527019871498};\\\", \\\"{x:1309,y:700,t:1527019871515};\\\", \\\"{x:1307,y:704,t:1527019871533};\\\", \\\"{x:1307,y:707,t:1527019871548};\\\", \\\"{x:1307,y:709,t:1527019871565};\\\", \\\"{x:1307,y:711,t:1527019871582};\\\", \\\"{x:1307,y:714,t:1527019871599};\\\", \\\"{x:1307,y:715,t:1527019871615};\\\", \\\"{x:1307,y:718,t:1527019871631};\\\", \\\"{x:1306,y:724,t:1527019871649};\\\", \\\"{x:1305,y:731,t:1527019871665};\\\", \\\"{x:1305,y:734,t:1527019871681};\\\", \\\"{x:1305,y:740,t:1527019871699};\\\", \\\"{x:1305,y:745,t:1527019871715};\\\", \\\"{x:1305,y:752,t:1527019871733};\\\", \\\"{x:1305,y:757,t:1527019871749};\\\", \\\"{x:1305,y:760,t:1527019871764};\\\", \\\"{x:1305,y:762,t:1527019871782};\\\", \\\"{x:1305,y:765,t:1527019871798};\\\", \\\"{x:1305,y:766,t:1527019871827};\\\", \\\"{x:1305,y:767,t:1527019871842};\\\", \\\"{x:1305,y:768,t:1527019871859};\\\", \\\"{x:1304,y:770,t:1527019871874};\\\", \\\"{x:1304,y:772,t:1527019871890};\\\", \\\"{x:1304,y:773,t:1527019871907};\\\", \\\"{x:1304,y:774,t:1527019871915};\\\", \\\"{x:1304,y:776,t:1527019871931};\\\", \\\"{x:1304,y:777,t:1527019871948};\\\", \\\"{x:1304,y:779,t:1527019871965};\\\", \\\"{x:1304,y:783,t:1527019871982};\\\", \\\"{x:1304,y:790,t:1527019871999};\\\", \\\"{x:1304,y:800,t:1527019872015};\\\", \\\"{x:1303,y:811,t:1527019872032};\\\", \\\"{x:1302,y:818,t:1527019872049};\\\", \\\"{x:1302,y:821,t:1527019872066};\\\", \\\"{x:1302,y:824,t:1527019872082};\\\", \\\"{x:1302,y:827,t:1527019872098};\\\", \\\"{x:1302,y:830,t:1527019872115};\\\", \\\"{x:1302,y:831,t:1527019872132};\\\", \\\"{x:1302,y:834,t:1527019872148};\\\", \\\"{x:1302,y:837,t:1527019872165};\\\", \\\"{x:1302,y:841,t:1527019872181};\\\", \\\"{x:1302,y:844,t:1527019872199};\\\", \\\"{x:1302,y:846,t:1527019872216};\\\", \\\"{x:1302,y:848,t:1527019872232};\\\", \\\"{x:1302,y:849,t:1527019872248};\\\", \\\"{x:1302,y:852,t:1527019872265};\\\", \\\"{x:1302,y:854,t:1527019872282};\\\", \\\"{x:1302,y:859,t:1527019872298};\\\", \\\"{x:1302,y:860,t:1527019872315};\\\", \\\"{x:1302,y:862,t:1527019872333};\\\", \\\"{x:1302,y:863,t:1527019872348};\\\", \\\"{x:1302,y:866,t:1527019872366};\\\", \\\"{x:1302,y:867,t:1527019872381};\\\", \\\"{x:1302,y:870,t:1527019872399};\\\", \\\"{x:1303,y:875,t:1527019872416};\\\", \\\"{x:1304,y:879,t:1527019872432};\\\", \\\"{x:1304,y:880,t:1527019872448};\\\", \\\"{x:1304,y:883,t:1527019872465};\\\", \\\"{x:1304,y:886,t:1527019872482};\\\", \\\"{x:1304,y:890,t:1527019872499};\\\", \\\"{x:1306,y:893,t:1527019872515};\\\", \\\"{x:1306,y:896,t:1527019872533};\\\", \\\"{x:1306,y:898,t:1527019872549};\\\", \\\"{x:1306,y:903,t:1527019872566};\\\", \\\"{x:1308,y:909,t:1527019872582};\\\", \\\"{x:1308,y:913,t:1527019872599};\\\", \\\"{x:1310,y:918,t:1527019872615};\\\", \\\"{x:1310,y:920,t:1527019872632};\\\", \\\"{x:1310,y:921,t:1527019872649};\\\", \\\"{x:1310,y:922,t:1527019872666};\\\", \\\"{x:1310,y:925,t:1527019872682};\\\", \\\"{x:1310,y:930,t:1527019872698};\\\", \\\"{x:1310,y:935,t:1527019872716};\\\", \\\"{x:1310,y:939,t:1527019872734};\\\", \\\"{x:1310,y:942,t:1527019872748};\\\", \\\"{x:1310,y:943,t:1527019872766};\\\", \\\"{x:1310,y:945,t:1527019872783};\\\", \\\"{x:1310,y:946,t:1527019872802};\\\", \\\"{x:1310,y:947,t:1527019872815};\\\", \\\"{x:1310,y:948,t:1527019872833};\\\", \\\"{x:1310,y:950,t:1527019872849};\\\", \\\"{x:1310,y:951,t:1527019872866};\\\", \\\"{x:1310,y:952,t:1527019873651};\\\", \\\"{x:1309,y:952,t:1527019873667};\\\", \\\"{x:1307,y:953,t:1527019873691};\\\", \\\"{x:1306,y:953,t:1527019873699};\\\", \\\"{x:1302,y:953,t:1527019873716};\\\", \\\"{x:1296,y:953,t:1527019873733};\\\", \\\"{x:1287,y:953,t:1527019873750};\\\", \\\"{x:1279,y:953,t:1527019873766};\\\", \\\"{x:1270,y:953,t:1527019873783};\\\", \\\"{x:1261,y:953,t:1527019873800};\\\", \\\"{x:1252,y:953,t:1527019873817};\\\", \\\"{x:1241,y:953,t:1527019873833};\\\", \\\"{x:1233,y:953,t:1527019873850};\\\", \\\"{x:1224,y:953,t:1527019873867};\\\", \\\"{x:1221,y:953,t:1527019873883};\\\", \\\"{x:1217,y:953,t:1527019873900};\\\", \\\"{x:1215,y:953,t:1527019873917};\\\", \\\"{x:1211,y:953,t:1527019873933};\\\", \\\"{x:1209,y:953,t:1527019873950};\\\", \\\"{x:1207,y:953,t:1527019873967};\\\", \\\"{x:1203,y:953,t:1527019873983};\\\", \\\"{x:1199,y:953,t:1527019874000};\\\", \\\"{x:1194,y:953,t:1527019874016};\\\", \\\"{x:1190,y:953,t:1527019874034};\\\", \\\"{x:1188,y:953,t:1527019874049};\\\", \\\"{x:1184,y:953,t:1527019874067};\\\", \\\"{x:1181,y:953,t:1527019874082};\\\", \\\"{x:1175,y:953,t:1527019874100};\\\", \\\"{x:1167,y:953,t:1527019874116};\\\", \\\"{x:1154,y:953,t:1527019874133};\\\", \\\"{x:1137,y:950,t:1527019874149};\\\", \\\"{x:1120,y:946,t:1527019874166};\\\", \\\"{x:1105,y:944,t:1527019874183};\\\", \\\"{x:1089,y:939,t:1527019874199};\\\", \\\"{x:1073,y:933,t:1527019874217};\\\", \\\"{x:1063,y:930,t:1527019874233};\\\", \\\"{x:1057,y:929,t:1527019874250};\\\", \\\"{x:1056,y:929,t:1527019874266};\\\", \\\"{x:1056,y:928,t:1527019874370};\\\", \\\"{x:1056,y:927,t:1527019874387};\\\", \\\"{x:1056,y:926,t:1527019874400};\\\", \\\"{x:1058,y:919,t:1527019874416};\\\", \\\"{x:1066,y:909,t:1527019874434};\\\", \\\"{x:1086,y:884,t:1527019874450};\\\", \\\"{x:1100,y:865,t:1527019874467};\\\", \\\"{x:1123,y:838,t:1527019874483};\\\", \\\"{x:1161,y:806,t:1527019874500};\\\", \\\"{x:1183,y:783,t:1527019874517};\\\", \\\"{x:1198,y:763,t:1527019874534};\\\", \\\"{x:1210,y:742,t:1527019874550};\\\", \\\"{x:1226,y:716,t:1527019874567};\\\", \\\"{x:1243,y:679,t:1527019874584};\\\", \\\"{x:1255,y:652,t:1527019874600};\\\", \\\"{x:1265,y:627,t:1527019874617};\\\", \\\"{x:1272,y:607,t:1527019874634};\\\", \\\"{x:1277,y:578,t:1527019874650};\\\", \\\"{x:1281,y:564,t:1527019874667};\\\", \\\"{x:1281,y:551,t:1527019874683};\\\", \\\"{x:1282,y:544,t:1527019874701};\\\", \\\"{x:1282,y:540,t:1527019874717};\\\", \\\"{x:1282,y:538,t:1527019874733};\\\", \\\"{x:1282,y:536,t:1527019874750};\\\", \\\"{x:1282,y:535,t:1527019874766};\\\", \\\"{x:1282,y:533,t:1527019874783};\\\", \\\"{x:1282,y:529,t:1527019874800};\\\", \\\"{x:1283,y:527,t:1527019874817};\\\", \\\"{x:1283,y:526,t:1527019874834};\\\", \\\"{x:1284,y:524,t:1527019874914};\\\", \\\"{x:1285,y:523,t:1527019874923};\\\", \\\"{x:1287,y:520,t:1527019874933};\\\", \\\"{x:1291,y:516,t:1527019874951};\\\", \\\"{x:1295,y:510,t:1527019874967};\\\", \\\"{x:1298,y:506,t:1527019874984};\\\", \\\"{x:1299,y:504,t:1527019875000};\\\", \\\"{x:1300,y:504,t:1527019875018};\\\", \\\"{x:1302,y:503,t:1527019875034};\\\", \\\"{x:1304,y:502,t:1527019875050};\\\", \\\"{x:1303,y:502,t:1527019878435};\\\", \\\"{x:1302,y:502,t:1527019880259};\\\", \\\"{x:1301,y:502,t:1527019880331};\\\", \\\"{x:1300,y:502,t:1527019880458};\\\", \\\"{x:1301,y:502,t:1527019883555};\\\", \\\"{x:1305,y:501,t:1527019883570};\\\", \\\"{x:1306,y:501,t:1527019883594};\\\", \\\"{x:1307,y:501,t:1527019883607};\\\", \\\"{x:1308,y:500,t:1527019883624};\\\", \\\"{x:1310,y:499,t:1527019883640};\\\", \\\"{x:1312,y:498,t:1527019883656};\\\", \\\"{x:1312,y:499,t:1527019884090};\\\", \\\"{x:1312,y:501,t:1527019884106};\\\", \\\"{x:1312,y:503,t:1527019884124};\\\", \\\"{x:1312,y:504,t:1527019884141};\\\", \\\"{x:1312,y:506,t:1527019884157};\\\", \\\"{x:1312,y:507,t:1527019884178};\\\", \\\"{x:1313,y:509,t:1527019884194};\\\", \\\"{x:1313,y:510,t:1527019884207};\\\", \\\"{x:1313,y:511,t:1527019884224};\\\", \\\"{x:1313,y:512,t:1527019884241};\\\", \\\"{x:1313,y:514,t:1527019884257};\\\", \\\"{x:1313,y:518,t:1527019884274};\\\", \\\"{x:1313,y:520,t:1527019884290};\\\", \\\"{x:1313,y:523,t:1527019884307};\\\", \\\"{x:1313,y:526,t:1527019884324};\\\", \\\"{x:1313,y:529,t:1527019884341};\\\", \\\"{x:1313,y:530,t:1527019884358};\\\", \\\"{x:1313,y:531,t:1527019884374};\\\", \\\"{x:1313,y:532,t:1527019884391};\\\", \\\"{x:1313,y:533,t:1527019884426};\\\", \\\"{x:1313,y:534,t:1527019884498};\\\", \\\"{x:1313,y:535,t:1527019884508};\\\", \\\"{x:1313,y:536,t:1527019884524};\\\", \\\"{x:1313,y:537,t:1527019884541};\\\", \\\"{x:1313,y:539,t:1527019884558};\\\", \\\"{x:1313,y:540,t:1527019884574};\\\", \\\"{x:1313,y:541,t:1527019884591};\\\", \\\"{x:1313,y:543,t:1527019884610};\\\", \\\"{x:1313,y:545,t:1527019884626};\\\", \\\"{x:1313,y:546,t:1527019884642};\\\", \\\"{x:1313,y:548,t:1527019884658};\\\", \\\"{x:1312,y:551,t:1527019884674};\\\", \\\"{x:1312,y:553,t:1527019884691};\\\", \\\"{x:1312,y:556,t:1527019884708};\\\", \\\"{x:1312,y:558,t:1527019884724};\\\", \\\"{x:1311,y:560,t:1527019884741};\\\", \\\"{x:1311,y:565,t:1527019884758};\\\", \\\"{x:1309,y:576,t:1527019884774};\\\", \\\"{x:1309,y:586,t:1527019884791};\\\", \\\"{x:1309,y:593,t:1527019884808};\\\", \\\"{x:1309,y:596,t:1527019884825};\\\", \\\"{x:1309,y:600,t:1527019884841};\\\", \\\"{x:1308,y:605,t:1527019884858};\\\", \\\"{x:1308,y:609,t:1527019884874};\\\", \\\"{x:1308,y:617,t:1527019884891};\\\", \\\"{x:1306,y:629,t:1527019884908};\\\", \\\"{x:1304,y:642,t:1527019884925};\\\", \\\"{x:1303,y:654,t:1527019884941};\\\", \\\"{x:1302,y:660,t:1527019884958};\\\", \\\"{x:1301,y:662,t:1527019884975};\\\", \\\"{x:1301,y:670,t:1527019884991};\\\", \\\"{x:1299,y:680,t:1527019885007};\\\", \\\"{x:1298,y:687,t:1527019885025};\\\", \\\"{x:1298,y:692,t:1527019885041};\\\", \\\"{x:1296,y:700,t:1527019885058};\\\", \\\"{x:1296,y:704,t:1527019885075};\\\", \\\"{x:1295,y:709,t:1527019885091};\\\", \\\"{x:1294,y:715,t:1527019885108};\\\", \\\"{x:1294,y:722,t:1527019885125};\\\", \\\"{x:1294,y:730,t:1527019885141};\\\", \\\"{x:1294,y:738,t:1527019885158};\\\", \\\"{x:1294,y:744,t:1527019885175};\\\", \\\"{x:1294,y:746,t:1527019885191};\\\", \\\"{x:1294,y:748,t:1527019885207};\\\", \\\"{x:1294,y:749,t:1527019885224};\\\", \\\"{x:1294,y:752,t:1527019885241};\\\", \\\"{x:1293,y:764,t:1527019885258};\\\", \\\"{x:1293,y:779,t:1527019885274};\\\", \\\"{x:1293,y:791,t:1527019885291};\\\", \\\"{x:1293,y:801,t:1527019885308};\\\", \\\"{x:1293,y:808,t:1527019885325};\\\", \\\"{x:1293,y:815,t:1527019885342};\\\", \\\"{x:1293,y:822,t:1527019885357};\\\", \\\"{x:1293,y:830,t:1527019885375};\\\", \\\"{x:1293,y:841,t:1527019885393};\\\", \\\"{x:1293,y:858,t:1527019885408};\\\", \\\"{x:1293,y:870,t:1527019885425};\\\", \\\"{x:1293,y:888,t:1527019885442};\\\", \\\"{x:1293,y:898,t:1527019885458};\\\", \\\"{x:1293,y:903,t:1527019885475};\\\", \\\"{x:1293,y:908,t:1527019885492};\\\", \\\"{x:1293,y:913,t:1527019885508};\\\", \\\"{x:1293,y:916,t:1527019885524};\\\", \\\"{x:1293,y:921,t:1527019885542};\\\", \\\"{x:1293,y:924,t:1527019885558};\\\", \\\"{x:1293,y:928,t:1527019885574};\\\", \\\"{x:1293,y:934,t:1527019885592};\\\", \\\"{x:1293,y:937,t:1527019885607};\\\", \\\"{x:1293,y:941,t:1527019885625};\\\", \\\"{x:1293,y:942,t:1527019885642};\\\", \\\"{x:1293,y:944,t:1527019885666};\\\", \\\"{x:1293,y:945,t:1527019885690};\\\", \\\"{x:1293,y:947,t:1527019885706};\\\", \\\"{x:1293,y:948,t:1527019885722};\\\", \\\"{x:1294,y:949,t:1527019885730};\\\", \\\"{x:1294,y:950,t:1527019885742};\\\", \\\"{x:1296,y:953,t:1527019885759};\\\", \\\"{x:1300,y:959,t:1527019885775};\\\", \\\"{x:1302,y:961,t:1527019885791};\\\", \\\"{x:1305,y:964,t:1527019885809};\\\", \\\"{x:1307,y:965,t:1527019885825};\\\", \\\"{x:1313,y:970,t:1527019885842};\\\", \\\"{x:1317,y:973,t:1527019885858};\\\", \\\"{x:1321,y:975,t:1527019885875};\\\", \\\"{x:1323,y:977,t:1527019885892};\\\", \\\"{x:1324,y:977,t:1527019885908};\\\", \\\"{x:1326,y:977,t:1527019885925};\\\", \\\"{x:1329,y:975,t:1527019887010};\\\", \\\"{x:1335,y:962,t:1527019887025};\\\", \\\"{x:1335,y:961,t:1527019887049};\\\", \\\"{x:1337,y:961,t:1527019887571};\\\", \\\"{x:1338,y:962,t:1527019887866};\\\", \\\"{x:1344,y:961,t:1527019887898};\\\", \\\"{x:1351,y:957,t:1527019887910};\\\", \\\"{x:1366,y:948,t:1527019887927};\\\", \\\"{x:1372,y:945,t:1527019887943};\\\", \\\"{x:1373,y:944,t:1527019887960};\\\", \\\"{x:1371,y:944,t:1527019888041};\\\", \\\"{x:1366,y:944,t:1527019888049};\\\", \\\"{x:1362,y:944,t:1527019888060};\\\", \\\"{x:1355,y:944,t:1527019888076};\\\", \\\"{x:1354,y:944,t:1527019888154};\\\", \\\"{x:1352,y:944,t:1527019888170};\\\", \\\"{x:1348,y:943,t:1527019888177};\\\", \\\"{x:1344,y:936,t:1527019888193};\\\", \\\"{x:1338,y:929,t:1527019888210};\\\", \\\"{x:1335,y:919,t:1527019888227};\\\", \\\"{x:1335,y:911,t:1527019888243};\\\", \\\"{x:1333,y:906,t:1527019888260};\\\", \\\"{x:1333,y:905,t:1527019888289};\\\", \\\"{x:1332,y:900,t:1527019888546};\\\", \\\"{x:1336,y:885,t:1527019888560};\\\", \\\"{x:1345,y:837,t:1527019888577};\\\", \\\"{x:1346,y:803,t:1527019888593};\\\", \\\"{x:1346,y:782,t:1527019888610};\\\", \\\"{x:1346,y:762,t:1527019888627};\\\", \\\"{x:1346,y:744,t:1527019888644};\\\", \\\"{x:1346,y:724,t:1527019888661};\\\", \\\"{x:1343,y:704,t:1527019888677};\\\", \\\"{x:1338,y:688,t:1527019888694};\\\", \\\"{x:1332,y:674,t:1527019888711};\\\", \\\"{x:1328,y:665,t:1527019888727};\\\", \\\"{x:1326,y:656,t:1527019888744};\\\", \\\"{x:1322,y:646,t:1527019888761};\\\", \\\"{x:1319,y:637,t:1527019888778};\\\", \\\"{x:1317,y:625,t:1527019888794};\\\", \\\"{x:1314,y:617,t:1527019888810};\\\", \\\"{x:1313,y:611,t:1527019888827};\\\", \\\"{x:1313,y:609,t:1527019888844};\\\", \\\"{x:1311,y:604,t:1527019888861};\\\", \\\"{x:1311,y:602,t:1527019888877};\\\", \\\"{x:1310,y:601,t:1527019888894};\\\", \\\"{x:1310,y:600,t:1527019888911};\\\", \\\"{x:1310,y:599,t:1527019888927};\\\", \\\"{x:1309,y:600,t:1527019889162};\\\", \\\"{x:1307,y:606,t:1527019889178};\\\", \\\"{x:1305,y:614,t:1527019889194};\\\", \\\"{x:1305,y:621,t:1527019889211};\\\", \\\"{x:1305,y:631,t:1527019889228};\\\", \\\"{x:1303,y:641,t:1527019889244};\\\", \\\"{x:1303,y:651,t:1527019889261};\\\", \\\"{x:1303,y:658,t:1527019889278};\\\", \\\"{x:1303,y:666,t:1527019889294};\\\", \\\"{x:1303,y:675,t:1527019889311};\\\", \\\"{x:1305,y:684,t:1527019889328};\\\", \\\"{x:1307,y:693,t:1527019889344};\\\", \\\"{x:1310,y:703,t:1527019889361};\\\", \\\"{x:1315,y:721,t:1527019889377};\\\", \\\"{x:1318,y:731,t:1527019889394};\\\", \\\"{x:1321,y:740,t:1527019889411};\\\", \\\"{x:1323,y:748,t:1527019889428};\\\", \\\"{x:1325,y:753,t:1527019889444};\\\", \\\"{x:1326,y:758,t:1527019889461};\\\", \\\"{x:1328,y:764,t:1527019889478};\\\", \\\"{x:1329,y:768,t:1527019889494};\\\", \\\"{x:1331,y:774,t:1527019889511};\\\", \\\"{x:1332,y:781,t:1527019889528};\\\", \\\"{x:1334,y:788,t:1527019889546};\\\", \\\"{x:1335,y:793,t:1527019889561};\\\", \\\"{x:1335,y:809,t:1527019889578};\\\", \\\"{x:1335,y:824,t:1527019889595};\\\", \\\"{x:1335,y:837,t:1527019889611};\\\", \\\"{x:1335,y:849,t:1527019889628};\\\", \\\"{x:1335,y:860,t:1527019889645};\\\", \\\"{x:1335,y:871,t:1527019889661};\\\", \\\"{x:1335,y:881,t:1527019889678};\\\", \\\"{x:1335,y:893,t:1527019889696};\\\", \\\"{x:1335,y:904,t:1527019889711};\\\", \\\"{x:1335,y:913,t:1527019889728};\\\", \\\"{x:1332,y:921,t:1527019889746};\\\", \\\"{x:1329,y:930,t:1527019889761};\\\", \\\"{x:1328,y:939,t:1527019889778};\\\", \\\"{x:1328,y:942,t:1527019889795};\\\", \\\"{x:1325,y:949,t:1527019889811};\\\", \\\"{x:1323,y:953,t:1527019889828};\\\", \\\"{x:1323,y:956,t:1527019889845};\\\", \\\"{x:1323,y:960,t:1527019889861};\\\", \\\"{x:1322,y:960,t:1527019889882};\\\", \\\"{x:1321,y:960,t:1527019889895};\\\", \\\"{x:1320,y:960,t:1527019889979};\\\", \\\"{x:1319,y:960,t:1527019890514};\\\", \\\"{x:1318,y:961,t:1527019890530};\\\", \\\"{x:1317,y:964,t:1527019890545};\\\", \\\"{x:1315,y:964,t:1527019890562};\\\", \\\"{x:1314,y:965,t:1527019890579};\\\", \\\"{x:1314,y:966,t:1527019890625};\\\", \\\"{x:1314,y:967,t:1527019890650};\\\", \\\"{x:1314,y:968,t:1527019890673};\\\", \\\"{x:1314,y:969,t:1527019890690};\\\", \\\"{x:1314,y:970,t:1527019891282};\\\", \\\"{x:1318,y:970,t:1527019891296};\\\", \\\"{x:1329,y:961,t:1527019891313};\\\", \\\"{x:1345,y:941,t:1527019891329};\\\", \\\"{x:1366,y:907,t:1527019891346};\\\", \\\"{x:1375,y:885,t:1527019891362};\\\", \\\"{x:1383,y:864,t:1527019891379};\\\", \\\"{x:1387,y:850,t:1527019891396};\\\", \\\"{x:1389,y:841,t:1527019891414};\\\", \\\"{x:1391,y:837,t:1527019891429};\\\", \\\"{x:1393,y:833,t:1527019891447};\\\", \\\"{x:1394,y:832,t:1527019891462};\\\", \\\"{x:1396,y:829,t:1527019891480};\\\", \\\"{x:1397,y:827,t:1527019891496};\\\", \\\"{x:1398,y:827,t:1527019891513};\\\", \\\"{x:1398,y:826,t:1527019891554};\\\", \\\"{x:1399,y:826,t:1527019891602};\\\", \\\"{x:1402,y:826,t:1527019891626};\\\", \\\"{x:1404,y:826,t:1527019891634};\\\", \\\"{x:1412,y:829,t:1527019891646};\\\", \\\"{x:1429,y:838,t:1527019891663};\\\", \\\"{x:1447,y:845,t:1527019891679};\\\", \\\"{x:1468,y:853,t:1527019891696};\\\", \\\"{x:1488,y:859,t:1527019891713};\\\", \\\"{x:1505,y:864,t:1527019891729};\\\", \\\"{x:1525,y:871,t:1527019891746};\\\", \\\"{x:1531,y:874,t:1527019891763};\\\", \\\"{x:1539,y:878,t:1527019891778};\\\", \\\"{x:1544,y:881,t:1527019891796};\\\", \\\"{x:1551,y:885,t:1527019891813};\\\", \\\"{x:1556,y:888,t:1527019891828};\\\", \\\"{x:1563,y:892,t:1527019891845};\\\", \\\"{x:1569,y:895,t:1527019891862};\\\", \\\"{x:1576,y:900,t:1527019891880};\\\", \\\"{x:1579,y:903,t:1527019891896};\\\", \\\"{x:1583,y:908,t:1527019891913};\\\", \\\"{x:1588,y:918,t:1527019891929};\\\", \\\"{x:1590,y:926,t:1527019891946};\\\", \\\"{x:1592,y:932,t:1527019891962};\\\", \\\"{x:1592,y:941,t:1527019891980};\\\", \\\"{x:1592,y:949,t:1527019891995};\\\", \\\"{x:1592,y:955,t:1527019892013};\\\", \\\"{x:1591,y:963,t:1527019892030};\\\", \\\"{x:1588,y:969,t:1527019892046};\\\", \\\"{x:1582,y:977,t:1527019892063};\\\", \\\"{x:1579,y:980,t:1527019892080};\\\", \\\"{x:1575,y:983,t:1527019892096};\\\", \\\"{x:1567,y:986,t:1527019892113};\\\", \\\"{x:1559,y:989,t:1527019892130};\\\", \\\"{x:1555,y:990,t:1527019892146};\\\", \\\"{x:1551,y:991,t:1527019892163};\\\", \\\"{x:1548,y:991,t:1527019892179};\\\", \\\"{x:1544,y:992,t:1527019892195};\\\", \\\"{x:1540,y:993,t:1527019892212};\\\", \\\"{x:1537,y:993,t:1527019892229};\\\", \\\"{x:1534,y:993,t:1527019892246};\\\", \\\"{x:1533,y:993,t:1527019892265};\\\", \\\"{x:1532,y:993,t:1527019892369};\\\", \\\"{x:1531,y:992,t:1527019892409};\\\", \\\"{x:1531,y:991,t:1527019892457};\\\", \\\"{x:1531,y:990,t:1527019892465};\\\", \\\"{x:1530,y:989,t:1527019892488};\\\", \\\"{x:1530,y:988,t:1527019892497};\\\", \\\"{x:1530,y:987,t:1527019892512};\\\", \\\"{x:1528,y:984,t:1527019892529};\\\", \\\"{x:1528,y:983,t:1527019892546};\\\", \\\"{x:1528,y:982,t:1527019892562};\\\", \\\"{x:1528,y:980,t:1527019892579};\\\", \\\"{x:1527,y:977,t:1527019892597};\\\", \\\"{x:1525,y:975,t:1527019892613};\\\", \\\"{x:1525,y:973,t:1527019892630};\\\", \\\"{x:1524,y:969,t:1527019892647};\\\", \\\"{x:1522,y:965,t:1527019892662};\\\", \\\"{x:1521,y:963,t:1527019892680};\\\", \\\"{x:1520,y:959,t:1527019892697};\\\", \\\"{x:1516,y:955,t:1527019892712};\\\", \\\"{x:1511,y:948,t:1527019892729};\\\", \\\"{x:1509,y:946,t:1527019892747};\\\", \\\"{x:1507,y:943,t:1527019892763};\\\", \\\"{x:1505,y:941,t:1527019892780};\\\", \\\"{x:1502,y:938,t:1527019892797};\\\", \\\"{x:1502,y:937,t:1527019892814};\\\", \\\"{x:1500,y:934,t:1527019892830};\\\", \\\"{x:1498,y:933,t:1527019892847};\\\", \\\"{x:1497,y:933,t:1527019892864};\\\", \\\"{x:1497,y:931,t:1527019892881};\\\", \\\"{x:1496,y:931,t:1527019892898};\\\", \\\"{x:1495,y:929,t:1527019892913};\\\", \\\"{x:1495,y:928,t:1527019892930};\\\", \\\"{x:1494,y:927,t:1527019892947};\\\", \\\"{x:1492,y:925,t:1527019892964};\\\", \\\"{x:1491,y:924,t:1527019892980};\\\", \\\"{x:1490,y:922,t:1527019893002};\\\", \\\"{x:1488,y:919,t:1527019896707};\\\", \\\"{x:1485,y:916,t:1527019896717};\\\", \\\"{x:1482,y:914,t:1527019896735};\\\", \\\"{x:1481,y:913,t:1527019896749};\\\", \\\"{x:1479,y:912,t:1527019896793};\\\", \\\"{x:1470,y:905,t:1527019903746};\\\", \\\"{x:1451,y:891,t:1527019903755};\\\", \\\"{x:1410,y:867,t:1527019903772};\\\", \\\"{x:1373,y:848,t:1527019903788};\\\", \\\"{x:1326,y:830,t:1527019903806};\\\", \\\"{x:1274,y:807,t:1527019903822};\\\", \\\"{x:1239,y:795,t:1527019903838};\\\", \\\"{x:1213,y:787,t:1527019903856};\\\", \\\"{x:1191,y:778,t:1527019903871};\\\", \\\"{x:1171,y:772,t:1527019903888};\\\", \\\"{x:1152,y:765,t:1527019903906};\\\", \\\"{x:1143,y:760,t:1527019903921};\\\", \\\"{x:1123,y:752,t:1527019903939};\\\", \\\"{x:1094,y:747,t:1527019903955};\\\", \\\"{x:1043,y:739,t:1527019903972};\\\", \\\"{x:984,y:731,t:1527019903988};\\\", \\\"{x:915,y:722,t:1527019904006};\\\", \\\"{x:840,y:713,t:1527019904021};\\\", \\\"{x:783,y:710,t:1527019904039};\\\", \\\"{x:731,y:704,t:1527019904055};\\\", \\\"{x:689,y:704,t:1527019904072};\\\", \\\"{x:656,y:701,t:1527019904088};\\\", \\\"{x:614,y:699,t:1527019904105};\\\", \\\"{x:588,y:697,t:1527019904121};\\\", \\\"{x:558,y:694,t:1527019904138};\\\", \\\"{x:535,y:692,t:1527019904155};\\\", \\\"{x:518,y:688,t:1527019904172};\\\", \\\"{x:505,y:685,t:1527019904188};\\\", \\\"{x:493,y:681,t:1527019904204};\\\", \\\"{x:484,y:676,t:1527019904222};\\\", \\\"{x:478,y:670,t:1527019904237};\\\", \\\"{x:476,y:668,t:1527019904255};\\\", \\\"{x:475,y:667,t:1527019904272};\\\", \\\"{x:474,y:667,t:1527019904287};\\\", \\\"{x:472,y:665,t:1527019904522};\\\", \\\"{x:467,y:654,t:1527019904539};\\\", \\\"{x:461,y:639,t:1527019904555};\\\", \\\"{x:457,y:628,t:1527019904572};\\\", \\\"{x:450,y:606,t:1527019904595};\\\", \\\"{x:444,y:594,t:1527019904613};\\\", \\\"{x:439,y:581,t:1527019904629};\\\", \\\"{x:431,y:566,t:1527019904650};\\\", \\\"{x:425,y:557,t:1527019904667};\\\", \\\"{x:417,y:546,t:1527019904684};\\\", \\\"{x:412,y:540,t:1527019904701};\\\", \\\"{x:410,y:537,t:1527019904717};\\\", \\\"{x:408,y:534,t:1527019904733};\\\", \\\"{x:405,y:530,t:1527019904750};\\\", \\\"{x:404,y:527,t:1527019904766};\\\", \\\"{x:402,y:523,t:1527019904784};\\\", \\\"{x:401,y:523,t:1527019904800};\\\", \\\"{x:400,y:521,t:1527019904818};\\\", \\\"{x:399,y:521,t:1527019904890};\\\", \\\"{x:398,y:524,t:1527019904902};\\\", \\\"{x:393,y:535,t:1527019904917};\\\", \\\"{x:387,y:549,t:1527019904934};\\\", \\\"{x:382,y:559,t:1527019904951};\\\", \\\"{x:377,y:565,t:1527019904967};\\\", \\\"{x:375,y:568,t:1527019904983};\\\", \\\"{x:374,y:570,t:1527019905001};\\\", \\\"{x:374,y:571,t:1527019905018};\\\", \\\"{x:372,y:573,t:1527019905033};\\\", \\\"{x:371,y:576,t:1527019905051};\\\", \\\"{x:371,y:577,t:1527019905068};\\\", \\\"{x:371,y:577,t:1527019905212};\\\", \\\"{x:371,y:575,t:1527019905329};\\\", \\\"{x:371,y:575,t:1527019905331};\\\", \\\"{x:372,y:572,t:1527019905336};\\\", \\\"{x:374,y:565,t:1527019905351};\\\", \\\"{x:379,y:552,t:1527019905368};\\\", \\\"{x:382,y:540,t:1527019905384};\\\", \\\"{x:386,y:530,t:1527019905401};\\\", \\\"{x:386,y:527,t:1527019905418};\\\", \\\"{x:383,y:527,t:1527019905832};\\\", \\\"{x:380,y:528,t:1527019905841};\\\", \\\"{x:376,y:531,t:1527019905852};\\\", \\\"{x:370,y:540,t:1527019905868};\\\", \\\"{x:367,y:546,t:1527019905884};\\\", \\\"{x:365,y:554,t:1527019905901};\\\", \\\"{x:365,y:560,t:1527019905918};\\\", \\\"{x:365,y:562,t:1527019905935};\\\", \\\"{x:365,y:565,t:1527019905951};\\\", \\\"{x:365,y:569,t:1527019905968};\\\", \\\"{x:365,y:573,t:1527019905985};\\\", \\\"{x:365,y:575,t:1527019906002};\\\", \\\"{x:365,y:577,t:1527019906018};\\\", \\\"{x:365,y:581,t:1527019906218};\\\", \\\"{x:365,y:586,t:1527019906236};\\\", \\\"{x:369,y:596,t:1527019906253};\\\", \\\"{x:372,y:602,t:1527019906268};\\\", \\\"{x:377,y:611,t:1527019906285};\\\", \\\"{x:389,y:625,t:1527019906302};\\\", \\\"{x:402,y:640,t:1527019906319};\\\", \\\"{x:416,y:652,t:1527019906335};\\\", \\\"{x:427,y:658,t:1527019906352};\\\", \\\"{x:430,y:660,t:1527019906368};\\\", \\\"{x:430,y:657,t:1527019906425};\\\", \\\"{x:430,y:648,t:1527019906435};\\\", \\\"{x:427,y:629,t:1527019906453};\\\", \\\"{x:417,y:613,t:1527019906470};\\\", \\\"{x:409,y:601,t:1527019906485};\\\", \\\"{x:405,y:595,t:1527019906503};\\\", \\\"{x:400,y:592,t:1527019906519};\\\", \\\"{x:396,y:588,t:1527019906535};\\\", \\\"{x:393,y:585,t:1527019906552};\\\", \\\"{x:392,y:584,t:1527019906570};\\\", \\\"{x:391,y:583,t:1527019906585};\\\", \\\"{x:390,y:582,t:1527019906602};\\\", \\\"{x:391,y:591,t:1527019906873};\\\", \\\"{x:398,y:609,t:1527019906886};\\\", \\\"{x:414,y:640,t:1527019906902};\\\", \\\"{x:429,y:666,t:1527019906919};\\\", \\\"{x:443,y:686,t:1527019906936};\\\", \\\"{x:459,y:706,t:1527019906952};\\\", \\\"{x:481,y:729,t:1527019906969};\\\", \\\"{x:493,y:741,t:1527019906986};\\\", \\\"{x:499,y:745,t:1527019907002};\\\", \\\"{x:501,y:746,t:1527019907019};\\\", \\\"{x:502,y:747,t:1527019907036};\\\", \\\"{x:502,y:748,t:1527019907065};\\\", \\\"{x:501,y:748,t:1527019907306};\\\", \\\"{x:501,y:747,t:1527019907319};\\\", \\\"{x:501,y:745,t:1527019907336};\\\" ] }, { \\\"rt\\\": 6482, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 538569, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:744,t:1527019909538};\\\", \\\"{x:504,y:738,t:1527019911138};\\\", \\\"{x:521,y:717,t:1527019911154};\\\", \\\"{x:543,y:692,t:1527019911170};\\\", \\\"{x:590,y:663,t:1527019911186};\\\", \\\"{x:636,y:638,t:1527019911206};\\\", \\\"{x:681,y:616,t:1527019911222};\\\", \\\"{x:722,y:599,t:1527019911240};\\\", \\\"{x:764,y:579,t:1527019911257};\\\", \\\"{x:803,y:569,t:1527019911272};\\\", \\\"{x:847,y:558,t:1527019911289};\\\", \\\"{x:865,y:556,t:1527019911306};\\\", \\\"{x:877,y:554,t:1527019911323};\\\", \\\"{x:884,y:552,t:1527019911339};\\\", \\\"{x:887,y:552,t:1527019911355};\\\", \\\"{x:885,y:552,t:1527019911530};\\\", \\\"{x:879,y:553,t:1527019911540};\\\", \\\"{x:864,y:559,t:1527019911558};\\\", \\\"{x:843,y:566,t:1527019911573};\\\", \\\"{x:809,y:573,t:1527019911590};\\\", \\\"{x:760,y:584,t:1527019911605};\\\", \\\"{x:704,y:592,t:1527019911622};\\\", \\\"{x:642,y:595,t:1527019911639};\\\", \\\"{x:564,y:595,t:1527019911656};\\\", \\\"{x:475,y:595,t:1527019911673};\\\", \\\"{x:440,y:595,t:1527019911689};\\\", \\\"{x:419,y:595,t:1527019911706};\\\", \\\"{x:411,y:595,t:1527019911723};\\\", \\\"{x:410,y:595,t:1527019911777};\\\", \\\"{x:410,y:592,t:1527019911791};\\\", \\\"{x:414,y:584,t:1527019911808};\\\", \\\"{x:420,y:575,t:1527019911822};\\\", \\\"{x:425,y:567,t:1527019911839};\\\", \\\"{x:433,y:556,t:1527019911857};\\\", \\\"{x:450,y:545,t:1527019911874};\\\", \\\"{x:463,y:538,t:1527019911889};\\\", \\\"{x:474,y:533,t:1527019911906};\\\", \\\"{x:489,y:526,t:1527019911923};\\\", \\\"{x:501,y:519,t:1527019911940};\\\", \\\"{x:506,y:516,t:1527019911956};\\\", \\\"{x:509,y:514,t:1527019911973};\\\", \\\"{x:512,y:512,t:1527019911989};\\\", \\\"{x:515,y:510,t:1527019912006};\\\", \\\"{x:521,y:507,t:1527019912023};\\\", \\\"{x:530,y:504,t:1527019912039};\\\", \\\"{x:538,y:500,t:1527019912056};\\\", \\\"{x:546,y:496,t:1527019912072};\\\", \\\"{x:559,y:492,t:1527019912089};\\\", \\\"{x:569,y:488,t:1527019912106};\\\", \\\"{x:576,y:488,t:1527019912123};\\\", \\\"{x:580,y:487,t:1527019912139};\\\", \\\"{x:581,y:487,t:1527019912156};\\\", \\\"{x:584,y:486,t:1527019912174};\\\", \\\"{x:592,y:486,t:1527019912190};\\\", \\\"{x:607,y:486,t:1527019912206};\\\", \\\"{x:626,y:486,t:1527019912223};\\\", \\\"{x:641,y:486,t:1527019912240};\\\", \\\"{x:652,y:486,t:1527019912256};\\\", \\\"{x:659,y:486,t:1527019912273};\\\", \\\"{x:657,y:486,t:1527019912713};\\\", \\\"{x:655,y:487,t:1527019912724};\\\", \\\"{x:651,y:489,t:1527019912740};\\\", \\\"{x:646,y:491,t:1527019912757};\\\", \\\"{x:644,y:492,t:1527019912773};\\\", \\\"{x:643,y:492,t:1527019912825};\\\", \\\"{x:641,y:493,t:1527019912841};\\\", \\\"{x:646,y:493,t:1527019913001};\\\", \\\"{x:653,y:491,t:1527019913008};\\\", \\\"{x:659,y:489,t:1527019913024};\\\", \\\"{x:671,y:488,t:1527019913040};\\\", \\\"{x:689,y:491,t:1527019913057};\\\", \\\"{x:703,y:498,t:1527019913074};\\\", \\\"{x:716,y:506,t:1527019913090};\\\", \\\"{x:728,y:511,t:1527019913108};\\\", \\\"{x:740,y:514,t:1527019913124};\\\", \\\"{x:757,y:519,t:1527019913141};\\\", \\\"{x:774,y:522,t:1527019913157};\\\", \\\"{x:789,y:524,t:1527019913174};\\\", \\\"{x:803,y:526,t:1527019913190};\\\", \\\"{x:815,y:530,t:1527019913207};\\\", \\\"{x:823,y:533,t:1527019913224};\\\", \\\"{x:831,y:535,t:1527019913241};\\\", \\\"{x:836,y:537,t:1527019913257};\\\", \\\"{x:838,y:537,t:1527019913274};\\\", \\\"{x:839,y:537,t:1527019913313};\\\", \\\"{x:836,y:543,t:1527019913624};\\\", \\\"{x:820,y:564,t:1527019913641};\\\", \\\"{x:786,y:603,t:1527019913659};\\\", \\\"{x:729,y:643,t:1527019913675};\\\", \\\"{x:664,y:681,t:1527019913691};\\\", \\\"{x:603,y:707,t:1527019913707};\\\", \\\"{x:558,y:722,t:1527019913725};\\\", \\\"{x:524,y:731,t:1527019913742};\\\", \\\"{x:499,y:737,t:1527019913758};\\\", \\\"{x:483,y:740,t:1527019913774};\\\", \\\"{x:477,y:743,t:1527019913791};\\\", \\\"{x:476,y:744,t:1527019913809};\\\", \\\"{x:475,y:744,t:1527019913825};\\\", \\\"{x:475,y:745,t:1527019914041};\\\" ] }, { \\\"rt\\\": 26785, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 566577, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -10 AM-B -B -F -F -F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:476,y:745,t:1527019919982};\\\", \\\"{x:538,y:725,t:1527019920000};\\\", \\\"{x:595,y:715,t:1527019920004};\\\", \\\"{x:646,y:709,t:1527019920018};\\\", \\\"{x:760,y:693,t:1527019920034};\\\", \\\"{x:868,y:688,t:1527019920050};\\\", \\\"{x:985,y:674,t:1527019920067};\\\", \\\"{x:1087,y:662,t:1527019920083};\\\", \\\"{x:1219,y:644,t:1527019920100};\\\", \\\"{x:1285,y:635,t:1527019920117};\\\", \\\"{x:1327,y:629,t:1527019920133};\\\", \\\"{x:1342,y:627,t:1527019920151};\\\", \\\"{x:1356,y:621,t:1527019920166};\\\", \\\"{x:1368,y:616,t:1527019920184};\\\", \\\"{x:1372,y:614,t:1527019920200};\\\", \\\"{x:1394,y:603,t:1527019920217};\\\", \\\"{x:1423,y:589,t:1527019920234};\\\", \\\"{x:1440,y:579,t:1527019920251};\\\", \\\"{x:1443,y:578,t:1527019920267};\\\", \\\"{x:1444,y:578,t:1527019920284};\\\", \\\"{x:1444,y:579,t:1527019920382};\\\", \\\"{x:1444,y:581,t:1527019920389};\\\", \\\"{x:1443,y:587,t:1527019920401};\\\", \\\"{x:1441,y:593,t:1527019920417};\\\", \\\"{x:1441,y:600,t:1527019920433};\\\", \\\"{x:1441,y:605,t:1527019920451};\\\", \\\"{x:1441,y:611,t:1527019920468};\\\", \\\"{x:1441,y:618,t:1527019920483};\\\", \\\"{x:1441,y:629,t:1527019920501};\\\", \\\"{x:1444,y:634,t:1527019920519};\\\", \\\"{x:1445,y:641,t:1527019920535};\\\", \\\"{x:1446,y:643,t:1527019920551};\\\", \\\"{x:1447,y:645,t:1527019920568};\\\", \\\"{x:1447,y:647,t:1527019920583};\\\", \\\"{x:1449,y:650,t:1527019920601};\\\", \\\"{x:1452,y:655,t:1527019920618};\\\", \\\"{x:1452,y:659,t:1527019920634};\\\", \\\"{x:1454,y:663,t:1527019920651};\\\", \\\"{x:1456,y:665,t:1527019920668};\\\", \\\"{x:1460,y:665,t:1527019920684};\\\", \\\"{x:1467,y:661,t:1527019920701};\\\", \\\"{x:1467,y:660,t:1527019920718};\\\", \\\"{x:1465,y:660,t:1527019921134};\\\", \\\"{x:1461,y:663,t:1527019921151};\\\", \\\"{x:1452,y:669,t:1527019921168};\\\", \\\"{x:1445,y:674,t:1527019921185};\\\", \\\"{x:1438,y:678,t:1527019921201};\\\", \\\"{x:1427,y:684,t:1527019921218};\\\", \\\"{x:1415,y:689,t:1527019921235};\\\", \\\"{x:1407,y:692,t:1527019921251};\\\", \\\"{x:1400,y:695,t:1527019921268};\\\", \\\"{x:1392,y:698,t:1527019921285};\\\", \\\"{x:1388,y:699,t:1527019921301};\\\", \\\"{x:1386,y:701,t:1527019921318};\\\", \\\"{x:1385,y:701,t:1527019921336};\\\", \\\"{x:1384,y:701,t:1527019921351};\\\", \\\"{x:1382,y:702,t:1527019921368};\\\", \\\"{x:1380,y:702,t:1527019921385};\\\", \\\"{x:1377,y:703,t:1527019921401};\\\", \\\"{x:1375,y:704,t:1527019921418};\\\", \\\"{x:1373,y:705,t:1527019921436};\\\", \\\"{x:1372,y:705,t:1527019921453};\\\", \\\"{x:1371,y:705,t:1527019921469};\\\", \\\"{x:1370,y:706,t:1527019921501};\\\", \\\"{x:1369,y:706,t:1527019921518};\\\", \\\"{x:1368,y:706,t:1527019921535};\\\", \\\"{x:1363,y:708,t:1527019921552};\\\", \\\"{x:1360,y:708,t:1527019921569};\\\", \\\"{x:1354,y:708,t:1527019921585};\\\", \\\"{x:1349,y:708,t:1527019921603};\\\", \\\"{x:1345,y:708,t:1527019921619};\\\", \\\"{x:1341,y:708,t:1527019921635};\\\", \\\"{x:1339,y:708,t:1527019921652};\\\", \\\"{x:1336,y:708,t:1527019921668};\\\", \\\"{x:1335,y:708,t:1527019921685};\\\", \\\"{x:1334,y:708,t:1527019921702};\\\", \\\"{x:1332,y:708,t:1527019921718};\\\", \\\"{x:1331,y:708,t:1527019921735};\\\", \\\"{x:1330,y:708,t:1527019921757};\\\", \\\"{x:1329,y:708,t:1527019921782};\\\", \\\"{x:1328,y:708,t:1527019921917};\\\", \\\"{x:1327,y:708,t:1527019921966};\\\", \\\"{x:1326,y:708,t:1527019921981};\\\", \\\"{x:1326,y:709,t:1527019921989};\\\", \\\"{x:1327,y:709,t:1527019922134};\\\", \\\"{x:1331,y:707,t:1527019922141};\\\", \\\"{x:1333,y:706,t:1527019922152};\\\", \\\"{x:1337,y:704,t:1527019922170};\\\", \\\"{x:1338,y:703,t:1527019922197};\\\", \\\"{x:1339,y:703,t:1527019922213};\\\", \\\"{x:1340,y:703,t:1527019922373};\\\", \\\"{x:1339,y:705,t:1527019922385};\\\", \\\"{x:1337,y:711,t:1527019922402};\\\", \\\"{x:1334,y:716,t:1527019922419};\\\", \\\"{x:1332,y:721,t:1527019922437};\\\", \\\"{x:1330,y:727,t:1527019922452};\\\", \\\"{x:1327,y:741,t:1527019922469};\\\", \\\"{x:1323,y:755,t:1527019922486};\\\", \\\"{x:1321,y:762,t:1527019922502};\\\", \\\"{x:1318,y:771,t:1527019922519};\\\", \\\"{x:1316,y:780,t:1527019922536};\\\", \\\"{x:1314,y:788,t:1527019922553};\\\", \\\"{x:1309,y:797,t:1527019922570};\\\", \\\"{x:1298,y:817,t:1527019922586};\\\", \\\"{x:1285,y:836,t:1527019922602};\\\", \\\"{x:1279,y:847,t:1527019922619};\\\", \\\"{x:1271,y:861,t:1527019922636};\\\", \\\"{x:1265,y:869,t:1527019922653};\\\", \\\"{x:1261,y:875,t:1527019922669};\\\", \\\"{x:1258,y:881,t:1527019922686};\\\", \\\"{x:1255,y:886,t:1527019922702};\\\", \\\"{x:1251,y:893,t:1527019922719};\\\", \\\"{x:1248,y:901,t:1527019922736};\\\", \\\"{x:1243,y:909,t:1527019922753};\\\", \\\"{x:1240,y:915,t:1527019922769};\\\", \\\"{x:1238,y:919,t:1527019922786};\\\", \\\"{x:1236,y:923,t:1527019922802};\\\", \\\"{x:1234,y:927,t:1527019922819};\\\", \\\"{x:1231,y:933,t:1527019922836};\\\", \\\"{x:1228,y:939,t:1527019922853};\\\", \\\"{x:1225,y:943,t:1527019922869};\\\", \\\"{x:1224,y:946,t:1527019922887};\\\", \\\"{x:1222,y:948,t:1527019922903};\\\", \\\"{x:1222,y:951,t:1527019922920};\\\", \\\"{x:1219,y:955,t:1527019922936};\\\", \\\"{x:1215,y:960,t:1527019922953};\\\", \\\"{x:1213,y:963,t:1527019922969};\\\", \\\"{x:1210,y:966,t:1527019922986};\\\", \\\"{x:1208,y:969,t:1527019923004};\\\", \\\"{x:1208,y:970,t:1527019923019};\\\", \\\"{x:1207,y:970,t:1527019923037};\\\", \\\"{x:1205,y:972,t:1527019923053};\\\", \\\"{x:1204,y:975,t:1527019923069};\\\", \\\"{x:1202,y:977,t:1527019923087};\\\", \\\"{x:1200,y:979,t:1527019923103};\\\", \\\"{x:1199,y:980,t:1527019923120};\\\", \\\"{x:1197,y:981,t:1527019923136};\\\", \\\"{x:1196,y:982,t:1527019923153};\\\", \\\"{x:1194,y:981,t:1527019923479};\\\", \\\"{x:1193,y:978,t:1527019923486};\\\", \\\"{x:1192,y:974,t:1527019923503};\\\", \\\"{x:1190,y:969,t:1527019923520};\\\", \\\"{x:1188,y:965,t:1527019923536};\\\", \\\"{x:1188,y:963,t:1527019923554};\\\", \\\"{x:1186,y:960,t:1527019923570};\\\", \\\"{x:1184,y:956,t:1527019923586};\\\", \\\"{x:1180,y:951,t:1527019923603};\\\", \\\"{x:1179,y:947,t:1527019923620};\\\", \\\"{x:1176,y:942,t:1527019923636};\\\", \\\"{x:1171,y:930,t:1527019923654};\\\", \\\"{x:1171,y:925,t:1527019923670};\\\", \\\"{x:1169,y:923,t:1527019923686};\\\", \\\"{x:1168,y:921,t:1527019923703};\\\", \\\"{x:1168,y:918,t:1527019923720};\\\", \\\"{x:1168,y:913,t:1527019923737};\\\", \\\"{x:1168,y:907,t:1527019923754};\\\", \\\"{x:1168,y:903,t:1527019923770};\\\", \\\"{x:1168,y:896,t:1527019923787};\\\", \\\"{x:1168,y:891,t:1527019923804};\\\", \\\"{x:1169,y:884,t:1527019923821};\\\", \\\"{x:1170,y:878,t:1527019923837};\\\", \\\"{x:1171,y:875,t:1527019923853};\\\", \\\"{x:1172,y:873,t:1527019923870};\\\", \\\"{x:1173,y:871,t:1527019923887};\\\", \\\"{x:1176,y:867,t:1527019923903};\\\", \\\"{x:1176,y:865,t:1527019923921};\\\", \\\"{x:1177,y:864,t:1527019923937};\\\", \\\"{x:1178,y:863,t:1527019923953};\\\", \\\"{x:1178,y:862,t:1527019923973};\\\", \\\"{x:1179,y:862,t:1527019923988};\\\", \\\"{x:1180,y:861,t:1527019924004};\\\", \\\"{x:1186,y:857,t:1527019924020};\\\", \\\"{x:1190,y:854,t:1527019924037};\\\", \\\"{x:1191,y:853,t:1527019924054};\\\", \\\"{x:1192,y:853,t:1527019924071};\\\", \\\"{x:1193,y:853,t:1527019924087};\\\", \\\"{x:1194,y:853,t:1527019924166};\\\", \\\"{x:1195,y:853,t:1527019924174};\\\", \\\"{x:1197,y:853,t:1527019924187};\\\", \\\"{x:1201,y:853,t:1527019924203};\\\", \\\"{x:1208,y:853,t:1527019924220};\\\", \\\"{x:1222,y:858,t:1527019924237};\\\", \\\"{x:1232,y:862,t:1527019924254};\\\", \\\"{x:1239,y:864,t:1527019924271};\\\", \\\"{x:1242,y:867,t:1527019924287};\\\", \\\"{x:1244,y:867,t:1527019924305};\\\", \\\"{x:1244,y:868,t:1527019924321};\\\", \\\"{x:1244,y:869,t:1527019924494};\\\", \\\"{x:1243,y:869,t:1527019924526};\\\", \\\"{x:1242,y:869,t:1527019924537};\\\", \\\"{x:1239,y:869,t:1527019924555};\\\", \\\"{x:1233,y:868,t:1527019924571};\\\", \\\"{x:1225,y:864,t:1527019924588};\\\", \\\"{x:1214,y:860,t:1527019924604};\\\", \\\"{x:1205,y:857,t:1527019924620};\\\", \\\"{x:1200,y:855,t:1527019924637};\\\", \\\"{x:1199,y:854,t:1527019924655};\\\", \\\"{x:1198,y:854,t:1527019924798};\\\", \\\"{x:1198,y:852,t:1527019924805};\\\", \\\"{x:1198,y:851,t:1527019924821};\\\", \\\"{x:1198,y:848,t:1527019924837};\\\", \\\"{x:1200,y:845,t:1527019924854};\\\", \\\"{x:1202,y:843,t:1527019924871};\\\", \\\"{x:1203,y:842,t:1527019924887};\\\", \\\"{x:1204,y:841,t:1527019924904};\\\", \\\"{x:1205,y:840,t:1527019925181};\\\", \\\"{x:1208,y:838,t:1527019925190};\\\", \\\"{x:1212,y:836,t:1527019925204};\\\", \\\"{x:1221,y:831,t:1527019925221};\\\", \\\"{x:1225,y:829,t:1527019925237};\\\", \\\"{x:1229,y:828,t:1527019925254};\\\", \\\"{x:1232,y:827,t:1527019925272};\\\", \\\"{x:1238,y:826,t:1527019925289};\\\", \\\"{x:1243,y:824,t:1527019925304};\\\", \\\"{x:1248,y:822,t:1527019925322};\\\", \\\"{x:1252,y:820,t:1527019925338};\\\", \\\"{x:1255,y:819,t:1527019925354};\\\", \\\"{x:1257,y:818,t:1527019925371};\\\", \\\"{x:1260,y:817,t:1527019925389};\\\", \\\"{x:1267,y:814,t:1527019925404};\\\", \\\"{x:1276,y:810,t:1527019925421};\\\", \\\"{x:1283,y:806,t:1527019925438};\\\", \\\"{x:1288,y:803,t:1527019925454};\\\", \\\"{x:1293,y:801,t:1527019925471};\\\", \\\"{x:1297,y:798,t:1527019925489};\\\", \\\"{x:1302,y:795,t:1527019925504};\\\", \\\"{x:1306,y:793,t:1527019925521};\\\", \\\"{x:1310,y:791,t:1527019925539};\\\", \\\"{x:1313,y:790,t:1527019925555};\\\", \\\"{x:1316,y:787,t:1527019925571};\\\", \\\"{x:1323,y:783,t:1527019925589};\\\", \\\"{x:1326,y:781,t:1527019925605};\\\", \\\"{x:1327,y:780,t:1527019925621};\\\", \\\"{x:1328,y:779,t:1527019925638};\\\", \\\"{x:1330,y:777,t:1527019925654};\\\", \\\"{x:1331,y:777,t:1527019925671};\\\", \\\"{x:1332,y:776,t:1527019925689};\\\", \\\"{x:1333,y:774,t:1527019925704};\\\", \\\"{x:1334,y:773,t:1527019925721};\\\", \\\"{x:1335,y:772,t:1527019925749};\\\", \\\"{x:1336,y:771,t:1527019925757};\\\", \\\"{x:1337,y:770,t:1527019925772};\\\", \\\"{x:1339,y:768,t:1527019925789};\\\", \\\"{x:1345,y:765,t:1527019925804};\\\", \\\"{x:1345,y:763,t:1527019925821};\\\", \\\"{x:1347,y:763,t:1527019925837};\\\", \\\"{x:1347,y:762,t:1527019925854};\\\", \\\"{x:1347,y:761,t:1527019925941};\\\", \\\"{x:1347,y:760,t:1527019925981};\\\", \\\"{x:1347,y:758,t:1527019926150};\\\", \\\"{x:1348,y:755,t:1527019926158};\\\", \\\"{x:1349,y:753,t:1527019926171};\\\", \\\"{x:1349,y:746,t:1527019926188};\\\", \\\"{x:1349,y:734,t:1527019926206};\\\", \\\"{x:1349,y:731,t:1527019926222};\\\", \\\"{x:1349,y:728,t:1527019926238};\\\", \\\"{x:1349,y:726,t:1527019926255};\\\", \\\"{x:1349,y:724,t:1527019926272};\\\", \\\"{x:1349,y:719,t:1527019926289};\\\", \\\"{x:1349,y:716,t:1527019926305};\\\", \\\"{x:1349,y:713,t:1527019926323};\\\", \\\"{x:1349,y:709,t:1527019926338};\\\", \\\"{x:1349,y:704,t:1527019926356};\\\", \\\"{x:1349,y:699,t:1527019926373};\\\", \\\"{x:1349,y:695,t:1527019926388};\\\", \\\"{x:1349,y:692,t:1527019926404};\\\", \\\"{x:1349,y:691,t:1527019926423};\\\", \\\"{x:1349,y:693,t:1527019926568};\\\", \\\"{x:1349,y:701,t:1527019926588};\\\", \\\"{x:1349,y:713,t:1527019926605};\\\", \\\"{x:1349,y:717,t:1527019926621};\\\", \\\"{x:1350,y:721,t:1527019926638};\\\", \\\"{x:1350,y:722,t:1527019926654};\\\", \\\"{x:1351,y:725,t:1527019926671};\\\", \\\"{x:1351,y:728,t:1527019926689};\\\", \\\"{x:1351,y:730,t:1527019926704};\\\", \\\"{x:1351,y:733,t:1527019926722};\\\", \\\"{x:1351,y:734,t:1527019926739};\\\", \\\"{x:1351,y:737,t:1527019926755};\\\", \\\"{x:1351,y:739,t:1527019926772};\\\", \\\"{x:1351,y:742,t:1527019926788};\\\", \\\"{x:1351,y:743,t:1527019926812};\\\", \\\"{x:1351,y:745,t:1527019926822};\\\", \\\"{x:1351,y:747,t:1527019926839};\\\", \\\"{x:1351,y:750,t:1527019926855};\\\", \\\"{x:1351,y:752,t:1527019926872};\\\", \\\"{x:1351,y:755,t:1527019926889};\\\", \\\"{x:1351,y:756,t:1527019926905};\\\", \\\"{x:1351,y:757,t:1527019926922};\\\", \\\"{x:1351,y:759,t:1527019926939};\\\", \\\"{x:1351,y:762,t:1527019926972};\\\", \\\"{x:1351,y:768,t:1527019926989};\\\", \\\"{x:1351,y:772,t:1527019927005};\\\", \\\"{x:1350,y:773,t:1527019927022};\\\", \\\"{x:1350,y:776,t:1527019927040};\\\", \\\"{x:1350,y:779,t:1527019927056};\\\", \\\"{x:1349,y:783,t:1527019927073};\\\", \\\"{x:1348,y:786,t:1527019927089};\\\", \\\"{x:1348,y:790,t:1527019927105};\\\", \\\"{x:1348,y:796,t:1527019927122};\\\", \\\"{x:1348,y:803,t:1527019927139};\\\", \\\"{x:1348,y:814,t:1527019927157};\\\", \\\"{x:1348,y:823,t:1527019927172};\\\", \\\"{x:1348,y:835,t:1527019927189};\\\", \\\"{x:1348,y:844,t:1527019927206};\\\", \\\"{x:1348,y:849,t:1527019927222};\\\", \\\"{x:1348,y:858,t:1527019927239};\\\", \\\"{x:1348,y:866,t:1527019927256};\\\", \\\"{x:1348,y:873,t:1527019927272};\\\", \\\"{x:1348,y:882,t:1527019927289};\\\", \\\"{x:1348,y:889,t:1527019927306};\\\", \\\"{x:1347,y:896,t:1527019927322};\\\", \\\"{x:1347,y:898,t:1527019927340};\\\", \\\"{x:1347,y:902,t:1527019927356};\\\", \\\"{x:1347,y:904,t:1527019927373};\\\", \\\"{x:1346,y:908,t:1527019927389};\\\", \\\"{x:1346,y:910,t:1527019927406};\\\", \\\"{x:1346,y:913,t:1527019927422};\\\", \\\"{x:1346,y:915,t:1527019927439};\\\", \\\"{x:1346,y:918,t:1527019927456};\\\", \\\"{x:1344,y:921,t:1527019927473};\\\", \\\"{x:1344,y:923,t:1527019927489};\\\", \\\"{x:1344,y:924,t:1527019927506};\\\", \\\"{x:1344,y:925,t:1527019927522};\\\", \\\"{x:1344,y:927,t:1527019927540};\\\", \\\"{x:1344,y:929,t:1527019927556};\\\", \\\"{x:1344,y:932,t:1527019927573};\\\", \\\"{x:1344,y:933,t:1527019927589};\\\", \\\"{x:1344,y:935,t:1527019927606};\\\", \\\"{x:1344,y:937,t:1527019927624};\\\", \\\"{x:1344,y:939,t:1527019927640};\\\", \\\"{x:1344,y:942,t:1527019927656};\\\", \\\"{x:1344,y:945,t:1527019927673};\\\", \\\"{x:1344,y:946,t:1527019927690};\\\", \\\"{x:1344,y:949,t:1527019927706};\\\", \\\"{x:1344,y:951,t:1527019927733};\\\", \\\"{x:1344,y:952,t:1527019927757};\\\", \\\"{x:1344,y:954,t:1527019927774};\\\", \\\"{x:1344,y:955,t:1527019927789};\\\", \\\"{x:1344,y:957,t:1527019927807};\\\", \\\"{x:1344,y:958,t:1527019927823};\\\", \\\"{x:1344,y:960,t:1527019927839};\\\", \\\"{x:1344,y:961,t:1527019927856};\\\", \\\"{x:1344,y:963,t:1527019927873};\\\", \\\"{x:1344,y:964,t:1527019927901};\\\", \\\"{x:1344,y:965,t:1527019927917};\\\", \\\"{x:1344,y:966,t:1527019927925};\\\", \\\"{x:1343,y:966,t:1527019929333};\\\", \\\"{x:1339,y:964,t:1527019929342};\\\", \\\"{x:1329,y:959,t:1527019929358};\\\", \\\"{x:1318,y:956,t:1527019929375};\\\", \\\"{x:1299,y:951,t:1527019929391};\\\", \\\"{x:1275,y:943,t:1527019929407};\\\", \\\"{x:1253,y:936,t:1527019929424};\\\", \\\"{x:1224,y:930,t:1527019929441};\\\", \\\"{x:1193,y:921,t:1527019929457};\\\", \\\"{x:1163,y:913,t:1527019929474};\\\", \\\"{x:1135,y:905,t:1527019929491};\\\", \\\"{x:1112,y:898,t:1527019929507};\\\", \\\"{x:1096,y:894,t:1527019929525};\\\", \\\"{x:1074,y:887,t:1527019929541};\\\", \\\"{x:1061,y:883,t:1527019929557};\\\", \\\"{x:1056,y:881,t:1527019929574};\\\", \\\"{x:1049,y:879,t:1527019929592};\\\", \\\"{x:1042,y:878,t:1527019929607};\\\", \\\"{x:1035,y:875,t:1527019929624};\\\", \\\"{x:1026,y:874,t:1527019929641};\\\", \\\"{x:1015,y:870,t:1527019929658};\\\", \\\"{x:1001,y:866,t:1527019929675};\\\", \\\"{x:986,y:864,t:1527019929692};\\\", \\\"{x:966,y:859,t:1527019929707};\\\", \\\"{x:949,y:854,t:1527019929724};\\\", \\\"{x:922,y:850,t:1527019929741};\\\", \\\"{x:902,y:846,t:1527019929757};\\\", \\\"{x:886,y:842,t:1527019929774};\\\", \\\"{x:876,y:839,t:1527019929791};\\\", \\\"{x:860,y:834,t:1527019929807};\\\", \\\"{x:846,y:828,t:1527019929825};\\\", \\\"{x:830,y:823,t:1527019929841};\\\", \\\"{x:815,y:818,t:1527019929857};\\\", \\\"{x:805,y:814,t:1527019929874};\\\", \\\"{x:793,y:809,t:1527019929891};\\\", \\\"{x:778,y:802,t:1527019929908};\\\", \\\"{x:758,y:792,t:1527019929924};\\\", \\\"{x:741,y:781,t:1527019929941};\\\", \\\"{x:725,y:770,t:1527019929958};\\\", \\\"{x:703,y:754,t:1527019929975};\\\", \\\"{x:683,y:742,t:1527019929991};\\\", \\\"{x:663,y:731,t:1527019930008};\\\", \\\"{x:642,y:719,t:1527019930024};\\\", \\\"{x:618,y:705,t:1527019930041};\\\", \\\"{x:593,y:690,t:1527019930059};\\\", \\\"{x:564,y:673,t:1527019930074};\\\", \\\"{x:538,y:658,t:1527019930091};\\\", \\\"{x:518,y:647,t:1527019930108};\\\", \\\"{x:504,y:636,t:1527019930124};\\\", \\\"{x:486,y:622,t:1527019930142};\\\", \\\"{x:474,y:611,t:1527019930157};\\\", \\\"{x:463,y:603,t:1527019930174};\\\", \\\"{x:453,y:597,t:1527019930192};\\\", \\\"{x:445,y:589,t:1527019930208};\\\", \\\"{x:442,y:586,t:1527019930225};\\\", \\\"{x:439,y:581,t:1527019930241};\\\", \\\"{x:434,y:578,t:1527019930258};\\\", \\\"{x:428,y:573,t:1527019930274};\\\", \\\"{x:421,y:568,t:1527019930292};\\\", \\\"{x:414,y:558,t:1527019930308};\\\", \\\"{x:400,y:540,t:1527019930325};\\\", \\\"{x:394,y:530,t:1527019930342};\\\", \\\"{x:390,y:524,t:1527019930358};\\\", \\\"{x:386,y:517,t:1527019930375};\\\", \\\"{x:385,y:516,t:1527019930391};\\\", \\\"{x:385,y:514,t:1527019930409};\\\", \\\"{x:385,y:513,t:1527019930429};\\\", \\\"{x:385,y:512,t:1527019930442};\\\", \\\"{x:393,y:508,t:1527019930458};\\\", \\\"{x:403,y:504,t:1527019930475};\\\", \\\"{x:413,y:499,t:1527019930491};\\\", \\\"{x:423,y:495,t:1527019930509};\\\", \\\"{x:438,y:489,t:1527019930525};\\\", \\\"{x:448,y:489,t:1527019930542};\\\", \\\"{x:463,y:489,t:1527019930559};\\\", \\\"{x:485,y:491,t:1527019930575};\\\", \\\"{x:513,y:498,t:1527019930592};\\\", \\\"{x:549,y:507,t:1527019930609};\\\", \\\"{x:591,y:513,t:1527019930625};\\\", \\\"{x:632,y:522,t:1527019930642};\\\", \\\"{x:660,y:527,t:1527019930660};\\\", \\\"{x:681,y:530,t:1527019930674};\\\", \\\"{x:694,y:533,t:1527019930692};\\\", \\\"{x:702,y:536,t:1527019930708};\\\", \\\"{x:707,y:538,t:1527019930724};\\\", \\\"{x:709,y:540,t:1527019930741};\\\", \\\"{x:711,y:540,t:1527019930758};\\\", \\\"{x:713,y:540,t:1527019930775};\\\", \\\"{x:718,y:540,t:1527019930792};\\\", \\\"{x:732,y:542,t:1527019930810};\\\", \\\"{x:754,y:544,t:1527019930825};\\\", \\\"{x:775,y:544,t:1527019930841};\\\", \\\"{x:794,y:544,t:1527019930859};\\\", \\\"{x:810,y:544,t:1527019930876};\\\", \\\"{x:819,y:544,t:1527019930892};\\\", \\\"{x:825,y:542,t:1527019930909};\\\", \\\"{x:828,y:539,t:1527019930926};\\\", \\\"{x:831,y:536,t:1527019930942};\\\", \\\"{x:834,y:531,t:1527019930959};\\\", \\\"{x:837,y:527,t:1527019930977};\\\", \\\"{x:841,y:523,t:1527019930992};\\\", \\\"{x:844,y:519,t:1527019931009};\\\", \\\"{x:847,y:515,t:1527019931027};\\\", \\\"{x:850,y:511,t:1527019931042};\\\", \\\"{x:852,y:509,t:1527019931059};\\\", \\\"{x:856,y:505,t:1527019931075};\\\", \\\"{x:858,y:501,t:1527019931091};\\\", \\\"{x:861,y:496,t:1527019931108};\\\", \\\"{x:861,y:495,t:1527019931126};\\\", \\\"{x:861,y:494,t:1527019931324};\\\", \\\"{x:860,y:494,t:1527019931332};\\\", \\\"{x:859,y:494,t:1527019931343};\\\", \\\"{x:854,y:496,t:1527019931359};\\\", \\\"{x:849,y:499,t:1527019931376};\\\", \\\"{x:830,y:511,t:1527019931393};\\\", \\\"{x:804,y:527,t:1527019931409};\\\", \\\"{x:767,y:546,t:1527019931426};\\\", \\\"{x:732,y:561,t:1527019931443};\\\", \\\"{x:705,y:569,t:1527019931460};\\\", \\\"{x:680,y:574,t:1527019931476};\\\", \\\"{x:647,y:580,t:1527019931493};\\\", \\\"{x:626,y:581,t:1527019931510};\\\", \\\"{x:610,y:584,t:1527019931526};\\\", \\\"{x:597,y:586,t:1527019931543};\\\", \\\"{x:584,y:590,t:1527019931558};\\\", \\\"{x:557,y:597,t:1527019931577};\\\", \\\"{x:529,y:602,t:1527019931594};\\\", \\\"{x:498,y:608,t:1527019931611};\\\", \\\"{x:455,y:616,t:1527019931626};\\\", \\\"{x:400,y:622,t:1527019931644};\\\", \\\"{x:342,y:627,t:1527019931660};\\\", \\\"{x:291,y:630,t:1527019931676};\\\", \\\"{x:240,y:630,t:1527019931694};\\\", \\\"{x:218,y:630,t:1527019931710};\\\", \\\"{x:201,y:630,t:1527019931726};\\\", \\\"{x:189,y:630,t:1527019931743};\\\", \\\"{x:180,y:630,t:1527019931759};\\\", \\\"{x:175,y:630,t:1527019931776};\\\", \\\"{x:169,y:629,t:1527019931792};\\\", \\\"{x:166,y:629,t:1527019931809};\\\", \\\"{x:165,y:628,t:1527019931826};\\\", \\\"{x:165,y:626,t:1527019931901};\\\", \\\"{x:165,y:624,t:1527019931908};\\\", \\\"{x:165,y:619,t:1527019931926};\\\", \\\"{x:165,y:613,t:1527019931943};\\\", \\\"{x:165,y:603,t:1527019931960};\\\", \\\"{x:166,y:593,t:1527019931977};\\\", \\\"{x:167,y:583,t:1527019931993};\\\", \\\"{x:167,y:577,t:1527019932009};\\\", \\\"{x:170,y:572,t:1527019932026};\\\", \\\"{x:170,y:568,t:1527019932043};\\\", \\\"{x:173,y:564,t:1527019932060};\\\", \\\"{x:174,y:562,t:1527019932077};\\\", \\\"{x:175,y:559,t:1527019932093};\\\", \\\"{x:175,y:557,t:1527019932110};\\\", \\\"{x:177,y:555,t:1527019932127};\\\", \\\"{x:178,y:552,t:1527019932142};\\\", \\\"{x:181,y:546,t:1527019932160};\\\", \\\"{x:182,y:545,t:1527019932177};\\\", \\\"{x:183,y:543,t:1527019932192};\\\", \\\"{x:184,y:542,t:1527019932460};\\\", \\\"{x:199,y:552,t:1527019932476};\\\", \\\"{x:224,y:574,t:1527019932494};\\\", \\\"{x:261,y:603,t:1527019932510};\\\", \\\"{x:302,y:634,t:1527019932527};\\\", \\\"{x:347,y:657,t:1527019932545};\\\", \\\"{x:386,y:681,t:1527019932560};\\\", \\\"{x:420,y:699,t:1527019932577};\\\", \\\"{x:447,y:712,t:1527019932594};\\\", \\\"{x:465,y:723,t:1527019932610};\\\", \\\"{x:475,y:729,t:1527019932627};\\\", \\\"{x:480,y:733,t:1527019932643};\\\", \\\"{x:483,y:734,t:1527019932660};\\\", \\\"{x:483,y:735,t:1527019932677};\\\", \\\"{x:485,y:736,t:1527019932693};\\\", \\\"{x:486,y:737,t:1527019932710};\\\", \\\"{x:486,y:738,t:1527019932727};\\\", \\\"{x:487,y:739,t:1527019932743};\\\", \\\"{x:487,y:740,t:1527019932821};\\\", \\\"{x:489,y:741,t:1527019932836};\\\", \\\"{x:489,y:742,t:1527019932901};\\\", \\\"{x:489,y:743,t:1527019932998};\\\" ] }, { \\\"rt\\\": 165697, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 733487, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -G -H -M -X -B -E -F -F -02 PM-02 PM-J -J -B -B -B -F -B -B -B -J -J -F -01 PM-C -F -F -B -B -E -K -E -J -B -B -I -3-3-3-02 PM-02 PM-02 PM-02 PM-05 PM-X -X -02 PM-02 PM-X -X -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:490,y:743,t:1527019945909};\\\", \\\"{x:509,y:733,t:1527019945922};\\\", \\\"{x:567,y:707,t:1527019945940};\\\", \\\"{x:653,y:685,t:1527019945956};\\\", \\\"{x:723,y:670,t:1527019945971};\\\", \\\"{x:793,y:660,t:1527019945988};\\\", \\\"{x:883,y:642,t:1527019946004};\\\", \\\"{x:949,y:626,t:1527019946022};\\\", \\\"{x:1018,y:607,t:1527019946038};\\\", \\\"{x:1082,y:591,t:1527019946054};\\\", \\\"{x:1110,y:582,t:1527019946071};\\\", \\\"{x:1124,y:579,t:1527019946087};\\\", \\\"{x:1134,y:574,t:1527019946105};\\\", \\\"{x:1141,y:571,t:1527019946121};\\\", \\\"{x:1154,y:567,t:1527019946138};\\\", \\\"{x:1164,y:564,t:1527019946155};\\\", \\\"{x:1168,y:561,t:1527019946172};\\\", \\\"{x:1176,y:557,t:1527019946188};\\\", \\\"{x:1193,y:549,t:1527019946204};\\\", \\\"{x:1205,y:543,t:1527019946221};\\\", \\\"{x:1219,y:536,t:1527019946238};\\\", \\\"{x:1235,y:527,t:1527019946255};\\\", \\\"{x:1249,y:522,t:1527019946271};\\\", \\\"{x:1265,y:516,t:1527019946287};\\\", \\\"{x:1280,y:510,t:1527019946305};\\\", \\\"{x:1286,y:508,t:1527019946322};\\\", \\\"{x:1291,y:508,t:1527019946337};\\\", \\\"{x:1298,y:508,t:1527019946354};\\\", \\\"{x:1305,y:508,t:1527019946371};\\\", \\\"{x:1319,y:508,t:1527019946387};\\\", \\\"{x:1353,y:508,t:1527019946404};\\\", \\\"{x:1383,y:513,t:1527019946422};\\\", \\\"{x:1410,y:516,t:1527019946439};\\\", \\\"{x:1436,y:522,t:1527019946455};\\\", \\\"{x:1460,y:526,t:1527019946472};\\\", \\\"{x:1479,y:530,t:1527019946489};\\\", \\\"{x:1494,y:535,t:1527019946505};\\\", \\\"{x:1507,y:538,t:1527019946522};\\\", \\\"{x:1514,y:539,t:1527019946539};\\\", \\\"{x:1516,y:540,t:1527019946554};\\\", \\\"{x:1515,y:542,t:1527019947068};\\\", \\\"{x:1511,y:544,t:1527019947076};\\\", \\\"{x:1509,y:544,t:1527019947089};\\\", \\\"{x:1507,y:546,t:1527019947105};\\\", \\\"{x:1505,y:546,t:1527019947124};\\\", \\\"{x:1504,y:547,t:1527019947138};\\\", \\\"{x:1503,y:548,t:1527019947156};\\\", \\\"{x:1502,y:548,t:1527019947172};\\\", \\\"{x:1500,y:549,t:1527019947188};\\\", \\\"{x:1498,y:550,t:1527019947205};\\\", \\\"{x:1496,y:551,t:1527019947221};\\\", \\\"{x:1493,y:551,t:1527019947239};\\\", \\\"{x:1491,y:552,t:1527019947256};\\\", \\\"{x:1487,y:554,t:1527019947272};\\\", \\\"{x:1485,y:555,t:1527019947289};\\\", \\\"{x:1481,y:556,t:1527019947306};\\\", \\\"{x:1477,y:557,t:1527019947322};\\\", \\\"{x:1473,y:559,t:1527019947339};\\\", \\\"{x:1468,y:559,t:1527019947355};\\\", \\\"{x:1456,y:564,t:1527019947372};\\\", \\\"{x:1445,y:569,t:1527019947389};\\\", \\\"{x:1436,y:572,t:1527019947406};\\\", \\\"{x:1431,y:575,t:1527019947422};\\\", \\\"{x:1429,y:576,t:1527019947438};\\\", \\\"{x:1427,y:576,t:1527019947456};\\\", \\\"{x:1426,y:576,t:1527019947473};\\\", \\\"{x:1425,y:578,t:1527019948813};\\\", \\\"{x:1425,y:581,t:1527019948825};\\\", \\\"{x:1425,y:585,t:1527019948840};\\\", \\\"{x:1423,y:590,t:1527019948857};\\\", \\\"{x:1423,y:593,t:1527019948874};\\\", \\\"{x:1423,y:597,t:1527019948890};\\\", \\\"{x:1422,y:600,t:1527019948907};\\\", \\\"{x:1421,y:605,t:1527019948924};\\\", \\\"{x:1421,y:607,t:1527019948940};\\\", \\\"{x:1420,y:612,t:1527019948957};\\\", \\\"{x:1420,y:614,t:1527019948974};\\\", \\\"{x:1419,y:617,t:1527019948990};\\\", \\\"{x:1419,y:619,t:1527019949007};\\\", \\\"{x:1419,y:621,t:1527019949024};\\\", \\\"{x:1419,y:623,t:1527019949040};\\\", \\\"{x:1418,y:624,t:1527019949057};\\\", \\\"{x:1416,y:627,t:1527019949074};\\\", \\\"{x:1416,y:628,t:1527019949091};\\\", \\\"{x:1416,y:631,t:1527019949107};\\\", \\\"{x:1415,y:633,t:1527019949124};\\\", \\\"{x:1414,y:637,t:1527019949141};\\\", \\\"{x:1414,y:638,t:1527019949157};\\\", \\\"{x:1413,y:639,t:1527019949175};\\\", \\\"{x:1413,y:637,t:1527019949293};\\\", \\\"{x:1413,y:633,t:1527019949307};\\\", \\\"{x:1413,y:628,t:1527019949324};\\\", \\\"{x:1413,y:625,t:1527019949341};\\\", \\\"{x:1412,y:624,t:1527019949469};\\\", \\\"{x:1410,y:625,t:1527019949533};\\\", \\\"{x:1409,y:625,t:1527019949540};\\\", \\\"{x:1409,y:627,t:1527019949558};\\\", \\\"{x:1405,y:633,t:1527019949574};\\\", \\\"{x:1404,y:642,t:1527019949591};\\\", \\\"{x:1401,y:652,t:1527019949608};\\\", \\\"{x:1399,y:660,t:1527019949624};\\\", \\\"{x:1397,y:666,t:1527019949641};\\\", \\\"{x:1395,y:673,t:1527019949658};\\\", \\\"{x:1393,y:678,t:1527019949674};\\\", \\\"{x:1393,y:682,t:1527019949691};\\\", \\\"{x:1390,y:687,t:1527019949708};\\\", \\\"{x:1388,y:692,t:1527019949724};\\\", \\\"{x:1385,y:698,t:1527019949741};\\\", \\\"{x:1383,y:703,t:1527019949758};\\\", \\\"{x:1382,y:704,t:1527019949774};\\\", \\\"{x:1381,y:706,t:1527019949791};\\\", \\\"{x:1381,y:708,t:1527019949808};\\\", \\\"{x:1381,y:709,t:1527019949824};\\\", \\\"{x:1380,y:711,t:1527019949841};\\\", \\\"{x:1378,y:713,t:1527019949858};\\\", \\\"{x:1378,y:714,t:1527019949875};\\\", \\\"{x:1377,y:716,t:1527019949891};\\\", \\\"{x:1376,y:717,t:1527019949908};\\\", \\\"{x:1374,y:721,t:1527019949925};\\\", \\\"{x:1372,y:724,t:1527019949941};\\\", \\\"{x:1371,y:728,t:1527019949958};\\\", \\\"{x:1370,y:731,t:1527019949975};\\\", \\\"{x:1368,y:735,t:1527019949991};\\\", \\\"{x:1366,y:739,t:1527019950008};\\\", \\\"{x:1364,y:742,t:1527019950025};\\\", \\\"{x:1363,y:745,t:1527019950041};\\\", \\\"{x:1363,y:747,t:1527019950058};\\\", \\\"{x:1361,y:751,t:1527019950076};\\\", \\\"{x:1359,y:755,t:1527019950091};\\\", \\\"{x:1358,y:758,t:1527019950108};\\\", \\\"{x:1357,y:760,t:1527019950124};\\\", \\\"{x:1356,y:762,t:1527019950141};\\\", \\\"{x:1355,y:764,t:1527019950158};\\\", \\\"{x:1354,y:766,t:1527019950181};\\\", \\\"{x:1353,y:768,t:1527019950197};\\\", \\\"{x:1352,y:770,t:1527019950213};\\\", \\\"{x:1352,y:771,t:1527019950236};\\\", \\\"{x:1351,y:772,t:1527019950260};\\\", \\\"{x:1351,y:773,t:1527019950277};\\\", \\\"{x:1350,y:774,t:1527019950300};\\\", \\\"{x:1350,y:773,t:1527019951445};\\\", \\\"{x:1351,y:765,t:1527019951461};\\\", \\\"{x:1354,y:749,t:1527019951477};\\\", \\\"{x:1362,y:727,t:1527019951492};\\\", \\\"{x:1370,y:691,t:1527019951509};\\\", \\\"{x:1377,y:665,t:1527019951526};\\\", \\\"{x:1387,y:633,t:1527019951542};\\\", \\\"{x:1396,y:597,t:1527019951559};\\\", \\\"{x:1410,y:552,t:1527019951576};\\\", \\\"{x:1426,y:494,t:1527019951592};\\\", \\\"{x:1449,y:441,t:1527019951610};\\\", \\\"{x:1460,y:414,t:1527019951626};\\\", \\\"{x:1468,y:395,t:1527019951643};\\\", \\\"{x:1476,y:380,t:1527019951659};\\\", \\\"{x:1482,y:370,t:1527019951677};\\\", \\\"{x:1485,y:367,t:1527019951693};\\\", \\\"{x:1486,y:366,t:1527019951709};\\\", \\\"{x:1487,y:365,t:1527019951726};\\\", \\\"{x:1490,y:362,t:1527019951743};\\\", \\\"{x:1493,y:359,t:1527019951759};\\\", \\\"{x:1497,y:353,t:1527019951777};\\\", \\\"{x:1503,y:344,t:1527019951793};\\\", \\\"{x:1506,y:340,t:1527019951808};\\\", \\\"{x:1508,y:337,t:1527019951825};\\\", \\\"{x:1508,y:336,t:1527019951842};\\\", \\\"{x:1509,y:335,t:1527019951948};\\\", \\\"{x:1510,y:334,t:1527019951959};\\\", \\\"{x:1514,y:333,t:1527019951976};\\\", \\\"{x:1516,y:333,t:1527019951993};\\\", \\\"{x:1518,y:333,t:1527019952009};\\\", \\\"{x:1520,y:333,t:1527019952026};\\\", \\\"{x:1526,y:335,t:1527019952044};\\\", \\\"{x:1538,y:350,t:1527019952060};\\\", \\\"{x:1553,y:368,t:1527019952077};\\\", \\\"{x:1564,y:383,t:1527019952092};\\\", \\\"{x:1570,y:392,t:1527019952109};\\\", \\\"{x:1575,y:401,t:1527019952126};\\\", \\\"{x:1578,y:409,t:1527019952143};\\\", \\\"{x:1581,y:417,t:1527019952159};\\\", \\\"{x:1584,y:429,t:1527019952176};\\\", \\\"{x:1587,y:443,t:1527019952193};\\\", \\\"{x:1588,y:457,t:1527019952210};\\\", \\\"{x:1591,y:469,t:1527019952226};\\\", \\\"{x:1591,y:476,t:1527019952243};\\\", \\\"{x:1591,y:491,t:1527019952261};\\\", \\\"{x:1591,y:497,t:1527019952276};\\\", \\\"{x:1591,y:513,t:1527019952293};\\\", \\\"{x:1591,y:527,t:1527019952310};\\\", \\\"{x:1591,y:538,t:1527019952326};\\\", \\\"{x:1591,y:547,t:1527019952343};\\\", \\\"{x:1591,y:553,t:1527019952360};\\\", \\\"{x:1591,y:561,t:1527019952376};\\\", \\\"{x:1591,y:570,t:1527019952393};\\\", \\\"{x:1591,y:577,t:1527019952411};\\\", \\\"{x:1591,y:583,t:1527019952426};\\\", \\\"{x:1591,y:595,t:1527019952442};\\\", \\\"{x:1591,y:607,t:1527019952460};\\\", \\\"{x:1590,y:613,t:1527019952476};\\\", \\\"{x:1588,y:621,t:1527019952493};\\\", \\\"{x:1586,y:629,t:1527019952510};\\\", \\\"{x:1584,y:634,t:1527019952527};\\\", \\\"{x:1581,y:641,t:1527019952543};\\\", \\\"{x:1578,y:644,t:1527019952560};\\\", \\\"{x:1577,y:653,t:1527019952576};\\\", \\\"{x:1575,y:660,t:1527019952593};\\\", \\\"{x:1575,y:672,t:1527019952610};\\\", \\\"{x:1575,y:676,t:1527019952627};\\\", \\\"{x:1575,y:683,t:1527019952643};\\\", \\\"{x:1578,y:693,t:1527019952660};\\\", \\\"{x:1581,y:700,t:1527019952676};\\\", \\\"{x:1586,y:705,t:1527019952693};\\\", \\\"{x:1594,y:714,t:1527019952710};\\\", \\\"{x:1601,y:719,t:1527019952727};\\\", \\\"{x:1607,y:723,t:1527019952743};\\\", \\\"{x:1609,y:723,t:1527019952760};\\\", \\\"{x:1611,y:725,t:1527019952777};\\\", \\\"{x:1612,y:725,t:1527019952793};\\\", \\\"{x:1609,y:725,t:1527019952956};\\\", \\\"{x:1597,y:727,t:1527019952965};\\\", \\\"{x:1578,y:728,t:1527019952977};\\\", \\\"{x:1520,y:733,t:1527019952994};\\\", \\\"{x:1439,y:736,t:1527019953010};\\\", \\\"{x:1375,y:745,t:1527019953027};\\\", \\\"{x:1292,y:757,t:1527019953043};\\\", \\\"{x:1260,y:762,t:1527019953059};\\\", \\\"{x:1237,y:766,t:1527019953076};\\\", \\\"{x:1217,y:771,t:1527019953093};\\\", \\\"{x:1204,y:776,t:1527019953110};\\\", \\\"{x:1197,y:780,t:1527019953126};\\\", \\\"{x:1195,y:781,t:1527019953143};\\\", \\\"{x:1194,y:782,t:1527019953160};\\\", \\\"{x:1193,y:782,t:1527019953176};\\\", \\\"{x:1192,y:783,t:1527019953194};\\\", \\\"{x:1191,y:784,t:1527019953210};\\\", \\\"{x:1191,y:786,t:1527019953227};\\\", \\\"{x:1191,y:791,t:1527019953244};\\\", \\\"{x:1191,y:794,t:1527019953260};\\\", \\\"{x:1192,y:796,t:1527019953277};\\\", \\\"{x:1195,y:801,t:1527019953294};\\\", \\\"{x:1200,y:807,t:1527019953310};\\\", \\\"{x:1208,y:814,t:1527019953327};\\\", \\\"{x:1218,y:823,t:1527019953344};\\\", \\\"{x:1231,y:832,t:1527019953360};\\\", \\\"{x:1248,y:842,t:1527019953377};\\\", \\\"{x:1263,y:850,t:1527019953394};\\\", \\\"{x:1277,y:856,t:1527019953411};\\\", \\\"{x:1292,y:863,t:1527019953427};\\\", \\\"{x:1313,y:871,t:1527019953444};\\\", \\\"{x:1326,y:877,t:1527019953460};\\\", \\\"{x:1338,y:881,t:1527019953477};\\\", \\\"{x:1348,y:885,t:1527019953494};\\\", \\\"{x:1357,y:886,t:1527019953511};\\\", \\\"{x:1367,y:888,t:1527019953527};\\\", \\\"{x:1382,y:888,t:1527019953544};\\\", \\\"{x:1403,y:888,t:1527019953561};\\\", \\\"{x:1424,y:884,t:1527019953577};\\\", \\\"{x:1442,y:881,t:1527019953594};\\\", \\\"{x:1462,y:875,t:1527019953610};\\\", \\\"{x:1483,y:870,t:1527019953626};\\\", \\\"{x:1507,y:859,t:1527019953643};\\\", \\\"{x:1518,y:852,t:1527019953660};\\\", \\\"{x:1524,y:848,t:1527019953676};\\\", \\\"{x:1524,y:847,t:1527019953694};\\\", \\\"{x:1526,y:844,t:1527019953710};\\\", \\\"{x:1529,y:840,t:1527019953727};\\\", \\\"{x:1529,y:837,t:1527019953744};\\\", \\\"{x:1532,y:834,t:1527019953761};\\\", \\\"{x:1532,y:831,t:1527019953777};\\\", \\\"{x:1532,y:829,t:1527019953794};\\\", \\\"{x:1532,y:827,t:1527019953811};\\\", \\\"{x:1532,y:826,t:1527019953941};\\\", \\\"{x:1531,y:826,t:1527019953948};\\\", \\\"{x:1531,y:825,t:1527019953961};\\\", \\\"{x:1531,y:824,t:1527019953978};\\\", \\\"{x:1530,y:824,t:1527019953994};\\\", \\\"{x:1529,y:824,t:1527019954011};\\\", \\\"{x:1528,y:824,t:1527019954028};\\\", \\\"{x:1527,y:820,t:1527019954253};\\\", \\\"{x:1527,y:817,t:1527019954261};\\\", \\\"{x:1527,y:816,t:1527019954279};\\\", \\\"{x:1524,y:816,t:1527019954756};\\\", \\\"{x:1516,y:816,t:1527019954763};\\\", \\\"{x:1508,y:816,t:1527019954778};\\\", \\\"{x:1491,y:813,t:1527019954794};\\\", \\\"{x:1478,y:811,t:1527019954812};\\\", \\\"{x:1472,y:810,t:1527019954828};\\\", \\\"{x:1469,y:810,t:1527019954844};\\\", \\\"{x:1466,y:809,t:1527019954861};\\\", \\\"{x:1464,y:809,t:1527019954884};\\\", \\\"{x:1464,y:808,t:1527019954908};\\\", \\\"{x:1462,y:808,t:1527019954924};\\\", \\\"{x:1459,y:808,t:1527019954932};\\\", \\\"{x:1456,y:807,t:1527019954944};\\\", \\\"{x:1447,y:805,t:1527019954961};\\\", \\\"{x:1437,y:803,t:1527019954978};\\\", \\\"{x:1423,y:801,t:1527019954994};\\\", \\\"{x:1404,y:797,t:1527019955012};\\\", \\\"{x:1393,y:794,t:1527019955027};\\\", \\\"{x:1384,y:793,t:1527019955045};\\\", \\\"{x:1377,y:792,t:1527019955061};\\\", \\\"{x:1368,y:791,t:1527019955078};\\\", \\\"{x:1361,y:791,t:1527019955095};\\\", \\\"{x:1356,y:791,t:1527019955111};\\\", \\\"{x:1355,y:791,t:1527019955129};\\\", \\\"{x:1354,y:791,t:1527019955237};\\\", \\\"{x:1352,y:790,t:1527019955317};\\\", \\\"{x:1351,y:788,t:1527019955333};\\\", \\\"{x:1349,y:786,t:1527019955345};\\\", \\\"{x:1347,y:783,t:1527019955362};\\\", \\\"{x:1345,y:779,t:1527019955379};\\\", \\\"{x:1342,y:776,t:1527019955395};\\\", \\\"{x:1340,y:772,t:1527019955412};\\\", \\\"{x:1340,y:771,t:1527019955476};\\\", \\\"{x:1339,y:770,t:1527019956164};\\\", \\\"{x:1338,y:770,t:1527019956179};\\\", \\\"{x:1330,y:781,t:1527019956197};\\\", \\\"{x:1327,y:787,t:1527019956212};\\\", \\\"{x:1324,y:795,t:1527019956229};\\\", \\\"{x:1320,y:804,t:1527019956246};\\\", \\\"{x:1315,y:815,t:1527019956264};\\\", \\\"{x:1315,y:816,t:1527019956280};\\\", \\\"{x:1315,y:817,t:1527019956317};\\\", \\\"{x:1315,y:818,t:1527019956653};\\\", \\\"{x:1315,y:820,t:1527019956669};\\\", \\\"{x:1315,y:821,t:1527019956813};\\\", \\\"{x:1320,y:815,t:1527019957021};\\\", \\\"{x:1328,y:805,t:1527019957030};\\\", \\\"{x:1343,y:787,t:1527019957047};\\\", \\\"{x:1361,y:773,t:1527019957063};\\\", \\\"{x:1376,y:764,t:1527019957081};\\\", \\\"{x:1382,y:761,t:1527019957097};\\\", \\\"{x:1384,y:759,t:1527019957114};\\\", \\\"{x:1384,y:758,t:1527019957141};\\\", \\\"{x:1383,y:757,t:1527019957237};\\\", \\\"{x:1379,y:757,t:1527019957247};\\\", \\\"{x:1370,y:758,t:1527019957264};\\\", \\\"{x:1363,y:760,t:1527019957280};\\\", \\\"{x:1360,y:761,t:1527019957298};\\\", \\\"{x:1359,y:761,t:1527019957314};\\\", \\\"{x:1358,y:762,t:1527019957741};\\\", \\\"{x:1356,y:763,t:1527019957748};\\\", \\\"{x:1353,y:763,t:1527019957765};\\\", \\\"{x:1352,y:764,t:1527019957781};\\\", \\\"{x:1350,y:765,t:1527019958212};\\\", \\\"{x:1349,y:765,t:1527019958429};\\\", \\\"{x:1348,y:766,t:1527019958477};\\\", \\\"{x:1347,y:766,t:1527019958492};\\\", \\\"{x:1346,y:766,t:1527019958796};\\\", \\\"{x:1344,y:766,t:1527019958925};\\\", \\\"{x:1342,y:766,t:1527019958933};\\\", \\\"{x:1331,y:769,t:1527019958948};\\\", \\\"{x:1315,y:773,t:1527019958965};\\\", \\\"{x:1300,y:778,t:1527019958981};\\\", \\\"{x:1277,y:787,t:1527019958998};\\\", \\\"{x:1259,y:788,t:1527019959015};\\\", \\\"{x:1248,y:789,t:1527019959032};\\\", \\\"{x:1239,y:792,t:1527019959049};\\\", \\\"{x:1236,y:792,t:1527019959066};\\\", \\\"{x:1233,y:793,t:1527019959082};\\\", \\\"{x:1232,y:793,t:1527019959098};\\\", \\\"{x:1232,y:791,t:1527019959245};\\\", \\\"{x:1232,y:788,t:1527019959253};\\\", \\\"{x:1232,y:786,t:1527019959265};\\\", \\\"{x:1231,y:782,t:1527019959282};\\\", \\\"{x:1229,y:776,t:1527019959299};\\\", \\\"{x:1229,y:772,t:1527019959316};\\\", \\\"{x:1228,y:769,t:1527019959332};\\\", \\\"{x:1228,y:768,t:1527019959349};\\\", \\\"{x:1227,y:766,t:1527019959366};\\\", \\\"{x:1227,y:763,t:1527019959382};\\\", \\\"{x:1227,y:760,t:1527019959399};\\\", \\\"{x:1227,y:757,t:1527019959415};\\\", \\\"{x:1227,y:756,t:1527019959433};\\\", \\\"{x:1227,y:753,t:1527019959449};\\\", \\\"{x:1228,y:746,t:1527019959465};\\\", \\\"{x:1230,y:744,t:1527019959482};\\\", \\\"{x:1232,y:742,t:1527019959499};\\\", \\\"{x:1233,y:740,t:1527019959515};\\\", \\\"{x:1236,y:739,t:1527019959532};\\\", \\\"{x:1238,y:738,t:1527019959549};\\\", \\\"{x:1240,y:736,t:1527019959566};\\\", \\\"{x:1243,y:736,t:1527019959582};\\\", \\\"{x:1247,y:735,t:1527019959598};\\\", \\\"{x:1253,y:735,t:1527019959614};\\\", \\\"{x:1260,y:735,t:1527019959632};\\\", \\\"{x:1271,y:739,t:1527019959649};\\\", \\\"{x:1283,y:747,t:1527019959665};\\\", \\\"{x:1292,y:754,t:1527019959682};\\\", \\\"{x:1296,y:757,t:1527019959698};\\\", \\\"{x:1301,y:760,t:1527019959715};\\\", \\\"{x:1304,y:762,t:1527019959731};\\\", \\\"{x:1305,y:763,t:1527019959749};\\\", \\\"{x:1308,y:763,t:1527019959957};\\\", \\\"{x:1310,y:763,t:1527019959966};\\\", \\\"{x:1313,y:763,t:1527019959982};\\\", \\\"{x:1315,y:763,t:1527019960004};\\\", \\\"{x:1316,y:763,t:1527019960016};\\\", \\\"{x:1317,y:762,t:1527019960032};\\\", \\\"{x:1318,y:762,t:1527019960049};\\\", \\\"{x:1319,y:762,t:1527019960076};\\\", \\\"{x:1319,y:757,t:1527019961932};\\\", \\\"{x:1312,y:741,t:1527019961941};\\\", \\\"{x:1300,y:721,t:1527019961951};\\\", \\\"{x:1281,y:684,t:1527019961969};\\\", \\\"{x:1264,y:659,t:1527019961985};\\\", \\\"{x:1246,y:629,t:1527019962000};\\\", \\\"{x:1237,y:615,t:1527019962017};\\\", \\\"{x:1231,y:606,t:1527019962035};\\\", \\\"{x:1229,y:599,t:1527019962050};\\\", \\\"{x:1227,y:596,t:1527019962068};\\\", \\\"{x:1226,y:591,t:1527019962085};\\\", \\\"{x:1226,y:588,t:1527019962100};\\\", \\\"{x:1223,y:584,t:1527019962118};\\\", \\\"{x:1223,y:579,t:1527019962134};\\\", \\\"{x:1220,y:575,t:1527019962151};\\\", \\\"{x:1220,y:574,t:1527019962168};\\\", \\\"{x:1220,y:573,t:1527019962185};\\\", \\\"{x:1220,y:572,t:1527019962236};\\\", \\\"{x:1220,y:570,t:1527019962251};\\\", \\\"{x:1228,y:567,t:1527019962267};\\\", \\\"{x:1238,y:562,t:1527019962284};\\\", \\\"{x:1244,y:560,t:1527019962302};\\\", \\\"{x:1249,y:558,t:1527019962318};\\\", \\\"{x:1252,y:557,t:1527019962335};\\\", \\\"{x:1253,y:557,t:1527019962351};\\\", \\\"{x:1255,y:555,t:1527019962368};\\\", \\\"{x:1256,y:555,t:1527019962388};\\\", \\\"{x:1256,y:554,t:1527019962420};\\\", \\\"{x:1258,y:554,t:1527019962435};\\\", \\\"{x:1260,y:554,t:1527019962452};\\\", \\\"{x:1265,y:554,t:1527019962467};\\\", \\\"{x:1268,y:554,t:1527019962484};\\\", \\\"{x:1270,y:554,t:1527019963676};\\\", \\\"{x:1272,y:556,t:1527019963686};\\\", \\\"{x:1273,y:558,t:1527019963702};\\\", \\\"{x:1274,y:562,t:1527019963719};\\\", \\\"{x:1276,y:564,t:1527019963735};\\\", \\\"{x:1278,y:568,t:1527019963752};\\\", \\\"{x:1279,y:570,t:1527019963770};\\\", \\\"{x:1280,y:572,t:1527019963785};\\\", \\\"{x:1282,y:574,t:1527019963802};\\\", \\\"{x:1284,y:580,t:1527019963820};\\\", \\\"{x:1287,y:585,t:1527019963835};\\\", \\\"{x:1290,y:590,t:1527019963852};\\\", \\\"{x:1292,y:592,t:1527019963870};\\\", \\\"{x:1294,y:598,t:1527019963885};\\\", \\\"{x:1298,y:601,t:1527019963902};\\\", \\\"{x:1301,y:608,t:1527019963920};\\\", \\\"{x:1306,y:616,t:1527019963935};\\\", \\\"{x:1312,y:627,t:1527019963952};\\\", \\\"{x:1319,y:638,t:1527019963969};\\\", \\\"{x:1325,y:651,t:1527019963985};\\\", \\\"{x:1331,y:661,t:1527019964003};\\\", \\\"{x:1336,y:669,t:1527019964020};\\\", \\\"{x:1341,y:678,t:1527019964035};\\\", \\\"{x:1345,y:686,t:1527019964052};\\\", \\\"{x:1346,y:691,t:1527019964069};\\\", \\\"{x:1350,y:698,t:1527019964086};\\\", \\\"{x:1353,y:707,t:1527019964103};\\\", \\\"{x:1355,y:717,t:1527019964120};\\\", \\\"{x:1359,y:728,t:1527019964136};\\\", \\\"{x:1362,y:736,t:1527019964153};\\\", \\\"{x:1364,y:742,t:1527019964170};\\\", \\\"{x:1366,y:748,t:1527019964186};\\\", \\\"{x:1369,y:755,t:1527019964203};\\\", \\\"{x:1372,y:764,t:1527019964220};\\\", \\\"{x:1376,y:779,t:1527019964236};\\\", \\\"{x:1380,y:787,t:1527019964253};\\\", \\\"{x:1384,y:796,t:1527019964269};\\\", \\\"{x:1389,y:808,t:1527019964287};\\\", \\\"{x:1392,y:815,t:1527019964303};\\\", \\\"{x:1396,y:820,t:1527019964319};\\\", \\\"{x:1398,y:824,t:1527019964336};\\\", \\\"{x:1403,y:832,t:1527019964352};\\\", \\\"{x:1404,y:835,t:1527019964369};\\\", \\\"{x:1408,y:840,t:1527019964386};\\\", \\\"{x:1411,y:846,t:1527019964402};\\\", \\\"{x:1415,y:852,t:1527019964420};\\\", \\\"{x:1424,y:864,t:1527019964436};\\\", \\\"{x:1428,y:870,t:1527019964453};\\\", \\\"{x:1432,y:876,t:1527019964469};\\\", \\\"{x:1435,y:881,t:1527019964487};\\\", \\\"{x:1439,y:888,t:1527019964503};\\\", \\\"{x:1446,y:897,t:1527019964520};\\\", \\\"{x:1453,y:907,t:1527019964537};\\\", \\\"{x:1461,y:919,t:1527019964553};\\\", \\\"{x:1469,y:930,t:1527019964571};\\\", \\\"{x:1477,y:941,t:1527019964586};\\\", \\\"{x:1483,y:952,t:1527019964602};\\\", \\\"{x:1487,y:959,t:1527019964619};\\\", \\\"{x:1491,y:969,t:1527019964636};\\\", \\\"{x:1494,y:976,t:1527019964653};\\\", \\\"{x:1495,y:978,t:1527019964669};\\\", \\\"{x:1495,y:980,t:1527019964686};\\\", \\\"{x:1496,y:981,t:1527019964703};\\\", \\\"{x:1496,y:983,t:1527019964719};\\\", \\\"{x:1497,y:985,t:1527019964736};\\\", \\\"{x:1497,y:986,t:1527019964753};\\\", \\\"{x:1496,y:986,t:1527019964901};\\\", \\\"{x:1494,y:984,t:1527019964909};\\\", \\\"{x:1493,y:983,t:1527019964919};\\\", \\\"{x:1492,y:981,t:1527019964937};\\\", \\\"{x:1489,y:976,t:1527019964953};\\\", \\\"{x:1486,y:972,t:1527019964969};\\\", \\\"{x:1482,y:968,t:1527019964987};\\\", \\\"{x:1481,y:966,t:1527019965003};\\\", \\\"{x:1479,y:965,t:1527019965020};\\\", \\\"{x:1479,y:964,t:1527019965037};\\\", \\\"{x:1479,y:962,t:1527019965245};\\\", \\\"{x:1478,y:960,t:1527019965254};\\\", \\\"{x:1477,y:956,t:1527019965270};\\\", \\\"{x:1477,y:950,t:1527019965287};\\\", \\\"{x:1476,y:946,t:1527019965303};\\\", \\\"{x:1476,y:942,t:1527019965321};\\\", \\\"{x:1476,y:937,t:1527019965337};\\\", \\\"{x:1476,y:934,t:1527019965353};\\\", \\\"{x:1476,y:932,t:1527019965371};\\\", \\\"{x:1476,y:931,t:1527019965386};\\\", \\\"{x:1475,y:931,t:1527019965604};\\\", \\\"{x:1473,y:931,t:1527019965620};\\\", \\\"{x:1467,y:931,t:1527019965637};\\\", \\\"{x:1455,y:931,t:1527019965654};\\\", \\\"{x:1437,y:931,t:1527019965671};\\\", \\\"{x:1410,y:931,t:1527019965687};\\\", \\\"{x:1374,y:931,t:1527019965704};\\\", \\\"{x:1338,y:931,t:1527019965720};\\\", \\\"{x:1308,y:931,t:1527019965737};\\\", \\\"{x:1279,y:927,t:1527019965754};\\\", \\\"{x:1258,y:922,t:1527019965771};\\\", \\\"{x:1241,y:916,t:1527019965788};\\\", \\\"{x:1225,y:911,t:1527019965804};\\\", \\\"{x:1210,y:903,t:1527019965820};\\\", \\\"{x:1200,y:899,t:1527019965838};\\\", \\\"{x:1190,y:890,t:1527019965853};\\\", \\\"{x:1179,y:878,t:1527019965871};\\\", \\\"{x:1169,y:865,t:1527019965888};\\\", \\\"{x:1162,y:851,t:1527019965903};\\\", \\\"{x:1157,y:843,t:1527019965920};\\\", \\\"{x:1153,y:832,t:1527019965938};\\\", \\\"{x:1149,y:823,t:1527019965954};\\\", \\\"{x:1145,y:816,t:1527019965971};\\\", \\\"{x:1144,y:811,t:1527019965988};\\\", \\\"{x:1142,y:806,t:1527019966004};\\\", \\\"{x:1142,y:805,t:1527019966020};\\\", \\\"{x:1142,y:803,t:1527019966038};\\\", \\\"{x:1142,y:801,t:1527019966140};\\\", \\\"{x:1143,y:800,t:1527019966154};\\\", \\\"{x:1146,y:799,t:1527019966171};\\\", \\\"{x:1150,y:797,t:1527019966187};\\\", \\\"{x:1153,y:796,t:1527019966204};\\\", \\\"{x:1157,y:796,t:1527019966220};\\\", \\\"{x:1160,y:795,t:1527019966237};\\\", \\\"{x:1168,y:792,t:1527019966254};\\\", \\\"{x:1183,y:786,t:1527019966270};\\\", \\\"{x:1200,y:775,t:1527019966288};\\\", \\\"{x:1217,y:762,t:1527019966304};\\\", \\\"{x:1236,y:748,t:1527019966320};\\\", \\\"{x:1248,y:741,t:1527019966337};\\\", \\\"{x:1255,y:736,t:1527019966354};\\\", \\\"{x:1257,y:733,t:1527019966370};\\\", \\\"{x:1258,y:731,t:1527019966388};\\\", \\\"{x:1261,y:724,t:1527019966404};\\\", \\\"{x:1263,y:719,t:1527019966421};\\\", \\\"{x:1264,y:715,t:1527019966438};\\\", \\\"{x:1265,y:713,t:1527019966455};\\\", \\\"{x:1265,y:709,t:1527019966471};\\\", \\\"{x:1266,y:706,t:1527019966488};\\\", \\\"{x:1266,y:696,t:1527019966504};\\\", \\\"{x:1267,y:686,t:1527019966521};\\\", \\\"{x:1267,y:678,t:1527019966538};\\\", \\\"{x:1267,y:671,t:1527019966555};\\\", \\\"{x:1267,y:662,t:1527019966571};\\\", \\\"{x:1267,y:655,t:1527019966587};\\\", \\\"{x:1264,y:645,t:1527019966604};\\\", \\\"{x:1263,y:635,t:1527019966621};\\\", \\\"{x:1262,y:629,t:1527019966638};\\\", \\\"{x:1262,y:624,t:1527019966654};\\\", \\\"{x:1262,y:620,t:1527019966672};\\\", \\\"{x:1262,y:614,t:1527019966687};\\\", \\\"{x:1262,y:608,t:1527019966704};\\\", \\\"{x:1262,y:602,t:1527019966722};\\\", \\\"{x:1262,y:600,t:1527019966737};\\\", \\\"{x:1262,y:596,t:1527019966755};\\\", \\\"{x:1262,y:593,t:1527019966771};\\\", \\\"{x:1262,y:591,t:1527019966787};\\\", \\\"{x:1262,y:589,t:1527019966805};\\\", \\\"{x:1262,y:591,t:1527019967004};\\\", \\\"{x:1262,y:611,t:1527019967022};\\\", \\\"{x:1262,y:635,t:1527019967039};\\\", \\\"{x:1262,y:657,t:1527019967054};\\\", \\\"{x:1262,y:679,t:1527019967072};\\\", \\\"{x:1260,y:701,t:1527019967089};\\\", \\\"{x:1258,y:715,t:1527019967104};\\\", \\\"{x:1255,y:725,t:1527019967122};\\\", \\\"{x:1253,y:734,t:1527019967139};\\\", \\\"{x:1249,y:742,t:1527019967154};\\\", \\\"{x:1248,y:749,t:1527019967172};\\\", \\\"{x:1245,y:756,t:1527019967188};\\\", \\\"{x:1245,y:758,t:1527019967204};\\\", \\\"{x:1243,y:763,t:1527019967222};\\\", \\\"{x:1240,y:770,t:1527019967239};\\\", \\\"{x:1236,y:776,t:1527019967256};\\\", \\\"{x:1232,y:782,t:1527019967271};\\\", \\\"{x:1228,y:787,t:1527019967289};\\\", \\\"{x:1225,y:791,t:1527019967305};\\\", \\\"{x:1222,y:797,t:1527019967321};\\\", \\\"{x:1218,y:805,t:1527019967338};\\\", \\\"{x:1215,y:811,t:1527019967356};\\\", \\\"{x:1213,y:817,t:1527019967372};\\\", \\\"{x:1211,y:825,t:1527019967388};\\\", \\\"{x:1210,y:829,t:1527019967404};\\\", \\\"{x:1209,y:836,t:1527019967423};\\\", \\\"{x:1209,y:842,t:1527019967439};\\\", \\\"{x:1209,y:847,t:1527019967456};\\\", \\\"{x:1209,y:851,t:1527019967472};\\\", \\\"{x:1209,y:852,t:1527019967488};\\\", \\\"{x:1209,y:853,t:1527019967532};\\\", \\\"{x:1210,y:855,t:1527019967548};\\\", \\\"{x:1212,y:859,t:1527019967556};\\\", \\\"{x:1215,y:862,t:1527019967571};\\\", \\\"{x:1232,y:874,t:1527019967588};\\\", \\\"{x:1246,y:883,t:1527019967606};\\\", \\\"{x:1261,y:894,t:1527019967622};\\\", \\\"{x:1277,y:904,t:1527019967639};\\\", \\\"{x:1293,y:914,t:1527019967656};\\\", \\\"{x:1309,y:923,t:1527019967671};\\\", \\\"{x:1327,y:933,t:1527019967689};\\\", \\\"{x:1337,y:936,t:1527019967706};\\\", \\\"{x:1348,y:938,t:1527019967723};\\\", \\\"{x:1359,y:938,t:1527019967739};\\\", \\\"{x:1371,y:938,t:1527019967756};\\\", \\\"{x:1383,y:936,t:1527019967772};\\\", \\\"{x:1388,y:934,t:1527019967789};\\\", \\\"{x:1392,y:931,t:1527019967806};\\\", \\\"{x:1397,y:927,t:1527019967822};\\\", \\\"{x:1402,y:923,t:1527019967838};\\\", \\\"{x:1408,y:915,t:1527019967855};\\\", \\\"{x:1413,y:909,t:1527019967873};\\\", \\\"{x:1419,y:902,t:1527019967889};\\\", \\\"{x:1423,y:897,t:1527019967906};\\\", \\\"{x:1424,y:895,t:1527019967922};\\\", \\\"{x:1425,y:893,t:1527019967939};\\\", \\\"{x:1426,y:892,t:1527019967956};\\\", \\\"{x:1426,y:890,t:1527019967972};\\\", \\\"{x:1426,y:887,t:1527019967988};\\\", \\\"{x:1426,y:881,t:1527019968006};\\\", \\\"{x:1424,y:869,t:1527019968023};\\\", \\\"{x:1421,y:854,t:1527019968038};\\\", \\\"{x:1419,y:840,t:1527019968056};\\\", \\\"{x:1415,y:825,t:1527019968073};\\\", \\\"{x:1408,y:811,t:1527019968089};\\\", \\\"{x:1402,y:797,t:1527019968106};\\\", \\\"{x:1397,y:785,t:1527019968123};\\\", \\\"{x:1392,y:776,t:1527019968140};\\\", \\\"{x:1389,y:769,t:1527019968156};\\\", \\\"{x:1385,y:763,t:1527019968172};\\\", \\\"{x:1382,y:759,t:1527019968189};\\\", \\\"{x:1378,y:755,t:1527019968206};\\\", \\\"{x:1375,y:753,t:1527019968223};\\\", \\\"{x:1366,y:748,t:1527019968239};\\\", \\\"{x:1357,y:744,t:1527019968255};\\\", \\\"{x:1347,y:739,t:1527019968272};\\\", \\\"{x:1342,y:738,t:1527019968289};\\\", \\\"{x:1340,y:737,t:1527019968306};\\\", \\\"{x:1339,y:737,t:1527019968373};\\\", \\\"{x:1338,y:735,t:1527019968492};\\\", \\\"{x:1338,y:731,t:1527019968506};\\\", \\\"{x:1338,y:724,t:1527019968523};\\\", \\\"{x:1336,y:713,t:1527019968540};\\\", \\\"{x:1335,y:702,t:1527019968556};\\\", \\\"{x:1334,y:695,t:1527019968572};\\\", \\\"{x:1333,y:690,t:1527019968590};\\\", \\\"{x:1333,y:688,t:1527019968606};\\\", \\\"{x:1333,y:692,t:1527019968789};\\\", \\\"{x:1333,y:705,t:1527019968806};\\\", \\\"{x:1337,y:718,t:1527019968822};\\\", \\\"{x:1342,y:731,t:1527019968840};\\\", \\\"{x:1346,y:747,t:1527019968859};\\\", \\\"{x:1351,y:761,t:1527019968873};\\\", \\\"{x:1354,y:768,t:1527019968889};\\\", \\\"{x:1356,y:771,t:1527019968906};\\\", \\\"{x:1356,y:770,t:1527019969220};\\\", \\\"{x:1355,y:767,t:1527019969227};\\\", \\\"{x:1355,y:764,t:1527019969239};\\\", \\\"{x:1354,y:760,t:1527019969256};\\\", \\\"{x:1352,y:757,t:1527019969273};\\\", \\\"{x:1352,y:753,t:1527019969290};\\\", \\\"{x:1351,y:750,t:1527019969306};\\\", \\\"{x:1350,y:747,t:1527019969324};\\\", \\\"{x:1349,y:745,t:1527019969339};\\\", \\\"{x:1349,y:744,t:1527019969363};\\\", \\\"{x:1348,y:743,t:1527019969374};\\\", \\\"{x:1348,y:742,t:1527019969389};\\\", \\\"{x:1348,y:741,t:1527019969406};\\\", \\\"{x:1348,y:737,t:1527019969423};\\\", \\\"{x:1347,y:733,t:1527019969440};\\\", \\\"{x:1347,y:728,t:1527019969457};\\\", \\\"{x:1344,y:722,t:1527019969474};\\\", \\\"{x:1344,y:717,t:1527019969490};\\\", \\\"{x:1343,y:715,t:1527019969506};\\\", \\\"{x:1343,y:710,t:1527019969524};\\\", \\\"{x:1343,y:708,t:1527019969540};\\\", \\\"{x:1343,y:707,t:1527019969557};\\\", \\\"{x:1343,y:704,t:1527019969573};\\\", \\\"{x:1342,y:702,t:1527019969591};\\\", \\\"{x:1342,y:700,t:1527019969606};\\\", \\\"{x:1342,y:697,t:1527019969624};\\\", \\\"{x:1342,y:696,t:1527019969641};\\\", \\\"{x:1341,y:695,t:1527019969658};\\\", \\\"{x:1341,y:694,t:1527019969674};\\\", \\\"{x:1341,y:702,t:1527019970021};\\\", \\\"{x:1341,y:709,t:1527019970029};\\\", \\\"{x:1341,y:718,t:1527019970042};\\\", \\\"{x:1341,y:735,t:1527019970058};\\\", \\\"{x:1341,y:751,t:1527019970074};\\\", \\\"{x:1342,y:761,t:1527019970091};\\\", \\\"{x:1344,y:773,t:1527019970108};\\\", \\\"{x:1344,y:777,t:1527019970124};\\\", \\\"{x:1347,y:783,t:1527019970141};\\\", \\\"{x:1347,y:784,t:1527019970157};\\\", \\\"{x:1347,y:787,t:1527019970174};\\\", \\\"{x:1347,y:788,t:1527019970191};\\\", \\\"{x:1347,y:789,t:1527019970207};\\\", \\\"{x:1347,y:788,t:1527019970556};\\\", \\\"{x:1347,y:786,t:1527019970564};\\\", \\\"{x:1347,y:784,t:1527019970580};\\\", \\\"{x:1347,y:783,t:1527019970591};\\\", \\\"{x:1346,y:782,t:1527019970608};\\\", \\\"{x:1346,y:781,t:1527019970624};\\\", \\\"{x:1346,y:780,t:1527019970640};\\\", \\\"{x:1346,y:779,t:1527019970660};\\\", \\\"{x:1345,y:779,t:1527019970957};\\\", \\\"{x:1344,y:776,t:1527019970975};\\\", \\\"{x:1344,y:774,t:1527019970992};\\\", \\\"{x:1344,y:773,t:1527019971012};\\\", \\\"{x:1344,y:772,t:1527019971025};\\\", \\\"{x:1344,y:771,t:1527019971041};\\\", \\\"{x:1344,y:770,t:1527019971058};\\\", \\\"{x:1343,y:769,t:1527019971075};\\\", \\\"{x:1343,y:768,t:1527019971092};\\\", \\\"{x:1343,y:764,t:1527019971421};\\\", \\\"{x:1343,y:757,t:1527019971443};\\\", \\\"{x:1342,y:752,t:1527019971459};\\\", \\\"{x:1342,y:749,t:1527019971474};\\\", \\\"{x:1342,y:745,t:1527019971492};\\\", \\\"{x:1341,y:742,t:1527019971508};\\\", \\\"{x:1341,y:736,t:1527019971525};\\\", \\\"{x:1339,y:730,t:1527019971542};\\\", \\\"{x:1338,y:724,t:1527019971559};\\\", \\\"{x:1337,y:716,t:1527019971575};\\\", \\\"{x:1337,y:714,t:1527019971591};\\\", \\\"{x:1337,y:711,t:1527019971608};\\\", \\\"{x:1336,y:711,t:1527019972156};\\\", \\\"{x:1331,y:707,t:1527019972163};\\\", \\\"{x:1328,y:701,t:1527019972175};\\\", \\\"{x:1321,y:690,t:1527019972192};\\\", \\\"{x:1320,y:684,t:1527019972208};\\\", \\\"{x:1316,y:678,t:1527019972225};\\\", \\\"{x:1315,y:675,t:1527019972243};\\\", \\\"{x:1314,y:675,t:1527019972324};\\\", \\\"{x:1307,y:692,t:1527019972343};\\\", \\\"{x:1303,y:714,t:1527019972359};\\\", \\\"{x:1301,y:732,t:1527019972376};\\\", \\\"{x:1301,y:743,t:1527019972393};\\\", \\\"{x:1302,y:748,t:1527019972409};\\\", \\\"{x:1303,y:752,t:1527019972425};\\\", \\\"{x:1306,y:756,t:1527019972443};\\\", \\\"{x:1312,y:762,t:1527019972458};\\\", \\\"{x:1322,y:773,t:1527019972476};\\\", \\\"{x:1332,y:781,t:1527019972492};\\\", \\\"{x:1341,y:787,t:1527019972509};\\\", \\\"{x:1348,y:790,t:1527019972526};\\\", \\\"{x:1352,y:791,t:1527019972543};\\\", \\\"{x:1352,y:792,t:1527019972560};\\\", \\\"{x:1353,y:792,t:1527019972576};\\\", \\\"{x:1355,y:792,t:1527019972596};\\\", \\\"{x:1357,y:792,t:1527019972610};\\\", \\\"{x:1359,y:792,t:1527019972625};\\\", \\\"{x:1361,y:791,t:1527019972644};\\\", \\\"{x:1361,y:790,t:1527019972693};\\\", \\\"{x:1360,y:787,t:1527019972710};\\\", \\\"{x:1357,y:784,t:1527019972726};\\\", \\\"{x:1356,y:781,t:1527019972743};\\\", \\\"{x:1354,y:780,t:1527019972759};\\\", \\\"{x:1350,y:777,t:1527019972776};\\\", \\\"{x:1345,y:773,t:1527019972793};\\\", \\\"{x:1343,y:771,t:1527019972810};\\\", \\\"{x:1340,y:768,t:1527019972826};\\\", \\\"{x:1339,y:767,t:1527019972842};\\\", \\\"{x:1338,y:765,t:1527019972860};\\\", \\\"{x:1338,y:764,t:1527019973773};\\\", \\\"{x:1339,y:763,t:1527019973780};\\\", \\\"{x:1342,y:762,t:1527019973794};\\\", \\\"{x:1344,y:761,t:1527019973809};\\\", \\\"{x:1345,y:760,t:1527019973827};\\\", \\\"{x:1346,y:760,t:1527019973843};\\\", \\\"{x:1345,y:760,t:1527019976108};\\\", \\\"{x:1344,y:760,t:1527019976124};\\\", \\\"{x:1343,y:760,t:1527019976148};\\\", \\\"{x:1343,y:761,t:1527019976171};\\\", \\\"{x:1341,y:761,t:1527019976196};\\\", \\\"{x:1337,y:766,t:1527019976211};\\\", \\\"{x:1333,y:770,t:1527019976229};\\\", \\\"{x:1331,y:773,t:1527019976245};\\\", \\\"{x:1330,y:775,t:1527019976262};\\\", \\\"{x:1328,y:777,t:1527019976279};\\\", \\\"{x:1324,y:780,t:1527019976296};\\\", \\\"{x:1314,y:786,t:1527019976312};\\\", \\\"{x:1306,y:793,t:1527019976329};\\\", \\\"{x:1300,y:797,t:1527019976346};\\\", \\\"{x:1297,y:800,t:1527019976366};\\\", \\\"{x:1294,y:803,t:1527019976384};\\\", \\\"{x:1290,y:810,t:1527019976400};\\\", \\\"{x:1286,y:816,t:1527019976416};\\\", \\\"{x:1282,y:820,t:1527019976433};\\\", \\\"{x:1276,y:825,t:1527019976451};\\\", \\\"{x:1269,y:829,t:1527019976467};\\\", \\\"{x:1266,y:831,t:1527019976483};\\\", \\\"{x:1257,y:835,t:1527019976500};\\\", \\\"{x:1252,y:837,t:1527019976517};\\\", \\\"{x:1251,y:838,t:1527019976533};\\\", \\\"{x:1247,y:838,t:1527019976551};\\\", \\\"{x:1244,y:840,t:1527019976567};\\\", \\\"{x:1239,y:840,t:1527019976583};\\\", \\\"{x:1232,y:841,t:1527019976600};\\\", \\\"{x:1228,y:841,t:1527019976617};\\\", \\\"{x:1226,y:841,t:1527019976634};\\\", \\\"{x:1225,y:841,t:1527019976651};\\\", \\\"{x:1224,y:841,t:1527019978368};\\\", \\\"{x:1223,y:841,t:1527019979288};\\\", \\\"{x:1222,y:841,t:1527019979312};\\\", \\\"{x:1221,y:840,t:1527019980001};\\\", \\\"{x:1218,y:832,t:1527019980008};\\\", \\\"{x:1214,y:821,t:1527019980020};\\\", \\\"{x:1210,y:807,t:1527019980037};\\\", \\\"{x:1209,y:799,t:1527019980053};\\\", \\\"{x:1209,y:797,t:1527019980072};\\\", \\\"{x:1211,y:796,t:1527019980086};\\\", \\\"{x:1213,y:795,t:1527019980104};\\\", \\\"{x:1212,y:795,t:1527019980945};\\\", \\\"{x:1211,y:795,t:1527019980953};\\\", \\\"{x:1210,y:795,t:1527019980976};\\\", \\\"{x:1209,y:795,t:1527019980992};\\\", \\\"{x:1208,y:795,t:1527019981002};\\\", \\\"{x:1207,y:795,t:1527019981020};\\\", \\\"{x:1206,y:795,t:1527019981037};\\\", \\\"{x:1205,y:795,t:1527019981053};\\\", \\\"{x:1202,y:795,t:1527019981070};\\\", \\\"{x:1199,y:795,t:1527019981087};\\\", \\\"{x:1194,y:794,t:1527019981103};\\\", \\\"{x:1189,y:793,t:1527019981120};\\\", \\\"{x:1187,y:791,t:1527019981137};\\\", \\\"{x:1187,y:790,t:1527019981480};\\\", \\\"{x:1188,y:791,t:1527019981625};\\\", \\\"{x:1193,y:798,t:1527019981638};\\\", \\\"{x:1198,y:805,t:1527019981654};\\\", \\\"{x:1198,y:803,t:1527019982152};\\\", \\\"{x:1198,y:802,t:1527019982160};\\\", \\\"{x:1198,y:799,t:1527019982176};\\\", \\\"{x:1198,y:798,t:1527019982208};\\\", \\\"{x:1198,y:797,t:1527019982248};\\\", \\\"{x:1198,y:795,t:1527019982265};\\\", \\\"{x:1198,y:793,t:1527019982280};\\\", \\\"{x:1198,y:792,t:1527019982288};\\\", \\\"{x:1201,y:786,t:1527019982304};\\\", \\\"{x:1203,y:780,t:1527019982322};\\\", \\\"{x:1210,y:773,t:1527019982338};\\\", \\\"{x:1215,y:766,t:1527019982354};\\\", \\\"{x:1221,y:759,t:1527019982373};\\\", \\\"{x:1231,y:748,t:1527019982388};\\\", \\\"{x:1239,y:741,t:1527019982404};\\\", \\\"{x:1249,y:733,t:1527019982421};\\\", \\\"{x:1254,y:728,t:1527019982439};\\\", \\\"{x:1259,y:724,t:1527019982455};\\\", \\\"{x:1264,y:720,t:1527019982471};\\\", \\\"{x:1269,y:716,t:1527019982488};\\\", \\\"{x:1275,y:712,t:1527019982505};\\\", \\\"{x:1282,y:708,t:1527019982522};\\\", \\\"{x:1296,y:702,t:1527019982538};\\\", \\\"{x:1311,y:697,t:1527019982555};\\\", \\\"{x:1329,y:693,t:1527019982572};\\\", \\\"{x:1351,y:692,t:1527019982588};\\\", \\\"{x:1366,y:692,t:1527019982606};\\\", \\\"{x:1370,y:692,t:1527019982621};\\\", \\\"{x:1371,y:692,t:1527019982639};\\\", \\\"{x:1373,y:692,t:1527019983008};\\\", \\\"{x:1381,y:692,t:1527019983023};\\\", \\\"{x:1388,y:697,t:1527019983039};\\\", \\\"{x:1403,y:707,t:1527019983055};\\\", \\\"{x:1439,y:733,t:1527019983072};\\\", \\\"{x:1456,y:745,t:1527019983088};\\\", \\\"{x:1469,y:754,t:1527019983105};\\\", \\\"{x:1478,y:761,t:1527019983122};\\\", \\\"{x:1482,y:765,t:1527019983138};\\\", \\\"{x:1486,y:770,t:1527019983156};\\\", \\\"{x:1488,y:774,t:1527019983172};\\\", \\\"{x:1491,y:776,t:1527019983188};\\\", \\\"{x:1492,y:778,t:1527019983205};\\\", \\\"{x:1493,y:780,t:1527019983222};\\\", \\\"{x:1494,y:781,t:1527019983238};\\\", \\\"{x:1496,y:785,t:1527019983255};\\\", \\\"{x:1497,y:793,t:1527019983272};\\\", \\\"{x:1497,y:797,t:1527019983288};\\\", \\\"{x:1498,y:800,t:1527019983306};\\\", \\\"{x:1499,y:801,t:1527019983322};\\\", \\\"{x:1500,y:803,t:1527019983339};\\\", \\\"{x:1500,y:804,t:1527019983368};\\\", \\\"{x:1500,y:806,t:1527019983376};\\\", \\\"{x:1500,y:807,t:1527019983390};\\\", \\\"{x:1499,y:810,t:1527019983406};\\\", \\\"{x:1497,y:814,t:1527019983423};\\\", \\\"{x:1495,y:821,t:1527019983439};\\\", \\\"{x:1492,y:827,t:1527019983455};\\\", \\\"{x:1490,y:834,t:1527019983472};\\\", \\\"{x:1488,y:838,t:1527019983488};\\\", \\\"{x:1487,y:839,t:1527019983506};\\\", \\\"{x:1487,y:840,t:1527019983523};\\\", \\\"{x:1486,y:840,t:1527019984280};\\\", \\\"{x:1483,y:840,t:1527019984295};\\\", \\\"{x:1480,y:840,t:1527019984306};\\\", \\\"{x:1475,y:840,t:1527019984323};\\\", \\\"{x:1468,y:840,t:1527019984338};\\\", \\\"{x:1463,y:840,t:1527019984356};\\\", \\\"{x:1460,y:839,t:1527019984373};\\\", \\\"{x:1458,y:839,t:1527019984389};\\\", \\\"{x:1457,y:839,t:1527019984406};\\\", \\\"{x:1456,y:839,t:1527019984423};\\\", \\\"{x:1455,y:839,t:1527019984439};\\\", \\\"{x:1454,y:839,t:1527019984456};\\\", \\\"{x:1453,y:839,t:1527019984473};\\\", \\\"{x:1450,y:839,t:1527019984489};\\\", \\\"{x:1446,y:838,t:1527019984507};\\\", \\\"{x:1442,y:836,t:1527019984523};\\\", \\\"{x:1436,y:836,t:1527019984540};\\\", \\\"{x:1429,y:836,t:1527019984556};\\\", \\\"{x:1420,y:835,t:1527019984573};\\\", \\\"{x:1415,y:833,t:1527019984588};\\\", \\\"{x:1410,y:832,t:1527019984606};\\\", \\\"{x:1399,y:832,t:1527019984622};\\\", \\\"{x:1382,y:829,t:1527019984639};\\\", \\\"{x:1368,y:827,t:1527019984656};\\\", \\\"{x:1354,y:826,t:1527019984673};\\\", \\\"{x:1342,y:823,t:1527019984690};\\\", \\\"{x:1337,y:823,t:1527019984706};\\\", \\\"{x:1335,y:823,t:1527019984723};\\\", \\\"{x:1339,y:820,t:1527019987888};\\\", \\\"{x:1349,y:816,t:1527019987896};\\\", \\\"{x:1360,y:811,t:1527019987909};\\\", \\\"{x:1385,y:806,t:1527019987925};\\\", \\\"{x:1397,y:806,t:1527019987943};\\\", \\\"{x:1400,y:807,t:1527019987960};\\\", \\\"{x:1401,y:807,t:1527019987975};\\\", \\\"{x:1402,y:808,t:1527019987992};\\\", \\\"{x:1404,y:809,t:1527019988010};\\\", \\\"{x:1405,y:810,t:1527019988025};\\\", \\\"{x:1406,y:810,t:1527019988043};\\\", \\\"{x:1408,y:810,t:1527019988063};\\\", \\\"{x:1409,y:810,t:1527019988076};\\\", \\\"{x:1421,y:810,t:1527019988092};\\\", \\\"{x:1437,y:803,t:1527019988109};\\\", \\\"{x:1448,y:799,t:1527019988125};\\\", \\\"{x:1457,y:794,t:1527019988142};\\\", \\\"{x:1467,y:789,t:1527019988159};\\\", \\\"{x:1469,y:787,t:1527019988175};\\\", \\\"{x:1471,y:786,t:1527019988192};\\\", \\\"{x:1472,y:786,t:1527019988209};\\\", \\\"{x:1473,y:785,t:1527019988226};\\\", \\\"{x:1470,y:785,t:1527019988520};\\\", \\\"{x:1461,y:790,t:1527019988528};\\\", \\\"{x:1456,y:796,t:1527019988543};\\\", \\\"{x:1440,y:826,t:1527019988560};\\\", \\\"{x:1430,y:849,t:1527019988576};\\\", \\\"{x:1421,y:872,t:1527019988594};\\\", \\\"{x:1412,y:892,t:1527019988610};\\\", \\\"{x:1406,y:907,t:1527019988627};\\\", \\\"{x:1401,y:919,t:1527019988643};\\\", \\\"{x:1397,y:934,t:1527019988660};\\\", \\\"{x:1397,y:944,t:1527019988677};\\\", \\\"{x:1394,y:958,t:1527019988694};\\\", \\\"{x:1394,y:969,t:1527019988709};\\\", \\\"{x:1394,y:977,t:1527019988726};\\\", \\\"{x:1393,y:990,t:1527019988743};\\\", \\\"{x:1392,y:1000,t:1527019988760};\\\", \\\"{x:1392,y:1003,t:1527019988776};\\\", \\\"{x:1392,y:1006,t:1527019988793};\\\", \\\"{x:1392,y:1007,t:1527019988912};\\\", \\\"{x:1394,y:1006,t:1527019988927};\\\", \\\"{x:1406,y:997,t:1527019988944};\\\", \\\"{x:1410,y:991,t:1527019988959};\\\", \\\"{x:1414,y:987,t:1527019988976};\\\", \\\"{x:1415,y:984,t:1527019988994};\\\", \\\"{x:1416,y:981,t:1527019989010};\\\", \\\"{x:1417,y:978,t:1527019989027};\\\", \\\"{x:1418,y:976,t:1527019989043};\\\", \\\"{x:1418,y:974,t:1527019989061};\\\", \\\"{x:1419,y:972,t:1527019989076};\\\", \\\"{x:1420,y:969,t:1527019989094};\\\", \\\"{x:1421,y:967,t:1527019989111};\\\", \\\"{x:1421,y:965,t:1527019989127};\\\", \\\"{x:1421,y:964,t:1527019989144};\\\", \\\"{x:1422,y:963,t:1527019989160};\\\", \\\"{x:1421,y:962,t:1527019992896};\\\", \\\"{x:1413,y:951,t:1527019992913};\\\", \\\"{x:1405,y:942,t:1527019992930};\\\", \\\"{x:1391,y:930,t:1527019992947};\\\", \\\"{x:1377,y:919,t:1527019992963};\\\", \\\"{x:1360,y:905,t:1527019992980};\\\", \\\"{x:1349,y:893,t:1527019992996};\\\", \\\"{x:1339,y:880,t:1527019993014};\\\", \\\"{x:1335,y:871,t:1527019993029};\\\", \\\"{x:1331,y:865,t:1527019993046};\\\", \\\"{x:1326,y:852,t:1527019993064};\\\", \\\"{x:1323,y:844,t:1527019993080};\\\", \\\"{x:1322,y:838,t:1527019993097};\\\", \\\"{x:1320,y:832,t:1527019993114};\\\", \\\"{x:1320,y:827,t:1527019993129};\\\", \\\"{x:1319,y:823,t:1527019993147};\\\", \\\"{x:1319,y:817,t:1527019993164};\\\", \\\"{x:1319,y:809,t:1527019993180};\\\", \\\"{x:1319,y:804,t:1527019993196};\\\", \\\"{x:1319,y:797,t:1527019993213};\\\", \\\"{x:1319,y:791,t:1527019993229};\\\", \\\"{x:1319,y:785,t:1527019993246};\\\", \\\"{x:1319,y:781,t:1527019993263};\\\", \\\"{x:1319,y:779,t:1527019993279};\\\", \\\"{x:1319,y:778,t:1527019993296};\\\", \\\"{x:1319,y:776,t:1527019993313};\\\", \\\"{x:1319,y:775,t:1527019993330};\\\", \\\"{x:1319,y:773,t:1527019993346};\\\", \\\"{x:1320,y:771,t:1527019993363};\\\", \\\"{x:1320,y:769,t:1527019993391};\\\", \\\"{x:1321,y:766,t:1527019993407};\\\", \\\"{x:1323,y:764,t:1527019993415};\\\", \\\"{x:1323,y:763,t:1527019993430};\\\", \\\"{x:1325,y:760,t:1527019993447};\\\", \\\"{x:1327,y:758,t:1527019993463};\\\", \\\"{x:1327,y:756,t:1527019993480};\\\", \\\"{x:1328,y:754,t:1527019993496};\\\", \\\"{x:1330,y:752,t:1527019993520};\\\", \\\"{x:1330,y:751,t:1527019993530};\\\", \\\"{x:1331,y:747,t:1527019993546};\\\", \\\"{x:1334,y:742,t:1527019993563};\\\", \\\"{x:1334,y:739,t:1527019993580};\\\", \\\"{x:1334,y:736,t:1527019993597};\\\", \\\"{x:1335,y:734,t:1527019993613};\\\", \\\"{x:1335,y:733,t:1527019993631};\\\", \\\"{x:1336,y:732,t:1527019993646};\\\", \\\"{x:1336,y:731,t:1527019993671};\\\", \\\"{x:1336,y:730,t:1527019993776};\\\", \\\"{x:1336,y:729,t:1527019993784};\\\", \\\"{x:1336,y:727,t:1527019993797};\\\", \\\"{x:1336,y:724,t:1527019993814};\\\", \\\"{x:1336,y:720,t:1527019993831};\\\", \\\"{x:1337,y:712,t:1527019993847};\\\", \\\"{x:1339,y:703,t:1527019993864};\\\", \\\"{x:1340,y:699,t:1527019993881};\\\", \\\"{x:1340,y:697,t:1527019993897};\\\", \\\"{x:1341,y:696,t:1527019993914};\\\", \\\"{x:1341,y:694,t:1527019993936};\\\", \\\"{x:1341,y:692,t:1527019993947};\\\", \\\"{x:1340,y:686,t:1527019993964};\\\", \\\"{x:1340,y:682,t:1527019993981};\\\", \\\"{x:1338,y:677,t:1527019993998};\\\", \\\"{x:1337,y:671,t:1527019994014};\\\", \\\"{x:1334,y:664,t:1527019994030};\\\", \\\"{x:1334,y:662,t:1527019994048};\\\", \\\"{x:1334,y:660,t:1527019994064};\\\", \\\"{x:1334,y:655,t:1527019994081};\\\", \\\"{x:1343,y:644,t:1527019994098};\\\", \\\"{x:1356,y:631,t:1527019994113};\\\", \\\"{x:1367,y:618,t:1527019994131};\\\", \\\"{x:1377,y:608,t:1527019994148};\\\", \\\"{x:1391,y:598,t:1527019994164};\\\", \\\"{x:1409,y:584,t:1527019994180};\\\", \\\"{x:1429,y:573,t:1527019994198};\\\", \\\"{x:1441,y:564,t:1527019994214};\\\", \\\"{x:1447,y:558,t:1527019994230};\\\", \\\"{x:1453,y:552,t:1527019994248};\\\", \\\"{x:1463,y:544,t:1527019994264};\\\", \\\"{x:1466,y:541,t:1527019994281};\\\", \\\"{x:1468,y:538,t:1527019994297};\\\", \\\"{x:1468,y:537,t:1527019994319};\\\", \\\"{x:1467,y:538,t:1527019994409};\\\", \\\"{x:1465,y:539,t:1527019994415};\\\", \\\"{x:1463,y:541,t:1527019994431};\\\", \\\"{x:1461,y:549,t:1527019994448};\\\", \\\"{x:1461,y:557,t:1527019994464};\\\", \\\"{x:1461,y:568,t:1527019994481};\\\", \\\"{x:1461,y:577,t:1527019994497};\\\", \\\"{x:1461,y:585,t:1527019994515};\\\", \\\"{x:1461,y:595,t:1527019994531};\\\", \\\"{x:1463,y:603,t:1527019994548};\\\", \\\"{x:1465,y:609,t:1527019994565};\\\", \\\"{x:1467,y:617,t:1527019994581};\\\", \\\"{x:1468,y:624,t:1527019994597};\\\", \\\"{x:1468,y:628,t:1527019994614};\\\", \\\"{x:1468,y:631,t:1527019994630};\\\", \\\"{x:1468,y:632,t:1527019994663};\\\", \\\"{x:1468,y:635,t:1527019994671};\\\", \\\"{x:1468,y:638,t:1527019994681};\\\", \\\"{x:1468,y:646,t:1527019994698};\\\", \\\"{x:1468,y:657,t:1527019994714};\\\", \\\"{x:1469,y:670,t:1527019994731};\\\", \\\"{x:1469,y:679,t:1527019994747};\\\", \\\"{x:1469,y:687,t:1527019994764};\\\", \\\"{x:1471,y:694,t:1527019994781};\\\", \\\"{x:1471,y:696,t:1527019994797};\\\", \\\"{x:1472,y:697,t:1527019994814};\\\", \\\"{x:1471,y:697,t:1527019994912};\\\", \\\"{x:1468,y:690,t:1527019994920};\\\", \\\"{x:1466,y:682,t:1527019994931};\\\", \\\"{x:1462,y:669,t:1527019994948};\\\", \\\"{x:1457,y:657,t:1527019994964};\\\", \\\"{x:1451,y:644,t:1527019994981};\\\", \\\"{x:1445,y:634,t:1527019994997};\\\", \\\"{x:1440,y:628,t:1527019995015};\\\", \\\"{x:1437,y:624,t:1527019995031};\\\", \\\"{x:1435,y:622,t:1527019995047};\\\", \\\"{x:1434,y:620,t:1527019995065};\\\", \\\"{x:1432,y:615,t:1527019995082};\\\", \\\"{x:1430,y:610,t:1527019995098};\\\", \\\"{x:1426,y:606,t:1527019995114};\\\", \\\"{x:1423,y:601,t:1527019995132};\\\", \\\"{x:1422,y:598,t:1527019995148};\\\", \\\"{x:1421,y:596,t:1527019995164};\\\", \\\"{x:1419,y:594,t:1527019995182};\\\", \\\"{x:1417,y:589,t:1527019995198};\\\", \\\"{x:1413,y:584,t:1527019995214};\\\", \\\"{x:1409,y:576,t:1527019995232};\\\", \\\"{x:1407,y:571,t:1527019995248};\\\", \\\"{x:1406,y:569,t:1527019995265};\\\", \\\"{x:1405,y:568,t:1527019995281};\\\", \\\"{x:1404,y:565,t:1527019995299};\\\", \\\"{x:1404,y:563,t:1527019995315};\\\", \\\"{x:1403,y:562,t:1527019995332};\\\", \\\"{x:1401,y:564,t:1527019995688};\\\", \\\"{x:1400,y:569,t:1527019995699};\\\", \\\"{x:1396,y:578,t:1527019995716};\\\", \\\"{x:1390,y:585,t:1527019995732};\\\", \\\"{x:1387,y:588,t:1527019995749};\\\", \\\"{x:1383,y:594,t:1527019995766};\\\", \\\"{x:1380,y:598,t:1527019995781};\\\", \\\"{x:1377,y:601,t:1527019995799};\\\", \\\"{x:1374,y:603,t:1527019995815};\\\", \\\"{x:1373,y:604,t:1527019995832};\\\", \\\"{x:1370,y:606,t:1527019995849};\\\", \\\"{x:1368,y:609,t:1527019995866};\\\", \\\"{x:1366,y:610,t:1527019995882};\\\", \\\"{x:1363,y:612,t:1527019995899};\\\", \\\"{x:1360,y:616,t:1527019995916};\\\", \\\"{x:1357,y:619,t:1527019995932};\\\", \\\"{x:1355,y:624,t:1527019995949};\\\", \\\"{x:1350,y:630,t:1527019995966};\\\", \\\"{x:1343,y:640,t:1527019995984};\\\", \\\"{x:1338,y:654,t:1527019995999};\\\", \\\"{x:1328,y:677,t:1527019996015};\\\", \\\"{x:1327,y:687,t:1527019996032};\\\", \\\"{x:1325,y:695,t:1527019996049};\\\", \\\"{x:1324,y:701,t:1527019996065};\\\", \\\"{x:1324,y:707,t:1527019996083};\\\", \\\"{x:1324,y:712,t:1527019996099};\\\", \\\"{x:1324,y:717,t:1527019996116};\\\", \\\"{x:1324,y:723,t:1527019996133};\\\", \\\"{x:1324,y:726,t:1527019996149};\\\", \\\"{x:1324,y:730,t:1527019996166};\\\", \\\"{x:1324,y:731,t:1527019996183};\\\", \\\"{x:1324,y:733,t:1527019996199};\\\", \\\"{x:1324,y:734,t:1527019996216};\\\", \\\"{x:1325,y:736,t:1527019996233};\\\", \\\"{x:1326,y:737,t:1527019996249};\\\", \\\"{x:1326,y:740,t:1527019996266};\\\", \\\"{x:1327,y:742,t:1527019996283};\\\", \\\"{x:1331,y:748,t:1527019996299};\\\", \\\"{x:1332,y:752,t:1527019996316};\\\", \\\"{x:1333,y:756,t:1527019996333};\\\", \\\"{x:1335,y:759,t:1527019996349};\\\", \\\"{x:1335,y:761,t:1527019996366};\\\", \\\"{x:1337,y:765,t:1527019996383};\\\", \\\"{x:1338,y:768,t:1527019996399};\\\", \\\"{x:1339,y:770,t:1527019996416};\\\", \\\"{x:1340,y:772,t:1527019996433};\\\", \\\"{x:1340,y:773,t:1527019996449};\\\", \\\"{x:1341,y:775,t:1527019996466};\\\", \\\"{x:1342,y:775,t:1527019996483};\\\", \\\"{x:1342,y:776,t:1527019996499};\\\", \\\"{x:1342,y:777,t:1527019996516};\\\", \\\"{x:1342,y:778,t:1527019996533};\\\", \\\"{x:1343,y:779,t:1527019996568};\\\", \\\"{x:1343,y:780,t:1527019996583};\\\", \\\"{x:1345,y:783,t:1527019996598};\\\", \\\"{x:1345,y:785,t:1527019996615};\\\", \\\"{x:1346,y:791,t:1527019996632};\\\", \\\"{x:1349,y:796,t:1527019996649};\\\", \\\"{x:1351,y:805,t:1527019996665};\\\", \\\"{x:1355,y:818,t:1527019996682};\\\", \\\"{x:1359,y:831,t:1527019996699};\\\", \\\"{x:1361,y:846,t:1527019996715};\\\", \\\"{x:1365,y:859,t:1527019996732};\\\", \\\"{x:1368,y:871,t:1527019996749};\\\", \\\"{x:1368,y:882,t:1527019996765};\\\", \\\"{x:1368,y:895,t:1527019996783};\\\", \\\"{x:1367,y:902,t:1527019996799};\\\", \\\"{x:1366,y:905,t:1527019996816};\\\", \\\"{x:1365,y:907,t:1527019996832};\\\", \\\"{x:1365,y:908,t:1527019996850};\\\", \\\"{x:1365,y:909,t:1527019996867};\\\", \\\"{x:1365,y:910,t:1527019996888};\\\", \\\"{x:1365,y:911,t:1527019996904};\\\", \\\"{x:1364,y:912,t:1527019996919};\\\", \\\"{x:1364,y:913,t:1527019996933};\\\", \\\"{x:1363,y:914,t:1527019996950};\\\", \\\"{x:1363,y:915,t:1527019996966};\\\", \\\"{x:1362,y:916,t:1527019996983};\\\", \\\"{x:1361,y:918,t:1527019996999};\\\", \\\"{x:1360,y:919,t:1527019997017};\\\", \\\"{x:1359,y:922,t:1527019997033};\\\", \\\"{x:1358,y:925,t:1527019997050};\\\", \\\"{x:1357,y:927,t:1527019997067};\\\", \\\"{x:1355,y:932,t:1527019997083};\\\", \\\"{x:1355,y:934,t:1527019997100};\\\", \\\"{x:1354,y:936,t:1527019997116};\\\", \\\"{x:1353,y:938,t:1527019997132};\\\", \\\"{x:1352,y:941,t:1527019997152};\\\", \\\"{x:1352,y:942,t:1527019997175};\\\", \\\"{x:1351,y:943,t:1527019997183};\\\", \\\"{x:1351,y:944,t:1527019997199};\\\", \\\"{x:1351,y:947,t:1527019997216};\\\", \\\"{x:1350,y:949,t:1527019997233};\\\", \\\"{x:1349,y:951,t:1527019997249};\\\", \\\"{x:1348,y:955,t:1527019997266};\\\", \\\"{x:1347,y:957,t:1527019997287};\\\", \\\"{x:1347,y:958,t:1527019997303};\\\", \\\"{x:1347,y:959,t:1527019997327};\\\", \\\"{x:1347,y:961,t:1527019997336};\\\", \\\"{x:1346,y:961,t:1527019997801};\\\", \\\"{x:1345,y:960,t:1527019998000};\\\", \\\"{x:1343,y:950,t:1527019998017};\\\", \\\"{x:1342,y:936,t:1527019998034};\\\", \\\"{x:1339,y:916,t:1527019998051};\\\", \\\"{x:1337,y:894,t:1527019998066};\\\", \\\"{x:1333,y:871,t:1527019998084};\\\", \\\"{x:1330,y:857,t:1527019998101};\\\", \\\"{x:1329,y:848,t:1527019998117};\\\", \\\"{x:1328,y:834,t:1527019998133};\\\", \\\"{x:1328,y:818,t:1527019998151};\\\", \\\"{x:1328,y:800,t:1527019998166};\\\", \\\"{x:1328,y:775,t:1527019998184};\\\", \\\"{x:1327,y:768,t:1527019998200};\\\", \\\"{x:1327,y:764,t:1527019998218};\\\", \\\"{x:1327,y:763,t:1527019998233};\\\", \\\"{x:1327,y:762,t:1527019998264};\\\", \\\"{x:1327,y:761,t:1527019998279};\\\", \\\"{x:1327,y:759,t:1527019998320};\\\", \\\"{x:1328,y:757,t:1527019998343};\\\", \\\"{x:1329,y:756,t:1527019998360};\\\", \\\"{x:1330,y:754,t:1527019998367};\\\", \\\"{x:1332,y:752,t:1527019998383};\\\", \\\"{x:1333,y:750,t:1527019998401};\\\", \\\"{x:1335,y:747,t:1527019998418};\\\", \\\"{x:1336,y:745,t:1527019998434};\\\", \\\"{x:1337,y:742,t:1527019998451};\\\", \\\"{x:1338,y:741,t:1527019998467};\\\", \\\"{x:1339,y:735,t:1527019998483};\\\", \\\"{x:1340,y:732,t:1527019998501};\\\", \\\"{x:1341,y:728,t:1527019998518};\\\", \\\"{x:1342,y:723,t:1527019998534};\\\", \\\"{x:1342,y:717,t:1527019998550};\\\", \\\"{x:1343,y:708,t:1527019998567};\\\", \\\"{x:1343,y:703,t:1527019998584};\\\", \\\"{x:1343,y:697,t:1527019998601};\\\", \\\"{x:1343,y:691,t:1527019998618};\\\", \\\"{x:1343,y:688,t:1527019998635};\\\", \\\"{x:1343,y:685,t:1527019998651};\\\", \\\"{x:1345,y:684,t:1527019998668};\\\", \\\"{x:1344,y:684,t:1527019999432};\\\", \\\"{x:1344,y:686,t:1527019999439};\\\", \\\"{x:1341,y:691,t:1527019999452};\\\", \\\"{x:1341,y:696,t:1527019999469};\\\", \\\"{x:1341,y:697,t:1527019999485};\\\", \\\"{x:1341,y:699,t:1527019999502};\\\", \\\"{x:1341,y:700,t:1527019999519};\\\", \\\"{x:1341,y:702,t:1527019999535};\\\", \\\"{x:1341,y:704,t:1527019999552};\\\", \\\"{x:1341,y:706,t:1527019999568};\\\", \\\"{x:1341,y:709,t:1527019999585};\\\", \\\"{x:1341,y:713,t:1527019999602};\\\", \\\"{x:1341,y:716,t:1527019999619};\\\", \\\"{x:1341,y:720,t:1527019999634};\\\", \\\"{x:1341,y:723,t:1527019999652};\\\", \\\"{x:1341,y:727,t:1527019999669};\\\", \\\"{x:1341,y:731,t:1527019999685};\\\", \\\"{x:1342,y:739,t:1527019999702};\\\", \\\"{x:1343,y:747,t:1527019999720};\\\", \\\"{x:1344,y:757,t:1527019999734};\\\", \\\"{x:1347,y:771,t:1527019999752};\\\", \\\"{x:1347,y:779,t:1527019999769};\\\", \\\"{x:1349,y:783,t:1527019999785};\\\", \\\"{x:1350,y:785,t:1527019999802};\\\", \\\"{x:1350,y:788,t:1527019999819};\\\", \\\"{x:1350,y:786,t:1527020000240};\\\", \\\"{x:1350,y:785,t:1527020000252};\\\", \\\"{x:1350,y:779,t:1527020000269};\\\", \\\"{x:1350,y:777,t:1527020000286};\\\", \\\"{x:1350,y:776,t:1527020000302};\\\", \\\"{x:1350,y:773,t:1527020000319};\\\", \\\"{x:1350,y:769,t:1527020000335};\\\", \\\"{x:1350,y:768,t:1527020000353};\\\", \\\"{x:1350,y:767,t:1527020000368};\\\", \\\"{x:1350,y:766,t:1527020000386};\\\", \\\"{x:1350,y:770,t:1527020000897};\\\", \\\"{x:1350,y:777,t:1527020000904};\\\", \\\"{x:1350,y:792,t:1527020000920};\\\", \\\"{x:1350,y:807,t:1527020000935};\\\", \\\"{x:1350,y:821,t:1527020000953};\\\", \\\"{x:1351,y:834,t:1527020000970};\\\", \\\"{x:1353,y:845,t:1527020000986};\\\", \\\"{x:1356,y:856,t:1527020001003};\\\", \\\"{x:1356,y:866,t:1527020001020};\\\", \\\"{x:1360,y:877,t:1527020001036};\\\", \\\"{x:1361,y:887,t:1527020001053};\\\", \\\"{x:1367,y:903,t:1527020001070};\\\", \\\"{x:1371,y:917,t:1527020001086};\\\", \\\"{x:1375,y:929,t:1527020001103};\\\", \\\"{x:1376,y:938,t:1527020001119};\\\", \\\"{x:1379,y:943,t:1527020001136};\\\", \\\"{x:1379,y:945,t:1527020001153};\\\", \\\"{x:1379,y:950,t:1527020001170};\\\", \\\"{x:1379,y:952,t:1527020001185};\\\", \\\"{x:1379,y:954,t:1527020001203};\\\", \\\"{x:1380,y:955,t:1527020001219};\\\", \\\"{x:1380,y:957,t:1527020001236};\\\", \\\"{x:1380,y:959,t:1527020001252};\\\", \\\"{x:1380,y:962,t:1527020001269};\\\", \\\"{x:1379,y:966,t:1527020001287};\\\", \\\"{x:1378,y:971,t:1527020001302};\\\", \\\"{x:1377,y:976,t:1527020001319};\\\", \\\"{x:1375,y:981,t:1527020001336};\\\", \\\"{x:1374,y:984,t:1527020001352};\\\", \\\"{x:1373,y:987,t:1527020001370};\\\", \\\"{x:1372,y:989,t:1527020001387};\\\", \\\"{x:1371,y:991,t:1527020001403};\\\", \\\"{x:1371,y:992,t:1527020001424};\\\", \\\"{x:1371,y:989,t:1527020001512};\\\", \\\"{x:1371,y:980,t:1527020001520};\\\", \\\"{x:1367,y:959,t:1527020001537};\\\", \\\"{x:1362,y:935,t:1527020001553};\\\", \\\"{x:1357,y:909,t:1527020001570};\\\", \\\"{x:1352,y:884,t:1527020001587};\\\", \\\"{x:1349,y:859,t:1527020001603};\\\", \\\"{x:1347,y:844,t:1527020001620};\\\", \\\"{x:1347,y:834,t:1527020001637};\\\", \\\"{x:1345,y:824,t:1527020001654};\\\", \\\"{x:1344,y:816,t:1527020001670};\\\", \\\"{x:1343,y:809,t:1527020001687};\\\", \\\"{x:1342,y:800,t:1527020001703};\\\", \\\"{x:1341,y:795,t:1527020001720};\\\", \\\"{x:1341,y:794,t:1527020001737};\\\", \\\"{x:1341,y:793,t:1527020001754};\\\", \\\"{x:1341,y:791,t:1527020001770};\\\", \\\"{x:1341,y:787,t:1527020001787};\\\", \\\"{x:1341,y:783,t:1527020001804};\\\", \\\"{x:1341,y:779,t:1527020001820};\\\", \\\"{x:1341,y:777,t:1527020001837};\\\", \\\"{x:1341,y:773,t:1527020001854};\\\", \\\"{x:1341,y:768,t:1527020001870};\\\", \\\"{x:1341,y:760,t:1527020001887};\\\", \\\"{x:1340,y:736,t:1527020001903};\\\", \\\"{x:1340,y:724,t:1527020001920};\\\", \\\"{x:1340,y:712,t:1527020001937};\\\", \\\"{x:1340,y:702,t:1527020001954};\\\", \\\"{x:1340,y:695,t:1527020001970};\\\", \\\"{x:1340,y:691,t:1527020001987};\\\", \\\"{x:1340,y:687,t:1527020002004};\\\", \\\"{x:1340,y:684,t:1527020002020};\\\", \\\"{x:1340,y:683,t:1527020002037};\\\", \\\"{x:1340,y:681,t:1527020002054};\\\", \\\"{x:1340,y:680,t:1527020002071};\\\", \\\"{x:1340,y:678,t:1527020002095};\\\", \\\"{x:1340,y:675,t:1527020002335};\\\", \\\"{x:1334,y:659,t:1527020002354};\\\", \\\"{x:1325,y:643,t:1527020002371};\\\", \\\"{x:1319,y:633,t:1527020002387};\\\", \\\"{x:1315,y:629,t:1527020002404};\\\", \\\"{x:1314,y:626,t:1527020002421};\\\", \\\"{x:1311,y:621,t:1527020002437};\\\", \\\"{x:1310,y:617,t:1527020002454};\\\", \\\"{x:1309,y:616,t:1527020002471};\\\", \\\"{x:1308,y:616,t:1527020002487};\\\", \\\"{x:1308,y:615,t:1527020002505};\\\", \\\"{x:1308,y:614,t:1527020002584};\\\", \\\"{x:1307,y:610,t:1527020002592};\\\", \\\"{x:1303,y:605,t:1527020002604};\\\", \\\"{x:1298,y:597,t:1527020002621};\\\", \\\"{x:1294,y:588,t:1527020002637};\\\", \\\"{x:1290,y:581,t:1527020002654};\\\", \\\"{x:1286,y:574,t:1527020002671};\\\", \\\"{x:1281,y:568,t:1527020002688};\\\", \\\"{x:1281,y:566,t:1527020002704};\\\", \\\"{x:1280,y:566,t:1527020002721};\\\", \\\"{x:1280,y:565,t:1527020002738};\\\", \\\"{x:1278,y:570,t:1527020015792};\\\", \\\"{x:1278,y:575,t:1527020015799};\\\", \\\"{x:1278,y:580,t:1527020015814};\\\", \\\"{x:1278,y:593,t:1527020015831};\\\", \\\"{x:1280,y:603,t:1527020015848};\\\", \\\"{x:1285,y:621,t:1527020015864};\\\", \\\"{x:1293,y:641,t:1527020015882};\\\", \\\"{x:1305,y:665,t:1527020015899};\\\", \\\"{x:1321,y:688,t:1527020015914};\\\", \\\"{x:1334,y:706,t:1527020015931};\\\", \\\"{x:1345,y:721,t:1527020015948};\\\", \\\"{x:1353,y:731,t:1527020015965};\\\", \\\"{x:1357,y:738,t:1527020015981};\\\", \\\"{x:1361,y:742,t:1527020015998};\\\", \\\"{x:1365,y:748,t:1527020016015};\\\", \\\"{x:1368,y:753,t:1527020016031};\\\", \\\"{x:1372,y:757,t:1527020016048};\\\", \\\"{x:1376,y:761,t:1527020016065};\\\", \\\"{x:1380,y:766,t:1527020016081};\\\", \\\"{x:1386,y:774,t:1527020016098};\\\", \\\"{x:1392,y:780,t:1527020016116};\\\", \\\"{x:1395,y:784,t:1527020016131};\\\", \\\"{x:1400,y:790,t:1527020016148};\\\", \\\"{x:1403,y:794,t:1527020016166};\\\", \\\"{x:1406,y:800,t:1527020016182};\\\", \\\"{x:1412,y:808,t:1527020016199};\\\", \\\"{x:1419,y:819,t:1527020016215};\\\", \\\"{x:1424,y:825,t:1527020016231};\\\", \\\"{x:1428,y:832,t:1527020016248};\\\", \\\"{x:1433,y:840,t:1527020016265};\\\", \\\"{x:1441,y:853,t:1527020016281};\\\", \\\"{x:1448,y:864,t:1527020016298};\\\", \\\"{x:1451,y:871,t:1527020016315};\\\", \\\"{x:1455,y:880,t:1527020016332};\\\", \\\"{x:1457,y:887,t:1527020016349};\\\", \\\"{x:1460,y:892,t:1527020016366};\\\", \\\"{x:1464,y:897,t:1527020016382};\\\", \\\"{x:1466,y:902,t:1527020016398};\\\", \\\"{x:1468,y:908,t:1527020016415};\\\", \\\"{x:1470,y:910,t:1527020016431};\\\", \\\"{x:1470,y:912,t:1527020016448};\\\", \\\"{x:1470,y:913,t:1527020016466};\\\", \\\"{x:1471,y:915,t:1527020016483};\\\", \\\"{x:1472,y:916,t:1527020016499};\\\", \\\"{x:1472,y:918,t:1527020016515};\\\", \\\"{x:1472,y:922,t:1527020016532};\\\", \\\"{x:1474,y:925,t:1527020016548};\\\", \\\"{x:1475,y:928,t:1527020016565};\\\", \\\"{x:1475,y:930,t:1527020016583};\\\", \\\"{x:1476,y:932,t:1527020016599};\\\", \\\"{x:1478,y:936,t:1527020016615};\\\", \\\"{x:1478,y:938,t:1527020016633};\\\", \\\"{x:1478,y:940,t:1527020016649};\\\", \\\"{x:1479,y:942,t:1527020016665};\\\", \\\"{x:1480,y:945,t:1527020016683};\\\", \\\"{x:1480,y:948,t:1527020016703};\\\", \\\"{x:1481,y:948,t:1527020016716};\\\", \\\"{x:1482,y:951,t:1527020016732};\\\", \\\"{x:1482,y:954,t:1527020016748};\\\", \\\"{x:1482,y:955,t:1527020016766};\\\", \\\"{x:1483,y:957,t:1527020016783};\\\", \\\"{x:1483,y:958,t:1527020016798};\\\", \\\"{x:1484,y:960,t:1527020016815};\\\", \\\"{x:1485,y:961,t:1527020016848};\\\", \\\"{x:1485,y:963,t:1527020016896};\\\", \\\"{x:1485,y:964,t:1527020017024};\\\", \\\"{x:1485,y:966,t:1527020017063};\\\", \\\"{x:1486,y:967,t:1527020017103};\\\", \\\"{x:1486,y:966,t:1527020017367};\\\", \\\"{x:1486,y:962,t:1527020017383};\\\", \\\"{x:1474,y:937,t:1527020017399};\\\", \\\"{x:1458,y:908,t:1527020017416};\\\", \\\"{x:1438,y:866,t:1527020017433};\\\", \\\"{x:1404,y:816,t:1527020017449};\\\", \\\"{x:1367,y:765,t:1527020017466};\\\", \\\"{x:1329,y:709,t:1527020017482};\\\", \\\"{x:1300,y:669,t:1527020017499};\\\", \\\"{x:1283,y:642,t:1527020017516};\\\", \\\"{x:1275,y:626,t:1527020017533};\\\", \\\"{x:1270,y:615,t:1527020017550};\\\", \\\"{x:1266,y:605,t:1527020017566};\\\", \\\"{x:1266,y:598,t:1527020017583};\\\", \\\"{x:1263,y:589,t:1527020017599};\\\", \\\"{x:1263,y:586,t:1527020017616};\\\", \\\"{x:1263,y:583,t:1527020017632};\\\", \\\"{x:1263,y:580,t:1527020017650};\\\", \\\"{x:1263,y:578,t:1527020017667};\\\", \\\"{x:1263,y:576,t:1527020017683};\\\", \\\"{x:1266,y:571,t:1527020017699};\\\", \\\"{x:1268,y:567,t:1527020017717};\\\", \\\"{x:1271,y:561,t:1527020017733};\\\", \\\"{x:1275,y:553,t:1527020017750};\\\", \\\"{x:1284,y:535,t:1527020017766};\\\", \\\"{x:1304,y:498,t:1527020017783};\\\", \\\"{x:1324,y:470,t:1527020017800};\\\", \\\"{x:1346,y:451,t:1527020017817};\\\", \\\"{x:1382,y:421,t:1527020017834};\\\", \\\"{x:1404,y:404,t:1527020017850};\\\", \\\"{x:1422,y:385,t:1527020017866};\\\", \\\"{x:1443,y:360,t:1527020017884};\\\", \\\"{x:1460,y:337,t:1527020017899};\\\", \\\"{x:1471,y:320,t:1527020017916};\\\", \\\"{x:1476,y:302,t:1527020017933};\\\", \\\"{x:1478,y:288,t:1527020017949};\\\", \\\"{x:1481,y:277,t:1527020017967};\\\", \\\"{x:1483,y:257,t:1527020017983};\\\", \\\"{x:1484,y:244,t:1527020018000};\\\", \\\"{x:1484,y:238,t:1527020018016};\\\", \\\"{x:1484,y:234,t:1527020018034};\\\", \\\"{x:1484,y:231,t:1527020018050};\\\", \\\"{x:1480,y:231,t:1527020018142};\\\", \\\"{x:1471,y:235,t:1527020018150};\\\", \\\"{x:1460,y:241,t:1527020018166};\\\", \\\"{x:1425,y:284,t:1527020018183};\\\", \\\"{x:1395,y:326,t:1527020018200};\\\", \\\"{x:1371,y:367,t:1527020018216};\\\", \\\"{x:1345,y:413,t:1527020018233};\\\", \\\"{x:1323,y:451,t:1527020018250};\\\", \\\"{x:1311,y:471,t:1527020018266};\\\", \\\"{x:1301,y:490,t:1527020018283};\\\", \\\"{x:1291,y:510,t:1527020018300};\\\", \\\"{x:1285,y:527,t:1527020018317};\\\", \\\"{x:1279,y:543,t:1527020018333};\\\", \\\"{x:1276,y:553,t:1527020018351};\\\", \\\"{x:1275,y:559,t:1527020018367};\\\", \\\"{x:1274,y:565,t:1527020018383};\\\", \\\"{x:1273,y:566,t:1527020018401};\\\", \\\"{x:1273,y:567,t:1527020018455};\\\", \\\"{x:1273,y:568,t:1527020019160};\\\", \\\"{x:1275,y:573,t:1527020019167};\\\", \\\"{x:1292,y:591,t:1527020019184};\\\", \\\"{x:1305,y:614,t:1527020019200};\\\", \\\"{x:1309,y:636,t:1527020019217};\\\", \\\"{x:1312,y:653,t:1527020019234};\\\", \\\"{x:1313,y:662,t:1527020019250};\\\", \\\"{x:1313,y:669,t:1527020019267};\\\", \\\"{x:1310,y:682,t:1527020019284};\\\", \\\"{x:1306,y:697,t:1527020019300};\\\", \\\"{x:1303,y:710,t:1527020019317};\\\", \\\"{x:1301,y:718,t:1527020019334};\\\", \\\"{x:1301,y:722,t:1527020019350};\\\", \\\"{x:1301,y:728,t:1527020019367};\\\", \\\"{x:1301,y:742,t:1527020019385};\\\", \\\"{x:1301,y:759,t:1527020019400};\\\", \\\"{x:1301,y:782,t:1527020019417};\\\", \\\"{x:1301,y:806,t:1527020019434};\\\", \\\"{x:1301,y:835,t:1527020019451};\\\", \\\"{x:1301,y:861,t:1527020019467};\\\", \\\"{x:1301,y:877,t:1527020019484};\\\", \\\"{x:1304,y:888,t:1527020019502};\\\", \\\"{x:1306,y:890,t:1527020019517};\\\", \\\"{x:1306,y:892,t:1527020019983};\\\", \\\"{x:1306,y:893,t:1527020020048};\\\", \\\"{x:1304,y:893,t:1527020020063};\\\", \\\"{x:1302,y:893,t:1527020020071};\\\", \\\"{x:1300,y:892,t:1527020020085};\\\", \\\"{x:1296,y:888,t:1527020020101};\\\", \\\"{x:1294,y:887,t:1527020020118};\\\", \\\"{x:1290,y:884,t:1527020020134};\\\", \\\"{x:1278,y:875,t:1527020020151};\\\", \\\"{x:1270,y:870,t:1527020020169};\\\", \\\"{x:1258,y:862,t:1527020020184};\\\", \\\"{x:1244,y:855,t:1527020020201};\\\", \\\"{x:1233,y:849,t:1527020020218};\\\", \\\"{x:1223,y:843,t:1527020020234};\\\", \\\"{x:1218,y:840,t:1527020020251};\\\", \\\"{x:1213,y:836,t:1527020020268};\\\", \\\"{x:1210,y:834,t:1527020020285};\\\", \\\"{x:1208,y:833,t:1527020020301};\\\", \\\"{x:1206,y:833,t:1527020020318};\\\", \\\"{x:1205,y:832,t:1527020021824};\\\", \\\"{x:1204,y:826,t:1527020021855};\\\", \\\"{x:1201,y:820,t:1527020021869};\\\", \\\"{x:1199,y:811,t:1527020021887};\\\", \\\"{x:1194,y:799,t:1527020021902};\\\", \\\"{x:1186,y:784,t:1527020021919};\\\", \\\"{x:1182,y:776,t:1527020021936};\\\", \\\"{x:1181,y:772,t:1527020021953};\\\", \\\"{x:1180,y:771,t:1527020021969};\\\", \\\"{x:1180,y:770,t:1527020022056};\\\", \\\"{x:1182,y:770,t:1527020022591};\\\", \\\"{x:1187,y:773,t:1527020022603};\\\", \\\"{x:1190,y:778,t:1527020022621};\\\", \\\"{x:1192,y:783,t:1527020022637};\\\", \\\"{x:1197,y:793,t:1527020022653};\\\", \\\"{x:1205,y:810,t:1527020022671};\\\", \\\"{x:1208,y:820,t:1527020022687};\\\", \\\"{x:1211,y:826,t:1527020022704};\\\", \\\"{x:1212,y:830,t:1527020022721};\\\", \\\"{x:1213,y:831,t:1527020022736};\\\", \\\"{x:1213,y:832,t:1527020022754};\\\", \\\"{x:1213,y:833,t:1527020022807};\\\", \\\"{x:1213,y:834,t:1527020022831};\\\", \\\"{x:1213,y:835,t:1527020022839};\\\", \\\"{x:1213,y:836,t:1527020022854};\\\", \\\"{x:1213,y:843,t:1527020022871};\\\", \\\"{x:1213,y:846,t:1527020022886};\\\", \\\"{x:1213,y:853,t:1527020022904};\\\", \\\"{x:1213,y:854,t:1527020022920};\\\", \\\"{x:1213,y:856,t:1527020022938};\\\", \\\"{x:1213,y:857,t:1527020022953};\\\", \\\"{x:1213,y:858,t:1527020022971};\\\", \\\"{x:1213,y:859,t:1527020022988};\\\", \\\"{x:1213,y:860,t:1527020026007};\\\", \\\"{x:1213,y:858,t:1527020032358};\\\", \\\"{x:1216,y:854,t:1527020032365};\\\", \\\"{x:1220,y:850,t:1527020032377};\\\", \\\"{x:1228,y:846,t:1527020032395};\\\", \\\"{x:1236,y:842,t:1527020032410};\\\", \\\"{x:1242,y:839,t:1527020032427};\\\", \\\"{x:1251,y:836,t:1527020032444};\\\", \\\"{x:1258,y:833,t:1527020032460};\\\", \\\"{x:1265,y:829,t:1527020032477};\\\", \\\"{x:1275,y:825,t:1527020032494};\\\", \\\"{x:1281,y:823,t:1527020032511};\\\", \\\"{x:1283,y:822,t:1527020032528};\\\", \\\"{x:1286,y:821,t:1527020032544};\\\", \\\"{x:1288,y:820,t:1527020032562};\\\", \\\"{x:1290,y:819,t:1527020032577};\\\", \\\"{x:1291,y:819,t:1527020032638};\\\", \\\"{x:1293,y:819,t:1527020032645};\\\", \\\"{x:1296,y:817,t:1527020032661};\\\", \\\"{x:1303,y:814,t:1527020032678};\\\", \\\"{x:1313,y:808,t:1527020032693};\\\", \\\"{x:1318,y:805,t:1527020032711};\\\", \\\"{x:1325,y:799,t:1527020032727};\\\", \\\"{x:1330,y:794,t:1527020032744};\\\", \\\"{x:1333,y:791,t:1527020032762};\\\", \\\"{x:1336,y:787,t:1527020032777};\\\", \\\"{x:1337,y:785,t:1527020032794};\\\", \\\"{x:1338,y:782,t:1527020032811};\\\", \\\"{x:1338,y:780,t:1527020032828};\\\", \\\"{x:1338,y:779,t:1527020032844};\\\", \\\"{x:1338,y:777,t:1527020032861};\\\", \\\"{x:1338,y:776,t:1527020032877};\\\", \\\"{x:1338,y:774,t:1527020032894};\\\", \\\"{x:1337,y:773,t:1527020032918};\\\", \\\"{x:1334,y:773,t:1527020032990};\\\", \\\"{x:1333,y:773,t:1527020032998};\\\", \\\"{x:1332,y:773,t:1527020033030};\\\", \\\"{x:1331,y:773,t:1527020033054};\\\", \\\"{x:1330,y:772,t:1527020033126};\\\", \\\"{x:1331,y:769,t:1527020033142};\\\", \\\"{x:1338,y:766,t:1527020033150};\\\", \\\"{x:1346,y:763,t:1527020033162};\\\", \\\"{x:1359,y:757,t:1527020033178};\\\", \\\"{x:1367,y:753,t:1527020033195};\\\", \\\"{x:1369,y:752,t:1527020033211};\\\", \\\"{x:1367,y:752,t:1527020033382};\\\", \\\"{x:1361,y:754,t:1527020033396};\\\", \\\"{x:1356,y:756,t:1527020033412};\\\", \\\"{x:1353,y:758,t:1527020033428};\\\", \\\"{x:1351,y:759,t:1527020033445};\\\", \\\"{x:1347,y:759,t:1527020033461};\\\", \\\"{x:1347,y:760,t:1527020033478};\\\", \\\"{x:1346,y:760,t:1527020033510};\\\", \\\"{x:1340,y:762,t:1527020033959};\\\", \\\"{x:1332,y:762,t:1527020033966};\\\", \\\"{x:1318,y:763,t:1527020033979};\\\", \\\"{x:1282,y:764,t:1527020033996};\\\", \\\"{x:1232,y:764,t:1527020034012};\\\", \\\"{x:1179,y:764,t:1527020034029};\\\", \\\"{x:1134,y:764,t:1527020034046};\\\", \\\"{x:1087,y:764,t:1527020034062};\\\", \\\"{x:1065,y:764,t:1527020034078};\\\", \\\"{x:1053,y:764,t:1527020034095};\\\", \\\"{x:1050,y:764,t:1527020034113};\\\", \\\"{x:1051,y:764,t:1527020034726};\\\", \\\"{x:1055,y:761,t:1527020034734};\\\", \\\"{x:1059,y:758,t:1527020034746};\\\", \\\"{x:1070,y:751,t:1527020034763};\\\", \\\"{x:1081,y:743,t:1527020034780};\\\", \\\"{x:1088,y:737,t:1527020034797};\\\", \\\"{x:1093,y:734,t:1527020034813};\\\", \\\"{x:1095,y:733,t:1527020034829};\\\", \\\"{x:1096,y:731,t:1527020034847};\\\", \\\"{x:1095,y:731,t:1527020034918};\\\", \\\"{x:1092,y:732,t:1527020034930};\\\", \\\"{x:1085,y:735,t:1527020034946};\\\", \\\"{x:1081,y:736,t:1527020034962};\\\", \\\"{x:1077,y:738,t:1527020034979};\\\", \\\"{x:1076,y:738,t:1527020034996};\\\", \\\"{x:1074,y:739,t:1527020035012};\\\", \\\"{x:1073,y:739,t:1527020035053};\\\", \\\"{x:1072,y:739,t:1527020035062};\\\", \\\"{x:1071,y:739,t:1527020035079};\\\", \\\"{x:1071,y:740,t:1527020035174};\\\", \\\"{x:1071,y:741,t:1527020035198};\\\", \\\"{x:1071,y:742,t:1527020035213};\\\", \\\"{x:1071,y:746,t:1527020035229};\\\", \\\"{x:1071,y:751,t:1527020035246};\\\", \\\"{x:1071,y:755,t:1527020035263};\\\", \\\"{x:1071,y:757,t:1527020035279};\\\", \\\"{x:1071,y:760,t:1527020035296};\\\", \\\"{x:1073,y:760,t:1527020035454};\\\", \\\"{x:1075,y:759,t:1527020035463};\\\", \\\"{x:1078,y:751,t:1527020035480};\\\", \\\"{x:1080,y:747,t:1527020035497};\\\", \\\"{x:1082,y:742,t:1527020035514};\\\", \\\"{x:1082,y:739,t:1527020035531};\\\", \\\"{x:1083,y:737,t:1527020035550};\\\", \\\"{x:1080,y:737,t:1527020035742};\\\", \\\"{x:1077,y:738,t:1527020035750};\\\", \\\"{x:1073,y:740,t:1527020035764};\\\", \\\"{x:1070,y:741,t:1527020035780};\\\", \\\"{x:1068,y:742,t:1527020035796};\\\", \\\"{x:1066,y:743,t:1527020035813};\\\", \\\"{x:1065,y:743,t:1527020035830};\\\", \\\"{x:1064,y:744,t:1527020035990};\\\", \\\"{x:1064,y:745,t:1527020036030};\\\", \\\"{x:1064,y:747,t:1527020036047};\\\", \\\"{x:1066,y:749,t:1527020036064};\\\", \\\"{x:1066,y:750,t:1527020036081};\\\", \\\"{x:1067,y:751,t:1527020036097};\\\", \\\"{x:1068,y:752,t:1527020036118};\\\", \\\"{x:1069,y:753,t:1527020036142};\\\", \\\"{x:1069,y:754,t:1527020036157};\\\", \\\"{x:1069,y:755,t:1527020036165};\\\", \\\"{x:1069,y:756,t:1527020036180};\\\", \\\"{x:1070,y:757,t:1527020036394};\\\", \\\"{x:1072,y:757,t:1527020036409};\\\", \\\"{x:1076,y:756,t:1527020036417};\\\", \\\"{x:1079,y:754,t:1527020036434};\\\", \\\"{x:1081,y:750,t:1527020036451};\\\", \\\"{x:1083,y:745,t:1527020036469};\\\", \\\"{x:1084,y:744,t:1527020036484};\\\", \\\"{x:1084,y:743,t:1527020036522};\\\", \\\"{x:1084,y:742,t:1527020036534};\\\", \\\"{x:1080,y:743,t:1527020036898};\\\", \\\"{x:1074,y:746,t:1527020036905};\\\", \\\"{x:1070,y:747,t:1527020036918};\\\", \\\"{x:1065,y:750,t:1527020036935};\\\", \\\"{x:1062,y:751,t:1527020036951};\\\", \\\"{x:1061,y:751,t:1527020036968};\\\", \\\"{x:1059,y:752,t:1527020036985};\\\", \\\"{x:1059,y:753,t:1527020037001};\\\", \\\"{x:1059,y:756,t:1527020037249};\\\", \\\"{x:1060,y:759,t:1527020037257};\\\", \\\"{x:1061,y:762,t:1527020037267};\\\", \\\"{x:1067,y:767,t:1527020037285};\\\", \\\"{x:1069,y:769,t:1527020037302};\\\", \\\"{x:1071,y:770,t:1527020037318};\\\", \\\"{x:1073,y:770,t:1527020037545};\\\", \\\"{x:1074,y:770,t:1527020037554};\\\", \\\"{x:1076,y:769,t:1527020037568};\\\", \\\"{x:1079,y:763,t:1527020037585};\\\", \\\"{x:1080,y:759,t:1527020037601};\\\", \\\"{x:1081,y:756,t:1527020037618};\\\", \\\"{x:1081,y:755,t:1527020037635};\\\", \\\"{x:1081,y:754,t:1527020037652};\\\", \\\"{x:1081,y:753,t:1527020037961};\\\", \\\"{x:1080,y:754,t:1527020037969};\\\", \\\"{x:1079,y:754,t:1527020037984};\\\", \\\"{x:1078,y:755,t:1527020038002};\\\", \\\"{x:1075,y:756,t:1527020038019};\\\", \\\"{x:1074,y:757,t:1527020038035};\\\", \\\"{x:1074,y:761,t:1527020038052};\\\", \\\"{x:1073,y:762,t:1527020038068};\\\", \\\"{x:1072,y:763,t:1527020038185};\\\", \\\"{x:1069,y:764,t:1527020038202};\\\", \\\"{x:1069,y:765,t:1527020038219};\\\", \\\"{x:1066,y:766,t:1527020038236};\\\", \\\"{x:1065,y:767,t:1527020038252};\\\", \\\"{x:1062,y:767,t:1527020038269};\\\", \\\"{x:1060,y:768,t:1527020038286};\\\", \\\"{x:1060,y:766,t:1527020038633};\\\", \\\"{x:1059,y:766,t:1527020059114};\\\", \\\"{x:1045,y:766,t:1527020059122};\\\", \\\"{x:1012,y:766,t:1527020059136};\\\", \\\"{x:859,y:766,t:1527020059154};\\\", \\\"{x:759,y:764,t:1527020059169};\\\", \\\"{x:666,y:758,t:1527020059186};\\\", \\\"{x:602,y:750,t:1527020059202};\\\", \\\"{x:554,y:742,t:1527020059219};\\\", \\\"{x:524,y:740,t:1527020059236};\\\", \\\"{x:512,y:740,t:1527020059247};\\\", \\\"{x:500,y:740,t:1527020059262};\\\", \\\"{x:498,y:740,t:1527020059280};\\\", \\\"{x:498,y:739,t:1527020059546};\\\", \\\"{x:498,y:736,t:1527020059564};\\\", \\\"{x:498,y:730,t:1527020059581};\\\", \\\"{x:498,y:717,t:1527020059597};\\\", \\\"{x:498,y:709,t:1527020059613};\\\", \\\"{x:498,y:701,t:1527020059636};\\\", \\\"{x:496,y:696,t:1527020059653};\\\", \\\"{x:496,y:691,t:1527020059669};\\\", \\\"{x:495,y:690,t:1527020059685};\\\", \\\"{x:495,y:688,t:1527020059702};\\\", \\\"{x:492,y:684,t:1527020059718};\\\", \\\"{x:491,y:681,t:1527020059734};\\\", \\\"{x:488,y:677,t:1527020059752};\\\", \\\"{x:482,y:672,t:1527020059769};\\\", \\\"{x:478,y:668,t:1527020059786};\\\", \\\"{x:478,y:666,t:1527020059801};\\\", \\\"{x:477,y:662,t:1527020059818};\\\", \\\"{x:476,y:657,t:1527020059836};\\\", \\\"{x:469,y:651,t:1527020059852};\\\", \\\"{x:462,y:643,t:1527020059869};\\\", \\\"{x:462,y:641,t:1527020061698};\\\", \\\"{x:462,y:639,t:1527020061705};\\\", \\\"{x:462,y:635,t:1527020061722};\\\", \\\"{x:462,y:632,t:1527020061738};\\\", \\\"{x:462,y:628,t:1527020061754};\\\", \\\"{x:464,y:626,t:1527020061770};\\\", \\\"{x:464,y:623,t:1527020061787};\\\", \\\"{x:464,y:620,t:1527020061803};\\\", \\\"{x:466,y:616,t:1527020061821};\\\", \\\"{x:467,y:613,t:1527020061838};\\\", \\\"{x:468,y:612,t:1527020061854};\\\", \\\"{x:470,y:611,t:1527020061881};\\\", \\\"{x:471,y:609,t:1527020061904};\\\", \\\"{x:473,y:608,t:1527020061920};\\\", \\\"{x:474,y:607,t:1527020061938};\\\", \\\"{x:475,y:605,t:1527020061955};\\\", \\\"{x:476,y:604,t:1527020061971};\\\", \\\"{x:474,y:604,t:1527020072298};\\\", \\\"{x:473,y:604,t:1527020072312};\\\", \\\"{x:471,y:605,t:1527020072330};\\\", \\\"{x:472,y:605,t:1527020073194};\\\", \\\"{x:473,y:605,t:1527020073201};\\\", \\\"{x:475,y:603,t:1527020073213};\\\", \\\"{x:477,y:602,t:1527020073231};\\\", \\\"{x:481,y:601,t:1527020073247};\\\", \\\"{x:488,y:598,t:1527020073264};\\\", \\\"{x:506,y:598,t:1527020073281};\\\", \\\"{x:526,y:598,t:1527020073296};\\\", \\\"{x:556,y:607,t:1527020073313};\\\", \\\"{x:603,y:616,t:1527020073331};\\\", \\\"{x:673,y:631,t:1527020073347};\\\", \\\"{x:762,y:642,t:1527020073363};\\\", \\\"{x:857,y:658,t:1527020073380};\\\", \\\"{x:946,y:669,t:1527020073397};\\\", \\\"{x:1026,y:680,t:1527020073413};\\\", \\\"{x:1084,y:695,t:1527020073430};\\\", \\\"{x:1134,y:709,t:1527020073448};\\\", \\\"{x:1161,y:718,t:1527020073463};\\\", \\\"{x:1183,y:729,t:1527020073480};\\\", \\\"{x:1218,y:750,t:1527020073496};\\\", \\\"{x:1238,y:764,t:1527020073513};\\\", \\\"{x:1265,y:781,t:1527020073530};\\\", \\\"{x:1290,y:798,t:1527020073548};\\\", \\\"{x:1312,y:811,t:1527020073564};\\\", \\\"{x:1339,y:827,t:1527020073580};\\\", \\\"{x:1359,y:838,t:1527020073598};\\\", \\\"{x:1378,y:849,t:1527020073613};\\\", \\\"{x:1391,y:858,t:1527020073631};\\\", \\\"{x:1401,y:866,t:1527020073648};\\\", \\\"{x:1417,y:875,t:1527020073664};\\\", \\\"{x:1431,y:883,t:1527020073681};\\\", \\\"{x:1458,y:892,t:1527020073696};\\\", \\\"{x:1482,y:898,t:1527020073714};\\\", \\\"{x:1505,y:905,t:1527020073730};\\\", \\\"{x:1530,y:909,t:1527020073748};\\\", \\\"{x:1552,y:912,t:1527020073764};\\\", \\\"{x:1569,y:912,t:1527020073781};\\\", \\\"{x:1577,y:912,t:1527020073798};\\\", \\\"{x:1580,y:912,t:1527020073814};\\\", \\\"{x:1581,y:912,t:1527020073842};\\\", \\\"{x:1581,y:909,t:1527020073857};\\\", \\\"{x:1581,y:906,t:1527020073866};\\\", \\\"{x:1581,y:902,t:1527020073881};\\\", \\\"{x:1581,y:888,t:1527020073898};\\\", \\\"{x:1579,y:875,t:1527020073913};\\\", \\\"{x:1571,y:860,t:1527020073931};\\\", \\\"{x:1564,y:847,t:1527020073947};\\\", \\\"{x:1551,y:830,t:1527020073964};\\\", \\\"{x:1535,y:813,t:1527020073981};\\\", \\\"{x:1519,y:793,t:1527020073998};\\\", \\\"{x:1500,y:773,t:1527020074014};\\\", \\\"{x:1483,y:758,t:1527020074030};\\\", \\\"{x:1469,y:747,t:1527020074048};\\\", \\\"{x:1461,y:741,t:1527020074064};\\\", \\\"{x:1456,y:736,t:1527020074081};\\\", \\\"{x:1452,y:733,t:1527020074097};\\\", \\\"{x:1450,y:730,t:1527020074113};\\\", \\\"{x:1449,y:729,t:1527020074131};\\\", \\\"{x:1448,y:728,t:1527020074148};\\\", \\\"{x:1446,y:725,t:1527020074164};\\\", \\\"{x:1444,y:722,t:1527020074181};\\\", \\\"{x:1442,y:719,t:1527020074197};\\\", \\\"{x:1440,y:716,t:1527020074213};\\\", \\\"{x:1439,y:715,t:1527020074230};\\\", \\\"{x:1437,y:713,t:1527020074247};\\\", \\\"{x:1436,y:712,t:1527020074263};\\\", \\\"{x:1434,y:710,t:1527020074280};\\\", \\\"{x:1433,y:708,t:1527020074297};\\\", \\\"{x:1432,y:708,t:1527020074465};\\\", \\\"{x:1432,y:711,t:1527020074481};\\\", \\\"{x:1428,y:735,t:1527020074498};\\\", \\\"{x:1428,y:747,t:1527020074515};\\\", \\\"{x:1428,y:758,t:1527020074531};\\\", \\\"{x:1428,y:765,t:1527020074548};\\\", \\\"{x:1428,y:772,t:1527020074565};\\\", \\\"{x:1428,y:783,t:1527020074581};\\\", \\\"{x:1429,y:794,t:1527020074597};\\\", \\\"{x:1431,y:805,t:1527020074615};\\\", \\\"{x:1435,y:813,t:1527020074631};\\\", \\\"{x:1437,y:816,t:1527020074648};\\\", \\\"{x:1438,y:818,t:1527020074665};\\\", \\\"{x:1440,y:823,t:1527020074681};\\\", \\\"{x:1445,y:831,t:1527020074697};\\\", \\\"{x:1447,y:836,t:1527020074715};\\\", \\\"{x:1451,y:841,t:1527020074730};\\\", \\\"{x:1454,y:845,t:1527020074747};\\\", \\\"{x:1459,y:852,t:1527020074765};\\\", \\\"{x:1463,y:858,t:1527020074780};\\\", \\\"{x:1472,y:866,t:1527020074797};\\\", \\\"{x:1478,y:873,t:1527020074814};\\\", \\\"{x:1488,y:881,t:1527020074830};\\\", \\\"{x:1497,y:888,t:1527020074848};\\\", \\\"{x:1503,y:894,t:1527020074865};\\\", \\\"{x:1509,y:906,t:1527020074881};\\\", \\\"{x:1510,y:916,t:1527020074898};\\\", \\\"{x:1510,y:930,t:1527020074915};\\\", \\\"{x:1510,y:941,t:1527020074931};\\\", \\\"{x:1506,y:955,t:1527020074949};\\\", \\\"{x:1496,y:975,t:1527020074965};\\\", \\\"{x:1489,y:991,t:1527020074982};\\\", \\\"{x:1486,y:996,t:1527020074997};\\\", \\\"{x:1484,y:998,t:1527020075015};\\\", \\\"{x:1482,y:999,t:1527020075031};\\\", \\\"{x:1480,y:1000,t:1527020075047};\\\", \\\"{x:1479,y:1001,t:1527020075065};\\\", \\\"{x:1478,y:1001,t:1527020075080};\\\", \\\"{x:1477,y:1001,t:1527020075145};\\\", \\\"{x:1476,y:1001,t:1527020075153};\\\", \\\"{x:1474,y:1000,t:1527020075164};\\\", \\\"{x:1472,y:995,t:1527020075180};\\\", \\\"{x:1472,y:993,t:1527020075198};\\\", \\\"{x:1470,y:992,t:1527020075215};\\\", \\\"{x:1470,y:990,t:1527020075231};\\\", \\\"{x:1469,y:987,t:1527020075248};\\\", \\\"{x:1467,y:981,t:1527020075265};\\\", \\\"{x:1466,y:981,t:1527020075281};\\\", \\\"{x:1466,y:977,t:1527020075298};\\\", \\\"{x:1465,y:976,t:1527020075314};\\\", \\\"{x:1463,y:973,t:1527020075331};\\\", \\\"{x:1463,y:972,t:1527020075348};\\\", \\\"{x:1462,y:970,t:1527020075365};\\\", \\\"{x:1462,y:968,t:1527020075382};\\\", \\\"{x:1460,y:966,t:1527020075402};\\\", \\\"{x:1460,y:965,t:1527020075418};\\\", \\\"{x:1459,y:963,t:1527020075434};\\\", \\\"{x:1459,y:962,t:1527020075449};\\\", \\\"{x:1456,y:958,t:1527020075465};\\\", \\\"{x:1455,y:954,t:1527020075481};\\\", \\\"{x:1452,y:951,t:1527020075498};\\\", \\\"{x:1448,y:945,t:1527020075515};\\\", \\\"{x:1445,y:940,t:1527020075531};\\\", \\\"{x:1442,y:937,t:1527020075548};\\\", \\\"{x:1440,y:934,t:1527020075565};\\\", \\\"{x:1438,y:930,t:1527020075581};\\\", \\\"{x:1434,y:925,t:1527020075598};\\\", \\\"{x:1433,y:923,t:1527020075615};\\\", \\\"{x:1431,y:920,t:1527020075632};\\\", \\\"{x:1429,y:917,t:1527020075648};\\\", \\\"{x:1423,y:910,t:1527020075665};\\\", \\\"{x:1417,y:899,t:1527020075681};\\\", \\\"{x:1411,y:889,t:1527020075698};\\\", \\\"{x:1406,y:879,t:1527020075714};\\\", \\\"{x:1397,y:864,t:1527020075732};\\\", \\\"{x:1390,y:851,t:1527020075749};\\\", \\\"{x:1380,y:836,t:1527020075765};\\\", \\\"{x:1370,y:817,t:1527020075782};\\\", \\\"{x:1361,y:801,t:1527020075798};\\\", \\\"{x:1349,y:781,t:1527020075815};\\\", \\\"{x:1333,y:752,t:1527020075832};\\\", \\\"{x:1315,y:718,t:1527020075848};\\\", \\\"{x:1289,y:674,t:1527020075865};\\\", \\\"{x:1277,y:650,t:1527020075881};\\\", \\\"{x:1265,y:631,t:1527020075898};\\\", \\\"{x:1259,y:616,t:1527020075915};\\\", \\\"{x:1255,y:606,t:1527020075932};\\\", \\\"{x:1252,y:586,t:1527020075948};\\\", \\\"{x:1250,y:570,t:1527020075965};\\\", \\\"{x:1248,y:552,t:1527020075982};\\\", \\\"{x:1246,y:534,t:1527020075998};\\\", \\\"{x:1244,y:523,t:1527020076015};\\\", \\\"{x:1244,y:516,t:1527020076032};\\\", \\\"{x:1244,y:513,t:1527020076048};\\\", \\\"{x:1244,y:511,t:1527020076065};\\\", \\\"{x:1245,y:511,t:1527020076082};\\\", \\\"{x:1246,y:510,t:1527020076098};\\\", \\\"{x:1246,y:511,t:1527020076170};\\\", \\\"{x:1246,y:512,t:1527020076193};\\\", \\\"{x:1246,y:514,t:1527020076202};\\\", \\\"{x:1246,y:515,t:1527020076215};\\\", \\\"{x:1247,y:525,t:1527020076232};\\\", \\\"{x:1252,y:537,t:1527020076248};\\\", \\\"{x:1259,y:547,t:1527020076265};\\\", \\\"{x:1263,y:553,t:1527020076281};\\\", \\\"{x:1264,y:555,t:1527020076298};\\\", \\\"{x:1266,y:558,t:1527020076315};\\\", \\\"{x:1267,y:563,t:1527020076332};\\\", \\\"{x:1270,y:569,t:1527020076348};\\\", \\\"{x:1274,y:576,t:1527020076365};\\\", \\\"{x:1276,y:580,t:1527020076382};\\\", \\\"{x:1278,y:583,t:1527020076398};\\\", \\\"{x:1279,y:584,t:1527020076415};\\\", \\\"{x:1280,y:586,t:1527020076432};\\\", \\\"{x:1281,y:587,t:1527020076457};\\\", \\\"{x:1281,y:588,t:1527020076946};\\\", \\\"{x:1281,y:592,t:1527020076954};\\\", \\\"{x:1281,y:596,t:1527020076965};\\\", \\\"{x:1281,y:602,t:1527020076982};\\\", \\\"{x:1285,y:609,t:1527020076999};\\\", \\\"{x:1285,y:614,t:1527020077015};\\\", \\\"{x:1286,y:618,t:1527020077032};\\\", \\\"{x:1287,y:622,t:1527020077050};\\\", \\\"{x:1287,y:623,t:1527020077066};\\\", \\\"{x:1287,y:625,t:1527020077082};\\\", \\\"{x:1287,y:626,t:1527020077099};\\\", \\\"{x:1287,y:628,t:1527020077115};\\\", \\\"{x:1288,y:630,t:1527020077132};\\\", \\\"{x:1288,y:634,t:1527020077149};\\\", \\\"{x:1289,y:635,t:1527020077165};\\\", \\\"{x:1289,y:636,t:1527020077182};\\\", \\\"{x:1289,y:637,t:1527020077199};\\\", \\\"{x:1289,y:638,t:1527020077215};\\\", \\\"{x:1289,y:641,t:1527020077232};\\\", \\\"{x:1289,y:647,t:1527020077249};\\\", \\\"{x:1289,y:652,t:1527020077265};\\\", \\\"{x:1289,y:657,t:1527020077282};\\\", \\\"{x:1289,y:664,t:1527020077299};\\\", \\\"{x:1289,y:671,t:1527020077315};\\\", \\\"{x:1289,y:677,t:1527020077332};\\\", \\\"{x:1289,y:682,t:1527020077349};\\\", \\\"{x:1290,y:687,t:1527020077365};\\\", \\\"{x:1291,y:695,t:1527020077382};\\\", \\\"{x:1292,y:699,t:1527020077399};\\\", \\\"{x:1292,y:704,t:1527020077415};\\\", \\\"{x:1293,y:706,t:1527020077432};\\\", \\\"{x:1293,y:707,t:1527020077457};\\\", \\\"{x:1293,y:708,t:1527020077465};\\\", \\\"{x:1293,y:709,t:1527020077482};\\\", \\\"{x:1293,y:711,t:1527020077498};\\\", \\\"{x:1293,y:712,t:1527020077515};\\\", \\\"{x:1296,y:719,t:1527020077532};\\\", \\\"{x:1301,y:732,t:1527020077549};\\\", \\\"{x:1314,y:753,t:1527020077565};\\\", \\\"{x:1339,y:788,t:1527020077582};\\\", \\\"{x:1362,y:831,t:1527020077599};\\\", \\\"{x:1388,y:866,t:1527020077615};\\\", \\\"{x:1423,y:899,t:1527020077632};\\\", \\\"{x:1449,y:927,t:1527020077649};\\\", \\\"{x:1459,y:939,t:1527020077665};\\\", \\\"{x:1464,y:949,t:1527020077682};\\\", \\\"{x:1468,y:956,t:1527020077699};\\\", \\\"{x:1472,y:962,t:1527020077715};\\\", \\\"{x:1475,y:971,t:1527020077732};\\\", \\\"{x:1483,y:982,t:1527020077748};\\\", \\\"{x:1492,y:994,t:1527020077766};\\\", \\\"{x:1492,y:995,t:1527020077782};\\\", \\\"{x:1494,y:995,t:1527020077849};\\\", \\\"{x:1494,y:992,t:1527020077929};\\\", \\\"{x:1493,y:988,t:1527020077937};\\\", \\\"{x:1490,y:983,t:1527020077949};\\\", \\\"{x:1485,y:975,t:1527020077966};\\\", \\\"{x:1484,y:968,t:1527020077982};\\\", \\\"{x:1481,y:964,t:1527020077999};\\\", \\\"{x:1478,y:960,t:1527020078016};\\\", \\\"{x:1477,y:958,t:1527020078032};\\\", \\\"{x:1473,y:954,t:1527020078050};\\\", \\\"{x:1471,y:951,t:1527020078065};\\\", \\\"{x:1468,y:949,t:1527020078082};\\\", \\\"{x:1466,y:946,t:1527020078099};\\\", \\\"{x:1463,y:944,t:1527020078116};\\\", \\\"{x:1461,y:941,t:1527020078132};\\\", \\\"{x:1458,y:938,t:1527020078149};\\\", \\\"{x:1456,y:935,t:1527020078165};\\\", \\\"{x:1456,y:934,t:1527020078182};\\\", \\\"{x:1455,y:934,t:1527020078199};\\\", \\\"{x:1453,y:930,t:1527020078215};\\\", \\\"{x:1450,y:927,t:1527020078231};\\\", \\\"{x:1444,y:920,t:1527020078248};\\\", \\\"{x:1441,y:916,t:1527020078265};\\\", \\\"{x:1439,y:913,t:1527020078282};\\\", \\\"{x:1438,y:911,t:1527020078299};\\\", \\\"{x:1437,y:908,t:1527020078315};\\\", \\\"{x:1435,y:905,t:1527020078332};\\\", \\\"{x:1433,y:899,t:1527020078348};\\\", \\\"{x:1431,y:893,t:1527020078366};\\\", \\\"{x:1428,y:884,t:1527020078382};\\\", \\\"{x:1423,y:875,t:1527020078398};\\\", \\\"{x:1418,y:866,t:1527020078415};\\\", \\\"{x:1416,y:859,t:1527020078432};\\\", \\\"{x:1412,y:851,t:1527020078449};\\\", \\\"{x:1408,y:842,t:1527020078465};\\\", \\\"{x:1402,y:832,t:1527020078482};\\\", \\\"{x:1395,y:819,t:1527020078499};\\\", \\\"{x:1391,y:811,t:1527020078516};\\\", \\\"{x:1386,y:806,t:1527020078531};\\\", \\\"{x:1383,y:801,t:1527020078549};\\\", \\\"{x:1380,y:798,t:1527020078566};\\\", \\\"{x:1379,y:793,t:1527020078582};\\\", \\\"{x:1376,y:788,t:1527020078600};\\\", \\\"{x:1371,y:779,t:1527020078616};\\\", \\\"{x:1364,y:768,t:1527020078632};\\\", \\\"{x:1357,y:755,t:1527020078649};\\\", \\\"{x:1352,y:746,t:1527020078666};\\\", \\\"{x:1347,y:736,t:1527020078682};\\\", \\\"{x:1341,y:726,t:1527020078699};\\\", \\\"{x:1337,y:716,t:1527020078716};\\\", \\\"{x:1331,y:705,t:1527020078732};\\\", \\\"{x:1324,y:694,t:1527020078749};\\\", \\\"{x:1319,y:686,t:1527020078766};\\\", \\\"{x:1316,y:678,t:1527020078782};\\\", \\\"{x:1312,y:673,t:1527020078799};\\\", \\\"{x:1309,y:666,t:1527020078816};\\\", \\\"{x:1304,y:657,t:1527020078832};\\\", \\\"{x:1300,y:645,t:1527020078849};\\\", \\\"{x:1297,y:639,t:1527020078866};\\\", \\\"{x:1293,y:630,t:1527020078882};\\\", \\\"{x:1287,y:618,t:1527020078899};\\\", \\\"{x:1283,y:605,t:1527020078916};\\\", \\\"{x:1279,y:592,t:1527020078933};\\\", \\\"{x:1277,y:580,t:1527020078949};\\\", \\\"{x:1273,y:568,t:1527020078966};\\\", \\\"{x:1272,y:563,t:1527020078983};\\\", \\\"{x:1271,y:558,t:1527020079000};\\\", \\\"{x:1269,y:556,t:1527020079017};\\\", \\\"{x:1269,y:552,t:1527020079034};\\\", \\\"{x:1268,y:550,t:1527020079049};\\\", \\\"{x:1267,y:550,t:1527020079338};\\\", \\\"{x:1266,y:553,t:1527020079349};\\\", \\\"{x:1266,y:566,t:1527020079366};\\\", \\\"{x:1266,y:571,t:1527020079383};\\\", \\\"{x:1266,y:574,t:1527020079399};\\\", \\\"{x:1266,y:577,t:1527020079416};\\\", \\\"{x:1266,y:578,t:1527020079465};\\\", \\\"{x:1268,y:580,t:1527020079529};\\\", \\\"{x:1270,y:582,t:1527020079537};\\\", \\\"{x:1272,y:584,t:1527020079549};\\\", \\\"{x:1278,y:589,t:1527020079566};\\\", \\\"{x:1289,y:596,t:1527020079583};\\\", \\\"{x:1305,y:610,t:1527020079600};\\\", \\\"{x:1319,y:622,t:1527020079617};\\\", \\\"{x:1342,y:650,t:1527020079633};\\\", \\\"{x:1356,y:666,t:1527020079650};\\\", \\\"{x:1373,y:679,t:1527020079666};\\\", \\\"{x:1387,y:688,t:1527020079683};\\\", \\\"{x:1400,y:697,t:1527020079699};\\\", \\\"{x:1406,y:699,t:1527020079716};\\\", \\\"{x:1411,y:702,t:1527020079733};\\\", \\\"{x:1417,y:703,t:1527020079749};\\\", \\\"{x:1419,y:705,t:1527020079766};\\\", \\\"{x:1421,y:705,t:1527020079783};\\\", \\\"{x:1424,y:707,t:1527020079799};\\\", \\\"{x:1428,y:709,t:1527020079816};\\\", \\\"{x:1436,y:713,t:1527020079833};\\\", \\\"{x:1444,y:716,t:1527020079849};\\\", \\\"{x:1450,y:719,t:1527020079866};\\\", \\\"{x:1456,y:722,t:1527020079883};\\\", \\\"{x:1462,y:726,t:1527020079899};\\\", \\\"{x:1471,y:732,t:1527020079916};\\\", \\\"{x:1478,y:737,t:1527020079934};\\\", \\\"{x:1484,y:743,t:1527020079949};\\\", \\\"{x:1489,y:749,t:1527020079966};\\\", \\\"{x:1499,y:758,t:1527020079984};\\\", \\\"{x:1503,y:762,t:1527020079999};\\\", \\\"{x:1505,y:763,t:1527020080016};\\\", \\\"{x:1505,y:764,t:1527020080034};\\\", \\\"{x:1504,y:764,t:1527020080226};\\\", \\\"{x:1495,y:758,t:1527020080233};\\\", \\\"{x:1477,y:745,t:1527020080250};\\\", \\\"{x:1454,y:730,t:1527020080266};\\\", \\\"{x:1429,y:716,t:1527020080283};\\\", \\\"{x:1407,y:701,t:1527020080300};\\\", \\\"{x:1389,y:689,t:1527020080316};\\\", \\\"{x:1383,y:684,t:1527020080333};\\\", \\\"{x:1378,y:679,t:1527020080350};\\\", \\\"{x:1373,y:672,t:1527020080366};\\\", \\\"{x:1367,y:664,t:1527020080383};\\\", \\\"{x:1363,y:656,t:1527020080400};\\\", \\\"{x:1359,y:650,t:1527020080416};\\\", \\\"{x:1354,y:641,t:1527020080434};\\\", \\\"{x:1351,y:635,t:1527020080449};\\\", \\\"{x:1346,y:630,t:1527020080466};\\\", \\\"{x:1343,y:623,t:1527020080483};\\\", \\\"{x:1340,y:617,t:1527020080501};\\\", \\\"{x:1336,y:611,t:1527020080516};\\\", \\\"{x:1331,y:603,t:1527020080533};\\\", \\\"{x:1328,y:598,t:1527020080550};\\\", \\\"{x:1325,y:593,t:1527020080567};\\\", \\\"{x:1324,y:592,t:1527020080583};\\\", \\\"{x:1324,y:591,t:1527020080600};\\\", \\\"{x:1323,y:590,t:1527020080616};\\\", \\\"{x:1324,y:590,t:1527020080714};\\\", \\\"{x:1325,y:590,t:1527020080729};\\\", \\\"{x:1328,y:589,t:1527020080737};\\\", \\\"{x:1329,y:587,t:1527020080750};\\\", \\\"{x:1333,y:586,t:1527020080766};\\\", \\\"{x:1338,y:585,t:1527020080783};\\\", \\\"{x:1343,y:583,t:1527020080800};\\\", \\\"{x:1347,y:582,t:1527020080816};\\\", \\\"{x:1357,y:580,t:1527020080833};\\\", \\\"{x:1360,y:579,t:1527020080850};\\\", \\\"{x:1362,y:578,t:1527020080866};\\\", \\\"{x:1365,y:576,t:1527020080883};\\\", \\\"{x:1368,y:575,t:1527020080900};\\\", \\\"{x:1369,y:574,t:1527020080921};\\\", \\\"{x:1371,y:574,t:1527020080945};\\\", \\\"{x:1372,y:573,t:1527020080953};\\\", \\\"{x:1374,y:573,t:1527020080969};\\\", \\\"{x:1375,y:572,t:1527020080983};\\\", \\\"{x:1377,y:571,t:1527020081001};\\\", \\\"{x:1382,y:569,t:1527020081016};\\\", \\\"{x:1386,y:568,t:1527020081033};\\\", \\\"{x:1388,y:566,t:1527020081050};\\\", \\\"{x:1389,y:566,t:1527020081154};\\\", \\\"{x:1391,y:566,t:1527020081167};\\\", \\\"{x:1405,y:587,t:1527020081183};\\\", \\\"{x:1430,y:619,t:1527020081200};\\\", \\\"{x:1462,y:658,t:1527020081216};\\\", \\\"{x:1516,y:706,t:1527020081234};\\\", \\\"{x:1537,y:720,t:1527020081251};\\\", \\\"{x:1553,y:733,t:1527020081266};\\\", \\\"{x:1562,y:741,t:1527020081283};\\\", \\\"{x:1572,y:755,t:1527020081300};\\\", \\\"{x:1587,y:771,t:1527020081316};\\\", \\\"{x:1596,y:780,t:1527020081333};\\\", \\\"{x:1603,y:788,t:1527020081351};\\\", \\\"{x:1617,y:797,t:1527020081367};\\\", \\\"{x:1627,y:805,t:1527020081383};\\\", \\\"{x:1635,y:813,t:1527020081400};\\\", \\\"{x:1651,y:827,t:1527020081418};\\\", \\\"{x:1660,y:837,t:1527020081433};\\\", \\\"{x:1670,y:848,t:1527020081450};\\\", \\\"{x:1678,y:861,t:1527020081467};\\\", \\\"{x:1687,y:873,t:1527020081483};\\\", \\\"{x:1693,y:884,t:1527020081500};\\\", \\\"{x:1700,y:895,t:1527020081517};\\\", \\\"{x:1703,y:904,t:1527020081533};\\\", \\\"{x:1706,y:911,t:1527020081551};\\\", \\\"{x:1709,y:917,t:1527020081567};\\\", \\\"{x:1710,y:921,t:1527020081583};\\\", \\\"{x:1711,y:926,t:1527020081599};\\\", \\\"{x:1713,y:938,t:1527020081616};\\\", \\\"{x:1715,y:944,t:1527020081633};\\\", \\\"{x:1717,y:949,t:1527020081650};\\\", \\\"{x:1717,y:954,t:1527020081666};\\\", \\\"{x:1717,y:960,t:1527020081682};\\\", \\\"{x:1717,y:962,t:1527020081699};\\\", \\\"{x:1717,y:964,t:1527020081717};\\\", \\\"{x:1717,y:966,t:1527020081733};\\\", \\\"{x:1717,y:967,t:1527020081749};\\\", \\\"{x:1717,y:968,t:1527020081767};\\\", \\\"{x:1716,y:968,t:1527020081784};\\\", \\\"{x:1714,y:969,t:1527020081801};\\\", \\\"{x:1711,y:970,t:1527020081817};\\\", \\\"{x:1706,y:970,t:1527020081833};\\\", \\\"{x:1701,y:970,t:1527020081851};\\\", \\\"{x:1694,y:970,t:1527020081867};\\\", \\\"{x:1684,y:966,t:1527020081884};\\\", \\\"{x:1676,y:964,t:1527020081901};\\\", \\\"{x:1672,y:962,t:1527020081918};\\\", \\\"{x:1668,y:960,t:1527020081933};\\\", \\\"{x:1665,y:958,t:1527020081951};\\\", \\\"{x:1662,y:957,t:1527020081968};\\\", \\\"{x:1658,y:954,t:1527020081983};\\\", \\\"{x:1652,y:950,t:1527020082000};\\\", \\\"{x:1639,y:943,t:1527020082017};\\\", \\\"{x:1631,y:940,t:1527020082033};\\\", \\\"{x:1625,y:936,t:1527020082050};\\\", \\\"{x:1619,y:933,t:1527020082067};\\\", \\\"{x:1615,y:932,t:1527020082083};\\\", \\\"{x:1613,y:930,t:1527020082100};\\\", \\\"{x:1609,y:929,t:1527020082117};\\\", \\\"{x:1608,y:927,t:1527020082133};\\\", \\\"{x:1606,y:924,t:1527020082150};\\\", \\\"{x:1602,y:918,t:1527020082168};\\\", \\\"{x:1594,y:906,t:1527020082183};\\\", \\\"{x:1587,y:897,t:1527020082200};\\\", \\\"{x:1581,y:888,t:1527020082217};\\\", \\\"{x:1577,y:882,t:1527020082233};\\\", \\\"{x:1573,y:874,t:1527020082251};\\\", \\\"{x:1567,y:864,t:1527020082267};\\\", \\\"{x:1563,y:856,t:1527020082283};\\\", \\\"{x:1556,y:845,t:1527020082300};\\\", \\\"{x:1550,y:838,t:1527020082317};\\\", \\\"{x:1548,y:835,t:1527020082333};\\\", \\\"{x:1547,y:832,t:1527020082350};\\\", \\\"{x:1546,y:830,t:1527020082368};\\\", \\\"{x:1543,y:828,t:1527020082384};\\\", \\\"{x:1543,y:826,t:1527020082400};\\\", \\\"{x:1540,y:822,t:1527020082417};\\\", \\\"{x:1539,y:821,t:1527020082434};\\\", \\\"{x:1539,y:820,t:1527020082577};\\\", \\\"{x:1538,y:820,t:1527020082586};\\\", \\\"{x:1537,y:820,t:1527020082600};\\\", \\\"{x:1534,y:820,t:1527020082617};\\\", \\\"{x:1532,y:821,t:1527020082634};\\\", \\\"{x:1531,y:821,t:1527020082681};\\\", \\\"{x:1529,y:821,t:1527020082697};\\\", \\\"{x:1527,y:821,t:1527020082705};\\\", \\\"{x:1522,y:821,t:1527020082717};\\\", \\\"{x:1511,y:821,t:1527020082734};\\\", \\\"{x:1495,y:821,t:1527020082750};\\\", \\\"{x:1480,y:821,t:1527020082767};\\\", \\\"{x:1468,y:821,t:1527020082784};\\\", \\\"{x:1461,y:821,t:1527020082800};\\\", \\\"{x:1450,y:821,t:1527020082817};\\\", \\\"{x:1449,y:821,t:1527020082834};\\\", \\\"{x:1448,y:822,t:1527020083025};\\\", \\\"{x:1448,y:823,t:1527020083034};\\\", \\\"{x:1450,y:826,t:1527020083050};\\\", \\\"{x:1457,y:828,t:1527020083068};\\\", \\\"{x:1462,y:830,t:1527020083085};\\\", \\\"{x:1470,y:833,t:1527020083101};\\\", \\\"{x:1474,y:834,t:1527020083117};\\\", \\\"{x:1475,y:835,t:1527020083137};\\\", \\\"{x:1476,y:835,t:1527020083184};\\\", \\\"{x:1478,y:836,t:1527020083666};\\\", \\\"{x:1480,y:839,t:1527020083674};\\\", \\\"{x:1483,y:840,t:1527020083684};\\\", \\\"{x:1486,y:842,t:1527020083701};\\\", \\\"{x:1489,y:846,t:1527020083718};\\\", \\\"{x:1494,y:854,t:1527020083734};\\\", \\\"{x:1499,y:865,t:1527020083751};\\\", \\\"{x:1500,y:870,t:1527020083767};\\\", \\\"{x:1503,y:878,t:1527020083784};\\\", \\\"{x:1509,y:891,t:1527020083801};\\\", \\\"{x:1512,y:897,t:1527020083817};\\\", \\\"{x:1515,y:903,t:1527020083835};\\\", \\\"{x:1518,y:909,t:1527020083852};\\\", \\\"{x:1519,y:911,t:1527020083867};\\\", \\\"{x:1520,y:911,t:1527020083884};\\\", \\\"{x:1521,y:912,t:1527020083901};\\\", \\\"{x:1521,y:913,t:1527020083917};\\\", \\\"{x:1521,y:914,t:1527020083935};\\\", \\\"{x:1522,y:916,t:1527020083951};\\\", \\\"{x:1526,y:922,t:1527020083967};\\\", \\\"{x:1529,y:927,t:1527020083984};\\\", \\\"{x:1531,y:930,t:1527020084001};\\\", \\\"{x:1532,y:932,t:1527020084017};\\\", \\\"{x:1533,y:934,t:1527020084034};\\\", \\\"{x:1535,y:936,t:1527020084051};\\\", \\\"{x:1537,y:938,t:1527020084067};\\\", \\\"{x:1538,y:940,t:1527020084084};\\\", \\\"{x:1539,y:941,t:1527020084101};\\\", \\\"{x:1541,y:942,t:1527020084117};\\\", \\\"{x:1543,y:945,t:1527020084134};\\\", \\\"{x:1544,y:948,t:1527020084151};\\\", \\\"{x:1545,y:950,t:1527020084168};\\\", \\\"{x:1547,y:953,t:1527020084184};\\\", \\\"{x:1549,y:957,t:1527020084201};\\\", \\\"{x:1550,y:959,t:1527020084218};\\\", \\\"{x:1550,y:960,t:1527020084234};\\\", \\\"{x:1551,y:960,t:1527020084251};\\\", \\\"{x:1549,y:960,t:1527020084672};\\\", \\\"{x:1548,y:960,t:1527020084684};\\\", \\\"{x:1543,y:960,t:1527020084700};\\\", \\\"{x:1539,y:960,t:1527020084717};\\\", \\\"{x:1534,y:960,t:1527020084734};\\\", \\\"{x:1527,y:960,t:1527020084750};\\\", \\\"{x:1517,y:958,t:1527020084768};\\\", \\\"{x:1504,y:954,t:1527020084784};\\\", \\\"{x:1490,y:947,t:1527020084800};\\\", \\\"{x:1486,y:944,t:1527020084818};\\\", \\\"{x:1484,y:938,t:1527020084834};\\\", \\\"{x:1483,y:933,t:1527020084851};\\\", \\\"{x:1482,y:924,t:1527020084867};\\\", \\\"{x:1482,y:914,t:1527020084884};\\\", \\\"{x:1482,y:902,t:1527020084901};\\\", \\\"{x:1482,y:888,t:1527020084918};\\\", \\\"{x:1482,y:877,t:1527020084934};\\\", \\\"{x:1482,y:867,t:1527020084951};\\\", \\\"{x:1482,y:855,t:1527020084968};\\\", \\\"{x:1486,y:844,t:1527020084983};\\\", \\\"{x:1490,y:830,t:1527020085000};\\\", \\\"{x:1491,y:824,t:1527020085018};\\\", \\\"{x:1492,y:821,t:1527020085033};\\\", \\\"{x:1493,y:821,t:1527020085051};\\\", \\\"{x:1492,y:821,t:1527020085169};\\\", \\\"{x:1489,y:824,t:1527020085185};\\\", \\\"{x:1485,y:842,t:1527020085201};\\\", \\\"{x:1485,y:848,t:1527020085218};\\\", \\\"{x:1485,y:853,t:1527020085234};\\\", \\\"{x:1485,y:859,t:1527020085252};\\\", \\\"{x:1485,y:863,t:1527020085268};\\\", \\\"{x:1485,y:868,t:1527020085285};\\\", \\\"{x:1485,y:873,t:1527020085301};\\\", \\\"{x:1485,y:879,t:1527020085318};\\\", \\\"{x:1485,y:885,t:1527020085334};\\\", \\\"{x:1485,y:892,t:1527020085351};\\\", \\\"{x:1486,y:896,t:1527020085368};\\\", \\\"{x:1486,y:899,t:1527020085384};\\\", \\\"{x:1489,y:906,t:1527020085402};\\\", \\\"{x:1489,y:910,t:1527020085418};\\\", \\\"{x:1490,y:913,t:1527020085434};\\\", \\\"{x:1492,y:917,t:1527020085451};\\\", \\\"{x:1492,y:919,t:1527020085468};\\\", \\\"{x:1493,y:922,t:1527020085484};\\\", \\\"{x:1494,y:924,t:1527020085501};\\\", \\\"{x:1494,y:926,t:1527020085518};\\\", \\\"{x:1495,y:928,t:1527020085534};\\\", \\\"{x:1496,y:931,t:1527020085551};\\\", \\\"{x:1496,y:933,t:1527020085569};\\\", \\\"{x:1496,y:935,t:1527020085585};\\\", \\\"{x:1496,y:937,t:1527020085601};\\\", \\\"{x:1497,y:939,t:1527020085618};\\\", \\\"{x:1497,y:940,t:1527020085635};\\\", \\\"{x:1497,y:941,t:1527020085652};\\\", \\\"{x:1497,y:942,t:1527020085673};\\\", \\\"{x:1498,y:945,t:1527020085685};\\\", \\\"{x:1498,y:946,t:1527020085701};\\\", \\\"{x:1498,y:947,t:1527020085719};\\\", \\\"{x:1499,y:949,t:1527020085734};\\\", \\\"{x:1500,y:950,t:1527020085752};\\\", \\\"{x:1500,y:951,t:1527020085769};\\\", \\\"{x:1500,y:952,t:1527020085785};\\\", \\\"{x:1500,y:953,t:1527020085802};\\\", \\\"{x:1502,y:955,t:1527020085818};\\\", \\\"{x:1502,y:956,t:1527020085834};\\\", \\\"{x:1503,y:958,t:1527020085851};\\\", \\\"{x:1505,y:960,t:1527020085868};\\\", \\\"{x:1509,y:961,t:1527020085884};\\\", \\\"{x:1516,y:963,t:1527020085901};\\\", \\\"{x:1520,y:963,t:1527020085918};\\\", \\\"{x:1524,y:963,t:1527020085935};\\\", \\\"{x:1527,y:963,t:1527020085951};\\\", \\\"{x:1530,y:963,t:1527020085968};\\\", \\\"{x:1534,y:963,t:1527020085985};\\\", \\\"{x:1537,y:963,t:1527020086001};\\\", \\\"{x:1538,y:963,t:1527020086018};\\\", \\\"{x:1540,y:963,t:1527020086036};\\\", \\\"{x:1542,y:963,t:1527020086057};\\\", \\\"{x:1544,y:963,t:1527020086068};\\\", \\\"{x:1550,y:962,t:1527020086086};\\\", \\\"{x:1555,y:962,t:1527020086101};\\\", \\\"{x:1556,y:962,t:1527020086119};\\\", \\\"{x:1556,y:961,t:1527020086234};\\\", \\\"{x:1556,y:960,t:1527020086249};\\\", \\\"{x:1556,y:959,t:1527020086257};\\\", \\\"{x:1556,y:958,t:1527020086268};\\\", \\\"{x:1556,y:956,t:1527020086296};\\\", \\\"{x:1556,y:955,t:1527020086304};\\\", \\\"{x:1556,y:954,t:1527020086317};\\\", \\\"{x:1556,y:953,t:1527020086335};\\\", \\\"{x:1556,y:951,t:1527020086350};\\\", \\\"{x:1555,y:950,t:1527020086368};\\\", \\\"{x:1555,y:949,t:1527020086384};\\\", \\\"{x:1554,y:948,t:1527020086449};\\\", \\\"{x:1552,y:948,t:1527020086738};\\\", \\\"{x:1552,y:949,t:1527020086752};\\\", \\\"{x:1551,y:951,t:1527020086769};\\\", \\\"{x:1551,y:953,t:1527020086786};\\\", \\\"{x:1549,y:954,t:1527020087273};\\\", \\\"{x:1545,y:953,t:1527020087285};\\\", \\\"{x:1530,y:944,t:1527020087302};\\\", \\\"{x:1514,y:934,t:1527020087318};\\\", \\\"{x:1502,y:926,t:1527020087336};\\\", \\\"{x:1492,y:917,t:1527020087352};\\\", \\\"{x:1485,y:908,t:1527020087368};\\\", \\\"{x:1482,y:901,t:1527020087385};\\\", \\\"{x:1481,y:897,t:1527020087403};\\\", \\\"{x:1480,y:894,t:1527020087418};\\\", \\\"{x:1480,y:890,t:1527020087435};\\\", \\\"{x:1480,y:885,t:1527020087452};\\\", \\\"{x:1480,y:880,t:1527020087468};\\\", \\\"{x:1480,y:876,t:1527020087485};\\\", \\\"{x:1480,y:871,t:1527020087503};\\\", \\\"{x:1480,y:869,t:1527020087519};\\\", \\\"{x:1480,y:866,t:1527020087535};\\\", \\\"{x:1481,y:865,t:1527020087553};\\\", \\\"{x:1481,y:862,t:1527020087569};\\\", \\\"{x:1483,y:857,t:1527020087585};\\\", \\\"{x:1483,y:856,t:1527020087602};\\\", \\\"{x:1483,y:855,t:1527020087619};\\\", \\\"{x:1483,y:853,t:1527020087635};\\\", \\\"{x:1483,y:852,t:1527020087652};\\\", \\\"{x:1483,y:850,t:1527020087669};\\\", \\\"{x:1483,y:847,t:1527020087685};\\\", \\\"{x:1483,y:845,t:1527020087703};\\\", \\\"{x:1483,y:841,t:1527020087719};\\\", \\\"{x:1482,y:838,t:1527020087735};\\\", \\\"{x:1481,y:836,t:1527020087752};\\\", \\\"{x:1481,y:835,t:1527020087769};\\\", \\\"{x:1481,y:833,t:1527020087802};\\\", \\\"{x:1480,y:832,t:1527020087832};\\\", \\\"{x:1480,y:833,t:1527020088025};\\\", \\\"{x:1480,y:836,t:1527020088036};\\\", \\\"{x:1481,y:841,t:1527020088053};\\\", \\\"{x:1483,y:846,t:1527020088068};\\\", \\\"{x:1484,y:851,t:1527020088085};\\\", \\\"{x:1486,y:855,t:1527020088102};\\\", \\\"{x:1487,y:859,t:1527020088118};\\\", \\\"{x:1488,y:861,t:1527020088135};\\\", \\\"{x:1489,y:865,t:1527020088152};\\\", \\\"{x:1490,y:870,t:1527020088169};\\\", \\\"{x:1491,y:872,t:1527020088185};\\\", \\\"{x:1491,y:875,t:1527020088202};\\\", \\\"{x:1492,y:879,t:1527020088218};\\\", \\\"{x:1493,y:881,t:1527020088234};\\\", \\\"{x:1494,y:882,t:1527020088252};\\\", \\\"{x:1495,y:885,t:1527020088268};\\\", \\\"{x:1497,y:888,t:1527020088285};\\\", \\\"{x:1498,y:892,t:1527020088302};\\\", \\\"{x:1499,y:896,t:1527020088318};\\\", \\\"{x:1501,y:897,t:1527020088335};\\\", \\\"{x:1502,y:899,t:1527020088352};\\\", \\\"{x:1502,y:900,t:1527020088369};\\\", \\\"{x:1503,y:900,t:1527020088385};\\\", \\\"{x:1503,y:897,t:1527020088537};\\\", \\\"{x:1502,y:893,t:1527020088552};\\\", \\\"{x:1500,y:886,t:1527020088569};\\\", \\\"{x:1498,y:875,t:1527020088586};\\\", \\\"{x:1495,y:869,t:1527020088602};\\\", \\\"{x:1494,y:863,t:1527020088619};\\\", \\\"{x:1491,y:859,t:1527020088636};\\\", \\\"{x:1491,y:857,t:1527020088652};\\\", \\\"{x:1491,y:855,t:1527020088669};\\\", \\\"{x:1491,y:851,t:1527020088685};\\\", \\\"{x:1490,y:848,t:1527020088703};\\\", \\\"{x:1488,y:845,t:1527020088719};\\\", \\\"{x:1488,y:843,t:1527020088735};\\\", \\\"{x:1488,y:841,t:1527020088753};\\\", \\\"{x:1488,y:840,t:1527020088770};\\\", \\\"{x:1488,y:839,t:1527020088785};\\\", \\\"{x:1487,y:839,t:1527020088961};\\\", \\\"{x:1487,y:843,t:1527020088969};\\\", \\\"{x:1487,y:852,t:1527020088985};\\\", \\\"{x:1487,y:861,t:1527020089002};\\\", \\\"{x:1487,y:868,t:1527020089020};\\\", \\\"{x:1487,y:875,t:1527020089035};\\\", \\\"{x:1487,y:880,t:1527020089052};\\\", \\\"{x:1487,y:884,t:1527020089070};\\\", \\\"{x:1487,y:890,t:1527020089085};\\\", \\\"{x:1488,y:896,t:1527020089103};\\\", \\\"{x:1489,y:899,t:1527020089120};\\\", \\\"{x:1489,y:903,t:1527020089136};\\\", \\\"{x:1490,y:906,t:1527020089153};\\\", \\\"{x:1490,y:907,t:1527020089169};\\\", \\\"{x:1490,y:908,t:1527020089193};\\\", \\\"{x:1490,y:909,t:1527020089203};\\\", \\\"{x:1491,y:911,t:1527020089219};\\\", \\\"{x:1491,y:914,t:1527020089236};\\\", \\\"{x:1492,y:916,t:1527020089252};\\\", \\\"{x:1492,y:918,t:1527020089269};\\\", \\\"{x:1493,y:921,t:1527020089285};\\\", \\\"{x:1493,y:922,t:1527020089302};\\\", \\\"{x:1493,y:923,t:1527020089319};\\\", \\\"{x:1495,y:925,t:1527020089335};\\\", \\\"{x:1495,y:927,t:1527020089352};\\\", \\\"{x:1495,y:929,t:1527020089368};\\\", \\\"{x:1496,y:931,t:1527020089387};\\\", \\\"{x:1497,y:934,t:1527020089403};\\\", \\\"{x:1497,y:936,t:1527020089420};\\\", \\\"{x:1498,y:939,t:1527020089436};\\\", \\\"{x:1498,y:941,t:1527020089453};\\\", \\\"{x:1498,y:943,t:1527020089469};\\\", \\\"{x:1499,y:944,t:1527020089486};\\\", \\\"{x:1499,y:945,t:1527020089502};\\\", \\\"{x:1499,y:947,t:1527020089519};\\\", \\\"{x:1499,y:948,t:1527020089537};\\\", \\\"{x:1499,y:951,t:1527020089553};\\\", \\\"{x:1498,y:958,t:1527020089569};\\\", \\\"{x:1497,y:965,t:1527020089586};\\\", \\\"{x:1497,y:971,t:1527020089602};\\\", \\\"{x:1497,y:975,t:1527020089619};\\\", \\\"{x:1497,y:978,t:1527020089636};\\\", \\\"{x:1497,y:981,t:1527020089652};\\\", \\\"{x:1497,y:983,t:1527020089669};\\\", \\\"{x:1495,y:985,t:1527020089687};\\\", \\\"{x:1495,y:986,t:1527020089705};\\\", \\\"{x:1494,y:986,t:1527020090066};\\\", \\\"{x:1493,y:986,t:1527020090073};\\\", \\\"{x:1492,y:985,t:1527020090087};\\\", \\\"{x:1492,y:984,t:1527020090102};\\\", \\\"{x:1490,y:982,t:1527020090119};\\\", \\\"{x:1487,y:978,t:1527020090137};\\\", \\\"{x:1487,y:975,t:1527020090152};\\\", \\\"{x:1485,y:971,t:1527020090169};\\\", \\\"{x:1484,y:968,t:1527020090187};\\\", \\\"{x:1483,y:967,t:1527020090202};\\\", \\\"{x:1483,y:966,t:1527020090219};\\\", \\\"{x:1482,y:964,t:1527020090236};\\\", \\\"{x:1481,y:962,t:1527020090252};\\\", \\\"{x:1480,y:958,t:1527020090269};\\\", \\\"{x:1480,y:955,t:1527020090285};\\\", \\\"{x:1480,y:950,t:1527020090302};\\\", \\\"{x:1478,y:947,t:1527020090319};\\\", \\\"{x:1478,y:944,t:1527020090336};\\\", \\\"{x:1477,y:943,t:1527020090352};\\\", \\\"{x:1477,y:941,t:1527020090369};\\\", \\\"{x:1477,y:940,t:1527020090386};\\\", \\\"{x:1476,y:940,t:1527020090402};\\\", \\\"{x:1476,y:939,t:1527020090425};\\\", \\\"{x:1476,y:938,t:1527020090440};\\\", \\\"{x:1476,y:937,t:1527020090457};\\\", \\\"{x:1475,y:936,t:1527020090481};\\\", \\\"{x:1475,y:935,t:1527020090505};\\\", \\\"{x:1475,y:934,t:1527020090520};\\\", \\\"{x:1475,y:933,t:1527020090537};\\\", \\\"{x:1475,y:932,t:1527020090577};\\\", \\\"{x:1475,y:931,t:1527020090609};\\\", \\\"{x:1474,y:931,t:1527020090619};\\\", \\\"{x:1474,y:930,t:1527020090636};\\\", \\\"{x:1473,y:928,t:1527020090653};\\\", \\\"{x:1473,y:926,t:1527020090670};\\\", \\\"{x:1473,y:922,t:1527020090687};\\\", \\\"{x:1471,y:917,t:1527020090703};\\\", \\\"{x:1470,y:907,t:1527020090719};\\\", \\\"{x:1469,y:893,t:1527020090736};\\\", \\\"{x:1465,y:868,t:1527020090753};\\\", \\\"{x:1462,y:856,t:1527020090769};\\\", \\\"{x:1461,y:849,t:1527020090786};\\\", \\\"{x:1460,y:845,t:1527020090803};\\\", \\\"{x:1459,y:842,t:1527020090819};\\\", \\\"{x:1459,y:841,t:1527020090837};\\\", \\\"{x:1459,y:838,t:1527020090854};\\\", \\\"{x:1459,y:837,t:1527020090870};\\\", \\\"{x:1459,y:836,t:1527020090886};\\\", \\\"{x:1459,y:835,t:1527020091154};\\\", \\\"{x:1461,y:834,t:1527020091169};\\\", \\\"{x:1465,y:831,t:1527020091186};\\\", \\\"{x:1467,y:831,t:1527020091225};\\\", \\\"{x:1468,y:830,t:1527020091378};\\\", \\\"{x:1469,y:830,t:1527020091387};\\\", \\\"{x:1470,y:829,t:1527020091403};\\\", \\\"{x:1471,y:829,t:1527020091420};\\\", \\\"{x:1472,y:828,t:1527020091436};\\\", \\\"{x:1473,y:828,t:1527020091761};\\\", \\\"{x:1474,y:828,t:1527020091770};\\\", \\\"{x:1478,y:825,t:1527020091786};\\\", \\\"{x:1481,y:825,t:1527020091803};\\\", \\\"{x:1481,y:824,t:1527020091821};\\\", \\\"{x:1482,y:821,t:1527020092721};\\\", \\\"{x:1483,y:817,t:1527020092745};\\\", \\\"{x:1485,y:814,t:1527020092753};\\\", \\\"{x:1489,y:804,t:1527020092770};\\\", \\\"{x:1492,y:797,t:1527020092787};\\\", \\\"{x:1495,y:793,t:1527020092804};\\\", \\\"{x:1497,y:790,t:1527020092821};\\\", \\\"{x:1498,y:787,t:1527020092836};\\\", \\\"{x:1499,y:783,t:1527020092854};\\\", \\\"{x:1503,y:776,t:1527020092870};\\\", \\\"{x:1508,y:768,t:1527020092887};\\\", \\\"{x:1514,y:757,t:1527020092904};\\\", \\\"{x:1521,y:746,t:1527020092921};\\\", \\\"{x:1525,y:736,t:1527020092937};\\\", \\\"{x:1528,y:730,t:1527020092953};\\\", \\\"{x:1530,y:724,t:1527020092971};\\\", \\\"{x:1531,y:721,t:1527020092987};\\\", \\\"{x:1531,y:720,t:1527020093003};\\\", \\\"{x:1531,y:719,t:1527020093025};\\\", \\\"{x:1532,y:719,t:1527020093633};\\\", \\\"{x:1534,y:713,t:1527020093641};\\\", \\\"{x:1540,y:703,t:1527020093654};\\\", \\\"{x:1547,y:687,t:1527020093671};\\\", \\\"{x:1552,y:679,t:1527020093687};\\\", \\\"{x:1556,y:672,t:1527020093704};\\\", \\\"{x:1561,y:665,t:1527020093721};\\\", \\\"{x:1562,y:660,t:1527020093737};\\\", \\\"{x:1563,y:657,t:1527020093754};\\\", \\\"{x:1564,y:657,t:1527020093770};\\\", \\\"{x:1565,y:655,t:1527020093787};\\\", \\\"{x:1565,y:654,t:1527020093809};\\\", \\\"{x:1565,y:653,t:1527020106341};\\\", \\\"{x:1557,y:655,t:1527020107685};\\\", \\\"{x:1532,y:656,t:1527020107696};\\\", \\\"{x:1433,y:664,t:1527020107712};\\\", \\\"{x:1322,y:664,t:1527020107729};\\\", \\\"{x:1181,y:664,t:1527020107746};\\\", \\\"{x:1029,y:664,t:1527020107762};\\\", \\\"{x:816,y:664,t:1527020107780};\\\", \\\"{x:758,y:664,t:1527020107795};\\\", \\\"{x:638,y:654,t:1527020107812};\\\", \\\"{x:597,y:644,t:1527020107829};\\\", \\\"{x:580,y:639,t:1527020107845};\\\", \\\"{x:573,y:635,t:1527020107863};\\\", \\\"{x:572,y:635,t:1527020107878};\\\", \\\"{x:571,y:635,t:1527020107908};\\\", \\\"{x:568,y:633,t:1527020107916};\\\", \\\"{x:568,y:632,t:1527020107928};\\\", \\\"{x:564,y:630,t:1527020107947};\\\", \\\"{x:561,y:626,t:1527020107962};\\\", \\\"{x:560,y:622,t:1527020107979};\\\", \\\"{x:560,y:611,t:1527020107990};\\\", \\\"{x:560,y:599,t:1527020108007};\\\", \\\"{x:560,y:588,t:1527020108023};\\\", \\\"{x:567,y:576,t:1527020108040};\\\", \\\"{x:578,y:559,t:1527020108062};\\\", \\\"{x:583,y:549,t:1527020108078};\\\", \\\"{x:586,y:544,t:1527020108095};\\\", \\\"{x:587,y:540,t:1527020108112};\\\", \\\"{x:588,y:537,t:1527020108128};\\\", \\\"{x:593,y:529,t:1527020108145};\\\", \\\"{x:596,y:524,t:1527020108163};\\\", \\\"{x:599,y:520,t:1527020108179};\\\", \\\"{x:601,y:518,t:1527020108196};\\\", \\\"{x:603,y:515,t:1527020108213};\\\", \\\"{x:607,y:511,t:1527020108229};\\\", \\\"{x:612,y:506,t:1527020108245};\\\", \\\"{x:615,y:502,t:1527020108262};\\\", \\\"{x:617,y:499,t:1527020108278};\\\", \\\"{x:618,y:498,t:1527020108296};\\\", \\\"{x:618,y:497,t:1527020108312};\\\", \\\"{x:619,y:496,t:1527020108420};\\\", \\\"{x:619,y:496,t:1527020108432};\\\", \\\"{x:617,y:496,t:1527020108491};\\\", \\\"{x:611,y:507,t:1527020108500};\\\", \\\"{x:601,y:535,t:1527020108513};\\\", \\\"{x:585,y:598,t:1527020108530};\\\", \\\"{x:566,y:665,t:1527020108545};\\\", \\\"{x:555,y:704,t:1527020108563};\\\", \\\"{x:543,y:734,t:1527020108580};\\\", \\\"{x:535,y:754,t:1527020108595};\\\", \\\"{x:526,y:777,t:1527020108612};\\\", \\\"{x:522,y:785,t:1527020108630};\\\", \\\"{x:522,y:787,t:1527020108645};\\\", \\\"{x:520,y:790,t:1527020108663};\\\", \\\"{x:519,y:794,t:1527020108679};\\\", \\\"{x:517,y:797,t:1527020108695};\\\", \\\"{x:517,y:795,t:1527020108804};\\\", \\\"{x:518,y:790,t:1527020108812};\\\", \\\"{x:519,y:780,t:1527020108829};\\\", \\\"{x:519,y:772,t:1527020108845};\\\", \\\"{x:519,y:767,t:1527020108863};\\\", \\\"{x:520,y:763,t:1527020108879};\\\", \\\"{x:520,y:761,t:1527020108896};\\\", \\\"{x:522,y:755,t:1527020109405};\\\", \\\"{x:523,y:751,t:1527020109414};\\\", \\\"{x:524,y:745,t:1527020109430};\\\", \\\"{x:525,y:743,t:1527020109446};\\\", \\\"{x:526,y:740,t:1527020109462};\\\", \\\"{x:526,y:738,t:1527020109516};\\\" ] }, { \\\"rt\\\": 31217, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 766232, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O -B -B -F -B -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:733,t:1527020112493};\\\", \\\"{x:529,y:727,t:1527020112500};\\\", \\\"{x:536,y:714,t:1527020112518};\\\", \\\"{x:542,y:702,t:1527020112533};\\\", \\\"{x:550,y:688,t:1527020112548};\\\", \\\"{x:557,y:680,t:1527020112565};\\\", \\\"{x:561,y:674,t:1527020112582};\\\", \\\"{x:568,y:662,t:1527020112599};\\\", \\\"{x:572,y:654,t:1527020112615};\\\", \\\"{x:572,y:654,t:1527020112632};\\\", \\\"{x:572,y:656,t:1527020112956};\\\", \\\"{x:572,y:657,t:1527020112988};\\\", \\\"{x:573,y:657,t:1527020113069};\\\", \\\"{x:575,y:657,t:1527020113081};\\\", \\\"{x:587,y:657,t:1527020113099};\\\", \\\"{x:627,y:659,t:1527020113116};\\\", \\\"{x:685,y:664,t:1527020113133};\\\", \\\"{x:757,y:675,t:1527020113149};\\\", \\\"{x:838,y:686,t:1527020113165};\\\", \\\"{x:899,y:694,t:1527020113182};\\\", \\\"{x:955,y:702,t:1527020113198};\\\", \\\"{x:998,y:709,t:1527020113216};\\\", \\\"{x:1023,y:714,t:1527020113231};\\\", \\\"{x:1040,y:718,t:1527020113249};\\\", \\\"{x:1055,y:722,t:1527020113266};\\\", \\\"{x:1067,y:728,t:1527020113282};\\\", \\\"{x:1086,y:734,t:1527020113299};\\\", \\\"{x:1120,y:738,t:1527020113316};\\\", \\\"{x:1139,y:742,t:1527020113332};\\\", \\\"{x:1152,y:745,t:1527020113349};\\\", \\\"{x:1155,y:745,t:1527020113366};\\\", \\\"{x:1157,y:745,t:1527020113382};\\\", \\\"{x:1157,y:744,t:1527020114349};\\\", \\\"{x:1157,y:739,t:1527020114366};\\\", \\\"{x:1164,y:731,t:1527020114382};\\\", \\\"{x:1177,y:718,t:1527020114399};\\\", \\\"{x:1189,y:707,t:1527020114416};\\\", \\\"{x:1197,y:702,t:1527020114432};\\\", \\\"{x:1205,y:695,t:1527020114449};\\\", \\\"{x:1214,y:688,t:1527020114466};\\\", \\\"{x:1221,y:683,t:1527020114482};\\\", \\\"{x:1228,y:675,t:1527020114500};\\\", \\\"{x:1238,y:665,t:1527020114516};\\\", \\\"{x:1244,y:657,t:1527020114532};\\\", \\\"{x:1247,y:642,t:1527020114549};\\\", \\\"{x:1247,y:641,t:1527020114566};\\\", \\\"{x:1247,y:640,t:1527020114583};\\\", \\\"{x:1249,y:640,t:1527020114892};\\\", \\\"{x:1250,y:640,t:1527020114901};\\\", \\\"{x:1254,y:638,t:1527020114916};\\\", \\\"{x:1266,y:638,t:1527020114932};\\\", \\\"{x:1288,y:639,t:1527020114950};\\\", \\\"{x:1318,y:647,t:1527020114966};\\\", \\\"{x:1354,y:652,t:1527020114982};\\\", \\\"{x:1384,y:661,t:1527020114999};\\\", \\\"{x:1419,y:672,t:1527020115016};\\\", \\\"{x:1444,y:683,t:1527020115032};\\\", \\\"{x:1458,y:689,t:1527020115050};\\\", \\\"{x:1468,y:697,t:1527020115066};\\\", \\\"{x:1473,y:702,t:1527020115082};\\\", \\\"{x:1475,y:704,t:1527020115099};\\\", \\\"{x:1479,y:710,t:1527020115116};\\\", \\\"{x:1482,y:715,t:1527020115132};\\\", \\\"{x:1488,y:723,t:1527020115149};\\\", \\\"{x:1494,y:731,t:1527020115167};\\\", \\\"{x:1504,y:743,t:1527020115182};\\\", \\\"{x:1512,y:753,t:1527020115199};\\\", \\\"{x:1518,y:760,t:1527020115218};\\\", \\\"{x:1523,y:768,t:1527020115232};\\\", \\\"{x:1531,y:778,t:1527020115249};\\\", \\\"{x:1540,y:790,t:1527020115265};\\\", \\\"{x:1548,y:801,t:1527020115282};\\\", \\\"{x:1560,y:816,t:1527020115298};\\\", \\\"{x:1572,y:835,t:1527020115316};\\\", \\\"{x:1576,y:841,t:1527020115331};\\\", \\\"{x:1579,y:843,t:1527020115349};\\\", \\\"{x:1579,y:844,t:1527020115387};\\\", \\\"{x:1578,y:845,t:1527020115685};\\\", \\\"{x:1576,y:847,t:1527020115699};\\\", \\\"{x:1572,y:848,t:1527020115716};\\\", \\\"{x:1569,y:848,t:1527020115733};\\\", \\\"{x:1567,y:850,t:1527020115749};\\\", \\\"{x:1566,y:850,t:1527020115766};\\\", \\\"{x:1563,y:851,t:1527020115782};\\\", \\\"{x:1561,y:852,t:1527020115799};\\\", \\\"{x:1557,y:852,t:1527020115816};\\\", \\\"{x:1549,y:852,t:1527020115832};\\\", \\\"{x:1536,y:852,t:1527020115849};\\\", \\\"{x:1524,y:852,t:1527020115866};\\\", \\\"{x:1514,y:852,t:1527020115882};\\\", \\\"{x:1504,y:852,t:1527020115899};\\\", \\\"{x:1490,y:852,t:1527020115916};\\\", \\\"{x:1486,y:852,t:1527020115933};\\\", \\\"{x:1480,y:851,t:1527020115950};\\\", \\\"{x:1479,y:850,t:1527020115966};\\\", \\\"{x:1475,y:850,t:1527020115982};\\\", \\\"{x:1473,y:850,t:1527020116000};\\\", \\\"{x:1471,y:850,t:1527020116016};\\\", \\\"{x:1469,y:850,t:1527020116033};\\\", \\\"{x:1467,y:850,t:1527020116050};\\\", \\\"{x:1464,y:850,t:1527020116066};\\\", \\\"{x:1462,y:849,t:1527020116082};\\\", \\\"{x:1460,y:845,t:1527020116100};\\\", \\\"{x:1452,y:819,t:1527020116116};\\\", \\\"{x:1449,y:799,t:1527020116132};\\\", \\\"{x:1441,y:778,t:1527020116149};\\\", \\\"{x:1431,y:769,t:1527020116167};\\\", \\\"{x:1430,y:767,t:1527020116183};\\\", \\\"{x:1429,y:766,t:1527020116199};\\\", \\\"{x:1427,y:763,t:1527020116405};\\\", \\\"{x:1425,y:762,t:1527020116417};\\\", \\\"{x:1411,y:762,t:1527020116432};\\\", \\\"{x:1389,y:765,t:1527020116450};\\\", \\\"{x:1370,y:773,t:1527020116466};\\\", \\\"{x:1356,y:781,t:1527020116483};\\\", \\\"{x:1335,y:790,t:1527020116499};\\\", \\\"{x:1332,y:794,t:1527020116516};\\\", \\\"{x:1318,y:797,t:1527020116533};\\\", \\\"{x:1315,y:799,t:1527020116931};\\\", \\\"{x:1310,y:801,t:1527020116948};\\\", \\\"{x:1305,y:808,t:1527020116965};\\\", \\\"{x:1294,y:822,t:1527020116981};\\\", \\\"{x:1287,y:828,t:1527020116999};\\\", \\\"{x:1276,y:840,t:1527020117015};\\\", \\\"{x:1259,y:852,t:1527020117031};\\\", \\\"{x:1246,y:862,t:1527020117048};\\\", \\\"{x:1232,y:870,t:1527020117065};\\\", \\\"{x:1219,y:877,t:1527020117082};\\\", \\\"{x:1205,y:882,t:1527020117098};\\\", \\\"{x:1189,y:889,t:1527020117115};\\\", \\\"{x:1181,y:891,t:1527020117132};\\\", \\\"{x:1173,y:896,t:1527020117148};\\\", \\\"{x:1166,y:898,t:1527020117165};\\\", \\\"{x:1157,y:902,t:1527020117182};\\\", \\\"{x:1151,y:904,t:1527020117199};\\\", \\\"{x:1146,y:904,t:1527020117215};\\\", \\\"{x:1141,y:907,t:1527020117231};\\\", \\\"{x:1139,y:907,t:1527020117248};\\\", \\\"{x:1138,y:906,t:1527020117460};\\\", \\\"{x:1138,y:904,t:1527020117467};\\\", \\\"{x:1139,y:902,t:1527020117482};\\\", \\\"{x:1144,y:894,t:1527020117499};\\\", \\\"{x:1152,y:885,t:1527020117516};\\\", \\\"{x:1158,y:880,t:1527020117531};\\\", \\\"{x:1163,y:876,t:1527020117549};\\\", \\\"{x:1165,y:875,t:1527020117565};\\\", \\\"{x:1165,y:874,t:1527020117741};\\\", \\\"{x:1166,y:874,t:1527020117749};\\\", \\\"{x:1167,y:874,t:1527020118117};\\\", \\\"{x:1195,y:856,t:1527020118132};\\\", \\\"{x:1220,y:844,t:1527020118149};\\\", \\\"{x:1235,y:837,t:1527020118167};\\\", \\\"{x:1245,y:833,t:1527020118181};\\\", \\\"{x:1249,y:830,t:1527020118199};\\\", \\\"{x:1253,y:827,t:1527020118216};\\\", \\\"{x:1256,y:824,t:1527020118232};\\\", \\\"{x:1260,y:821,t:1527020118249};\\\", \\\"{x:1263,y:817,t:1527020118266};\\\", \\\"{x:1271,y:810,t:1527020118282};\\\", \\\"{x:1275,y:807,t:1527020118299};\\\", \\\"{x:1286,y:800,t:1527020118316};\\\", \\\"{x:1291,y:797,t:1527020118332};\\\", \\\"{x:1294,y:794,t:1527020118350};\\\", \\\"{x:1297,y:793,t:1527020118366};\\\", \\\"{x:1299,y:792,t:1527020118388};\\\", \\\"{x:1301,y:790,t:1527020118399};\\\", \\\"{x:1303,y:789,t:1527020118416};\\\", \\\"{x:1305,y:787,t:1527020118432};\\\", \\\"{x:1311,y:784,t:1527020118449};\\\", \\\"{x:1315,y:782,t:1527020118466};\\\", \\\"{x:1318,y:782,t:1527020118482};\\\", \\\"{x:1319,y:781,t:1527020118499};\\\", \\\"{x:1320,y:780,t:1527020118548};\\\", \\\"{x:1322,y:778,t:1527020118566};\\\", \\\"{x:1326,y:775,t:1527020118584};\\\", \\\"{x:1329,y:772,t:1527020118600};\\\", \\\"{x:1333,y:770,t:1527020118616};\\\", \\\"{x:1334,y:768,t:1527020118632};\\\", \\\"{x:1337,y:765,t:1527020118650};\\\", \\\"{x:1340,y:762,t:1527020118667};\\\", \\\"{x:1344,y:759,t:1527020118683};\\\", \\\"{x:1345,y:758,t:1527020118699};\\\", \\\"{x:1345,y:757,t:1527020118733};\\\", \\\"{x:1346,y:757,t:1527020118756};\\\", \\\"{x:1346,y:756,t:1527020118767};\\\", \\\"{x:1347,y:755,t:1527020118783};\\\", \\\"{x:1347,y:754,t:1527020118799};\\\", \\\"{x:1347,y:753,t:1527020118816};\\\", \\\"{x:1347,y:752,t:1527020118869};\\\", \\\"{x:1347,y:750,t:1527020118884};\\\", \\\"{x:1347,y:749,t:1527020118899};\\\", \\\"{x:1350,y:735,t:1527020118916};\\\", \\\"{x:1351,y:726,t:1527020118933};\\\", \\\"{x:1353,y:718,t:1527020118949};\\\", \\\"{x:1354,y:711,t:1527020118967};\\\", \\\"{x:1354,y:707,t:1527020118982};\\\", \\\"{x:1354,y:702,t:1527020118999};\\\", \\\"{x:1354,y:699,t:1527020119017};\\\", \\\"{x:1354,y:697,t:1527020119033};\\\", \\\"{x:1354,y:696,t:1527020119050};\\\", \\\"{x:1352,y:698,t:1527020119189};\\\", \\\"{x:1352,y:701,t:1527020119200};\\\", \\\"{x:1351,y:707,t:1527020119216};\\\", \\\"{x:1351,y:712,t:1527020119233};\\\", \\\"{x:1351,y:717,t:1527020119249};\\\", \\\"{x:1351,y:722,t:1527020119266};\\\", \\\"{x:1351,y:727,t:1527020119282};\\\", \\\"{x:1351,y:734,t:1527020119299};\\\", \\\"{x:1351,y:741,t:1527020119316};\\\", \\\"{x:1350,y:746,t:1527020119332};\\\", \\\"{x:1350,y:751,t:1527020119349};\\\", \\\"{x:1350,y:754,t:1527020119366};\\\", \\\"{x:1349,y:757,t:1527020119382};\\\", \\\"{x:1349,y:759,t:1527020119400};\\\", \\\"{x:1349,y:760,t:1527020119433};\\\", \\\"{x:1349,y:762,t:1527020119452};\\\", \\\"{x:1349,y:764,t:1527020119468};\\\", \\\"{x:1349,y:765,t:1527020119483};\\\", \\\"{x:1349,y:766,t:1527020119499};\\\", \\\"{x:1348,y:770,t:1527020119517};\\\", \\\"{x:1347,y:773,t:1527020119532};\\\", \\\"{x:1347,y:770,t:1527020119932};\\\", \\\"{x:1347,y:769,t:1527020119950};\\\", \\\"{x:1347,y:768,t:1527020119966};\\\", \\\"{x:1347,y:767,t:1527020120589};\\\", \\\"{x:1347,y:766,t:1527020120716};\\\", \\\"{x:1347,y:762,t:1527020120732};\\\", \\\"{x:1347,y:759,t:1527020120749};\\\", \\\"{x:1347,y:755,t:1527020120767};\\\", \\\"{x:1347,y:751,t:1527020120783};\\\", \\\"{x:1347,y:746,t:1527020120799};\\\", \\\"{x:1347,y:740,t:1527020120816};\\\", \\\"{x:1347,y:736,t:1527020120833};\\\", \\\"{x:1347,y:731,t:1527020120849};\\\", \\\"{x:1347,y:726,t:1527020120866};\\\", \\\"{x:1347,y:722,t:1527020120883};\\\", \\\"{x:1347,y:718,t:1527020120912};\\\", \\\"{x:1347,y:717,t:1527020120924};\\\", \\\"{x:1347,y:716,t:1527020120932};\\\", \\\"{x:1347,y:715,t:1527020121043};\\\", \\\"{x:1347,y:714,t:1527020121051};\\\", \\\"{x:1347,y:713,t:1527020121066};\\\", \\\"{x:1347,y:712,t:1527020121083};\\\", \\\"{x:1347,y:710,t:1527020121099};\\\", \\\"{x:1347,y:707,t:1527020121116};\\\", \\\"{x:1347,y:706,t:1527020121148};\\\", \\\"{x:1347,y:705,t:1527020121172};\\\", \\\"{x:1347,y:704,t:1527020121196};\\\", \\\"{x:1346,y:704,t:1527020121413};\\\", \\\"{x:1345,y:704,t:1527020121460};\\\", \\\"{x:1344,y:704,t:1527020121476};\\\", \\\"{x:1341,y:704,t:1527020121484};\\\", \\\"{x:1334,y:704,t:1527020121499};\\\", \\\"{x:1303,y:691,t:1527020121515};\\\", \\\"{x:1269,y:680,t:1527020121533};\\\", \\\"{x:1212,y:660,t:1527020121549};\\\", \\\"{x:1126,y:635,t:1527020121566};\\\", \\\"{x:1029,y:621,t:1527020121582};\\\", \\\"{x:932,y:606,t:1527020121599};\\\", \\\"{x:846,y:596,t:1527020121616};\\\", \\\"{x:782,y:588,t:1527020121633};\\\", \\\"{x:691,y:573,t:1527020121656};\\\", \\\"{x:650,y:570,t:1527020121673};\\\", \\\"{x:627,y:566,t:1527020121689};\\\", \\\"{x:613,y:565,t:1527020121706};\\\", \\\"{x:602,y:562,t:1527020121723};\\\", \\\"{x:589,y:560,t:1527020121739};\\\", \\\"{x:581,y:560,t:1527020121756};\\\", \\\"{x:574,y:558,t:1527020121773};\\\", \\\"{x:569,y:556,t:1527020121790};\\\", \\\"{x:568,y:556,t:1527020121806};\\\", \\\"{x:566,y:556,t:1527020121823};\\\", \\\"{x:565,y:554,t:1527020121840};\\\", \\\"{x:564,y:553,t:1527020121856};\\\", \\\"{x:563,y:553,t:1527020121872};\\\", \\\"{x:563,y:551,t:1527020121890};\\\", \\\"{x:563,y:549,t:1527020121906};\\\", \\\"{x:564,y:545,t:1527020121923};\\\", \\\"{x:572,y:539,t:1527020121940};\\\", \\\"{x:579,y:536,t:1527020121956};\\\", \\\"{x:584,y:534,t:1527020121973};\\\", \\\"{x:586,y:532,t:1527020121989};\\\", \\\"{x:588,y:532,t:1527020122006};\\\", \\\"{x:591,y:530,t:1527020122024};\\\", \\\"{x:594,y:529,t:1527020122040};\\\", \\\"{x:595,y:528,t:1527020122056};\\\", \\\"{x:597,y:527,t:1527020122073};\\\", \\\"{x:598,y:527,t:1527020122092};\\\", \\\"{x:598,y:526,t:1527020122108};\\\", \\\"{x:600,y:525,t:1527020122124};\\\", \\\"{x:602,y:525,t:1527020122140};\\\", \\\"{x:603,y:524,t:1527020122157};\\\", \\\"{x:604,y:524,t:1527020122179};\\\", \\\"{x:605,y:523,t:1527020122211};\\\", \\\"{x:605,y:522,t:1527020122260};\\\", \\\"{x:606,y:522,t:1527020122291};\\\", \\\"{x:604,y:524,t:1527020135885};\\\", \\\"{x:594,y:532,t:1527020135893};\\\", \\\"{x:585,y:539,t:1527020135904};\\\", \\\"{x:569,y:545,t:1527020135920};\\\", \\\"{x:551,y:552,t:1527020135933};\\\", \\\"{x:537,y:556,t:1527020135950};\\\", \\\"{x:525,y:560,t:1527020135967};\\\", \\\"{x:516,y:562,t:1527020135984};\\\", \\\"{x:510,y:563,t:1527020136000};\\\", \\\"{x:505,y:565,t:1527020136017};\\\", \\\"{x:501,y:566,t:1527020136034};\\\", \\\"{x:493,y:569,t:1527020136052};\\\", \\\"{x:488,y:570,t:1527020136067};\\\", \\\"{x:487,y:570,t:1527020136091};\\\", \\\"{x:486,y:570,t:1527020136101};\\\", \\\"{x:483,y:572,t:1527020136117};\\\", \\\"{x:477,y:575,t:1527020136134};\\\", \\\"{x:468,y:577,t:1527020136151};\\\", \\\"{x:461,y:579,t:1527020136168};\\\", \\\"{x:458,y:580,t:1527020136185};\\\", \\\"{x:455,y:581,t:1527020136201};\\\", \\\"{x:453,y:581,t:1527020136217};\\\", \\\"{x:452,y:583,t:1527020136324};\\\", \\\"{x:450,y:583,t:1527020136334};\\\", \\\"{x:448,y:584,t:1527020136351};\\\", \\\"{x:441,y:587,t:1527020136367};\\\", \\\"{x:436,y:589,t:1527020136385};\\\", \\\"{x:429,y:589,t:1527020136402};\\\", \\\"{x:425,y:589,t:1527020136418};\\\", \\\"{x:417,y:586,t:1527020136435};\\\", \\\"{x:406,y:574,t:1527020136451};\\\", \\\"{x:391,y:559,t:1527020136469};\\\", \\\"{x:376,y:550,t:1527020136485};\\\", \\\"{x:359,y:544,t:1527020136502};\\\", \\\"{x:338,y:539,t:1527020136518};\\\", \\\"{x:314,y:538,t:1527020136534};\\\", \\\"{x:294,y:537,t:1527020136551};\\\", \\\"{x:272,y:535,t:1527020136569};\\\", \\\"{x:257,y:535,t:1527020136584};\\\", \\\"{x:254,y:535,t:1527020136601};\\\", \\\"{x:254,y:534,t:1527020136659};\\\", \\\"{x:254,y:532,t:1527020136675};\\\", \\\"{x:254,y:530,t:1527020136684};\\\", \\\"{x:254,y:524,t:1527020136702};\\\", \\\"{x:254,y:521,t:1527020136718};\\\", \\\"{x:254,y:520,t:1527020136734};\\\", \\\"{x:251,y:517,t:1527020136752};\\\", \\\"{x:249,y:516,t:1527020136768};\\\", \\\"{x:249,y:515,t:1527020136795};\\\", \\\"{x:249,y:514,t:1527020137316};\\\", \\\"{x:249,y:513,t:1527020137356};\\\", \\\"{x:249,y:514,t:1527020137676};\\\", \\\"{x:249,y:521,t:1527020137686};\\\", \\\"{x:251,y:545,t:1527020137702};\\\", \\\"{x:261,y:578,t:1527020137719};\\\", \\\"{x:278,y:614,t:1527020137735};\\\", \\\"{x:300,y:652,t:1527020137753};\\\", \\\"{x:321,y:681,t:1527020137769};\\\", \\\"{x:338,y:703,t:1527020137785};\\\", \\\"{x:353,y:720,t:1527020137802};\\\", \\\"{x:361,y:731,t:1527020137818};\\\", \\\"{x:373,y:747,t:1527020137835};\\\", \\\"{x:378,y:755,t:1527020137852};\\\", \\\"{x:383,y:761,t:1527020137869};\\\", \\\"{x:384,y:764,t:1527020137885};\\\", \\\"{x:386,y:766,t:1527020137902};\\\", \\\"{x:387,y:767,t:1527020137919};\\\", \\\"{x:389,y:769,t:1527020137935};\\\", \\\"{x:390,y:771,t:1527020137953};\\\", \\\"{x:393,y:774,t:1527020137968};\\\", \\\"{x:398,y:778,t:1527020137986};\\\", \\\"{x:407,y:783,t:1527020138003};\\\", \\\"{x:416,y:789,t:1527020138018};\\\", \\\"{x:427,y:795,t:1527020138035};\\\", \\\"{x:431,y:797,t:1527020138052};\\\", \\\"{x:435,y:798,t:1527020138068};\\\", \\\"{x:435,y:799,t:1527020138086};\\\", \\\"{x:437,y:799,t:1527020138103};\\\", \\\"{x:438,y:799,t:1527020138119};\\\", \\\"{x:439,y:799,t:1527020138195};\\\", \\\"{x:441,y:799,t:1527020138203};\\\", \\\"{x:442,y:799,t:1527020138218};\\\", \\\"{x:448,y:798,t:1527020138235};\\\", \\\"{x:449,y:798,t:1527020138252};\\\", \\\"{x:449,y:796,t:1527020138332};\\\", \\\"{x:449,y:789,t:1527020138339};\\\", \\\"{x:447,y:778,t:1527020138353};\\\", \\\"{x:431,y:736,t:1527020138368};\\\", \\\"{x:396,y:673,t:1527020138385};\\\", \\\"{x:351,y:614,t:1527020138403};\\\", \\\"{x:303,y:570,t:1527020138419};\\\", \\\"{x:268,y:541,t:1527020138437};\\\", \\\"{x:253,y:527,t:1527020138452};\\\", \\\"{x:249,y:522,t:1527020138470};\\\", \\\"{x:247,y:520,t:1527020138486};\\\", \\\"{x:247,y:517,t:1527020138503};\\\", \\\"{x:247,y:514,t:1527020138519};\\\", \\\"{x:246,y:511,t:1527020138536};\\\", \\\"{x:245,y:507,t:1527020138552};\\\", \\\"{x:243,y:504,t:1527020138569};\\\", \\\"{x:243,y:503,t:1527020138586};\\\", \\\"{x:242,y:501,t:1527020138603};\\\", \\\"{x:240,y:498,t:1527020138619};\\\", \\\"{x:240,y:497,t:1527020138643};\\\", \\\"{x:238,y:497,t:1527020138748};\\\", \\\"{x:235,y:497,t:1527020138756};\\\", \\\"{x:232,y:497,t:1527020138769};\\\", \\\"{x:224,y:501,t:1527020138787};\\\", \\\"{x:210,y:505,t:1527020138803};\\\", \\\"{x:202,y:508,t:1527020138820};\\\", \\\"{x:201,y:509,t:1527020138837};\\\", \\\"{x:199,y:510,t:1527020138854};\\\", \\\"{x:198,y:510,t:1527020139284};\\\", \\\"{x:197,y:509,t:1527020139291};\\\", \\\"{x:197,y:508,t:1527020139303};\\\", \\\"{x:197,y:506,t:1527020139321};\\\", \\\"{x:195,y:504,t:1527020139336};\\\", \\\"{x:194,y:504,t:1527020140060};\\\", \\\"{x:192,y:504,t:1527020140071};\\\", \\\"{x:187,y:506,t:1527020140089};\\\", \\\"{x:185,y:508,t:1527020140105};\\\", \\\"{x:181,y:511,t:1527020140121};\\\", \\\"{x:177,y:512,t:1527020140137};\\\", \\\"{x:175,y:514,t:1527020140154};\\\", \\\"{x:174,y:514,t:1527020140170};\\\", \\\"{x:175,y:514,t:1527020141252};\\\", \\\"{x:176,y:514,t:1527020141260};\\\", \\\"{x:177,y:513,t:1527020141271};\\\", \\\"{x:179,y:512,t:1527020141356};\\\", \\\"{x:180,y:511,t:1527020141373};\\\", \\\"{x:181,y:510,t:1527020141388};\\\", \\\"{x:183,y:510,t:1527020141405};\\\", \\\"{x:184,y:509,t:1527020141421};\\\", \\\"{x:185,y:508,t:1527020141439};\\\", \\\"{x:186,y:507,t:1527020141455};\\\", \\\"{x:185,y:505,t:1527020141604};\\\", \\\"{x:183,y:504,t:1527020141611};\\\", \\\"{x:181,y:503,t:1527020141623};\\\", \\\"{x:179,y:503,t:1527020141639};\\\", \\\"{x:179,y:502,t:1527020141972};\\\", \\\"{x:177,y:502,t:1527020141980};\\\", \\\"{x:175,y:502,t:1527020141989};\\\", \\\"{x:173,y:502,t:1527020142006};\\\", \\\"{x:172,y:502,t:1527020142022};\\\", \\\"{x:171,y:503,t:1527020142076};\\\", \\\"{x:171,y:505,t:1527020142089};\\\", \\\"{x:169,y:518,t:1527020142107};\\\", \\\"{x:169,y:537,t:1527020142124};\\\", \\\"{x:184,y:567,t:1527020142140};\\\", \\\"{x:259,y:647,t:1527020142157};\\\", \\\"{x:330,y:698,t:1527020142172};\\\", \\\"{x:419,y:742,t:1527020142189};\\\", \\\"{x:503,y:770,t:1527020142206};\\\", \\\"{x:568,y:784,t:1527020142223};\\\", \\\"{x:619,y:792,t:1527020142239};\\\", \\\"{x:644,y:796,t:1527020142255};\\\", \\\"{x:653,y:796,t:1527020142272};\\\", \\\"{x:654,y:797,t:1527020142290};\\\", \\\"{x:655,y:797,t:1527020142363};\\\", \\\"{x:656,y:797,t:1527020142372};\\\", \\\"{x:656,y:796,t:1527020142389};\\\", \\\"{x:656,y:795,t:1527020142908};\\\", \\\"{x:654,y:790,t:1527020142923};\\\", \\\"{x:628,y:776,t:1527020142939};\\\", \\\"{x:577,y:754,t:1527020142955};\\\", \\\"{x:546,y:742,t:1527020142974};\\\", \\\"{x:524,y:736,t:1527020142988};\\\", \\\"{x:507,y:731,t:1527020143007};\\\", \\\"{x:503,y:731,t:1527020143022};\\\", \\\"{x:503,y:728,t:1527020143844};\\\", \\\"{x:504,y:725,t:1527020143858};\\\", \\\"{x:507,y:719,t:1527020143874};\\\", \\\"{x:512,y:715,t:1527020143891};\\\", \\\"{x:521,y:708,t:1527020143907};\\\", \\\"{x:526,y:704,t:1527020143923};\\\", \\\"{x:528,y:700,t:1527020143940};\\\", \\\"{x:528,y:698,t:1527020143957};\\\", \\\"{x:528,y:696,t:1527020143973};\\\" ] }, { \\\"rt\\\": 12508, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 780008, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:694,t:1527020144627};\\\", \\\"{x:529,y:693,t:1527020144641};\\\", \\\"{x:529,y:691,t:1527020144756};\\\", \\\"{x:529,y:690,t:1527020144763};\\\", \\\"{x:529,y:689,t:1527020144775};\\\", \\\"{x:529,y:687,t:1527020144790};\\\", \\\"{x:529,y:685,t:1527020144808};\\\", \\\"{x:529,y:684,t:1527020144824};\\\", \\\"{x:529,y:683,t:1527020144844};\\\", \\\"{x:530,y:681,t:1527020144875};\\\", \\\"{x:535,y:679,t:1527020145210};\\\", \\\"{x:548,y:675,t:1527020145225};\\\", \\\"{x:607,y:669,t:1527020145241};\\\", \\\"{x:765,y:667,t:1527020145258};\\\", \\\"{x:912,y:667,t:1527020145275};\\\", \\\"{x:1070,y:667,t:1527020145292};\\\", \\\"{x:1200,y:667,t:1527020145309};\\\", \\\"{x:1309,y:672,t:1527020145324};\\\", \\\"{x:1387,y:683,t:1527020145342};\\\", \\\"{x:1412,y:687,t:1527020145358};\\\", \\\"{x:1416,y:689,t:1527020145375};\\\", \\\"{x:1417,y:690,t:1527020145403};\\\", \\\"{x:1417,y:691,t:1527020145419};\\\", \\\"{x:1417,y:692,t:1527020145427};\\\", \\\"{x:1417,y:697,t:1527020145442};\\\", \\\"{x:1417,y:700,t:1527020145460};\\\", \\\"{x:1417,y:701,t:1527020145475};\\\", \\\"{x:1417,y:703,t:1527020145492};\\\", \\\"{x:1417,y:706,t:1527020145509};\\\", \\\"{x:1417,y:709,t:1527020145524};\\\", \\\"{x:1416,y:712,t:1527020145542};\\\", \\\"{x:1412,y:717,t:1527020145559};\\\", \\\"{x:1409,y:721,t:1527020145575};\\\", \\\"{x:1406,y:725,t:1527020145592};\\\", \\\"{x:1404,y:726,t:1527020145609};\\\", \\\"{x:1402,y:726,t:1527020145625};\\\", \\\"{x:1401,y:726,t:1527020145709};\\\", \\\"{x:1395,y:726,t:1527020145726};\\\", \\\"{x:1388,y:726,t:1527020145742};\\\", \\\"{x:1379,y:725,t:1527020145759};\\\", \\\"{x:1368,y:723,t:1527020145776};\\\", \\\"{x:1355,y:722,t:1527020145792};\\\", \\\"{x:1345,y:719,t:1527020145809};\\\", \\\"{x:1338,y:718,t:1527020145827};\\\", \\\"{x:1335,y:717,t:1527020145842};\\\", \\\"{x:1333,y:716,t:1527020145860};\\\", \\\"{x:1332,y:716,t:1527020145876};\\\", \\\"{x:1332,y:715,t:1527020145891};\\\", \\\"{x:1331,y:714,t:1527020145908};\\\", \\\"{x:1329,y:710,t:1527020145926};\\\", \\\"{x:1327,y:708,t:1527020145942};\\\", \\\"{x:1326,y:705,t:1527020145959};\\\", \\\"{x:1326,y:704,t:1527020145976};\\\", \\\"{x:1326,y:703,t:1527020145992};\\\", \\\"{x:1325,y:702,t:1527020146011};\\\", \\\"{x:1326,y:701,t:1527020146275};\\\", \\\"{x:1328,y:699,t:1527020146293};\\\", \\\"{x:1329,y:699,t:1527020146820};\\\", \\\"{x:1329,y:700,t:1527020146827};\\\", \\\"{x:1329,y:704,t:1527020146843};\\\", \\\"{x:1329,y:709,t:1527020146860};\\\", \\\"{x:1331,y:711,t:1527020146876};\\\", \\\"{x:1331,y:714,t:1527020146893};\\\", \\\"{x:1331,y:715,t:1527020146910};\\\", \\\"{x:1331,y:717,t:1527020146926};\\\", \\\"{x:1331,y:720,t:1527020146943};\\\", \\\"{x:1331,y:723,t:1527020146960};\\\", \\\"{x:1331,y:726,t:1527020146976};\\\", \\\"{x:1331,y:730,t:1527020146994};\\\", \\\"{x:1331,y:731,t:1527020147010};\\\", \\\"{x:1331,y:733,t:1527020147027};\\\", \\\"{x:1331,y:735,t:1527020147043};\\\", \\\"{x:1330,y:738,t:1527020147060};\\\", \\\"{x:1330,y:739,t:1527020147077};\\\", \\\"{x:1329,y:743,t:1527020147093};\\\", \\\"{x:1328,y:745,t:1527020147110};\\\", \\\"{x:1328,y:746,t:1527020147127};\\\", \\\"{x:1327,y:749,t:1527020147143};\\\", \\\"{x:1327,y:750,t:1527020147164};\\\", \\\"{x:1326,y:752,t:1527020147176};\\\", \\\"{x:1325,y:752,t:1527020147193};\\\", \\\"{x:1324,y:753,t:1527020147210};\\\", \\\"{x:1323,y:755,t:1527020147228};\\\", \\\"{x:1323,y:756,t:1527020147243};\\\", \\\"{x:1322,y:758,t:1527020147260};\\\", \\\"{x:1322,y:759,t:1527020147277};\\\", \\\"{x:1321,y:760,t:1527020147293};\\\", \\\"{x:1320,y:762,t:1527020147310};\\\", \\\"{x:1320,y:764,t:1527020147328};\\\", \\\"{x:1319,y:765,t:1527020147356};\\\", \\\"{x:1318,y:767,t:1527020147371};\\\", \\\"{x:1317,y:768,t:1527020147380};\\\", \\\"{x:1316,y:770,t:1527020147396};\\\", \\\"{x:1316,y:771,t:1527020147411};\\\", \\\"{x:1315,y:773,t:1527020147427};\\\", \\\"{x:1314,y:774,t:1527020147444};\\\", \\\"{x:1313,y:775,t:1527020147460};\\\", \\\"{x:1312,y:778,t:1527020147477};\\\", \\\"{x:1311,y:779,t:1527020147508};\\\", \\\"{x:1311,y:780,t:1527020147523};\\\", \\\"{x:1311,y:781,t:1527020147539};\\\", \\\"{x:1310,y:782,t:1527020147548};\\\", \\\"{x:1310,y:783,t:1527020147560};\\\", \\\"{x:1309,y:785,t:1527020147577};\\\", \\\"{x:1308,y:788,t:1527020147593};\\\", \\\"{x:1307,y:790,t:1527020147611};\\\", \\\"{x:1305,y:793,t:1527020147627};\\\", \\\"{x:1305,y:794,t:1527020147652};\\\", \\\"{x:1305,y:796,t:1527020147708};\\\", \\\"{x:1304,y:798,t:1527020147861};\\\", \\\"{x:1303,y:801,t:1527020147877};\\\", \\\"{x:1301,y:804,t:1527020147894};\\\", \\\"{x:1300,y:807,t:1527020147910};\\\", \\\"{x:1300,y:810,t:1527020147927};\\\", \\\"{x:1297,y:820,t:1527020147944};\\\", \\\"{x:1289,y:841,t:1527020147961};\\\", \\\"{x:1280,y:865,t:1527020147977};\\\", \\\"{x:1275,y:889,t:1527020147994};\\\", \\\"{x:1275,y:891,t:1527020148010};\\\", \\\"{x:1275,y:892,t:1527020148027};\\\", \\\"{x:1274,y:892,t:1527020149380};\\\", \\\"{x:1274,y:886,t:1527020150428};\\\", \\\"{x:1274,y:865,t:1527020150445};\\\", \\\"{x:1274,y:839,t:1527020150463};\\\", \\\"{x:1283,y:801,t:1527020150479};\\\", \\\"{x:1296,y:747,t:1527020150496};\\\", \\\"{x:1300,y:721,t:1527020150512};\\\", \\\"{x:1305,y:703,t:1527020150529};\\\", \\\"{x:1306,y:689,t:1527020150546};\\\", \\\"{x:1307,y:682,t:1527020150563};\\\", \\\"{x:1309,y:675,t:1527020150579};\\\", \\\"{x:1309,y:669,t:1527020150596};\\\", \\\"{x:1310,y:666,t:1527020150613};\\\", \\\"{x:1310,y:664,t:1527020150629};\\\", \\\"{x:1311,y:663,t:1527020150646};\\\", \\\"{x:1312,y:662,t:1527020150675};\\\", \\\"{x:1313,y:662,t:1527020150684};\\\", \\\"{x:1313,y:661,t:1527020150696};\\\", \\\"{x:1317,y:659,t:1527020150712};\\\", \\\"{x:1320,y:658,t:1527020150730};\\\", \\\"{x:1322,y:657,t:1527020150746};\\\", \\\"{x:1323,y:657,t:1527020150812};\\\", \\\"{x:1325,y:658,t:1527020150844};\\\", \\\"{x:1327,y:664,t:1527020150851};\\\", \\\"{x:1327,y:666,t:1527020150862};\\\", \\\"{x:1327,y:674,t:1527020150879};\\\", \\\"{x:1328,y:682,t:1527020150897};\\\", \\\"{x:1330,y:693,t:1527020150912};\\\", \\\"{x:1330,y:702,t:1527020150930};\\\", \\\"{x:1330,y:709,t:1527020150946};\\\", \\\"{x:1331,y:719,t:1527020150964};\\\", \\\"{x:1334,y:725,t:1527020150980};\\\", \\\"{x:1334,y:729,t:1527020150996};\\\", \\\"{x:1334,y:730,t:1527020151013};\\\", \\\"{x:1334,y:731,t:1527020151052};\\\", \\\"{x:1333,y:733,t:1527020151188};\\\", \\\"{x:1333,y:735,t:1527020151211};\\\", \\\"{x:1333,y:736,t:1527020151316};\\\", \\\"{x:1332,y:736,t:1527020151330};\\\", \\\"{x:1331,y:737,t:1527020151347};\\\", \\\"{x:1330,y:739,t:1527020151363};\\\", \\\"{x:1330,y:738,t:1527020152324};\\\", \\\"{x:1330,y:736,t:1527020152332};\\\", \\\"{x:1331,y:733,t:1527020152347};\\\", \\\"{x:1332,y:731,t:1527020152363};\\\", \\\"{x:1333,y:728,t:1527020152380};\\\", \\\"{x:1334,y:727,t:1527020152398};\\\", \\\"{x:1335,y:723,t:1527020152415};\\\", \\\"{x:1338,y:716,t:1527020152430};\\\", \\\"{x:1339,y:713,t:1527020152447};\\\", \\\"{x:1340,y:711,t:1527020152464};\\\", \\\"{x:1341,y:709,t:1527020152480};\\\", \\\"{x:1341,y:708,t:1527020152565};\\\", \\\"{x:1342,y:707,t:1527020152581};\\\", \\\"{x:1342,y:710,t:1527020153203};\\\", \\\"{x:1349,y:721,t:1527020153213};\\\", \\\"{x:1360,y:745,t:1527020153230};\\\", \\\"{x:1376,y:772,t:1527020153247};\\\", \\\"{x:1392,y:794,t:1527020153263};\\\", \\\"{x:1405,y:809,t:1527020153281};\\\", \\\"{x:1415,y:822,t:1527020153298};\\\", \\\"{x:1426,y:834,t:1527020153314};\\\", \\\"{x:1448,y:860,t:1527020153331};\\\", \\\"{x:1460,y:875,t:1527020153348};\\\", \\\"{x:1470,y:885,t:1527020153364};\\\", \\\"{x:1482,y:895,t:1527020153381};\\\", \\\"{x:1490,y:903,t:1527020153398};\\\", \\\"{x:1494,y:908,t:1527020153414};\\\", \\\"{x:1499,y:916,t:1527020153431};\\\", \\\"{x:1503,y:922,t:1527020153449};\\\", \\\"{x:1506,y:926,t:1527020153464};\\\", \\\"{x:1507,y:929,t:1527020153480};\\\", \\\"{x:1507,y:931,t:1527020153498};\\\", \\\"{x:1509,y:934,t:1527020153514};\\\", \\\"{x:1511,y:942,t:1527020153530};\\\", \\\"{x:1513,y:947,t:1527020153548};\\\", \\\"{x:1513,y:954,t:1527020153564};\\\", \\\"{x:1514,y:961,t:1527020153581};\\\", \\\"{x:1514,y:965,t:1527020153598};\\\", \\\"{x:1514,y:969,t:1527020153614};\\\", \\\"{x:1514,y:971,t:1527020153631};\\\", \\\"{x:1514,y:972,t:1527020153648};\\\", \\\"{x:1514,y:973,t:1527020153664};\\\", \\\"{x:1514,y:975,t:1527020153681};\\\", \\\"{x:1513,y:976,t:1527020153698};\\\", \\\"{x:1513,y:977,t:1527020153714};\\\", \\\"{x:1511,y:978,t:1527020153731};\\\", \\\"{x:1510,y:979,t:1527020153748};\\\", \\\"{x:1509,y:979,t:1527020153765};\\\", \\\"{x:1507,y:979,t:1527020153852};\\\", \\\"{x:1506,y:978,t:1527020153867};\\\", \\\"{x:1505,y:977,t:1527020153883};\\\", \\\"{x:1503,y:976,t:1527020153899};\\\", \\\"{x:1500,y:975,t:1527020153915};\\\", \\\"{x:1496,y:972,t:1527020153931};\\\", \\\"{x:1492,y:968,t:1527020153949};\\\", \\\"{x:1485,y:962,t:1527020153966};\\\", \\\"{x:1478,y:958,t:1527020153981};\\\", \\\"{x:1474,y:956,t:1527020153998};\\\", \\\"{x:1470,y:952,t:1527020154015};\\\", \\\"{x:1466,y:949,t:1527020154031};\\\", \\\"{x:1461,y:942,t:1527020154048};\\\", \\\"{x:1455,y:934,t:1527020154065};\\\", \\\"{x:1449,y:923,t:1527020154081};\\\", \\\"{x:1438,y:906,t:1527020154099};\\\", \\\"{x:1420,y:881,t:1527020154115};\\\", \\\"{x:1406,y:862,t:1527020154131};\\\", \\\"{x:1385,y:838,t:1527020154148};\\\", \\\"{x:1355,y:811,t:1527020154165};\\\", \\\"{x:1319,y:782,t:1527020154182};\\\", \\\"{x:1274,y:750,t:1527020154198};\\\", \\\"{x:1226,y:717,t:1527020154215};\\\", \\\"{x:1177,y:689,t:1527020154231};\\\", \\\"{x:1126,y:661,t:1527020154248};\\\", \\\"{x:1069,y:630,t:1527020154265};\\\", \\\"{x:1019,y:607,t:1527020154281};\\\", \\\"{x:985,y:583,t:1527020154298};\\\", \\\"{x:956,y:563,t:1527020154314};\\\", \\\"{x:936,y:554,t:1527020154332};\\\", \\\"{x:916,y:548,t:1527020154347};\\\", \\\"{x:897,y:546,t:1527020154365};\\\", \\\"{x:887,y:546,t:1527020154382};\\\", \\\"{x:880,y:546,t:1527020154399};\\\", \\\"{x:872,y:546,t:1527020154415};\\\", \\\"{x:856,y:548,t:1527020154432};\\\", \\\"{x:835,y:553,t:1527020154449};\\\", \\\"{x:813,y:555,t:1527020154466};\\\", \\\"{x:787,y:555,t:1527020154482};\\\", \\\"{x:751,y:555,t:1527020154498};\\\", \\\"{x:730,y:555,t:1527020154516};\\\", \\\"{x:719,y:555,t:1527020154533};\\\", \\\"{x:713,y:555,t:1527020154549};\\\", \\\"{x:708,y:554,t:1527020154566};\\\", \\\"{x:705,y:553,t:1527020154583};\\\", \\\"{x:702,y:551,t:1527020154599};\\\", \\\"{x:695,y:546,t:1527020154616};\\\", \\\"{x:686,y:541,t:1527020154633};\\\", \\\"{x:677,y:536,t:1527020154649};\\\", \\\"{x:671,y:535,t:1527020154666};\\\", \\\"{x:665,y:530,t:1527020154683};\\\", \\\"{x:659,y:520,t:1527020154700};\\\", \\\"{x:653,y:512,t:1527020154716};\\\", \\\"{x:650,y:506,t:1527020154732};\\\", \\\"{x:645,y:502,t:1527020154749};\\\", \\\"{x:643,y:499,t:1527020154766};\\\", \\\"{x:640,y:497,t:1527020154782};\\\", \\\"{x:638,y:495,t:1527020154799};\\\", \\\"{x:637,y:494,t:1527020154816};\\\", \\\"{x:636,y:493,t:1527020154833};\\\", \\\"{x:635,y:492,t:1527020155034};\\\", \\\"{x:636,y:491,t:1527020155049};\\\", \\\"{x:638,y:490,t:1527020155065};\\\", \\\"{x:640,y:493,t:1527020155107};\\\", \\\"{x:643,y:499,t:1527020155116};\\\", \\\"{x:647,y:512,t:1527020155133};\\\", \\\"{x:648,y:529,t:1527020155149};\\\", \\\"{x:649,y:557,t:1527020155167};\\\", \\\"{x:650,y:589,t:1527020155184};\\\", \\\"{x:656,y:621,t:1527020155200};\\\", \\\"{x:661,y:647,t:1527020155216};\\\", \\\"{x:662,y:664,t:1527020155233};\\\", \\\"{x:664,y:675,t:1527020155250};\\\", \\\"{x:664,y:681,t:1527020155266};\\\", \\\"{x:662,y:685,t:1527020155283};\\\", \\\"{x:659,y:687,t:1527020155300};\\\", \\\"{x:650,y:688,t:1527020155317};\\\", \\\"{x:634,y:688,t:1527020155333};\\\", \\\"{x:620,y:686,t:1527020155350};\\\", \\\"{x:602,y:681,t:1527020155367};\\\", \\\"{x:580,y:675,t:1527020155383};\\\", \\\"{x:557,y:672,t:1527020155400};\\\", \\\"{x:537,y:677,t:1527020155417};\\\", \\\"{x:517,y:685,t:1527020155433};\\\", \\\"{x:500,y:694,t:1527020155450};\\\", \\\"{x:494,y:697,t:1527020155467};\\\", \\\"{x:493,y:698,t:1527020155484};\\\", \\\"{x:492,y:699,t:1527020155538};\\\", \\\"{x:492,y:700,t:1527020155550};\\\", \\\"{x:490,y:705,t:1527020155567};\\\", \\\"{x:490,y:712,t:1527020155584};\\\", \\\"{x:490,y:716,t:1527020155601};\\\", \\\"{x:490,y:719,t:1527020155617};\\\", \\\"{x:490,y:721,t:1527020155635};\\\", \\\"{x:490,y:722,t:1527020155650};\\\", \\\"{x:490,y:724,t:1527020155675};\\\", \\\"{x:490,y:725,t:1527020155690};\\\", \\\"{x:491,y:726,t:1527020155706};\\\", \\\"{x:491,y:727,t:1527020155714};\\\", \\\"{x:491,y:728,t:1527020155731};\\\", \\\"{x:491,y:733,t:1527020155749};\\\", \\\"{x:494,y:739,t:1527020155765};\\\", \\\"{x:496,y:745,t:1527020155782};\\\", \\\"{x:497,y:750,t:1527020155798};\\\", \\\"{x:498,y:753,t:1527020155815};\\\", \\\"{x:498,y:754,t:1527020155832};\\\", \\\"{x:499,y:754,t:1527020156028};\\\", \\\"{x:500,y:754,t:1527020156035};\\\", \\\"{x:501,y:752,t:1527020156051};\\\", \\\"{x:502,y:751,t:1527020156067};\\\", \\\"{x:502,y:749,t:1527020156091};\\\", \\\"{x:502,y:748,t:1527020156251};\\\", \\\"{x:504,y:744,t:1527020156264};\\\", \\\"{x:504,y:741,t:1527020156282};\\\", \\\"{x:505,y:736,t:1527020156297};\\\", \\\"{x:505,y:734,t:1527020156315};\\\" ] }, { \\\"rt\\\": 8247, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 789490, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:729,t:1527020159880};\\\", \\\"{x:535,y:723,t:1527020159894};\\\", \\\"{x:623,y:714,t:1527020159911};\\\", \\\"{x:701,y:714,t:1527020159927};\\\", \\\"{x:821,y:714,t:1527020159942};\\\", \\\"{x:909,y:714,t:1527020159962};\\\", \\\"{x:951,y:712,t:1527020159973};\\\", \\\"{x:1038,y:710,t:1527020159990};\\\", \\\"{x:1154,y:701,t:1527020160007};\\\", \\\"{x:1224,y:690,t:1527020160024};\\\", \\\"{x:1255,y:685,t:1527020160040};\\\", \\\"{x:1263,y:684,t:1527020160057};\\\", \\\"{x:1270,y:683,t:1527020160074};\\\", \\\"{x:1275,y:681,t:1527020160090};\\\", \\\"{x:1281,y:677,t:1527020160107};\\\", \\\"{x:1289,y:673,t:1527020160125};\\\", \\\"{x:1301,y:667,t:1527020160141};\\\", \\\"{x:1323,y:656,t:1527020160158};\\\", \\\"{x:1343,y:645,t:1527020160174};\\\", \\\"{x:1360,y:635,t:1527020160190};\\\", \\\"{x:1380,y:623,t:1527020160208};\\\", \\\"{x:1390,y:617,t:1527020160225};\\\", \\\"{x:1392,y:614,t:1527020160241};\\\", \\\"{x:1393,y:613,t:1527020160258};\\\", \\\"{x:1394,y:612,t:1527020160368};\\\", \\\"{x:1394,y:613,t:1527020160400};\\\", \\\"{x:1394,y:624,t:1527020160408};\\\", \\\"{x:1392,y:656,t:1527020160424};\\\", \\\"{x:1397,y:701,t:1527020160440};\\\", \\\"{x:1414,y:749,t:1527020160458};\\\", \\\"{x:1432,y:793,t:1527020160474};\\\", \\\"{x:1443,y:827,t:1527020160491};\\\", \\\"{x:1452,y:857,t:1527020160508};\\\", \\\"{x:1458,y:876,t:1527020160525};\\\", \\\"{x:1462,y:890,t:1527020160541};\\\", \\\"{x:1463,y:901,t:1527020160558};\\\", \\\"{x:1465,y:914,t:1527020160575};\\\", \\\"{x:1465,y:923,t:1527020160591};\\\", \\\"{x:1468,y:938,t:1527020160608};\\\", \\\"{x:1472,y:946,t:1527020160625};\\\", \\\"{x:1474,y:949,t:1527020160641};\\\", \\\"{x:1474,y:950,t:1527020160657};\\\", \\\"{x:1476,y:952,t:1527020160675};\\\", \\\"{x:1476,y:954,t:1527020160691};\\\", \\\"{x:1478,y:956,t:1527020160707};\\\", \\\"{x:1480,y:961,t:1527020160724};\\\", \\\"{x:1484,y:968,t:1527020160742};\\\", \\\"{x:1488,y:976,t:1527020160758};\\\", \\\"{x:1489,y:980,t:1527020160774};\\\", \\\"{x:1489,y:981,t:1527020160792};\\\", \\\"{x:1489,y:982,t:1527020160839};\\\", \\\"{x:1489,y:983,t:1527020160880};\\\", \\\"{x:1489,y:984,t:1527020160892};\\\", \\\"{x:1485,y:986,t:1527020160909};\\\", \\\"{x:1479,y:987,t:1527020160925};\\\", \\\"{x:1467,y:989,t:1527020160941};\\\", \\\"{x:1457,y:991,t:1527020160958};\\\", \\\"{x:1443,y:992,t:1527020160975};\\\", \\\"{x:1417,y:994,t:1527020160991};\\\", \\\"{x:1399,y:994,t:1527020161008};\\\", \\\"{x:1381,y:994,t:1527020161025};\\\", \\\"{x:1365,y:994,t:1527020161042};\\\", \\\"{x:1343,y:994,t:1527020161058};\\\", \\\"{x:1326,y:993,t:1527020161074};\\\", \\\"{x:1319,y:992,t:1527020161092};\\\", \\\"{x:1318,y:991,t:1527020161108};\\\", \\\"{x:1317,y:990,t:1527020161135};\\\", \\\"{x:1317,y:989,t:1527020161152};\\\", \\\"{x:1317,y:987,t:1527020161160};\\\", \\\"{x:1315,y:985,t:1527020161175};\\\", \\\"{x:1315,y:982,t:1527020161192};\\\", \\\"{x:1315,y:979,t:1527020161208};\\\", \\\"{x:1315,y:973,t:1527020161225};\\\", \\\"{x:1315,y:969,t:1527020161242};\\\", \\\"{x:1315,y:966,t:1527020161258};\\\", \\\"{x:1316,y:965,t:1527020161275};\\\", \\\"{x:1317,y:963,t:1527020161292};\\\", \\\"{x:1318,y:962,t:1527020161309};\\\", \\\"{x:1320,y:960,t:1527020161325};\\\", \\\"{x:1321,y:960,t:1527020161342};\\\", \\\"{x:1323,y:959,t:1527020161359};\\\", \\\"{x:1325,y:959,t:1527020161374};\\\", \\\"{x:1327,y:957,t:1527020161392};\\\", \\\"{x:1328,y:957,t:1527020161409};\\\", \\\"{x:1329,y:956,t:1527020161425};\\\", \\\"{x:1330,y:956,t:1527020161441};\\\", \\\"{x:1331,y:956,t:1527020161471};\\\", \\\"{x:1332,y:954,t:1527020161479};\\\", \\\"{x:1334,y:953,t:1527020161495};\\\", \\\"{x:1335,y:952,t:1527020161509};\\\", \\\"{x:1336,y:949,t:1527020161525};\\\", \\\"{x:1337,y:943,t:1527020161542};\\\", \\\"{x:1339,y:938,t:1527020161558};\\\", \\\"{x:1340,y:928,t:1527020161575};\\\", \\\"{x:1342,y:903,t:1527020161591};\\\", \\\"{x:1342,y:891,t:1527020161608};\\\", \\\"{x:1342,y:879,t:1527020161625};\\\", \\\"{x:1342,y:866,t:1527020161642};\\\", \\\"{x:1342,y:852,t:1527020161659};\\\", \\\"{x:1342,y:841,t:1527020161675};\\\", \\\"{x:1341,y:829,t:1527020161692};\\\", \\\"{x:1340,y:819,t:1527020161709};\\\", \\\"{x:1337,y:809,t:1527020161725};\\\", \\\"{x:1336,y:800,t:1527020161743};\\\", \\\"{x:1334,y:791,t:1527020161759};\\\", \\\"{x:1332,y:777,t:1527020161775};\\\", \\\"{x:1331,y:769,t:1527020161791};\\\", \\\"{x:1329,y:761,t:1527020161809};\\\", \\\"{x:1328,y:751,t:1527020161824};\\\", \\\"{x:1327,y:742,t:1527020161841};\\\", \\\"{x:1327,y:736,t:1527020161858};\\\", \\\"{x:1327,y:733,t:1527020161875};\\\", \\\"{x:1327,y:731,t:1527020161891};\\\", \\\"{x:1327,y:729,t:1527020161909};\\\", \\\"{x:1327,y:727,t:1527020161925};\\\", \\\"{x:1327,y:726,t:1527020161942};\\\", \\\"{x:1327,y:723,t:1527020161958};\\\", \\\"{x:1325,y:723,t:1527020162055};\\\", \\\"{x:1328,y:724,t:1527020162095};\\\", \\\"{x:1334,y:724,t:1527020162109};\\\", \\\"{x:1333,y:724,t:1527020162345};\\\", \\\"{x:1327,y:724,t:1527020162359};\\\", \\\"{x:1305,y:724,t:1527020162375};\\\", \\\"{x:1295,y:724,t:1527020162392};\\\", \\\"{x:1283,y:724,t:1527020162409};\\\", \\\"{x:1266,y:724,t:1527020162426};\\\", \\\"{x:1234,y:728,t:1527020162442};\\\", \\\"{x:1170,y:737,t:1527020162459};\\\", \\\"{x:1080,y:739,t:1527020162475};\\\", \\\"{x:975,y:739,t:1527020162492};\\\", \\\"{x:870,y:739,t:1527020162508};\\\", \\\"{x:770,y:739,t:1527020162525};\\\", \\\"{x:665,y:739,t:1527020162543};\\\", \\\"{x:576,y:739,t:1527020162558};\\\", \\\"{x:506,y:739,t:1527020162577};\\\", \\\"{x:483,y:739,t:1527020162592};\\\", \\\"{x:470,y:739,t:1527020162608};\\\", \\\"{x:463,y:739,t:1527020162626};\\\", \\\"{x:459,y:738,t:1527020162643};\\\", \\\"{x:457,y:737,t:1527020162659};\\\", \\\"{x:456,y:735,t:1527020162677};\\\", \\\"{x:456,y:734,t:1527020162879};\\\", \\\"{x:456,y:733,t:1527020162895};\\\", \\\"{x:456,y:732,t:1527020162911};\\\", \\\"{x:456,y:731,t:1527020162927};\\\", \\\"{x:456,y:729,t:1527020162943};\\\", \\\"{x:456,y:728,t:1527020162960};\\\", \\\"{x:454,y:726,t:1527020162976};\\\", \\\"{x:454,y:724,t:1527020162993};\\\", \\\"{x:453,y:723,t:1527020163010};\\\", \\\"{x:452,y:722,t:1527020163026};\\\", \\\"{x:451,y:720,t:1527020163044};\\\", \\\"{x:449,y:717,t:1527020163061};\\\", \\\"{x:447,y:714,t:1527020163077};\\\", \\\"{x:447,y:712,t:1527020163094};\\\", \\\"{x:447,y:710,t:1527020163111};\\\", \\\"{x:441,y:703,t:1527020163127};\\\", \\\"{x:439,y:702,t:1527020163143};\\\", \\\"{x:439,y:700,t:1527020163487};\\\", \\\"{x:435,y:698,t:1527020163495};\\\", \\\"{x:432,y:694,t:1527020163510};\\\", \\\"{x:424,y:684,t:1527020163527};\\\", \\\"{x:417,y:680,t:1527020163543};\\\", \\\"{x:414,y:678,t:1527020163560};\\\", \\\"{x:409,y:676,t:1527020163578};\\\", \\\"{x:408,y:674,t:1527020163593};\\\", \\\"{x:406,y:674,t:1527020163610};\\\", \\\"{x:405,y:672,t:1527020163628};\\\", \\\"{x:404,y:670,t:1527020163644};\\\", \\\"{x:403,y:668,t:1527020163663};\\\", \\\"{x:402,y:661,t:1527020163678};\\\", \\\"{x:401,y:645,t:1527020163693};\\\", \\\"{x:401,y:631,t:1527020163713};\\\", \\\"{x:401,y:624,t:1527020163727};\\\", \\\"{x:401,y:619,t:1527020163743};\\\", \\\"{x:401,y:616,t:1527020163760};\\\", \\\"{x:401,y:614,t:1527020163777};\\\", \\\"{x:401,y:610,t:1527020163794};\\\", \\\"{x:403,y:606,t:1527020163810};\\\", \\\"{x:405,y:602,t:1527020163827};\\\", \\\"{x:407,y:599,t:1527020163845};\\\", \\\"{x:408,y:596,t:1527020163860};\\\", \\\"{x:410,y:594,t:1527020163877};\\\", \\\"{x:412,y:592,t:1527020163894};\\\", \\\"{x:415,y:586,t:1527020163911};\\\", \\\"{x:417,y:582,t:1527020163927};\\\", \\\"{x:419,y:576,t:1527020163945};\\\", \\\"{x:422,y:572,t:1527020163960};\\\", \\\"{x:423,y:569,t:1527020163977};\\\", \\\"{x:424,y:566,t:1527020163993};\\\", \\\"{x:426,y:565,t:1527020164010};\\\", \\\"{x:428,y:563,t:1527020164027};\\\", \\\"{x:431,y:560,t:1527020164044};\\\", \\\"{x:442,y:553,t:1527020164061};\\\", \\\"{x:464,y:542,t:1527020164077};\\\", \\\"{x:487,y:530,t:1527020164094};\\\", \\\"{x:506,y:524,t:1527020164111};\\\", \\\"{x:518,y:519,t:1527020164127};\\\", \\\"{x:527,y:516,t:1527020164145};\\\", \\\"{x:530,y:515,t:1527020164160};\\\", \\\"{x:531,y:515,t:1527020164177};\\\", \\\"{x:530,y:515,t:1527020164239};\\\", \\\"{x:523,y:516,t:1527020164247};\\\", \\\"{x:517,y:518,t:1527020164261};\\\", \\\"{x:503,y:524,t:1527020164278};\\\", \\\"{x:477,y:533,t:1527020164295};\\\", \\\"{x:451,y:540,t:1527020164311};\\\", \\\"{x:422,y:544,t:1527020164327};\\\", \\\"{x:396,y:549,t:1527020164345};\\\", \\\"{x:368,y:555,t:1527020164361};\\\", \\\"{x:347,y:557,t:1527020164377};\\\", \\\"{x:327,y:558,t:1527020164394};\\\", \\\"{x:305,y:560,t:1527020164411};\\\", \\\"{x:286,y:560,t:1527020164427};\\\", \\\"{x:273,y:560,t:1527020164444};\\\", \\\"{x:265,y:560,t:1527020164461};\\\", \\\"{x:261,y:560,t:1527020164477};\\\", \\\"{x:258,y:560,t:1527020164494};\\\", \\\"{x:257,y:560,t:1527020164559};\\\", \\\"{x:254,y:560,t:1527020164567};\\\", \\\"{x:250,y:560,t:1527020164578};\\\", \\\"{x:243,y:560,t:1527020164594};\\\", \\\"{x:235,y:560,t:1527020164611};\\\", \\\"{x:227,y:560,t:1527020164628};\\\", \\\"{x:215,y:557,t:1527020164644};\\\", \\\"{x:201,y:551,t:1527020164663};\\\", \\\"{x:192,y:550,t:1527020164678};\\\", \\\"{x:178,y:547,t:1527020164695};\\\", \\\"{x:176,y:546,t:1527020164710};\\\", \\\"{x:183,y:543,t:1527020164894};\\\", \\\"{x:202,y:534,t:1527020164911};\\\", \\\"{x:229,y:524,t:1527020164928};\\\", \\\"{x:260,y:519,t:1527020164944};\\\", \\\"{x:306,y:511,t:1527020164962};\\\", \\\"{x:371,y:506,t:1527020164978};\\\", \\\"{x:458,y:502,t:1527020164994};\\\", \\\"{x:561,y:500,t:1527020165012};\\\", \\\"{x:655,y:500,t:1527020165028};\\\", \\\"{x:728,y:500,t:1527020165045};\\\", \\\"{x:762,y:500,t:1527020165061};\\\", \\\"{x:790,y:500,t:1527020165078};\\\", \\\"{x:796,y:500,t:1527020165094};\\\", \\\"{x:801,y:500,t:1527020165111};\\\", \\\"{x:809,y:500,t:1527020165129};\\\", \\\"{x:821,y:500,t:1527020165145};\\\", \\\"{x:830,y:500,t:1527020165162};\\\", \\\"{x:838,y:500,t:1527020165179};\\\", \\\"{x:840,y:500,t:1527020165196};\\\", \\\"{x:840,y:501,t:1527020165494};\\\", \\\"{x:825,y:515,t:1527020165512};\\\", \\\"{x:799,y:540,t:1527020165529};\\\", \\\"{x:767,y:572,t:1527020165546};\\\", \\\"{x:724,y:605,t:1527020165563};\\\", \\\"{x:667,y:638,t:1527020165579};\\\", \\\"{x:597,y:659,t:1527020165596};\\\", \\\"{x:511,y:686,t:1527020165613};\\\", \\\"{x:447,y:705,t:1527020165628};\\\", \\\"{x:411,y:719,t:1527020165646};\\\", \\\"{x:394,y:724,t:1527020165661};\\\", \\\"{x:381,y:732,t:1527020165678};\\\", \\\"{x:381,y:733,t:1527020165703};\\\", \\\"{x:381,y:734,t:1527020165713};\\\", \\\"{x:382,y:735,t:1527020165728};\\\", \\\"{x:384,y:739,t:1527020165746};\\\", \\\"{x:385,y:740,t:1527020165791};\\\", \\\"{x:390,y:741,t:1527020165799};\\\", \\\"{x:397,y:743,t:1527020165813};\\\", \\\"{x:414,y:750,t:1527020165829};\\\", \\\"{x:430,y:755,t:1527020165846};\\\", \\\"{x:450,y:760,t:1527020165863};\\\", \\\"{x:465,y:762,t:1527020165879};\\\", \\\"{x:476,y:762,t:1527020165896};\\\", \\\"{x:488,y:762,t:1527020165913};\\\", \\\"{x:492,y:759,t:1527020165929};\\\", \\\"{x:494,y:758,t:1527020165946};\\\", \\\"{x:494,y:757,t:1527020165963};\\\", \\\"{x:495,y:757,t:1527020165979};\\\", \\\"{x:496,y:756,t:1527020166023};\\\", \\\"{x:497,y:756,t:1527020166031};\\\", \\\"{x:498,y:756,t:1527020166062};\\\", \\\"{x:498,y:756,t:1527020166111};\\\", \\\"{x:498,y:755,t:1527020166150};\\\", \\\"{x:498,y:753,t:1527020166166};\\\", \\\"{x:498,y:751,t:1527020166178};\\\", \\\"{x:499,y:747,t:1527020166195};\\\", \\\"{x:501,y:745,t:1527020166212};\\\", \\\"{x:501,y:743,t:1527020166229};\\\", \\\"{x:501,y:741,t:1527020166246};\\\", \\\"{x:501,y:739,t:1527020166262};\\\", \\\"{x:502,y:738,t:1527020166279};\\\", \\\"{x:502,y:737,t:1527020166295};\\\", \\\"{x:503,y:737,t:1527020166313};\\\" ] }, { \\\"rt\\\": 3769, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 794539, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:736,t:1527020168431};\\\", \\\"{x:542,y:724,t:1527020168447};\\\", \\\"{x:604,y:714,t:1527020168470};\\\", \\\"{x:694,y:708,t:1527020168480};\\\", \\\"{x:805,y:708,t:1527020168497};\\\", \\\"{x:930,y:708,t:1527020168515};\\\", \\\"{x:1054,y:708,t:1527020168531};\\\", \\\"{x:1177,y:713,t:1527020168547};\\\", \\\"{x:1274,y:727,t:1527020168565};\\\", \\\"{x:1328,y:735,t:1527020168580};\\\", \\\"{x:1353,y:738,t:1527020168597};\\\", \\\"{x:1363,y:741,t:1527020168615};\\\", \\\"{x:1364,y:741,t:1527020168671};\\\", \\\"{x:1366,y:743,t:1527020168681};\\\", \\\"{x:1372,y:750,t:1527020168697};\\\", \\\"{x:1381,y:761,t:1527020168715};\\\", \\\"{x:1393,y:771,t:1527020168731};\\\", \\\"{x:1407,y:781,t:1527020168748};\\\", \\\"{x:1413,y:786,t:1527020168765};\\\", \\\"{x:1415,y:788,t:1527020168781};\\\", \\\"{x:1416,y:789,t:1527020168798};\\\", \\\"{x:1415,y:789,t:1527020168880};\\\", \\\"{x:1410,y:789,t:1527020168898};\\\", \\\"{x:1406,y:789,t:1527020168915};\\\", \\\"{x:1403,y:789,t:1527020168931};\\\", \\\"{x:1398,y:788,t:1527020168948};\\\", \\\"{x:1396,y:787,t:1527020168965};\\\", \\\"{x:1394,y:787,t:1527020168981};\\\", \\\"{x:1391,y:786,t:1527020168998};\\\", \\\"{x:1388,y:784,t:1527020169015};\\\", \\\"{x:1387,y:783,t:1527020169031};\\\", \\\"{x:1385,y:783,t:1527020169048};\\\", \\\"{x:1383,y:780,t:1527020169065};\\\", \\\"{x:1380,y:779,t:1527020169081};\\\", \\\"{x:1374,y:774,t:1527020169098};\\\", \\\"{x:1363,y:768,t:1527020169115};\\\", \\\"{x:1356,y:764,t:1527020169131};\\\", \\\"{x:1348,y:760,t:1527020169150};\\\", \\\"{x:1346,y:759,t:1527020169164};\\\", \\\"{x:1345,y:758,t:1527020169181};\\\", \\\"{x:1343,y:757,t:1527020169198};\\\", \\\"{x:1339,y:755,t:1527020169214};\\\", \\\"{x:1332,y:755,t:1527020169231};\\\", \\\"{x:1316,y:749,t:1527020169247};\\\", \\\"{x:1270,y:742,t:1527020169264};\\\", \\\"{x:1170,y:727,t:1527020169281};\\\", \\\"{x:1047,y:706,t:1527020169297};\\\", \\\"{x:909,y:687,t:1527020169315};\\\", \\\"{x:759,y:660,t:1527020169332};\\\", \\\"{x:620,y:639,t:1527020169348};\\\", \\\"{x:502,y:612,t:1527020169365};\\\", \\\"{x:405,y:597,t:1527020169382};\\\", \\\"{x:351,y:578,t:1527020169399};\\\", \\\"{x:348,y:577,t:1527020169414};\\\", \\\"{x:347,y:576,t:1527020169487};\\\", \\\"{x:347,y:575,t:1527020169498};\\\", \\\"{x:349,y:574,t:1527020169515};\\\", \\\"{x:356,y:570,t:1527020169531};\\\", \\\"{x:368,y:564,t:1527020169548};\\\", \\\"{x:379,y:558,t:1527020169566};\\\", \\\"{x:388,y:554,t:1527020169582};\\\", \\\"{x:393,y:552,t:1527020169599};\\\", \\\"{x:390,y:552,t:1527020169695};\\\", \\\"{x:388,y:553,t:1527020169703};\\\", \\\"{x:384,y:553,t:1527020169716};\\\", \\\"{x:377,y:558,t:1527020169733};\\\", \\\"{x:370,y:561,t:1527020169748};\\\", \\\"{x:365,y:564,t:1527020169766};\\\", \\\"{x:362,y:565,t:1527020169781};\\\", \\\"{x:358,y:568,t:1527020169798};\\\", \\\"{x:352,y:572,t:1527020169815};\\\", \\\"{x:339,y:578,t:1527020169831};\\\", \\\"{x:319,y:585,t:1527020169848};\\\", \\\"{x:298,y:590,t:1527020169865};\\\", \\\"{x:277,y:594,t:1527020169882};\\\", \\\"{x:258,y:596,t:1527020169898};\\\", \\\"{x:238,y:598,t:1527020169915};\\\", \\\"{x:215,y:598,t:1527020169931};\\\", \\\"{x:202,y:598,t:1527020169949};\\\", \\\"{x:198,y:598,t:1527020169965};\\\", \\\"{x:196,y:597,t:1527020169983};\\\", \\\"{x:192,y:594,t:1527020169998};\\\", \\\"{x:185,y:586,t:1527020170017};\\\", \\\"{x:177,y:576,t:1527020170032};\\\", \\\"{x:173,y:571,t:1527020170048};\\\", \\\"{x:169,y:567,t:1527020170066};\\\", \\\"{x:168,y:566,t:1527020170083};\\\", \\\"{x:168,y:565,t:1527020170111};\\\", \\\"{x:166,y:564,t:1527020170119};\\\", \\\"{x:166,y:563,t:1527020170134};\\\", \\\"{x:166,y:562,t:1527020170151};\\\", \\\"{x:166,y:561,t:1527020170166};\\\", \\\"{x:166,y:560,t:1527020170183};\\\", \\\"{x:165,y:558,t:1527020170207};\\\", \\\"{x:165,y:556,t:1527020170223};\\\", \\\"{x:165,y:555,t:1527020170235};\\\", \\\"{x:165,y:552,t:1527020170249};\\\", \\\"{x:165,y:548,t:1527020170266};\\\", \\\"{x:165,y:545,t:1527020170282};\\\", \\\"{x:165,y:544,t:1527020170298};\\\", \\\"{x:165,y:542,t:1527020170315};\\\", \\\"{x:165,y:541,t:1527020170694};\\\", \\\"{x:166,y:541,t:1527020170703};\\\", \\\"{x:168,y:541,t:1527020170715};\\\", \\\"{x:177,y:548,t:1527020170733};\\\", \\\"{x:191,y:562,t:1527020170750};\\\", \\\"{x:218,y:582,t:1527020170767};\\\", \\\"{x:238,y:595,t:1527020170783};\\\", \\\"{x:259,y:608,t:1527020170800};\\\", \\\"{x:275,y:620,t:1527020170817};\\\", \\\"{x:287,y:627,t:1527020170833};\\\", \\\"{x:301,y:637,t:1527020170850};\\\", \\\"{x:316,y:648,t:1527020170866};\\\", \\\"{x:330,y:658,t:1527020170883};\\\", \\\"{x:342,y:669,t:1527020170899};\\\", \\\"{x:356,y:680,t:1527020170917};\\\", \\\"{x:375,y:694,t:1527020170933};\\\", \\\"{x:396,y:706,t:1527020170950};\\\", \\\"{x:427,y:724,t:1527020170966};\\\", \\\"{x:449,y:734,t:1527020170983};\\\", \\\"{x:471,y:745,t:1527020170999};\\\", \\\"{x:492,y:751,t:1527020171017};\\\", \\\"{x:509,y:758,t:1527020171033};\\\", \\\"{x:520,y:761,t:1527020171050};\\\", \\\"{x:525,y:761,t:1527020171066};\\\", \\\"{x:526,y:761,t:1527020171083};\\\", \\\"{x:526,y:762,t:1527020171100};\\\", \\\"{x:528,y:762,t:1527020171176};\\\", \\\"{x:529,y:761,t:1527020171182};\\\", \\\"{x:531,y:759,t:1527020171200};\\\", \\\"{x:532,y:756,t:1527020171217};\\\", \\\"{x:534,y:752,t:1527020171234};\\\", \\\"{x:535,y:747,t:1527020171250};\\\", \\\"{x:536,y:746,t:1527020171267};\\\", \\\"{x:537,y:744,t:1527020171283};\\\", \\\"{x:537,y:743,t:1527020171310};\\\" ] }, { \\\"rt\\\": 41500, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 837261, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -Z -Z -Z -Z -Z -Z -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:740,t:1527020173968};\\\", \\\"{x:547,y:737,t:1527020173975};\\\", \\\"{x:553,y:734,t:1527020173988};\\\", \\\"{x:566,y:729,t:1527020174006};\\\", \\\"{x:575,y:726,t:1527020174021};\\\", \\\"{x:589,y:725,t:1527020174036};\\\", \\\"{x:606,y:723,t:1527020174051};\\\", \\\"{x:626,y:721,t:1527020174069};\\\", \\\"{x:651,y:717,t:1527020174085};\\\", \\\"{x:702,y:712,t:1527020174101};\\\", \\\"{x:796,y:696,t:1527020174118};\\\", \\\"{x:851,y:688,t:1527020174135};\\\", \\\"{x:918,y:680,t:1527020174151};\\\", \\\"{x:979,y:664,t:1527020174168};\\\", \\\"{x:1011,y:658,t:1527020174186};\\\", \\\"{x:1033,y:652,t:1527020174202};\\\", \\\"{x:1047,y:647,t:1527020174219};\\\", \\\"{x:1056,y:646,t:1527020174236};\\\", \\\"{x:1071,y:642,t:1527020174252};\\\", \\\"{x:1088,y:635,t:1527020174269};\\\", \\\"{x:1099,y:632,t:1527020174286};\\\", \\\"{x:1106,y:629,t:1527020174302};\\\", \\\"{x:1113,y:618,t:1527020174318};\\\", \\\"{x:1113,y:615,t:1527020174336};\\\", \\\"{x:1113,y:614,t:1527020174352};\\\", \\\"{x:1115,y:612,t:1527020174783};\\\", \\\"{x:1127,y:604,t:1527020174791};\\\", \\\"{x:1136,y:599,t:1527020174803};\\\", \\\"{x:1153,y:593,t:1527020174819};\\\", \\\"{x:1179,y:587,t:1527020174836};\\\", \\\"{x:1203,y:580,t:1527020174853};\\\", \\\"{x:1237,y:569,t:1527020174870};\\\", \\\"{x:1266,y:559,t:1527020174887};\\\", \\\"{x:1306,y:547,t:1527020174903};\\\", \\\"{x:1323,y:542,t:1527020174919};\\\", \\\"{x:1332,y:542,t:1527020174936};\\\", \\\"{x:1335,y:541,t:1527020174953};\\\", \\\"{x:1339,y:541,t:1527020174970};\\\", \\\"{x:1358,y:535,t:1527020174986};\\\", \\\"{x:1379,y:526,t:1527020175002};\\\", \\\"{x:1397,y:521,t:1527020175019};\\\", \\\"{x:1416,y:513,t:1527020175036};\\\", \\\"{x:1451,y:505,t:1527020175053};\\\", \\\"{x:1490,y:495,t:1527020175070};\\\", \\\"{x:1508,y:493,t:1527020175086};\\\", \\\"{x:1514,y:492,t:1527020175102};\\\", \\\"{x:1515,y:492,t:1527020175120};\\\", \\\"{x:1516,y:492,t:1527020175136};\\\", \\\"{x:1517,y:491,t:1527020175153};\\\", \\\"{x:1517,y:490,t:1527020175170};\\\", \\\"{x:1518,y:490,t:1527020175186};\\\", \\\"{x:1519,y:490,t:1527020175287};\\\", \\\"{x:1521,y:494,t:1527020175311};\\\", \\\"{x:1523,y:500,t:1527020175320};\\\", \\\"{x:1528,y:517,t:1527020175336};\\\", \\\"{x:1533,y:531,t:1527020175353};\\\", \\\"{x:1538,y:544,t:1527020175371};\\\", \\\"{x:1539,y:553,t:1527020175388};\\\", \\\"{x:1539,y:559,t:1527020175403};\\\", \\\"{x:1539,y:567,t:1527020175420};\\\", \\\"{x:1541,y:579,t:1527020175438};\\\", \\\"{x:1541,y:591,t:1527020175454};\\\", \\\"{x:1544,y:601,t:1527020175470};\\\", \\\"{x:1546,y:614,t:1527020175487};\\\", \\\"{x:1546,y:620,t:1527020175503};\\\", \\\"{x:1547,y:622,t:1527020175520};\\\", \\\"{x:1547,y:624,t:1527020175537};\\\", \\\"{x:1547,y:627,t:1527020175553};\\\", \\\"{x:1548,y:631,t:1527020175570};\\\", \\\"{x:1549,y:640,t:1527020175588};\\\", \\\"{x:1551,y:650,t:1527020175603};\\\", \\\"{x:1553,y:657,t:1527020175620};\\\", \\\"{x:1554,y:663,t:1527020175638};\\\", \\\"{x:1557,y:674,t:1527020175653};\\\", \\\"{x:1560,y:682,t:1527020175670};\\\", \\\"{x:1562,y:692,t:1527020175687};\\\", \\\"{x:1563,y:700,t:1527020175703};\\\", \\\"{x:1565,y:708,t:1527020175720};\\\", \\\"{x:1567,y:713,t:1527020175738};\\\", \\\"{x:1570,y:718,t:1527020175754};\\\", \\\"{x:1574,y:723,t:1527020175770};\\\", \\\"{x:1576,y:724,t:1527020175787};\\\", \\\"{x:1577,y:725,t:1527020175804};\\\", \\\"{x:1579,y:725,t:1527020175820};\\\", \\\"{x:1583,y:726,t:1527020175837};\\\", \\\"{x:1587,y:726,t:1527020175855};\\\", \\\"{x:1594,y:726,t:1527020175870};\\\", \\\"{x:1603,y:726,t:1527020175887};\\\", \\\"{x:1607,y:725,t:1527020175905};\\\", \\\"{x:1609,y:724,t:1527020175920};\\\", \\\"{x:1610,y:723,t:1527020175938};\\\", \\\"{x:1611,y:723,t:1527020175975};\\\", \\\"{x:1612,y:723,t:1527020175987};\\\", \\\"{x:1613,y:722,t:1527020176004};\\\", \\\"{x:1614,y:721,t:1527020176023};\\\", \\\"{x:1615,y:720,t:1527020176063};\\\", \\\"{x:1615,y:719,t:1527020176079};\\\", \\\"{x:1616,y:718,t:1527020176087};\\\", \\\"{x:1617,y:714,t:1527020176104};\\\", \\\"{x:1617,y:711,t:1527020176120};\\\", \\\"{x:1617,y:708,t:1527020176137};\\\", \\\"{x:1617,y:705,t:1527020176155};\\\", \\\"{x:1619,y:701,t:1527020176170};\\\", \\\"{x:1619,y:700,t:1527020176190};\\\", \\\"{x:1619,y:698,t:1527020176204};\\\", \\\"{x:1618,y:698,t:1527020176591};\\\", \\\"{x:1617,y:698,t:1527020176607};\\\", \\\"{x:1617,y:699,t:1527020176621};\\\", \\\"{x:1615,y:699,t:1527020176637};\\\", \\\"{x:1613,y:700,t:1527020176654};\\\", \\\"{x:1610,y:704,t:1527020176673};\\\", \\\"{x:1609,y:705,t:1527020176688};\\\", \\\"{x:1609,y:706,t:1527020176704};\\\", \\\"{x:1610,y:706,t:1527020176935};\\\", \\\"{x:1612,y:706,t:1527020176951};\\\", \\\"{x:1614,y:705,t:1527020176967};\\\", \\\"{x:1614,y:704,t:1527020176975};\\\", \\\"{x:1615,y:704,t:1527020176988};\\\", \\\"{x:1615,y:703,t:1527020177004};\\\", \\\"{x:1612,y:709,t:1527020177408};\\\", \\\"{x:1610,y:715,t:1527020177421};\\\", \\\"{x:1605,y:734,t:1527020177438};\\\", \\\"{x:1594,y:763,t:1527020177455};\\\", \\\"{x:1590,y:777,t:1527020177472};\\\", \\\"{x:1588,y:786,t:1527020177489};\\\", \\\"{x:1586,y:793,t:1527020177506};\\\", \\\"{x:1586,y:794,t:1527020177522};\\\", \\\"{x:1586,y:792,t:1527020177599};\\\", \\\"{x:1588,y:785,t:1527020177607};\\\", \\\"{x:1591,y:776,t:1527020177622};\\\", \\\"{x:1596,y:763,t:1527020177638};\\\", \\\"{x:1603,y:739,t:1527020177656};\\\", \\\"{x:1607,y:729,t:1527020177672};\\\", \\\"{x:1608,y:721,t:1527020177689};\\\", \\\"{x:1608,y:717,t:1527020177705};\\\", \\\"{x:1608,y:715,t:1527020177722};\\\", \\\"{x:1609,y:712,t:1527020177887};\\\", \\\"{x:1610,y:702,t:1527020177906};\\\", \\\"{x:1611,y:696,t:1527020177922};\\\", \\\"{x:1612,y:693,t:1527020177938};\\\", \\\"{x:1612,y:690,t:1527020177956};\\\", \\\"{x:1613,y:689,t:1527020178334};\\\", \\\"{x:1614,y:688,t:1527020178342};\\\", \\\"{x:1614,y:687,t:1527020178355};\\\", \\\"{x:1614,y:686,t:1527020178375};\\\", \\\"{x:1614,y:687,t:1527020179559};\\\", \\\"{x:1612,y:689,t:1527020179575};\\\", \\\"{x:1612,y:691,t:1527020179589};\\\", \\\"{x:1610,y:694,t:1527020179607};\\\", \\\"{x:1609,y:697,t:1527020179623};\\\", \\\"{x:1608,y:699,t:1527020179642};\\\", \\\"{x:1607,y:702,t:1527020179657};\\\", \\\"{x:1606,y:704,t:1527020179673};\\\", \\\"{x:1606,y:707,t:1527020179690};\\\", \\\"{x:1606,y:710,t:1527020179707};\\\", \\\"{x:1603,y:713,t:1527020179724};\\\", \\\"{x:1603,y:715,t:1527020179740};\\\", \\\"{x:1603,y:716,t:1527020179756};\\\", \\\"{x:1602,y:718,t:1527020179773};\\\", \\\"{x:1602,y:719,t:1527020179790};\\\", \\\"{x:1601,y:721,t:1527020179806};\\\", \\\"{x:1600,y:722,t:1527020179823};\\\", \\\"{x:1600,y:723,t:1527020179847};\\\", \\\"{x:1600,y:724,t:1527020179863};\\\", \\\"{x:1600,y:725,t:1527020179879};\\\", \\\"{x:1599,y:726,t:1527020179890};\\\", \\\"{x:1598,y:728,t:1527020179907};\\\", \\\"{x:1597,y:729,t:1527020179924};\\\", \\\"{x:1597,y:727,t:1527020180095};\\\", \\\"{x:1598,y:726,t:1527020180107};\\\", \\\"{x:1601,y:720,t:1527020180123};\\\", \\\"{x:1604,y:715,t:1527020180140};\\\", \\\"{x:1605,y:714,t:1527020180157};\\\", \\\"{x:1605,y:713,t:1527020180174};\\\", \\\"{x:1607,y:710,t:1527020180190};\\\", \\\"{x:1608,y:707,t:1527020180207};\\\", \\\"{x:1609,y:705,t:1527020180223};\\\", \\\"{x:1610,y:704,t:1527020180256};\\\", \\\"{x:1610,y:703,t:1527020180264};\\\", \\\"{x:1611,y:702,t:1527020180375};\\\", \\\"{x:1613,y:698,t:1527020180391};\\\", \\\"{x:1614,y:697,t:1527020180407};\\\", \\\"{x:1614,y:696,t:1527020180423};\\\", \\\"{x:1614,y:697,t:1527020180631};\\\", \\\"{x:1614,y:698,t:1527020180640};\\\", \\\"{x:1614,y:703,t:1527020180659};\\\", \\\"{x:1614,y:706,t:1527020180675};\\\", \\\"{x:1614,y:708,t:1527020180691};\\\", \\\"{x:1614,y:710,t:1527020180707};\\\", \\\"{x:1614,y:712,t:1527020180725};\\\", \\\"{x:1614,y:715,t:1527020180740};\\\", \\\"{x:1614,y:718,t:1527020180758};\\\", \\\"{x:1614,y:719,t:1527020180774};\\\", \\\"{x:1614,y:722,t:1527020180790};\\\", \\\"{x:1615,y:722,t:1527020180808};\\\", \\\"{x:1615,y:724,t:1527020180824};\\\", \\\"{x:1615,y:725,t:1527020180841};\\\", \\\"{x:1615,y:726,t:1527020180858};\\\", \\\"{x:1615,y:729,t:1527020180874};\\\", \\\"{x:1615,y:731,t:1527020180890};\\\", \\\"{x:1616,y:734,t:1527020180907};\\\", \\\"{x:1616,y:735,t:1527020180924};\\\", \\\"{x:1616,y:737,t:1527020180940};\\\", \\\"{x:1616,y:738,t:1527020180957};\\\", \\\"{x:1616,y:740,t:1527020180975};\\\", \\\"{x:1616,y:742,t:1527020180991};\\\", \\\"{x:1616,y:744,t:1527020181007};\\\", \\\"{x:1617,y:749,t:1527020181024};\\\", \\\"{x:1617,y:752,t:1527020181042};\\\", \\\"{x:1617,y:757,t:1527020181058};\\\", \\\"{x:1617,y:762,t:1527020181075};\\\", \\\"{x:1617,y:764,t:1527020181091};\\\", \\\"{x:1617,y:766,t:1527020181108};\\\", \\\"{x:1617,y:771,t:1527020181125};\\\", \\\"{x:1617,y:776,t:1527020181141};\\\", \\\"{x:1617,y:781,t:1527020181157};\\\", \\\"{x:1617,y:787,t:1527020181175};\\\", \\\"{x:1617,y:792,t:1527020181191};\\\", \\\"{x:1617,y:795,t:1527020181207};\\\", \\\"{x:1617,y:799,t:1527020181225};\\\", \\\"{x:1617,y:806,t:1527020181241};\\\", \\\"{x:1617,y:813,t:1527020181257};\\\", \\\"{x:1617,y:821,t:1527020181275};\\\", \\\"{x:1617,y:830,t:1527020181292};\\\", \\\"{x:1617,y:836,t:1527020181308};\\\", \\\"{x:1617,y:843,t:1527020181324};\\\", \\\"{x:1617,y:850,t:1527020181342};\\\", \\\"{x:1617,y:856,t:1527020181358};\\\", \\\"{x:1617,y:865,t:1527020181375};\\\", \\\"{x:1617,y:873,t:1527020181391};\\\", \\\"{x:1617,y:883,t:1527020181407};\\\", \\\"{x:1617,y:893,t:1527020181424};\\\", \\\"{x:1617,y:900,t:1527020181441};\\\", \\\"{x:1617,y:908,t:1527020181459};\\\", \\\"{x:1617,y:916,t:1527020181475};\\\", \\\"{x:1617,y:924,t:1527020181491};\\\", \\\"{x:1617,y:934,t:1527020181507};\\\", \\\"{x:1617,y:942,t:1527020181525};\\\", \\\"{x:1617,y:947,t:1527020181541};\\\", \\\"{x:1617,y:956,t:1527020181558};\\\", \\\"{x:1617,y:959,t:1527020181574};\\\", \\\"{x:1617,y:960,t:1527020181591};\\\", \\\"{x:1618,y:961,t:1527020181711};\\\", \\\"{x:1618,y:959,t:1527020181724};\\\", \\\"{x:1620,y:940,t:1527020181741};\\\", \\\"{x:1624,y:911,t:1527020181759};\\\", \\\"{x:1627,y:897,t:1527020181775};\\\", \\\"{x:1628,y:883,t:1527020181791};\\\", \\\"{x:1629,y:871,t:1527020181808};\\\", \\\"{x:1632,y:860,t:1527020181825};\\\", \\\"{x:1633,y:851,t:1527020181841};\\\", \\\"{x:1634,y:846,t:1527020181859};\\\", \\\"{x:1635,y:838,t:1527020181874};\\\", \\\"{x:1637,y:831,t:1527020181891};\\\", \\\"{x:1638,y:822,t:1527020181909};\\\", \\\"{x:1639,y:811,t:1527020181925};\\\", \\\"{x:1642,y:792,t:1527020181941};\\\", \\\"{x:1642,y:774,t:1527020181958};\\\", \\\"{x:1641,y:742,t:1527020181975};\\\", \\\"{x:1633,y:716,t:1527020181992};\\\", \\\"{x:1625,y:700,t:1527020182008};\\\", \\\"{x:1624,y:694,t:1527020182025};\\\", \\\"{x:1623,y:693,t:1527020182042};\\\", \\\"{x:1621,y:693,t:1527020182151};\\\", \\\"{x:1619,y:693,t:1527020182167};\\\", \\\"{x:1618,y:693,t:1527020182174};\\\", \\\"{x:1616,y:693,t:1527020182191};\\\", \\\"{x:1612,y:695,t:1527020182208};\\\", \\\"{x:1608,y:697,t:1527020182226};\\\", \\\"{x:1604,y:699,t:1527020182241};\\\", \\\"{x:1598,y:702,t:1527020182258};\\\", \\\"{x:1595,y:704,t:1527020182275};\\\", \\\"{x:1595,y:705,t:1527020182291};\\\", \\\"{x:1593,y:706,t:1527020182318};\\\", \\\"{x:1592,y:707,t:1527020182326};\\\", \\\"{x:1592,y:709,t:1527020182711};\\\", \\\"{x:1592,y:710,t:1527020182726};\\\", \\\"{x:1593,y:710,t:1527020182767};\\\", \\\"{x:1594,y:710,t:1527020182782};\\\", \\\"{x:1594,y:709,t:1527020182792};\\\", \\\"{x:1597,y:706,t:1527020182808};\\\", \\\"{x:1601,y:701,t:1527020182826};\\\", \\\"{x:1604,y:693,t:1527020182842};\\\", \\\"{x:1607,y:678,t:1527020182859};\\\", \\\"{x:1611,y:667,t:1527020182876};\\\", \\\"{x:1612,y:661,t:1527020182892};\\\", \\\"{x:1613,y:659,t:1527020182909};\\\", \\\"{x:1614,y:657,t:1527020182959};\\\", \\\"{x:1618,y:655,t:1527020182975};\\\", \\\"{x:1630,y:650,t:1527020182993};\\\", \\\"{x:1636,y:647,t:1527020183009};\\\", \\\"{x:1639,y:646,t:1527020183026};\\\", \\\"{x:1638,y:647,t:1527020183959};\\\", \\\"{x:1633,y:662,t:1527020183977};\\\", \\\"{x:1631,y:673,t:1527020183994};\\\", \\\"{x:1629,y:686,t:1527020184009};\\\", \\\"{x:1626,y:699,t:1527020184027};\\\", \\\"{x:1623,y:709,t:1527020184043};\\\", \\\"{x:1620,y:715,t:1527020184059};\\\", \\\"{x:1620,y:717,t:1527020184076};\\\", \\\"{x:1620,y:719,t:1527020184093};\\\", \\\"{x:1619,y:720,t:1527020184110};\\\", \\\"{x:1618,y:724,t:1527020184127};\\\", \\\"{x:1617,y:726,t:1527020184143};\\\", \\\"{x:1617,y:727,t:1527020184160};\\\", \\\"{x:1617,y:728,t:1527020184176};\\\", \\\"{x:1617,y:730,t:1527020184215};\\\", \\\"{x:1616,y:733,t:1527020184226};\\\", \\\"{x:1614,y:739,t:1527020184243};\\\", \\\"{x:1619,y:749,t:1527020184260};\\\", \\\"{x:1623,y:756,t:1527020184277};\\\", \\\"{x:1627,y:754,t:1527020184591};\\\", \\\"{x:1627,y:753,t:1527020184599};\\\", \\\"{x:1627,y:751,t:1527020184615};\\\", \\\"{x:1627,y:749,t:1527020184627};\\\", \\\"{x:1627,y:744,t:1527020184644};\\\", \\\"{x:1627,y:739,t:1527020184660};\\\", \\\"{x:1625,y:731,t:1527020184677};\\\", \\\"{x:1623,y:727,t:1527020184693};\\\", \\\"{x:1619,y:720,t:1527020184710};\\\", \\\"{x:1618,y:718,t:1527020184727};\\\", \\\"{x:1616,y:717,t:1527020184743};\\\", \\\"{x:1613,y:715,t:1527020184760};\\\", \\\"{x:1612,y:715,t:1527020184778};\\\", \\\"{x:1611,y:715,t:1527020184794};\\\", \\\"{x:1610,y:715,t:1527020184811};\\\", \\\"{x:1609,y:715,t:1527020184839};\\\", \\\"{x:1609,y:714,t:1527020184879};\\\", \\\"{x:1609,y:713,t:1527020184894};\\\", \\\"{x:1609,y:708,t:1527020184911};\\\", \\\"{x:1609,y:705,t:1527020184927};\\\", \\\"{x:1609,y:703,t:1527020184943};\\\", \\\"{x:1610,y:699,t:1527020184961};\\\", \\\"{x:1610,y:697,t:1527020184977};\\\", \\\"{x:1610,y:691,t:1527020184994};\\\", \\\"{x:1610,y:683,t:1527020185010};\\\", \\\"{x:1610,y:679,t:1527020185028};\\\", \\\"{x:1609,y:679,t:1527020185280};\\\", \\\"{x:1607,y:679,t:1527020185294};\\\", \\\"{x:1606,y:680,t:1527020185567};\\\", \\\"{x:1606,y:683,t:1527020185578};\\\", \\\"{x:1607,y:694,t:1527020185594};\\\", \\\"{x:1609,y:702,t:1527020185611};\\\", \\\"{x:1609,y:716,t:1527020185628};\\\", \\\"{x:1610,y:730,t:1527020185644};\\\", \\\"{x:1612,y:748,t:1527020185660};\\\", \\\"{x:1614,y:767,t:1527020185678};\\\", \\\"{x:1617,y:793,t:1527020185694};\\\", \\\"{x:1618,y:803,t:1527020185711};\\\", \\\"{x:1619,y:811,t:1527020185727};\\\", \\\"{x:1620,y:826,t:1527020185745};\\\", \\\"{x:1620,y:842,t:1527020185762};\\\", \\\"{x:1620,y:859,t:1527020185778};\\\", \\\"{x:1617,y:879,t:1527020185795};\\\", \\\"{x:1615,y:896,t:1527020185812};\\\", \\\"{x:1613,y:906,t:1527020185828};\\\", \\\"{x:1613,y:912,t:1527020185845};\\\", \\\"{x:1613,y:915,t:1527020185862};\\\", \\\"{x:1613,y:920,t:1527020185877};\\\", \\\"{x:1613,y:925,t:1527020185894};\\\", \\\"{x:1613,y:930,t:1527020185911};\\\", \\\"{x:1613,y:935,t:1527020185928};\\\", \\\"{x:1613,y:942,t:1527020185944};\\\", \\\"{x:1614,y:950,t:1527020185961};\\\", \\\"{x:1615,y:955,t:1527020185978};\\\", \\\"{x:1615,y:958,t:1527020185995};\\\", \\\"{x:1615,y:960,t:1527020186087};\\\", \\\"{x:1615,y:961,t:1527020186119};\\\", \\\"{x:1615,y:963,t:1527020186151};\\\", \\\"{x:1615,y:964,t:1527020186183};\\\", \\\"{x:1615,y:966,t:1527020186214};\\\", \\\"{x:1615,y:967,t:1527020186247};\\\", \\\"{x:1615,y:968,t:1527020186262};\\\", \\\"{x:1615,y:966,t:1527020187175};\\\", \\\"{x:1615,y:964,t:1527020187183};\\\", \\\"{x:1615,y:960,t:1527020187195};\\\", \\\"{x:1613,y:951,t:1527020187212};\\\", \\\"{x:1611,y:936,t:1527020187229};\\\", \\\"{x:1608,y:918,t:1527020187245};\\\", \\\"{x:1603,y:898,t:1527020187262};\\\", \\\"{x:1600,y:886,t:1527020187278};\\\", \\\"{x:1598,y:879,t:1527020187296};\\\", \\\"{x:1596,y:874,t:1527020187312};\\\", \\\"{x:1594,y:866,t:1527020187328};\\\", \\\"{x:1593,y:861,t:1527020187345};\\\", \\\"{x:1592,y:856,t:1527020187362};\\\", \\\"{x:1590,y:853,t:1527020187379};\\\", \\\"{x:1590,y:852,t:1527020187399};\\\", \\\"{x:1590,y:851,t:1527020187412};\\\", \\\"{x:1590,y:850,t:1527020187428};\\\", \\\"{x:1590,y:849,t:1527020187446};\\\", \\\"{x:1590,y:847,t:1527020187462};\\\", \\\"{x:1590,y:845,t:1527020187479};\\\", \\\"{x:1590,y:841,t:1527020187496};\\\", \\\"{x:1590,y:838,t:1527020187512};\\\", \\\"{x:1590,y:834,t:1527020187529};\\\", \\\"{x:1590,y:833,t:1527020187545};\\\", \\\"{x:1590,y:831,t:1527020187567};\\\", \\\"{x:1591,y:830,t:1527020187616};\\\", \\\"{x:1592,y:830,t:1527020187646};\\\", \\\"{x:1593,y:828,t:1527020187663};\\\", \\\"{x:1594,y:828,t:1527020187680};\\\", \\\"{x:1595,y:827,t:1527020187696};\\\", \\\"{x:1596,y:827,t:1527020187713};\\\", \\\"{x:1597,y:832,t:1527020187799};\\\", \\\"{x:1599,y:842,t:1527020187812};\\\", \\\"{x:1600,y:858,t:1527020187829};\\\", \\\"{x:1602,y:873,t:1527020187846};\\\", \\\"{x:1604,y:887,t:1527020187863};\\\", \\\"{x:1606,y:896,t:1527020187879};\\\", \\\"{x:1607,y:905,t:1527020187896};\\\", \\\"{x:1609,y:915,t:1527020187912};\\\", \\\"{x:1610,y:926,t:1527020187929};\\\", \\\"{x:1611,y:936,t:1527020187945};\\\", \\\"{x:1614,y:942,t:1527020187963};\\\", \\\"{x:1615,y:944,t:1527020187979};\\\", \\\"{x:1615,y:940,t:1527020188103};\\\", \\\"{x:1611,y:930,t:1527020188113};\\\", \\\"{x:1603,y:914,t:1527020188130};\\\", \\\"{x:1594,y:899,t:1527020188146};\\\", \\\"{x:1586,y:887,t:1527020188163};\\\", \\\"{x:1580,y:879,t:1527020188180};\\\", \\\"{x:1575,y:870,t:1527020188197};\\\", \\\"{x:1571,y:865,t:1527020188213};\\\", \\\"{x:1569,y:857,t:1527020188230};\\\", \\\"{x:1563,y:844,t:1527020188247};\\\", \\\"{x:1561,y:835,t:1527020188262};\\\", \\\"{x:1557,y:827,t:1527020188279};\\\", \\\"{x:1553,y:820,t:1527020188296};\\\", \\\"{x:1549,y:812,t:1527020188312};\\\", \\\"{x:1546,y:808,t:1527020188329};\\\", \\\"{x:1541,y:798,t:1527020188346};\\\", \\\"{x:1535,y:790,t:1527020188362};\\\", \\\"{x:1528,y:782,t:1527020188380};\\\", \\\"{x:1524,y:775,t:1527020188396};\\\", \\\"{x:1520,y:769,t:1527020188412};\\\", \\\"{x:1517,y:765,t:1527020188429};\\\", \\\"{x:1513,y:759,t:1527020188446};\\\", \\\"{x:1508,y:753,t:1527020188463};\\\", \\\"{x:1505,y:750,t:1527020188479};\\\", \\\"{x:1501,y:745,t:1527020188496};\\\", \\\"{x:1493,y:738,t:1527020188513};\\\", \\\"{x:1488,y:731,t:1527020188529};\\\", \\\"{x:1481,y:724,t:1527020188546};\\\", \\\"{x:1473,y:715,t:1527020188563};\\\", \\\"{x:1464,y:707,t:1527020188579};\\\", \\\"{x:1452,y:695,t:1527020188596};\\\", \\\"{x:1443,y:683,t:1527020188614};\\\", \\\"{x:1436,y:675,t:1527020188630};\\\", \\\"{x:1426,y:663,t:1527020188647};\\\", \\\"{x:1419,y:658,t:1527020188663};\\\", \\\"{x:1418,y:656,t:1527020188679};\\\", \\\"{x:1416,y:654,t:1527020188697};\\\", \\\"{x:1414,y:652,t:1527020188714};\\\", \\\"{x:1411,y:649,t:1527020188730};\\\", \\\"{x:1410,y:649,t:1527020188759};\\\", \\\"{x:1410,y:648,t:1527020188767};\\\", \\\"{x:1408,y:647,t:1527020188807};\\\", \\\"{x:1407,y:646,t:1527020188823};\\\", \\\"{x:1406,y:646,t:1527020188831};\\\", \\\"{x:1401,y:643,t:1527020188847};\\\", \\\"{x:1398,y:641,t:1527020188864};\\\", \\\"{x:1396,y:640,t:1527020188880};\\\", \\\"{x:1395,y:640,t:1527020188903};\\\", \\\"{x:1395,y:639,t:1527020189535};\\\", \\\"{x:1401,y:637,t:1527020189548};\\\", \\\"{x:1408,y:635,t:1527020189564};\\\", \\\"{x:1412,y:634,t:1527020189580};\\\", \\\"{x:1414,y:634,t:1527020189607};\\\", \\\"{x:1415,y:634,t:1527020189623};\\\", \\\"{x:1416,y:634,t:1527020189655};\\\", \\\"{x:1417,y:634,t:1527020189664};\\\", \\\"{x:1417,y:635,t:1527020189681};\\\", \\\"{x:1418,y:637,t:1527020189698};\\\", \\\"{x:1419,y:642,t:1527020189714};\\\", \\\"{x:1423,y:654,t:1527020189731};\\\", \\\"{x:1429,y:666,t:1527020189748};\\\", \\\"{x:1435,y:682,t:1527020189764};\\\", \\\"{x:1443,y:702,t:1527020189781};\\\", \\\"{x:1457,y:728,t:1527020189798};\\\", \\\"{x:1481,y:762,t:1527020189814};\\\", \\\"{x:1508,y:796,t:1527020189831};\\\", \\\"{x:1524,y:814,t:1527020189848};\\\", \\\"{x:1539,y:831,t:1527020189864};\\\", \\\"{x:1549,y:841,t:1527020189880};\\\", \\\"{x:1553,y:845,t:1527020189897};\\\", \\\"{x:1555,y:845,t:1527020189914};\\\", \\\"{x:1555,y:847,t:1527020189935};\\\", \\\"{x:1556,y:848,t:1527020189948};\\\", \\\"{x:1558,y:852,t:1527020189964};\\\", \\\"{x:1561,y:859,t:1527020189981};\\\", \\\"{x:1566,y:866,t:1527020189998};\\\", \\\"{x:1577,y:882,t:1527020190015};\\\", \\\"{x:1586,y:895,t:1527020190032};\\\", \\\"{x:1598,y:909,t:1527020190048};\\\", \\\"{x:1608,y:920,t:1527020190065};\\\", \\\"{x:1618,y:932,t:1527020190081};\\\", \\\"{x:1624,y:938,t:1527020190098};\\\", \\\"{x:1628,y:943,t:1527020190115};\\\", \\\"{x:1628,y:944,t:1527020190159};\\\", \\\"{x:1629,y:944,t:1527020190167};\\\", \\\"{x:1630,y:946,t:1527020190183};\\\", \\\"{x:1630,y:947,t:1527020190199};\\\", \\\"{x:1630,y:949,t:1527020190215};\\\", \\\"{x:1630,y:951,t:1527020190231};\\\", \\\"{x:1631,y:954,t:1527020190248};\\\", \\\"{x:1632,y:956,t:1527020190265};\\\", \\\"{x:1633,y:960,t:1527020190281};\\\", \\\"{x:1635,y:964,t:1527020190298};\\\", \\\"{x:1635,y:966,t:1527020190315};\\\", \\\"{x:1635,y:967,t:1527020190331};\\\", \\\"{x:1633,y:967,t:1527020190407};\\\", \\\"{x:1631,y:965,t:1527020190415};\\\", \\\"{x:1621,y:954,t:1527020190431};\\\", \\\"{x:1610,y:940,t:1527020190448};\\\", \\\"{x:1599,y:926,t:1527020190465};\\\", \\\"{x:1593,y:917,t:1527020190482};\\\", \\\"{x:1589,y:906,t:1527020190497};\\\", \\\"{x:1587,y:899,t:1527020190515};\\\", \\\"{x:1585,y:893,t:1527020190532};\\\", \\\"{x:1582,y:886,t:1527020190547};\\\", \\\"{x:1579,y:878,t:1527020190564};\\\", \\\"{x:1575,y:872,t:1527020190582};\\\", \\\"{x:1572,y:864,t:1527020190598};\\\", \\\"{x:1567,y:854,t:1527020190615};\\\", \\\"{x:1565,y:848,t:1527020190632};\\\", \\\"{x:1560,y:839,t:1527020190648};\\\", \\\"{x:1558,y:835,t:1527020190665};\\\", \\\"{x:1555,y:828,t:1527020190682};\\\", \\\"{x:1551,y:822,t:1527020190698};\\\", \\\"{x:1549,y:818,t:1527020190715};\\\", \\\"{x:1546,y:813,t:1527020190733};\\\", \\\"{x:1545,y:809,t:1527020190748};\\\", \\\"{x:1543,y:804,t:1527020190764};\\\", \\\"{x:1541,y:800,t:1527020190782};\\\", \\\"{x:1539,y:796,t:1527020190798};\\\", \\\"{x:1537,y:792,t:1527020190814};\\\", \\\"{x:1536,y:789,t:1527020190832};\\\", \\\"{x:1535,y:786,t:1527020190848};\\\", \\\"{x:1535,y:785,t:1527020190865};\\\", \\\"{x:1535,y:788,t:1527020191007};\\\", \\\"{x:1535,y:798,t:1527020191015};\\\", \\\"{x:1535,y:826,t:1527020191031};\\\", \\\"{x:1539,y:854,t:1527020191049};\\\", \\\"{x:1548,y:875,t:1527020191065};\\\", \\\"{x:1555,y:892,t:1527020191082};\\\", \\\"{x:1557,y:899,t:1527020191099};\\\", \\\"{x:1559,y:905,t:1527020191115};\\\", \\\"{x:1559,y:907,t:1527020191133};\\\", \\\"{x:1560,y:908,t:1527020191148};\\\", \\\"{x:1560,y:907,t:1527020191351};\\\", \\\"{x:1560,y:903,t:1527020191365};\\\", \\\"{x:1556,y:894,t:1527020191382};\\\", \\\"{x:1544,y:872,t:1527020191399};\\\", \\\"{x:1534,y:852,t:1527020191415};\\\", \\\"{x:1518,y:831,t:1527020191432};\\\", \\\"{x:1505,y:812,t:1527020191449};\\\", \\\"{x:1494,y:797,t:1527020191466};\\\", \\\"{x:1486,y:786,t:1527020191482};\\\", \\\"{x:1475,y:773,t:1527020191499};\\\", \\\"{x:1470,y:766,t:1527020191516};\\\", \\\"{x:1465,y:761,t:1527020191533};\\\", \\\"{x:1461,y:756,t:1527020191549};\\\", \\\"{x:1458,y:753,t:1527020191566};\\\", \\\"{x:1455,y:751,t:1527020191582};\\\", \\\"{x:1452,y:748,t:1527020191599};\\\", \\\"{x:1451,y:745,t:1527020191616};\\\", \\\"{x:1448,y:741,t:1527020191631};\\\", \\\"{x:1446,y:738,t:1527020191649};\\\", \\\"{x:1443,y:733,t:1527020191666};\\\", \\\"{x:1439,y:727,t:1527020191682};\\\", \\\"{x:1434,y:719,t:1527020191699};\\\", \\\"{x:1431,y:713,t:1527020191716};\\\", \\\"{x:1427,y:703,t:1527020191733};\\\", \\\"{x:1423,y:695,t:1527020191749};\\\", \\\"{x:1421,y:688,t:1527020191766};\\\", \\\"{x:1418,y:679,t:1527020191782};\\\", \\\"{x:1414,y:666,t:1527020191798};\\\", \\\"{x:1413,y:657,t:1527020191815};\\\", \\\"{x:1410,y:650,t:1527020191831};\\\", \\\"{x:1409,y:648,t:1527020191848};\\\", \\\"{x:1409,y:646,t:1527020191865};\\\", \\\"{x:1409,y:645,t:1527020191883};\\\", \\\"{x:1409,y:642,t:1527020191898};\\\", \\\"{x:1409,y:640,t:1527020191916};\\\", \\\"{x:1409,y:637,t:1527020191932};\\\", \\\"{x:1408,y:635,t:1527020191948};\\\", \\\"{x:1408,y:632,t:1527020191965};\\\", \\\"{x:1407,y:630,t:1527020191982};\\\", \\\"{x:1407,y:629,t:1527020191999};\\\", \\\"{x:1407,y:627,t:1527020192016};\\\", \\\"{x:1407,y:626,t:1527020192033};\\\", \\\"{x:1406,y:625,t:1527020192055};\\\", \\\"{x:1406,y:624,t:1527020192066};\\\", \\\"{x:1406,y:623,t:1527020192103};\\\", \\\"{x:1413,y:628,t:1527020195271};\\\", \\\"{x:1429,y:645,t:1527020195285};\\\", \\\"{x:1538,y:717,t:1527020195302};\\\", \\\"{x:1587,y:745,t:1527020195318};\\\", \\\"{x:1731,y:818,t:1527020195334};\\\", \\\"{x:1812,y:849,t:1527020195352};\\\", \\\"{x:1861,y:864,t:1527020195368};\\\", \\\"{x:1876,y:870,t:1527020195385};\\\", \\\"{x:1879,y:872,t:1527020195402};\\\", \\\"{x:1879,y:873,t:1527020195431};\\\", \\\"{x:1879,y:875,t:1527020195455};\\\", \\\"{x:1879,y:876,t:1527020195468};\\\", \\\"{x:1879,y:878,t:1527020195484};\\\", \\\"{x:1879,y:879,t:1527020195502};\\\", \\\"{x:1876,y:882,t:1527020195518};\\\", \\\"{x:1853,y:887,t:1527020195535};\\\", \\\"{x:1823,y:890,t:1527020195552};\\\", \\\"{x:1790,y:893,t:1527020195568};\\\", \\\"{x:1753,y:894,t:1527020195585};\\\", \\\"{x:1720,y:894,t:1527020195602};\\\", \\\"{x:1694,y:894,t:1527020195618};\\\", \\\"{x:1677,y:894,t:1527020195635};\\\", \\\"{x:1670,y:894,t:1527020195652};\\\", \\\"{x:1666,y:895,t:1527020195669};\\\", \\\"{x:1664,y:896,t:1527020195685};\\\", \\\"{x:1661,y:897,t:1527020195702};\\\", \\\"{x:1656,y:898,t:1527020195718};\\\", \\\"{x:1652,y:898,t:1527020195735};\\\", \\\"{x:1649,y:898,t:1527020195752};\\\", \\\"{x:1646,y:900,t:1527020195769};\\\", \\\"{x:1643,y:901,t:1527020195785};\\\", \\\"{x:1637,y:905,t:1527020195802};\\\", \\\"{x:1631,y:909,t:1527020195819};\\\", \\\"{x:1624,y:913,t:1527020195834};\\\", \\\"{x:1617,y:915,t:1527020195852};\\\", \\\"{x:1608,y:918,t:1527020195869};\\\", \\\"{x:1597,y:922,t:1527020195885};\\\", \\\"{x:1588,y:924,t:1527020195902};\\\", \\\"{x:1580,y:925,t:1527020195919};\\\", \\\"{x:1576,y:926,t:1527020195935};\\\", \\\"{x:1571,y:927,t:1527020195952};\\\", \\\"{x:1567,y:927,t:1527020195969};\\\", \\\"{x:1564,y:928,t:1527020195985};\\\", \\\"{x:1560,y:928,t:1527020196002};\\\", \\\"{x:1558,y:929,t:1527020196019};\\\", \\\"{x:1556,y:929,t:1527020196035};\\\", \\\"{x:1555,y:929,t:1527020196190};\\\", \\\"{x:1555,y:930,t:1527020196423};\\\", \\\"{x:1557,y:932,t:1527020196439};\\\", \\\"{x:1560,y:933,t:1527020196452};\\\", \\\"{x:1565,y:936,t:1527020196469};\\\", \\\"{x:1573,y:940,t:1527020196486};\\\", \\\"{x:1580,y:944,t:1527020196502};\\\", \\\"{x:1586,y:946,t:1527020196519};\\\", \\\"{x:1589,y:947,t:1527020196536};\\\", \\\"{x:1591,y:947,t:1527020196552};\\\", \\\"{x:1595,y:948,t:1527020196569};\\\", \\\"{x:1596,y:949,t:1527020196586};\\\", \\\"{x:1596,y:950,t:1527020196603};\\\", \\\"{x:1597,y:950,t:1527020196619};\\\", \\\"{x:1598,y:950,t:1527020196655};\\\", \\\"{x:1599,y:951,t:1527020196694};\\\", \\\"{x:1600,y:951,t:1527020197527};\\\", \\\"{x:1601,y:951,t:1527020197671};\\\", \\\"{x:1602,y:951,t:1527020198807};\\\", \\\"{x:1602,y:950,t:1527020198887};\\\", \\\"{x:1603,y:950,t:1527020198910};\\\", \\\"{x:1603,y:949,t:1527020200263};\\\", \\\"{x:1603,y:947,t:1527020200751};\\\", \\\"{x:1603,y:946,t:1527020200758};\\\", \\\"{x:1603,y:944,t:1527020200772};\\\", \\\"{x:1603,y:943,t:1527020200789};\\\", \\\"{x:1603,y:941,t:1527020200805};\\\", \\\"{x:1602,y:939,t:1527020200822};\\\", \\\"{x:1602,y:937,t:1527020200847};\\\", \\\"{x:1601,y:935,t:1527020200862};\\\", \\\"{x:1600,y:932,t:1527020200873};\\\", \\\"{x:1600,y:930,t:1527020200890};\\\", \\\"{x:1600,y:924,t:1527020200906};\\\", \\\"{x:1599,y:922,t:1527020200922};\\\", \\\"{x:1599,y:919,t:1527020200939};\\\", \\\"{x:1598,y:916,t:1527020200956};\\\", \\\"{x:1598,y:913,t:1527020200972};\\\", \\\"{x:1598,y:912,t:1527020200989};\\\", \\\"{x:1597,y:908,t:1527020201007};\\\", \\\"{x:1596,y:906,t:1527020201022};\\\", \\\"{x:1596,y:910,t:1527020202038};\\\", \\\"{x:1596,y:921,t:1527020202057};\\\", \\\"{x:1596,y:928,t:1527020202074};\\\", \\\"{x:1596,y:936,t:1527020202090};\\\", \\\"{x:1597,y:944,t:1527020202106};\\\", \\\"{x:1599,y:949,t:1527020202123};\\\", \\\"{x:1600,y:953,t:1527020202140};\\\", \\\"{x:1601,y:955,t:1527020202156};\\\", \\\"{x:1601,y:956,t:1527020202270};\\\", \\\"{x:1601,y:955,t:1527020202278};\\\", \\\"{x:1601,y:950,t:1527020202290};\\\", \\\"{x:1601,y:935,t:1527020202307};\\\", \\\"{x:1601,y:916,t:1527020202324};\\\", \\\"{x:1601,y:892,t:1527020202341};\\\", \\\"{x:1601,y:867,t:1527020202356};\\\", \\\"{x:1601,y:843,t:1527020202374};\\\", \\\"{x:1601,y:815,t:1527020202391};\\\", \\\"{x:1599,y:800,t:1527020202407};\\\", \\\"{x:1598,y:785,t:1527020202423};\\\", \\\"{x:1597,y:769,t:1527020202440};\\\", \\\"{x:1596,y:751,t:1527020202457};\\\", \\\"{x:1596,y:734,t:1527020202473};\\\", \\\"{x:1596,y:715,t:1527020202490};\\\", \\\"{x:1596,y:703,t:1527020202507};\\\", \\\"{x:1597,y:696,t:1527020202523};\\\", \\\"{x:1598,y:693,t:1527020202540};\\\", \\\"{x:1598,y:691,t:1527020202556};\\\", \\\"{x:1599,y:690,t:1527020202572};\\\", \\\"{x:1600,y:689,t:1527020202590};\\\", \\\"{x:1601,y:688,t:1527020202607};\\\", \\\"{x:1602,y:688,t:1527020202622};\\\", \\\"{x:1603,y:688,t:1527020202766};\\\", \\\"{x:1606,y:690,t:1527020202774};\\\", \\\"{x:1611,y:706,t:1527020202789};\\\", \\\"{x:1616,y:719,t:1527020202807};\\\", \\\"{x:1621,y:728,t:1527020202823};\\\", \\\"{x:1622,y:732,t:1527020202839};\\\", \\\"{x:1622,y:733,t:1527020202856};\\\", \\\"{x:1623,y:734,t:1527020202878};\\\", \\\"{x:1624,y:735,t:1527020202909};\\\", \\\"{x:1624,y:736,t:1527020202926};\\\", \\\"{x:1624,y:737,t:1527020202940};\\\", \\\"{x:1624,y:739,t:1527020202956};\\\", \\\"{x:1624,y:742,t:1527020202974};\\\", \\\"{x:1624,y:743,t:1527020202990};\\\", \\\"{x:1624,y:746,t:1527020203007};\\\", \\\"{x:1624,y:747,t:1527020203030};\\\", \\\"{x:1624,y:744,t:1527020203318};\\\", \\\"{x:1624,y:740,t:1527020203326};\\\", \\\"{x:1624,y:736,t:1527020203340};\\\", \\\"{x:1624,y:729,t:1527020203356};\\\", \\\"{x:1624,y:720,t:1527020203374};\\\", \\\"{x:1624,y:715,t:1527020203390};\\\", \\\"{x:1624,y:711,t:1527020203407};\\\", \\\"{x:1624,y:710,t:1527020203431};\\\", \\\"{x:1623,y:710,t:1527020204535};\\\", \\\"{x:1622,y:710,t:1527020204542};\\\", \\\"{x:1622,y:709,t:1527020205254};\\\", \\\"{x:1621,y:708,t:1527020205263};\\\", \\\"{x:1621,y:707,t:1527020205275};\\\", \\\"{x:1620,y:706,t:1527020205415};\\\", \\\"{x:1618,y:709,t:1527020205432};\\\", \\\"{x:1617,y:716,t:1527020205442};\\\", \\\"{x:1614,y:727,t:1527020205460};\\\", \\\"{x:1612,y:738,t:1527020205475};\\\", \\\"{x:1609,y:750,t:1527020205492};\\\", \\\"{x:1608,y:764,t:1527020205509};\\\", \\\"{x:1606,y:781,t:1527020205526};\\\", \\\"{x:1606,y:799,t:1527020205543};\\\", \\\"{x:1606,y:812,t:1527020205559};\\\", \\\"{x:1606,y:831,t:1527020205577};\\\", \\\"{x:1606,y:849,t:1527020205592};\\\", \\\"{x:1606,y:868,t:1527020205610};\\\", \\\"{x:1606,y:880,t:1527020205626};\\\", \\\"{x:1606,y:895,t:1527020205642};\\\", \\\"{x:1606,y:901,t:1527020205659};\\\", \\\"{x:1606,y:906,t:1527020205677};\\\", \\\"{x:1606,y:909,t:1527020205692};\\\", \\\"{x:1606,y:912,t:1527020205709};\\\", \\\"{x:1606,y:917,t:1527020205726};\\\", \\\"{x:1607,y:921,t:1527020205742};\\\", \\\"{x:1607,y:923,t:1527020205759};\\\", \\\"{x:1608,y:925,t:1527020205776};\\\", \\\"{x:1608,y:928,t:1527020205792};\\\", \\\"{x:1608,y:929,t:1527020205809};\\\", \\\"{x:1608,y:931,t:1527020205826};\\\", \\\"{x:1609,y:934,t:1527020205842};\\\", \\\"{x:1609,y:938,t:1527020205859};\\\", \\\"{x:1611,y:942,t:1527020205876};\\\", \\\"{x:1611,y:945,t:1527020205892};\\\", \\\"{x:1611,y:948,t:1527020205909};\\\", \\\"{x:1612,y:951,t:1527020205927};\\\", \\\"{x:1612,y:953,t:1527020205942};\\\", \\\"{x:1613,y:956,t:1527020205959};\\\", \\\"{x:1613,y:957,t:1527020205983};\\\", \\\"{x:1613,y:958,t:1527020205993};\\\", \\\"{x:1613,y:959,t:1527020206014};\\\", \\\"{x:1613,y:958,t:1527020206054};\\\", \\\"{x:1613,y:948,t:1527020206063};\\\", \\\"{x:1613,y:934,t:1527020206076};\\\", \\\"{x:1610,y:903,t:1527020206093};\\\", \\\"{x:1607,y:879,t:1527020206109};\\\", \\\"{x:1601,y:841,t:1527020206126};\\\", \\\"{x:1596,y:819,t:1527020206142};\\\", \\\"{x:1593,y:800,t:1527020206160};\\\", \\\"{x:1592,y:788,t:1527020206176};\\\", \\\"{x:1590,y:777,t:1527020206193};\\\", \\\"{x:1589,y:768,t:1527020206209};\\\", \\\"{x:1589,y:765,t:1527020206227};\\\", \\\"{x:1588,y:764,t:1527020206244};\\\", \\\"{x:1588,y:763,t:1527020206259};\\\", \\\"{x:1585,y:763,t:1527020206294};\\\", \\\"{x:1582,y:763,t:1527020206309};\\\", \\\"{x:1572,y:767,t:1527020206326};\\\", \\\"{x:1569,y:768,t:1527020206343};\\\", \\\"{x:1567,y:768,t:1527020206360};\\\", \\\"{x:1566,y:768,t:1527020206376};\\\", \\\"{x:1564,y:768,t:1527020206423};\\\", \\\"{x:1563,y:768,t:1527020206430};\\\", \\\"{x:1562,y:768,t:1527020206444};\\\", \\\"{x:1559,y:768,t:1527020206459};\\\", \\\"{x:1556,y:767,t:1527020206476};\\\", \\\"{x:1554,y:767,t:1527020206494};\\\", \\\"{x:1551,y:766,t:1527020206510};\\\", \\\"{x:1549,y:766,t:1527020206527};\\\", \\\"{x:1545,y:766,t:1527020206543};\\\", \\\"{x:1544,y:766,t:1527020206560};\\\", \\\"{x:1543,y:765,t:1527020206622};\\\", \\\"{x:1543,y:763,t:1527020206630};\\\", \\\"{x:1543,y:761,t:1527020206644};\\\", \\\"{x:1543,y:755,t:1527020206660};\\\", \\\"{x:1543,y:743,t:1527020206676};\\\", \\\"{x:1543,y:733,t:1527020206693};\\\", \\\"{x:1543,y:719,t:1527020206711};\\\", \\\"{x:1544,y:707,t:1527020206727};\\\", \\\"{x:1545,y:703,t:1527020206744};\\\", \\\"{x:1545,y:700,t:1527020206760};\\\", \\\"{x:1545,y:699,t:1527020207007};\\\", \\\"{x:1545,y:697,t:1527020207014};\\\", \\\"{x:1545,y:696,t:1527020207028};\\\", \\\"{x:1545,y:693,t:1527020207044};\\\", \\\"{x:1545,y:694,t:1527020207175};\\\", \\\"{x:1546,y:704,t:1527020207182};\\\", \\\"{x:1550,y:717,t:1527020207193};\\\", \\\"{x:1557,y:743,t:1527020207211};\\\", \\\"{x:1565,y:773,t:1527020207227};\\\", \\\"{x:1576,y:805,t:1527020207243};\\\", \\\"{x:1588,y:835,t:1527020207260};\\\", \\\"{x:1597,y:855,t:1527020207277};\\\", \\\"{x:1604,y:877,t:1527020207293};\\\", \\\"{x:1612,y:902,t:1527020207311};\\\", \\\"{x:1615,y:913,t:1527020207328};\\\", \\\"{x:1618,y:925,t:1527020207343};\\\", \\\"{x:1620,y:932,t:1527020207360};\\\", \\\"{x:1622,y:937,t:1527020207377};\\\", \\\"{x:1622,y:939,t:1527020207394};\\\", \\\"{x:1622,y:943,t:1527020207410};\\\", \\\"{x:1622,y:946,t:1527020207427};\\\", \\\"{x:1622,y:950,t:1527020207445};\\\", \\\"{x:1622,y:951,t:1527020207462};\\\", \\\"{x:1622,y:953,t:1527020207478};\\\", \\\"{x:1622,y:954,t:1527020207494};\\\", \\\"{x:1622,y:957,t:1527020207510};\\\", \\\"{x:1622,y:959,t:1527020207527};\\\", \\\"{x:1622,y:960,t:1527020207545};\\\", \\\"{x:1622,y:961,t:1527020207638};\\\", \\\"{x:1620,y:960,t:1527020207687};\\\", \\\"{x:1617,y:955,t:1527020207694};\\\", \\\"{x:1611,y:944,t:1527020207710};\\\", \\\"{x:1604,y:933,t:1527020207727};\\\", \\\"{x:1598,y:923,t:1527020207744};\\\", \\\"{x:1592,y:916,t:1527020207761};\\\", \\\"{x:1586,y:909,t:1527020207777};\\\", \\\"{x:1582,y:902,t:1527020207794};\\\", \\\"{x:1576,y:895,t:1527020207811};\\\", \\\"{x:1572,y:889,t:1527020207828};\\\", \\\"{x:1569,y:886,t:1527020207845};\\\", \\\"{x:1568,y:882,t:1527020207861};\\\", \\\"{x:1564,y:875,t:1527020207878};\\\", \\\"{x:1560,y:868,t:1527020207895};\\\", \\\"{x:1559,y:865,t:1527020207910};\\\", \\\"{x:1558,y:861,t:1527020207927};\\\", \\\"{x:1556,y:858,t:1527020207944};\\\", \\\"{x:1553,y:854,t:1527020207961};\\\", \\\"{x:1552,y:850,t:1527020207977};\\\", \\\"{x:1550,y:847,t:1527020207994};\\\", \\\"{x:1549,y:845,t:1527020208011};\\\", \\\"{x:1547,y:841,t:1527020208027};\\\", \\\"{x:1546,y:839,t:1527020208045};\\\", \\\"{x:1545,y:838,t:1527020208061};\\\", \\\"{x:1544,y:836,t:1527020208078};\\\", \\\"{x:1543,y:834,t:1527020208095};\\\", \\\"{x:1542,y:833,t:1527020208111};\\\", \\\"{x:1540,y:832,t:1527020208128};\\\", \\\"{x:1539,y:829,t:1527020208145};\\\", \\\"{x:1539,y:828,t:1527020208161};\\\", \\\"{x:1537,y:826,t:1527020208177};\\\", \\\"{x:1537,y:825,t:1527020208195};\\\", \\\"{x:1535,y:822,t:1527020208212};\\\", \\\"{x:1535,y:820,t:1527020208227};\\\", \\\"{x:1533,y:818,t:1527020208244};\\\", \\\"{x:1530,y:814,t:1527020208262};\\\", \\\"{x:1528,y:812,t:1527020208278};\\\", \\\"{x:1526,y:809,t:1527020208295};\\\", \\\"{x:1526,y:808,t:1527020208312};\\\", \\\"{x:1524,y:805,t:1527020208327};\\\", \\\"{x:1522,y:800,t:1527020208345};\\\", \\\"{x:1517,y:792,t:1527020208361};\\\", \\\"{x:1510,y:781,t:1527020208378};\\\", \\\"{x:1506,y:773,t:1527020208395};\\\", \\\"{x:1503,y:769,t:1527020208411};\\\", \\\"{x:1501,y:766,t:1527020208428};\\\", \\\"{x:1500,y:764,t:1527020208445};\\\", \\\"{x:1498,y:761,t:1527020208461};\\\", \\\"{x:1494,y:754,t:1527020208479};\\\", \\\"{x:1493,y:751,t:1527020208494};\\\", \\\"{x:1490,y:748,t:1527020208511};\\\", \\\"{x:1489,y:744,t:1527020208528};\\\", \\\"{x:1487,y:741,t:1527020208544};\\\", \\\"{x:1484,y:737,t:1527020208561};\\\", \\\"{x:1482,y:734,t:1527020208578};\\\", \\\"{x:1482,y:732,t:1527020208595};\\\", \\\"{x:1479,y:729,t:1527020208611};\\\", \\\"{x:1478,y:727,t:1527020208628};\\\", \\\"{x:1476,y:724,t:1527020208644};\\\", \\\"{x:1475,y:722,t:1527020208661};\\\", \\\"{x:1474,y:720,t:1527020208678};\\\", \\\"{x:1473,y:719,t:1527020208695};\\\", \\\"{x:1472,y:716,t:1527020208711};\\\", \\\"{x:1468,y:711,t:1527020208728};\\\", \\\"{x:1464,y:705,t:1527020208745};\\\", \\\"{x:1461,y:701,t:1527020208761};\\\", \\\"{x:1458,y:696,t:1527020208778};\\\", \\\"{x:1456,y:693,t:1527020208795};\\\", \\\"{x:1453,y:690,t:1527020208811};\\\", \\\"{x:1446,y:683,t:1527020208828};\\\", \\\"{x:1436,y:669,t:1527020208846};\\\", \\\"{x:1421,y:652,t:1527020208862};\\\", \\\"{x:1403,y:636,t:1527020208878};\\\", \\\"{x:1393,y:626,t:1527020208894};\\\", \\\"{x:1386,y:617,t:1527020208911};\\\", \\\"{x:1381,y:612,t:1527020208929};\\\", \\\"{x:1374,y:608,t:1527020208945};\\\", \\\"{x:1366,y:603,t:1527020208961};\\\", \\\"{x:1358,y:601,t:1527020208978};\\\", \\\"{x:1351,y:598,t:1527020208995};\\\", \\\"{x:1332,y:593,t:1527020209012};\\\", \\\"{x:1284,y:572,t:1527020209028};\\\", \\\"{x:1285,y:573,t:1527020209398};\\\", \\\"{x:1286,y:574,t:1527020209413};\\\", \\\"{x:1288,y:574,t:1527020209429};\\\", \\\"{x:1288,y:576,t:1527020209446};\\\", \\\"{x:1286,y:576,t:1527020209463};\\\", \\\"{x:1285,y:577,t:1527020209478};\\\", \\\"{x:1282,y:578,t:1527020209495};\\\", \\\"{x:1279,y:579,t:1527020209512};\\\", \\\"{x:1278,y:580,t:1527020209528};\\\", \\\"{x:1272,y:580,t:1527020209546};\\\", \\\"{x:1261,y:584,t:1527020209562};\\\", \\\"{x:1245,y:585,t:1527020209579};\\\", \\\"{x:1216,y:585,t:1527020209595};\\\", \\\"{x:1171,y:585,t:1527020209613};\\\", \\\"{x:1104,y:585,t:1527020209628};\\\", \\\"{x:1031,y:585,t:1527020209645};\\\", \\\"{x:895,y:585,t:1527020209665};\\\", \\\"{x:801,y:585,t:1527020209678};\\\", \\\"{x:717,y:573,t:1527020209695};\\\", \\\"{x:669,y:564,t:1527020209711};\\\", \\\"{x:638,y:557,t:1527020209730};\\\", \\\"{x:630,y:555,t:1527020209746};\\\", \\\"{x:628,y:555,t:1527020209846};\\\", \\\"{x:626,y:555,t:1527020209854};\\\", \\\"{x:623,y:555,t:1527020209864};\\\", \\\"{x:612,y:559,t:1527020209880};\\\", \\\"{x:591,y:568,t:1527020209897};\\\", \\\"{x:556,y:575,t:1527020209913};\\\", \\\"{x:503,y:582,t:1527020209931};\\\", \\\"{x:457,y:585,t:1527020209949};\\\", \\\"{x:431,y:585,t:1527020209963};\\\", \\\"{x:420,y:585,t:1527020209980};\\\", \\\"{x:419,y:585,t:1527020209997};\\\", \\\"{x:418,y:585,t:1527020210191};\\\", \\\"{x:415,y:587,t:1527020210199};\\\", \\\"{x:405,y:593,t:1527020210214};\\\", \\\"{x:379,y:605,t:1527020210231};\\\", \\\"{x:355,y:613,t:1527020210248};\\\", \\\"{x:331,y:623,t:1527020210263};\\\", \\\"{x:301,y:631,t:1527020210281};\\\", \\\"{x:270,y:635,t:1527020210298};\\\", \\\"{x:245,y:639,t:1527020210315};\\\", \\\"{x:227,y:641,t:1527020210331};\\\", \\\"{x:216,y:642,t:1527020210348};\\\", \\\"{x:209,y:642,t:1527020210363};\\\", \\\"{x:205,y:642,t:1527020210381};\\\", \\\"{x:203,y:642,t:1527020210397};\\\", \\\"{x:202,y:643,t:1527020210413};\\\", \\\"{x:201,y:643,t:1527020210438};\\\", \\\"{x:200,y:643,t:1527020210477};\\\", \\\"{x:199,y:643,t:1527020210623};\\\", \\\"{x:199,y:642,t:1527020210646};\\\", \\\"{x:199,y:641,t:1527020210654};\\\", \\\"{x:199,y:640,t:1527020210670};\\\", \\\"{x:199,y:639,t:1527020210681};\\\", \\\"{x:200,y:638,t:1527020210700};\\\", \\\"{x:201,y:636,t:1527020210715};\\\", \\\"{x:206,y:633,t:1527020210732};\\\", \\\"{x:222,y:628,t:1527020210750};\\\", \\\"{x:248,y:622,t:1527020210765};\\\", \\\"{x:290,y:617,t:1527020210781};\\\", \\\"{x:397,y:613,t:1527020210798};\\\", \\\"{x:481,y:609,t:1527020210815};\\\", \\\"{x:573,y:609,t:1527020210831};\\\", \\\"{x:656,y:609,t:1527020210848};\\\", \\\"{x:726,y:609,t:1527020210865};\\\", \\\"{x:779,y:609,t:1527020210881};\\\", \\\"{x:813,y:609,t:1527020210898};\\\", \\\"{x:830,y:609,t:1527020210915};\\\", \\\"{x:839,y:609,t:1527020210932};\\\", \\\"{x:843,y:609,t:1527020210948};\\\", \\\"{x:845,y:609,t:1527020210965};\\\", \\\"{x:846,y:609,t:1527020210981};\\\", \\\"{x:847,y:609,t:1527020211005};\\\", \\\"{x:848,y:609,t:1527020211015};\\\", \\\"{x:848,y:608,t:1527020211031};\\\", \\\"{x:852,y:604,t:1527020212054};\\\", \\\"{x:853,y:597,t:1527020212067};\\\", \\\"{x:853,y:588,t:1527020212082};\\\", \\\"{x:856,y:582,t:1527020212099};\\\", \\\"{x:857,y:576,t:1527020212116};\\\", \\\"{x:858,y:573,t:1527020212132};\\\", \\\"{x:858,y:571,t:1527020212148};\\\", \\\"{x:859,y:570,t:1527020212166};\\\", \\\"{x:857,y:570,t:1527020212621};\\\", \\\"{x:856,y:570,t:1527020212633};\\\", \\\"{x:843,y:572,t:1527020212650};\\\", \\\"{x:815,y:574,t:1527020212667};\\\", \\\"{x:762,y:576,t:1527020212683};\\\", \\\"{x:678,y:576,t:1527020212700};\\\", \\\"{x:581,y:576,t:1527020212715};\\\", \\\"{x:471,y:565,t:1527020212733};\\\", \\\"{x:322,y:541,t:1527020212750};\\\", \\\"{x:244,y:530,t:1527020212767};\\\", \\\"{x:185,y:522,t:1527020212784};\\\", \\\"{x:144,y:519,t:1527020212800};\\\", \\\"{x:124,y:519,t:1527020212816};\\\", \\\"{x:110,y:519,t:1527020212833};\\\", \\\"{x:103,y:519,t:1527020212850};\\\", \\\"{x:101,y:519,t:1527020212866};\\\", \\\"{x:98,y:519,t:1527020212883};\\\", \\\"{x:96,y:519,t:1527020212974};\\\", \\\"{x:96,y:520,t:1527020212998};\\\", \\\"{x:97,y:523,t:1527020213006};\\\", \\\"{x:99,y:527,t:1527020213017};\\\", \\\"{x:105,y:534,t:1527020213033};\\\", \\\"{x:112,y:541,t:1527020213050};\\\", \\\"{x:122,y:548,t:1527020213067};\\\", \\\"{x:131,y:555,t:1527020213084};\\\", \\\"{x:137,y:559,t:1527020213100};\\\", \\\"{x:141,y:562,t:1527020213117};\\\", \\\"{x:146,y:565,t:1527020213133};\\\", \\\"{x:147,y:566,t:1527020213150};\\\", \\\"{x:149,y:567,t:1527020213166};\\\", \\\"{x:152,y:568,t:1527020213183};\\\", \\\"{x:154,y:568,t:1527020213200};\\\", \\\"{x:154,y:569,t:1527020213222};\\\", \\\"{x:155,y:569,t:1527020213237};\\\", \\\"{x:157,y:569,t:1527020213253};\\\", \\\"{x:158,y:569,t:1527020213269};\\\", \\\"{x:159,y:570,t:1527020213285};\\\", \\\"{x:160,y:570,t:1527020213517};\\\", \\\"{x:167,y:580,t:1527020213533};\\\", \\\"{x:180,y:594,t:1527020213550};\\\", \\\"{x:198,y:610,t:1527020213568};\\\", \\\"{x:218,y:625,t:1527020213584};\\\", \\\"{x:239,y:638,t:1527020213600};\\\", \\\"{x:265,y:652,t:1527020213617};\\\", \\\"{x:286,y:661,t:1527020213634};\\\", \\\"{x:305,y:667,t:1527020213650};\\\", \\\"{x:323,y:672,t:1527020213667};\\\", \\\"{x:332,y:678,t:1527020213684};\\\", \\\"{x:346,y:682,t:1527020213700};\\\", \\\"{x:363,y:686,t:1527020213717};\\\", \\\"{x:388,y:694,t:1527020213733};\\\", \\\"{x:406,y:699,t:1527020213750};\\\", \\\"{x:426,y:705,t:1527020213767};\\\", \\\"{x:441,y:706,t:1527020213784};\\\", \\\"{x:453,y:709,t:1527020213800};\\\", \\\"{x:463,y:710,t:1527020213817};\\\", \\\"{x:474,y:711,t:1527020213834};\\\", \\\"{x:481,y:712,t:1527020213850};\\\", \\\"{x:489,y:714,t:1527020213867};\\\", \\\"{x:498,y:718,t:1527020213884};\\\", \\\"{x:504,y:719,t:1527020213900};\\\", \\\"{x:514,y:722,t:1527020213919};\\\", \\\"{x:520,y:723,t:1527020213934};\\\", \\\"{x:525,y:725,t:1527020213950};\\\", \\\"{x:528,y:726,t:1527020213966};\\\", \\\"{x:531,y:727,t:1527020213984};\\\", \\\"{x:532,y:728,t:1527020214001};\\\", \\\"{x:533,y:729,t:1527020214017};\\\" ] }, { \\\"rt\\\": 5971, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 844433, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:729,t:1527020216029};\\\", \\\"{x:541,y:727,t:1527020216037};\\\", \\\"{x:553,y:722,t:1527020216052};\\\", \\\"{x:615,y:702,t:1527020216071};\\\", \\\"{x:683,y:692,t:1527020216087};\\\", \\\"{x:773,y:684,t:1527020216103};\\\", \\\"{x:876,y:684,t:1527020216119};\\\", \\\"{x:970,y:684,t:1527020216136};\\\", \\\"{x:1053,y:684,t:1527020216152};\\\", \\\"{x:1131,y:684,t:1527020216169};\\\", \\\"{x:1171,y:689,t:1527020216187};\\\", \\\"{x:1197,y:694,t:1527020216202};\\\", \\\"{x:1218,y:700,t:1527020216219};\\\", \\\"{x:1229,y:707,t:1527020216236};\\\", \\\"{x:1239,y:713,t:1527020216253};\\\", \\\"{x:1249,y:718,t:1527020216269};\\\", \\\"{x:1264,y:729,t:1527020216286};\\\", \\\"{x:1278,y:737,t:1527020216302};\\\", \\\"{x:1289,y:742,t:1527020216320};\\\", \\\"{x:1302,y:749,t:1527020216337};\\\", \\\"{x:1318,y:757,t:1527020216353};\\\", \\\"{x:1337,y:768,t:1527020216370};\\\", \\\"{x:1356,y:779,t:1527020216387};\\\", \\\"{x:1373,y:786,t:1527020216402};\\\", \\\"{x:1385,y:793,t:1527020216420};\\\", \\\"{x:1394,y:798,t:1527020216436};\\\", \\\"{x:1404,y:803,t:1527020216453};\\\", \\\"{x:1415,y:811,t:1527020216474};\\\", \\\"{x:1423,y:817,t:1527020216490};\\\", \\\"{x:1432,y:823,t:1527020216508};\\\", \\\"{x:1442,y:830,t:1527020216524};\\\", \\\"{x:1456,y:840,t:1527020216541};\\\", \\\"{x:1471,y:848,t:1527020216558};\\\", \\\"{x:1490,y:860,t:1527020216574};\\\", \\\"{x:1506,y:869,t:1527020216591};\\\", \\\"{x:1521,y:878,t:1527020216607};\\\", \\\"{x:1534,y:886,t:1527020216624};\\\", \\\"{x:1545,y:894,t:1527020216642};\\\", \\\"{x:1553,y:902,t:1527020216657};\\\", \\\"{x:1567,y:916,t:1527020216674};\\\", \\\"{x:1576,y:926,t:1527020216691};\\\", \\\"{x:1584,y:937,t:1527020216708};\\\", \\\"{x:1591,y:945,t:1527020216724};\\\", \\\"{x:1596,y:951,t:1527020216741};\\\", \\\"{x:1598,y:954,t:1527020216758};\\\", \\\"{x:1599,y:956,t:1527020216774};\\\", \\\"{x:1600,y:959,t:1527020216791};\\\", \\\"{x:1600,y:960,t:1527020216808};\\\", \\\"{x:1601,y:962,t:1527020216825};\\\", \\\"{x:1602,y:964,t:1527020216841};\\\", \\\"{x:1602,y:967,t:1527020216859};\\\", \\\"{x:1602,y:969,t:1527020216875};\\\", \\\"{x:1601,y:971,t:1527020216891};\\\", \\\"{x:1595,y:974,t:1527020216908};\\\", \\\"{x:1591,y:976,t:1527020216925};\\\", \\\"{x:1587,y:977,t:1527020216941};\\\", \\\"{x:1586,y:978,t:1527020216958};\\\", \\\"{x:1584,y:978,t:1527020216975};\\\", \\\"{x:1583,y:979,t:1527020216995};\\\", \\\"{x:1582,y:979,t:1527020217098};\\\", \\\"{x:1581,y:979,t:1527020217115};\\\", \\\"{x:1579,y:979,t:1527020217125};\\\", \\\"{x:1574,y:978,t:1527020217141};\\\", \\\"{x:1565,y:974,t:1527020217159};\\\", \\\"{x:1553,y:971,t:1527020217175};\\\", \\\"{x:1543,y:967,t:1527020217191};\\\", \\\"{x:1532,y:964,t:1527020217208};\\\", \\\"{x:1527,y:962,t:1527020217226};\\\", \\\"{x:1521,y:959,t:1527020217241};\\\", \\\"{x:1514,y:956,t:1527020217259};\\\", \\\"{x:1512,y:954,t:1527020217275};\\\", \\\"{x:1510,y:952,t:1527020217292};\\\", \\\"{x:1509,y:951,t:1527020217309};\\\", \\\"{x:1508,y:949,t:1527020217325};\\\", \\\"{x:1507,y:949,t:1527020217346};\\\", \\\"{x:1507,y:948,t:1527020217931};\\\", \\\"{x:1507,y:945,t:1527020217942};\\\", \\\"{x:1504,y:942,t:1527020217959};\\\", \\\"{x:1502,y:939,t:1527020217976};\\\", \\\"{x:1495,y:934,t:1527020217992};\\\", \\\"{x:1478,y:923,t:1527020218010};\\\", \\\"{x:1422,y:905,t:1527020218025};\\\", \\\"{x:1247,y:851,t:1527020218042};\\\", \\\"{x:1090,y:807,t:1527020218058};\\\", \\\"{x:910,y:750,t:1527020218075};\\\", \\\"{x:760,y:704,t:1527020218092};\\\", \\\"{x:644,y:668,t:1527020218110};\\\", \\\"{x:571,y:643,t:1527020218126};\\\", \\\"{x:541,y:627,t:1527020218143};\\\", \\\"{x:532,y:622,t:1527020218158};\\\", \\\"{x:531,y:621,t:1527020218175};\\\", \\\"{x:531,y:619,t:1527020218193};\\\", \\\"{x:531,y:616,t:1527020218208};\\\", \\\"{x:531,y:607,t:1527020218225};\\\", \\\"{x:531,y:586,t:1527020218242};\\\", \\\"{x:532,y:570,t:1527020218258};\\\", \\\"{x:532,y:559,t:1527020218275};\\\", \\\"{x:532,y:551,t:1527020218292};\\\", \\\"{x:534,y:548,t:1527020218308};\\\", \\\"{x:534,y:547,t:1527020218325};\\\", \\\"{x:535,y:546,t:1527020218341};\\\", \\\"{x:537,y:545,t:1527020218359};\\\", \\\"{x:538,y:545,t:1527020218375};\\\", \\\"{x:540,y:543,t:1527020218394};\\\", \\\"{x:542,y:543,t:1527020218418};\\\", \\\"{x:543,y:543,t:1527020218425};\\\", \\\"{x:543,y:542,t:1527020218442};\\\", \\\"{x:539,y:543,t:1527020218522};\\\", \\\"{x:531,y:546,t:1527020218530};\\\", \\\"{x:523,y:549,t:1527020218542};\\\", \\\"{x:501,y:559,t:1527020218560};\\\", \\\"{x:459,y:571,t:1527020218576};\\\", \\\"{x:415,y:583,t:1527020218591};\\\", \\\"{x:392,y:587,t:1527020218608};\\\", \\\"{x:379,y:587,t:1527020218626};\\\", \\\"{x:378,y:587,t:1527020218641};\\\", \\\"{x:376,y:587,t:1527020218786};\\\", \\\"{x:373,y:588,t:1527020218794};\\\", \\\"{x:368,y:589,t:1527020218808};\\\", \\\"{x:342,y:598,t:1527020218826};\\\", \\\"{x:324,y:601,t:1527020218842};\\\", \\\"{x:307,y:604,t:1527020218858};\\\", \\\"{x:289,y:610,t:1527020218875};\\\", \\\"{x:271,y:611,t:1527020218892};\\\", \\\"{x:259,y:614,t:1527020218908};\\\", \\\"{x:251,y:614,t:1527020218925};\\\", \\\"{x:244,y:615,t:1527020218942};\\\", \\\"{x:243,y:615,t:1527020218958};\\\", \\\"{x:242,y:615,t:1527020218975};\\\", \\\"{x:240,y:616,t:1527020218993};\\\", \\\"{x:240,y:617,t:1527020219010};\\\", \\\"{x:238,y:617,t:1527020219025};\\\", \\\"{x:238,y:618,t:1527020219049};\\\", \\\"{x:238,y:617,t:1527020219098};\\\", \\\"{x:241,y:616,t:1527020219108};\\\", \\\"{x:252,y:612,t:1527020219126};\\\", \\\"{x:269,y:609,t:1527020219143};\\\", \\\"{x:288,y:608,t:1527020219160};\\\", \\\"{x:306,y:608,t:1527020219175};\\\", \\\"{x:331,y:608,t:1527020219192};\\\", \\\"{x:367,y:608,t:1527020219208};\\\", \\\"{x:419,y:608,t:1527020219225};\\\", \\\"{x:455,y:608,t:1527020219243};\\\", \\\"{x:485,y:608,t:1527020219258};\\\", \\\"{x:507,y:608,t:1527020219277};\\\", \\\"{x:531,y:607,t:1527020219292};\\\", \\\"{x:552,y:603,t:1527020219309};\\\", \\\"{x:569,y:601,t:1527020219325};\\\", \\\"{x:585,y:600,t:1527020219343};\\\", \\\"{x:602,y:597,t:1527020219359};\\\", \\\"{x:619,y:595,t:1527020219376};\\\", \\\"{x:637,y:592,t:1527020219393};\\\", \\\"{x:664,y:588,t:1527020219409};\\\", \\\"{x:676,y:587,t:1527020219426};\\\", \\\"{x:688,y:585,t:1527020219442};\\\", \\\"{x:695,y:584,t:1527020219460};\\\", \\\"{x:697,y:583,t:1527020219475};\\\", \\\"{x:692,y:582,t:1527020219610};\\\", \\\"{x:679,y:578,t:1527020219626};\\\", \\\"{x:672,y:577,t:1527020219643};\\\", \\\"{x:668,y:577,t:1527020219660};\\\", \\\"{x:665,y:577,t:1527020219677};\\\", \\\"{x:664,y:577,t:1527020219693};\\\", \\\"{x:663,y:577,t:1527020219710};\\\", \\\"{x:660,y:577,t:1527020219898};\\\", \\\"{x:648,y:585,t:1527020219910};\\\", \\\"{x:628,y:612,t:1527020219928};\\\", \\\"{x:611,y:635,t:1527020219944};\\\", \\\"{x:599,y:647,t:1527020219959};\\\", \\\"{x:582,y:657,t:1527020219976};\\\", \\\"{x:571,y:664,t:1527020219992};\\\", \\\"{x:561,y:671,t:1527020220008};\\\", \\\"{x:556,y:676,t:1527020220026};\\\", \\\"{x:556,y:677,t:1527020220050};\\\", \\\"{x:555,y:679,t:1527020220065};\\\", \\\"{x:554,y:680,t:1527020220106};\\\", \\\"{x:553,y:682,t:1527020220154};\\\", \\\"{x:552,y:685,t:1527020220162};\\\", \\\"{x:552,y:686,t:1527020220176};\\\", \\\"{x:552,y:691,t:1527020220193};\\\", \\\"{x:549,y:697,t:1527020220208};\\\", \\\"{x:548,y:700,t:1527020220226};\\\", \\\"{x:554,y:694,t:1527020220258};\\\", \\\"{x:565,y:672,t:1527020220276};\\\", \\\"{x:577,y:649,t:1527020220293};\\\", \\\"{x:587,y:632,t:1527020220309};\\\", \\\"{x:596,y:620,t:1527020220327};\\\", \\\"{x:602,y:613,t:1527020220343};\\\", \\\"{x:604,y:610,t:1527020220360};\\\", \\\"{x:606,y:608,t:1527020220377};\\\", \\\"{x:608,y:605,t:1527020220393};\\\", \\\"{x:609,y:603,t:1527020220410};\\\", \\\"{x:609,y:601,t:1527020220427};\\\", \\\"{x:609,y:600,t:1527020220444};\\\", \\\"{x:610,y:597,t:1527020220461};\\\", \\\"{x:610,y:594,t:1527020220477};\\\", \\\"{x:610,y:590,t:1527020220494};\\\", \\\"{x:610,y:584,t:1527020220510};\\\", \\\"{x:610,y:577,t:1527020220526};\\\", \\\"{x:610,y:572,t:1527020220543};\\\", \\\"{x:612,y:571,t:1527020220560};\\\", \\\"{x:607,y:578,t:1527020220746};\\\", \\\"{x:599,y:597,t:1527020220761};\\\", \\\"{x:583,y:636,t:1527020220776};\\\", \\\"{x:566,y:671,t:1527020220794};\\\", \\\"{x:559,y:683,t:1527020220811};\\\", \\\"{x:556,y:688,t:1527020220826};\\\", \\\"{x:553,y:694,t:1527020220844};\\\", \\\"{x:549,y:702,t:1527020220861};\\\", \\\"{x:546,y:710,t:1527020220876};\\\", \\\"{x:544,y:717,t:1527020220894};\\\", \\\"{x:544,y:720,t:1527020220912};\\\", \\\"{x:542,y:722,t:1527020220927};\\\", \\\"{x:542,y:723,t:1527020220943};\\\", \\\"{x:542,y:724,t:1527020221034};\\\", \\\"{x:541,y:727,t:1527020221044};\\\", \\\"{x:539,y:731,t:1527020221061};\\\", \\\"{x:538,y:735,t:1527020221078};\\\", \\\"{x:538,y:737,t:1527020221094};\\\", \\\"{x:538,y:738,t:1527020221114};\\\", \\\"{x:537,y:739,t:1527020222235};\\\" ] }, { \\\"rt\\\": 24368, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 870051, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X -C -C -C -O -O -C -02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:734,t:1527020224595};\\\", \\\"{x:534,y:730,t:1527020224602};\\\", \\\"{x:532,y:724,t:1527020224614};\\\", \\\"{x:531,y:716,t:1527020224631};\\\", \\\"{x:528,y:707,t:1527020224646};\\\", \\\"{x:526,y:703,t:1527020224663};\\\", \\\"{x:525,y:699,t:1527020224680};\\\", \\\"{x:525,y:695,t:1527020224696};\\\", \\\"{x:525,y:691,t:1527020224713};\\\", \\\"{x:525,y:689,t:1527020224730};\\\", \\\"{x:524,y:688,t:1527020224746};\\\", \\\"{x:524,y:686,t:1527020224764};\\\", \\\"{x:524,y:685,t:1527020224802};\\\", \\\"{x:524,y:683,t:1527020224842};\\\", \\\"{x:524,y:682,t:1527020224866};\\\", \\\"{x:524,y:680,t:1527020224882};\\\", \\\"{x:524,y:679,t:1527020224898};\\\", \\\"{x:523,y:677,t:1527020224914};\\\", \\\"{x:522,y:672,t:1527020224930};\\\", \\\"{x:522,y:669,t:1527020224947};\\\", \\\"{x:522,y:666,t:1527020224964};\\\", \\\"{x:521,y:663,t:1527020224981};\\\", \\\"{x:520,y:661,t:1527020224997};\\\", \\\"{x:520,y:660,t:1527020225014};\\\", \\\"{x:519,y:659,t:1527020225031};\\\", \\\"{x:519,y:658,t:1527020225074};\\\", \\\"{x:519,y:657,t:1527020225091};\\\", \\\"{x:518,y:655,t:1527020225098};\\\", \\\"{x:518,y:654,t:1527020225147};\\\", \\\"{x:518,y:653,t:1527020225194};\\\", \\\"{x:518,y:652,t:1527020225209};\\\", \\\"{x:517,y:651,t:1527020225234};\\\", \\\"{x:516,y:651,t:1527020225248};\\\", \\\"{x:516,y:650,t:1527020226659};\\\", \\\"{x:516,y:649,t:1527020226666};\\\", \\\"{x:528,y:648,t:1527020227115};\\\", \\\"{x:576,y:655,t:1527020227122};\\\", \\\"{x:641,y:681,t:1527020227133};\\\", \\\"{x:806,y:746,t:1527020227151};\\\", \\\"{x:1006,y:823,t:1527020227167};\\\", \\\"{x:1224,y:886,t:1527020227184};\\\", \\\"{x:1406,y:932,t:1527020227200};\\\", \\\"{x:1527,y:965,t:1527020227217};\\\", \\\"{x:1576,y:973,t:1527020227233};\\\", \\\"{x:1582,y:975,t:1527020227251};\\\", \\\"{x:1583,y:975,t:1527020227346};\\\", \\\"{x:1583,y:973,t:1527020227355};\\\", \\\"{x:1583,y:972,t:1527020227367};\\\", \\\"{x:1583,y:968,t:1527020227384};\\\", \\\"{x:1581,y:965,t:1527020227400};\\\", \\\"{x:1580,y:962,t:1527020227418};\\\", \\\"{x:1577,y:960,t:1527020227433};\\\", \\\"{x:1568,y:957,t:1527020227450};\\\", \\\"{x:1559,y:953,t:1527020227467};\\\", \\\"{x:1544,y:951,t:1527020227484};\\\", \\\"{x:1524,y:948,t:1527020227501};\\\", \\\"{x:1509,y:946,t:1527020227518};\\\", \\\"{x:1499,y:945,t:1527020227533};\\\", \\\"{x:1492,y:944,t:1527020227551};\\\", \\\"{x:1491,y:943,t:1527020227683};\\\", \\\"{x:1489,y:941,t:1527020227723};\\\", \\\"{x:1488,y:940,t:1527020227734};\\\", \\\"{x:1485,y:934,t:1527020227750};\\\", \\\"{x:1484,y:929,t:1527020227768};\\\", \\\"{x:1481,y:923,t:1527020227785};\\\", \\\"{x:1479,y:914,t:1527020227800};\\\", \\\"{x:1476,y:898,t:1527020227818};\\\", \\\"{x:1470,y:873,t:1527020227835};\\\", \\\"{x:1467,y:862,t:1527020227850};\\\", \\\"{x:1465,y:857,t:1527020227868};\\\", \\\"{x:1465,y:853,t:1527020227885};\\\", \\\"{x:1464,y:851,t:1527020227900};\\\", \\\"{x:1463,y:851,t:1527020227917};\\\", \\\"{x:1463,y:850,t:1527020227934};\\\", \\\"{x:1463,y:849,t:1527020227951};\\\", \\\"{x:1463,y:847,t:1527020227967};\\\", \\\"{x:1462,y:846,t:1527020227984};\\\", \\\"{x:1462,y:843,t:1527020228002};\\\", \\\"{x:1462,y:842,t:1527020228017};\\\", \\\"{x:1460,y:837,t:1527020228035};\\\", \\\"{x:1460,y:833,t:1527020228051};\\\", \\\"{x:1459,y:830,t:1527020228068};\\\", \\\"{x:1459,y:828,t:1527020228085};\\\", \\\"{x:1459,y:826,t:1527020228102};\\\", \\\"{x:1458,y:825,t:1527020228117};\\\", \\\"{x:1458,y:824,t:1527020228135};\\\", \\\"{x:1458,y:823,t:1527020228243};\\\", \\\"{x:1458,y:821,t:1527020228305};\\\", \\\"{x:1458,y:820,t:1527020228318};\\\", \\\"{x:1458,y:819,t:1527020228334};\\\", \\\"{x:1458,y:816,t:1527020228351};\\\", \\\"{x:1458,y:813,t:1527020228368};\\\", \\\"{x:1458,y:810,t:1527020228384};\\\", \\\"{x:1458,y:806,t:1527020228401};\\\", \\\"{x:1458,y:800,t:1527020228417};\\\", \\\"{x:1458,y:796,t:1527020228434};\\\", \\\"{x:1457,y:793,t:1527020228451};\\\", \\\"{x:1457,y:789,t:1527020228468};\\\", \\\"{x:1457,y:786,t:1527020228484};\\\", \\\"{x:1457,y:784,t:1527020228502};\\\", \\\"{x:1457,y:782,t:1527020228518};\\\", \\\"{x:1457,y:780,t:1527020228535};\\\", \\\"{x:1457,y:779,t:1527020228552};\\\", \\\"{x:1457,y:777,t:1527020228568};\\\", \\\"{x:1457,y:776,t:1527020228586};\\\", \\\"{x:1457,y:774,t:1527020228602};\\\", \\\"{x:1457,y:770,t:1527020228618};\\\", \\\"{x:1457,y:766,t:1527020228636};\\\", \\\"{x:1457,y:763,t:1527020228652};\\\", \\\"{x:1457,y:760,t:1527020228669};\\\", \\\"{x:1457,y:759,t:1527020228686};\\\", \\\"{x:1457,y:756,t:1527020228701};\\\", \\\"{x:1457,y:748,t:1527020228719};\\\", \\\"{x:1457,y:744,t:1527020228735};\\\", \\\"{x:1457,y:737,t:1527020228752};\\\", \\\"{x:1457,y:732,t:1527020228769};\\\", \\\"{x:1458,y:727,t:1527020228785};\\\", \\\"{x:1458,y:724,t:1527020228802};\\\", \\\"{x:1460,y:720,t:1527020228818};\\\", \\\"{x:1460,y:718,t:1527020228835};\\\", \\\"{x:1460,y:715,t:1527020228852};\\\", \\\"{x:1461,y:714,t:1527020228868};\\\", \\\"{x:1462,y:711,t:1527020228886};\\\", \\\"{x:1463,y:706,t:1527020228902};\\\", \\\"{x:1465,y:703,t:1527020228918};\\\", \\\"{x:1465,y:701,t:1527020228936};\\\", \\\"{x:1465,y:699,t:1527020228952};\\\", \\\"{x:1468,y:697,t:1527020228969};\\\", \\\"{x:1468,y:696,t:1527020228986};\\\", \\\"{x:1467,y:697,t:1527020229075};\\\", \\\"{x:1467,y:703,t:1527020229086};\\\", \\\"{x:1463,y:720,t:1527020229102};\\\", \\\"{x:1458,y:746,t:1527020229118};\\\", \\\"{x:1454,y:779,t:1527020229135};\\\", \\\"{x:1450,y:820,t:1527020229152};\\\", \\\"{x:1450,y:847,t:1527020229168};\\\", \\\"{x:1450,y:862,t:1527020229186};\\\", \\\"{x:1451,y:882,t:1527020229202};\\\", \\\"{x:1451,y:890,t:1527020229219};\\\", \\\"{x:1452,y:899,t:1527020229235};\\\", \\\"{x:1455,y:909,t:1527020229252};\\\", \\\"{x:1456,y:922,t:1527020229269};\\\", \\\"{x:1459,y:931,t:1527020229285};\\\", \\\"{x:1460,y:935,t:1527020229302};\\\", \\\"{x:1462,y:938,t:1527020229320};\\\", \\\"{x:1463,y:938,t:1527020229335};\\\", \\\"{x:1464,y:940,t:1527020229353};\\\", \\\"{x:1466,y:943,t:1527020229370};\\\", \\\"{x:1466,y:946,t:1527020229386};\\\", \\\"{x:1466,y:948,t:1527020229402};\\\", \\\"{x:1467,y:951,t:1527020229419};\\\", \\\"{x:1468,y:955,t:1527020229435};\\\", \\\"{x:1469,y:957,t:1527020229452};\\\", \\\"{x:1469,y:958,t:1527020229470};\\\", \\\"{x:1470,y:958,t:1527020229485};\\\", \\\"{x:1472,y:957,t:1527020229571};\\\", \\\"{x:1474,y:945,t:1527020229587};\\\", \\\"{x:1479,y:925,t:1527020229602};\\\", \\\"{x:1481,y:907,t:1527020229620};\\\", \\\"{x:1481,y:892,t:1527020229637};\\\", \\\"{x:1481,y:877,t:1527020229652};\\\", \\\"{x:1481,y:870,t:1527020229670};\\\", \\\"{x:1481,y:862,t:1527020229687};\\\", \\\"{x:1481,y:856,t:1527020229702};\\\", \\\"{x:1481,y:850,t:1527020229720};\\\", \\\"{x:1481,y:846,t:1527020229737};\\\", \\\"{x:1481,y:843,t:1527020229753};\\\", \\\"{x:1481,y:842,t:1527020229770};\\\", \\\"{x:1481,y:837,t:1527020229786};\\\", \\\"{x:1481,y:836,t:1527020229803};\\\", \\\"{x:1479,y:833,t:1527020229822};\\\", \\\"{x:1479,y:831,t:1527020229853};\\\", \\\"{x:1479,y:830,t:1527020229869};\\\", \\\"{x:1478,y:828,t:1527020229885};\\\", \\\"{x:1478,y:827,t:1527020229903};\\\", \\\"{x:1478,y:826,t:1527020229921};\\\", \\\"{x:1478,y:825,t:1527020229936};\\\", \\\"{x:1477,y:823,t:1527020229953};\\\", \\\"{x:1476,y:821,t:1527020229969};\\\", \\\"{x:1476,y:820,t:1527020229986};\\\", \\\"{x:1476,y:818,t:1527020230003};\\\", \\\"{x:1476,y:816,t:1527020230019};\\\", \\\"{x:1475,y:811,t:1527020230036};\\\", \\\"{x:1475,y:808,t:1527020230054};\\\", \\\"{x:1474,y:804,t:1527020230069};\\\", \\\"{x:1473,y:802,t:1527020230087};\\\", \\\"{x:1473,y:797,t:1527020230103};\\\", \\\"{x:1472,y:792,t:1527020230120};\\\", \\\"{x:1472,y:788,t:1527020230136};\\\", \\\"{x:1472,y:782,t:1527020230153};\\\", \\\"{x:1472,y:777,t:1527020230170};\\\", \\\"{x:1472,y:771,t:1527020230187};\\\", \\\"{x:1472,y:768,t:1527020230204};\\\", \\\"{x:1472,y:764,t:1527020230220};\\\", \\\"{x:1472,y:758,t:1527020230236};\\\", \\\"{x:1472,y:749,t:1527020230253};\\\", \\\"{x:1472,y:742,t:1527020230271};\\\", \\\"{x:1472,y:735,t:1527020230286};\\\", \\\"{x:1472,y:732,t:1527020230303};\\\", \\\"{x:1472,y:728,t:1527020230321};\\\", \\\"{x:1472,y:723,t:1527020230337};\\\", \\\"{x:1472,y:720,t:1527020230354};\\\", \\\"{x:1472,y:714,t:1527020230371};\\\", \\\"{x:1472,y:711,t:1527020230387};\\\", \\\"{x:1472,y:707,t:1527020230404};\\\", \\\"{x:1472,y:704,t:1527020230421};\\\", \\\"{x:1472,y:700,t:1527020230437};\\\", \\\"{x:1472,y:699,t:1527020230453};\\\", \\\"{x:1472,y:696,t:1527020230470};\\\", \\\"{x:1472,y:694,t:1527020230488};\\\", \\\"{x:1472,y:691,t:1527020230503};\\\", \\\"{x:1472,y:690,t:1527020230521};\\\", \\\"{x:1472,y:688,t:1527020230538};\\\", \\\"{x:1472,y:687,t:1527020230553};\\\", \\\"{x:1472,y:684,t:1527020230570};\\\", \\\"{x:1471,y:683,t:1527020230587};\\\", \\\"{x:1471,y:682,t:1527020230618};\\\", \\\"{x:1471,y:681,t:1527020230898};\\\", \\\"{x:1471,y:680,t:1527020230906};\\\", \\\"{x:1471,y:679,t:1527020230921};\\\", \\\"{x:1469,y:675,t:1527020230937};\\\", \\\"{x:1467,y:671,t:1527020230955};\\\", \\\"{x:1466,y:670,t:1527020230970};\\\", \\\"{x:1465,y:667,t:1527020230987};\\\", \\\"{x:1463,y:663,t:1527020231005};\\\", \\\"{x:1461,y:659,t:1527020231021};\\\", \\\"{x:1460,y:655,t:1527020231038};\\\", \\\"{x:1458,y:650,t:1527020231054};\\\", \\\"{x:1456,y:645,t:1527020231072};\\\", \\\"{x:1454,y:642,t:1527020231088};\\\", \\\"{x:1453,y:638,t:1527020231105};\\\", \\\"{x:1451,y:635,t:1527020231121};\\\", \\\"{x:1449,y:631,t:1527020231137};\\\", \\\"{x:1446,y:625,t:1527020231154};\\\", \\\"{x:1445,y:621,t:1527020231171};\\\", \\\"{x:1444,y:617,t:1527020231187};\\\", \\\"{x:1443,y:613,t:1527020231204};\\\", \\\"{x:1443,y:612,t:1527020231221};\\\", \\\"{x:1443,y:610,t:1527020231237};\\\", \\\"{x:1442,y:609,t:1527020231254};\\\", \\\"{x:1441,y:608,t:1527020231273};\\\", \\\"{x:1441,y:607,t:1527020231287};\\\", \\\"{x:1441,y:606,t:1527020231314};\\\", \\\"{x:1440,y:606,t:1527020231321};\\\", \\\"{x:1440,y:604,t:1527020231355};\\\", \\\"{x:1440,y:607,t:1527020231498};\\\", \\\"{x:1440,y:610,t:1527020231506};\\\", \\\"{x:1441,y:616,t:1527020231521};\\\", \\\"{x:1447,y:631,t:1527020231538};\\\", \\\"{x:1452,y:644,t:1527020231556};\\\", \\\"{x:1455,y:652,t:1527020231572};\\\", \\\"{x:1460,y:661,t:1527020231589};\\\", \\\"{x:1465,y:673,t:1527020231604};\\\", \\\"{x:1469,y:682,t:1527020231621};\\\", \\\"{x:1474,y:694,t:1527020231639};\\\", \\\"{x:1479,y:703,t:1527020231655};\\\", \\\"{x:1485,y:712,t:1527020231671};\\\", \\\"{x:1491,y:721,t:1527020231688};\\\", \\\"{x:1495,y:728,t:1527020231706};\\\", \\\"{x:1499,y:734,t:1527020231722};\\\", \\\"{x:1505,y:744,t:1527020231739};\\\", \\\"{x:1509,y:751,t:1527020231756};\\\", \\\"{x:1511,y:755,t:1527020231772};\\\", \\\"{x:1514,y:761,t:1527020231788};\\\", \\\"{x:1515,y:765,t:1527020231805};\\\", \\\"{x:1519,y:770,t:1527020231821};\\\", \\\"{x:1519,y:772,t:1527020231838};\\\", \\\"{x:1521,y:774,t:1527020231855};\\\", \\\"{x:1523,y:781,t:1527020236018};\\\", \\\"{x:1526,y:794,t:1527020236026};\\\", \\\"{x:1534,y:821,t:1527020236042};\\\", \\\"{x:1540,y:839,t:1527020236060};\\\", \\\"{x:1544,y:857,t:1527020236077};\\\", \\\"{x:1547,y:872,t:1527020236093};\\\", \\\"{x:1551,y:888,t:1527020236110};\\\", \\\"{x:1551,y:899,t:1527020236127};\\\", \\\"{x:1553,y:911,t:1527020236144};\\\", \\\"{x:1553,y:923,t:1527020236159};\\\", \\\"{x:1553,y:932,t:1527020236177};\\\", \\\"{x:1553,y:939,t:1527020236194};\\\", \\\"{x:1553,y:942,t:1527020236210};\\\", \\\"{x:1553,y:943,t:1527020236227};\\\", \\\"{x:1553,y:945,t:1527020236244};\\\", \\\"{x:1553,y:946,t:1527020236260};\\\", \\\"{x:1553,y:947,t:1527020236276};\\\", \\\"{x:1553,y:949,t:1527020236294};\\\", \\\"{x:1553,y:953,t:1527020236310};\\\", \\\"{x:1553,y:955,t:1527020236327};\\\", \\\"{x:1553,y:956,t:1527020236344};\\\", \\\"{x:1553,y:957,t:1527020236360};\\\", \\\"{x:1554,y:958,t:1527020237586};\\\", \\\"{x:1558,y:958,t:1527020237594};\\\", \\\"{x:1565,y:954,t:1527020237611};\\\", \\\"{x:1568,y:954,t:1527020237628};\\\", \\\"{x:1569,y:953,t:1527020237645};\\\", \\\"{x:1570,y:953,t:1527020237667};\\\", \\\"{x:1570,y:952,t:1527020237679};\\\", \\\"{x:1571,y:952,t:1527020237730};\\\", \\\"{x:1574,y:952,t:1527020237745};\\\", \\\"{x:1580,y:952,t:1527020237762};\\\", \\\"{x:1585,y:952,t:1527020237779};\\\", \\\"{x:1587,y:952,t:1527020237795};\\\", \\\"{x:1592,y:952,t:1527020237812};\\\", \\\"{x:1594,y:952,t:1527020237829};\\\", \\\"{x:1596,y:952,t:1527020237844};\\\", \\\"{x:1598,y:952,t:1527020237862};\\\", \\\"{x:1600,y:952,t:1527020237878};\\\", \\\"{x:1601,y:952,t:1527020237895};\\\", \\\"{x:1605,y:952,t:1527020237911};\\\", \\\"{x:1609,y:952,t:1527020237929};\\\", \\\"{x:1612,y:952,t:1527020237946};\\\", \\\"{x:1613,y:952,t:1527020237962};\\\", \\\"{x:1613,y:950,t:1527020238163};\\\", \\\"{x:1613,y:946,t:1527020238179};\\\", \\\"{x:1612,y:943,t:1527020238196};\\\", \\\"{x:1612,y:940,t:1527020238212};\\\", \\\"{x:1612,y:938,t:1527020238234};\\\", \\\"{x:1611,y:937,t:1527020238246};\\\", \\\"{x:1609,y:935,t:1527020238262};\\\", \\\"{x:1607,y:930,t:1527020238279};\\\", \\\"{x:1605,y:929,t:1527020238295};\\\", \\\"{x:1602,y:925,t:1527020238312};\\\", \\\"{x:1599,y:921,t:1527020238328};\\\", \\\"{x:1594,y:917,t:1527020238345};\\\", \\\"{x:1591,y:914,t:1527020238362};\\\", \\\"{x:1588,y:911,t:1527020238378};\\\", \\\"{x:1585,y:909,t:1527020238395};\\\", \\\"{x:1582,y:906,t:1527020238413};\\\", \\\"{x:1578,y:903,t:1527020238428};\\\", \\\"{x:1572,y:899,t:1527020238446};\\\", \\\"{x:1570,y:897,t:1527020238462};\\\", \\\"{x:1569,y:897,t:1527020238479};\\\", \\\"{x:1568,y:896,t:1527020238496};\\\", \\\"{x:1566,y:894,t:1527020238513};\\\", \\\"{x:1564,y:891,t:1527020238529};\\\", \\\"{x:1558,y:885,t:1527020238546};\\\", \\\"{x:1554,y:880,t:1527020238563};\\\", \\\"{x:1550,y:875,t:1527020238580};\\\", \\\"{x:1545,y:865,t:1527020238596};\\\", \\\"{x:1533,y:842,t:1527020238613};\\\", \\\"{x:1522,y:821,t:1527020238630};\\\", \\\"{x:1512,y:805,t:1527020238646};\\\", \\\"{x:1505,y:790,t:1527020238664};\\\", \\\"{x:1499,y:778,t:1527020238680};\\\", \\\"{x:1492,y:768,t:1527020238696};\\\", \\\"{x:1485,y:755,t:1527020238713};\\\", \\\"{x:1478,y:743,t:1527020238730};\\\", \\\"{x:1473,y:734,t:1527020238746};\\\", \\\"{x:1469,y:729,t:1527020238763};\\\", \\\"{x:1468,y:721,t:1527020238780};\\\", \\\"{x:1464,y:713,t:1527020238796};\\\", \\\"{x:1461,y:706,t:1527020238813};\\\", \\\"{x:1458,y:699,t:1527020238830};\\\", \\\"{x:1455,y:692,t:1527020238846};\\\", \\\"{x:1454,y:686,t:1527020238863};\\\", \\\"{x:1453,y:683,t:1527020238880};\\\", \\\"{x:1452,y:677,t:1527020238897};\\\", \\\"{x:1450,y:672,t:1527020238914};\\\", \\\"{x:1450,y:668,t:1527020238930};\\\", \\\"{x:1449,y:667,t:1527020238947};\\\", \\\"{x:1449,y:666,t:1527020238963};\\\", \\\"{x:1448,y:663,t:1527020238980};\\\", \\\"{x:1448,y:661,t:1527020238997};\\\", \\\"{x:1448,y:659,t:1527020239012};\\\", \\\"{x:1448,y:658,t:1527020239030};\\\", \\\"{x:1447,y:658,t:1527020239047};\\\", \\\"{x:1447,y:657,t:1527020239114};\\\", \\\"{x:1447,y:656,t:1527020239130};\\\", \\\"{x:1446,y:653,t:1527020239146};\\\", \\\"{x:1444,y:648,t:1527020239164};\\\", \\\"{x:1444,y:643,t:1527020239180};\\\", \\\"{x:1444,y:638,t:1527020239197};\\\", \\\"{x:1444,y:635,t:1527020239213};\\\", \\\"{x:1444,y:633,t:1527020239230};\\\", \\\"{x:1444,y:632,t:1527020239263};\\\", \\\"{x:1444,y:637,t:1527020239795};\\\", \\\"{x:1444,y:648,t:1527020239802};\\\", \\\"{x:1444,y:660,t:1527020239814};\\\", \\\"{x:1444,y:679,t:1527020239830};\\\", \\\"{x:1444,y:697,t:1527020239847};\\\", \\\"{x:1444,y:710,t:1527020239864};\\\", \\\"{x:1444,y:724,t:1527020239880};\\\", \\\"{x:1447,y:749,t:1527020239897};\\\", \\\"{x:1448,y:767,t:1527020239914};\\\", \\\"{x:1449,y:788,t:1527020239931};\\\", \\\"{x:1451,y:806,t:1527020239947};\\\", \\\"{x:1451,y:824,t:1527020239964};\\\", \\\"{x:1453,y:835,t:1527020239980};\\\", \\\"{x:1454,y:844,t:1527020239998};\\\", \\\"{x:1454,y:854,t:1527020240014};\\\", \\\"{x:1454,y:865,t:1527020240031};\\\", \\\"{x:1454,y:876,t:1527020240048};\\\", \\\"{x:1456,y:889,t:1527020240063};\\\", \\\"{x:1457,y:899,t:1527020240081};\\\", \\\"{x:1459,y:910,t:1527020240098};\\\", \\\"{x:1460,y:914,t:1527020240114};\\\", \\\"{x:1460,y:918,t:1527020240130};\\\", \\\"{x:1461,y:921,t:1527020240148};\\\", \\\"{x:1461,y:924,t:1527020240164};\\\", \\\"{x:1462,y:925,t:1527020240180};\\\", \\\"{x:1462,y:926,t:1527020240198};\\\", \\\"{x:1462,y:928,t:1527020240218};\\\", \\\"{x:1462,y:929,t:1527020240234};\\\", \\\"{x:1464,y:930,t:1527020240248};\\\", \\\"{x:1464,y:931,t:1527020240265};\\\", \\\"{x:1465,y:933,t:1527020240282};\\\", \\\"{x:1466,y:935,t:1527020240298};\\\", \\\"{x:1467,y:936,t:1527020240315};\\\", \\\"{x:1469,y:938,t:1527020240331};\\\", \\\"{x:1472,y:941,t:1527020240348};\\\", \\\"{x:1473,y:947,t:1527020240365};\\\", \\\"{x:1479,y:954,t:1527020240380};\\\", \\\"{x:1485,y:965,t:1527020240398};\\\", \\\"{x:1489,y:973,t:1527020240415};\\\", \\\"{x:1494,y:980,t:1527020240431};\\\", \\\"{x:1495,y:983,t:1527020240448};\\\", \\\"{x:1496,y:986,t:1527020240466};\\\", \\\"{x:1497,y:987,t:1527020240482};\\\", \\\"{x:1497,y:986,t:1527020240602};\\\", \\\"{x:1498,y:977,t:1527020240615};\\\", \\\"{x:1502,y:944,t:1527020240633};\\\", \\\"{x:1504,y:913,t:1527020240648};\\\", \\\"{x:1504,y:882,t:1527020240665};\\\", \\\"{x:1504,y:826,t:1527020240682};\\\", \\\"{x:1504,y:803,t:1527020240698};\\\", \\\"{x:1504,y:785,t:1527020240715};\\\", \\\"{x:1504,y:773,t:1527020240732};\\\", \\\"{x:1504,y:762,t:1527020240748};\\\", \\\"{x:1504,y:750,t:1527020240765};\\\", \\\"{x:1504,y:744,t:1527020240782};\\\", \\\"{x:1504,y:738,t:1527020240798};\\\", \\\"{x:1504,y:734,t:1527020240815};\\\", \\\"{x:1504,y:733,t:1527020240831};\\\", \\\"{x:1504,y:732,t:1527020240850};\\\", \\\"{x:1504,y:730,t:1527020240914};\\\", \\\"{x:1504,y:724,t:1527020240932};\\\", \\\"{x:1503,y:720,t:1527020240949};\\\", \\\"{x:1502,y:715,t:1527020240965};\\\", \\\"{x:1499,y:711,t:1527020240982};\\\", \\\"{x:1497,y:708,t:1527020240999};\\\", \\\"{x:1495,y:704,t:1527020241014};\\\", \\\"{x:1495,y:702,t:1527020241034};\\\", \\\"{x:1493,y:700,t:1527020241049};\\\", \\\"{x:1492,y:698,t:1527020241065};\\\", \\\"{x:1491,y:695,t:1527020241082};\\\", \\\"{x:1490,y:693,t:1527020241099};\\\", \\\"{x:1489,y:692,t:1527020241116};\\\", \\\"{x:1489,y:691,t:1527020241132};\\\", \\\"{x:1488,y:691,t:1527020241162};\\\", \\\"{x:1488,y:690,t:1527020241818};\\\", \\\"{x:1483,y:684,t:1527020241833};\\\", \\\"{x:1474,y:674,t:1527020241850};\\\", \\\"{x:1466,y:667,t:1527020241867};\\\", \\\"{x:1457,y:659,t:1527020241883};\\\", \\\"{x:1448,y:652,t:1527020241900};\\\", \\\"{x:1441,y:646,t:1527020241916};\\\", \\\"{x:1438,y:643,t:1527020241933};\\\", \\\"{x:1434,y:638,t:1527020241950};\\\", \\\"{x:1428,y:631,t:1527020241966};\\\", \\\"{x:1425,y:626,t:1527020241983};\\\", \\\"{x:1419,y:620,t:1527020242000};\\\", \\\"{x:1415,y:616,t:1527020242017};\\\", \\\"{x:1413,y:614,t:1527020242033};\\\", \\\"{x:1411,y:612,t:1527020242050};\\\", \\\"{x:1409,y:610,t:1527020242066};\\\", \\\"{x:1408,y:609,t:1527020242082};\\\", \\\"{x:1406,y:607,t:1527020242100};\\\", \\\"{x:1405,y:607,t:1527020242130};\\\", \\\"{x:1405,y:606,t:1527020242186};\\\", \\\"{x:1404,y:605,t:1527020242226};\\\", \\\"{x:1393,y:605,t:1527020243299};\\\", \\\"{x:1372,y:605,t:1527020243305};\\\", \\\"{x:1338,y:603,t:1527020243317};\\\", \\\"{x:1231,y:596,t:1527020243334};\\\", \\\"{x:1088,y:581,t:1527020243350};\\\", \\\"{x:936,y:559,t:1527020243368};\\\", \\\"{x:770,y:539,t:1527020243384};\\\", \\\"{x:613,y:517,t:1527020243401};\\\", \\\"{x:493,y:496,t:1527020243411};\\\", \\\"{x:402,y:485,t:1527020243429};\\\", \\\"{x:357,y:481,t:1527020243446};\\\", \\\"{x:344,y:480,t:1527020243461};\\\", \\\"{x:341,y:480,t:1527020243478};\\\", \\\"{x:341,y:481,t:1527020243593};\\\", \\\"{x:344,y:483,t:1527020243602};\\\", \\\"{x:349,y:485,t:1527020243612};\\\", \\\"{x:363,y:493,t:1527020243629};\\\", \\\"{x:380,y:505,t:1527020243647};\\\", \\\"{x:398,y:524,t:1527020243662};\\\", \\\"{x:413,y:539,t:1527020243679};\\\", \\\"{x:421,y:550,t:1527020243695};\\\", \\\"{x:431,y:565,t:1527020243712};\\\", \\\"{x:444,y:576,t:1527020243728};\\\", \\\"{x:482,y:589,t:1527020243746};\\\", \\\"{x:531,y:600,t:1527020243762};\\\", \\\"{x:580,y:604,t:1527020243778};\\\", \\\"{x:637,y:608,t:1527020243795};\\\", \\\"{x:699,y:609,t:1527020243812};\\\", \\\"{x:747,y:609,t:1527020243828};\\\", \\\"{x:770,y:609,t:1527020243845};\\\", \\\"{x:778,y:609,t:1527020243862};\\\", \\\"{x:779,y:609,t:1527020243878};\\\", \\\"{x:780,y:609,t:1527020243895};\\\", \\\"{x:782,y:609,t:1527020243938};\\\", \\\"{x:785,y:609,t:1527020243946};\\\", \\\"{x:787,y:610,t:1527020243963};\\\", \\\"{x:789,y:610,t:1527020243978};\\\", \\\"{x:789,y:611,t:1527020244010};\\\", \\\"{x:789,y:612,t:1527020244018};\\\", \\\"{x:789,y:616,t:1527020244029};\\\", \\\"{x:777,y:631,t:1527020244045};\\\", \\\"{x:758,y:642,t:1527020244062};\\\", \\\"{x:731,y:649,t:1527020244079};\\\", \\\"{x:694,y:649,t:1527020244096};\\\", \\\"{x:638,y:649,t:1527020244112};\\\", \\\"{x:552,y:649,t:1527020244128};\\\", \\\"{x:519,y:649,t:1527020244145};\\\", \\\"{x:509,y:649,t:1527020244162};\\\", \\\"{x:508,y:649,t:1527020244185};\\\", \\\"{x:509,y:646,t:1527020244195};\\\", \\\"{x:525,y:634,t:1527020244213};\\\", \\\"{x:551,y:621,t:1527020244230};\\\", \\\"{x:600,y:603,t:1527020244247};\\\", \\\"{x:686,y:580,t:1527020244262};\\\", \\\"{x:774,y:559,t:1527020244280};\\\", \\\"{x:838,y:550,t:1527020244296};\\\", \\\"{x:874,y:545,t:1527020244313};\\\", \\\"{x:887,y:544,t:1527020244329};\\\", \\\"{x:887,y:543,t:1527020244770};\\\", \\\"{x:886,y:543,t:1527020244780};\\\", \\\"{x:866,y:556,t:1527020244796};\\\", \\\"{x:832,y:583,t:1527020244813};\\\", \\\"{x:786,y:619,t:1527020244831};\\\", \\\"{x:749,y:646,t:1527020244847};\\\", \\\"{x:722,y:662,t:1527020244863};\\\", \\\"{x:702,y:672,t:1527020244880};\\\", \\\"{x:679,y:681,t:1527020244897};\\\", \\\"{x:642,y:697,t:1527020244914};\\\", \\\"{x:624,y:705,t:1527020244929};\\\", \\\"{x:621,y:707,t:1527020244947};\\\", \\\"{x:620,y:705,t:1527020244969};\\\", \\\"{x:625,y:699,t:1527020244980};\\\", \\\"{x:637,y:685,t:1527020244997};\\\", \\\"{x:652,y:671,t:1527020245013};\\\", \\\"{x:669,y:657,t:1527020245029};\\\", \\\"{x:694,y:642,t:1527020245048};\\\", \\\"{x:721,y:627,t:1527020245064};\\\", \\\"{x:747,y:616,t:1527020245080};\\\", \\\"{x:762,y:609,t:1527020245097};\\\", \\\"{x:778,y:599,t:1527020245113};\\\", \\\"{x:784,y:596,t:1527020245129};\\\", \\\"{x:787,y:594,t:1527020245146};\\\", \\\"{x:789,y:593,t:1527020245163};\\\", \\\"{x:795,y:590,t:1527020245179};\\\", \\\"{x:801,y:586,t:1527020245196};\\\", \\\"{x:805,y:584,t:1527020245214};\\\", \\\"{x:813,y:581,t:1527020245229};\\\", \\\"{x:819,y:578,t:1527020245246};\\\", \\\"{x:825,y:574,t:1527020245263};\\\", \\\"{x:827,y:573,t:1527020245279};\\\", \\\"{x:831,y:569,t:1527020245296};\\\", \\\"{x:833,y:567,t:1527020245313};\\\", \\\"{x:833,y:566,t:1527020245329};\\\", \\\"{x:829,y:567,t:1527020245770};\\\", \\\"{x:823,y:569,t:1527020245781};\\\", \\\"{x:816,y:573,t:1527020245797};\\\", \\\"{x:815,y:573,t:1527020245814};\\\", \\\"{x:816,y:573,t:1527020245890};\\\", \\\"{x:820,y:571,t:1527020245897};\\\", \\\"{x:828,y:567,t:1527020245915};\\\", \\\"{x:830,y:566,t:1527020245930};\\\", \\\"{x:834,y:564,t:1527020245947};\\\", \\\"{x:837,y:562,t:1527020245963};\\\", \\\"{x:839,y:560,t:1527020245981};\\\", \\\"{x:838,y:560,t:1527020246185};\\\", \\\"{x:833,y:560,t:1527020246197};\\\", \\\"{x:827,y:562,t:1527020246214};\\\", \\\"{x:817,y:570,t:1527020246231};\\\", \\\"{x:807,y:581,t:1527020246248};\\\", \\\"{x:796,y:595,t:1527020246265};\\\", \\\"{x:782,y:608,t:1527020246281};\\\", \\\"{x:747,y:638,t:1527020246297};\\\", \\\"{x:696,y:675,t:1527020246315};\\\", \\\"{x:642,y:707,t:1527020246331};\\\", \\\"{x:592,y:730,t:1527020246347};\\\", \\\"{x:563,y:740,t:1527020246365};\\\", \\\"{x:538,y:747,t:1527020246380};\\\", \\\"{x:519,y:752,t:1527020246398};\\\", \\\"{x:509,y:758,t:1527020246415};\\\", \\\"{x:498,y:763,t:1527020246431};\\\", \\\"{x:487,y:768,t:1527020246448};\\\", \\\"{x:482,y:771,t:1527020246466};\\\", \\\"{x:477,y:773,t:1527020246480};\\\", \\\"{x:472,y:774,t:1527020246498};\\\", \\\"{x:466,y:776,t:1527020246515};\\\", \\\"{x:454,y:781,t:1527020246530};\\\", \\\"{x:444,y:785,t:1527020246548};\\\", \\\"{x:441,y:786,t:1527020246564};\\\", \\\"{x:440,y:786,t:1527020246581};\\\", \\\"{x:444,y:781,t:1527020246624};\\\", \\\"{x:450,y:774,t:1527020246633};\\\", \\\"{x:453,y:769,t:1527020246647};\\\", \\\"{x:461,y:760,t:1527020246665};\\\", \\\"{x:469,y:754,t:1527020246680};\\\", \\\"{x:472,y:752,t:1527020246698};\\\" ] }, { \\\"rt\\\": 53098, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 924413, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Events that start at 12p.m are indicated by the black dots, which symbolize beginning time. Simply locate the black dot that is vertical to the time \\\\\\\"12 PM.\\\\\\\" \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6527, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 931946, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8076, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 941044, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 25368, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 967759, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"DM4T0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"DM4T0\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 189, dom: 818, initialDom: 883",
  "javascriptErrors": []
}