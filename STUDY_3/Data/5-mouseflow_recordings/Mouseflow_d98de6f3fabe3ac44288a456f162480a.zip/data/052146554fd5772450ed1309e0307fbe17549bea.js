var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052146554fd5772450ed1309e0307fbe17549bea"] = {
  "startTime": "2018-05-21T19:16:46.6439194Z",
  "websitePageUrl": "/16",
  "visitTime": 251467,
  "engagementTime": 165315,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "d98de6f3fabe3ac44288a456f162480a",
    "created": "2018-05-21T19:16:46.5888191+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=A9CZD",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "14411dec7fb7444d054bb7cdbd315532",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d98de6f3fabe3ac44288a456f162480a/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 247,
      "e": 247,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 645,
      "y": 775
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 521,
      "y": 665
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 47651,
      "y": 36396,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 482,
      "y": 625
    },
    {
      "t": 1652,
      "e": 1652,
      "ty": 6,
      "x": 478,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 477,
      "y": 589
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 42705,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 477,
      "y": 569
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 477,
      "y": 567
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 42705,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2278,
      "e": 2278,
      "ty": 3,
      "x": 477,
      "y": 567,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2279,
      "e": 2279,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2397,
      "e": 2397,
      "ty": 4,
      "x": 42705,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2398,
      "e": 2398,
      "ty": 5,
      "x": 477,
      "y": 567,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 478,
      "y": 567
    },
    {
      "t": 2619,
      "e": 2619,
      "ty": 7,
      "x": 508,
      "y": 626,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 678,
      "y": 862
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 1831,
      "y": 52470,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 712,
      "y": 877
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 713,
      "y": 876
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 1888,
      "y": 52399,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 10000,
      "e": 8001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 18099,
      "e": 8001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 18130,
      "e": 8032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18130,
      "e": 8032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18201,
      "e": 8103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "t"
    },
    {
      "t": 18201,
      "e": 8103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "t"
    },
    {
      "t": 18272,
      "e": 8174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18272,
      "e": 8174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18353,
      "e": 8255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tH"
    },
    {
      "t": 18386,
      "e": 8288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18386,
      "e": 8288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18457,
      "e": 8359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHE"
    },
    {
      "t": 18472,
      "e": 8374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18472,
      "e": 8374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18577,
      "e": 8479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18577,
      "e": 8479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18585,
      "e": 8487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHERE"
    },
    {
      "t": 18625,
      "e": 8527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18698,
      "e": 8600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18698,
      "e": 8600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18744,
      "e": 8646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18816,
      "e": 8718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18816,
      "e": 8718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18873,
      "e": 8775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 19002,
      "e": 8904,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHERE A"
    },
    {
      "t": 19049,
      "e": 8951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19105,
      "e": 9007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHERE "
    },
    {
      "t": 19193,
      "e": 9095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19256,
      "e": 9158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHERE"
    },
    {
      "t": 19344,
      "e": 9246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19409,
      "e": 9311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHER"
    },
    {
      "t": 19490,
      "e": 9392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19552,
      "e": 9454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHE"
    },
    {
      "t": 19641,
      "e": 9543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19689,
      "e": 9591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tH"
    },
    {
      "t": 19794,
      "e": 9696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19840,
      "e": 9742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "t"
    },
    {
      "t": 19920,
      "e": 9822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19976,
      "e": 9878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 20544,
      "e": 10446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 20601,
      "e": 10503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 20801,
      "e": 10703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20801,
      "e": 10703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20873,
      "e": 10775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "t"
    },
    {
      "t": 20937,
      "e": 10839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20937,
      "e": 10839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20993,
      "e": 10895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "th"
    },
    {
      "t": 21017,
      "e": 10919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21017,
      "e": 10919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21089,
      "e": 10991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the"
    },
    {
      "t": 21203,
      "e": 11105,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the"
    },
    {
      "t": 21281,
      "e": 11183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21329,
      "e": 11231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "th"
    },
    {
      "t": 21441,
      "e": 11343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21488,
      "e": 11390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "t"
    },
    {
      "t": 21585,
      "e": 11487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21640,
      "e": 11542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 21785,
      "e": 11687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 21817,
      "e": 11719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21817,
      "e": 11719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21873,
      "e": 11775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 21889,
      "e": 11791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 22002,
      "e": 11904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22002,
      "e": 11904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22080,
      "e": 11982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Th"
    },
    {
      "t": 22145,
      "e": 12047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22145,
      "e": 12047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22217,
      "e": 12119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The"
    },
    {
      "t": 22242,
      "e": 12144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22242,
      "e": 12144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22328,
      "e": 12230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22328,
      "e": 12230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22384,
      "e": 12286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There"
    },
    {
      "t": 22425,
      "e": 12327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22505,
      "e": 12407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22506,
      "e": 12408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22552,
      "e": 12454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22561,
      "e": 12463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22561,
      "e": 12463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22632,
      "e": 12534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 22681,
      "e": 12583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22681,
      "e": 12583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22745,
      "e": 12647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 22762,
      "e": 12664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22762,
      "e": 12664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22824,
      "e": 12726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 22897,
      "e": 12799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22897,
      "e": 12799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22953,
      "e": 12855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22993,
      "e": 12895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22994,
      "e": 12896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23049,
      "e": 12951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23073,
      "e": 12975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 23073,
      "e": 12975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23154,
      "e": 13056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 23185,
      "e": 13087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23187,
      "e": 13089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23248,
      "e": 13150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 23842,
      "e": 13744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23842,
      "e": 13744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23920,
      "e": 13822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24041,
      "e": 13943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 24042,
      "e": 13944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24105,
      "e": 14007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 24484,
      "e": 14386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24485,
      "e": 14387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24540,
      "e": 14442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 24652,
      "e": 14554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24653,
      "e": 14555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24725,
      "e": 14627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24885,
      "e": 14787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 24885,
      "e": 14787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24947,
      "e": 14849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 25133,
      "e": 15035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25134,
      "e": 15036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25228,
      "e": 15130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25260,
      "e": 15162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25260,
      "e": 15162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25340,
      "e": 15242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 25436,
      "e": 15338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25438,
      "e": 15340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25492,
      "e": 15394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 25607,
      "e": 15509,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagona"
    },
    {
      "t": 25877,
      "e": 15779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25878,
      "e": 15780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25940,
      "e": 15842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 26845,
      "e": 16747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26846,
      "e": 16748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26925,
      "e": 16827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27006,
      "e": 16828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27008,
      "e": 16830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27067,
      "e": 16889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27068,
      "e": 16890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27116,
      "e": 16938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 27132,
      "e": 16954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27132,
      "e": 16954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27172,
      "e": 16994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 27252,
      "e": 17074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27797,
      "e": 17619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27798,
      "e": 17620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27860,
      "e": 17682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 27932,
      "e": 17754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 27932,
      "e": 17754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28013,
      "e": 17835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 30053,
      "e": 19875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30055,
      "e": 19877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30116,
      "e": 19938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30180,
      "e": 20002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 30180,
      "e": 20002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30236,
      "e": 20058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30236,
      "e": 20058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30244,
      "e": 20066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 30301,
      "e": 20123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30301,
      "e": 20123,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30356,
      "e": 20178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30357,
      "e": 20179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30372,
      "e": 20194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 30405,
      "e": 20227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30452,
      "e": 20274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 30453,
      "e": 20275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30468,
      "e": 20290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 30540,
      "e": 20362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30725,
      "e": 20547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30725,
      "e": 20547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30828,
      "e": 20650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31701,
      "e": 21523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31780,
      "e": 21602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines going"
    },
    {
      "t": 31893,
      "e": 21715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31940,
      "e": 21762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines goin"
    },
    {
      "t": 32052,
      "e": 21874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32100,
      "e": 21922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines goi"
    },
    {
      "t": 32196,
      "e": 22018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32244,
      "e": 22066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines go"
    },
    {
      "t": 32349,
      "e": 22171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32397,
      "e": 22219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines g"
    },
    {
      "t": 32485,
      "e": 22307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32540,
      "e": 22362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines "
    },
    {
      "t": 34245,
      "e": 24067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 34245,
      "e": 24067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34308,
      "e": 24130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 34725,
      "e": 24547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34725,
      "e": 24547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34804,
      "e": 24626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34804,
      "e": 24626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34812,
      "e": 24634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ea"
    },
    {
      "t": 34900,
      "e": 24722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35076,
      "e": 24898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 35078,
      "e": 24900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35131,
      "e": 24953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 35285,
      "e": 25107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 35285,
      "e": 25107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35331,
      "e": 25153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35332,
      "e": 25154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35372,
      "e": 25194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 35435,
      "e": 25257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35444,
      "e": 25266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 35445,
      "e": 25267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35493,
      "e": 25315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 35597,
      "e": 25419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35597,
      "e": 25419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35667,
      "e": 25489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35916,
      "e": 25738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35917,
      "e": 25739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35980,
      "e": 25802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36243,
      "e": 26065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 36244,
      "e": 26066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36307,
      "e": 26129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 36315,
      "e": 26137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36315,
      "e": 26137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36388,
      "e": 26210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36444,
      "e": 26266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 36445,
      "e": 26267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36492,
      "e": 26314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 36606,
      "e": 26428,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away"
    },
    {
      "t": 37251,
      "e": 27073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37252,
      "e": 27074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37308,
      "e": 27130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37348,
      "e": 27170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 37348,
      "e": 27170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37404,
      "e": 27226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 37492,
      "e": 27314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 37493,
      "e": 27315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37500,
      "e": 27322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37500,
      "e": 27322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37539,
      "e": 27361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ro"
    },
    {
      "t": 37540,
      "e": 27362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 37540,
      "e": 27362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37572,
      "e": 27394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 37652,
      "e": 27474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37659,
      "e": 27481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37660,
      "e": 27482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37724,
      "e": 27546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38142,
      "e": 27547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 38143,
      "e": 27548,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38220,
      "e": 27625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 38268,
      "e": 27673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 38268,
      "e": 27673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38326,
      "e": 27731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 38596,
      "e": 28001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 38708,
      "e": 28113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 38709,
      "e": 28114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38868,
      "e": 28273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 38908,
      "e": 28313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39228,
      "e": 28633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 39300,
      "e": 28705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 39301,
      "e": 28706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39396,
      "e": 28801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 39468,
      "e": 28873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40125,
      "e": 29530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 40126,
      "e": 29531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40203,
      "e": 29608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40203,
      "e": 29608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40235,
      "e": 29640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||. "
    },
    {
      "t": 40283,
      "e": 29688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40453,
      "e": 29858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 40532,
      "e": 29937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40533,
      "e": 29938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40555,
      "e": 29960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 40604,
      "e": 30009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40611,
      "e": 30016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40611,
      "e": 30016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40684,
      "e": 30089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 40749,
      "e": 30154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40749,
      "e": 30154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40804,
      "e": 30209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40812,
      "e": 30217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40814,
      "e": 30219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40876,
      "e": 30281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40972,
      "e": 30377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40972,
      "e": 30377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41004,
      "e": 30409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 41004,
      "e": 30409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41036,
      "e": 30441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 41084,
      "e": 30489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41468,
      "e": 30873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 41469,
      "e": 30874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41547,
      "e": 30952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 42316,
      "e": 31721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42404,
      "e": 31809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The on"
    },
    {
      "t": 42964,
      "e": 32369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42965,
      "e": 32370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43028,
      "e": 32433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 43156,
      "e": 32561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43157,
      "e": 32562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43212,
      "e": 32617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43661,
      "e": 33066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 43661,
      "e": 33066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43740,
      "e": 33145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43741,
      "e": 33146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43763,
      "e": 33168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 43828,
      "e": 33233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44469,
      "e": 33874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44548,
      "e": 33953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one o"
    },
    {
      "t": 44636,
      "e": 34041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44692,
      "e": 34097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one "
    },
    {
      "t": 44806,
      "e": 34211,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one "
    },
    {
      "t": 45661,
      "e": 35066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45661,
      "e": 35066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45724,
      "e": 35129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45779,
      "e": 35184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 45780,
      "e": 35185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45852,
      "e": 35257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 45892,
      "e": 35297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 45893,
      "e": 35298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45964,
      "e": 35369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 46116,
      "e": 35521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 46117,
      "e": 35522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46163,
      "e": 35568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 46677,
      "e": 36082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46677,
      "e": 36082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46740,
      "e": 36145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 46821,
      "e": 36226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 46821,
      "e": 36226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46876,
      "e": 36281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 46876,
      "e": 36281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46892,
      "e": 36297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 46964,
      "e": 36369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47563,
      "e": 36968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47563,
      "e": 36968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47619,
      "e": 37024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47659,
      "e": 37064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47660,
      "e": 37065,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47707,
      "e": 37112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 47708,
      "e": 37113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47715,
      "e": 37120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 47755,
      "e": 37160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47764,
      "e": 37169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47764,
      "e": 37169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47843,
      "e": 37248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 47868,
      "e": 37273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47868,
      "e": 37273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47940,
      "e": 37273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48188,
      "e": 37521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 48189,
      "e": 37522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48259,
      "e": 37592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 48388,
      "e": 37721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48389,
      "e": 37722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48468,
      "e": 37801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 48580,
      "e": 37913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 48581,
      "e": 37914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48636,
      "e": 37969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 48749,
      "e": 38082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48749,
      "e": 38082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48795,
      "e": 38128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 49117,
      "e": 38450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49118,
      "e": 38451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49179,
      "e": 38512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49244,
      "e": 38577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 49244,
      "e": 38577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49300,
      "e": 38633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 49364,
      "e": 38697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 49365,
      "e": 38698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49436,
      "e": 38769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 49484,
      "e": 38817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49484,
      "e": 38817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49548,
      "e": 38881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51756,
      "e": 41089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51820,
      "e": 41153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left is"
    },
    {
      "t": 51916,
      "e": 41249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51979,
      "e": 41312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left i"
    },
    {
      "t": 52075,
      "e": 41408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52140,
      "e": 41473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left "
    },
    {
      "t": 52300,
      "e": 41633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52356,
      "e": 41689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left"
    },
    {
      "t": 53236,
      "e": 42569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53237,
      "e": 42570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53283,
      "e": 42616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53406,
      "e": 42739,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left "
    },
    {
      "t": 53460,
      "e": 42793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 53461,
      "e": 42794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53532,
      "e": 42865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 53579,
      "e": 42912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 53580,
      "e": 42913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53652,
      "e": 42985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53652,
      "e": 42985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53660,
      "e": 42993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ea"
    },
    {
      "t": 53708,
      "e": 43041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 53709,
      "e": 43042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53732,
      "e": 43065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 53773,
      "e": 43106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54259,
      "e": 43592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 54260,
      "e": 43593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54324,
      "e": 43657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 55892,
      "e": 45225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55894,
      "e": 45227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55948,
      "e": 45281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55979,
      "e": 45312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 55980,
      "e": 45313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56035,
      "e": 45368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 56076,
      "e": 45409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 56076,
      "e": 45409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56132,
      "e": 45465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 56220,
      "e": 45553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 56221,
      "e": 45554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56292,
      "e": 45625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 56407,
      "e": 45740,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any"
    },
    {
      "t": 57556,
      "e": 46889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57557,
      "e": 46890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57603,
      "e": 46936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57732,
      "e": 46937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 57734,
      "e": 46939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57779,
      "e": 46984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 57780,
      "e": 46985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57795,
      "e": 47000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 57860,
      "e": 47065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57899,
      "e": 47104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 57900,
      "e": 47105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57956,
      "e": 47161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 58100,
      "e": 47305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 58101,
      "e": 47306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58179,
      "e": 47384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 58301,
      "e": 47506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58301,
      "e": 47506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58364,
      "e": 47569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 58396,
      "e": 47601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 58397,
      "e": 47602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58467,
      "e": 47672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 58571,
      "e": 47776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58572,
      "e": 47777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58627,
      "e": 47832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58733,
      "e": 47938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58733,
      "e": 47938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58795,
      "e": 48000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 58819,
      "e": 48024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 58819,
      "e": 48024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58891,
      "e": 48096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 59007,
      "e": 48212,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts en"
    },
    {
      "t": 59108,
      "e": 48313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 59108,
      "e": 48313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59164,
      "e": 48369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 59211,
      "e": 48416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 59211,
      "e": 48416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59284,
      "e": 48489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 59284,
      "e": 48489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59316,
      "e": 48521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 59396,
      "e": 48601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59420,
      "e": 48625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 59421,
      "e": 48626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59467,
      "e": 48672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 59556,
      "e": 48761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59556,
      "e": 48761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59619,
      "e": 48824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59676,
      "e": 48881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59679,
      "e": 48884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59739,
      "e": 48944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 59819,
      "e": 49024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59820,
      "e": 49025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59884,
      "e": 49089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 60007,
      "e": 49212,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at"
    },
    {
      "t": 60460,
      "e": 49665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60461,
      "e": 49666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60515,
      "e": 49720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60740,
      "e": 49945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 60741,
      "e": 49946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60819,
      "e": 50024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 60851,
      "e": 50056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 60851,
      "e": 50056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60916,
      "e": 50121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 61051,
      "e": 50256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 61055,
      "e": 50260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61147,
      "e": 50352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 61147,
      "e": 50352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61163,
      "e": 50368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 61228,
      "e": 50433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61427,
      "e": 50632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 61428,
      "e": 50633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61484,
      "e": 50689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61484,
      "e": 50689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61499,
      "e": 50704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 61539,
      "e": 50744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 61539,
      "e": 50744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61547,
      "e": 50752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 61595,
      "e": 50800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61635,
      "e": 50840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 61635,
      "e": 50840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61667,
      "e": 50872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 61668,
      "e": 50873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61691,
      "e": 50896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 61699,
      "e": 50904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61805,
      "e": 51010,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and"
    },
    {
      "t": 63269,
      "e": 52474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 63269,
      "e": 52474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63299,
      "e": 52504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 63300,
      "e": 52505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63339,
      "e": 52544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 63347,
      "e": 52552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63451,
      "e": 52656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63452,
      "e": 52657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63492,
      "e": 52697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63492,
      "e": 52697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63499,
      "e": 52704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 63564,
      "e": 52704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63676,
      "e": 52816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 63676,
      "e": 52816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63731,
      "e": 52871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 63732,
      "e": 52872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63763,
      "e": 52903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 63828,
      "e": 52968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64036,
      "e": 53176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64099,
      "e": 53239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, andthe o"
    },
    {
      "t": 64196,
      "e": 53336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64252,
      "e": 53392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, andthe "
    },
    {
      "t": 64331,
      "e": 53471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64411,
      "e": 53551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, andthe"
    },
    {
      "t": 64492,
      "e": 53632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64564,
      "e": 53704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, andth"
    },
    {
      "t": 64660,
      "e": 53800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64724,
      "e": 53864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, andt"
    },
    {
      "t": 64820,
      "e": 53960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64883,
      "e": 54023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and"
    },
    {
      "t": 65006,
      "e": 54146,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and"
    },
    {
      "t": 65204,
      "e": 54344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65205,
      "e": 54345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65267,
      "e": 54407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65492,
      "e": 54632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 65493,
      "e": 54633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65555,
      "e": 54695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 65556,
      "e": 54695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65587,
      "e": 54726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 65643,
      "e": 54782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65716,
      "e": 54855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 65716,
      "e": 54855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65771,
      "e": 54910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 67325,
      "e": 56464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67325,
      "e": 56464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67379,
      "e": 56518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67380,
      "e": 56519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 67380,
      "e": 56519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67460,
      "e": 56599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 67491,
      "e": 56630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 67492,
      "e": 56631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67548,
      "e": 56687,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 67580,
      "e": 56719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 67580,
      "e": 56719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67651,
      "e": 56790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 67707,
      "e": 56846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 67707,
      "e": 56846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67787,
      "e": 56926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 67891,
      "e": 57030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 67891,
      "e": 57030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67979,
      "e": 57118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 68051,
      "e": 57190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 68051,
      "e": 57190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68100,
      "e": 57239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 68100,
      "e": 57239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68124,
      "e": 57263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 68196,
      "e": 57335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68748,
      "e": 57887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68748,
      "e": 57887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68795,
      "e": 57934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68811,
      "e": 57950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68811,
      "e": 57950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68875,
      "e": 58014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 68883,
      "e": 58022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 68883,
      "e": 58022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68948,
      "e": 58087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 68948,
      "e": 58087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68949,
      "e": 58088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69004,
      "e": 58143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 69051,
      "e": 58190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69051,
      "e": 58190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69107,
      "e": 58246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69260,
      "e": 58399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 69261,
      "e": 58400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69323,
      "e": 58462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 69323,
      "e": 58462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69323,
      "e": 58462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69379,
      "e": 58518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 69444,
      "e": 58583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 69444,
      "e": 58583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69499,
      "e": 58638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 69507,
      "e": 58646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69507,
      "e": 58646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69571,
      "e": 58710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 69612,
      "e": 58751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69612,
      "e": 58751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69659,
      "e": 58798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 69684,
      "e": 58823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69685,
      "e": 58824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69756,
      "e": 58895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69788,
      "e": 58927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69788,
      "e": 58927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69844,
      "e": 58983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 69876,
      "e": 59015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 69877,
      "e": 59016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69955,
      "e": 59094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 69987,
      "e": 59126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69988,
      "e": 59127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70043,
      "e": 59182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70316,
      "e": 59455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 70317,
      "e": 59456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70372,
      "e": 59511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 70420,
      "e": 59559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 70421,
      "e": 59560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70475,
      "e": 59614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 70588,
      "e": 59727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 70588,
      "e": 59727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70667,
      "e": 59806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 71284,
      "e": 60423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71285,
      "e": 60424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71331,
      "e": 60470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 71403,
      "e": 60542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 71403,
      "e": 60542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71451,
      "e": 60590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 71451,
      "e": 60590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71467,
      "e": 60606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 71539,
      "e": 60678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71539,
      "e": 60678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 71539,
      "e": 60678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71619,
      "e": 60758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 72356,
      "e": 61495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 72356,
      "e": 61495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72428,
      "e": 61567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 72524,
      "e": 61663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 72524,
      "e": 61663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72579,
      "e": 61718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 72611,
      "e": 61750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 72611,
      "e": 61750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72691,
      "e": 61830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 72807,
      "e": 61946,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts"
    },
    {
      "t": 72964,
      "e": 62103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72965,
      "e": 62104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73003,
      "e": 62142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73091,
      "e": 62230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73091,
      "e": 62230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73163,
      "e": 62302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 74045,
      "e": 63184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74116,
      "e": 63185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts "
    },
    {
      "t": 74162,
      "e": 63231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 74163,
      "e": 63232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74219,
      "e": 63288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 74283,
      "e": 63352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 74284,
      "e": 63353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74331,
      "e": 63400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 74379,
      "e": 63448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 74379,
      "e": 63448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74451,
      "e": 63520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 74812,
      "e": 63881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 74812,
      "e": 63881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74859,
      "e": 63928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 75006,
      "e": 64075,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts star"
    },
    {
      "t": 75059,
      "e": 64128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 75061,
      "e": 64130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75139,
      "e": 64208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 75219,
      "e": 64288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 75219,
      "e": 64288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75292,
      "e": 64361,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 75292,
      "e": 64361,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75315,
      "e": 64384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 75379,
      "e": 64448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 75395,
      "e": 64464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 75396,
      "e": 64465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75419,
      "e": 64488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 75476,
      "e": 64545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75476,
      "e": 64545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75548,
      "e": 64617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 75564,
      "e": 64633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 75564,
      "e": 64633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75636,
      "e": 64705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 75676,
      "e": 64745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 75677,
      "e": 64746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75747,
      "e": 64816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 75940,
      "e": 65009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75941,
      "e": 65010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76003,
      "e": 65072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 76228,
      "e": 65297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 76229,
      "e": 65298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76315,
      "e": 65384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 76339,
      "e": 65408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 76339,
      "e": 65408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76411,
      "e": 65480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 76579,
      "e": 65648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 76581,
      "e": 65650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76667,
      "e": 65736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 76667,
      "e": 65736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76691,
      "e": 65760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 76755,
      "e": 65824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 77132,
      "e": 66201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 77133,
      "e": 66202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77211,
      "e": 66280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77211,
      "e": 66280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77227,
      "e": 66296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||. "
    },
    {
      "t": 77291,
      "e": 66360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 77407,
      "e": 66476,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts starting at 12pm. "
    },
    {
      "t": 79421,
      "e": 68490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 79500,
      "e": 68569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 79501,
      "e": 68570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79547,
      "e": 68616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||Y"
    },
    {
      "t": 79555,
      "e": 68624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79980,
      "e": 69049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 79980,
      "e": 69049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80005,
      "e": 69074,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80059,
      "e": 69128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 80059,
      "e": 69128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80067,
      "e": 69136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 80123,
      "e": 69192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80323,
      "e": 69392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80333,
      "e": 69402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80371,
      "e": 69440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80475,
      "e": 69544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 80476,
      "e": 69545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80523,
      "e": 69592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 80547,
      "e": 69616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 80547,
      "e": 69616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80588,
      "e": 69657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 80588,
      "e": 69657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80611,
      "e": 69680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 80644,
      "e": 69713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80740,
      "e": 69809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80740,
      "e": 69809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80803,
      "e": 69872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 81180,
      "e": 70249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 81180,
      "e": 70249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81227,
      "e": 70296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 81291,
      "e": 70360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 81291,
      "e": 70360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81347,
      "e": 70416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 81459,
      "e": 70528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 81460,
      "e": 70529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81523,
      "e": 70592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 81620,
      "e": 70689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 81620,
      "e": 70689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81659,
      "e": 70728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 81787,
      "e": 70856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 81787,
      "e": 70856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81826,
      "e": 70895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 82196,
      "e": 71265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 82197,
      "e": 71266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82243,
      "e": 71312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 82748,
      "e": 71817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 82748,
      "e": 71817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82811,
      "e": 71880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 83939,
      "e": 73008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 83940,
      "e": 73009,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83995,
      "e": 73064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 84019,
      "e": 73088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 84019,
      "e": 73088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84075,
      "e": 73144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 84131,
      "e": 73200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 84132,
      "e": 73201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84212,
      "e": 73281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 84243,
      "e": 73312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 84243,
      "e": 73312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84307,
      "e": 73376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 84371,
      "e": 73440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 84371,
      "e": 73440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84439,
      "e": 73508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 84575,
      "e": 73644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 84576,
      "e": 73645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84615,
      "e": 73684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 84671,
      "e": 73740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 84672,
      "e": 73741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84727,
      "e": 73796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 85008,
      "e": 74077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 85047,
      "e": 74116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow that r"
    },
    {
      "t": 85143,
      "e": 74212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 85207,
      "e": 74276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow that "
    },
    {
      "t": 85296,
      "e": 74365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 85352,
      "e": 74366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow that"
    },
    {
      "t": 85447,
      "e": 74461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 85495,
      "e": 74509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow tha"
    },
    {
      "t": 85611,
      "e": 74625,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow tha"
    },
    {
      "t": 85624,
      "e": 74638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 85638,
      "e": 74652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow th"
    },
    {
      "t": 85719,
      "e": 74733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 85759,
      "e": 74773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow t"
    },
    {
      "t": 86360,
      "e": 75374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 86360,
      "e": 75374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86431,
      "e": 75374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 86519,
      "e": 75462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 86519,
      "e": 75462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86583,
      "e": 75526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 86647,
      "e": 75590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 86648,
      "e": 75591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86719,
      "e": 75662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 86782,
      "e": 75725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 86783,
      "e": 75726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86830,
      "e": 75773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 86847,
      "e": 75790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 86847,
      "e": 75790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86895,
      "e": 75838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 87011,
      "e": 75954,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow the ri"
    },
    {
      "t": 87063,
      "e": 76006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 87064,
      "e": 76007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87111,
      "e": 76054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 87135,
      "e": 76078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 87135,
      "e": 76078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87199,
      "e": 76142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 87279,
      "e": 76222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 87279,
      "e": 76222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87327,
      "e": 76270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 87359,
      "e": 76302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 87359,
      "e": 76302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87471,
      "e": 76414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 87703,
      "e": 76646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 87704,
      "e": 76647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87784,
      "e": 76727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 87784,
      "e": 76727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87807,
      "e": 76750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 87863,
      "e": 76806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 87912,
      "e": 76855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 87912,
      "e": 76855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87999,
      "e": 76942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 88135,
      "e": 77078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 88136,
      "e": 77079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88199,
      "e": 77142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 88256,
      "e": 77199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 88256,
      "e": 77199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88303,
      "e": 77246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 88391,
      "e": 77334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 88392,
      "e": 77335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88431,
      "e": 77374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 88432,
      "e": 77375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 88433,
      "e": 77376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88486,
      "e": 77429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 88487,
      "e": 77430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88496,
      "e": 77439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 88551,
      "e": 77494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 88623,
      "e": 77566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 88623,
      "e": 77566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88711,
      "e": 77654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 88815,
      "e": 77758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 88815,
      "e": 77758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88870,
      "e": 77813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 88927,
      "e": 77870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 88927,
      "e": 77870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88983,
      "e": 77926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 89048,
      "e": 77991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89048,
      "e": 77991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89111,
      "e": 78054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89135,
      "e": 78078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 89135,
      "e": 78078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89199,
      "e": 78142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 89199,
      "e": 78142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89207,
      "e": 78150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 89255,
      "e": 78198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 89279,
      "e": 78222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 89279,
      "e": 78222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89359,
      "e": 78302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 89400,
      "e": 78343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 89401,
      "e": 78344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89472,
      "e": 78415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 89536,
      "e": 78479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89537,
      "e": 78480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89590,
      "e": 78533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 92488,
      "e": 81431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 92583,
      "e": 81526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 92585,
      "e": 81528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92638,
      "e": 81581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 92679,
      "e": 81622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93000,
      "e": 81943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 93001,
      "e": 81944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93055,
      "e": 81998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 93103,
      "e": 82046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 93103,
      "e": 82046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93127,
      "e": 82070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 93127,
      "e": 82070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93158,
      "e": 82101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 93199,
      "e": 82142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93247,
      "e": 82190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 93248,
      "e": 82191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93271,
      "e": 82214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 93271,
      "e": 82214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93287,
      "e": 82230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 93335,
      "e": 82278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93560,
      "e": 82503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 93616,
      "e": 82559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 93616,
      "e": 82559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93671,
      "e": 82614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 93727,
      "e": 82670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 94552,
      "e": 83495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 94553,
      "e": 83496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94622,
      "e": 83565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 94943,
      "e": 83886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 94945,
      "e": 83887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94990,
      "e": 83932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 95047,
      "e": 83989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 95047,
      "e": 83989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95119,
      "e": 84061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 95159,
      "e": 84101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 95159,
      "e": 84101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95223,
      "e": 84165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 95239,
      "e": 84181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 95239,
      "e": 84181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95312,
      "e": 84254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 95344,
      "e": 84286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 95344,
      "e": 84286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95407,
      "e": 84349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 95479,
      "e": 84421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 95479,
      "e": 84421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95567,
      "e": 84509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 95703,
      "e": 84645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 95704,
      "e": 84646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95774,
      "e": 84716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 95935,
      "e": 84877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 95936,
      "e": 84878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95983,
      "e": 84925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 96054,
      "e": 84996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 96054,
      "e": 84996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96095,
      "e": 85037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 96191,
      "e": 85133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 96192,
      "e": 85134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96247,
      "e": 85189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 96374,
      "e": 85316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 96375,
      "e": 85317,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96423,
      "e": 85365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 96423,
      "e": 85365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96431,
      "e": 85373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 96495,
      "e": 85437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 96575,
      "e": 85517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 96575,
      "e": 85517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96631,
      "e": 85573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 96687,
      "e": 85629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 96687,
      "e": 85629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96742,
      "e": 85684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 97359,
      "e": 86301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 97359,
      "e": 86301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97439,
      "e": 86381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 97439,
      "e": 86381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97471,
      "e": 86413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 97519,
      "e": 86461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 97920,
      "e": 86862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 97920,
      "e": 86862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97984,
      "e": 86926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 97984,
      "e": 86926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98007,
      "e": 86949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 98062,
      "e": 87004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 98368,
      "e": 87310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 98368,
      "e": 87310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98455,
      "e": 87397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 98455,
      "e": 87397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98462,
      "e": 87404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 98518,
      "e": 87460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 98526,
      "e": 87468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 98527,
      "e": 87469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98599,
      "e": 87541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 98630,
      "e": 87572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 98631,
      "e": 87573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98679,
      "e": 87621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 98811,
      "e": 87753,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow the right line to see that M and L both start at 12pm, an"
    },
    {
      "t": 99040,
      "e": 87982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 99103,
      "e": 88045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow the right line to see that M and L both start at 12pm, a"
    },
    {
      "t": 99190,
      "e": 88132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 99248,
      "e": 88134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any shifts ending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow the right line to see that M and L both start at 12pm, "
    },
    {
      "t": 99335,
      "e": 88221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 99336,
      "e": 88222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99390,
      "e": 88276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 99422,
      "e": 88308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 99422,
      "e": 88308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99479,
      "e": 88365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 99479,
      "e": 88365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99526,
      "e": 88412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 99574,
      "e": 88460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 99678,
      "e": 88564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 99678,
      "e": 88564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99735,
      "e": 88621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 100103,
      "e": 88989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 100104,
      "e": 88990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100151,
      "e": 89037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 100552,
      "e": 89438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 100552,
      "e": 89438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100607,
      "e": 89493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 101815,
      "e": 90701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 101816,
      "e": 90702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101871,
      "e": 90757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 101895,
      "e": 90781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 101895,
      "e": 90781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101959,
      "e": 90845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 101998,
      "e": 90884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 101999,
      "e": 90885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102054,
      "e": 90940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 102063,
      "e": 90949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 102064,
      "e": 90950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102127,
      "e": 91013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 102207,
      "e": 91093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 102208,
      "e": 91094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102262,
      "e": 91148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 102263,
      "e": 91149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102271,
      "e": 91157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 102335,
      "e": 91221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 102399,
      "e": 91285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 102399,
      "e": 91285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102455,
      "e": 91341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 102470,
      "e": 91356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 102470,
      "e": 91356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102535,
      "e": 91421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 102888,
      "e": 91774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 102888,
      "e": 91774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102950,
      "e": 91836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 103047,
      "e": 91933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 103047,
      "e": 91933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103086,
      "e": 91972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 103102,
      "e": 91988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 103103,
      "e": 91989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103159,
      "e": 92045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 103232,
      "e": 92118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 103232,
      "e": 92118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103294,
      "e": 92180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 103294,
      "e": 92180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103303,
      "e": 92189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 103375,
      "e": 92261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 103439,
      "e": 92325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 103439,
      "e": 92325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103511,
      "e": 92397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 103599,
      "e": 92485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 103600,
      "e": 92486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103646,
      "e": 92532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 103647,
      "e": 92533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103687,
      "e": 92573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 103735,
      "e": 92621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 103735,
      "e": 92621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103750,
      "e": 92636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 103807,
      "e": 92693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 103983,
      "e": 92869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 103985,
      "e": 92871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104047,
      "e": 92933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 104071,
      "e": 92957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 104071,
      "e": 92957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104151,
      "e": 93037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 104200,
      "e": 93086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 104200,
      "e": 93086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104263,
      "e": 93149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 104319,
      "e": 93205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 104319,
      "e": 93205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104391,
      "e": 93277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 104423,
      "e": 93309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 104423,
      "e": 93309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104495,
      "e": 93381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 104567,
      "e": 93453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 104567,
      "e": 93453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104647,
      "e": 93533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 104648,
      "e": 93534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104671,
      "e": 93557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 104766,
      "e": 93652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 104775,
      "e": 93661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 104775,
      "e": 93661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104854,
      "e": 93740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 105120,
      "e": 94006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 105120,
      "e": 94006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105167,
      "e": 94053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 106009,
      "e": 94895,
      "ty": 2,
      "x": 683,
      "y": 749
    },
    {
      "t": 106009,
      "e": 94895,
      "ty": 41,
      "x": 166,
      "y": 43382,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 106026,
      "e": 94912,
      "ty": 6,
      "x": 575,
      "y": 552,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106042,
      "e": 94928,
      "ty": 7,
      "x": 464,
      "y": 425,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106108,
      "e": 94928,
      "ty": 2,
      "x": 359,
      "y": 344
    },
    {
      "t": 106208,
      "e": 95028,
      "ty": 2,
      "x": 330,
      "y": 389
    },
    {
      "t": 106259,
      "e": 95079,
      "ty": 41,
      "x": 21684,
      "y": 793,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 106291,
      "e": 95111,
      "ty": 6,
      "x": 282,
      "y": 523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106308,
      "e": 95128,
      "ty": 2,
      "x": 282,
      "y": 561
    },
    {
      "t": 106326,
      "e": 95146,
      "ty": 7,
      "x": 296,
      "y": 612,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106408,
      "e": 95228,
      "ty": 2,
      "x": 317,
      "y": 650
    },
    {
      "t": 106476,
      "e": 95296,
      "ty": 6,
      "x": 340,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 106509,
      "e": 95329,
      "ty": 2,
      "x": 342,
      "y": 669
    },
    {
      "t": 106509,
      "e": 95329,
      "ty": 41,
      "x": 1860,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 106608,
      "e": 95428,
      "ty": 2,
      "x": 349,
      "y": 669
    },
    {
      "t": 106708,
      "e": 95528,
      "ty": 2,
      "x": 365,
      "y": 676
    },
    {
      "t": 106759,
      "e": 95579,
      "ty": 41,
      "x": 19882,
      "y": 46771,
      "ta": "#strategyButton"
    },
    {
      "t": 106809,
      "e": 95629,
      "ty": 2,
      "x": 375,
      "y": 679
    },
    {
      "t": 108856,
      "e": 97676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 108856,
      "e": 97676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108918,
      "e": 97738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 109609,
      "e": 98429,
      "ty": 2,
      "x": 374,
      "y": 677
    },
    {
      "t": 109759,
      "e": 98579,
      "ty": 41,
      "x": 19336,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 111397,
      "e": 100217,
      "ty": 7,
      "x": 396,
      "y": 642,
      "ta": "#strategyButton"
    },
    {
      "t": 111409,
      "e": 100229,
      "ty": 2,
      "x": 396,
      "y": 642
    },
    {
      "t": 111446,
      "e": 100266,
      "ty": 6,
      "x": 423,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111508,
      "e": 100328,
      "ty": 2,
      "x": 426,
      "y": 583
    },
    {
      "t": 111508,
      "e": 100328,
      "ty": 41,
      "x": 36972,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111609,
      "e": 100429,
      "ty": 2,
      "x": 427,
      "y": 569
    },
    {
      "t": 111708,
      "e": 100528,
      "ty": 2,
      "x": 401,
      "y": 558
    },
    {
      "t": 111759,
      "e": 100579,
      "ty": 41,
      "x": 30677,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111809,
      "e": 100629,
      "ty": 2,
      "x": 332,
      "y": 539
    },
    {
      "t": 111909,
      "e": 100729,
      "ty": 2,
      "x": 301,
      "y": 536
    },
    {
      "t": 112009,
      "e": 100829,
      "ty": 2,
      "x": 230,
      "y": 554
    },
    {
      "t": 112010,
      "e": 100830,
      "ty": 41,
      "x": 14939,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112108,
      "e": 100928,
      "ty": 2,
      "x": 222,
      "y": 556
    },
    {
      "t": 112209,
      "e": 101029,
      "ty": 2,
      "x": 233,
      "y": 538
    },
    {
      "t": 112248,
      "e": 101068,
      "ty": 7,
      "x": 266,
      "y": 519,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112259,
      "e": 101079,
      "ty": 41,
      "x": 18986,
      "y": 56794,
      "ta": "#.strategy > p"
    },
    {
      "t": 112309,
      "e": 101129,
      "ty": 2,
      "x": 308,
      "y": 515
    },
    {
      "t": 112407,
      "e": 101227,
      "ty": 2,
      "x": 437,
      "y": 515
    },
    {
      "t": 112508,
      "e": 101328,
      "ty": 2,
      "x": 480,
      "y": 511
    },
    {
      "t": 112508,
      "e": 101328,
      "ty": 41,
      "x": 43042,
      "y": 38070,
      "ta": "#.strategy > p"
    },
    {
      "t": 112609,
      "e": 101429,
      "ty": 2,
      "x": 564,
      "y": 514
    },
    {
      "t": 112709,
      "e": 101529,
      "ty": 2,
      "x": 619,
      "y": 515
    },
    {
      "t": 112759,
      "e": 101579,
      "ty": 41,
      "x": 58779,
      "y": 49772,
      "ta": "#.strategy > p"
    },
    {
      "t": 112808,
      "e": 101628,
      "ty": 2,
      "x": 621,
      "y": 520
    },
    {
      "t": 112831,
      "e": 101651,
      "ty": 6,
      "x": 617,
      "y": 525,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112908,
      "e": 101728,
      "ty": 2,
      "x": 555,
      "y": 529
    },
    {
      "t": 113008,
      "e": 101828,
      "ty": 2,
      "x": 512,
      "y": 528
    },
    {
      "t": 113009,
      "e": 101829,
      "ty": 41,
      "x": 46639,
      "y": 4260,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113047,
      "e": 101867,
      "ty": 7,
      "x": 458,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113108,
      "e": 101928,
      "ty": 2,
      "x": 355,
      "y": 517
    },
    {
      "t": 113131,
      "e": 101951,
      "ty": 6,
      "x": 293,
      "y": 525,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113208,
      "e": 102028,
      "ty": 2,
      "x": 274,
      "y": 539
    },
    {
      "t": 113258,
      "e": 102078,
      "ty": 41,
      "x": 19436,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113308,
      "e": 102128,
      "ty": 2,
      "x": 258,
      "y": 550
    },
    {
      "t": 113408,
      "e": 102228,
      "ty": 2,
      "x": 204,
      "y": 554
    },
    {
      "t": 113507,
      "e": 102327,
      "ty": 2,
      "x": 204,
      "y": 555
    },
    {
      "t": 113508,
      "e": 102328,
      "ty": 41,
      "x": 12017,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113608,
      "e": 102428,
      "ty": 2,
      "x": 204,
      "y": 554
    },
    {
      "t": 113758,
      "e": 102578,
      "ty": 41,
      "x": 11680,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113807,
      "e": 102627,
      "ty": 2,
      "x": 201,
      "y": 554
    },
    {
      "t": 114028,
      "e": 102848,
      "ty": 3,
      "x": 201,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114082,
      "e": 102902,
      "ty": 4,
      "x": 11680,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114083,
      "e": 102903,
      "ty": 5,
      "x": 201,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114179,
      "e": 102999,
      "ty": 3,
      "x": 201,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114235,
      "e": 103055,
      "ty": 4,
      "x": 11680,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114235,
      "e": 103055,
      "ty": 5,
      "x": 201,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115552,
      "e": 104372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 115552,
      "e": 104372,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115630,
      "e": 104450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any eending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 115718,
      "e": 104538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 115718,
      "e": 104538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115792,
      "e": 104539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any evending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 115846,
      "e": 104593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 115846,
      "e": 104593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115894,
      "e": 104641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any eveending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 115919,
      "e": 104666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 115919,
      "e": 104666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115974,
      "e": 104721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any evenending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 116007,
      "e": 104754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 116007,
      "e": 104754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116072,
      "e": 104755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any eventending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 116079,
      "e": 104762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 116079,
      "e": 104762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116150,
      "e": 104833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any eventsending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 116296,
      "e": 104979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 116296,
      "e": 104979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116367,
      "e": 105050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any shifts starting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 117108,
      "e": 105791,
      "ty": 2,
      "x": 239,
      "y": 546
    },
    {
      "t": 117208,
      "e": 105891,
      "ty": 2,
      "x": 430,
      "y": 538
    },
    {
      "t": 117258,
      "e": 105941,
      "ty": 41,
      "x": 45627,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117308,
      "e": 105991,
      "ty": 2,
      "x": 531,
      "y": 545
    },
    {
      "t": 117408,
      "e": 106091,
      "ty": 2,
      "x": 535,
      "y": 545
    },
    {
      "t": 117508,
      "e": 106191,
      "ty": 2,
      "x": 539,
      "y": 548
    },
    {
      "t": 117509,
      "e": 106192,
      "ty": 41,
      "x": 49674,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117608,
      "e": 106291,
      "ty": 2,
      "x": 556,
      "y": 557
    },
    {
      "t": 117708,
      "e": 106391,
      "ty": 2,
      "x": 575,
      "y": 559
    },
    {
      "t": 117758,
      "e": 106441,
      "ty": 41,
      "x": 53946,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117808,
      "e": 106491,
      "ty": 2,
      "x": 578,
      "y": 559
    },
    {
      "t": 117907,
      "e": 106590,
      "ty": 2,
      "x": 590,
      "y": 552
    },
    {
      "t": 118007,
      "e": 106690,
      "ty": 2,
      "x": 597,
      "y": 548
    },
    {
      "t": 118008,
      "e": 106691,
      "ty": 41,
      "x": 56194,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118123,
      "e": 106806,
      "ty": 3,
      "x": 597,
      "y": 548,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118203,
      "e": 106886,
      "ty": 4,
      "x": 56194,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118203,
      "e": 106886,
      "ty": 5,
      "x": 597,
      "y": 548,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118291,
      "e": 106974,
      "ty": 3,
      "x": 597,
      "y": 548,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118346,
      "e": 107029,
      "ty": 4,
      "x": 56194,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118346,
      "e": 107029,
      "ty": 5,
      "x": 597,
      "y": 548,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118815,
      "e": 107498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 118816,
      "e": 107499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118871,
      "e": 107500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any estarting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 119010,
      "e": 107639,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any estarting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 119015,
      "e": 107644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 119016,
      "e": 107645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119086,
      "e": 107715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any evstarting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 119191,
      "e": 107820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 119191,
      "e": 107820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119247,
      "e": 107876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 119247,
      "e": 107876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119255,
      "e": 107876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any evnestarting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 119334,
      "e": 107955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 119479,
      "e": 108100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 119480,
      "e": 108101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119558,
      "e": 108179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any evnesstarting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 121079,
      "e": 109700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 121150,
      "e": 109771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any evnestarting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 121214,
      "e": 109835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 121214,
      "e": 109835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121271,
      "e": 109835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any evnetstarting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 121279,
      "e": 109843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 121279,
      "e": 109843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121343,
      "e": 109907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any evnetsstarting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 123743,
      "e": 112307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 123744,
      "e": 112308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123831,
      "e": 112395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any evnets starting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 124509,
      "e": 113073,
      "ty": 2,
      "x": 551,
      "y": 561
    },
    {
      "t": 124509,
      "e": 113073,
      "ty": 41,
      "x": 51023,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124608,
      "e": 113172,
      "ty": 2,
      "x": 534,
      "y": 567
    },
    {
      "t": 124708,
      "e": 113272,
      "ty": 2,
      "x": 517,
      "y": 569
    },
    {
      "t": 124759,
      "e": 113323,
      "ty": 41,
      "x": 47201,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125708,
      "e": 114272,
      "ty": 2,
      "x": 565,
      "y": 561
    },
    {
      "t": 125759,
      "e": 114323,
      "ty": 41,
      "x": 55295,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125808,
      "e": 114372,
      "ty": 2,
      "x": 590,
      "y": 557
    },
    {
      "t": 126008,
      "e": 114572,
      "ty": 2,
      "x": 595,
      "y": 555
    },
    {
      "t": 126008,
      "e": 114572,
      "ty": 41,
      "x": 55969,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126109,
      "e": 114673,
      "ty": 2,
      "x": 601,
      "y": 553
    },
    {
      "t": 126208,
      "e": 114772,
      "ty": 2,
      "x": 605,
      "y": 551
    },
    {
      "t": 126258,
      "e": 114822,
      "ty": 41,
      "x": 57318,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126309,
      "e": 114873,
      "ty": 2,
      "x": 607,
      "y": 550
    },
    {
      "t": 126442,
      "e": 115006,
      "ty": 3,
      "x": 607,
      "y": 550,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126554,
      "e": 115118,
      "ty": 4,
      "x": 57318,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126554,
      "e": 115118,
      "ty": 5,
      "x": 607,
      "y": 550,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126708,
      "e": 115272,
      "ty": 2,
      "x": 643,
      "y": 561
    },
    {
      "t": 126759,
      "e": 115323,
      "ty": 41,
      "x": 65187,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126809,
      "e": 115373,
      "ty": 2,
      "x": 679,
      "y": 571
    },
    {
      "t": 127008,
      "e": 115572,
      "ty": 41,
      "x": 65412,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127503,
      "e": 116067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 127574,
      "e": 116067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any evets starting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 128207,
      "e": 116700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 128262,
      "e": 116755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 128479,
      "e": 116972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 128480,
      "e": 116973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128534,
      "e": 117027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any events starting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 129108,
      "e": 117601,
      "ty": 2,
      "x": 563,
      "y": 539
    },
    {
      "t": 129127,
      "e": 117620,
      "ty": 7,
      "x": 532,
      "y": 517,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129208,
      "e": 117701,
      "ty": 2,
      "x": 460,
      "y": 496
    },
    {
      "t": 129258,
      "e": 117751,
      "ty": 41,
      "x": 33037,
      "y": 5783,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 129308,
      "e": 117801,
      "ty": 2,
      "x": 357,
      "y": 490
    },
    {
      "t": 129408,
      "e": 117901,
      "ty": 2,
      "x": 321,
      "y": 514
    },
    {
      "t": 129427,
      "e": 117920,
      "ty": 6,
      "x": 316,
      "y": 524,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129508,
      "e": 118001,
      "ty": 2,
      "x": 312,
      "y": 535
    },
    {
      "t": 129509,
      "e": 118002,
      "ty": 41,
      "x": 24157,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129609,
      "e": 118102,
      "ty": 2,
      "x": 308,
      "y": 549
    },
    {
      "t": 129708,
      "e": 118201,
      "ty": 2,
      "x": 305,
      "y": 552
    },
    {
      "t": 129759,
      "e": 118252,
      "ty": 41,
      "x": 23370,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129808,
      "e": 118301,
      "ty": 2,
      "x": 304,
      "y": 553
    },
    {
      "t": 129909,
      "e": 118402,
      "ty": 2,
      "x": 303,
      "y": 553
    },
    {
      "t": 130009,
      "e": 118502,
      "ty": 41,
      "x": 23145,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130209,
      "e": 118702,
      "ty": 2,
      "x": 307,
      "y": 553
    },
    {
      "t": 130258,
      "e": 118751,
      "ty": 41,
      "x": 24157,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130309,
      "e": 118802,
      "ty": 2,
      "x": 312,
      "y": 556
    },
    {
      "t": 131108,
      "e": 119601,
      "ty": 2,
      "x": 314,
      "y": 558
    },
    {
      "t": 131208,
      "e": 119701,
      "ty": 2,
      "x": 319,
      "y": 561
    },
    {
      "t": 131259,
      "e": 119752,
      "ty": 41,
      "x": 24832,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131309,
      "e": 119802,
      "ty": 2,
      "x": 303,
      "y": 569
    },
    {
      "t": 131408,
      "e": 119901,
      "ty": 2,
      "x": 291,
      "y": 576
    },
    {
      "t": 131509,
      "e": 120002,
      "ty": 2,
      "x": 286,
      "y": 578
    },
    {
      "t": 131509,
      "e": 120002,
      "ty": 41,
      "x": 21234,
      "y": 44713,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131609,
      "e": 120102,
      "ty": 2,
      "x": 287,
      "y": 581
    },
    {
      "t": 131708,
      "e": 120201,
      "ty": 2,
      "x": 300,
      "y": 582
    },
    {
      "t": 131758,
      "e": 120251,
      "ty": 41,
      "x": 23145,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131809,
      "e": 120302,
      "ty": 2,
      "x": 304,
      "y": 582
    },
    {
      "t": 131908,
      "e": 120401,
      "ty": 2,
      "x": 350,
      "y": 583
    },
    {
      "t": 132008,
      "e": 120501,
      "ty": 2,
      "x": 400,
      "y": 590
    },
    {
      "t": 132009,
      "e": 120502,
      "ty": 41,
      "x": 34049,
      "y": 54422,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132208,
      "e": 120701,
      "ty": 2,
      "x": 396,
      "y": 598
    },
    {
      "t": 132246,
      "e": 120739,
      "ty": 7,
      "x": 392,
      "y": 608,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132258,
      "e": 120751,
      "ty": 41,
      "x": 33150,
      "y": 63443,
      "ta": "#.strategy"
    },
    {
      "t": 132308,
      "e": 120801,
      "ty": 2,
      "x": 399,
      "y": 639
    },
    {
      "t": 132362,
      "e": 120855,
      "ty": 6,
      "x": 410,
      "y": 659,
      "ta": "#strategyButton"
    },
    {
      "t": 132409,
      "e": 120902,
      "ty": 2,
      "x": 411,
      "y": 665
    },
    {
      "t": 132508,
      "e": 121001,
      "ty": 2,
      "x": 411,
      "y": 667
    },
    {
      "t": 132509,
      "e": 121002,
      "ty": 41,
      "x": 39542,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 132652,
      "e": 121145,
      "ty": 3,
      "x": 411,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 132654,
      "e": 121146,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any events starting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line."
    },
    {
      "t": 132656,
      "e": 121148,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132656,
      "e": 121148,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 132746,
      "e": 121238,
      "ty": 4,
      "x": 39542,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 132758,
      "e": 121250,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 132759,
      "e": 121251,
      "ty": 5,
      "x": 411,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 132766,
      "e": 121258,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 133766,
      "e": 122258,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 134259,
      "e": 122751,
      "ty": 41,
      "x": 15049,
      "y": 36063,
      "ta": "html > body"
    },
    {
      "t": 134309,
      "e": 122801,
      "ty": 2,
      "x": 690,
      "y": 656
    },
    {
      "t": 134331,
      "e": 122823,
      "ty": 6,
      "x": 919,
      "y": 683,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 134408,
      "e": 122900,
      "ty": 2,
      "x": 985,
      "y": 687
    },
    {
      "t": 134498,
      "e": 122990,
      "ty": 7,
      "x": 988,
      "y": 664,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 134498,
      "e": 122990,
      "ty": 6,
      "x": 988,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134508,
      "e": 123000,
      "ty": 2,
      "x": 988,
      "y": 664
    },
    {
      "t": 134509,
      "e": 123001,
      "ty": 41,
      "x": 38931,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134531,
      "e": 123023,
      "ty": 7,
      "x": 988,
      "y": 644,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134609,
      "e": 123101,
      "ty": 2,
      "x": 971,
      "y": 598
    },
    {
      "t": 134666,
      "e": 123158,
      "ty": 6,
      "x": 962,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 134708,
      "e": 123200,
      "ty": 2,
      "x": 962,
      "y": 573
    },
    {
      "t": 134759,
      "e": 123251,
      "ty": 41,
      "x": 33308,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 134971,
      "e": 123463,
      "ty": 3,
      "x": 962,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 134972,
      "e": 123464,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135082,
      "e": 123574,
      "ty": 4,
      "x": 33091,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135083,
      "e": 123575,
      "ty": 5,
      "x": 961,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135108,
      "e": 123600,
      "ty": 2,
      "x": 961,
      "y": 573
    },
    {
      "t": 135259,
      "e": 123751,
      "ty": 41,
      "x": 33091,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136086,
      "e": 124578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 136086,
      "e": 124578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136174,
      "e": 124666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 136768,
      "e": 125260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 136768,
      "e": 125260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136847,
      "e": 125339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 137567,
      "e": 126059,
      "ty": 7,
      "x": 972,
      "y": 596,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 137583,
      "e": 126075,
      "ty": 6,
      "x": 1005,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 137600,
      "e": 126092,
      "ty": 7,
      "x": 1028,
      "y": 696,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 137608,
      "e": 126100,
      "ty": 2,
      "x": 1028,
      "y": 696
    },
    {
      "t": 137709,
      "e": 126201,
      "ty": 2,
      "x": 1044,
      "y": 719
    },
    {
      "t": 137759,
      "e": 126251,
      "ty": 41,
      "x": 35677,
      "y": 39387,
      "ta": "html > body"
    },
    {
      "t": 137809,
      "e": 126301,
      "ty": 2,
      "x": 1043,
      "y": 703
    },
    {
      "t": 137850,
      "e": 126342,
      "ty": 6,
      "x": 1031,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 137909,
      "e": 126401,
      "ty": 2,
      "x": 1029,
      "y": 662
    },
    {
      "t": 138009,
      "e": 126501,
      "ty": 2,
      "x": 1026,
      "y": 654
    },
    {
      "t": 138009,
      "e": 126501,
      "ty": 41,
      "x": 47150,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 138083,
      "e": 126575,
      "ty": 3,
      "x": 1026,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 138084,
      "e": 126576,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 138085,
      "e": 126577,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138086,
      "e": 126578,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 138162,
      "e": 126654,
      "ty": 4,
      "x": 47150,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 138163,
      "e": 126655,
      "ty": 5,
      "x": 1026,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 139063,
      "e": 127555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 139143,
      "e": 127635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 139639,
      "e": 128131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 139759,
      "e": 128251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 139759,
      "e": 128251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 139806,
      "e": 128298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 139806,
      "e": 128298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 139806,
      "e": 128298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 139870,
      "e": 128362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "UC"
    },
    {
      "t": 140008,
      "e": 128500,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140327,
      "e": 128819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "UC"
    },
    {
      "t": 140471,
      "e": 128963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 140551,
      "e": 129043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 140687,
      "e": 129179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 140743,
      "e": 129235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 140744,
      "e": 129236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 140814,
      "e": 129306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 140975,
      "e": 129467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 140976,
      "e": 129468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 141030,
      "e": 129522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 141061,
      "e": 129553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 141808,
      "e": 130300,
      "ty": 2,
      "x": 1007,
      "y": 665
    },
    {
      "t": 141820,
      "e": 130312,
      "ty": 7,
      "x": 1000,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 141853,
      "e": 130345,
      "ty": 6,
      "x": 992,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 141908,
      "e": 130400,
      "ty": 2,
      "x": 988,
      "y": 680
    },
    {
      "t": 142008,
      "e": 130500,
      "ty": 2,
      "x": 988,
      "y": 682
    },
    {
      "t": 142008,
      "e": 130500,
      "ty": 41,
      "x": 47456,
      "y": 11915,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142108,
      "e": 130600,
      "ty": 2,
      "x": 988,
      "y": 687
    },
    {
      "t": 142187,
      "e": 130679,
      "ty": 3,
      "x": 988,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142188,
      "e": 130680,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 142188,
      "e": 130680,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 142189,
      "e": 130681,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142258,
      "e": 130750,
      "ty": 41,
      "x": 47456,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142266,
      "e": 130758,
      "ty": 4,
      "x": 47456,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142266,
      "e": 130758,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142267,
      "e": 130759,
      "ty": 5,
      "x": 988,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142267,
      "e": 130759,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 142608,
      "e": 131100,
      "ty": 2,
      "x": 781,
      "y": 635
    },
    {
      "t": 142708,
      "e": 131200,
      "ty": 2,
      "x": 508,
      "y": 548
    },
    {
      "t": 142759,
      "e": 131251,
      "ty": 41,
      "x": 17218,
      "y": 29914,
      "ta": "html > body"
    },
    {
      "t": 142908,
      "e": 131400,
      "ty": 2,
      "x": 500,
      "y": 519
    },
    {
      "t": 143008,
      "e": 131500,
      "ty": 2,
      "x": 474,
      "y": 481
    },
    {
      "t": 143008,
      "e": 131500,
      "ty": 41,
      "x": 16047,
      "y": 26202,
      "ta": "html > body"
    },
    {
      "t": 143286,
      "e": 131778,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 143408,
      "e": 131900,
      "ty": 2,
      "x": 474,
      "y": 480
    },
    {
      "t": 143507,
      "e": 131999,
      "ty": 2,
      "x": 476,
      "y": 455
    },
    {
      "t": 143508,
      "e": 132000,
      "ty": 41,
      "x": 16116,
      "y": 24762,
      "ta": "html > body"
    },
    {
      "t": 143608,
      "e": 132100,
      "ty": 2,
      "x": 494,
      "y": 437
    },
    {
      "t": 143708,
      "e": 132200,
      "ty": 2,
      "x": 511,
      "y": 428
    },
    {
      "t": 143758,
      "e": 132250,
      "ty": 41,
      "x": 17459,
      "y": 23100,
      "ta": "html > body"
    },
    {
      "t": 143808,
      "e": 132300,
      "ty": 2,
      "x": 515,
      "y": 425
    },
    {
      "t": 143908,
      "e": 132400,
      "ty": 2,
      "x": 519,
      "y": 423
    },
    {
      "t": 144008,
      "e": 132500,
      "ty": 2,
      "x": 520,
      "y": 423
    },
    {
      "t": 144009,
      "e": 132501,
      "ty": 41,
      "x": 17632,
      "y": 22989,
      "ta": "html > body"
    },
    {
      "t": 144512,
      "e": 133004,
      "ty": 2,
      "x": 564,
      "y": 401
    },
    {
      "t": 144512,
      "e": 133004,
      "ty": 41,
      "x": 19147,
      "y": 21771,
      "ta": "html > body"
    },
    {
      "t": 144611,
      "e": 133103,
      "ty": 2,
      "x": 897,
      "y": 272
    },
    {
      "t": 144761,
      "e": 133253,
      "ty": 41,
      "x": 57561,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 144812,
      "e": 133304,
      "ty": 2,
      "x": 894,
      "y": 244
    },
    {
      "t": 144912,
      "e": 133404,
      "ty": 2,
      "x": 868,
      "y": 233
    },
    {
      "t": 144977,
      "e": 133469,
      "ty": 6,
      "x": 831,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 144994,
      "e": 133486,
      "ty": 7,
      "x": 824,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 145011,
      "e": 133503,
      "ty": 2,
      "x": 820,
      "y": 238
    },
    {
      "t": 145012,
      "e": 133504,
      "ty": 41,
      "x": 27963,
      "y": 12741,
      "ta": "html > body"
    },
    {
      "t": 145111,
      "e": 133603,
      "ty": 2,
      "x": 812,
      "y": 240
    },
    {
      "t": 145262,
      "e": 133754,
      "ty": 41,
      "x": 27653,
      "y": 12685,
      "ta": "html > body"
    },
    {
      "t": 145312,
      "e": 133804,
      "ty": 2,
      "x": 814,
      "y": 231
    },
    {
      "t": 145412,
      "e": 133904,
      "ty": 2,
      "x": 821,
      "y": 230
    },
    {
      "t": 145512,
      "e": 134004,
      "ty": 2,
      "x": 821,
      "y": 237
    },
    {
      "t": 145512,
      "e": 134004,
      "ty": 41,
      "x": 0,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 145712,
      "e": 134204,
      "ty": 2,
      "x": 821,
      "y": 239
    },
    {
      "t": 145762,
      "e": 134254,
      "ty": 41,
      "x": 473,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 145812,
      "e": 134304,
      "ty": 2,
      "x": 824,
      "y": 240
    },
    {
      "t": 145903,
      "e": 134395,
      "ty": 6,
      "x": 826,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 145912,
      "e": 134404,
      "ty": 2,
      "x": 826,
      "y": 242
    },
    {
      "t": 145951,
      "e": 134443,
      "ty": 7,
      "x": 830,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 146011,
      "e": 134503,
      "ty": 2,
      "x": 846,
      "y": 269
    },
    {
      "t": 146012,
      "e": 134504,
      "ty": 41,
      "x": 18719,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 146111,
      "e": 134603,
      "ty": 2,
      "x": 849,
      "y": 280
    },
    {
      "t": 146213,
      "e": 134705,
      "ty": 2,
      "x": 847,
      "y": 286
    },
    {
      "t": 146262,
      "e": 134754,
      "ty": 41,
      "x": 7075,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 146312,
      "e": 134804,
      "ty": 2,
      "x": 835,
      "y": 310
    },
    {
      "t": 146512,
      "e": 135004,
      "ty": 41,
      "x": 3222,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 146612,
      "e": 135104,
      "ty": 2,
      "x": 835,
      "y": 304
    },
    {
      "t": 146663,
      "e": 135155,
      "ty": 6,
      "x": 835,
      "y": 299,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 146712,
      "e": 135204,
      "ty": 2,
      "x": 834,
      "y": 296
    },
    {
      "t": 146762,
      "e": 135254,
      "ty": 41,
      "x": 33161,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 146812,
      "e": 135304,
      "ty": 2,
      "x": 833,
      "y": 295
    },
    {
      "t": 146894,
      "e": 135386,
      "ty": 3,
      "x": 833,
      "y": 295,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 146894,
      "e": 135386,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 146990,
      "e": 135482,
      "ty": 4,
      "x": 33161,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 146990,
      "e": 135482,
      "ty": 5,
      "x": 833,
      "y": 295,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 146991,
      "e": 135483,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 147212,
      "e": 135704,
      "ty": 2,
      "x": 835,
      "y": 294
    },
    {
      "t": 147262,
      "e": 135704,
      "ty": 41,
      "x": 43243,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 147411,
      "e": 135853,
      "ty": 2,
      "x": 836,
      "y": 294
    },
    {
      "t": 147445,
      "e": 135887,
      "ty": 7,
      "x": 837,
      "y": 301,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 147478,
      "e": 135920,
      "ty": 6,
      "x": 836,
      "y": 316,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 147512,
      "e": 135954,
      "ty": 2,
      "x": 836,
      "y": 325
    },
    {
      "t": 147512,
      "e": 135954,
      "ty": 41,
      "x": 48284,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 147512,
      "e": 135954,
      "ty": 7,
      "x": 836,
      "y": 329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 147611,
      "e": 136053,
      "ty": 2,
      "x": 831,
      "y": 348
    },
    {
      "t": 147712,
      "e": 136154,
      "ty": 2,
      "x": 826,
      "y": 369
    },
    {
      "t": 147763,
      "e": 136205,
      "ty": 41,
      "x": 1323,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 147779,
      "e": 136221,
      "ty": 6,
      "x": 831,
      "y": 414,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 147812,
      "e": 136254,
      "ty": 2,
      "x": 836,
      "y": 419
    },
    {
      "t": 147813,
      "e": 136255,
      "ty": 7,
      "x": 842,
      "y": 423,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 147912,
      "e": 136354,
      "ty": 2,
      "x": 921,
      "y": 431
    },
    {
      "t": 148012,
      "e": 136454,
      "ty": 2,
      "x": 934,
      "y": 426
    },
    {
      "t": 148012,
      "e": 136454,
      "ty": 41,
      "x": 26717,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 148412,
      "e": 136854,
      "ty": 2,
      "x": 923,
      "y": 425
    },
    {
      "t": 148512,
      "e": 136954,
      "ty": 2,
      "x": 849,
      "y": 443
    },
    {
      "t": 148512,
      "e": 136954,
      "ty": 41,
      "x": 22028,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 148528,
      "e": 136970,
      "ty": 6,
      "x": 839,
      "y": 448,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 148544,
      "e": 136986,
      "ty": 7,
      "x": 834,
      "y": 450,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 148612,
      "e": 137054,
      "ty": 2,
      "x": 825,
      "y": 456
    },
    {
      "t": 148712,
      "e": 137154,
      "ty": 2,
      "x": 824,
      "y": 460
    },
    {
      "t": 148762,
      "e": 137204,
      "ty": 41,
      "x": 2725,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 148812,
      "e": 137254,
      "ty": 2,
      "x": 824,
      "y": 471
    },
    {
      "t": 148912,
      "e": 137354,
      "ty": 2,
      "x": 825,
      "y": 474
    },
    {
      "t": 149013,
      "e": 137455,
      "ty": 41,
      "x": 3782,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 149095,
      "e": 137537,
      "ty": 6,
      "x": 826,
      "y": 474,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 149111,
      "e": 137553,
      "ty": 2,
      "x": 826,
      "y": 474
    },
    {
      "t": 149211,
      "e": 137653,
      "ty": 2,
      "x": 829,
      "y": 474
    },
    {
      "t": 149262,
      "e": 137704,
      "ty": 41,
      "x": 12996,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 149335,
      "e": 137777,
      "ty": 3,
      "x": 829,
      "y": 474,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 149336,
      "e": 137778,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 149337,
      "e": 137779,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 149438,
      "e": 137880,
      "ty": 4,
      "x": 12996,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 149438,
      "e": 137880,
      "ty": 5,
      "x": 829,
      "y": 474,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 149439,
      "e": 137881,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 149663,
      "e": 138105,
      "ty": 7,
      "x": 830,
      "y": 478,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 149681,
      "e": 138123,
      "ty": 6,
      "x": 832,
      "y": 494,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 149698,
      "e": 138140,
      "ty": 7,
      "x": 837,
      "y": 521,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 149698,
      "e": 138140,
      "ty": 6,
      "x": 837,
      "y": 521,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 149712,
      "e": 138154,
      "ty": 2,
      "x": 837,
      "y": 521
    },
    {
      "t": 149714,
      "e": 138156,
      "ty": 7,
      "x": 843,
      "y": 542,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 149762,
      "e": 138156,
      "ty": 41,
      "x": 6544,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 149812,
      "e": 138206,
      "ty": 2,
      "x": 852,
      "y": 618
    },
    {
      "t": 149911,
      "e": 138305,
      "ty": 2,
      "x": 851,
      "y": 635
    },
    {
      "t": 150012,
      "e": 138406,
      "ty": 41,
      "x": 7019,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 151212,
      "e": 139606,
      "ty": 2,
      "x": 851,
      "y": 641
    },
    {
      "t": 151262,
      "e": 139656,
      "ty": 41,
      "x": 7404,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 151312,
      "e": 139706,
      "ty": 2,
      "x": 844,
      "y": 693
    },
    {
      "t": 151365,
      "e": 139759,
      "ty": 6,
      "x": 839,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 151412,
      "e": 139806,
      "ty": 2,
      "x": 838,
      "y": 707
    },
    {
      "t": 151512,
      "e": 139906,
      "ty": 41,
      "x": 58367,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 151883,
      "e": 140277,
      "ty": 7,
      "x": 838,
      "y": 693,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 151912,
      "e": 140306,
      "ty": 2,
      "x": 838,
      "y": 688
    },
    {
      "t": 152011,
      "e": 140405,
      "ty": 2,
      "x": 837,
      "y": 684
    },
    {
      "t": 152012,
      "e": 140406,
      "ty": 41,
      "x": 4182,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 152335,
      "e": 140729,
      "ty": 6,
      "x": 836,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 152412,
      "e": 140806,
      "ty": 2,
      "x": 836,
      "y": 676
    },
    {
      "t": 152513,
      "e": 140907,
      "ty": 41,
      "x": 48284,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 153512,
      "e": 141906,
      "ty": 2,
      "x": 836,
      "y": 675
    },
    {
      "t": 153512,
      "e": 141906,
      "ty": 41,
      "x": 48284,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 153551,
      "e": 141945,
      "ty": 7,
      "x": 836,
      "y": 685,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 153583,
      "e": 141977,
      "ty": 6,
      "x": 837,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 153612,
      "e": 142006,
      "ty": 2,
      "x": 838,
      "y": 702
    },
    {
      "t": 153617,
      "e": 142011,
      "ty": 7,
      "x": 840,
      "y": 715,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 153712,
      "e": 142106,
      "ty": 2,
      "x": 865,
      "y": 796
    },
    {
      "t": 153763,
      "e": 142157,
      "ty": 41,
      "x": 18173,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 153812,
      "e": 142206,
      "ty": 2,
      "x": 908,
      "y": 873
    },
    {
      "t": 154012,
      "e": 142406,
      "ty": 2,
      "x": 874,
      "y": 851
    },
    {
      "t": 154012,
      "e": 142406,
      "ty": 41,
      "x": 37044,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 154112,
      "e": 142506,
      "ty": 2,
      "x": 857,
      "y": 838
    },
    {
      "t": 154212,
      "e": 142606,
      "ty": 2,
      "x": 847,
      "y": 823
    },
    {
      "t": 154262,
      "e": 142656,
      "ty": 41,
      "x": 13326,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 154312,
      "e": 142706,
      "ty": 2,
      "x": 840,
      "y": 812
    },
    {
      "t": 154412,
      "e": 142806,
      "ty": 2,
      "x": 840,
      "y": 811
    },
    {
      "t": 154512,
      "e": 142906,
      "ty": 2,
      "x": 840,
      "y": 815
    },
    {
      "t": 154512,
      "e": 142906,
      "ty": 41,
      "x": 10965,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 154612,
      "e": 143006,
      "ty": 2,
      "x": 840,
      "y": 820
    },
    {
      "t": 154763,
      "e": 143157,
      "ty": 41,
      "x": 10965,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 156712,
      "e": 145106,
      "ty": 2,
      "x": 828,
      "y": 832
    },
    {
      "t": 156762,
      "e": 145156,
      "ty": 41,
      "x": 3225,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 156813,
      "e": 145207,
      "ty": 2,
      "x": 826,
      "y": 833
    },
    {
      "t": 156912,
      "e": 145306,
      "ty": 2,
      "x": 824,
      "y": 833
    },
    {
      "t": 157012,
      "e": 145406,
      "ty": 2,
      "x": 822,
      "y": 809
    },
    {
      "t": 157012,
      "e": 145406,
      "ty": 41,
      "x": 341,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 157112,
      "e": 145506,
      "ty": 2,
      "x": 822,
      "y": 807
    },
    {
      "t": 157262,
      "e": 145656,
      "ty": 41,
      "x": 341,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 157312,
      "e": 145706,
      "ty": 2,
      "x": 822,
      "y": 809
    },
    {
      "t": 157412,
      "e": 145806,
      "ty": 2,
      "x": 822,
      "y": 815
    },
    {
      "t": 157513,
      "e": 145907,
      "ty": 2,
      "x": 823,
      "y": 820
    },
    {
      "t": 157513,
      "e": 145907,
      "ty": 41,
      "x": 931,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 157613,
      "e": 146007,
      "ty": 2,
      "x": 824,
      "y": 821
    },
    {
      "t": 157719,
      "e": 146113,
      "ty": 6,
      "x": 827,
      "y": 820,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 157762,
      "e": 146156,
      "ty": 41,
      "x": 23079,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 157813,
      "e": 146207,
      "ty": 2,
      "x": 831,
      "y": 818
    },
    {
      "t": 157912,
      "e": 146306,
      "ty": 2,
      "x": 836,
      "y": 820
    },
    {
      "t": 157921,
      "e": 146315,
      "ty": 7,
      "x": 837,
      "y": 821,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 158012,
      "e": 146406,
      "ty": 2,
      "x": 834,
      "y": 829
    },
    {
      "t": 158013,
      "e": 146407,
      "ty": 41,
      "x": 2985,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 158113,
      "e": 146507,
      "ty": 2,
      "x": 834,
      "y": 830
    },
    {
      "t": 158213,
      "e": 146607,
      "ty": 2,
      "x": 834,
      "y": 831
    },
    {
      "t": 158255,
      "e": 146608,
      "ty": 6,
      "x": 834,
      "y": 837,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 158262,
      "e": 146615,
      "ty": 41,
      "x": 38202,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 158312,
      "e": 146665,
      "ty": 2,
      "x": 834,
      "y": 840
    },
    {
      "t": 158454,
      "e": 146807,
      "ty": 7,
      "x": 834,
      "y": 828,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 158488,
      "e": 146841,
      "ty": 6,
      "x": 836,
      "y": 817,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 158512,
      "e": 146865,
      "ty": 2,
      "x": 837,
      "y": 812
    },
    {
      "t": 158513,
      "e": 146866,
      "ty": 41,
      "x": 53325,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 158612,
      "e": 146965,
      "ty": 2,
      "x": 838,
      "y": 809
    },
    {
      "t": 158763,
      "e": 147116,
      "ty": 41,
      "x": 58367,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 158775,
      "e": 147128,
      "ty": 3,
      "x": 838,
      "y": 809,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 158776,
      "e": 147129,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 158777,
      "e": 147130,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 158869,
      "e": 147222,
      "ty": 4,
      "x": 58367,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 158869,
      "e": 147222,
      "ty": 5,
      "x": 838,
      "y": 809,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 158870,
      "e": 147223,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf",
      "v": "Humanities"
    },
    {
      "t": 159112,
      "e": 147465,
      "ty": 2,
      "x": 838,
      "y": 820
    },
    {
      "t": 159121,
      "e": 147474,
      "ty": 7,
      "x": 834,
      "y": 831,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 159213,
      "e": 147566,
      "ty": 2,
      "x": 825,
      "y": 885
    },
    {
      "t": 159262,
      "e": 147615,
      "ty": 41,
      "x": 849,
      "y": 15123,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 159313,
      "e": 147666,
      "ty": 2,
      "x": 826,
      "y": 919
    },
    {
      "t": 159406,
      "e": 147759,
      "ty": 6,
      "x": 829,
      "y": 928,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 159412,
      "e": 147765,
      "ty": 2,
      "x": 829,
      "y": 928
    },
    {
      "t": 159512,
      "e": 147865,
      "ty": 2,
      "x": 830,
      "y": 929
    },
    {
      "t": 159512,
      "e": 147865,
      "ty": 41,
      "x": 18037,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 159612,
      "e": 147965,
      "ty": 2,
      "x": 830,
      "y": 934
    },
    {
      "t": 159656,
      "e": 148009,
      "ty": 7,
      "x": 829,
      "y": 949,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 159712,
      "e": 148065,
      "ty": 2,
      "x": 825,
      "y": 956
    },
    {
      "t": 159762,
      "e": 148115,
      "ty": 41,
      "x": 2894,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 159812,
      "e": 148165,
      "ty": 2,
      "x": 825,
      "y": 964
    },
    {
      "t": 159966,
      "e": 148319,
      "ty": 3,
      "x": 825,
      "y": 964,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 159968,
      "e": 148321,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 160062,
      "e": 148415,
      "ty": 4,
      "x": 2894,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 160062,
      "e": 148415,
      "ty": 5,
      "x": 825,
      "y": 964,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 160062,
      "e": 148415,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 160062,
      "e": 148415,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 160212,
      "e": 148565,
      "ty": 2,
      "x": 825,
      "y": 965
    },
    {
      "t": 160231,
      "e": 148584,
      "ty": 6,
      "x": 827,
      "y": 965,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 160262,
      "e": 148615,
      "ty": 41,
      "x": 2914,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 160313,
      "e": 148666,
      "ty": 2,
      "x": 827,
      "y": 965
    },
    {
      "t": 160374,
      "e": 148727,
      "ty": 7,
      "x": 831,
      "y": 972,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 160412,
      "e": 148765,
      "ty": 2,
      "x": 841,
      "y": 989
    },
    {
      "t": 160439,
      "e": 148792,
      "ty": 6,
      "x": 880,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 160513,
      "e": 148866,
      "ty": 2,
      "x": 902,
      "y": 1033
    },
    {
      "t": 160513,
      "e": 148866,
      "ty": 41,
      "x": 37406,
      "y": 55605,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 160762,
      "e": 149115,
      "ty": 41,
      "x": 37406,
      "y": 53619,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 160812,
      "e": 149165,
      "ty": 2,
      "x": 902,
      "y": 1031
    },
    {
      "t": 160863,
      "e": 149216,
      "ty": 3,
      "x": 902,
      "y": 1031,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 160864,
      "e": 149217,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 160865,
      "e": 149218,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 160949,
      "e": 149302,
      "ty": 4,
      "x": 37406,
      "y": 51633,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 160949,
      "e": 149302,
      "ty": 5,
      "x": 902,
      "y": 1031,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 160952,
      "e": 149305,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 160953,
      "e": 149306,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 160954,
      "e": 149307,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 161012,
      "e": 149365,
      "ty": 41,
      "x": 30787,
      "y": 56671,
      "ta": "html > body"
    },
    {
      "t": 161212,
      "e": 149565,
      "ty": 2,
      "x": 1079,
      "y": 897
    },
    {
      "t": 161262,
      "e": 149615,
      "ty": 41,
      "x": 43735,
      "y": 41824,
      "ta": "html > body"
    },
    {
      "t": 161312,
      "e": 149665,
      "ty": 2,
      "x": 1360,
      "y": 689
    },
    {
      "t": 161413,
      "e": 149766,
      "ty": 2,
      "x": 1374,
      "y": 665
    },
    {
      "t": 161512,
      "e": 149865,
      "ty": 2,
      "x": 1374,
      "y": 664
    },
    {
      "t": 161512,
      "e": 149865,
      "ty": 41,
      "x": 47041,
      "y": 36340,
      "ta": "html > body"
    },
    {
      "t": 162290,
      "e": 150643,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 163013,
      "e": 151366,
      "ty": 2,
      "x": 1192,
      "y": 882
    },
    {
      "t": 163013,
      "e": 151366,
      "ty": 41,
      "x": 44205,
      "y": 22271,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 163112,
      "e": 151465,
      "ty": 2,
      "x": 1084,
      "y": 967
    },
    {
      "t": 163212,
      "e": 151565,
      "ty": 2,
      "x": 1037,
      "y": 998
    },
    {
      "t": 163262,
      "e": 151615,
      "ty": 41,
      "x": 35596,
      "y": 64240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 163312,
      "e": 151665,
      "ty": 2,
      "x": 1014,
      "y": 1071
    },
    {
      "t": 163326,
      "e": 151679,
      "ty": 6,
      "x": 1013,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 163412,
      "e": 151765,
      "ty": 2,
      "x": 1011,
      "y": 1097
    },
    {
      "t": 163513,
      "e": 151866,
      "ty": 41,
      "x": 55431,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 163612,
      "e": 151965,
      "ty": 2,
      "x": 1010,
      "y": 1097
    },
    {
      "t": 163763,
      "e": 151965,
      "ty": 41,
      "x": 54885,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 164812,
      "e": 153014,
      "ty": 2,
      "x": 1006,
      "y": 1094
    },
    {
      "t": 164827,
      "e": 153029,
      "ty": 7,
      "x": 989,
      "y": 1061,
      "ta": "#start"
    },
    {
      "t": 164913,
      "e": 153115,
      "ty": 2,
      "x": 883,
      "y": 953
    },
    {
      "t": 165011,
      "e": 153213,
      "ty": 2,
      "x": 832,
      "y": 944
    },
    {
      "t": 165012,
      "e": 153214,
      "ty": 41,
      "x": 26494,
      "y": 56623,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 165112,
      "e": 153314,
      "ty": 2,
      "x": 826,
      "y": 943
    },
    {
      "t": 165262,
      "e": 153464,
      "ty": 41,
      "x": 26199,
      "y": 56554,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 165762,
      "e": 153964,
      "ty": 41,
      "x": 26445,
      "y": 55931,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 165812,
      "e": 154014,
      "ty": 2,
      "x": 831,
      "y": 928
    },
    {
      "t": 166012,
      "e": 154214,
      "ty": 41,
      "x": 26445,
      "y": 55515,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 168011,
      "e": 156213,
      "ty": 2,
      "x": 831,
      "y": 931
    },
    {
      "t": 168013,
      "e": 156215,
      "ty": 41,
      "x": 26445,
      "y": 55723,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 168112,
      "e": 156314,
      "ty": 2,
      "x": 830,
      "y": 933
    },
    {
      "t": 168262,
      "e": 156464,
      "ty": 41,
      "x": 26396,
      "y": 55862,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 170011,
      "e": 158213,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 247616,
      "e": 161464,
      "ty": 2,
      "x": 838,
      "y": 1004
    },
    {
      "t": 247715,
      "e": 161563,
      "ty": 2,
      "x": 850,
      "y": 1035
    },
    {
      "t": 247765,
      "e": 161613,
      "ty": 41,
      "x": 27478,
      "y": 63063,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 247816,
      "e": 161664,
      "ty": 2,
      "x": 855,
      "y": 1039
    },
    {
      "t": 247916,
      "e": 161764,
      "ty": 2,
      "x": 878,
      "y": 1037
    },
    {
      "t": 248015,
      "e": 161863,
      "ty": 2,
      "x": 929,
      "y": 1059
    },
    {
      "t": 248016,
      "e": 161864,
      "ty": 41,
      "x": 31266,
      "y": 64587,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 248116,
      "e": 161964,
      "ty": 2,
      "x": 944,
      "y": 1071
    },
    {
      "t": 248125,
      "e": 161973,
      "ty": 6,
      "x": 944,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 248215,
      "e": 162063,
      "ty": 2,
      "x": 957,
      "y": 1089
    },
    {
      "t": 248266,
      "e": 162114,
      "ty": 41,
      "x": 31948,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 248315,
      "e": 162163,
      "ty": 2,
      "x": 968,
      "y": 1099
    },
    {
      "t": 248516,
      "e": 162364,
      "ty": 41,
      "x": 31948,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 249378,
      "e": 163226,
      "ty": 3,
      "x": 968,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 249379,
      "e": 163227,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 249512,
      "e": 163360,
      "ty": 4,
      "x": 31948,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 249513,
      "e": 163361,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 249513,
      "e": 163361,
      "ty": 5,
      "x": 968,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 249514,
      "e": 163362,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 250538,
      "e": 164386,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 250869,
      "e": 164717,
      "ty": 2,
      "x": 1331,
      "y": 743
    },
    {
      "t": 250869,
      "e": 164717,
      "ty": 41,
      "x": 41339,
      "y": 32832,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 251467,
      "e": 165315,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 162165, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 162172, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 4925, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 168435, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 17948, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"CHARLIE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 187390, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 22446, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 210918, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 13857, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 225778, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 68595, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 295738, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:920,y:785,t:1526929868211};\\\", \\\"{x:920,y:784,t:1526929868234};\\\", \\\"{x:920,y:782,t:1526929868282};\\\", \\\"{x:921,y:780,t:1526929868306};\\\", \\\"{x:921,y:779,t:1526929868331};\\\", \\\"{x:921,y:778,t:1526929868348};\\\", \\\"{x:921,y:777,t:1526929868378};\\\", \\\"{x:921,y:776,t:1526929868394};\\\", \\\"{x:921,y:775,t:1526929868434};\\\", \\\"{x:921,y:774,t:1526929868555};\\\", \\\"{x:921,y:773,t:1526929868618};\\\", \\\"{x:921,y:772,t:1526929868631};\\\", \\\"{x:921,y:771,t:1526929868675};\\\", \\\"{x:921,y:770,t:1526929868682};\\\", \\\"{x:921,y:769,t:1526929868698};\\\", \\\"{x:921,y:768,t:1526929868818};\\\", \\\"{x:921,y:767,t:1526929868832};\\\", \\\"{x:921,y:766,t:1526929868848};\\\", \\\"{x:921,y:765,t:1526929868865};\\\", \\\"{x:921,y:764,t:1526929868882};\\\", \\\"{x:921,y:763,t:1526929868897};\\\", \\\"{x:920,y:763,t:1526929868915};\\\", \\\"{x:920,y:762,t:1526929868946};\\\", \\\"{x:920,y:761,t:1526929868962};\\\", \\\"{x:920,y:760,t:1526929868970};\\\", \\\"{x:920,y:759,t:1526929868981};\\\", \\\"{x:920,y:758,t:1526929869010};\\\", \\\"{x:920,y:752,t:1526929882245};\\\", \\\"{x:912,y:736,t:1526929882261};\\\", \\\"{x:907,y:730,t:1526929882279};\\\", \\\"{x:904,y:727,t:1526929882295};\\\", \\\"{x:901,y:724,t:1526929882312};\\\", \\\"{x:899,y:724,t:1526929882328};\\\", \\\"{x:896,y:721,t:1526929882344};\\\", \\\"{x:895,y:720,t:1526929882365};\\\", \\\"{x:894,y:720,t:1526929882380};\\\", \\\"{x:889,y:717,t:1526929884901};\\\", \\\"{x:874,y:711,t:1526929884913};\\\", \\\"{x:819,y:689,t:1526929884930};\\\", \\\"{x:763,y:671,t:1526929884947};\\\", \\\"{x:715,y:664,t:1526929884964};\\\", \\\"{x:672,y:655,t:1526929884979};\\\", \\\"{x:611,y:639,t:1526929884998};\\\", \\\"{x:582,y:631,t:1526929885014};\\\", \\\"{x:557,y:624,t:1526929885030};\\\", \\\"{x:535,y:617,t:1526929885049};\\\", \\\"{x:516,y:612,t:1526929885065};\\\", \\\"{x:502,y:608,t:1526929885081};\\\", \\\"{x:493,y:605,t:1526929885099};\\\", \\\"{x:491,y:604,t:1526929885114};\\\", \\\"{x:489,y:603,t:1526929885196};\\\", \\\"{x:487,y:601,t:1526929885212};\\\", \\\"{x:484,y:600,t:1526929885219};\\\", \\\"{x:481,y:597,t:1526929885231};\\\", \\\"{x:471,y:593,t:1526929885248};\\\", \\\"{x:458,y:583,t:1526929885264};\\\", \\\"{x:446,y:573,t:1526929885282};\\\", \\\"{x:430,y:561,t:1526929885298};\\\", \\\"{x:415,y:548,t:1526929885315};\\\", \\\"{x:405,y:539,t:1526929885332};\\\", \\\"{x:391,y:519,t:1526929885348};\\\", \\\"{x:385,y:507,t:1526929885366};\\\", \\\"{x:379,y:496,t:1526929885382};\\\", \\\"{x:376,y:490,t:1526929885398};\\\", \\\"{x:374,y:488,t:1526929885415};\\\", \\\"{x:374,y:489,t:1526929885524};\\\", \\\"{x:374,y:492,t:1526929885532};\\\", \\\"{x:376,y:496,t:1526929885548};\\\", \\\"{x:379,y:501,t:1526929885566};\\\", \\\"{x:380,y:503,t:1526929885583};\\\", \\\"{x:382,y:504,t:1526929885598};\\\", \\\"{x:382,y:506,t:1526929885616};\\\", \\\"{x:382,y:508,t:1526929885632};\\\", \\\"{x:382,y:510,t:1526929885648};\\\", \\\"{x:383,y:512,t:1526929885665};\\\", \\\"{x:383,y:513,t:1526929885682};\\\", \\\"{x:383,y:514,t:1526929885885};\\\", \\\"{x:383,y:516,t:1526929885899};\\\", \\\"{x:383,y:519,t:1526929885915};\\\", \\\"{x:383,y:521,t:1526929885932};\\\", \\\"{x:383,y:522,t:1526929885948};\\\", \\\"{x:383,y:524,t:1526929886700};\\\", \\\"{x:390,y:546,t:1526929886717};\\\", \\\"{x:418,y:585,t:1526929886732};\\\", \\\"{x:455,y:629,t:1526929886750};\\\", \\\"{x:497,y:674,t:1526929886767};\\\", \\\"{x:561,y:719,t:1526929886783};\\\", \\\"{x:645,y:775,t:1526929886799};\\\", \\\"{x:730,y:828,t:1526929886817};\\\", \\\"{x:813,y:867,t:1526929886832};\\\", \\\"{x:890,y:897,t:1526929886849};\\\", \\\"{x:950,y:919,t:1526929886866};\\\", \\\"{x:989,y:932,t:1526929886882};\\\", \\\"{x:1014,y:936,t:1526929886900};\\\", \\\"{x:1021,y:938,t:1526929886917};\\\", \\\"{x:1022,y:938,t:1526929886965};\\\", \\\"{x:1022,y:937,t:1526929886998};\\\", \\\"{x:1022,y:935,t:1526929887005};\\\", \\\"{x:1022,y:934,t:1526929887016};\\\", \\\"{x:1021,y:930,t:1526929887033};\\\", \\\"{x:1020,y:928,t:1526929887049};\\\", \\\"{x:1020,y:927,t:1526929887068};\\\", \\\"{x:1020,y:926,t:1526929887083};\\\", \\\"{x:1019,y:925,t:1526929887099};\\\", \\\"{x:1018,y:923,t:1526929887116};\\\", \\\"{x:1018,y:922,t:1526929887140};\\\", \\\"{x:1018,y:920,t:1526929888214};\\\", \\\"{x:1019,y:916,t:1526929888222};\\\", \\\"{x:1024,y:913,t:1526929888234};\\\", \\\"{x:1035,y:908,t:1526929888251};\\\", \\\"{x:1049,y:902,t:1526929888268};\\\", \\\"{x:1070,y:893,t:1526929888284};\\\", \\\"{x:1119,y:890,t:1526929888301};\\\", \\\"{x:1150,y:890,t:1526929888317};\\\", \\\"{x:1182,y:887,t:1526929888334};\\\", \\\"{x:1202,y:887,t:1526929888351};\\\", \\\"{x:1221,y:887,t:1526929888368};\\\", \\\"{x:1240,y:887,t:1526929888384};\\\", \\\"{x:1259,y:887,t:1526929888400};\\\", \\\"{x:1269,y:887,t:1526929888418};\\\", \\\"{x:1274,y:887,t:1526929888435};\\\", \\\"{x:1275,y:887,t:1526929888451};\\\", \\\"{x:1277,y:888,t:1526929888468};\\\", \\\"{x:1289,y:896,t:1526929888485};\\\", \\\"{x:1299,y:906,t:1526929888501};\\\", \\\"{x:1307,y:920,t:1526929888518};\\\", \\\"{x:1309,y:928,t:1526929888535};\\\", \\\"{x:1312,y:933,t:1526929888551};\\\", \\\"{x:1314,y:935,t:1526929888568};\\\", \\\"{x:1314,y:937,t:1526929888585};\\\", \\\"{x:1314,y:938,t:1526929888601};\\\", \\\"{x:1314,y:940,t:1526929888618};\\\", \\\"{x:1310,y:943,t:1526929888635};\\\", \\\"{x:1305,y:944,t:1526929888651};\\\", \\\"{x:1299,y:946,t:1526929888668};\\\", \\\"{x:1294,y:948,t:1526929888685};\\\", \\\"{x:1292,y:948,t:1526929888717};\\\", \\\"{x:1291,y:948,t:1526929888735};\\\", \\\"{x:1289,y:948,t:1526929888752};\\\", \\\"{x:1289,y:949,t:1526929888837};\\\", \\\"{x:1288,y:949,t:1526929888851};\\\", \\\"{x:1287,y:951,t:1526929888868};\\\", \\\"{x:1284,y:955,t:1526929888885};\\\", \\\"{x:1283,y:956,t:1526929888902};\\\", \\\"{x:1282,y:958,t:1526929888918};\\\", \\\"{x:1281,y:959,t:1526929888935};\\\", \\\"{x:1280,y:961,t:1526929888952};\\\", \\\"{x:1280,y:962,t:1526929888968};\\\", \\\"{x:1279,y:963,t:1526929888985};\\\", \\\"{x:1278,y:965,t:1526929889002};\\\", \\\"{x:1278,y:960,t:1526929892685};\\\", \\\"{x:1278,y:952,t:1526929892692};\\\", \\\"{x:1278,y:941,t:1526929892704};\\\", \\\"{x:1278,y:907,t:1526929892721};\\\", \\\"{x:1273,y:877,t:1526929892738};\\\", \\\"{x:1268,y:855,t:1526929892754};\\\", \\\"{x:1269,y:847,t:1526929892771};\\\", \\\"{x:1269,y:846,t:1526929892789};\\\", \\\"{x:1272,y:840,t:1526929892804};\\\", \\\"{x:1273,y:832,t:1526929892821};\\\", \\\"{x:1274,y:830,t:1526929892838};\\\", \\\"{x:1275,y:827,t:1526929892854};\\\", \\\"{x:1275,y:825,t:1526929892871};\\\", \\\"{x:1275,y:824,t:1526929892888};\\\", \\\"{x:1274,y:825,t:1526929893285};\\\", \\\"{x:1272,y:828,t:1526929893293};\\\", \\\"{x:1271,y:830,t:1526929893305};\\\", \\\"{x:1270,y:832,t:1526929893321};\\\", \\\"{x:1268,y:834,t:1526929893338};\\\", \\\"{x:1266,y:836,t:1526929893355};\\\", \\\"{x:1263,y:843,t:1526929893371};\\\", \\\"{x:1260,y:849,t:1526929893388};\\\", \\\"{x:1257,y:861,t:1526929893404};\\\", \\\"{x:1255,y:876,t:1526929893421};\\\", \\\"{x:1254,y:895,t:1526929893438};\\\", \\\"{x:1252,y:907,t:1526929893455};\\\", \\\"{x:1249,y:915,t:1526929893471};\\\", \\\"{x:1246,y:921,t:1526929893488};\\\", \\\"{x:1241,y:928,t:1526929893506};\\\", \\\"{x:1240,y:934,t:1526929893522};\\\", \\\"{x:1237,y:940,t:1526929893538};\\\", \\\"{x:1237,y:948,t:1526929893555};\\\", \\\"{x:1235,y:950,t:1526929893571};\\\", \\\"{x:1234,y:954,t:1526929893589};\\\", \\\"{x:1230,y:957,t:1526929893605};\\\", \\\"{x:1228,y:958,t:1526929893621};\\\", \\\"{x:1226,y:959,t:1526929893638};\\\", \\\"{x:1225,y:960,t:1526929893669};\\\", \\\"{x:1224,y:960,t:1526929893685};\\\", \\\"{x:1223,y:960,t:1526929895245};\\\", \\\"{x:1224,y:958,t:1526929895256};\\\", \\\"{x:1231,y:957,t:1526929895273};\\\", \\\"{x:1236,y:955,t:1526929895289};\\\", \\\"{x:1248,y:953,t:1526929895307};\\\", \\\"{x:1257,y:951,t:1526929895324};\\\", \\\"{x:1263,y:951,t:1526929895339};\\\", \\\"{x:1269,y:951,t:1526929895356};\\\", \\\"{x:1274,y:951,t:1526929895373};\\\", \\\"{x:1275,y:951,t:1526929895413};\\\", \\\"{x:1276,y:951,t:1526929895424};\\\", \\\"{x:1282,y:954,t:1526929895439};\\\", \\\"{x:1288,y:967,t:1526929895457};\\\", \\\"{x:1294,y:977,t:1526929895474};\\\", \\\"{x:1297,y:982,t:1526929895490};\\\", \\\"{x:1299,y:984,t:1526929895506};\\\", \\\"{x:1299,y:983,t:1526929895709};\\\", \\\"{x:1299,y:982,t:1526929895724};\\\", \\\"{x:1299,y:980,t:1526929895740};\\\", \\\"{x:1299,y:978,t:1526929895756};\\\", \\\"{x:1298,y:976,t:1526929895773};\\\", \\\"{x:1297,y:974,t:1526929895790};\\\", \\\"{x:1297,y:973,t:1526929895821};\\\", \\\"{x:1296,y:971,t:1526929895893};\\\", \\\"{x:1296,y:970,t:1526929895925};\\\", \\\"{x:1296,y:969,t:1526929895941};\\\", \\\"{x:1296,y:967,t:1526929895957};\\\", \\\"{x:1294,y:961,t:1526929895973};\\\", \\\"{x:1292,y:960,t:1526929895990};\\\", \\\"{x:1292,y:958,t:1526929896006};\\\", \\\"{x:1292,y:955,t:1526929896024};\\\", \\\"{x:1291,y:950,t:1526929896040};\\\", \\\"{x:1291,y:943,t:1526929896057};\\\", \\\"{x:1291,y:931,t:1526929896075};\\\", \\\"{x:1291,y:919,t:1526929896089};\\\", \\\"{x:1298,y:905,t:1526929896106};\\\", \\\"{x:1308,y:885,t:1526929896123};\\\", \\\"{x:1317,y:863,t:1526929896139};\\\", \\\"{x:1334,y:827,t:1526929896156};\\\", \\\"{x:1343,y:808,t:1526929896173};\\\", \\\"{x:1348,y:802,t:1526929896190};\\\", \\\"{x:1351,y:798,t:1526929896207};\\\", \\\"{x:1353,y:796,t:1526929896222};\\\", \\\"{x:1354,y:794,t:1526929896240};\\\", \\\"{x:1355,y:792,t:1526929896257};\\\", \\\"{x:1357,y:791,t:1526929896273};\\\", \\\"{x:1359,y:789,t:1526929896290};\\\", \\\"{x:1359,y:788,t:1526929896307};\\\", \\\"{x:1362,y:785,t:1526929896323};\\\", \\\"{x:1363,y:782,t:1526929896341};\\\", \\\"{x:1368,y:780,t:1526929896357};\\\", \\\"{x:1370,y:778,t:1526929896373};\\\", \\\"{x:1372,y:777,t:1526929896390};\\\", \\\"{x:1374,y:775,t:1526929896407};\\\", \\\"{x:1377,y:774,t:1526929896424};\\\", \\\"{x:1380,y:771,t:1526929896440};\\\", \\\"{x:1383,y:770,t:1526929896457};\\\", \\\"{x:1387,y:768,t:1526929896473};\\\", \\\"{x:1388,y:767,t:1526929896490};\\\", \\\"{x:1389,y:767,t:1526929896508};\\\", \\\"{x:1390,y:766,t:1526929896565};\\\", \\\"{x:1386,y:766,t:1526929897141};\\\", \\\"{x:1362,y:766,t:1526929897157};\\\", \\\"{x:1312,y:762,t:1526929897174};\\\", \\\"{x:1235,y:752,t:1526929897191};\\\", \\\"{x:1144,y:741,t:1526929897207};\\\", \\\"{x:1046,y:723,t:1526929897224};\\\", \\\"{x:935,y:709,t:1526929897241};\\\", \\\"{x:827,y:695,t:1526929897257};\\\", \\\"{x:731,y:686,t:1526929897274};\\\", \\\"{x:663,y:684,t:1526929897290};\\\", \\\"{x:623,y:681,t:1526929897307};\\\", \\\"{x:587,y:678,t:1526929897324};\\\", \\\"{x:567,y:678,t:1526929897341};\\\", \\\"{x:561,y:677,t:1526929897357};\\\", \\\"{x:558,y:677,t:1526929897375};\\\", \\\"{x:557,y:675,t:1526929897397};\\\", \\\"{x:555,y:675,t:1526929897407};\\\", \\\"{x:549,y:671,t:1526929897424};\\\", \\\"{x:537,y:665,t:1526929897441};\\\", \\\"{x:524,y:660,t:1526929897458};\\\", \\\"{x:507,y:649,t:1526929897476};\\\", \\\"{x:488,y:636,t:1526929897492};\\\", \\\"{x:437,y:606,t:1526929897524};\\\", \\\"{x:406,y:589,t:1526929897541};\\\", \\\"{x:391,y:581,t:1526929897559};\\\", \\\"{x:381,y:573,t:1526929897575};\\\", \\\"{x:371,y:565,t:1526929897592};\\\", \\\"{x:362,y:555,t:1526929897607};\\\", \\\"{x:357,y:552,t:1526929897624};\\\", \\\"{x:355,y:550,t:1526929897641};\\\", \\\"{x:356,y:549,t:1526929897733};\\\", \\\"{x:358,y:548,t:1526929897742};\\\", \\\"{x:364,y:545,t:1526929897758};\\\", \\\"{x:366,y:544,t:1526929897775};\\\", \\\"{x:373,y:543,t:1526929897792};\\\", \\\"{x:377,y:541,t:1526929897808};\\\", \\\"{x:381,y:540,t:1526929897824};\\\", \\\"{x:382,y:540,t:1526929897841};\\\", \\\"{x:382,y:538,t:1526929897933};\\\", \\\"{x:382,y:537,t:1526929897957};\\\", \\\"{x:382,y:535,t:1526929897988};\\\", \\\"{x:383,y:534,t:1526929898003};\\\", \\\"{x:383,y:532,t:1526929898019};\\\", \\\"{x:383,y:531,t:1526929898068};\\\", \\\"{x:383,y:529,t:1526929898099};\\\", \\\"{x:383,y:528,t:1526929898116};\\\", \\\"{x:384,y:526,t:1526929898396};\\\", \\\"{x:384,y:529,t:1526929898419};\\\", \\\"{x:385,y:532,t:1526929898427};\\\", \\\"{x:385,y:534,t:1526929898442};\\\", \\\"{x:388,y:539,t:1526929898459};\\\", \\\"{x:388,y:542,t:1526929898476};\\\", \\\"{x:389,y:543,t:1526929898492};\\\", \\\"{x:389,y:545,t:1526929898510};\\\", \\\"{x:389,y:546,t:1526929898629};\\\", \\\"{x:389,y:547,t:1526929898643};\\\", \\\"{x:389,y:548,t:1526929898661};\\\", \\\"{x:389,y:550,t:1526929898679};\\\", \\\"{x:388,y:552,t:1526929898693};\\\", \\\"{x:388,y:553,t:1526929898708};\\\", \\\"{x:388,y:554,t:1526929898726};\\\", \\\"{x:388,y:556,t:1526929898743};\\\", \\\"{x:387,y:559,t:1526929898759};\\\", \\\"{x:387,y:562,t:1526929898775};\\\", \\\"{x:387,y:563,t:1526929898793};\\\", \\\"{x:387,y:565,t:1526929899382};\\\", \\\"{x:392,y:572,t:1526929899394};\\\", \\\"{x:416,y:590,t:1526929899410};\\\", \\\"{x:470,y:621,t:1526929899426};\\\", \\\"{x:555,y:651,t:1526929899442};\\\", \\\"{x:721,y:696,t:1526929899459};\\\", \\\"{x:831,y:725,t:1526929899476};\\\", \\\"{x:936,y:751,t:1526929899492};\\\", \\\"{x:1033,y:767,t:1526929899510};\\\", \\\"{x:1118,y:785,t:1526929899526};\\\", \\\"{x:1186,y:802,t:1526929899542};\\\", \\\"{x:1235,y:815,t:1526929899560};\\\", \\\"{x:1254,y:821,t:1526929899575};\\\", \\\"{x:1256,y:821,t:1526929899593};\\\", \\\"{x:1257,y:822,t:1526929899612};\\\", \\\"{x:1257,y:823,t:1526929899629};\\\", \\\"{x:1257,y:824,t:1526929899643};\\\", \\\"{x:1257,y:834,t:1526929899660};\\\", \\\"{x:1257,y:842,t:1526929899676};\\\", \\\"{x:1257,y:869,t:1526929899693};\\\", \\\"{x:1258,y:879,t:1526929899711};\\\", \\\"{x:1260,y:883,t:1526929899726};\\\", \\\"{x:1263,y:891,t:1526929899743};\\\", \\\"{x:1270,y:911,t:1526929899760};\\\", \\\"{x:1295,y:944,t:1526929899776};\\\", \\\"{x:1332,y:993,t:1526929899793};\\\", \\\"{x:1348,y:1013,t:1526929899810};\\\", \\\"{x:1350,y:1016,t:1526929899828};\\\", \\\"{x:1349,y:1015,t:1526929899934};\\\", \\\"{x:1348,y:1013,t:1526929899943};\\\", \\\"{x:1342,y:1002,t:1526929899961};\\\", \\\"{x:1333,y:991,t:1526929899977};\\\", \\\"{x:1327,y:985,t:1526929899993};\\\", \\\"{x:1321,y:981,t:1526929900010};\\\", \\\"{x:1318,y:980,t:1526929900027};\\\", \\\"{x:1316,y:979,t:1526929900043};\\\", \\\"{x:1315,y:979,t:1526929900078};\\\", \\\"{x:1312,y:977,t:1526929900093};\\\", \\\"{x:1310,y:976,t:1526929900110};\\\", \\\"{x:1307,y:974,t:1526929900127};\\\", \\\"{x:1306,y:971,t:1526929900143};\\\", \\\"{x:1303,y:964,t:1526929900160};\\\", \\\"{x:1299,y:955,t:1526929900178};\\\", \\\"{x:1299,y:947,t:1526929900193};\\\", \\\"{x:1299,y:940,t:1526929900210};\\\", \\\"{x:1299,y:930,t:1526929900228};\\\", \\\"{x:1307,y:915,t:1526929900244};\\\", \\\"{x:1311,y:910,t:1526929900260};\\\", \\\"{x:1321,y:893,t:1526929900277};\\\", \\\"{x:1330,y:882,t:1526929900293};\\\", \\\"{x:1339,y:870,t:1526929900310};\\\", \\\"{x:1341,y:866,t:1526929900326};\\\", \\\"{x:1346,y:858,t:1526929900344};\\\", \\\"{x:1352,y:852,t:1526929900360};\\\", \\\"{x:1353,y:849,t:1526929900377};\\\", \\\"{x:1356,y:845,t:1526929900393};\\\", \\\"{x:1358,y:839,t:1526929900410};\\\", \\\"{x:1360,y:830,t:1526929900427};\\\", \\\"{x:1360,y:821,t:1526929900444};\\\", \\\"{x:1361,y:817,t:1526929900459};\\\", \\\"{x:1361,y:815,t:1526929900478};\\\", \\\"{x:1362,y:814,t:1526929900494};\\\", \\\"{x:1362,y:813,t:1526929900805};\\\", \\\"{x:1370,y:796,t:1526929900813};\\\", \\\"{x:1380,y:768,t:1526929900828};\\\", \\\"{x:1440,y:647,t:1526929900846};\\\", \\\"{x:1471,y:590,t:1526929900861};\\\", \\\"{x:1489,y:555,t:1526929900879};\\\", \\\"{x:1502,y:535,t:1526929900894};\\\", \\\"{x:1516,y:510,t:1526929900911};\\\", \\\"{x:1536,y:484,t:1526929900928};\\\", \\\"{x:1553,y:464,t:1526929900945};\\\", \\\"{x:1565,y:443,t:1526929900961};\\\", \\\"{x:1573,y:430,t:1526929900978};\\\", \\\"{x:1575,y:425,t:1526929900995};\\\", \\\"{x:1578,y:420,t:1526929901011};\\\", \\\"{x:1579,y:419,t:1526929901027};\\\", \\\"{x:1580,y:417,t:1526929901045};\\\", \\\"{x:1582,y:411,t:1526929901061};\\\", \\\"{x:1582,y:409,t:1526929901079};\\\", \\\"{x:1583,y:406,t:1526929901095};\\\", \\\"{x:1583,y:403,t:1526929901111};\\\", \\\"{x:1584,y:402,t:1526929901127};\\\", \\\"{x:1584,y:400,t:1526929901144};\\\", \\\"{x:1585,y:396,t:1526929901162};\\\", \\\"{x:1585,y:393,t:1526929901177};\\\", \\\"{x:1586,y:386,t:1526929901195};\\\", \\\"{x:1586,y:381,t:1526929901212};\\\", \\\"{x:1587,y:373,t:1526929901228};\\\", \\\"{x:1587,y:369,t:1526929901244};\\\", \\\"{x:1587,y:363,t:1526929901262};\\\", \\\"{x:1587,y:362,t:1526929901279};\\\", \\\"{x:1587,y:361,t:1526929901301};\\\", \\\"{x:1584,y:361,t:1526929906061};\\\", \\\"{x:1573,y:364,t:1526929906069};\\\", \\\"{x:1560,y:371,t:1526929906082};\\\", \\\"{x:1520,y:392,t:1526929906099};\\\", \\\"{x:1462,y:416,t:1526929906115};\\\", \\\"{x:1398,y:437,t:1526929906132};\\\", \\\"{x:1280,y:474,t:1526929906149};\\\", \\\"{x:1203,y:494,t:1526929906165};\\\", \\\"{x:1155,y:508,t:1526929906182};\\\", \\\"{x:1125,y:516,t:1526929906199};\\\", \\\"{x:1103,y:524,t:1526929906215};\\\", \\\"{x:1086,y:534,t:1526929906232};\\\", \\\"{x:1076,y:539,t:1526929906249};\\\", \\\"{x:1074,y:541,t:1526929906264};\\\", \\\"{x:1073,y:542,t:1526929906281};\\\", \\\"{x:1069,y:543,t:1526929919115};\\\", \\\"{x:1063,y:546,t:1526929919124};\\\", \\\"{x:1045,y:550,t:1526929919140};\\\", \\\"{x:1020,y:553,t:1526929919158};\\\", \\\"{x:994,y:554,t:1526929919173};\\\", \\\"{x:964,y:554,t:1526929919190};\\\", \\\"{x:937,y:556,t:1526929919208};\\\", \\\"{x:910,y:556,t:1526929919224};\\\", \\\"{x:888,y:558,t:1526929919240};\\\", \\\"{x:864,y:559,t:1526929919256};\\\", \\\"{x:842,y:559,t:1526929919272};\\\", \\\"{x:812,y:559,t:1526929919289};\\\", \\\"{x:790,y:559,t:1526929919306};\\\", \\\"{x:747,y:559,t:1526929919326};\\\", \\\"{x:710,y:561,t:1526929919341};\\\", \\\"{x:676,y:561,t:1526929919359};\\\", \\\"{x:649,y:561,t:1526929919375};\\\", \\\"{x:624,y:561,t:1526929919391};\\\", \\\"{x:602,y:563,t:1526929919409};\\\", \\\"{x:582,y:563,t:1526929919426};\\\", \\\"{x:561,y:563,t:1526929919442};\\\", \\\"{x:550,y:563,t:1526929919458};\\\", \\\"{x:544,y:563,t:1526929919475};\\\", \\\"{x:543,y:563,t:1526929919499};\\\", \\\"{x:542,y:563,t:1526929919523};\\\", \\\"{x:541,y:563,t:1526929919531};\\\", \\\"{x:540,y:563,t:1526929919547};\\\", \\\"{x:537,y:561,t:1526929919558};\\\", \\\"{x:527,y:557,t:1526929919575};\\\", \\\"{x:518,y:555,t:1526929919591};\\\", \\\"{x:509,y:552,t:1526929919608};\\\", \\\"{x:501,y:550,t:1526929919625};\\\", \\\"{x:492,y:547,t:1526929919642};\\\", \\\"{x:480,y:543,t:1526929919659};\\\", \\\"{x:461,y:538,t:1526929919675};\\\", \\\"{x:457,y:537,t:1526929919693};\\\", \\\"{x:451,y:536,t:1526929919709};\\\", \\\"{x:446,y:534,t:1526929919725};\\\", \\\"{x:442,y:533,t:1526929919743};\\\", \\\"{x:438,y:532,t:1526929919758};\\\", \\\"{x:437,y:532,t:1526929919775};\\\", \\\"{x:435,y:531,t:1526929919792};\\\", \\\"{x:434,y:530,t:1526929919809};\\\", \\\"{x:433,y:530,t:1526929919827};\\\", \\\"{x:432,y:530,t:1526929919843};\\\", \\\"{x:430,y:529,t:1526929919858};\\\", \\\"{x:429,y:529,t:1526929919876};\\\", \\\"{x:427,y:527,t:1526929919893};\\\", \\\"{x:426,y:527,t:1526929919908};\\\", \\\"{x:424,y:527,t:1526929919931};\\\", \\\"{x:422,y:526,t:1526929919947};\\\", \\\"{x:421,y:526,t:1526929919964};\\\", \\\"{x:420,y:526,t:1526929920003};\\\", \\\"{x:419,y:526,t:1526929920011};\\\", \\\"{x:417,y:526,t:1526929920028};\\\", \\\"{x:414,y:526,t:1526929920042};\\\", \\\"{x:413,y:526,t:1526929920059};\\\", \\\"{x:409,y:526,t:1526929920075};\\\", \\\"{x:408,y:526,t:1526929920092};\\\", \\\"{x:407,y:526,t:1526929920140};\\\", \\\"{x:405,y:524,t:1526929920147};\\\", \\\"{x:404,y:524,t:1526929920164};\\\", \\\"{x:403,y:524,t:1526929920180};\\\", \\\"{x:402,y:524,t:1526929920192};\\\", \\\"{x:402,y:523,t:1526929920211};\\\", \\\"{x:401,y:523,t:1526929920228};\\\", \\\"{x:401,y:522,t:1526929920242};\\\", \\\"{x:398,y:521,t:1526929920260};\\\", \\\"{x:396,y:520,t:1526929920275};\\\", \\\"{x:395,y:520,t:1526929920299};\\\", \\\"{x:394,y:520,t:1526929920364};\\\", \\\"{x:394,y:523,t:1526929925923};\\\", \\\"{x:395,y:534,t:1526929925931};\\\", \\\"{x:395,y:546,t:1526929925946};\\\", \\\"{x:400,y:568,t:1526929925963};\\\", \\\"{x:409,y:601,t:1526929925980};\\\", \\\"{x:412,y:617,t:1526929925997};\\\", \\\"{x:416,y:638,t:1526929926014};\\\", \\\"{x:420,y:659,t:1526929926031};\\\", \\\"{x:423,y:675,t:1526929926047};\\\", \\\"{x:424,y:685,t:1526929926064};\\\", \\\"{x:427,y:691,t:1526929926080};\\\", \\\"{x:431,y:706,t:1526929926097};\\\", \\\"{x:440,y:722,t:1526929926113};\\\", \\\"{x:445,y:732,t:1526929926130};\\\", \\\"{x:453,y:750,t:1526929926147};\\\", \\\"{x:458,y:761,t:1526929926163};\\\", \\\"{x:464,y:771,t:1526929926180};\\\", \\\"{x:469,y:776,t:1526929926197};\\\", \\\"{x:470,y:777,t:1526929926214};\\\", \\\"{x:471,y:777,t:1526929926267};\\\", \\\"{x:473,y:777,t:1526929926280};\\\", \\\"{x:477,y:768,t:1526929926297};\\\", \\\"{x:479,y:764,t:1526929926314};\\\", \\\"{x:486,y:752,t:1526929926331};\\\", \\\"{x:488,y:747,t:1526929926348};\\\", \\\"{x:492,y:741,t:1526929926364};\\\", \\\"{x:495,y:733,t:1526929926382};\\\", \\\"{x:497,y:727,t:1526929926398};\\\", \\\"{x:497,y:725,t:1526929926414};\\\", \\\"{x:498,y:724,t:1526929926430};\\\", \\\"{x:498,y:723,t:1526929926447};\\\" ] }, { \\\"rt\\\": 14393, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 311886, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:719,t:1526929928555};\\\", \\\"{x:503,y:717,t:1526929929212};\\\", \\\"{x:506,y:716,t:1526929929220};\\\", \\\"{x:510,y:715,t:1526929929234};\\\", \\\"{x:521,y:714,t:1526929929251};\\\", \\\"{x:534,y:711,t:1526929929267};\\\", \\\"{x:551,y:710,t:1526929929283};\\\", \\\"{x:575,y:710,t:1526929929302};\\\", \\\"{x:602,y:709,t:1526929929317};\\\", \\\"{x:631,y:709,t:1526929929333};\\\", \\\"{x:661,y:707,t:1526929929350};\\\", \\\"{x:688,y:704,t:1526929929366};\\\", \\\"{x:709,y:702,t:1526929929383};\\\", \\\"{x:726,y:699,t:1526929929400};\\\", \\\"{x:733,y:697,t:1526929929417};\\\", \\\"{x:735,y:697,t:1526929929434};\\\", \\\"{x:736,y:696,t:1526929930409};\\\", \\\"{x:735,y:697,t:1526929933448};\\\", \\\"{x:733,y:699,t:1526929933459};\\\", \\\"{x:730,y:702,t:1526929933476};\\\", \\\"{x:729,y:702,t:1526929933505};\\\", \\\"{x:728,y:703,t:1526929933512};\\\", \\\"{x:732,y:702,t:1526929934808};\\\", \\\"{x:735,y:699,t:1526929934816};\\\", \\\"{x:739,y:696,t:1526929934827};\\\", \\\"{x:745,y:690,t:1526929934845};\\\", \\\"{x:749,y:684,t:1526929934862};\\\", \\\"{x:753,y:681,t:1526929934878};\\\", \\\"{x:761,y:673,t:1526929934894};\\\", \\\"{x:771,y:667,t:1526929934912};\\\", \\\"{x:775,y:662,t:1526929934928};\\\", \\\"{x:781,y:658,t:1526929934944};\\\", \\\"{x:789,y:651,t:1526929934962};\\\", \\\"{x:797,y:646,t:1526929934978};\\\", \\\"{x:813,y:635,t:1526929934995};\\\", \\\"{x:831,y:624,t:1526929935011};\\\", \\\"{x:848,y:614,t:1526929935028};\\\", \\\"{x:862,y:607,t:1526929935047};\\\", \\\"{x:873,y:598,t:1526929935061};\\\", \\\"{x:886,y:593,t:1526929935078};\\\", \\\"{x:898,y:587,t:1526929935091};\\\", \\\"{x:908,y:580,t:1526929935109};\\\", \\\"{x:915,y:578,t:1526929935125};\\\", \\\"{x:926,y:574,t:1526929935142};\\\", \\\"{x:947,y:569,t:1526929935158};\\\", \\\"{x:975,y:565,t:1526929935176};\\\", \\\"{x:987,y:563,t:1526929935193};\\\", \\\"{x:998,y:562,t:1526929935208};\\\", \\\"{x:1006,y:560,t:1526929935225};\\\", \\\"{x:1011,y:559,t:1526929935242};\\\", \\\"{x:1017,y:558,t:1526929935260};\\\", \\\"{x:1020,y:558,t:1526929935275};\\\", \\\"{x:1021,y:558,t:1526929935293};\\\", \\\"{x:1018,y:558,t:1526929935671};\\\", \\\"{x:1013,y:558,t:1526929935679};\\\", \\\"{x:1010,y:558,t:1526929935694};\\\", \\\"{x:1006,y:559,t:1526929935710};\\\", \\\"{x:1003,y:560,t:1526929935727};\\\", \\\"{x:1002,y:560,t:1526929935760};\\\", \\\"{x:996,y:561,t:1526929935776};\\\", \\\"{x:986,y:564,t:1526929935794};\\\", \\\"{x:971,y:564,t:1526929935811};\\\", \\\"{x:954,y:564,t:1526929935827};\\\", \\\"{x:931,y:565,t:1526929935844};\\\", \\\"{x:902,y:570,t:1526929935860};\\\", \\\"{x:850,y:583,t:1526929935876};\\\", \\\"{x:794,y:591,t:1526929935892};\\\", \\\"{x:726,y:603,t:1526929935909};\\\", \\\"{x:665,y:620,t:1526929935926};\\\", \\\"{x:607,y:637,t:1526929935943};\\\", \\\"{x:546,y:657,t:1526929935960};\\\", \\\"{x:529,y:661,t:1526929935977};\\\", \\\"{x:526,y:662,t:1526929935992};\\\", \\\"{x:524,y:662,t:1526929936039};\\\", \\\"{x:524,y:660,t:1526929936137};\\\", \\\"{x:522,y:653,t:1526929936145};\\\", \\\"{x:512,y:632,t:1526929936161};\\\", \\\"{x:501,y:611,t:1526929936177};\\\", \\\"{x:490,y:591,t:1526929936194};\\\", \\\"{x:484,y:580,t:1526929936210};\\\", \\\"{x:479,y:572,t:1526929936227};\\\", \\\"{x:477,y:568,t:1526929936243};\\\", \\\"{x:477,y:565,t:1526929936259};\\\", \\\"{x:476,y:563,t:1526929936276};\\\", \\\"{x:476,y:561,t:1526929936294};\\\", \\\"{x:473,y:559,t:1526929936310};\\\", \\\"{x:472,y:558,t:1526929936335};\\\", \\\"{x:472,y:557,t:1526929936359};\\\", \\\"{x:470,y:558,t:1526929936416};\\\", \\\"{x:468,y:558,t:1526929936427};\\\", \\\"{x:464,y:561,t:1526929936444};\\\", \\\"{x:459,y:564,t:1526929936460};\\\", \\\"{x:454,y:567,t:1526929936476};\\\", \\\"{x:439,y:577,t:1526929936495};\\\", \\\"{x:422,y:584,t:1526929936510};\\\", \\\"{x:406,y:592,t:1526929936527};\\\", \\\"{x:392,y:595,t:1526929936542};\\\", \\\"{x:386,y:595,t:1526929936559};\\\", \\\"{x:385,y:595,t:1526929936577};\\\", \\\"{x:384,y:595,t:1526929936672};\\\", \\\"{x:382,y:593,t:1526929936696};\\\", \\\"{x:382,y:591,t:1526929936709};\\\", \\\"{x:382,y:588,t:1526929936726};\\\", \\\"{x:382,y:584,t:1526929936744};\\\", \\\"{x:382,y:579,t:1526929936761};\\\", \\\"{x:387,y:571,t:1526929936778};\\\", \\\"{x:388,y:566,t:1526929936794};\\\", \\\"{x:390,y:563,t:1526929936811};\\\", \\\"{x:391,y:562,t:1526929936826};\\\", \\\"{x:391,y:563,t:1526929937167};\\\", \\\"{x:391,y:564,t:1526929937183};\\\", \\\"{x:390,y:566,t:1526929937193};\\\", \\\"{x:390,y:567,t:1526929937215};\\\", \\\"{x:390,y:569,t:1526929937226};\\\", \\\"{x:387,y:572,t:1526929937243};\\\", \\\"{x:384,y:576,t:1526929937260};\\\", \\\"{x:383,y:577,t:1526929937278};\\\", \\\"{x:383,y:578,t:1526929937293};\\\", \\\"{x:382,y:579,t:1526929937343};\\\", \\\"{x:382,y:580,t:1526929937360};\\\", \\\"{x:381,y:583,t:1526929937377};\\\", \\\"{x:380,y:586,t:1526929937394};\\\", \\\"{x:379,y:589,t:1526929937410};\\\", \\\"{x:379,y:593,t:1526929937427};\\\", \\\"{x:378,y:596,t:1526929937443};\\\", \\\"{x:378,y:599,t:1526929937460};\\\", \\\"{x:378,y:600,t:1526929937477};\\\", \\\"{x:377,y:601,t:1526929937494};\\\", \\\"{x:377,y:602,t:1526929937544};\\\", \\\"{x:378,y:604,t:1526929940088};\\\", \\\"{x:385,y:605,t:1526929940096};\\\", \\\"{x:397,y:609,t:1526929940113};\\\", \\\"{x:411,y:618,t:1526929940130};\\\", \\\"{x:429,y:633,t:1526929940146};\\\", \\\"{x:440,y:644,t:1526929940162};\\\", \\\"{x:447,y:651,t:1526929940180};\\\", \\\"{x:448,y:654,t:1526929940196};\\\", \\\"{x:451,y:658,t:1526929940213};\\\", \\\"{x:456,y:666,t:1526929940229};\\\", \\\"{x:464,y:672,t:1526929940247};\\\", \\\"{x:470,y:678,t:1526929940263};\\\", \\\"{x:472,y:680,t:1526929940279};\\\", \\\"{x:473,y:680,t:1526929940296};\\\", \\\"{x:474,y:682,t:1526929940312};\\\", \\\"{x:476,y:684,t:1526929940335};\\\", \\\"{x:477,y:684,t:1526929940360};\\\", \\\"{x:479,y:686,t:1526929940440};\\\", \\\"{x:480,y:687,t:1526929940455};\\\", \\\"{x:480,y:688,t:1526929940463};\\\", \\\"{x:480,y:689,t:1526929940496};\\\", \\\"{x:480,y:691,t:1526929940520};\\\", \\\"{x:480,y:692,t:1526929940536};\\\", \\\"{x:480,y:694,t:1526929940547};\\\", \\\"{x:481,y:697,t:1526929940562};\\\", \\\"{x:483,y:699,t:1526929940580};\\\", \\\"{x:483,y:700,t:1526929940597};\\\", \\\"{x:484,y:701,t:1526929940614};\\\", \\\"{x:484,y:702,t:1526929940776};\\\", \\\"{x:484,y:704,t:1526929940841};\\\", \\\"{x:484,y:706,t:1526929940864};\\\" ] }, { \\\"rt\\\": 10466, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 323621, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:484,y:697,t:1526929945267};\\\", \\\"{x:492,y:647,t:1526929945285};\\\", \\\"{x:503,y:625,t:1526929945300};\\\", \\\"{x:512,y:608,t:1526929945317};\\\", \\\"{x:516,y:598,t:1526929945333};\\\", \\\"{x:520,y:592,t:1526929945350};\\\", \\\"{x:521,y:588,t:1526929945366};\\\", \\\"{x:522,y:583,t:1526929945383};\\\", \\\"{x:524,y:578,t:1526929945400};\\\", \\\"{x:525,y:575,t:1526929945416};\\\", \\\"{x:525,y:573,t:1526929945434};\\\", \\\"{x:526,y:570,t:1526929945450};\\\", \\\"{x:527,y:567,t:1526929945467};\\\", \\\"{x:527,y:566,t:1526929945484};\\\", \\\"{x:532,y:565,t:1526929945697};\\\", \\\"{x:538,y:567,t:1526929945704};\\\", \\\"{x:542,y:569,t:1526929945717};\\\", \\\"{x:553,y:575,t:1526929945735};\\\", \\\"{x:556,y:578,t:1526929945751};\\\", \\\"{x:558,y:580,t:1526929945767};\\\", \\\"{x:553,y:580,t:1526929946169};\\\", \\\"{x:544,y:577,t:1526929946185};\\\", \\\"{x:543,y:576,t:1526929946203};\\\", \\\"{x:540,y:573,t:1526929946221};\\\", \\\"{x:540,y:571,t:1526929946234};\\\", \\\"{x:540,y:570,t:1526929946251};\\\", \\\"{x:540,y:569,t:1526929946267};\\\", \\\"{x:540,y:567,t:1526929946311};\\\", \\\"{x:540,y:566,t:1526929946319};\\\", \\\"{x:540,y:564,t:1526929946351};\\\", \\\"{x:540,y:563,t:1526929946383};\\\", \\\"{x:540,y:561,t:1526929946407};\\\", \\\"{x:540,y:560,t:1526929946624};\\\", \\\"{x:540,y:558,t:1526929946664};\\\", \\\"{x:539,y:557,t:1526929946696};\\\", \\\"{x:539,y:555,t:1526929946720};\\\", \\\"{x:538,y:555,t:1526929946735};\\\", \\\"{x:538,y:554,t:1526929947992};\\\", \\\"{x:536,y:554,t:1526929953024};\\\", \\\"{x:530,y:554,t:1526929953039};\\\", \\\"{x:521,y:554,t:1526929953056};\\\", \\\"{x:514,y:555,t:1526929953073};\\\", \\\"{x:512,y:555,t:1526929953090};\\\", \\\"{x:511,y:555,t:1526929953106};\\\", \\\"{x:508,y:555,t:1526929953151};\\\", \\\"{x:507,y:555,t:1526929953160};\\\", \\\"{x:505,y:555,t:1526929953173};\\\", \\\"{x:501,y:554,t:1526929953190};\\\", \\\"{x:496,y:552,t:1526929953208};\\\", \\\"{x:476,y:551,t:1526929953223};\\\", \\\"{x:448,y:548,t:1526929953240};\\\", \\\"{x:425,y:545,t:1526929953256};\\\", \\\"{x:403,y:542,t:1526929953272};\\\", \\\"{x:388,y:541,t:1526929953289};\\\", \\\"{x:384,y:541,t:1526929953306};\\\", \\\"{x:383,y:541,t:1526929953323};\\\", \\\"{x:382,y:541,t:1526929953359};\\\", \\\"{x:380,y:541,t:1526929953373};\\\", \\\"{x:378,y:542,t:1526929953391};\\\", \\\"{x:377,y:547,t:1526929953407};\\\", \\\"{x:375,y:552,t:1526929953423};\\\", \\\"{x:375,y:553,t:1526929953464};\\\", \\\"{x:375,y:554,t:1526929953903};\\\", \\\"{x:375,y:560,t:1526929953911};\\\", \\\"{x:381,y:570,t:1526929953924};\\\", \\\"{x:393,y:587,t:1526929953941};\\\", \\\"{x:408,y:605,t:1526929953957};\\\", \\\"{x:426,y:626,t:1526929953974};\\\", \\\"{x:446,y:642,t:1526929953990};\\\", \\\"{x:466,y:658,t:1526929954007};\\\", \\\"{x:471,y:662,t:1526929954024};\\\", \\\"{x:473,y:665,t:1526929954040};\\\", \\\"{x:478,y:673,t:1526929954057};\\\", \\\"{x:483,y:685,t:1526929954074};\\\", \\\"{x:492,y:695,t:1526929954090};\\\", \\\"{x:497,y:701,t:1526929954107};\\\", \\\"{x:497,y:702,t:1526929954124};\\\", \\\"{x:497,y:704,t:1526929954344};\\\", \\\"{x:497,y:706,t:1526929954357};\\\", \\\"{x:497,y:711,t:1526929954374};\\\", \\\"{x:497,y:713,t:1526929954392};\\\", \\\"{x:497,y:714,t:1526929954441};\\\", \\\"{x:500,y:714,t:1526929955488};\\\", \\\"{x:504,y:711,t:1526929955496};\\\", \\\"{x:507,y:708,t:1526929955508};\\\", \\\"{x:519,y:702,t:1526929955525};\\\", \\\"{x:534,y:696,t:1526929955541};\\\", \\\"{x:552,y:686,t:1526929955558};\\\", \\\"{x:579,y:674,t:1526929955575};\\\", \\\"{x:596,y:667,t:1526929955591};\\\", \\\"{x:609,y:664,t:1526929955608};\\\", \\\"{x:623,y:660,t:1526929955625};\\\", \\\"{x:635,y:660,t:1526929955641};\\\", \\\"{x:648,y:660,t:1526929955658};\\\", \\\"{x:663,y:660,t:1526929955675};\\\", \\\"{x:668,y:660,t:1526929955692};\\\", \\\"{x:675,y:660,t:1526929955719};\\\", \\\"{x:678,y:660,t:1526929955724};\\\", \\\"{x:679,y:660,t:1526929955742};\\\" ] }, { \\\"rt\\\": 14543, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 339384, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-05 PM-04 PM-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:680,y:660,t:1526929963937};\\\", \\\"{x:699,y:656,t:1526929963952};\\\", \\\"{x:716,y:657,t:1526929963965};\\\", \\\"{x:777,y:683,t:1526929963981};\\\", \\\"{x:854,y:703,t:1526929963997};\\\", \\\"{x:940,y:730,t:1526929964014};\\\", \\\"{x:1056,y:759,t:1526929964031};\\\", \\\"{x:1120,y:778,t:1526929964048};\\\", \\\"{x:1174,y:794,t:1526929964065};\\\", \\\"{x:1221,y:815,t:1526929964082};\\\", \\\"{x:1247,y:820,t:1526929964098};\\\", \\\"{x:1271,y:827,t:1526929964115};\\\", \\\"{x:1289,y:833,t:1526929964132};\\\", \\\"{x:1305,y:841,t:1526929964148};\\\", \\\"{x:1318,y:846,t:1526929964164};\\\", \\\"{x:1341,y:854,t:1526929964182};\\\", \\\"{x:1381,y:875,t:1526929964199};\\\", \\\"{x:1445,y:903,t:1526929964215};\\\", \\\"{x:1545,y:941,t:1526929964232};\\\", \\\"{x:1598,y:959,t:1526929964249};\\\", \\\"{x:1653,y:972,t:1526929964265};\\\", \\\"{x:1701,y:988,t:1526929964282};\\\", \\\"{x:1734,y:996,t:1526929964298};\\\", \\\"{x:1754,y:1001,t:1526929964315};\\\", \\\"{x:1765,y:1004,t:1526929964332};\\\", \\\"{x:1770,y:1004,t:1526929964349};\\\", \\\"{x:1771,y:1004,t:1526929964365};\\\", \\\"{x:1771,y:1003,t:1526929964465};\\\", \\\"{x:1768,y:996,t:1526929964482};\\\", \\\"{x:1749,y:989,t:1526929964499};\\\", \\\"{x:1732,y:985,t:1526929964515};\\\", \\\"{x:1712,y:984,t:1526929964532};\\\", \\\"{x:1690,y:981,t:1526929964549};\\\", \\\"{x:1666,y:977,t:1526929964565};\\\", \\\"{x:1643,y:974,t:1526929964583};\\\", \\\"{x:1629,y:972,t:1526929964599};\\\", \\\"{x:1620,y:971,t:1526929964616};\\\", \\\"{x:1616,y:970,t:1526929964632};\\\", \\\"{x:1615,y:970,t:1526929964705};\\\", \\\"{x:1613,y:968,t:1526929964722};\\\", \\\"{x:1610,y:967,t:1526929964734};\\\", \\\"{x:1610,y:966,t:1526929964748};\\\", \\\"{x:1610,y:963,t:1526929964765};\\\", \\\"{x:1607,y:957,t:1526929964781};\\\", \\\"{x:1602,y:951,t:1526929964798};\\\", \\\"{x:1598,y:945,t:1526929964815};\\\", \\\"{x:1598,y:942,t:1526929964832};\\\", \\\"{x:1595,y:935,t:1526929964849};\\\", \\\"{x:1592,y:928,t:1526929964866};\\\", \\\"{x:1588,y:920,t:1526929964882};\\\", \\\"{x:1586,y:915,t:1526929964899};\\\", \\\"{x:1585,y:913,t:1526929964916};\\\", \\\"{x:1585,y:912,t:1526929964931};\\\", \\\"{x:1584,y:909,t:1526929964949};\\\", \\\"{x:1582,y:903,t:1526929964965};\\\", \\\"{x:1578,y:892,t:1526929964982};\\\", \\\"{x:1572,y:880,t:1526929964999};\\\", \\\"{x:1566,y:864,t:1526929965016};\\\", \\\"{x:1561,y:853,t:1526929965033};\\\", \\\"{x:1556,y:838,t:1526929965049};\\\", \\\"{x:1544,y:817,t:1526929965067};\\\", \\\"{x:1532,y:797,t:1526929965082};\\\", \\\"{x:1519,y:779,t:1526929965099};\\\", \\\"{x:1508,y:763,t:1526929965116};\\\", \\\"{x:1497,y:749,t:1526929965133};\\\", \\\"{x:1487,y:738,t:1526929965149};\\\", \\\"{x:1478,y:728,t:1526929965165};\\\", \\\"{x:1470,y:719,t:1526929965183};\\\", \\\"{x:1468,y:717,t:1526929965199};\\\", \\\"{x:1467,y:717,t:1526929965216};\\\", \\\"{x:1467,y:716,t:1526929965233};\\\", \\\"{x:1465,y:714,t:1526929965303};\\\", \\\"{x:1463,y:712,t:1526929965319};\\\", \\\"{x:1463,y:707,t:1526929965332};\\\", \\\"{x:1461,y:703,t:1526929965349};\\\", \\\"{x:1460,y:698,t:1526929965366};\\\", \\\"{x:1459,y:690,t:1526929965383};\\\", \\\"{x:1456,y:684,t:1526929965398};\\\", \\\"{x:1454,y:669,t:1526929965415};\\\", \\\"{x:1451,y:659,t:1526929965433};\\\", \\\"{x:1451,y:650,t:1526929965449};\\\", \\\"{x:1450,y:643,t:1526929965466};\\\", \\\"{x:1447,y:634,t:1526929965482};\\\", \\\"{x:1446,y:625,t:1526929965499};\\\", \\\"{x:1444,y:619,t:1526929965516};\\\", \\\"{x:1442,y:613,t:1526929965533};\\\", \\\"{x:1441,y:607,t:1526929965549};\\\", \\\"{x:1439,y:600,t:1526929965567};\\\", \\\"{x:1436,y:596,t:1526929965583};\\\", \\\"{x:1434,y:591,t:1526929965600};\\\", \\\"{x:1434,y:590,t:1526929965616};\\\", \\\"{x:1434,y:586,t:1526929965633};\\\", \\\"{x:1431,y:582,t:1526929965650};\\\", \\\"{x:1431,y:579,t:1526929965665};\\\", \\\"{x:1430,y:578,t:1526929965683};\\\", \\\"{x:1429,y:574,t:1526929965976};\\\", \\\"{x:1427,y:571,t:1526929965984};\\\", \\\"{x:1424,y:564,t:1526929966000};\\\", \\\"{x:1422,y:559,t:1526929966016};\\\", \\\"{x:1419,y:556,t:1526929966033};\\\", \\\"{x:1418,y:555,t:1526929966050};\\\", \\\"{x:1418,y:553,t:1526929966066};\\\", \\\"{x:1417,y:552,t:1526929966083};\\\", \\\"{x:1416,y:551,t:1526929966111};\\\", \\\"{x:1415,y:550,t:1526929966128};\\\", \\\"{x:1414,y:549,t:1526929966160};\\\", \\\"{x:1411,y:549,t:1526929966168};\\\", \\\"{x:1404,y:549,t:1526929966184};\\\", \\\"{x:1374,y:548,t:1526929966199};\\\", \\\"{x:1350,y:548,t:1526929966217};\\\", \\\"{x:1324,y:547,t:1526929966233};\\\", \\\"{x:1290,y:547,t:1526929966250};\\\", \\\"{x:1213,y:538,t:1526929966267};\\\", \\\"{x:1137,y:523,t:1526929966283};\\\", \\\"{x:1070,y:515,t:1526929966300};\\\", \\\"{x:1037,y:513,t:1526929966317};\\\", \\\"{x:1009,y:513,t:1526929966333};\\\", \\\"{x:992,y:513,t:1526929966350};\\\", \\\"{x:974,y:516,t:1526929966367};\\\", \\\"{x:969,y:517,t:1526929966382};\\\", \\\"{x:963,y:523,t:1526929966400};\\\", \\\"{x:959,y:529,t:1526929966417};\\\", \\\"{x:950,y:536,t:1526929966435};\\\", \\\"{x:932,y:543,t:1526929966451};\\\", \\\"{x:907,y:551,t:1526929966467};\\\", \\\"{x:858,y:562,t:1526929966500};\\\", \\\"{x:825,y:564,t:1526929966516};\\\", \\\"{x:764,y:564,t:1526929966533};\\\", \\\"{x:675,y:564,t:1526929966551};\\\", \\\"{x:547,y:564,t:1526929966567};\\\", \\\"{x:461,y:563,t:1526929966584};\\\", \\\"{x:378,y:556,t:1526929966601};\\\", \\\"{x:328,y:554,t:1526929966617};\\\", \\\"{x:300,y:554,t:1526929966633};\\\", \\\"{x:296,y:554,t:1526929966650};\\\", \\\"{x:296,y:555,t:1526929966667};\\\", \\\"{x:296,y:558,t:1526929966683};\\\", \\\"{x:301,y:561,t:1526929966700};\\\", \\\"{x:311,y:564,t:1526929966718};\\\", \\\"{x:331,y:567,t:1526929966734};\\\", \\\"{x:358,y:569,t:1526929966750};\\\", \\\"{x:400,y:569,t:1526929966768};\\\", \\\"{x:420,y:569,t:1526929966785};\\\", \\\"{x:435,y:569,t:1526929966801};\\\", \\\"{x:438,y:569,t:1526929966818};\\\", \\\"{x:443,y:569,t:1526929966834};\\\", \\\"{x:451,y:566,t:1526929966850};\\\", \\\"{x:454,y:564,t:1526929966867};\\\", \\\"{x:456,y:563,t:1526929966884};\\\", \\\"{x:457,y:563,t:1526929966901};\\\", \\\"{x:460,y:561,t:1526929966918};\\\", \\\"{x:467,y:560,t:1526929966935};\\\", \\\"{x:481,y:553,t:1526929966952};\\\", \\\"{x:490,y:549,t:1526929966969};\\\", \\\"{x:503,y:547,t:1526929966987};\\\", \\\"{x:520,y:547,t:1526929967002};\\\", \\\"{x:533,y:547,t:1526929967017};\\\", \\\"{x:541,y:547,t:1526929967034};\\\", \\\"{x:547,y:547,t:1526929967050};\\\", \\\"{x:561,y:549,t:1526929967068};\\\", \\\"{x:580,y:559,t:1526929967085};\\\", \\\"{x:590,y:565,t:1526929967101};\\\", \\\"{x:593,y:567,t:1526929967117};\\\", \\\"{x:594,y:567,t:1526929967134};\\\", \\\"{x:595,y:567,t:1526929967151};\\\", \\\"{x:596,y:567,t:1526929967440};\\\", \\\"{x:597,y:570,t:1526929967808};\\\", \\\"{x:595,y:580,t:1526929967819};\\\", \\\"{x:586,y:596,t:1526929967835};\\\", \\\"{x:574,y:615,t:1526929967852};\\\", \\\"{x:565,y:631,t:1526929967868};\\\", \\\"{x:558,y:643,t:1526929967885};\\\", \\\"{x:551,y:652,t:1526929967902};\\\", \\\"{x:542,y:660,t:1526929967920};\\\", \\\"{x:541,y:662,t:1526929967935};\\\", \\\"{x:535,y:671,t:1526929967952};\\\", \\\"{x:531,y:677,t:1526929967968};\\\", \\\"{x:529,y:682,t:1526929967985};\\\", \\\"{x:527,y:684,t:1526929968002};\\\", \\\"{x:524,y:689,t:1526929968018};\\\", \\\"{x:523,y:690,t:1526929968035};\\\", \\\"{x:522,y:692,t:1526929968051};\\\", \\\"{x:522,y:693,t:1526929968069};\\\", \\\"{x:522,y:694,t:1526929968111};\\\", \\\"{x:522,y:695,t:1526929968127};\\\", \\\"{x:524,y:691,t:1526929968232};\\\", \\\"{x:532,y:675,t:1526929968240};\\\", \\\"{x:546,y:643,t:1526929968253};\\\", \\\"{x:569,y:575,t:1526929968269};\\\", \\\"{x:595,y:517,t:1526929968285};\\\", \\\"{x:614,y:490,t:1526929968301};\\\", \\\"{x:625,y:475,t:1526929968318};\\\", \\\"{x:625,y:474,t:1526929968335};\\\", \\\"{x:626,y:470,t:1526929968351};\\\", \\\"{x:626,y:474,t:1526929968480};\\\", \\\"{x:626,y:483,t:1526929968487};\\\", \\\"{x:626,y:492,t:1526929968501};\\\", \\\"{x:624,y:512,t:1526929968520};\\\", \\\"{x:620,y:522,t:1526929968534};\\\", \\\"{x:616,y:537,t:1526929968552};\\\", \\\"{x:615,y:543,t:1526929968569};\\\", \\\"{x:614,y:545,t:1526929968586};\\\", \\\"{x:613,y:548,t:1526929968602};\\\", \\\"{x:612,y:549,t:1526929968619};\\\", \\\"{x:612,y:551,t:1526929968636};\\\", \\\"{x:611,y:553,t:1526929968651};\\\", \\\"{x:609,y:555,t:1526929968669};\\\", \\\"{x:609,y:556,t:1526929968686};\\\", \\\"{x:609,y:558,t:1526929969047};\\\", \\\"{x:607,y:566,t:1526929969054};\\\", \\\"{x:602,y:579,t:1526929969068};\\\", \\\"{x:589,y:612,t:1526929969086};\\\", \\\"{x:576,y:658,t:1526929969103};\\\", \\\"{x:567,y:671,t:1526929969119};\\\", \\\"{x:564,y:679,t:1526929969135};\\\", \\\"{x:563,y:681,t:1526929969153};\\\", \\\"{x:562,y:682,t:1526929969168};\\\", \\\"{x:562,y:683,t:1526929969186};\\\", \\\"{x:558,y:690,t:1526929969203};\\\", \\\"{x:554,y:697,t:1526929969218};\\\", \\\"{x:552,y:701,t:1526929969238};\\\", \\\"{x:550,y:703,t:1526929969252};\\\", \\\"{x:548,y:705,t:1526929969269};\\\", \\\"{x:547,y:706,t:1526929969287};\\\", \\\"{x:544,y:707,t:1526929969335};\\\", \\\"{x:541,y:707,t:1526929969344};\\\", \\\"{x:538,y:710,t:1526929969353};\\\", \\\"{x:522,y:716,t:1526929969370};\\\", \\\"{x:512,y:717,t:1526929969387};\\\", \\\"{x:496,y:720,t:1526929969403};\\\", \\\"{x:492,y:721,t:1526929969420};\\\", \\\"{x:489,y:722,t:1526929969437};\\\", \\\"{x:487,y:723,t:1526929969454};\\\", \\\"{x:486,y:728,t:1526929969470};\\\", \\\"{x:486,y:731,t:1526929969487};\\\", \\\"{x:485,y:732,t:1526929969505};\\\", \\\"{x:486,y:731,t:1526929969680};\\\", \\\"{x:486,y:730,t:1526929969695};\\\", \\\"{x:486,y:728,t:1526929969752};\\\", \\\"{x:487,y:728,t:1526929969760};\\\", \\\"{x:487,y:727,t:1526929969783};\\\", \\\"{x:487,y:726,t:1526929969936};\\\", \\\"{x:488,y:723,t:1526929969944};\\\", \\\"{x:489,y:720,t:1526929969960};\\\", \\\"{x:489,y:719,t:1526929969972};\\\", \\\"{x:490,y:717,t:1526929969988};\\\", \\\"{x:492,y:714,t:1526929970005};\\\", \\\"{x:492,y:712,t:1526929970022};\\\", \\\"{x:493,y:710,t:1526929970038};\\\", \\\"{x:494,y:709,t:1526929970055};\\\", \\\"{x:494,y:708,t:1526929970840};\\\", \\\"{x:499,y:706,t:1526929970854};\\\", \\\"{x:517,y:695,t:1526929970871};\\\", \\\"{x:524,y:693,t:1526929970887};\\\", \\\"{x:543,y:686,t:1526929970903};\\\", \\\"{x:561,y:684,t:1526929970921};\\\", \\\"{x:580,y:681,t:1526929970936};\\\", \\\"{x:598,y:679,t:1526929970954};\\\", \\\"{x:620,y:675,t:1526929970971};\\\", \\\"{x:640,y:667,t:1526929970987};\\\", \\\"{x:661,y:658,t:1526929971003};\\\", \\\"{x:687,y:646,t:1526929971021};\\\", \\\"{x:708,y:638,t:1526929971037};\\\", \\\"{x:726,y:627,t:1526929971054};\\\", \\\"{x:750,y:619,t:1526929971071};\\\", \\\"{x:761,y:615,t:1526929971087};\\\", \\\"{x:762,y:614,t:1526929971104};\\\" ] }, { \\\"rt\\\": 34389, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 374982, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:764,y:612,t:1526929995019};\\\", \\\"{x:779,y:610,t:1526929995034};\\\", \\\"{x:790,y:610,t:1526929995041};\\\", \\\"{x:814,y:610,t:1526929995057};\\\", \\\"{x:832,y:610,t:1526929995075};\\\", \\\"{x:853,y:611,t:1526929995092};\\\", \\\"{x:870,y:613,t:1526929995109};\\\", \\\"{x:889,y:616,t:1526929995126};\\\", \\\"{x:910,y:618,t:1526929995142};\\\", \\\"{x:937,y:619,t:1526929995158};\\\", \\\"{x:966,y:622,t:1526929995176};\\\", \\\"{x:992,y:623,t:1526929995193};\\\", \\\"{x:1031,y:623,t:1526929995209};\\\", \\\"{x:1055,y:623,t:1526929995226};\\\", \\\"{x:1080,y:622,t:1526929995242};\\\", \\\"{x:1110,y:613,t:1526929995260};\\\", \\\"{x:1163,y:597,t:1526929995276};\\\", \\\"{x:1207,y:587,t:1526929995293};\\\", \\\"{x:1240,y:579,t:1526929995310};\\\", \\\"{x:1260,y:574,t:1526929995326};\\\", \\\"{x:1281,y:567,t:1526929995343};\\\", \\\"{x:1296,y:558,t:1526929995360};\\\", \\\"{x:1304,y:553,t:1526929995377};\\\", \\\"{x:1315,y:544,t:1526929995393};\\\", \\\"{x:1324,y:532,t:1526929995410};\\\", \\\"{x:1327,y:526,t:1526929995426};\\\", \\\"{x:1331,y:517,t:1526929995443};\\\", \\\"{x:1335,y:507,t:1526929995460};\\\", \\\"{x:1346,y:490,t:1526929995476};\\\", \\\"{x:1360,y:474,t:1526929995494};\\\", \\\"{x:1378,y:456,t:1526929995511};\\\", \\\"{x:1397,y:441,t:1526929995527};\\\", \\\"{x:1408,y:434,t:1526929995544};\\\", \\\"{x:1417,y:430,t:1526929995562};\\\", \\\"{x:1424,y:427,t:1526929995576};\\\", \\\"{x:1426,y:426,t:1526929995593};\\\", \\\"{x:1434,y:422,t:1526929995609};\\\", \\\"{x:1442,y:418,t:1526929995626};\\\", \\\"{x:1450,y:415,t:1526929995642};\\\", \\\"{x:1453,y:413,t:1526929995660};\\\", \\\"{x:1457,y:412,t:1526929995676};\\\", \\\"{x:1459,y:410,t:1526929995692};\\\", \\\"{x:1460,y:410,t:1526929995710};\\\", \\\"{x:1461,y:409,t:1526929995915};\\\", \\\"{x:1461,y:406,t:1526929995926};\\\", \\\"{x:1461,y:401,t:1526929995943};\\\", \\\"{x:1460,y:397,t:1526929995960};\\\", \\\"{x:1458,y:391,t:1526929995976};\\\", \\\"{x:1458,y:384,t:1526929995994};\\\", \\\"{x:1456,y:376,t:1526929996010};\\\", \\\"{x:1456,y:373,t:1526929996026};\\\", \\\"{x:1455,y:373,t:1526929996170};\\\", \\\"{x:1452,y:373,t:1526929996178};\\\", \\\"{x:1448,y:374,t:1526929996194};\\\", \\\"{x:1431,y:386,t:1526929996211};\\\", \\\"{x:1421,y:394,t:1526929996226};\\\", \\\"{x:1413,y:405,t:1526929996243};\\\", \\\"{x:1406,y:412,t:1526929996260};\\\", \\\"{x:1400,y:418,t:1526929996277};\\\", \\\"{x:1397,y:423,t:1526929996293};\\\", \\\"{x:1395,y:426,t:1526929996310};\\\", \\\"{x:1390,y:430,t:1526929996327};\\\", \\\"{x:1387,y:432,t:1526929996344};\\\", \\\"{x:1384,y:433,t:1526929996361};\\\", \\\"{x:1380,y:435,t:1526929996376};\\\", \\\"{x:1378,y:437,t:1526929996393};\\\", \\\"{x:1371,y:440,t:1526929996411};\\\", \\\"{x:1365,y:443,t:1526929996427};\\\", \\\"{x:1362,y:445,t:1526929996444};\\\", \\\"{x:1358,y:449,t:1526929996460};\\\", \\\"{x:1354,y:453,t:1526929996476};\\\", \\\"{x:1347,y:460,t:1526929996494};\\\", \\\"{x:1340,y:468,t:1526929996510};\\\", \\\"{x:1335,y:478,t:1526929996526};\\\", \\\"{x:1330,y:484,t:1526929996544};\\\", \\\"{x:1327,y:489,t:1526929996560};\\\", \\\"{x:1326,y:491,t:1526929996576};\\\", \\\"{x:1326,y:493,t:1526929996594};\\\", \\\"{x:1325,y:494,t:1526929996611};\\\", \\\"{x:1324,y:496,t:1526929996634};\\\", \\\"{x:1323,y:497,t:1526929996650};\\\", \\\"{x:1323,y:498,t:1526929996661};\\\", \\\"{x:1323,y:499,t:1526929996698};\\\", \\\"{x:1323,y:500,t:1526929996731};\\\", \\\"{x:1322,y:500,t:1526929996827};\\\", \\\"{x:1321,y:500,t:1526929996874};\\\", \\\"{x:1320,y:500,t:1526929996882};\\\", \\\"{x:1318,y:501,t:1526929996894};\\\", \\\"{x:1318,y:503,t:1526929996911};\\\", \\\"{x:1317,y:505,t:1526929996927};\\\", \\\"{x:1317,y:507,t:1526929996995};\\\", \\\"{x:1317,y:510,t:1526929997010};\\\", \\\"{x:1317,y:515,t:1526929997027};\\\", \\\"{x:1317,y:521,t:1526929997043};\\\", \\\"{x:1317,y:523,t:1526929997060};\\\", \\\"{x:1317,y:528,t:1526929997077};\\\", \\\"{x:1315,y:533,t:1526929997093};\\\", \\\"{x:1315,y:540,t:1526929997110};\\\", \\\"{x:1314,y:549,t:1526929997126};\\\", \\\"{x:1314,y:558,t:1526929997143};\\\", \\\"{x:1314,y:561,t:1526929997160};\\\", \\\"{x:1314,y:566,t:1526929997176};\\\", \\\"{x:1313,y:572,t:1526929997193};\\\", \\\"{x:1313,y:580,t:1526929997210};\\\", \\\"{x:1313,y:584,t:1526929997226};\\\", \\\"{x:1313,y:587,t:1526929997242};\\\", \\\"{x:1313,y:590,t:1526929997260};\\\", \\\"{x:1313,y:591,t:1526929997276};\\\", \\\"{x:1313,y:593,t:1526929997293};\\\", \\\"{x:1313,y:594,t:1526929997310};\\\", \\\"{x:1313,y:597,t:1526929997325};\\\", \\\"{x:1313,y:600,t:1526929997343};\\\", \\\"{x:1313,y:605,t:1526929997360};\\\", \\\"{x:1313,y:607,t:1526929997376};\\\", \\\"{x:1314,y:608,t:1526929997393};\\\", \\\"{x:1314,y:609,t:1526929997409};\\\", \\\"{x:1314,y:613,t:1526929997426};\\\", \\\"{x:1314,y:615,t:1526929997443};\\\", \\\"{x:1314,y:616,t:1526929997460};\\\", \\\"{x:1314,y:617,t:1526929997506};\\\", \\\"{x:1314,y:618,t:1526929997514};\\\", \\\"{x:1314,y:619,t:1526929997527};\\\", \\\"{x:1314,y:621,t:1526929997543};\\\", \\\"{x:1314,y:623,t:1526929997560};\\\", \\\"{x:1314,y:625,t:1526929997577};\\\", \\\"{x:1314,y:627,t:1526929997594};\\\", \\\"{x:1314,y:633,t:1526929997610};\\\", \\\"{x:1314,y:636,t:1526929997626};\\\", \\\"{x:1314,y:639,t:1526929997642};\\\", \\\"{x:1314,y:640,t:1526929997660};\\\", \\\"{x:1314,y:643,t:1526929997705};\\\", \\\"{x:1314,y:644,t:1526929997714};\\\", \\\"{x:1315,y:646,t:1526929997726};\\\", \\\"{x:1317,y:652,t:1526929997743};\\\", \\\"{x:1319,y:657,t:1526929997760};\\\", \\\"{x:1321,y:662,t:1526929997776};\\\", \\\"{x:1324,y:667,t:1526929997793};\\\", \\\"{x:1330,y:680,t:1526929997810};\\\", \\\"{x:1332,y:687,t:1526929997826};\\\", \\\"{x:1336,y:693,t:1526929997843};\\\", \\\"{x:1339,y:699,t:1526929997860};\\\", \\\"{x:1339,y:703,t:1526929997876};\\\", \\\"{x:1340,y:705,t:1526929997894};\\\", \\\"{x:1340,y:708,t:1526929997910};\\\", \\\"{x:1343,y:713,t:1526929997926};\\\", \\\"{x:1344,y:718,t:1526929997943};\\\", \\\"{x:1345,y:720,t:1526929997960};\\\", \\\"{x:1345,y:722,t:1526929997977};\\\", \\\"{x:1345,y:724,t:1526929997994};\\\", \\\"{x:1345,y:731,t:1526929998011};\\\", \\\"{x:1346,y:735,t:1526929998027};\\\", \\\"{x:1346,y:742,t:1526929998044};\\\", \\\"{x:1346,y:748,t:1526929998060};\\\", \\\"{x:1346,y:755,t:1526929998076};\\\", \\\"{x:1346,y:760,t:1526929998093};\\\", \\\"{x:1346,y:764,t:1526929998110};\\\", \\\"{x:1346,y:767,t:1526929998126};\\\", \\\"{x:1345,y:774,t:1526929998143};\\\", \\\"{x:1344,y:779,t:1526929998160};\\\", \\\"{x:1342,y:788,t:1526929998176};\\\", \\\"{x:1341,y:796,t:1526929998193};\\\", \\\"{x:1340,y:804,t:1526929998210};\\\", \\\"{x:1338,y:806,t:1526929998227};\\\", \\\"{x:1338,y:810,t:1526929998243};\\\", \\\"{x:1337,y:817,t:1526929998260};\\\", \\\"{x:1334,y:825,t:1526929998277};\\\", \\\"{x:1333,y:835,t:1526929998293};\\\", \\\"{x:1332,y:841,t:1526929998310};\\\", \\\"{x:1330,y:845,t:1526929998326};\\\", \\\"{x:1328,y:848,t:1526929998343};\\\", \\\"{x:1327,y:850,t:1526929998359};\\\", \\\"{x:1324,y:857,t:1526929998377};\\\", \\\"{x:1321,y:871,t:1526929998393};\\\", \\\"{x:1321,y:886,t:1526929998410};\\\", \\\"{x:1321,y:890,t:1526929998426};\\\", \\\"{x:1321,y:894,t:1526929998444};\\\", \\\"{x:1321,y:895,t:1526929998461};\\\", \\\"{x:1321,y:898,t:1526929998477};\\\", \\\"{x:1321,y:899,t:1526929998499};\\\", \\\"{x:1320,y:902,t:1526929998511};\\\", \\\"{x:1320,y:904,t:1526929998530};\\\", \\\"{x:1320,y:905,t:1526929998543};\\\", \\\"{x:1319,y:907,t:1526929998560};\\\", \\\"{x:1319,y:908,t:1526929998579};\\\", \\\"{x:1318,y:910,t:1526929998594};\\\", \\\"{x:1318,y:912,t:1526929998609};\\\", \\\"{x:1318,y:917,t:1526929998627};\\\", \\\"{x:1317,y:924,t:1526929998644};\\\", \\\"{x:1314,y:933,t:1526929998660};\\\", \\\"{x:1313,y:938,t:1526929998677};\\\", \\\"{x:1312,y:943,t:1526929998693};\\\", \\\"{x:1310,y:947,t:1526929998710};\\\", \\\"{x:1310,y:951,t:1526929998727};\\\", \\\"{x:1306,y:955,t:1526929998743};\\\", \\\"{x:1304,y:962,t:1526929998760};\\\", \\\"{x:1304,y:965,t:1526929998776};\\\", \\\"{x:1303,y:967,t:1526929998793};\\\", \\\"{x:1303,y:969,t:1526929998810};\\\", \\\"{x:1305,y:969,t:1526929998931};\\\", \\\"{x:1307,y:970,t:1526929998962};\\\", \\\"{x:1308,y:970,t:1526929998976};\\\", \\\"{x:1309,y:970,t:1526929999211};\\\", \\\"{x:1310,y:970,t:1526929999315};\\\", \\\"{x:1310,y:968,t:1526929999507};\\\", \\\"{x:1311,y:968,t:1526929999530};\\\", \\\"{x:1311,y:967,t:1526929999563};\\\", \\\"{x:1311,y:966,t:1526929999578};\\\", \\\"{x:1311,y:964,t:1526929999594};\\\", \\\"{x:1311,y:962,t:1526929999619};\\\", \\\"{x:1311,y:961,t:1526929999634};\\\", \\\"{x:1311,y:958,t:1526930002963};\\\", \\\"{x:1309,y:945,t:1526930002976};\\\", \\\"{x:1300,y:922,t:1526930002992};\\\", \\\"{x:1285,y:896,t:1526930003010};\\\", \\\"{x:1243,y:835,t:1526930003026};\\\", \\\"{x:1206,y:784,t:1526930003044};\\\", \\\"{x:1149,y:725,t:1526930003060};\\\", \\\"{x:1088,y:671,t:1526930003077};\\\", \\\"{x:1029,y:616,t:1526930003093};\\\", \\\"{x:954,y:566,t:1526930003109};\\\", \\\"{x:861,y:516,t:1526930003126};\\\", \\\"{x:795,y:471,t:1526930003143};\\\", \\\"{x:767,y:450,t:1526930003159};\\\", \\\"{x:749,y:440,t:1526930003176};\\\", \\\"{x:726,y:432,t:1526930003192};\\\", \\\"{x:702,y:427,t:1526930003209};\\\", \\\"{x:675,y:423,t:1526930003225};\\\", \\\"{x:659,y:425,t:1526930003242};\\\", \\\"{x:642,y:431,t:1526930003259};\\\", \\\"{x:630,y:439,t:1526930003276};\\\", \\\"{x:619,y:444,t:1526930003292};\\\", \\\"{x:610,y:450,t:1526930003310};\\\", \\\"{x:603,y:461,t:1526930003326};\\\", \\\"{x:597,y:482,t:1526930003343};\\\", \\\"{x:595,y:504,t:1526930003359};\\\", \\\"{x:594,y:518,t:1526930003376};\\\", \\\"{x:597,y:530,t:1526930003394};\\\", \\\"{x:602,y:544,t:1526930003409};\\\", \\\"{x:623,y:569,t:1526930003426};\\\", \\\"{x:647,y:586,t:1526930003446};\\\", \\\"{x:679,y:601,t:1526930003464};\\\", \\\"{x:719,y:610,t:1526930003480};\\\", \\\"{x:837,y:622,t:1526930003499};\\\", \\\"{x:887,y:627,t:1526930003516};\\\", \\\"{x:917,y:627,t:1526930003533};\\\", \\\"{x:933,y:622,t:1526930003550};\\\", \\\"{x:935,y:618,t:1526930003566};\\\", \\\"{x:936,y:615,t:1526930003583};\\\", \\\"{x:936,y:611,t:1526930003600};\\\", \\\"{x:935,y:608,t:1526930003615};\\\", \\\"{x:931,y:602,t:1526930003632};\\\", \\\"{x:918,y:583,t:1526930003649};\\\", \\\"{x:908,y:571,t:1526930003666};\\\", \\\"{x:899,y:566,t:1526930003683};\\\", \\\"{x:893,y:562,t:1526930003699};\\\", \\\"{x:887,y:558,t:1526930003716};\\\", \\\"{x:881,y:556,t:1526930003733};\\\", \\\"{x:879,y:554,t:1526930003749};\\\", \\\"{x:877,y:554,t:1526930003766};\\\", \\\"{x:876,y:552,t:1526930003801};\\\", \\\"{x:876,y:551,t:1526930003817};\\\", \\\"{x:874,y:549,t:1526930003834};\\\", \\\"{x:873,y:548,t:1526930003858};\\\", \\\"{x:872,y:548,t:1526930003874};\\\", \\\"{x:872,y:546,t:1526930003883};\\\", \\\"{x:870,y:544,t:1526930003900};\\\", \\\"{x:869,y:542,t:1526930003917};\\\", \\\"{x:867,y:541,t:1526930003933};\\\", \\\"{x:865,y:539,t:1526930003953};\\\", \\\"{x:863,y:538,t:1526930003969};\\\", \\\"{x:860,y:537,t:1526930003983};\\\", \\\"{x:857,y:536,t:1526930004000};\\\", \\\"{x:854,y:535,t:1526930004017};\\\", \\\"{x:853,y:535,t:1526930004138};\\\", \\\"{x:852,y:535,t:1526930004162};\\\", \\\"{x:851,y:535,t:1526930004170};\\\", \\\"{x:850,y:535,t:1526930004184};\\\", \\\"{x:848,y:535,t:1526930004201};\\\", \\\"{x:845,y:535,t:1526930004217};\\\", \\\"{x:843,y:535,t:1526930004234};\\\", \\\"{x:840,y:535,t:1526930004250};\\\", \\\"{x:839,y:535,t:1526930004267};\\\", \\\"{x:838,y:535,t:1526930004284};\\\", \\\"{x:835,y:535,t:1526930004301};\\\", \\\"{x:833,y:540,t:1526930004962};\\\", \\\"{x:824,y:555,t:1526930004972};\\\", \\\"{x:813,y:572,t:1526930004984};\\\", \\\"{x:766,y:624,t:1526930005001};\\\", \\\"{x:717,y:652,t:1526930005018};\\\", \\\"{x:666,y:680,t:1526930005034};\\\", \\\"{x:628,y:696,t:1526930005051};\\\", \\\"{x:603,y:707,t:1526930005067};\\\", \\\"{x:592,y:709,t:1526930005084};\\\", \\\"{x:587,y:713,t:1526930005101};\\\", \\\"{x:584,y:715,t:1526930005117};\\\", \\\"{x:583,y:717,t:1526930005134};\\\", \\\"{x:582,y:718,t:1526930005151};\\\", \\\"{x:580,y:719,t:1526930005167};\\\", \\\"{x:578,y:720,t:1526930005201};\\\", \\\"{x:577,y:720,t:1526930005217};\\\", \\\"{x:575,y:720,t:1526930005234};\\\", \\\"{x:574,y:720,t:1526930005250};\\\", \\\"{x:573,y:720,t:1526930005266};\\\", \\\"{x:566,y:720,t:1526930005284};\\\", \\\"{x:557,y:720,t:1526930005300};\\\", \\\"{x:546,y:720,t:1526930005317};\\\", \\\"{x:537,y:719,t:1526930005334};\\\", \\\"{x:535,y:718,t:1526930005351};\\\", \\\"{x:534,y:717,t:1526930005368};\\\", \\\"{x:533,y:717,t:1526930005441};\\\", \\\"{x:532,y:717,t:1526930005778};\\\", \\\"{x:532,y:718,t:1526930005785};\\\", \\\"{x:532,y:719,t:1526930005802};\\\", \\\"{x:532,y:721,t:1526930005819};\\\", \\\"{x:535,y:721,t:1526930006915};\\\", \\\"{x:537,y:716,t:1526930006922};\\\", \\\"{x:537,y:712,t:1526930006936};\\\", \\\"{x:537,y:704,t:1526930006952};\\\", \\\"{x:537,y:691,t:1526930006969};\\\", \\\"{x:538,y:684,t:1526930006986};\\\", \\\"{x:539,y:680,t:1526930007002};\\\", \\\"{x:539,y:677,t:1526930007020};\\\", \\\"{x:540,y:675,t:1526930007041};\\\", \\\"{x:541,y:675,t:1526930007052};\\\", \\\"{x:542,y:671,t:1526930007086};\\\", \\\"{x:543,y:669,t:1526930007102};\\\", \\\"{x:544,y:667,t:1526930007119};\\\", \\\"{x:544,y:664,t:1526930007135};\\\", \\\"{x:545,y:659,t:1526930007152};\\\", \\\"{x:546,y:645,t:1526930007169};\\\", \\\"{x:546,y:629,t:1526930007185};\\\", \\\"{x:546,y:613,t:1526930007202};\\\", \\\"{x:546,y:597,t:1526930007219};\\\" ] }, { \\\"rt\\\": 9581, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 385850, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:578,y:501,t:1526930007334};\\\", \\\"{x:586,y:492,t:1526930007352};\\\", \\\"{x:595,y:483,t:1526930007370};\\\", \\\"{x:599,y:479,t:1526930007386};\\\", \\\"{x:602,y:476,t:1526930007402};\\\", \\\"{x:605,y:475,t:1526930007419};\\\", \\\"{x:608,y:474,t:1526930007436};\\\", \\\"{x:608,y:472,t:1526930007452};\\\", \\\"{x:609,y:471,t:1526930007497};\\\", \\\"{x:610,y:469,t:1526930007506};\\\", \\\"{x:610,y:467,t:1526930007521};\\\", \\\"{x:611,y:467,t:1526930007536};\\\", \\\"{x:612,y:465,t:1526930007553};\\\", \\\"{x:612,y:464,t:1526930007583};\\\", \\\"{x:612,y:463,t:1526930007801};\\\", \\\"{x:612,y:460,t:1526930008129};\\\", \\\"{x:616,y:460,t:1526930008138};\\\", \\\"{x:622,y:455,t:1526930008153};\\\", \\\"{x:625,y:452,t:1526930008170};\\\", \\\"{x:632,y:447,t:1526930008186};\\\", \\\"{x:638,y:443,t:1526930008203};\\\", \\\"{x:642,y:440,t:1526930008220};\\\", \\\"{x:643,y:439,t:1526930008241};\\\", \\\"{x:643,y:437,t:1526930008273};\\\", \\\"{x:646,y:436,t:1526930012922};\\\", \\\"{x:653,y:434,t:1526930012930};\\\", \\\"{x:662,y:430,t:1526930012941};\\\", \\\"{x:677,y:429,t:1526930012957};\\\", \\\"{x:704,y:429,t:1526930012974};\\\", \\\"{x:728,y:429,t:1526930012990};\\\", \\\"{x:750,y:437,t:1526930013007};\\\", \\\"{x:773,y:444,t:1526930013024};\\\", \\\"{x:797,y:451,t:1526930013041};\\\", \\\"{x:823,y:458,t:1526930013056};\\\", \\\"{x:851,y:466,t:1526930013074};\\\", \\\"{x:865,y:468,t:1526930013090};\\\", \\\"{x:883,y:475,t:1526930013106};\\\", \\\"{x:907,y:483,t:1526930013123};\\\", \\\"{x:946,y:492,t:1526930013141};\\\", \\\"{x:988,y:504,t:1526930013158};\\\", \\\"{x:1030,y:509,t:1526930013173};\\\", \\\"{x:1053,y:510,t:1526930013190};\\\", \\\"{x:1072,y:510,t:1526930013207};\\\", \\\"{x:1087,y:510,t:1526930013225};\\\", \\\"{x:1096,y:510,t:1526930013240};\\\", \\\"{x:1115,y:513,t:1526930013257};\\\", \\\"{x:1126,y:515,t:1526930013275};\\\", \\\"{x:1137,y:516,t:1526930013290};\\\", \\\"{x:1149,y:517,t:1526930013307};\\\", \\\"{x:1158,y:519,t:1526930013325};\\\", \\\"{x:1168,y:521,t:1526930013340};\\\", \\\"{x:1188,y:524,t:1526930013357};\\\", \\\"{x:1209,y:528,t:1526930013374};\\\", \\\"{x:1225,y:530,t:1526930013391};\\\", \\\"{x:1237,y:531,t:1526930013407};\\\", \\\"{x:1243,y:531,t:1526930013424};\\\", \\\"{x:1244,y:531,t:1526930013440};\\\", \\\"{x:1246,y:531,t:1526930013465};\\\", \\\"{x:1247,y:531,t:1526930013537};\\\", \\\"{x:1247,y:529,t:1526930013746};\\\", \\\"{x:1243,y:529,t:1526930013758};\\\", \\\"{x:1239,y:526,t:1526930013775};\\\", \\\"{x:1225,y:520,t:1526930013792};\\\", \\\"{x:1203,y:509,t:1526930013809};\\\", \\\"{x:1161,y:493,t:1526930013825};\\\", \\\"{x:1041,y:453,t:1526930013842};\\\", \\\"{x:966,y:433,t:1526930013858};\\\", \\\"{x:904,y:415,t:1526930013875};\\\", \\\"{x:842,y:401,t:1526930013893};\\\", \\\"{x:786,y:393,t:1526930013907};\\\", \\\"{x:746,y:392,t:1526930013925};\\\", \\\"{x:724,y:392,t:1526930013941};\\\", \\\"{x:708,y:395,t:1526930013958};\\\", \\\"{x:691,y:403,t:1526930013975};\\\", \\\"{x:683,y:407,t:1526930013992};\\\", \\\"{x:668,y:420,t:1526930014008};\\\", \\\"{x:656,y:431,t:1526930014025};\\\", \\\"{x:646,y:445,t:1526930014041};\\\", \\\"{x:637,y:451,t:1526930014057};\\\", \\\"{x:626,y:460,t:1526930014075};\\\", \\\"{x:616,y:470,t:1526930014092};\\\", \\\"{x:604,y:480,t:1526930014107};\\\", \\\"{x:595,y:484,t:1526930014125};\\\", \\\"{x:587,y:489,t:1526930014142};\\\", \\\"{x:578,y:493,t:1526930014158};\\\", \\\"{x:565,y:498,t:1526930014174};\\\", \\\"{x:554,y:503,t:1526930014192};\\\", \\\"{x:548,y:504,t:1526930014209};\\\", \\\"{x:540,y:505,t:1526930014225};\\\", \\\"{x:518,y:505,t:1526930014242};\\\", \\\"{x:513,y:505,t:1526930014259};\\\", \\\"{x:510,y:506,t:1526930014275};\\\", \\\"{x:513,y:506,t:1526930014322};\\\", \\\"{x:519,y:505,t:1526930014330};\\\", \\\"{x:527,y:501,t:1526930014342};\\\", \\\"{x:542,y:497,t:1526930014359};\\\", \\\"{x:550,y:497,t:1526930014375};\\\", \\\"{x:560,y:496,t:1526930014392};\\\", \\\"{x:568,y:495,t:1526930014408};\\\", \\\"{x:569,y:495,t:1526930014434};\\\", \\\"{x:571,y:495,t:1526930014450};\\\", \\\"{x:573,y:493,t:1526930014458};\\\", \\\"{x:575,y:493,t:1526930014475};\\\", \\\"{x:578,y:493,t:1526930014492};\\\", \\\"{x:580,y:493,t:1526930014578};\\\", \\\"{x:582,y:493,t:1526930014592};\\\", \\\"{x:584,y:493,t:1526930014609};\\\", \\\"{x:586,y:493,t:1526930014626};\\\", \\\"{x:587,y:494,t:1526930014650};\\\", \\\"{x:589,y:494,t:1526930014659};\\\", \\\"{x:591,y:494,t:1526930014676};\\\", \\\"{x:596,y:495,t:1526930014692};\\\", \\\"{x:596,y:496,t:1526930014709};\\\", \\\"{x:601,y:497,t:1526930014727};\\\", \\\"{x:602,y:498,t:1526930014742};\\\", \\\"{x:604,y:499,t:1526930014759};\\\", \\\"{x:605,y:500,t:1526930014776};\\\", \\\"{x:606,y:500,t:1526930014792};\\\", \\\"{x:608,y:500,t:1526930015081};\\\", \\\"{x:614,y:500,t:1526930015092};\\\", \\\"{x:643,y:504,t:1526930015109};\\\", \\\"{x:700,y:516,t:1526930015125};\\\", \\\"{x:785,y:525,t:1526930015143};\\\", \\\"{x:882,y:535,t:1526930015158};\\\", \\\"{x:924,y:538,t:1526930015175};\\\", \\\"{x:942,y:538,t:1526930015192};\\\", \\\"{x:946,y:538,t:1526930015209};\\\", \\\"{x:946,y:537,t:1526930015330};\\\", \\\"{x:941,y:537,t:1526930015342};\\\", \\\"{x:923,y:534,t:1526930015359};\\\", \\\"{x:900,y:532,t:1526930015376};\\\", \\\"{x:866,y:532,t:1526930015393};\\\", \\\"{x:843,y:535,t:1526930015409};\\\", \\\"{x:836,y:535,t:1526930015425};\\\", \\\"{x:833,y:536,t:1526930015442};\\\", \\\"{x:833,y:537,t:1526930015571};\\\", \\\"{x:833,y:538,t:1526930015594};\\\", \\\"{x:833,y:539,t:1526930015610};\\\", \\\"{x:833,y:542,t:1526930015801};\\\", \\\"{x:830,y:553,t:1526930015810};\\\", \\\"{x:815,y:581,t:1526930015827};\\\", \\\"{x:799,y:602,t:1526930015843};\\\", \\\"{x:771,y:627,t:1526930015860};\\\", \\\"{x:734,y:650,t:1526930015885};\\\", \\\"{x:721,y:652,t:1526930015893};\\\", \\\"{x:693,y:660,t:1526930015910};\\\", \\\"{x:673,y:667,t:1526930015926};\\\", \\\"{x:660,y:673,t:1526930015942};\\\", \\\"{x:652,y:677,t:1526930015959};\\\", \\\"{x:644,y:679,t:1526930015977};\\\", \\\"{x:643,y:681,t:1526930015993};\\\", \\\"{x:641,y:681,t:1526930016050};\\\", \\\"{x:638,y:681,t:1526930016073};\\\", \\\"{x:632,y:681,t:1526930016081};\\\", \\\"{x:624,y:681,t:1526930016094};\\\", \\\"{x:609,y:681,t:1526930016110};\\\", \\\"{x:601,y:682,t:1526930016127};\\\", \\\"{x:587,y:687,t:1526930016143};\\\", \\\"{x:572,y:693,t:1526930016160};\\\", \\\"{x:563,y:696,t:1526930016177};\\\", \\\"{x:554,y:700,t:1526930016194};\\\", \\\"{x:546,y:706,t:1526930016210};\\\", \\\"{x:543,y:708,t:1526930016227};\\\", \\\"{x:541,y:710,t:1526930016244};\\\", \\\"{x:540,y:711,t:1526930016298};\\\", \\\"{x:540,y:712,t:1526930016311};\\\", \\\"{x:539,y:718,t:1526930016327};\\\", \\\"{x:539,y:720,t:1526930016346};\\\", \\\"{x:539,y:722,t:1526930016360};\\\", \\\"{x:538,y:723,t:1526930016376};\\\", \\\"{x:538,y:724,t:1526930016401};\\\", \\\"{x:537,y:726,t:1526930016425};\\\", \\\"{x:537,y:727,t:1526930016433};\\\", \\\"{x:537,y:728,t:1526930016444};\\\", \\\"{x:537,y:729,t:1526930016460};\\\", \\\"{x:537,y:730,t:1526930016512};\\\", \\\"{x:536,y:731,t:1526930016865};\\\", \\\"{x:536,y:731,t:1526930016938};\\\", \\\"{x:536,y:730,t:1526930017817};\\\", \\\"{x:536,y:729,t:1526930017993};\\\", \\\"{x:536,y:728,t:1526930018033};\\\" ] }, { \\\"rt\\\": 27399, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 414500, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:726,t:1526930018164};\\\", \\\"{x:538,y:723,t:1526930018778};\\\", \\\"{x:542,y:721,t:1526930018792};\\\", \\\"{x:554,y:717,t:1526930018795};\\\", \\\"{x:567,y:711,t:1526930018812};\\\", \\\"{x:585,y:704,t:1526930018828};\\\", \\\"{x:612,y:699,t:1526930018844};\\\", \\\"{x:633,y:698,t:1526930018861};\\\", \\\"{x:650,y:699,t:1526930018879};\\\", \\\"{x:667,y:700,t:1526930018894};\\\", \\\"{x:680,y:702,t:1526930018912};\\\", \\\"{x:690,y:705,t:1526930018928};\\\", \\\"{x:698,y:707,t:1526930018944};\\\", \\\"{x:702,y:707,t:1526930018962};\\\", \\\"{x:704,y:707,t:1526930020115};\\\", \\\"{x:705,y:706,t:1526930020129};\\\", \\\"{x:706,y:705,t:1526930020146};\\\", \\\"{x:706,y:704,t:1526930020164};\\\", \\\"{x:708,y:703,t:1526930020180};\\\", \\\"{x:709,y:703,t:1526930020209};\\\", \\\"{x:709,y:702,t:1526930020217};\\\", \\\"{x:710,y:702,t:1526930020230};\\\", \\\"{x:710,y:701,t:1526930020266};\\\", \\\"{x:711,y:701,t:1526930020298};\\\", \\\"{x:712,y:700,t:1526930020386};\\\", \\\"{x:713,y:699,t:1526930020522};\\\", \\\"{x:714,y:698,t:1526930020554};\\\", \\\"{x:715,y:697,t:1526930021434};\\\", \\\"{x:716,y:696,t:1526930021514};\\\", \\\"{x:716,y:695,t:1526930021538};\\\", \\\"{x:718,y:693,t:1526930027009};\\\", \\\"{x:722,y:692,t:1526930027018};\\\", \\\"{x:730,y:686,t:1526930027034};\\\", \\\"{x:744,y:678,t:1526930027051};\\\", \\\"{x:765,y:666,t:1526930027068};\\\", \\\"{x:791,y:655,t:1526930027084};\\\", \\\"{x:831,y:640,t:1526930027101};\\\", \\\"{x:887,y:623,t:1526930027118};\\\", \\\"{x:945,y:607,t:1526930027135};\\\", \\\"{x:994,y:589,t:1526930027151};\\\", \\\"{x:1048,y:568,t:1526930027168};\\\", \\\"{x:1124,y:552,t:1526930027185};\\\", \\\"{x:1156,y:547,t:1526930027201};\\\", \\\"{x:1178,y:544,t:1526930027218};\\\", \\\"{x:1195,y:542,t:1526930027234};\\\", \\\"{x:1214,y:542,t:1526930027251};\\\", \\\"{x:1229,y:542,t:1526930027268};\\\", \\\"{x:1245,y:542,t:1526930027284};\\\", \\\"{x:1264,y:545,t:1526930027301};\\\", \\\"{x:1289,y:548,t:1526930027318};\\\", \\\"{x:1301,y:549,t:1526930027335};\\\", \\\"{x:1301,y:552,t:1526930027546};\\\", \\\"{x:1301,y:555,t:1526930027554};\\\", \\\"{x:1297,y:562,t:1526930027569};\\\", \\\"{x:1283,y:577,t:1526930027586};\\\", \\\"{x:1281,y:581,t:1526930027601};\\\", \\\"{x:1274,y:589,t:1526930027619};\\\", \\\"{x:1266,y:598,t:1526930027635};\\\", \\\"{x:1258,y:605,t:1526930027653};\\\", \\\"{x:1252,y:610,t:1526930027669};\\\", \\\"{x:1242,y:617,t:1526930027685};\\\", \\\"{x:1232,y:626,t:1526930027702};\\\", \\\"{x:1222,y:639,t:1526930027719};\\\", \\\"{x:1209,y:653,t:1526930027736};\\\", \\\"{x:1202,y:660,t:1526930027753};\\\", \\\"{x:1193,y:668,t:1526930027769};\\\", \\\"{x:1184,y:678,t:1526930027785};\\\", \\\"{x:1178,y:684,t:1526930027802};\\\", \\\"{x:1176,y:687,t:1526930027818};\\\", \\\"{x:1172,y:690,t:1526930027834};\\\", \\\"{x:1169,y:694,t:1526930027852};\\\", \\\"{x:1165,y:696,t:1526930027868};\\\", \\\"{x:1163,y:698,t:1526930027885};\\\", \\\"{x:1162,y:700,t:1526930027902};\\\", \\\"{x:1163,y:700,t:1526930028025};\\\", \\\"{x:1165,y:700,t:1526930028035};\\\", \\\"{x:1171,y:698,t:1526930028051};\\\", \\\"{x:1175,y:696,t:1526930028069};\\\", \\\"{x:1180,y:695,t:1526930028085};\\\", \\\"{x:1187,y:695,t:1526930028102};\\\", \\\"{x:1194,y:695,t:1526930028119};\\\", \\\"{x:1200,y:695,t:1526930028135};\\\", \\\"{x:1208,y:695,t:1526930028152};\\\", \\\"{x:1214,y:695,t:1526930028169};\\\", \\\"{x:1219,y:695,t:1526930028185};\\\", \\\"{x:1227,y:695,t:1526930028202};\\\", \\\"{x:1233,y:695,t:1526930028219};\\\", \\\"{x:1237,y:695,t:1526930028235};\\\", \\\"{x:1244,y:694,t:1526930028253};\\\", \\\"{x:1254,y:694,t:1526930028269};\\\", \\\"{x:1265,y:694,t:1526930028285};\\\", \\\"{x:1279,y:694,t:1526930028302};\\\", \\\"{x:1292,y:691,t:1526930028319};\\\", \\\"{x:1299,y:689,t:1526930028335};\\\", \\\"{x:1306,y:685,t:1526930028352};\\\", \\\"{x:1314,y:681,t:1526930028369};\\\", \\\"{x:1316,y:678,t:1526930028386};\\\", \\\"{x:1318,y:677,t:1526930028402};\\\", \\\"{x:1322,y:672,t:1526930028420};\\\", \\\"{x:1325,y:668,t:1526930028435};\\\", \\\"{x:1327,y:665,t:1526930028452};\\\", \\\"{x:1329,y:663,t:1526930028470};\\\", \\\"{x:1331,y:661,t:1526930028486};\\\", \\\"{x:1332,y:660,t:1526930028502};\\\", \\\"{x:1333,y:659,t:1526930028522};\\\", \\\"{x:1335,y:658,t:1526930028538};\\\", \\\"{x:1336,y:658,t:1526930028554};\\\", \\\"{x:1337,y:656,t:1526930028569};\\\", \\\"{x:1338,y:656,t:1526930028586};\\\", \\\"{x:1340,y:654,t:1526930028603};\\\", \\\"{x:1341,y:654,t:1526930028619};\\\", \\\"{x:1342,y:653,t:1526930028636};\\\", \\\"{x:1344,y:653,t:1526930028652};\\\", \\\"{x:1346,y:652,t:1526930028669};\\\", \\\"{x:1349,y:650,t:1526930028686};\\\", \\\"{x:1351,y:649,t:1526930028702};\\\", \\\"{x:1354,y:647,t:1526930028720};\\\", \\\"{x:1356,y:645,t:1526930028736};\\\", \\\"{x:1358,y:645,t:1526930028762};\\\", \\\"{x:1359,y:644,t:1526930028770};\\\", \\\"{x:1360,y:643,t:1526930028794};\\\", \\\"{x:1360,y:642,t:1526930028802};\\\", \\\"{x:1362,y:642,t:1526930028819};\\\", \\\"{x:1362,y:640,t:1526930028837};\\\", \\\"{x:1363,y:640,t:1526930028853};\\\", \\\"{x:1365,y:639,t:1526930028870};\\\", \\\"{x:1366,y:639,t:1526930032066};\\\", \\\"{x:1369,y:637,t:1526930032074};\\\", \\\"{x:1371,y:637,t:1526930032088};\\\", \\\"{x:1382,y:635,t:1526930032105};\\\", \\\"{x:1390,y:635,t:1526930032121};\\\", \\\"{x:1398,y:635,t:1526930032138};\\\", \\\"{x:1399,y:635,t:1526930032169};\\\", \\\"{x:1401,y:635,t:1526930032201};\\\", \\\"{x:1402,y:634,t:1526930032217};\\\", \\\"{x:1403,y:634,t:1526930032225};\\\", \\\"{x:1403,y:633,t:1526930032238};\\\", \\\"{x:1404,y:633,t:1526930032290};\\\", \\\"{x:1406,y:633,t:1526930032304};\\\", \\\"{x:1407,y:633,t:1526930032322};\\\", \\\"{x:1409,y:633,t:1526930032345};\\\", \\\"{x:1410,y:633,t:1526930032361};\\\", \\\"{x:1411,y:634,t:1526930032372};\\\", \\\"{x:1411,y:635,t:1526930032417};\\\", \\\"{x:1411,y:636,t:1526930032449};\\\", \\\"{x:1412,y:636,t:1526930032481};\\\", \\\"{x:1412,y:639,t:1526930034426};\\\", \\\"{x:1412,y:640,t:1526930034441};\\\", \\\"{x:1414,y:646,t:1526930034457};\\\", \\\"{x:1417,y:654,t:1526930034474};\\\", \\\"{x:1417,y:659,t:1526930034491};\\\", \\\"{x:1417,y:662,t:1526930034507};\\\", \\\"{x:1417,y:665,t:1526930034524};\\\", \\\"{x:1415,y:669,t:1526930034541};\\\", \\\"{x:1413,y:671,t:1526930034557};\\\", \\\"{x:1410,y:673,t:1526930034574};\\\", \\\"{x:1405,y:675,t:1526930034591};\\\", \\\"{x:1403,y:677,t:1526930034607};\\\", \\\"{x:1402,y:677,t:1526930034624};\\\", \\\"{x:1400,y:679,t:1526930034641};\\\", \\\"{x:1398,y:680,t:1526930034657};\\\", \\\"{x:1395,y:682,t:1526930034674};\\\", \\\"{x:1392,y:682,t:1526930034691};\\\", \\\"{x:1387,y:683,t:1526930034708};\\\", \\\"{x:1386,y:683,t:1526930034724};\\\", \\\"{x:1380,y:683,t:1526930034741};\\\", \\\"{x:1378,y:683,t:1526930034758};\\\", \\\"{x:1375,y:683,t:1526930034774};\\\", \\\"{x:1373,y:683,t:1526930034791};\\\", \\\"{x:1369,y:683,t:1526930034808};\\\", \\\"{x:1366,y:683,t:1526930034824};\\\", \\\"{x:1363,y:683,t:1526930034841};\\\", \\\"{x:1362,y:683,t:1526930034858};\\\", \\\"{x:1360,y:683,t:1526930034873};\\\", \\\"{x:1359,y:684,t:1526930034891};\\\", \\\"{x:1356,y:684,t:1526930034908};\\\", \\\"{x:1352,y:684,t:1526930034924};\\\", \\\"{x:1349,y:684,t:1526930034941};\\\", \\\"{x:1346,y:684,t:1526930034958};\\\", \\\"{x:1345,y:684,t:1526930034974};\\\", \\\"{x:1343,y:684,t:1526930034990};\\\", \\\"{x:1342,y:684,t:1526930035008};\\\", \\\"{x:1340,y:684,t:1526930035023};\\\", \\\"{x:1337,y:684,t:1526930035040};\\\", \\\"{x:1336,y:684,t:1526930035306};\\\", \\\"{x:1335,y:684,t:1526930042954};\\\", \\\"{x:1328,y:684,t:1526930042964};\\\", \\\"{x:1301,y:677,t:1526930042980};\\\", \\\"{x:1278,y:672,t:1526930042996};\\\", \\\"{x:1235,y:668,t:1526930043012};\\\", \\\"{x:1188,y:664,t:1526930043030};\\\", \\\"{x:1118,y:662,t:1526930043047};\\\", \\\"{x:1056,y:652,t:1526930043063};\\\", \\\"{x:1007,y:649,t:1526930043080};\\\", \\\"{x:947,y:641,t:1526930043096};\\\", \\\"{x:920,y:633,t:1526930043112};\\\", \\\"{x:896,y:627,t:1526930043130};\\\", \\\"{x:876,y:622,t:1526930043147};\\\", \\\"{x:862,y:617,t:1526930043163};\\\", \\\"{x:849,y:616,t:1526930043181};\\\", \\\"{x:835,y:609,t:1526930043197};\\\", \\\"{x:813,y:600,t:1526930043215};\\\", \\\"{x:789,y:589,t:1526930043232};\\\", \\\"{x:767,y:577,t:1526930043247};\\\", \\\"{x:746,y:566,t:1526930043265};\\\", \\\"{x:739,y:562,t:1526930043281};\\\", \\\"{x:735,y:559,t:1526930043298};\\\", \\\"{x:734,y:558,t:1526930043315};\\\", \\\"{x:733,y:557,t:1526930043331};\\\", \\\"{x:732,y:556,t:1526930043348};\\\", \\\"{x:735,y:559,t:1526930043433};\\\", \\\"{x:746,y:565,t:1526930043448};\\\", \\\"{x:795,y:581,t:1526930043464};\\\", \\\"{x:833,y:589,t:1526930043481};\\\", \\\"{x:855,y:590,t:1526930043498};\\\", \\\"{x:866,y:590,t:1526930043515};\\\", \\\"{x:869,y:590,t:1526930043531};\\\", \\\"{x:870,y:590,t:1526930043548};\\\", \\\"{x:871,y:590,t:1526930043642};\\\", \\\"{x:872,y:590,t:1526930043649};\\\", \\\"{x:871,y:590,t:1526930043705};\\\", \\\"{x:869,y:588,t:1526930043715};\\\", \\\"{x:864,y:587,t:1526930043732};\\\", \\\"{x:860,y:585,t:1526930043749};\\\", \\\"{x:859,y:585,t:1526930043765};\\\", \\\"{x:857,y:584,t:1526930043810};\\\", \\\"{x:855,y:584,t:1526930043842};\\\", \\\"{x:852,y:584,t:1526930043849};\\\", \\\"{x:845,y:584,t:1526930043866};\\\", \\\"{x:837,y:584,t:1526930043882};\\\", \\\"{x:834,y:584,t:1526930043899};\\\", \\\"{x:832,y:584,t:1526930044233};\\\", \\\"{x:821,y:587,t:1526930044249};\\\", \\\"{x:803,y:591,t:1526930044266};\\\", \\\"{x:781,y:593,t:1526930044281};\\\", \\\"{x:752,y:593,t:1526930044298};\\\", \\\"{x:714,y:593,t:1526930044316};\\\", \\\"{x:682,y:593,t:1526930044331};\\\", \\\"{x:656,y:592,t:1526930044349};\\\", \\\"{x:636,y:590,t:1526930044366};\\\", \\\"{x:626,y:589,t:1526930044383};\\\", \\\"{x:617,y:589,t:1526930044398};\\\", \\\"{x:613,y:589,t:1526930044416};\\\", \\\"{x:610,y:589,t:1526930044432};\\\", \\\"{x:609,y:588,t:1526930044496};\\\", \\\"{x:610,y:586,t:1526930044505};\\\", \\\"{x:610,y:585,t:1526930044520};\\\", \\\"{x:610,y:584,t:1526930044532};\\\", \\\"{x:611,y:583,t:1526930044549};\\\", \\\"{x:614,y:579,t:1526930044565};\\\", \\\"{x:615,y:578,t:1526930044585};\\\", \\\"{x:615,y:584,t:1526930044832};\\\", \\\"{x:611,y:602,t:1526930044849};\\\", \\\"{x:606,y:615,t:1526930044865};\\\", \\\"{x:602,y:624,t:1526930044883};\\\", \\\"{x:599,y:630,t:1526930044899};\\\", \\\"{x:596,y:638,t:1526930044916};\\\", \\\"{x:589,y:649,t:1526930044932};\\\", \\\"{x:584,y:656,t:1526930044949};\\\", \\\"{x:581,y:661,t:1526930044965};\\\", \\\"{x:576,y:666,t:1526930044983};\\\", \\\"{x:572,y:671,t:1526930045000};\\\", \\\"{x:568,y:676,t:1526930045015};\\\", \\\"{x:563,y:681,t:1526930045032};\\\", \\\"{x:560,y:684,t:1526930045049};\\\", \\\"{x:559,y:687,t:1526930045065};\\\", \\\"{x:556,y:691,t:1526930045082};\\\", \\\"{x:554,y:695,t:1526930045100};\\\", \\\"{x:551,y:701,t:1526930045115};\\\", \\\"{x:544,y:713,t:1526930045133};\\\", \\\"{x:536,y:728,t:1526930045150};\\\", \\\"{x:532,y:741,t:1526930045166};\\\", \\\"{x:531,y:748,t:1526930045183};\\\", \\\"{x:529,y:750,t:1526930045199};\\\", \\\"{x:529,y:751,t:1526930045418};\\\", \\\"{x:531,y:751,t:1526930046704};\\\" ] }, { \\\"rt\\\": 31824, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 447658, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:546,y:745,t:1526930046901};\\\", \\\"{x:547,y:745,t:1526930046969};\\\", \\\"{x:549,y:742,t:1526930046994};\\\", \\\"{x:550,y:740,t:1526930047002};\\\", \\\"{x:550,y:737,t:1526930047017};\\\", \\\"{x:551,y:735,t:1526930047034};\\\", \\\"{x:553,y:733,t:1526930047051};\\\", \\\"{x:554,y:731,t:1526930047068};\\\", \\\"{x:556,y:730,t:1526930047084};\\\", \\\"{x:557,y:729,t:1526930047105};\\\", \\\"{x:557,y:728,t:1526930047168};\\\", \\\"{x:558,y:727,t:1526930047183};\\\", \\\"{x:559,y:725,t:1526930047200};\\\", \\\"{x:562,y:716,t:1526930047287};\\\", \\\"{x:563,y:713,t:1526930047300};\\\", \\\"{x:564,y:711,t:1526930047318};\\\", \\\"{x:565,y:711,t:1526930047602};\\\", \\\"{x:575,y:716,t:1526930047618};\\\", \\\"{x:590,y:719,t:1526930047635};\\\", \\\"{x:608,y:725,t:1526930047652};\\\", \\\"{x:653,y:740,t:1526930047668};\\\", \\\"{x:720,y:757,t:1526930047685};\\\", \\\"{x:755,y:762,t:1526930047702};\\\", \\\"{x:765,y:761,t:1526930047718};\\\", \\\"{x:768,y:759,t:1526930047735};\\\", \\\"{x:769,y:759,t:1526930052492};\\\", \\\"{x:770,y:758,t:1526930052510};\\\", \\\"{x:770,y:757,t:1526930052573};\\\", \\\"{x:770,y:756,t:1526930052589};\\\", \\\"{x:770,y:755,t:1526930052613};\\\", \\\"{x:770,y:754,t:1526930052645};\\\", \\\"{x:770,y:753,t:1526930052660};\\\", \\\"{x:770,y:752,t:1526930052677};\\\", \\\"{x:772,y:750,t:1526930052693};\\\", \\\"{x:774,y:747,t:1526930052710};\\\", \\\"{x:776,y:744,t:1526930052727};\\\", \\\"{x:778,y:739,t:1526930052743};\\\", \\\"{x:781,y:735,t:1526930052760};\\\", \\\"{x:783,y:731,t:1526930052777};\\\", \\\"{x:784,y:729,t:1526930052793};\\\", \\\"{x:785,y:727,t:1526930052810};\\\", \\\"{x:788,y:723,t:1526930052827};\\\", \\\"{x:793,y:717,t:1526930052844};\\\", \\\"{x:797,y:712,t:1526930052860};\\\", \\\"{x:802,y:703,t:1526930052877};\\\", \\\"{x:808,y:695,t:1526930052894};\\\", \\\"{x:816,y:685,t:1526930052911};\\\", \\\"{x:830,y:673,t:1526930052927};\\\", \\\"{x:838,y:662,t:1526930052944};\\\", \\\"{x:848,y:654,t:1526930052961};\\\", \\\"{x:860,y:647,t:1526930052977};\\\", \\\"{x:874,y:638,t:1526930052994};\\\", \\\"{x:900,y:623,t:1526930053012};\\\", \\\"{x:931,y:607,t:1526930053026};\\\", \\\"{x:984,y:583,t:1526930053045};\\\", \\\"{x:1087,y:555,t:1526930053059};\\\", \\\"{x:1194,y:528,t:1526930053075};\\\", \\\"{x:1286,y:501,t:1526930053092};\\\", \\\"{x:1355,y:489,t:1526930053108};\\\", \\\"{x:1376,y:484,t:1526930053124};\\\", \\\"{x:1385,y:484,t:1526930053141};\\\", \\\"{x:1386,y:484,t:1526930053158};\\\", \\\"{x:1386,y:483,t:1526930053175};\\\", \\\"{x:1387,y:484,t:1526930053405};\\\", \\\"{x:1392,y:484,t:1526930053413};\\\", \\\"{x:1399,y:485,t:1526930053425};\\\", \\\"{x:1414,y:490,t:1526930053442};\\\", \\\"{x:1434,y:493,t:1526930053459};\\\", \\\"{x:1456,y:495,t:1526930053475};\\\", \\\"{x:1482,y:500,t:1526930053492};\\\", \\\"{x:1506,y:504,t:1526930053509};\\\", \\\"{x:1525,y:506,t:1526930053527};\\\", \\\"{x:1541,y:509,t:1526930053542};\\\", \\\"{x:1546,y:509,t:1526930053559};\\\", \\\"{x:1545,y:509,t:1526930053789};\\\", \\\"{x:1539,y:508,t:1526930053797};\\\", \\\"{x:1533,y:505,t:1526930053809};\\\", \\\"{x:1524,y:501,t:1526930053827};\\\", \\\"{x:1504,y:494,t:1526930053843};\\\", \\\"{x:1487,y:491,t:1526930053860};\\\", \\\"{x:1482,y:490,t:1526930053876};\\\", \\\"{x:1480,y:490,t:1526930053893};\\\", \\\"{x:1479,y:489,t:1526930054589};\\\", \\\"{x:1479,y:488,t:1526930054613};\\\", \\\"{x:1478,y:488,t:1526930057045};\\\", \\\"{x:1476,y:488,t:1526930057062};\\\", \\\"{x:1474,y:490,t:1526930057078};\\\", \\\"{x:1469,y:493,t:1526930057095};\\\", \\\"{x:1468,y:493,t:1526930057111};\\\", \\\"{x:1466,y:495,t:1526930057129};\\\", \\\"{x:1463,y:496,t:1526930057144};\\\", \\\"{x:1457,y:498,t:1526930057162};\\\", \\\"{x:1444,y:499,t:1526930057178};\\\", \\\"{x:1429,y:501,t:1526930057195};\\\", \\\"{x:1415,y:501,t:1526930057211};\\\", \\\"{x:1401,y:501,t:1526930057228};\\\", \\\"{x:1399,y:501,t:1526930057244};\\\", \\\"{x:1393,y:501,t:1526930057261};\\\", \\\"{x:1390,y:502,t:1526930057278};\\\", \\\"{x:1390,y:503,t:1526930057295};\\\", \\\"{x:1392,y:503,t:1526930057428};\\\", \\\"{x:1399,y:503,t:1526930057445};\\\", \\\"{x:1406,y:503,t:1526930057460};\\\", \\\"{x:1416,y:503,t:1526930057478};\\\", \\\"{x:1423,y:503,t:1526930057495};\\\", \\\"{x:1431,y:499,t:1526930057511};\\\", \\\"{x:1433,y:499,t:1526930057528};\\\", \\\"{x:1436,y:496,t:1526930057545};\\\", \\\"{x:1439,y:495,t:1526930057561};\\\", \\\"{x:1442,y:494,t:1526930057580};\\\", \\\"{x:1443,y:493,t:1526930057604};\\\", \\\"{x:1445,y:493,t:1526930057628};\\\", \\\"{x:1447,y:491,t:1526930057645};\\\", \\\"{x:1449,y:490,t:1526930057661};\\\", \\\"{x:1450,y:489,t:1526930057679};\\\", \\\"{x:1451,y:489,t:1526930057696};\\\", \\\"{x:1453,y:489,t:1526930057757};\\\", \\\"{x:1454,y:489,t:1526930057765};\\\", \\\"{x:1459,y:489,t:1526930057779};\\\", \\\"{x:1466,y:489,t:1526930057796};\\\", \\\"{x:1475,y:489,t:1526930057811};\\\", \\\"{x:1487,y:489,t:1526930057829};\\\", \\\"{x:1494,y:491,t:1526930057845};\\\", \\\"{x:1496,y:491,t:1526930057862};\\\", \\\"{x:1497,y:491,t:1526930058078};\\\", \\\"{x:1497,y:493,t:1526930059622};\\\", \\\"{x:1495,y:494,t:1526930059629};\\\", \\\"{x:1493,y:495,t:1526930059647};\\\", \\\"{x:1492,y:497,t:1526930059693};\\\", \\\"{x:1491,y:497,t:1526930059702};\\\", \\\"{x:1489,y:499,t:1526930059717};\\\", \\\"{x:1485,y:502,t:1526930059730};\\\", \\\"{x:1480,y:511,t:1526930059746};\\\", \\\"{x:1473,y:517,t:1526930059763};\\\", \\\"{x:1462,y:524,t:1526930059780};\\\", \\\"{x:1447,y:535,t:1526930059797};\\\", \\\"{x:1438,y:540,t:1526930059813};\\\", \\\"{x:1428,y:545,t:1526930059830};\\\", \\\"{x:1420,y:551,t:1526930059847};\\\", \\\"{x:1411,y:558,t:1526930059864};\\\", \\\"{x:1400,y:564,t:1526930059879};\\\", \\\"{x:1388,y:571,t:1526930059897};\\\", \\\"{x:1378,y:578,t:1526930059914};\\\", \\\"{x:1376,y:580,t:1526930059930};\\\", \\\"{x:1374,y:581,t:1526930059947};\\\", \\\"{x:1372,y:581,t:1526930059964};\\\", \\\"{x:1372,y:584,t:1526930059980};\\\", \\\"{x:1370,y:586,t:1526930059997};\\\", \\\"{x:1369,y:587,t:1526930060014};\\\", \\\"{x:1369,y:590,t:1526930060029};\\\", \\\"{x:1367,y:592,t:1526930060047};\\\", \\\"{x:1367,y:593,t:1526930060064};\\\", \\\"{x:1364,y:598,t:1526930060080};\\\", \\\"{x:1363,y:603,t:1526930060096};\\\", \\\"{x:1361,y:608,t:1526930060114};\\\", \\\"{x:1361,y:614,t:1526930060129};\\\", \\\"{x:1360,y:618,t:1526930060146};\\\", \\\"{x:1360,y:625,t:1526930060164};\\\", \\\"{x:1360,y:631,t:1526930060180};\\\", \\\"{x:1360,y:639,t:1526930060197};\\\", \\\"{x:1360,y:644,t:1526930060213};\\\", \\\"{x:1360,y:648,t:1526930060230};\\\", \\\"{x:1360,y:652,t:1526930060247};\\\", \\\"{x:1360,y:655,t:1526930060263};\\\", \\\"{x:1360,y:662,t:1526930060279};\\\", \\\"{x:1360,y:672,t:1526930060297};\\\", \\\"{x:1360,y:682,t:1526930060313};\\\", \\\"{x:1360,y:689,t:1526930060330};\\\", \\\"{x:1360,y:693,t:1526930060346};\\\", \\\"{x:1360,y:696,t:1526930060363};\\\", \\\"{x:1363,y:707,t:1526930060380};\\\", \\\"{x:1367,y:717,t:1526930060396};\\\", \\\"{x:1368,y:722,t:1526930060413};\\\", \\\"{x:1369,y:725,t:1526930060430};\\\", \\\"{x:1369,y:727,t:1526930060446};\\\", \\\"{x:1370,y:730,t:1526930060463};\\\", \\\"{x:1371,y:734,t:1526930060481};\\\", \\\"{x:1371,y:736,t:1526930060496};\\\", \\\"{x:1371,y:738,t:1526930060513};\\\", \\\"{x:1371,y:741,t:1526930060530};\\\", \\\"{x:1371,y:744,t:1526930060547};\\\", \\\"{x:1369,y:750,t:1526930060564};\\\", \\\"{x:1364,y:757,t:1526930060580};\\\", \\\"{x:1361,y:760,t:1526930060596};\\\", \\\"{x:1358,y:763,t:1526930060614};\\\", \\\"{x:1355,y:765,t:1526930060631};\\\", \\\"{x:1353,y:767,t:1526930060646};\\\", \\\"{x:1352,y:768,t:1526930060663};\\\", \\\"{x:1352,y:769,t:1526930060680};\\\", \\\"{x:1351,y:769,t:1526930060701};\\\", \\\"{x:1350,y:769,t:1526930060714};\\\", \\\"{x:1350,y:770,t:1526930060733};\\\", \\\"{x:1349,y:770,t:1526930061006};\\\", \\\"{x:1349,y:768,t:1526930061056};\\\", \\\"{x:1344,y:777,t:1526930063221};\\\", \\\"{x:1342,y:790,t:1526930063231};\\\", \\\"{x:1334,y:812,t:1526930063248};\\\", \\\"{x:1328,y:833,t:1526930063265};\\\", \\\"{x:1321,y:852,t:1526930063281};\\\", \\\"{x:1312,y:874,t:1526930063298};\\\", \\\"{x:1303,y:896,t:1526930063315};\\\", \\\"{x:1298,y:911,t:1526930063332};\\\", \\\"{x:1295,y:923,t:1526930063348};\\\", \\\"{x:1293,y:938,t:1526930063365};\\\", \\\"{x:1290,y:954,t:1526930063382};\\\", \\\"{x:1286,y:963,t:1526930063398};\\\", \\\"{x:1285,y:964,t:1526930063415};\\\", \\\"{x:1283,y:965,t:1526930063432};\\\", \\\"{x:1281,y:967,t:1526930063448};\\\", \\\"{x:1279,y:968,t:1526930063466};\\\", \\\"{x:1276,y:969,t:1526930063482};\\\", \\\"{x:1275,y:969,t:1526930063498};\\\", \\\"{x:1272,y:969,t:1526930063516};\\\", \\\"{x:1266,y:969,t:1526930063532};\\\", \\\"{x:1255,y:969,t:1526930063549};\\\", \\\"{x:1248,y:969,t:1526930063565};\\\", \\\"{x:1243,y:969,t:1526930063582};\\\", \\\"{x:1241,y:969,t:1526930063599};\\\", \\\"{x:1238,y:968,t:1526930063616};\\\", \\\"{x:1237,y:968,t:1526930063632};\\\", \\\"{x:1235,y:968,t:1526930063648};\\\", \\\"{x:1233,y:968,t:1526930063666};\\\", \\\"{x:1228,y:968,t:1526930063682};\\\", \\\"{x:1226,y:968,t:1526930063699};\\\", \\\"{x:1225,y:968,t:1526930063715};\\\", \\\"{x:1224,y:968,t:1526930063733};\\\", \\\"{x:1221,y:968,t:1526930064062};\\\", \\\"{x:1220,y:968,t:1526930064077};\\\", \\\"{x:1218,y:968,t:1526930064085};\\\", \\\"{x:1216,y:968,t:1526930064101};\\\", \\\"{x:1215,y:968,t:1526930064133};\\\", \\\"{x:1214,y:968,t:1526930064149};\\\", \\\"{x:1213,y:968,t:1526930064167};\\\", \\\"{x:1212,y:968,t:1526930064183};\\\", \\\"{x:1211,y:968,t:1526930064198};\\\", \\\"{x:1211,y:967,t:1526930064237};\\\", \\\"{x:1211,y:966,t:1526930064249};\\\", \\\"{x:1210,y:965,t:1526930064266};\\\", \\\"{x:1209,y:965,t:1526930064285};\\\", \\\"{x:1209,y:964,t:1526930064341};\\\", \\\"{x:1209,y:963,t:1526930064349};\\\", \\\"{x:1209,y:962,t:1526930073662};\\\", \\\"{x:1209,y:961,t:1526930073672};\\\", \\\"{x:1208,y:959,t:1526930073688};\\\", \\\"{x:1206,y:959,t:1526930073705};\\\", \\\"{x:1205,y:954,t:1526930076581};\\\", \\\"{x:1200,y:948,t:1526930076591};\\\", \\\"{x:1191,y:937,t:1526930076607};\\\", \\\"{x:1170,y:919,t:1526930076623};\\\", \\\"{x:1139,y:891,t:1526930076641};\\\", \\\"{x:1071,y:834,t:1526930076656};\\\", \\\"{x:983,y:765,t:1526930076672};\\\", \\\"{x:883,y:690,t:1526930076689};\\\", \\\"{x:777,y:614,t:1526930076707};\\\", \\\"{x:681,y:554,t:1526930076724};\\\", \\\"{x:541,y:492,t:1526930076740};\\\", \\\"{x:472,y:459,t:1526930076762};\\\", \\\"{x:434,y:439,t:1526930076779};\\\", \\\"{x:420,y:426,t:1526930076794};\\\", \\\"{x:413,y:420,t:1526930076812};\\\", \\\"{x:416,y:420,t:1526930076924};\\\", \\\"{x:425,y:420,t:1526930076932};\\\", \\\"{x:435,y:424,t:1526930076945};\\\", \\\"{x:473,y:441,t:1526930076962};\\\", \\\"{x:513,y:468,t:1526930076978};\\\", \\\"{x:543,y:499,t:1526930076995};\\\", \\\"{x:589,y:541,t:1526930077013};\\\", \\\"{x:610,y:561,t:1526930077029};\\\", \\\"{x:620,y:572,t:1526930077046};\\\", \\\"{x:622,y:575,t:1526930077062};\\\", \\\"{x:622,y:576,t:1526930077079};\\\", \\\"{x:623,y:578,t:1526930077165};\\\", \\\"{x:625,y:580,t:1526930077179};\\\", \\\"{x:637,y:581,t:1526930077196};\\\", \\\"{x:650,y:581,t:1526930077213};\\\", \\\"{x:659,y:581,t:1526930077229};\\\", \\\"{x:681,y:580,t:1526930077246};\\\", \\\"{x:704,y:577,t:1526930077262};\\\", \\\"{x:727,y:577,t:1526930077280};\\\", \\\"{x:739,y:577,t:1526930077296};\\\", \\\"{x:741,y:577,t:1526930077311};\\\", \\\"{x:742,y:577,t:1526930077328};\\\", \\\"{x:743,y:577,t:1526930077346};\\\", \\\"{x:744,y:577,t:1526930077436};\\\", \\\"{x:745,y:575,t:1526930077446};\\\", \\\"{x:746,y:573,t:1526930077462};\\\", \\\"{x:746,y:572,t:1526930077478};\\\", \\\"{x:751,y:567,t:1526930077495};\\\", \\\"{x:757,y:563,t:1526930077512};\\\", \\\"{x:764,y:558,t:1526930077529};\\\", \\\"{x:780,y:552,t:1526930077546};\\\", \\\"{x:796,y:546,t:1526930077562};\\\", \\\"{x:811,y:542,t:1526930077579};\\\", \\\"{x:821,y:541,t:1526930077596};\\\", \\\"{x:823,y:541,t:1526930077612};\\\", \\\"{x:825,y:541,t:1526930077669};\\\", \\\"{x:826,y:541,t:1526930077692};\\\", \\\"{x:828,y:541,t:1526930077708};\\\", \\\"{x:829,y:541,t:1526930077725};\\\", \\\"{x:830,y:541,t:1526930077740};\\\", \\\"{x:830,y:544,t:1526930077956};\\\", \\\"{x:822,y:560,t:1526930077964};\\\", \\\"{x:785,y:610,t:1526930077980};\\\", \\\"{x:723,y:670,t:1526930077996};\\\", \\\"{x:654,y:713,t:1526930078013};\\\", \\\"{x:593,y:743,t:1526930078030};\\\", \\\"{x:558,y:761,t:1526930078046};\\\", \\\"{x:539,y:772,t:1526930078063};\\\", \\\"{x:527,y:779,t:1526930078079};\\\", \\\"{x:520,y:785,t:1526930078095};\\\", \\\"{x:515,y:791,t:1526930078113};\\\", \\\"{x:513,y:793,t:1526930078129};\\\", \\\"{x:512,y:794,t:1526930078146};\\\", \\\"{x:512,y:792,t:1526930078236};\\\", \\\"{x:512,y:790,t:1526930078246};\\\", \\\"{x:514,y:784,t:1526930078263};\\\", \\\"{x:518,y:779,t:1526930078281};\\\", \\\"{x:522,y:773,t:1526930078296};\\\", \\\"{x:524,y:765,t:1526930078313};\\\", \\\"{x:528,y:757,t:1526930078330};\\\", \\\"{x:529,y:755,t:1526930078357};\\\", \\\"{x:530,y:754,t:1526930078373};\\\", \\\"{x:530,y:751,t:1526930078396};\\\", \\\"{x:530,y:748,t:1526930078419};\\\", \\\"{x:530,y:747,t:1526930078443};\\\", \\\"{x:531,y:745,t:1526930078468};\\\", \\\"{x:531,y:744,t:1526930078492};\\\", \\\"{x:532,y:742,t:1526930078540};\\\", \\\"{x:533,y:740,t:1526930078564};\\\", \\\"{x:534,y:738,t:1526930078597};\\\", \\\"{x:536,y:738,t:1526930079213};\\\", \\\"{x:544,y:739,t:1526930079221};\\\", \\\"{x:552,y:743,t:1526930079230};\\\", \\\"{x:576,y:753,t:1526930079247};\\\", \\\"{x:588,y:759,t:1526930079264};\\\", \\\"{x:599,y:763,t:1526930079280};\\\", \\\"{x:605,y:764,t:1526930079297};\\\", \\\"{x:608,y:764,t:1526930079314};\\\", \\\"{x:613,y:761,t:1526930079330};\\\", \\\"{x:619,y:759,t:1526930079347};\\\", \\\"{x:622,y:759,t:1526930079364};\\\", \\\"{x:623,y:759,t:1526930079428};\\\", \\\"{x:627,y:759,t:1526930079437};\\\", \\\"{x:633,y:759,t:1526930079447};\\\", \\\"{x:642,y:757,t:1526930079464};\\\", \\\"{x:644,y:757,t:1526930079481};\\\", \\\"{x:645,y:757,t:1526930079508};\\\", \\\"{x:646,y:757,t:1526930079533};\\\", \\\"{x:648,y:757,t:1526930079548};\\\", \\\"{x:650,y:757,t:1526930079581};\\\" ] }, { \\\"rt\\\": 42712, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 491641, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:651,y:757,t:1526930080031};\\\", \\\"{x:649,y:757,t:1526930081909};\\\", \\\"{x:648,y:757,t:1526930081936};\\\", \\\"{x:647,y:757,t:1526930081949};\\\", \\\"{x:646,y:756,t:1526930085229};\\\", \\\"{x:647,y:755,t:1526930085236};\\\", \\\"{x:648,y:754,t:1526930086197};\\\", \\\"{x:649,y:753,t:1526930086909};\\\", \\\"{x:650,y:752,t:1526930086919};\\\", \\\"{x:654,y:748,t:1526930086936};\\\", \\\"{x:655,y:747,t:1526930086958};\\\", \\\"{x:655,y:746,t:1526930087085};\\\", \\\"{x:656,y:745,t:1526930087093};\\\", \\\"{x:657,y:744,t:1526930087117};\\\", \\\"{x:658,y:743,t:1526930087141};\\\", \\\"{x:658,y:742,t:1526930087158};\\\", \\\"{x:659,y:742,t:1526930087181};\\\", \\\"{x:659,y:741,t:1526930087189};\\\", \\\"{x:660,y:741,t:1526930087203};\\\", \\\"{x:661,y:740,t:1526930087219};\\\", \\\"{x:662,y:740,t:1526930087237};\\\", \\\"{x:665,y:738,t:1526930087254};\\\", \\\"{x:666,y:736,t:1526930087717};\\\", \\\"{x:667,y:736,t:1526930087748};\\\", \\\"{x:667,y:735,t:1526930087812};\\\", \\\"{x:668,y:735,t:1526930087820};\\\", \\\"{x:671,y:733,t:1526930090021};\\\", \\\"{x:693,y:730,t:1526930090039};\\\", \\\"{x:719,y:731,t:1526930090055};\\\", \\\"{x:751,y:738,t:1526930090072};\\\", \\\"{x:789,y:747,t:1526930090088};\\\", \\\"{x:828,y:758,t:1526930090106};\\\", \\\"{x:880,y:769,t:1526930090122};\\\", \\\"{x:913,y:775,t:1526930090139};\\\", \\\"{x:939,y:781,t:1526930090157};\\\", \\\"{x:944,y:784,t:1526930090172};\\\", \\\"{x:957,y:788,t:1526930090188};\\\", \\\"{x:961,y:790,t:1526930090206};\\\", \\\"{x:965,y:793,t:1526930090222};\\\", \\\"{x:967,y:794,t:1526930090239};\\\", \\\"{x:968,y:795,t:1526930090257};\\\", \\\"{x:970,y:798,t:1526930090272};\\\", \\\"{x:975,y:803,t:1526930090288};\\\", \\\"{x:983,y:807,t:1526930090307};\\\", \\\"{x:991,y:812,t:1526930090323};\\\", \\\"{x:1004,y:817,t:1526930090339};\\\", \\\"{x:1020,y:823,t:1526930090356};\\\", \\\"{x:1043,y:835,t:1526930090372};\\\", \\\"{x:1055,y:841,t:1526930090389};\\\", \\\"{x:1066,y:845,t:1526930090406};\\\", \\\"{x:1071,y:849,t:1526930090422};\\\", \\\"{x:1073,y:850,t:1526930090439};\\\", \\\"{x:1073,y:852,t:1526930090460};\\\", \\\"{x:1076,y:855,t:1526930090473};\\\", \\\"{x:1081,y:865,t:1526930090489};\\\", \\\"{x:1088,y:876,t:1526930090506};\\\", \\\"{x:1094,y:880,t:1526930090522};\\\", \\\"{x:1098,y:884,t:1526930090538};\\\", \\\"{x:1102,y:889,t:1526930090557};\\\", \\\"{x:1110,y:895,t:1526930090572};\\\", \\\"{x:1111,y:903,t:1526930090589};\\\", \\\"{x:1115,y:909,t:1526930090606};\\\", \\\"{x:1118,y:913,t:1526930090628};\\\", \\\"{x:1118,y:915,t:1526930090639};\\\", \\\"{x:1123,y:926,t:1526930090656};\\\", \\\"{x:1128,y:936,t:1526930090673};\\\", \\\"{x:1129,y:942,t:1526930090690};\\\", \\\"{x:1130,y:943,t:1526930090706};\\\", \\\"{x:1131,y:945,t:1526930090722};\\\", \\\"{x:1131,y:946,t:1526930090741};\\\", \\\"{x:1132,y:948,t:1526930090758};\\\", \\\"{x:1132,y:949,t:1526930090788};\\\", \\\"{x:1133,y:949,t:1526930090837};\\\", \\\"{x:1134,y:949,t:1526930090845};\\\", \\\"{x:1135,y:951,t:1526930090856};\\\", \\\"{x:1139,y:954,t:1526930090872};\\\", \\\"{x:1144,y:957,t:1526930090890};\\\", \\\"{x:1146,y:958,t:1526930090906};\\\", \\\"{x:1148,y:960,t:1526930090923};\\\", \\\"{x:1149,y:961,t:1526930090940};\\\", \\\"{x:1150,y:961,t:1526930090956};\\\", \\\"{x:1151,y:961,t:1526930090972};\\\", \\\"{x:1152,y:962,t:1526930090990};\\\", \\\"{x:1153,y:962,t:1526930091006};\\\", \\\"{x:1152,y:962,t:1526930091389};\\\", \\\"{x:1151,y:962,t:1526930091429};\\\", \\\"{x:1150,y:962,t:1526930091573};\\\", \\\"{x:1149,y:962,t:1526930091605};\\\", \\\"{x:1146,y:962,t:1526930091805};\\\", \\\"{x:1145,y:962,t:1526930091813};\\\", \\\"{x:1142,y:962,t:1526930091824};\\\", \\\"{x:1133,y:958,t:1526930091840};\\\", \\\"{x:1122,y:957,t:1526930091857};\\\", \\\"{x:1114,y:956,t:1526930091874};\\\", \\\"{x:1111,y:955,t:1526930091890};\\\", \\\"{x:1105,y:954,t:1526930091907};\\\", \\\"{x:1103,y:953,t:1526930091924};\\\", \\\"{x:1101,y:953,t:1526930091940};\\\", \\\"{x:1100,y:953,t:1526930091981};\\\", \\\"{x:1100,y:952,t:1526930091990};\\\", \\\"{x:1098,y:952,t:1526930092006};\\\", \\\"{x:1096,y:952,t:1526930092028};\\\", \\\"{x:1095,y:952,t:1526930092044};\\\", \\\"{x:1092,y:952,t:1526930092057};\\\", \\\"{x:1091,y:952,t:1526930092074};\\\", \\\"{x:1089,y:952,t:1526930092158};\\\", \\\"{x:1089,y:951,t:1526930093173};\\\", \\\"{x:1089,y:950,t:1526930094269};\\\", \\\"{x:1089,y:947,t:1526930094645};\\\", \\\"{x:1089,y:944,t:1526930094660};\\\", \\\"{x:1093,y:935,t:1526930094676};\\\", \\\"{x:1094,y:933,t:1526930094692};\\\", \\\"{x:1097,y:928,t:1526930094709};\\\", \\\"{x:1099,y:925,t:1526930094726};\\\", \\\"{x:1100,y:921,t:1526930094742};\\\", \\\"{x:1101,y:917,t:1526930094759};\\\", \\\"{x:1103,y:910,t:1526930094776};\\\", \\\"{x:1107,y:902,t:1526930094792};\\\", \\\"{x:1113,y:896,t:1526930094809};\\\", \\\"{x:1114,y:893,t:1526930094826};\\\", \\\"{x:1117,y:889,t:1526930094842};\\\", \\\"{x:1119,y:885,t:1526930094859};\\\", \\\"{x:1122,y:882,t:1526930094877};\\\", \\\"{x:1125,y:879,t:1526930094893};\\\", \\\"{x:1128,y:875,t:1526930094909};\\\", \\\"{x:1133,y:867,t:1526930094926};\\\", \\\"{x:1137,y:861,t:1526930094942};\\\", \\\"{x:1141,y:853,t:1526930094959};\\\", \\\"{x:1145,y:847,t:1526930094976};\\\", \\\"{x:1146,y:843,t:1526930094993};\\\", \\\"{x:1150,y:835,t:1526930095009};\\\", \\\"{x:1154,y:828,t:1526930095026};\\\", \\\"{x:1154,y:825,t:1526930095043};\\\", \\\"{x:1155,y:822,t:1526930095059};\\\", \\\"{x:1157,y:819,t:1526930095077};\\\", \\\"{x:1158,y:817,t:1526930095092};\\\", \\\"{x:1158,y:815,t:1526930095109};\\\", \\\"{x:1160,y:811,t:1526930095126};\\\", \\\"{x:1160,y:810,t:1526930095143};\\\", \\\"{x:1161,y:810,t:1526930095159};\\\", \\\"{x:1161,y:809,t:1526930095196};\\\", \\\"{x:1162,y:805,t:1526930095509};\\\", \\\"{x:1171,y:788,t:1526930095526};\\\", \\\"{x:1177,y:770,t:1526930095544};\\\", \\\"{x:1183,y:755,t:1526930095560};\\\", \\\"{x:1188,y:746,t:1526930095576};\\\", \\\"{x:1192,y:739,t:1526930095593};\\\", \\\"{x:1193,y:733,t:1526930095610};\\\", \\\"{x:1195,y:730,t:1526930095626};\\\", \\\"{x:1196,y:723,t:1526930095643};\\\", \\\"{x:1200,y:711,t:1526930095661};\\\", \\\"{x:1203,y:701,t:1526930095676};\\\", \\\"{x:1204,y:694,t:1526930095693};\\\", \\\"{x:1207,y:688,t:1526930095710};\\\", \\\"{x:1208,y:683,t:1526930095726};\\\", \\\"{x:1209,y:679,t:1526930095743};\\\", \\\"{x:1211,y:676,t:1526930095760};\\\", \\\"{x:1211,y:674,t:1526930095776};\\\", \\\"{x:1212,y:672,t:1526930095793};\\\", \\\"{x:1214,y:669,t:1526930095810};\\\", \\\"{x:1216,y:667,t:1526930095826};\\\", \\\"{x:1219,y:664,t:1526930095843};\\\", \\\"{x:1222,y:658,t:1526930095860};\\\", \\\"{x:1228,y:650,t:1526930095876};\\\", \\\"{x:1233,y:643,t:1526930095893};\\\", \\\"{x:1240,y:631,t:1526930095910};\\\", \\\"{x:1245,y:626,t:1526930095927};\\\", \\\"{x:1253,y:616,t:1526930095943};\\\", \\\"{x:1256,y:612,t:1526930095960};\\\", \\\"{x:1259,y:609,t:1526930095977};\\\", \\\"{x:1261,y:605,t:1526930095993};\\\", \\\"{x:1266,y:593,t:1526930096010};\\\", \\\"{x:1269,y:588,t:1526930096027};\\\", \\\"{x:1270,y:584,t:1526930096043};\\\", \\\"{x:1273,y:579,t:1526930096060};\\\", \\\"{x:1273,y:578,t:1526930096084};\\\", \\\"{x:1273,y:577,t:1526930096381};\\\", \\\"{x:1273,y:575,t:1526930096396};\\\", \\\"{x:1273,y:574,t:1526930096410};\\\", \\\"{x:1273,y:573,t:1526930104773};\\\", \\\"{x:1267,y:580,t:1526930104784};\\\", \\\"{x:1244,y:604,t:1526930104799};\\\", \\\"{x:1230,y:617,t:1526930104817};\\\", \\\"{x:1216,y:631,t:1526930104833};\\\", \\\"{x:1206,y:641,t:1526930104849};\\\", \\\"{x:1199,y:655,t:1526930104867};\\\", \\\"{x:1196,y:665,t:1526930104884};\\\", \\\"{x:1192,y:676,t:1526930104900};\\\", \\\"{x:1190,y:692,t:1526930104916};\\\", \\\"{x:1186,y:704,t:1526930104933};\\\", \\\"{x:1182,y:717,t:1526930104951};\\\", \\\"{x:1178,y:729,t:1526930104967};\\\", \\\"{x:1175,y:737,t:1526930104983};\\\", \\\"{x:1175,y:742,t:1526930105000};\\\", \\\"{x:1175,y:750,t:1526930105016};\\\", \\\"{x:1173,y:757,t:1526930105033};\\\", \\\"{x:1172,y:760,t:1526930105050};\\\", \\\"{x:1171,y:764,t:1526930105067};\\\", \\\"{x:1171,y:767,t:1526930105084};\\\", \\\"{x:1170,y:772,t:1526930105100};\\\", \\\"{x:1169,y:774,t:1526930105117};\\\", \\\"{x:1169,y:776,t:1526930105133};\\\", \\\"{x:1169,y:778,t:1526930105150};\\\", \\\"{x:1169,y:779,t:1526930105196};\\\", \\\"{x:1169,y:781,t:1526930113721};\\\", \\\"{x:1175,y:786,t:1526930113727};\\\", \\\"{x:1202,y:795,t:1526930113743};\\\", \\\"{x:1218,y:802,t:1526930113759};\\\", \\\"{x:1230,y:810,t:1526930113776};\\\", \\\"{x:1240,y:819,t:1526930113793};\\\", \\\"{x:1243,y:823,t:1526930113811};\\\", \\\"{x:1243,y:824,t:1526930113864};\\\", \\\"{x:1243,y:825,t:1526930113876};\\\", \\\"{x:1243,y:829,t:1526930113893};\\\", \\\"{x:1243,y:830,t:1526930114039};\\\", \\\"{x:1242,y:829,t:1526930114047};\\\", \\\"{x:1242,y:825,t:1526930114060};\\\", \\\"{x:1240,y:814,t:1526930114076};\\\", \\\"{x:1240,y:801,t:1526930114093};\\\", \\\"{x:1241,y:791,t:1526930114110};\\\", \\\"{x:1245,y:782,t:1526930114127};\\\", \\\"{x:1248,y:779,t:1526930114142};\\\", \\\"{x:1251,y:773,t:1526930114161};\\\", \\\"{x:1254,y:768,t:1526930114177};\\\", \\\"{x:1256,y:765,t:1526930114193};\\\", \\\"{x:1257,y:763,t:1526930114210};\\\", \\\"{x:1258,y:761,t:1526930114227};\\\", \\\"{x:1259,y:760,t:1526930114243};\\\", \\\"{x:1259,y:759,t:1526930114304};\\\", \\\"{x:1260,y:758,t:1526930114336};\\\", \\\"{x:1264,y:759,t:1526930115206};\\\", \\\"{x:1269,y:766,t:1526930115215};\\\", \\\"{x:1274,y:772,t:1526930115227};\\\", \\\"{x:1279,y:776,t:1526930115243};\\\", \\\"{x:1285,y:780,t:1526930115260};\\\", \\\"{x:1287,y:781,t:1526930115277};\\\", \\\"{x:1289,y:782,t:1526930115294};\\\", \\\"{x:1292,y:784,t:1526930115311};\\\", \\\"{x:1293,y:784,t:1526930115335};\\\", \\\"{x:1294,y:784,t:1526930115351};\\\", \\\"{x:1295,y:785,t:1526930115360};\\\", \\\"{x:1296,y:785,t:1526930115377};\\\", \\\"{x:1297,y:785,t:1526930115394};\\\", \\\"{x:1301,y:785,t:1526930115680};\\\", \\\"{x:1306,y:782,t:1526930115695};\\\", \\\"{x:1311,y:779,t:1526930115711};\\\", \\\"{x:1313,y:778,t:1526930115729};\\\", \\\"{x:1316,y:777,t:1526930115744};\\\", \\\"{x:1322,y:775,t:1526930115762};\\\", \\\"{x:1327,y:772,t:1526930115779};\\\", \\\"{x:1333,y:770,t:1526930115794};\\\", \\\"{x:1335,y:769,t:1526930115811};\\\", \\\"{x:1337,y:767,t:1526930115828};\\\", \\\"{x:1339,y:767,t:1526930115845};\\\", \\\"{x:1341,y:765,t:1526930115861};\\\", \\\"{x:1343,y:763,t:1526930115881};\\\", \\\"{x:1344,y:761,t:1526930115895};\\\", \\\"{x:1346,y:761,t:1526930115911};\\\", \\\"{x:1347,y:760,t:1526930115928};\\\", \\\"{x:1340,y:760,t:1526930121329};\\\", \\\"{x:1336,y:758,t:1526930121336};\\\", \\\"{x:1324,y:756,t:1526930121348};\\\", \\\"{x:1298,y:751,t:1526930121366};\\\", \\\"{x:1253,y:744,t:1526930121383};\\\", \\\"{x:1217,y:736,t:1526930121398};\\\", \\\"{x:1202,y:730,t:1526930121415};\\\", \\\"{x:1172,y:726,t:1526930121433};\\\", \\\"{x:1133,y:713,t:1526930121449};\\\", \\\"{x:1125,y:709,t:1526930121465};\\\", \\\"{x:1121,y:704,t:1526930121482};\\\", \\\"{x:1114,y:700,t:1526930121498};\\\", \\\"{x:1113,y:700,t:1526930121516};\\\", \\\"{x:1112,y:700,t:1526930121533};\\\", \\\"{x:1112,y:698,t:1526930121549};\\\", \\\"{x:1109,y:700,t:1526930121565};\\\", \\\"{x:1108,y:707,t:1526930121582};\\\", \\\"{x:1107,y:714,t:1526930121599};\\\", \\\"{x:1100,y:728,t:1526930121615};\\\", \\\"{x:1090,y:743,t:1526930121632};\\\", \\\"{x:1078,y:759,t:1526930121650};\\\", \\\"{x:1059,y:772,t:1526930121666};\\\", \\\"{x:1033,y:787,t:1526930121683};\\\", \\\"{x:1007,y:800,t:1526930121699};\\\", \\\"{x:979,y:816,t:1526930121716};\\\", \\\"{x:940,y:835,t:1526930121732};\\\", \\\"{x:900,y:847,t:1526930121749};\\\", \\\"{x:874,y:857,t:1526930121766};\\\", \\\"{x:853,y:859,t:1526930121782};\\\", \\\"{x:837,y:860,t:1526930121799};\\\", \\\"{x:821,y:860,t:1526930121815};\\\", \\\"{x:792,y:860,t:1526930121833};\\\", \\\"{x:768,y:855,t:1526930121850};\\\", \\\"{x:747,y:850,t:1526930121866};\\\", \\\"{x:714,y:839,t:1526930121882};\\\", \\\"{x:684,y:831,t:1526930121899};\\\", \\\"{x:658,y:821,t:1526930121916};\\\", \\\"{x:637,y:813,t:1526930121932};\\\", \\\"{x:625,y:808,t:1526930121949};\\\", \\\"{x:622,y:804,t:1526930121965};\\\", \\\"{x:618,y:797,t:1526930121983};\\\", \\\"{x:609,y:783,t:1526930121999};\\\", \\\"{x:601,y:774,t:1526930122015};\\\", \\\"{x:597,y:768,t:1526930122032};\\\", \\\"{x:584,y:758,t:1526930122050};\\\", \\\"{x:572,y:749,t:1526930122066};\\\", \\\"{x:564,y:744,t:1526930122083};\\\", \\\"{x:559,y:739,t:1526930122099};\\\", \\\"{x:553,y:735,t:1526930122116};\\\", \\\"{x:543,y:730,t:1526930122134};\\\", \\\"{x:537,y:728,t:1526930122151};\\\", \\\"{x:531,y:726,t:1526930122168};\\\", \\\"{x:530,y:726,t:1526930122185};\\\", \\\"{x:528,y:726,t:1526930122201};\\\", \\\"{x:526,y:726,t:1526930122217};\\\", \\\"{x:525,y:726,t:1526930122254};\\\", \\\"{x:524,y:726,t:1526930122384};\\\", \\\"{x:523,y:726,t:1526930122392};\\\", \\\"{x:522,y:726,t:1526930122407};\\\", \\\"{x:522,y:727,t:1526930122418};\\\", \\\"{x:522,y:729,t:1526930122436};\\\", \\\"{x:521,y:732,t:1526930122453};\\\", \\\"{x:521,y:734,t:1526930122468};\\\", \\\"{x:520,y:736,t:1526930122486};\\\", \\\"{x:525,y:736,t:1526930122999};\\\", \\\"{x:538,y:736,t:1526930123007};\\\", \\\"{x:553,y:736,t:1526930123019};\\\", \\\"{x:589,y:736,t:1526930123034};\\\", \\\"{x:624,y:735,t:1526930123052};\\\", \\\"{x:657,y:735,t:1526930123069};\\\", \\\"{x:696,y:735,t:1526930123084};\\\", \\\"{x:752,y:735,t:1526930123102};\\\", \\\"{x:814,y:729,t:1526930123119};\\\", \\\"{x:830,y:725,t:1526930123135};\\\", \\\"{x:833,y:725,t:1526930123152};\\\", \\\"{x:834,y:725,t:1526930123169};\\\" ] }, { \\\"rt\\\": 8204, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 501156, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:833,y:725,t:1526930130200};\\\", \\\"{x:832,y:725,t:1526930130207};\\\", \\\"{x:824,y:724,t:1526930130224};\\\", \\\"{x:813,y:723,t:1526930130241};\\\", \\\"{x:793,y:720,t:1526930130258};\\\", \\\"{x:777,y:720,t:1526930130275};\\\", \\\"{x:760,y:719,t:1526930130290};\\\", \\\"{x:744,y:718,t:1526930130308};\\\", \\\"{x:725,y:715,t:1526930130325};\\\", \\\"{x:701,y:710,t:1526930130341};\\\", \\\"{x:678,y:700,t:1526930130357};\\\", \\\"{x:626,y:673,t:1526930130375};\\\", \\\"{x:585,y:650,t:1526930130391};\\\", \\\"{x:548,y:630,t:1526930130409};\\\", \\\"{x:524,y:612,t:1526930130424};\\\", \\\"{x:514,y:601,t:1526930130441};\\\", \\\"{x:509,y:591,t:1526930130457};\\\", \\\"{x:508,y:579,t:1526930130474};\\\", \\\"{x:508,y:564,t:1526930130492};\\\", \\\"{x:518,y:542,t:1526930130509};\\\", \\\"{x:532,y:526,t:1526930130524};\\\", \\\"{x:545,y:514,t:1526930130542};\\\", \\\"{x:552,y:507,t:1526930130558};\\\", \\\"{x:555,y:505,t:1526930130574};\\\", \\\"{x:558,y:503,t:1526930130591};\\\", \\\"{x:561,y:501,t:1526930130608};\\\", \\\"{x:570,y:496,t:1526930130624};\\\", \\\"{x:577,y:494,t:1526930130641};\\\", \\\"{x:588,y:493,t:1526930130658};\\\", \\\"{x:601,y:493,t:1526930130674};\\\", \\\"{x:607,y:493,t:1526930130691};\\\", \\\"{x:608,y:493,t:1526930130708};\\\", \\\"{x:609,y:493,t:1526930130725};\\\", \\\"{x:610,y:493,t:1526930130742};\\\", \\\"{x:611,y:494,t:1526930130758};\\\", \\\"{x:614,y:496,t:1526930130774};\\\", \\\"{x:616,y:498,t:1526930130791};\\\", \\\"{x:616,y:499,t:1526930130808};\\\", \\\"{x:617,y:499,t:1526930130831};\\\", \\\"{x:613,y:504,t:1526930131150};\\\", \\\"{x:606,y:519,t:1526930131158};\\\", \\\"{x:581,y:574,t:1526930131176};\\\", \\\"{x:542,y:645,t:1526930131193};\\\", \\\"{x:505,y:710,t:1526930131208};\\\", \\\"{x:471,y:763,t:1526930131225};\\\", \\\"{x:454,y:790,t:1526930131243};\\\", \\\"{x:447,y:808,t:1526930131258};\\\", \\\"{x:443,y:816,t:1526930131276};\\\", \\\"{x:443,y:819,t:1526930131292};\\\", \\\"{x:443,y:823,t:1526930131308};\\\", \\\"{x:443,y:829,t:1526930131326};\\\", \\\"{x:445,y:836,t:1526930131342};\\\", \\\"{x:445,y:838,t:1526930131358};\\\", \\\"{x:446,y:838,t:1526930131431};\\\", \\\"{x:448,y:838,t:1526930131443};\\\", \\\"{x:455,y:821,t:1526930131458};\\\", \\\"{x:466,y:804,t:1526930131476};\\\", \\\"{x:471,y:794,t:1526930131493};\\\", \\\"{x:478,y:784,t:1526930131509};\\\", \\\"{x:483,y:774,t:1526930131525};\\\", \\\"{x:488,y:763,t:1526930131543};\\\", \\\"{x:492,y:757,t:1526930131559};\\\", \\\"{x:496,y:753,t:1526930131577};\\\", \\\"{x:497,y:751,t:1526930131592};\\\", \\\"{x:498,y:750,t:1526930131638};\\\" ] }, { \\\"rt\\\": 10932, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 513298, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:743,t:1526930141767};\\\", \\\"{x:498,y:720,t:1526930141780};\\\", \\\"{x:482,y:658,t:1526930141807};\\\", \\\"{x:477,y:638,t:1526930141814};\\\", \\\"{x:470,y:612,t:1526930141830};\\\", \\\"{x:467,y:594,t:1526930141867};\\\", \\\"{x:471,y:580,t:1526930141884};\\\", \\\"{x:486,y:558,t:1526930141901};\\\", \\\"{x:501,y:544,t:1526930141917};\\\", \\\"{x:517,y:530,t:1526930141934};\\\", \\\"{x:545,y:514,t:1526930141951};\\\", \\\"{x:563,y:508,t:1526930141967};\\\", \\\"{x:572,y:506,t:1526930141983};\\\", \\\"{x:575,y:505,t:1526930141999};\\\", \\\"{x:577,y:505,t:1526930142017};\\\", \\\"{x:577,y:506,t:1526930142199};\\\", \\\"{x:575,y:511,t:1526930142217};\\\", \\\"{x:574,y:513,t:1526930142233};\\\", \\\"{x:572,y:515,t:1526930142250};\\\", \\\"{x:569,y:517,t:1526930142266};\\\", \\\"{x:562,y:523,t:1526930142284};\\\", \\\"{x:553,y:529,t:1526930142300};\\\", \\\"{x:541,y:534,t:1526930142318};\\\", \\\"{x:523,y:537,t:1526930142334};\\\", \\\"{x:493,y:545,t:1526930142350};\\\", \\\"{x:478,y:548,t:1526930142367};\\\", \\\"{x:467,y:554,t:1526930142383};\\\", \\\"{x:458,y:561,t:1526930142401};\\\", \\\"{x:449,y:570,t:1526930142418};\\\", \\\"{x:443,y:579,t:1526930142433};\\\", \\\"{x:436,y:589,t:1526930142450};\\\", \\\"{x:428,y:596,t:1526930142468};\\\", \\\"{x:416,y:605,t:1526930142484};\\\", \\\"{x:409,y:608,t:1526930142501};\\\", \\\"{x:400,y:610,t:1526930142518};\\\", \\\"{x:397,y:610,t:1526930142534};\\\", \\\"{x:395,y:610,t:1526930142551};\\\", \\\"{x:392,y:608,t:1526930142568};\\\", \\\"{x:391,y:600,t:1526930142585};\\\", \\\"{x:389,y:588,t:1526930142601};\\\", \\\"{x:387,y:575,t:1526930142618};\\\", \\\"{x:386,y:567,t:1526930142635};\\\", \\\"{x:386,y:564,t:1526930142651};\\\", \\\"{x:386,y:561,t:1526930142668};\\\", \\\"{x:386,y:560,t:1526930142685};\\\", \\\"{x:386,y:559,t:1526930142701};\\\", \\\"{x:386,y:557,t:1526930142718};\\\", \\\"{x:387,y:555,t:1526930142735};\\\", \\\"{x:387,y:554,t:1526930142758};\\\", \\\"{x:387,y:552,t:1526930142783};\\\", \\\"{x:388,y:551,t:1526930142791};\\\", \\\"{x:389,y:550,t:1526930142806};\\\", \\\"{x:389,y:548,t:1526930142822};\\\", \\\"{x:390,y:547,t:1526930142839};\\\", \\\"{x:390,y:546,t:1526930142851};\\\", \\\"{x:390,y:545,t:1526930142868};\\\", \\\"{x:390,y:556,t:1526930143118};\\\", \\\"{x:392,y:573,t:1526930143134};\\\", \\\"{x:392,y:584,t:1526930143152};\\\", \\\"{x:393,y:589,t:1526930143168};\\\", \\\"{x:394,y:590,t:1526930143185};\\\", \\\"{x:394,y:592,t:1526930143206};\\\", \\\"{x:394,y:593,t:1526930143230};\\\", \\\"{x:394,y:595,t:1526930143239};\\\", \\\"{x:394,y:596,t:1526930143254};\\\", \\\"{x:394,y:597,t:1526930143268};\\\", \\\"{x:393,y:600,t:1526930143284};\\\", \\\"{x:392,y:602,t:1526930143302};\\\", \\\"{x:391,y:607,t:1526930143319};\\\", \\\"{x:389,y:610,t:1526930143334};\\\", \\\"{x:389,y:611,t:1526930143358};\\\", \\\"{x:389,y:612,t:1526930143368};\\\", \\\"{x:388,y:614,t:1526930143385};\\\", \\\"{x:388,y:617,t:1526930143402};\\\", \\\"{x:387,y:619,t:1526930143418};\\\", \\\"{x:387,y:621,t:1526930143435};\\\", \\\"{x:387,y:623,t:1526930143719};\\\", \\\"{x:397,y:645,t:1526930143735};\\\", \\\"{x:412,y:666,t:1526930143752};\\\", \\\"{x:426,y:682,t:1526930143770};\\\", \\\"{x:438,y:695,t:1526930143785};\\\", \\\"{x:449,y:702,t:1526930143802};\\\", \\\"{x:450,y:704,t:1526930143819};\\\", \\\"{x:453,y:705,t:1526930143935};\\\", \\\"{x:454,y:706,t:1526930143959};\\\", \\\"{x:455,y:707,t:1526930143969};\\\", \\\"{x:458,y:707,t:1526930143986};\\\", \\\"{x:461,y:708,t:1526930144002};\\\", \\\"{x:464,y:711,t:1526930144020};\\\", \\\"{x:468,y:714,t:1526930144036};\\\", \\\"{x:474,y:720,t:1526930144053};\\\", \\\"{x:480,y:726,t:1526930144068};\\\", \\\"{x:483,y:729,t:1526930144086};\\\", \\\"{x:485,y:733,t:1526930144102};\\\", \\\"{x:488,y:737,t:1526930144119};\\\", \\\"{x:489,y:739,t:1526930144136};\\\", \\\"{x:491,y:741,t:1526930144151};\\\", \\\"{x:491,y:742,t:1526930144169};\\\", \\\"{x:492,y:743,t:1526930144186};\\\" ] }, { \\\"rt\\\": 9559, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 524115, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:743,t:1526930146127};\\\", \\\"{x:507,y:743,t:1526930146136};\\\", \\\"{x:552,y:738,t:1526930146154};\\\", \\\"{x:606,y:736,t:1526930146171};\\\", \\\"{x:651,y:736,t:1526930146187};\\\", \\\"{x:698,y:741,t:1526930146204};\\\", \\\"{x:736,y:744,t:1526930146219};\\\", \\\"{x:762,y:747,t:1526930146236};\\\", \\\"{x:780,y:748,t:1526930146254};\\\", \\\"{x:781,y:748,t:1526930146269};\\\", \\\"{x:783,y:748,t:1526930146287};\\\", \\\"{x:784,y:740,t:1526930150535};\\\", \\\"{x:784,y:730,t:1526930150543};\\\", \\\"{x:784,y:720,t:1526930150555};\\\", \\\"{x:783,y:703,t:1526930150571};\\\", \\\"{x:776,y:684,t:1526930150589};\\\", \\\"{x:771,y:669,t:1526930150604};\\\", \\\"{x:763,y:653,t:1526930150621};\\\", \\\"{x:756,y:628,t:1526930150640};\\\", \\\"{x:744,y:603,t:1526930150654};\\\", \\\"{x:733,y:589,t:1526930150671};\\\", \\\"{x:722,y:578,t:1526930150689};\\\", \\\"{x:698,y:564,t:1526930150707};\\\", \\\"{x:649,y:547,t:1526930150725};\\\", \\\"{x:596,y:539,t:1526930150741};\\\", \\\"{x:563,y:536,t:1526930150756};\\\", \\\"{x:525,y:530,t:1526930150773};\\\", \\\"{x:516,y:529,t:1526930150791};\\\", \\\"{x:509,y:527,t:1526930150807};\\\", \\\"{x:500,y:523,t:1526930150824};\\\", \\\"{x:493,y:523,t:1526930150841};\\\", \\\"{x:486,y:523,t:1526930150857};\\\", \\\"{x:481,y:523,t:1526930150874};\\\", \\\"{x:478,y:523,t:1526930150891};\\\", \\\"{x:477,y:524,t:1526930150907};\\\", \\\"{x:475,y:527,t:1526930150925};\\\", \\\"{x:472,y:529,t:1526930150941};\\\", \\\"{x:470,y:531,t:1526930150957};\\\", \\\"{x:469,y:536,t:1526930150974};\\\", \\\"{x:468,y:538,t:1526930150991};\\\", \\\"{x:467,y:538,t:1526930151014};\\\", \\\"{x:466,y:540,t:1526930151030};\\\", \\\"{x:465,y:541,t:1526930151041};\\\", \\\"{x:462,y:542,t:1526930151058};\\\", \\\"{x:460,y:542,t:1526930151074};\\\", \\\"{x:455,y:545,t:1526930151091};\\\", \\\"{x:450,y:545,t:1526930151108};\\\", \\\"{x:445,y:546,t:1526930151124};\\\", \\\"{x:439,y:547,t:1526930151141};\\\", \\\"{x:429,y:548,t:1526930151159};\\\", \\\"{x:422,y:550,t:1526930151174};\\\", \\\"{x:414,y:554,t:1526930151191};\\\", \\\"{x:403,y:558,t:1526930151209};\\\", \\\"{x:396,y:562,t:1526930151224};\\\", \\\"{x:388,y:566,t:1526930151242};\\\", \\\"{x:375,y:572,t:1526930151259};\\\", \\\"{x:361,y:572,t:1526930151275};\\\", \\\"{x:350,y:576,t:1526930151291};\\\", \\\"{x:342,y:577,t:1526930151308};\\\", \\\"{x:335,y:578,t:1526930151324};\\\", \\\"{x:332,y:578,t:1526930151341};\\\", \\\"{x:331,y:579,t:1526930151359};\\\", \\\"{x:330,y:577,t:1526930151447};\\\", \\\"{x:329,y:575,t:1526930151459};\\\", \\\"{x:326,y:567,t:1526930151476};\\\", \\\"{x:324,y:554,t:1526930151494};\\\", \\\"{x:321,y:540,t:1526930151508};\\\", \\\"{x:318,y:534,t:1526930151525};\\\", \\\"{x:315,y:531,t:1526930151541};\\\", \\\"{x:313,y:528,t:1526930151558};\\\", \\\"{x:311,y:528,t:1526930151575};\\\", \\\"{x:304,y:528,t:1526930151591};\\\", \\\"{x:287,y:528,t:1526930151608};\\\", \\\"{x:252,y:537,t:1526930151626};\\\", \\\"{x:223,y:548,t:1526930151641};\\\", \\\"{x:208,y:556,t:1526930151658};\\\", \\\"{x:200,y:561,t:1526930151675};\\\", \\\"{x:199,y:562,t:1526930151691};\\\", \\\"{x:199,y:564,t:1526930151711};\\\", \\\"{x:199,y:566,t:1526930151734};\\\", \\\"{x:199,y:568,t:1526930151742};\\\", \\\"{x:199,y:571,t:1526930151759};\\\", \\\"{x:201,y:572,t:1526930151775};\\\", \\\"{x:205,y:572,t:1526930151792};\\\", \\\"{x:209,y:572,t:1526930151808};\\\", \\\"{x:215,y:571,t:1526930151825};\\\", \\\"{x:231,y:562,t:1526930151842};\\\", \\\"{x:249,y:555,t:1526930151859};\\\", \\\"{x:281,y:544,t:1526930151876};\\\", \\\"{x:336,y:527,t:1526930151892};\\\", \\\"{x:402,y:514,t:1526930151909};\\\", \\\"{x:462,y:502,t:1526930151926};\\\", \\\"{x:517,y:496,t:1526930151943};\\\", \\\"{x:543,y:492,t:1526930151958};\\\", \\\"{x:561,y:492,t:1526930151976};\\\", \\\"{x:580,y:492,t:1526930151991};\\\", \\\"{x:594,y:490,t:1526930152008};\\\", \\\"{x:600,y:490,t:1526930152026};\\\", \\\"{x:602,y:489,t:1526930152042};\\\", \\\"{x:604,y:489,t:1526930152231};\\\", \\\"{x:607,y:490,t:1526930152243};\\\", \\\"{x:613,y:494,t:1526930152260};\\\", \\\"{x:616,y:494,t:1526930152278};\\\", \\\"{x:618,y:495,t:1526930152293};\\\", \\\"{x:624,y:497,t:1526930152309};\\\", \\\"{x:625,y:498,t:1526930152325};\\\", \\\"{x:626,y:499,t:1526930152342};\\\", \\\"{x:627,y:499,t:1526930152511};\\\", \\\"{x:627,y:500,t:1526930152534};\\\", \\\"{x:627,y:502,t:1526930152551};\\\", \\\"{x:625,y:502,t:1526930152559};\\\", \\\"{x:622,y:504,t:1526930152576};\\\", \\\"{x:620,y:505,t:1526930152593};\\\", \\\"{x:630,y:505,t:1526930152646};\\\", \\\"{x:658,y:505,t:1526930152660};\\\", \\\"{x:751,y:500,t:1526930152677};\\\", \\\"{x:837,y:500,t:1526930152693};\\\", \\\"{x:896,y:500,t:1526930152709};\\\", \\\"{x:928,y:500,t:1526930152725};\\\", \\\"{x:938,y:500,t:1526930152742};\\\", \\\"{x:937,y:500,t:1526930152823};\\\", \\\"{x:932,y:501,t:1526930152831};\\\", \\\"{x:929,y:501,t:1526930152842};\\\", \\\"{x:915,y:502,t:1526930152860};\\\", \\\"{x:896,y:506,t:1526930152876};\\\", \\\"{x:877,y:507,t:1526930152893};\\\", \\\"{x:855,y:508,t:1526930152911};\\\", \\\"{x:839,y:508,t:1526930152926};\\\", \\\"{x:835,y:508,t:1526930152942};\\\", \\\"{x:834,y:508,t:1526930152959};\\\", \\\"{x:834,y:527,t:1526930153293};\\\", \\\"{x:837,y:548,t:1526930153309};\\\", \\\"{x:840,y:574,t:1526930153326};\\\", \\\"{x:839,y:579,t:1526930153343};\\\", \\\"{x:839,y:581,t:1526930153359};\\\", \\\"{x:838,y:582,t:1526930153376};\\\", \\\"{x:837,y:582,t:1526930153494};\\\", \\\"{x:836,y:582,t:1526930153509};\\\", \\\"{x:835,y:577,t:1526930153527};\\\", \\\"{x:833,y:572,t:1526930153543};\\\", \\\"{x:833,y:567,t:1526930153559};\\\", \\\"{x:832,y:563,t:1526930153577};\\\", \\\"{x:832,y:560,t:1526930153594};\\\", \\\"{x:832,y:559,t:1526930153614};\\\", \\\"{x:832,y:557,t:1526930153630};\\\", \\\"{x:832,y:556,t:1526930153646};\\\", \\\"{x:832,y:554,t:1526930153661};\\\", \\\"{x:832,y:552,t:1526930153677};\\\", \\\"{x:832,y:549,t:1526930153694};\\\", \\\"{x:832,y:548,t:1526930153710};\\\", \\\"{x:832,y:546,t:1526930153726};\\\", \\\"{x:832,y:544,t:1526930153743};\\\", \\\"{x:832,y:543,t:1526930153760};\\\", \\\"{x:832,y:542,t:1526930153776};\\\", \\\"{x:832,y:541,t:1526930153793};\\\", \\\"{x:832,y:540,t:1526930153822};\\\", \\\"{x:832,y:539,t:1526930153839};\\\", \\\"{x:831,y:538,t:1526930154182};\\\", \\\"{x:829,y:540,t:1526930154193};\\\", \\\"{x:814,y:566,t:1526930154211};\\\", \\\"{x:789,y:598,t:1526930154228};\\\", \\\"{x:767,y:620,t:1526930154244};\\\", \\\"{x:734,y:643,t:1526930154260};\\\", \\\"{x:709,y:659,t:1526930154277};\\\", \\\"{x:684,y:671,t:1526930154293};\\\", \\\"{x:651,y:690,t:1526930154310};\\\", \\\"{x:636,y:700,t:1526930154328};\\\", \\\"{x:626,y:704,t:1526930154343};\\\", \\\"{x:623,y:706,t:1526930154360};\\\", \\\"{x:621,y:708,t:1526930154431};\\\", \\\"{x:620,y:709,t:1526930154444};\\\", \\\"{x:618,y:711,t:1526930154460};\\\", \\\"{x:615,y:714,t:1526930154478};\\\", \\\"{x:614,y:716,t:1526930154494};\\\", \\\"{x:610,y:718,t:1526930154511};\\\", \\\"{x:606,y:720,t:1526930154527};\\\", \\\"{x:598,y:723,t:1526930154545};\\\", \\\"{x:592,y:724,t:1526930154560};\\\", \\\"{x:589,y:724,t:1526930154578};\\\", \\\"{x:581,y:726,t:1526930154594};\\\", \\\"{x:577,y:726,t:1526930154610};\\\", \\\"{x:572,y:726,t:1526930154628};\\\", \\\"{x:570,y:726,t:1526930154645};\\\", \\\"{x:570,y:727,t:1526930154661};\\\", \\\"{x:568,y:728,t:1526930154687};\\\", \\\"{x:566,y:728,t:1526930154703};\\\", \\\"{x:566,y:729,t:1526930154718};\\\", \\\"{x:565,y:729,t:1526930154727};\\\", \\\"{x:565,y:730,t:1526930154775};\\\", \\\"{x:564,y:731,t:1526930154808};\\\", \\\"{x:561,y:733,t:1526930154862};\\\", \\\"{x:560,y:733,t:1526930155006};\\\", \\\"{x:560,y:729,t:1526930155431};\\\", \\\"{x:560,y:718,t:1526930155444};\\\", \\\"{x:563,y:699,t:1526930155462};\\\", \\\"{x:571,y:672,t:1526930155478};\\\", \\\"{x:586,y:611,t:1526930155495};\\\", \\\"{x:604,y:574,t:1526930155512};\\\", \\\"{x:620,y:543,t:1526930155527};\\\", \\\"{x:644,y:504,t:1526930155544};\\\", \\\"{x:670,y:467,t:1526930155561};\\\", \\\"{x:692,y:436,t:1526930155577};\\\", \\\"{x:701,y:425,t:1526930155594};\\\", \\\"{x:705,y:415,t:1526930155612};\\\", \\\"{x:706,y:411,t:1526930155628};\\\", \\\"{x:706,y:410,t:1526930155644};\\\", \\\"{x:708,y:408,t:1526930155661};\\\" ] }, { \\\"rt\\\": 19075, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 544412, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:708,y:413,t:1526930157400};\\\", \\\"{x:708,y:432,t:1526930157413};\\\", \\\"{x:706,y:472,t:1526930157430};\\\", \\\"{x:701,y:566,t:1526930157446};\\\", \\\"{x:701,y:627,t:1526930157463};\\\", \\\"{x:700,y:658,t:1526930157480};\\\", \\\"{x:699,y:674,t:1526930157496};\\\", \\\"{x:698,y:683,t:1526930157512};\\\", \\\"{x:698,y:687,t:1526930157529};\\\", \\\"{x:697,y:690,t:1526930157546};\\\", \\\"{x:708,y:690,t:1526930170007};\\\", \\\"{x:741,y:690,t:1526930170022};\\\", \\\"{x:788,y:694,t:1526930170039};\\\", \\\"{x:871,y:706,t:1526930170056};\\\", \\\"{x:954,y:717,t:1526930170072};\\\", \\\"{x:1052,y:732,t:1526930170090};\\\", \\\"{x:1120,y:744,t:1526930170105};\\\", \\\"{x:1159,y:755,t:1526930170123};\\\", \\\"{x:1177,y:760,t:1526930170143};\\\", \\\"{x:1189,y:763,t:1526930170158};\\\", \\\"{x:1201,y:768,t:1526930170173};\\\", \\\"{x:1208,y:772,t:1526930170189};\\\", \\\"{x:1220,y:778,t:1526930170207};\\\", \\\"{x:1239,y:786,t:1526930170223};\\\", \\\"{x:1259,y:795,t:1526930170239};\\\", \\\"{x:1278,y:801,t:1526930170256};\\\", \\\"{x:1301,y:804,t:1526930170272};\\\", \\\"{x:1317,y:807,t:1526930170289};\\\", \\\"{x:1330,y:806,t:1526930170307};\\\", \\\"{x:1342,y:802,t:1526930170323};\\\", \\\"{x:1364,y:789,t:1526930170339};\\\", \\\"{x:1386,y:780,t:1526930170357};\\\", \\\"{x:1397,y:777,t:1526930170372};\\\", \\\"{x:1402,y:773,t:1526930170389};\\\", \\\"{x:1412,y:768,t:1526930170407};\\\", \\\"{x:1416,y:765,t:1526930170422};\\\", \\\"{x:1423,y:763,t:1526930170440};\\\", \\\"{x:1430,y:759,t:1526930170457};\\\", \\\"{x:1440,y:755,t:1526930170473};\\\", \\\"{x:1444,y:752,t:1526930170489};\\\", \\\"{x:1451,y:748,t:1526930170506};\\\", \\\"{x:1463,y:744,t:1526930170523};\\\", \\\"{x:1482,y:743,t:1526930170540};\\\", \\\"{x:1504,y:743,t:1526930170556};\\\", \\\"{x:1531,y:743,t:1526930170573};\\\", \\\"{x:1551,y:748,t:1526930170590};\\\", \\\"{x:1567,y:752,t:1526930170607};\\\", \\\"{x:1568,y:754,t:1526930170623};\\\", \\\"{x:1570,y:755,t:1526930170639};\\\", \\\"{x:1570,y:759,t:1526930170655};\\\", \\\"{x:1569,y:767,t:1526930170672};\\\", \\\"{x:1563,y:782,t:1526930170689};\\\", \\\"{x:1558,y:795,t:1526930170705};\\\", \\\"{x:1554,y:808,t:1526930170723};\\\", \\\"{x:1549,y:818,t:1526930170739};\\\", \\\"{x:1544,y:828,t:1526930170756};\\\", \\\"{x:1543,y:833,t:1526930170777};\\\", \\\"{x:1541,y:835,t:1526930170793};\\\", \\\"{x:1535,y:839,t:1526930170810};\\\", \\\"{x:1529,y:845,t:1526930170827};\\\", \\\"{x:1523,y:851,t:1526930170843};\\\", \\\"{x:1516,y:860,t:1526930170860};\\\", \\\"{x:1504,y:876,t:1526930170877};\\\", \\\"{x:1497,y:889,t:1526930170894};\\\", \\\"{x:1489,y:899,t:1526930170911};\\\", \\\"{x:1482,y:906,t:1526930170928};\\\", \\\"{x:1478,y:909,t:1526930170944};\\\", \\\"{x:1477,y:911,t:1526930170960};\\\", \\\"{x:1476,y:913,t:1526930170978};\\\", \\\"{x:1474,y:921,t:1526930170995};\\\", \\\"{x:1473,y:928,t:1526930171011};\\\", \\\"{x:1472,y:937,t:1526930171027};\\\", \\\"{x:1472,y:945,t:1526930171044};\\\", \\\"{x:1472,y:952,t:1526930171060};\\\", \\\"{x:1474,y:957,t:1526930171078};\\\", \\\"{x:1477,y:964,t:1526930171095};\\\", \\\"{x:1479,y:967,t:1526930171110};\\\", \\\"{x:1482,y:970,t:1526930171127};\\\", \\\"{x:1483,y:970,t:1526930171143};\\\", \\\"{x:1484,y:971,t:1526930171160};\\\", \\\"{x:1485,y:973,t:1526930171177};\\\", \\\"{x:1488,y:974,t:1526930171194};\\\", \\\"{x:1490,y:975,t:1526930171210};\\\", \\\"{x:1491,y:975,t:1526930171243};\\\", \\\"{x:1490,y:975,t:1526930171563};\\\", \\\"{x:1489,y:975,t:1526930171578};\\\", \\\"{x:1487,y:973,t:1526930171594};\\\", \\\"{x:1486,y:973,t:1526930171610};\\\", \\\"{x:1485,y:973,t:1526930171795};\\\", \\\"{x:1484,y:973,t:1526930171859};\\\", \\\"{x:1483,y:972,t:1526930171883};\\\", \\\"{x:1482,y:972,t:1526930171895};\\\", \\\"{x:1481,y:970,t:1526930171912};\\\", \\\"{x:1480,y:968,t:1526930171930};\\\", \\\"{x:1480,y:966,t:1526930171944};\\\", \\\"{x:1478,y:965,t:1526930171961};\\\", \\\"{x:1478,y:963,t:1526930171979};\\\", \\\"{x:1478,y:962,t:1526930171995};\\\", \\\"{x:1477,y:960,t:1526930172011};\\\", \\\"{x:1477,y:959,t:1526930172028};\\\", \\\"{x:1476,y:956,t:1526930172044};\\\", \\\"{x:1476,y:953,t:1526930172062};\\\", \\\"{x:1475,y:949,t:1526930172079};\\\", \\\"{x:1475,y:947,t:1526930172095};\\\", \\\"{x:1474,y:944,t:1526930172111};\\\", \\\"{x:1474,y:942,t:1526930172128};\\\", \\\"{x:1474,y:939,t:1526930172145};\\\", \\\"{x:1473,y:935,t:1526930172161};\\\", \\\"{x:1472,y:928,t:1526930172179};\\\", \\\"{x:1471,y:922,t:1526930172194};\\\", \\\"{x:1470,y:916,t:1526930172212};\\\", \\\"{x:1465,y:905,t:1526930172228};\\\", \\\"{x:1460,y:898,t:1526930172244};\\\", \\\"{x:1451,y:889,t:1526930172261};\\\", \\\"{x:1446,y:881,t:1526930172279};\\\", \\\"{x:1441,y:871,t:1526930172294};\\\", \\\"{x:1439,y:865,t:1526930172311};\\\", \\\"{x:1437,y:861,t:1526930172328};\\\", \\\"{x:1435,y:855,t:1526930172345};\\\", \\\"{x:1431,y:849,t:1526930172361};\\\", \\\"{x:1425,y:836,t:1526930172378};\\\", \\\"{x:1422,y:830,t:1526930172394};\\\", \\\"{x:1420,y:825,t:1526930172411};\\\", \\\"{x:1419,y:823,t:1526930172429};\\\", \\\"{x:1417,y:817,t:1526930172445};\\\", \\\"{x:1412,y:810,t:1526930172462};\\\", \\\"{x:1408,y:803,t:1526930172478};\\\", \\\"{x:1404,y:794,t:1526930172495};\\\", \\\"{x:1400,y:787,t:1526930172511};\\\", \\\"{x:1395,y:782,t:1526930172529};\\\", \\\"{x:1389,y:773,t:1526930172546};\\\", \\\"{x:1375,y:755,t:1526930172561};\\\", \\\"{x:1354,y:719,t:1526930172578};\\\", \\\"{x:1338,y:698,t:1526930172595};\\\", \\\"{x:1324,y:678,t:1526930172611};\\\", \\\"{x:1310,y:663,t:1526930172628};\\\", \\\"{x:1291,y:652,t:1526930172645};\\\", \\\"{x:1264,y:636,t:1526930172660};\\\", \\\"{x:1229,y:622,t:1526930172678};\\\", \\\"{x:1196,y:611,t:1526930172694};\\\", \\\"{x:1170,y:605,t:1526930172711};\\\", \\\"{x:1149,y:599,t:1526930172728};\\\", \\\"{x:1130,y:592,t:1526930172745};\\\", \\\"{x:1106,y:585,t:1526930172760};\\\", \\\"{x:1037,y:563,t:1526930172778};\\\", \\\"{x:942,y:545,t:1526930172795};\\\", \\\"{x:853,y:530,t:1526930172811};\\\", \\\"{x:761,y:514,t:1526930172828};\\\", \\\"{x:589,y:492,t:1526930172862};\\\", \\\"{x:493,y:486,t:1526930172879};\\\", \\\"{x:417,y:472,t:1526930172895};\\\", \\\"{x:374,y:469,t:1526930172911};\\\", \\\"{x:349,y:464,t:1526930172929};\\\", \\\"{x:325,y:461,t:1526930172946};\\\", \\\"{x:323,y:460,t:1526930172962};\\\", \\\"{x:322,y:460,t:1526930173042};\\\", \\\"{x:321,y:460,t:1526930173050};\\\", \\\"{x:325,y:462,t:1526930173114};\\\", \\\"{x:338,y:469,t:1526930173129};\\\", \\\"{x:412,y:504,t:1526930173146};\\\", \\\"{x:469,y:522,t:1526930173163};\\\", \\\"{x:536,y:535,t:1526930173180};\\\", \\\"{x:584,y:541,t:1526930173196};\\\", \\\"{x:606,y:542,t:1526930173213};\\\", \\\"{x:609,y:542,t:1526930173228};\\\", \\\"{x:610,y:542,t:1526930173402};\\\", \\\"{x:612,y:540,t:1526930173412};\\\", \\\"{x:613,y:528,t:1526930173429};\\\", \\\"{x:616,y:516,t:1526930173447};\\\", \\\"{x:616,y:502,t:1526930173462};\\\", \\\"{x:616,y:499,t:1526930173480};\\\", \\\"{x:616,y:498,t:1526930173496};\\\", \\\"{x:618,y:497,t:1526930173833};\\\", \\\"{x:629,y:499,t:1526930173845};\\\", \\\"{x:660,y:508,t:1526930173862};\\\", \\\"{x:694,y:513,t:1526930173879};\\\", \\\"{x:725,y:514,t:1526930173896};\\\", \\\"{x:756,y:514,t:1526930173913};\\\", \\\"{x:778,y:517,t:1526930173930};\\\", \\\"{x:779,y:517,t:1526930173946};\\\", \\\"{x:781,y:517,t:1526930173993};\\\", \\\"{x:782,y:516,t:1526930174002};\\\", \\\"{x:783,y:516,t:1526930174013};\\\", \\\"{x:784,y:516,t:1526930174029};\\\", \\\"{x:787,y:514,t:1526930174047};\\\", \\\"{x:788,y:513,t:1526930174063};\\\", \\\"{x:792,y:510,t:1526930174080};\\\", \\\"{x:794,y:509,t:1526930174097};\\\", \\\"{x:798,y:508,t:1526930174113};\\\", \\\"{x:799,y:508,t:1526930174130};\\\", \\\"{x:805,y:506,t:1526930174146};\\\", \\\"{x:814,y:504,t:1526930174163};\\\", \\\"{x:819,y:504,t:1526930174180};\\\", \\\"{x:824,y:503,t:1526930174198};\\\", \\\"{x:825,y:503,t:1526930174213};\\\", \\\"{x:826,y:503,t:1526930174231};\\\", \\\"{x:820,y:507,t:1526930174570};\\\", \\\"{x:803,y:516,t:1526930174579};\\\", \\\"{x:749,y:545,t:1526930174597};\\\", \\\"{x:678,y:584,t:1526930174615};\\\", \\\"{x:607,y:625,t:1526930174630};\\\", \\\"{x:527,y:663,t:1526930174647};\\\", \\\"{x:469,y:698,t:1526930174664};\\\", \\\"{x:423,y:725,t:1526930174680};\\\", \\\"{x:401,y:736,t:1526930174697};\\\", \\\"{x:385,y:744,t:1526930174713};\\\", \\\"{x:384,y:744,t:1526930174730};\\\", \\\"{x:383,y:745,t:1526930174787};\\\", \\\"{x:383,y:747,t:1526930174797};\\\", \\\"{x:384,y:750,t:1526930174814};\\\", \\\"{x:389,y:755,t:1526930174831};\\\", \\\"{x:404,y:763,t:1526930174847};\\\", \\\"{x:424,y:771,t:1526930174864};\\\", \\\"{x:439,y:775,t:1526930174882};\\\", \\\"{x:454,y:777,t:1526930174897};\\\", \\\"{x:469,y:779,t:1526930174914};\\\", \\\"{x:479,y:780,t:1526930174931};\\\", \\\"{x:485,y:780,t:1526930174948};\\\", \\\"{x:487,y:780,t:1526930174964};\\\", \\\"{x:488,y:780,t:1526930174981};\\\", \\\"{x:491,y:778,t:1526930174997};\\\", \\\"{x:493,y:775,t:1526930175014};\\\", \\\"{x:496,y:771,t:1526930175031};\\\", \\\"{x:498,y:765,t:1526930175048};\\\", \\\"{x:500,y:761,t:1526930175064};\\\", \\\"{x:502,y:756,t:1526930175082};\\\", \\\"{x:503,y:753,t:1526930175099};\\\", \\\"{x:505,y:751,t:1526930175114};\\\", \\\"{x:506,y:749,t:1526930175131};\\\", \\\"{x:507,y:748,t:1526930175147};\\\", \\\"{x:508,y:747,t:1526930175164};\\\", \\\"{x:510,y:743,t:1526930176226};\\\", \\\"{x:521,y:742,t:1526930176234};\\\", \\\"{x:537,y:742,t:1526930176248};\\\", \\\"{x:569,y:742,t:1526930176266};\\\", \\\"{x:645,y:750,t:1526930176282};\\\", \\\"{x:701,y:758,t:1526930176298};\\\", \\\"{x:763,y:772,t:1526930176315};\\\", \\\"{x:814,y:780,t:1526930176332};\\\", \\\"{x:841,y:787,t:1526930176348};\\\", \\\"{x:854,y:791,t:1526930176365};\\\", \\\"{x:855,y:791,t:1526930176393};\\\", \\\"{x:856,y:791,t:1526930176401};\\\" ] }, { \\\"rt\\\": 9843, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 555510, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:852,y:788,t:1526930177241};\\\", \\\"{x:841,y:783,t:1526930177249};\\\", \\\"{x:796,y:765,t:1526930177266};\\\", \\\"{x:757,y:754,t:1526930177281};\\\", \\\"{x:726,y:743,t:1526930177299};\\\", \\\"{x:704,y:737,t:1526930177315};\\\", \\\"{x:692,y:733,t:1526930177331};\\\", \\\"{x:688,y:732,t:1526930177349};\\\", \\\"{x:688,y:731,t:1526930181954};\\\", \\\"{x:676,y:717,t:1526930181970};\\\", \\\"{x:624,y:676,t:1526930181986};\\\", \\\"{x:603,y:658,t:1526930182002};\\\", \\\"{x:587,y:650,t:1526930182020};\\\", \\\"{x:568,y:642,t:1526930182037};\\\", \\\"{x:560,y:637,t:1526930182053};\\\", \\\"{x:558,y:636,t:1526930182070};\\\", \\\"{x:562,y:633,t:1526930182139};\\\", \\\"{x:565,y:633,t:1526930182153};\\\", \\\"{x:573,y:629,t:1526930182171};\\\", \\\"{x:595,y:623,t:1526930182186};\\\", \\\"{x:616,y:618,t:1526930182203};\\\", \\\"{x:635,y:612,t:1526930182220};\\\", \\\"{x:648,y:609,t:1526930182236};\\\", \\\"{x:654,y:607,t:1526930182253};\\\", \\\"{x:655,y:606,t:1526930182270};\\\", \\\"{x:655,y:605,t:1526930182286};\\\", \\\"{x:655,y:602,t:1526930182304};\\\", \\\"{x:655,y:598,t:1526930182320};\\\", \\\"{x:655,y:593,t:1526930182336};\\\", \\\"{x:646,y:584,t:1526930182353};\\\", \\\"{x:641,y:580,t:1526930182369};\\\", \\\"{x:636,y:577,t:1526930182386};\\\", \\\"{x:635,y:577,t:1526930182403};\\\", \\\"{x:635,y:576,t:1526930182420};\\\", \\\"{x:633,y:576,t:1526930182457};\\\", \\\"{x:632,y:576,t:1526930182547};\\\", \\\"{x:630,y:576,t:1526930182594};\\\", \\\"{x:629,y:576,t:1526930182610};\\\", \\\"{x:628,y:576,t:1526930182620};\\\", \\\"{x:627,y:576,t:1526930182636};\\\", \\\"{x:626,y:577,t:1526930182737};\\\", \\\"{x:619,y:577,t:1526930183130};\\\", \\\"{x:608,y:584,t:1526930183137};\\\", \\\"{x:574,y:611,t:1526930183154};\\\", \\\"{x:555,y:631,t:1526930183170};\\\", \\\"{x:541,y:646,t:1526930183188};\\\", \\\"{x:527,y:662,t:1526930183204};\\\", \\\"{x:515,y:677,t:1526930183219};\\\", \\\"{x:507,y:695,t:1526930183237};\\\", \\\"{x:504,y:704,t:1526930183255};\\\", \\\"{x:504,y:712,t:1526930183270};\\\", \\\"{x:504,y:717,t:1526930183287};\\\", \\\"{x:504,y:719,t:1526930183304};\\\", \\\"{x:504,y:724,t:1526930183321};\\\", \\\"{x:504,y:726,t:1526930183337};\\\", \\\"{x:505,y:727,t:1526930183353};\\\", \\\"{x:505,y:728,t:1526930183371};\\\", \\\"{x:506,y:729,t:1526930183387};\\\", \\\"{x:506,y:730,t:1526930183506};\\\" ] }, { \\\"rt\\\": 17736, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 574466, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:731,t:1526930188578};\\\", \\\"{x:521,y:735,t:1526930188593};\\\", \\\"{x:549,y:741,t:1526930188609};\\\", \\\"{x:593,y:750,t:1526930188625};\\\", \\\"{x:703,y:766,t:1526930188641};\\\", \\\"{x:761,y:772,t:1526930188659};\\\", \\\"{x:797,y:772,t:1526930188674};\\\", \\\"{x:818,y:772,t:1526930188691};\\\", \\\"{x:824,y:772,t:1526930188708};\\\", \\\"{x:825,y:773,t:1526930188724};\\\", \\\"{x:827,y:773,t:1526930198587};\\\", \\\"{x:851,y:779,t:1526930198600};\\\", \\\"{x:935,y:806,t:1526930198617};\\\", \\\"{x:1029,y:839,t:1526930198634};\\\", \\\"{x:1079,y:853,t:1526930198650};\\\", \\\"{x:1115,y:864,t:1526930198667};\\\", \\\"{x:1139,y:868,t:1526930198684};\\\", \\\"{x:1154,y:870,t:1526930198700};\\\", \\\"{x:1160,y:872,t:1526930198718};\\\", \\\"{x:1161,y:872,t:1526930198734};\\\", \\\"{x:1169,y:878,t:1526930198750};\\\", \\\"{x:1184,y:892,t:1526930198767};\\\", \\\"{x:1202,y:906,t:1526930198784};\\\", \\\"{x:1216,y:917,t:1526930198800};\\\", \\\"{x:1232,y:927,t:1526930198817};\\\", \\\"{x:1266,y:950,t:1526930198834};\\\", \\\"{x:1291,y:966,t:1526930198850};\\\", \\\"{x:1313,y:978,t:1526930198867};\\\", \\\"{x:1329,y:985,t:1526930198884};\\\", \\\"{x:1342,y:989,t:1526930198900};\\\", \\\"{x:1349,y:989,t:1526930198917};\\\", \\\"{x:1354,y:990,t:1526930198934};\\\", \\\"{x:1356,y:990,t:1526930198970};\\\", \\\"{x:1358,y:990,t:1526930198985};\\\", \\\"{x:1367,y:990,t:1526930199001};\\\", \\\"{x:1385,y:990,t:1526930199017};\\\", \\\"{x:1415,y:977,t:1526930199034};\\\", \\\"{x:1429,y:974,t:1526930199052};\\\", \\\"{x:1447,y:966,t:1526930199068};\\\", \\\"{x:1461,y:963,t:1526930199084};\\\", \\\"{x:1481,y:958,t:1526930199102};\\\", \\\"{x:1496,y:955,t:1526930199117};\\\", \\\"{x:1509,y:951,t:1526930199135};\\\", \\\"{x:1517,y:948,t:1526930199151};\\\", \\\"{x:1520,y:946,t:1526930199167};\\\", \\\"{x:1521,y:945,t:1526930199212};\\\", \\\"{x:1521,y:944,t:1526930199283};\\\", \\\"{x:1521,y:943,t:1526930199290};\\\", \\\"{x:1521,y:942,t:1526930199347};\\\", \\\"{x:1521,y:940,t:1526930199362};\\\", \\\"{x:1519,y:939,t:1526930199370};\\\", \\\"{x:1518,y:936,t:1526930199384};\\\", \\\"{x:1511,y:930,t:1526930199401};\\\", \\\"{x:1495,y:910,t:1526930199418};\\\", \\\"{x:1487,y:895,t:1526930199434};\\\", \\\"{x:1482,y:883,t:1526930199451};\\\", \\\"{x:1478,y:877,t:1526930199468};\\\", \\\"{x:1476,y:872,t:1526930199484};\\\", \\\"{x:1475,y:868,t:1526930199501};\\\", \\\"{x:1475,y:861,t:1526930199518};\\\", \\\"{x:1475,y:851,t:1526930199535};\\\", \\\"{x:1475,y:844,t:1526930199551};\\\", \\\"{x:1475,y:841,t:1526930199569};\\\", \\\"{x:1475,y:839,t:1526930199585};\\\", \\\"{x:1475,y:838,t:1526930199602};\\\", \\\"{x:1475,y:837,t:1526930199619};\\\", \\\"{x:1475,y:836,t:1526930199882};\\\", \\\"{x:1475,y:834,t:1526930199898};\\\", \\\"{x:1474,y:829,t:1526930201394};\\\", \\\"{x:1474,y:826,t:1526930201404};\\\", \\\"{x:1472,y:818,t:1526930201420};\\\", \\\"{x:1469,y:812,t:1526930201437};\\\", \\\"{x:1466,y:806,t:1526930201454};\\\", \\\"{x:1463,y:798,t:1526930201470};\\\", \\\"{x:1461,y:794,t:1526930201486};\\\", \\\"{x:1460,y:792,t:1526930201504};\\\", \\\"{x:1459,y:789,t:1526930201587};\\\", \\\"{x:1458,y:785,t:1526930201603};\\\", \\\"{x:1456,y:780,t:1526930201620};\\\", \\\"{x:1456,y:775,t:1526930201637};\\\", \\\"{x:1454,y:769,t:1526930201653};\\\", \\\"{x:1452,y:762,t:1526930201670};\\\", \\\"{x:1451,y:753,t:1526930201686};\\\", \\\"{x:1450,y:743,t:1526930201704};\\\", \\\"{x:1447,y:733,t:1526930201719};\\\", \\\"{x:1447,y:725,t:1526930201736};\\\", \\\"{x:1445,y:713,t:1526930201754};\\\", \\\"{x:1443,y:707,t:1526930201770};\\\", \\\"{x:1443,y:703,t:1526930201786};\\\", \\\"{x:1443,y:701,t:1526930201803};\\\", \\\"{x:1442,y:699,t:1526930201819};\\\", \\\"{x:1441,y:697,t:1526930201836};\\\", \\\"{x:1441,y:693,t:1526930201853};\\\", \\\"{x:1439,y:688,t:1526930201870};\\\", \\\"{x:1439,y:684,t:1526930201887};\\\", \\\"{x:1439,y:682,t:1526930201904};\\\", \\\"{x:1439,y:678,t:1526930201921};\\\", \\\"{x:1439,y:676,t:1526930201937};\\\", \\\"{x:1439,y:672,t:1526930201953};\\\", \\\"{x:1439,y:669,t:1526930201970};\\\", \\\"{x:1440,y:667,t:1526930201987};\\\", \\\"{x:1440,y:664,t:1526930202004};\\\", \\\"{x:1442,y:660,t:1526930202021};\\\", \\\"{x:1443,y:655,t:1526930202036};\\\", \\\"{x:1443,y:651,t:1526930202054};\\\", \\\"{x:1446,y:645,t:1526930202071};\\\", \\\"{x:1448,y:637,t:1526930202087};\\\", \\\"{x:1452,y:631,t:1526930202106};\\\", \\\"{x:1454,y:626,t:1526930202120};\\\", \\\"{x:1456,y:622,t:1526930202136};\\\", \\\"{x:1456,y:618,t:1526930202153};\\\", \\\"{x:1460,y:613,t:1526930202169};\\\", \\\"{x:1463,y:605,t:1526930202186};\\\", \\\"{x:1467,y:596,t:1526930202203};\\\", \\\"{x:1471,y:589,t:1526930202220};\\\", \\\"{x:1472,y:584,t:1526930202237};\\\", \\\"{x:1474,y:578,t:1526930202253};\\\", \\\"{x:1475,y:575,t:1526930202270};\\\", \\\"{x:1476,y:573,t:1526930202287};\\\", \\\"{x:1476,y:570,t:1526930202304};\\\", \\\"{x:1476,y:568,t:1526930202320};\\\", \\\"{x:1476,y:564,t:1526930202338};\\\", \\\"{x:1476,y:558,t:1526930202353};\\\", \\\"{x:1476,y:555,t:1526930202371};\\\", \\\"{x:1476,y:551,t:1526930202387};\\\", \\\"{x:1476,y:547,t:1526930202404};\\\", \\\"{x:1476,y:542,t:1526930202421};\\\", \\\"{x:1476,y:537,t:1526930202437};\\\", \\\"{x:1476,y:532,t:1526930202453};\\\", \\\"{x:1476,y:528,t:1526930202470};\\\", \\\"{x:1476,y:522,t:1526930202488};\\\", \\\"{x:1474,y:519,t:1526930202504};\\\", \\\"{x:1474,y:512,t:1526930202521};\\\", \\\"{x:1474,y:504,t:1526930202538};\\\", \\\"{x:1473,y:490,t:1526930202553};\\\", \\\"{x:1473,y:479,t:1526930202571};\\\", \\\"{x:1473,y:464,t:1526930202588};\\\", \\\"{x:1473,y:450,t:1526930202603};\\\", \\\"{x:1471,y:435,t:1526930202621};\\\", \\\"{x:1470,y:422,t:1526930202637};\\\", \\\"{x:1468,y:411,t:1526930202653};\\\", \\\"{x:1466,y:402,t:1526930202670};\\\", \\\"{x:1466,y:400,t:1526930202687};\\\", \\\"{x:1465,y:399,t:1526930202704};\\\", \\\"{x:1465,y:398,t:1526930202753};\\\", \\\"{x:1465,y:397,t:1526930202793};\\\", \\\"{x:1460,y:400,t:1526930202850};\\\", \\\"{x:1447,y:417,t:1526930202857};\\\", \\\"{x:1431,y:435,t:1526930202870};\\\", \\\"{x:1379,y:496,t:1526930202887};\\\", \\\"{x:1319,y:559,t:1526930202905};\\\", \\\"{x:1229,y:609,t:1526930202920};\\\", \\\"{x:1039,y:657,t:1526930202937};\\\", \\\"{x:881,y:659,t:1526930202953};\\\", \\\"{x:715,y:660,t:1526930202970};\\\", \\\"{x:564,y:649,t:1526930202988};\\\", \\\"{x:455,y:645,t:1526930203006};\\\", \\\"{x:388,y:645,t:1526930203021};\\\", \\\"{x:367,y:650,t:1526930203037};\\\", \\\"{x:362,y:651,t:1526930203053};\\\", \\\"{x:362,y:655,t:1526930203070};\\\", \\\"{x:363,y:659,t:1526930203086};\\\", \\\"{x:364,y:659,t:1526930203103};\\\", \\\"{x:366,y:659,t:1526930203120};\\\", \\\"{x:369,y:659,t:1526930203136};\\\", \\\"{x:381,y:652,t:1526930203153};\\\", \\\"{x:400,y:642,t:1526930203170};\\\", \\\"{x:429,y:626,t:1526930203187};\\\", \\\"{x:486,y:605,t:1526930203204};\\\", \\\"{x:548,y:584,t:1526930203221};\\\", \\\"{x:596,y:570,t:1526930203237};\\\", \\\"{x:641,y:557,t:1526930203253};\\\", \\\"{x:658,y:552,t:1526930203270};\\\", \\\"{x:660,y:551,t:1526930203286};\\\", \\\"{x:661,y:551,t:1526930203401};\\\", \\\"{x:657,y:553,t:1526930203417};\\\", \\\"{x:648,y:558,t:1526930203425};\\\", \\\"{x:643,y:562,t:1526930203437};\\\", \\\"{x:630,y:570,t:1526930203454};\\\", \\\"{x:620,y:578,t:1526930203470};\\\", \\\"{x:616,y:582,t:1526930203487};\\\", \\\"{x:615,y:583,t:1526930203513};\\\", \\\"{x:613,y:585,t:1526930204008};\\\", \\\"{x:610,y:586,t:1526930204020};\\\", \\\"{x:593,y:589,t:1526930204037};\\\", \\\"{x:573,y:593,t:1526930204053};\\\", \\\"{x:551,y:600,t:1526930204069};\\\", \\\"{x:525,y:604,t:1526930204087};\\\", \\\"{x:497,y:607,t:1526930204105};\\\", \\\"{x:455,y:609,t:1526930204121};\\\", \\\"{x:429,y:611,t:1526930204136};\\\", \\\"{x:416,y:612,t:1526930204154};\\\", \\\"{x:407,y:613,t:1526930204170};\\\", \\\"{x:406,y:614,t:1526930204187};\\\", \\\"{x:405,y:614,t:1526930204402};\\\", \\\"{x:404,y:614,t:1526930204412};\\\", \\\"{x:402,y:614,t:1526930204422};\\\", \\\"{x:401,y:614,t:1526930204438};\\\", \\\"{x:398,y:614,t:1526930204454};\\\", \\\"{x:397,y:613,t:1526930204490};\\\", \\\"{x:396,y:613,t:1526930204522};\\\", \\\"{x:395,y:613,t:1526930204537};\\\", \\\"{x:394,y:612,t:1526930204554};\\\", \\\"{x:393,y:611,t:1526930204586};\\\", \\\"{x:393,y:609,t:1526930204617};\\\", \\\"{x:392,y:609,t:1526930204626};\\\", \\\"{x:392,y:608,t:1526930204637};\\\", \\\"{x:391,y:606,t:1526930204654};\\\", \\\"{x:389,y:601,t:1526930204671};\\\", \\\"{x:389,y:599,t:1526930204687};\\\", \\\"{x:389,y:598,t:1526930204703};\\\", \\\"{x:388,y:596,t:1526930204719};\\\", \\\"{x:388,y:595,t:1526930204737};\\\", \\\"{x:388,y:596,t:1526930204961};\\\", \\\"{x:393,y:606,t:1526930204971};\\\", \\\"{x:429,y:649,t:1526930204988};\\\", \\\"{x:475,y:697,t:1526930205004};\\\", \\\"{x:521,y:744,t:1526930205021};\\\", \\\"{x:549,y:763,t:1526930205038};\\\", \\\"{x:557,y:767,t:1526930205054};\\\", \\\"{x:554,y:763,t:1526930205187};\\\", \\\"{x:551,y:759,t:1526930205194};\\\", \\\"{x:548,y:755,t:1526930205204};\\\", \\\"{x:542,y:747,t:1526930205221};\\\", \\\"{x:538,y:741,t:1526930205238};\\\", \\\"{x:534,y:736,t:1526930205255};\\\", \\\"{x:532,y:735,t:1526930205271};\\\", \\\"{x:532,y:736,t:1526930205946};\\\", \\\"{x:532,y:742,t:1526930205955};\\\", \\\"{x:546,y:758,t:1526930205972};\\\", \\\"{x:563,y:776,t:1526930205988};\\\", \\\"{x:579,y:785,t:1526930206005};\\\", \\\"{x:607,y:800,t:1526930206022};\\\", \\\"{x:630,y:809,t:1526930206040};\\\", \\\"{x:652,y:816,t:1526930206055};\\\", \\\"{x:670,y:818,t:1526930206073};\\\", \\\"{x:692,y:822,t:1526930206089};\\\", \\\"{x:706,y:826,t:1526930206105};\\\", \\\"{x:712,y:827,t:1526930206123};\\\", \\\"{x:715,y:827,t:1526930206139};\\\", \\\"{x:716,y:827,t:1526930206155};\\\" ] }, { \\\"rt\\\": 132503, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 708237, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"There are two diagonal lines leading away from 12PM. The one towards the left means any events ending at 12pm, and one towards the right is any events starting at 12pm. You can follow the right line to see that M and L both start at 12pm, since they are both on this line.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8501, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 717746, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 17666, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Humanities\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 736432, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 87229, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 824992, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"A9CZD\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"A9CZD\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 680, dom: 1125, initialDom: 1220",
  "javascriptErrors": []
}