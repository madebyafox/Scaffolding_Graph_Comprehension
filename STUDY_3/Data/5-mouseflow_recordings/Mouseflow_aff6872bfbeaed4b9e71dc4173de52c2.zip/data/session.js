var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "aff6872bfbeaed4b9e71dc4173de52c2",
  "created": "2018-05-25T11:19:20.2394617-07:00",
  "lastActivity": "2018-05-25T11:21:10.2734617-07:00",
  "pageViews": [
    {
      "id": "05252068a37f646096d42adf6d453630275bfd68",
      "startTime": "2018-05-25T11:19:20.2394617-07:00",
      "endTime": "2018-05-25T11:21:10.2734617-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 110034,
      "engagementTime": 71086,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 110034,
  "engagementTime": 71086,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=VB9NP",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "21845e93f9ca6ecc00127e426d90131c",
  "gdpr": false
}