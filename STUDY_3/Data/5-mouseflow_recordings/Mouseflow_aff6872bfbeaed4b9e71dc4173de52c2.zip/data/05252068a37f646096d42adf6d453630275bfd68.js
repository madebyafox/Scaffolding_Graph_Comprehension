var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05252068a37f646096d42adf6d453630275bfd68"] = {
  "startTime": "2018-05-25T18:19:20.2394617Z",
  "websitePageUrl": "/16",
  "visitTime": 110034,
  "engagementTime": 71086,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "aff6872bfbeaed4b9e71dc4173de52c2",
    "created": "2018-05-25T18:19:20.2394617+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=VB9NP",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "21845e93f9ca6ecc00127e426d90131c",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/aff6872bfbeaed4b9e71dc4173de52c2/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 541,
      "y": 748
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 474,
      "y": 652
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 61980,
      "y": 4106,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 1281,
      "e": 1281,
      "ty": 6,
      "x": 436,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 433,
      "y": 594
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 425,
      "y": 552
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 425,
      "y": 547
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 36859,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 426,
      "y": 546
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 430,
      "y": 549
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 38321,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 445,
      "y": 557
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 452,
      "y": 571
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 452,
      "y": 572
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 39894,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 455,
      "y": 576
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 40232,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 458,
      "y": 577
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 468,
      "y": 581
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 41693,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 493,
      "y": 571
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 46639,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3299,
      "e": 3299,
      "ty": 2,
      "x": 545,
      "y": 548
    },
    {
      "t": 3398,
      "e": 3398,
      "ty": 2,
      "x": 564,
      "y": 540
    },
    {
      "t": 3497,
      "e": 3497,
      "ty": 2,
      "x": 577,
      "y": 536
    },
    {
      "t": 3497,
      "e": 3497,
      "ty": 41,
      "x": 53946,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3597,
      "e": 3597,
      "ty": 2,
      "x": 611,
      "y": 539
    },
    {
      "t": 3680,
      "e": 3680,
      "ty": 7,
      "x": 684,
      "y": 541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3698,
      "e": 3698,
      "ty": 2,
      "x": 692,
      "y": 538
    },
    {
      "t": 3748,
      "e": 3748,
      "ty": 41,
      "x": 4643,
      "y": 30459,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 3797,
      "e": 3797,
      "ty": 2,
      "x": 960,
      "y": 729
    },
    {
      "t": 3898,
      "e": 3898,
      "ty": 2,
      "x": 1221,
      "y": 971
    },
    {
      "t": 3997,
      "e": 3997,
      "ty": 2,
      "x": 1212,
      "y": 998
    },
    {
      "t": 3997,
      "e": 3997,
      "ty": 41,
      "x": 30020,
      "y": 61595,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4097,
      "e": 4097,
      "ty": 2,
      "x": 1145,
      "y": 998
    },
    {
      "t": 4197,
      "e": 4197,
      "ty": 2,
      "x": 1103,
      "y": 976
    },
    {
      "t": 4248,
      "e": 4248,
      "ty": 41,
      "x": 61872,
      "y": 16639,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[7] > text"
    },
    {
      "t": 4298,
      "e": 4298,
      "ty": 2,
      "x": 1137,
      "y": 956
    },
    {
      "t": 4398,
      "e": 4398,
      "ty": 2,
      "x": 1179,
      "y": 951
    },
    {
      "t": 4499,
      "e": 4499,
      "ty": 2,
      "x": 1166,
      "y": 937
    },
    {
      "t": 4499,
      "e": 4499,
      "ty": 41,
      "x": 3280,
      "y": 62340,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[9]"
    },
    {
      "t": 4598,
      "e": 4598,
      "ty": 2,
      "x": 280,
      "y": 685
    },
    {
      "t": 4698,
      "e": 4698,
      "ty": 6,
      "x": 113,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 113,
      "y": 601
    },
    {
      "t": 4748,
      "e": 4748,
      "ty": 41,
      "x": 5160,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4798,
      "e": 4798,
      "ty": 7,
      "x": 222,
      "y": 514,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 222,
      "y": 514
    },
    {
      "t": 4897,
      "e": 4897,
      "ty": 2,
      "x": 280,
      "y": 468
    },
    {
      "t": 4997,
      "e": 4997,
      "ty": 2,
      "x": 273,
      "y": 469
    },
    {
      "t": 4997,
      "e": 4997,
      "ty": 41,
      "x": 19773,
      "y": 25538,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5098,
      "e": 5098,
      "ty": 2,
      "x": 249,
      "y": 483
    },
    {
      "t": 5164,
      "e": 5164,
      "ty": 6,
      "x": 257,
      "y": 527,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5197,
      "e": 5197,
      "ty": 2,
      "x": 264,
      "y": 541
    },
    {
      "t": 5247,
      "e": 5247,
      "ty": 41,
      "x": 19323,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5297,
      "e": 5297,
      "ty": 2,
      "x": 269,
      "y": 572
    },
    {
      "t": 5447,
      "e": 5447,
      "ty": 3,
      "x": 269,
      "y": 572,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5449,
      "e": 5449,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5498,
      "e": 5498,
      "ty": 41,
      "x": 19323,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5557,
      "e": 5557,
      "ty": 4,
      "x": 19323,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5557,
      "e": 5557,
      "ty": 5,
      "x": 269,
      "y": 572,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9997,
      "e": 9997,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20915,
      "e": 10557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 21177,
      "e": 10819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21179,
      "e": 10821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21241,
      "e": 10883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 21241,
      "e": 10883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 21353,
      "e": 10995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21354,
      "e": 10996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21418,
      "e": 11060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 21498,
      "e": 11140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21499,
      "e": 11141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21553,
      "e": 11195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 21658,
      "e": 11300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 21659,
      "e": 11301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21714,
      "e": 11356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 21810,
      "e": 11452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21810,
      "e": 11452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21865,
      "e": 11507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 21999,
      "e": 11641,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looki"
    },
    {
      "t": 22121,
      "e": 11763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22122,
      "e": 11764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22233,
      "e": 11875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 22370,
      "e": 12012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22370,
      "e": 12012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22417,
      "e": 12059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22681,
      "e": 12323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22769,
      "e": 12411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lookin"
    },
    {
      "t": 22898,
      "e": 12540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 22899,
      "e": 12541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22985,
      "e": 12627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 23001,
      "e": 12643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23001,
      "e": 12643,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23065,
      "e": 12707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23137,
      "e": 12779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23138,
      "e": 12780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23209,
      "e": 12851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 23322,
      "e": 12964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23322,
      "e": 12964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23369,
      "e": 13011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23369,
      "e": 13011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23401,
      "e": 13043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 23457,
      "e": 13099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23489,
      "e": 13131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23489,
      "e": 13131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23561,
      "e": 13203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23585,
      "e": 13227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23586,
      "e": 13228,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23641,
      "e": 13283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23641,
      "e": 13283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23657,
      "e": 13299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 23754,
      "e": 13396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23761,
      "e": 13403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23761,
      "e": 13403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23833,
      "e": 13475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24474,
      "e": 14116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 24475,
      "e": 14117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24537,
      "e": 14179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 24577,
      "e": 14219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24577,
      "e": 14219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24649,
      "e": 14291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25250,
      "e": 14892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 25250,
      "e": 14892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25369,
      "e": 15011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25369,
      "e": 15011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25377,
      "e": 15019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||- "
    },
    {
      "t": 25458,
      "e": 15100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26282,
      "e": 15924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26283,
      "e": 15925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26385,
      "e": 16027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26603,
      "e": 16245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 26603,
      "e": 16245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26681,
      "e": 16323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 26713,
      "e": 16355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26713,
      "e": 16355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26778,
      "e": 16420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 26825,
      "e": 16467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26826,
      "e": 16468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26905,
      "e": 16547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27082,
      "e": 16724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27083,
      "e": 16725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27169,
      "e": 16811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29997,
      "e": 19639,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60497,
      "e": 21811,
      "ty": 2,
      "x": 308,
      "y": 601
    },
    {
      "t": 60497,
      "e": 21811,
      "ty": 41,
      "x": 23707,
      "y": 63322,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60508,
      "e": 21822,
      "ty": 7,
      "x": 334,
      "y": 622,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60598,
      "e": 21912,
      "ty": 2,
      "x": 354,
      "y": 647
    },
    {
      "t": 60643,
      "e": 21957,
      "ty": 6,
      "x": 360,
      "y": 662,
      "ta": "#strategyButton"
    },
    {
      "t": 60693,
      "e": 22007,
      "ty": 7,
      "x": 369,
      "y": 691,
      "ta": "#strategyButton"
    },
    {
      "t": 60697,
      "e": 22011,
      "ty": 2,
      "x": 369,
      "y": 691
    },
    {
      "t": 60747,
      "e": 22061,
      "ty": 41,
      "x": 22191,
      "y": 52602,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 60797,
      "e": 22111,
      "ty": 2,
      "x": 364,
      "y": 711
    },
    {
      "t": 60897,
      "e": 22211,
      "ty": 2,
      "x": 382,
      "y": 703
    },
    {
      "t": 60942,
      "e": 22256,
      "ty": 6,
      "x": 394,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 60997,
      "e": 22311,
      "ty": 2,
      "x": 394,
      "y": 688
    },
    {
      "t": 60997,
      "e": 22311,
      "ty": 41,
      "x": 30258,
      "y": 64119,
      "ta": "#strategyButton"
    },
    {
      "t": 61097,
      "e": 22411,
      "ty": 2,
      "x": 396,
      "y": 686
    },
    {
      "t": 61197,
      "e": 22511,
      "ty": 2,
      "x": 404,
      "y": 683
    },
    {
      "t": 61243,
      "e": 22557,
      "ty": 7,
      "x": 459,
      "y": 680,
      "ta": "#strategyButton"
    },
    {
      "t": 61247,
      "e": 22561,
      "ty": 41,
      "x": 40681,
      "y": 37226,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 61297,
      "e": 22611,
      "ty": 2,
      "x": 744,
      "y": 769
    },
    {
      "t": 61397,
      "e": 22711,
      "ty": 2,
      "x": 1132,
      "y": 909
    },
    {
      "t": 61497,
      "e": 22811,
      "ty": 2,
      "x": 1108,
      "y": 929
    },
    {
      "t": 61498,
      "e": 22812,
      "ty": 41,
      "x": 22691,
      "y": 56653,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 61598,
      "e": 22912,
      "ty": 2,
      "x": 966,
      "y": 946
    },
    {
      "t": 61697,
      "e": 23011,
      "ty": 2,
      "x": 943,
      "y": 993
    },
    {
      "t": 61747,
      "e": 23061,
      "ty": 41,
      "x": 10430,
      "y": 62526,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 61797,
      "e": 23111,
      "ty": 2,
      "x": 921,
      "y": 1019
    },
    {
      "t": 61998,
      "e": 23312,
      "ty": 41,
      "x": 9514,
      "y": 63099,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 62097,
      "e": 23411,
      "ty": 2,
      "x": 938,
      "y": 1015
    },
    {
      "t": 62197,
      "e": 23511,
      "ty": 2,
      "x": 942,
      "y": 1014
    },
    {
      "t": 62248,
      "e": 23562,
      "ty": 41,
      "x": 10994,
      "y": 62741,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 62397,
      "e": 23711,
      "ty": 2,
      "x": 908,
      "y": 938
    },
    {
      "t": 62497,
      "e": 23811,
      "ty": 2,
      "x": 906,
      "y": 933
    },
    {
      "t": 62498,
      "e": 23812,
      "ty": 41,
      "x": 8457,
      "y": 56940,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 62596,
      "e": 23910,
      "ty": 2,
      "x": 949,
      "y": 919
    },
    {
      "t": 62697,
      "e": 24011,
      "ty": 2,
      "x": 1028,
      "y": 897
    },
    {
      "t": 62748,
      "e": 24062,
      "ty": 41,
      "x": 17688,
      "y": 52929,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 62797,
      "e": 24111,
      "ty": 2,
      "x": 1038,
      "y": 875
    },
    {
      "t": 62897,
      "e": 24211,
      "ty": 2,
      "x": 1025,
      "y": 853
    },
    {
      "t": 62998,
      "e": 24312,
      "ty": 41,
      "x": 16842,
      "y": 51210,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 63098,
      "e": 24412,
      "ty": 2,
      "x": 1025,
      "y": 844
    },
    {
      "t": 63198,
      "e": 24512,
      "ty": 2,
      "x": 1025,
      "y": 839
    },
    {
      "t": 63247,
      "e": 24561,
      "ty": 41,
      "x": 16842,
      "y": 50207,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 63695,
      "e": 25009,
      "ty": 2,
      "x": 1022,
      "y": 833
    },
    {
      "t": 63745,
      "e": 25059,
      "ty": 41,
      "x": 47416,
      "y": 45510,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[10] > circle"
    },
    {
      "t": 63794,
      "e": 25108,
      "ty": 2,
      "x": 1022,
      "y": 832
    },
    {
      "t": 64746,
      "e": 26060,
      "ty": 41,
      "x": 14658,
      "y": 51640,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 64794,
      "e": 26108,
      "ty": 2,
      "x": 914,
      "y": 924
    },
    {
      "t": 64894,
      "e": 26208,
      "ty": 2,
      "x": 875,
      "y": 950
    },
    {
      "t": 64994,
      "e": 26308,
      "ty": 2,
      "x": 873,
      "y": 952
    },
    {
      "t": 64996,
      "e": 26310,
      "ty": 41,
      "x": 6131,
      "y": 58301,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 65094,
      "e": 26408,
      "ty": 2,
      "x": 986,
      "y": 830
    },
    {
      "t": 65195,
      "e": 26509,
      "ty": 2,
      "x": 1013,
      "y": 794
    },
    {
      "t": 65246,
      "e": 26560,
      "ty": 41,
      "x": 15997,
      "y": 46340,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 65294,
      "e": 26608,
      "ty": 2,
      "x": 1008,
      "y": 780
    },
    {
      "t": 65394,
      "e": 26708,
      "ty": 2,
      "x": 996,
      "y": 767
    },
    {
      "t": 65494,
      "e": 26808,
      "ty": 2,
      "x": 992,
      "y": 762
    },
    {
      "t": 65494,
      "e": 26808,
      "ty": 41,
      "x": 65534,
      "y": 27306,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[9] > circle"
    },
    {
      "t": 65695,
      "e": 27009,
      "ty": 2,
      "x": 1007,
      "y": 818
    },
    {
      "t": 65745,
      "e": 27059,
      "ty": 41,
      "x": 17265,
      "y": 51855,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 65795,
      "e": 27109,
      "ty": 2,
      "x": 1060,
      "y": 913
    },
    {
      "t": 65894,
      "e": 27208,
      "ty": 2,
      "x": 1092,
      "y": 980
    },
    {
      "t": 65995,
      "e": 27309,
      "ty": 2,
      "x": 1100,
      "y": 997
    },
    {
      "t": 65995,
      "e": 27309,
      "ty": 41,
      "x": 22127,
      "y": 61524,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 66394,
      "e": 27708,
      "ty": 2,
      "x": 1072,
      "y": 993
    },
    {
      "t": 66495,
      "e": 27809,
      "ty": 2,
      "x": 227,
      "y": 654
    },
    {
      "t": 66495,
      "e": 27809,
      "ty": 41,
      "x": 14602,
      "y": 35786,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 66595,
      "e": 27909,
      "ty": 2,
      "x": 175,
      "y": 618
    },
    {
      "t": 66695,
      "e": 28009,
      "ty": 2,
      "x": 262,
      "y": 627
    },
    {
      "t": 66745,
      "e": 28059,
      "ty": 41,
      "x": 45128,
      "y": 20489,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 66747,
      "e": 28061,
      "ty": 6,
      "x": 454,
      "y": 666,
      "ta": "#strategyButton"
    },
    {
      "t": 66761,
      "e": 28075,
      "ty": 7,
      "x": 477,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 66795,
      "e": 28109,
      "ty": 2,
      "x": 485,
      "y": 676
    },
    {
      "t": 66895,
      "e": 28209,
      "ty": 2,
      "x": 485,
      "y": 679
    },
    {
      "t": 66995,
      "e": 28309,
      "ty": 2,
      "x": 468,
      "y": 683
    },
    {
      "t": 66995,
      "e": 28309,
      "ty": 41,
      "x": 41693,
      "y": 37393,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 67013,
      "e": 28327,
      "ty": 6,
      "x": 458,
      "y": 683,
      "ta": "#strategyButton"
    },
    {
      "t": 67095,
      "e": 28409,
      "ty": 2,
      "x": 447,
      "y": 683
    },
    {
      "t": 67195,
      "e": 28509,
      "ty": 2,
      "x": 445,
      "y": 682
    },
    {
      "t": 67245,
      "e": 28559,
      "ty": 41,
      "x": 58111,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 67300,
      "e": 28614,
      "ty": 3,
      "x": 445,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 67302,
      "e": 28616,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the x - axis "
    },
    {
      "t": 67303,
      "e": 28617,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67304,
      "e": 28618,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 67426,
      "e": 28740,
      "ty": 4,
      "x": 58111,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 67439,
      "e": 28753,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 67441,
      "e": 28755,
      "ty": 5,
      "x": 445,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 67446,
      "e": 28760,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 68448,
      "e": 29762,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 68895,
      "e": 30209,
      "ty": 2,
      "x": 571,
      "y": 723
    },
    {
      "t": 68995,
      "e": 30309,
      "ty": 2,
      "x": 1007,
      "y": 780
    },
    {
      "t": 68995,
      "e": 30309,
      "ty": 41,
      "x": 34403,
      "y": 42766,
      "ta": "html > body"
    },
    {
      "t": 69095,
      "e": 30409,
      "ty": 2,
      "x": 1069,
      "y": 719
    },
    {
      "t": 69130,
      "e": 30444,
      "ty": 6,
      "x": 1029,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69163,
      "e": 30477,
      "ty": 7,
      "x": 1016,
      "y": 643,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69195,
      "e": 30509,
      "ty": 2,
      "x": 999,
      "y": 632
    },
    {
      "t": 69245,
      "e": 30559,
      "ty": 41,
      "x": 35254,
      "y": 2340,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 69295,
      "e": 30609,
      "ty": 2,
      "x": 967,
      "y": 594
    },
    {
      "t": 69394,
      "e": 30708,
      "ty": 2,
      "x": 947,
      "y": 576
    },
    {
      "t": 69399,
      "e": 30713,
      "ty": 6,
      "x": 945,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69495,
      "e": 30809,
      "ty": 2,
      "x": 935,
      "y": 565
    },
    {
      "t": 69495,
      "e": 30809,
      "ty": 41,
      "x": 27468,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69643,
      "e": 30957,
      "ty": 3,
      "x": 935,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69645,
      "e": 30959,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69763,
      "e": 31077,
      "ty": 4,
      "x": 27468,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69764,
      "e": 31078,
      "ty": 5,
      "x": 935,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69995,
      "e": 31309,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70095,
      "e": 31409,
      "ty": 2,
      "x": 938,
      "y": 565
    },
    {
      "t": 70195,
      "e": 31509,
      "ty": 2,
      "x": 946,
      "y": 569
    },
    {
      "t": 70245,
      "e": 31559,
      "ty": 41,
      "x": 29847,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70983,
      "e": 32297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 70983,
      "e": 32297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71078,
      "e": 32392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 71078,
      "e": 32392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 71078,
      "e": 32392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71149,
      "e": 32463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 71667,
      "e": 32981,
      "ty": 7,
      "x": 947,
      "y": 580,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71695,
      "e": 33009,
      "ty": 2,
      "x": 947,
      "y": 627
    },
    {
      "t": 71699,
      "e": 33013,
      "ty": 6,
      "x": 947,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71733,
      "e": 33047,
      "ty": 7,
      "x": 947,
      "y": 720,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71746,
      "e": 33060,
      "ty": 41,
      "x": 32337,
      "y": 39442,
      "ta": "html > body"
    },
    {
      "t": 71795,
      "e": 33109,
      "ty": 2,
      "x": 947,
      "y": 724
    },
    {
      "t": 71867,
      "e": 33181,
      "ty": 6,
      "x": 949,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71895,
      "e": 33209,
      "ty": 2,
      "x": 952,
      "y": 679
    },
    {
      "t": 71900,
      "e": 33214,
      "ty": 7,
      "x": 953,
      "y": 669,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 71916,
      "e": 33230,
      "ty": 6,
      "x": 953,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 71995,
      "e": 33309,
      "ty": 2,
      "x": 953,
      "y": 663
    },
    {
      "t": 71995,
      "e": 33309,
      "ty": 41,
      "x": 31361,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72106,
      "e": 33420,
      "ty": 3,
      "x": 953,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72107,
      "e": 33421,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 72109,
      "e": 33423,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72109,
      "e": 33423,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72242,
      "e": 33556,
      "ty": 4,
      "x": 31361,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72242,
      "e": 33556,
      "ty": 5,
      "x": 953,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73158,
      "e": 34472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 73254,
      "e": 34568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 73407,
      "e": 34721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 73407,
      "e": 34721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73566,
      "e": 34880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 73598,
      "e": 34912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 73599,
      "e": 34913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73694,
      "e": 35008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 73796,
      "e": 35110,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 73855,
      "e": 35169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 73935,
      "e": 35249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 74532,
      "e": 35846,
      "ty": 7,
      "x": 953,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74552,
      "e": 35866,
      "ty": 6,
      "x": 947,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 74567,
      "e": 35881,
      "ty": 7,
      "x": 940,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 74595,
      "e": 35909,
      "ty": 2,
      "x": 938,
      "y": 723
    },
    {
      "t": 74695,
      "e": 36009,
      "ty": 2,
      "x": 936,
      "y": 734
    },
    {
      "t": 74745,
      "e": 36059,
      "ty": 41,
      "x": 32164,
      "y": 40218,
      "ta": "html > body"
    },
    {
      "t": 74794,
      "e": 36108,
      "ty": 2,
      "x": 955,
      "y": 728
    },
    {
      "t": 74895,
      "e": 36209,
      "ty": 2,
      "x": 960,
      "y": 723
    },
    {
      "t": 74953,
      "e": 36267,
      "ty": 6,
      "x": 963,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 74995,
      "e": 36309,
      "ty": 2,
      "x": 963,
      "y": 697
    },
    {
      "t": 74995,
      "e": 36309,
      "ty": 41,
      "x": 34571,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 75095,
      "e": 36409,
      "ty": 2,
      "x": 965,
      "y": 692
    },
    {
      "t": 75234,
      "e": 36548,
      "ty": 3,
      "x": 965,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 75235,
      "e": 36549,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 75235,
      "e": 36549,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75236,
      "e": 36550,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 75244,
      "e": 36558,
      "ty": 41,
      "x": 35602,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 75339,
      "e": 36653,
      "ty": 4,
      "x": 35602,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 75340,
      "e": 36654,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 75342,
      "e": 36656,
      "ty": 5,
      "x": 965,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 75342,
      "e": 36656,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 76357,
      "e": 37671,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 76994,
      "e": 38308,
      "ty": 2,
      "x": 965,
      "y": 689
    },
    {
      "t": 76995,
      "e": 38309,
      "ty": 41,
      "x": 34074,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 77094,
      "e": 38408,
      "ty": 2,
      "x": 970,
      "y": 198
    },
    {
      "t": 77194,
      "e": 38508,
      "ty": 2,
      "x": 948,
      "y": 0
    },
    {
      "t": 77244,
      "e": 38558,
      "ty": 41,
      "x": 31923,
      "y": 1883,
      "ta": "html > body"
    },
    {
      "t": 77295,
      "e": 38609,
      "ty": 2,
      "x": 889,
      "y": 269
    },
    {
      "t": 77394,
      "e": 38708,
      "ty": 2,
      "x": 848,
      "y": 363
    },
    {
      "t": 77494,
      "e": 38808,
      "ty": 2,
      "x": 798,
      "y": 331
    },
    {
      "t": 77494,
      "e": 38808,
      "ty": 41,
      "x": 27205,
      "y": 17893,
      "ta": "html > body"
    },
    {
      "t": 77594,
      "e": 38908,
      "ty": 2,
      "x": 780,
      "y": 273
    },
    {
      "t": 77694,
      "e": 39008,
      "ty": 2,
      "x": 803,
      "y": 263
    },
    {
      "t": 77744,
      "e": 39058,
      "ty": 41,
      "x": 27791,
      "y": 13904,
      "ta": "html > body"
    },
    {
      "t": 77794,
      "e": 39108,
      "ty": 2,
      "x": 818,
      "y": 258
    },
    {
      "t": 77895,
      "e": 39209,
      "ty": 2,
      "x": 825,
      "y": 253
    },
    {
      "t": 77994,
      "e": 39308,
      "ty": 2,
      "x": 826,
      "y": 252
    },
    {
      "t": 77994,
      "e": 39308,
      "ty": 41,
      "x": 1086,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 78094,
      "e": 39408,
      "ty": 2,
      "x": 827,
      "y": 252
    },
    {
      "t": 78194,
      "e": 39508,
      "ty": 2,
      "x": 834,
      "y": 253
    },
    {
      "t": 78244,
      "e": 39558,
      "ty": 41,
      "x": 2985,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 78294,
      "e": 39608,
      "ty": 2,
      "x": 833,
      "y": 259
    },
    {
      "t": 78305,
      "e": 39619,
      "ty": 6,
      "x": 833,
      "y": 261,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 78394,
      "e": 39708,
      "ty": 2,
      "x": 831,
      "y": 267
    },
    {
      "t": 78495,
      "e": 39809,
      "ty": 41,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 79611,
      "e": 40925,
      "ty": 7,
      "x": 831,
      "y": 273,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 79694,
      "e": 41008,
      "ty": 2,
      "x": 876,
      "y": 372
    },
    {
      "t": 79744,
      "e": 41058,
      "ty": 41,
      "x": 19123,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 79794,
      "e": 41108,
      "ty": 2,
      "x": 911,
      "y": 460
    },
    {
      "t": 79894,
      "e": 41208,
      "ty": 2,
      "x": 910,
      "y": 473
    },
    {
      "t": 79995,
      "e": 41309,
      "ty": 2,
      "x": 888,
      "y": 475
    },
    {
      "t": 79995,
      "e": 41309,
      "ty": 41,
      "x": 15800,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 79995,
      "e": 41309,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80094,
      "e": 41408,
      "ty": 2,
      "x": 865,
      "y": 455
    },
    {
      "t": 80194,
      "e": 41508,
      "ty": 2,
      "x": 849,
      "y": 410
    },
    {
      "t": 80244,
      "e": 41558,
      "ty": 41,
      "x": 6070,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 80294,
      "e": 41608,
      "ty": 2,
      "x": 846,
      "y": 401
    },
    {
      "t": 80395,
      "e": 41709,
      "ty": 2,
      "x": 837,
      "y": 400
    },
    {
      "t": 80494,
      "e": 41808,
      "ty": 2,
      "x": 832,
      "y": 400
    },
    {
      "t": 80495,
      "e": 41809,
      "ty": 41,
      "x": 2510,
      "y": 12186,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 80595,
      "e": 41909,
      "ty": 2,
      "x": 829,
      "y": 407
    },
    {
      "t": 80606,
      "e": 41920,
      "ty": 6,
      "x": 829,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 80694,
      "e": 42008,
      "ty": 2,
      "x": 828,
      "y": 411
    },
    {
      "t": 80745,
      "e": 42059,
      "ty": 41,
      "x": 7955,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 80857,
      "e": 42171,
      "ty": 7,
      "x": 833,
      "y": 404,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 80894,
      "e": 42208,
      "ty": 2,
      "x": 850,
      "y": 346
    },
    {
      "t": 80994,
      "e": 42308,
      "ty": 2,
      "x": 854,
      "y": 276
    },
    {
      "t": 80994,
      "e": 42308,
      "ty": 41,
      "x": 24812,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 81094,
      "e": 42408,
      "ty": 2,
      "x": 851,
      "y": 273
    },
    {
      "t": 81194,
      "e": 42508,
      "ty": 2,
      "x": 845,
      "y": 273
    },
    {
      "t": 81245,
      "e": 42559,
      "ty": 41,
      "x": 16434,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 81294,
      "e": 42608,
      "ty": 2,
      "x": 840,
      "y": 273
    },
    {
      "t": 81387,
      "e": 42701,
      "ty": 6,
      "x": 836,
      "y": 272,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 81395,
      "e": 42709,
      "ty": 2,
      "x": 836,
      "y": 272
    },
    {
      "t": 81495,
      "e": 42809,
      "ty": 2,
      "x": 835,
      "y": 272
    },
    {
      "t": 81495,
      "e": 42809,
      "ty": 41,
      "x": 43243,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 81694,
      "e": 43008,
      "ty": 2,
      "x": 836,
      "y": 269
    },
    {
      "t": 81744,
      "e": 43058,
      "ty": 41,
      "x": 53325,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 81794,
      "e": 43108,
      "ty": 2,
      "x": 837,
      "y": 267
    },
    {
      "t": 81828,
      "e": 43142,
      "ty": 3,
      "x": 837,
      "y": 267,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 81828,
      "e": 43142,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 81970,
      "e": 43284,
      "ty": 4,
      "x": 53325,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 81970,
      "e": 43284,
      "ty": 5,
      "x": 837,
      "y": 267,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 81970,
      "e": 43284,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 82295,
      "e": 43609,
      "ty": 2,
      "x": 837,
      "y": 268
    },
    {
      "t": 82308,
      "e": 43622,
      "ty": 7,
      "x": 837,
      "y": 278,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 82324,
      "e": 43638,
      "ty": 6,
      "x": 837,
      "y": 295,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 82341,
      "e": 43655,
      "ty": 7,
      "x": 837,
      "y": 315,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 82395,
      "e": 43709,
      "ty": 2,
      "x": 837,
      "y": 347
    },
    {
      "t": 82474,
      "e": 43788,
      "ty": 6,
      "x": 837,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 82495,
      "e": 43809,
      "ty": 2,
      "x": 837,
      "y": 419
    },
    {
      "t": 82495,
      "e": 43809,
      "ty": 41,
      "x": 53325,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 82508,
      "e": 43822,
      "ty": 7,
      "x": 837,
      "y": 428,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 82541,
      "e": 43855,
      "ty": 6,
      "x": 837,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 82591,
      "e": 43905,
      "ty": 7,
      "x": 837,
      "y": 451,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 82594,
      "e": 43908,
      "ty": 2,
      "x": 837,
      "y": 451
    },
    {
      "t": 82695,
      "e": 44009,
      "ty": 2,
      "x": 837,
      "y": 461
    },
    {
      "t": 82745,
      "e": 44059,
      "ty": 41,
      "x": 16466,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 82894,
      "e": 44208,
      "ty": 2,
      "x": 859,
      "y": 407
    },
    {
      "t": 82995,
      "e": 44309,
      "ty": 2,
      "x": 878,
      "y": 391
    },
    {
      "t": 82995,
      "e": 44309,
      "ty": 41,
      "x": 13427,
      "y": 9749,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 83095,
      "e": 44409,
      "ty": 2,
      "x": 882,
      "y": 389
    },
    {
      "t": 83244,
      "e": 44558,
      "ty": 41,
      "x": 14376,
      "y": 9207,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 84895,
      "e": 46209,
      "ty": 2,
      "x": 889,
      "y": 387
    },
    {
      "t": 84995,
      "e": 46309,
      "ty": 2,
      "x": 930,
      "y": 371
    },
    {
      "t": 84995,
      "e": 46309,
      "ty": 41,
      "x": 25768,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 85095,
      "e": 46409,
      "ty": 2,
      "x": 955,
      "y": 368
    },
    {
      "t": 85194,
      "e": 46508,
      "ty": 2,
      "x": 988,
      "y": 367
    },
    {
      "t": 85245,
      "e": 46559,
      "ty": 41,
      "x": 41194,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 85295,
      "e": 46609,
      "ty": 2,
      "x": 1010,
      "y": 367
    },
    {
      "t": 85394,
      "e": 46708,
      "ty": 2,
      "x": 1026,
      "y": 367
    },
    {
      "t": 85494,
      "e": 46808,
      "ty": 2,
      "x": 1042,
      "y": 367
    },
    {
      "t": 85494,
      "e": 46808,
      "ty": 41,
      "x": 52348,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 85595,
      "e": 46909,
      "ty": 2,
      "x": 1061,
      "y": 370
    },
    {
      "t": 85745,
      "e": 47059,
      "ty": 41,
      "x": 56857,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 85895,
      "e": 47209,
      "ty": 2,
      "x": 1054,
      "y": 375
    },
    {
      "t": 85994,
      "e": 47308,
      "ty": 2,
      "x": 1026,
      "y": 386
    },
    {
      "t": 85995,
      "e": 47309,
      "ty": 41,
      "x": 48551,
      "y": 8394,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 86095,
      "e": 47409,
      "ty": 2,
      "x": 937,
      "y": 406
    },
    {
      "t": 86195,
      "e": 47509,
      "ty": 2,
      "x": 854,
      "y": 416
    },
    {
      "t": 86245,
      "e": 47509,
      "ty": 41,
      "x": 27600,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 86276,
      "e": 47540,
      "ty": 6,
      "x": 839,
      "y": 416,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 86295,
      "e": 47559,
      "ty": 2,
      "x": 836,
      "y": 416
    },
    {
      "t": 86395,
      "e": 47659,
      "ty": 2,
      "x": 830,
      "y": 416
    },
    {
      "t": 86495,
      "e": 47759,
      "ty": 41,
      "x": 18037,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 86595,
      "e": 47859,
      "ty": 2,
      "x": 829,
      "y": 411
    },
    {
      "t": 86745,
      "e": 48009,
      "ty": 41,
      "x": 12996,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 86995,
      "e": 48259,
      "ty": 2,
      "x": 829,
      "y": 416
    },
    {
      "t": 86995,
      "e": 48259,
      "ty": 41,
      "x": 12996,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 87010,
      "e": 48274,
      "ty": 7,
      "x": 829,
      "y": 421,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 87095,
      "e": 48359,
      "ty": 2,
      "x": 829,
      "y": 433
    },
    {
      "t": 87112,
      "e": 48376,
      "ty": 6,
      "x": 830,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 87195,
      "e": 48459,
      "ty": 2,
      "x": 830,
      "y": 447
    },
    {
      "t": 87196,
      "e": 48460,
      "ty": 7,
      "x": 831,
      "y": 451,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 87245,
      "e": 48509,
      "ty": 41,
      "x": 2510,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 87278,
      "e": 48542,
      "ty": 6,
      "x": 833,
      "y": 466,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 87295,
      "e": 48559,
      "ty": 2,
      "x": 833,
      "y": 466
    },
    {
      "t": 87362,
      "e": 48626,
      "ty": 7,
      "x": 834,
      "y": 477,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 87395,
      "e": 48659,
      "ty": 2,
      "x": 834,
      "y": 479
    },
    {
      "t": 87478,
      "e": 48742,
      "ty": 6,
      "x": 834,
      "y": 493,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 87494,
      "e": 48758,
      "ty": 2,
      "x": 834,
      "y": 493
    },
    {
      "t": 87495,
      "e": 48759,
      "ty": 41,
      "x": 38202,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 87595,
      "e": 48859,
      "ty": 2,
      "x": 834,
      "y": 499
    },
    {
      "t": 87675,
      "e": 48939,
      "ty": 7,
      "x": 834,
      "y": 505,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 87694,
      "e": 48958,
      "ty": 2,
      "x": 834,
      "y": 505
    },
    {
      "t": 87745,
      "e": 49009,
      "ty": 41,
      "x": 12187,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 87795,
      "e": 49059,
      "ty": 2,
      "x": 835,
      "y": 511
    },
    {
      "t": 87895,
      "e": 49159,
      "ty": 2,
      "x": 836,
      "y": 516
    },
    {
      "t": 87938,
      "e": 49202,
      "ty": 6,
      "x": 836,
      "y": 520,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 87995,
      "e": 49259,
      "ty": 2,
      "x": 837,
      "y": 523
    },
    {
      "t": 87995,
      "e": 49259,
      "ty": 41,
      "x": 53325,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 88095,
      "e": 49359,
      "ty": 2,
      "x": 837,
      "y": 529
    },
    {
      "t": 88164,
      "e": 49428,
      "ty": 7,
      "x": 837,
      "y": 533,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 88194,
      "e": 49458,
      "ty": 2,
      "x": 837,
      "y": 535
    },
    {
      "t": 88245,
      "e": 49509,
      "ty": 41,
      "x": 18230,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 88295,
      "e": 49559,
      "ty": 2,
      "x": 837,
      "y": 539
    },
    {
      "t": 88395,
      "e": 49659,
      "ty": 2,
      "x": 835,
      "y": 547
    },
    {
      "t": 88402,
      "e": 49666,
      "ty": 6,
      "x": 835,
      "y": 548,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 88494,
      "e": 49758,
      "ty": 2,
      "x": 834,
      "y": 553
    },
    {
      "t": 88496,
      "e": 49760,
      "ty": 41,
      "x": 38202,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 88595,
      "e": 49859,
      "ty": 2,
      "x": 832,
      "y": 559
    },
    {
      "t": 88614,
      "e": 49878,
      "ty": 7,
      "x": 831,
      "y": 562,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 88695,
      "e": 49959,
      "ty": 2,
      "x": 829,
      "y": 568
    },
    {
      "t": 88745,
      "e": 50009,
      "ty": 41,
      "x": 7522,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 88763,
      "e": 50009,
      "ty": 6,
      "x": 829,
      "y": 577,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 88794,
      "e": 50040,
      "ty": 2,
      "x": 829,
      "y": 579
    },
    {
      "t": 88879,
      "e": 50125,
      "ty": 7,
      "x": 830,
      "y": 589,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 88895,
      "e": 50141,
      "ty": 2,
      "x": 830,
      "y": 589
    },
    {
      "t": 88995,
      "e": 50241,
      "ty": 2,
      "x": 830,
      "y": 590
    },
    {
      "t": 88995,
      "e": 50241,
      "ty": 41,
      "x": 8515,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 89095,
      "e": 50341,
      "ty": 2,
      "x": 830,
      "y": 592
    },
    {
      "t": 89245,
      "e": 50491,
      "ty": 41,
      "x": 8515,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 89387,
      "e": 50633,
      "ty": 6,
      "x": 830,
      "y": 588,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 89395,
      "e": 50641,
      "ty": 2,
      "x": 830,
      "y": 588
    },
    {
      "t": 89495,
      "e": 50741,
      "ty": 2,
      "x": 829,
      "y": 581
    },
    {
      "t": 89496,
      "e": 50742,
      "ty": 41,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 89563,
      "e": 50809,
      "ty": 7,
      "x": 829,
      "y": 575,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 89594,
      "e": 50840,
      "ty": 2,
      "x": 829,
      "y": 574
    },
    {
      "t": 89695,
      "e": 50941,
      "ty": 2,
      "x": 828,
      "y": 564
    },
    {
      "t": 89713,
      "e": 50959,
      "ty": 6,
      "x": 827,
      "y": 560,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 89746,
      "e": 50992,
      "ty": 41,
      "x": 2914,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 89795,
      "e": 51041,
      "ty": 2,
      "x": 827,
      "y": 551
    },
    {
      "t": 89815,
      "e": 51061,
      "ty": 7,
      "x": 827,
      "y": 547,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 89895,
      "e": 51141,
      "ty": 2,
      "x": 827,
      "y": 540
    },
    {
      "t": 89995,
      "e": 51241,
      "ty": 2,
      "x": 827,
      "y": 534
    },
    {
      "t": 89995,
      "e": 51241,
      "ty": 41,
      "x": 6527,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 90195,
      "e": 51441,
      "ty": 2,
      "x": 829,
      "y": 533
    },
    {
      "t": 90244,
      "e": 51490,
      "ty": 41,
      "x": 16087,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 90295,
      "e": 51541,
      "ty": 2,
      "x": 886,
      "y": 571
    },
    {
      "t": 90395,
      "e": 51641,
      "ty": 2,
      "x": 969,
      "y": 608
    },
    {
      "t": 90495,
      "e": 51741,
      "ty": 2,
      "x": 1036,
      "y": 638
    },
    {
      "t": 90495,
      "e": 51741,
      "ty": 41,
      "x": 50924,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 90595,
      "e": 51841,
      "ty": 2,
      "x": 1028,
      "y": 683
    },
    {
      "t": 90695,
      "e": 51941,
      "ty": 2,
      "x": 961,
      "y": 748
    },
    {
      "t": 90745,
      "e": 51991,
      "ty": 41,
      "x": 42801,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 90795,
      "e": 52041,
      "ty": 2,
      "x": 902,
      "y": 759
    },
    {
      "t": 90881,
      "e": 52127,
      "ty": 6,
      "x": 827,
      "y": 754,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 90895,
      "e": 52141,
      "ty": 2,
      "x": 827,
      "y": 754
    },
    {
      "t": 90897,
      "e": 52143,
      "ty": 7,
      "x": 815,
      "y": 749,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 90995,
      "e": 52241,
      "ty": 2,
      "x": 800,
      "y": 702
    },
    {
      "t": 90995,
      "e": 52241,
      "ty": 41,
      "x": 27274,
      "y": 38445,
      "ta": "html > body"
    },
    {
      "t": 91094,
      "e": 52340,
      "ty": 2,
      "x": 792,
      "y": 545
    },
    {
      "t": 91166,
      "e": 52412,
      "ty": 6,
      "x": 828,
      "y": 465,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 91182,
      "e": 52428,
      "ty": 7,
      "x": 831,
      "y": 460,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 91195,
      "e": 52441,
      "ty": 2,
      "x": 831,
      "y": 460
    },
    {
      "t": 91245,
      "e": 52491,
      "ty": 41,
      "x": 2747,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 91281,
      "e": 52527,
      "ty": 6,
      "x": 839,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 91294,
      "e": 52540,
      "ty": 2,
      "x": 839,
      "y": 469
    },
    {
      "t": 91298,
      "e": 52544,
      "ty": 7,
      "x": 842,
      "y": 476,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 91395,
      "e": 52641,
      "ty": 2,
      "x": 843,
      "y": 497
    },
    {
      "t": 91495,
      "e": 52741,
      "ty": 2,
      "x": 841,
      "y": 512
    },
    {
      "t": 91495,
      "e": 52741,
      "ty": 41,
      "x": 4646,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 91595,
      "e": 52841,
      "ty": 2,
      "x": 841,
      "y": 511
    },
    {
      "t": 91695,
      "e": 52941,
      "ty": 2,
      "x": 841,
      "y": 501
    },
    {
      "t": 91745,
      "e": 52991,
      "ty": 41,
      "x": 17572,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 91794,
      "e": 53040,
      "ty": 2,
      "x": 841,
      "y": 479
    },
    {
      "t": 91895,
      "e": 53141,
      "ty": 2,
      "x": 841,
      "y": 475
    },
    {
      "t": 91933,
      "e": 53179,
      "ty": 6,
      "x": 839,
      "y": 471,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 91995,
      "e": 53241,
      "ty": 2,
      "x": 832,
      "y": 466
    },
    {
      "t": 91996,
      "e": 53242,
      "ty": 41,
      "x": 28120,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 92016,
      "e": 53262,
      "ty": 7,
      "x": 828,
      "y": 463,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 92095,
      "e": 53341,
      "ty": 2,
      "x": 828,
      "y": 463
    },
    {
      "t": 92245,
      "e": 53491,
      "ty": 41,
      "x": 6953,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 92387,
      "e": 53633,
      "ty": 6,
      "x": 828,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 92395,
      "e": 53641,
      "ty": 2,
      "x": 828,
      "y": 464
    },
    {
      "t": 92495,
      "e": 53741,
      "ty": 2,
      "x": 829,
      "y": 466
    },
    {
      "t": 92495,
      "e": 53741,
      "ty": 41,
      "x": 12996,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 92570,
      "e": 53816,
      "ty": 3,
      "x": 829,
      "y": 466,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 92571,
      "e": 53817,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 92571,
      "e": 53817,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 92707,
      "e": 53953,
      "ty": 4,
      "x": 12996,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 92707,
      "e": 53953,
      "ty": 5,
      "x": 829,
      "y": 466,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 92707,
      "e": 53953,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 92849,
      "e": 54095,
      "ty": 7,
      "x": 830,
      "y": 478,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 92895,
      "e": 54141,
      "ty": 2,
      "x": 854,
      "y": 520
    },
    {
      "t": 92994,
      "e": 54240,
      "ty": 2,
      "x": 884,
      "y": 564
    },
    {
      "t": 92995,
      "e": 54241,
      "ty": 41,
      "x": 42698,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 93095,
      "e": 54341,
      "ty": 2,
      "x": 986,
      "y": 688
    },
    {
      "t": 93194,
      "e": 54440,
      "ty": 2,
      "x": 1001,
      "y": 704
    },
    {
      "t": 93245,
      "e": 54491,
      "ty": 41,
      "x": 45250,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 93295,
      "e": 54541,
      "ty": 2,
      "x": 1001,
      "y": 692
    },
    {
      "t": 93394,
      "e": 54640,
      "ty": 2,
      "x": 983,
      "y": 639
    },
    {
      "t": 93495,
      "e": 54741,
      "ty": 2,
      "x": 983,
      "y": 638
    },
    {
      "t": 93495,
      "e": 54741,
      "ty": 41,
      "x": 38346,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 93595,
      "e": 54841,
      "ty": 2,
      "x": 953,
      "y": 652
    },
    {
      "t": 93696,
      "e": 54842,
      "ty": 2,
      "x": 936,
      "y": 700
    },
    {
      "t": 93745,
      "e": 54891,
      "ty": 41,
      "x": 24818,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 93795,
      "e": 54941,
      "ty": 2,
      "x": 915,
      "y": 748
    },
    {
      "t": 93895,
      "e": 55041,
      "ty": 2,
      "x": 886,
      "y": 801
    },
    {
      "t": 93995,
      "e": 55141,
      "ty": 2,
      "x": 858,
      "y": 835
    },
    {
      "t": 93996,
      "e": 55142,
      "ty": 41,
      "x": 25771,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 94095,
      "e": 55241,
      "ty": 2,
      "x": 848,
      "y": 853
    },
    {
      "t": 94168,
      "e": 55314,
      "ty": 6,
      "x": 838,
      "y": 848,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 94195,
      "e": 55341,
      "ty": 2,
      "x": 835,
      "y": 842
    },
    {
      "t": 94218,
      "e": 55364,
      "ty": 7,
      "x": 828,
      "y": 829,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 94245,
      "e": 55391,
      "ty": 41,
      "x": 1323,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 94295,
      "e": 55441,
      "ty": 2,
      "x": 827,
      "y": 826
    },
    {
      "t": 94379,
      "e": 55525,
      "ty": 6,
      "x": 827,
      "y": 820,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 94395,
      "e": 55541,
      "ty": 2,
      "x": 827,
      "y": 820
    },
    {
      "t": 94495,
      "e": 55641,
      "ty": 2,
      "x": 830,
      "y": 818
    },
    {
      "t": 94496,
      "e": 55642,
      "ty": 41,
      "x": 18037,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 94595,
      "e": 55741,
      "ty": 2,
      "x": 835,
      "y": 818
    },
    {
      "t": 94634,
      "e": 55780,
      "ty": 7,
      "x": 840,
      "y": 821,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 94695,
      "e": 55841,
      "ty": 2,
      "x": 846,
      "y": 827
    },
    {
      "t": 94745,
      "e": 55891,
      "ty": 41,
      "x": 6307,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 94795,
      "e": 55941,
      "ty": 2,
      "x": 850,
      "y": 834
    },
    {
      "t": 94895,
      "e": 56041,
      "ty": 2,
      "x": 852,
      "y": 840
    },
    {
      "t": 94995,
      "e": 56141,
      "ty": 2,
      "x": 852,
      "y": 845
    },
    {
      "t": 94995,
      "e": 56141,
      "ty": 41,
      "x": 21544,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 95096,
      "e": 56242,
      "ty": 2,
      "x": 852,
      "y": 849
    },
    {
      "t": 95195,
      "e": 56341,
      "ty": 2,
      "x": 851,
      "y": 852
    },
    {
      "t": 95245,
      "e": 56391,
      "ty": 41,
      "x": 7019,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 95295,
      "e": 56441,
      "ty": 2,
      "x": 851,
      "y": 853
    },
    {
      "t": 95495,
      "e": 56641,
      "ty": 2,
      "x": 850,
      "y": 849
    },
    {
      "t": 95495,
      "e": 56641,
      "ty": 41,
      "x": 20134,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 95595,
      "e": 56741,
      "ty": 2,
      "x": 846,
      "y": 836
    },
    {
      "t": 95695,
      "e": 56841,
      "ty": 2,
      "x": 842,
      "y": 828
    },
    {
      "t": 95746,
      "e": 56892,
      "ty": 41,
      "x": 10375,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 95795,
      "e": 56941,
      "ty": 2,
      "x": 836,
      "y": 822
    },
    {
      "t": 95895,
      "e": 57041,
      "ty": 2,
      "x": 834,
      "y": 821
    },
    {
      "t": 95995,
      "e": 57141,
      "ty": 41,
      "x": 7424,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 96171,
      "e": 57317,
      "ty": 6,
      "x": 834,
      "y": 819,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 96194,
      "e": 57340,
      "ty": 2,
      "x": 834,
      "y": 818
    },
    {
      "t": 96245,
      "e": 57391,
      "ty": 41,
      "x": 38202,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 96895,
      "e": 58041,
      "ty": 2,
      "x": 836,
      "y": 809
    },
    {
      "t": 96988,
      "e": 58134,
      "ty": 3,
      "x": 836,
      "y": 809,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 96988,
      "e": 58134,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 96989,
      "e": 58135,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 96995,
      "e": 58141,
      "ty": 41,
      "x": 48284,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 97113,
      "e": 58259,
      "ty": 4,
      "x": 48284,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 97113,
      "e": 58259,
      "ty": 5,
      "x": 836,
      "y": 809,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 97114,
      "e": 58260,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf",
      "v": "Humanities"
    },
    {
      "t": 97386,
      "e": 58532,
      "ty": 7,
      "x": 841,
      "y": 809,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 97395,
      "e": 58541,
      "ty": 2,
      "x": 841,
      "y": 809
    },
    {
      "t": 97495,
      "e": 58641,
      "ty": 2,
      "x": 876,
      "y": 807
    },
    {
      "t": 97495,
      "e": 58641,
      "ty": 41,
      "x": 32214,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 97594,
      "e": 58740,
      "ty": 2,
      "x": 900,
      "y": 797
    },
    {
      "t": 97695,
      "e": 58841,
      "ty": 2,
      "x": 937,
      "y": 750
    },
    {
      "t": 97745,
      "e": 58891,
      "ty": 41,
      "x": 28616,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 97794,
      "e": 58940,
      "ty": 2,
      "x": 942,
      "y": 744
    },
    {
      "t": 97895,
      "e": 59041,
      "ty": 2,
      "x": 977,
      "y": 839
    },
    {
      "t": 97995,
      "e": 59141,
      "ty": 2,
      "x": 985,
      "y": 902
    },
    {
      "t": 97995,
      "e": 59141,
      "ty": 41,
      "x": 38821,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 98095,
      "e": 59241,
      "ty": 2,
      "x": 985,
      "y": 938
    },
    {
      "t": 98195,
      "e": 59341,
      "ty": 2,
      "x": 971,
      "y": 964
    },
    {
      "t": 98244,
      "e": 59390,
      "ty": 41,
      "x": 32650,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 98294,
      "e": 59440,
      "ty": 2,
      "x": 947,
      "y": 992
    },
    {
      "t": 98395,
      "e": 59541,
      "ty": 2,
      "x": 916,
      "y": 1002
    },
    {
      "t": 98495,
      "e": 59641,
      "ty": 2,
      "x": 889,
      "y": 981
    },
    {
      "t": 98495,
      "e": 59641,
      "ty": 41,
      "x": 16037,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 98594,
      "e": 59740,
      "ty": 2,
      "x": 841,
      "y": 932
    },
    {
      "t": 98694,
      "e": 59840,
      "ty": 2,
      "x": 819,
      "y": 917
    },
    {
      "t": 98745,
      "e": 59891,
      "ty": 41,
      "x": 27446,
      "y": 50577,
      "ta": "html > body"
    },
    {
      "t": 98794,
      "e": 59940,
      "ty": 2,
      "x": 800,
      "y": 944
    },
    {
      "t": 98894,
      "e": 60040,
      "ty": 2,
      "x": 803,
      "y": 961
    },
    {
      "t": 98994,
      "e": 60140,
      "ty": 2,
      "x": 811,
      "y": 970
    },
    {
      "t": 98994,
      "e": 60140,
      "ty": 41,
      "x": 27653,
      "y": 53292,
      "ta": "html > body"
    },
    {
      "t": 99095,
      "e": 60241,
      "ty": 2,
      "x": 816,
      "y": 971
    },
    {
      "t": 99191,
      "e": 60243,
      "ty": 6,
      "x": 829,
      "y": 968,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99194,
      "e": 60246,
      "ty": 2,
      "x": 829,
      "y": 968
    },
    {
      "t": 99244,
      "e": 60296,
      "ty": 41,
      "x": 28120,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99294,
      "e": 60346,
      "ty": 2,
      "x": 833,
      "y": 967
    },
    {
      "t": 99394,
      "e": 60446,
      "ty": 2,
      "x": 837,
      "y": 965
    },
    {
      "t": 99490,
      "e": 60542,
      "ty": 3,
      "x": 837,
      "y": 965,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99492,
      "e": 60544,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 99492,
      "e": 60544,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99495,
      "e": 60547,
      "ty": 41,
      "x": 53325,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99602,
      "e": 60654,
      "ty": 4,
      "x": 53325,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99603,
      "e": 60655,
      "ty": 5,
      "x": 837,
      "y": 965,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99604,
      "e": 60656,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 99738,
      "e": 60790,
      "ty": 7,
      "x": 842,
      "y": 969,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99744,
      "e": 60796,
      "ty": 41,
      "x": 16646,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 99789,
      "e": 60841,
      "ty": 6,
      "x": 884,
      "y": 1017,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 99795,
      "e": 60847,
      "ty": 2,
      "x": 884,
      "y": 1017
    },
    {
      "t": 99895,
      "e": 60947,
      "ty": 2,
      "x": 913,
      "y": 1035
    },
    {
      "t": 99995,
      "e": 61047,
      "ty": 41,
      "x": 43075,
      "y": 59577,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100194,
      "e": 61246,
      "ty": 2,
      "x": 915,
      "y": 1031
    },
    {
      "t": 100210,
      "e": 61262,
      "ty": 3,
      "x": 915,
      "y": 1031,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100211,
      "e": 61263,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 100211,
      "e": 61263,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100245,
      "e": 61297,
      "ty": 41,
      "x": 44106,
      "y": 51633,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100323,
      "e": 61375,
      "ty": 4,
      "x": 44106,
      "y": 51633,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100323,
      "e": 61375,
      "ty": 5,
      "x": 915,
      "y": 1031,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100332,
      "e": 61384,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100334,
      "e": 61386,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 100334,
      "e": 61386,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 101684,
      "e": 62736,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 102194,
      "e": 63246,
      "ty": 2,
      "x": 915,
      "y": 1020
    },
    {
      "t": 102244,
      "e": 63296,
      "ty": 41,
      "x": 29102,
      "y": 57177,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 102294,
      "e": 63346,
      "ty": 2,
      "x": 826,
      "y": 742
    },
    {
      "t": 102395,
      "e": 63447,
      "ty": 2,
      "x": 642,
      "y": 386
    },
    {
      "t": 102495,
      "e": 63547,
      "ty": 2,
      "x": 563,
      "y": 344
    },
    {
      "t": 102495,
      "e": 63547,
      "ty": 41,
      "x": 13260,
      "y": 22271,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 102594,
      "e": 63646,
      "ty": 2,
      "x": 540,
      "y": 351
    },
    {
      "t": 102695,
      "e": 63747,
      "ty": 2,
      "x": 501,
      "y": 390
    },
    {
      "t": 102744,
      "e": 63796,
      "ty": 41,
      "x": 10210,
      "y": 9764,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 102794,
      "e": 63846,
      "ty": 2,
      "x": 508,
      "y": 403
    },
    {
      "t": 102895,
      "e": 63947,
      "ty": 2,
      "x": 539,
      "y": 412
    },
    {
      "t": 102994,
      "e": 64046,
      "ty": 2,
      "x": 581,
      "y": 424
    },
    {
      "t": 102994,
      "e": 64046,
      "ty": 41,
      "x": 14146,
      "y": 33949,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 103094,
      "e": 64146,
      "ty": 2,
      "x": 617,
      "y": 438
    },
    {
      "t": 103195,
      "e": 64247,
      "ty": 2,
      "x": 655,
      "y": 449
    },
    {
      "t": 103245,
      "e": 64297,
      "ty": 41,
      "x": 17787,
      "y": 53454,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 103295,
      "e": 64347,
      "ty": 2,
      "x": 660,
      "y": 449
    },
    {
      "t": 103394,
      "e": 64446,
      "ty": 2,
      "x": 664,
      "y": 449
    },
    {
      "t": 103494,
      "e": 64546,
      "ty": 2,
      "x": 667,
      "y": 449
    },
    {
      "t": 103495,
      "e": 64547,
      "ty": 41,
      "x": 18377,
      "y": 53454,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 103594,
      "e": 64646,
      "ty": 2,
      "x": 668,
      "y": 449
    },
    {
      "t": 103745,
      "e": 64797,
      "ty": 41,
      "x": 18426,
      "y": 53454,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 106494,
      "e": 67546,
      "ty": 2,
      "x": 1015,
      "y": 735
    },
    {
      "t": 106495,
      "e": 67547,
      "ty": 41,
      "x": 35497,
      "y": 38920,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 106595,
      "e": 67647,
      "ty": 2,
      "x": 1086,
      "y": 914
    },
    {
      "t": 106694,
      "e": 67746,
      "ty": 2,
      "x": 989,
      "y": 934
    },
    {
      "t": 106745,
      "e": 67797,
      "ty": 41,
      "x": 32349,
      "y": 57385,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 106794,
      "e": 67846,
      "ty": 2,
      "x": 945,
      "y": 1003
    },
    {
      "t": 106861,
      "e": 67913,
      "ty": 6,
      "x": 957,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 106895,
      "e": 67947,
      "ty": 2,
      "x": 966,
      "y": 1094
    },
    {
      "t": 106995,
      "e": 68047,
      "ty": 2,
      "x": 973,
      "y": 1101
    },
    {
      "t": 106995,
      "e": 68047,
      "ty": 41,
      "x": 34678,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 107095,
      "e": 68147,
      "ty": 2,
      "x": 973,
      "y": 1092
    },
    {
      "t": 107195,
      "e": 68247,
      "ty": 2,
      "x": 974,
      "y": 1091
    },
    {
      "t": 107203,
      "e": 68255,
      "ty": 3,
      "x": 974,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 107205,
      "e": 68257,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 107244,
      "e": 68296,
      "ty": 41,
      "x": 35225,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 107299,
      "e": 68351,
      "ty": 4,
      "x": 35225,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 107299,
      "e": 68351,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 107301,
      "e": 68353,
      "ty": 5,
      "x": 974,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 107303,
      "e": 68355,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 107594,
      "e": 68646,
      "ty": 2,
      "x": 980,
      "y": 1086
    },
    {
      "t": 107695,
      "e": 68747,
      "ty": 2,
      "x": 1034,
      "y": 962
    },
    {
      "t": 107745,
      "e": 68797,
      "ty": 41,
      "x": 35298,
      "y": 47641,
      "ta": "html > body"
    },
    {
      "t": 107795,
      "e": 68847,
      "ty": 2,
      "x": 1029,
      "y": 813
    },
    {
      "t": 107894,
      "e": 68946,
      "ty": 2,
      "x": 997,
      "y": 777
    },
    {
      "t": 107995,
      "e": 69047,
      "ty": 2,
      "x": 984,
      "y": 771
    },
    {
      "t": 107995,
      "e": 69047,
      "ty": 41,
      "x": 33611,
      "y": 42268,
      "ta": "html > body"
    },
    {
      "t": 108346,
      "e": 69398,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 109995,
      "e": 71047,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110034,
      "e": 71086,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 120407, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 120414, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 17532, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 139309, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 14177, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"NOVEMBER\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 154492, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 21403, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 176980, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 7603, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 185588, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 19888, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 206833, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-Z -A -A -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:985,y:1011,t:1527271772851};\\\", \\\"{x:999,y:1005,t:1527271772858};\\\", \\\"{x:1023,y:994,t:1527271772867};\\\", \\\"{x:1067,y:975,t:1527271772884};\\\", \\\"{x:1130,y:949,t:1527271772902};\\\", \\\"{x:1197,y:928,t:1527271772919};\\\", \\\"{x:1256,y:920,t:1527271772935};\\\", \\\"{x:1300,y:909,t:1527271772951};\\\", \\\"{x:1341,y:898,t:1527271772968};\\\", \\\"{x:1365,y:889,t:1527271772985};\\\", \\\"{x:1376,y:882,t:1527271773002};\\\", \\\"{x:1386,y:875,t:1527271773019};\\\", \\\"{x:1389,y:870,t:1527271773034};\\\", \\\"{x:1390,y:868,t:1527271773052};\\\", \\\"{x:1391,y:867,t:1527271773069};\\\", \\\"{x:1390,y:864,t:1527271773099};\\\", \\\"{x:1389,y:864,t:1527271773107};\\\", \\\"{x:1387,y:864,t:1527271773120};\\\", \\\"{x:1385,y:864,t:1527271773134};\\\", \\\"{x:1380,y:864,t:1527271773151};\\\", \\\"{x:1373,y:866,t:1527271773168};\\\", \\\"{x:1363,y:871,t:1527271773184};\\\", \\\"{x:1343,y:880,t:1527271773202};\\\", \\\"{x:1315,y:893,t:1527271773218};\\\", \\\"{x:1298,y:901,t:1527271773234};\\\", \\\"{x:1286,y:906,t:1527271773252};\\\", \\\"{x:1277,y:911,t:1527271773268};\\\", \\\"{x:1270,y:917,t:1527271773284};\\\", \\\"{x:1265,y:924,t:1527271773302};\\\", \\\"{x:1261,y:931,t:1527271773319};\\\", \\\"{x:1259,y:937,t:1527271773334};\\\", \\\"{x:1259,y:940,t:1527271773351};\\\", \\\"{x:1258,y:943,t:1527271773368};\\\", \\\"{x:1258,y:944,t:1527271773547};\\\", \\\"{x:1260,y:945,t:1527271773555};\\\", \\\"{x:1261,y:946,t:1527271773569};\\\", \\\"{x:1263,y:947,t:1527271773585};\\\", \\\"{x:1264,y:948,t:1527271773601};\\\", \\\"{x:1265,y:948,t:1527271773618};\\\", \\\"{x:1266,y:950,t:1527271773635};\\\", \\\"{x:1268,y:951,t:1527271773652};\\\", \\\"{x:1270,y:954,t:1527271773669};\\\", \\\"{x:1271,y:955,t:1527271773686};\\\", \\\"{x:1273,y:955,t:1527271773723};\\\", \\\"{x:1274,y:955,t:1527271773735};\\\", \\\"{x:1276,y:955,t:1527271773752};\\\", \\\"{x:1277,y:955,t:1527271774019};\\\", \\\"{x:1278,y:955,t:1527271774043};\\\", \\\"{x:1278,y:953,t:1527271774163};\\\", \\\"{x:1278,y:950,t:1527271774171};\\\", \\\"{x:1278,y:949,t:1527271774186};\\\", \\\"{x:1278,y:939,t:1527271774203};\\\", \\\"{x:1278,y:929,t:1527271774219};\\\", \\\"{x:1280,y:922,t:1527271774236};\\\", \\\"{x:1280,y:913,t:1527271774253};\\\", \\\"{x:1280,y:905,t:1527271774269};\\\", \\\"{x:1281,y:896,t:1527271774286};\\\", \\\"{x:1281,y:888,t:1527271774303};\\\", \\\"{x:1281,y:877,t:1527271774319};\\\", \\\"{x:1281,y:868,t:1527271774336};\\\", \\\"{x:1281,y:862,t:1527271774353};\\\", \\\"{x:1279,y:854,t:1527271774372};\\\", \\\"{x:1279,y:852,t:1527271774387};\\\", \\\"{x:1277,y:848,t:1527271774403};\\\", \\\"{x:1277,y:845,t:1527271774419};\\\", \\\"{x:1277,y:843,t:1527271774437};\\\", \\\"{x:1277,y:840,t:1527271774453};\\\", \\\"{x:1277,y:837,t:1527271774470};\\\", \\\"{x:1276,y:837,t:1527271774487};\\\", \\\"{x:1276,y:836,t:1527271774503};\\\", \\\"{x:1276,y:834,t:1527271774520};\\\", \\\"{x:1276,y:833,t:1527271774536};\\\", \\\"{x:1276,y:831,t:1527271774556};\\\", \\\"{x:1276,y:828,t:1527271774570};\\\", \\\"{x:1276,y:826,t:1527271774594};\\\", \\\"{x:1276,y:825,t:1527271774602};\\\", \\\"{x:1276,y:824,t:1527271774626};\\\", \\\"{x:1276,y:823,t:1527271774642};\\\", \\\"{x:1276,y:822,t:1527271774658};\\\", \\\"{x:1277,y:821,t:1527271774682};\\\", \\\"{x:1277,y:820,t:1527271774706};\\\", \\\"{x:1277,y:819,t:1527271774738};\\\", \\\"{x:1277,y:821,t:1527271775402};\\\", \\\"{x:1277,y:822,t:1527271775451};\\\", \\\"{x:1273,y:822,t:1527271783604};\\\", \\\"{x:1257,y:820,t:1527271783612};\\\", \\\"{x:1214,y:813,t:1527271783627};\\\", \\\"{x:1120,y:800,t:1527271783643};\\\", \\\"{x:990,y:781,t:1527271783659};\\\", \\\"{x:851,y:760,t:1527271783677};\\\", \\\"{x:742,y:742,t:1527271783694};\\\", \\\"{x:661,y:729,t:1527271783709};\\\", \\\"{x:611,y:715,t:1527271783726};\\\", \\\"{x:566,y:699,t:1527271783743};\\\", \\\"{x:512,y:683,t:1527271783760};\\\", \\\"{x:487,y:677,t:1527271783777};\\\", \\\"{x:458,y:669,t:1527271783793};\\\", \\\"{x:435,y:666,t:1527271783810};\\\", \\\"{x:415,y:663,t:1527271783826};\\\", \\\"{x:395,y:661,t:1527271783843};\\\", \\\"{x:392,y:660,t:1527271783859};\\\", \\\"{x:390,y:658,t:1527271783939};\\\", \\\"{x:376,y:646,t:1527271783948};\\\", \\\"{x:359,y:635,t:1527271783960};\\\", \\\"{x:311,y:602,t:1527271783976};\\\", \\\"{x:273,y:571,t:1527271783992};\\\", \\\"{x:253,y:557,t:1527271784009};\\\", \\\"{x:247,y:552,t:1527271784026};\\\", \\\"{x:246,y:551,t:1527271784043};\\\", \\\"{x:246,y:547,t:1527271784061};\\\", \\\"{x:252,y:535,t:1527271784078};\\\", \\\"{x:263,y:521,t:1527271784093};\\\", \\\"{x:271,y:510,t:1527271784110};\\\", \\\"{x:278,y:504,t:1527271784127};\\\", \\\"{x:286,y:498,t:1527271784143};\\\", \\\"{x:297,y:493,t:1527271784161};\\\", \\\"{x:303,y:491,t:1527271784177};\\\", \\\"{x:308,y:488,t:1527271784194};\\\", \\\"{x:310,y:488,t:1527271784210};\\\", \\\"{x:311,y:487,t:1527271784227};\\\", \\\"{x:312,y:487,t:1527271784244};\\\", \\\"{x:314,y:487,t:1527271784332};\\\", \\\"{x:315,y:488,t:1527271784347};\\\", \\\"{x:316,y:489,t:1527271784362};\\\", \\\"{x:323,y:497,t:1527271784379};\\\", \\\"{x:330,y:500,t:1527271784395};\\\", \\\"{x:351,y:509,t:1527271784412};\\\", \\\"{x:364,y:512,t:1527271784428};\\\", \\\"{x:375,y:515,t:1527271784444};\\\", \\\"{x:380,y:515,t:1527271784461};\\\", \\\"{x:380,y:516,t:1527271784603};\\\", \\\"{x:380,y:517,t:1527271784611};\\\", \\\"{x:379,y:518,t:1527271784628};\\\", \\\"{x:378,y:518,t:1527271784698};\\\", \\\"{x:377,y:519,t:1527271784714};\\\", \\\"{x:376,y:520,t:1527271784729};\\\", \\\"{x:375,y:520,t:1527271784753};\\\", \\\"{x:374,y:520,t:1527271784770};\\\", \\\"{x:373,y:521,t:1527271784778};\\\", \\\"{x:372,y:522,t:1527271784794};\\\", \\\"{x:371,y:522,t:1527271784810};\\\", \\\"{x:370,y:522,t:1527271785163};\\\", \\\"{x:377,y:543,t:1527271785180};\\\", \\\"{x:398,y:568,t:1527271785194};\\\", \\\"{x:423,y:586,t:1527271785213};\\\", \\\"{x:449,y:604,t:1527271785228};\\\", \\\"{x:471,y:620,t:1527271785245};\\\", \\\"{x:489,y:640,t:1527271785261};\\\", \\\"{x:503,y:658,t:1527271785278};\\\", \\\"{x:504,y:663,t:1527271785294};\\\", \\\"{x:504,y:664,t:1527271785312};\\\", \\\"{x:503,y:665,t:1527271785328};\\\", \\\"{x:493,y:661,t:1527271785345};\\\", \\\"{x:448,y:613,t:1527271785362};\\\", \\\"{x:391,y:568,t:1527271785379};\\\", \\\"{x:351,y:539,t:1527271785395};\\\", \\\"{x:340,y:529,t:1527271785413};\\\", \\\"{x:338,y:526,t:1527271785427};\\\", \\\"{x:340,y:521,t:1527271785445};\\\", \\\"{x:344,y:518,t:1527271785462};\\\", \\\"{x:348,y:514,t:1527271785478};\\\", \\\"{x:350,y:510,t:1527271785495};\\\", \\\"{x:350,y:507,t:1527271785512};\\\", \\\"{x:351,y:504,t:1527271785528};\\\", \\\"{x:351,y:503,t:1527271785545};\\\", \\\"{x:352,y:502,t:1527271785627};\\\", \\\"{x:353,y:502,t:1527271785635};\\\", \\\"{x:355,y:502,t:1527271785645};\\\", \\\"{x:357,y:502,t:1527271785662};\\\", \\\"{x:359,y:502,t:1527271785679};\\\", \\\"{x:360,y:502,t:1527271785696};\\\", \\\"{x:362,y:502,t:1527271785715};\\\", \\\"{x:365,y:503,t:1527271785730};\\\", \\\"{x:374,y:504,t:1527271785745};\\\", \\\"{x:388,y:510,t:1527271785764};\\\", \\\"{x:394,y:513,t:1527271785778};\\\", \\\"{x:395,y:514,t:1527271785795};\\\", \\\"{x:396,y:515,t:1527271785812};\\\", \\\"{x:396,y:516,t:1527271785829};\\\", \\\"{x:396,y:518,t:1527271785850};\\\", \\\"{x:396,y:519,t:1527271785883};\\\", \\\"{x:395,y:520,t:1527271785995};\\\", \\\"{x:393,y:522,t:1527271786013};\\\", \\\"{x:392,y:522,t:1527271786035};\\\", \\\"{x:391,y:523,t:1527271786451};\\\", \\\"{x:391,y:526,t:1527271786462};\\\", \\\"{x:404,y:543,t:1527271786480};\\\", \\\"{x:441,y:579,t:1527271786496};\\\", \\\"{x:491,y:626,t:1527271786512};\\\", \\\"{x:556,y:672,t:1527271786530};\\\", \\\"{x:662,y:748,t:1527271786546};\\\", \\\"{x:706,y:791,t:1527271786562};\\\", \\\"{x:725,y:821,t:1527271786579};\\\", \\\"{x:726,y:847,t:1527271786595};\\\", \\\"{x:722,y:873,t:1527271786613};\\\", \\\"{x:702,y:900,t:1527271786629};\\\", \\\"{x:682,y:904,t:1527271786646};\\\", \\\"{x:662,y:904,t:1527271786663};\\\", \\\"{x:640,y:903,t:1527271786679};\\\", \\\"{x:620,y:895,t:1527271786696};\\\", \\\"{x:605,y:885,t:1527271786713};\\\", \\\"{x:588,y:870,t:1527271786729};\\\", \\\"{x:548,y:818,t:1527271786746};\\\", \\\"{x:530,y:791,t:1527271786763};\\\", \\\"{x:514,y:771,t:1527271786778};\\\", \\\"{x:503,y:760,t:1527271786796};\\\", \\\"{x:500,y:752,t:1527271786813};\\\", \\\"{x:499,y:744,t:1527271786829};\\\", \\\"{x:502,y:737,t:1527271786847};\\\", \\\"{x:506,y:731,t:1527271786864};\\\", \\\"{x:510,y:723,t:1527271786879};\\\", \\\"{x:511,y:716,t:1527271786896};\\\", \\\"{x:511,y:710,t:1527271786912};\\\", \\\"{x:513,y:706,t:1527271786928};\\\", \\\"{x:512,y:706,t:1527271787099};\\\", \\\"{x:510,y:706,t:1527271787111};\\\", \\\"{x:509,y:706,t:1527271787129};\\\", \\\"{x:506,y:709,t:1527271787146};\\\", \\\"{x:505,y:712,t:1527271787161};\\\", \\\"{x:503,y:716,t:1527271787178};\\\", \\\"{x:502,y:718,t:1527271787195};\\\", \\\"{x:502,y:719,t:1527271787211};\\\", \\\"{x:503,y:719,t:1527271787667};\\\" ] }, { \\\"rt\\\": 22037, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 230113, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -C -H -D -07 PM-E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:718,t:1527271793442};\\\", \\\"{x:505,y:718,t:1527271793458};\\\", \\\"{x:507,y:718,t:1527271793470};\\\", \\\"{x:507,y:716,t:1527271793487};\\\", \\\"{x:509,y:716,t:1527271793675};\\\", \\\"{x:512,y:716,t:1527271793687};\\\", \\\"{x:517,y:715,t:1527271793705};\\\", \\\"{x:522,y:710,t:1527271793722};\\\", \\\"{x:529,y:701,t:1527271793737};\\\", \\\"{x:543,y:674,t:1527271793756};\\\", \\\"{x:550,y:648,t:1527271793771};\\\", \\\"{x:557,y:622,t:1527271793787};\\\", \\\"{x:559,y:605,t:1527271793802};\\\", \\\"{x:573,y:547,t:1527271793818};\\\", \\\"{x:579,y:520,t:1527271793836};\\\", \\\"{x:581,y:492,t:1527271793851};\\\", \\\"{x:588,y:461,t:1527271793868};\\\", \\\"{x:589,y:445,t:1527271793886};\\\", \\\"{x:589,y:436,t:1527271793901};\\\", \\\"{x:587,y:428,t:1527271793918};\\\", \\\"{x:583,y:422,t:1527271793935};\\\", \\\"{x:577,y:417,t:1527271793951};\\\", \\\"{x:572,y:415,t:1527271793968};\\\", \\\"{x:571,y:414,t:1527271793985};\\\", \\\"{x:570,y:414,t:1527271794034};\\\", \\\"{x:561,y:414,t:1527271794052};\\\", \\\"{x:543,y:425,t:1527271794069};\\\", \\\"{x:523,y:436,t:1527271794084};\\\", \\\"{x:505,y:445,t:1527271794101};\\\", \\\"{x:490,y:453,t:1527271794118};\\\", \\\"{x:480,y:458,t:1527271794135};\\\", \\\"{x:473,y:463,t:1527271794152};\\\", \\\"{x:465,y:469,t:1527271794168};\\\", \\\"{x:458,y:476,t:1527271794184};\\\", \\\"{x:455,y:479,t:1527271794202};\\\", \\\"{x:452,y:481,t:1527271794218};\\\", \\\"{x:452,y:482,t:1527271794307};\\\", \\\"{x:453,y:482,t:1527271794317};\\\", \\\"{x:456,y:482,t:1527271794334};\\\", \\\"{x:462,y:482,t:1527271794351};\\\", \\\"{x:470,y:482,t:1527271794368};\\\", \\\"{x:482,y:479,t:1527271794384};\\\", \\\"{x:492,y:477,t:1527271794401};\\\", \\\"{x:502,y:475,t:1527271794418};\\\", \\\"{x:514,y:473,t:1527271794435};\\\", \\\"{x:521,y:473,t:1527271794451};\\\", \\\"{x:533,y:471,t:1527271794467};\\\", \\\"{x:539,y:470,t:1527271794484};\\\", \\\"{x:545,y:469,t:1527271794501};\\\", \\\"{x:550,y:469,t:1527271794518};\\\", \\\"{x:556,y:469,t:1527271794533};\\\", \\\"{x:561,y:469,t:1527271794551};\\\", \\\"{x:566,y:469,t:1527271794567};\\\", \\\"{x:572,y:469,t:1527271794584};\\\", \\\"{x:577,y:469,t:1527271794601};\\\", \\\"{x:589,y:472,t:1527271794617};\\\", \\\"{x:607,y:477,t:1527271794633};\\\", \\\"{x:643,y:487,t:1527271794651};\\\", \\\"{x:669,y:494,t:1527271794667};\\\", \\\"{x:694,y:502,t:1527271794683};\\\", \\\"{x:716,y:509,t:1527271794702};\\\", \\\"{x:735,y:514,t:1527271794717};\\\", \\\"{x:751,y:519,t:1527271794737};\\\", \\\"{x:770,y:526,t:1527271794752};\\\", \\\"{x:792,y:533,t:1527271794769};\\\", \\\"{x:825,y:543,t:1527271794786};\\\", \\\"{x:847,y:545,t:1527271794802};\\\", \\\"{x:877,y:550,t:1527271794819};\\\", \\\"{x:913,y:556,t:1527271794836};\\\", \\\"{x:961,y:572,t:1527271794854};\\\", \\\"{x:1005,y:578,t:1527271794869};\\\", \\\"{x:1045,y:583,t:1527271794886};\\\", \\\"{x:1074,y:589,t:1527271794902};\\\", \\\"{x:1106,y:598,t:1527271794919};\\\", \\\"{x:1129,y:603,t:1527271794936};\\\", \\\"{x:1149,y:612,t:1527271794952};\\\", \\\"{x:1164,y:617,t:1527271794969};\\\", \\\"{x:1182,y:628,t:1527271794985};\\\", \\\"{x:1206,y:646,t:1527271795002};\\\", \\\"{x:1222,y:659,t:1527271795020};\\\", \\\"{x:1241,y:674,t:1527271795035};\\\", \\\"{x:1261,y:691,t:1527271795053};\\\", \\\"{x:1281,y:710,t:1527271795069};\\\", \\\"{x:1297,y:726,t:1527271795086};\\\", \\\"{x:1310,y:741,t:1527271795103};\\\", \\\"{x:1322,y:757,t:1527271795120};\\\", \\\"{x:1339,y:776,t:1527271795135};\\\", \\\"{x:1357,y:793,t:1527271795153};\\\", \\\"{x:1376,y:808,t:1527271795169};\\\", \\\"{x:1388,y:819,t:1527271795185};\\\", \\\"{x:1399,y:828,t:1527271795202};\\\", \\\"{x:1400,y:830,t:1527271795220};\\\", \\\"{x:1401,y:830,t:1527271795235};\\\", \\\"{x:1401,y:831,t:1527271795252};\\\", \\\"{x:1401,y:833,t:1527271795269};\\\", \\\"{x:1400,y:838,t:1527271795285};\\\", \\\"{x:1399,y:842,t:1527271795302};\\\", \\\"{x:1396,y:848,t:1527271795320};\\\", \\\"{x:1392,y:852,t:1527271795336};\\\", \\\"{x:1384,y:857,t:1527271795353};\\\", \\\"{x:1375,y:865,t:1527271795370};\\\", \\\"{x:1364,y:872,t:1527271795385};\\\", \\\"{x:1343,y:878,t:1527271795402};\\\", \\\"{x:1330,y:879,t:1527271795419};\\\", \\\"{x:1317,y:879,t:1527271795436};\\\", \\\"{x:1306,y:879,t:1527271795453};\\\", \\\"{x:1294,y:879,t:1527271795470};\\\", \\\"{x:1279,y:879,t:1527271795486};\\\", \\\"{x:1268,y:879,t:1527271795502};\\\", \\\"{x:1264,y:880,t:1527271795519};\\\", \\\"{x:1262,y:880,t:1527271795595};\\\", \\\"{x:1258,y:875,t:1527271795602};\\\", \\\"{x:1250,y:864,t:1527271795619};\\\", \\\"{x:1244,y:857,t:1527271795636};\\\", \\\"{x:1241,y:853,t:1527271795652};\\\", \\\"{x:1240,y:851,t:1527271795668};\\\", \\\"{x:1239,y:850,t:1527271795699};\\\", \\\"{x:1237,y:847,t:1527271795715};\\\", \\\"{x:1235,y:846,t:1527271795731};\\\", \\\"{x:1232,y:843,t:1527271795739};\\\", \\\"{x:1231,y:843,t:1527271795753};\\\", \\\"{x:1229,y:842,t:1527271795768};\\\", \\\"{x:1227,y:841,t:1527271795785};\\\", \\\"{x:1226,y:841,t:1527271795818};\\\", \\\"{x:1220,y:840,t:1527271795836};\\\", \\\"{x:1213,y:839,t:1527271795853};\\\", \\\"{x:1206,y:838,t:1527271795868};\\\", \\\"{x:1195,y:836,t:1527271795885};\\\", \\\"{x:1189,y:834,t:1527271795902};\\\", \\\"{x:1186,y:834,t:1527271795919};\\\", \\\"{x:1186,y:833,t:1527271795935};\\\", \\\"{x:1187,y:833,t:1527271796091};\\\", \\\"{x:1189,y:833,t:1527271796102};\\\", \\\"{x:1193,y:831,t:1527271796118};\\\", \\\"{x:1201,y:827,t:1527271796135};\\\", \\\"{x:1211,y:822,t:1527271796152};\\\", \\\"{x:1229,y:811,t:1527271796169};\\\", \\\"{x:1252,y:796,t:1527271796186};\\\", \\\"{x:1272,y:781,t:1527271796202};\\\", \\\"{x:1303,y:756,t:1527271796218};\\\", \\\"{x:1316,y:745,t:1527271796236};\\\", \\\"{x:1323,y:738,t:1527271796252};\\\", \\\"{x:1327,y:735,t:1527271796269};\\\", \\\"{x:1329,y:731,t:1527271796285};\\\", \\\"{x:1331,y:726,t:1527271796302};\\\", \\\"{x:1332,y:719,t:1527271796318};\\\", \\\"{x:1333,y:712,t:1527271796336};\\\", \\\"{x:1335,y:704,t:1527271796352};\\\", \\\"{x:1339,y:693,t:1527271796368};\\\", \\\"{x:1340,y:690,t:1527271796385};\\\", \\\"{x:1340,y:687,t:1527271796402};\\\", \\\"{x:1343,y:683,t:1527271796418};\\\", \\\"{x:1344,y:679,t:1527271796436};\\\", \\\"{x:1347,y:671,t:1527271796452};\\\", \\\"{x:1352,y:661,t:1527271796469};\\\", \\\"{x:1359,y:645,t:1527271796485};\\\", \\\"{x:1367,y:631,t:1527271796501};\\\", \\\"{x:1378,y:617,t:1527271796518};\\\", \\\"{x:1397,y:591,t:1527271796536};\\\", \\\"{x:1417,y:559,t:1527271796554};\\\", \\\"{x:1429,y:544,t:1527271796568};\\\", \\\"{x:1439,y:534,t:1527271796586};\\\", \\\"{x:1446,y:526,t:1527271796601};\\\", \\\"{x:1449,y:522,t:1527271796618};\\\", \\\"{x:1451,y:519,t:1527271796634};\\\", \\\"{x:1455,y:515,t:1527271796651};\\\", \\\"{x:1458,y:513,t:1527271796668};\\\", \\\"{x:1459,y:512,t:1527271796684};\\\", \\\"{x:1462,y:510,t:1527271796701};\\\", \\\"{x:1470,y:507,t:1527271796718};\\\", \\\"{x:1473,y:507,t:1527271796734};\\\", \\\"{x:1474,y:507,t:1527271796868};\\\", \\\"{x:1493,y:512,t:1527271796885};\\\", \\\"{x:1509,y:519,t:1527271796902};\\\", \\\"{x:1511,y:521,t:1527271796919};\\\", \\\"{x:1513,y:523,t:1527271796935};\\\", \\\"{x:1528,y:530,t:1527271796952};\\\", \\\"{x:1552,y:543,t:1527271796968};\\\", \\\"{x:1571,y:555,t:1527271796985};\\\", \\\"{x:1590,y:567,t:1527271797002};\\\", \\\"{x:1600,y:575,t:1527271797019};\\\", \\\"{x:1604,y:578,t:1527271797035};\\\", \\\"{x:1607,y:581,t:1527271797051};\\\", \\\"{x:1611,y:587,t:1527271797069};\\\", \\\"{x:1611,y:592,t:1527271797085};\\\", \\\"{x:1614,y:597,t:1527271797102};\\\", \\\"{x:1615,y:605,t:1527271797117};\\\", \\\"{x:1619,y:614,t:1527271797135};\\\", \\\"{x:1621,y:624,t:1527271797152};\\\", \\\"{x:1625,y:633,t:1527271797168};\\\", \\\"{x:1628,y:644,t:1527271797185};\\\", \\\"{x:1629,y:650,t:1527271797202};\\\", \\\"{x:1630,y:655,t:1527271797219};\\\", \\\"{x:1632,y:662,t:1527271797235};\\\", \\\"{x:1633,y:667,t:1527271797252};\\\", \\\"{x:1636,y:674,t:1527271797268};\\\", \\\"{x:1637,y:682,t:1527271797285};\\\", \\\"{x:1637,y:687,t:1527271797301};\\\", \\\"{x:1637,y:692,t:1527271797317};\\\", \\\"{x:1637,y:694,t:1527271797335};\\\", \\\"{x:1637,y:696,t:1527271797352};\\\", \\\"{x:1637,y:697,t:1527271797368};\\\", \\\"{x:1637,y:699,t:1527271797385};\\\", \\\"{x:1637,y:697,t:1527271797547};\\\", \\\"{x:1637,y:690,t:1527271797555};\\\", \\\"{x:1637,y:676,t:1527271797568};\\\", \\\"{x:1634,y:657,t:1527271797585};\\\", \\\"{x:1629,y:637,t:1527271797601};\\\", \\\"{x:1624,y:612,t:1527271797619};\\\", \\\"{x:1623,y:595,t:1527271797635};\\\", \\\"{x:1623,y:579,t:1527271797652};\\\", \\\"{x:1623,y:567,t:1527271797668};\\\", \\\"{x:1623,y:547,t:1527271797684};\\\", \\\"{x:1623,y:523,t:1527271797700};\\\", \\\"{x:1623,y:511,t:1527271797718};\\\", \\\"{x:1623,y:504,t:1527271797735};\\\", \\\"{x:1623,y:500,t:1527271797751};\\\", \\\"{x:1623,y:497,t:1527271797768};\\\", \\\"{x:1623,y:495,t:1527271797827};\\\", \\\"{x:1621,y:492,t:1527271797834};\\\", \\\"{x:1612,y:478,t:1527271797850};\\\", \\\"{x:1602,y:469,t:1527271797868};\\\", \\\"{x:1600,y:466,t:1527271797885};\\\", \\\"{x:1600,y:465,t:1527271797901};\\\", \\\"{x:1600,y:463,t:1527271797918};\\\", \\\"{x:1600,y:457,t:1527271797935};\\\", \\\"{x:1600,y:449,t:1527271797951};\\\", \\\"{x:1600,y:442,t:1527271797968};\\\", \\\"{x:1600,y:433,t:1527271797985};\\\", \\\"{x:1600,y:428,t:1527271798001};\\\", \\\"{x:1601,y:423,t:1527271798018};\\\", \\\"{x:1601,y:422,t:1527271798035};\\\", \\\"{x:1603,y:420,t:1527271798051};\\\", \\\"{x:1604,y:419,t:1527271798068};\\\", \\\"{x:1605,y:418,t:1527271798085};\\\", \\\"{x:1605,y:417,t:1527271798101};\\\", \\\"{x:1606,y:418,t:1527271798243};\\\", \\\"{x:1606,y:421,t:1527271798251};\\\", \\\"{x:1607,y:427,t:1527271798268};\\\", \\\"{x:1607,y:433,t:1527271798284};\\\", \\\"{x:1607,y:437,t:1527271798301};\\\", \\\"{x:1608,y:440,t:1527271798318};\\\", \\\"{x:1610,y:442,t:1527271798334};\\\", \\\"{x:1610,y:443,t:1527271798351};\\\", \\\"{x:1610,y:445,t:1527271798368};\\\", \\\"{x:1611,y:447,t:1527271798384};\\\", \\\"{x:1612,y:451,t:1527271798401};\\\", \\\"{x:1613,y:456,t:1527271798419};\\\", \\\"{x:1613,y:457,t:1527271798434};\\\", \\\"{x:1613,y:461,t:1527271798451};\\\", \\\"{x:1615,y:469,t:1527271798467};\\\", \\\"{x:1618,y:479,t:1527271798484};\\\", \\\"{x:1621,y:488,t:1527271798501};\\\", \\\"{x:1622,y:494,t:1527271798518};\\\", \\\"{x:1624,y:498,t:1527271798534};\\\", \\\"{x:1624,y:501,t:1527271798551};\\\", \\\"{x:1624,y:507,t:1527271798567};\\\", \\\"{x:1624,y:512,t:1527271798584};\\\", \\\"{x:1624,y:514,t:1527271798601};\\\", \\\"{x:1624,y:517,t:1527271798619};\\\", \\\"{x:1624,y:518,t:1527271798634};\\\", \\\"{x:1624,y:519,t:1527271798651};\\\", \\\"{x:1624,y:520,t:1527271798667};\\\", \\\"{x:1624,y:522,t:1527271798684};\\\", \\\"{x:1624,y:524,t:1527271798701};\\\", \\\"{x:1624,y:525,t:1527271798718};\\\", \\\"{x:1624,y:528,t:1527271798734};\\\", \\\"{x:1624,y:531,t:1527271798751};\\\", \\\"{x:1624,y:534,t:1527271798767};\\\", \\\"{x:1624,y:536,t:1527271798784};\\\", \\\"{x:1624,y:537,t:1527271798802};\\\", \\\"{x:1624,y:538,t:1527271798819};\\\", \\\"{x:1624,y:539,t:1527271798859};\\\", \\\"{x:1624,y:540,t:1527271798891};\\\", \\\"{x:1624,y:542,t:1527271798907};\\\", \\\"{x:1624,y:543,t:1527271798923};\\\", \\\"{x:1624,y:544,t:1527271798947};\\\", \\\"{x:1624,y:545,t:1527271798971};\\\", \\\"{x:1624,y:546,t:1527271798984};\\\", \\\"{x:1624,y:547,t:1527271799001};\\\", \\\"{x:1623,y:547,t:1527271799017};\\\", \\\"{x:1623,y:548,t:1527271799034};\\\", \\\"{x:1623,y:549,t:1527271799051};\\\", \\\"{x:1623,y:548,t:1527271799970};\\\", \\\"{x:1622,y:539,t:1527271799983};\\\", \\\"{x:1619,y:519,t:1527271800000};\\\", \\\"{x:1613,y:502,t:1527271800017};\\\", \\\"{x:1611,y:492,t:1527271800033};\\\", \\\"{x:1609,y:484,t:1527271800050};\\\", \\\"{x:1608,y:471,t:1527271800068};\\\", \\\"{x:1607,y:465,t:1527271800083};\\\", \\\"{x:1607,y:458,t:1527271800100};\\\", \\\"{x:1606,y:452,t:1527271800117};\\\", \\\"{x:1605,y:449,t:1527271800132};\\\", \\\"{x:1605,y:446,t:1527271800149};\\\", \\\"{x:1605,y:442,t:1527271800166};\\\", \\\"{x:1605,y:438,t:1527271800182};\\\", \\\"{x:1605,y:437,t:1527271800200};\\\", \\\"{x:1605,y:435,t:1527271800217};\\\", \\\"{x:1605,y:434,t:1527271800232};\\\", \\\"{x:1605,y:432,t:1527271800266};\\\", \\\"{x:1605,y:431,t:1527271800283};\\\", \\\"{x:1606,y:431,t:1527271800300};\\\", \\\"{x:1608,y:430,t:1527271800316};\\\", \\\"{x:1612,y:428,t:1527271800333};\\\", \\\"{x:1614,y:427,t:1527271800350};\\\", \\\"{x:1615,y:427,t:1527271800378};\\\", \\\"{x:1616,y:425,t:1527271800386};\\\", \\\"{x:1617,y:425,t:1527271800426};\\\", \\\"{x:1618,y:425,t:1527271800442};\\\", \\\"{x:1617,y:425,t:1527271801091};\\\", \\\"{x:1616,y:427,t:1527271802115};\\\", \\\"{x:1616,y:429,t:1527271802132};\\\", \\\"{x:1616,y:431,t:1527271802149};\\\", \\\"{x:1616,y:433,t:1527271802165};\\\", \\\"{x:1616,y:434,t:1527271802182};\\\", \\\"{x:1616,y:435,t:1527271802219};\\\", \\\"{x:1616,y:436,t:1527271802233};\\\", \\\"{x:1616,y:438,t:1527271802249};\\\", \\\"{x:1616,y:442,t:1527271802265};\\\", \\\"{x:1616,y:444,t:1527271802283};\\\", \\\"{x:1618,y:450,t:1527271802299};\\\", \\\"{x:1618,y:454,t:1527271802315};\\\", \\\"{x:1618,y:459,t:1527271802333};\\\", \\\"{x:1619,y:462,t:1527271802349};\\\", \\\"{x:1620,y:469,t:1527271802365};\\\", \\\"{x:1622,y:474,t:1527271802382};\\\", \\\"{x:1623,y:481,t:1527271802399};\\\", \\\"{x:1623,y:486,t:1527271802415};\\\", \\\"{x:1624,y:490,t:1527271802432};\\\", \\\"{x:1626,y:498,t:1527271802448};\\\", \\\"{x:1627,y:504,t:1527271802466};\\\", \\\"{x:1628,y:515,t:1527271802483};\\\", \\\"{x:1628,y:519,t:1527271802498};\\\", \\\"{x:1628,y:524,t:1527271802515};\\\", \\\"{x:1631,y:529,t:1527271802532};\\\", \\\"{x:1631,y:532,t:1527271802549};\\\", \\\"{x:1631,y:536,t:1527271802564};\\\", \\\"{x:1631,y:539,t:1527271802581};\\\", \\\"{x:1631,y:542,t:1527271802597};\\\", \\\"{x:1631,y:545,t:1527271802614};\\\", \\\"{x:1632,y:548,t:1527271802631};\\\", \\\"{x:1632,y:553,t:1527271802648};\\\", \\\"{x:1632,y:557,t:1527271802664};\\\", \\\"{x:1632,y:564,t:1527271802682};\\\", \\\"{x:1632,y:572,t:1527271802698};\\\", \\\"{x:1632,y:577,t:1527271802715};\\\", \\\"{x:1632,y:582,t:1527271802732};\\\", \\\"{x:1632,y:586,t:1527271802748};\\\", \\\"{x:1632,y:588,t:1527271802764};\\\", \\\"{x:1632,y:592,t:1527271802782};\\\", \\\"{x:1631,y:594,t:1527271802798};\\\", \\\"{x:1631,y:597,t:1527271802815};\\\", \\\"{x:1631,y:600,t:1527271802832};\\\", \\\"{x:1630,y:605,t:1527271802848};\\\", \\\"{x:1630,y:611,t:1527271802865};\\\", \\\"{x:1629,y:617,t:1527271802883};\\\", \\\"{x:1629,y:620,t:1527271802898};\\\", \\\"{x:1627,y:625,t:1527271802914};\\\", \\\"{x:1626,y:629,t:1527271802932};\\\", \\\"{x:1626,y:634,t:1527271802948};\\\", \\\"{x:1626,y:637,t:1527271802966};\\\", \\\"{x:1626,y:640,t:1527271802982};\\\", \\\"{x:1625,y:644,t:1527271802999};\\\", \\\"{x:1625,y:646,t:1527271803015};\\\", \\\"{x:1624,y:650,t:1527271803031};\\\", \\\"{x:1623,y:651,t:1527271803048};\\\", \\\"{x:1623,y:654,t:1527271803066};\\\", \\\"{x:1622,y:656,t:1527271803081};\\\", \\\"{x:1622,y:659,t:1527271803098};\\\", \\\"{x:1622,y:663,t:1527271803114};\\\", \\\"{x:1622,y:668,t:1527271803131};\\\", \\\"{x:1622,y:672,t:1527271803148};\\\", \\\"{x:1622,y:676,t:1527271803165};\\\", \\\"{x:1622,y:681,t:1527271803182};\\\", \\\"{x:1622,y:685,t:1527271803198};\\\", \\\"{x:1622,y:688,t:1527271803216};\\\", \\\"{x:1622,y:690,t:1527271803231};\\\", \\\"{x:1622,y:692,t:1527271803248};\\\", \\\"{x:1622,y:694,t:1527271803265};\\\", \\\"{x:1622,y:700,t:1527271803281};\\\", \\\"{x:1622,y:707,t:1527271803298};\\\", \\\"{x:1622,y:710,t:1527271803315};\\\", \\\"{x:1623,y:710,t:1527271803331};\\\", \\\"{x:1623,y:713,t:1527271803348};\\\", \\\"{x:1623,y:714,t:1527271803365};\\\", \\\"{x:1623,y:719,t:1527271803381};\\\", \\\"{x:1623,y:723,t:1527271803398};\\\", \\\"{x:1623,y:731,t:1527271803415};\\\", \\\"{x:1623,y:736,t:1527271803431};\\\", \\\"{x:1623,y:740,t:1527271803448};\\\", \\\"{x:1623,y:745,t:1527271803466};\\\", \\\"{x:1623,y:747,t:1527271803481};\\\", \\\"{x:1623,y:751,t:1527271803498};\\\", \\\"{x:1623,y:754,t:1527271803514};\\\", \\\"{x:1623,y:759,t:1527271803531};\\\", \\\"{x:1623,y:761,t:1527271803548};\\\", \\\"{x:1623,y:763,t:1527271803565};\\\", \\\"{x:1622,y:764,t:1527271803582};\\\", \\\"{x:1622,y:766,t:1527271803598};\\\", \\\"{x:1622,y:769,t:1527271803614};\\\", \\\"{x:1620,y:774,t:1527271803632};\\\", \\\"{x:1620,y:779,t:1527271803648};\\\", \\\"{x:1619,y:781,t:1527271803664};\\\", \\\"{x:1619,y:785,t:1527271803681};\\\", \\\"{x:1619,y:787,t:1527271803699};\\\", \\\"{x:1619,y:790,t:1527271803714};\\\", \\\"{x:1619,y:793,t:1527271803730};\\\", \\\"{x:1619,y:798,t:1527271803748};\\\", \\\"{x:1619,y:801,t:1527271803764};\\\", \\\"{x:1618,y:805,t:1527271803781};\\\", \\\"{x:1618,y:807,t:1527271803798};\\\", \\\"{x:1618,y:808,t:1527271803819};\\\", \\\"{x:1618,y:810,t:1527271803834};\\\", \\\"{x:1618,y:812,t:1527271803848};\\\", \\\"{x:1618,y:815,t:1527271803864};\\\", \\\"{x:1619,y:817,t:1527271803881};\\\", \\\"{x:1619,y:818,t:1527271803898};\\\", \\\"{x:1619,y:819,t:1527271803914};\\\", \\\"{x:1619,y:821,t:1527271803931};\\\", \\\"{x:1619,y:826,t:1527271803948};\\\", \\\"{x:1619,y:830,t:1527271803964};\\\", \\\"{x:1619,y:833,t:1527271803981};\\\", \\\"{x:1619,y:835,t:1527271804003};\\\", \\\"{x:1619,y:836,t:1527271804035};\\\", \\\"{x:1619,y:838,t:1527271804049};\\\", \\\"{x:1619,y:842,t:1527271804065};\\\", \\\"{x:1620,y:846,t:1527271804081};\\\", \\\"{x:1620,y:850,t:1527271804097};\\\", \\\"{x:1620,y:854,t:1527271804114};\\\", \\\"{x:1621,y:856,t:1527271804131};\\\", \\\"{x:1621,y:861,t:1527271804147};\\\", \\\"{x:1624,y:865,t:1527271804164};\\\", \\\"{x:1625,y:868,t:1527271804181};\\\", \\\"{x:1627,y:870,t:1527271804197};\\\", \\\"{x:1629,y:875,t:1527271804214};\\\", \\\"{x:1629,y:877,t:1527271804232};\\\", \\\"{x:1630,y:879,t:1527271804247};\\\", \\\"{x:1630,y:880,t:1527271804264};\\\", \\\"{x:1630,y:881,t:1527271804281};\\\", \\\"{x:1630,y:884,t:1527271804298};\\\", \\\"{x:1631,y:890,t:1527271804314};\\\", \\\"{x:1631,y:893,t:1527271804331};\\\", \\\"{x:1632,y:894,t:1527271804346};\\\", \\\"{x:1632,y:895,t:1527271804364};\\\", \\\"{x:1632,y:896,t:1527271804385};\\\", \\\"{x:1632,y:897,t:1527271804397};\\\", \\\"{x:1632,y:901,t:1527271804414};\\\", \\\"{x:1631,y:905,t:1527271804430};\\\", \\\"{x:1631,y:910,t:1527271804447};\\\", \\\"{x:1630,y:917,t:1527271804464};\\\", \\\"{x:1629,y:922,t:1527271804481};\\\", \\\"{x:1627,y:926,t:1527271804497};\\\", \\\"{x:1625,y:931,t:1527271804514};\\\", \\\"{x:1625,y:933,t:1527271804531};\\\", \\\"{x:1625,y:936,t:1527271804547};\\\", \\\"{x:1623,y:939,t:1527271804564};\\\", \\\"{x:1623,y:943,t:1527271804581};\\\", \\\"{x:1622,y:947,t:1527271804598};\\\", \\\"{x:1622,y:950,t:1527271804614};\\\", \\\"{x:1622,y:951,t:1527271804650};\\\", \\\"{x:1622,y:953,t:1527271804722};\\\", \\\"{x:1622,y:956,t:1527271804729};\\\", \\\"{x:1622,y:959,t:1527271804747};\\\", \\\"{x:1622,y:960,t:1527271804764};\\\", \\\"{x:1622,y:961,t:1527271804780};\\\", \\\"{x:1622,y:962,t:1527271804797};\\\", \\\"{x:1622,y:963,t:1527271804826};\\\", \\\"{x:1622,y:964,t:1527271805107};\\\", \\\"{x:1618,y:960,t:1527271805115};\\\", \\\"{x:1599,y:944,t:1527271805130};\\\", \\\"{x:1540,y:905,t:1527271805147};\\\", \\\"{x:1448,y:857,t:1527271805163};\\\", \\\"{x:1340,y:812,t:1527271805180};\\\", \\\"{x:1205,y:775,t:1527271805197};\\\", \\\"{x:1037,y:733,t:1527271805213};\\\", \\\"{x:836,y:675,t:1527271805230};\\\", \\\"{x:612,y:602,t:1527271805248};\\\", \\\"{x:422,y:558,t:1527271805264};\\\", \\\"{x:256,y:538,t:1527271805297};\\\", \\\"{x:238,y:535,t:1527271805310};\\\", \\\"{x:233,y:533,t:1527271805327};\\\", \\\"{x:233,y:532,t:1527271805401};\\\", \\\"{x:234,y:531,t:1527271805411};\\\", \\\"{x:236,y:531,t:1527271805428};\\\", \\\"{x:244,y:529,t:1527271805445};\\\", \\\"{x:261,y:526,t:1527271805460};\\\", \\\"{x:282,y:524,t:1527271805478};\\\", \\\"{x:318,y:519,t:1527271805495};\\\", \\\"{x:354,y:513,t:1527271805511};\\\", \\\"{x:388,y:508,t:1527271805527};\\\", \\\"{x:413,y:505,t:1527271805545};\\\", \\\"{x:432,y:503,t:1527271805561};\\\", \\\"{x:435,y:503,t:1527271805803};\\\", \\\"{x:441,y:503,t:1527271805812};\\\", \\\"{x:482,y:506,t:1527271805829};\\\", \\\"{x:580,y:521,t:1527271805845};\\\", \\\"{x:733,y:554,t:1527271805862};\\\", \\\"{x:926,y:610,t:1527271805879};\\\", \\\"{x:1123,y:674,t:1527271805895};\\\", \\\"{x:1305,y:750,t:1527271805911};\\\", \\\"{x:1468,y:834,t:1527271805928};\\\", \\\"{x:1623,y:901,t:1527271805945};\\\", \\\"{x:1761,y:955,t:1527271805962};\\\", \\\"{x:1795,y:971,t:1527271805977};\\\", \\\"{x:1809,y:976,t:1527271805995};\\\", \\\"{x:1814,y:979,t:1527271806011};\\\", \\\"{x:1815,y:979,t:1527271806130};\\\", \\\"{x:1815,y:976,t:1527271806145};\\\", \\\"{x:1810,y:969,t:1527271806162};\\\", \\\"{x:1807,y:967,t:1527271806179};\\\", \\\"{x:1805,y:965,t:1527271806195};\\\", \\\"{x:1803,y:963,t:1527271806213};\\\", \\\"{x:1799,y:960,t:1527271806228};\\\", \\\"{x:1796,y:958,t:1527271806245};\\\", \\\"{x:1792,y:956,t:1527271806262};\\\", \\\"{x:1790,y:953,t:1527271806278};\\\", \\\"{x:1787,y:952,t:1527271806295};\\\", \\\"{x:1786,y:951,t:1527271806312};\\\", \\\"{x:1783,y:949,t:1527271806328};\\\", \\\"{x:1780,y:947,t:1527271806345};\\\", \\\"{x:1775,y:945,t:1527271806363};\\\", \\\"{x:1768,y:940,t:1527271806379};\\\", \\\"{x:1757,y:934,t:1527271806395};\\\", \\\"{x:1748,y:929,t:1527271806412};\\\", \\\"{x:1742,y:925,t:1527271806428};\\\", \\\"{x:1738,y:924,t:1527271806445};\\\", \\\"{x:1737,y:923,t:1527271806462};\\\", \\\"{x:1736,y:923,t:1527271806555};\\\", \\\"{x:1735,y:921,t:1527271806562};\\\", \\\"{x:1734,y:920,t:1527271806595};\\\", \\\"{x:1731,y:920,t:1527271806612};\\\", \\\"{x:1729,y:918,t:1527271806628};\\\", \\\"{x:1727,y:916,t:1527271806645};\\\", \\\"{x:1723,y:914,t:1527271806662};\\\", \\\"{x:1721,y:912,t:1527271806679};\\\", \\\"{x:1717,y:909,t:1527271806695};\\\", \\\"{x:1714,y:906,t:1527271806712};\\\", \\\"{x:1708,y:902,t:1527271806729};\\\", \\\"{x:1703,y:899,t:1527271806745};\\\", \\\"{x:1692,y:890,t:1527271806763};\\\", \\\"{x:1679,y:875,t:1527271806779};\\\", \\\"{x:1663,y:858,t:1527271806795};\\\", \\\"{x:1647,y:837,t:1527271806812};\\\", \\\"{x:1635,y:816,t:1527271806829};\\\", \\\"{x:1623,y:791,t:1527271806845};\\\", \\\"{x:1601,y:737,t:1527271806862};\\\", \\\"{x:1588,y:676,t:1527271806878};\\\", \\\"{x:1585,y:625,t:1527271806895};\\\", \\\"{x:1585,y:586,t:1527271806912};\\\", \\\"{x:1583,y:537,t:1527271806929};\\\", \\\"{x:1583,y:498,t:1527271806945};\\\", \\\"{x:1583,y:453,t:1527271806962};\\\", \\\"{x:1579,y:429,t:1527271806979};\\\", \\\"{x:1575,y:407,t:1527271806995};\\\", \\\"{x:1575,y:397,t:1527271807012};\\\", \\\"{x:1575,y:392,t:1527271807028};\\\", \\\"{x:1576,y:391,t:1527271807045};\\\", \\\"{x:1577,y:390,t:1527271807063};\\\", \\\"{x:1578,y:396,t:1527271807163};\\\", \\\"{x:1585,y:429,t:1527271807179};\\\", \\\"{x:1601,y:485,t:1527271807196};\\\", \\\"{x:1620,y:552,t:1527271807213};\\\", \\\"{x:1636,y:602,t:1527271807228};\\\", \\\"{x:1642,y:622,t:1527271807246};\\\", \\\"{x:1645,y:629,t:1527271807262};\\\", \\\"{x:1645,y:631,t:1527271807278};\\\", \\\"{x:1642,y:631,t:1527271807443};\\\", \\\"{x:1634,y:623,t:1527271807450};\\\", \\\"{x:1627,y:615,t:1527271807462};\\\", \\\"{x:1619,y:603,t:1527271807477};\\\", \\\"{x:1615,y:595,t:1527271807495};\\\", \\\"{x:1614,y:593,t:1527271807512};\\\", \\\"{x:1614,y:592,t:1527271807527};\\\", \\\"{x:1614,y:590,t:1527271807658};\\\", \\\"{x:1615,y:590,t:1527271807665};\\\", \\\"{x:1616,y:589,t:1527271807678};\\\", \\\"{x:1617,y:587,t:1527271807698};\\\", \\\"{x:1618,y:582,t:1527271807712};\\\", \\\"{x:1619,y:567,t:1527271807728};\\\", \\\"{x:1619,y:557,t:1527271807745};\\\", \\\"{x:1619,y:547,t:1527271807763};\\\", \\\"{x:1619,y:542,t:1527271807778};\\\", \\\"{x:1619,y:540,t:1527271807795};\\\", \\\"{x:1619,y:539,t:1527271807813};\\\", \\\"{x:1618,y:539,t:1527271807962};\\\", \\\"{x:1616,y:539,t:1527271807979};\\\", \\\"{x:1615,y:539,t:1527271807996};\\\", \\\"{x:1614,y:539,t:1527271808195};\\\", \\\"{x:1614,y:540,t:1527271808219};\\\", \\\"{x:1613,y:540,t:1527271808229};\\\", \\\"{x:1613,y:547,t:1527271809707};\\\", \\\"{x:1613,y:554,t:1527271809716};\\\", \\\"{x:1613,y:559,t:1527271809728};\\\", \\\"{x:1614,y:564,t:1527271809745};\\\", \\\"{x:1614,y:567,t:1527271809762};\\\", \\\"{x:1610,y:568,t:1527271809988};\\\", \\\"{x:1598,y:568,t:1527271809995};\\\", \\\"{x:1549,y:568,t:1527271810013};\\\", \\\"{x:1452,y:568,t:1527271810028};\\\", \\\"{x:1338,y:568,t:1527271810046};\\\", \\\"{x:1200,y:589,t:1527271810062};\\\", \\\"{x:1085,y:608,t:1527271810078};\\\", \\\"{x:983,y:620,t:1527271810095};\\\", \\\"{x:926,y:624,t:1527271810112};\\\", \\\"{x:891,y:624,t:1527271810128};\\\", \\\"{x:880,y:624,t:1527271810146};\\\", \\\"{x:874,y:624,t:1527271810162};\\\", \\\"{x:867,y:620,t:1527271810178};\\\", \\\"{x:863,y:616,t:1527271810195};\\\", \\\"{x:859,y:609,t:1527271810214};\\\", \\\"{x:853,y:596,t:1527271810229};\\\", \\\"{x:842,y:580,t:1527271810250};\\\", \\\"{x:796,y:553,t:1527271810265};\\\", \\\"{x:759,y:540,t:1527271810281};\\\", \\\"{x:728,y:535,t:1527271810299};\\\", \\\"{x:693,y:533,t:1527271810316};\\\", \\\"{x:657,y:533,t:1527271810332};\\\", \\\"{x:605,y:538,t:1527271810349};\\\", \\\"{x:552,y:553,t:1527271810365};\\\", \\\"{x:500,y:565,t:1527271810381};\\\", \\\"{x:444,y:573,t:1527271810399};\\\", \\\"{x:376,y:577,t:1527271810415};\\\", \\\"{x:309,y:577,t:1527271810431};\\\", \\\"{x:255,y:582,t:1527271810450};\\\", \\\"{x:188,y:599,t:1527271810466};\\\", \\\"{x:152,y:608,t:1527271810481};\\\", \\\"{x:60,y:640,t:1527271810500};\\\", \\\"{x:0,y:701,t:1527271810515};\\\", \\\"{x:0,y:723,t:1527271810531};\\\", \\\"{x:0,y:725,t:1527271810548};\\\", \\\"{x:0,y:726,t:1527271810577};\\\", \\\"{x:2,y:726,t:1527271810585};\\\", \\\"{x:4,y:725,t:1527271810599};\\\", \\\"{x:15,y:717,t:1527271810616};\\\", \\\"{x:31,y:708,t:1527271810631};\\\", \\\"{x:50,y:698,t:1527271810648};\\\", \\\"{x:91,y:676,t:1527271810665};\\\", \\\"{x:128,y:656,t:1527271810682};\\\", \\\"{x:179,y:631,t:1527271810700};\\\", \\\"{x:237,y:605,t:1527271810716};\\\", \\\"{x:279,y:584,t:1527271810733};\\\", \\\"{x:300,y:577,t:1527271810749};\\\", \\\"{x:307,y:575,t:1527271810766};\\\", \\\"{x:307,y:574,t:1527271810835};\\\", \\\"{x:294,y:580,t:1527271810884};\\\", \\\"{x:282,y:587,t:1527271810900};\\\", \\\"{x:272,y:594,t:1527271810917};\\\", \\\"{x:260,y:605,t:1527271810932};\\\", \\\"{x:247,y:610,t:1527271810948};\\\", \\\"{x:235,y:615,t:1527271810967};\\\", \\\"{x:227,y:618,t:1527271810982};\\\", \\\"{x:221,y:621,t:1527271810999};\\\", \\\"{x:216,y:625,t:1527271811016};\\\", \\\"{x:213,y:627,t:1527271811032};\\\", \\\"{x:211,y:627,t:1527271811057};\\\", \\\"{x:210,y:628,t:1527271811066};\\\", \\\"{x:209,y:628,t:1527271811082};\\\", \\\"{x:203,y:629,t:1527271811099};\\\", \\\"{x:199,y:629,t:1527271811116};\\\", \\\"{x:198,y:629,t:1527271811133};\\\", \\\"{x:196,y:629,t:1527271811149};\\\", \\\"{x:195,y:629,t:1527271811203};\\\", \\\"{x:193,y:629,t:1527271811216};\\\", \\\"{x:189,y:631,t:1527271811234};\\\", \\\"{x:178,y:636,t:1527271811249};\\\", \\\"{x:164,y:640,t:1527271811266};\\\", \\\"{x:150,y:640,t:1527271811283};\\\", \\\"{x:147,y:641,t:1527271811299};\\\", \\\"{x:157,y:646,t:1527271811747};\\\", \\\"{x:191,y:656,t:1527271811766};\\\", \\\"{x:230,y:661,t:1527271811783};\\\", \\\"{x:262,y:669,t:1527271811800};\\\", \\\"{x:312,y:683,t:1527271811816};\\\", \\\"{x:359,y:695,t:1527271811833};\\\", \\\"{x:438,y:719,t:1527271811849};\\\", \\\"{x:480,y:732,t:1527271811867};\\\", \\\"{x:498,y:735,t:1527271811882};\\\", \\\"{x:501,y:735,t:1527271811900};\\\", \\\"{x:502,y:736,t:1527271811916};\\\", \\\"{x:496,y:735,t:1527271811938};\\\", \\\"{x:478,y:727,t:1527271811949};\\\", \\\"{x:388,y:693,t:1527271811968};\\\", \\\"{x:287,y:661,t:1527271811983};\\\", \\\"{x:197,y:642,t:1527271812001};\\\", \\\"{x:136,y:634,t:1527271812016};\\\", \\\"{x:88,y:626,t:1527271812033};\\\", \\\"{x:67,y:626,t:1527271812050};\\\", \\\"{x:70,y:627,t:1527271812097};\\\", \\\"{x:72,y:628,t:1527271812106};\\\", \\\"{x:73,y:628,t:1527271812117};\\\", \\\"{x:74,y:629,t:1527271812133};\\\", \\\"{x:75,y:630,t:1527271812154};\\\", \\\"{x:80,y:631,t:1527271812167};\\\", \\\"{x:89,y:634,t:1527271812183};\\\", \\\"{x:107,y:639,t:1527271812200};\\\", \\\"{x:127,y:643,t:1527271812217};\\\", \\\"{x:144,y:646,t:1527271812233};\\\", \\\"{x:155,y:647,t:1527271812250};\\\", \\\"{x:156,y:647,t:1527271812419};\\\", \\\"{x:156,y:646,t:1527271812435};\\\", \\\"{x:156,y:643,t:1527271812450};\\\", \\\"{x:156,y:640,t:1527271812467};\\\", \\\"{x:156,y:639,t:1527271812484};\\\", \\\"{x:156,y:636,t:1527271812499};\\\", \\\"{x:157,y:635,t:1527271812517};\\\", \\\"{x:157,y:634,t:1527271812534};\\\", \\\"{x:158,y:633,t:1527271812826};\\\", \\\"{x:159,y:633,t:1527271812833};\\\", \\\"{x:175,y:637,t:1527271812850};\\\", \\\"{x:202,y:647,t:1527271812867};\\\", \\\"{x:227,y:657,t:1527271812884};\\\", \\\"{x:252,y:662,t:1527271812901};\\\", \\\"{x:264,y:663,t:1527271812917};\\\", \\\"{x:265,y:663,t:1527271812934};\\\", \\\"{x:266,y:664,t:1527271812970};\\\", \\\"{x:270,y:669,t:1527271812984};\\\", \\\"{x:301,y:680,t:1527271813001};\\\", \\\"{x:365,y:687,t:1527271813018};\\\", \\\"{x:469,y:703,t:1527271813035};\\\", \\\"{x:514,y:708,t:1527271813051};\\\", \\\"{x:540,y:712,t:1527271813067};\\\", \\\"{x:554,y:715,t:1527271813085};\\\", \\\"{x:559,y:716,t:1527271813102};\\\", \\\"{x:560,y:718,t:1527271813146};\\\", \\\"{x:563,y:720,t:1527271813154};\\\", \\\"{x:566,y:724,t:1527271813167};\\\", \\\"{x:577,y:730,t:1527271813184};\\\", \\\"{x:586,y:733,t:1527271813201};\\\", \\\"{x:590,y:734,t:1527271813218};\\\", \\\"{x:587,y:734,t:1527271813283};\\\", \\\"{x:583,y:734,t:1527271813290};\\\", \\\"{x:574,y:731,t:1527271813301};\\\", \\\"{x:558,y:727,t:1527271813319};\\\", \\\"{x:551,y:727,t:1527271813334};\\\", \\\"{x:549,y:726,t:1527271813351};\\\", \\\"{x:548,y:726,t:1527271813402};\\\", \\\"{x:547,y:726,t:1527271813418};\\\", \\\"{x:546,y:726,t:1527271813434};\\\" ] }, { \\\"rt\\\": 28773, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 260187, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -C -11 AM-09 AM-10 AM-11 AM-01 PM-12 PM-10 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:726,t:1527271818227};\\\", \\\"{x:582,y:736,t:1527271818243};\\\", \\\"{x:624,y:747,t:1527271818260};\\\", \\\"{x:669,y:761,t:1527271818277};\\\", \\\"{x:687,y:764,t:1527271818288};\\\", \\\"{x:726,y:774,t:1527271818305};\\\", \\\"{x:738,y:777,t:1527271818321};\\\", \\\"{x:759,y:784,t:1527271818338};\\\", \\\"{x:762,y:785,t:1527271818355};\\\", \\\"{x:771,y:785,t:1527271823390};\\\", \\\"{x:796,y:786,t:1527271823397};\\\", \\\"{x:883,y:801,t:1527271823413};\\\", \\\"{x:978,y:815,t:1527271823429};\\\", \\\"{x:1081,y:830,t:1527271823446};\\\", \\\"{x:1186,y:844,t:1527271823464};\\\", \\\"{x:1273,y:859,t:1527271823479};\\\", \\\"{x:1339,y:868,t:1527271823496};\\\", \\\"{x:1367,y:869,t:1527271823513};\\\", \\\"{x:1381,y:869,t:1527271823531};\\\", \\\"{x:1382,y:869,t:1527271823545};\\\", \\\"{x:1380,y:869,t:1527271823581};\\\", \\\"{x:1378,y:868,t:1527271823596};\\\", \\\"{x:1373,y:864,t:1527271823613};\\\", \\\"{x:1368,y:861,t:1527271823629};\\\", \\\"{x:1349,y:849,t:1527271823646};\\\", \\\"{x:1312,y:831,t:1527271823663};\\\", \\\"{x:1276,y:820,t:1527271823680};\\\", \\\"{x:1231,y:806,t:1527271823698};\\\", \\\"{x:1188,y:797,t:1527271823713};\\\", \\\"{x:1163,y:794,t:1527271823730};\\\", \\\"{x:1158,y:794,t:1527271823747};\\\", \\\"{x:1158,y:795,t:1527271823829};\\\", \\\"{x:1158,y:799,t:1527271823836};\\\", \\\"{x:1158,y:802,t:1527271823846};\\\", \\\"{x:1158,y:809,t:1527271823862};\\\", \\\"{x:1160,y:813,t:1527271823880};\\\", \\\"{x:1160,y:814,t:1527271823896};\\\", \\\"{x:1160,y:816,t:1527271823957};\\\", \\\"{x:1161,y:818,t:1527271823965};\\\", \\\"{x:1163,y:821,t:1527271823979};\\\", \\\"{x:1166,y:828,t:1527271823997};\\\", \\\"{x:1166,y:829,t:1527271824013};\\\", \\\"{x:1167,y:829,t:1527271824037};\\\", \\\"{x:1168,y:829,t:1527271824047};\\\", \\\"{x:1176,y:828,t:1527271824062};\\\", \\\"{x:1183,y:825,t:1527271824080};\\\", \\\"{x:1190,y:822,t:1527271824096};\\\", \\\"{x:1197,y:819,t:1527271824113};\\\", \\\"{x:1205,y:815,t:1527271824130};\\\", \\\"{x:1207,y:814,t:1527271824147};\\\", \\\"{x:1208,y:814,t:1527271824438};\\\", \\\"{x:1208,y:815,t:1527271824454};\\\", \\\"{x:1208,y:816,t:1527271824464};\\\", \\\"{x:1208,y:818,t:1527271824480};\\\", \\\"{x:1208,y:820,t:1527271824497};\\\", \\\"{x:1209,y:821,t:1527271824517};\\\", \\\"{x:1209,y:823,t:1527271825854};\\\", \\\"{x:1209,y:825,t:1527271825865};\\\", \\\"{x:1209,y:826,t:1527271825882};\\\", \\\"{x:1209,y:827,t:1527271825900};\\\", \\\"{x:1209,y:818,t:1527271826935};\\\", \\\"{x:1209,y:799,t:1527271826950};\\\", \\\"{x:1209,y:791,t:1527271826965};\\\", \\\"{x:1209,y:782,t:1527271826982};\\\", \\\"{x:1208,y:776,t:1527271826999};\\\", \\\"{x:1208,y:770,t:1527271827016};\\\", \\\"{x:1208,y:765,t:1527271827033};\\\", \\\"{x:1209,y:759,t:1527271827049};\\\", \\\"{x:1212,y:752,t:1527271827066};\\\", \\\"{x:1215,y:748,t:1527271827083};\\\", \\\"{x:1217,y:742,t:1527271827099};\\\", \\\"{x:1219,y:740,t:1527271827116};\\\", \\\"{x:1220,y:734,t:1527271827133};\\\", \\\"{x:1220,y:731,t:1527271827149};\\\", \\\"{x:1220,y:729,t:1527271827166};\\\", \\\"{x:1222,y:727,t:1527271827183};\\\", \\\"{x:1222,y:725,t:1527271827199};\\\", \\\"{x:1223,y:718,t:1527271827216};\\\", \\\"{x:1223,y:713,t:1527271827233};\\\", \\\"{x:1223,y:706,t:1527271827249};\\\", \\\"{x:1222,y:702,t:1527271827266};\\\", \\\"{x:1221,y:701,t:1527271827285};\\\", \\\"{x:1221,y:700,t:1527271827309};\\\", \\\"{x:1220,y:699,t:1527271827317};\\\", \\\"{x:1218,y:697,t:1527271827333};\\\", \\\"{x:1215,y:694,t:1527271827349};\\\", \\\"{x:1213,y:691,t:1527271827367};\\\", \\\"{x:1212,y:690,t:1527271827383};\\\", \\\"{x:1209,y:689,t:1527271827399};\\\", \\\"{x:1209,y:695,t:1527271827893};\\\", \\\"{x:1209,y:701,t:1527271827901};\\\", \\\"{x:1211,y:711,t:1527271827917};\\\", \\\"{x:1213,y:715,t:1527271827932};\\\", \\\"{x:1214,y:721,t:1527271827949};\\\", \\\"{x:1217,y:728,t:1527271827967};\\\", \\\"{x:1220,y:741,t:1527271827983};\\\", \\\"{x:1224,y:752,t:1527271828000};\\\", \\\"{x:1225,y:758,t:1527271828017};\\\", \\\"{x:1226,y:761,t:1527271828033};\\\", \\\"{x:1227,y:771,t:1527271828050};\\\", \\\"{x:1230,y:790,t:1527271828067};\\\", \\\"{x:1233,y:814,t:1527271828083};\\\", \\\"{x:1237,y:838,t:1527271828100};\\\", \\\"{x:1245,y:870,t:1527271828117};\\\", \\\"{x:1252,y:894,t:1527271828133};\\\", \\\"{x:1261,y:917,t:1527271828150};\\\", \\\"{x:1266,y:932,t:1527271828167};\\\", \\\"{x:1269,y:948,t:1527271828182};\\\", \\\"{x:1272,y:957,t:1527271828200};\\\", \\\"{x:1272,y:966,t:1527271828217};\\\", \\\"{x:1272,y:978,t:1527271828233};\\\", \\\"{x:1272,y:990,t:1527271828250};\\\", \\\"{x:1272,y:996,t:1527271828267};\\\", \\\"{x:1272,y:997,t:1527271828300};\\\", \\\"{x:1272,y:999,t:1527271828316};\\\", \\\"{x:1272,y:1001,t:1527271828334};\\\", \\\"{x:1272,y:1002,t:1527271828350};\\\", \\\"{x:1268,y:1002,t:1527271828366};\\\", \\\"{x:1252,y:1002,t:1527271828384};\\\", \\\"{x:1228,y:998,t:1527271828399};\\\", \\\"{x:1207,y:994,t:1527271828416};\\\", \\\"{x:1183,y:991,t:1527271828434};\\\", \\\"{x:1167,y:987,t:1527271828449};\\\", \\\"{x:1162,y:985,t:1527271828466};\\\", \\\"{x:1161,y:985,t:1527271828485};\\\", \\\"{x:1161,y:984,t:1527271828501};\\\", \\\"{x:1162,y:982,t:1527271828517};\\\", \\\"{x:1165,y:982,t:1527271828534};\\\", \\\"{x:1166,y:981,t:1527271828550};\\\", \\\"{x:1169,y:980,t:1527271828567};\\\", \\\"{x:1175,y:980,t:1527271828584};\\\", \\\"{x:1181,y:979,t:1527271828600};\\\", \\\"{x:1192,y:979,t:1527271828616};\\\", \\\"{x:1209,y:979,t:1527271828635};\\\", \\\"{x:1226,y:979,t:1527271828651};\\\", \\\"{x:1244,y:978,t:1527271828667};\\\", \\\"{x:1261,y:974,t:1527271828684};\\\", \\\"{x:1269,y:970,t:1527271828701};\\\", \\\"{x:1271,y:968,t:1527271828718};\\\", \\\"{x:1272,y:968,t:1527271828734};\\\", \\\"{x:1274,y:967,t:1527271829086};\\\", \\\"{x:1276,y:965,t:1527271829101};\\\", \\\"{x:1280,y:965,t:1527271829117};\\\", \\\"{x:1280,y:964,t:1527271829134};\\\", \\\"{x:1282,y:964,t:1527271829446};\\\", \\\"{x:1288,y:964,t:1527271829453};\\\", \\\"{x:1291,y:964,t:1527271829468};\\\", \\\"{x:1306,y:964,t:1527271829485};\\\", \\\"{x:1324,y:964,t:1527271829501};\\\", \\\"{x:1333,y:964,t:1527271829518};\\\", \\\"{x:1338,y:964,t:1527271829535};\\\", \\\"{x:1340,y:963,t:1527271829828};\\\", \\\"{x:1341,y:963,t:1527271829844};\\\", \\\"{x:1341,y:962,t:1527271829853};\\\", \\\"{x:1344,y:962,t:1527271830262};\\\", \\\"{x:1345,y:961,t:1527271830269};\\\", \\\"{x:1347,y:960,t:1527271830285};\\\", \\\"{x:1358,y:959,t:1527271830302};\\\", \\\"{x:1377,y:959,t:1527271830319};\\\", \\\"{x:1395,y:959,t:1527271830336};\\\", \\\"{x:1410,y:959,t:1527271830352};\\\", \\\"{x:1424,y:959,t:1527271830369};\\\", \\\"{x:1431,y:959,t:1527271830385};\\\", \\\"{x:1432,y:959,t:1527271830421};\\\", \\\"{x:1434,y:959,t:1527271830435};\\\", \\\"{x:1435,y:959,t:1527271830452};\\\", \\\"{x:1434,y:959,t:1527271830573};\\\", \\\"{x:1432,y:960,t:1527271830585};\\\", \\\"{x:1426,y:962,t:1527271830603};\\\", \\\"{x:1423,y:964,t:1527271830619};\\\", \\\"{x:1420,y:965,t:1527271830636};\\\", \\\"{x:1420,y:966,t:1527271830917};\\\", \\\"{x:1417,y:967,t:1527271830925};\\\", \\\"{x:1415,y:968,t:1527271830942};\\\", \\\"{x:1413,y:969,t:1527271830957};\\\", \\\"{x:1412,y:969,t:1527271830980};\\\", \\\"{x:1411,y:970,t:1527271830989};\\\", \\\"{x:1410,y:970,t:1527271831022};\\\", \\\"{x:1410,y:971,t:1527271831429};\\\", \\\"{x:1407,y:972,t:1527271831437};\\\", \\\"{x:1392,y:973,t:1527271831454};\\\", \\\"{x:1368,y:976,t:1527271831470};\\\", \\\"{x:1341,y:977,t:1527271831487};\\\", \\\"{x:1310,y:982,t:1527271831503};\\\", \\\"{x:1288,y:985,t:1527271831519};\\\", \\\"{x:1276,y:987,t:1527271831536};\\\", \\\"{x:1266,y:990,t:1527271831553};\\\", \\\"{x:1261,y:992,t:1527271831570};\\\", \\\"{x:1254,y:995,t:1527271831586};\\\", \\\"{x:1247,y:997,t:1527271831603};\\\", \\\"{x:1234,y:1001,t:1527271831620};\\\", \\\"{x:1223,y:1002,t:1527271831635};\\\", \\\"{x:1210,y:1002,t:1527271831653};\\\", \\\"{x:1207,y:1002,t:1527271831670};\\\", \\\"{x:1206,y:1002,t:1527271831685};\\\", \\\"{x:1206,y:1000,t:1527271831703};\\\", \\\"{x:1208,y:997,t:1527271831720};\\\", \\\"{x:1209,y:992,t:1527271831735};\\\", \\\"{x:1209,y:987,t:1527271831753};\\\", \\\"{x:1209,y:983,t:1527271831770};\\\", \\\"{x:1209,y:980,t:1527271831785};\\\", \\\"{x:1210,y:979,t:1527271831838};\\\", \\\"{x:1214,y:975,t:1527271831853};\\\", \\\"{x:1219,y:972,t:1527271831870};\\\", \\\"{x:1222,y:969,t:1527271831886};\\\", \\\"{x:1228,y:967,t:1527271831903};\\\", \\\"{x:1233,y:965,t:1527271831920};\\\", \\\"{x:1237,y:963,t:1527271831936};\\\", \\\"{x:1240,y:962,t:1527271831953};\\\", \\\"{x:1245,y:961,t:1527271831970};\\\", \\\"{x:1253,y:961,t:1527271831988};\\\", \\\"{x:1266,y:961,t:1527271832003};\\\", \\\"{x:1274,y:961,t:1527271832020};\\\", \\\"{x:1286,y:961,t:1527271832038};\\\", \\\"{x:1290,y:961,t:1527271832053};\\\", \\\"{x:1291,y:961,t:1527271832070};\\\", \\\"{x:1292,y:962,t:1527271832213};\\\", \\\"{x:1291,y:963,t:1527271832237};\\\", \\\"{x:1285,y:965,t:1527271832253};\\\", \\\"{x:1282,y:967,t:1527271832270};\\\", \\\"{x:1281,y:968,t:1527271832287};\\\", \\\"{x:1283,y:968,t:1527271832542};\\\", \\\"{x:1287,y:968,t:1527271832554};\\\", \\\"{x:1297,y:967,t:1527271832570};\\\", \\\"{x:1314,y:964,t:1527271832588};\\\", \\\"{x:1329,y:964,t:1527271832605};\\\", \\\"{x:1348,y:964,t:1527271832621};\\\", \\\"{x:1367,y:964,t:1527271832637};\\\", \\\"{x:1369,y:964,t:1527271832654};\\\", \\\"{x:1371,y:964,t:1527271832670};\\\", \\\"{x:1371,y:965,t:1527271832805};\\\", \\\"{x:1366,y:965,t:1527271832820};\\\", \\\"{x:1360,y:965,t:1527271832837};\\\", \\\"{x:1350,y:967,t:1527271832854};\\\", \\\"{x:1346,y:968,t:1527271832871};\\\", \\\"{x:1345,y:968,t:1527271832887};\\\", \\\"{x:1346,y:968,t:1527271833189};\\\", \\\"{x:1350,y:967,t:1527271833205};\\\", \\\"{x:1358,y:966,t:1527271833221};\\\", \\\"{x:1366,y:966,t:1527271833238};\\\", \\\"{x:1378,y:966,t:1527271833254};\\\", \\\"{x:1393,y:966,t:1527271833271};\\\", \\\"{x:1406,y:966,t:1527271833288};\\\", \\\"{x:1411,y:967,t:1527271833304};\\\", \\\"{x:1412,y:967,t:1527271833322};\\\", \\\"{x:1414,y:967,t:1527271833621};\\\", \\\"{x:1422,y:967,t:1527271833639};\\\", \\\"{x:1436,y:967,t:1527271833655};\\\", \\\"{x:1449,y:966,t:1527271833672};\\\", \\\"{x:1462,y:963,t:1527271833689};\\\", \\\"{x:1468,y:963,t:1527271833706};\\\", \\\"{x:1471,y:963,t:1527271833721};\\\", \\\"{x:1473,y:963,t:1527271833738};\\\", \\\"{x:1476,y:963,t:1527271834245};\\\", \\\"{x:1478,y:963,t:1527271834261};\\\", \\\"{x:1479,y:963,t:1527271834272};\\\", \\\"{x:1482,y:963,t:1527271834289};\\\", \\\"{x:1483,y:963,t:1527271834306};\\\", \\\"{x:1484,y:963,t:1527271834322};\\\", \\\"{x:1484,y:964,t:1527271834566};\\\", \\\"{x:1483,y:964,t:1527271834661};\\\", \\\"{x:1482,y:965,t:1527271835941};\\\", \\\"{x:1481,y:965,t:1527271835956};\\\", \\\"{x:1480,y:965,t:1527271835973};\\\", \\\"{x:1477,y:965,t:1527271836213};\\\", \\\"{x:1474,y:965,t:1527271836223};\\\", \\\"{x:1460,y:960,t:1527271836241};\\\", \\\"{x:1416,y:942,t:1527271836258};\\\", \\\"{x:1323,y:905,t:1527271836273};\\\", \\\"{x:1186,y:855,t:1527271836290};\\\", \\\"{x:1039,y:809,t:1527271836308};\\\", \\\"{x:896,y:772,t:1527271836324};\\\", \\\"{x:763,y:729,t:1527271836341};\\\", \\\"{x:577,y:676,t:1527271836357};\\\", \\\"{x:458,y:638,t:1527271836375};\\\", \\\"{x:366,y:611,t:1527271836392};\\\", \\\"{x:317,y:598,t:1527271836406};\\\", \\\"{x:298,y:593,t:1527271836421};\\\", \\\"{x:295,y:592,t:1527271836439};\\\", \\\"{x:294,y:592,t:1527271836596};\\\", \\\"{x:291,y:596,t:1527271836606};\\\", \\\"{x:279,y:608,t:1527271836623};\\\", \\\"{x:262,y:619,t:1527271836639};\\\", \\\"{x:231,y:630,t:1527271836657};\\\", \\\"{x:202,y:639,t:1527271836673};\\\", \\\"{x:177,y:649,t:1527271836689};\\\", \\\"{x:162,y:654,t:1527271836707};\\\", \\\"{x:158,y:656,t:1527271836723};\\\", \\\"{x:157,y:655,t:1527271836764};\\\", \\\"{x:157,y:649,t:1527271836773};\\\", \\\"{x:155,y:636,t:1527271836790};\\\", \\\"{x:148,y:623,t:1527271836806};\\\", \\\"{x:144,y:616,t:1527271836824};\\\", \\\"{x:144,y:615,t:1527271836840};\\\", \\\"{x:144,y:614,t:1527271836856};\\\", \\\"{x:145,y:612,t:1527271836873};\\\", \\\"{x:149,y:609,t:1527271836889};\\\", \\\"{x:152,y:606,t:1527271836906};\\\", \\\"{x:152,y:600,t:1527271836922};\\\", \\\"{x:152,y:586,t:1527271836940};\\\", \\\"{x:152,y:584,t:1527271836956};\\\", \\\"{x:151,y:579,t:1527271836973};\\\", \\\"{x:151,y:578,t:1527271836996};\\\", \\\"{x:151,y:577,t:1527271837012};\\\", \\\"{x:152,y:576,t:1527271837023};\\\", \\\"{x:155,y:575,t:1527271837040};\\\", \\\"{x:156,y:574,t:1527271837057};\\\", \\\"{x:157,y:574,t:1527271837073};\\\", \\\"{x:158,y:574,t:1527271837090};\\\", \\\"{x:159,y:573,t:1527271837106};\\\", \\\"{x:161,y:572,t:1527271837123};\\\", \\\"{x:163,y:572,t:1527271837205};\\\", \\\"{x:165,y:577,t:1527271837214};\\\", \\\"{x:166,y:577,t:1527271837222};\\\", \\\"{x:169,y:580,t:1527271837240};\\\", \\\"{x:175,y:582,t:1527271837258};\\\", \\\"{x:188,y:586,t:1527271837273};\\\", \\\"{x:226,y:593,t:1527271837290};\\\", \\\"{x:299,y:606,t:1527271837308};\\\", \\\"{x:380,y:607,t:1527271837323};\\\", \\\"{x:509,y:601,t:1527271837341};\\\", \\\"{x:584,y:583,t:1527271837357};\\\", \\\"{x:629,y:570,t:1527271837373};\\\", \\\"{x:668,y:558,t:1527271837390};\\\", \\\"{x:690,y:555,t:1527271837407};\\\", \\\"{x:699,y:551,t:1527271837424};\\\", \\\"{x:699,y:549,t:1527271837492};\\\", \\\"{x:696,y:548,t:1527271837507};\\\", \\\"{x:677,y:547,t:1527271837524};\\\", \\\"{x:671,y:547,t:1527271837541};\\\", \\\"{x:668,y:548,t:1527271837557};\\\", \\\"{x:665,y:549,t:1527271837574};\\\", \\\"{x:660,y:552,t:1527271837591};\\\", \\\"{x:656,y:557,t:1527271837607};\\\", \\\"{x:651,y:564,t:1527271837624};\\\", \\\"{x:647,y:574,t:1527271837641};\\\", \\\"{x:643,y:583,t:1527271837660};\\\", \\\"{x:643,y:591,t:1527271837674};\\\", \\\"{x:642,y:600,t:1527271837689};\\\", \\\"{x:642,y:610,t:1527271837707};\\\", \\\"{x:642,y:624,t:1527271837723};\\\", \\\"{x:645,y:650,t:1527271837740};\\\", \\\"{x:645,y:657,t:1527271837757};\\\", \\\"{x:643,y:663,t:1527271837774};\\\", \\\"{x:640,y:669,t:1527271837790};\\\", \\\"{x:638,y:671,t:1527271837807};\\\", \\\"{x:637,y:672,t:1527271837824};\\\", \\\"{x:636,y:673,t:1527271837840};\\\", \\\"{x:630,y:673,t:1527271837857};\\\", \\\"{x:613,y:670,t:1527271837874};\\\", \\\"{x:595,y:658,t:1527271837891};\\\", \\\"{x:586,y:648,t:1527271837908};\\\", \\\"{x:582,y:638,t:1527271837924};\\\", \\\"{x:582,y:629,t:1527271837940};\\\", \\\"{x:587,y:616,t:1527271837958};\\\", \\\"{x:589,y:611,t:1527271837974};\\\", \\\"{x:590,y:605,t:1527271837990};\\\", \\\"{x:592,y:601,t:1527271838007};\\\", \\\"{x:592,y:600,t:1527271838037};\\\", \\\"{x:593,y:600,t:1527271838109};\\\", \\\"{x:594,y:600,t:1527271838125};\\\", \\\"{x:594,y:599,t:1527271838205};\\\", \\\"{x:595,y:599,t:1527271838213};\\\", \\\"{x:597,y:598,t:1527271838229};\\\", \\\"{x:598,y:597,t:1527271838285};\\\", \\\"{x:599,y:597,t:1527271838670};\\\", \\\"{x:606,y:597,t:1527271838676};\\\", \\\"{x:631,y:607,t:1527271838691};\\\", \\\"{x:732,y:641,t:1527271838707};\\\", \\\"{x:962,y:692,t:1527271838725};\\\", \\\"{x:1157,y:737,t:1527271838742};\\\", \\\"{x:1346,y:769,t:1527271838758};\\\", \\\"{x:1501,y:791,t:1527271838774};\\\", \\\"{x:1592,y:803,t:1527271838791};\\\", \\\"{x:1610,y:805,t:1527271838808};\\\", \\\"{x:1612,y:806,t:1527271838824};\\\", \\\"{x:1607,y:807,t:1527271838842};\\\", \\\"{x:1597,y:807,t:1527271838859};\\\", \\\"{x:1595,y:807,t:1527271838875};\\\", \\\"{x:1595,y:806,t:1527271838892};\\\", \\\"{x:1601,y:803,t:1527271838908};\\\", \\\"{x:1601,y:801,t:1527271838941};\\\", \\\"{x:1589,y:794,t:1527271838958};\\\", \\\"{x:1565,y:787,t:1527271838975};\\\", \\\"{x:1544,y:782,t:1527271838991};\\\", \\\"{x:1523,y:782,t:1527271839008};\\\", \\\"{x:1502,y:782,t:1527271839025};\\\", \\\"{x:1483,y:778,t:1527271839041};\\\", \\\"{x:1470,y:767,t:1527271839058};\\\", \\\"{x:1458,y:739,t:1527271839075};\\\", \\\"{x:1456,y:709,t:1527271839091};\\\", \\\"{x:1467,y:619,t:1527271839108};\\\", \\\"{x:1476,y:531,t:1527271839124};\\\", \\\"{x:1486,y:432,t:1527271839141};\\\", \\\"{x:1492,y:331,t:1527271839158};\\\", \\\"{x:1514,y:268,t:1527271839175};\\\", \\\"{x:1539,y:225,t:1527271839191};\\\", \\\"{x:1549,y:202,t:1527271839208};\\\", \\\"{x:1551,y:189,t:1527271839225};\\\", \\\"{x:1551,y:181,t:1527271839241};\\\", \\\"{x:1551,y:175,t:1527271839259};\\\", \\\"{x:1547,y:170,t:1527271839275};\\\", \\\"{x:1541,y:161,t:1527271839291};\\\", \\\"{x:1531,y:153,t:1527271839309};\\\", \\\"{x:1530,y:150,t:1527271839324};\\\", \\\"{x:1529,y:149,t:1527271839342};\\\", \\\"{x:1528,y:148,t:1527271839358};\\\", \\\"{x:1526,y:147,t:1527271839405};\\\", \\\"{x:1523,y:146,t:1527271839413};\\\", \\\"{x:1521,y:145,t:1527271839425};\\\", \\\"{x:1518,y:144,t:1527271839441};\\\", \\\"{x:1517,y:144,t:1527271839477};\\\", \\\"{x:1515,y:144,t:1527271839501};\\\", \\\"{x:1514,y:144,t:1527271839509};\\\", \\\"{x:1510,y:144,t:1527271839629};\\\", \\\"{x:1509,y:145,t:1527271839642};\\\", \\\"{x:1505,y:147,t:1527271839658};\\\", \\\"{x:1501,y:151,t:1527271839676};\\\", \\\"{x:1501,y:152,t:1527271839692};\\\", \\\"{x:1500,y:153,t:1527271839709};\\\", \\\"{x:1498,y:154,t:1527271839725};\\\", \\\"{x:1495,y:155,t:1527271839742};\\\", \\\"{x:1492,y:157,t:1527271839759};\\\", \\\"{x:1488,y:164,t:1527271839775};\\\", \\\"{x:1487,y:168,t:1527271839792};\\\", \\\"{x:1487,y:169,t:1527271839808};\\\", \\\"{x:1487,y:170,t:1527271839825};\\\", \\\"{x:1486,y:171,t:1527271839843};\\\", \\\"{x:1481,y:175,t:1527271839859};\\\", \\\"{x:1466,y:188,t:1527271839875};\\\", \\\"{x:1403,y:230,t:1527271839893};\\\", \\\"{x:1319,y:290,t:1527271839909};\\\", \\\"{x:1187,y:372,t:1527271839926};\\\", \\\"{x:1036,y:471,t:1527271839943};\\\", \\\"{x:870,y:551,t:1527271839959};\\\", \\\"{x:690,y:634,t:1527271839976};\\\", \\\"{x:493,y:739,t:1527271839993};\\\", \\\"{x:397,y:799,t:1527271840009};\\\", \\\"{x:356,y:815,t:1527271840025};\\\", \\\"{x:352,y:812,t:1527271840042};\\\", \\\"{x:347,y:807,t:1527271840059};\\\", \\\"{x:322,y:785,t:1527271840076};\\\", \\\"{x:319,y:781,t:1527271840091};\\\", \\\"{x:321,y:774,t:1527271840109};\\\", \\\"{x:329,y:764,t:1527271840126};\\\", \\\"{x:340,y:753,t:1527271840142};\\\", \\\"{x:353,y:740,t:1527271840159};\\\", \\\"{x:365,y:729,t:1527271840176};\\\", \\\"{x:382,y:715,t:1527271840192};\\\", \\\"{x:397,y:701,t:1527271840210};\\\", \\\"{x:403,y:691,t:1527271840226};\\\", \\\"{x:403,y:684,t:1527271840242};\\\", \\\"{x:402,y:678,t:1527271840259};\\\", \\\"{x:386,y:672,t:1527271840276};\\\", \\\"{x:343,y:659,t:1527271840293};\\\", \\\"{x:246,y:644,t:1527271840309};\\\", \\\"{x:197,y:641,t:1527271840326};\\\", \\\"{x:161,y:630,t:1527271840342};\\\", \\\"{x:131,y:621,t:1527271840359};\\\", \\\"{x:100,y:608,t:1527271840376};\\\", \\\"{x:68,y:596,t:1527271840391};\\\", \\\"{x:60,y:596,t:1527271840409};\\\", \\\"{x:59,y:595,t:1527271840484};\\\", \\\"{x:60,y:593,t:1527271840508};\\\", \\\"{x:63,y:593,t:1527271840516};\\\", \\\"{x:66,y:593,t:1527271840526};\\\", \\\"{x:71,y:593,t:1527271840542};\\\", \\\"{x:76,y:593,t:1527271840559};\\\", \\\"{x:79,y:594,t:1527271840576};\\\", \\\"{x:83,y:596,t:1527271840592};\\\", \\\"{x:90,y:596,t:1527271840610};\\\", \\\"{x:95,y:596,t:1527271840626};\\\", \\\"{x:98,y:598,t:1527271840642};\\\", \\\"{x:99,y:598,t:1527271840701};\\\", \\\"{x:101,y:598,t:1527271840709};\\\", \\\"{x:104,y:598,t:1527271840741};\\\", \\\"{x:105,y:598,t:1527271840749};\\\", \\\"{x:108,y:598,t:1527271840759};\\\", \\\"{x:116,y:599,t:1527271840777};\\\", \\\"{x:122,y:600,t:1527271840793};\\\", \\\"{x:123,y:600,t:1527271840809};\\\", \\\"{x:124,y:600,t:1527271840826};\\\", \\\"{x:126,y:600,t:1527271840843};\\\", \\\"{x:129,y:600,t:1527271840859};\\\", \\\"{x:136,y:600,t:1527271840877};\\\", \\\"{x:138,y:600,t:1527271840893};\\\", \\\"{x:138,y:599,t:1527271840909};\\\", \\\"{x:139,y:599,t:1527271840926};\\\", \\\"{x:140,y:599,t:1527271840942};\\\", \\\"{x:143,y:598,t:1527271841349};\\\", \\\"{x:144,y:598,t:1527271841360};\\\", \\\"{x:144,y:597,t:1527271841377};\\\", \\\"{x:146,y:597,t:1527271841392};\\\", \\\"{x:148,y:596,t:1527271841437};\\\", \\\"{x:150,y:595,t:1527271841446};\\\", \\\"{x:151,y:595,t:1527271841458};\\\", \\\"{x:153,y:594,t:1527271841475};\\\", \\\"{x:153,y:595,t:1527271841828};\\\", \\\"{x:158,y:604,t:1527271841843};\\\", \\\"{x:219,y:639,t:1527271841861};\\\", \\\"{x:253,y:657,t:1527271841878};\\\", \\\"{x:278,y:666,t:1527271841893};\\\", \\\"{x:285,y:668,t:1527271841910};\\\", \\\"{x:288,y:669,t:1527271841940};\\\", \\\"{x:294,y:672,t:1527271841948};\\\", \\\"{x:307,y:679,t:1527271841960};\\\", \\\"{x:347,y:692,t:1527271841977};\\\", \\\"{x:400,y:708,t:1527271841993};\\\", \\\"{x:477,y:724,t:1527271842011};\\\", \\\"{x:552,y:735,t:1527271842027};\\\", \\\"{x:601,y:741,t:1527271842045};\\\", \\\"{x:602,y:741,t:1527271842060};\\\", \\\"{x:598,y:741,t:1527271842084};\\\", \\\"{x:590,y:739,t:1527271842094};\\\", \\\"{x:587,y:738,t:1527271842110};\\\", \\\"{x:586,y:737,t:1527271842173};\\\", \\\"{x:582,y:736,t:1527271842189};\\\", \\\"{x:578,y:736,t:1527271842197};\\\", \\\"{x:572,y:735,t:1527271842210};\\\", \\\"{x:558,y:731,t:1527271842228};\\\", \\\"{x:543,y:730,t:1527271842244};\\\", \\\"{x:542,y:728,t:1527271842365};\\\", \\\"{x:542,y:725,t:1527271842378};\\\", \\\"{x:542,y:718,t:1527271842394};\\\", \\\"{x:546,y:701,t:1527271842412};\\\", \\\"{x:558,y:671,t:1527271842429};\\\", \\\"{x:563,y:654,t:1527271842444};\\\", \\\"{x:568,y:643,t:1527271842461};\\\", \\\"{x:571,y:636,t:1527271842476};\\\", \\\"{x:575,y:629,t:1527271842494};\\\", \\\"{x:577,y:624,t:1527271842511};\\\", \\\"{x:579,y:621,t:1527271842527};\\\", \\\"{x:580,y:617,t:1527271842545};\\\", \\\"{x:583,y:613,t:1527271842561};\\\", \\\"{x:583,y:609,t:1527271842578};\\\", \\\"{x:587,y:604,t:1527271842594};\\\", \\\"{x:588,y:602,t:1527271842611};\\\", \\\"{x:588,y:601,t:1527271842627};\\\", \\\"{x:590,y:600,t:1527271842644};\\\", \\\"{x:591,y:600,t:1527271842693};\\\", \\\"{x:594,y:599,t:1527271842700};\\\", \\\"{x:595,y:598,t:1527271842711};\\\", \\\"{x:599,y:598,t:1527271842728};\\\", \\\"{x:601,y:596,t:1527271842746};\\\", \\\"{x:603,y:595,t:1527271842761};\\\", \\\"{x:604,y:595,t:1527271842805};\\\", \\\"{x:605,y:594,t:1527271842821};\\\", \\\"{x:606,y:594,t:1527271842845};\\\", \\\"{x:603,y:596,t:1527271843205};\\\", \\\"{x:602,y:599,t:1527271843213};\\\", \\\"{x:599,y:607,t:1527271843228};\\\", \\\"{x:595,y:616,t:1527271843246};\\\", \\\"{x:588,y:627,t:1527271843262};\\\", \\\"{x:575,y:640,t:1527271843278};\\\", \\\"{x:562,y:655,t:1527271843295};\\\", \\\"{x:554,y:670,t:1527271843312};\\\", \\\"{x:546,y:682,t:1527271843328};\\\", \\\"{x:538,y:691,t:1527271843345};\\\", \\\"{x:532,y:696,t:1527271843361};\\\", \\\"{x:528,y:700,t:1527271843378};\\\", \\\"{x:525,y:704,t:1527271843396};\\\", \\\"{x:521,y:707,t:1527271843412};\\\", \\\"{x:518,y:707,t:1527271843428};\\\", \\\"{x:513,y:710,t:1527271843445};\\\", \\\"{x:511,y:711,t:1527271843468};\\\" ] }, { \\\"rt\\\": 50719, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 312143, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -03 PM-05 PM-04 PM-10 AM-11 AM-11 AM-C -05 PM-07 PM-04 PM-O -O -O -O -I -Z -Z -Z -Z -Z -U -U -U -H -J -U -K -03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:711,t:1527271845476};\\\", \\\"{x:508,y:711,t:1527271845484};\\\", \\\"{x:505,y:713,t:1527271845497};\\\", \\\"{x:501,y:714,t:1527271845513};\\\", \\\"{x:496,y:715,t:1527271845530};\\\", \\\"{x:494,y:715,t:1527271845548};\\\", \\\"{x:493,y:715,t:1527271845564};\\\", \\\"{x:491,y:715,t:1527271845580};\\\", \\\"{x:496,y:715,t:1527271845693};\\\", \\\"{x:510,y:715,t:1527271845700};\\\", \\\"{x:533,y:715,t:1527271845714};\\\", \\\"{x:644,y:715,t:1527271845732};\\\", \\\"{x:840,y:715,t:1527271845748};\\\", \\\"{x:1066,y:715,t:1527271845763};\\\", \\\"{x:1425,y:715,t:1527271845780};\\\", \\\"{x:1630,y:715,t:1527271845797};\\\", \\\"{x:1773,y:715,t:1527271845813};\\\", \\\"{x:1841,y:718,t:1527271845830};\\\", \\\"{x:1857,y:720,t:1527271845847};\\\", \\\"{x:1857,y:721,t:1527271845868};\\\", \\\"{x:1849,y:721,t:1527271845880};\\\", \\\"{x:1820,y:721,t:1527271845898};\\\", \\\"{x:1790,y:721,t:1527271845913};\\\", \\\"{x:1767,y:723,t:1527271845930};\\\", \\\"{x:1749,y:724,t:1527271845948};\\\", \\\"{x:1728,y:728,t:1527271845963};\\\", \\\"{x:1704,y:735,t:1527271845981};\\\", \\\"{x:1689,y:741,t:1527271845997};\\\", \\\"{x:1671,y:747,t:1527271846014};\\\", \\\"{x:1648,y:752,t:1527271846031};\\\", \\\"{x:1623,y:759,t:1527271846048};\\\", \\\"{x:1600,y:767,t:1527271846063};\\\", \\\"{x:1574,y:776,t:1527271846080};\\\", \\\"{x:1552,y:786,t:1527271846098};\\\", \\\"{x:1535,y:796,t:1527271846114};\\\", \\\"{x:1519,y:804,t:1527271846130};\\\", \\\"{x:1507,y:812,t:1527271846147};\\\", \\\"{x:1500,y:818,t:1527271846163};\\\", \\\"{x:1490,y:828,t:1527271846181};\\\", \\\"{x:1487,y:833,t:1527271846197};\\\", \\\"{x:1481,y:844,t:1527271846214};\\\", \\\"{x:1477,y:853,t:1527271846230};\\\", \\\"{x:1471,y:865,t:1527271846248};\\\", \\\"{x:1465,y:879,t:1527271846265};\\\", \\\"{x:1451,y:894,t:1527271846282};\\\", \\\"{x:1442,y:904,t:1527271846297};\\\", \\\"{x:1440,y:905,t:1527271846314};\\\", \\\"{x:1438,y:908,t:1527271846749};\\\", \\\"{x:1436,y:912,t:1527271846765};\\\", \\\"{x:1436,y:916,t:1527271846782};\\\", \\\"{x:1438,y:921,t:1527271846798};\\\", \\\"{x:1452,y:931,t:1527271846815};\\\", \\\"{x:1467,y:941,t:1527271846831};\\\", \\\"{x:1480,y:951,t:1527271846847};\\\", \\\"{x:1497,y:962,t:1527271846864};\\\", \\\"{x:1515,y:971,t:1527271846881};\\\", \\\"{x:1541,y:980,t:1527271846898};\\\", \\\"{x:1569,y:989,t:1527271846915};\\\", \\\"{x:1596,y:994,t:1527271846932};\\\", \\\"{x:1624,y:1002,t:1527271846948};\\\", \\\"{x:1644,y:1005,t:1527271846964};\\\", \\\"{x:1646,y:1006,t:1527271846982};\\\", \\\"{x:1648,y:1006,t:1527271847012};\\\", \\\"{x:1649,y:1006,t:1527271847020};\\\", \\\"{x:1650,y:1005,t:1527271847031};\\\", \\\"{x:1654,y:1004,t:1527271847047};\\\", \\\"{x:1659,y:999,t:1527271847065};\\\", \\\"{x:1661,y:994,t:1527271847081};\\\", \\\"{x:1663,y:988,t:1527271847097};\\\", \\\"{x:1663,y:982,t:1527271847115};\\\", \\\"{x:1663,y:975,t:1527271847131};\\\", \\\"{x:1657,y:965,t:1527271847149};\\\", \\\"{x:1651,y:960,t:1527271847165};\\\", \\\"{x:1647,y:957,t:1527271847182};\\\", \\\"{x:1646,y:957,t:1527271847199};\\\", \\\"{x:1645,y:957,t:1527271847277};\\\", \\\"{x:1642,y:957,t:1527271847285};\\\", \\\"{x:1641,y:958,t:1527271847299};\\\", \\\"{x:1640,y:958,t:1527271847315};\\\", \\\"{x:1639,y:958,t:1527271847332};\\\", \\\"{x:1637,y:962,t:1527271847349};\\\", \\\"{x:1634,y:966,t:1527271847365};\\\", \\\"{x:1634,y:967,t:1527271847383};\\\", \\\"{x:1633,y:967,t:1527271847399};\\\", \\\"{x:1632,y:968,t:1527271847415};\\\", \\\"{x:1631,y:968,t:1527271847432};\\\", \\\"{x:1631,y:969,t:1527271847449};\\\", \\\"{x:1629,y:969,t:1527271847465};\\\", \\\"{x:1628,y:969,t:1527271847509};\\\", \\\"{x:1626,y:971,t:1527271847525};\\\", \\\"{x:1625,y:971,t:1527271847565};\\\", \\\"{x:1624,y:972,t:1527271847629};\\\", \\\"{x:1622,y:972,t:1527271847636};\\\", \\\"{x:1621,y:972,t:1527271847649};\\\", \\\"{x:1615,y:972,t:1527271847666};\\\", \\\"{x:1608,y:971,t:1527271847681};\\\", \\\"{x:1602,y:970,t:1527271847699};\\\", \\\"{x:1599,y:969,t:1527271847716};\\\", \\\"{x:1598,y:969,t:1527271847805};\\\", \\\"{x:1598,y:968,t:1527271847957};\\\", \\\"{x:1599,y:967,t:1527271847982};\\\", \\\"{x:1600,y:967,t:1527271848037};\\\", \\\"{x:1600,y:966,t:1527271848053};\\\", \\\"{x:1601,y:965,t:1527271848066};\\\", \\\"{x:1602,y:964,t:1527271848083};\\\", \\\"{x:1603,y:964,t:1527271848099};\\\", \\\"{x:1605,y:964,t:1527271848213};\\\", \\\"{x:1606,y:963,t:1527271848229};\\\", \\\"{x:1608,y:963,t:1527271848237};\\\", \\\"{x:1609,y:961,t:1527271848249};\\\", \\\"{x:1610,y:961,t:1527271848284};\\\", \\\"{x:1611,y:961,t:1527271848316};\\\", \\\"{x:1612,y:960,t:1527271848333};\\\", \\\"{x:1605,y:960,t:1527271857989};\\\", \\\"{x:1563,y:959,t:1527271858008};\\\", \\\"{x:1489,y:950,t:1527271858024};\\\", \\\"{x:1397,y:937,t:1527271858040};\\\", \\\"{x:1312,y:931,t:1527271858058};\\\", \\\"{x:1229,y:922,t:1527271858073};\\\", \\\"{x:1179,y:915,t:1527271858090};\\\", \\\"{x:1148,y:911,t:1527271858108};\\\", \\\"{x:1139,y:910,t:1527271858123};\\\", \\\"{x:1138,y:910,t:1527271858140};\\\", \\\"{x:1137,y:910,t:1527271858181};\\\", \\\"{x:1136,y:910,t:1527271858191};\\\", \\\"{x:1135,y:910,t:1527271858208};\\\", \\\"{x:1134,y:910,t:1527271858225};\\\", \\\"{x:1132,y:913,t:1527271858240};\\\", \\\"{x:1132,y:917,t:1527271858257};\\\", \\\"{x:1133,y:924,t:1527271858275};\\\", \\\"{x:1140,y:932,t:1527271858290};\\\", \\\"{x:1154,y:941,t:1527271858308};\\\", \\\"{x:1193,y:959,t:1527271858324};\\\", \\\"{x:1233,y:972,t:1527271858341};\\\", \\\"{x:1262,y:981,t:1527271858357};\\\", \\\"{x:1278,y:987,t:1527271858375};\\\", \\\"{x:1283,y:989,t:1527271858391};\\\", \\\"{x:1282,y:990,t:1527271858445};\\\", \\\"{x:1279,y:989,t:1527271858458};\\\", \\\"{x:1274,y:988,t:1527271858474};\\\", \\\"{x:1268,y:985,t:1527271858490};\\\", \\\"{x:1262,y:981,t:1527271858508};\\\", \\\"{x:1249,y:977,t:1527271858525};\\\", \\\"{x:1237,y:971,t:1527271858541};\\\", \\\"{x:1224,y:966,t:1527271858558};\\\", \\\"{x:1213,y:960,t:1527271858574};\\\", \\\"{x:1201,y:954,t:1527271858591};\\\", \\\"{x:1196,y:949,t:1527271858608};\\\", \\\"{x:1195,y:948,t:1527271858624};\\\", \\\"{x:1194,y:945,t:1527271858641};\\\", \\\"{x:1194,y:941,t:1527271858657};\\\", \\\"{x:1196,y:936,t:1527271858675};\\\", \\\"{x:1198,y:926,t:1527271858691};\\\", \\\"{x:1199,y:920,t:1527271858708};\\\", \\\"{x:1201,y:907,t:1527271858724};\\\", \\\"{x:1203,y:899,t:1527271858741};\\\", \\\"{x:1204,y:894,t:1527271858758};\\\", \\\"{x:1205,y:889,t:1527271858774};\\\", \\\"{x:1207,y:885,t:1527271858792};\\\", \\\"{x:1207,y:880,t:1527271858808};\\\", \\\"{x:1208,y:878,t:1527271858825};\\\", \\\"{x:1210,y:875,t:1527271858842};\\\", \\\"{x:1211,y:873,t:1527271858857};\\\", \\\"{x:1212,y:872,t:1527271858874};\\\", \\\"{x:1214,y:868,t:1527271858892};\\\", \\\"{x:1215,y:863,t:1527271858907};\\\", \\\"{x:1218,y:854,t:1527271858925};\\\", \\\"{x:1219,y:850,t:1527271858941};\\\", \\\"{x:1219,y:846,t:1527271858957};\\\", \\\"{x:1220,y:843,t:1527271858974};\\\", \\\"{x:1220,y:841,t:1527271858992};\\\", \\\"{x:1220,y:840,t:1527271859007};\\\", \\\"{x:1220,y:839,t:1527271859024};\\\", \\\"{x:1220,y:838,t:1527271859041};\\\", \\\"{x:1220,y:837,t:1527271859057};\\\", \\\"{x:1220,y:836,t:1527271859075};\\\", \\\"{x:1218,y:835,t:1527271859091};\\\", \\\"{x:1218,y:834,t:1527271859111};\\\", \\\"{x:1218,y:835,t:1527271859486};\\\", \\\"{x:1232,y:847,t:1527271859493};\\\", \\\"{x:1290,y:882,t:1527271859509};\\\", \\\"{x:1380,y:917,t:1527271859524};\\\", \\\"{x:1474,y:941,t:1527271859542};\\\", \\\"{x:1572,y:960,t:1527271859558};\\\", \\\"{x:1681,y:978,t:1527271859575};\\\", \\\"{x:1779,y:996,t:1527271859591};\\\", \\\"{x:1845,y:1004,t:1527271859608};\\\", \\\"{x:1888,y:1010,t:1527271859625};\\\", \\\"{x:1903,y:1010,t:1527271859641};\\\", \\\"{x:1904,y:1010,t:1527271859693};\\\", \\\"{x:1899,y:1005,t:1527271859709};\\\", \\\"{x:1880,y:997,t:1527271859725};\\\", \\\"{x:1859,y:989,t:1527271859741};\\\", \\\"{x:1839,y:981,t:1527271859758};\\\", \\\"{x:1812,y:973,t:1527271859775};\\\", \\\"{x:1773,y:963,t:1527271859792};\\\", \\\"{x:1744,y:958,t:1527271859808};\\\", \\\"{x:1721,y:953,t:1527271859825};\\\", \\\"{x:1704,y:952,t:1527271859842};\\\", \\\"{x:1690,y:950,t:1527271859858};\\\", \\\"{x:1682,y:950,t:1527271859875};\\\", \\\"{x:1677,y:950,t:1527271859892};\\\", \\\"{x:1675,y:950,t:1527271860021};\\\", \\\"{x:1674,y:950,t:1527271860044};\\\", \\\"{x:1672,y:951,t:1527271860061};\\\", \\\"{x:1671,y:952,t:1527271860075};\\\", \\\"{x:1670,y:956,t:1527271860092};\\\", \\\"{x:1670,y:957,t:1527271860109};\\\", \\\"{x:1668,y:958,t:1527271860125};\\\", \\\"{x:1668,y:959,t:1527271860142};\\\", \\\"{x:1668,y:960,t:1527271860159};\\\", \\\"{x:1668,y:961,t:1527271860181};\\\", \\\"{x:1668,y:962,t:1527271860213};\\\", \\\"{x:1668,y:963,t:1527271860383};\\\", \\\"{x:1665,y:963,t:1527271860404};\\\", \\\"{x:1664,y:963,t:1527271860413};\\\", \\\"{x:1662,y:964,t:1527271860425};\\\", \\\"{x:1653,y:966,t:1527271860443};\\\", \\\"{x:1643,y:968,t:1527271860460};\\\", \\\"{x:1634,y:969,t:1527271860476};\\\", \\\"{x:1627,y:970,t:1527271860492};\\\", \\\"{x:1622,y:970,t:1527271860509};\\\", \\\"{x:1620,y:970,t:1527271860526};\\\", \\\"{x:1616,y:971,t:1527271860542};\\\", \\\"{x:1614,y:971,t:1527271860565};\\\", \\\"{x:1614,y:972,t:1527271860588};\\\", \\\"{x:1613,y:972,t:1527271860645};\\\", \\\"{x:1611,y:973,t:1527271860669};\\\", \\\"{x:1610,y:973,t:1527271860693};\\\", \\\"{x:1609,y:974,t:1527271860797};\\\", \\\"{x:1608,y:973,t:1527271860877};\\\", \\\"{x:1607,y:971,t:1527271860892};\\\", \\\"{x:1607,y:970,t:1527271860909};\\\", \\\"{x:1606,y:968,t:1527271860927};\\\", \\\"{x:1606,y:967,t:1527271860943};\\\", \\\"{x:1605,y:966,t:1527271860997};\\\", \\\"{x:1605,y:965,t:1527271862254};\\\", \\\"{x:1603,y:965,t:1527271863068};\\\", \\\"{x:1581,y:959,t:1527271863077};\\\", \\\"{x:1533,y:945,t:1527271863094};\\\", \\\"{x:1481,y:924,t:1527271863111};\\\", \\\"{x:1412,y:893,t:1527271863128};\\\", \\\"{x:1347,y:859,t:1527271863144};\\\", \\\"{x:1299,y:824,t:1527271863162};\\\", \\\"{x:1263,y:785,t:1527271863178};\\\", \\\"{x:1248,y:764,t:1527271863194};\\\", \\\"{x:1243,y:751,t:1527271863212};\\\", \\\"{x:1241,y:743,t:1527271863228};\\\", \\\"{x:1241,y:734,t:1527271863244};\\\", \\\"{x:1241,y:725,t:1527271863261};\\\", \\\"{x:1241,y:724,t:1527271863278};\\\", \\\"{x:1241,y:725,t:1527271863324};\\\", \\\"{x:1241,y:740,t:1527271863332};\\\", \\\"{x:1241,y:762,t:1527271863344};\\\", \\\"{x:1244,y:806,t:1527271863361};\\\", \\\"{x:1259,y:849,t:1527271863378};\\\", \\\"{x:1276,y:879,t:1527271863394};\\\", \\\"{x:1294,y:909,t:1527271863411};\\\", \\\"{x:1314,y:932,t:1527271863428};\\\", \\\"{x:1319,y:934,t:1527271863445};\\\", \\\"{x:1322,y:934,t:1527271863461};\\\", \\\"{x:1334,y:921,t:1527271863478};\\\", \\\"{x:1339,y:884,t:1527271863495};\\\", \\\"{x:1341,y:808,t:1527271863511};\\\", \\\"{x:1341,y:714,t:1527271863528};\\\", \\\"{x:1341,y:609,t:1527271863544};\\\", \\\"{x:1341,y:539,t:1527271863561};\\\", \\\"{x:1333,y:467,t:1527271863578};\\\", \\\"{x:1321,y:422,t:1527271863596};\\\", \\\"{x:1319,y:415,t:1527271863612};\\\", \\\"{x:1319,y:413,t:1527271863628};\\\", \\\"{x:1318,y:413,t:1527271863645};\\\", \\\"{x:1317,y:413,t:1527271863662};\\\", \\\"{x:1316,y:413,t:1527271863679};\\\", \\\"{x:1316,y:419,t:1527271863741};\\\", \\\"{x:1316,y:430,t:1527271863748};\\\", \\\"{x:1320,y:443,t:1527271863761};\\\", \\\"{x:1333,y:465,t:1527271863778};\\\", \\\"{x:1343,y:482,t:1527271863795};\\\", \\\"{x:1347,y:493,t:1527271863811};\\\", \\\"{x:1347,y:500,t:1527271863828};\\\", \\\"{x:1346,y:506,t:1527271863845};\\\", \\\"{x:1340,y:511,t:1527271863861};\\\", \\\"{x:1336,y:513,t:1527271863878};\\\", \\\"{x:1333,y:516,t:1527271863896};\\\", \\\"{x:1332,y:517,t:1527271863925};\\\", \\\"{x:1331,y:518,t:1527271863933};\\\", \\\"{x:1330,y:519,t:1527271863949};\\\", \\\"{x:1330,y:521,t:1527271863965};\\\", \\\"{x:1328,y:522,t:1527271863978};\\\", \\\"{x:1328,y:524,t:1527271863995};\\\", \\\"{x:1324,y:530,t:1527271864012};\\\", \\\"{x:1320,y:539,t:1527271864029};\\\", \\\"{x:1319,y:542,t:1527271864045};\\\", \\\"{x:1318,y:546,t:1527271864062};\\\", \\\"{x:1316,y:554,t:1527271864079};\\\", \\\"{x:1315,y:562,t:1527271864095};\\\", \\\"{x:1315,y:570,t:1527271864113};\\\", \\\"{x:1315,y:577,t:1527271864129};\\\", \\\"{x:1315,y:583,t:1527271864145};\\\", \\\"{x:1315,y:589,t:1527271864163};\\\", \\\"{x:1315,y:594,t:1527271864178};\\\", \\\"{x:1315,y:605,t:1527271864195};\\\", \\\"{x:1316,y:624,t:1527271864212};\\\", \\\"{x:1316,y:630,t:1527271864229};\\\", \\\"{x:1316,y:632,t:1527271864245};\\\", \\\"{x:1316,y:633,t:1527271864262};\\\", \\\"{x:1316,y:635,t:1527271864300};\\\", \\\"{x:1316,y:636,t:1527271864316};\\\", \\\"{x:1316,y:638,t:1527271864332};\\\", \\\"{x:1316,y:639,t:1527271864420};\\\", \\\"{x:1316,y:638,t:1527271864557};\\\", \\\"{x:1316,y:637,t:1527271864572};\\\", \\\"{x:1316,y:636,t:1527271864588};\\\", \\\"{x:1317,y:636,t:1527271864605};\\\", \\\"{x:1317,y:635,t:1527271864621};\\\", \\\"{x:1317,y:634,t:1527271864628};\\\", \\\"{x:1317,y:633,t:1527271864645};\\\", \\\"{x:1317,y:630,t:1527271864663};\\\", \\\"{x:1317,y:628,t:1527271864679};\\\", \\\"{x:1317,y:626,t:1527271864695};\\\", \\\"{x:1317,y:624,t:1527271864713};\\\", \\\"{x:1317,y:623,t:1527271864730};\\\", \\\"{x:1317,y:622,t:1527271864745};\\\", \\\"{x:1317,y:620,t:1527271864763};\\\", \\\"{x:1317,y:618,t:1527271864779};\\\", \\\"{x:1317,y:615,t:1527271864795};\\\", \\\"{x:1317,y:614,t:1527271864812};\\\", \\\"{x:1317,y:610,t:1527271864829};\\\", \\\"{x:1317,y:608,t:1527271864845};\\\", \\\"{x:1317,y:605,t:1527271864862};\\\", \\\"{x:1317,y:601,t:1527271864879};\\\", \\\"{x:1317,y:597,t:1527271864897};\\\", \\\"{x:1317,y:595,t:1527271864912};\\\", \\\"{x:1317,y:594,t:1527271864929};\\\", \\\"{x:1317,y:593,t:1527271864946};\\\", \\\"{x:1317,y:592,t:1527271864962};\\\", \\\"{x:1317,y:586,t:1527271864979};\\\", \\\"{x:1317,y:579,t:1527271864996};\\\", \\\"{x:1317,y:571,t:1527271865012};\\\", \\\"{x:1316,y:562,t:1527271865029};\\\", \\\"{x:1315,y:555,t:1527271865046};\\\", \\\"{x:1314,y:548,t:1527271865063};\\\", \\\"{x:1314,y:542,t:1527271865080};\\\", \\\"{x:1314,y:538,t:1527271865097};\\\", \\\"{x:1314,y:533,t:1527271865112};\\\", \\\"{x:1313,y:525,t:1527271865130};\\\", \\\"{x:1312,y:519,t:1527271865147};\\\", \\\"{x:1312,y:516,t:1527271865162};\\\", \\\"{x:1311,y:514,t:1527271865179};\\\", \\\"{x:1311,y:511,t:1527271865196};\\\", \\\"{x:1311,y:509,t:1527271865212};\\\", \\\"{x:1311,y:508,t:1527271865229};\\\", \\\"{x:1310,y:504,t:1527271865247};\\\", \\\"{x:1310,y:503,t:1527271865263};\\\", \\\"{x:1310,y:500,t:1527271865280};\\\", \\\"{x:1310,y:498,t:1527271865296};\\\", \\\"{x:1310,y:497,t:1527271865312};\\\", \\\"{x:1310,y:494,t:1527271865329};\\\", \\\"{x:1310,y:493,t:1527271865346};\\\", \\\"{x:1310,y:494,t:1527271866612};\\\", \\\"{x:1310,y:496,t:1527271866630};\\\", \\\"{x:1310,y:499,t:1527271866648};\\\", \\\"{x:1310,y:500,t:1527271866669};\\\", \\\"{x:1310,y:501,t:1527271866681};\\\", \\\"{x:1310,y:502,t:1527271866698};\\\", \\\"{x:1310,y:503,t:1527271866714};\\\", \\\"{x:1310,y:504,t:1527271866731};\\\", \\\"{x:1310,y:505,t:1527271866747};\\\", \\\"{x:1310,y:507,t:1527271866765};\\\", \\\"{x:1310,y:509,t:1527271866782};\\\", \\\"{x:1310,y:512,t:1527271866798};\\\", \\\"{x:1310,y:516,t:1527271866814};\\\", \\\"{x:1310,y:520,t:1527271866830};\\\", \\\"{x:1310,y:524,t:1527271866847};\\\", \\\"{x:1310,y:526,t:1527271866864};\\\", \\\"{x:1310,y:528,t:1527271866880};\\\", \\\"{x:1310,y:532,t:1527271866898};\\\", \\\"{x:1310,y:535,t:1527271866914};\\\", \\\"{x:1310,y:540,t:1527271866930};\\\", \\\"{x:1310,y:547,t:1527271866948};\\\", \\\"{x:1310,y:557,t:1527271866964};\\\", \\\"{x:1310,y:564,t:1527271866980};\\\", \\\"{x:1310,y:573,t:1527271866997};\\\", \\\"{x:1308,y:581,t:1527271867015};\\\", \\\"{x:1306,y:586,t:1527271867031};\\\", \\\"{x:1306,y:593,t:1527271867048};\\\", \\\"{x:1305,y:597,t:1527271867064};\\\", \\\"{x:1303,y:603,t:1527271867080};\\\", \\\"{x:1302,y:607,t:1527271867098};\\\", \\\"{x:1302,y:613,t:1527271867115};\\\", \\\"{x:1302,y:621,t:1527271867131};\\\", \\\"{x:1302,y:632,t:1527271867147};\\\", \\\"{x:1302,y:643,t:1527271867164};\\\", \\\"{x:1302,y:646,t:1527271867184};\\\", \\\"{x:1302,y:648,t:1527271867197};\\\", \\\"{x:1302,y:649,t:1527271867215};\\\", \\\"{x:1302,y:650,t:1527271867231};\\\", \\\"{x:1302,y:652,t:1527271867248};\\\", \\\"{x:1302,y:654,t:1527271867265};\\\", \\\"{x:1302,y:655,t:1527271867293};\\\", \\\"{x:1302,y:657,t:1527271867300};\\\", \\\"{x:1302,y:658,t:1527271867316};\\\", \\\"{x:1302,y:660,t:1527271867332};\\\", \\\"{x:1302,y:662,t:1527271867348};\\\", \\\"{x:1302,y:671,t:1527271867365};\\\", \\\"{x:1302,y:676,t:1527271867383};\\\", \\\"{x:1302,y:681,t:1527271867397};\\\", \\\"{x:1302,y:682,t:1527271867415};\\\", \\\"{x:1302,y:685,t:1527271867432};\\\", \\\"{x:1302,y:687,t:1527271867447};\\\", \\\"{x:1302,y:690,t:1527271867464};\\\", \\\"{x:1302,y:693,t:1527271867482};\\\", \\\"{x:1302,y:696,t:1527271867498};\\\", \\\"{x:1302,y:702,t:1527271867516};\\\", \\\"{x:1302,y:708,t:1527271867532};\\\", \\\"{x:1302,y:715,t:1527271867548};\\\", \\\"{x:1302,y:722,t:1527271867565};\\\", \\\"{x:1303,y:727,t:1527271867584};\\\", \\\"{x:1303,y:729,t:1527271867599};\\\", \\\"{x:1304,y:733,t:1527271867615};\\\", \\\"{x:1304,y:737,t:1527271867632};\\\", \\\"{x:1305,y:742,t:1527271867649};\\\", \\\"{x:1308,y:748,t:1527271867665};\\\", \\\"{x:1309,y:753,t:1527271867682};\\\", \\\"{x:1311,y:759,t:1527271867699};\\\", \\\"{x:1312,y:764,t:1527271867715};\\\", \\\"{x:1313,y:767,t:1527271867732};\\\", \\\"{x:1313,y:771,t:1527271867748};\\\", \\\"{x:1315,y:773,t:1527271867765};\\\", \\\"{x:1315,y:777,t:1527271867782};\\\", \\\"{x:1319,y:783,t:1527271867799};\\\", \\\"{x:1319,y:790,t:1527271867815};\\\", \\\"{x:1319,y:797,t:1527271867832};\\\", \\\"{x:1319,y:807,t:1527271867849};\\\", \\\"{x:1319,y:817,t:1527271867864};\\\", \\\"{x:1317,y:831,t:1527271867882};\\\", \\\"{x:1316,y:842,t:1527271867898};\\\", \\\"{x:1314,y:851,t:1527271867915};\\\", \\\"{x:1313,y:860,t:1527271867932};\\\", \\\"{x:1313,y:864,t:1527271867949};\\\", \\\"{x:1313,y:866,t:1527271867965};\\\", \\\"{x:1313,y:867,t:1527271867988};\\\", \\\"{x:1313,y:868,t:1527271867999};\\\", \\\"{x:1313,y:871,t:1527271868015};\\\", \\\"{x:1315,y:877,t:1527271868032};\\\", \\\"{x:1318,y:883,t:1527271868049};\\\", \\\"{x:1320,y:888,t:1527271868065};\\\", \\\"{x:1321,y:892,t:1527271868082};\\\", \\\"{x:1322,y:892,t:1527271868099};\\\", \\\"{x:1322,y:894,t:1527271868140};\\\", \\\"{x:1322,y:895,t:1527271868156};\\\", \\\"{x:1322,y:897,t:1527271868173};\\\", \\\"{x:1322,y:898,t:1527271868189};\\\", \\\"{x:1322,y:900,t:1527271868199};\\\", \\\"{x:1322,y:901,t:1527271868221};\\\", \\\"{x:1322,y:902,t:1527271868232};\\\", \\\"{x:1322,y:903,t:1527271868249};\\\", \\\"{x:1322,y:905,t:1527271868266};\\\", \\\"{x:1322,y:906,t:1527271868282};\\\", \\\"{x:1322,y:907,t:1527271868299};\\\", \\\"{x:1322,y:909,t:1527271868316};\\\", \\\"{x:1321,y:911,t:1527271868332};\\\", \\\"{x:1320,y:915,t:1527271868349};\\\", \\\"{x:1320,y:919,t:1527271868366};\\\", \\\"{x:1318,y:922,t:1527271868383};\\\", \\\"{x:1318,y:924,t:1527271868399};\\\", \\\"{x:1317,y:928,t:1527271868416};\\\", \\\"{x:1317,y:930,t:1527271868432};\\\", \\\"{x:1315,y:932,t:1527271868449};\\\", \\\"{x:1315,y:934,t:1527271868465};\\\", \\\"{x:1315,y:936,t:1527271868483};\\\", \\\"{x:1314,y:939,t:1527271868499};\\\", \\\"{x:1314,y:941,t:1527271868516};\\\", \\\"{x:1313,y:946,t:1527271868532};\\\", \\\"{x:1313,y:950,t:1527271868549};\\\", \\\"{x:1313,y:952,t:1527271868566};\\\", \\\"{x:1313,y:954,t:1527271868584};\\\", \\\"{x:1312,y:957,t:1527271868599};\\\", \\\"{x:1312,y:959,t:1527271868701};\\\", \\\"{x:1312,y:960,t:1527271868716};\\\", \\\"{x:1312,y:963,t:1527271868733};\\\", \\\"{x:1312,y:965,t:1527271868749};\\\", \\\"{x:1314,y:967,t:1527271868766};\\\", \\\"{x:1315,y:967,t:1527271869717};\\\", \\\"{x:1315,y:966,t:1527271869835};\\\", \\\"{x:1315,y:964,t:1527271869849};\\\", \\\"{x:1315,y:963,t:1527271869866};\\\", \\\"{x:1315,y:961,t:1527271869883};\\\", \\\"{x:1315,y:958,t:1527271869900};\\\", \\\"{x:1315,y:954,t:1527271869916};\\\", \\\"{x:1315,y:952,t:1527271869934};\\\", \\\"{x:1315,y:950,t:1527271869950};\\\", \\\"{x:1315,y:947,t:1527271869966};\\\", \\\"{x:1315,y:945,t:1527271869983};\\\", \\\"{x:1315,y:944,t:1527271870004};\\\", \\\"{x:1315,y:942,t:1527271870020};\\\", \\\"{x:1315,y:941,t:1527271870036};\\\", \\\"{x:1315,y:939,t:1527271870061};\\\", \\\"{x:1315,y:938,t:1527271870085};\\\", \\\"{x:1315,y:937,t:1527271870165};\\\", \\\"{x:1315,y:936,t:1527271870181};\\\", \\\"{x:1315,y:935,t:1527271870205};\\\", \\\"{x:1315,y:934,t:1527271870261};\\\", \\\"{x:1315,y:933,t:1527271870301};\\\", \\\"{x:1315,y:932,t:1527271870357};\\\", \\\"{x:1315,y:931,t:1527271870372};\\\", \\\"{x:1315,y:930,t:1527271870412};\\\", \\\"{x:1315,y:929,t:1527271870493};\\\", \\\"{x:1315,y:928,t:1527271870524};\\\", \\\"{x:1315,y:926,t:1527271870540};\\\", \\\"{x:1315,y:925,t:1527271870564};\\\", \\\"{x:1315,y:924,t:1527271870581};\\\", \\\"{x:1315,y:923,t:1527271870589};\\\", \\\"{x:1314,y:923,t:1527271870604};\\\", \\\"{x:1314,y:922,t:1527271870619};\\\", \\\"{x:1314,y:921,t:1527271870651};\\\", \\\"{x:1314,y:920,t:1527271870668};\\\", \\\"{x:1314,y:919,t:1527271870732};\\\", \\\"{x:1313,y:917,t:1527271870764};\\\", \\\"{x:1312,y:916,t:1527271870780};\\\", \\\"{x:1312,y:914,t:1527271870788};\\\", \\\"{x:1311,y:913,t:1527271870800};\\\", \\\"{x:1311,y:910,t:1527271870817};\\\", \\\"{x:1308,y:905,t:1527271870834};\\\", \\\"{x:1307,y:900,t:1527271870851};\\\", \\\"{x:1305,y:896,t:1527271870868};\\\", \\\"{x:1304,y:892,t:1527271870885};\\\", \\\"{x:1303,y:889,t:1527271870901};\\\", \\\"{x:1303,y:887,t:1527271870918};\\\", \\\"{x:1303,y:886,t:1527271870934};\\\", \\\"{x:1302,y:884,t:1527271870951};\\\", \\\"{x:1301,y:884,t:1527271870968};\\\", \\\"{x:1301,y:882,t:1527271870983};\\\", \\\"{x:1301,y:881,t:1527271871005};\\\", \\\"{x:1301,y:880,t:1527271871036};\\\", \\\"{x:1301,y:879,t:1527271871051};\\\", \\\"{x:1301,y:878,t:1527271871068};\\\", \\\"{x:1301,y:876,t:1527271871085};\\\", \\\"{x:1301,y:875,t:1527271871101};\\\", \\\"{x:1300,y:874,t:1527271871118};\\\", \\\"{x:1300,y:872,t:1527271871134};\\\", \\\"{x:1299,y:870,t:1527271871156};\\\", \\\"{x:1299,y:869,t:1527271871181};\\\", \\\"{x:1299,y:867,t:1527271871204};\\\", \\\"{x:1299,y:866,t:1527271871218};\\\", \\\"{x:1299,y:864,t:1527271871236};\\\", \\\"{x:1298,y:863,t:1527271871251};\\\", \\\"{x:1298,y:861,t:1527271871268};\\\", \\\"{x:1298,y:859,t:1527271871284};\\\", \\\"{x:1297,y:857,t:1527271871301};\\\", \\\"{x:1297,y:856,t:1527271871324};\\\", \\\"{x:1297,y:855,t:1527271871335};\\\", \\\"{x:1297,y:854,t:1527271871351};\\\", \\\"{x:1296,y:852,t:1527271871396};\\\", \\\"{x:1296,y:851,t:1527271871421};\\\", \\\"{x:1296,y:849,t:1527271871437};\\\", \\\"{x:1296,y:848,t:1527271871451};\\\", \\\"{x:1295,y:847,t:1527271871468};\\\", \\\"{x:1294,y:844,t:1527271871485};\\\", \\\"{x:1294,y:842,t:1527271871501};\\\", \\\"{x:1293,y:840,t:1527271871518};\\\", \\\"{x:1293,y:838,t:1527271871535};\\\", \\\"{x:1293,y:837,t:1527271871557};\\\", \\\"{x:1292,y:836,t:1527271871597};\\\", \\\"{x:1292,y:835,t:1527271871620};\\\", \\\"{x:1291,y:834,t:1527271871661};\\\", \\\"{x:1291,y:833,t:1527271871709};\\\", \\\"{x:1291,y:832,t:1527271871725};\\\", \\\"{x:1291,y:831,t:1527271871749};\\\", \\\"{x:1291,y:830,t:1527271871757};\\\", \\\"{x:1290,y:829,t:1527271871768};\\\", \\\"{x:1289,y:827,t:1527271871785};\\\", \\\"{x:1289,y:825,t:1527271871802};\\\", \\\"{x:1288,y:821,t:1527271871817};\\\", \\\"{x:1287,y:817,t:1527271871834};\\\", \\\"{x:1285,y:812,t:1527271871851};\\\", \\\"{x:1284,y:808,t:1527271871868};\\\", \\\"{x:1283,y:804,t:1527271871884};\\\", \\\"{x:1283,y:802,t:1527271871902};\\\", \\\"{x:1281,y:799,t:1527271871918};\\\", \\\"{x:1281,y:797,t:1527271871934};\\\", \\\"{x:1281,y:795,t:1527271871964};\\\", \\\"{x:1281,y:794,t:1527271871987};\\\", \\\"{x:1281,y:792,t:1527271872004};\\\", \\\"{x:1280,y:792,t:1527271872020};\\\", \\\"{x:1280,y:791,t:1527271872877};\\\", \\\"{x:1280,y:790,t:1527271872886};\\\", \\\"{x:1282,y:788,t:1527271872902};\\\", \\\"{x:1284,y:788,t:1527271872919};\\\", \\\"{x:1286,y:787,t:1527271872936};\\\", \\\"{x:1288,y:787,t:1527271872953};\\\", \\\"{x:1290,y:787,t:1527271872972};\\\", \\\"{x:1291,y:787,t:1527271872986};\\\", \\\"{x:1295,y:790,t:1527271873003};\\\", \\\"{x:1307,y:804,t:1527271873018};\\\", \\\"{x:1320,y:820,t:1527271873036};\\\", \\\"{x:1326,y:829,t:1527271873052};\\\", \\\"{x:1332,y:842,t:1527271873069};\\\", \\\"{x:1337,y:854,t:1527271873085};\\\", \\\"{x:1341,y:863,t:1527271873103};\\\", \\\"{x:1343,y:875,t:1527271873119};\\\", \\\"{x:1344,y:880,t:1527271873135};\\\", \\\"{x:1344,y:884,t:1527271873153};\\\", \\\"{x:1344,y:888,t:1527271873169};\\\", \\\"{x:1346,y:897,t:1527271873186};\\\", \\\"{x:1346,y:904,t:1527271873203};\\\", \\\"{x:1346,y:907,t:1527271873219};\\\", \\\"{x:1347,y:908,t:1527271873461};\\\", \\\"{x:1349,y:907,t:1527271873470};\\\", \\\"{x:1350,y:902,t:1527271873487};\\\", \\\"{x:1353,y:898,t:1527271873504};\\\", \\\"{x:1353,y:897,t:1527271873520};\\\", \\\"{x:1349,y:898,t:1527271874317};\\\", \\\"{x:1349,y:899,t:1527271874332};\\\", \\\"{x:1348,y:899,t:1527271875805};\\\", \\\"{x:1346,y:899,t:1527271875821};\\\", \\\"{x:1345,y:899,t:1527271876292};\\\", \\\"{x:1343,y:899,t:1527271876305};\\\", \\\"{x:1340,y:898,t:1527271876322};\\\", \\\"{x:1339,y:898,t:1527271876337};\\\", \\\"{x:1339,y:897,t:1527271876388};\\\", \\\"{x:1339,y:896,t:1527271876405};\\\", \\\"{x:1342,y:895,t:1527271876422};\\\", \\\"{x:1344,y:892,t:1527271876438};\\\", \\\"{x:1347,y:891,t:1527271876455};\\\", \\\"{x:1350,y:889,t:1527271876472};\\\", \\\"{x:1355,y:888,t:1527271876489};\\\", \\\"{x:1363,y:887,t:1527271876505};\\\", \\\"{x:1371,y:887,t:1527271876522};\\\", \\\"{x:1386,y:887,t:1527271876539};\\\", \\\"{x:1404,y:887,t:1527271876555};\\\", \\\"{x:1434,y:890,t:1527271876572};\\\", \\\"{x:1446,y:892,t:1527271876588};\\\", \\\"{x:1455,y:893,t:1527271876605};\\\", \\\"{x:1460,y:894,t:1527271876621};\\\", \\\"{x:1461,y:894,t:1527271876639};\\\", \\\"{x:1462,y:894,t:1527271876677};\\\", \\\"{x:1463,y:894,t:1527271876693};\\\", \\\"{x:1464,y:894,t:1527271876782};\\\", \\\"{x:1464,y:895,t:1527271876789};\\\", \\\"{x:1461,y:895,t:1527271876806};\\\", \\\"{x:1458,y:895,t:1527271876822};\\\", \\\"{x:1457,y:895,t:1527271876845};\\\", \\\"{x:1456,y:895,t:1527271876868};\\\", \\\"{x:1455,y:895,t:1527271876876};\\\", \\\"{x:1454,y:895,t:1527271876892};\\\", \\\"{x:1453,y:895,t:1527271877157};\\\", \\\"{x:1461,y:883,t:1527271877173};\\\", \\\"{x:1470,y:861,t:1527271877189};\\\", \\\"{x:1480,y:843,t:1527271877206};\\\", \\\"{x:1485,y:828,t:1527271877222};\\\", \\\"{x:1490,y:819,t:1527271877239};\\\", \\\"{x:1491,y:814,t:1527271877255};\\\", \\\"{x:1492,y:813,t:1527271877272};\\\", \\\"{x:1492,y:812,t:1527271877356};\\\", \\\"{x:1490,y:812,t:1527271877372};\\\", \\\"{x:1489,y:813,t:1527271877389};\\\", \\\"{x:1488,y:813,t:1527271877406};\\\", \\\"{x:1487,y:814,t:1527271877423};\\\", \\\"{x:1484,y:818,t:1527271877439};\\\", \\\"{x:1482,y:823,t:1527271877456};\\\", \\\"{x:1481,y:827,t:1527271877474};\\\", \\\"{x:1480,y:829,t:1527271877489};\\\", \\\"{x:1479,y:831,t:1527271877506};\\\", \\\"{x:1479,y:832,t:1527271877844};\\\", \\\"{x:1479,y:834,t:1527271877856};\\\", \\\"{x:1479,y:836,t:1527271877894};\\\", \\\"{x:1480,y:837,t:1527271878733};\\\", \\\"{x:1481,y:837,t:1527271878757};\\\", \\\"{x:1482,y:837,t:1527271878781};\\\", \\\"{x:1477,y:836,t:1527271879357};\\\", \\\"{x:1444,y:831,t:1527271879375};\\\", \\\"{x:1399,y:823,t:1527271879391};\\\", \\\"{x:1326,y:813,t:1527271879408};\\\", \\\"{x:1248,y:802,t:1527271879425};\\\", \\\"{x:1150,y:782,t:1527271879441};\\\", \\\"{x:1044,y:764,t:1527271879458};\\\", \\\"{x:950,y:751,t:1527271879475};\\\", \\\"{x:871,y:738,t:1527271879491};\\\", \\\"{x:794,y:727,t:1527271879508};\\\", \\\"{x:760,y:722,t:1527271879525};\\\", \\\"{x:737,y:717,t:1527271879541};\\\", \\\"{x:719,y:709,t:1527271879558};\\\", \\\"{x:703,y:700,t:1527271879574};\\\", \\\"{x:675,y:687,t:1527271879591};\\\", \\\"{x:635,y:666,t:1527271879609};\\\", \\\"{x:589,y:648,t:1527271879626};\\\", \\\"{x:566,y:637,t:1527271879641};\\\", \\\"{x:561,y:634,t:1527271879658};\\\", \\\"{x:561,y:630,t:1527271879673};\\\", \\\"{x:561,y:627,t:1527271879690};\\\", \\\"{x:563,y:620,t:1527271879707};\\\", \\\"{x:565,y:619,t:1527271879725};\\\", \\\"{x:565,y:616,t:1527271879741};\\\", \\\"{x:565,y:614,t:1527271879757};\\\", \\\"{x:563,y:612,t:1527271879776};\\\", \\\"{x:553,y:611,t:1527271879790};\\\", \\\"{x:538,y:611,t:1527271879807};\\\", \\\"{x:526,y:611,t:1527271879824};\\\", \\\"{x:519,y:611,t:1527271879841};\\\", \\\"{x:526,y:611,t:1527271879884};\\\", \\\"{x:534,y:606,t:1527271879892};\\\", \\\"{x:554,y:600,t:1527271879908};\\\", \\\"{x:569,y:591,t:1527271879925};\\\", \\\"{x:576,y:589,t:1527271879941};\\\", \\\"{x:578,y:589,t:1527271879958};\\\", \\\"{x:578,y:588,t:1527271880037};\\\", \\\"{x:578,y:587,t:1527271880077};\\\", \\\"{x:579,y:586,t:1527271880092};\\\", \\\"{x:581,y:585,t:1527271880149};\\\", \\\"{x:582,y:585,t:1527271880197};\\\", \\\"{x:583,y:586,t:1527271880208};\\\", \\\"{x:596,y:593,t:1527271880226};\\\", \\\"{x:609,y:598,t:1527271880243};\\\", \\\"{x:620,y:601,t:1527271880258};\\\", \\\"{x:625,y:603,t:1527271880275};\\\", \\\"{x:626,y:603,t:1527271880292};\\\", \\\"{x:625,y:603,t:1527271880395};\\\", \\\"{x:625,y:604,t:1527271880408};\\\", \\\"{x:623,y:605,t:1527271880436};\\\", \\\"{x:621,y:605,t:1527271880452};\\\", \\\"{x:619,y:607,t:1527271880469};\\\", \\\"{x:618,y:607,t:1527271880484};\\\", \\\"{x:617,y:607,t:1527271880492};\\\", \\\"{x:616,y:607,t:1527271880524};\\\", \\\"{x:616,y:606,t:1527271880717};\\\", \\\"{x:616,y:605,t:1527271881180};\\\", \\\"{x:617,y:603,t:1527271881196};\\\", \\\"{x:618,y:603,t:1527271881212};\\\", \\\"{x:619,y:603,t:1527271881226};\\\", \\\"{x:624,y:600,t:1527271881242};\\\", \\\"{x:639,y:598,t:1527271881259};\\\", \\\"{x:731,y:614,t:1527271881278};\\\", \\\"{x:848,y:637,t:1527271881292};\\\", \\\"{x:977,y:664,t:1527271881308};\\\", \\\"{x:1122,y:695,t:1527271881326};\\\", \\\"{x:1263,y:732,t:1527271881343};\\\", \\\"{x:1394,y:759,t:1527271881359};\\\", \\\"{x:1498,y:783,t:1527271881376};\\\", \\\"{x:1585,y:810,t:1527271881393};\\\", \\\"{x:1638,y:826,t:1527271881409};\\\", \\\"{x:1657,y:831,t:1527271881426};\\\", \\\"{x:1661,y:834,t:1527271881443};\\\", \\\"{x:1661,y:836,t:1527271881459};\\\", \\\"{x:1661,y:838,t:1527271881476};\\\", \\\"{x:1660,y:840,t:1527271881493};\\\", \\\"{x:1658,y:846,t:1527271881510};\\\", \\\"{x:1655,y:851,t:1527271881526};\\\", \\\"{x:1647,y:860,t:1527271881543};\\\", \\\"{x:1639,y:864,t:1527271881559};\\\", \\\"{x:1630,y:868,t:1527271881576};\\\", \\\"{x:1611,y:869,t:1527271881593};\\\", \\\"{x:1586,y:870,t:1527271881608};\\\", \\\"{x:1563,y:874,t:1527271881626};\\\", \\\"{x:1546,y:875,t:1527271881643};\\\", \\\"{x:1530,y:875,t:1527271881659};\\\", \\\"{x:1514,y:875,t:1527271881675};\\\", \\\"{x:1511,y:874,t:1527271881693};\\\", \\\"{x:1507,y:873,t:1527271881709};\\\", \\\"{x:1506,y:872,t:1527271881740};\\\", \\\"{x:1506,y:871,t:1527271881788};\\\", \\\"{x:1506,y:868,t:1527271881796};\\\", \\\"{x:1504,y:865,t:1527271881809};\\\", \\\"{x:1501,y:862,t:1527271881826};\\\", \\\"{x:1500,y:859,t:1527271881843};\\\", \\\"{x:1498,y:856,t:1527271881860};\\\", \\\"{x:1498,y:855,t:1527271881876};\\\", \\\"{x:1498,y:853,t:1527271881894};\\\", \\\"{x:1495,y:847,t:1527271881910};\\\", \\\"{x:1492,y:840,t:1527271881926};\\\", \\\"{x:1488,y:832,t:1527271881944};\\\", \\\"{x:1485,y:822,t:1527271881961};\\\", \\\"{x:1478,y:806,t:1527271881977};\\\", \\\"{x:1469,y:787,t:1527271881993};\\\", \\\"{x:1456,y:764,t:1527271882010};\\\", \\\"{x:1430,y:735,t:1527271882026};\\\", \\\"{x:1406,y:712,t:1527271882043};\\\", \\\"{x:1368,y:643,t:1527271882060};\\\", \\\"{x:1347,y:601,t:1527271882076};\\\", \\\"{x:1334,y:583,t:1527271882093};\\\", \\\"{x:1330,y:575,t:1527271882110};\\\", \\\"{x:1330,y:574,t:1527271882127};\\\", \\\"{x:1330,y:571,t:1527271882205};\\\", \\\"{x:1337,y:569,t:1527271882212};\\\", \\\"{x:1344,y:563,t:1527271882228};\\\", \\\"{x:1357,y:558,t:1527271882244};\\\", \\\"{x:1370,y:552,t:1527271882261};\\\", \\\"{x:1374,y:550,t:1527271882277};\\\", \\\"{x:1378,y:549,t:1527271882293};\\\", \\\"{x:1386,y:545,t:1527271882311};\\\", \\\"{x:1391,y:543,t:1527271882328};\\\", \\\"{x:1394,y:542,t:1527271882344};\\\", \\\"{x:1395,y:542,t:1527271882421};\\\", \\\"{x:1396,y:542,t:1527271882428};\\\", \\\"{x:1397,y:541,t:1527271882443};\\\", \\\"{x:1399,y:545,t:1527271882573};\\\", \\\"{x:1401,y:547,t:1527271882581};\\\", \\\"{x:1404,y:552,t:1527271882593};\\\", \\\"{x:1407,y:554,t:1527271882611};\\\", \\\"{x:1408,y:555,t:1527271882628};\\\", \\\"{x:1408,y:556,t:1527271882969};\\\", \\\"{x:1409,y:557,t:1527271882981};\\\", \\\"{x:1410,y:558,t:1527271882999};\\\", \\\"{x:1411,y:560,t:1527271883015};\\\", \\\"{x:1412,y:561,t:1527271883031};\\\", \\\"{x:1413,y:561,t:1527271883055};\\\", \\\"{x:1414,y:561,t:1527271883072};\\\", \\\"{x:1415,y:561,t:1527271883087};\\\", \\\"{x:1416,y:561,t:1527271883984};\\\", \\\"{x:1416,y:562,t:1527271884361};\\\", \\\"{x:1416,y:564,t:1527271884392};\\\", \\\"{x:1415,y:559,t:1527271884752};\\\", \\\"{x:1415,y:538,t:1527271884768};\\\", \\\"{x:1415,y:510,t:1527271884782};\\\", \\\"{x:1414,y:480,t:1527271884799};\\\", \\\"{x:1413,y:447,t:1527271884815};\\\", \\\"{x:1411,y:439,t:1527271884832};\\\", \\\"{x:1410,y:437,t:1527271884849};\\\", \\\"{x:1410,y:435,t:1527271884865};\\\", \\\"{x:1410,y:434,t:1527271885401};\\\", \\\"{x:1411,y:433,t:1527271885416};\\\", \\\"{x:1412,y:433,t:1527271885433};\\\", \\\"{x:1413,y:433,t:1527271885568};\\\", \\\"{x:1413,y:435,t:1527271886088};\\\", \\\"{x:1413,y:442,t:1527271886101};\\\", \\\"{x:1419,y:462,t:1527271886117};\\\", \\\"{x:1432,y:494,t:1527271886133};\\\", \\\"{x:1453,y:539,t:1527271886150};\\\", \\\"{x:1477,y:590,t:1527271886168};\\\", \\\"{x:1483,y:602,t:1527271886184};\\\", \\\"{x:1499,y:646,t:1527271886200};\\\", \\\"{x:1507,y:697,t:1527271886218};\\\", \\\"{x:1514,y:740,t:1527271886234};\\\", \\\"{x:1519,y:774,t:1527271886250};\\\", \\\"{x:1520,y:796,t:1527271886267};\\\", \\\"{x:1521,y:810,t:1527271886285};\\\", \\\"{x:1521,y:821,t:1527271886301};\\\", \\\"{x:1524,y:837,t:1527271886318};\\\", \\\"{x:1526,y:855,t:1527271886334};\\\", \\\"{x:1532,y:875,t:1527271886350};\\\", \\\"{x:1536,y:889,t:1527271886368};\\\", \\\"{x:1538,y:896,t:1527271886384};\\\", \\\"{x:1538,y:897,t:1527271886401};\\\", \\\"{x:1538,y:896,t:1527271886472};\\\", \\\"{x:1537,y:893,t:1527271886484};\\\", \\\"{x:1535,y:889,t:1527271886500};\\\", \\\"{x:1532,y:882,t:1527271886518};\\\", \\\"{x:1530,y:878,t:1527271886535};\\\", \\\"{x:1528,y:876,t:1527271886550};\\\", \\\"{x:1527,y:874,t:1527271886567};\\\", \\\"{x:1520,y:866,t:1527271886584};\\\", \\\"{x:1511,y:860,t:1527271886601};\\\", \\\"{x:1503,y:853,t:1527271886618};\\\", \\\"{x:1497,y:847,t:1527271886634};\\\", \\\"{x:1495,y:844,t:1527271886652};\\\", \\\"{x:1494,y:844,t:1527271886720};\\\", \\\"{x:1494,y:843,t:1527271886736};\\\", \\\"{x:1493,y:842,t:1527271886751};\\\", \\\"{x:1493,y:839,t:1527271886920};\\\", \\\"{x:1491,y:837,t:1527271886934};\\\", \\\"{x:1490,y:833,t:1527271886951};\\\", \\\"{x:1488,y:831,t:1527271886968};\\\", \\\"{x:1487,y:828,t:1527271886984};\\\", \\\"{x:1486,y:827,t:1527271887002};\\\", \\\"{x:1485,y:824,t:1527271887019};\\\", \\\"{x:1485,y:818,t:1527271887035};\\\", \\\"{x:1485,y:807,t:1527271887051};\\\", \\\"{x:1486,y:787,t:1527271887067};\\\", \\\"{x:1497,y:738,t:1527271887084};\\\", \\\"{x:1513,y:656,t:1527271887101};\\\", \\\"{x:1530,y:606,t:1527271887119};\\\", \\\"{x:1541,y:578,t:1527271887135};\\\", \\\"{x:1546,y:565,t:1527271887152};\\\", \\\"{x:1549,y:560,t:1527271887168};\\\", \\\"{x:1549,y:559,t:1527271887185};\\\", \\\"{x:1550,y:556,t:1527271887202};\\\", \\\"{x:1549,y:555,t:1527271887289};\\\", \\\"{x:1548,y:555,t:1527271887301};\\\", \\\"{x:1540,y:560,t:1527271887318};\\\", \\\"{x:1535,y:573,t:1527271887334};\\\", \\\"{x:1529,y:595,t:1527271887352};\\\", \\\"{x:1525,y:616,t:1527271887368};\\\", \\\"{x:1525,y:621,t:1527271887384};\\\", \\\"{x:1524,y:623,t:1527271887401};\\\", \\\"{x:1524,y:625,t:1527271887417};\\\", \\\"{x:1524,y:626,t:1527271887434};\\\", \\\"{x:1523,y:628,t:1527271887451};\\\", \\\"{x:1523,y:629,t:1527271887467};\\\", \\\"{x:1523,y:631,t:1527271887484};\\\", \\\"{x:1522,y:631,t:1527271887641};\\\", \\\"{x:1521,y:632,t:1527271887651};\\\", \\\"{x:1519,y:633,t:1527271887668};\\\", \\\"{x:1518,y:634,t:1527271887685};\\\", \\\"{x:1517,y:634,t:1527271887703};\\\", \\\"{x:1516,y:635,t:1527271889992};\\\", \\\"{x:1515,y:641,t:1527271890004};\\\", \\\"{x:1515,y:657,t:1527271890020};\\\", \\\"{x:1515,y:667,t:1527271890036};\\\", \\\"{x:1517,y:675,t:1527271890053};\\\", \\\"{x:1518,y:681,t:1527271890070};\\\", \\\"{x:1520,y:685,t:1527271890087};\\\", \\\"{x:1521,y:691,t:1527271890103};\\\", \\\"{x:1523,y:705,t:1527271890120};\\\", \\\"{x:1524,y:714,t:1527271890137};\\\", \\\"{x:1525,y:718,t:1527271890153};\\\", \\\"{x:1525,y:723,t:1527271890170};\\\", \\\"{x:1525,y:738,t:1527271890187};\\\", \\\"{x:1518,y:764,t:1527271890203};\\\", \\\"{x:1512,y:782,t:1527271890220};\\\", \\\"{x:1511,y:792,t:1527271890237};\\\", \\\"{x:1507,y:801,t:1527271890253};\\\", \\\"{x:1507,y:815,t:1527271890270};\\\", \\\"{x:1507,y:828,t:1527271890288};\\\", \\\"{x:1507,y:836,t:1527271890303};\\\", \\\"{x:1506,y:848,t:1527271890320};\\\", \\\"{x:1506,y:856,t:1527271890338};\\\", \\\"{x:1506,y:866,t:1527271890353};\\\", \\\"{x:1507,y:877,t:1527271890371};\\\", \\\"{x:1512,y:889,t:1527271890387};\\\", \\\"{x:1514,y:897,t:1527271890403};\\\", \\\"{x:1517,y:902,t:1527271890421};\\\", \\\"{x:1518,y:904,t:1527271890437};\\\", \\\"{x:1518,y:905,t:1527271890454};\\\", \\\"{x:1518,y:906,t:1527271890471};\\\", \\\"{x:1518,y:911,t:1527271890488};\\\", \\\"{x:1523,y:922,t:1527271890504};\\\", \\\"{x:1527,y:934,t:1527271890520};\\\", \\\"{x:1528,y:939,t:1527271890538};\\\", \\\"{x:1529,y:941,t:1527271890553};\\\", \\\"{x:1529,y:942,t:1527271890616};\\\", \\\"{x:1529,y:943,t:1527271890624};\\\", \\\"{x:1529,y:944,t:1527271890637};\\\", \\\"{x:1528,y:948,t:1527271890655};\\\", \\\"{x:1528,y:950,t:1527271890671};\\\", \\\"{x:1526,y:953,t:1527271890688};\\\", \\\"{x:1526,y:955,t:1527271890704};\\\", \\\"{x:1525,y:957,t:1527271890720};\\\", \\\"{x:1525,y:959,t:1527271890737};\\\", \\\"{x:1524,y:962,t:1527271890754};\\\", \\\"{x:1523,y:965,t:1527271890771};\\\", \\\"{x:1521,y:968,t:1527271890787};\\\", \\\"{x:1519,y:972,t:1527271890805};\\\", \\\"{x:1518,y:974,t:1527271890821};\\\", \\\"{x:1518,y:976,t:1527271890968};\\\", \\\"{x:1520,y:978,t:1527271890984};\\\", \\\"{x:1528,y:979,t:1527271890992};\\\", \\\"{x:1534,y:979,t:1527271891003};\\\", \\\"{x:1539,y:979,t:1527271891020};\\\", \\\"{x:1542,y:980,t:1527271891037};\\\", \\\"{x:1550,y:980,t:1527271891054};\\\", \\\"{x:1555,y:980,t:1527271891071};\\\", \\\"{x:1560,y:980,t:1527271891087};\\\", \\\"{x:1565,y:980,t:1527271891103};\\\", \\\"{x:1570,y:980,t:1527271891121};\\\", \\\"{x:1576,y:978,t:1527271891137};\\\", \\\"{x:1583,y:976,t:1527271891153};\\\", \\\"{x:1591,y:973,t:1527271891171};\\\", \\\"{x:1595,y:971,t:1527271891188};\\\", \\\"{x:1600,y:968,t:1527271891204};\\\", \\\"{x:1604,y:965,t:1527271891221};\\\", \\\"{x:1605,y:964,t:1527271891238};\\\", \\\"{x:1605,y:963,t:1527271891254};\\\", \\\"{x:1605,y:962,t:1527271891272};\\\", \\\"{x:1606,y:962,t:1527271891288};\\\", \\\"{x:1606,y:961,t:1527271891320};\\\", \\\"{x:1607,y:961,t:1527271891880};\\\", \\\"{x:1608,y:962,t:1527271891888};\\\", \\\"{x:1612,y:967,t:1527271891905};\\\", \\\"{x:1614,y:968,t:1527271891922};\\\", \\\"{x:1616,y:968,t:1527271891939};\\\", \\\"{x:1617,y:968,t:1527271892096};\\\", \\\"{x:1617,y:967,t:1527271892135};\\\", \\\"{x:1617,y:966,t:1527271892392};\\\", \\\"{x:1617,y:965,t:1527271892408};\\\", \\\"{x:1617,y:964,t:1527271892422};\\\", \\\"{x:1617,y:963,t:1527271892440};\\\", \\\"{x:1617,y:961,t:1527271892456};\\\", \\\"{x:1617,y:960,t:1527271892703};\\\", \\\"{x:1617,y:959,t:1527271892711};\\\", \\\"{x:1617,y:958,t:1527271892722};\\\", \\\"{x:1617,y:957,t:1527271892840};\\\", \\\"{x:1617,y:955,t:1527271892855};\\\", \\\"{x:1616,y:954,t:1527271892872};\\\", \\\"{x:1614,y:951,t:1527271892890};\\\", \\\"{x:1613,y:948,t:1527271892905};\\\", \\\"{x:1612,y:946,t:1527271892922};\\\", \\\"{x:1611,y:944,t:1527271892939};\\\", \\\"{x:1609,y:939,t:1527271892955};\\\", \\\"{x:1607,y:935,t:1527271892972};\\\", \\\"{x:1607,y:929,t:1527271892990};\\\", \\\"{x:1606,y:919,t:1527271893005};\\\", \\\"{x:1603,y:905,t:1527271893023};\\\", \\\"{x:1602,y:888,t:1527271893040};\\\", \\\"{x:1601,y:882,t:1527271893056};\\\", \\\"{x:1600,y:875,t:1527271893072};\\\", \\\"{x:1598,y:866,t:1527271893089};\\\", \\\"{x:1598,y:857,t:1527271893105};\\\", \\\"{x:1596,y:843,t:1527271893122};\\\", \\\"{x:1594,y:834,t:1527271893139};\\\", \\\"{x:1593,y:824,t:1527271893155};\\\", \\\"{x:1593,y:812,t:1527271893171};\\\", \\\"{x:1593,y:799,t:1527271893189};\\\", \\\"{x:1593,y:786,t:1527271893204};\\\", \\\"{x:1593,y:776,t:1527271893222};\\\", \\\"{x:1593,y:756,t:1527271893239};\\\", \\\"{x:1593,y:736,t:1527271893255};\\\", \\\"{x:1593,y:717,t:1527271893272};\\\", \\\"{x:1593,y:704,t:1527271893289};\\\", \\\"{x:1593,y:696,t:1527271893306};\\\", \\\"{x:1594,y:688,t:1527271893323};\\\", \\\"{x:1594,y:681,t:1527271893339};\\\", \\\"{x:1594,y:677,t:1527271893356};\\\", \\\"{x:1596,y:672,t:1527271893373};\\\", \\\"{x:1597,y:667,t:1527271893390};\\\", \\\"{x:1597,y:660,t:1527271893407};\\\", \\\"{x:1597,y:652,t:1527271893422};\\\", \\\"{x:1597,y:635,t:1527271893440};\\\", \\\"{x:1596,y:630,t:1527271893456};\\\", \\\"{x:1596,y:626,t:1527271893473};\\\", \\\"{x:1596,y:620,t:1527271893490};\\\", \\\"{x:1596,y:615,t:1527271893506};\\\", \\\"{x:1596,y:604,t:1527271893523};\\\", \\\"{x:1596,y:593,t:1527271893540};\\\", \\\"{x:1596,y:576,t:1527271893556};\\\", \\\"{x:1592,y:557,t:1527271893572};\\\", \\\"{x:1585,y:537,t:1527271893588};\\\", \\\"{x:1577,y:522,t:1527271893606};\\\", \\\"{x:1573,y:512,t:1527271893622};\\\", \\\"{x:1570,y:506,t:1527271893639};\\\", \\\"{x:1570,y:502,t:1527271893656};\\\", \\\"{x:1568,y:496,t:1527271893672};\\\", \\\"{x:1567,y:490,t:1527271893689};\\\", \\\"{x:1566,y:482,t:1527271893706};\\\", \\\"{x:1564,y:476,t:1527271893723};\\\", \\\"{x:1563,y:471,t:1527271893739};\\\", \\\"{x:1563,y:466,t:1527271893756};\\\", \\\"{x:1563,y:461,t:1527271893773};\\\", \\\"{x:1563,y:455,t:1527271893790};\\\", \\\"{x:1563,y:447,t:1527271893806};\\\", \\\"{x:1560,y:433,t:1527271893823};\\\", \\\"{x:1558,y:424,t:1527271893839};\\\", \\\"{x:1555,y:415,t:1527271893857};\\\", \\\"{x:1553,y:410,t:1527271893873};\\\", \\\"{x:1553,y:405,t:1527271893889};\\\", \\\"{x:1551,y:403,t:1527271893906};\\\", \\\"{x:1550,y:402,t:1527271894000};\\\", \\\"{x:1544,y:405,t:1527271894007};\\\", \\\"{x:1510,y:446,t:1527271894024};\\\", \\\"{x:1450,y:520,t:1527271894040};\\\", \\\"{x:1352,y:613,t:1527271894057};\\\", \\\"{x:1225,y:701,t:1527271894073};\\\", \\\"{x:1125,y:747,t:1527271894089};\\\", \\\"{x:1048,y:770,t:1527271894106};\\\", \\\"{x:940,y:800,t:1527271894123};\\\", \\\"{x:839,y:834,t:1527271894139};\\\", \\\"{x:776,y:848,t:1527271894156};\\\", \\\"{x:726,y:854,t:1527271894173};\\\", \\\"{x:690,y:854,t:1527271894190};\\\", \\\"{x:660,y:854,t:1527271894206};\\\", \\\"{x:618,y:850,t:1527271894223};\\\", \\\"{x:589,y:841,t:1527271894240};\\\", \\\"{x:566,y:833,t:1527271894255};\\\", \\\"{x:542,y:823,t:1527271894273};\\\", \\\"{x:516,y:816,t:1527271894290};\\\", \\\"{x:494,y:808,t:1527271894306};\\\", \\\"{x:474,y:800,t:1527271894323};\\\", \\\"{x:445,y:790,t:1527271894340};\\\", \\\"{x:410,y:776,t:1527271894356};\\\", \\\"{x:376,y:761,t:1527271894373};\\\", \\\"{x:344,y:750,t:1527271894391};\\\", \\\"{x:315,y:736,t:1527271894406};\\\", \\\"{x:300,y:728,t:1527271894424};\\\", \\\"{x:300,y:727,t:1527271894440};\\\", \\\"{x:299,y:727,t:1527271894496};\\\", \\\"{x:298,y:724,t:1527271894507};\\\", \\\"{x:296,y:718,t:1527271894523};\\\", \\\"{x:295,y:712,t:1527271894541};\\\", \\\"{x:295,y:706,t:1527271894557};\\\", \\\"{x:295,y:702,t:1527271894574};\\\", \\\"{x:295,y:699,t:1527271894591};\\\", \\\"{x:295,y:695,t:1527271894607};\\\", \\\"{x:298,y:687,t:1527271894624};\\\", \\\"{x:303,y:683,t:1527271894640};\\\", \\\"{x:307,y:679,t:1527271894657};\\\", \\\"{x:310,y:679,t:1527271894673};\\\", \\\"{x:312,y:678,t:1527271894690};\\\", \\\"{x:315,y:676,t:1527271894707};\\\", \\\"{x:324,y:676,t:1527271894724};\\\", \\\"{x:342,y:676,t:1527271894741};\\\", \\\"{x:362,y:676,t:1527271894758};\\\", \\\"{x:382,y:677,t:1527271894773};\\\", \\\"{x:399,y:681,t:1527271894789};\\\", \\\"{x:427,y:692,t:1527271894806};\\\", \\\"{x:449,y:699,t:1527271894823};\\\", \\\"{x:470,y:704,t:1527271894840};\\\", \\\"{x:485,y:710,t:1527271894857};\\\", \\\"{x:490,y:713,t:1527271894873};\\\", \\\"{x:491,y:714,t:1527271894890};\\\", \\\"{x:491,y:715,t:1527271894907};\\\", \\\"{x:492,y:717,t:1527271894924};\\\", \\\"{x:493,y:720,t:1527271894940};\\\", \\\"{x:493,y:722,t:1527271894957};\\\", \\\"{x:495,y:726,t:1527271894974};\\\", \\\"{x:496,y:732,t:1527271894990};\\\", \\\"{x:502,y:742,t:1527271895007};\\\", \\\"{x:502,y:744,t:1527271895024};\\\", \\\"{x:503,y:746,t:1527271895040};\\\", \\\"{x:505,y:748,t:1527271895057};\\\", \\\"{x:506,y:749,t:1527271895078};\\\", \\\"{x:507,y:749,t:1527271895103};\\\", \\\"{x:508,y:749,t:1527271895127};\\\", \\\"{x:509,y:749,t:1527271895140};\\\", \\\"{x:511,y:748,t:1527271895157};\\\", \\\"{x:515,y:742,t:1527271895175};\\\", \\\"{x:519,y:734,t:1527271895191};\\\", \\\"{x:521,y:731,t:1527271895206};\\\", \\\"{x:521,y:727,t:1527271895223};\\\", \\\"{x:522,y:727,t:1527271895247};\\\" ] }, { \\\"rt\\\": 119141, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 432499, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -E -I -I -I -I -O -O -H -01 PM-O -O -I -Z -A -I -I -05 PM-06 PM-K -K -K -K -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:734,t:1527271904888};\\\", \\\"{x:577,y:784,t:1527271904906};\\\", \\\"{x:620,y:814,t:1527271904923};\\\", \\\"{x:651,y:828,t:1527271904940};\\\", \\\"{x:674,y:837,t:1527271904963};\\\", \\\"{x:675,y:837,t:1527271904981};\\\", \\\"{x:677,y:826,t:1527271905031};\\\", \\\"{x:697,y:777,t:1527271905046};\\\", \\\"{x:709,y:727,t:1527271905064};\\\", \\\"{x:710,y:690,t:1527271905080};\\\", \\\"{x:709,y:609,t:1527271905099};\\\", \\\"{x:685,y:559,t:1527271905114};\\\", \\\"{x:665,y:541,t:1527271905132};\\\", \\\"{x:657,y:534,t:1527271905148};\\\", \\\"{x:656,y:533,t:1527271905175};\\\", \\\"{x:655,y:537,t:1527271905279};\\\", \\\"{x:655,y:545,t:1527271905287};\\\", \\\"{x:655,y:551,t:1527271905299};\\\", \\\"{x:653,y:558,t:1527271905316};\\\", \\\"{x:653,y:560,t:1527271905332};\\\", \\\"{x:653,y:562,t:1527271905348};\\\", \\\"{x:653,y:561,t:1527271905440};\\\", \\\"{x:652,y:557,t:1527271905450};\\\", \\\"{x:648,y:550,t:1527271905466};\\\", \\\"{x:647,y:546,t:1527271905482};\\\", \\\"{x:645,y:544,t:1527271905499};\\\", \\\"{x:645,y:542,t:1527271905711};\\\", \\\"{x:648,y:541,t:1527271905719};\\\", \\\"{x:653,y:538,t:1527271905734};\\\", \\\"{x:668,y:538,t:1527271905750};\\\", \\\"{x:759,y:548,t:1527271905767};\\\", \\\"{x:911,y:570,t:1527271905784};\\\", \\\"{x:1162,y:605,t:1527271905800};\\\", \\\"{x:1479,y:649,t:1527271905816};\\\", \\\"{x:1818,y:693,t:1527271905833};\\\", \\\"{x:1919,y:705,t:1527271905850};\\\", \\\"{x:1919,y:729,t:1527271905866};\\\", \\\"{x:1919,y:740,t:1527271905883};\\\", \\\"{x:1919,y:745,t:1527271905900};\\\", \\\"{x:1915,y:745,t:1527271905943};\\\", \\\"{x:1904,y:745,t:1527271905951};\\\", \\\"{x:1891,y:745,t:1527271905966};\\\", \\\"{x:1798,y:745,t:1527271905984};\\\", \\\"{x:1706,y:745,t:1527271905999};\\\", \\\"{x:1564,y:739,t:1527271906017};\\\", \\\"{x:1418,y:724,t:1527271906032};\\\", \\\"{x:1282,y:703,t:1527271906050};\\\", \\\"{x:1168,y:683,t:1527271906066};\\\", \\\"{x:1090,y:661,t:1527271906083};\\\", \\\"{x:1046,y:641,t:1527271906100};\\\", \\\"{x:1027,y:628,t:1527271906117};\\\", \\\"{x:1019,y:622,t:1527271906134};\\\", \\\"{x:1018,y:614,t:1527271906150};\\\", \\\"{x:1018,y:596,t:1527271906167};\\\", \\\"{x:1022,y:583,t:1527271906183};\\\", \\\"{x:1026,y:573,t:1527271906200};\\\", \\\"{x:1036,y:555,t:1527271906216};\\\", \\\"{x:1047,y:544,t:1527271906236};\\\", \\\"{x:1085,y:514,t:1527271906263};\\\", \\\"{x:1096,y:506,t:1527271906270};\\\", \\\"{x:1106,y:500,t:1527271906282};\\\", \\\"{x:1124,y:487,t:1527271906300};\\\", \\\"{x:1144,y:473,t:1527271906316};\\\", \\\"{x:1175,y:453,t:1527271906333};\\\", \\\"{x:1207,y:436,t:1527271906349};\\\", \\\"{x:1237,y:417,t:1527271906367};\\\", \\\"{x:1270,y:400,t:1527271906383};\\\", \\\"{x:1286,y:394,t:1527271906400};\\\", \\\"{x:1289,y:392,t:1527271906417};\\\", \\\"{x:1290,y:392,t:1527271906568};\\\", \\\"{x:1290,y:422,t:1527271906583};\\\", \\\"{x:1296,y:463,t:1527271906600};\\\", \\\"{x:1307,y:501,t:1527271906617};\\\", \\\"{x:1316,y:523,t:1527271906635};\\\", \\\"{x:1320,y:531,t:1527271906650};\\\", \\\"{x:1321,y:534,t:1527271906667};\\\", \\\"{x:1323,y:533,t:1527271906831};\\\", \\\"{x:1324,y:521,t:1527271906839};\\\", \\\"{x:1324,y:508,t:1527271906850};\\\", \\\"{x:1324,y:489,t:1527271906866};\\\", \\\"{x:1324,y:480,t:1527271906884};\\\", \\\"{x:1324,y:477,t:1527271906901};\\\", \\\"{x:1324,y:479,t:1527271907033};\\\", \\\"{x:1324,y:480,t:1527271907039};\\\", \\\"{x:1324,y:483,t:1527271907051};\\\", \\\"{x:1323,y:484,t:1527271907067};\\\", \\\"{x:1322,y:486,t:1527271907084};\\\", \\\"{x:1322,y:488,t:1527271907103};\\\", \\\"{x:1321,y:488,t:1527271907135};\\\", \\\"{x:1321,y:489,t:1527271907151};\\\", \\\"{x:1319,y:490,t:1527271907167};\\\", \\\"{x:1318,y:492,t:1527271907203};\\\", \\\"{x:1318,y:493,t:1527271907233};\\\", \\\"{x:1317,y:493,t:1527271907250};\\\", \\\"{x:1316,y:494,t:1527271907286};\\\", \\\"{x:1314,y:494,t:1527271907953};\\\", \\\"{x:1313,y:496,t:1527271907968};\\\", \\\"{x:1313,y:497,t:1527271907985};\\\", \\\"{x:1312,y:499,t:1527271908001};\\\", \\\"{x:1312,y:500,t:1527271908023};\\\", \\\"{x:1312,y:501,t:1527271908035};\\\", \\\"{x:1312,y:503,t:1527271908053};\\\", \\\"{x:1312,y:506,t:1527271908068};\\\", \\\"{x:1312,y:508,t:1527271908085};\\\", \\\"{x:1311,y:509,t:1527271908101};\\\", \\\"{x:1311,y:511,t:1527271908118};\\\", \\\"{x:1310,y:514,t:1527271908136};\\\", \\\"{x:1310,y:517,t:1527271908151};\\\", \\\"{x:1310,y:523,t:1527271908168};\\\", \\\"{x:1310,y:525,t:1527271908185};\\\", \\\"{x:1310,y:529,t:1527271908203};\\\", \\\"{x:1310,y:531,t:1527271908218};\\\", \\\"{x:1310,y:533,t:1527271908235};\\\", \\\"{x:1310,y:537,t:1527271908252};\\\", \\\"{x:1310,y:545,t:1527271908267};\\\", \\\"{x:1310,y:552,t:1527271908285};\\\", \\\"{x:1310,y:559,t:1527271908302};\\\", \\\"{x:1310,y:563,t:1527271908318};\\\", \\\"{x:1310,y:566,t:1527271908336};\\\", \\\"{x:1310,y:569,t:1527271908352};\\\", \\\"{x:1310,y:573,t:1527271908368};\\\", \\\"{x:1309,y:577,t:1527271908385};\\\", \\\"{x:1309,y:584,t:1527271908403};\\\", \\\"{x:1309,y:588,t:1527271908419};\\\", \\\"{x:1306,y:595,t:1527271908435};\\\", \\\"{x:1306,y:600,t:1527271908452};\\\", \\\"{x:1305,y:603,t:1527271908468};\\\", \\\"{x:1305,y:607,t:1527271908485};\\\", \\\"{x:1305,y:611,t:1527271908503};\\\", \\\"{x:1305,y:620,t:1527271908519};\\\", \\\"{x:1305,y:623,t:1527271908535};\\\", \\\"{x:1305,y:627,t:1527271908551};\\\", \\\"{x:1305,y:630,t:1527271908569};\\\", \\\"{x:1305,y:635,t:1527271908585};\\\", \\\"{x:1305,y:640,t:1527271908602};\\\", \\\"{x:1305,y:644,t:1527271908619};\\\", \\\"{x:1305,y:648,t:1527271908634};\\\", \\\"{x:1305,y:652,t:1527271908652};\\\", \\\"{x:1305,y:655,t:1527271908668};\\\", \\\"{x:1305,y:658,t:1527271908685};\\\", \\\"{x:1305,y:661,t:1527271908702};\\\", \\\"{x:1305,y:668,t:1527271908719};\\\", \\\"{x:1305,y:671,t:1527271908735};\\\", \\\"{x:1305,y:684,t:1527271908752};\\\", \\\"{x:1307,y:691,t:1527271908768};\\\", \\\"{x:1307,y:696,t:1527271908785};\\\", \\\"{x:1308,y:700,t:1527271908803};\\\", \\\"{x:1310,y:709,t:1527271908819};\\\", \\\"{x:1312,y:717,t:1527271908836};\\\", \\\"{x:1316,y:728,t:1527271908852};\\\", \\\"{x:1320,y:740,t:1527271908869};\\\", \\\"{x:1321,y:750,t:1527271908887};\\\", \\\"{x:1322,y:755,t:1527271908903};\\\", \\\"{x:1322,y:758,t:1527271908919};\\\", \\\"{x:1322,y:761,t:1527271908935};\\\", \\\"{x:1322,y:767,t:1527271908952};\\\", \\\"{x:1322,y:774,t:1527271908969};\\\", \\\"{x:1322,y:778,t:1527271908986};\\\", \\\"{x:1322,y:782,t:1527271909002};\\\", \\\"{x:1322,y:785,t:1527271909019};\\\", \\\"{x:1322,y:787,t:1527271909036};\\\", \\\"{x:1322,y:788,t:1527271909080};\\\", \\\"{x:1322,y:791,t:1527271909095};\\\", \\\"{x:1322,y:792,t:1527271909112};\\\", \\\"{x:1322,y:793,t:1527271909119};\\\", \\\"{x:1322,y:795,t:1527271909136};\\\", \\\"{x:1322,y:796,t:1527271909152};\\\", \\\"{x:1322,y:800,t:1527271909170};\\\", \\\"{x:1322,y:805,t:1527271909187};\\\", \\\"{x:1322,y:809,t:1527271909202};\\\", \\\"{x:1322,y:814,t:1527271909220};\\\", \\\"{x:1322,y:815,t:1527271909236};\\\", \\\"{x:1322,y:816,t:1527271909328};\\\", \\\"{x:1322,y:817,t:1527271909344};\\\", \\\"{x:1322,y:818,t:1527271909368};\\\", \\\"{x:1323,y:819,t:1527271909416};\\\", \\\"{x:1324,y:820,t:1527271909424};\\\", \\\"{x:1324,y:821,t:1527271909447};\\\", \\\"{x:1324,y:822,t:1527271909511};\\\", \\\"{x:1324,y:823,t:1527271909518};\\\", \\\"{x:1324,y:827,t:1527271909535};\\\", \\\"{x:1324,y:828,t:1527271909553};\\\", \\\"{x:1324,y:830,t:1527271909569};\\\", \\\"{x:1324,y:833,t:1527271910297};\\\", \\\"{x:1324,y:834,t:1527271910304};\\\", \\\"{x:1324,y:836,t:1527271910320};\\\", \\\"{x:1324,y:837,t:1527271910337};\\\", \\\"{x:1323,y:839,t:1527271910353};\\\", \\\"{x:1323,y:840,t:1527271910440};\\\", \\\"{x:1323,y:841,t:1527271910472};\\\", \\\"{x:1323,y:843,t:1527271910488};\\\", \\\"{x:1323,y:845,t:1527271910512};\\\", \\\"{x:1323,y:846,t:1527271910520};\\\", \\\"{x:1323,y:849,t:1527271910537};\\\", \\\"{x:1323,y:850,t:1527271910554};\\\", \\\"{x:1323,y:852,t:1527271910571};\\\", \\\"{x:1323,y:853,t:1527271910587};\\\", \\\"{x:1323,y:855,t:1527271910604};\\\", \\\"{x:1323,y:856,t:1527271910620};\\\", \\\"{x:1323,y:858,t:1527271910639};\\\", \\\"{x:1323,y:859,t:1527271910680};\\\", \\\"{x:1323,y:861,t:1527271910688};\\\", \\\"{x:1323,y:864,t:1527271910704};\\\", \\\"{x:1323,y:867,t:1527271910720};\\\", \\\"{x:1323,y:868,t:1527271910738};\\\", \\\"{x:1322,y:870,t:1527271910754};\\\", \\\"{x:1321,y:872,t:1527271910770};\\\", \\\"{x:1321,y:875,t:1527271910787};\\\", \\\"{x:1321,y:878,t:1527271910804};\\\", \\\"{x:1320,y:882,t:1527271910820};\\\", \\\"{x:1320,y:884,t:1527271910838};\\\", \\\"{x:1320,y:886,t:1527271910855};\\\", \\\"{x:1319,y:890,t:1527271910871};\\\", \\\"{x:1318,y:895,t:1527271910888};\\\", \\\"{x:1318,y:898,t:1527271910903};\\\", \\\"{x:1317,y:902,t:1527271910922};\\\", \\\"{x:1316,y:905,t:1527271910937};\\\", \\\"{x:1315,y:907,t:1527271910953};\\\", \\\"{x:1315,y:909,t:1527271910971};\\\", \\\"{x:1315,y:911,t:1527271910987};\\\", \\\"{x:1315,y:916,t:1527271911004};\\\", \\\"{x:1315,y:920,t:1527271911021};\\\", \\\"{x:1315,y:926,t:1527271911037};\\\", \\\"{x:1317,y:930,t:1527271911054};\\\", \\\"{x:1317,y:932,t:1527271911070};\\\", \\\"{x:1317,y:933,t:1527271911087};\\\", \\\"{x:1317,y:936,t:1527271911104};\\\", \\\"{x:1317,y:940,t:1527271911121};\\\", \\\"{x:1317,y:945,t:1527271911137};\\\", \\\"{x:1317,y:949,t:1527271911154};\\\", \\\"{x:1317,y:950,t:1527271911240};\\\", \\\"{x:1317,y:952,t:1527271911254};\\\", \\\"{x:1317,y:954,t:1527271911296};\\\", \\\"{x:1317,y:955,t:1527271911304};\\\", \\\"{x:1317,y:957,t:1527271911322};\\\", \\\"{x:1317,y:958,t:1527271911344};\\\", \\\"{x:1317,y:960,t:1527271911392};\\\", \\\"{x:1317,y:961,t:1527271911404};\\\", \\\"{x:1317,y:964,t:1527271911422};\\\", \\\"{x:1317,y:966,t:1527271911439};\\\", \\\"{x:1317,y:968,t:1527271918320};\\\", \\\"{x:1316,y:969,t:1527271918368};\\\", \\\"{x:1311,y:969,t:1527271921096};\\\", \\\"{x:1281,y:963,t:1527271921113};\\\", \\\"{x:1236,y:956,t:1527271921130};\\\", \\\"{x:1204,y:951,t:1527271921146};\\\", \\\"{x:1182,y:947,t:1527271921163};\\\", \\\"{x:1175,y:946,t:1527271921180};\\\", \\\"{x:1176,y:946,t:1527271921280};\\\", \\\"{x:1181,y:946,t:1527271921297};\\\", \\\"{x:1185,y:949,t:1527271921313};\\\", \\\"{x:1193,y:953,t:1527271921330};\\\", \\\"{x:1198,y:956,t:1527271921347};\\\", \\\"{x:1201,y:958,t:1527271921363};\\\", \\\"{x:1201,y:959,t:1527271921383};\\\", \\\"{x:1201,y:961,t:1527271921432};\\\", \\\"{x:1201,y:962,t:1527271921455};\\\", \\\"{x:1200,y:964,t:1527271921472};\\\", \\\"{x:1199,y:964,t:1527271921480};\\\", \\\"{x:1198,y:965,t:1527271921497};\\\", \\\"{x:1196,y:966,t:1527271921513};\\\", \\\"{x:1195,y:966,t:1527271921530};\\\", \\\"{x:1191,y:967,t:1527271921546};\\\", \\\"{x:1189,y:969,t:1527271921563};\\\", \\\"{x:1187,y:969,t:1527271921579};\\\", \\\"{x:1186,y:969,t:1527271921596};\\\", \\\"{x:1184,y:971,t:1527271921614};\\\", \\\"{x:1183,y:971,t:1527271921639};\\\", \\\"{x:1182,y:971,t:1527271921647};\\\", \\\"{x:1182,y:969,t:1527271922184};\\\", \\\"{x:1183,y:968,t:1527271922198};\\\", \\\"{x:1185,y:967,t:1527271922214};\\\", \\\"{x:1191,y:965,t:1527271922231};\\\", \\\"{x:1192,y:964,t:1527271922247};\\\", \\\"{x:1193,y:964,t:1527271922264};\\\", \\\"{x:1195,y:964,t:1527271922287};\\\", \\\"{x:1195,y:963,t:1527271922303};\\\", \\\"{x:1196,y:963,t:1527271922313};\\\", \\\"{x:1198,y:962,t:1527271922331};\\\", \\\"{x:1199,y:961,t:1527271922348};\\\", \\\"{x:1200,y:961,t:1527271922391};\\\", \\\"{x:1201,y:960,t:1527271922400};\\\", \\\"{x:1202,y:960,t:1527271922414};\\\", \\\"{x:1204,y:960,t:1527271922431};\\\", \\\"{x:1205,y:960,t:1527271922447};\\\", \\\"{x:1206,y:960,t:1527271922480};\\\", \\\"{x:1207,y:960,t:1527271922504};\\\", \\\"{x:1208,y:960,t:1527271922520};\\\", \\\"{x:1208,y:961,t:1527271922576};\\\", \\\"{x:1209,y:962,t:1527271922591};\\\", \\\"{x:1209,y:963,t:1527271922657};\\\", \\\"{x:1210,y:964,t:1527271922664};\\\", \\\"{x:1210,y:965,t:1527271922682};\\\", \\\"{x:1211,y:967,t:1527271922697};\\\", \\\"{x:1212,y:968,t:1527271922727};\\\", \\\"{x:1213,y:968,t:1527271923080};\\\", \\\"{x:1214,y:968,t:1527271923098};\\\", \\\"{x:1215,y:968,t:1527271923119};\\\", \\\"{x:1215,y:967,t:1527271923136};\\\", \\\"{x:1215,y:966,t:1527271923176};\\\", \\\"{x:1215,y:965,t:1527271923791};\\\", \\\"{x:1215,y:966,t:1527271930752};\\\", \\\"{x:1214,y:967,t:1527271930824};\\\", \\\"{x:1212,y:968,t:1527271930960};\\\", \\\"{x:1213,y:954,t:1527271934344};\\\", \\\"{x:1220,y:910,t:1527271934358};\\\", \\\"{x:1233,y:824,t:1527271934374};\\\", \\\"{x:1252,y:765,t:1527271934391};\\\", \\\"{x:1258,y:752,t:1527271934407};\\\", \\\"{x:1266,y:738,t:1527271934424};\\\", \\\"{x:1273,y:726,t:1527271934441};\\\", \\\"{x:1278,y:720,t:1527271934458};\\\", \\\"{x:1282,y:716,t:1527271934474};\\\", \\\"{x:1284,y:712,t:1527271934492};\\\", \\\"{x:1285,y:709,t:1527271934507};\\\", \\\"{x:1286,y:707,t:1527271934525};\\\", \\\"{x:1288,y:705,t:1527271934542};\\\", \\\"{x:1288,y:704,t:1527271934559};\\\", \\\"{x:1290,y:702,t:1527271935640};\\\", \\\"{x:1297,y:699,t:1527271935647};\\\", \\\"{x:1309,y:694,t:1527271935659};\\\", \\\"{x:1341,y:679,t:1527271935675};\\\", \\\"{x:1402,y:660,t:1527271935692};\\\", \\\"{x:1479,y:632,t:1527271935708};\\\", \\\"{x:1547,y:607,t:1527271935725};\\\", \\\"{x:1590,y:583,t:1527271935742};\\\", \\\"{x:1612,y:568,t:1527271935759};\\\", \\\"{x:1619,y:559,t:1527271935777};\\\", \\\"{x:1619,y:554,t:1527271935793};\\\", \\\"{x:1619,y:546,t:1527271935809};\\\", \\\"{x:1607,y:532,t:1527271935826};\\\", \\\"{x:1582,y:515,t:1527271935843};\\\", \\\"{x:1540,y:494,t:1527271935859};\\\", \\\"{x:1501,y:477,t:1527271935875};\\\", \\\"{x:1472,y:470,t:1527271935892};\\\", \\\"{x:1447,y:465,t:1527271935909};\\\", \\\"{x:1428,y:465,t:1527271935926};\\\", \\\"{x:1414,y:465,t:1527271935943};\\\", \\\"{x:1394,y:467,t:1527271935959};\\\", \\\"{x:1378,y:476,t:1527271935975};\\\", \\\"{x:1358,y:486,t:1527271935992};\\\", \\\"{x:1336,y:495,t:1527271936009};\\\", \\\"{x:1316,y:504,t:1527271936025};\\\", \\\"{x:1300,y:510,t:1527271936043};\\\", \\\"{x:1296,y:511,t:1527271936059};\\\", \\\"{x:1293,y:513,t:1527271936076};\\\", \\\"{x:1291,y:513,t:1527271936112};\\\", \\\"{x:1289,y:514,t:1527271936125};\\\", \\\"{x:1293,y:514,t:1527271936216};\\\", \\\"{x:1297,y:510,t:1527271936226};\\\", \\\"{x:1310,y:499,t:1527271936243};\\\", \\\"{x:1319,y:489,t:1527271936260};\\\", \\\"{x:1323,y:485,t:1527271936276};\\\", \\\"{x:1327,y:482,t:1527271936292};\\\", \\\"{x:1325,y:482,t:1527271936408};\\\", \\\"{x:1324,y:482,t:1527271936416};\\\", \\\"{x:1322,y:483,t:1527271936426};\\\", \\\"{x:1319,y:485,t:1527271936442};\\\", \\\"{x:1317,y:486,t:1527271936460};\\\", \\\"{x:1315,y:487,t:1527271936476};\\\", \\\"{x:1314,y:488,t:1527271936493};\\\", \\\"{x:1313,y:488,t:1527271936720};\\\", \\\"{x:1312,y:489,t:1527271936727};\\\", \\\"{x:1312,y:490,t:1527271936742};\\\", \\\"{x:1312,y:495,t:1527271936759};\\\", \\\"{x:1312,y:497,t:1527271936776};\\\", \\\"{x:1312,y:500,t:1527271936793};\\\", \\\"{x:1312,y:501,t:1527271936809};\\\", \\\"{x:1312,y:502,t:1527271936826};\\\", \\\"{x:1313,y:503,t:1527271937279};\\\", \\\"{x:1314,y:502,t:1527271937319};\\\", \\\"{x:1315,y:502,t:1527271937358};\\\", \\\"{x:1315,y:503,t:1527271939064};\\\", \\\"{x:1315,y:507,t:1527271939078};\\\", \\\"{x:1315,y:514,t:1527271939093};\\\", \\\"{x:1313,y:517,t:1527271939111};\\\", \\\"{x:1313,y:518,t:1527271939127};\\\", \\\"{x:1313,y:520,t:1527271939145};\\\", \\\"{x:1313,y:524,t:1527271939161};\\\", \\\"{x:1312,y:531,t:1527271939178};\\\", \\\"{x:1311,y:540,t:1527271939195};\\\", \\\"{x:1309,y:548,t:1527271939211};\\\", \\\"{x:1307,y:557,t:1527271939228};\\\", \\\"{x:1306,y:563,t:1527271939245};\\\", \\\"{x:1305,y:570,t:1527271939261};\\\", \\\"{x:1304,y:575,t:1527271939278};\\\", \\\"{x:1302,y:583,t:1527271939294};\\\", \\\"{x:1301,y:589,t:1527271939311};\\\", \\\"{x:1300,y:594,t:1527271939328};\\\", \\\"{x:1300,y:601,t:1527271939345};\\\", \\\"{x:1297,y:610,t:1527271939361};\\\", \\\"{x:1293,y:621,t:1527271939378};\\\", \\\"{x:1292,y:628,t:1527271939395};\\\", \\\"{x:1291,y:638,t:1527271939411};\\\", \\\"{x:1291,y:645,t:1527271939428};\\\", \\\"{x:1291,y:653,t:1527271939445};\\\", \\\"{x:1291,y:657,t:1527271939461};\\\", \\\"{x:1291,y:660,t:1527271939478};\\\", \\\"{x:1291,y:664,t:1527271939495};\\\", \\\"{x:1292,y:666,t:1527271939512};\\\", \\\"{x:1292,y:669,t:1527271939528};\\\", \\\"{x:1292,y:670,t:1527271939545};\\\", \\\"{x:1292,y:671,t:1527271939562};\\\", \\\"{x:1292,y:672,t:1527271939578};\\\", \\\"{x:1292,y:673,t:1527271939595};\\\", \\\"{x:1292,y:675,t:1527271939612};\\\", \\\"{x:1293,y:675,t:1527271939702};\\\", \\\"{x:1295,y:675,t:1527271939712};\\\", \\\"{x:1299,y:666,t:1527271939728};\\\", \\\"{x:1304,y:656,t:1527271939745};\\\", \\\"{x:1306,y:644,t:1527271939762};\\\", \\\"{x:1307,y:634,t:1527271939778};\\\", \\\"{x:1309,y:629,t:1527271939795};\\\", \\\"{x:1309,y:626,t:1527271939812};\\\", \\\"{x:1309,y:625,t:1527271939828};\\\", \\\"{x:1309,y:627,t:1527271940063};\\\", \\\"{x:1308,y:633,t:1527271940079};\\\", \\\"{x:1308,y:637,t:1527271940095};\\\", \\\"{x:1308,y:640,t:1527271940112};\\\", \\\"{x:1308,y:642,t:1527271940129};\\\", \\\"{x:1308,y:645,t:1527271940145};\\\", \\\"{x:1308,y:649,t:1527271940162};\\\", \\\"{x:1308,y:657,t:1527271940179};\\\", \\\"{x:1308,y:665,t:1527271940195};\\\", \\\"{x:1308,y:673,t:1527271940212};\\\", \\\"{x:1308,y:677,t:1527271940229};\\\", \\\"{x:1308,y:682,t:1527271940245};\\\", \\\"{x:1308,y:684,t:1527271940262};\\\", \\\"{x:1308,y:688,t:1527271940278};\\\", \\\"{x:1308,y:694,t:1527271940296};\\\", \\\"{x:1308,y:704,t:1527271940312};\\\", \\\"{x:1308,y:716,t:1527271940329};\\\", \\\"{x:1308,y:725,t:1527271940346};\\\", \\\"{x:1308,y:735,t:1527271940361};\\\", \\\"{x:1308,y:746,t:1527271940379};\\\", \\\"{x:1308,y:758,t:1527271940395};\\\", \\\"{x:1308,y:765,t:1527271940412};\\\", \\\"{x:1308,y:775,t:1527271940429};\\\", \\\"{x:1308,y:784,t:1527271940446};\\\", \\\"{x:1308,y:797,t:1527271940462};\\\", \\\"{x:1308,y:811,t:1527271940479};\\\", \\\"{x:1309,y:820,t:1527271940496};\\\", \\\"{x:1309,y:822,t:1527271940512};\\\", \\\"{x:1309,y:823,t:1527271940529};\\\", \\\"{x:1309,y:826,t:1527271940545};\\\", \\\"{x:1309,y:830,t:1527271940562};\\\", \\\"{x:1309,y:834,t:1527271940579};\\\", \\\"{x:1309,y:837,t:1527271940596};\\\", \\\"{x:1309,y:839,t:1527271940612};\\\", \\\"{x:1309,y:845,t:1527271940629};\\\", \\\"{x:1309,y:855,t:1527271940646};\\\", \\\"{x:1314,y:870,t:1527271940663};\\\", \\\"{x:1315,y:874,t:1527271940679};\\\", \\\"{x:1315,y:876,t:1527271940696};\\\", \\\"{x:1315,y:878,t:1527271940712};\\\", \\\"{x:1315,y:880,t:1527271940729};\\\", \\\"{x:1315,y:885,t:1527271940745};\\\", \\\"{x:1315,y:890,t:1527271940762};\\\", \\\"{x:1315,y:895,t:1527271940779};\\\", \\\"{x:1315,y:900,t:1527271940796};\\\", \\\"{x:1315,y:901,t:1527271940813};\\\", \\\"{x:1315,y:903,t:1527271940829};\\\", \\\"{x:1315,y:905,t:1527271940846};\\\", \\\"{x:1316,y:908,t:1527271940862};\\\", \\\"{x:1316,y:912,t:1527271940879};\\\", \\\"{x:1316,y:915,t:1527271940896};\\\", \\\"{x:1317,y:918,t:1527271940913};\\\", \\\"{x:1317,y:920,t:1527271940929};\\\", \\\"{x:1317,y:922,t:1527271940946};\\\", \\\"{x:1318,y:923,t:1527271940963};\\\", \\\"{x:1319,y:926,t:1527271940979};\\\", \\\"{x:1319,y:930,t:1527271940996};\\\", \\\"{x:1319,y:935,t:1527271941013};\\\", \\\"{x:1321,y:939,t:1527271941029};\\\", \\\"{x:1321,y:943,t:1527271941046};\\\", \\\"{x:1322,y:946,t:1527271941062};\\\", \\\"{x:1322,y:950,t:1527271941079};\\\", \\\"{x:1322,y:953,t:1527271941096};\\\", \\\"{x:1323,y:958,t:1527271941113};\\\", \\\"{x:1323,y:961,t:1527271941129};\\\", \\\"{x:1323,y:962,t:1527271941151};\\\", \\\"{x:1323,y:964,t:1527271941163};\\\", \\\"{x:1323,y:965,t:1527271941180};\\\", \\\"{x:1323,y:967,t:1527271941196};\\\", \\\"{x:1323,y:968,t:1527271941213};\\\", \\\"{x:1323,y:970,t:1527271941230};\\\", \\\"{x:1323,y:972,t:1527271941245};\\\", \\\"{x:1322,y:972,t:1527271941959};\\\", \\\"{x:1321,y:971,t:1527271941983};\\\", \\\"{x:1321,y:970,t:1527271942006};\\\", \\\"{x:1321,y:969,t:1527271942022};\\\", \\\"{x:1321,y:968,t:1527271942030};\\\", \\\"{x:1320,y:967,t:1527271942046};\\\", \\\"{x:1319,y:967,t:1527271942064};\\\", \\\"{x:1319,y:965,t:1527271942080};\\\", \\\"{x:1319,y:964,t:1527271942103};\\\", \\\"{x:1319,y:963,t:1527271942126};\\\", \\\"{x:1319,y:962,t:1527271942134};\\\", \\\"{x:1319,y:961,t:1527271942214};\\\", \\\"{x:1318,y:960,t:1527271942230};\\\", \\\"{x:1318,y:959,t:1527271943338};\\\", \\\"{x:1318,y:957,t:1527271943354};\\\", \\\"{x:1317,y:956,t:1527271943368};\\\", \\\"{x:1317,y:955,t:1527271943385};\\\", \\\"{x:1317,y:953,t:1527271943466};\\\", \\\"{x:1317,y:952,t:1527271943489};\\\", \\\"{x:1317,y:950,t:1527271943578};\\\", \\\"{x:1317,y:949,t:1527271945218};\\\", \\\"{x:1316,y:949,t:1527271945226};\\\", \\\"{x:1316,y:950,t:1527271945241};\\\", \\\"{x:1316,y:951,t:1527271945252};\\\", \\\"{x:1315,y:952,t:1527271945270};\\\", \\\"{x:1315,y:953,t:1527271945286};\\\", \\\"{x:1315,y:954,t:1527271945303};\\\", \\\"{x:1315,y:955,t:1527271945410};\\\", \\\"{x:1315,y:953,t:1527271948915};\\\", \\\"{x:1315,y:952,t:1527271948930};\\\", \\\"{x:1316,y:951,t:1527271948940};\\\", \\\"{x:1316,y:950,t:1527271949026};\\\", \\\"{x:1316,y:948,t:1527271949090};\\\", \\\"{x:1317,y:948,t:1527271949153};\\\", \\\"{x:1317,y:947,t:1527271949169};\\\", \\\"{x:1317,y:946,t:1527271949201};\\\", \\\"{x:1317,y:944,t:1527271949282};\\\", \\\"{x:1318,y:942,t:1527271950643};\\\", \\\"{x:1322,y:940,t:1527271950658};\\\", \\\"{x:1323,y:940,t:1527271950675};\\\", \\\"{x:1329,y:939,t:1527271950691};\\\", \\\"{x:1341,y:940,t:1527271950708};\\\", \\\"{x:1362,y:943,t:1527271950726};\\\", \\\"{x:1393,y:953,t:1527271950742};\\\", \\\"{x:1448,y:967,t:1527271950758};\\\", \\\"{x:1526,y:988,t:1527271950774};\\\", \\\"{x:1605,y:1006,t:1527271950790};\\\", \\\"{x:1664,y:1014,t:1527271950808};\\\", \\\"{x:1708,y:1017,t:1527271950824};\\\", \\\"{x:1726,y:1019,t:1527271950841};\\\", \\\"{x:1731,y:1019,t:1527271950857};\\\", \\\"{x:1732,y:1017,t:1527271950922};\\\", \\\"{x:1732,y:1014,t:1527271950930};\\\", \\\"{x:1732,y:1012,t:1527271950941};\\\", \\\"{x:1732,y:1001,t:1527271950958};\\\", \\\"{x:1732,y:993,t:1527271950975};\\\", \\\"{x:1725,y:983,t:1527271950991};\\\", \\\"{x:1718,y:974,t:1527271951008};\\\", \\\"{x:1709,y:968,t:1527271951025};\\\", \\\"{x:1707,y:966,t:1527271951043};\\\", \\\"{x:1707,y:965,t:1527271951058};\\\", \\\"{x:1707,y:963,t:1527271951076};\\\", \\\"{x:1707,y:961,t:1527271951092};\\\", \\\"{x:1707,y:959,t:1527271951108};\\\", \\\"{x:1707,y:958,t:1527271951125};\\\", \\\"{x:1708,y:958,t:1527271951143};\\\", \\\"{x:1709,y:958,t:1527271951158};\\\", \\\"{x:1710,y:957,t:1527271951174};\\\", \\\"{x:1713,y:956,t:1527271951192};\\\", \\\"{x:1715,y:956,t:1527271951208};\\\", \\\"{x:1717,y:955,t:1527271951224};\\\", \\\"{x:1719,y:955,t:1527271951250};\\\", \\\"{x:1721,y:955,t:1527271951258};\\\", \\\"{x:1732,y:955,t:1527271951275};\\\", \\\"{x:1743,y:960,t:1527271951292};\\\", \\\"{x:1753,y:965,t:1527271951308};\\\", \\\"{x:1760,y:966,t:1527271951325};\\\", \\\"{x:1761,y:966,t:1527271951483};\\\", \\\"{x:1763,y:966,t:1527271951492};\\\", \\\"{x:1767,y:963,t:1527271951510};\\\", \\\"{x:1773,y:961,t:1527271951526};\\\", \\\"{x:1777,y:959,t:1527271951542};\\\", \\\"{x:1780,y:957,t:1527271951559};\\\", \\\"{x:1782,y:956,t:1527271951575};\\\", \\\"{x:1784,y:955,t:1527271951592};\\\", \\\"{x:1783,y:955,t:1527271951731};\\\", \\\"{x:1782,y:955,t:1527271951746};\\\", \\\"{x:1781,y:955,t:1527271951760};\\\", \\\"{x:1779,y:956,t:1527271951776};\\\", \\\"{x:1779,y:958,t:1527271952019};\\\", \\\"{x:1779,y:959,t:1527271952026};\\\", \\\"{x:1779,y:960,t:1527271952042};\\\", \\\"{x:1780,y:961,t:1527271952083};\\\", \\\"{x:1780,y:962,t:1527271952211};\\\", \\\"{x:1780,y:963,t:1527271952235};\\\", \\\"{x:1780,y:964,t:1527271953987};\\\", \\\"{x:1779,y:964,t:1527271954003};\\\", \\\"{x:1779,y:965,t:1527271954012};\\\", \\\"{x:1777,y:965,t:1527271954163};\\\", \\\"{x:1776,y:966,t:1527271954202};\\\", \\\"{x:1768,y:963,t:1527271969235};\\\", \\\"{x:1744,y:954,t:1527271969243};\\\", \\\"{x:1702,y:943,t:1527271969258};\\\", \\\"{x:1536,y:896,t:1527271969274};\\\", \\\"{x:1393,y:856,t:1527271969291};\\\", \\\"{x:1260,y:813,t:1527271969307};\\\", \\\"{x:1140,y:773,t:1527271969325};\\\", \\\"{x:1037,y:726,t:1527271969341};\\\", \\\"{x:954,y:685,t:1527271969357};\\\", \\\"{x:894,y:650,t:1527271969374};\\\", \\\"{x:848,y:625,t:1527271969392};\\\", \\\"{x:824,y:615,t:1527271969407};\\\", \\\"{x:809,y:609,t:1527271969423};\\\", \\\"{x:804,y:606,t:1527271969437};\\\", \\\"{x:804,y:605,t:1527271969514};\\\", \\\"{x:803,y:604,t:1527271969553};\\\", \\\"{x:801,y:603,t:1527271969562};\\\", \\\"{x:795,y:601,t:1527271969570};\\\", \\\"{x:771,y:595,t:1527271969588};\\\", \\\"{x:736,y:582,t:1527271969605};\\\", \\\"{x:673,y:565,t:1527271969622};\\\", \\\"{x:620,y:550,t:1527271969638};\\\", \\\"{x:588,y:544,t:1527271969655};\\\", \\\"{x:575,y:542,t:1527271969672};\\\", \\\"{x:575,y:543,t:1527271969803};\\\", \\\"{x:577,y:547,t:1527271969810};\\\", \\\"{x:580,y:551,t:1527271969823};\\\", \\\"{x:592,y:560,t:1527271969838};\\\", \\\"{x:607,y:571,t:1527271969855};\\\", \\\"{x:622,y:580,t:1527271969872};\\\", \\\"{x:633,y:585,t:1527271969888};\\\", \\\"{x:636,y:586,t:1527271969905};\\\", \\\"{x:635,y:585,t:1527271970074};\\\", \\\"{x:634,y:583,t:1527271970090};\\\", \\\"{x:632,y:581,t:1527271970105};\\\", \\\"{x:631,y:579,t:1527271970121};\\\", \\\"{x:630,y:578,t:1527271970225};\\\", \\\"{x:629,y:578,t:1527271970242};\\\", \\\"{x:629,y:577,t:1527271970255};\\\", \\\"{x:625,y:577,t:1527271970270};\\\", \\\"{x:622,y:577,t:1527271970288};\\\", \\\"{x:619,y:575,t:1527271970305};\\\", \\\"{x:617,y:575,t:1527271970321};\\\", \\\"{x:616,y:575,t:1527271970345};\\\", \\\"{x:617,y:574,t:1527271970609};\\\", \\\"{x:618,y:573,t:1527271970621};\\\", \\\"{x:620,y:573,t:1527271970690};\\\", \\\"{x:624,y:571,t:1527271970706};\\\", \\\"{x:628,y:571,t:1527271970722};\\\", \\\"{x:633,y:571,t:1527271970738};\\\", \\\"{x:637,y:571,t:1527271970755};\\\", \\\"{x:642,y:571,t:1527271970772};\\\", \\\"{x:651,y:571,t:1527271970789};\\\", \\\"{x:676,y:578,t:1527271970806};\\\", \\\"{x:721,y:585,t:1527271970821};\\\", \\\"{x:810,y:600,t:1527271970840};\\\", \\\"{x:918,y:614,t:1527271970856};\\\", \\\"{x:1046,y:635,t:1527271970872};\\\", \\\"{x:1191,y:642,t:1527271970889};\\\", \\\"{x:1402,y:646,t:1527271970906};\\\", \\\"{x:1510,y:646,t:1527271970922};\\\", \\\"{x:1579,y:646,t:1527271970939};\\\", \\\"{x:1614,y:646,t:1527271970956};\\\", \\\"{x:1627,y:645,t:1527271970972};\\\", \\\"{x:1630,y:644,t:1527271970989};\\\", \\\"{x:1630,y:642,t:1527271971123};\\\", \\\"{x:1607,y:627,t:1527271971139};\\\", \\\"{x:1531,y:585,t:1527271971156};\\\", \\\"{x:1433,y:551,t:1527271971172};\\\", \\\"{x:1357,y:537,t:1527271971189};\\\", \\\"{x:1309,y:535,t:1527271971205};\\\", \\\"{x:1278,y:535,t:1527271971222};\\\", \\\"{x:1272,y:535,t:1527271971238};\\\", \\\"{x:1273,y:537,t:1527271971346};\\\", \\\"{x:1278,y:543,t:1527271971356};\\\", \\\"{x:1296,y:559,t:1527271971373};\\\", \\\"{x:1319,y:570,t:1527271971389};\\\", \\\"{x:1351,y:582,t:1527271971406};\\\", \\\"{x:1379,y:588,t:1527271971423};\\\", \\\"{x:1404,y:593,t:1527271971439};\\\", \\\"{x:1423,y:594,t:1527271971456};\\\", \\\"{x:1427,y:594,t:1527271971474};\\\", \\\"{x:1429,y:594,t:1527271971490};\\\", \\\"{x:1430,y:594,t:1527271971539};\\\", \\\"{x:1430,y:591,t:1527271971557};\\\", \\\"{x:1430,y:589,t:1527271971574};\\\", \\\"{x:1430,y:587,t:1527271971589};\\\", \\\"{x:1429,y:584,t:1527271971606};\\\", \\\"{x:1428,y:582,t:1527271971623};\\\", \\\"{x:1426,y:580,t:1527271971639};\\\", \\\"{x:1424,y:579,t:1527271971656};\\\", \\\"{x:1424,y:577,t:1527271971673};\\\", \\\"{x:1424,y:575,t:1527271971786};\\\", \\\"{x:1424,y:574,t:1527271971794};\\\", \\\"{x:1424,y:573,t:1527271971806};\\\", \\\"{x:1424,y:572,t:1527271971823};\\\", \\\"{x:1423,y:571,t:1527271971866};\\\", \\\"{x:1422,y:570,t:1527271972115};\\\", \\\"{x:1420,y:569,t:1527271972123};\\\", \\\"{x:1417,y:568,t:1527271972140};\\\", \\\"{x:1416,y:567,t:1527271972156};\\\", \\\"{x:1414,y:567,t:1527271972178};\\\", \\\"{x:1414,y:575,t:1527271973786};\\\", \\\"{x:1414,y:590,t:1527271973793};\\\", \\\"{x:1414,y:605,t:1527271973806};\\\", \\\"{x:1414,y:634,t:1527271973823};\\\", \\\"{x:1414,y:664,t:1527271973840};\\\", \\\"{x:1416,y:699,t:1527271973857};\\\", \\\"{x:1422,y:744,t:1527271973873};\\\", \\\"{x:1428,y:782,t:1527271973891};\\\", \\\"{x:1428,y:852,t:1527271973906};\\\", \\\"{x:1420,y:945,t:1527271973924};\\\", \\\"{x:1409,y:1003,t:1527271973940};\\\", \\\"{x:1407,y:1023,t:1527271973957};\\\", \\\"{x:1406,y:1039,t:1527271973974};\\\", \\\"{x:1407,y:1045,t:1527271973991};\\\", \\\"{x:1414,y:1048,t:1527271974007};\\\", \\\"{x:1422,y:1051,t:1527271974024};\\\", \\\"{x:1426,y:1051,t:1527271974041};\\\", \\\"{x:1427,y:1051,t:1527271974057};\\\", \\\"{x:1427,y:1048,t:1527271974130};\\\", \\\"{x:1427,y:1047,t:1527271974142};\\\", \\\"{x:1427,y:1041,t:1527271974158};\\\", \\\"{x:1428,y:1030,t:1527271974174};\\\", \\\"{x:1430,y:1016,t:1527271974191};\\\", \\\"{x:1430,y:1000,t:1527271974208};\\\", \\\"{x:1434,y:984,t:1527271974225};\\\", \\\"{x:1441,y:968,t:1527271974242};\\\", \\\"{x:1445,y:956,t:1527271974257};\\\", \\\"{x:1446,y:954,t:1527271974274};\\\", \\\"{x:1447,y:956,t:1527271974475};\\\", \\\"{x:1447,y:964,t:1527271974492};\\\", \\\"{x:1447,y:971,t:1527271974509};\\\", \\\"{x:1447,y:973,t:1527271974524};\\\", \\\"{x:1447,y:974,t:1527271974542};\\\", \\\"{x:1448,y:974,t:1527271974857};\\\", \\\"{x:1448,y:973,t:1527271975003};\\\", \\\"{x:1448,y:972,t:1527271975010};\\\", \\\"{x:1448,y:971,t:1527271975025};\\\", \\\"{x:1448,y:970,t:1527271975049};\\\", \\\"{x:1448,y:969,t:1527271975065};\\\", \\\"{x:1448,y:968,t:1527271975113};\\\", \\\"{x:1449,y:967,t:1527271975145};\\\", \\\"{x:1449,y:966,t:1527271978354};\\\", \\\"{x:1446,y:964,t:1527271978363};\\\", \\\"{x:1437,y:958,t:1527271978377};\\\", \\\"{x:1399,y:941,t:1527271978393};\\\", \\\"{x:1243,y:874,t:1527271978410};\\\", \\\"{x:1092,y:821,t:1527271978427};\\\", \\\"{x:931,y:763,t:1527271978444};\\\", \\\"{x:781,y:710,t:1527271978460};\\\", \\\"{x:646,y:658,t:1527271978477};\\\", \\\"{x:532,y:601,t:1527271978494};\\\", \\\"{x:462,y:550,t:1527271978510};\\\", \\\"{x:426,y:518,t:1527271978545};\\\", \\\"{x:426,y:517,t:1527271978585};\\\", \\\"{x:426,y:516,t:1527271978609};\\\", \\\"{x:430,y:515,t:1527271978625};\\\", \\\"{x:433,y:514,t:1527271978633};\\\", \\\"{x:437,y:514,t:1527271978645};\\\", \\\"{x:452,y:514,t:1527271978662};\\\", \\\"{x:474,y:514,t:1527271978678};\\\", \\\"{x:505,y:519,t:1527271978695};\\\", \\\"{x:545,y:530,t:1527271978713};\\\", \\\"{x:578,y:538,t:1527271978728};\\\", \\\"{x:626,y:551,t:1527271978746};\\\", \\\"{x:648,y:555,t:1527271978762};\\\", \\\"{x:653,y:556,t:1527271978779};\\\", \\\"{x:653,y:557,t:1527271978890};\\\", \\\"{x:652,y:557,t:1527271978906};\\\", \\\"{x:651,y:557,t:1527271978914};\\\", \\\"{x:649,y:557,t:1527271978929};\\\", \\\"{x:645,y:557,t:1527271978946};\\\", \\\"{x:640,y:557,t:1527271978962};\\\", \\\"{x:635,y:554,t:1527271978979};\\\", \\\"{x:632,y:554,t:1527271978995};\\\", \\\"{x:630,y:554,t:1527271979012};\\\", \\\"{x:629,y:554,t:1527271979029};\\\", \\\"{x:626,y:553,t:1527271979045};\\\", \\\"{x:622,y:550,t:1527271979063};\\\", \\\"{x:608,y:544,t:1527271979080};\\\", \\\"{x:595,y:539,t:1527271979095};\\\", \\\"{x:588,y:537,t:1527271979112};\\\", \\\"{x:588,y:536,t:1527271979128};\\\", \\\"{x:587,y:535,t:1527271979210};\\\", \\\"{x:587,y:534,t:1527271979226};\\\", \\\"{x:589,y:533,t:1527271979242};\\\", \\\"{x:590,y:532,t:1527271979257};\\\", \\\"{x:592,y:532,t:1527271979265};\\\", \\\"{x:593,y:531,t:1527271979290};\\\", \\\"{x:594,y:530,t:1527271979298};\\\", \\\"{x:595,y:530,t:1527271979312};\\\", \\\"{x:599,y:528,t:1527271979329};\\\", \\\"{x:601,y:528,t:1527271979345};\\\", \\\"{x:602,y:527,t:1527271979362};\\\", \\\"{x:604,y:527,t:1527271979585};\\\", \\\"{x:605,y:526,t:1527271979595};\\\", \\\"{x:609,y:526,t:1527271979612};\\\", \\\"{x:618,y:529,t:1527271979629};\\\", \\\"{x:626,y:541,t:1527271979646};\\\", \\\"{x:630,y:543,t:1527271979663};\\\", \\\"{x:630,y:549,t:1527271979679};\\\", \\\"{x:629,y:551,t:1527271979697};\\\", \\\"{x:626,y:553,t:1527271979713};\\\", \\\"{x:626,y:554,t:1527271979746};\\\", \\\"{x:626,y:555,t:1527271979764};\\\", \\\"{x:626,y:557,t:1527271979780};\\\", \\\"{x:624,y:557,t:1527271979797};\\\", \\\"{x:622,y:558,t:1527271979815};\\\", \\\"{x:621,y:558,t:1527271979830};\\\", \\\"{x:619,y:559,t:1527271979874};\\\", \\\"{x:619,y:557,t:1527271979985};\\\", \\\"{x:620,y:553,t:1527271979996};\\\", \\\"{x:622,y:541,t:1527271980013};\\\", \\\"{x:622,y:539,t:1527271980030};\\\", \\\"{x:622,y:538,t:1527271980046};\\\", \\\"{x:622,y:537,t:1527271980064};\\\", \\\"{x:621,y:539,t:1527271980361};\\\", \\\"{x:619,y:545,t:1527271980369};\\\", \\\"{x:618,y:554,t:1527271980381};\\\", \\\"{x:616,y:563,t:1527271980397};\\\", \\\"{x:615,y:564,t:1527271980413};\\\", \\\"{x:614,y:565,t:1527271980430};\\\", \\\"{x:613,y:566,t:1527271980594};\\\", \\\"{x:613,y:565,t:1527271980793};\\\", \\\"{x:617,y:565,t:1527271980977};\\\", \\\"{x:625,y:565,t:1527271980985};\\\", \\\"{x:634,y:569,t:1527271980997};\\\", \\\"{x:661,y:579,t:1527271981014};\\\", \\\"{x:700,y:590,t:1527271981031};\\\", \\\"{x:753,y:605,t:1527271981048};\\\", \\\"{x:819,y:624,t:1527271981064};\\\", \\\"{x:902,y:642,t:1527271981081};\\\", \\\"{x:1045,y:678,t:1527271981097};\\\", \\\"{x:1140,y:695,t:1527271981113};\\\", \\\"{x:1227,y:710,t:1527271981130};\\\", \\\"{x:1299,y:721,t:1527271981147};\\\", \\\"{x:1355,y:729,t:1527271981164};\\\", \\\"{x:1384,y:729,t:1527271981180};\\\", \\\"{x:1401,y:729,t:1527271981197};\\\", \\\"{x:1407,y:728,t:1527271981214};\\\", \\\"{x:1409,y:728,t:1527271981230};\\\", \\\"{x:1409,y:725,t:1527271981247};\\\", \\\"{x:1410,y:720,t:1527271981264};\\\", \\\"{x:1410,y:715,t:1527271981280};\\\", \\\"{x:1409,y:708,t:1527271981297};\\\", \\\"{x:1404,y:700,t:1527271981315};\\\", \\\"{x:1389,y:690,t:1527271981330};\\\", \\\"{x:1373,y:679,t:1527271981348};\\\", \\\"{x:1351,y:669,t:1527271981365};\\\", \\\"{x:1335,y:662,t:1527271981381};\\\", \\\"{x:1324,y:648,t:1527271981397};\\\", \\\"{x:1314,y:632,t:1527271981415};\\\", \\\"{x:1311,y:625,t:1527271981430};\\\", \\\"{x:1310,y:623,t:1527271981448};\\\", \\\"{x:1310,y:621,t:1527271981465};\\\", \\\"{x:1310,y:617,t:1527271981481};\\\", \\\"{x:1311,y:608,t:1527271981498};\\\", \\\"{x:1322,y:588,t:1527271981514};\\\", \\\"{x:1329,y:572,t:1527271981532};\\\", \\\"{x:1333,y:562,t:1527271981547};\\\", \\\"{x:1337,y:556,t:1527271981564};\\\", \\\"{x:1337,y:550,t:1527271981582};\\\", \\\"{x:1341,y:544,t:1527271981597};\\\", \\\"{x:1341,y:539,t:1527271981615};\\\", \\\"{x:1343,y:535,t:1527271981631};\\\", \\\"{x:1343,y:529,t:1527271981648};\\\", \\\"{x:1343,y:522,t:1527271981665};\\\", \\\"{x:1342,y:513,t:1527271981682};\\\", \\\"{x:1340,y:505,t:1527271981698};\\\", \\\"{x:1338,y:503,t:1527271981714};\\\", \\\"{x:1338,y:501,t:1527271981732};\\\", \\\"{x:1336,y:500,t:1527271981747};\\\", \\\"{x:1333,y:497,t:1527271981765};\\\", \\\"{x:1329,y:494,t:1527271981782};\\\", \\\"{x:1327,y:494,t:1527271981797};\\\", \\\"{x:1326,y:494,t:1527271981814};\\\", \\\"{x:1325,y:494,t:1527271981867};\\\", \\\"{x:1322,y:494,t:1527271981882};\\\", \\\"{x:1320,y:494,t:1527271981898};\\\", \\\"{x:1317,y:495,t:1527271981915};\\\", \\\"{x:1315,y:495,t:1527271981932};\\\", \\\"{x:1313,y:496,t:1527271981949};\\\", \\\"{x:1312,y:497,t:1527271981978};\\\", \\\"{x:1312,y:498,t:1527271982507};\\\", \\\"{x:1312,y:503,t:1527271982851};\\\", \\\"{x:1308,y:539,t:1527271982866};\\\", \\\"{x:1308,y:562,t:1527271982882};\\\", \\\"{x:1307,y:578,t:1527271982898};\\\", \\\"{x:1305,y:599,t:1527271982915};\\\", \\\"{x:1305,y:628,t:1527271982933};\\\", \\\"{x:1305,y:658,t:1527271982949};\\\", \\\"{x:1308,y:684,t:1527271982966};\\\", \\\"{x:1310,y:708,t:1527271982982};\\\", \\\"{x:1313,y:734,t:1527271982999};\\\", \\\"{x:1305,y:769,t:1527271983015};\\\", \\\"{x:1300,y:793,t:1527271983032};\\\", \\\"{x:1298,y:804,t:1527271983048};\\\", \\\"{x:1297,y:811,t:1527271983065};\\\", \\\"{x:1297,y:815,t:1527271983082};\\\", \\\"{x:1297,y:820,t:1527271983099};\\\", \\\"{x:1298,y:826,t:1527271983115};\\\", \\\"{x:1300,y:833,t:1527271983132};\\\", \\\"{x:1303,y:847,t:1527271983148};\\\", \\\"{x:1308,y:860,t:1527271983165};\\\", \\\"{x:1311,y:868,t:1527271983183};\\\", \\\"{x:1315,y:875,t:1527271983199};\\\", \\\"{x:1319,y:885,t:1527271983215};\\\", \\\"{x:1323,y:891,t:1527271983232};\\\", \\\"{x:1332,y:908,t:1527271983250};\\\", \\\"{x:1338,y:919,t:1527271983265};\\\", \\\"{x:1342,y:927,t:1527271983283};\\\", \\\"{x:1344,y:931,t:1527271983299};\\\", \\\"{x:1344,y:932,t:1527271983315};\\\", \\\"{x:1344,y:929,t:1527271983418};\\\", \\\"{x:1344,y:922,t:1527271983433};\\\", \\\"{x:1347,y:888,t:1527271983450};\\\", \\\"{x:1348,y:854,t:1527271983465};\\\", \\\"{x:1356,y:795,t:1527271983482};\\\", \\\"{x:1365,y:710,t:1527271983500};\\\", \\\"{x:1367,y:612,t:1527271983515};\\\", \\\"{x:1367,y:540,t:1527271983532};\\\", \\\"{x:1360,y:508,t:1527271983549};\\\", \\\"{x:1357,y:497,t:1527271983565};\\\", \\\"{x:1353,y:491,t:1527271983582};\\\", \\\"{x:1351,y:491,t:1527271983714};\\\", \\\"{x:1349,y:494,t:1527271983721};\\\", \\\"{x:1347,y:503,t:1527271983733};\\\", \\\"{x:1344,y:523,t:1527271983749};\\\", \\\"{x:1337,y:548,t:1527271983766};\\\", \\\"{x:1333,y:564,t:1527271983782};\\\", \\\"{x:1333,y:575,t:1527271983799};\\\", \\\"{x:1333,y:588,t:1527271983816};\\\", \\\"{x:1333,y:596,t:1527271983832};\\\", \\\"{x:1335,y:611,t:1527271983849};\\\", \\\"{x:1336,y:624,t:1527271983866};\\\", \\\"{x:1340,y:635,t:1527271983882};\\\", \\\"{x:1340,y:643,t:1527271983900};\\\", \\\"{x:1342,y:647,t:1527271983916};\\\", \\\"{x:1343,y:651,t:1527271983933};\\\", \\\"{x:1345,y:654,t:1527271983949};\\\", \\\"{x:1345,y:658,t:1527271983966};\\\", \\\"{x:1345,y:661,t:1527271983983};\\\", \\\"{x:1347,y:663,t:1527271983999};\\\", \\\"{x:1347,y:664,t:1527271984016};\\\", \\\"{x:1347,y:666,t:1527271984032};\\\", \\\"{x:1347,y:667,t:1527271984050};\\\", \\\"{x:1347,y:668,t:1527271984154};\\\", \\\"{x:1347,y:670,t:1527271984167};\\\", \\\"{x:1346,y:675,t:1527271984184};\\\", \\\"{x:1346,y:677,t:1527271984200};\\\", \\\"{x:1346,y:681,t:1527271984216};\\\", \\\"{x:1346,y:693,t:1527271984234};\\\", \\\"{x:1346,y:701,t:1527271984250};\\\", \\\"{x:1346,y:705,t:1527271984267};\\\", \\\"{x:1346,y:710,t:1527271984283};\\\", \\\"{x:1348,y:720,t:1527271984300};\\\", \\\"{x:1350,y:731,t:1527271984316};\\\", \\\"{x:1353,y:740,t:1527271984334};\\\", \\\"{x:1353,y:748,t:1527271984349};\\\", \\\"{x:1354,y:752,t:1527271984366};\\\", \\\"{x:1354,y:759,t:1527271984384};\\\", \\\"{x:1354,y:766,t:1527271984399};\\\", \\\"{x:1356,y:775,t:1527271984417};\\\", \\\"{x:1358,y:786,t:1527271984434};\\\", \\\"{x:1359,y:799,t:1527271984450};\\\", \\\"{x:1359,y:810,t:1527271984466};\\\", \\\"{x:1359,y:823,t:1527271984484};\\\", \\\"{x:1358,y:833,t:1527271984501};\\\", \\\"{x:1357,y:838,t:1527271984517};\\\", \\\"{x:1357,y:844,t:1527271984534};\\\", \\\"{x:1357,y:852,t:1527271984549};\\\", \\\"{x:1356,y:857,t:1527271984567};\\\", \\\"{x:1353,y:865,t:1527271984584};\\\", \\\"{x:1352,y:873,t:1527271984601};\\\", \\\"{x:1350,y:885,t:1527271984617};\\\", \\\"{x:1341,y:911,t:1527271984634};\\\", \\\"{x:1333,y:929,t:1527271984650};\\\", \\\"{x:1326,y:941,t:1527271984667};\\\", \\\"{x:1320,y:952,t:1527271984684};\\\", \\\"{x:1316,y:959,t:1527271984701};\\\", \\\"{x:1313,y:963,t:1527271984717};\\\", \\\"{x:1312,y:964,t:1527271984734};\\\", \\\"{x:1311,y:966,t:1527271984751};\\\", \\\"{x:1311,y:968,t:1527271984767};\\\", \\\"{x:1311,y:970,t:1527271984784};\\\", \\\"{x:1311,y:973,t:1527271984801};\\\", \\\"{x:1311,y:977,t:1527271984817};\\\", \\\"{x:1310,y:984,t:1527271984834};\\\", \\\"{x:1310,y:987,t:1527271984851};\\\", \\\"{x:1309,y:988,t:1527271984874};\\\", \\\"{x:1309,y:987,t:1527271984954};\\\", \\\"{x:1309,y:985,t:1527271984966};\\\", \\\"{x:1309,y:984,t:1527271985018};\\\", \\\"{x:1309,y:983,t:1527271985033};\\\", \\\"{x:1309,y:982,t:1527271985050};\\\", \\\"{x:1309,y:981,t:1527271985068};\\\", \\\"{x:1309,y:980,t:1527271985084};\\\", \\\"{x:1309,y:979,t:1527271985106};\\\", \\\"{x:1309,y:978,t:1527271985122};\\\", \\\"{x:1309,y:977,t:1527271985161};\\\", \\\"{x:1310,y:977,t:1527271985169};\\\", \\\"{x:1310,y:976,t:1527271985194};\\\", \\\"{x:1310,y:975,t:1527271985210};\\\", \\\"{x:1310,y:973,t:1527271985218};\\\", \\\"{x:1310,y:972,t:1527271985234};\\\", \\\"{x:1310,y:970,t:1527271985251};\\\", \\\"{x:1310,y:969,t:1527271985282};\\\", \\\"{x:1312,y:968,t:1527271985298};\\\", \\\"{x:1312,y:966,t:1527271985306};\\\", \\\"{x:1313,y:966,t:1527271985994};\\\", \\\"{x:1314,y:965,t:1527271986010};\\\", \\\"{x:1315,y:959,t:1527271986667};\\\", \\\"{x:1315,y:948,t:1527271986674};\\\", \\\"{x:1315,y:937,t:1527271986685};\\\", \\\"{x:1314,y:918,t:1527271986702};\\\", \\\"{x:1308,y:890,t:1527271986719};\\\", \\\"{x:1295,y:853,t:1527271986737};\\\", \\\"{x:1288,y:833,t:1527271986752};\\\", \\\"{x:1284,y:820,t:1527271986769};\\\", \\\"{x:1278,y:800,t:1527271986786};\\\", \\\"{x:1274,y:782,t:1527271986802};\\\", \\\"{x:1272,y:764,t:1527271986819};\\\", \\\"{x:1270,y:744,t:1527271986836};\\\", \\\"{x:1268,y:722,t:1527271986852};\\\", \\\"{x:1268,y:702,t:1527271986869};\\\", \\\"{x:1268,y:681,t:1527271986885};\\\", \\\"{x:1268,y:662,t:1527271986901};\\\", \\\"{x:1268,y:646,t:1527271986918};\\\", \\\"{x:1269,y:634,t:1527271986935};\\\", \\\"{x:1271,y:622,t:1527271986951};\\\", \\\"{x:1275,y:608,t:1527271986969};\\\", \\\"{x:1284,y:587,t:1527271986986};\\\", \\\"{x:1290,y:569,t:1527271987001};\\\", \\\"{x:1295,y:552,t:1527271987019};\\\", \\\"{x:1300,y:539,t:1527271987035};\\\", \\\"{x:1306,y:526,t:1527271987052};\\\", \\\"{x:1310,y:514,t:1527271987068};\\\", \\\"{x:1313,y:506,t:1527271987085};\\\", \\\"{x:1319,y:497,t:1527271987102};\\\", \\\"{x:1325,y:487,t:1527271987119};\\\", \\\"{x:1327,y:479,t:1527271987135};\\\", \\\"{x:1330,y:470,t:1527271987153};\\\", \\\"{x:1330,y:460,t:1527271987169};\\\", \\\"{x:1331,y:454,t:1527271987186};\\\", \\\"{x:1332,y:454,t:1527271987203};\\\", \\\"{x:1330,y:454,t:1527271987299};\\\", \\\"{x:1328,y:457,t:1527271987306};\\\", \\\"{x:1328,y:462,t:1527271987319};\\\", \\\"{x:1323,y:471,t:1527271987336};\\\", \\\"{x:1320,y:477,t:1527271987353};\\\", \\\"{x:1319,y:482,t:1527271987369};\\\", \\\"{x:1317,y:487,t:1527271987386};\\\", \\\"{x:1316,y:490,t:1527271987403};\\\", \\\"{x:1315,y:493,t:1527271987419};\\\", \\\"{x:1315,y:494,t:1527271987435};\\\", \\\"{x:1314,y:496,t:1527271987453};\\\", \\\"{x:1316,y:505,t:1527271993508};\\\", \\\"{x:1377,y:563,t:1527271993525};\\\", \\\"{x:1485,y:637,t:1527271993541};\\\", \\\"{x:1601,y:690,t:1527271993557};\\\", \\\"{x:1736,y:751,t:1527271993574};\\\", \\\"{x:1879,y:806,t:1527271993592};\\\", \\\"{x:1919,y:864,t:1527271993608};\\\", \\\"{x:1919,y:912,t:1527271993624};\\\", \\\"{x:1919,y:935,t:1527271993640};\\\", \\\"{x:1919,y:945,t:1527271993658};\\\", \\\"{x:1919,y:947,t:1527271993673};\\\", \\\"{x:1904,y:947,t:1527271993690};\\\", \\\"{x:1895,y:947,t:1527271993708};\\\", \\\"{x:1885,y:947,t:1527271993724};\\\", \\\"{x:1864,y:942,t:1527271993741};\\\", \\\"{x:1844,y:939,t:1527271993758};\\\", \\\"{x:1821,y:938,t:1527271993773};\\\", \\\"{x:1786,y:938,t:1527271993790};\\\", \\\"{x:1730,y:947,t:1527271993807};\\\", \\\"{x:1683,y:976,t:1527271993823};\\\", \\\"{x:1654,y:1007,t:1527271993841};\\\", \\\"{x:1636,y:1027,t:1527271993857};\\\", \\\"{x:1627,y:1050,t:1527271993874};\\\", \\\"{x:1628,y:1053,t:1527271993890};\\\", \\\"{x:1634,y:1053,t:1527271993907};\\\", \\\"{x:1645,y:1049,t:1527271993924};\\\", \\\"{x:1655,y:1045,t:1527271993941};\\\", \\\"{x:1670,y:1040,t:1527271993957};\\\", \\\"{x:1683,y:1033,t:1527271993974};\\\", \\\"{x:1692,y:1031,t:1527271993991};\\\", \\\"{x:1699,y:1028,t:1527271994007};\\\", \\\"{x:1704,y:1026,t:1527271994024};\\\", \\\"{x:1706,y:1025,t:1527271994042};\\\", \\\"{x:1707,y:1023,t:1527271994057};\\\", \\\"{x:1711,y:1011,t:1527271994074};\\\", \\\"{x:1717,y:1002,t:1527271994091};\\\", \\\"{x:1726,y:992,t:1527271994107};\\\", \\\"{x:1736,y:983,t:1527271994125};\\\", \\\"{x:1743,y:978,t:1527271994141};\\\", \\\"{x:1747,y:975,t:1527271994158};\\\", \\\"{x:1748,y:975,t:1527271994175};\\\", \\\"{x:1750,y:974,t:1527271994194};\\\", \\\"{x:1751,y:973,t:1527271994207};\\\", \\\"{x:1756,y:971,t:1527271994225};\\\", \\\"{x:1764,y:968,t:1527271994242};\\\", \\\"{x:1772,y:964,t:1527271994258};\\\", \\\"{x:1775,y:961,t:1527271994274};\\\", \\\"{x:1776,y:960,t:1527271994291};\\\", \\\"{x:1777,y:960,t:1527271994307};\\\", \\\"{x:1778,y:960,t:1527271994410};\\\", \\\"{x:1776,y:960,t:1527272003286};\\\", \\\"{x:1774,y:960,t:1527272003293};\\\", \\\"{x:1766,y:959,t:1527272003305};\\\", \\\"{x:1749,y:954,t:1527272003323};\\\", \\\"{x:1729,y:949,t:1527272003338};\\\", \\\"{x:1707,y:941,t:1527272003356};\\\", \\\"{x:1670,y:928,t:1527272003373};\\\", \\\"{x:1637,y:915,t:1527272003389};\\\", \\\"{x:1579,y:892,t:1527272003406};\\\", \\\"{x:1533,y:873,t:1527272003424};\\\", \\\"{x:1509,y:862,t:1527272003438};\\\", \\\"{x:1498,y:857,t:1527272003456};\\\", \\\"{x:1495,y:855,t:1527272003473};\\\", \\\"{x:1494,y:854,t:1527272003489};\\\", \\\"{x:1494,y:846,t:1527272003506};\\\", \\\"{x:1494,y:831,t:1527272003523};\\\", \\\"{x:1500,y:814,t:1527272003539};\\\", \\\"{x:1503,y:797,t:1527272003556};\\\", \\\"{x:1508,y:765,t:1527272003573};\\\", \\\"{x:1513,y:743,t:1527272003589};\\\", \\\"{x:1514,y:722,t:1527272003606};\\\", \\\"{x:1515,y:708,t:1527272003623};\\\", \\\"{x:1522,y:696,t:1527272003639};\\\", \\\"{x:1528,y:679,t:1527272003656};\\\", \\\"{x:1531,y:666,t:1527272003673};\\\", \\\"{x:1533,y:660,t:1527272003689};\\\", \\\"{x:1533,y:655,t:1527272003706};\\\", \\\"{x:1533,y:652,t:1527272003722};\\\", \\\"{x:1533,y:649,t:1527272003739};\\\", \\\"{x:1533,y:646,t:1527272003755};\\\", \\\"{x:1532,y:640,t:1527272003771};\\\", \\\"{x:1528,y:636,t:1527272003788};\\\", \\\"{x:1519,y:631,t:1527272003805};\\\", \\\"{x:1510,y:623,t:1527272003822};\\\", \\\"{x:1508,y:622,t:1527272003838};\\\", \\\"{x:1510,y:622,t:1527272004085};\\\", \\\"{x:1511,y:622,t:1527272004092};\\\", \\\"{x:1512,y:622,t:1527272004105};\\\", \\\"{x:1511,y:623,t:1527272004213};\\\", \\\"{x:1510,y:623,t:1527272004612};\\\", \\\"{x:1510,y:624,t:1527272004621};\\\", \\\"{x:1509,y:624,t:1527272004639};\\\", \\\"{x:1507,y:624,t:1527272004654};\\\", \\\"{x:1507,y:625,t:1527272004749};\\\", \\\"{x:1506,y:625,t:1527272004781};\\\", \\\"{x:1505,y:626,t:1527272004789};\\\", \\\"{x:1505,y:633,t:1527272004805};\\\", \\\"{x:1505,y:638,t:1527272004821};\\\", \\\"{x:1505,y:641,t:1527272004839};\\\", \\\"{x:1505,y:643,t:1527272004854};\\\", \\\"{x:1505,y:644,t:1527272004872};\\\", \\\"{x:1505,y:646,t:1527272004889};\\\", \\\"{x:1504,y:648,t:1527272004905};\\\", \\\"{x:1504,y:650,t:1527272004922};\\\", \\\"{x:1504,y:653,t:1527272004938};\\\", \\\"{x:1504,y:657,t:1527272004954};\\\", \\\"{x:1504,y:663,t:1527272004971};\\\", \\\"{x:1504,y:670,t:1527272004988};\\\", \\\"{x:1504,y:672,t:1527272005004};\\\", \\\"{x:1503,y:674,t:1527272005022};\\\", \\\"{x:1503,y:679,t:1527272005038};\\\", \\\"{x:1503,y:686,t:1527272005055};\\\", \\\"{x:1503,y:694,t:1527272005072};\\\", \\\"{x:1506,y:702,t:1527272005087};\\\", \\\"{x:1506,y:707,t:1527272005104};\\\", \\\"{x:1506,y:709,t:1527272005122};\\\", \\\"{x:1506,y:711,t:1527272005138};\\\", \\\"{x:1506,y:717,t:1527272005155};\\\", \\\"{x:1506,y:724,t:1527272005172};\\\", \\\"{x:1506,y:731,t:1527272005188};\\\", \\\"{x:1506,y:740,t:1527272005204};\\\", \\\"{x:1506,y:744,t:1527272005222};\\\", \\\"{x:1506,y:747,t:1527272005238};\\\", \\\"{x:1506,y:753,t:1527272005255};\\\", \\\"{x:1506,y:760,t:1527272005272};\\\", \\\"{x:1506,y:772,t:1527272005287};\\\", \\\"{x:1506,y:781,t:1527272005305};\\\", \\\"{x:1506,y:788,t:1527272005321};\\\", \\\"{x:1506,y:794,t:1527272005337};\\\", \\\"{x:1506,y:798,t:1527272005355};\\\", \\\"{x:1506,y:805,t:1527272005371};\\\", \\\"{x:1506,y:815,t:1527272005388};\\\", \\\"{x:1508,y:823,t:1527272005405};\\\", \\\"{x:1508,y:825,t:1527272005422};\\\", \\\"{x:1508,y:827,t:1527272005438};\\\", \\\"{x:1509,y:830,t:1527272005455};\\\", \\\"{x:1509,y:832,t:1527272005472};\\\", \\\"{x:1510,y:836,t:1527272005487};\\\", \\\"{x:1510,y:841,t:1527272005505};\\\", \\\"{x:1511,y:846,t:1527272005522};\\\", \\\"{x:1512,y:848,t:1527272005538};\\\", \\\"{x:1513,y:850,t:1527272005555};\\\", \\\"{x:1513,y:851,t:1527272005571};\\\", \\\"{x:1513,y:853,t:1527272005588};\\\", \\\"{x:1514,y:858,t:1527272005605};\\\", \\\"{x:1515,y:864,t:1527272005621};\\\", \\\"{x:1518,y:872,t:1527272005638};\\\", \\\"{x:1519,y:878,t:1527272005655};\\\", \\\"{x:1522,y:884,t:1527272005671};\\\", \\\"{x:1522,y:889,t:1527272005688};\\\", \\\"{x:1523,y:890,t:1527272005705};\\\", \\\"{x:1523,y:892,t:1527272005721};\\\", \\\"{x:1523,y:893,t:1527272005737};\\\", \\\"{x:1524,y:897,t:1527272005755};\\\", \\\"{x:1524,y:903,t:1527272005771};\\\", \\\"{x:1525,y:911,t:1527272005788};\\\", \\\"{x:1527,y:921,t:1527272005805};\\\", \\\"{x:1527,y:924,t:1527272005821};\\\", \\\"{x:1528,y:925,t:1527272005837};\\\", \\\"{x:1528,y:926,t:1527272005854};\\\", \\\"{x:1528,y:931,t:1527272005871};\\\", \\\"{x:1529,y:937,t:1527272005887};\\\", \\\"{x:1530,y:939,t:1527272005905};\\\", \\\"{x:1530,y:940,t:1527272005921};\\\", \\\"{x:1530,y:941,t:1527272005981};\\\", \\\"{x:1530,y:942,t:1527272005989};\\\", \\\"{x:1530,y:945,t:1527272006005};\\\", \\\"{x:1530,y:947,t:1527272006021};\\\", \\\"{x:1530,y:949,t:1527272006038};\\\", \\\"{x:1530,y:950,t:1527272006055};\\\", \\\"{x:1530,y:951,t:1527272006085};\\\", \\\"{x:1530,y:952,t:1527272006092};\\\", \\\"{x:1530,y:953,t:1527272006109};\\\", \\\"{x:1530,y:949,t:1527272006293};\\\", \\\"{x:1531,y:934,t:1527272006303};\\\", \\\"{x:1537,y:902,t:1527272006321};\\\", \\\"{x:1547,y:867,t:1527272006338};\\\", \\\"{x:1556,y:824,t:1527272006354};\\\", \\\"{x:1562,y:780,t:1527272006371};\\\", \\\"{x:1564,y:756,t:1527272006388};\\\", \\\"{x:1566,y:745,t:1527272006404};\\\", \\\"{x:1566,y:734,t:1527272006421};\\\", \\\"{x:1566,y:729,t:1527272006438};\\\", \\\"{x:1566,y:721,t:1527272006454};\\\", \\\"{x:1565,y:709,t:1527272006470};\\\", \\\"{x:1562,y:702,t:1527272006488};\\\", \\\"{x:1560,y:695,t:1527272006504};\\\", \\\"{x:1558,y:692,t:1527272006521};\\\", \\\"{x:1557,y:691,t:1527272006537};\\\", \\\"{x:1557,y:690,t:1527272006605};\\\", \\\"{x:1554,y:689,t:1527272006620};\\\", \\\"{x:1552,y:688,t:1527272006638};\\\", \\\"{x:1548,y:685,t:1527272006654};\\\", \\\"{x:1541,y:681,t:1527272006671};\\\", \\\"{x:1537,y:679,t:1527272006687};\\\", \\\"{x:1535,y:676,t:1527272006704};\\\", \\\"{x:1534,y:672,t:1527272006721};\\\", \\\"{x:1531,y:665,t:1527272006737};\\\", \\\"{x:1530,y:660,t:1527272006754};\\\", \\\"{x:1527,y:655,t:1527272006771};\\\", \\\"{x:1526,y:652,t:1527272006788};\\\", \\\"{x:1526,y:651,t:1527272006892};\\\", \\\"{x:1526,y:650,t:1527272006903};\\\", \\\"{x:1526,y:646,t:1527272006920};\\\", \\\"{x:1526,y:644,t:1527272006936};\\\", \\\"{x:1526,y:643,t:1527272006964};\\\", \\\"{x:1525,y:643,t:1527272006972};\\\", \\\"{x:1525,y:642,t:1527272006986};\\\", \\\"{x:1524,y:641,t:1527272007003};\\\", \\\"{x:1522,y:640,t:1527272007020};\\\", \\\"{x:1521,y:638,t:1527272007036};\\\", \\\"{x:1521,y:637,t:1527272007054};\\\", \\\"{x:1521,y:635,t:1527272007309};\\\", \\\"{x:1519,y:634,t:1527272007320};\\\", \\\"{x:1517,y:633,t:1527272007337};\\\", \\\"{x:1515,y:630,t:1527272007353};\\\", \\\"{x:1513,y:629,t:1527272007369};\\\", \\\"{x:1513,y:631,t:1527272008669};\\\", \\\"{x:1513,y:639,t:1527272008686};\\\", \\\"{x:1513,y:647,t:1527272008702};\\\", \\\"{x:1513,y:650,t:1527272008719};\\\", \\\"{x:1513,y:651,t:1527272008735};\\\", \\\"{x:1513,y:652,t:1527272008764};\\\", \\\"{x:1513,y:653,t:1527272008780};\\\", \\\"{x:1513,y:654,t:1527272008788};\\\", \\\"{x:1513,y:656,t:1527272008802};\\\", \\\"{x:1513,y:657,t:1527272008828};\\\", \\\"{x:1513,y:659,t:1527272008844};\\\", \\\"{x:1513,y:661,t:1527272008860};\\\", \\\"{x:1513,y:663,t:1527272008870};\\\", \\\"{x:1513,y:665,t:1527272008886};\\\", \\\"{x:1513,y:669,t:1527272008902};\\\", \\\"{x:1513,y:673,t:1527272008920};\\\", \\\"{x:1513,y:678,t:1527272008936};\\\", \\\"{x:1513,y:686,t:1527272008953};\\\", \\\"{x:1514,y:691,t:1527272008969};\\\", \\\"{x:1514,y:693,t:1527272008986};\\\", \\\"{x:1514,y:695,t:1527272009002};\\\", \\\"{x:1514,y:697,t:1527272009020};\\\", \\\"{x:1515,y:699,t:1527272009036};\\\", \\\"{x:1515,y:707,t:1527272009053};\\\", \\\"{x:1516,y:713,t:1527272009070};\\\", \\\"{x:1516,y:717,t:1527272009086};\\\", \\\"{x:1516,y:722,t:1527272009103};\\\", \\\"{x:1517,y:725,t:1527272009120};\\\", \\\"{x:1517,y:729,t:1527272009136};\\\", \\\"{x:1517,y:733,t:1527272009152};\\\", \\\"{x:1517,y:739,t:1527272009169};\\\", \\\"{x:1518,y:744,t:1527272009185};\\\", \\\"{x:1518,y:747,t:1527272009202};\\\", \\\"{x:1519,y:753,t:1527272009219};\\\", \\\"{x:1519,y:758,t:1527272009236};\\\", \\\"{x:1520,y:771,t:1527272009252};\\\", \\\"{x:1520,y:782,t:1527272009269};\\\", \\\"{x:1521,y:791,t:1527272009286};\\\", \\\"{x:1521,y:799,t:1527272009303};\\\", \\\"{x:1523,y:807,t:1527272009318};\\\", \\\"{x:1524,y:812,t:1527272009336};\\\", \\\"{x:1524,y:815,t:1527272009353};\\\", \\\"{x:1524,y:817,t:1527272009369};\\\", \\\"{x:1524,y:822,t:1527272009386};\\\", \\\"{x:1525,y:830,t:1527272009403};\\\", \\\"{x:1525,y:837,t:1527272009419};\\\", \\\"{x:1525,y:842,t:1527272009436};\\\", \\\"{x:1525,y:845,t:1527272009453};\\\", \\\"{x:1525,y:848,t:1527272009469};\\\", \\\"{x:1525,y:851,t:1527272009486};\\\", \\\"{x:1525,y:856,t:1527272009503};\\\", \\\"{x:1525,y:862,t:1527272009519};\\\", \\\"{x:1525,y:868,t:1527272009536};\\\", \\\"{x:1525,y:874,t:1527272009553};\\\", \\\"{x:1525,y:877,t:1527272009570};\\\", \\\"{x:1525,y:879,t:1527272009586};\\\", \\\"{x:1525,y:882,t:1527272009603};\\\", \\\"{x:1524,y:884,t:1527272009619};\\\", \\\"{x:1523,y:890,t:1527272009636};\\\", \\\"{x:1522,y:895,t:1527272009653};\\\", \\\"{x:1520,y:899,t:1527272009669};\\\", \\\"{x:1520,y:902,t:1527272009686};\\\", \\\"{x:1519,y:904,t:1527272009703};\\\", \\\"{x:1519,y:906,t:1527272009719};\\\", \\\"{x:1518,y:908,t:1527272009736};\\\", \\\"{x:1518,y:911,t:1527272009752};\\\", \\\"{x:1517,y:913,t:1527272009769};\\\", \\\"{x:1516,y:915,t:1527272009786};\\\", \\\"{x:1516,y:918,t:1527272009803};\\\", \\\"{x:1516,y:921,t:1527272009819};\\\", \\\"{x:1516,y:923,t:1527272009836};\\\", \\\"{x:1515,y:925,t:1527272009852};\\\", \\\"{x:1515,y:927,t:1527272009870};\\\", \\\"{x:1515,y:928,t:1527272009886};\\\", \\\"{x:1515,y:930,t:1527272009902};\\\", \\\"{x:1514,y:931,t:1527272009919};\\\", \\\"{x:1514,y:933,t:1527272009956};\\\", \\\"{x:1514,y:935,t:1527272009973};\\\", \\\"{x:1514,y:938,t:1527272009986};\\\", \\\"{x:1514,y:940,t:1527272010002};\\\", \\\"{x:1514,y:944,t:1527272010019};\\\", \\\"{x:1514,y:945,t:1527272010036};\\\", \\\"{x:1514,y:946,t:1527272010052};\\\", \\\"{x:1514,y:947,t:1527272010077};\\\", \\\"{x:1514,y:948,t:1527272010086};\\\", \\\"{x:1514,y:953,t:1527272010102};\\\", \\\"{x:1514,y:957,t:1527272010119};\\\", \\\"{x:1514,y:958,t:1527272010136};\\\", \\\"{x:1514,y:960,t:1527272010245};\\\", \\\"{x:1514,y:961,t:1527272010333};\\\", \\\"{x:1514,y:963,t:1527272010349};\\\", \\\"{x:1514,y:964,t:1527272010373};\\\", \\\"{x:1514,y:966,t:1527272010386};\\\", \\\"{x:1514,y:967,t:1527272010405};\\\", \\\"{x:1514,y:966,t:1527272011949};\\\", \\\"{x:1514,y:965,t:1527272013446};\\\", \\\"{x:1514,y:964,t:1527272013461};\\\", \\\"{x:1514,y:963,t:1527272013509};\\\", \\\"{x:1514,y:962,t:1527272013517};\\\", \\\"{x:1513,y:961,t:1527272013541};\\\", \\\"{x:1513,y:960,t:1527272013565};\\\", \\\"{x:1513,y:959,t:1527272013573};\\\", \\\"{x:1513,y:958,t:1527272013585};\\\", \\\"{x:1513,y:957,t:1527272013600};\\\", \\\"{x:1512,y:957,t:1527272013617};\\\", \\\"{x:1512,y:956,t:1527272013635};\\\", \\\"{x:1511,y:952,t:1527272013651};\\\", \\\"{x:1510,y:950,t:1527272013667};\\\", \\\"{x:1508,y:944,t:1527272013684};\\\", \\\"{x:1505,y:935,t:1527272013701};\\\", \\\"{x:1500,y:925,t:1527272013717};\\\", \\\"{x:1498,y:921,t:1527272013735};\\\", \\\"{x:1497,y:916,t:1527272013749};\\\", \\\"{x:1494,y:909,t:1527272013766};\\\", \\\"{x:1492,y:902,t:1527272013784};\\\", \\\"{x:1488,y:896,t:1527272013800};\\\", \\\"{x:1484,y:888,t:1527272013817};\\\", \\\"{x:1479,y:880,t:1527272013833};\\\", \\\"{x:1477,y:874,t:1527272013850};\\\", \\\"{x:1475,y:871,t:1527272013867};\\\", \\\"{x:1474,y:868,t:1527272013882};\\\", \\\"{x:1473,y:864,t:1527272013900};\\\", \\\"{x:1473,y:861,t:1527272013916};\\\", \\\"{x:1473,y:856,t:1527272013933};\\\", \\\"{x:1473,y:850,t:1527272013950};\\\", \\\"{x:1473,y:845,t:1527272013967};\\\", \\\"{x:1473,y:841,t:1527272013983};\\\", \\\"{x:1473,y:839,t:1527272014000};\\\", \\\"{x:1473,y:837,t:1527272014017};\\\", \\\"{x:1473,y:835,t:1527272014033};\\\", \\\"{x:1473,y:834,t:1527272014050};\\\", \\\"{x:1474,y:833,t:1527272014067};\\\", \\\"{x:1475,y:831,t:1527272014309};\\\", \\\"{x:1476,y:831,t:1527272014325};\\\", \\\"{x:1476,y:830,t:1527272014373};\\\", \\\"{x:1466,y:835,t:1527272014972};\\\", \\\"{x:1442,y:841,t:1527272014982};\\\", \\\"{x:1357,y:852,t:1527272014999};\\\", \\\"{x:1245,y:870,t:1527272015016};\\\", \\\"{x:1152,y:880,t:1527272015032};\\\", \\\"{x:1041,y:880,t:1527272015050};\\\", \\\"{x:908,y:880,t:1527272015065};\\\", \\\"{x:768,y:872,t:1527272015083};\\\", \\\"{x:626,y:844,t:1527272015099};\\\", \\\"{x:417,y:812,t:1527272015116};\\\", \\\"{x:308,y:794,t:1527272015132};\\\", \\\"{x:253,y:790,t:1527272015148};\\\", \\\"{x:224,y:780,t:1527272015166};\\\", \\\"{x:208,y:775,t:1527272015182};\\\", \\\"{x:199,y:769,t:1527272015198};\\\", \\\"{x:190,y:762,t:1527272015216};\\\", \\\"{x:188,y:760,t:1527272015233};\\\", \\\"{x:188,y:759,t:1527272015249};\\\", \\\"{x:189,y:754,t:1527272015268};\\\", \\\"{x:192,y:751,t:1527272015283};\\\", \\\"{x:208,y:737,t:1527272015299};\\\", \\\"{x:259,y:716,t:1527272015316};\\\", \\\"{x:327,y:701,t:1527272015332};\\\", \\\"{x:396,y:692,t:1527272015349};\\\", \\\"{x:447,y:683,t:1527272015367};\\\", \\\"{x:487,y:683,t:1527272015383};\\\", \\\"{x:510,y:683,t:1527272015399};\\\", \\\"{x:514,y:683,t:1527272015416};\\\", \\\"{x:514,y:687,t:1527272015508};\\\", \\\"{x:513,y:689,t:1527272015516};\\\", \\\"{x:508,y:696,t:1527272015532};\\\", \\\"{x:501,y:706,t:1527272015549};\\\", \\\"{x:499,y:715,t:1527272015567};\\\", \\\"{x:496,y:727,t:1527272015583};\\\", \\\"{x:496,y:732,t:1527272015599};\\\", \\\"{x:496,y:736,t:1527272015609};\\\", \\\"{x:496,y:742,t:1527272015627};\\\", \\\"{x:496,y:745,t:1527272015644};\\\", \\\"{x:498,y:745,t:1527272015893};\\\", \\\"{x:503,y:742,t:1527272015911};\\\", \\\"{x:505,y:739,t:1527272015927};\\\", \\\"{x:506,y:739,t:1527272015944};\\\" ] }, { \\\"rt\\\": 7645, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 441713, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-8-7-E -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:738,t:1527272018036};\\\", \\\"{x:509,y:737,t:1527272018047};\\\", \\\"{x:517,y:733,t:1527272018064};\\\", \\\"{x:522,y:729,t:1527272018079};\\\", \\\"{x:530,y:719,t:1527272018098};\\\", \\\"{x:540,y:700,t:1527272018114};\\\", \\\"{x:549,y:677,t:1527272018130};\\\", \\\"{x:561,y:632,t:1527272018146};\\\", \\\"{x:572,y:593,t:1527272018163};\\\", \\\"{x:577,y:557,t:1527272018181};\\\", \\\"{x:578,y:545,t:1527272018197};\\\", \\\"{x:579,y:535,t:1527272018213};\\\", \\\"{x:580,y:527,t:1527272018231};\\\", \\\"{x:581,y:524,t:1527272018247};\\\", \\\"{x:581,y:518,t:1527272018264};\\\", \\\"{x:581,y:512,t:1527272018281};\\\", \\\"{x:581,y:508,t:1527272018296};\\\", \\\"{x:577,y:501,t:1527272018314};\\\", \\\"{x:573,y:496,t:1527272018330};\\\", \\\"{x:568,y:494,t:1527272018347};\\\", \\\"{x:561,y:491,t:1527272018364};\\\", \\\"{x:556,y:489,t:1527272018381};\\\", \\\"{x:549,y:488,t:1527272018397};\\\", \\\"{x:541,y:487,t:1527272018414};\\\", \\\"{x:528,y:487,t:1527272018430};\\\", \\\"{x:520,y:487,t:1527272018447};\\\", \\\"{x:508,y:489,t:1527272018464};\\\", \\\"{x:494,y:491,t:1527272018481};\\\", \\\"{x:480,y:491,t:1527272018497};\\\", \\\"{x:470,y:493,t:1527272018514};\\\", \\\"{x:466,y:494,t:1527272018531};\\\", \\\"{x:464,y:494,t:1527272018547};\\\", \\\"{x:470,y:494,t:1527272018676};\\\", \\\"{x:483,y:496,t:1527272018684};\\\", \\\"{x:506,y:500,t:1527272018699};\\\", \\\"{x:587,y:509,t:1527272018715};\\\", \\\"{x:695,y:523,t:1527272018731};\\\", \\\"{x:805,y:540,t:1527272018747};\\\", \\\"{x:989,y:562,t:1527272018764};\\\", \\\"{x:1103,y:581,t:1527272018781};\\\", \\\"{x:1214,y:593,t:1527272018798};\\\", \\\"{x:1308,y:608,t:1527272018813};\\\", \\\"{x:1370,y:616,t:1527272018831};\\\", \\\"{x:1427,y:628,t:1527272018847};\\\", \\\"{x:1483,y:644,t:1527272018864};\\\", \\\"{x:1515,y:656,t:1527272018881};\\\", \\\"{x:1532,y:666,t:1527272018898};\\\", \\\"{x:1541,y:673,t:1527272018914};\\\", \\\"{x:1547,y:684,t:1527272018931};\\\", \\\"{x:1547,y:701,t:1527272018948};\\\", \\\"{x:1542,y:703,t:1527272018964};\\\", \\\"{x:1539,y:703,t:1527272019477};\\\", \\\"{x:1536,y:703,t:1527272019485};\\\", \\\"{x:1531,y:703,t:1527272019498};\\\", \\\"{x:1520,y:703,t:1527272019515};\\\", \\\"{x:1507,y:703,t:1527272019532};\\\", \\\"{x:1493,y:704,t:1527272019549};\\\", \\\"{x:1489,y:705,t:1527272019564};\\\", \\\"{x:1480,y:707,t:1527272019581};\\\", \\\"{x:1470,y:713,t:1527272019598};\\\", \\\"{x:1455,y:725,t:1527272019614};\\\", \\\"{x:1438,y:737,t:1527272019631};\\\", \\\"{x:1414,y:756,t:1527272019648};\\\", \\\"{x:1376,y:782,t:1527272019664};\\\", \\\"{x:1341,y:801,t:1527272019681};\\\", \\\"{x:1306,y:819,t:1527272019698};\\\", \\\"{x:1275,y:833,t:1527272019714};\\\", \\\"{x:1254,y:841,t:1527272019732};\\\", \\\"{x:1230,y:856,t:1527272019749};\\\", \\\"{x:1222,y:863,t:1527272019764};\\\", \\\"{x:1210,y:871,t:1527272019782};\\\", \\\"{x:1202,y:873,t:1527272019798};\\\", \\\"{x:1198,y:875,t:1527272019814};\\\", \\\"{x:1197,y:876,t:1527272019831};\\\", \\\"{x:1196,y:873,t:1527272019901};\\\", \\\"{x:1196,y:870,t:1527272019915};\\\", \\\"{x:1196,y:860,t:1527272019931};\\\", \\\"{x:1193,y:844,t:1527272019948};\\\", \\\"{x:1191,y:836,t:1527272019965};\\\", \\\"{x:1191,y:833,t:1527272019982};\\\", \\\"{x:1191,y:826,t:1527272019998};\\\", \\\"{x:1191,y:819,t:1527272020015};\\\", \\\"{x:1196,y:805,t:1527272020032};\\\", \\\"{x:1204,y:782,t:1527272020049};\\\", \\\"{x:1227,y:739,t:1527272020065};\\\", \\\"{x:1260,y:692,t:1527272020082};\\\", \\\"{x:1287,y:655,t:1527272020099};\\\", \\\"{x:1310,y:619,t:1527272020114};\\\", \\\"{x:1322,y:596,t:1527272020132};\\\", \\\"{x:1337,y:566,t:1527272020149};\\\", \\\"{x:1341,y:541,t:1527272020164};\\\", \\\"{x:1341,y:522,t:1527272020181};\\\", \\\"{x:1342,y:507,t:1527272020198};\\\", \\\"{x:1343,y:495,t:1527272020215};\\\", \\\"{x:1343,y:490,t:1527272020231};\\\", \\\"{x:1343,y:486,t:1527272020248};\\\", \\\"{x:1343,y:482,t:1527272020264};\\\", \\\"{x:1343,y:477,t:1527272020282};\\\", \\\"{x:1343,y:474,t:1527272020299};\\\", \\\"{x:1343,y:472,t:1527272020315};\\\", \\\"{x:1343,y:470,t:1527272020331};\\\", \\\"{x:1342,y:469,t:1527272020349};\\\", \\\"{x:1341,y:469,t:1527272020381};\\\", \\\"{x:1328,y:469,t:1527272020399};\\\", \\\"{x:1290,y:473,t:1527272020415};\\\", \\\"{x:1254,y:483,t:1527272020432};\\\", \\\"{x:1226,y:491,t:1527272020448};\\\", \\\"{x:1197,y:496,t:1527272020464};\\\", \\\"{x:1176,y:497,t:1527272020481};\\\", \\\"{x:1163,y:498,t:1527272020498};\\\", \\\"{x:1157,y:498,t:1527272020514};\\\", \\\"{x:1153,y:498,t:1527272020530};\\\", \\\"{x:1147,y:499,t:1527272020548};\\\", \\\"{x:1144,y:499,t:1527272020565};\\\", \\\"{x:1141,y:499,t:1527272020581};\\\", \\\"{x:1140,y:499,t:1527272020620};\\\", \\\"{x:1140,y:498,t:1527272020636};\\\", \\\"{x:1140,y:493,t:1527272020648};\\\", \\\"{x:1140,y:484,t:1527272020665};\\\", \\\"{x:1139,y:466,t:1527272020681};\\\", \\\"{x:1132,y:445,t:1527272020698};\\\", \\\"{x:1124,y:427,t:1527272020715};\\\", \\\"{x:1121,y:418,t:1527272020731};\\\", \\\"{x:1119,y:418,t:1527272020805};\\\", \\\"{x:1115,y:418,t:1527272020814};\\\", \\\"{x:1107,y:420,t:1527272020831};\\\", \\\"{x:1099,y:424,t:1527272020848};\\\", \\\"{x:1086,y:428,t:1527272020865};\\\", \\\"{x:1074,y:431,t:1527272020881};\\\", \\\"{x:1067,y:434,t:1527272020899};\\\", \\\"{x:1063,y:437,t:1527272020916};\\\", \\\"{x:1062,y:439,t:1527272020933};\\\", \\\"{x:1059,y:447,t:1527272020948};\\\", \\\"{x:1057,y:457,t:1527272020964};\\\", \\\"{x:1057,y:469,t:1527272020981};\\\", \\\"{x:1056,y:482,t:1527272020998};\\\", \\\"{x:1056,y:490,t:1527272021016};\\\", \\\"{x:1057,y:501,t:1527272021031};\\\", \\\"{x:1059,y:511,t:1527272021049};\\\", \\\"{x:1062,y:526,t:1527272021064};\\\", \\\"{x:1070,y:552,t:1527272021081};\\\", \\\"{x:1079,y:577,t:1527272021098};\\\", \\\"{x:1085,y:591,t:1527272021116};\\\", \\\"{x:1091,y:599,t:1527272021132};\\\", \\\"{x:1096,y:601,t:1527272021148};\\\", \\\"{x:1097,y:601,t:1527272021165};\\\", \\\"{x:1101,y:601,t:1527272021213};\\\", \\\"{x:1108,y:602,t:1527272021221};\\\", \\\"{x:1114,y:603,t:1527272021231};\\\", \\\"{x:1126,y:605,t:1527272021249};\\\", \\\"{x:1132,y:606,t:1527272021265};\\\", \\\"{x:1133,y:606,t:1527272021281};\\\", \\\"{x:1134,y:606,t:1527272021299};\\\", \\\"{x:1137,y:606,t:1527272021324};\\\", \\\"{x:1141,y:606,t:1527272021334};\\\", \\\"{x:1161,y:607,t:1527272021347};\\\", \\\"{x:1188,y:607,t:1527272021365};\\\", \\\"{x:1216,y:608,t:1527272021381};\\\", \\\"{x:1243,y:608,t:1527272021398};\\\", \\\"{x:1256,y:608,t:1527272021415};\\\", \\\"{x:1259,y:608,t:1527272021431};\\\", \\\"{x:1260,y:606,t:1527272021484};\\\", \\\"{x:1262,y:603,t:1527272021498};\\\", \\\"{x:1263,y:602,t:1527272021515};\\\", \\\"{x:1264,y:600,t:1527272021532};\\\", \\\"{x:1266,y:598,t:1527272021549};\\\", \\\"{x:1266,y:597,t:1527272021566};\\\", \\\"{x:1266,y:596,t:1527272021589};\\\", \\\"{x:1267,y:595,t:1527272021598};\\\", \\\"{x:1267,y:593,t:1527272021616};\\\", \\\"{x:1270,y:590,t:1527272021632};\\\", \\\"{x:1271,y:586,t:1527272021649};\\\", \\\"{x:1273,y:583,t:1527272021666};\\\", \\\"{x:1274,y:580,t:1527272021682};\\\", \\\"{x:1275,y:578,t:1527272021699};\\\", \\\"{x:1275,y:577,t:1527272021716};\\\", \\\"{x:1275,y:575,t:1527272021732};\\\", \\\"{x:1275,y:569,t:1527272021749};\\\", \\\"{x:1275,y:566,t:1527272021765};\\\", \\\"{x:1273,y:564,t:1527272021782};\\\", \\\"{x:1273,y:563,t:1527272021973};\\\", \\\"{x:1273,y:561,t:1527272021982};\\\", \\\"{x:1278,y:559,t:1527272022001};\\\", \\\"{x:1280,y:558,t:1527272022015};\\\", \\\"{x:1284,y:558,t:1527272022031};\\\", \\\"{x:1287,y:558,t:1527272022048};\\\", \\\"{x:1290,y:558,t:1527272022065};\\\", \\\"{x:1295,y:557,t:1527272022081};\\\", \\\"{x:1303,y:557,t:1527272022098};\\\", \\\"{x:1322,y:557,t:1527272022115};\\\", \\\"{x:1342,y:557,t:1527272022131};\\\", \\\"{x:1372,y:557,t:1527272022148};\\\", \\\"{x:1387,y:557,t:1527272022165};\\\", \\\"{x:1394,y:557,t:1527272022181};\\\", \\\"{x:1395,y:557,t:1527272022198};\\\", \\\"{x:1400,y:557,t:1527272022215};\\\", \\\"{x:1411,y:557,t:1527272022231};\\\", \\\"{x:1427,y:557,t:1527272022248};\\\", \\\"{x:1440,y:557,t:1527272022265};\\\", \\\"{x:1451,y:557,t:1527272022281};\\\", \\\"{x:1454,y:557,t:1527272022298};\\\", \\\"{x:1452,y:555,t:1527272022373};\\\", \\\"{x:1450,y:555,t:1527272022381};\\\", \\\"{x:1443,y:555,t:1527272022398};\\\", \\\"{x:1439,y:555,t:1527272022415};\\\", \\\"{x:1432,y:556,t:1527272022431};\\\", \\\"{x:1411,y:559,t:1527272022448};\\\", \\\"{x:1371,y:561,t:1527272022465};\\\", \\\"{x:1299,y:561,t:1527272022482};\\\", \\\"{x:1196,y:561,t:1527272022498};\\\", \\\"{x:1088,y:561,t:1527272022515};\\\", \\\"{x:941,y:561,t:1527272022532};\\\", \\\"{x:874,y:561,t:1527272022548};\\\", \\\"{x:827,y:561,t:1527272022565};\\\", \\\"{x:795,y:561,t:1527272022581};\\\", \\\"{x:772,y:561,t:1527272022598};\\\", \\\"{x:749,y:561,t:1527272022615};\\\", \\\"{x:724,y:561,t:1527272022631};\\\", \\\"{x:708,y:560,t:1527272022648};\\\", \\\"{x:704,y:558,t:1527272022665};\\\", \\\"{x:702,y:558,t:1527272022682};\\\", \\\"{x:699,y:558,t:1527272022699};\\\", \\\"{x:693,y:555,t:1527272022716};\\\", \\\"{x:682,y:550,t:1527272022731};\\\", \\\"{x:674,y:542,t:1527272022748};\\\", \\\"{x:672,y:541,t:1527272022760};\\\", \\\"{x:663,y:533,t:1527272022778};\\\", \\\"{x:652,y:525,t:1527272022794};\\\", \\\"{x:637,y:519,t:1527272022812};\\\", \\\"{x:605,y:519,t:1527272022828};\\\", \\\"{x:581,y:519,t:1527272022851};\\\", \\\"{x:575,y:519,t:1527272022867};\\\", \\\"{x:574,y:519,t:1527272022948};\\\", \\\"{x:574,y:517,t:1527272022957};\\\", \\\"{x:575,y:515,t:1527272022967};\\\", \\\"{x:580,y:509,t:1527272022984};\\\", \\\"{x:586,y:506,t:1527272023000};\\\", \\\"{x:593,y:503,t:1527272023018};\\\", \\\"{x:597,y:501,t:1527272023034};\\\", \\\"{x:600,y:500,t:1527272023051};\\\", \\\"{x:602,y:499,t:1527272023068};\\\", \\\"{x:606,y:498,t:1527272023084};\\\", \\\"{x:611,y:495,t:1527272023101};\\\", \\\"{x:613,y:494,t:1527272023118};\\\", \\\"{x:614,y:494,t:1527272023134};\\\", \\\"{x:613,y:494,t:1527272023269};\\\", \\\"{x:610,y:494,t:1527272023284};\\\", \\\"{x:609,y:495,t:1527272023301};\\\", \\\"{x:609,y:497,t:1527272023724};\\\", \\\"{x:613,y:503,t:1527272023735};\\\", \\\"{x:636,y:518,t:1527272023752};\\\", \\\"{x:665,y:533,t:1527272023768};\\\", \\\"{x:712,y:547,t:1527272023785};\\\", \\\"{x:779,y:566,t:1527272023801};\\\", \\\"{x:858,y:581,t:1527272023818};\\\", \\\"{x:939,y:594,t:1527272023835};\\\", \\\"{x:1019,y:605,t:1527272023851};\\\", \\\"{x:1084,y:611,t:1527272023868};\\\", \\\"{x:1094,y:611,t:1527272023885};\\\", \\\"{x:1093,y:611,t:1527272023923};\\\", \\\"{x:1086,y:607,t:1527272023935};\\\", \\\"{x:1059,y:600,t:1527272023952};\\\", \\\"{x:1021,y:592,t:1527272023968};\\\", \\\"{x:966,y:581,t:1527272023986};\\\", \\\"{x:920,y:576,t:1527272024003};\\\", \\\"{x:899,y:576,t:1527272024018};\\\", \\\"{x:898,y:576,t:1527272024035};\\\", \\\"{x:897,y:576,t:1527272024068};\\\", \\\"{x:897,y:575,t:1527272024085};\\\", \\\"{x:898,y:574,t:1527272024101};\\\", \\\"{x:898,y:573,t:1527272024118};\\\", \\\"{x:899,y:573,t:1527272024156};\\\", \\\"{x:900,y:572,t:1527272024169};\\\", \\\"{x:902,y:571,t:1527272024185};\\\", \\\"{x:902,y:569,t:1527272024202};\\\", \\\"{x:902,y:565,t:1527272024219};\\\", \\\"{x:896,y:559,t:1527272024236};\\\", \\\"{x:888,y:555,t:1527272024252};\\\", \\\"{x:879,y:551,t:1527272024269};\\\", \\\"{x:868,y:549,t:1527272024285};\\\", \\\"{x:849,y:545,t:1527272024302};\\\", \\\"{x:839,y:544,t:1527272024319};\\\", \\\"{x:835,y:542,t:1527272024335};\\\", \\\"{x:831,y:541,t:1527272024352};\\\", \\\"{x:830,y:541,t:1527272024369};\\\", \\\"{x:831,y:540,t:1527272024420};\\\", \\\"{x:832,y:540,t:1527272024501};\\\", \\\"{x:832,y:541,t:1527272024708};\\\", \\\"{x:832,y:548,t:1527272024719};\\\", \\\"{x:819,y:571,t:1527272024737};\\\", \\\"{x:796,y:604,t:1527272024753};\\\", \\\"{x:758,y:648,t:1527272024769};\\\", \\\"{x:724,y:681,t:1527272024785};\\\", \\\"{x:689,y:701,t:1527272024802};\\\", \\\"{x:663,y:709,t:1527272024819};\\\", \\\"{x:630,y:716,t:1527272024836};\\\", \\\"{x:621,y:719,t:1527272024852};\\\", \\\"{x:615,y:722,t:1527272024869};\\\", \\\"{x:608,y:724,t:1527272024886};\\\", \\\"{x:593,y:732,t:1527272024903};\\\", \\\"{x:582,y:737,t:1527272024919};\\\", \\\"{x:570,y:743,t:1527272024936};\\\", \\\"{x:564,y:743,t:1527272024953};\\\", \\\"{x:557,y:743,t:1527272024969};\\\", \\\"{x:548,y:741,t:1527272024987};\\\", \\\"{x:538,y:736,t:1527272025004};\\\", \\\"{x:531,y:732,t:1527272025019};\\\", \\\"{x:527,y:728,t:1527272025037};\\\", \\\"{x:525,y:726,t:1527272025053};\\\", \\\"{x:524,y:726,t:1527272025331};\\\", \\\"{x:524,y:725,t:1527272025589};\\\", \\\"{x:524,y:724,t:1527272025684};\\\", \\\"{x:525,y:723,t:1527272025692};\\\" ] }, { \\\"rt\\\": 22127, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 465098, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -F -B -B -F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:722,t:1527272026876};\\\", \\\"{x:527,y:718,t:1527272026887};\\\", \\\"{x:535,y:698,t:1527272026905};\\\", \\\"{x:541,y:681,t:1527272026920};\\\", \\\"{x:546,y:662,t:1527272026937};\\\", \\\"{x:551,y:638,t:1527272026954};\\\", \\\"{x:555,y:615,t:1527272026971};\\\", \\\"{x:561,y:588,t:1527272026987};\\\", \\\"{x:564,y:554,t:1527272027004};\\\", \\\"{x:564,y:531,t:1527272027021};\\\", \\\"{x:564,y:489,t:1527272027109};\\\", \\\"{x:561,y:487,t:1527272027123};\\\", \\\"{x:548,y:482,t:1527272027138};\\\", \\\"{x:528,y:477,t:1527272027154};\\\", \\\"{x:510,y:473,t:1527272027171};\\\", \\\"{x:495,y:471,t:1527272027187};\\\", \\\"{x:478,y:470,t:1527272027204};\\\", \\\"{x:472,y:470,t:1527272027221};\\\", \\\"{x:462,y:470,t:1527272027237};\\\", \\\"{x:452,y:470,t:1527272027254};\\\", \\\"{x:444,y:470,t:1527272027271};\\\", \\\"{x:438,y:471,t:1527272027287};\\\", \\\"{x:433,y:471,t:1527272027304};\\\", \\\"{x:430,y:472,t:1527272027321};\\\", \\\"{x:429,y:472,t:1527272027337};\\\", \\\"{x:428,y:472,t:1527272027354};\\\", \\\"{x:429,y:472,t:1527272027476};\\\", \\\"{x:432,y:470,t:1527272027488};\\\", \\\"{x:438,y:468,t:1527272027504};\\\", \\\"{x:441,y:466,t:1527272027521};\\\", \\\"{x:445,y:464,t:1527272027538};\\\", \\\"{x:448,y:462,t:1527272027555};\\\", \\\"{x:451,y:461,t:1527272027572};\\\", \\\"{x:454,y:460,t:1527272027588};\\\", \\\"{x:455,y:460,t:1527272027629};\\\", \\\"{x:456,y:460,t:1527272027717};\\\", \\\"{x:458,y:459,t:1527272027725};\\\", \\\"{x:460,y:459,t:1527272027738};\\\", \\\"{x:461,y:459,t:1527272027754};\\\", \\\"{x:463,y:458,t:1527272027771};\\\", \\\"{x:464,y:458,t:1527272027820};\\\", \\\"{x:466,y:457,t:1527272027900};\\\", \\\"{x:467,y:457,t:1527272027924};\\\", \\\"{x:468,y:456,t:1527272027938};\\\", \\\"{x:469,y:456,t:1527272027973};\\\", \\\"{x:470,y:455,t:1527272027997};\\\", \\\"{x:471,y:455,t:1527272028045};\\\", \\\"{x:472,y:455,t:1527272028061};\\\", \\\"{x:473,y:455,t:1527272028109};\\\", \\\"{x:474,y:455,t:1527272028124};\\\", \\\"{x:474,y:454,t:1527272028139};\\\", \\\"{x:475,y:454,t:1527272028156};\\\", \\\"{x:476,y:453,t:1527272028171};\\\", \\\"{x:477,y:453,t:1527272028589};\\\", \\\"{x:480,y:452,t:1527272028605};\\\", \\\"{x:491,y:452,t:1527272028623};\\\", \\\"{x:504,y:454,t:1527272028638};\\\", \\\"{x:513,y:456,t:1527272028656};\\\", \\\"{x:526,y:460,t:1527272028672};\\\", \\\"{x:537,y:464,t:1527272028688};\\\", \\\"{x:541,y:465,t:1527272028705};\\\", \\\"{x:544,y:466,t:1527272028723};\\\", \\\"{x:545,y:466,t:1527272028738};\\\", \\\"{x:546,y:466,t:1527272028755};\\\", \\\"{x:547,y:466,t:1527272028772};\\\", \\\"{x:551,y:466,t:1527272028788};\\\", \\\"{x:554,y:467,t:1527272028805};\\\", \\\"{x:564,y:469,t:1527272028822};\\\", \\\"{x:579,y:472,t:1527272028838};\\\", \\\"{x:604,y:476,t:1527272028855};\\\", \\\"{x:630,y:480,t:1527272028872};\\\", \\\"{x:661,y:485,t:1527272028888};\\\", \\\"{x:695,y:490,t:1527272028906};\\\", \\\"{x:721,y:493,t:1527272028922};\\\", \\\"{x:744,y:497,t:1527272028940};\\\", \\\"{x:764,y:500,t:1527272028956};\\\", \\\"{x:769,y:500,t:1527272028972};\\\", \\\"{x:769,y:501,t:1527272029469};\\\", \\\"{x:769,y:502,t:1527272029476};\\\", \\\"{x:764,y:505,t:1527272029489};\\\", \\\"{x:755,y:507,t:1527272029506};\\\", \\\"{x:748,y:508,t:1527272029522};\\\", \\\"{x:741,y:508,t:1527272029540};\\\", \\\"{x:733,y:507,t:1527272029556};\\\", \\\"{x:731,y:506,t:1527272029572};\\\", \\\"{x:727,y:505,t:1527272029590};\\\", \\\"{x:722,y:504,t:1527272029608};\\\", \\\"{x:716,y:502,t:1527272029623};\\\", \\\"{x:710,y:501,t:1527272029639};\\\", \\\"{x:702,y:498,t:1527272029656};\\\", \\\"{x:691,y:497,t:1527272029673};\\\", \\\"{x:676,y:495,t:1527272029690};\\\", \\\"{x:659,y:491,t:1527272029706};\\\", \\\"{x:638,y:489,t:1527272029723};\\\", \\\"{x:599,y:483,t:1527272029739};\\\", \\\"{x:565,y:478,t:1527272029757};\\\", \\\"{x:523,y:471,t:1527272029774};\\\", \\\"{x:477,y:464,t:1527272029790};\\\", \\\"{x:435,y:458,t:1527272029807};\\\", \\\"{x:412,y:457,t:1527272029824};\\\", \\\"{x:398,y:457,t:1527272029839};\\\", \\\"{x:392,y:457,t:1527272029857};\\\", \\\"{x:390,y:457,t:1527272029874};\\\", \\\"{x:389,y:457,t:1527272029890};\\\", \\\"{x:388,y:457,t:1527272029933};\\\", \\\"{x:389,y:457,t:1527272030453};\\\", \\\"{x:391,y:457,t:1527272030461};\\\", \\\"{x:393,y:456,t:1527272030474};\\\", \\\"{x:396,y:455,t:1527272030491};\\\", \\\"{x:398,y:454,t:1527272030508};\\\", \\\"{x:402,y:453,t:1527272030525};\\\", \\\"{x:403,y:453,t:1527272030540};\\\", \\\"{x:405,y:453,t:1527272030558};\\\", \\\"{x:405,y:452,t:1527272030574};\\\", \\\"{x:406,y:452,t:1527272030596};\\\", \\\"{x:408,y:452,t:1527272030661};\\\", \\\"{x:411,y:451,t:1527272030674};\\\", \\\"{x:415,y:449,t:1527272030691};\\\", \\\"{x:420,y:447,t:1527272030708};\\\", \\\"{x:422,y:446,t:1527272030724};\\\", \\\"{x:423,y:446,t:1527272030741};\\\", \\\"{x:425,y:445,t:1527272030758};\\\", \\\"{x:429,y:445,t:1527272030774};\\\", \\\"{x:445,y:446,t:1527272030791};\\\", \\\"{x:466,y:451,t:1527272030807};\\\", \\\"{x:483,y:456,t:1527272030825};\\\", \\\"{x:498,y:460,t:1527272030841};\\\", \\\"{x:509,y:463,t:1527272030858};\\\", \\\"{x:513,y:464,t:1527272030875};\\\", \\\"{x:515,y:465,t:1527272030891};\\\", \\\"{x:518,y:465,t:1527272031005};\\\", \\\"{x:521,y:465,t:1527272031012};\\\", \\\"{x:526,y:464,t:1527272031025};\\\", \\\"{x:544,y:464,t:1527272031041};\\\", \\\"{x:563,y:464,t:1527272031058};\\\", \\\"{x:582,y:464,t:1527272031075};\\\", \\\"{x:597,y:464,t:1527272031090};\\\", \\\"{x:606,y:464,t:1527272031107};\\\", \\\"{x:607,y:464,t:1527272031124};\\\", \\\"{x:609,y:463,t:1527272031405};\\\", \\\"{x:610,y:463,t:1527272031421};\\\", \\\"{x:611,y:463,t:1527272031428};\\\", \\\"{x:613,y:462,t:1527272031442};\\\", \\\"{x:614,y:461,t:1527272031517};\\\", \\\"{x:615,y:461,t:1527272031525};\\\", \\\"{x:620,y:461,t:1527272031542};\\\", \\\"{x:628,y:461,t:1527272031558};\\\", \\\"{x:644,y:461,t:1527272031575};\\\", \\\"{x:656,y:461,t:1527272031592};\\\", \\\"{x:667,y:461,t:1527272031608};\\\", \\\"{x:678,y:461,t:1527272031625};\\\", \\\"{x:693,y:461,t:1527272031642};\\\", \\\"{x:711,y:461,t:1527272031658};\\\", \\\"{x:726,y:461,t:1527272031674};\\\", \\\"{x:739,y:461,t:1527272031692};\\\", \\\"{x:743,y:461,t:1527272031709};\\\", \\\"{x:744,y:460,t:1527272031996};\\\", \\\"{x:743,y:460,t:1527272032012};\\\", \\\"{x:741,y:460,t:1527272032025};\\\", \\\"{x:739,y:461,t:1527272032042};\\\", \\\"{x:737,y:461,t:1527272032059};\\\", \\\"{x:735,y:460,t:1527272032075};\\\", \\\"{x:731,y:460,t:1527272032092};\\\", \\\"{x:726,y:458,t:1527272032109};\\\", \\\"{x:724,y:457,t:1527272032125};\\\", \\\"{x:723,y:458,t:1527272035253};\\\", \\\"{x:723,y:465,t:1527272035261};\\\", \\\"{x:723,y:476,t:1527272035278};\\\", \\\"{x:723,y:486,t:1527272035295};\\\", \\\"{x:723,y:489,t:1527272035312};\\\", \\\"{x:723,y:494,t:1527272035328};\\\", \\\"{x:724,y:505,t:1527272035345};\\\", \\\"{x:729,y:522,t:1527272035362};\\\", \\\"{x:739,y:540,t:1527272035378};\\\", \\\"{x:751,y:558,t:1527272035395};\\\", \\\"{x:765,y:576,t:1527272035411};\\\", \\\"{x:800,y:607,t:1527272035428};\\\", \\\"{x:841,y:640,t:1527272035445};\\\", \\\"{x:907,y:685,t:1527272035461};\\\", \\\"{x:975,y:719,t:1527272035478};\\\", \\\"{x:1036,y:745,t:1527272035495};\\\", \\\"{x:1095,y:777,t:1527272035511};\\\", \\\"{x:1154,y:820,t:1527272035528};\\\", \\\"{x:1200,y:854,t:1527272035545};\\\", \\\"{x:1234,y:878,t:1527272035561};\\\", \\\"{x:1254,y:892,t:1527272035577};\\\", \\\"{x:1271,y:902,t:1527272035595};\\\", \\\"{x:1288,y:912,t:1527272035611};\\\", \\\"{x:1297,y:914,t:1527272035627};\\\", \\\"{x:1297,y:915,t:1527272035645};\\\", \\\"{x:1294,y:910,t:1527272035717};\\\", \\\"{x:1288,y:905,t:1527272035728};\\\", \\\"{x:1278,y:897,t:1527272035744};\\\", \\\"{x:1270,y:891,t:1527272035762};\\\", \\\"{x:1262,y:887,t:1527272035779};\\\", \\\"{x:1255,y:883,t:1527272035795};\\\", \\\"{x:1249,y:879,t:1527272035813};\\\", \\\"{x:1244,y:874,t:1527272035829};\\\", \\\"{x:1238,y:869,t:1527272035845};\\\", \\\"{x:1229,y:864,t:1527272035862};\\\", \\\"{x:1226,y:861,t:1527272035879};\\\", \\\"{x:1225,y:861,t:1527272035908};\\\", \\\"{x:1225,y:860,t:1527272038259};\\\", \\\"{x:1230,y:857,t:1527272038267};\\\", \\\"{x:1237,y:854,t:1527272038281};\\\", \\\"{x:1244,y:852,t:1527272038298};\\\", \\\"{x:1249,y:848,t:1527272038315};\\\", \\\"{x:1255,y:846,t:1527272038331};\\\", \\\"{x:1264,y:842,t:1527272038347};\\\", \\\"{x:1276,y:828,t:1527272038365};\\\", \\\"{x:1294,y:797,t:1527272038382};\\\", \\\"{x:1309,y:767,t:1527272038398};\\\", \\\"{x:1315,y:751,t:1527272038415};\\\", \\\"{x:1318,y:741,t:1527272038432};\\\", \\\"{x:1318,y:735,t:1527272038448};\\\", \\\"{x:1318,y:730,t:1527272038465};\\\", \\\"{x:1318,y:727,t:1527272038482};\\\", \\\"{x:1318,y:726,t:1527272038497};\\\", \\\"{x:1318,y:724,t:1527272038515};\\\", \\\"{x:1318,y:722,t:1527272038531};\\\", \\\"{x:1318,y:720,t:1527272038548};\\\", \\\"{x:1318,y:718,t:1527272038565};\\\", \\\"{x:1318,y:717,t:1527272038582};\\\", \\\"{x:1318,y:715,t:1527272038598};\\\", \\\"{x:1318,y:714,t:1527272038661};\\\", \\\"{x:1320,y:713,t:1527272038676};\\\", \\\"{x:1322,y:712,t:1527272038693};\\\", \\\"{x:1323,y:711,t:1527272038700};\\\", \\\"{x:1324,y:710,t:1527272038716};\\\", \\\"{x:1330,y:707,t:1527272038731};\\\", \\\"{x:1333,y:705,t:1527272038749};\\\", \\\"{x:1336,y:702,t:1527272038765};\\\", \\\"{x:1338,y:699,t:1527272038782};\\\", \\\"{x:1339,y:696,t:1527272038799};\\\", \\\"{x:1339,y:694,t:1527272038815};\\\", \\\"{x:1339,y:693,t:1527272038832};\\\", \\\"{x:1339,y:691,t:1527272038848};\\\", \\\"{x:1340,y:691,t:1527272038876};\\\", \\\"{x:1340,y:693,t:1527272039117};\\\", \\\"{x:1340,y:697,t:1527272039133};\\\", \\\"{x:1340,y:702,t:1527272039149};\\\", \\\"{x:1340,y:708,t:1527272039166};\\\", \\\"{x:1341,y:713,t:1527272039182};\\\", \\\"{x:1342,y:718,t:1527272039199};\\\", \\\"{x:1343,y:723,t:1527272039216};\\\", \\\"{x:1343,y:728,t:1527272039233};\\\", \\\"{x:1344,y:732,t:1527272039249};\\\", \\\"{x:1345,y:736,t:1527272039266};\\\", \\\"{x:1345,y:738,t:1527272039282};\\\", \\\"{x:1345,y:740,t:1527272039299};\\\", \\\"{x:1345,y:742,t:1527272039316};\\\", \\\"{x:1345,y:743,t:1527272039333};\\\", \\\"{x:1345,y:745,t:1527272039349};\\\", \\\"{x:1345,y:746,t:1527272039367};\\\", \\\"{x:1345,y:749,t:1527272039383};\\\", \\\"{x:1345,y:750,t:1527272039412};\\\", \\\"{x:1345,y:751,t:1527272039436};\\\", \\\"{x:1345,y:752,t:1527272039449};\\\", \\\"{x:1345,y:753,t:1527272039501};\\\", \\\"{x:1345,y:754,t:1527272039516};\\\", \\\"{x:1345,y:757,t:1527272039534};\\\", \\\"{x:1344,y:758,t:1527272039550};\\\", \\\"{x:1344,y:759,t:1527272039569};\\\", \\\"{x:1344,y:758,t:1527272039684};\\\", \\\"{x:1344,y:743,t:1527272039700};\\\", \\\"{x:1344,y:730,t:1527272039716};\\\", \\\"{x:1344,y:719,t:1527272039733};\\\", \\\"{x:1346,y:715,t:1527272039750};\\\", \\\"{x:1346,y:711,t:1527272039767};\\\", \\\"{x:1346,y:709,t:1527272039783};\\\", \\\"{x:1346,y:708,t:1527272039800};\\\", \\\"{x:1346,y:706,t:1527272039817};\\\", \\\"{x:1347,y:706,t:1527272039833};\\\", \\\"{x:1347,y:705,t:1527272040061};\\\", \\\"{x:1347,y:703,t:1527272040076};\\\", \\\"{x:1347,y:702,t:1527272040093};\\\", \\\"{x:1347,y:701,t:1527272040100};\\\", \\\"{x:1347,y:700,t:1527272040117};\\\", \\\"{x:1346,y:698,t:1527272040135};\\\", \\\"{x:1346,y:697,t:1527272040150};\\\", \\\"{x:1346,y:696,t:1527272040196};\\\", \\\"{x:1346,y:695,t:1527272040204};\\\", \\\"{x:1346,y:694,t:1527272040216};\\\", \\\"{x:1346,y:697,t:1527272040437};\\\", \\\"{x:1346,y:698,t:1527272040451};\\\", \\\"{x:1346,y:701,t:1527272040467};\\\", \\\"{x:1346,y:704,t:1527272040485};\\\", \\\"{x:1346,y:706,t:1527272040500};\\\", \\\"{x:1346,y:709,t:1527272040518};\\\", \\\"{x:1346,y:715,t:1527272040534};\\\", \\\"{x:1346,y:723,t:1527272040551};\\\", \\\"{x:1346,y:733,t:1527272040567};\\\", \\\"{x:1346,y:736,t:1527272040584};\\\", \\\"{x:1346,y:738,t:1527272040601};\\\", \\\"{x:1346,y:739,t:1527272040618};\\\", \\\"{x:1346,y:741,t:1527272040635};\\\", \\\"{x:1346,y:742,t:1527272040652};\\\", \\\"{x:1346,y:745,t:1527272040669};\\\", \\\"{x:1345,y:747,t:1527272040683};\\\", \\\"{x:1345,y:748,t:1527272040701};\\\", \\\"{x:1345,y:751,t:1527272040719};\\\", \\\"{x:1344,y:752,t:1527272040756};\\\", \\\"{x:1343,y:753,t:1527272040768};\\\", \\\"{x:1343,y:754,t:1527272040784};\\\", \\\"{x:1343,y:756,t:1527272040801};\\\", \\\"{x:1343,y:757,t:1527272040819};\\\", \\\"{x:1342,y:758,t:1527272040834};\\\", \\\"{x:1342,y:759,t:1527272040852};\\\", \\\"{x:1342,y:760,t:1527272040868};\\\", \\\"{x:1342,y:761,t:1527272040901};\\\", \\\"{x:1342,y:762,t:1527272040920};\\\", \\\"{x:1342,y:763,t:1527272040951};\\\", \\\"{x:1341,y:763,t:1527272040970};\\\", \\\"{x:1341,y:764,t:1527272041021};\\\", \\\"{x:1340,y:764,t:1527272041421};\\\", \\\"{x:1339,y:763,t:1527272041436};\\\", \\\"{x:1339,y:755,t:1527272041453};\\\", \\\"{x:1337,y:751,t:1527272041469};\\\", \\\"{x:1336,y:749,t:1527272041485};\\\", \\\"{x:1336,y:746,t:1527272041502};\\\", \\\"{x:1336,y:745,t:1527272041520};\\\", \\\"{x:1336,y:741,t:1527272041536};\\\", \\\"{x:1336,y:738,t:1527272041553};\\\", \\\"{x:1336,y:732,t:1527272041570};\\\", \\\"{x:1336,y:730,t:1527272041585};\\\", \\\"{x:1336,y:727,t:1527272041603};\\\", \\\"{x:1336,y:724,t:1527272041619};\\\", \\\"{x:1336,y:720,t:1527272041636};\\\", \\\"{x:1336,y:716,t:1527272041653};\\\", \\\"{x:1337,y:714,t:1527272041669};\\\", \\\"{x:1338,y:711,t:1527272041685};\\\", \\\"{x:1338,y:708,t:1527272041702};\\\", \\\"{x:1340,y:707,t:1527272041720};\\\", \\\"{x:1340,y:705,t:1527272041735};\\\", \\\"{x:1341,y:703,t:1527272041753};\\\", \\\"{x:1343,y:702,t:1527272041769};\\\", \\\"{x:1344,y:701,t:1527272041797};\\\", \\\"{x:1345,y:700,t:1527272041820};\\\", \\\"{x:1346,y:699,t:1527272041852};\\\", \\\"{x:1347,y:698,t:1527272041900};\\\", \\\"{x:1348,y:697,t:1527272041949};\\\", \\\"{x:1348,y:698,t:1527272042061};\\\", \\\"{x:1348,y:701,t:1527272042069};\\\", \\\"{x:1348,y:706,t:1527272042088};\\\", \\\"{x:1348,y:709,t:1527272042104};\\\", \\\"{x:1348,y:713,t:1527272042121};\\\", \\\"{x:1348,y:716,t:1527272042136};\\\", \\\"{x:1348,y:721,t:1527272042153};\\\", \\\"{x:1348,y:725,t:1527272042168};\\\", \\\"{x:1348,y:728,t:1527272042186};\\\", \\\"{x:1348,y:731,t:1527272042203};\\\", \\\"{x:1348,y:734,t:1527272042219};\\\", \\\"{x:1348,y:740,t:1527272042236};\\\", \\\"{x:1346,y:741,t:1527272042253};\\\", \\\"{x:1346,y:745,t:1527272042269};\\\", \\\"{x:1346,y:747,t:1527272042285};\\\", \\\"{x:1346,y:750,t:1527272042303};\\\", \\\"{x:1345,y:754,t:1527272042320};\\\", \\\"{x:1341,y:761,t:1527272042336};\\\", \\\"{x:1329,y:769,t:1527272042353};\\\", \\\"{x:1301,y:780,t:1527272042370};\\\", \\\"{x:1241,y:783,t:1527272042386};\\\", \\\"{x:1129,y:780,t:1527272042403};\\\", \\\"{x:891,y:731,t:1527272042419};\\\", \\\"{x:801,y:711,t:1527272042436};\\\", \\\"{x:556,y:655,t:1527272042453};\\\", \\\"{x:462,y:628,t:1527272042472};\\\", \\\"{x:413,y:611,t:1527272042486};\\\", \\\"{x:397,y:603,t:1527272042503};\\\", \\\"{x:397,y:601,t:1527272042548};\\\", \\\"{x:397,y:599,t:1527272042556};\\\", \\\"{x:399,y:595,t:1527272042565};\\\", \\\"{x:405,y:585,t:1527272042584};\\\", \\\"{x:414,y:573,t:1527272042599};\\\", \\\"{x:420,y:566,t:1527272042617};\\\", \\\"{x:425,y:560,t:1527272042634};\\\", \\\"{x:429,y:555,t:1527272042650};\\\", \\\"{x:433,y:550,t:1527272042666};\\\", \\\"{x:436,y:544,t:1527272042684};\\\", \\\"{x:436,y:538,t:1527272042700};\\\", \\\"{x:439,y:534,t:1527272042717};\\\", \\\"{x:439,y:530,t:1527272042734};\\\", \\\"{x:439,y:527,t:1527272042750};\\\", \\\"{x:434,y:523,t:1527272042768};\\\", \\\"{x:421,y:520,t:1527272042784};\\\", \\\"{x:397,y:515,t:1527272042801};\\\", \\\"{x:378,y:514,t:1527272042817};\\\", \\\"{x:365,y:514,t:1527272042834};\\\", \\\"{x:350,y:514,t:1527272042849};\\\", \\\"{x:333,y:520,t:1527272042867};\\\", \\\"{x:299,y:538,t:1527272042884};\\\", \\\"{x:281,y:556,t:1527272042901};\\\", \\\"{x:268,y:574,t:1527272042918};\\\", \\\"{x:261,y:585,t:1527272042933};\\\", \\\"{x:257,y:592,t:1527272042950};\\\", \\\"{x:257,y:602,t:1527272042967};\\\", \\\"{x:257,y:615,t:1527272042983};\\\", \\\"{x:268,y:627,t:1527272043000};\\\", \\\"{x:289,y:633,t:1527272043017};\\\", \\\"{x:317,y:638,t:1527272043034};\\\", \\\"{x:363,y:638,t:1527272043050};\\\", \\\"{x:419,y:638,t:1527272043067};\\\", \\\"{x:529,y:609,t:1527272043084};\\\", \\\"{x:586,y:589,t:1527272043101};\\\", \\\"{x:631,y:568,t:1527272043117};\\\", \\\"{x:654,y:556,t:1527272043134};\\\", \\\"{x:662,y:548,t:1527272043152};\\\", \\\"{x:664,y:543,t:1527272043167};\\\", \\\"{x:664,y:538,t:1527272043183};\\\", \\\"{x:664,y:536,t:1527272043201};\\\", \\\"{x:663,y:532,t:1527272043216};\\\", \\\"{x:659,y:531,t:1527272043233};\\\", \\\"{x:655,y:530,t:1527272043250};\\\", \\\"{x:651,y:529,t:1527272043267};\\\", \\\"{x:642,y:529,t:1527272043284};\\\", \\\"{x:635,y:529,t:1527272043300};\\\", \\\"{x:622,y:533,t:1527272043317};\\\", \\\"{x:602,y:544,t:1527272043334};\\\", \\\"{x:572,y:558,t:1527272043352};\\\", \\\"{x:525,y:577,t:1527272043369};\\\", \\\"{x:483,y:598,t:1527272043384};\\\", \\\"{x:459,y:610,t:1527272043401};\\\", \\\"{x:436,y:624,t:1527272043418};\\\", \\\"{x:422,y:634,t:1527272043434};\\\", \\\"{x:413,y:641,t:1527272043452};\\\", \\\"{x:404,y:656,t:1527272043467};\\\", \\\"{x:397,y:679,t:1527272043485};\\\", \\\"{x:385,y:723,t:1527272043501};\\\", \\\"{x:377,y:749,t:1527272043519};\\\", \\\"{x:371,y:762,t:1527272043534};\\\", \\\"{x:367,y:770,t:1527272043551};\\\", \\\"{x:363,y:771,t:1527272043568};\\\", \\\"{x:362,y:772,t:1527272043585};\\\", \\\"{x:359,y:768,t:1527272043620};\\\", \\\"{x:357,y:759,t:1527272043635};\\\", \\\"{x:353,y:744,t:1527272043651};\\\", \\\"{x:353,y:711,t:1527272043668};\\\", \\\"{x:353,y:691,t:1527272043685};\\\", \\\"{x:356,y:674,t:1527272043701};\\\", \\\"{x:361,y:659,t:1527272043719};\\\", \\\"{x:364,y:656,t:1527272043735};\\\", \\\"{x:369,y:652,t:1527272043751};\\\", \\\"{x:376,y:646,t:1527272043768};\\\", \\\"{x:386,y:638,t:1527272043785};\\\", \\\"{x:391,y:631,t:1527272043801};\\\", \\\"{x:399,y:623,t:1527272043818};\\\", \\\"{x:407,y:613,t:1527272043835};\\\", \\\"{x:425,y:601,t:1527272043851};\\\", \\\"{x:456,y:578,t:1527272043869};\\\", \\\"{x:484,y:564,t:1527272043885};\\\", \\\"{x:530,y:542,t:1527272043902};\\\", \\\"{x:598,y:515,t:1527272043919};\\\", \\\"{x:679,y:504,t:1527272043934};\\\", \\\"{x:752,y:491,t:1527272043951};\\\", \\\"{x:814,y:490,t:1527272043967};\\\", \\\"{x:856,y:490,t:1527272043985};\\\", \\\"{x:883,y:490,t:1527272044001};\\\", \\\"{x:891,y:490,t:1527272044017};\\\", \\\"{x:890,y:490,t:1527272044092};\\\", \\\"{x:887,y:490,t:1527272044100};\\\", \\\"{x:880,y:493,t:1527272044119};\\\", \\\"{x:875,y:495,t:1527272044135};\\\", \\\"{x:872,y:496,t:1527272044151};\\\", \\\"{x:870,y:497,t:1527272044168};\\\", \\\"{x:866,y:499,t:1527272044186};\\\", \\\"{x:862,y:501,t:1527272044201};\\\", \\\"{x:859,y:502,t:1527272044218};\\\", \\\"{x:857,y:503,t:1527272044235};\\\", \\\"{x:855,y:504,t:1527272044252};\\\", \\\"{x:854,y:504,t:1527272044388};\\\", \\\"{x:854,y:505,t:1527272044548};\\\", \\\"{x:852,y:506,t:1527272044563};\\\", \\\"{x:850,y:508,t:1527272044571};\\\", \\\"{x:848,y:508,t:1527272044588};\\\", \\\"{x:847,y:508,t:1527272044601};\\\", \\\"{x:845,y:508,t:1527272044635};\\\", \\\"{x:845,y:509,t:1527272044652};\\\", \\\"{x:844,y:509,t:1527272044995};\\\", \\\"{x:844,y:510,t:1527272045012};\\\", \\\"{x:843,y:511,t:1527272045027};\\\", \\\"{x:842,y:512,t:1527272045036};\\\", \\\"{x:841,y:512,t:1527272045052};\\\", \\\"{x:839,y:512,t:1527272045069};\\\", \\\"{x:838,y:514,t:1527272045086};\\\", \\\"{x:836,y:514,t:1527272045102};\\\", \\\"{x:829,y:518,t:1527272045119};\\\", \\\"{x:809,y:523,t:1527272045135};\\\", \\\"{x:784,y:529,t:1527272045153};\\\", \\\"{x:758,y:534,t:1527272045169};\\\", \\\"{x:727,y:538,t:1527272045186};\\\", \\\"{x:698,y:543,t:1527272045203};\\\", \\\"{x:667,y:544,t:1527272045219};\\\", \\\"{x:597,y:550,t:1527272045235};\\\", \\\"{x:546,y:550,t:1527272045251};\\\", \\\"{x:499,y:550,t:1527272045269};\\\", \\\"{x:446,y:543,t:1527272045286};\\\", \\\"{x:409,y:538,t:1527272045302};\\\", \\\"{x:384,y:532,t:1527272045318};\\\", \\\"{x:357,y:528,t:1527272045336};\\\", \\\"{x:326,y:528,t:1527272045351};\\\", \\\"{x:309,y:528,t:1527272045368};\\\", \\\"{x:298,y:528,t:1527272045385};\\\", \\\"{x:291,y:528,t:1527272045403};\\\", \\\"{x:282,y:528,t:1527272045419};\\\", \\\"{x:281,y:530,t:1527272045436};\\\", \\\"{x:275,y:534,t:1527272045453};\\\", \\\"{x:269,y:544,t:1527272045470};\\\", \\\"{x:261,y:563,t:1527272045486};\\\", \\\"{x:252,y:587,t:1527272045501};\\\", \\\"{x:247,y:608,t:1527272045520};\\\", \\\"{x:245,y:624,t:1527272045536};\\\", \\\"{x:245,y:638,t:1527272045553};\\\", \\\"{x:243,y:654,t:1527272045569};\\\", \\\"{x:243,y:669,t:1527272045586};\\\", \\\"{x:247,y:689,t:1527272045604};\\\", \\\"{x:248,y:695,t:1527272045619};\\\", \\\"{x:258,y:708,t:1527272045635};\\\", \\\"{x:264,y:710,t:1527272045653};\\\", \\\"{x:270,y:710,t:1527272045669};\\\", \\\"{x:281,y:710,t:1527272045686};\\\", \\\"{x:293,y:701,t:1527272045703};\\\", \\\"{x:310,y:688,t:1527272045719};\\\", \\\"{x:325,y:676,t:1527272045736};\\\", \\\"{x:337,y:659,t:1527272045753};\\\", \\\"{x:341,y:642,t:1527272045769};\\\", \\\"{x:341,y:628,t:1527272045787};\\\", \\\"{x:320,y:608,t:1527272045803};\\\", \\\"{x:310,y:603,t:1527272045819};\\\", \\\"{x:262,y:583,t:1527272045837};\\\", \\\"{x:236,y:576,t:1527272045853};\\\", \\\"{x:224,y:572,t:1527272045869};\\\", \\\"{x:221,y:569,t:1527272045886};\\\", \\\"{x:220,y:569,t:1527272045923};\\\", \\\"{x:220,y:567,t:1527272045936};\\\", \\\"{x:215,y:558,t:1527272045954};\\\", \\\"{x:210,y:551,t:1527272045969};\\\", \\\"{x:206,y:547,t:1527272045986};\\\", \\\"{x:205,y:545,t:1527272046003};\\\", \\\"{x:204,y:544,t:1527272046076};\\\", \\\"{x:203,y:544,t:1527272046087};\\\", \\\"{x:197,y:544,t:1527272046103};\\\", \\\"{x:188,y:544,t:1527272046121};\\\", \\\"{x:174,y:543,t:1527272046136};\\\", \\\"{x:161,y:541,t:1527272046153};\\\", \\\"{x:146,y:540,t:1527272046170};\\\", \\\"{x:140,y:539,t:1527272046186};\\\", \\\"{x:138,y:539,t:1527272046202};\\\", \\\"{x:138,y:540,t:1527272046268};\\\", \\\"{x:139,y:540,t:1527272046389};\\\", \\\"{x:140,y:540,t:1527272046404};\\\", \\\"{x:143,y:540,t:1527272046420};\\\", \\\"{x:144,y:540,t:1527272046557};\\\", \\\"{x:146,y:540,t:1527272046900};\\\", \\\"{x:148,y:540,t:1527272046916};\\\", \\\"{x:153,y:542,t:1527272046925};\\\", \\\"{x:160,y:545,t:1527272046937};\\\", \\\"{x:169,y:547,t:1527272046954};\\\", \\\"{x:177,y:547,t:1527272046970};\\\", \\\"{x:178,y:548,t:1527272046995};\\\", \\\"{x:178,y:549,t:1527272047036};\\\", \\\"{x:177,y:549,t:1527272047124};\\\", \\\"{x:176,y:549,t:1527272047137};\\\", \\\"{x:173,y:551,t:1527272047155};\\\", \\\"{x:169,y:552,t:1527272047170};\\\", \\\"{x:169,y:553,t:1527272047187};\\\", \\\"{x:167,y:553,t:1527272047204};\\\", \\\"{x:166,y:553,t:1527272047221};\\\", \\\"{x:165,y:553,t:1527272047238};\\\", \\\"{x:164,y:552,t:1527272047255};\\\", \\\"{x:163,y:552,t:1527272047452};\\\", \\\"{x:163,y:550,t:1527272047461};\\\", \\\"{x:163,y:548,t:1527272047471};\\\", \\\"{x:163,y:545,t:1527272047487};\\\", \\\"{x:163,y:543,t:1527272047504};\\\", \\\"{x:163,y:542,t:1527272047521};\\\", \\\"{x:163,y:540,t:1527272047538};\\\", \\\"{x:164,y:540,t:1527272047819};\\\", \\\"{x:171,y:547,t:1527272047828};\\\", \\\"{x:182,y:556,t:1527272047838};\\\", \\\"{x:212,y:582,t:1527272047855};\\\", \\\"{x:273,y:626,t:1527272047872};\\\", \\\"{x:378,y:671,t:1527272047888};\\\", \\\"{x:499,y:724,t:1527272047904};\\\", \\\"{x:603,y:765,t:1527272047921};\\\", \\\"{x:678,y:801,t:1527272047938};\\\", \\\"{x:715,y:818,t:1527272047954};\\\", \\\"{x:722,y:822,t:1527272047971};\\\", \\\"{x:719,y:822,t:1527272048011};\\\", \\\"{x:711,y:822,t:1527272048021};\\\", \\\"{x:697,y:815,t:1527272048038};\\\", \\\"{x:675,y:802,t:1527272048054};\\\", \\\"{x:654,y:795,t:1527272048071};\\\", \\\"{x:643,y:790,t:1527272048089};\\\", \\\"{x:637,y:785,t:1527272048104};\\\", \\\"{x:634,y:782,t:1527272048122};\\\", \\\"{x:628,y:774,t:1527272048138};\\\", \\\"{x:619,y:763,t:1527272048155};\\\", \\\"{x:603,y:750,t:1527272048171};\\\", \\\"{x:575,y:737,t:1527272048188};\\\", \\\"{x:556,y:730,t:1527272048206};\\\", \\\"{x:546,y:726,t:1527272048221};\\\", \\\"{x:540,y:725,t:1527272048238};\\\", \\\"{x:539,y:725,t:1527272048254};\\\", \\\"{x:538,y:725,t:1527272048276};\\\", \\\"{x:537,y:725,t:1527272048420};\\\", \\\"{x:537,y:727,t:1527272048438};\\\", \\\"{x:537,y:728,t:1527272048456};\\\", \\\"{x:537,y:729,t:1527272048472};\\\", \\\"{x:537,y:731,t:1527272048488};\\\", \\\"{x:538,y:732,t:1527272048505};\\\", \\\"{x:538,y:733,t:1527272048527};\\\", \\\"{x:539,y:734,t:1527272049164};\\\", \\\"{x:540,y:734,t:1527272049188};\\\", \\\"{x:541,y:734,t:1527272049573};\\\", \\\"{x:544,y:732,t:1527272049590};\\\", \\\"{x:547,y:731,t:1527272049607};\\\", \\\"{x:549,y:731,t:1527272049622};\\\", \\\"{x:551,y:729,t:1527272049639};\\\", \\\"{x:552,y:729,t:1527272049723};\\\" ] }, { \\\"rt\\\": 28380, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 494772, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -B -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:553,y:729,t:1527272052805};\\\", \\\"{x:561,y:728,t:1527272052830};\\\", \\\"{x:562,y:728,t:1527272052842};\\\", \\\"{x:565,y:727,t:1527272052859};\\\", \\\"{x:569,y:727,t:1527272052875};\\\", \\\"{x:572,y:727,t:1527272052892};\\\", \\\"{x:579,y:727,t:1527272052908};\\\", \\\"{x:596,y:732,t:1527272052925};\\\", \\\"{x:620,y:736,t:1527272052941};\\\", \\\"{x:641,y:742,t:1527272052958};\\\", \\\"{x:665,y:749,t:1527272052975};\\\", \\\"{x:684,y:755,t:1527272052993};\\\", \\\"{x:698,y:757,t:1527272053008};\\\", \\\"{x:708,y:758,t:1527272053025};\\\", \\\"{x:717,y:759,t:1527272053042};\\\", \\\"{x:725,y:762,t:1527272053058};\\\", \\\"{x:746,y:766,t:1527272053076};\\\", \\\"{x:764,y:769,t:1527272053092};\\\", \\\"{x:788,y:775,t:1527272053108};\\\", \\\"{x:807,y:781,t:1527272053126};\\\", \\\"{x:831,y:786,t:1527272053142};\\\", \\\"{x:868,y:795,t:1527272053159};\\\", \\\"{x:902,y:803,t:1527272053175};\\\", \\\"{x:931,y:808,t:1527272053193};\\\", \\\"{x:966,y:811,t:1527272053209};\\\", \\\"{x:992,y:816,t:1527272053226};\\\", \\\"{x:1013,y:820,t:1527272053243};\\\", \\\"{x:1035,y:825,t:1527272053259};\\\", \\\"{x:1068,y:830,t:1527272053277};\\\", \\\"{x:1092,y:836,t:1527272053292};\\\", \\\"{x:1114,y:838,t:1527272053308};\\\", \\\"{x:1137,y:841,t:1527272053326};\\\", \\\"{x:1168,y:845,t:1527272053343};\\\", \\\"{x:1206,y:855,t:1527272053358};\\\", \\\"{x:1263,y:864,t:1527272053375};\\\", \\\"{x:1324,y:873,t:1527272053393};\\\", \\\"{x:1382,y:881,t:1527272053408};\\\", \\\"{x:1435,y:887,t:1527272053426};\\\", \\\"{x:1469,y:894,t:1527272053443};\\\", \\\"{x:1512,y:899,t:1527272053459};\\\", \\\"{x:1532,y:901,t:1527272053476};\\\", \\\"{x:1543,y:904,t:1527272053493};\\\", \\\"{x:1544,y:904,t:1527272053510};\\\", \\\"{x:1545,y:904,t:1527272053564};\\\", \\\"{x:1541,y:904,t:1527272053716};\\\", \\\"{x:1525,y:902,t:1527272053726};\\\", \\\"{x:1499,y:891,t:1527272053743};\\\", \\\"{x:1481,y:881,t:1527272053760};\\\", \\\"{x:1460,y:868,t:1527272053776};\\\", \\\"{x:1439,y:852,t:1527272053792};\\\", \\\"{x:1411,y:825,t:1527272053810};\\\", \\\"{x:1391,y:799,t:1527272053826};\\\", \\\"{x:1373,y:775,t:1527272053843};\\\", \\\"{x:1353,y:740,t:1527272053859};\\\", \\\"{x:1341,y:719,t:1527272053876};\\\", \\\"{x:1335,y:704,t:1527272053892};\\\", \\\"{x:1333,y:689,t:1527272053909};\\\", \\\"{x:1334,y:664,t:1527272053926};\\\", \\\"{x:1343,y:642,t:1527272053943};\\\", \\\"{x:1349,y:630,t:1527272053960};\\\", \\\"{x:1354,y:616,t:1527272053977};\\\", \\\"{x:1360,y:603,t:1527272053993};\\\", \\\"{x:1364,y:592,t:1527272054010};\\\", \\\"{x:1368,y:582,t:1527272054027};\\\", \\\"{x:1374,y:569,t:1527272054043};\\\", \\\"{x:1381,y:547,t:1527272054060};\\\", \\\"{x:1387,y:536,t:1527272054077};\\\", \\\"{x:1390,y:528,t:1527272054093};\\\", \\\"{x:1393,y:524,t:1527272054110};\\\", \\\"{x:1393,y:518,t:1527272054127};\\\", \\\"{x:1394,y:516,t:1527272054142};\\\", \\\"{x:1395,y:514,t:1527272054160};\\\", \\\"{x:1391,y:518,t:1527272054229};\\\", \\\"{x:1385,y:532,t:1527272054243};\\\", \\\"{x:1353,y:605,t:1527272054261};\\\", \\\"{x:1320,y:672,t:1527272054276};\\\", \\\"{x:1296,y:730,t:1527272054293};\\\", \\\"{x:1282,y:766,t:1527272054310};\\\", \\\"{x:1280,y:784,t:1527272054327};\\\", \\\"{x:1280,y:794,t:1527272054343};\\\", \\\"{x:1280,y:799,t:1527272054360};\\\", \\\"{x:1282,y:801,t:1527272054377};\\\", \\\"{x:1282,y:803,t:1527272054393};\\\", \\\"{x:1282,y:805,t:1527272054410};\\\", \\\"{x:1283,y:807,t:1527272054427};\\\", \\\"{x:1285,y:810,t:1527272054444};\\\", \\\"{x:1289,y:813,t:1527272054461};\\\", \\\"{x:1290,y:813,t:1527272054485};\\\", \\\"{x:1290,y:814,t:1527272054494};\\\", \\\"{x:1293,y:815,t:1527272054510};\\\", \\\"{x:1294,y:816,t:1527272054527};\\\", \\\"{x:1295,y:816,t:1527272054645};\\\", \\\"{x:1297,y:816,t:1527272054660};\\\", \\\"{x:1299,y:816,t:1527272054677};\\\", \\\"{x:1300,y:816,t:1527272054694};\\\", \\\"{x:1302,y:816,t:1527272054733};\\\", \\\"{x:1302,y:815,t:1527272054744};\\\", \\\"{x:1304,y:814,t:1527272054760};\\\", \\\"{x:1306,y:813,t:1527272054777};\\\", \\\"{x:1310,y:810,t:1527272054794};\\\", \\\"{x:1312,y:808,t:1527272054810};\\\", \\\"{x:1319,y:801,t:1527272054827};\\\", \\\"{x:1333,y:785,t:1527272054845};\\\", \\\"{x:1340,y:771,t:1527272054860};\\\", \\\"{x:1343,y:767,t:1527272054877};\\\", \\\"{x:1344,y:765,t:1527272054897};\\\", \\\"{x:1344,y:763,t:1527272054910};\\\", \\\"{x:1345,y:759,t:1527272054926};\\\", \\\"{x:1346,y:757,t:1527272054944};\\\", \\\"{x:1346,y:755,t:1527272054961};\\\", \\\"{x:1347,y:753,t:1527272054976};\\\", \\\"{x:1347,y:754,t:1527272057372};\\\", \\\"{x:1349,y:759,t:1527272057381};\\\", \\\"{x:1356,y:770,t:1527272057396};\\\", \\\"{x:1366,y:778,t:1527272057412};\\\", \\\"{x:1378,y:784,t:1527272057429};\\\", \\\"{x:1386,y:787,t:1527272057446};\\\", \\\"{x:1390,y:788,t:1527272057462};\\\", \\\"{x:1391,y:788,t:1527272057597};\\\", \\\"{x:1387,y:781,t:1527272057612};\\\", \\\"{x:1380,y:772,t:1527272057629};\\\", \\\"{x:1373,y:762,t:1527272057647};\\\", \\\"{x:1371,y:759,t:1527272057663};\\\", \\\"{x:1369,y:755,t:1527272057679};\\\", \\\"{x:1368,y:753,t:1527272057700};\\\", \\\"{x:1367,y:752,t:1527272057712};\\\", \\\"{x:1366,y:752,t:1527272057797};\\\", \\\"{x:1363,y:752,t:1527272057812};\\\", \\\"{x:1360,y:754,t:1527272057830};\\\", \\\"{x:1358,y:757,t:1527272057846};\\\", \\\"{x:1356,y:762,t:1527272057862};\\\", \\\"{x:1355,y:765,t:1527272057880};\\\", \\\"{x:1354,y:768,t:1527272057896};\\\", \\\"{x:1354,y:769,t:1527272057913};\\\", \\\"{x:1352,y:769,t:1527272058517};\\\", \\\"{x:1352,y:768,t:1527272058530};\\\", \\\"{x:1352,y:767,t:1527272058547};\\\", \\\"{x:1351,y:764,t:1527272058564};\\\", \\\"{x:1351,y:763,t:1527272058580};\\\", \\\"{x:1345,y:760,t:1527272070413};\\\", \\\"{x:1330,y:753,t:1527272070424};\\\", \\\"{x:1259,y:723,t:1527272070440};\\\", \\\"{x:1122,y:671,t:1527272070456};\\\", \\\"{x:948,y:622,t:1527272070474};\\\", \\\"{x:771,y:567,t:1527272070491};\\\", \\\"{x:608,y:525,t:1527272070507};\\\", \\\"{x:478,y:483,t:1527272070525};\\\", \\\"{x:476,y:480,t:1527272070540};\\\", \\\"{x:475,y:480,t:1527272070558};\\\", \\\"{x:474,y:479,t:1527272070661};\\\", \\\"{x:475,y:478,t:1527272070676};\\\", \\\"{x:476,y:477,t:1527272070693};\\\", \\\"{x:477,y:477,t:1527272070707};\\\", \\\"{x:491,y:479,t:1527272070724};\\\", \\\"{x:501,y:484,t:1527272070740};\\\", \\\"{x:508,y:488,t:1527272070758};\\\", \\\"{x:512,y:490,t:1527272070775};\\\", \\\"{x:516,y:491,t:1527272070791};\\\", \\\"{x:517,y:492,t:1527272070807};\\\", \\\"{x:518,y:492,t:1527272070828};\\\", \\\"{x:520,y:492,t:1527272070841};\\\", \\\"{x:526,y:493,t:1527272070857};\\\", \\\"{x:535,y:494,t:1527272070875};\\\", \\\"{x:544,y:496,t:1527272070892};\\\", \\\"{x:551,y:497,t:1527272070907};\\\", \\\"{x:556,y:498,t:1527272070924};\\\", \\\"{x:557,y:498,t:1527272070941};\\\", \\\"{x:558,y:498,t:1527272070965};\\\", \\\"{x:560,y:498,t:1527272070975};\\\", \\\"{x:568,y:498,t:1527272070992};\\\", \\\"{x:581,y:500,t:1527272071007};\\\", \\\"{x:598,y:502,t:1527272071024};\\\", \\\"{x:605,y:503,t:1527272071043};\\\", \\\"{x:607,y:503,t:1527272071058};\\\", \\\"{x:608,y:504,t:1527272071461};\\\", \\\"{x:608,y:513,t:1527272071475};\\\", \\\"{x:603,y:537,t:1527272071492};\\\", \\\"{x:598,y:549,t:1527272071509};\\\", \\\"{x:591,y:562,t:1527272071524};\\\", \\\"{x:584,y:575,t:1527272071541};\\\", \\\"{x:573,y:592,t:1527272071558};\\\", \\\"{x:562,y:611,t:1527272071576};\\\", \\\"{x:554,y:633,t:1527272071592};\\\", \\\"{x:551,y:637,t:1527272071608};\\\", \\\"{x:551,y:641,t:1527272071624};\\\", \\\"{x:550,y:642,t:1527272071642};\\\", \\\"{x:550,y:645,t:1527272071658};\\\", \\\"{x:550,y:650,t:1527272071675};\\\", \\\"{x:551,y:660,t:1527272071691};\\\", \\\"{x:551,y:661,t:1527272071708};\\\", \\\"{x:551,y:662,t:1527272071805};\\\", \\\"{x:552,y:663,t:1527272071813};\\\", \\\"{x:553,y:663,t:1527272071824};\\\", \\\"{x:553,y:664,t:1527272071841};\\\", \\\"{x:553,y:665,t:1527272071860};\\\", \\\"{x:553,y:666,t:1527272071876};\\\", \\\"{x:553,y:669,t:1527272071891};\\\", \\\"{x:550,y:677,t:1527272071908};\\\", \\\"{x:550,y:683,t:1527272071924};\\\", \\\"{x:550,y:690,t:1527272071942};\\\", \\\"{x:550,y:698,t:1527272071958};\\\", \\\"{x:552,y:707,t:1527272071975};\\\", \\\"{x:554,y:717,t:1527272071991};\\\", \\\"{x:555,y:729,t:1527272072009};\\\", \\\"{x:555,y:735,t:1527272072025};\\\", \\\"{x:555,y:743,t:1527272072041};\\\", \\\"{x:555,y:749,t:1527272072057};\\\", \\\"{x:555,y:753,t:1527272072075};\\\", \\\"{x:555,y:754,t:1527272072181};\\\", \\\"{x:554,y:754,t:1527272072191};\\\", \\\"{x:552,y:751,t:1527272072208};\\\", \\\"{x:551,y:747,t:1527272072224};\\\", \\\"{x:550,y:743,t:1527272072241};\\\", \\\"{x:549,y:739,t:1527272072258};\\\", \\\"{x:547,y:736,t:1527272072274};\\\", \\\"{x:547,y:734,t:1527272072291};\\\", \\\"{x:547,y:733,t:1527272072308};\\\", \\\"{x:547,y:732,t:1527272072437};\\\", \\\"{x:546,y:732,t:1527272072453};\\\", \\\"{x:546,y:731,t:1527272073342};\\\", \\\"{x:546,y:729,t:1527272073398};\\\", \\\"{x:552,y:726,t:1527272073405};\\\", \\\"{x:577,y:718,t:1527272073423};\\\", \\\"{x:616,y:711,t:1527272073438};\\\", \\\"{x:683,y:703,t:1527272073459};\\\", \\\"{x:783,y:676,t:1527272073476};\\\", \\\"{x:855,y:657,t:1527272073493};\\\", \\\"{x:916,y:640,t:1527272073509};\\\", \\\"{x:948,y:630,t:1527272073526};\\\", \\\"{x:955,y:626,t:1527272073544};\\\", \\\"{x:956,y:626,t:1527272073572};\\\", \\\"{x:955,y:624,t:1527272073580};\\\", \\\"{x:954,y:624,t:1527272073593};\\\", \\\"{x:954,y:620,t:1527272073726};\\\", \\\"{x:959,y:617,t:1527272073733};\\\", \\\"{x:962,y:614,t:1527272073744};\\\", \\\"{x:978,y:608,t:1527272073761};\\\", \\\"{x:1006,y:599,t:1527272073777};\\\", \\\"{x:1051,y:592,t:1527272073794};\\\", \\\"{x:1102,y:590,t:1527272073812};\\\", \\\"{x:1152,y:590,t:1527272073827};\\\", \\\"{x:1191,y:593,t:1527272073844};\\\", \\\"{x:1225,y:601,t:1527272073860};\\\", \\\"{x:1232,y:608,t:1527272073877};\\\", \\\"{x:1232,y:613,t:1527272073894};\\\", \\\"{x:1230,y:622,t:1527272073911};\\\", \\\"{x:1215,y:630,t:1527272073927};\\\", \\\"{x:1195,y:638,t:1527272073944};\\\", \\\"{x:1172,y:648,t:1527272073961};\\\", \\\"{x:1149,y:655,t:1527272073977};\\\", \\\"{x:1121,y:662,t:1527272073994};\\\", \\\"{x:1093,y:667,t:1527272074011};\\\", \\\"{x:1060,y:672,t:1527272074027};\\\", \\\"{x:1023,y:677,t:1527272074045};\\\", \\\"{x:973,y:683,t:1527272074061};\\\", \\\"{x:940,y:683,t:1527272074078};\\\", \\\"{x:908,y:683,t:1527272074094};\\\", \\\"{x:878,y:683,t:1527272074111};\\\", \\\"{x:851,y:684,t:1527272074127};\\\", \\\"{x:833,y:685,t:1527272074143};\\\", \\\"{x:830,y:687,t:1527272074161};\\\", \\\"{x:822,y:690,t:1527272074178};\\\", \\\"{x:808,y:692,t:1527272074194};\\\", \\\"{x:806,y:692,t:1527272074211};\\\", \\\"{x:785,y:703,t:1527272074228};\\\", \\\"{x:775,y:712,t:1527272074244};\\\", \\\"{x:756,y:727,t:1527272074262};\\\", \\\"{x:751,y:730,t:1527272074277};\\\", \\\"{x:750,y:734,t:1527272074294};\\\", \\\"{x:747,y:735,t:1527272074311};\\\", \\\"{x:747,y:737,t:1527272074341};\\\", \\\"{x:747,y:736,t:1527272074493};\\\", \\\"{x:749,y:736,t:1527272074533};\\\", \\\"{x:748,y:736,t:1527272074629};\\\", \\\"{x:741,y:736,t:1527272074645};\\\", \\\"{x:739,y:735,t:1527272074661};\\\", \\\"{x:738,y:734,t:1527272074678};\\\", \\\"{x:737,y:734,t:1527272074695};\\\", \\\"{x:736,y:734,t:1527272074733};\\\", \\\"{x:734,y:734,t:1527272074749};\\\", \\\"{x:730,y:734,t:1527272074761};\\\", \\\"{x:725,y:734,t:1527272074778};\\\", \\\"{x:724,y:734,t:1527272074794};\\\", \\\"{x:721,y:734,t:1527272074811};\\\", \\\"{x:720,y:734,t:1527272074828};\\\", \\\"{x:719,y:737,t:1527272074844};\\\", \\\"{x:718,y:738,t:1527272075422};\\\", \\\"{x:718,y:739,t:1527272075429};\\\", \\\"{x:716,y:740,t:1527272075453};\\\", \\\"{x:714,y:740,t:1527272075461};\\\", \\\"{x:703,y:741,t:1527272075479};\\\", \\\"{x:686,y:744,t:1527272075495};\\\", \\\"{x:673,y:744,t:1527272075512};\\\", \\\"{x:660,y:744,t:1527272075529};\\\", \\\"{x:648,y:744,t:1527272075545};\\\", \\\"{x:643,y:744,t:1527272075561};\\\", \\\"{x:637,y:744,t:1527272075579};\\\", \\\"{x:636,y:744,t:1527272075594};\\\", \\\"{x:635,y:745,t:1527272075621};\\\", \\\"{x:634,y:745,t:1527272075629};\\\", \\\"{x:633,y:745,t:1527272075645};\\\", \\\"{x:627,y:745,t:1527272075662};\\\", \\\"{x:622,y:745,t:1527272075679};\\\", \\\"{x:616,y:745,t:1527272075695};\\\", \\\"{x:608,y:745,t:1527272075712};\\\", \\\"{x:597,y:745,t:1527272075729};\\\", \\\"{x:587,y:745,t:1527272075745};\\\", \\\"{x:578,y:745,t:1527272075762};\\\", \\\"{x:569,y:745,t:1527272075779};\\\", \\\"{x:563,y:745,t:1527272075796};\\\", \\\"{x:559,y:747,t:1527272075812};\\\", \\\"{x:557,y:747,t:1527272075829};\\\", \\\"{x:556,y:747,t:1527272075981};\\\", \\\"{x:559,y:745,t:1527272076326};\\\", \\\"{x:565,y:742,t:1527272076334};\\\", \\\"{x:577,y:736,t:1527272076345};\\\", \\\"{x:604,y:726,t:1527272076362};\\\", \\\"{x:670,y:713,t:1527272076379};\\\", \\\"{x:764,y:697,t:1527272076396};\\\", \\\"{x:949,y:673,t:1527272076412};\\\", \\\"{x:1081,y:654,t:1527272076429};\\\", \\\"{x:1215,y:633,t:1527272076446};\\\", \\\"{x:1323,y:616,t:1527272076463};\\\", \\\"{x:1384,y:608,t:1527272076478};\\\", \\\"{x:1419,y:604,t:1527272076495};\\\", \\\"{x:1428,y:602,t:1527272076512};\\\", \\\"{x:1427,y:601,t:1527272076629};\\\", \\\"{x:1417,y:597,t:1527272076645};\\\", \\\"{x:1402,y:592,t:1527272076663};\\\", \\\"{x:1382,y:587,t:1527272076679};\\\", \\\"{x:1356,y:582,t:1527272076696};\\\", \\\"{x:1336,y:580,t:1527272076713};\\\", \\\"{x:1327,y:580,t:1527272076729};\\\", \\\"{x:1322,y:580,t:1527272076746};\\\", \\\"{x:1321,y:580,t:1527272076854};\\\", \\\"{x:1320,y:581,t:1527272076885};\\\", \\\"{x:1318,y:582,t:1527272076901};\\\", \\\"{x:1317,y:582,t:1527272076913};\\\", \\\"{x:1310,y:582,t:1527272076930};\\\", \\\"{x:1297,y:582,t:1527272076946};\\\", \\\"{x:1285,y:582,t:1527272076962};\\\", \\\"{x:1275,y:582,t:1527272076980};\\\", \\\"{x:1266,y:582,t:1527272076996};\\\", \\\"{x:1260,y:582,t:1527272077013};\\\", \\\"{x:1259,y:582,t:1527272077030};\\\", \\\"{x:1257,y:582,t:1527272077046};\\\", \\\"{x:1255,y:581,t:1527272077070};\\\", \\\"{x:1255,y:580,t:1527272077117};\\\", \\\"{x:1255,y:579,t:1527272077130};\\\", \\\"{x:1255,y:577,t:1527272077147};\\\", \\\"{x:1255,y:576,t:1527272077164};\\\", \\\"{x:1255,y:575,t:1527272077180};\\\", \\\"{x:1257,y:571,t:1527272077197};\\\", \\\"{x:1260,y:570,t:1527272077213};\\\", \\\"{x:1263,y:568,t:1527272077230};\\\", \\\"{x:1264,y:567,t:1527272077253};\\\", \\\"{x:1266,y:567,t:1527272077269};\\\", \\\"{x:1267,y:566,t:1527272077285};\\\", \\\"{x:1268,y:565,t:1527272077297};\\\", \\\"{x:1269,y:565,t:1527272077313};\\\", \\\"{x:1270,y:564,t:1527272077329};\\\", \\\"{x:1271,y:563,t:1527272077380};\\\", \\\"{x:1272,y:563,t:1527272077396};\\\", \\\"{x:1262,y:566,t:1527272077486};\\\", \\\"{x:1246,y:572,t:1527272077497};\\\", \\\"{x:1154,y:604,t:1527272077513};\\\", \\\"{x:1017,y:649,t:1527272077530};\\\", \\\"{x:845,y:715,t:1527272077547};\\\", \\\"{x:665,y:770,t:1527272077563};\\\", \\\"{x:514,y:805,t:1527272077580};\\\", \\\"{x:354,y:831,t:1527272077597};\\\", \\\"{x:305,y:836,t:1527272077613};\\\", \\\"{x:285,y:836,t:1527272077630};\\\", \\\"{x:271,y:836,t:1527272077647};\\\", \\\"{x:259,y:833,t:1527272077664};\\\", \\\"{x:250,y:826,t:1527272077680};\\\", \\\"{x:246,y:820,t:1527272077697};\\\", \\\"{x:245,y:813,t:1527272077714};\\\", \\\"{x:244,y:801,t:1527272077730};\\\", \\\"{x:242,y:794,t:1527272077747};\\\", \\\"{x:242,y:781,t:1527272077764};\\\", \\\"{x:247,y:765,t:1527272077780};\\\", \\\"{x:252,y:755,t:1527272077796};\\\", \\\"{x:259,y:753,t:1527272077814};\\\", \\\"{x:270,y:748,t:1527272077830};\\\", \\\"{x:283,y:743,t:1527272077847};\\\", \\\"{x:297,y:739,t:1527272077864};\\\", \\\"{x:315,y:736,t:1527272077880};\\\", \\\"{x:335,y:735,t:1527272077897};\\\", \\\"{x:370,y:735,t:1527272077914};\\\", \\\"{x:420,y:735,t:1527272077930};\\\", \\\"{x:480,y:743,t:1527272077948};\\\", \\\"{x:511,y:745,t:1527272077964};\\\", \\\"{x:529,y:745,t:1527272077979};\\\", \\\"{x:530,y:745,t:1527272077996};\\\", \\\"{x:530,y:744,t:1527272078166};\\\" ] }, { \\\"rt\\\": 30030, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 526067, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -J -J -B -J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:735,t:1527272080124};\\\", \\\"{x:515,y:712,t:1527272080133};\\\", \\\"{x:486,y:665,t:1527272080151};\\\", \\\"{x:451,y:615,t:1527272080165};\\\", \\\"{x:416,y:580,t:1527272080182};\\\", \\\"{x:388,y:560,t:1527272080199};\\\", \\\"{x:380,y:554,t:1527272080216};\\\", \\\"{x:377,y:552,t:1527272080231};\\\", \\\"{x:376,y:551,t:1527272080249};\\\", \\\"{x:376,y:550,t:1527272080268};\\\", \\\"{x:376,y:549,t:1527272080282};\\\", \\\"{x:375,y:547,t:1527272080298};\\\", \\\"{x:375,y:545,t:1527272080316};\\\", \\\"{x:375,y:544,t:1527272080332};\\\", \\\"{x:375,y:542,t:1527272080349};\\\", \\\"{x:375,y:540,t:1527272080366};\\\", \\\"{x:375,y:538,t:1527272080382};\\\", \\\"{x:378,y:534,t:1527272080399};\\\", \\\"{x:383,y:531,t:1527272080416};\\\", \\\"{x:389,y:528,t:1527272080432};\\\", \\\"{x:393,y:525,t:1527272080449};\\\", \\\"{x:399,y:521,t:1527272080466};\\\", \\\"{x:404,y:517,t:1527272080482};\\\", \\\"{x:410,y:513,t:1527272080498};\\\", \\\"{x:419,y:507,t:1527272080516};\\\", \\\"{x:439,y:494,t:1527272080532};\\\", \\\"{x:455,y:485,t:1527272080550};\\\", \\\"{x:464,y:480,t:1527272080565};\\\", \\\"{x:472,y:474,t:1527272080582};\\\", \\\"{x:478,y:470,t:1527272080599};\\\", \\\"{x:482,y:466,t:1527272080616};\\\", \\\"{x:485,y:465,t:1527272080633};\\\", \\\"{x:487,y:463,t:1527272080648};\\\", \\\"{x:490,y:460,t:1527272080666};\\\", \\\"{x:493,y:458,t:1527272080683};\\\", \\\"{x:495,y:456,t:1527272080699};\\\", \\\"{x:495,y:455,t:1527272080716};\\\", \\\"{x:496,y:454,t:1527272080733};\\\", \\\"{x:497,y:454,t:1527272080757};\\\", \\\"{x:498,y:453,t:1527272080766};\\\", \\\"{x:498,y:452,t:1527272080783};\\\", \\\"{x:500,y:450,t:1527272081029};\\\", \\\"{x:508,y:447,t:1527272081037};\\\", \\\"{x:516,y:445,t:1527272081049};\\\", \\\"{x:534,y:445,t:1527272081066};\\\", \\\"{x:548,y:445,t:1527272081083};\\\", \\\"{x:559,y:447,t:1527272081100};\\\", \\\"{x:572,y:448,t:1527272081116};\\\", \\\"{x:592,y:452,t:1527272081133};\\\", \\\"{x:598,y:453,t:1527272081148};\\\", \\\"{x:599,y:453,t:1527272081165};\\\", \\\"{x:601,y:453,t:1527272081182};\\\", \\\"{x:603,y:453,t:1527272081200};\\\", \\\"{x:605,y:453,t:1527272081216};\\\", \\\"{x:607,y:453,t:1527272081233};\\\", \\\"{x:609,y:453,t:1527272081250};\\\", \\\"{x:615,y:453,t:1527272081266};\\\", \\\"{x:622,y:453,t:1527272081283};\\\", \\\"{x:632,y:453,t:1527272081300};\\\", \\\"{x:640,y:453,t:1527272081316};\\\", \\\"{x:653,y:456,t:1527272081332};\\\", \\\"{x:661,y:457,t:1527272081350};\\\", \\\"{x:670,y:458,t:1527272081366};\\\", \\\"{x:677,y:459,t:1527272081383};\\\", \\\"{x:680,y:459,t:1527272081400};\\\", \\\"{x:682,y:460,t:1527272081416};\\\", \\\"{x:683,y:460,t:1527272081453};\\\", \\\"{x:685,y:460,t:1527272081493};\\\", \\\"{x:686,y:460,t:1527272081517};\\\", \\\"{x:688,y:460,t:1527272081532};\\\", \\\"{x:690,y:460,t:1527272081550};\\\", \\\"{x:695,y:460,t:1527272081566};\\\", \\\"{x:699,y:460,t:1527272081584};\\\", \\\"{x:702,y:459,t:1527272081600};\\\", \\\"{x:704,y:458,t:1527272081616};\\\", \\\"{x:705,y:458,t:1527272081633};\\\", \\\"{x:706,y:458,t:1527272081661};\\\", \\\"{x:708,y:458,t:1527272081676};\\\", \\\"{x:709,y:458,t:1527272081684};\\\", \\\"{x:705,y:458,t:1527272084766};\\\", \\\"{x:694,y:462,t:1527272084772};\\\", \\\"{x:674,y:467,t:1527272084785};\\\", \\\"{x:611,y:479,t:1527272084803};\\\", \\\"{x:534,y:488,t:1527272084821};\\\", \\\"{x:472,y:490,t:1527272084835};\\\", \\\"{x:391,y:490,t:1527272084851};\\\", \\\"{x:359,y:490,t:1527272084869};\\\", \\\"{x:337,y:490,t:1527272084886};\\\", \\\"{x:322,y:490,t:1527272084902};\\\", \\\"{x:316,y:490,t:1527272084919};\\\", \\\"{x:311,y:490,t:1527272084936};\\\", \\\"{x:308,y:490,t:1527272084953};\\\", \\\"{x:306,y:490,t:1527272084969};\\\", \\\"{x:306,y:489,t:1527272085003};\\\", \\\"{x:306,y:488,t:1527272085019};\\\", \\\"{x:314,y:480,t:1527272085037};\\\", \\\"{x:328,y:473,t:1527272085052};\\\", \\\"{x:354,y:462,t:1527272085069};\\\", \\\"{x:386,y:456,t:1527272085086};\\\", \\\"{x:421,y:454,t:1527272085102};\\\", \\\"{x:448,y:449,t:1527272085119};\\\", \\\"{x:468,y:449,t:1527272085136};\\\", \\\"{x:482,y:449,t:1527272085153};\\\", \\\"{x:489,y:449,t:1527272085169};\\\", \\\"{x:490,y:449,t:1527272085185};\\\", \\\"{x:492,y:449,t:1527272085285};\\\", \\\"{x:495,y:448,t:1527272085303};\\\", \\\"{x:502,y:448,t:1527272085320};\\\", \\\"{x:511,y:448,t:1527272085336};\\\", \\\"{x:522,y:448,t:1527272085353};\\\", \\\"{x:540,y:448,t:1527272085370};\\\", \\\"{x:567,y:452,t:1527272085386};\\\", \\\"{x:591,y:457,t:1527272085403};\\\", \\\"{x:612,y:459,t:1527272085420};\\\", \\\"{x:624,y:462,t:1527272085436};\\\", \\\"{x:626,y:462,t:1527272085453};\\\", \\\"{x:625,y:462,t:1527272085709};\\\", \\\"{x:624,y:462,t:1527272085733};\\\", \\\"{x:623,y:462,t:1527272085741};\\\", \\\"{x:622,y:462,t:1527272085790};\\\", \\\"{x:620,y:462,t:1527272085821};\\\", \\\"{x:619,y:462,t:1527272085845};\\\", \\\"{x:617,y:462,t:1527272085862};\\\", \\\"{x:616,y:462,t:1527272085893};\\\", \\\"{x:614,y:462,t:1527272085909};\\\", \\\"{x:613,y:462,t:1527272085921};\\\", \\\"{x:609,y:462,t:1527272085938};\\\", \\\"{x:602,y:462,t:1527272085954};\\\", \\\"{x:599,y:462,t:1527272085970};\\\", \\\"{x:595,y:462,t:1527272085987};\\\", \\\"{x:589,y:462,t:1527272086004};\\\", \\\"{x:585,y:462,t:1527272086020};\\\", \\\"{x:580,y:462,t:1527272086037};\\\", \\\"{x:576,y:462,t:1527272086054};\\\", \\\"{x:574,y:462,t:1527272086071};\\\", \\\"{x:572,y:462,t:1527272086087};\\\", \\\"{x:571,y:462,t:1527272086109};\\\", \\\"{x:572,y:462,t:1527272086269};\\\", \\\"{x:575,y:462,t:1527272086277};\\\", \\\"{x:577,y:462,t:1527272086288};\\\", \\\"{x:581,y:460,t:1527272086305};\\\", \\\"{x:585,y:459,t:1527272086321};\\\", \\\"{x:588,y:459,t:1527272086337};\\\", \\\"{x:589,y:458,t:1527272086355};\\\", \\\"{x:595,y:458,t:1527272086371};\\\", \\\"{x:606,y:458,t:1527272086388};\\\", \\\"{x:653,y:465,t:1527272086405};\\\", \\\"{x:702,y:476,t:1527272086421};\\\", \\\"{x:758,y:491,t:1527272086440};\\\", \\\"{x:844,y:518,t:1527272086455};\\\", \\\"{x:949,y:548,t:1527272086470};\\\", \\\"{x:1085,y:585,t:1527272086487};\\\", \\\"{x:1228,y:624,t:1527272086504};\\\", \\\"{x:1371,y:661,t:1527272086520};\\\", \\\"{x:1496,y:695,t:1527272086537};\\\", \\\"{x:1607,y:730,t:1527272086554};\\\", \\\"{x:1685,y:754,t:1527272086570};\\\", \\\"{x:1738,y:779,t:1527272086587};\\\", \\\"{x:1768,y:797,t:1527272086604};\\\", \\\"{x:1773,y:808,t:1527272086620};\\\", \\\"{x:1775,y:817,t:1527272086637};\\\", \\\"{x:1778,y:827,t:1527272086654};\\\", \\\"{x:1779,y:840,t:1527272086670};\\\", \\\"{x:1783,y:858,t:1527272086687};\\\", \\\"{x:1784,y:874,t:1527272086703};\\\", \\\"{x:1784,y:885,t:1527272086721};\\\", \\\"{x:1778,y:892,t:1527272086737};\\\", \\\"{x:1761,y:897,t:1527272086754};\\\", \\\"{x:1729,y:902,t:1527272086772};\\\", \\\"{x:1696,y:911,t:1527272086787};\\\", \\\"{x:1604,y:939,t:1527272086804};\\\", \\\"{x:1558,y:954,t:1527272086821};\\\", \\\"{x:1536,y:960,t:1527272086837};\\\", \\\"{x:1527,y:961,t:1527272086854};\\\", \\\"{x:1519,y:963,t:1527272086871};\\\", \\\"{x:1517,y:963,t:1527272086893};\\\", \\\"{x:1516,y:963,t:1527272086933};\\\", \\\"{x:1511,y:962,t:1527272086941};\\\", \\\"{x:1509,y:956,t:1527272086955};\\\", \\\"{x:1504,y:940,t:1527272086971};\\\", \\\"{x:1501,y:912,t:1527272086987};\\\", \\\"{x:1499,y:800,t:1527272087005};\\\", \\\"{x:1468,y:721,t:1527272087022};\\\", \\\"{x:1434,y:666,t:1527272087037};\\\", \\\"{x:1415,y:631,t:1527272087055};\\\", \\\"{x:1410,y:620,t:1527272087072};\\\", \\\"{x:1410,y:616,t:1527272087088};\\\", \\\"{x:1410,y:609,t:1527272087105};\\\", \\\"{x:1410,y:599,t:1527272087121};\\\", \\\"{x:1410,y:588,t:1527272087138};\\\", \\\"{x:1404,y:571,t:1527272087155};\\\", \\\"{x:1397,y:557,t:1527272087171};\\\", \\\"{x:1393,y:551,t:1527272087189};\\\", \\\"{x:1393,y:550,t:1527272087205};\\\", \\\"{x:1394,y:548,t:1527272087237};\\\", \\\"{x:1396,y:547,t:1527272087245};\\\", \\\"{x:1397,y:546,t:1527272087254};\\\", \\\"{x:1402,y:545,t:1527272087272};\\\", \\\"{x:1406,y:542,t:1527272087288};\\\", \\\"{x:1407,y:542,t:1527272087304};\\\", \\\"{x:1412,y:540,t:1527272087322};\\\", \\\"{x:1417,y:538,t:1527272087338};\\\", \\\"{x:1421,y:536,t:1527272087354};\\\", \\\"{x:1428,y:532,t:1527272087372};\\\", \\\"{x:1438,y:520,t:1527272087389};\\\", \\\"{x:1440,y:517,t:1527272087405};\\\", \\\"{x:1447,y:500,t:1527272087421};\\\", \\\"{x:1449,y:489,t:1527272087439};\\\", \\\"{x:1450,y:479,t:1527272087454};\\\", \\\"{x:1450,y:466,t:1527272087471};\\\", \\\"{x:1450,y:454,t:1527272087489};\\\", \\\"{x:1450,y:445,t:1527272087504};\\\", \\\"{x:1452,y:437,t:1527272087522};\\\", \\\"{x:1454,y:433,t:1527272087539};\\\", \\\"{x:1456,y:429,t:1527272087554};\\\", \\\"{x:1458,y:426,t:1527272087572};\\\", \\\"{x:1461,y:423,t:1527272087589};\\\", \\\"{x:1466,y:418,t:1527272087604};\\\", \\\"{x:1470,y:415,t:1527272087621};\\\", \\\"{x:1475,y:410,t:1527272087638};\\\", \\\"{x:1482,y:405,t:1527272087655};\\\", \\\"{x:1492,y:396,t:1527272087672};\\\", \\\"{x:1503,y:382,t:1527272087689};\\\", \\\"{x:1510,y:364,t:1527272087705};\\\", \\\"{x:1511,y:338,t:1527272087722};\\\", \\\"{x:1511,y:313,t:1527272087738};\\\", \\\"{x:1511,y:293,t:1527272087756};\\\", \\\"{x:1511,y:284,t:1527272087771};\\\", \\\"{x:1511,y:281,t:1527272087788};\\\", \\\"{x:1518,y:293,t:1527272087941};\\\", \\\"{x:1524,y:304,t:1527272087955};\\\", \\\"{x:1538,y:329,t:1527272087971};\\\", \\\"{x:1552,y:357,t:1527272087988};\\\", \\\"{x:1559,y:372,t:1527272088005};\\\", \\\"{x:1564,y:383,t:1527272088021};\\\", \\\"{x:1566,y:388,t:1527272088038};\\\", \\\"{x:1570,y:395,t:1527272088055};\\\", \\\"{x:1573,y:404,t:1527272088071};\\\", \\\"{x:1579,y:420,t:1527272088088};\\\", \\\"{x:1584,y:437,t:1527272088105};\\\", \\\"{x:1589,y:462,t:1527272088129};\\\", \\\"{x:1595,y:509,t:1527272088167};\\\", \\\"{x:1596,y:518,t:1527272088172};\\\", \\\"{x:1596,y:533,t:1527272088188};\\\", \\\"{x:1596,y:547,t:1527272088204};\\\", \\\"{x:1596,y:556,t:1527272088221};\\\", \\\"{x:1595,y:567,t:1527272088238};\\\", \\\"{x:1595,y:577,t:1527272088255};\\\", \\\"{x:1595,y:583,t:1527272088272};\\\", \\\"{x:1594,y:589,t:1527272088288};\\\", \\\"{x:1594,y:594,t:1527272088305};\\\", \\\"{x:1594,y:602,t:1527272088322};\\\", \\\"{x:1594,y:610,t:1527272088338};\\\", \\\"{x:1593,y:619,t:1527272088355};\\\", \\\"{x:1590,y:627,t:1527272088372};\\\", \\\"{x:1590,y:634,t:1527272088388};\\\", \\\"{x:1587,y:640,t:1527272088405};\\\", \\\"{x:1586,y:645,t:1527272088422};\\\", \\\"{x:1584,y:660,t:1527272088438};\\\", \\\"{x:1582,y:674,t:1527272088455};\\\", \\\"{x:1579,y:693,t:1527272088472};\\\", \\\"{x:1570,y:718,t:1527272088489};\\\", \\\"{x:1563,y:738,t:1527272088506};\\\", \\\"{x:1557,y:753,t:1527272088522};\\\", \\\"{x:1550,y:762,t:1527272088538};\\\", \\\"{x:1546,y:769,t:1527272088555};\\\", \\\"{x:1541,y:777,t:1527272088573};\\\", \\\"{x:1537,y:785,t:1527272088589};\\\", \\\"{x:1530,y:796,t:1527272088606};\\\", \\\"{x:1521,y:808,t:1527272088623};\\\", \\\"{x:1509,y:819,t:1527272088639};\\\", \\\"{x:1494,y:828,t:1527272088655};\\\", \\\"{x:1476,y:839,t:1527272088673};\\\", \\\"{x:1457,y:851,t:1527272088690};\\\", \\\"{x:1441,y:860,t:1527272088706};\\\", \\\"{x:1426,y:870,t:1527272088722};\\\", \\\"{x:1406,y:881,t:1527272088740};\\\", \\\"{x:1382,y:891,t:1527272088756};\\\", \\\"{x:1296,y:903,t:1527272088796};\\\", \\\"{x:1269,y:903,t:1527272088805};\\\", \\\"{x:1254,y:904,t:1527272088822};\\\", \\\"{x:1245,y:905,t:1527272088839};\\\", \\\"{x:1241,y:905,t:1527272088855};\\\", \\\"{x:1241,y:903,t:1527272088908};\\\", \\\"{x:1241,y:898,t:1527272088922};\\\", \\\"{x:1243,y:891,t:1527272088939};\\\", \\\"{x:1245,y:881,t:1527272088955};\\\", \\\"{x:1246,y:873,t:1527272088973};\\\", \\\"{x:1246,y:870,t:1527272088989};\\\", \\\"{x:1246,y:866,t:1527272089006};\\\", \\\"{x:1247,y:861,t:1527272089022};\\\", \\\"{x:1247,y:856,t:1527272089039};\\\", \\\"{x:1247,y:847,t:1527272089056};\\\", \\\"{x:1240,y:838,t:1527272089073};\\\", \\\"{x:1235,y:833,t:1527272089090};\\\", \\\"{x:1232,y:830,t:1527272089106};\\\", \\\"{x:1230,y:830,t:1527272089125};\\\", \\\"{x:1229,y:830,t:1527272089139};\\\", \\\"{x:1228,y:830,t:1527272089156};\\\", \\\"{x:1226,y:830,t:1527272089172};\\\", \\\"{x:1225,y:830,t:1527272089190};\\\", \\\"{x:1223,y:830,t:1527272089325};\\\", \\\"{x:1222,y:830,t:1527272089341};\\\", \\\"{x:1220,y:830,t:1527272089359};\\\", \\\"{x:1219,y:831,t:1527272089389};\\\", \\\"{x:1217,y:831,t:1527272089429};\\\", \\\"{x:1216,y:831,t:1527272089439};\\\", \\\"{x:1214,y:831,t:1527272089456};\\\", \\\"{x:1211,y:831,t:1527272089473};\\\", \\\"{x:1207,y:831,t:1527272089491};\\\", \\\"{x:1204,y:830,t:1527272089507};\\\", \\\"{x:1205,y:829,t:1527272091414};\\\", \\\"{x:1206,y:829,t:1527272091437};\\\", \\\"{x:1208,y:828,t:1527272091670};\\\", \\\"{x:1209,y:827,t:1527272091694};\\\", \\\"{x:1212,y:826,t:1527272094469};\\\", \\\"{x:1219,y:823,t:1527272094478};\\\", \\\"{x:1231,y:818,t:1527272094493};\\\", \\\"{x:1241,y:813,t:1527272094510};\\\", \\\"{x:1254,y:807,t:1527272094527};\\\", \\\"{x:1266,y:802,t:1527272094544};\\\", \\\"{x:1275,y:797,t:1527272094561};\\\", \\\"{x:1283,y:795,t:1527272094577};\\\", \\\"{x:1291,y:792,t:1527272094594};\\\", \\\"{x:1299,y:788,t:1527272094610};\\\", \\\"{x:1303,y:788,t:1527272094627};\\\", \\\"{x:1308,y:785,t:1527272094644};\\\", \\\"{x:1309,y:785,t:1527272094686};\\\", \\\"{x:1310,y:783,t:1527272094694};\\\", \\\"{x:1315,y:779,t:1527272094710};\\\", \\\"{x:1321,y:772,t:1527272094727};\\\", \\\"{x:1327,y:767,t:1527272094744};\\\", \\\"{x:1337,y:760,t:1527272094759};\\\", \\\"{x:1346,y:753,t:1527272094777};\\\", \\\"{x:1350,y:748,t:1527272094794};\\\", \\\"{x:1359,y:743,t:1527272094811};\\\", \\\"{x:1364,y:740,t:1527272094827};\\\", \\\"{x:1367,y:737,t:1527272094843};\\\", \\\"{x:1368,y:737,t:1527272094860};\\\", \\\"{x:1366,y:738,t:1527272094982};\\\", \\\"{x:1365,y:740,t:1527272094994};\\\", \\\"{x:1362,y:747,t:1527272095010};\\\", \\\"{x:1361,y:751,t:1527272095027};\\\", \\\"{x:1359,y:757,t:1527272095043};\\\", \\\"{x:1359,y:762,t:1527272095060};\\\", \\\"{x:1359,y:763,t:1527272095076};\\\", \\\"{x:1358,y:764,t:1527272095100};\\\", \\\"{x:1358,y:766,t:1527272095237};\\\", \\\"{x:1358,y:767,t:1527272095244};\\\", \\\"{x:1358,y:769,t:1527272095261};\\\", \\\"{x:1358,y:772,t:1527272095278};\\\", \\\"{x:1358,y:776,t:1527272095294};\\\", \\\"{x:1358,y:780,t:1527272095311};\\\", \\\"{x:1358,y:783,t:1527272095326};\\\", \\\"{x:1358,y:793,t:1527272095344};\\\", \\\"{x:1358,y:809,t:1527272095361};\\\", \\\"{x:1358,y:831,t:1527272095377};\\\", \\\"{x:1359,y:850,t:1527272095393};\\\", \\\"{x:1361,y:867,t:1527272095411};\\\", \\\"{x:1361,y:877,t:1527272095428};\\\", \\\"{x:1361,y:886,t:1527272095444};\\\", \\\"{x:1361,y:895,t:1527272095461};\\\", \\\"{x:1361,y:900,t:1527272095478};\\\", \\\"{x:1361,y:904,t:1527272095494};\\\", \\\"{x:1361,y:907,t:1527272095512};\\\", \\\"{x:1361,y:911,t:1527272095528};\\\", \\\"{x:1361,y:917,t:1527272095544};\\\", \\\"{x:1361,y:921,t:1527272095560};\\\", \\\"{x:1361,y:925,t:1527272095577};\\\", \\\"{x:1361,y:930,t:1527272095593};\\\", \\\"{x:1361,y:937,t:1527272095611};\\\", \\\"{x:1361,y:941,t:1527272095627};\\\", \\\"{x:1361,y:945,t:1527272095643};\\\", \\\"{x:1359,y:950,t:1527272095660};\\\", \\\"{x:1358,y:954,t:1527272095677};\\\", \\\"{x:1357,y:955,t:1527272095693};\\\", \\\"{x:1357,y:957,t:1527272095710};\\\", \\\"{x:1356,y:960,t:1527272095728};\\\", \\\"{x:1355,y:964,t:1527272095743};\\\", \\\"{x:1354,y:966,t:1527272095761};\\\", \\\"{x:1353,y:967,t:1527272095777};\\\", \\\"{x:1350,y:965,t:1527272095950};\\\", \\\"{x:1344,y:952,t:1527272095960};\\\", \\\"{x:1322,y:919,t:1527272095978};\\\", \\\"{x:1295,y:890,t:1527272095996};\\\", \\\"{x:1271,y:873,t:1527272096011};\\\", \\\"{x:1250,y:864,t:1527272096028};\\\", \\\"{x:1230,y:859,t:1527272096045};\\\", \\\"{x:1226,y:858,t:1527272096061};\\\", \\\"{x:1226,y:857,t:1527272096078};\\\", \\\"{x:1224,y:857,t:1527272096096};\\\", \\\"{x:1223,y:857,t:1527272096112};\\\", \\\"{x:1216,y:856,t:1527272096128};\\\", \\\"{x:1205,y:854,t:1527272096145};\\\", \\\"{x:1198,y:853,t:1527272096161};\\\", \\\"{x:1198,y:852,t:1527272096270};\\\", \\\"{x:1200,y:850,t:1527272096278};\\\", \\\"{x:1203,y:844,t:1527272096295};\\\", \\\"{x:1204,y:838,t:1527272096312};\\\", \\\"{x:1205,y:835,t:1527272096328};\\\", \\\"{x:1206,y:833,t:1527272096345};\\\", \\\"{x:1206,y:832,t:1527272096363};\\\", \\\"{x:1207,y:830,t:1527272096378};\\\", \\\"{x:1208,y:830,t:1527272096397};\\\", \\\"{x:1209,y:830,t:1527272096430};\\\", \\\"{x:1209,y:824,t:1527272096647};\\\", \\\"{x:1199,y:809,t:1527272096663};\\\", \\\"{x:1191,y:793,t:1527272096678};\\\", \\\"{x:1179,y:778,t:1527272096695};\\\", \\\"{x:1174,y:772,t:1527272096712};\\\", \\\"{x:1174,y:771,t:1527272096886};\\\", \\\"{x:1175,y:771,t:1527272096895};\\\", \\\"{x:1176,y:770,t:1527272096912};\\\", \\\"{x:1178,y:770,t:1527272096929};\\\", \\\"{x:1179,y:769,t:1527272096946};\\\", \\\"{x:1186,y:767,t:1527272096965};\\\", \\\"{x:1189,y:765,t:1527272096979};\\\", \\\"{x:1193,y:764,t:1527272096995};\\\", \\\"{x:1193,y:763,t:1527272097094};\\\", \\\"{x:1192,y:763,t:1527272097117};\\\", \\\"{x:1192,y:762,t:1527272097141};\\\", \\\"{x:1191,y:762,t:1527272097172};\\\", \\\"{x:1190,y:762,t:1527272097301};\\\", \\\"{x:1189,y:762,t:1527272097324};\\\", \\\"{x:1188,y:762,t:1527272097357};\\\", \\\"{x:1187,y:762,t:1527272097405};\\\", \\\"{x:1186,y:762,t:1527272097413};\\\", \\\"{x:1185,y:762,t:1527272097446};\\\", \\\"{x:1184,y:763,t:1527272097493};\\\", \\\"{x:1183,y:763,t:1527272097652};\\\", \\\"{x:1182,y:764,t:1527272097668};\\\", \\\"{x:1180,y:765,t:1527272107388};\\\", \\\"{x:1167,y:765,t:1527272107403};\\\", \\\"{x:1097,y:765,t:1527272107419};\\\", \\\"{x:888,y:734,t:1527272107436};\\\", \\\"{x:708,y:707,t:1527272107452};\\\", \\\"{x:520,y:677,t:1527272107468};\\\", \\\"{x:318,y:655,t:1527272107486};\\\", \\\"{x:141,y:628,t:1527272107503};\\\", \\\"{x:8,y:606,t:1527272107519};\\\", \\\"{x:0,y:592,t:1527272107538};\\\", \\\"{x:0,y:590,t:1527272107553};\\\", \\\"{x:0,y:588,t:1527272107627};\\\", \\\"{x:0,y:587,t:1527272107637};\\\", \\\"{x:2,y:582,t:1527272107654};\\\", \\\"{x:11,y:578,t:1527272107671};\\\", \\\"{x:25,y:569,t:1527272107688};\\\", \\\"{x:43,y:564,t:1527272107704};\\\", \\\"{x:63,y:562,t:1527272107721};\\\", \\\"{x:91,y:558,t:1527272107738};\\\", \\\"{x:128,y:558,t:1527272107754};\\\", \\\"{x:187,y:558,t:1527272107770};\\\", \\\"{x:295,y:558,t:1527272107787};\\\", \\\"{x:359,y:558,t:1527272107804};\\\", \\\"{x:399,y:557,t:1527272107821};\\\", \\\"{x:419,y:554,t:1527272107838};\\\", \\\"{x:420,y:554,t:1527272107854};\\\", \\\"{x:420,y:552,t:1527272107979};\\\", \\\"{x:417,y:552,t:1527272107987};\\\", \\\"{x:409,y:547,t:1527272108004};\\\", \\\"{x:400,y:543,t:1527272108020};\\\", \\\"{x:388,y:536,t:1527272108038};\\\", \\\"{x:381,y:530,t:1527272108055};\\\", \\\"{x:376,y:527,t:1527272108071};\\\", \\\"{x:375,y:525,t:1527272108088};\\\", \\\"{x:375,y:524,t:1527272108108};\\\", \\\"{x:375,y:523,t:1527272108132};\\\", \\\"{x:375,y:522,t:1527272108140};\\\", \\\"{x:375,y:521,t:1527272108155};\\\", \\\"{x:373,y:518,t:1527272108171};\\\", \\\"{x:367,y:515,t:1527272108188};\\\", \\\"{x:354,y:508,t:1527272108204};\\\", \\\"{x:327,y:501,t:1527272108221};\\\", \\\"{x:301,y:492,t:1527272108238};\\\", \\\"{x:275,y:485,t:1527272108255};\\\", \\\"{x:254,y:482,t:1527272108271};\\\", \\\"{x:237,y:479,t:1527272108288};\\\", \\\"{x:229,y:478,t:1527272108305};\\\", \\\"{x:223,y:478,t:1527272108322};\\\", \\\"{x:221,y:478,t:1527272108338};\\\", \\\"{x:220,y:478,t:1527272108355};\\\", \\\"{x:217,y:478,t:1527272108372};\\\", \\\"{x:213,y:478,t:1527272108388};\\\", \\\"{x:208,y:480,t:1527272108405};\\\", \\\"{x:204,y:481,t:1527272108421};\\\", \\\"{x:197,y:484,t:1527272108438};\\\", \\\"{x:191,y:488,t:1527272108455};\\\", \\\"{x:187,y:489,t:1527272108472};\\\", \\\"{x:183,y:492,t:1527272108488};\\\", \\\"{x:181,y:493,t:1527272108505};\\\", \\\"{x:178,y:495,t:1527272108522};\\\", \\\"{x:176,y:497,t:1527272108538};\\\", \\\"{x:176,y:498,t:1527272108555};\\\", \\\"{x:176,y:501,t:1527272108571};\\\", \\\"{x:174,y:502,t:1527272108588};\\\", \\\"{x:173,y:503,t:1527272108605};\\\", \\\"{x:172,y:503,t:1527272108622};\\\", \\\"{x:168,y:504,t:1527272108638};\\\", \\\"{x:171,y:506,t:1527272108900};\\\", \\\"{x:180,y:510,t:1527272108907};\\\", \\\"{x:192,y:515,t:1527272108922};\\\", \\\"{x:222,y:528,t:1527272108939};\\\", \\\"{x:246,y:541,t:1527272108955};\\\", \\\"{x:295,y:584,t:1527272108972};\\\", \\\"{x:326,y:620,t:1527272108989};\\\", \\\"{x:364,y:664,t:1527272109006};\\\", \\\"{x:383,y:689,t:1527272109022};\\\", \\\"{x:393,y:702,t:1527272109039};\\\", \\\"{x:393,y:703,t:1527272109055};\\\", \\\"{x:393,y:704,t:1527272109084};\\\", \\\"{x:393,y:705,t:1527272109124};\\\", \\\"{x:393,y:706,t:1527272109156};\\\", \\\"{x:393,y:708,t:1527272109171};\\\", \\\"{x:393,y:709,t:1527272109188};\\\", \\\"{x:393,y:713,t:1527272109206};\\\", \\\"{x:395,y:716,t:1527272109222};\\\", \\\"{x:401,y:720,t:1527272109239};\\\", \\\"{x:410,y:724,t:1527272109256};\\\", \\\"{x:417,y:725,t:1527272109272};\\\", \\\"{x:422,y:725,t:1527272109289};\\\", \\\"{x:428,y:725,t:1527272109305};\\\", \\\"{x:444,y:725,t:1527272109322};\\\", \\\"{x:466,y:725,t:1527272109339};\\\", \\\"{x:495,y:725,t:1527272109356};\\\", \\\"{x:509,y:726,t:1527272109372};\\\", \\\"{x:512,y:726,t:1527272109389};\\\", \\\"{x:513,y:726,t:1527272109406};\\\" ] }, { \\\"rt\\\": 52056, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 579376, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -G -C -F -B -B -12 PM-03 PM-04 PM-05 PM-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:713,t:1527272111360};\\\", \\\"{x:510,y:688,t:1527272111375};\\\", \\\"{x:505,y:662,t:1527272111391};\\\", \\\"{x:503,y:633,t:1527272111406};\\\", \\\"{x:503,y:608,t:1527272111424};\\\", \\\"{x:500,y:585,t:1527272111441};\\\", \\\"{x:499,y:566,t:1527272111457};\\\", \\\"{x:494,y:548,t:1527272111475};\\\", \\\"{x:487,y:532,t:1527272111491};\\\", \\\"{x:480,y:521,t:1527272111508};\\\", \\\"{x:476,y:514,t:1527272111524};\\\", \\\"{x:476,y:513,t:1527272111541};\\\", \\\"{x:476,y:512,t:1527272111557};\\\", \\\"{x:476,y:511,t:1527272111574};\\\", \\\"{x:476,y:510,t:1527272111596};\\\", \\\"{x:476,y:509,t:1527272111607};\\\", \\\"{x:484,y:505,t:1527272111624};\\\", \\\"{x:491,y:501,t:1527272111641};\\\", \\\"{x:495,y:498,t:1527272111656};\\\", \\\"{x:501,y:494,t:1527272111674};\\\", \\\"{x:503,y:489,t:1527272111691};\\\", \\\"{x:504,y:488,t:1527272111707};\\\", \\\"{x:509,y:485,t:1527272111724};\\\", \\\"{x:515,y:481,t:1527272111740};\\\", \\\"{x:520,y:478,t:1527272111757};\\\", \\\"{x:526,y:477,t:1527272111774};\\\", \\\"{x:528,y:474,t:1527272111791};\\\", \\\"{x:531,y:473,t:1527272111808};\\\", \\\"{x:534,y:471,t:1527272111825};\\\", \\\"{x:537,y:469,t:1527272111842};\\\", \\\"{x:540,y:467,t:1527272111858};\\\", \\\"{x:544,y:466,t:1527272111874};\\\", \\\"{x:546,y:465,t:1527272111891};\\\", \\\"{x:548,y:464,t:1527272111908};\\\", \\\"{x:549,y:464,t:1527272111925};\\\", \\\"{x:551,y:463,t:1527272111941};\\\", \\\"{x:554,y:461,t:1527272111958};\\\", \\\"{x:558,y:460,t:1527272111974};\\\", \\\"{x:559,y:460,t:1527272111997};\\\", \\\"{x:560,y:460,t:1527272112008};\\\", \\\"{x:561,y:460,t:1527272112024};\\\", \\\"{x:562,y:460,t:1527272112061};\\\", \\\"{x:562,y:459,t:1527272112075};\\\", \\\"{x:565,y:458,t:1527272112091};\\\", \\\"{x:570,y:457,t:1527272112109};\\\", \\\"{x:573,y:456,t:1527272112125};\\\", \\\"{x:576,y:455,t:1527272112141};\\\", \\\"{x:579,y:454,t:1527272112159};\\\", \\\"{x:582,y:454,t:1527272112176};\\\", \\\"{x:586,y:453,t:1527272112191};\\\", \\\"{x:593,y:453,t:1527272112209};\\\", \\\"{x:597,y:453,t:1527272112225};\\\", \\\"{x:602,y:451,t:1527272112242};\\\", \\\"{x:603,y:451,t:1527272112258};\\\", \\\"{x:606,y:450,t:1527272112275};\\\", \\\"{x:607,y:450,t:1527272112291};\\\", \\\"{x:613,y:450,t:1527272112308};\\\", \\\"{x:618,y:449,t:1527272112325};\\\", \\\"{x:624,y:449,t:1527272112342};\\\", \\\"{x:630,y:447,t:1527272112359};\\\", \\\"{x:634,y:447,t:1527272112375};\\\", \\\"{x:636,y:447,t:1527272112393};\\\", \\\"{x:637,y:447,t:1527272112436};\\\", \\\"{x:638,y:447,t:1527272112453};\\\", \\\"{x:640,y:447,t:1527272112461};\\\", \\\"{x:643,y:447,t:1527272112476};\\\", \\\"{x:646,y:447,t:1527272112493};\\\", \\\"{x:647,y:447,t:1527272112508};\\\", \\\"{x:648,y:447,t:1527272112525};\\\", \\\"{x:649,y:447,t:1527272112543};\\\", \\\"{x:651,y:447,t:1527272112559};\\\", \\\"{x:657,y:447,t:1527272112576};\\\", \\\"{x:664,y:448,t:1527272112592};\\\", \\\"{x:678,y:449,t:1527272112608};\\\", \\\"{x:699,y:454,t:1527272112625};\\\", \\\"{x:729,y:460,t:1527272112642};\\\", \\\"{x:778,y:468,t:1527272112658};\\\", \\\"{x:851,y:485,t:1527272112676};\\\", \\\"{x:994,y:504,t:1527272112693};\\\", \\\"{x:1081,y:519,t:1527272112709};\\\", \\\"{x:1181,y:533,t:1527272112726};\\\", \\\"{x:1264,y:544,t:1527272112743};\\\", \\\"{x:1325,y:552,t:1527272112759};\\\", \\\"{x:1373,y:558,t:1527272112776};\\\", \\\"{x:1407,y:558,t:1527272112792};\\\", \\\"{x:1432,y:558,t:1527272112810};\\\", \\\"{x:1447,y:558,t:1527272112825};\\\", \\\"{x:1453,y:558,t:1527272112843};\\\", \\\"{x:1454,y:558,t:1527272112860};\\\", \\\"{x:1455,y:558,t:1527272112876};\\\", \\\"{x:1458,y:549,t:1527272112893};\\\", \\\"{x:1462,y:537,t:1527272112910};\\\", \\\"{x:1467,y:524,t:1527272112926};\\\", \\\"{x:1469,y:511,t:1527272112943};\\\", \\\"{x:1468,y:498,t:1527272112960};\\\", \\\"{x:1466,y:490,t:1527272112976};\\\", \\\"{x:1463,y:485,t:1527272112992};\\\", \\\"{x:1462,y:482,t:1527272113009};\\\", \\\"{x:1459,y:478,t:1527272113026};\\\", \\\"{x:1456,y:475,t:1527272113042};\\\", \\\"{x:1452,y:469,t:1527272113059};\\\", \\\"{x:1448,y:462,t:1527272113076};\\\", \\\"{x:1447,y:459,t:1527272113093};\\\", \\\"{x:1446,y:459,t:1527272113110};\\\", \\\"{x:1446,y:458,t:1527272113181};\\\", \\\"{x:1444,y:465,t:1527272113205};\\\", \\\"{x:1443,y:474,t:1527272113213};\\\", \\\"{x:1440,y:486,t:1527272113226};\\\", \\\"{x:1433,y:516,t:1527272113243};\\\", \\\"{x:1421,y:548,t:1527272113260};\\\", \\\"{x:1403,y:588,t:1527272113277};\\\", \\\"{x:1391,y:605,t:1527272113293};\\\", \\\"{x:1383,y:621,t:1527272113310};\\\", \\\"{x:1375,y:640,t:1527272113327};\\\", \\\"{x:1369,y:662,t:1527272113343};\\\", \\\"{x:1364,y:687,t:1527272113360};\\\", \\\"{x:1358,y:708,t:1527272113377};\\\", \\\"{x:1353,y:728,t:1527272113394};\\\", \\\"{x:1348,y:747,t:1527272113410};\\\", \\\"{x:1340,y:761,t:1527272113428};\\\", \\\"{x:1334,y:773,t:1527272113444};\\\", \\\"{x:1328,y:783,t:1527272113460};\\\", \\\"{x:1321,y:792,t:1527272113476};\\\", \\\"{x:1314,y:798,t:1527272113494};\\\", \\\"{x:1307,y:801,t:1527272113510};\\\", \\\"{x:1299,y:802,t:1527272113527};\\\", \\\"{x:1288,y:801,t:1527272113544};\\\", \\\"{x:1273,y:785,t:1527272113559};\\\", \\\"{x:1263,y:766,t:1527272113576};\\\", \\\"{x:1259,y:745,t:1527272113594};\\\", \\\"{x:1254,y:717,t:1527272113610};\\\", \\\"{x:1254,y:687,t:1527272113627};\\\", \\\"{x:1254,y:658,t:1527272113644};\\\", \\\"{x:1255,y:632,t:1527272113661};\\\", \\\"{x:1264,y:618,t:1527272113676};\\\", \\\"{x:1272,y:609,t:1527272113694};\\\", \\\"{x:1280,y:600,t:1527272113710};\\\", \\\"{x:1287,y:591,t:1527272113727};\\\", \\\"{x:1296,y:579,t:1527272113744};\\\", \\\"{x:1307,y:569,t:1527272113761};\\\", \\\"{x:1323,y:561,t:1527272113777};\\\", \\\"{x:1338,y:556,t:1527272113794};\\\", \\\"{x:1357,y:549,t:1527272113811};\\\", \\\"{x:1376,y:547,t:1527272113827};\\\", \\\"{x:1392,y:546,t:1527272113844};\\\", \\\"{x:1414,y:555,t:1527272113861};\\\", \\\"{x:1426,y:571,t:1527272113877};\\\", \\\"{x:1437,y:595,t:1527272113894};\\\", \\\"{x:1445,y:625,t:1527272113913};\\\", \\\"{x:1450,y:660,t:1527272113927};\\\", \\\"{x:1450,y:693,t:1527272113943};\\\", \\\"{x:1448,y:718,t:1527272113960};\\\", \\\"{x:1438,y:737,t:1527272113976};\\\", \\\"{x:1428,y:748,t:1527272113993};\\\", \\\"{x:1414,y:760,t:1527272114010};\\\", \\\"{x:1399,y:767,t:1527272114027};\\\", \\\"{x:1384,y:776,t:1527272114043};\\\", \\\"{x:1353,y:781,t:1527272114060};\\\", \\\"{x:1332,y:781,t:1527272114077};\\\", \\\"{x:1296,y:764,t:1527272114093};\\\", \\\"{x:1256,y:735,t:1527272114111};\\\", \\\"{x:1230,y:712,t:1527272114128};\\\", \\\"{x:1223,y:696,t:1527272114144};\\\", \\\"{x:1222,y:684,t:1527272114161};\\\", \\\"{x:1227,y:674,t:1527272114177};\\\", \\\"{x:1237,y:666,t:1527272114194};\\\", \\\"{x:1247,y:661,t:1527272114210};\\\", \\\"{x:1253,y:659,t:1527272114228};\\\", \\\"{x:1260,y:656,t:1527272114244};\\\", \\\"{x:1269,y:656,t:1527272114260};\\\", \\\"{x:1274,y:655,t:1527272114278};\\\", \\\"{x:1281,y:655,t:1527272114294};\\\", \\\"{x:1286,y:655,t:1527272114311};\\\", \\\"{x:1295,y:655,t:1527272114328};\\\", \\\"{x:1307,y:655,t:1527272114345};\\\", \\\"{x:1316,y:655,t:1527272114361};\\\", \\\"{x:1321,y:655,t:1527272114378};\\\", \\\"{x:1324,y:656,t:1527272114394};\\\", \\\"{x:1329,y:659,t:1527272114411};\\\", \\\"{x:1339,y:667,t:1527272114428};\\\", \\\"{x:1355,y:681,t:1527272114445};\\\", \\\"{x:1360,y:686,t:1527272114461};\\\", \\\"{x:1361,y:686,t:1527272114478};\\\", \\\"{x:1361,y:687,t:1527272114494};\\\", \\\"{x:1361,y:688,t:1527272114549};\\\", \\\"{x:1361,y:689,t:1527272114564};\\\", \\\"{x:1359,y:689,t:1527272114581};\\\", \\\"{x:1358,y:690,t:1527272114621};\\\", \\\"{x:1357,y:691,t:1527272114637};\\\", \\\"{x:1356,y:691,t:1527272114645};\\\", \\\"{x:1355,y:692,t:1527272114661};\\\", \\\"{x:1354,y:692,t:1527272114678};\\\", \\\"{x:1352,y:692,t:1527272114696};\\\", \\\"{x:1350,y:694,t:1527272114712};\\\", \\\"{x:1349,y:694,t:1527272114728};\\\", \\\"{x:1349,y:695,t:1527272119405};\\\", \\\"{x:1349,y:698,t:1527272119416};\\\", \\\"{x:1349,y:707,t:1527272119434};\\\", \\\"{x:1349,y:712,t:1527272119451};\\\", \\\"{x:1347,y:715,t:1527272119467};\\\", \\\"{x:1347,y:717,t:1527272119483};\\\", \\\"{x:1347,y:719,t:1527272119500};\\\", \\\"{x:1347,y:720,t:1527272119517};\\\", \\\"{x:1347,y:722,t:1527272119533};\\\", \\\"{x:1347,y:723,t:1527272119550};\\\", \\\"{x:1347,y:724,t:1527272119567};\\\", \\\"{x:1347,y:726,t:1527272119583};\\\", \\\"{x:1347,y:729,t:1527272119601};\\\", \\\"{x:1346,y:732,t:1527272119617};\\\", \\\"{x:1346,y:735,t:1527272119633};\\\", \\\"{x:1346,y:739,t:1527272119650};\\\", \\\"{x:1346,y:741,t:1527272119668};\\\", \\\"{x:1345,y:744,t:1527272119684};\\\", \\\"{x:1345,y:746,t:1527272119700};\\\", \\\"{x:1345,y:752,t:1527272119716};\\\", \\\"{x:1345,y:757,t:1527272119733};\\\", \\\"{x:1344,y:764,t:1527272119749};\\\", \\\"{x:1342,y:770,t:1527272119766};\\\", \\\"{x:1342,y:772,t:1527272119783};\\\", \\\"{x:1342,y:776,t:1527272119799};\\\", \\\"{x:1342,y:781,t:1527272119817};\\\", \\\"{x:1342,y:787,t:1527272119833};\\\", \\\"{x:1342,y:793,t:1527272119849};\\\", \\\"{x:1341,y:798,t:1527272119866};\\\", \\\"{x:1340,y:802,t:1527272119884};\\\", \\\"{x:1339,y:809,t:1527272119899};\\\", \\\"{x:1338,y:817,t:1527272119917};\\\", \\\"{x:1338,y:826,t:1527272119934};\\\", \\\"{x:1338,y:834,t:1527272119950};\\\", \\\"{x:1337,y:838,t:1527272119967};\\\", \\\"{x:1337,y:841,t:1527272119984};\\\", \\\"{x:1336,y:844,t:1527272120000};\\\", \\\"{x:1336,y:848,t:1527272120017};\\\", \\\"{x:1336,y:853,t:1527272120034};\\\", \\\"{x:1336,y:859,t:1527272120051};\\\", \\\"{x:1336,y:867,t:1527272120067};\\\", \\\"{x:1336,y:875,t:1527272120084};\\\", \\\"{x:1336,y:885,t:1527272120100};\\\", \\\"{x:1336,y:892,t:1527272120117};\\\", \\\"{x:1336,y:899,t:1527272120134};\\\", \\\"{x:1336,y:904,t:1527272120151};\\\", \\\"{x:1336,y:911,t:1527272120167};\\\", \\\"{x:1336,y:916,t:1527272120184};\\\", \\\"{x:1336,y:922,t:1527272120201};\\\", \\\"{x:1336,y:926,t:1527272120217};\\\", \\\"{x:1336,y:931,t:1527272120234};\\\", \\\"{x:1336,y:937,t:1527272120251};\\\", \\\"{x:1336,y:940,t:1527272120267};\\\", \\\"{x:1336,y:942,t:1527272120284};\\\", \\\"{x:1336,y:947,t:1527272120300};\\\", \\\"{x:1336,y:951,t:1527272120318};\\\", \\\"{x:1338,y:956,t:1527272120334};\\\", \\\"{x:1338,y:960,t:1527272120351};\\\", \\\"{x:1338,y:962,t:1527272120368};\\\", \\\"{x:1338,y:963,t:1527272120384};\\\", \\\"{x:1339,y:963,t:1527272120401};\\\", \\\"{x:1339,y:965,t:1527272120418};\\\", \\\"{x:1339,y:967,t:1527272120434};\\\", \\\"{x:1339,y:970,t:1527272120452};\\\", \\\"{x:1339,y:971,t:1527272120468};\\\", \\\"{x:1341,y:972,t:1527272120660};\\\", \\\"{x:1343,y:972,t:1527272120676};\\\", \\\"{x:1344,y:970,t:1527272120684};\\\", \\\"{x:1346,y:966,t:1527272120701};\\\", \\\"{x:1347,y:964,t:1527272120718};\\\", \\\"{x:1348,y:963,t:1527272120735};\\\", \\\"{x:1349,y:962,t:1527272121301};\\\", \\\"{x:1352,y:960,t:1527272121308};\\\", \\\"{x:1357,y:958,t:1527272121318};\\\", \\\"{x:1367,y:958,t:1527272121334};\\\", \\\"{x:1384,y:958,t:1527272121352};\\\", \\\"{x:1411,y:964,t:1527272121368};\\\", \\\"{x:1433,y:966,t:1527272121385};\\\", \\\"{x:1451,y:969,t:1527272121402};\\\", \\\"{x:1456,y:970,t:1527272121419};\\\", \\\"{x:1457,y:970,t:1527272121435};\\\", \\\"{x:1455,y:970,t:1527272121572};\\\", \\\"{x:1451,y:969,t:1527272121584};\\\", \\\"{x:1441,y:967,t:1527272121602};\\\", \\\"{x:1428,y:967,t:1527272121619};\\\", \\\"{x:1418,y:967,t:1527272121636};\\\", \\\"{x:1417,y:967,t:1527272121653};\\\", \\\"{x:1416,y:967,t:1527272121893};\\\", \\\"{x:1417,y:965,t:1527272121904};\\\", \\\"{x:1423,y:962,t:1527272121919};\\\", \\\"{x:1436,y:962,t:1527272121936};\\\", \\\"{x:1458,y:963,t:1527272121953};\\\", \\\"{x:1481,y:965,t:1527272121970};\\\", \\\"{x:1499,y:967,t:1527272121986};\\\", \\\"{x:1508,y:967,t:1527272122003};\\\", \\\"{x:1509,y:967,t:1527272122019};\\\", \\\"{x:1508,y:967,t:1527272122181};\\\", \\\"{x:1505,y:967,t:1527272122189};\\\", \\\"{x:1503,y:967,t:1527272122203};\\\", \\\"{x:1497,y:967,t:1527272122220};\\\", \\\"{x:1496,y:967,t:1527272122237};\\\", \\\"{x:1498,y:968,t:1527272122533};\\\", \\\"{x:1503,y:968,t:1527272122541};\\\", \\\"{x:1507,y:969,t:1527272122553};\\\", \\\"{x:1521,y:969,t:1527272122570};\\\", \\\"{x:1533,y:969,t:1527272122587};\\\", \\\"{x:1539,y:969,t:1527272122603};\\\", \\\"{x:1541,y:969,t:1527272122620};\\\", \\\"{x:1542,y:969,t:1527272122805};\\\", \\\"{x:1556,y:969,t:1527272122821};\\\", \\\"{x:1576,y:969,t:1527272122837};\\\", \\\"{x:1601,y:969,t:1527272122854};\\\", \\\"{x:1628,y:969,t:1527272122870};\\\", \\\"{x:1649,y:969,t:1527272122888};\\\", \\\"{x:1663,y:969,t:1527272122904};\\\", \\\"{x:1668,y:969,t:1527272122920};\\\", \\\"{x:1670,y:969,t:1527272122937};\\\", \\\"{x:1669,y:969,t:1527272123149};\\\", \\\"{x:1668,y:969,t:1527272123156};\\\", \\\"{x:1666,y:969,t:1527272123171};\\\", \\\"{x:1662,y:969,t:1527272123187};\\\", \\\"{x:1658,y:969,t:1527272123205};\\\", \\\"{x:1657,y:969,t:1527272123229};\\\", \\\"{x:1656,y:969,t:1527272123253};\\\", \\\"{x:1655,y:969,t:1527272123260};\\\", \\\"{x:1655,y:970,t:1527272123272};\\\", \\\"{x:1654,y:970,t:1527272123287};\\\", \\\"{x:1652,y:970,t:1527272123302};\\\", \\\"{x:1651,y:971,t:1527272123319};\\\", \\\"{x:1650,y:971,t:1527272123387};\\\", \\\"{x:1648,y:972,t:1527272123402};\\\", \\\"{x:1645,y:973,t:1527272123419};\\\", \\\"{x:1641,y:973,t:1527272123435};\\\", \\\"{x:1639,y:973,t:1527272123452};\\\", \\\"{x:1638,y:974,t:1527272123469};\\\", \\\"{x:1637,y:974,t:1527272123506};\\\", \\\"{x:1636,y:974,t:1527272123519};\\\", \\\"{x:1635,y:974,t:1527272123536};\\\", \\\"{x:1632,y:974,t:1527272123552};\\\", \\\"{x:1628,y:974,t:1527272123569};\\\", \\\"{x:1622,y:974,t:1527272123586};\\\", \\\"{x:1618,y:974,t:1527272123602};\\\", \\\"{x:1611,y:973,t:1527272123618};\\\", \\\"{x:1605,y:972,t:1527272123636};\\\", \\\"{x:1602,y:972,t:1527272123652};\\\", \\\"{x:1602,y:971,t:1527272123811};\\\", \\\"{x:1603,y:969,t:1527272123819};\\\", \\\"{x:1608,y:967,t:1527272123837};\\\", \\\"{x:1613,y:965,t:1527272123853};\\\", \\\"{x:1601,y:956,t:1527272134275};\\\", \\\"{x:1549,y:931,t:1527272134282};\\\", \\\"{x:1474,y:902,t:1527272134298};\\\", \\\"{x:1238,y:797,t:1527272134314};\\\", \\\"{x:1051,y:723,t:1527272134330};\\\", \\\"{x:848,y:672,t:1527272134348};\\\", \\\"{x:682,y:625,t:1527272134366};\\\", \\\"{x:577,y:608,t:1527272134380};\\\", \\\"{x:539,y:607,t:1527272134397};\\\", \\\"{x:530,y:606,t:1527272134407};\\\", \\\"{x:526,y:604,t:1527272134424};\\\", \\\"{x:527,y:604,t:1527272134530};\\\", \\\"{x:533,y:602,t:1527272134541};\\\", \\\"{x:550,y:596,t:1527272134558};\\\", \\\"{x:571,y:589,t:1527272134575};\\\", \\\"{x:591,y:586,t:1527272134591};\\\", \\\"{x:605,y:580,t:1527272134607};\\\", \\\"{x:613,y:578,t:1527272134624};\\\", \\\"{x:614,y:577,t:1527272134641};\\\", \\\"{x:614,y:575,t:1527272135089};\\\", \\\"{x:612,y:580,t:1527272135097};\\\", \\\"{x:612,y:590,t:1527272135108};\\\", \\\"{x:612,y:611,t:1527272135125};\\\", \\\"{x:612,y:623,t:1527272135141};\\\", \\\"{x:609,y:643,t:1527272135159};\\\", \\\"{x:605,y:658,t:1527272135175};\\\", \\\"{x:602,y:666,t:1527272135191};\\\", \\\"{x:597,y:677,t:1527272135208};\\\", \\\"{x:592,y:685,t:1527272135225};\\\", \\\"{x:585,y:697,t:1527272135241};\\\", \\\"{x:576,y:713,t:1527272135257};\\\", \\\"{x:568,y:722,t:1527272135275};\\\", \\\"{x:565,y:726,t:1527272135291};\\\", \\\"{x:561,y:731,t:1527272135310};\\\", \\\"{x:557,y:737,t:1527272135325};\\\", \\\"{x:556,y:745,t:1527272135341};\\\", \\\"{x:555,y:753,t:1527272135358};\\\", \\\"{x:553,y:759,t:1527272135375};\\\", \\\"{x:553,y:765,t:1527272135391};\\\", \\\"{x:559,y:775,t:1527272135408};\\\", \\\"{x:580,y:790,t:1527272135425};\\\", \\\"{x:635,y:813,t:1527272135441};\\\", \\\"{x:792,y:855,t:1527272135458};\\\", \\\"{x:934,y:877,t:1527272135475};\\\", \\\"{x:1083,y:898,t:1527272135491};\\\", \\\"{x:1232,y:913,t:1527272135508};\\\", \\\"{x:1360,y:918,t:1527272135525};\\\", \\\"{x:1463,y:918,t:1527272135541};\\\", \\\"{x:1516,y:918,t:1527272135558};\\\", \\\"{x:1536,y:915,t:1527272135575};\\\", \\\"{x:1540,y:915,t:1527272135592};\\\", \\\"{x:1541,y:914,t:1527272135608};\\\", \\\"{x:1542,y:914,t:1527272135634};\\\", \\\"{x:1546,y:912,t:1527272135642};\\\", \\\"{x:1549,y:911,t:1527272135658};\\\", \\\"{x:1553,y:910,t:1527272135676};\\\", \\\"{x:1560,y:910,t:1527272135693};\\\", \\\"{x:1570,y:912,t:1527272135708};\\\", \\\"{x:1577,y:917,t:1527272135725};\\\", \\\"{x:1582,y:920,t:1527272135742};\\\", \\\"{x:1584,y:925,t:1527272135758};\\\", \\\"{x:1588,y:939,t:1527272135775};\\\", \\\"{x:1591,y:951,t:1527272135793};\\\", \\\"{x:1595,y:964,t:1527272135808};\\\", \\\"{x:1595,y:969,t:1527272135826};\\\", \\\"{x:1597,y:976,t:1527272135842};\\\", \\\"{x:1597,y:979,t:1527272135858};\\\", \\\"{x:1599,y:981,t:1527272135875};\\\", \\\"{x:1600,y:982,t:1527272135898};\\\", \\\"{x:1601,y:982,t:1527272135986};\\\", \\\"{x:1602,y:982,t:1527272135994};\\\", \\\"{x:1603,y:982,t:1527272136010};\\\", \\\"{x:1604,y:982,t:1527272136026};\\\", \\\"{x:1608,y:981,t:1527272136042};\\\", \\\"{x:1613,y:979,t:1527272136058};\\\", \\\"{x:1615,y:978,t:1527272136075};\\\", \\\"{x:1619,y:975,t:1527272136093};\\\", \\\"{x:1620,y:974,t:1527272136108};\\\", \\\"{x:1622,y:971,t:1527272136126};\\\", \\\"{x:1624,y:968,t:1527272136143};\\\", \\\"{x:1625,y:967,t:1527272136162};\\\", \\\"{x:1625,y:966,t:1527272136175};\\\", \\\"{x:1626,y:966,t:1527272136194};\\\", \\\"{x:1626,y:965,t:1527272136210};\\\", \\\"{x:1627,y:965,t:1527272136226};\\\", \\\"{x:1627,y:963,t:1527272136363};\\\", \\\"{x:1627,y:962,t:1527272136387};\\\", \\\"{x:1623,y:962,t:1527272138859};\\\", \\\"{x:1620,y:962,t:1527272138866};\\\", \\\"{x:1618,y:962,t:1527272138878};\\\", \\\"{x:1616,y:962,t:1527272138895};\\\", \\\"{x:1605,y:962,t:1527272161979};\\\", \\\"{x:1542,y:958,t:1527272161995};\\\", \\\"{x:1445,y:942,t:1527272162012};\\\", \\\"{x:1338,y:934,t:1527272162028};\\\", \\\"{x:1200,y:917,t:1527272162045};\\\", \\\"{x:1041,y:889,t:1527272162062};\\\", \\\"{x:833,y:842,t:1527272162079};\\\", \\\"{x:610,y:791,t:1527272162095};\\\", \\\"{x:427,y:761,t:1527272162112};\\\", \\\"{x:307,y:753,t:1527272162129};\\\", \\\"{x:243,y:753,t:1527272162144};\\\", \\\"{x:211,y:753,t:1527272162162};\\\", \\\"{x:210,y:752,t:1527272162178};\\\", \\\"{x:207,y:752,t:1527272162242};\\\", \\\"{x:205,y:753,t:1527272162258};\\\", \\\"{x:207,y:751,t:1527272162322};\\\", \\\"{x:217,y:748,t:1527272162329};\\\", \\\"{x:228,y:747,t:1527272162345};\\\", \\\"{x:268,y:743,t:1527272162362};\\\", \\\"{x:304,y:743,t:1527272162378};\\\", \\\"{x:349,y:743,t:1527272162395};\\\", \\\"{x:381,y:743,t:1527272162411};\\\", \\\"{x:401,y:743,t:1527272162428};\\\", \\\"{x:415,y:743,t:1527272162445};\\\", \\\"{x:419,y:743,t:1527272162461};\\\", \\\"{x:423,y:742,t:1527272162479};\\\", \\\"{x:425,y:742,t:1527272162546};\\\", \\\"{x:426,y:742,t:1527272162561};\\\", \\\"{x:428,y:742,t:1527272162579};\\\", \\\"{x:430,y:742,t:1527272162595};\\\", \\\"{x:431,y:742,t:1527272162611};\\\", \\\"{x:432,y:742,t:1527272162641};\\\", \\\"{x:433,y:742,t:1527272162649};\\\", \\\"{x:437,y:740,t:1527272162662};\\\", \\\"{x:444,y:739,t:1527272162679};\\\", \\\"{x:454,y:738,t:1527272162695};\\\", \\\"{x:458,y:738,t:1527272162711};\\\", \\\"{x:463,y:737,t:1527272162731};\\\", \\\"{x:464,y:737,t:1527272162747};\\\", \\\"{x:465,y:737,t:1527272162769};\\\" ] }, { \\\"rt\\\": 7624, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 588239, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:441,y:635,t:1527272164630};\\\", \\\"{x:433,y:582,t:1527272164648};\\\", \\\"{x:422,y:543,t:1527272164665};\\\", \\\"{x:419,y:530,t:1527272164687};\\\", \\\"{x:419,y:521,t:1527272164698};\\\", \\\"{x:419,y:513,t:1527272164715};\\\", \\\"{x:419,y:506,t:1527272164732};\\\", \\\"{x:419,y:499,t:1527272164748};\\\", \\\"{x:423,y:494,t:1527272164765};\\\", \\\"{x:432,y:491,t:1527272164782};\\\", \\\"{x:444,y:486,t:1527272164800};\\\", \\\"{x:454,y:482,t:1527272164816};\\\", \\\"{x:468,y:480,t:1527272164832};\\\", \\\"{x:485,y:480,t:1527272164849};\\\", \\\"{x:519,y:480,t:1527272164865};\\\", \\\"{x:549,y:480,t:1527272164882};\\\", \\\"{x:594,y:480,t:1527272164899};\\\", \\\"{x:634,y:483,t:1527272164915};\\\", \\\"{x:693,y:483,t:1527272164933};\\\", \\\"{x:760,y:483,t:1527272164948};\\\", \\\"{x:818,y:483,t:1527272164966};\\\", \\\"{x:866,y:483,t:1527272164983};\\\", \\\"{x:906,y:484,t:1527272164999};\\\", \\\"{x:928,y:485,t:1527272165015};\\\", \\\"{x:946,y:486,t:1527272165032};\\\", \\\"{x:957,y:490,t:1527272165049};\\\", \\\"{x:959,y:490,t:1527272165066};\\\", \\\"{x:961,y:492,t:1527272165082};\\\", \\\"{x:961,y:494,t:1527272165578};\\\", \\\"{x:963,y:507,t:1527272165586};\\\", \\\"{x:964,y:511,t:1527272165599};\\\", \\\"{x:973,y:517,t:1527272165617};\\\", \\\"{x:991,y:529,t:1527272165633};\\\", \\\"{x:1047,y:555,t:1527272165649};\\\", \\\"{x:1118,y:584,t:1527272165667};\\\", \\\"{x:1193,y:614,t:1527272165683};\\\", \\\"{x:1266,y:641,t:1527272165700};\\\", \\\"{x:1333,y:672,t:1527272165717};\\\", \\\"{x:1391,y:700,t:1527272165733};\\\", \\\"{x:1435,y:718,t:1527272165750};\\\", \\\"{x:1468,y:737,t:1527272165767};\\\", \\\"{x:1489,y:757,t:1527272165783};\\\", \\\"{x:1512,y:783,t:1527272165800};\\\", \\\"{x:1544,y:828,t:1527272165816};\\\", \\\"{x:1577,y:869,t:1527272165833};\\\", \\\"{x:1624,y:935,t:1527272165850};\\\", \\\"{x:1656,y:984,t:1527272165867};\\\", \\\"{x:1665,y:1018,t:1527272165883};\\\", \\\"{x:1674,y:1039,t:1527272165900};\\\", \\\"{x:1673,y:1046,t:1527272165917};\\\", \\\"{x:1670,y:1040,t:1527272166090};\\\", \\\"{x:1670,y:1033,t:1527272166100};\\\", \\\"{x:1670,y:1024,t:1527272166117};\\\", \\\"{x:1670,y:1012,t:1527272166135};\\\", \\\"{x:1662,y:996,t:1527272166151};\\\", \\\"{x:1646,y:975,t:1527272166167};\\\", \\\"{x:1622,y:957,t:1527272166184};\\\", \\\"{x:1595,y:944,t:1527272166202};\\\", \\\"{x:1577,y:939,t:1527272166217};\\\", \\\"{x:1550,y:936,t:1527272166234};\\\", \\\"{x:1530,y:936,t:1527272166250};\\\", \\\"{x:1509,y:936,t:1527272166267};\\\", \\\"{x:1489,y:933,t:1527272166284};\\\", \\\"{x:1453,y:928,t:1527272166301};\\\", \\\"{x:1411,y:923,t:1527272166317};\\\", \\\"{x:1378,y:923,t:1527272166335};\\\", \\\"{x:1352,y:923,t:1527272166351};\\\", \\\"{x:1331,y:924,t:1527272166367};\\\", \\\"{x:1321,y:928,t:1527272166384};\\\", \\\"{x:1319,y:928,t:1527272166401};\\\", \\\"{x:1317,y:929,t:1527272166417};\\\", \\\"{x:1316,y:929,t:1527272166442};\\\", \\\"{x:1319,y:930,t:1527272166690};\\\", \\\"{x:1326,y:928,t:1527272166701};\\\", \\\"{x:1345,y:920,t:1527272166718};\\\", \\\"{x:1350,y:918,t:1527272166734};\\\", \\\"{x:1351,y:918,t:1527272166851};\\\", \\\"{x:1359,y:915,t:1527272166868};\\\", \\\"{x:1366,y:911,t:1527272166884};\\\", \\\"{x:1371,y:909,t:1527272166901};\\\", \\\"{x:1373,y:907,t:1527272166919};\\\", \\\"{x:1374,y:897,t:1527272166935};\\\", \\\"{x:1376,y:868,t:1527272166951};\\\", \\\"{x:1376,y:848,t:1527272166968};\\\", \\\"{x:1376,y:834,t:1527272166986};\\\", \\\"{x:1375,y:829,t:1527272167001};\\\", \\\"{x:1375,y:825,t:1527272167018};\\\", \\\"{x:1375,y:823,t:1527272167034};\\\", \\\"{x:1375,y:817,t:1527272167051};\\\", \\\"{x:1375,y:814,t:1527272167068};\\\", \\\"{x:1374,y:811,t:1527272167085};\\\", \\\"{x:1374,y:809,t:1527272167101};\\\", \\\"{x:1373,y:807,t:1527272167118};\\\", \\\"{x:1373,y:806,t:1527272167135};\\\", \\\"{x:1373,y:803,t:1527272167152};\\\", \\\"{x:1373,y:801,t:1527272167234};\\\", \\\"{x:1370,y:796,t:1527272167251};\\\", \\\"{x:1368,y:794,t:1527272167268};\\\", \\\"{x:1368,y:793,t:1527272167290};\\\", \\\"{x:1367,y:791,t:1527272167306};\\\", \\\"{x:1367,y:790,t:1527272167318};\\\", \\\"{x:1365,y:785,t:1527272167335};\\\", \\\"{x:1362,y:782,t:1527272167352};\\\", \\\"{x:1360,y:776,t:1527272167368};\\\", \\\"{x:1359,y:770,t:1527272167385};\\\", \\\"{x:1357,y:768,t:1527272167402};\\\", \\\"{x:1357,y:767,t:1527272167419};\\\", \\\"{x:1356,y:763,t:1527272167435};\\\", \\\"{x:1356,y:759,t:1527272167452};\\\", \\\"{x:1356,y:752,t:1527272167468};\\\", \\\"{x:1355,y:746,t:1527272167485};\\\", \\\"{x:1351,y:735,t:1527272167502};\\\", \\\"{x:1343,y:722,t:1527272167518};\\\", \\\"{x:1340,y:716,t:1527272167536};\\\", \\\"{x:1339,y:712,t:1527272167552};\\\", \\\"{x:1338,y:711,t:1527272167571};\\\", \\\"{x:1338,y:710,t:1527272167585};\\\", \\\"{x:1338,y:706,t:1527272167601};\\\", \\\"{x:1338,y:703,t:1527272167618};\\\", \\\"{x:1337,y:701,t:1527272167635};\\\", \\\"{x:1337,y:699,t:1527272167652};\\\", \\\"{x:1335,y:699,t:1527272167674};\\\", \\\"{x:1330,y:699,t:1527272167685};\\\", \\\"{x:1304,y:699,t:1527272167702};\\\", \\\"{x:1265,y:699,t:1527272167719};\\\", \\\"{x:1209,y:699,t:1527272167736};\\\", \\\"{x:1145,y:699,t:1527272167752};\\\", \\\"{x:1070,y:699,t:1527272167769};\\\", \\\"{x:1009,y:699,t:1527272167785};\\\", \\\"{x:936,y:699,t:1527272167802};\\\", \\\"{x:897,y:699,t:1527272167818};\\\", \\\"{x:851,y:697,t:1527272167835};\\\", \\\"{x:793,y:689,t:1527272167852};\\\", \\\"{x:737,y:682,t:1527272167869};\\\", \\\"{x:701,y:679,t:1527272167884};\\\", \\\"{x:679,y:672,t:1527272167902};\\\", \\\"{x:663,y:663,t:1527272167919};\\\", \\\"{x:641,y:650,t:1527272167935};\\\", \\\"{x:616,y:633,t:1527272167952};\\\", \\\"{x:574,y:591,t:1527272167971};\\\", \\\"{x:562,y:576,t:1527272167985};\\\", \\\"{x:549,y:547,t:1527272168002};\\\", \\\"{x:549,y:544,t:1527272168016};\\\", \\\"{x:549,y:538,t:1527272168033};\\\", \\\"{x:549,y:529,t:1527272168051};\\\", \\\"{x:550,y:524,t:1527272168067};\\\", \\\"{x:552,y:517,t:1527272168084};\\\", \\\"{x:552,y:515,t:1527272168101};\\\", \\\"{x:553,y:514,t:1527272168118};\\\", \\\"{x:554,y:513,t:1527272168134};\\\", \\\"{x:557,y:512,t:1527272168151};\\\", \\\"{x:563,y:509,t:1527272168168};\\\", \\\"{x:575,y:504,t:1527272168184};\\\", \\\"{x:586,y:499,t:1527272168201};\\\", \\\"{x:592,y:497,t:1527272168218};\\\", \\\"{x:593,y:496,t:1527272168235};\\\", \\\"{x:595,y:496,t:1527272168298};\\\", \\\"{x:596,y:496,t:1527272168314};\\\", \\\"{x:599,y:496,t:1527272168321};\\\", \\\"{x:603,y:497,t:1527272168336};\\\", \\\"{x:606,y:501,t:1527272168351};\\\", \\\"{x:606,y:505,t:1527272168367};\\\", \\\"{x:608,y:517,t:1527272168384};\\\", \\\"{x:615,y:530,t:1527272168401};\\\", \\\"{x:631,y:553,t:1527272168418};\\\", \\\"{x:643,y:560,t:1527272168435};\\\", \\\"{x:668,y:562,t:1527272168452};\\\", \\\"{x:756,y:559,t:1527272168469};\\\", \\\"{x:899,y:542,t:1527272168486};\\\", \\\"{x:1017,y:515,t:1527272168502};\\\", \\\"{x:1060,y:495,t:1527272168518};\\\", \\\"{x:1067,y:484,t:1527272168536};\\\", \\\"{x:1067,y:475,t:1527272168552};\\\", \\\"{x:1047,y:466,t:1527272168568};\\\", \\\"{x:985,y:459,t:1527272168585};\\\", \\\"{x:951,y:459,t:1527272168601};\\\", \\\"{x:923,y:459,t:1527272168619};\\\", \\\"{x:894,y:460,t:1527272168636};\\\", \\\"{x:872,y:465,t:1527272168652};\\\", \\\"{x:854,y:467,t:1527272168668};\\\", \\\"{x:846,y:469,t:1527272168686};\\\", \\\"{x:844,y:471,t:1527272168701};\\\", \\\"{x:842,y:472,t:1527272168719};\\\", \\\"{x:842,y:473,t:1527272168736};\\\", \\\"{x:842,y:477,t:1527272168752};\\\", \\\"{x:840,y:484,t:1527272168769};\\\", \\\"{x:840,y:494,t:1527272168787};\\\", \\\"{x:840,y:500,t:1527272168802};\\\", \\\"{x:841,y:506,t:1527272168818};\\\", \\\"{x:841,y:508,t:1527272168835};\\\", \\\"{x:841,y:509,t:1527272168913};\\\", \\\"{x:841,y:510,t:1527272168921};\\\", \\\"{x:840,y:510,t:1527272168936};\\\", \\\"{x:839,y:511,t:1527272168952};\\\", \\\"{x:834,y:513,t:1527272169345};\\\", \\\"{x:821,y:513,t:1527272169353};\\\", \\\"{x:800,y:514,t:1527272169368};\\\", \\\"{x:683,y:516,t:1527272169386};\\\", \\\"{x:590,y:524,t:1527272169403};\\\", \\\"{x:510,y:533,t:1527272169420};\\\", \\\"{x:442,y:535,t:1527272169436};\\\", \\\"{x:441,y:534,t:1527272169457};\\\", \\\"{x:440,y:534,t:1527272169469};\\\", \\\"{x:438,y:534,t:1527272169505};\\\", \\\"{x:437,y:534,t:1527272169522};\\\", \\\"{x:435,y:535,t:1527272169536};\\\", \\\"{x:433,y:535,t:1527272170283};\\\", \\\"{x:426,y:537,t:1527272170289};\\\", \\\"{x:422,y:537,t:1527272170305};\\\", \\\"{x:409,y:533,t:1527272170322};\\\", \\\"{x:405,y:532,t:1527272170338};\\\", \\\"{x:402,y:532,t:1527272170351};\\\", \\\"{x:383,y:529,t:1527272170369};\\\", \\\"{x:363,y:527,t:1527272170386};\\\", \\\"{x:340,y:524,t:1527272170402};\\\", \\\"{x:318,y:523,t:1527272170420};\\\", \\\"{x:298,y:523,t:1527272170437};\\\", \\\"{x:280,y:523,t:1527272170454};\\\", \\\"{x:270,y:523,t:1527272170469};\\\", \\\"{x:256,y:524,t:1527272170487};\\\", \\\"{x:241,y:526,t:1527272170504};\\\", \\\"{x:228,y:529,t:1527272170519};\\\", \\\"{x:217,y:532,t:1527272170536};\\\", \\\"{x:212,y:534,t:1527272170553};\\\", \\\"{x:210,y:535,t:1527272170571};\\\", \\\"{x:208,y:536,t:1527272170587};\\\", \\\"{x:208,y:537,t:1527272170603};\\\", \\\"{x:205,y:538,t:1527272170620};\\\", \\\"{x:201,y:541,t:1527272170636};\\\", \\\"{x:190,y:545,t:1527272170654};\\\", \\\"{x:179,y:549,t:1527272170671};\\\", \\\"{x:173,y:550,t:1527272170687};\\\", \\\"{x:170,y:551,t:1527272170704};\\\", \\\"{x:169,y:551,t:1527272170779};\\\", \\\"{x:168,y:551,t:1527272170793};\\\", \\\"{x:167,y:551,t:1527272170810};\\\", \\\"{x:165,y:550,t:1527272170826};\\\", \\\"{x:165,y:549,t:1527272170837};\\\", \\\"{x:164,y:549,t:1527272170854};\\\", \\\"{x:164,y:547,t:1527272170870};\\\", \\\"{x:164,y:546,t:1527272170887};\\\", \\\"{x:163,y:545,t:1527272170906};\\\", \\\"{x:163,y:544,t:1527272170920};\\\", \\\"{x:162,y:544,t:1527272171121};\\\", \\\"{x:161,y:544,t:1527272171136};\\\", \\\"{x:160,y:552,t:1527272171154};\\\", \\\"{x:167,y:580,t:1527272171171};\\\", \\\"{x:198,y:635,t:1527272171188};\\\", \\\"{x:244,y:704,t:1527272171203};\\\", \\\"{x:282,y:740,t:1527272171221};\\\", \\\"{x:308,y:758,t:1527272171238};\\\", \\\"{x:329,y:766,t:1527272171254};\\\", \\\"{x:352,y:772,t:1527272171271};\\\", \\\"{x:379,y:778,t:1527272171288};\\\", \\\"{x:407,y:782,t:1527272171303};\\\", \\\"{x:431,y:782,t:1527272171321};\\\", \\\"{x:464,y:782,t:1527272171337};\\\", \\\"{x:478,y:782,t:1527272171354};\\\", \\\"{x:480,y:782,t:1527272171371};\\\", \\\"{x:481,y:782,t:1527272171393};\\\", \\\"{x:482,y:776,t:1527272171404};\\\", \\\"{x:482,y:763,t:1527272171421};\\\", \\\"{x:483,y:758,t:1527272171438};\\\", \\\"{x:484,y:755,t:1527272171455};\\\", \\\"{x:484,y:754,t:1527272171472};\\\", \\\"{x:484,y:753,t:1527272171489};\\\", \\\"{x:484,y:752,t:1527272171504};\\\", \\\"{x:484,y:751,t:1527272171521};\\\", \\\"{x:486,y:750,t:1527272171538};\\\", \\\"{x:489,y:747,t:1527272171554};\\\", \\\"{x:490,y:745,t:1527272171570};\\\", \\\"{x:491,y:741,t:1527272171588};\\\", \\\"{x:493,y:739,t:1527272171604};\\\", \\\"{x:494,y:738,t:1527272171625};\\\", \\\"{x:495,y:738,t:1527272171641};\\\", \\\"{x:496,y:738,t:1527272171654};\\\" ] }, { \\\"rt\\\": 15915, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 605357, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -I -E -F -F -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:733,t:1527272173938};\\\", \\\"{x:501,y:726,t:1527272173945};\\\", \\\"{x:501,y:719,t:1527272173960};\\\", \\\"{x:505,y:706,t:1527272173975};\\\", \\\"{x:516,y:691,t:1527272173990};\\\", \\\"{x:526,y:679,t:1527272174007};\\\", \\\"{x:532,y:666,t:1527272174023};\\\", \\\"{x:537,y:651,t:1527272174040};\\\", \\\"{x:537,y:631,t:1527272174057};\\\", \\\"{x:542,y:618,t:1527272174072};\\\", \\\"{x:544,y:604,t:1527272174089};\\\", \\\"{x:547,y:594,t:1527272174106};\\\", \\\"{x:554,y:582,t:1527272174124};\\\", \\\"{x:558,y:572,t:1527272174139};\\\", \\\"{x:563,y:564,t:1527272174156};\\\", \\\"{x:567,y:559,t:1527272174174};\\\", \\\"{x:573,y:552,t:1527272174190};\\\", \\\"{x:576,y:550,t:1527272174206};\\\", \\\"{x:581,y:546,t:1527272174222};\\\", \\\"{x:595,y:538,t:1527272174239};\\\", \\\"{x:628,y:527,t:1527272174257};\\\", \\\"{x:648,y:522,t:1527272174274};\\\", \\\"{x:728,y:517,t:1527272174290};\\\", \\\"{x:819,y:517,t:1527272174307};\\\", \\\"{x:917,y:517,t:1527272174324};\\\", \\\"{x:1014,y:517,t:1527272174341};\\\", \\\"{x:1133,y:517,t:1527272174357};\\\", \\\"{x:1246,y:517,t:1527272174373};\\\", \\\"{x:1376,y:517,t:1527272174390};\\\", \\\"{x:1487,y:532,t:1527272174407};\\\", \\\"{x:1586,y:546,t:1527272174425};\\\", \\\"{x:1603,y:550,t:1527272174440};\\\", \\\"{x:1618,y:554,t:1527272174458};\\\", \\\"{x:1618,y:557,t:1527272174522};\\\", \\\"{x:1617,y:558,t:1527272174530};\\\", \\\"{x:1616,y:562,t:1527272174541};\\\", \\\"{x:1611,y:567,t:1527272174558};\\\", \\\"{x:1605,y:573,t:1527272174576};\\\", \\\"{x:1601,y:577,t:1527272174591};\\\", \\\"{x:1594,y:581,t:1527272174607};\\\", \\\"{x:1583,y:588,t:1527272174626};\\\", \\\"{x:1575,y:591,t:1527272174643};\\\", \\\"{x:1561,y:597,t:1527272174657};\\\", \\\"{x:1544,y:603,t:1527272174673};\\\", \\\"{x:1527,y:608,t:1527272174691};\\\", \\\"{x:1513,y:613,t:1527272174707};\\\", \\\"{x:1493,y:619,t:1527272174724};\\\", \\\"{x:1473,y:623,t:1527272174740};\\\", \\\"{x:1452,y:628,t:1527272174758};\\\", \\\"{x:1437,y:630,t:1527272174774};\\\", \\\"{x:1422,y:631,t:1527272174791};\\\", \\\"{x:1407,y:635,t:1527272174807};\\\", \\\"{x:1391,y:635,t:1527272174825};\\\", \\\"{x:1377,y:635,t:1527272174841};\\\", \\\"{x:1366,y:634,t:1527272174857};\\\", \\\"{x:1360,y:633,t:1527272174874};\\\", \\\"{x:1359,y:633,t:1527272174898};\\\", \\\"{x:1358,y:632,t:1527272175049};\\\", \\\"{x:1357,y:630,t:1527272175153};\\\", \\\"{x:1355,y:629,t:1527272175170};\\\", \\\"{x:1355,y:627,t:1527272175186};\\\", \\\"{x:1354,y:627,t:1527272175193};\\\", \\\"{x:1354,y:626,t:1527272175209};\\\", \\\"{x:1352,y:623,t:1527272175225};\\\", \\\"{x:1350,y:623,t:1527272176490};\\\", \\\"{x:1347,y:623,t:1527272176498};\\\", \\\"{x:1345,y:629,t:1527272176511};\\\", \\\"{x:1339,y:641,t:1527272176527};\\\", \\\"{x:1333,y:655,t:1527272176545};\\\", \\\"{x:1326,y:670,t:1527272176560};\\\", \\\"{x:1321,y:689,t:1527272176578};\\\", \\\"{x:1321,y:700,t:1527272176594};\\\", \\\"{x:1320,y:712,t:1527272176611};\\\", \\\"{x:1320,y:724,t:1527272176628};\\\", \\\"{x:1320,y:736,t:1527272176645};\\\", \\\"{x:1320,y:747,t:1527272176660};\\\", \\\"{x:1320,y:758,t:1527272176677};\\\", \\\"{x:1320,y:771,t:1527272176695};\\\", \\\"{x:1321,y:786,t:1527272176711};\\\", \\\"{x:1325,y:804,t:1527272176727};\\\", \\\"{x:1328,y:815,t:1527272176745};\\\", \\\"{x:1333,y:827,t:1527272176762};\\\", \\\"{x:1340,y:837,t:1527272176778};\\\", \\\"{x:1349,y:843,t:1527272176794};\\\", \\\"{x:1358,y:844,t:1527272176812};\\\", \\\"{x:1366,y:844,t:1527272176827};\\\", \\\"{x:1381,y:842,t:1527272176845};\\\", \\\"{x:1400,y:834,t:1527272176862};\\\", \\\"{x:1413,y:829,t:1527272176879};\\\", \\\"{x:1417,y:826,t:1527272176894};\\\", \\\"{x:1418,y:823,t:1527272176911};\\\", \\\"{x:1418,y:815,t:1527272176929};\\\", \\\"{x:1406,y:796,t:1527272176944};\\\", \\\"{x:1367,y:754,t:1527272176962};\\\", \\\"{x:1336,y:732,t:1527272176978};\\\", \\\"{x:1310,y:718,t:1527272176995};\\\", \\\"{x:1288,y:709,t:1527272177011};\\\", \\\"{x:1266,y:702,t:1527272177029};\\\", \\\"{x:1237,y:695,t:1527272177044};\\\", \\\"{x:1216,y:690,t:1527272177062};\\\", \\\"{x:1209,y:690,t:1527272177079};\\\", \\\"{x:1207,y:690,t:1527272177095};\\\", \\\"{x:1205,y:690,t:1527272177111};\\\", \\\"{x:1200,y:691,t:1527272177128};\\\", \\\"{x:1195,y:701,t:1527272177146};\\\", \\\"{x:1186,y:721,t:1527272177162};\\\", \\\"{x:1180,y:742,t:1527272177179};\\\", \\\"{x:1176,y:760,t:1527272177196};\\\", \\\"{x:1176,y:773,t:1527272177212};\\\", \\\"{x:1176,y:789,t:1527272177228};\\\", \\\"{x:1179,y:806,t:1527272177245};\\\", \\\"{x:1188,y:818,t:1527272177262};\\\", \\\"{x:1205,y:827,t:1527272177278};\\\", \\\"{x:1221,y:829,t:1527272177295};\\\", \\\"{x:1246,y:834,t:1527272177312};\\\", \\\"{x:1273,y:837,t:1527272177329};\\\", \\\"{x:1308,y:837,t:1527272177346};\\\", \\\"{x:1328,y:833,t:1527272177362};\\\", \\\"{x:1350,y:824,t:1527272177379};\\\", \\\"{x:1370,y:814,t:1527272177396};\\\", \\\"{x:1393,y:801,t:1527272177412};\\\", \\\"{x:1417,y:787,t:1527272177429};\\\", \\\"{x:1436,y:773,t:1527272177446};\\\", \\\"{x:1455,y:756,t:1527272177463};\\\", \\\"{x:1467,y:740,t:1527272177480};\\\", \\\"{x:1478,y:721,t:1527272177496};\\\", \\\"{x:1486,y:703,t:1527272177513};\\\", \\\"{x:1495,y:671,t:1527272177530};\\\", \\\"{x:1496,y:638,t:1527272177545};\\\", \\\"{x:1502,y:599,t:1527272177562};\\\", \\\"{x:1501,y:560,t:1527272177580};\\\", \\\"{x:1495,y:531,t:1527272177596};\\\", \\\"{x:1486,y:507,t:1527272177613};\\\", \\\"{x:1469,y:482,t:1527272177630};\\\", \\\"{x:1458,y:469,t:1527272177645};\\\", \\\"{x:1451,y:465,t:1527272177663};\\\", \\\"{x:1447,y:463,t:1527272177679};\\\", \\\"{x:1439,y:460,t:1527272177697};\\\", \\\"{x:1435,y:460,t:1527272177713};\\\", \\\"{x:1421,y:460,t:1527272177730};\\\", \\\"{x:1405,y:468,t:1527272177746};\\\", \\\"{x:1384,y:482,t:1527272177763};\\\", \\\"{x:1359,y:501,t:1527272177779};\\\", \\\"{x:1336,y:517,t:1527272177797};\\\", \\\"{x:1312,y:534,t:1527272177812};\\\", \\\"{x:1294,y:549,t:1527272177829};\\\", \\\"{x:1277,y:567,t:1527272177847};\\\", \\\"{x:1265,y:580,t:1527272177863};\\\", \\\"{x:1258,y:591,t:1527272177879};\\\", \\\"{x:1254,y:602,t:1527272177896};\\\", \\\"{x:1251,y:619,t:1527272177912};\\\", \\\"{x:1249,y:632,t:1527272177928};\\\", \\\"{x:1247,y:646,t:1527272177946};\\\", \\\"{x:1247,y:659,t:1527272177963};\\\", \\\"{x:1247,y:678,t:1527272177979};\\\", \\\"{x:1251,y:696,t:1527272177996};\\\", \\\"{x:1261,y:716,t:1527272178014};\\\", \\\"{x:1271,y:734,t:1527272178029};\\\", \\\"{x:1278,y:745,t:1527272178046};\\\", \\\"{x:1290,y:756,t:1527272178063};\\\", \\\"{x:1308,y:770,t:1527272178080};\\\", \\\"{x:1322,y:778,t:1527272178096};\\\", \\\"{x:1344,y:792,t:1527272178114};\\\", \\\"{x:1356,y:799,t:1527272178130};\\\", \\\"{x:1370,y:807,t:1527272178146};\\\", \\\"{x:1386,y:815,t:1527272178163};\\\", \\\"{x:1398,y:821,t:1527272178180};\\\", \\\"{x:1409,y:825,t:1527272178197};\\\", \\\"{x:1416,y:827,t:1527272178213};\\\", \\\"{x:1421,y:827,t:1527272178230};\\\", \\\"{x:1423,y:827,t:1527272178247};\\\", \\\"{x:1424,y:827,t:1527272178262};\\\", \\\"{x:1425,y:827,t:1527272178280};\\\", \\\"{x:1428,y:827,t:1527272178297};\\\", \\\"{x:1430,y:827,t:1527272178321};\\\", \\\"{x:1430,y:826,t:1527272178330};\\\", \\\"{x:1430,y:824,t:1527272178347};\\\", \\\"{x:1430,y:814,t:1527272178363};\\\", \\\"{x:1428,y:800,t:1527272178380};\\\", \\\"{x:1424,y:793,t:1527272178397};\\\", \\\"{x:1423,y:792,t:1527272178413};\\\", \\\"{x:1423,y:790,t:1527272178433};\\\", \\\"{x:1422,y:789,t:1527272178447};\\\", \\\"{x:1421,y:787,t:1527272178463};\\\", \\\"{x:1419,y:784,t:1527272178480};\\\", \\\"{x:1413,y:775,t:1527272178498};\\\", \\\"{x:1406,y:767,t:1527272178514};\\\", \\\"{x:1402,y:759,t:1527272178531};\\\", \\\"{x:1397,y:752,t:1527272178547};\\\", \\\"{x:1397,y:749,t:1527272178564};\\\", \\\"{x:1395,y:747,t:1527272178580};\\\", \\\"{x:1393,y:744,t:1527272178598};\\\", \\\"{x:1389,y:738,t:1527272178614};\\\", \\\"{x:1380,y:727,t:1527272178630};\\\", \\\"{x:1370,y:715,t:1527272178648};\\\", \\\"{x:1357,y:704,t:1527272178664};\\\", \\\"{x:1355,y:703,t:1527272178681};\\\", \\\"{x:1354,y:703,t:1527272178698};\\\", \\\"{x:1352,y:703,t:1527272178946};\\\", \\\"{x:1348,y:702,t:1527272178954};\\\", \\\"{x:1345,y:699,t:1527272178964};\\\", \\\"{x:1335,y:696,t:1527272178983};\\\", \\\"{x:1326,y:693,t:1527272178999};\\\", \\\"{x:1322,y:691,t:1527272179014};\\\", \\\"{x:1321,y:691,t:1527272179031};\\\", \\\"{x:1320,y:691,t:1527272179274};\\\", \\\"{x:1320,y:690,t:1527272179290};\\\", \\\"{x:1320,y:689,t:1527272179299};\\\", \\\"{x:1321,y:689,t:1527272179316};\\\", \\\"{x:1322,y:688,t:1527272179418};\\\", \\\"{x:1323,y:697,t:1527272180274};\\\", \\\"{x:1327,y:707,t:1527272180284};\\\", \\\"{x:1328,y:722,t:1527272180301};\\\", \\\"{x:1328,y:730,t:1527272180318};\\\", \\\"{x:1328,y:735,t:1527272180334};\\\", \\\"{x:1328,y:738,t:1527272180351};\\\", \\\"{x:1328,y:741,t:1527272180368};\\\", \\\"{x:1328,y:747,t:1527272180384};\\\", \\\"{x:1327,y:756,t:1527272180401};\\\", \\\"{x:1316,y:773,t:1527272180418};\\\", \\\"{x:1303,y:783,t:1527272180434};\\\", \\\"{x:1285,y:788,t:1527272180450};\\\", \\\"{x:1256,y:788,t:1527272180467};\\\", \\\"{x:1186,y:785,t:1527272180484};\\\", \\\"{x:1094,y:760,t:1527272180501};\\\", \\\"{x:987,y:734,t:1527272180517};\\\", \\\"{x:887,y:706,t:1527272180534};\\\", \\\"{x:828,y:684,t:1527272180551};\\\", \\\"{x:793,y:666,t:1527272180568};\\\", \\\"{x:781,y:658,t:1527272180584};\\\", \\\"{x:775,y:654,t:1527272180600};\\\", \\\"{x:763,y:644,t:1527272180618};\\\", \\\"{x:759,y:640,t:1527272180634};\\\", \\\"{x:750,y:629,t:1527272180651};\\\", \\\"{x:733,y:615,t:1527272180667};\\\", \\\"{x:705,y:601,t:1527272180684};\\\", \\\"{x:691,y:596,t:1527272180695};\\\", \\\"{x:670,y:589,t:1527272180712};\\\", \\\"{x:660,y:586,t:1527272180728};\\\", \\\"{x:658,y:585,t:1527272180745};\\\", \\\"{x:657,y:584,t:1527272180776};\\\", \\\"{x:657,y:583,t:1527272180785};\\\", \\\"{x:651,y:577,t:1527272180795};\\\", \\\"{x:637,y:565,t:1527272180812};\\\", \\\"{x:617,y:553,t:1527272180829};\\\", \\\"{x:608,y:549,t:1527272180846};\\\", \\\"{x:607,y:549,t:1527272180861};\\\", \\\"{x:610,y:547,t:1527272180897};\\\", \\\"{x:618,y:544,t:1527272180911};\\\", \\\"{x:636,y:539,t:1527272180929};\\\", \\\"{x:658,y:539,t:1527272180945};\\\", \\\"{x:697,y:539,t:1527272180961};\\\", \\\"{x:737,y:539,t:1527272180979};\\\", \\\"{x:764,y:539,t:1527272180995};\\\", \\\"{x:786,y:536,t:1527272181012};\\\", \\\"{x:796,y:536,t:1527272181029};\\\", \\\"{x:803,y:536,t:1527272181045};\\\", \\\"{x:814,y:534,t:1527272181062};\\\", \\\"{x:827,y:532,t:1527272181080};\\\", \\\"{x:837,y:530,t:1527272181095};\\\", \\\"{x:844,y:527,t:1527272181113};\\\", \\\"{x:845,y:527,t:1527272181128};\\\", \\\"{x:844,y:526,t:1527272181226};\\\", \\\"{x:840,y:525,t:1527272181233};\\\", \\\"{x:837,y:523,t:1527272181246};\\\", \\\"{x:831,y:522,t:1527272181262};\\\", \\\"{x:826,y:522,t:1527272181279};\\\", \\\"{x:824,y:522,t:1527272181295};\\\", \\\"{x:822,y:522,t:1527272181329};\\\", \\\"{x:820,y:522,t:1527272181345};\\\", \\\"{x:818,y:522,t:1527272181362};\\\", \\\"{x:816,y:522,t:1527272181380};\\\", \\\"{x:815,y:520,t:1527272181442};\\\", \\\"{x:816,y:518,t:1527272181450};\\\", \\\"{x:825,y:515,t:1527272181464};\\\", \\\"{x:841,y:509,t:1527272181479};\\\", \\\"{x:854,y:502,t:1527272181495};\\\", \\\"{x:860,y:500,t:1527272181512};\\\", \\\"{x:860,y:499,t:1527272181529};\\\", \\\"{x:860,y:498,t:1527272181561};\\\", \\\"{x:856,y:496,t:1527272181568};\\\", \\\"{x:851,y:495,t:1527272181579};\\\", \\\"{x:843,y:491,t:1527272181596};\\\", \\\"{x:836,y:490,t:1527272181612};\\\", \\\"{x:831,y:491,t:1527272181629};\\\", \\\"{x:826,y:492,t:1527272181646};\\\", \\\"{x:814,y:496,t:1527272181663};\\\", \\\"{x:797,y:502,t:1527272181679};\\\", \\\"{x:776,y:510,t:1527272181695};\\\", \\\"{x:748,y:515,t:1527272181713};\\\", \\\"{x:706,y:526,t:1527272181730};\\\", \\\"{x:681,y:530,t:1527272181745};\\\", \\\"{x:649,y:533,t:1527272181762};\\\", \\\"{x:616,y:533,t:1527272181780};\\\", \\\"{x:576,y:533,t:1527272181796};\\\", \\\"{x:537,y:533,t:1527272181812};\\\", \\\"{x:501,y:533,t:1527272181829};\\\", \\\"{x:470,y:533,t:1527272181848};\\\", \\\"{x:446,y:533,t:1527272181863};\\\", \\\"{x:428,y:533,t:1527272181879};\\\", \\\"{x:414,y:533,t:1527272181896};\\\", \\\"{x:392,y:529,t:1527272181912};\\\", \\\"{x:371,y:521,t:1527272181930};\\\", \\\"{x:351,y:511,t:1527272181946};\\\", \\\"{x:337,y:502,t:1527272181962};\\\", \\\"{x:332,y:497,t:1527272181979};\\\", \\\"{x:328,y:488,t:1527272181996};\\\", \\\"{x:325,y:480,t:1527272182012};\\\", \\\"{x:319,y:471,t:1527272182029};\\\", \\\"{x:315,y:466,t:1527272182046};\\\", \\\"{x:311,y:463,t:1527272182063};\\\", \\\"{x:308,y:462,t:1527272182079};\\\", \\\"{x:306,y:462,t:1527272182096};\\\", \\\"{x:305,y:462,t:1527272182113};\\\", \\\"{x:303,y:462,t:1527272182129};\\\", \\\"{x:298,y:463,t:1527272182146};\\\", \\\"{x:288,y:468,t:1527272182163};\\\", \\\"{x:278,y:474,t:1527272182180};\\\", \\\"{x:271,y:478,t:1527272182196};\\\", \\\"{x:264,y:483,t:1527272182213};\\\", \\\"{x:260,y:488,t:1527272182231};\\\", \\\"{x:258,y:492,t:1527272182246};\\\", \\\"{x:257,y:497,t:1527272182263};\\\", \\\"{x:254,y:502,t:1527272182279};\\\", \\\"{x:253,y:507,t:1527272182296};\\\", \\\"{x:253,y:515,t:1527272182312};\\\", \\\"{x:252,y:518,t:1527272182330};\\\", \\\"{x:252,y:524,t:1527272182346};\\\", \\\"{x:252,y:534,t:1527272182364};\\\", \\\"{x:260,y:546,t:1527272182380};\\\", \\\"{x:270,y:558,t:1527272182397};\\\", \\\"{x:278,y:563,t:1527272182414};\\\", \\\"{x:285,y:567,t:1527272182430};\\\", \\\"{x:297,y:573,t:1527272182446};\\\", \\\"{x:313,y:583,t:1527272182463};\\\", \\\"{x:333,y:591,t:1527272182480};\\\", \\\"{x:369,y:603,t:1527272182498};\\\", \\\"{x:420,y:617,t:1527272182513};\\\", \\\"{x:444,y:623,t:1527272182530};\\\", \\\"{x:466,y:626,t:1527272182547};\\\", \\\"{x:485,y:632,t:1527272182564};\\\", \\\"{x:514,y:636,t:1527272182580};\\\", \\\"{x:540,y:640,t:1527272182596};\\\", \\\"{x:563,y:640,t:1527272182613};\\\", \\\"{x:584,y:640,t:1527272182630};\\\", \\\"{x:601,y:632,t:1527272182646};\\\", \\\"{x:609,y:627,t:1527272182664};\\\", \\\"{x:616,y:619,t:1527272182680};\\\", \\\"{x:619,y:611,t:1527272182696};\\\", \\\"{x:621,y:602,t:1527272182714};\\\", \\\"{x:621,y:599,t:1527272182730};\\\", \\\"{x:621,y:597,t:1527272182748};\\\", \\\"{x:622,y:595,t:1527272182763};\\\", \\\"{x:622,y:593,t:1527272182781};\\\", \\\"{x:622,y:592,t:1527272182796};\\\", \\\"{x:622,y:591,t:1527272182817};\\\", \\\"{x:623,y:590,t:1527272182830};\\\", \\\"{x:623,y:589,t:1527272182970};\\\", \\\"{x:623,y:588,t:1527272182981};\\\", \\\"{x:629,y:585,t:1527272182998};\\\", \\\"{x:635,y:582,t:1527272183014};\\\", \\\"{x:641,y:580,t:1527272183030};\\\", \\\"{x:646,y:577,t:1527272183048};\\\", \\\"{x:649,y:575,t:1527272183063};\\\", \\\"{x:653,y:572,t:1527272183080};\\\", \\\"{x:659,y:567,t:1527272183098};\\\", \\\"{x:662,y:563,t:1527272183113};\\\", \\\"{x:666,y:559,t:1527272183132};\\\", \\\"{x:670,y:554,t:1527272183148};\\\", \\\"{x:673,y:549,t:1527272183164};\\\", \\\"{x:674,y:546,t:1527272183180};\\\", \\\"{x:674,y:539,t:1527272183197};\\\", \\\"{x:674,y:535,t:1527272183214};\\\", \\\"{x:669,y:529,t:1527272183230};\\\", \\\"{x:657,y:522,t:1527272183248};\\\", \\\"{x:643,y:519,t:1527272183264};\\\", \\\"{x:627,y:516,t:1527272183280};\\\", \\\"{x:606,y:516,t:1527272183294};\\\", \\\"{x:591,y:519,t:1527272183311};\\\", \\\"{x:571,y:524,t:1527272183327};\\\", \\\"{x:550,y:530,t:1527272183345};\\\", \\\"{x:526,y:540,t:1527272183361};\\\", \\\"{x:510,y:550,t:1527272183377};\\\", \\\"{x:499,y:557,t:1527272183395};\\\", \\\"{x:486,y:566,t:1527272183412};\\\", \\\"{x:484,y:569,t:1527272183427};\\\", \\\"{x:480,y:573,t:1527272183445};\\\", \\\"{x:477,y:577,t:1527272183461};\\\", \\\"{x:477,y:586,t:1527272183478};\\\", \\\"{x:478,y:611,t:1527272183496};\\\", \\\"{x:483,y:624,t:1527272183511};\\\", \\\"{x:487,y:630,t:1527272183527};\\\", \\\"{x:495,y:638,t:1527272183544};\\\", \\\"{x:501,y:642,t:1527272183561};\\\", \\\"{x:509,y:645,t:1527272183578};\\\", \\\"{x:514,y:647,t:1527272183595};\\\", \\\"{x:505,y:645,t:1527272183654};\\\", \\\"{x:494,y:641,t:1527272183663};\\\", \\\"{x:477,y:634,t:1527272183679};\\\", \\\"{x:403,y:607,t:1527272183695};\\\", \\\"{x:342,y:590,t:1527272183712};\\\", \\\"{x:299,y:577,t:1527272183728};\\\", \\\"{x:281,y:575,t:1527272183744};\\\", \\\"{x:278,y:574,t:1527272183762};\\\", \\\"{x:277,y:571,t:1527272183855};\\\", \\\"{x:274,y:563,t:1527272183862};\\\", \\\"{x:268,y:549,t:1527272183880};\\\", \\\"{x:257,y:535,t:1527272183895};\\\", \\\"{x:246,y:526,t:1527272183912};\\\", \\\"{x:232,y:521,t:1527272183929};\\\", \\\"{x:220,y:519,t:1527272183945};\\\", \\\"{x:203,y:519,t:1527272183962};\\\", \\\"{x:192,y:519,t:1527272183979};\\\", \\\"{x:184,y:521,t:1527272183994};\\\", \\\"{x:178,y:527,t:1527272184012};\\\", \\\"{x:174,y:532,t:1527272184029};\\\", \\\"{x:171,y:540,t:1527272184044};\\\", \\\"{x:168,y:544,t:1527272184061};\\\", \\\"{x:167,y:547,t:1527272184079};\\\", \\\"{x:166,y:548,t:1527272184094};\\\", \\\"{x:166,y:547,t:1527272184224};\\\", \\\"{x:163,y:541,t:1527272184231};\\\", \\\"{x:162,y:535,t:1527272184246};\\\", \\\"{x:159,y:529,t:1527272184262};\\\", \\\"{x:159,y:526,t:1527272184279};\\\", \\\"{x:158,y:526,t:1527272184767};\\\", \\\"{x:156,y:527,t:1527272184783};\\\", \\\"{x:156,y:528,t:1527272184797};\\\", \\\"{x:156,y:531,t:1527272184813};\\\", \\\"{x:154,y:532,t:1527272184829};\\\", \\\"{x:153,y:533,t:1527272184846};\\\", \\\"{x:153,y:535,t:1527272185215};\\\", \\\"{x:155,y:536,t:1527272185230};\\\", \\\"{x:162,y:540,t:1527272185246};\\\", \\\"{x:172,y:545,t:1527272185263};\\\", \\\"{x:185,y:554,t:1527272185281};\\\", \\\"{x:211,y:564,t:1527272185297};\\\", \\\"{x:266,y:586,t:1527272185312};\\\", \\\"{x:345,y:604,t:1527272185330};\\\", \\\"{x:443,y:618,t:1527272185346};\\\", \\\"{x:572,y:632,t:1527272185363};\\\", \\\"{x:724,y:650,t:1527272185380};\\\", \\\"{x:871,y:654,t:1527272185396};\\\", \\\"{x:1010,y:656,t:1527272185413};\\\", \\\"{x:1145,y:656,t:1527272185430};\\\", \\\"{x:1298,y:656,t:1527272185447};\\\", \\\"{x:1362,y:656,t:1527272185463};\\\", \\\"{x:1418,y:656,t:1527272185480};\\\", \\\"{x:1446,y:656,t:1527272185498};\\\", \\\"{x:1460,y:656,t:1527272185514};\\\", \\\"{x:1471,y:656,t:1527272185530};\\\", \\\"{x:1479,y:656,t:1527272185547};\\\", \\\"{x:1482,y:656,t:1527272185563};\\\", \\\"{x:1483,y:656,t:1527272185580};\\\", \\\"{x:1484,y:656,t:1527272185606};\\\", \\\"{x:1483,y:657,t:1527272185671};\\\", \\\"{x:1477,y:660,t:1527272185680};\\\", \\\"{x:1468,y:665,t:1527272185698};\\\", \\\"{x:1459,y:670,t:1527272185713};\\\", \\\"{x:1448,y:677,t:1527272185730};\\\", \\\"{x:1438,y:683,t:1527272185747};\\\", \\\"{x:1431,y:689,t:1527272185763};\\\", \\\"{x:1423,y:692,t:1527272185780};\\\", \\\"{x:1415,y:697,t:1527272185797};\\\", \\\"{x:1402,y:702,t:1527272185813};\\\", \\\"{x:1389,y:710,t:1527272185830};\\\", \\\"{x:1375,y:716,t:1527272185847};\\\", \\\"{x:1367,y:720,t:1527272185865};\\\", \\\"{x:1355,y:725,t:1527272185880};\\\", \\\"{x:1346,y:731,t:1527272185897};\\\", \\\"{x:1335,y:739,t:1527272185914};\\\", \\\"{x:1324,y:747,t:1527272185930};\\\", \\\"{x:1315,y:751,t:1527272185947};\\\", \\\"{x:1309,y:755,t:1527272185965};\\\", \\\"{x:1304,y:760,t:1527272185980};\\\", \\\"{x:1301,y:763,t:1527272185997};\\\", \\\"{x:1298,y:766,t:1527272186015};\\\", \\\"{x:1295,y:767,t:1527272186030};\\\", \\\"{x:1294,y:771,t:1527272186047};\\\", \\\"{x:1293,y:772,t:1527272186064};\\\", \\\"{x:1291,y:774,t:1527272186080};\\\", \\\"{x:1290,y:775,t:1527272186097};\\\", \\\"{x:1288,y:777,t:1527272186114};\\\", \\\"{x:1287,y:780,t:1527272186130};\\\", \\\"{x:1285,y:782,t:1527272186147};\\\", \\\"{x:1284,y:783,t:1527272186164};\\\", \\\"{x:1281,y:785,t:1527272186180};\\\", \\\"{x:1277,y:788,t:1527272186197};\\\", \\\"{x:1274,y:789,t:1527272186214};\\\", \\\"{x:1270,y:790,t:1527272186230};\\\", \\\"{x:1261,y:791,t:1527272186247};\\\", \\\"{x:1255,y:791,t:1527272186264};\\\", \\\"{x:1252,y:791,t:1527272186280};\\\", \\\"{x:1249,y:790,t:1527272186297};\\\", \\\"{x:1248,y:785,t:1527272186314};\\\", \\\"{x:1245,y:779,t:1527272186331};\\\", \\\"{x:1245,y:777,t:1527272186347};\\\", \\\"{x:1245,y:774,t:1527272186365};\\\", \\\"{x:1245,y:771,t:1527272186382};\\\", \\\"{x:1245,y:767,t:1527272186397};\\\", \\\"{x:1246,y:763,t:1527272186414};\\\", \\\"{x:1254,y:753,t:1527272186431};\\\", \\\"{x:1260,y:747,t:1527272186447};\\\", \\\"{x:1267,y:740,t:1527272186465};\\\", \\\"{x:1272,y:736,t:1527272186482};\\\", \\\"{x:1283,y:728,t:1527272186497};\\\", \\\"{x:1289,y:725,t:1527272186515};\\\", \\\"{x:1297,y:722,t:1527272186531};\\\", \\\"{x:1303,y:719,t:1527272186547};\\\", \\\"{x:1307,y:717,t:1527272186564};\\\", \\\"{x:1309,y:715,t:1527272186581};\\\", \\\"{x:1310,y:715,t:1527272186597};\\\", \\\"{x:1311,y:714,t:1527272186614};\\\", \\\"{x:1314,y:711,t:1527272186631};\\\", \\\"{x:1319,y:707,t:1527272186647};\\\", \\\"{x:1323,y:704,t:1527272186665};\\\", \\\"{x:1327,y:703,t:1527272186681};\\\", \\\"{x:1328,y:702,t:1527272186698};\\\", \\\"{x:1329,y:701,t:1527272186714};\\\", \\\"{x:1331,y:700,t:1527272186731};\\\", \\\"{x:1333,y:700,t:1527272186747};\\\", \\\"{x:1336,y:698,t:1527272186765};\\\", \\\"{x:1338,y:697,t:1527272186781};\\\", \\\"{x:1339,y:695,t:1527272186799};\\\", \\\"{x:1340,y:695,t:1527272186815};\\\", \\\"{x:1341,y:695,t:1527272186839};\\\", \\\"{x:1342,y:694,t:1527272186856};\\\", \\\"{x:1343,y:694,t:1527272186920};\\\", \\\"{x:1343,y:693,t:1527272186931};\\\", \\\"{x:1344,y:693,t:1527272186948};\\\", \\\"{x:1345,y:692,t:1527272186964};\\\", \\\"{x:1346,y:693,t:1527272187183};\\\", \\\"{x:1346,y:698,t:1527272187198};\\\", \\\"{x:1346,y:709,t:1527272187217};\\\", \\\"{x:1346,y:716,t:1527272187231};\\\", \\\"{x:1346,y:724,t:1527272187249};\\\", \\\"{x:1346,y:734,t:1527272187265};\\\", \\\"{x:1346,y:743,t:1527272187282};\\\", \\\"{x:1346,y:751,t:1527272187299};\\\", \\\"{x:1346,y:758,t:1527272187317};\\\", \\\"{x:1346,y:764,t:1527272187331};\\\", \\\"{x:1346,y:768,t:1527272187348};\\\", \\\"{x:1346,y:769,t:1527272187366};\\\", \\\"{x:1346,y:764,t:1527272187584};\\\", \\\"{x:1342,y:748,t:1527272187601};\\\", \\\"{x:1340,y:736,t:1527272187615};\\\", \\\"{x:1337,y:732,t:1527272187632};\\\", \\\"{x:1337,y:731,t:1527272187648};\\\", \\\"{x:1337,y:729,t:1527272187666};\\\", \\\"{x:1337,y:728,t:1527272187683};\\\", \\\"{x:1337,y:726,t:1527272187711};\\\", \\\"{x:1337,y:725,t:1527272187750};\\\", \\\"{x:1338,y:725,t:1527272187764};\\\", \\\"{x:1339,y:723,t:1527272187781};\\\", \\\"{x:1340,y:722,t:1527272187798};\\\", \\\"{x:1341,y:720,t:1527272187814};\\\", \\\"{x:1343,y:718,t:1527272187832};\\\", \\\"{x:1344,y:716,t:1527272187848};\\\", \\\"{x:1346,y:712,t:1527272187865};\\\", \\\"{x:1346,y:709,t:1527272187882};\\\", \\\"{x:1348,y:707,t:1527272187898};\\\", \\\"{x:1349,y:705,t:1527272187915};\\\", \\\"{x:1350,y:704,t:1527272187932};\\\", \\\"{x:1350,y:703,t:1527272187948};\\\", \\\"{x:1350,y:702,t:1527272187965};\\\", \\\"{x:1350,y:703,t:1527272188111};\\\", \\\"{x:1348,y:706,t:1527272188119};\\\", \\\"{x:1347,y:708,t:1527272188132};\\\", \\\"{x:1344,y:714,t:1527272188149};\\\", \\\"{x:1338,y:720,t:1527272188165};\\\", \\\"{x:1327,y:727,t:1527272188183};\\\", \\\"{x:1304,y:739,t:1527272188199};\\\", \\\"{x:1265,y:746,t:1527272188216};\\\", \\\"{x:1214,y:755,t:1527272188233};\\\", \\\"{x:1157,y:765,t:1527272188250};\\\", \\\"{x:1099,y:773,t:1527272188265};\\\", \\\"{x:1027,y:778,t:1527272188282};\\\", \\\"{x:947,y:778,t:1527272188300};\\\", \\\"{x:866,y:778,t:1527272188315};\\\", \\\"{x:794,y:778,t:1527272188332};\\\", \\\"{x:733,y:778,t:1527272188349};\\\", \\\"{x:680,y:778,t:1527272188365};\\\", \\\"{x:621,y:778,t:1527272188382};\\\", \\\"{x:537,y:771,t:1527272188399};\\\", \\\"{x:509,y:770,t:1527272188416};\\\", \\\"{x:495,y:770,t:1527272188432};\\\", \\\"{x:490,y:770,t:1527272188449};\\\", \\\"{x:488,y:770,t:1527272188504};\\\", \\\"{x:487,y:770,t:1527272188519};\\\", \\\"{x:485,y:770,t:1527272188535};\\\", \\\"{x:485,y:767,t:1527272188567};\\\", \\\"{x:485,y:762,t:1527272188582};\\\", \\\"{x:485,y:752,t:1527272188600};\\\", \\\"{x:485,y:749,t:1527272188616};\\\", \\\"{x:485,y:748,t:1527272188632};\\\", \\\"{x:486,y:746,t:1527272188649};\\\", \\\"{x:487,y:746,t:1527272188666};\\\", \\\"{x:488,y:745,t:1527272188682};\\\", \\\"{x:489,y:745,t:1527272188718};\\\", \\\"{x:491,y:743,t:1527272188731};\\\", \\\"{x:495,y:741,t:1527272188749};\\\", \\\"{x:499,y:739,t:1527272188766};\\\", \\\"{x:499,y:738,t:1527272188783};\\\" ] }, { \\\"rt\\\": 51959, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 658589, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -O -O -O -Z -M -02 PM-X -K -X -G -G -C -F -12 PM-B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:728,t:1527272190743};\\\", \\\"{x:504,y:710,t:1527272190752};\\\", \\\"{x:515,y:679,t:1527272190768};\\\", \\\"{x:528,y:643,t:1527272190783};\\\", \\\"{x:542,y:594,t:1527272190806};\\\", \\\"{x:549,y:559,t:1527272190817};\\\", \\\"{x:552,y:528,t:1527272190835};\\\", \\\"{x:554,y:513,t:1527272190851};\\\", \\\"{x:554,y:495,t:1527272190866};\\\", \\\"{x:554,y:480,t:1527272190884};\\\", \\\"{x:554,y:468,t:1527272190901};\\\", \\\"{x:554,y:466,t:1527272190917};\\\", \\\"{x:552,y:465,t:1527272190933};\\\", \\\"{x:551,y:465,t:1527272190951};\\\", \\\"{x:549,y:465,t:1527272190975};\\\", \\\"{x:547,y:465,t:1527272190990};\\\", \\\"{x:546,y:465,t:1527272191006};\\\", \\\"{x:544,y:465,t:1527272191022};\\\", \\\"{x:542,y:465,t:1527272191034};\\\", \\\"{x:536,y:469,t:1527272191051};\\\", \\\"{x:526,y:473,t:1527272191067};\\\", \\\"{x:519,y:476,t:1527272191084};\\\", \\\"{x:512,y:478,t:1527272191100};\\\", \\\"{x:498,y:480,t:1527272191118};\\\", \\\"{x:489,y:481,t:1527272191134};\\\", \\\"{x:478,y:482,t:1527272191151};\\\", \\\"{x:463,y:482,t:1527272191168};\\\", \\\"{x:448,y:482,t:1527272191184};\\\", \\\"{x:435,y:482,t:1527272191201};\\\", \\\"{x:432,y:482,t:1527272191218};\\\", \\\"{x:428,y:482,t:1527272191234};\\\", \\\"{x:427,y:482,t:1527272191254};\\\", \\\"{x:426,y:482,t:1527272191286};\\\", \\\"{x:425,y:482,t:1527272191301};\\\", \\\"{x:422,y:480,t:1527272191318};\\\", \\\"{x:422,y:479,t:1527272191334};\\\", \\\"{x:419,y:477,t:1527272191351};\\\", \\\"{x:418,y:475,t:1527272191368};\\\", \\\"{x:418,y:474,t:1527272191384};\\\", \\\"{x:418,y:472,t:1527272191401};\\\", \\\"{x:417,y:469,t:1527272191418};\\\", \\\"{x:417,y:466,t:1527272191434};\\\", \\\"{x:417,y:465,t:1527272191451};\\\", \\\"{x:417,y:462,t:1527272191468};\\\", \\\"{x:417,y:460,t:1527272191484};\\\", \\\"{x:417,y:459,t:1527272191501};\\\", \\\"{x:417,y:458,t:1527272191527};\\\", \\\"{x:418,y:458,t:1527272191558};\\\", \\\"{x:419,y:458,t:1527272191607};\\\", \\\"{x:420,y:457,t:1527272191622};\\\", \\\"{x:421,y:457,t:1527272191635};\\\", \\\"{x:422,y:456,t:1527272191651};\\\", \\\"{x:425,y:456,t:1527272191668};\\\", \\\"{x:427,y:455,t:1527272191686};\\\", \\\"{x:428,y:455,t:1527272191701};\\\", \\\"{x:431,y:453,t:1527272191719};\\\", \\\"{x:432,y:452,t:1527272191735};\\\", \\\"{x:434,y:452,t:1527272191775};\\\", \\\"{x:436,y:452,t:1527272191791};\\\", \\\"{x:437,y:452,t:1527272191801};\\\", \\\"{x:443,y:449,t:1527272191819};\\\", \\\"{x:452,y:445,t:1527272191836};\\\", \\\"{x:454,y:444,t:1527272191852};\\\", \\\"{x:456,y:443,t:1527272191869};\\\", \\\"{x:457,y:443,t:1527272191885};\\\", \\\"{x:458,y:443,t:1527272191901};\\\", \\\"{x:465,y:442,t:1527272191918};\\\", \\\"{x:487,y:442,t:1527272191934};\\\", \\\"{x:502,y:442,t:1527272191952};\\\", \\\"{x:514,y:444,t:1527272191968};\\\", \\\"{x:521,y:446,t:1527272191985};\\\", \\\"{x:522,y:446,t:1527272192007};\\\", \\\"{x:526,y:446,t:1527272192150};\\\", \\\"{x:530,y:446,t:1527272192158};\\\", \\\"{x:536,y:447,t:1527272192168};\\\", \\\"{x:546,y:448,t:1527272192185};\\\", \\\"{x:553,y:450,t:1527272192202};\\\", \\\"{x:558,y:451,t:1527272192218};\\\", \\\"{x:564,y:452,t:1527272192235};\\\", \\\"{x:568,y:452,t:1527272192252};\\\", \\\"{x:574,y:452,t:1527272192268};\\\", \\\"{x:576,y:452,t:1527272192285};\\\", \\\"{x:578,y:453,t:1527272192302};\\\", \\\"{x:578,y:454,t:1527272192887};\\\", \\\"{x:579,y:454,t:1527272192902};\\\", \\\"{x:580,y:454,t:1527272192919};\\\", \\\"{x:582,y:454,t:1527272192935};\\\", \\\"{x:585,y:454,t:1527272192953};\\\", \\\"{x:590,y:455,t:1527272192969};\\\", \\\"{x:596,y:455,t:1527272192985};\\\", \\\"{x:600,y:456,t:1527272193003};\\\", \\\"{x:603,y:457,t:1527272193019};\\\", \\\"{x:604,y:457,t:1527272193037};\\\", \\\"{x:607,y:457,t:1527272193052};\\\", \\\"{x:609,y:457,t:1527272193070};\\\", \\\"{x:612,y:457,t:1527272193086};\\\", \\\"{x:614,y:457,t:1527272193103};\\\", \\\"{x:617,y:457,t:1527272194935};\\\", \\\"{x:618,y:457,t:1527272194943};\\\", \\\"{x:622,y:457,t:1527272194954};\\\", \\\"{x:624,y:457,t:1527272194971};\\\", \\\"{x:626,y:456,t:1527272194987};\\\", \\\"{x:630,y:462,t:1527272195367};\\\", \\\"{x:646,y:484,t:1527272195375};\\\", \\\"{x:669,y:512,t:1527272195389};\\\", \\\"{x:743,y:591,t:1527272195406};\\\", \\\"{x:847,y:666,t:1527272195421};\\\", \\\"{x:1015,y:750,t:1527272195438};\\\", \\\"{x:1127,y:792,t:1527272195454};\\\", \\\"{x:1247,y:836,t:1527272195471};\\\", \\\"{x:1362,y:898,t:1527272195488};\\\", \\\"{x:1477,y:966,t:1527272195504};\\\", \\\"{x:1538,y:1007,t:1527272195522};\\\", \\\"{x:1566,y:1025,t:1527272195538};\\\", \\\"{x:1582,y:1035,t:1527272195554};\\\", \\\"{x:1591,y:1042,t:1527272195571};\\\", \\\"{x:1595,y:1045,t:1527272195588};\\\", \\\"{x:1598,y:1047,t:1527272195605};\\\", \\\"{x:1599,y:1047,t:1527272195671};\\\", \\\"{x:1605,y:1047,t:1527272195689};\\\", \\\"{x:1617,y:1039,t:1527272195704};\\\", \\\"{x:1629,y:1027,t:1527272195722};\\\", \\\"{x:1639,y:1014,t:1527272195738};\\\", \\\"{x:1643,y:1001,t:1527272195754};\\\", \\\"{x:1643,y:978,t:1527272195772};\\\", \\\"{x:1632,y:940,t:1527272195788};\\\", \\\"{x:1596,y:887,t:1527272195805};\\\", \\\"{x:1569,y:855,t:1527272195821};\\\", \\\"{x:1563,y:847,t:1527272195839};\\\", \\\"{x:1562,y:845,t:1527272195855};\\\", \\\"{x:1561,y:844,t:1527272195872};\\\", \\\"{x:1558,y:839,t:1527272195888};\\\", \\\"{x:1555,y:835,t:1527272195904};\\\", \\\"{x:1553,y:833,t:1527272195922};\\\", \\\"{x:1552,y:832,t:1527272195939};\\\", \\\"{x:1553,y:831,t:1527272196088};\\\", \\\"{x:1568,y:831,t:1527272196106};\\\", \\\"{x:1592,y:834,t:1527272196122};\\\", \\\"{x:1614,y:838,t:1527272196138};\\\", \\\"{x:1636,y:843,t:1527272196155};\\\", \\\"{x:1643,y:843,t:1527272196172};\\\", \\\"{x:1644,y:843,t:1527272196279};\\\", \\\"{x:1645,y:839,t:1527272196289};\\\", \\\"{x:1649,y:826,t:1527272196305};\\\", \\\"{x:1650,y:821,t:1527272196322};\\\", \\\"{x:1652,y:817,t:1527272196339};\\\", \\\"{x:1654,y:813,t:1527272196356};\\\", \\\"{x:1654,y:812,t:1527272196372};\\\", \\\"{x:1654,y:810,t:1527272196389};\\\", \\\"{x:1655,y:809,t:1527272196406};\\\", \\\"{x:1656,y:808,t:1527272196422};\\\", \\\"{x:1657,y:808,t:1527272196528};\\\", \\\"{x:1658,y:808,t:1527272196539};\\\", \\\"{x:1659,y:810,t:1527272196556};\\\", \\\"{x:1659,y:811,t:1527272196572};\\\", \\\"{x:1656,y:811,t:1527272196599};\\\", \\\"{x:1653,y:806,t:1527272196606};\\\", \\\"{x:1642,y:787,t:1527272196622};\\\", \\\"{x:1631,y:767,t:1527272196638};\\\", \\\"{x:1624,y:751,t:1527272196655};\\\", \\\"{x:1618,y:735,t:1527272196672};\\\", \\\"{x:1617,y:725,t:1527272196689};\\\", \\\"{x:1616,y:716,t:1527272196705};\\\", \\\"{x:1613,y:708,t:1527272196723};\\\", \\\"{x:1612,y:704,t:1527272196739};\\\", \\\"{x:1613,y:702,t:1527272197031};\\\", \\\"{x:1613,y:701,t:1527272197055};\\\", \\\"{x:1612,y:701,t:1527272205359};\\\", \\\"{x:1605,y:705,t:1527272205368};\\\", \\\"{x:1590,y:710,t:1527272205379};\\\", \\\"{x:1549,y:728,t:1527272205395};\\\", \\\"{x:1503,y:751,t:1527272205412};\\\", \\\"{x:1473,y:771,t:1527272205429};\\\", \\\"{x:1462,y:782,t:1527272205445};\\\", \\\"{x:1459,y:786,t:1527272205463};\\\", \\\"{x:1459,y:787,t:1527272205480};\\\", \\\"{x:1461,y:787,t:1527272205583};\\\", \\\"{x:1466,y:784,t:1527272205596};\\\", \\\"{x:1477,y:783,t:1527272205612};\\\", \\\"{x:1485,y:778,t:1527272205630};\\\", \\\"{x:1498,y:770,t:1527272205646};\\\", \\\"{x:1506,y:765,t:1527272205662};\\\", \\\"{x:1511,y:760,t:1527272205680};\\\", \\\"{x:1512,y:758,t:1527272205696};\\\", \\\"{x:1512,y:757,t:1527272205713};\\\", \\\"{x:1513,y:755,t:1527272205729};\\\", \\\"{x:1514,y:755,t:1527272205746};\\\", \\\"{x:1515,y:753,t:1527272205761};\\\", \\\"{x:1516,y:752,t:1527272205779};\\\", \\\"{x:1513,y:752,t:1527272205959};\\\", \\\"{x:1513,y:753,t:1527272205974};\\\", \\\"{x:1512,y:755,t:1527272205990};\\\", \\\"{x:1512,y:756,t:1527272206006};\\\", \\\"{x:1510,y:757,t:1527272206015};\\\", \\\"{x:1510,y:758,t:1527272206031};\\\", \\\"{x:1510,y:759,t:1527272206047};\\\", \\\"{x:1510,y:760,t:1527272206095};\\\", \\\"{x:1510,y:762,t:1527272206183};\\\", \\\"{x:1510,y:763,t:1527272206207};\\\", \\\"{x:1510,y:764,t:1527272206231};\\\", \\\"{x:1510,y:765,t:1527272206246};\\\", \\\"{x:1512,y:765,t:1527272207159};\\\", \\\"{x:1515,y:763,t:1527272207166};\\\", \\\"{x:1520,y:758,t:1527272207181};\\\", \\\"{x:1536,y:746,t:1527272207198};\\\", \\\"{x:1551,y:735,t:1527272207213};\\\", \\\"{x:1574,y:713,t:1527272207231};\\\", \\\"{x:1582,y:704,t:1527272207247};\\\", \\\"{x:1586,y:700,t:1527272207264};\\\", \\\"{x:1586,y:698,t:1527272207280};\\\", \\\"{x:1587,y:695,t:1527272207297};\\\", \\\"{x:1589,y:693,t:1527272207314};\\\", \\\"{x:1590,y:689,t:1527272207331};\\\", \\\"{x:1591,y:687,t:1527272207347};\\\", \\\"{x:1593,y:684,t:1527272207364};\\\", \\\"{x:1594,y:682,t:1527272207392};\\\", \\\"{x:1594,y:681,t:1527272207407};\\\", \\\"{x:1595,y:681,t:1527272207415};\\\", \\\"{x:1596,y:681,t:1527272207430};\\\", \\\"{x:1598,y:681,t:1527272207446};\\\", \\\"{x:1599,y:680,t:1527272207464};\\\", \\\"{x:1603,y:678,t:1527272207479};\\\", \\\"{x:1605,y:677,t:1527272207497};\\\", \\\"{x:1609,y:676,t:1527272207513};\\\", \\\"{x:1612,y:676,t:1527272207530};\\\", \\\"{x:1615,y:676,t:1527272207546};\\\", \\\"{x:1617,y:676,t:1527272207564};\\\", \\\"{x:1617,y:677,t:1527272207792};\\\", \\\"{x:1617,y:678,t:1527272207823};\\\", \\\"{x:1617,y:680,t:1527272207856};\\\", \\\"{x:1617,y:681,t:1527272207879};\\\", \\\"{x:1617,y:683,t:1527272207898};\\\", \\\"{x:1617,y:684,t:1527272207914};\\\", \\\"{x:1617,y:686,t:1527272207930};\\\", \\\"{x:1617,y:688,t:1527272207947};\\\", \\\"{x:1617,y:691,t:1527272207965};\\\", \\\"{x:1617,y:701,t:1527272207981};\\\", \\\"{x:1617,y:712,t:1527272207998};\\\", \\\"{x:1614,y:726,t:1527272208015};\\\", \\\"{x:1599,y:755,t:1527272208031};\\\", \\\"{x:1586,y:778,t:1527272208047};\\\", \\\"{x:1565,y:805,t:1527272208065};\\\", \\\"{x:1536,y:837,t:1527272208082};\\\", \\\"{x:1506,y:859,t:1527272208097};\\\", \\\"{x:1480,y:878,t:1527272208114};\\\", \\\"{x:1457,y:894,t:1527272208131};\\\", \\\"{x:1440,y:906,t:1527272208147};\\\", \\\"{x:1425,y:913,t:1527272208164};\\\", \\\"{x:1410,y:922,t:1527272208182};\\\", \\\"{x:1399,y:927,t:1527272208197};\\\", \\\"{x:1391,y:930,t:1527272208214};\\\", \\\"{x:1389,y:931,t:1527272208231};\\\", \\\"{x:1388,y:929,t:1527272208383};\\\", \\\"{x:1388,y:924,t:1527272208398};\\\", \\\"{x:1384,y:914,t:1527272208415};\\\", \\\"{x:1382,y:906,t:1527272208431};\\\", \\\"{x:1380,y:903,t:1527272208447};\\\", \\\"{x:1380,y:902,t:1527272208735};\\\", \\\"{x:1380,y:898,t:1527272208748};\\\", \\\"{x:1381,y:894,t:1527272208764};\\\", \\\"{x:1386,y:889,t:1527272208782};\\\", \\\"{x:1396,y:882,t:1527272208798};\\\", \\\"{x:1407,y:875,t:1527272208815};\\\", \\\"{x:1418,y:869,t:1527272208831};\\\", \\\"{x:1424,y:865,t:1527272208848};\\\", \\\"{x:1427,y:862,t:1527272208864};\\\", \\\"{x:1429,y:860,t:1527272208882};\\\", \\\"{x:1429,y:859,t:1527272208898};\\\", \\\"{x:1432,y:856,t:1527272208915};\\\", \\\"{x:1433,y:855,t:1527272208931};\\\", \\\"{x:1437,y:853,t:1527272208949};\\\", \\\"{x:1440,y:852,t:1527272208965};\\\", \\\"{x:1446,y:848,t:1527272208981};\\\", \\\"{x:1455,y:845,t:1527272208999};\\\", \\\"{x:1459,y:844,t:1527272209015};\\\", \\\"{x:1462,y:844,t:1527272209032};\\\", \\\"{x:1464,y:845,t:1527272209079};\\\", \\\"{x:1470,y:860,t:1527272209087};\\\", \\\"{x:1478,y:875,t:1527272209098};\\\", \\\"{x:1493,y:909,t:1527272209116};\\\", \\\"{x:1498,y:928,t:1527272209132};\\\", \\\"{x:1500,y:941,t:1527272209149};\\\", \\\"{x:1500,y:945,t:1527272209165};\\\", \\\"{x:1500,y:950,t:1527272209182};\\\", \\\"{x:1500,y:952,t:1527272209198};\\\", \\\"{x:1499,y:956,t:1527272209215};\\\", \\\"{x:1498,y:958,t:1527272209231};\\\", \\\"{x:1496,y:960,t:1527272209249};\\\", \\\"{x:1492,y:963,t:1527272209266};\\\", \\\"{x:1488,y:966,t:1527272209281};\\\", \\\"{x:1486,y:967,t:1527272209298};\\\", \\\"{x:1485,y:967,t:1527272209315};\\\", \\\"{x:1483,y:969,t:1527272209332};\\\", \\\"{x:1482,y:969,t:1527272209348};\\\", \\\"{x:1480,y:970,t:1527272209366};\\\", \\\"{x:1481,y:970,t:1527272209504};\\\", \\\"{x:1483,y:969,t:1527272209515};\\\", \\\"{x:1485,y:968,t:1527272209533};\\\", \\\"{x:1486,y:966,t:1527272209548};\\\", \\\"{x:1486,y:959,t:1527272209775};\\\", \\\"{x:1486,y:945,t:1527272209783};\\\", \\\"{x:1472,y:912,t:1527272209799};\\\", \\\"{x:1456,y:881,t:1527272209815};\\\", \\\"{x:1448,y:861,t:1527272209833};\\\", \\\"{x:1448,y:850,t:1527272209849};\\\", \\\"{x:1448,y:843,t:1527272209866};\\\", \\\"{x:1451,y:839,t:1527272209883};\\\", \\\"{x:1452,y:837,t:1527272209900};\\\", \\\"{x:1452,y:836,t:1527272209916};\\\", \\\"{x:1453,y:836,t:1527272209932};\\\", \\\"{x:1454,y:836,t:1527272209951};\\\", \\\"{x:1455,y:836,t:1527272209966};\\\", \\\"{x:1458,y:834,t:1527272209983};\\\", \\\"{x:1460,y:834,t:1527272209999};\\\", \\\"{x:1462,y:832,t:1527272210015};\\\", \\\"{x:1463,y:832,t:1527272210033};\\\", \\\"{x:1464,y:831,t:1527272210050};\\\", \\\"{x:1466,y:831,t:1527272210071};\\\", \\\"{x:1467,y:830,t:1527272210082};\\\", \\\"{x:1470,y:829,t:1527272210099};\\\", \\\"{x:1477,y:827,t:1527272210114};\\\", \\\"{x:1478,y:827,t:1527272210132};\\\", \\\"{x:1479,y:827,t:1527272210149};\\\", \\\"{x:1479,y:826,t:1527272210198};\\\", \\\"{x:1471,y:823,t:1527272210215};\\\", \\\"{x:1410,y:807,t:1527272210232};\\\", \\\"{x:1293,y:786,t:1527272210249};\\\", \\\"{x:1155,y:771,t:1527272210265};\\\", \\\"{x:991,y:765,t:1527272210282};\\\", \\\"{x:842,y:765,t:1527272210300};\\\", \\\"{x:712,y:765,t:1527272210315};\\\", \\\"{x:611,y:763,t:1527272210332};\\\", \\\"{x:547,y:750,t:1527272210351};\\\", \\\"{x:528,y:743,t:1527272210366};\\\", \\\"{x:522,y:738,t:1527272210381};\\\", \\\"{x:522,y:735,t:1527272210398};\\\", \\\"{x:524,y:727,t:1527272210415};\\\", \\\"{x:534,y:710,t:1527272210432};\\\", \\\"{x:546,y:694,t:1527272210448};\\\", \\\"{x:559,y:682,t:1527272210467};\\\", \\\"{x:570,y:669,t:1527272210484};\\\", \\\"{x:584,y:653,t:1527272210500};\\\", \\\"{x:596,y:637,t:1527272210517};\\\", \\\"{x:618,y:615,t:1527272210534};\\\", \\\"{x:636,y:598,t:1527272210550};\\\", \\\"{x:650,y:582,t:1527272210567};\\\", \\\"{x:665,y:560,t:1527272210585};\\\", \\\"{x:684,y:538,t:1527272210600};\\\", \\\"{x:701,y:524,t:1527272210617};\\\", \\\"{x:711,y:515,t:1527272210634};\\\", \\\"{x:713,y:513,t:1527272210649};\\\", \\\"{x:713,y:512,t:1527272210686};\\\", \\\"{x:712,y:511,t:1527272210699};\\\", \\\"{x:702,y:510,t:1527272210716};\\\", \\\"{x:695,y:510,t:1527272210732};\\\", \\\"{x:685,y:515,t:1527272210750};\\\", \\\"{x:672,y:528,t:1527272210768};\\\", \\\"{x:656,y:545,t:1527272210783};\\\", \\\"{x:642,y:558,t:1527272210800};\\\", \\\"{x:632,y:565,t:1527272210817};\\\", \\\"{x:620,y:572,t:1527272210834};\\\", \\\"{x:614,y:576,t:1527272210850};\\\", \\\"{x:613,y:577,t:1527272210867};\\\", \\\"{x:612,y:577,t:1527272210883};\\\", \\\"{x:611,y:577,t:1527272210900};\\\", \\\"{x:610,y:578,t:1527272210917};\\\", \\\"{x:608,y:579,t:1527272210967};\\\", \\\"{x:607,y:580,t:1527272210982};\\\", \\\"{x:606,y:581,t:1527272211422};\\\", \\\"{x:609,y:583,t:1527272211438};\\\", \\\"{x:612,y:585,t:1527272211451};\\\", \\\"{x:616,y:586,t:1527272211468};\\\", \\\"{x:617,y:587,t:1527272211510};\\\", \\\"{x:620,y:587,t:1527272211518};\\\", \\\"{x:633,y:593,t:1527272211534};\\\", \\\"{x:662,y:611,t:1527272211551};\\\", \\\"{x:720,y:637,t:1527272211569};\\\", \\\"{x:816,y:674,t:1527272211584};\\\", \\\"{x:938,y:710,t:1527272211601};\\\", \\\"{x:1100,y:746,t:1527272211618};\\\", \\\"{x:1281,y:780,t:1527272211634};\\\", \\\"{x:1459,y:818,t:1527272211651};\\\", \\\"{x:1619,y:842,t:1527272211668};\\\", \\\"{x:1739,y:861,t:1527272211684};\\\", \\\"{x:1803,y:871,t:1527272211701};\\\", \\\"{x:1824,y:876,t:1527272211718};\\\", \\\"{x:1825,y:876,t:1527272211750};\\\", \\\"{x:1825,y:877,t:1527272211774};\\\", \\\"{x:1823,y:879,t:1527272211784};\\\", \\\"{x:1816,y:881,t:1527272211801};\\\", \\\"{x:1801,y:888,t:1527272211818};\\\", \\\"{x:1782,y:897,t:1527272211834};\\\", \\\"{x:1761,y:906,t:1527272211851};\\\", \\\"{x:1734,y:913,t:1527272211868};\\\", \\\"{x:1680,y:926,t:1527272211884};\\\", \\\"{x:1622,y:931,t:1527272211901};\\\", \\\"{x:1536,y:931,t:1527272211918};\\\", \\\"{x:1477,y:931,t:1527272211934};\\\", \\\"{x:1441,y:931,t:1527272211951};\\\", \\\"{x:1426,y:931,t:1527272211968};\\\", \\\"{x:1420,y:931,t:1527272211985};\\\", \\\"{x:1419,y:931,t:1527272212070};\\\", \\\"{x:1419,y:929,t:1527272212084};\\\", \\\"{x:1419,y:921,t:1527272212101};\\\", \\\"{x:1423,y:904,t:1527272212117};\\\", \\\"{x:1433,y:888,t:1527272212135};\\\", \\\"{x:1447,y:870,t:1527272212151};\\\", \\\"{x:1460,y:855,t:1527272212168};\\\", \\\"{x:1466,y:845,t:1527272212185};\\\", \\\"{x:1470,y:837,t:1527272212201};\\\", \\\"{x:1471,y:828,t:1527272212218};\\\", \\\"{x:1471,y:820,t:1527272212235};\\\", \\\"{x:1471,y:814,t:1527272212251};\\\", \\\"{x:1471,y:807,t:1527272212268};\\\", \\\"{x:1467,y:798,t:1527272212286};\\\", \\\"{x:1463,y:792,t:1527272212302};\\\", \\\"{x:1463,y:783,t:1527272212744};\\\", \\\"{x:1463,y:765,t:1527272212753};\\\", \\\"{x:1463,y:738,t:1527272212768};\\\", \\\"{x:1463,y:713,t:1527272212785};\\\", \\\"{x:1468,y:682,t:1527272212802};\\\", \\\"{x:1469,y:656,t:1527272212818};\\\", \\\"{x:1469,y:633,t:1527272212835};\\\", \\\"{x:1469,y:614,t:1527272212852};\\\", \\\"{x:1471,y:604,t:1527272212868};\\\", \\\"{x:1474,y:590,t:1527272212885};\\\", \\\"{x:1483,y:568,t:1527272212902};\\\", \\\"{x:1484,y:562,t:1527272212919};\\\", \\\"{x:1486,y:553,t:1527272212935};\\\", \\\"{x:1486,y:538,t:1527272212952};\\\", \\\"{x:1486,y:523,t:1527272212968};\\\", \\\"{x:1485,y:502,t:1527272212985};\\\", \\\"{x:1484,y:487,t:1527272213002};\\\", \\\"{x:1484,y:470,t:1527272213019};\\\", \\\"{x:1480,y:455,t:1527272213035};\\\", \\\"{x:1476,y:436,t:1527272213052};\\\", \\\"{x:1474,y:414,t:1527272213069};\\\", \\\"{x:1474,y:397,t:1527272213085};\\\", \\\"{x:1474,y:375,t:1527272213102};\\\", \\\"{x:1474,y:364,t:1527272213118};\\\", \\\"{x:1474,y:354,t:1527272213136};\\\", \\\"{x:1473,y:348,t:1527272213152};\\\", \\\"{x:1473,y:341,t:1527272213170};\\\", \\\"{x:1472,y:337,t:1527272213186};\\\", \\\"{x:1472,y:334,t:1527272213203};\\\", \\\"{x:1472,y:332,t:1527272213220};\\\", \\\"{x:1474,y:329,t:1527272213236};\\\", \\\"{x:1475,y:327,t:1527272213252};\\\", \\\"{x:1477,y:325,t:1527272213270};\\\", \\\"{x:1479,y:324,t:1527272213285};\\\", \\\"{x:1480,y:323,t:1527272213303};\\\", \\\"{x:1482,y:321,t:1527272213319};\\\", \\\"{x:1482,y:320,t:1527272213336};\\\", \\\"{x:1483,y:316,t:1527272213353};\\\", \\\"{x:1483,y:314,t:1527272213369};\\\", \\\"{x:1483,y:312,t:1527272213385};\\\", \\\"{x:1483,y:310,t:1527272213402};\\\", \\\"{x:1485,y:309,t:1527272213419};\\\", \\\"{x:1485,y:307,t:1527272213435};\\\", \\\"{x:1487,y:304,t:1527272213452};\\\", \\\"{x:1487,y:302,t:1527272213469};\\\", \\\"{x:1487,y:301,t:1527272213486};\\\", \\\"{x:1487,y:299,t:1527272213502};\\\", \\\"{x:1487,y:298,t:1527272214286};\\\", \\\"{x:1486,y:298,t:1527272214303};\\\", \\\"{x:1485,y:298,t:1527272214319};\\\", \\\"{x:1484,y:300,t:1527272214342};\\\", \\\"{x:1484,y:304,t:1527272214353};\\\", \\\"{x:1484,y:314,t:1527272214369};\\\", \\\"{x:1483,y:324,t:1527272214386};\\\", \\\"{x:1481,y:338,t:1527272214403};\\\", \\\"{x:1480,y:356,t:1527272214418};\\\", \\\"{x:1480,y:388,t:1527272214436};\\\", \\\"{x:1480,y:439,t:1527272214453};\\\", \\\"{x:1477,y:515,t:1527272214469};\\\", \\\"{x:1472,y:586,t:1527272214486};\\\", \\\"{x:1472,y:621,t:1527272214503};\\\", \\\"{x:1472,y:648,t:1527272214519};\\\", \\\"{x:1472,y:673,t:1527272214536};\\\", \\\"{x:1472,y:693,t:1527272214553};\\\", \\\"{x:1472,y:713,t:1527272214569};\\\", \\\"{x:1473,y:734,t:1527272214586};\\\", \\\"{x:1478,y:759,t:1527272214603};\\\", \\\"{x:1483,y:806,t:1527272214620};\\\", \\\"{x:1487,y:836,t:1527272214637};\\\", \\\"{x:1493,y:855,t:1527272214653};\\\", \\\"{x:1494,y:864,t:1527272214671};\\\", \\\"{x:1495,y:861,t:1527272214735};\\\", \\\"{x:1479,y:816,t:1527272214754};\\\", \\\"{x:1441,y:743,t:1527272214771};\\\", \\\"{x:1402,y:670,t:1527272214786};\\\", \\\"{x:1367,y:612,t:1527272214803};\\\", \\\"{x:1356,y:592,t:1527272214820};\\\", \\\"{x:1352,y:584,t:1527272214837};\\\", \\\"{x:1352,y:581,t:1527272214854};\\\", \\\"{x:1352,y:574,t:1527272214870};\\\", \\\"{x:1352,y:569,t:1527272214887};\\\", \\\"{x:1353,y:561,t:1527272214903};\\\", \\\"{x:1354,y:554,t:1527272214921};\\\", \\\"{x:1358,y:548,t:1527272214936};\\\", \\\"{x:1363,y:544,t:1527272214954};\\\", \\\"{x:1378,y:538,t:1527272214970};\\\", \\\"{x:1393,y:532,t:1527272214987};\\\", \\\"{x:1400,y:528,t:1527272215004};\\\", \\\"{x:1405,y:526,t:1527272215020};\\\", \\\"{x:1406,y:526,t:1527272215055};\\\", \\\"{x:1408,y:529,t:1527272215110};\\\", \\\"{x:1409,y:532,t:1527272215120};\\\", \\\"{x:1410,y:538,t:1527272215137};\\\", \\\"{x:1410,y:543,t:1527272215153};\\\", \\\"{x:1410,y:544,t:1527272215170};\\\", \\\"{x:1410,y:546,t:1527272215187};\\\", \\\"{x:1410,y:547,t:1527272215203};\\\", \\\"{x:1409,y:549,t:1527272215220};\\\", \\\"{x:1409,y:551,t:1527272215238};\\\", \\\"{x:1409,y:554,t:1527272215253};\\\", \\\"{x:1409,y:558,t:1527272215271};\\\", \\\"{x:1409,y:560,t:1527272215287};\\\", \\\"{x:1409,y:561,t:1527272215304};\\\", \\\"{x:1410,y:561,t:1527272215543};\\\", \\\"{x:1411,y:561,t:1527272215559};\\\", \\\"{x:1412,y:562,t:1527272216039};\\\", \\\"{x:1412,y:564,t:1527272216054};\\\", \\\"{x:1412,y:566,t:1527272216070};\\\", \\\"{x:1412,y:567,t:1527272216111};\\\", \\\"{x:1412,y:568,t:1527272216175};\\\", \\\"{x:1412,y:569,t:1527272216189};\\\", \\\"{x:1412,y:571,t:1527272216207};\\\", \\\"{x:1412,y:573,t:1527272216222};\\\", \\\"{x:1413,y:575,t:1527272216238};\\\", \\\"{x:1413,y:576,t:1527272216254};\\\", \\\"{x:1413,y:577,t:1527272216311};\\\", \\\"{x:1413,y:578,t:1527272216360};\\\", \\\"{x:1413,y:582,t:1527272217199};\\\", \\\"{x:1413,y:587,t:1527272217206};\\\", \\\"{x:1413,y:593,t:1527272217222};\\\", \\\"{x:1413,y:599,t:1527272217239};\\\", \\\"{x:1415,y:603,t:1527272217255};\\\", \\\"{x:1417,y:607,t:1527272217272};\\\", \\\"{x:1420,y:614,t:1527272217289};\\\", \\\"{x:1424,y:619,t:1527272217306};\\\", \\\"{x:1427,y:625,t:1527272217321};\\\", \\\"{x:1429,y:627,t:1527272217339};\\\", \\\"{x:1429,y:628,t:1527272217356};\\\", \\\"{x:1430,y:628,t:1527272217372};\\\", \\\"{x:1431,y:629,t:1527272217389};\\\", \\\"{x:1432,y:630,t:1527272217406};\\\", \\\"{x:1433,y:630,t:1527272217422};\\\", \\\"{x:1434,y:630,t:1527272217439};\\\", \\\"{x:1435,y:630,t:1527272217456};\\\", \\\"{x:1436,y:630,t:1527272217487};\\\", \\\"{x:1437,y:630,t:1527272217519};\\\", \\\"{x:1438,y:630,t:1527272217527};\\\", \\\"{x:1440,y:630,t:1527272217539};\\\", \\\"{x:1442,y:629,t:1527272217556};\\\", \\\"{x:1443,y:628,t:1527272217571};\\\", \\\"{x:1444,y:628,t:1527272217598};\\\", \\\"{x:1445,y:627,t:1527272217614};\\\", \\\"{x:1446,y:627,t:1527272217791};\\\", \\\"{x:1442,y:630,t:1527272217807};\\\", \\\"{x:1437,y:638,t:1527272217823};\\\", \\\"{x:1421,y:656,t:1527272217838};\\\", \\\"{x:1414,y:671,t:1527272217856};\\\", \\\"{x:1405,y:686,t:1527272217872};\\\", \\\"{x:1398,y:700,t:1527272217888};\\\", \\\"{x:1393,y:713,t:1527272217905};\\\", \\\"{x:1389,y:720,t:1527272217923};\\\", \\\"{x:1385,y:726,t:1527272217939};\\\", \\\"{x:1383,y:728,t:1527272217955};\\\", \\\"{x:1379,y:731,t:1527272217973};\\\", \\\"{x:1375,y:732,t:1527272217989};\\\", \\\"{x:1372,y:734,t:1527272218005};\\\", \\\"{x:1368,y:735,t:1527272218022};\\\", \\\"{x:1365,y:735,t:1527272218038};\\\", \\\"{x:1364,y:737,t:1527272218056};\\\", \\\"{x:1363,y:737,t:1527272218072};\\\", \\\"{x:1361,y:737,t:1527272218144};\\\", \\\"{x:1358,y:733,t:1527272218156};\\\", \\\"{x:1352,y:722,t:1527272218173};\\\", \\\"{x:1347,y:711,t:1527272218189};\\\", \\\"{x:1342,y:702,t:1527272218206};\\\", \\\"{x:1339,y:695,t:1527272218222};\\\", \\\"{x:1339,y:692,t:1527272218239};\\\", \\\"{x:1340,y:692,t:1527272218903};\\\", \\\"{x:1340,y:693,t:1527272219015};\\\", \\\"{x:1341,y:693,t:1527272219054};\\\", \\\"{x:1342,y:694,t:1527272219063};\\\", \\\"{x:1343,y:696,t:1527272219079};\\\", \\\"{x:1343,y:697,t:1527272219090};\\\", \\\"{x:1346,y:701,t:1527272219106};\\\", \\\"{x:1346,y:703,t:1527272219124};\\\", \\\"{x:1347,y:706,t:1527272219140};\\\", \\\"{x:1349,y:713,t:1527272219157};\\\", \\\"{x:1351,y:722,t:1527272219173};\\\", \\\"{x:1354,y:727,t:1527272219190};\\\", \\\"{x:1354,y:728,t:1527272219207};\\\", \\\"{x:1354,y:730,t:1527272219271};\\\", \\\"{x:1354,y:733,t:1527272219287};\\\", \\\"{x:1354,y:736,t:1527272219295};\\\", \\\"{x:1354,y:737,t:1527272219307};\\\", \\\"{x:1354,y:743,t:1527272219324};\\\", \\\"{x:1354,y:750,t:1527272219340};\\\", \\\"{x:1354,y:757,t:1527272219357};\\\", \\\"{x:1354,y:765,t:1527272219374};\\\", \\\"{x:1354,y:772,t:1527272219390};\\\", \\\"{x:1354,y:791,t:1527272219406};\\\", \\\"{x:1355,y:808,t:1527272219424};\\\", \\\"{x:1357,y:823,t:1527272219440};\\\", \\\"{x:1357,y:836,t:1527272219456};\\\", \\\"{x:1357,y:841,t:1527272219474};\\\", \\\"{x:1357,y:848,t:1527272219490};\\\", \\\"{x:1355,y:859,t:1527272219507};\\\", \\\"{x:1355,y:866,t:1527272219524};\\\", \\\"{x:1355,y:872,t:1527272219540};\\\", \\\"{x:1355,y:874,t:1527272219557};\\\", \\\"{x:1355,y:877,t:1527272219574};\\\", \\\"{x:1356,y:883,t:1527272219590};\\\", \\\"{x:1356,y:888,t:1527272219606};\\\", \\\"{x:1356,y:891,t:1527272219624};\\\", \\\"{x:1356,y:895,t:1527272219639};\\\", \\\"{x:1359,y:902,t:1527272219657};\\\", \\\"{x:1359,y:912,t:1527272219674};\\\", \\\"{x:1360,y:921,t:1527272219690};\\\", \\\"{x:1363,y:928,t:1527272219707};\\\", \\\"{x:1363,y:931,t:1527272219724};\\\", \\\"{x:1364,y:932,t:1527272219743};\\\", \\\"{x:1366,y:934,t:1527272219759};\\\", \\\"{x:1366,y:940,t:1527272219774};\\\", \\\"{x:1369,y:951,t:1527272219790};\\\", \\\"{x:1369,y:957,t:1527272219807};\\\", \\\"{x:1369,y:958,t:1527272219824};\\\", \\\"{x:1369,y:959,t:1527272220078};\\\", \\\"{x:1370,y:959,t:1527272220091};\\\", \\\"{x:1371,y:958,t:1527272220110};\\\", \\\"{x:1371,y:957,t:1527272220124};\\\", \\\"{x:1371,y:956,t:1527272220295};\\\", \\\"{x:1371,y:955,t:1527272220318};\\\", \\\"{x:1372,y:955,t:1527272220335};\\\", \\\"{x:1372,y:954,t:1527272220431};\\\", \\\"{x:1373,y:954,t:1527272220479};\\\", \\\"{x:1373,y:953,t:1527272220503};\\\", \\\"{x:1373,y:952,t:1527272220526};\\\", \\\"{x:1373,y:951,t:1527272220903};\\\", \\\"{x:1373,y:950,t:1527272220919};\\\", \\\"{x:1373,y:949,t:1527272221015};\\\", \\\"{x:1375,y:949,t:1527272221039};\\\", \\\"{x:1375,y:950,t:1527272221055};\\\", \\\"{x:1375,y:952,t:1527272221071};\\\", \\\"{x:1375,y:954,t:1527272221087};\\\", \\\"{x:1375,y:955,t:1527272221094};\\\", \\\"{x:1375,y:957,t:1527272221108};\\\", \\\"{x:1375,y:959,t:1527272221125};\\\", \\\"{x:1375,y:962,t:1527272221141};\\\", \\\"{x:1374,y:964,t:1527272221159};\\\", \\\"{x:1372,y:966,t:1527272221174};\\\", \\\"{x:1372,y:967,t:1527272221190};\\\", \\\"{x:1371,y:969,t:1527272221207};\\\", \\\"{x:1371,y:970,t:1527272221224};\\\", \\\"{x:1369,y:970,t:1527272221286};\\\", \\\"{x:1368,y:970,t:1527272221294};\\\", \\\"{x:1367,y:970,t:1527272221308};\\\", \\\"{x:1361,y:968,t:1527272221325};\\\", \\\"{x:1357,y:967,t:1527272221340};\\\", \\\"{x:1356,y:967,t:1527272221357};\\\", \\\"{x:1354,y:967,t:1527272221375};\\\", \\\"{x:1353,y:967,t:1527272221415};\\\", \\\"{x:1351,y:967,t:1527272221439};\\\", \\\"{x:1350,y:966,t:1527272221831};\\\", \\\"{x:1350,y:965,t:1527272221960};\\\", \\\"{x:1349,y:965,t:1527272222072};\\\", \\\"{x:1348,y:964,t:1527272222119};\\\", \\\"{x:1348,y:963,t:1527272222152};\\\", \\\"{x:1348,y:962,t:1527272222182};\\\", \\\"{x:1346,y:958,t:1527272226312};\\\", \\\"{x:1323,y:931,t:1527272226328};\\\", \\\"{x:1259,y:885,t:1527272226345};\\\", \\\"{x:1159,y:824,t:1527272226361};\\\", \\\"{x:1040,y:762,t:1527272226378};\\\", \\\"{x:911,y:712,t:1527272226395};\\\", \\\"{x:809,y:667,t:1527272226411};\\\", \\\"{x:732,y:636,t:1527272226428};\\\", \\\"{x:686,y:610,t:1527272226446};\\\", \\\"{x:664,y:595,t:1527272226461};\\\", \\\"{x:660,y:592,t:1527272226478};\\\", \\\"{x:660,y:591,t:1527272226518};\\\", \\\"{x:661,y:590,t:1527272226530};\\\", \\\"{x:668,y:584,t:1527272226546};\\\", \\\"{x:677,y:577,t:1527272226564};\\\", \\\"{x:684,y:572,t:1527272226580};\\\", \\\"{x:693,y:567,t:1527272226596};\\\", \\\"{x:708,y:555,t:1527272226614};\\\", \\\"{x:710,y:550,t:1527272226630};\\\", \\\"{x:712,y:537,t:1527272226646};\\\", \\\"{x:711,y:519,t:1527272226664};\\\", \\\"{x:700,y:502,t:1527272226680};\\\", \\\"{x:681,y:487,t:1527272226696};\\\", \\\"{x:661,y:475,t:1527272226714};\\\", \\\"{x:640,y:469,t:1527272226730};\\\", \\\"{x:622,y:466,t:1527272226746};\\\", \\\"{x:612,y:466,t:1527272226763};\\\", \\\"{x:602,y:472,t:1527272226779};\\\", \\\"{x:596,y:484,t:1527272226797};\\\", \\\"{x:588,y:497,t:1527272226814};\\\", \\\"{x:584,y:502,t:1527272226829};\\\", \\\"{x:579,y:511,t:1527272226847};\\\", \\\"{x:575,y:522,t:1527272226865};\\\", \\\"{x:569,y:539,t:1527272226881};\\\", \\\"{x:567,y:557,t:1527272226897};\\\", \\\"{x:565,y:579,t:1527272226914};\\\", \\\"{x:566,y:591,t:1527272226929};\\\", \\\"{x:572,y:595,t:1527272226947};\\\", \\\"{x:583,y:595,t:1527272226964};\\\", \\\"{x:612,y:588,t:1527272226981};\\\", \\\"{x:658,y:573,t:1527272226997};\\\", \\\"{x:727,y:547,t:1527272227014};\\\", \\\"{x:764,y:527,t:1527272227030};\\\", \\\"{x:783,y:515,t:1527272227048};\\\", \\\"{x:792,y:510,t:1527272227063};\\\", \\\"{x:794,y:509,t:1527272227080};\\\", \\\"{x:794,y:508,t:1527272227134};\\\", \\\"{x:795,y:507,t:1527272227147};\\\", \\\"{x:797,y:507,t:1527272227163};\\\", \\\"{x:799,y:506,t:1527272227180};\\\", \\\"{x:803,y:504,t:1527272227198};\\\", \\\"{x:804,y:504,t:1527272227214};\\\", \\\"{x:805,y:503,t:1527272227231};\\\", \\\"{x:807,y:503,t:1527272227253};\\\", \\\"{x:809,y:501,t:1527272227265};\\\", \\\"{x:812,y:500,t:1527272227282};\\\", \\\"{x:816,y:499,t:1527272227297};\\\", \\\"{x:819,y:498,t:1527272227315};\\\", \\\"{x:820,y:498,t:1527272227332};\\\", \\\"{x:821,y:498,t:1527272227349};\\\", \\\"{x:822,y:498,t:1527272227365};\\\", \\\"{x:823,y:498,t:1527272227382};\\\", \\\"{x:824,y:498,t:1527272227406};\\\", \\\"{x:832,y:499,t:1527272227712};\\\", \\\"{x:889,y:549,t:1527272227731};\\\", \\\"{x:970,y:606,t:1527272227748};\\\", \\\"{x:1073,y:657,t:1527272227764};\\\", \\\"{x:1175,y:698,t:1527272227781};\\\", \\\"{x:1272,y:737,t:1527272227798};\\\", \\\"{x:1302,y:750,t:1527272227814};\\\", \\\"{x:1308,y:755,t:1527272227831};\\\", \\\"{x:1308,y:756,t:1527272227848};\\\", \\\"{x:1308,y:760,t:1527272227864};\\\", \\\"{x:1307,y:764,t:1527272227881};\\\", \\\"{x:1305,y:768,t:1527272227898};\\\", \\\"{x:1301,y:776,t:1527272227915};\\\", \\\"{x:1299,y:782,t:1527272227931};\\\", \\\"{x:1299,y:783,t:1527272227948};\\\", \\\"{x:1298,y:783,t:1527272227967};\\\", \\\"{x:1298,y:782,t:1527272227981};\\\", \\\"{x:1297,y:777,t:1527272227998};\\\", \\\"{x:1297,y:772,t:1527272228014};\\\", \\\"{x:1297,y:768,t:1527272228031};\\\", \\\"{x:1305,y:763,t:1527272228048};\\\", \\\"{x:1311,y:760,t:1527272228065};\\\", \\\"{x:1319,y:757,t:1527272228081};\\\", \\\"{x:1322,y:756,t:1527272228098};\\\", \\\"{x:1326,y:756,t:1527272228115};\\\", \\\"{x:1334,y:756,t:1527272228131};\\\", \\\"{x:1342,y:757,t:1527272228148};\\\", \\\"{x:1344,y:757,t:1527272228165};\\\", \\\"{x:1345,y:757,t:1527272228199};\\\", \\\"{x:1346,y:759,t:1527272228544};\\\", \\\"{x:1346,y:762,t:1527272228565};\\\", \\\"{x:1347,y:767,t:1527272228582};\\\", \\\"{x:1351,y:775,t:1527272228598};\\\", \\\"{x:1353,y:784,t:1527272228615};\\\", \\\"{x:1356,y:798,t:1527272228632};\\\", \\\"{x:1359,y:813,t:1527272228647};\\\", \\\"{x:1361,y:831,t:1527272228664};\\\", \\\"{x:1362,y:852,t:1527272228681};\\\", \\\"{x:1362,y:868,t:1527272228698};\\\", \\\"{x:1362,y:882,t:1527272228715};\\\", \\\"{x:1364,y:892,t:1527272228732};\\\", \\\"{x:1365,y:902,t:1527272228750};\\\", \\\"{x:1365,y:904,t:1527272228765};\\\", \\\"{x:1365,y:910,t:1527272228782};\\\", \\\"{x:1365,y:915,t:1527272228798};\\\", \\\"{x:1365,y:917,t:1527272228815};\\\", \\\"{x:1365,y:918,t:1527272228855};\\\", \\\"{x:1365,y:919,t:1527272228871};\\\", \\\"{x:1363,y:921,t:1527272228886};\\\", \\\"{x:1363,y:920,t:1527272229343};\\\", \\\"{x:1363,y:919,t:1527272229367};\\\", \\\"{x:1363,y:918,t:1527272229502};\\\", \\\"{x:1362,y:918,t:1527272229574};\\\", \\\"{x:1362,y:917,t:1527272229590};\\\", \\\"{x:1362,y:916,t:1527272229599};\\\", \\\"{x:1362,y:915,t:1527272229616};\\\", \\\"{x:1361,y:913,t:1527272229633};\\\", \\\"{x:1361,y:912,t:1527272229649};\\\", \\\"{x:1361,y:910,t:1527272229666};\\\", \\\"{x:1361,y:909,t:1527272229694};\\\", \\\"{x:1361,y:908,t:1527272229719};\\\", \\\"{x:1361,y:907,t:1527272229735};\\\", \\\"{x:1360,y:906,t:1527272229784};\\\", \\\"{x:1360,y:905,t:1527272231015};\\\", \\\"{x:1359,y:903,t:1527272231023};\\\", \\\"{x:1358,y:902,t:1527272231035};\\\", \\\"{x:1358,y:900,t:1527272231050};\\\", \\\"{x:1357,y:899,t:1527272231079};\\\", \\\"{x:1357,y:897,t:1527272231103};\\\", \\\"{x:1356,y:895,t:1527272231119};\\\", \\\"{x:1354,y:893,t:1527272231135};\\\", \\\"{x:1352,y:889,t:1527272231149};\\\", \\\"{x:1347,y:880,t:1527272231167};\\\", \\\"{x:1324,y:861,t:1527272231183};\\\", \\\"{x:1268,y:834,t:1527272231199};\\\", \\\"{x:1172,y:798,t:1527272231216};\\\", \\\"{x:1054,y:765,t:1527272231233};\\\", \\\"{x:918,y:744,t:1527272231250};\\\", \\\"{x:778,y:735,t:1527272231267};\\\", \\\"{x:675,y:733,t:1527272231284};\\\", \\\"{x:588,y:727,t:1527272231300};\\\", \\\"{x:542,y:727,t:1527272231317};\\\", \\\"{x:531,y:727,t:1527272231334};\\\", \\\"{x:530,y:728,t:1527272231350};\\\", \\\"{x:528,y:731,t:1527272231366};\\\", \\\"{x:523,y:738,t:1527272231383};\\\", \\\"{x:515,y:744,t:1527272231400};\\\", \\\"{x:510,y:750,t:1527272231417};\\\", \\\"{x:508,y:752,t:1527272231434};\\\", \\\"{x:507,y:754,t:1527272231450};\\\", \\\"{x:508,y:753,t:1527272231551};\\\", \\\"{x:516,y:745,t:1527272231567};\\\", \\\"{x:529,y:735,t:1527272231584};\\\", \\\"{x:544,y:719,t:1527272231602};\\\", \\\"{x:569,y:697,t:1527272231617};\\\", \\\"{x:587,y:672,t:1527272231633};\\\", \\\"{x:602,y:651,t:1527272231651};\\\", \\\"{x:612,y:633,t:1527272231666};\\\", \\\"{x:618,y:620,t:1527272231684};\\\", \\\"{x:625,y:605,t:1527272231701};\\\", \\\"{x:628,y:589,t:1527272231717};\\\", \\\"{x:633,y:563,t:1527272231734};\\\", \\\"{x:633,y:544,t:1527272231752};\\\", \\\"{x:633,y:527,t:1527272231767};\\\", \\\"{x:633,y:514,t:1527272231785};\\\", \\\"{x:631,y:503,t:1527272231801};\\\", \\\"{x:630,y:502,t:1527272231816};\\\", \\\"{x:630,y:500,t:1527272231903};\\\", \\\"{x:630,y:499,t:1527272231917};\\\", \\\"{x:648,y:500,t:1527272231935};\\\", \\\"{x:682,y:506,t:1527272231951};\\\", \\\"{x:749,y:518,t:1527272231968};\\\", \\\"{x:838,y:531,t:1527272231985};\\\", \\\"{x:906,y:535,t:1527272232000};\\\", \\\"{x:946,y:535,t:1527272232018};\\\", \\\"{x:957,y:535,t:1527272232033};\\\", \\\"{x:956,y:533,t:1527272232062};\\\", \\\"{x:952,y:530,t:1527272232069};\\\", \\\"{x:947,y:528,t:1527272232084};\\\", \\\"{x:936,y:521,t:1527272232101};\\\", \\\"{x:924,y:515,t:1527272232118};\\\", \\\"{x:919,y:513,t:1527272232134};\\\", \\\"{x:916,y:511,t:1527272232151};\\\", \\\"{x:912,y:510,t:1527272232168};\\\", \\\"{x:907,y:507,t:1527272232184};\\\", \\\"{x:897,y:503,t:1527272232200};\\\", \\\"{x:885,y:501,t:1527272232218};\\\", \\\"{x:880,y:499,t:1527272232235};\\\", \\\"{x:876,y:498,t:1527272232251};\\\", \\\"{x:874,y:497,t:1527272232267};\\\", \\\"{x:873,y:497,t:1527272232286};\\\", \\\"{x:871,y:497,t:1527272232302};\\\", \\\"{x:866,y:498,t:1527272232319};\\\", \\\"{x:862,y:499,t:1527272232334};\\\", \\\"{x:854,y:501,t:1527272232351};\\\", \\\"{x:847,y:502,t:1527272232368};\\\", \\\"{x:847,y:503,t:1527272232385};\\\", \\\"{x:846,y:503,t:1527272232402};\\\", \\\"{x:846,y:504,t:1527272232430};\\\", \\\"{x:844,y:504,t:1527272232438};\\\", \\\"{x:842,y:505,t:1527272232454};\\\", \\\"{x:840,y:506,t:1527272232469};\\\", \\\"{x:836,y:506,t:1527272232485};\\\", \\\"{x:833,y:506,t:1527272232502};\\\", \\\"{x:832,y:511,t:1527272233031};\\\", \\\"{x:849,y:533,t:1527272233040};\\\", \\\"{x:877,y:567,t:1527272233053};\\\", \\\"{x:938,y:644,t:1527272233068};\\\", \\\"{x:1016,y:718,t:1527272233085};\\\", \\\"{x:1150,y:796,t:1527272233101};\\\", \\\"{x:1239,y:825,t:1527272233118};\\\", \\\"{x:1308,y:845,t:1527272233134};\\\", \\\"{x:1361,y:851,t:1527272233151};\\\", \\\"{x:1387,y:853,t:1527272233169};\\\", \\\"{x:1396,y:854,t:1527272233184};\\\", \\\"{x:1397,y:854,t:1527272233201};\\\", \\\"{x:1397,y:852,t:1527272233230};\\\", \\\"{x:1397,y:844,t:1527272233238};\\\", \\\"{x:1392,y:829,t:1527272233252};\\\", \\\"{x:1379,y:797,t:1527272233269};\\\", \\\"{x:1353,y:748,t:1527272233285};\\\", \\\"{x:1341,y:722,t:1527272233302};\\\", \\\"{x:1340,y:719,t:1527272233320};\\\", \\\"{x:1339,y:717,t:1527272233335};\\\", \\\"{x:1339,y:715,t:1527272233353};\\\", \\\"{x:1338,y:711,t:1527272233369};\\\", \\\"{x:1338,y:706,t:1527272233385};\\\", \\\"{x:1337,y:704,t:1527272233402};\\\", \\\"{x:1337,y:703,t:1527272233423};\\\", \\\"{x:1337,y:702,t:1527272233471};\\\", \\\"{x:1339,y:702,t:1527272233511};\\\", \\\"{x:1341,y:702,t:1527272233518};\\\", \\\"{x:1342,y:702,t:1527272233537};\\\", \\\"{x:1342,y:701,t:1527272233552};\\\", \\\"{x:1340,y:703,t:1527272241303};\\\", \\\"{x:1320,y:711,t:1527272241311};\\\", \\\"{x:1223,y:737,t:1527272241327};\\\", \\\"{x:1158,y:745,t:1527272241341};\\\", \\\"{x:923,y:769,t:1527272241359};\\\", \\\"{x:784,y:769,t:1527272241375};\\\", \\\"{x:676,y:773,t:1527272241391};\\\", \\\"{x:595,y:773,t:1527272241409};\\\", \\\"{x:552,y:773,t:1527272241426};\\\", \\\"{x:533,y:770,t:1527272241442};\\\", \\\"{x:527,y:769,t:1527272241458};\\\", \\\"{x:524,y:769,t:1527272241475};\\\", \\\"{x:527,y:768,t:1527272241574};\\\", \\\"{x:531,y:766,t:1527272241593};\\\", \\\"{x:536,y:761,t:1527272241608};\\\", \\\"{x:546,y:751,t:1527272241627};\\\", \\\"{x:555,y:738,t:1527272241642};\\\", \\\"{x:560,y:732,t:1527272241658};\\\", \\\"{x:562,y:730,t:1527272241675};\\\", \\\"{x:563,y:728,t:1527272241692};\\\", \\\"{x:564,y:726,t:1527272241709};\\\", \\\"{x:565,y:726,t:1527272241726};\\\", \\\"{x:566,y:725,t:1527272241742};\\\", \\\"{x:567,y:724,t:1527272241759};\\\", \\\"{x:566,y:724,t:1527272241878};\\\", \\\"{x:563,y:724,t:1527272241894};\\\", \\\"{x:559,y:727,t:1527272241909};\\\", \\\"{x:556,y:728,t:1527272241925};\\\" ] }, { \\\"rt\\\": 45142, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 705012, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM-O -O -X -M -M -M -G -G -A -A -01 PM-01 PM-E -E -11 AM-E -E -E -I -B -12 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:564,y:728,t:1527272243843};\\\", \\\"{x:606,y:710,t:1527272243858};\\\", \\\"{x:628,y:707,t:1527272243875};\\\", \\\"{x:633,y:707,t:1527272243890};\\\", \\\"{x:634,y:707,t:1527272243907};\\\", \\\"{x:635,y:707,t:1527272244018};\\\", \\\"{x:638,y:707,t:1527272244042};\\\", \\\"{x:643,y:700,t:1527272244056};\\\", \\\"{x:663,y:674,t:1527272244074};\\\", \\\"{x:699,y:643,t:1527272244090};\\\", \\\"{x:726,y:625,t:1527272244107};\\\", \\\"{x:752,y:609,t:1527272244124};\\\", \\\"{x:769,y:604,t:1527272244141};\\\", \\\"{x:780,y:600,t:1527272244157};\\\", \\\"{x:788,y:595,t:1527272244174};\\\", \\\"{x:789,y:592,t:1527272244191};\\\", \\\"{x:790,y:589,t:1527272244771};\\\", \\\"{x:778,y:575,t:1527272244779};\\\", \\\"{x:743,y:558,t:1527272244793};\\\", \\\"{x:680,y:532,t:1527272244809};\\\", \\\"{x:612,y:507,t:1527272244826};\\\", \\\"{x:556,y:489,t:1527272244841};\\\", \\\"{x:523,y:479,t:1527272244858};\\\", \\\"{x:518,y:477,t:1527272244874};\\\", \\\"{x:518,y:476,t:1527272244922};\\\", \\\"{x:516,y:475,t:1527272244930};\\\", \\\"{x:512,y:472,t:1527272244941};\\\", \\\"{x:501,y:465,t:1527272244958};\\\", \\\"{x:489,y:455,t:1527272244975};\\\", \\\"{x:476,y:445,t:1527272244991};\\\", \\\"{x:468,y:439,t:1527272245008};\\\", \\\"{x:460,y:434,t:1527272245025};\\\", \\\"{x:458,y:431,t:1527272245041};\\\", \\\"{x:458,y:430,t:1527272245138};\\\", \\\"{x:459,y:427,t:1527272245146};\\\", \\\"{x:462,y:427,t:1527272245158};\\\", \\\"{x:465,y:425,t:1527272245175};\\\", \\\"{x:466,y:425,t:1527272245192};\\\", \\\"{x:468,y:424,t:1527272245208};\\\", \\\"{x:471,y:425,t:1527272245258};\\\", \\\"{x:476,y:432,t:1527272245275};\\\", \\\"{x:491,y:444,t:1527272245293};\\\", \\\"{x:505,y:456,t:1527272245308};\\\", \\\"{x:515,y:463,t:1527272245325};\\\", \\\"{x:521,y:467,t:1527272245342};\\\", \\\"{x:522,y:468,t:1527272245358};\\\", \\\"{x:523,y:468,t:1527272245515};\\\", \\\"{x:526,y:468,t:1527272245526};\\\", \\\"{x:531,y:468,t:1527272245542};\\\", \\\"{x:536,y:465,t:1527272245559};\\\", \\\"{x:540,y:463,t:1527272245576};\\\", \\\"{x:543,y:461,t:1527272245592};\\\", \\\"{x:545,y:461,t:1527272245608};\\\", \\\"{x:546,y:461,t:1527272245667};\\\", \\\"{x:546,y:460,t:1527272245675};\\\", \\\"{x:550,y:459,t:1527272245739};\\\", \\\"{x:552,y:458,t:1527272245746};\\\", \\\"{x:559,y:457,t:1527272245759};\\\", \\\"{x:578,y:457,t:1527272245775};\\\", \\\"{x:601,y:457,t:1527272245792};\\\", \\\"{x:623,y:458,t:1527272245809};\\\", \\\"{x:650,y:463,t:1527272245825};\\\", \\\"{x:702,y:470,t:1527272245842};\\\", \\\"{x:764,y:479,t:1527272245859};\\\", \\\"{x:847,y:490,t:1527272245877};\\\", \\\"{x:941,y:499,t:1527272245892};\\\", \\\"{x:1039,y:505,t:1527272245909};\\\", \\\"{x:1172,y:509,t:1527272245926};\\\", \\\"{x:1321,y:520,t:1527272245942};\\\", \\\"{x:1487,y:522,t:1527272245959};\\\", \\\"{x:1636,y:522,t:1527272245975};\\\", \\\"{x:1766,y:522,t:1527272245992};\\\", \\\"{x:1855,y:522,t:1527272246009};\\\", \\\"{x:1898,y:522,t:1527272246025};\\\", \\\"{x:1915,y:522,t:1527272246042};\\\", \\\"{x:1914,y:521,t:1527272246099};\\\", \\\"{x:1911,y:519,t:1527272246109};\\\", \\\"{x:1893,y:508,t:1527272246126};\\\", \\\"{x:1873,y:493,t:1527272246142};\\\", \\\"{x:1850,y:481,t:1527272246159};\\\", \\\"{x:1827,y:470,t:1527272246176};\\\", \\\"{x:1809,y:462,t:1527272246192};\\\", \\\"{x:1794,y:458,t:1527272246210};\\\", \\\"{x:1784,y:455,t:1527272246226};\\\", \\\"{x:1772,y:453,t:1527272246243};\\\", \\\"{x:1736,y:458,t:1527272246259};\\\", \\\"{x:1705,y:471,t:1527272246276};\\\", \\\"{x:1656,y:496,t:1527272246292};\\\", \\\"{x:1622,y:522,t:1527272246310};\\\", \\\"{x:1594,y:546,t:1527272246326};\\\", \\\"{x:1576,y:563,t:1527272246342};\\\", \\\"{x:1560,y:582,t:1527272246359};\\\", \\\"{x:1545,y:603,t:1527272246376};\\\", \\\"{x:1529,y:633,t:1527272246392};\\\", \\\"{x:1513,y:659,t:1527272246409};\\\", \\\"{x:1500,y:694,t:1527272246427};\\\", \\\"{x:1494,y:709,t:1527272246442};\\\", \\\"{x:1478,y:744,t:1527272246460};\\\", \\\"{x:1469,y:763,t:1527272246477};\\\", \\\"{x:1461,y:776,t:1527272246493};\\\", \\\"{x:1452,y:793,t:1527272246510};\\\", \\\"{x:1445,y:811,t:1527272246526};\\\", \\\"{x:1442,y:828,t:1527272246543};\\\", \\\"{x:1439,y:839,t:1527272246560};\\\", \\\"{x:1435,y:849,t:1527272246577};\\\", \\\"{x:1435,y:854,t:1527272246593};\\\", \\\"{x:1434,y:856,t:1527272246610};\\\", \\\"{x:1433,y:859,t:1527272246627};\\\", \\\"{x:1433,y:864,t:1527272246643};\\\", \\\"{x:1433,y:870,t:1527272246660};\\\", \\\"{x:1433,y:874,t:1527272246677};\\\", \\\"{x:1434,y:880,t:1527272246693};\\\", \\\"{x:1438,y:886,t:1527272246709};\\\", \\\"{x:1452,y:895,t:1527272246727};\\\", \\\"{x:1480,y:903,t:1527272246744};\\\", \\\"{x:1515,y:906,t:1527272246760};\\\", \\\"{x:1566,y:907,t:1527272246776};\\\", \\\"{x:1627,y:907,t:1527272246794};\\\", \\\"{x:1699,y:903,t:1527272246810};\\\", \\\"{x:1804,y:874,t:1527272246827};\\\", \\\"{x:1842,y:861,t:1527272246843};\\\", \\\"{x:1859,y:851,t:1527272246860};\\\", \\\"{x:1862,y:847,t:1527272246876};\\\", \\\"{x:1863,y:844,t:1527272246894};\\\", \\\"{x:1865,y:839,t:1527272246910};\\\", \\\"{x:1865,y:836,t:1527272246927};\\\", \\\"{x:1865,y:831,t:1527272246944};\\\", \\\"{x:1865,y:829,t:1527272246960};\\\", \\\"{x:1865,y:828,t:1527272246977};\\\", \\\"{x:1865,y:826,t:1527272246993};\\\", \\\"{x:1864,y:826,t:1527272247187};\\\", \\\"{x:1856,y:828,t:1527272247195};\\\", \\\"{x:1842,y:838,t:1527272247210};\\\", \\\"{x:1814,y:860,t:1527272247227};\\\", \\\"{x:1799,y:870,t:1527272247243};\\\", \\\"{x:1788,y:876,t:1527272247260};\\\", \\\"{x:1774,y:883,t:1527272247277};\\\", \\\"{x:1758,y:893,t:1527272247294};\\\", \\\"{x:1741,y:902,t:1527272247311};\\\", \\\"{x:1720,y:910,t:1527272247327};\\\", \\\"{x:1704,y:916,t:1527272247344};\\\", \\\"{x:1686,y:925,t:1527272247361};\\\", \\\"{x:1684,y:926,t:1527272247377};\\\", \\\"{x:1673,y:929,t:1527272247394};\\\", \\\"{x:1671,y:929,t:1527272247411};\\\", \\\"{x:1670,y:929,t:1527272247427};\\\", \\\"{x:1669,y:929,t:1527272247443};\\\", \\\"{x:1669,y:931,t:1527272247555};\\\", \\\"{x:1664,y:937,t:1527272247563};\\\", \\\"{x:1660,y:941,t:1527272247577};\\\", \\\"{x:1656,y:946,t:1527272247594};\\\", \\\"{x:1643,y:956,t:1527272247611};\\\", \\\"{x:1638,y:961,t:1527272247627};\\\", \\\"{x:1632,y:964,t:1527272247643};\\\", \\\"{x:1628,y:964,t:1527272247661};\\\", \\\"{x:1625,y:965,t:1527272247677};\\\", \\\"{x:1621,y:965,t:1527272247693};\\\", \\\"{x:1613,y:965,t:1527272247711};\\\", \\\"{x:1603,y:963,t:1527272247727};\\\", \\\"{x:1599,y:962,t:1527272247745};\\\", \\\"{x:1598,y:962,t:1527272247761};\\\", \\\"{x:1596,y:962,t:1527272247811};\\\", \\\"{x:1594,y:962,t:1527272247827};\\\", \\\"{x:1593,y:962,t:1527272247844};\\\", \\\"{x:1589,y:962,t:1527272247860};\\\", \\\"{x:1579,y:962,t:1527272247878};\\\", \\\"{x:1566,y:962,t:1527272247894};\\\", \\\"{x:1552,y:962,t:1527272247910};\\\", \\\"{x:1541,y:962,t:1527272247928};\\\", \\\"{x:1534,y:964,t:1527272247944};\\\", \\\"{x:1531,y:964,t:1527272247961};\\\", \\\"{x:1530,y:964,t:1527272247978};\\\", \\\"{x:1528,y:965,t:1527272247994};\\\", \\\"{x:1525,y:967,t:1527272248011};\\\", \\\"{x:1522,y:967,t:1527272248027};\\\", \\\"{x:1518,y:970,t:1527272248044};\\\", \\\"{x:1514,y:970,t:1527272248061};\\\", \\\"{x:1511,y:971,t:1527272248078};\\\", \\\"{x:1509,y:971,t:1527272248094};\\\", \\\"{x:1507,y:971,t:1527272248110};\\\", \\\"{x:1505,y:972,t:1527272248127};\\\", \\\"{x:1503,y:973,t:1527272248144};\\\", \\\"{x:1499,y:974,t:1527272248161};\\\", \\\"{x:1497,y:976,t:1527272248177};\\\", \\\"{x:1493,y:976,t:1527272248194};\\\", \\\"{x:1489,y:976,t:1527272248211};\\\", \\\"{x:1488,y:976,t:1527272248227};\\\", \\\"{x:1487,y:976,t:1527272248284};\\\", \\\"{x:1486,y:976,t:1527272248294};\\\", \\\"{x:1484,y:977,t:1527272248310};\\\", \\\"{x:1484,y:978,t:1527272248327};\\\", \\\"{x:1483,y:978,t:1527272248344};\\\", \\\"{x:1480,y:979,t:1527272248361};\\\", \\\"{x:1478,y:979,t:1527272248379};\\\", \\\"{x:1478,y:980,t:1527272248394};\\\", \\\"{x:1477,y:980,t:1527272248411};\\\", \\\"{x:1475,y:980,t:1527272248428};\\\", \\\"{x:1474,y:981,t:1527272248445};\\\", \\\"{x:1472,y:982,t:1527272248461};\\\", \\\"{x:1471,y:983,t:1527272248477};\\\", \\\"{x:1470,y:983,t:1527272248507};\\\", \\\"{x:1469,y:983,t:1527272248515};\\\", \\\"{x:1469,y:982,t:1527272248651};\\\", \\\"{x:1469,y:978,t:1527272248661};\\\", \\\"{x:1472,y:971,t:1527272248677};\\\", \\\"{x:1473,y:967,t:1527272248696};\\\", \\\"{x:1474,y:964,t:1527272248711};\\\", \\\"{x:1476,y:964,t:1527272248988};\\\", \\\"{x:1478,y:964,t:1527272248995};\\\", \\\"{x:1480,y:964,t:1527272249012};\\\", \\\"{x:1482,y:964,t:1527272249028};\\\", \\\"{x:1484,y:964,t:1527272249107};\\\", \\\"{x:1485,y:963,t:1527272249116};\\\", \\\"{x:1486,y:963,t:1527272249128};\\\", \\\"{x:1487,y:962,t:1527272249145};\\\", \\\"{x:1490,y:961,t:1527272249162};\\\", \\\"{x:1498,y:961,t:1527272249178};\\\", \\\"{x:1522,y:964,t:1527272249194};\\\", \\\"{x:1537,y:966,t:1527272249211};\\\", \\\"{x:1551,y:966,t:1527272249227};\\\", \\\"{x:1561,y:966,t:1527272249245};\\\", \\\"{x:1562,y:966,t:1527272249261};\\\", \\\"{x:1561,y:966,t:1527272249411};\\\", \\\"{x:1548,y:966,t:1527272249428};\\\", \\\"{x:1538,y:966,t:1527272249446};\\\", \\\"{x:1532,y:966,t:1527272249462};\\\", \\\"{x:1531,y:966,t:1527272249478};\\\", \\\"{x:1533,y:966,t:1527272249547};\\\", \\\"{x:1533,y:965,t:1527272249562};\\\", \\\"{x:1534,y:965,t:1527272249579};\\\", \\\"{x:1535,y:965,t:1527272249602};\\\", \\\"{x:1536,y:965,t:1527272249611};\\\", \\\"{x:1537,y:965,t:1527272249629};\\\", \\\"{x:1537,y:964,t:1527272249644};\\\", \\\"{x:1538,y:964,t:1527272249661};\\\", \\\"{x:1539,y:964,t:1527272249682};\\\", \\\"{x:1540,y:964,t:1527272249731};\\\", \\\"{x:1541,y:963,t:1527272249819};\\\", \\\"{x:1542,y:962,t:1527272250860};\\\", \\\"{x:1543,y:962,t:1527272250883};\\\", \\\"{x:1544,y:962,t:1527272250895};\\\", \\\"{x:1551,y:962,t:1527272250912};\\\", \\\"{x:1561,y:964,t:1527272250929};\\\", \\\"{x:1573,y:967,t:1527272250946};\\\", \\\"{x:1580,y:970,t:1527272250963};\\\", \\\"{x:1581,y:970,t:1527272250979};\\\", \\\"{x:1582,y:971,t:1527272251075};\\\", \\\"{x:1581,y:972,t:1527272251107};\\\", \\\"{x:1578,y:974,t:1527272251115};\\\", \\\"{x:1576,y:975,t:1527272251129};\\\", \\\"{x:1569,y:976,t:1527272251146};\\\", \\\"{x:1560,y:978,t:1527272251162};\\\", \\\"{x:1558,y:978,t:1527272251178};\\\", \\\"{x:1558,y:976,t:1527272251435};\\\", \\\"{x:1558,y:975,t:1527272251446};\\\", \\\"{x:1557,y:973,t:1527272251463};\\\", \\\"{x:1554,y:969,t:1527272251480};\\\", \\\"{x:1551,y:966,t:1527272251496};\\\", \\\"{x:1548,y:964,t:1527272251513};\\\", \\\"{x:1547,y:964,t:1527272251588};\\\", \\\"{x:1546,y:964,t:1527272251595};\\\", \\\"{x:1545,y:964,t:1527272251635};\\\", \\\"{x:1544,y:964,t:1527272251667};\\\", \\\"{x:1544,y:965,t:1527272251731};\\\", \\\"{x:1545,y:965,t:1527272252124};\\\", \\\"{x:1545,y:964,t:1527272252259};\\\", \\\"{x:1547,y:964,t:1527272253731};\\\", \\\"{x:1548,y:962,t:1527272256915};\\\", \\\"{x:1548,y:953,t:1527272256934};\\\", \\\"{x:1548,y:950,t:1527272256949};\\\", \\\"{x:1548,y:946,t:1527272256967};\\\", \\\"{x:1548,y:945,t:1527272256984};\\\", \\\"{x:1548,y:943,t:1527272256999};\\\", \\\"{x:1548,y:940,t:1527272257016};\\\", \\\"{x:1548,y:938,t:1527272257033};\\\", \\\"{x:1547,y:934,t:1527272257049};\\\", \\\"{x:1547,y:930,t:1527272257066};\\\", \\\"{x:1547,y:920,t:1527272257083};\\\", \\\"{x:1547,y:912,t:1527272257099};\\\", \\\"{x:1547,y:905,t:1527272257116};\\\", \\\"{x:1547,y:899,t:1527272257133};\\\", \\\"{x:1547,y:891,t:1527272257150};\\\", \\\"{x:1548,y:886,t:1527272257166};\\\", \\\"{x:1548,y:882,t:1527272257183};\\\", \\\"{x:1548,y:878,t:1527272257200};\\\", \\\"{x:1548,y:875,t:1527272257216};\\\", \\\"{x:1548,y:872,t:1527272257233};\\\", \\\"{x:1548,y:869,t:1527272257250};\\\", \\\"{x:1548,y:864,t:1527272257266};\\\", \\\"{x:1549,y:859,t:1527272257282};\\\", \\\"{x:1549,y:854,t:1527272257300};\\\", \\\"{x:1549,y:850,t:1527272257316};\\\", \\\"{x:1549,y:845,t:1527272257333};\\\", \\\"{x:1549,y:840,t:1527272257350};\\\", \\\"{x:1549,y:836,t:1527272257366};\\\", \\\"{x:1548,y:830,t:1527272257384};\\\", \\\"{x:1548,y:827,t:1527272257401};\\\", \\\"{x:1548,y:823,t:1527272257416};\\\", \\\"{x:1548,y:821,t:1527272257433};\\\", \\\"{x:1547,y:818,t:1527272257450};\\\", \\\"{x:1547,y:815,t:1527272257466};\\\", \\\"{x:1546,y:805,t:1527272257482};\\\", \\\"{x:1546,y:800,t:1527272257500};\\\", \\\"{x:1546,y:795,t:1527272257516};\\\", \\\"{x:1546,y:792,t:1527272257533};\\\", \\\"{x:1546,y:789,t:1527272257550};\\\", \\\"{x:1546,y:786,t:1527272257566};\\\", \\\"{x:1546,y:784,t:1527272257583};\\\", \\\"{x:1546,y:781,t:1527272257601};\\\", \\\"{x:1546,y:779,t:1527272257617};\\\", \\\"{x:1546,y:777,t:1527272257633};\\\", \\\"{x:1546,y:776,t:1527272257650};\\\", \\\"{x:1546,y:773,t:1527272257667};\\\", \\\"{x:1546,y:772,t:1527272257683};\\\", \\\"{x:1546,y:769,t:1527272257700};\\\", \\\"{x:1546,y:768,t:1527272257717};\\\", \\\"{x:1546,y:766,t:1527272257734};\\\", \\\"{x:1546,y:765,t:1527272257750};\\\", \\\"{x:1546,y:763,t:1527272257767};\\\", \\\"{x:1546,y:761,t:1527272257783};\\\", \\\"{x:1546,y:757,t:1527272257800};\\\", \\\"{x:1546,y:751,t:1527272257817};\\\", \\\"{x:1546,y:749,t:1527272257833};\\\", \\\"{x:1546,y:748,t:1527272257851};\\\", \\\"{x:1546,y:747,t:1527272257867};\\\", \\\"{x:1546,y:746,t:1527272258931};\\\", \\\"{x:1546,y:737,t:1527272258939};\\\", \\\"{x:1546,y:726,t:1527272258951};\\\", \\\"{x:1550,y:703,t:1527272258967};\\\", \\\"{x:1554,y:688,t:1527272258984};\\\", \\\"{x:1555,y:681,t:1527272259001};\\\", \\\"{x:1558,y:674,t:1527272259017};\\\", \\\"{x:1559,y:668,t:1527272259033};\\\", \\\"{x:1559,y:659,t:1527272259050};\\\", \\\"{x:1559,y:652,t:1527272259067};\\\", \\\"{x:1562,y:641,t:1527272259084};\\\", \\\"{x:1562,y:629,t:1527272259101};\\\", \\\"{x:1562,y:617,t:1527272259117};\\\", \\\"{x:1562,y:609,t:1527272259133};\\\", \\\"{x:1562,y:605,t:1527272259150};\\\", \\\"{x:1562,y:603,t:1527272259166};\\\", \\\"{x:1562,y:602,t:1527272259184};\\\", \\\"{x:1562,y:616,t:1527272259242};\\\", \\\"{x:1562,y:650,t:1527272259250};\\\", \\\"{x:1562,y:736,t:1527272259267};\\\", \\\"{x:1562,y:803,t:1527272259284};\\\", \\\"{x:1562,y:847,t:1527272259301};\\\", \\\"{x:1562,y:871,t:1527272259317};\\\", \\\"{x:1557,y:886,t:1527272259334};\\\", \\\"{x:1555,y:891,t:1527272259351};\\\", \\\"{x:1554,y:892,t:1527272259411};\\\", \\\"{x:1550,y:892,t:1527272259418};\\\", \\\"{x:1546,y:892,t:1527272259434};\\\", \\\"{x:1525,y:886,t:1527272259451};\\\", \\\"{x:1507,y:871,t:1527272259468};\\\", \\\"{x:1495,y:862,t:1527272259484};\\\", \\\"{x:1487,y:854,t:1527272259501};\\\", \\\"{x:1487,y:851,t:1527272259518};\\\", \\\"{x:1487,y:849,t:1527272259534};\\\", \\\"{x:1487,y:843,t:1527272259552};\\\", \\\"{x:1487,y:836,t:1527272259568};\\\", \\\"{x:1487,y:830,t:1527272259584};\\\", \\\"{x:1487,y:826,t:1527272259601};\\\", \\\"{x:1487,y:823,t:1527272259618};\\\", \\\"{x:1487,y:820,t:1527272259635};\\\", \\\"{x:1488,y:816,t:1527272259651};\\\", \\\"{x:1491,y:812,t:1527272259669};\\\", \\\"{x:1493,y:807,t:1527272259684};\\\", \\\"{x:1496,y:804,t:1527272259701};\\\", \\\"{x:1500,y:801,t:1527272259719};\\\", \\\"{x:1500,y:800,t:1527272259734};\\\", \\\"{x:1502,y:798,t:1527272259751};\\\", \\\"{x:1502,y:797,t:1527272259779};\\\", \\\"{x:1502,y:795,t:1527272259787};\\\", \\\"{x:1502,y:793,t:1527272259802};\\\", \\\"{x:1503,y:792,t:1527272259818};\\\", \\\"{x:1504,y:788,t:1527272259835};\\\", \\\"{x:1504,y:785,t:1527272259851};\\\", \\\"{x:1505,y:783,t:1527272259868};\\\", \\\"{x:1505,y:782,t:1527272259884};\\\", \\\"{x:1505,y:781,t:1527272259902};\\\", \\\"{x:1505,y:780,t:1527272259918};\\\", \\\"{x:1506,y:778,t:1527272259934};\\\", \\\"{x:1506,y:777,t:1527272259971};\\\", \\\"{x:1506,y:776,t:1527272259987};\\\", \\\"{x:1507,y:775,t:1527272260002};\\\", \\\"{x:1509,y:772,t:1527272260018};\\\", \\\"{x:1510,y:771,t:1527272260051};\\\", \\\"{x:1511,y:770,t:1527272260091};\\\", \\\"{x:1512,y:770,t:1527272260101};\\\", \\\"{x:1516,y:767,t:1527272260121};\\\", \\\"{x:1519,y:764,t:1527272260134};\\\", \\\"{x:1521,y:762,t:1527272260151};\\\", \\\"{x:1522,y:761,t:1527272260167};\\\", \\\"{x:1524,y:760,t:1527272260186};\\\", \\\"{x:1526,y:759,t:1527272260202};\\\", \\\"{x:1527,y:758,t:1527272260217};\\\", \\\"{x:1527,y:757,t:1527272260234};\\\", \\\"{x:1528,y:757,t:1527272260266};\\\", \\\"{x:1527,y:757,t:1527272260475};\\\", \\\"{x:1526,y:757,t:1527272260499};\\\", \\\"{x:1525,y:758,t:1527272260507};\\\", \\\"{x:1524,y:758,t:1527272260531};\\\", \\\"{x:1523,y:758,t:1527272260547};\\\", \\\"{x:1523,y:759,t:1527272260555};\\\", \\\"{x:1522,y:759,t:1527272260569};\\\", \\\"{x:1521,y:759,t:1527272260585};\\\", \\\"{x:1520,y:760,t:1527272260602};\\\", \\\"{x:1518,y:761,t:1527272260619};\\\", \\\"{x:1517,y:762,t:1527272260635};\\\", \\\"{x:1515,y:763,t:1527272260652};\\\", \\\"{x:1514,y:764,t:1527272260668};\\\", \\\"{x:1513,y:764,t:1527272260685};\\\", \\\"{x:1511,y:765,t:1527272261211};\\\", \\\"{x:1510,y:767,t:1527272261219};\\\", \\\"{x:1507,y:772,t:1527272261237};\\\", \\\"{x:1505,y:779,t:1527272261252};\\\", \\\"{x:1502,y:784,t:1527272261269};\\\", \\\"{x:1501,y:789,t:1527272261285};\\\", \\\"{x:1498,y:794,t:1527272261303};\\\", \\\"{x:1498,y:799,t:1527272261320};\\\", \\\"{x:1495,y:804,t:1527272261336};\\\", \\\"{x:1495,y:810,t:1527272261352};\\\", \\\"{x:1493,y:814,t:1527272261369};\\\", \\\"{x:1492,y:818,t:1527272261385};\\\", \\\"{x:1491,y:820,t:1527272261402};\\\", \\\"{x:1490,y:825,t:1527272261419};\\\", \\\"{x:1490,y:827,t:1527272261435};\\\", \\\"{x:1488,y:829,t:1527272261452};\\\", \\\"{x:1488,y:832,t:1527272261470};\\\", \\\"{x:1487,y:835,t:1527272261486};\\\", \\\"{x:1487,y:837,t:1527272261503};\\\", \\\"{x:1486,y:837,t:1527272261619};\\\", \\\"{x:1485,y:836,t:1527272261731};\\\", \\\"{x:1484,y:835,t:1527272261739};\\\", \\\"{x:1484,y:834,t:1527272261753};\\\", \\\"{x:1484,y:831,t:1527272261770};\\\", \\\"{x:1483,y:829,t:1527272261786};\\\", \\\"{x:1483,y:828,t:1527272261802};\\\", \\\"{x:1481,y:826,t:1527272264347};\\\", \\\"{x:1478,y:808,t:1527272264356};\\\", \\\"{x:1473,y:774,t:1527272264371};\\\", \\\"{x:1467,y:756,t:1527272264386};\\\", \\\"{x:1458,y:736,t:1527272264404};\\\", \\\"{x:1450,y:720,t:1527272264420};\\\", \\\"{x:1447,y:714,t:1527272264437};\\\", \\\"{x:1446,y:709,t:1527272264454};\\\", \\\"{x:1446,y:704,t:1527272264470};\\\", \\\"{x:1444,y:699,t:1527272264486};\\\", \\\"{x:1444,y:693,t:1527272264504};\\\", \\\"{x:1444,y:689,t:1527272264520};\\\", \\\"{x:1444,y:685,t:1527272264537};\\\", \\\"{x:1444,y:681,t:1527272264554};\\\", \\\"{x:1444,y:678,t:1527272264570};\\\", \\\"{x:1446,y:677,t:1527272264587};\\\", \\\"{x:1449,y:674,t:1527272264604};\\\", \\\"{x:1452,y:672,t:1527272264621};\\\", \\\"{x:1455,y:670,t:1527272264636};\\\", \\\"{x:1456,y:668,t:1527272264654};\\\", \\\"{x:1458,y:664,t:1527272264671};\\\", \\\"{x:1459,y:661,t:1527272264687};\\\", \\\"{x:1459,y:657,t:1527272264704};\\\", \\\"{x:1459,y:654,t:1527272264721};\\\", \\\"{x:1459,y:650,t:1527272264737};\\\", \\\"{x:1459,y:645,t:1527272264754};\\\", \\\"{x:1459,y:644,t:1527272264770};\\\", \\\"{x:1458,y:644,t:1527272264851};\\\", \\\"{x:1456,y:653,t:1527272264859};\\\", \\\"{x:1452,y:664,t:1527272264872};\\\", \\\"{x:1444,y:694,t:1527272264887};\\\", \\\"{x:1434,y:729,t:1527272264905};\\\", \\\"{x:1425,y:761,t:1527272264921};\\\", \\\"{x:1413,y:788,t:1527272264937};\\\", \\\"{x:1404,y:815,t:1527272264955};\\\", \\\"{x:1397,y:838,t:1527272264971};\\\", \\\"{x:1388,y:862,t:1527272264987};\\\", \\\"{x:1381,y:887,t:1527272265004};\\\", \\\"{x:1375,y:906,t:1527272265022};\\\", \\\"{x:1369,y:917,t:1527272265037};\\\", \\\"{x:1369,y:921,t:1527272265055};\\\", \\\"{x:1369,y:922,t:1527272265076};\\\", \\\"{x:1369,y:923,t:1527272265091};\\\", \\\"{x:1369,y:919,t:1527272265227};\\\", \\\"{x:1369,y:913,t:1527272265238};\\\", \\\"{x:1369,y:904,t:1527272265255};\\\", \\\"{x:1371,y:900,t:1527272265272};\\\", \\\"{x:1372,y:897,t:1527272265287};\\\", \\\"{x:1373,y:895,t:1527272265304};\\\", \\\"{x:1374,y:895,t:1527272265322};\\\", \\\"{x:1375,y:894,t:1527272265508};\\\", \\\"{x:1375,y:893,t:1527272265521};\\\", \\\"{x:1376,y:892,t:1527272265539};\\\", \\\"{x:1377,y:892,t:1527272266236};\\\", \\\"{x:1378,y:892,t:1527272266331};\\\", \\\"{x:1379,y:892,t:1527272266370};\\\", \\\"{x:1380,y:883,t:1527272267676};\\\", \\\"{x:1380,y:864,t:1527272267690};\\\", \\\"{x:1380,y:818,t:1527272267707};\\\", \\\"{x:1380,y:797,t:1527272267723};\\\", \\\"{x:1380,y:775,t:1527272267740};\\\", \\\"{x:1379,y:757,t:1527272267757};\\\", \\\"{x:1379,y:742,t:1527272267772};\\\", \\\"{x:1379,y:731,t:1527272267790};\\\", \\\"{x:1379,y:721,t:1527272267806};\\\", \\\"{x:1379,y:715,t:1527272267822};\\\", \\\"{x:1379,y:709,t:1527272267839};\\\", \\\"{x:1379,y:705,t:1527272267857};\\\", \\\"{x:1379,y:703,t:1527272267873};\\\", \\\"{x:1379,y:700,t:1527272267890};\\\", \\\"{x:1382,y:695,t:1527272267907};\\\", \\\"{x:1385,y:691,t:1527272267923};\\\", \\\"{x:1388,y:688,t:1527272267940};\\\", \\\"{x:1390,y:683,t:1527272267956};\\\", \\\"{x:1392,y:680,t:1527272267973};\\\", \\\"{x:1397,y:671,t:1527272267990};\\\", \\\"{x:1405,y:659,t:1527272268007};\\\", \\\"{x:1410,y:649,t:1527272268023};\\\", \\\"{x:1411,y:642,t:1527272268039};\\\", \\\"{x:1415,y:633,t:1527272268057};\\\", \\\"{x:1416,y:626,t:1527272268073};\\\", \\\"{x:1416,y:623,t:1527272268090};\\\", \\\"{x:1416,y:617,t:1527272268107};\\\", \\\"{x:1416,y:613,t:1527272268123};\\\", \\\"{x:1413,y:608,t:1527272268140};\\\", \\\"{x:1409,y:602,t:1527272268156};\\\", \\\"{x:1407,y:597,t:1527272268174};\\\", \\\"{x:1405,y:591,t:1527272268190};\\\", \\\"{x:1405,y:586,t:1527272268206};\\\", \\\"{x:1405,y:581,t:1527272268224};\\\", \\\"{x:1405,y:579,t:1527272268240};\\\", \\\"{x:1405,y:577,t:1527272268257};\\\", \\\"{x:1405,y:576,t:1527272268274};\\\", \\\"{x:1405,y:575,t:1527272268289};\\\", \\\"{x:1407,y:574,t:1527272268307};\\\", \\\"{x:1409,y:571,t:1527272268323};\\\", \\\"{x:1410,y:570,t:1527272268339};\\\", \\\"{x:1413,y:567,t:1527272268357};\\\", \\\"{x:1416,y:563,t:1527272268373};\\\", \\\"{x:1418,y:556,t:1527272268391};\\\", \\\"{x:1420,y:551,t:1527272268407};\\\", \\\"{x:1422,y:541,t:1527272268424};\\\", \\\"{x:1423,y:531,t:1527272268439};\\\", \\\"{x:1423,y:519,t:1527272268457};\\\", \\\"{x:1421,y:507,t:1527272268474};\\\", \\\"{x:1419,y:498,t:1527272268490};\\\", \\\"{x:1418,y:489,t:1527272268506};\\\", \\\"{x:1418,y:482,t:1527272268523};\\\", \\\"{x:1414,y:475,t:1527272268540};\\\", \\\"{x:1413,y:469,t:1527272268557};\\\", \\\"{x:1410,y:463,t:1527272268573};\\\", \\\"{x:1408,y:459,t:1527272268589};\\\", \\\"{x:1407,y:455,t:1527272268607};\\\", \\\"{x:1406,y:454,t:1527272268624};\\\", \\\"{x:1406,y:452,t:1527272268651};\\\", \\\"{x:1407,y:451,t:1527272268675};\\\", \\\"{x:1407,y:450,t:1527272268690};\\\", \\\"{x:1408,y:445,t:1527272268707};\\\", \\\"{x:1410,y:442,t:1527272268723};\\\", \\\"{x:1411,y:439,t:1527272268741};\\\", \\\"{x:1413,y:435,t:1527272268757};\\\", \\\"{x:1414,y:432,t:1527272268773};\\\", \\\"{x:1416,y:428,t:1527272268790};\\\", \\\"{x:1417,y:426,t:1527272268807};\\\", \\\"{x:1418,y:424,t:1527272268824};\\\", \\\"{x:1418,y:423,t:1527272268841};\\\", \\\"{x:1418,y:424,t:1527272269651};\\\", \\\"{x:1418,y:425,t:1527272269675};\\\", \\\"{x:1418,y:426,t:1527272270419};\\\", \\\"{x:1418,y:428,t:1527272270427};\\\", \\\"{x:1418,y:429,t:1527272270441};\\\", \\\"{x:1417,y:432,t:1527272270457};\\\", \\\"{x:1417,y:435,t:1527272270474};\\\", \\\"{x:1417,y:436,t:1527272270500};\\\", \\\"{x:1417,y:437,t:1527272270508};\\\", \\\"{x:1417,y:438,t:1527272270524};\\\", \\\"{x:1416,y:440,t:1527272270541};\\\", \\\"{x:1416,y:442,t:1527272270557};\\\", \\\"{x:1415,y:445,t:1527272270574};\\\", \\\"{x:1415,y:447,t:1527272270591};\\\", \\\"{x:1414,y:452,t:1527272270607};\\\", \\\"{x:1414,y:454,t:1527272270624};\\\", \\\"{x:1413,y:458,t:1527272270641};\\\", \\\"{x:1412,y:462,t:1527272270657};\\\", \\\"{x:1410,y:470,t:1527272270674};\\\", \\\"{x:1409,y:475,t:1527272270691};\\\", \\\"{x:1408,y:482,t:1527272270707};\\\", \\\"{x:1407,y:489,t:1527272270724};\\\", \\\"{x:1406,y:493,t:1527272270742};\\\", \\\"{x:1405,y:499,t:1527272270758};\\\", \\\"{x:1404,y:502,t:1527272270775};\\\", \\\"{x:1404,y:508,t:1527272270791};\\\", \\\"{x:1402,y:514,t:1527272270807};\\\", \\\"{x:1402,y:520,t:1527272270825};\\\", \\\"{x:1402,y:523,t:1527272270841};\\\", \\\"{x:1402,y:527,t:1527272270858};\\\", \\\"{x:1402,y:531,t:1527272270874};\\\", \\\"{x:1402,y:535,t:1527272270891};\\\", \\\"{x:1402,y:541,t:1527272270907};\\\", \\\"{x:1402,y:547,t:1527272270924};\\\", \\\"{x:1403,y:553,t:1527272270942};\\\", \\\"{x:1403,y:556,t:1527272270957};\\\", \\\"{x:1403,y:560,t:1527272270974};\\\", \\\"{x:1403,y:563,t:1527272270992};\\\", \\\"{x:1403,y:565,t:1527272271008};\\\", \\\"{x:1403,y:570,t:1527272271024};\\\", \\\"{x:1403,y:577,t:1527272271041};\\\", \\\"{x:1405,y:594,t:1527272271058};\\\", \\\"{x:1405,y:603,t:1527272271075};\\\", \\\"{x:1405,y:613,t:1527272271091};\\\", \\\"{x:1405,y:626,t:1527272271108};\\\", \\\"{x:1405,y:637,t:1527272271125};\\\", \\\"{x:1405,y:650,t:1527272271142};\\\", \\\"{x:1406,y:668,t:1527272271158};\\\", \\\"{x:1407,y:686,t:1527272271174};\\\", \\\"{x:1408,y:699,t:1527272271191};\\\", \\\"{x:1410,y:708,t:1527272271208};\\\", \\\"{x:1410,y:714,t:1527272271224};\\\", \\\"{x:1410,y:719,t:1527272271241};\\\", \\\"{x:1415,y:743,t:1527272271258};\\\", \\\"{x:1418,y:761,t:1527272271274};\\\", \\\"{x:1421,y:778,t:1527272271291};\\\", \\\"{x:1421,y:789,t:1527272271309};\\\", \\\"{x:1421,y:801,t:1527272271325};\\\", \\\"{x:1421,y:808,t:1527272271341};\\\", \\\"{x:1422,y:814,t:1527272271359};\\\", \\\"{x:1423,y:824,t:1527272271375};\\\", \\\"{x:1426,y:834,t:1527272271391};\\\", \\\"{x:1427,y:843,t:1527272271408};\\\", \\\"{x:1427,y:849,t:1527272271424};\\\", \\\"{x:1427,y:853,t:1527272271441};\\\", \\\"{x:1427,y:861,t:1527272271458};\\\", \\\"{x:1430,y:870,t:1527272271475};\\\", \\\"{x:1430,y:878,t:1527272271492};\\\", \\\"{x:1431,y:887,t:1527272271508};\\\", \\\"{x:1432,y:894,t:1527272271525};\\\", \\\"{x:1432,y:898,t:1527272271542};\\\", \\\"{x:1434,y:903,t:1527272271559};\\\", \\\"{x:1435,y:908,t:1527272271576};\\\", \\\"{x:1435,y:914,t:1527272271591};\\\", \\\"{x:1436,y:921,t:1527272271609};\\\", \\\"{x:1436,y:926,t:1527272271626};\\\", \\\"{x:1436,y:930,t:1527272271641};\\\", \\\"{x:1436,y:937,t:1527272271659};\\\", \\\"{x:1436,y:940,t:1527272271675};\\\", \\\"{x:1436,y:944,t:1527272271692};\\\", \\\"{x:1436,y:948,t:1527272271708};\\\", \\\"{x:1436,y:953,t:1527272271725};\\\", \\\"{x:1436,y:958,t:1527272271742};\\\", \\\"{x:1436,y:962,t:1527272271758};\\\", \\\"{x:1435,y:964,t:1527272271776};\\\", \\\"{x:1435,y:967,t:1527272271792};\\\", \\\"{x:1434,y:969,t:1527272271808};\\\", \\\"{x:1433,y:973,t:1527272271826};\\\", \\\"{x:1431,y:977,t:1527272271842};\\\", \\\"{x:1429,y:983,t:1527272271859};\\\", \\\"{x:1427,y:986,t:1527272271876};\\\", \\\"{x:1426,y:987,t:1527272271979};\\\", \\\"{x:1425,y:987,t:1527272271994};\\\", \\\"{x:1424,y:987,t:1527272272008};\\\", \\\"{x:1419,y:987,t:1527272272026};\\\", \\\"{x:1411,y:980,t:1527272272042};\\\", \\\"{x:1396,y:959,t:1527272272059};\\\", \\\"{x:1383,y:938,t:1527272272075};\\\", \\\"{x:1372,y:922,t:1527272272093};\\\", \\\"{x:1363,y:910,t:1527272272109};\\\", \\\"{x:1356,y:895,t:1527272272126};\\\", \\\"{x:1348,y:878,t:1527272272142};\\\", \\\"{x:1341,y:856,t:1527272272159};\\\", \\\"{x:1334,y:829,t:1527272272176};\\\", \\\"{x:1326,y:791,t:1527272272193};\\\", \\\"{x:1320,y:751,t:1527272272209};\\\", \\\"{x:1316,y:713,t:1527272272226};\\\", \\\"{x:1316,y:668,t:1527272272243};\\\", \\\"{x:1316,y:637,t:1527272272259};\\\", \\\"{x:1316,y:614,t:1527272272276};\\\", \\\"{x:1314,y:596,t:1527272272293};\\\", \\\"{x:1314,y:588,t:1527272272309};\\\", \\\"{x:1314,y:582,t:1527272272326};\\\", \\\"{x:1314,y:575,t:1527272272343};\\\", \\\"{x:1314,y:568,t:1527272272359};\\\", \\\"{x:1315,y:561,t:1527272272375};\\\", \\\"{x:1316,y:556,t:1527272272392};\\\", \\\"{x:1316,y:552,t:1527272272409};\\\", \\\"{x:1316,y:551,t:1527272272426};\\\", \\\"{x:1315,y:550,t:1527272272499};\\\", \\\"{x:1309,y:552,t:1527272272509};\\\", \\\"{x:1298,y:557,t:1527272272525};\\\", \\\"{x:1286,y:564,t:1527272272543};\\\", \\\"{x:1278,y:569,t:1527272272560};\\\", \\\"{x:1275,y:570,t:1527272272576};\\\", \\\"{x:1275,y:571,t:1527272272592};\\\", \\\"{x:1274,y:571,t:1527272272779};\\\", \\\"{x:1275,y:570,t:1527272272793};\\\", \\\"{x:1276,y:566,t:1527272272809};\\\", \\\"{x:1278,y:563,t:1527272272826};\\\", \\\"{x:1279,y:560,t:1527272272843};\\\", \\\"{x:1279,y:561,t:1527272272955};\\\", \\\"{x:1279,y:567,t:1527272272963};\\\", \\\"{x:1279,y:573,t:1527272272977};\\\", \\\"{x:1278,y:581,t:1527272272992};\\\", \\\"{x:1277,y:589,t:1527272273009};\\\", \\\"{x:1277,y:595,t:1527272273026};\\\", \\\"{x:1277,y:613,t:1527272273043};\\\", \\\"{x:1273,y:630,t:1527272273060};\\\", \\\"{x:1273,y:644,t:1527272273076};\\\", \\\"{x:1273,y:662,t:1527272273093};\\\", \\\"{x:1272,y:681,t:1527272273110};\\\", \\\"{x:1272,y:695,t:1527272273125};\\\", \\\"{x:1272,y:702,t:1527272273143};\\\", \\\"{x:1272,y:706,t:1527272273160};\\\", \\\"{x:1272,y:710,t:1527272273176};\\\", \\\"{x:1272,y:713,t:1527272273192};\\\", \\\"{x:1272,y:722,t:1527272273209};\\\", \\\"{x:1272,y:731,t:1527272273225};\\\", \\\"{x:1272,y:740,t:1527272273242};\\\", \\\"{x:1272,y:743,t:1527272273259};\\\", \\\"{x:1272,y:745,t:1527272273276};\\\", \\\"{x:1272,y:749,t:1527272273292};\\\", \\\"{x:1272,y:753,t:1527272273310};\\\", \\\"{x:1272,y:758,t:1527272273325};\\\", \\\"{x:1272,y:764,t:1527272273342};\\\", \\\"{x:1272,y:768,t:1527272273359};\\\", \\\"{x:1272,y:770,t:1527272273376};\\\", \\\"{x:1272,y:776,t:1527272273392};\\\", \\\"{x:1272,y:781,t:1527272273410};\\\", \\\"{x:1272,y:787,t:1527272273426};\\\", \\\"{x:1273,y:794,t:1527272273442};\\\", \\\"{x:1273,y:798,t:1527272273459};\\\", \\\"{x:1274,y:804,t:1527272273477};\\\", \\\"{x:1276,y:812,t:1527272273492};\\\", \\\"{x:1277,y:819,t:1527272273509};\\\", \\\"{x:1277,y:826,t:1527272273527};\\\", \\\"{x:1279,y:832,t:1527272273543};\\\", \\\"{x:1281,y:841,t:1527272273560};\\\", \\\"{x:1281,y:846,t:1527272273576};\\\", \\\"{x:1282,y:853,t:1527272273593};\\\", \\\"{x:1282,y:857,t:1527272273609};\\\", \\\"{x:1285,y:866,t:1527272273626};\\\", \\\"{x:1286,y:875,t:1527272273642};\\\", \\\"{x:1289,y:885,t:1527272273659};\\\", \\\"{x:1290,y:893,t:1527272273677};\\\", \\\"{x:1290,y:897,t:1527272273692};\\\", \\\"{x:1291,y:900,t:1527272273710};\\\", \\\"{x:1291,y:903,t:1527272273727};\\\", \\\"{x:1291,y:912,t:1527272273743};\\\", \\\"{x:1291,y:922,t:1527272273759};\\\", \\\"{x:1291,y:931,t:1527272273777};\\\", \\\"{x:1291,y:936,t:1527272273792};\\\", \\\"{x:1291,y:938,t:1527272273810};\\\", \\\"{x:1292,y:942,t:1527272273825};\\\", \\\"{x:1295,y:953,t:1527272273842};\\\", \\\"{x:1298,y:964,t:1527272273859};\\\", \\\"{x:1299,y:974,t:1527272273877};\\\", \\\"{x:1300,y:980,t:1527272273892};\\\", \\\"{x:1300,y:981,t:1527272274099};\\\", \\\"{x:1298,y:980,t:1527272274110};\\\", \\\"{x:1295,y:974,t:1527272274127};\\\", \\\"{x:1294,y:973,t:1527272274144};\\\", \\\"{x:1293,y:972,t:1527272274160};\\\", \\\"{x:1292,y:971,t:1527272274177};\\\", \\\"{x:1292,y:969,t:1527272274194};\\\", \\\"{x:1292,y:968,t:1527272274243};\\\", \\\"{x:1292,y:967,t:1527272274260};\\\", \\\"{x:1291,y:966,t:1527272274277};\\\", \\\"{x:1291,y:965,t:1527272274294};\\\", \\\"{x:1290,y:963,t:1527272274311};\\\", \\\"{x:1290,y:962,t:1527272274327};\\\", \\\"{x:1289,y:961,t:1527272274344};\\\", \\\"{x:1289,y:958,t:1527272274359};\\\", \\\"{x:1289,y:957,t:1527272274377};\\\", \\\"{x:1289,y:955,t:1527272274393};\\\", \\\"{x:1288,y:953,t:1527272274409};\\\", \\\"{x:1286,y:949,t:1527272274426};\\\", \\\"{x:1286,y:947,t:1527272274443};\\\", \\\"{x:1285,y:945,t:1527272274459};\\\", \\\"{x:1285,y:944,t:1527272274476};\\\", \\\"{x:1285,y:942,t:1527272274493};\\\", \\\"{x:1285,y:938,t:1527272274510};\\\", \\\"{x:1285,y:934,t:1527272274526};\\\", \\\"{x:1285,y:928,t:1527272274543};\\\", \\\"{x:1285,y:922,t:1527272274560};\\\", \\\"{x:1285,y:918,t:1527272274576};\\\", \\\"{x:1285,y:911,t:1527272274593};\\\", \\\"{x:1284,y:899,t:1527272274610};\\\", \\\"{x:1284,y:888,t:1527272274627};\\\", \\\"{x:1283,y:873,t:1527272274643};\\\", \\\"{x:1282,y:860,t:1527272274660};\\\", \\\"{x:1282,y:847,t:1527272274677};\\\", \\\"{x:1282,y:829,t:1527272274694};\\\", \\\"{x:1279,y:805,t:1527272274710};\\\", \\\"{x:1276,y:783,t:1527272274726};\\\", \\\"{x:1274,y:761,t:1527272274744};\\\", \\\"{x:1274,y:744,t:1527272274761};\\\", \\\"{x:1274,y:729,t:1527272274776};\\\", \\\"{x:1274,y:716,t:1527272274793};\\\", \\\"{x:1274,y:693,t:1527272274810};\\\", \\\"{x:1273,y:678,t:1527272274826};\\\", \\\"{x:1273,y:666,t:1527272274843};\\\", \\\"{x:1273,y:655,t:1527272274861};\\\", \\\"{x:1273,y:647,t:1527272274877};\\\", \\\"{x:1273,y:637,t:1527272274894};\\\", \\\"{x:1273,y:629,t:1527272274910};\\\", \\\"{x:1273,y:625,t:1527272274927};\\\", \\\"{x:1273,y:620,t:1527272274943};\\\", \\\"{x:1273,y:614,t:1527272274961};\\\", \\\"{x:1273,y:606,t:1527272274976};\\\", \\\"{x:1275,y:601,t:1527272274993};\\\", \\\"{x:1276,y:593,t:1527272275010};\\\", \\\"{x:1276,y:586,t:1527272275028};\\\", \\\"{x:1276,y:579,t:1527272275044};\\\", \\\"{x:1276,y:572,t:1527272275061};\\\", \\\"{x:1276,y:565,t:1527272275078};\\\", \\\"{x:1276,y:556,t:1527272275095};\\\", \\\"{x:1276,y:554,t:1527272275111};\\\", \\\"{x:1276,y:551,t:1527272275127};\\\", \\\"{x:1276,y:548,t:1527272275144};\\\", \\\"{x:1276,y:547,t:1527272275162};\\\", \\\"{x:1277,y:545,t:1527272275178};\\\", \\\"{x:1279,y:543,t:1527272275203};\\\", \\\"{x:1277,y:544,t:1527272275843};\\\", \\\"{x:1275,y:545,t:1527272275862};\\\", \\\"{x:1271,y:547,t:1527272275878};\\\", \\\"{x:1270,y:548,t:1527272275895};\\\", \\\"{x:1269,y:549,t:1527272275911};\\\", \\\"{x:1268,y:549,t:1527272275930};\\\", \\\"{x:1268,y:550,t:1527272275962};\\\", \\\"{x:1265,y:558,t:1527272278699};\\\", \\\"{x:1259,y:574,t:1527272278712};\\\", \\\"{x:1250,y:617,t:1527272278730};\\\", \\\"{x:1238,y:664,t:1527272278746};\\\", \\\"{x:1215,y:735,t:1527272278763};\\\", \\\"{x:1198,y:774,t:1527272278780};\\\", \\\"{x:1191,y:797,t:1527272278796};\\\", \\\"{x:1183,y:814,t:1527272278813};\\\", \\\"{x:1178,y:827,t:1527272278830};\\\", \\\"{x:1176,y:834,t:1527272278846};\\\", \\\"{x:1174,y:840,t:1527272278863};\\\", \\\"{x:1173,y:844,t:1527272278880};\\\", \\\"{x:1173,y:847,t:1527272278896};\\\", \\\"{x:1173,y:850,t:1527272278913};\\\", \\\"{x:1173,y:851,t:1527272278955};\\\", \\\"{x:1173,y:852,t:1527272278971};\\\", \\\"{x:1173,y:853,t:1527272278983};\\\", \\\"{x:1174,y:853,t:1527272279011};\\\", \\\"{x:1177,y:851,t:1527272279043};\\\", \\\"{x:1178,y:848,t:1527272279050};\\\", \\\"{x:1181,y:843,t:1527272279063};\\\", \\\"{x:1183,y:836,t:1527272279080};\\\", \\\"{x:1190,y:823,t:1527272279096};\\\", \\\"{x:1196,y:810,t:1527272279113};\\\", \\\"{x:1201,y:797,t:1527272279130};\\\", \\\"{x:1205,y:779,t:1527272279146};\\\", \\\"{x:1206,y:772,t:1527272279163};\\\", \\\"{x:1206,y:768,t:1527272279182};\\\", \\\"{x:1206,y:765,t:1527272279197};\\\", \\\"{x:1205,y:765,t:1527272279299};\\\", \\\"{x:1202,y:765,t:1527272279313};\\\", \\\"{x:1197,y:767,t:1527272279330};\\\", \\\"{x:1192,y:768,t:1527272279347};\\\", \\\"{x:1190,y:769,t:1527272279363};\\\", \\\"{x:1189,y:769,t:1527272279459};\\\", \\\"{x:1189,y:770,t:1527272279466};\\\", \\\"{x:1188,y:770,t:1527272279480};\\\", \\\"{x:1186,y:770,t:1527272279563};\\\", \\\"{x:1185,y:771,t:1527272279581};\\\", \\\"{x:1184,y:772,t:1527272279597};\\\", \\\"{x:1183,y:773,t:1527272279613};\\\", \\\"{x:1182,y:773,t:1527272279651};\\\", \\\"{x:1181,y:773,t:1527272279666};\\\", \\\"{x:1181,y:774,t:1527272279681};\\\", \\\"{x:1181,y:780,t:1527272279697};\\\", \\\"{x:1179,y:799,t:1527272279714};\\\", \\\"{x:1179,y:825,t:1527272279730};\\\", \\\"{x:1179,y:870,t:1527272279747};\\\", \\\"{x:1179,y:900,t:1527272279764};\\\", \\\"{x:1179,y:924,t:1527272279782};\\\", \\\"{x:1179,y:939,t:1527272279797};\\\", \\\"{x:1179,y:950,t:1527272279814};\\\", \\\"{x:1179,y:958,t:1527272279830};\\\", \\\"{x:1179,y:965,t:1527272279847};\\\", \\\"{x:1179,y:968,t:1527272279864};\\\", \\\"{x:1179,y:970,t:1527272279880};\\\", \\\"{x:1179,y:971,t:1527272279897};\\\", \\\"{x:1178,y:972,t:1527272279947};\\\", \\\"{x:1178,y:969,t:1527272280059};\\\", \\\"{x:1176,y:961,t:1527272280067};\\\", \\\"{x:1176,y:955,t:1527272280080};\\\", \\\"{x:1174,y:950,t:1527272280097};\\\", \\\"{x:1174,y:947,t:1527272280115};\\\", \\\"{x:1174,y:946,t:1527272280162};\\\", \\\"{x:1174,y:944,t:1527272280182};\\\", \\\"{x:1174,y:943,t:1527272280197};\\\", \\\"{x:1174,y:940,t:1527272280214};\\\", \\\"{x:1174,y:936,t:1527272280230};\\\", \\\"{x:1174,y:928,t:1527272280247};\\\", \\\"{x:1176,y:913,t:1527272280264};\\\", \\\"{x:1179,y:894,t:1527272280280};\\\", \\\"{x:1182,y:871,t:1527272280297};\\\", \\\"{x:1184,y:850,t:1527272280314};\\\", \\\"{x:1184,y:820,t:1527272280331};\\\", \\\"{x:1184,y:805,t:1527272280348};\\\", \\\"{x:1184,y:796,t:1527272280364};\\\", \\\"{x:1184,y:789,t:1527272280382};\\\", \\\"{x:1184,y:786,t:1527272280397};\\\", \\\"{x:1184,y:783,t:1527272280414};\\\", \\\"{x:1184,y:782,t:1527272280431};\\\", \\\"{x:1184,y:780,t:1527272280447};\\\", \\\"{x:1184,y:777,t:1527272280464};\\\", \\\"{x:1184,y:773,t:1527272280481};\\\", \\\"{x:1184,y:771,t:1527272280497};\\\", \\\"{x:1184,y:770,t:1527272280514};\\\", \\\"{x:1184,y:769,t:1527272280531};\\\", \\\"{x:1184,y:768,t:1527272280548};\\\", \\\"{x:1186,y:771,t:1527272281532};\\\", \\\"{x:1196,y:795,t:1527272281548};\\\", \\\"{x:1218,y:836,t:1527272281565};\\\", \\\"{x:1242,y:877,t:1527272281582};\\\", \\\"{x:1273,y:917,t:1527272281598};\\\", \\\"{x:1296,y:943,t:1527272281615};\\\", \\\"{x:1310,y:959,t:1527272281631};\\\", \\\"{x:1315,y:967,t:1527272281648};\\\", \\\"{x:1317,y:974,t:1527272281666};\\\", \\\"{x:1322,y:986,t:1527272281681};\\\", \\\"{x:1326,y:1003,t:1527272281698};\\\", \\\"{x:1328,y:1007,t:1527272281714};\\\", \\\"{x:1328,y:999,t:1527272281811};\\\", \\\"{x:1326,y:983,t:1527272281819};\\\", \\\"{x:1322,y:964,t:1527272281831};\\\", \\\"{x:1314,y:919,t:1527272281849};\\\", \\\"{x:1304,y:882,t:1527272281865};\\\", \\\"{x:1297,y:861,t:1527272281881};\\\", \\\"{x:1289,y:844,t:1527272281899};\\\", \\\"{x:1285,y:838,t:1527272281915};\\\", \\\"{x:1284,y:837,t:1527272281931};\\\", \\\"{x:1283,y:836,t:1527272281948};\\\", \\\"{x:1282,y:836,t:1527272281986};\\\", \\\"{x:1277,y:836,t:1527272281998};\\\", \\\"{x:1267,y:838,t:1527272282015};\\\", \\\"{x:1256,y:843,t:1527272282031};\\\", \\\"{x:1247,y:849,t:1527272282048};\\\", \\\"{x:1241,y:853,t:1527272282065};\\\", \\\"{x:1239,y:855,t:1527272282082};\\\", \\\"{x:1238,y:855,t:1527272282219};\\\", \\\"{x:1236,y:851,t:1527272282232};\\\", \\\"{x:1235,y:835,t:1527272282248};\\\", \\\"{x:1235,y:822,t:1527272282265};\\\", \\\"{x:1237,y:813,t:1527272282282};\\\", \\\"{x:1245,y:804,t:1527272282298};\\\", \\\"{x:1256,y:796,t:1527272282315};\\\", \\\"{x:1267,y:788,t:1527272282333};\\\", \\\"{x:1274,y:782,t:1527272282348};\\\", \\\"{x:1279,y:779,t:1527272282366};\\\", \\\"{x:1281,y:777,t:1527272282419};\\\", \\\"{x:1282,y:777,t:1527272282432};\\\", \\\"{x:1284,y:775,t:1527272282448};\\\", \\\"{x:1287,y:773,t:1527272282466};\\\", \\\"{x:1290,y:772,t:1527272282483};\\\", \\\"{x:1292,y:772,t:1527272282498};\\\", \\\"{x:1292,y:771,t:1527272282691};\\\", \\\"{x:1294,y:771,t:1527272282698};\\\", \\\"{x:1310,y:771,t:1527272282716};\\\", \\\"{x:1332,y:769,t:1527272282732};\\\", \\\"{x:1355,y:769,t:1527272282749};\\\", \\\"{x:1377,y:769,t:1527272282766};\\\", \\\"{x:1386,y:769,t:1527272282783};\\\", \\\"{x:1385,y:769,t:1527272282922};\\\", \\\"{x:1383,y:769,t:1527272282932};\\\", \\\"{x:1378,y:769,t:1527272282949};\\\", \\\"{x:1374,y:769,t:1527272282965};\\\", \\\"{x:1368,y:768,t:1527272282982};\\\", \\\"{x:1365,y:767,t:1527272282999};\\\", \\\"{x:1360,y:767,t:1527272283015};\\\", \\\"{x:1358,y:767,t:1527272283032};\\\", \\\"{x:1357,y:767,t:1527272283274};\\\", \\\"{x:1356,y:767,t:1527272283281};\\\", \\\"{x:1353,y:767,t:1527272283299};\\\", \\\"{x:1351,y:767,t:1527272283316};\\\", \\\"{x:1348,y:767,t:1527272283332};\\\", \\\"{x:1344,y:766,t:1527272283349};\\\", \\\"{x:1343,y:766,t:1527272283386};\\\", \\\"{x:1342,y:770,t:1527272283652};\\\", \\\"{x:1342,y:784,t:1527272283667};\\\", \\\"{x:1342,y:800,t:1527272283683};\\\", \\\"{x:1342,y:823,t:1527272283699};\\\", \\\"{x:1342,y:842,t:1527272283716};\\\", \\\"{x:1344,y:858,t:1527272283733};\\\", \\\"{x:1344,y:874,t:1527272283750};\\\", \\\"{x:1344,y:895,t:1527272283766};\\\", \\\"{x:1344,y:911,t:1527272283784};\\\", \\\"{x:1344,y:918,t:1527272283800};\\\", \\\"{x:1344,y:928,t:1527272283816};\\\", \\\"{x:1344,y:936,t:1527272283833};\\\", \\\"{x:1344,y:943,t:1527272283849};\\\", \\\"{x:1344,y:950,t:1527272283866};\\\", \\\"{x:1344,y:955,t:1527272283883};\\\", \\\"{x:1344,y:960,t:1527272283900};\\\", \\\"{x:1344,y:962,t:1527272283916};\\\", \\\"{x:1344,y:963,t:1527272283995};\\\", \\\"{x:1344,y:965,t:1527272284002};\\\", \\\"{x:1344,y:967,t:1527272284016};\\\", \\\"{x:1344,y:969,t:1527272284034};\\\", \\\"{x:1344,y:968,t:1527272284220};\\\", \\\"{x:1344,y:960,t:1527272284234};\\\", \\\"{x:1344,y:947,t:1527272284249};\\\", \\\"{x:1340,y:923,t:1527272284267};\\\", \\\"{x:1338,y:902,t:1527272284283};\\\", \\\"{x:1338,y:887,t:1527272284301};\\\", \\\"{x:1335,y:876,t:1527272284316};\\\", \\\"{x:1335,y:870,t:1527272284334};\\\", \\\"{x:1335,y:861,t:1527272284351};\\\", \\\"{x:1335,y:848,t:1527272284366};\\\", \\\"{x:1337,y:838,t:1527272284383};\\\", \\\"{x:1337,y:828,t:1527272284400};\\\", \\\"{x:1340,y:815,t:1527272284417};\\\", \\\"{x:1344,y:804,t:1527272284433};\\\", \\\"{x:1345,y:799,t:1527272284450};\\\", \\\"{x:1345,y:797,t:1527272284467};\\\", \\\"{x:1345,y:795,t:1527272284483};\\\", \\\"{x:1346,y:793,t:1527272284500};\\\", \\\"{x:1346,y:787,t:1527272284516};\\\", \\\"{x:1346,y:778,t:1527272284533};\\\", \\\"{x:1347,y:772,t:1527272284550};\\\", \\\"{x:1348,y:770,t:1527272284567};\\\", \\\"{x:1348,y:769,t:1527272284583};\\\", \\\"{x:1348,y:768,t:1527272284600};\\\", \\\"{x:1339,y:767,t:1527272284617};\\\", \\\"{x:1294,y:767,t:1527272284633};\\\", \\\"{x:1139,y:767,t:1527272284650};\\\", \\\"{x:982,y:767,t:1527272284666};\\\", \\\"{x:812,y:756,t:1527272284683};\\\", \\\"{x:647,y:741,t:1527272284700};\\\", \\\"{x:507,y:713,t:1527272284717};\\\", \\\"{x:410,y:683,t:1527272284733};\\\", \\\"{x:369,y:661,t:1527272284751};\\\", \\\"{x:358,y:653,t:1527272284767};\\\", \\\"{x:356,y:649,t:1527272284782};\\\", \\\"{x:357,y:634,t:1527272284805};\\\", \\\"{x:363,y:616,t:1527272284821};\\\", \\\"{x:369,y:598,t:1527272284841};\\\", \\\"{x:377,y:580,t:1527272284857};\\\", \\\"{x:391,y:564,t:1527272284874};\\\", \\\"{x:402,y:554,t:1527272284891};\\\", \\\"{x:415,y:543,t:1527272284907};\\\", \\\"{x:435,y:534,t:1527272284924};\\\", \\\"{x:465,y:521,t:1527272284941};\\\", \\\"{x:497,y:509,t:1527272284958};\\\", \\\"{x:520,y:501,t:1527272284974};\\\", \\\"{x:533,y:497,t:1527272284991};\\\", \\\"{x:533,y:496,t:1527272285006};\\\", \\\"{x:524,y:496,t:1527272285081};\\\", \\\"{x:513,y:499,t:1527272285091};\\\", \\\"{x:488,y:509,t:1527272285109};\\\", \\\"{x:467,y:516,t:1527272285123};\\\", \\\"{x:450,y:524,t:1527272285142};\\\", \\\"{x:417,y:538,t:1527272285158};\\\", \\\"{x:359,y:564,t:1527272285174};\\\", \\\"{x:296,y:590,t:1527272285191};\\\", \\\"{x:229,y:621,t:1527272285208};\\\", \\\"{x:163,y:659,t:1527272285225};\\\", \\\"{x:110,y:686,t:1527272285241};\\\", \\\"{x:57,y:703,t:1527272285257};\\\", \\\"{x:40,y:707,t:1527272285274};\\\", \\\"{x:30,y:707,t:1527272285290};\\\", \\\"{x:15,y:701,t:1527272285307};\\\", \\\"{x:0,y:685,t:1527272285325};\\\", \\\"{x:0,y:664,t:1527272285341};\\\", \\\"{x:0,y:637,t:1527272285358};\\\", \\\"{x:10,y:604,t:1527272285375};\\\", \\\"{x:24,y:582,t:1527272285391};\\\", \\\"{x:35,y:570,t:1527272285408};\\\", \\\"{x:43,y:563,t:1527272285425};\\\", \\\"{x:50,y:559,t:1527272285441};\\\", \\\"{x:54,y:556,t:1527272285458};\\\", \\\"{x:56,y:556,t:1527272285475};\\\", \\\"{x:57,y:556,t:1527272285523};\\\", \\\"{x:58,y:555,t:1527272285542};\\\", \\\"{x:63,y:554,t:1527272285557};\\\", \\\"{x:67,y:552,t:1527272285574};\\\", \\\"{x:69,y:552,t:1527272285589};\\\", \\\"{x:72,y:549,t:1527272285606};\\\", \\\"{x:76,y:548,t:1527272285623};\\\", \\\"{x:81,y:546,t:1527272285640};\\\", \\\"{x:88,y:543,t:1527272285657};\\\", \\\"{x:100,y:537,t:1527272285672};\\\", \\\"{x:115,y:530,t:1527272285690};\\\", \\\"{x:119,y:530,t:1527272285706};\\\", \\\"{x:120,y:529,t:1527272285723};\\\", \\\"{x:122,y:529,t:1527272285827};\\\", \\\"{x:123,y:529,t:1527272285842};\\\", \\\"{x:124,y:531,t:1527272285856};\\\", \\\"{x:126,y:532,t:1527272285873};\\\", \\\"{x:132,y:536,t:1527272285889};\\\", \\\"{x:141,y:539,t:1527272285906};\\\", \\\"{x:143,y:540,t:1527272285922};\\\", \\\"{x:148,y:542,t:1527272285939};\\\", \\\"{x:154,y:543,t:1527272285956};\\\", \\\"{x:162,y:545,t:1527272285973};\\\", \\\"{x:165,y:545,t:1527272285991};\\\", \\\"{x:170,y:546,t:1527272286466};\\\", \\\"{x:193,y:561,t:1527272286475};\\\", \\\"{x:252,y:602,t:1527272286492};\\\", \\\"{x:319,y:651,t:1527272286510};\\\", \\\"{x:383,y:694,t:1527272286525};\\\", \\\"{x:437,y:732,t:1527272286542};\\\", \\\"{x:477,y:763,t:1527272286558};\\\", \\\"{x:501,y:786,t:1527272286575};\\\", \\\"{x:513,y:800,t:1527272286592};\\\", \\\"{x:516,y:805,t:1527272286608};\\\", \\\"{x:516,y:811,t:1527272286626};\\\", \\\"{x:516,y:814,t:1527272286641};\\\", \\\"{x:516,y:815,t:1527272286682};\\\", \\\"{x:515,y:815,t:1527272286692};\\\", \\\"{x:514,y:815,t:1527272286747};\\\", \\\"{x:512,y:810,t:1527272286759};\\\", \\\"{x:506,y:792,t:1527272286776};\\\", \\\"{x:502,y:774,t:1527272286793};\\\", \\\"{x:500,y:757,t:1527272286809};\\\", \\\"{x:500,y:735,t:1527272286826};\\\", \\\"{x:501,y:728,t:1527272286843};\\\", \\\"{x:502,y:723,t:1527272286858};\\\", \\\"{x:505,y:719,t:1527272286876};\\\", \\\"{x:506,y:718,t:1527272286906};\\\", \\\"{x:506,y:719,t:1527272287083};\\\", \\\"{x:506,y:722,t:1527272287093};\\\", \\\"{x:506,y:726,t:1527272287109};\\\", \\\"{x:506,y:731,t:1527272287126};\\\", \\\"{x:506,y:734,t:1527272287143};\\\", \\\"{x:506,y:735,t:1527272287158};\\\", \\\"{x:506,y:736,t:1527272287176};\\\", \\\"{x:506,y:737,t:1527272287899};\\\", \\\"{x:506,y:738,t:1527272287938};\\\", \\\"{x:505,y:738,t:1527272288591};\\\" ] }, { \\\"rt\\\": 69340, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 775654, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-X -X -10 AM-09 AM-08 AM-10 AM-11 AM-01 PM-02 PM-Z -01 PM-X -02 PM-X -B -B -F -F -F -B -4-12 PM-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:745,t:1527272293771};\\\", \\\"{x:595,y:762,t:1527272293783};\\\", \\\"{x:750,y:806,t:1527272293797};\\\", \\\"{x:927,y:860,t:1527272293815};\\\", \\\"{x:1125,y:913,t:1527272293831};\\\", \\\"{x:1322,y:976,t:1527272293848};\\\", \\\"{x:1498,y:1056,t:1527272293864};\\\", \\\"{x:1628,y:1137,t:1527272293881};\\\", \\\"{x:1721,y:1199,t:1527272293898};\\\", \\\"{x:1732,y:1199,t:1527272293914};\\\", \\\"{x:1733,y:1199,t:1527272293931};\\\", \\\"{x:1738,y:1199,t:1527272294098};\\\", \\\"{x:1765,y:1199,t:1527272294114};\\\", \\\"{x:1796,y:1199,t:1527272294131};\\\", \\\"{x:1819,y:1199,t:1527272294148};\\\", \\\"{x:1832,y:1199,t:1527272294165};\\\", \\\"{x:1845,y:1197,t:1527272294181};\\\", \\\"{x:1845,y:1196,t:1527272294198};\\\", \\\"{x:1813,y:1169,t:1527272294215};\\\", \\\"{x:1699,y:1085,t:1527272294231};\\\", \\\"{x:1557,y:1003,t:1527272294248};\\\", \\\"{x:1430,y:945,t:1527272294265};\\\", \\\"{x:1355,y:925,t:1527272294281};\\\", \\\"{x:1327,y:919,t:1527272294298};\\\", \\\"{x:1325,y:919,t:1527272294316};\\\", \\\"{x:1327,y:924,t:1527272294338};\\\", \\\"{x:1340,y:932,t:1527272294349};\\\", \\\"{x:1389,y:960,t:1527272294365};\\\", \\\"{x:1438,y:990,t:1527272294382};\\\", \\\"{x:1495,y:1021,t:1527272294398};\\\", \\\"{x:1553,y:1044,t:1527272294416};\\\", \\\"{x:1604,y:1062,t:1527272294432};\\\", \\\"{x:1633,y:1072,t:1527272294449};\\\", \\\"{x:1646,y:1074,t:1527272294465};\\\", \\\"{x:1647,y:1075,t:1527272294482};\\\", \\\"{x:1643,y:1071,t:1527272294523};\\\", \\\"{x:1638,y:1066,t:1527272294531};\\\", \\\"{x:1627,y:1055,t:1527272294549};\\\", \\\"{x:1613,y:1037,t:1527272294566};\\\", \\\"{x:1598,y:1019,t:1527272294582};\\\", \\\"{x:1586,y:1002,t:1527272294599};\\\", \\\"{x:1579,y:992,t:1527272294615};\\\", \\\"{x:1574,y:987,t:1527272294632};\\\", \\\"{x:1570,y:980,t:1527272294648};\\\", \\\"{x:1567,y:975,t:1527272294665};\\\", \\\"{x:1559,y:965,t:1527272294681};\\\", \\\"{x:1555,y:960,t:1527272294698};\\\", \\\"{x:1548,y:950,t:1527272294716};\\\", \\\"{x:1542,y:944,t:1527272294733};\\\", \\\"{x:1536,y:940,t:1527272294749};\\\", \\\"{x:1530,y:937,t:1527272294766};\\\", \\\"{x:1524,y:934,t:1527272294783};\\\", \\\"{x:1522,y:933,t:1527272294799};\\\", \\\"{x:1520,y:933,t:1527272294816};\\\", \\\"{x:1517,y:933,t:1527272294833};\\\", \\\"{x:1510,y:934,t:1527272294848};\\\", \\\"{x:1501,y:939,t:1527272294865};\\\", \\\"{x:1487,y:949,t:1527272294882};\\\", \\\"{x:1485,y:952,t:1527272294899};\\\", \\\"{x:1485,y:953,t:1527272294916};\\\", \\\"{x:1484,y:954,t:1527272294932};\\\", \\\"{x:1483,y:955,t:1527272295018};\\\", \\\"{x:1483,y:956,t:1527272295034};\\\", \\\"{x:1483,y:957,t:1527272295058};\\\", \\\"{x:1483,y:955,t:1527272295131};\\\", \\\"{x:1483,y:949,t:1527272295138};\\\", \\\"{x:1483,y:938,t:1527272295150};\\\", \\\"{x:1484,y:909,t:1527272295165};\\\", \\\"{x:1484,y:881,t:1527272295182};\\\", \\\"{x:1479,y:857,t:1527272295199};\\\", \\\"{x:1476,y:843,t:1527272295215};\\\", \\\"{x:1476,y:834,t:1527272295232};\\\", \\\"{x:1477,y:830,t:1527272295250};\\\", \\\"{x:1478,y:829,t:1527272295265};\\\", \\\"{x:1479,y:829,t:1527272295282};\\\", \\\"{x:1479,y:827,t:1527272295362};\\\", \\\"{x:1479,y:825,t:1527272295370};\\\", \\\"{x:1479,y:824,t:1527272295383};\\\", \\\"{x:1479,y:820,t:1527272295400};\\\", \\\"{x:1478,y:822,t:1527272313480};\\\", \\\"{x:1474,y:862,t:1527272313497};\\\", \\\"{x:1457,y:911,t:1527272313512};\\\", \\\"{x:1439,y:952,t:1527272313528};\\\", \\\"{x:1425,y:988,t:1527272313545};\\\", \\\"{x:1420,y:1010,t:1527272313562};\\\", \\\"{x:1420,y:1030,t:1527272313578};\\\", \\\"{x:1420,y:1045,t:1527272313595};\\\", \\\"{x:1420,y:1062,t:1527272313612};\\\", \\\"{x:1422,y:1076,t:1527272313627};\\\", \\\"{x:1423,y:1083,t:1527272313644};\\\", \\\"{x:1423,y:1087,t:1527272313661};\\\", \\\"{x:1423,y:1088,t:1527272313677};\\\", \\\"{x:1426,y:1077,t:1527272313823};\\\", \\\"{x:1435,y:1047,t:1527272313832};\\\", \\\"{x:1441,y:1017,t:1527272313845};\\\", \\\"{x:1448,y:977,t:1527272313862};\\\", \\\"{x:1450,y:955,t:1527272313878};\\\", \\\"{x:1450,y:939,t:1527272313895};\\\", \\\"{x:1453,y:921,t:1527272313912};\\\", \\\"{x:1454,y:914,t:1527272313927};\\\", \\\"{x:1455,y:909,t:1527272313945};\\\", \\\"{x:1455,y:907,t:1527272313962};\\\", \\\"{x:1456,y:906,t:1527272313979};\\\", \\\"{x:1457,y:905,t:1527272313995};\\\", \\\"{x:1456,y:902,t:1527272314012};\\\", \\\"{x:1435,y:895,t:1527272314029};\\\", \\\"{x:1399,y:878,t:1527272314045};\\\", \\\"{x:1367,y:866,t:1527272314062};\\\", \\\"{x:1350,y:864,t:1527272314079};\\\", \\\"{x:1343,y:864,t:1527272314095};\\\", \\\"{x:1336,y:866,t:1527272314111};\\\", \\\"{x:1330,y:876,t:1527272314129};\\\", \\\"{x:1327,y:892,t:1527272314145};\\\", \\\"{x:1321,y:915,t:1527272314162};\\\", \\\"{x:1315,y:928,t:1527272314179};\\\", \\\"{x:1304,y:934,t:1527272314195};\\\", \\\"{x:1290,y:937,t:1527272314213};\\\", \\\"{x:1283,y:938,t:1527272314229};\\\", \\\"{x:1278,y:939,t:1527272314245};\\\", \\\"{x:1277,y:939,t:1527272314296};\\\", \\\"{x:1276,y:940,t:1527272314327};\\\", \\\"{x:1275,y:942,t:1527272314346};\\\", \\\"{x:1274,y:944,t:1527272314362};\\\", \\\"{x:1273,y:946,t:1527272314379};\\\", \\\"{x:1272,y:948,t:1527272314395};\\\", \\\"{x:1271,y:949,t:1527272314412};\\\", \\\"{x:1269,y:951,t:1527272314429};\\\", \\\"{x:1266,y:954,t:1527272314446};\\\", \\\"{x:1264,y:957,t:1527272314462};\\\", \\\"{x:1260,y:960,t:1527272314478};\\\", \\\"{x:1257,y:963,t:1527272314496};\\\", \\\"{x:1255,y:965,t:1527272314512};\\\", \\\"{x:1252,y:965,t:1527272314529};\\\", \\\"{x:1250,y:966,t:1527272314545};\\\", \\\"{x:1248,y:966,t:1527272314562};\\\", \\\"{x:1244,y:967,t:1527272314579};\\\", \\\"{x:1241,y:968,t:1527272314596};\\\", \\\"{x:1233,y:969,t:1527272314612};\\\", \\\"{x:1221,y:970,t:1527272314629};\\\", \\\"{x:1204,y:974,t:1527272314646};\\\", \\\"{x:1190,y:977,t:1527272314663};\\\", \\\"{x:1178,y:979,t:1527272314679};\\\", \\\"{x:1165,y:983,t:1527272314696};\\\", \\\"{x:1155,y:985,t:1527272314713};\\\", \\\"{x:1145,y:988,t:1527272314729};\\\", \\\"{x:1137,y:990,t:1527272314746};\\\", \\\"{x:1131,y:991,t:1527272314762};\\\", \\\"{x:1121,y:992,t:1527272314779};\\\", \\\"{x:1112,y:993,t:1527272314796};\\\", \\\"{x:1105,y:993,t:1527272314812};\\\", \\\"{x:1100,y:993,t:1527272314829};\\\", \\\"{x:1098,y:993,t:1527272314846};\\\", \\\"{x:1097,y:993,t:1527272314872};\\\", \\\"{x:1096,y:993,t:1527272314879};\\\", \\\"{x:1094,y:987,t:1527272314896};\\\", \\\"{x:1093,y:980,t:1527272314913};\\\", \\\"{x:1093,y:952,t:1527272314929};\\\", \\\"{x:1095,y:929,t:1527272314946};\\\", \\\"{x:1095,y:924,t:1527272314963};\\\", \\\"{x:1095,y:919,t:1527272314979};\\\", \\\"{x:1097,y:915,t:1527272314996};\\\", \\\"{x:1098,y:914,t:1527272315013};\\\", \\\"{x:1099,y:912,t:1527272315029};\\\", \\\"{x:1099,y:911,t:1527272315046};\\\", \\\"{x:1101,y:911,t:1527272315063};\\\", \\\"{x:1104,y:910,t:1527272315079};\\\", \\\"{x:1107,y:908,t:1527272315096};\\\", \\\"{x:1111,y:907,t:1527272315113};\\\", \\\"{x:1115,y:905,t:1527272315129};\\\", \\\"{x:1120,y:905,t:1527272315146};\\\", \\\"{x:1130,y:905,t:1527272315163};\\\", \\\"{x:1143,y:913,t:1527272315178};\\\", \\\"{x:1155,y:920,t:1527272315195};\\\", \\\"{x:1169,y:927,t:1527272315213};\\\", \\\"{x:1184,y:936,t:1527272315229};\\\", \\\"{x:1199,y:945,t:1527272315246};\\\", \\\"{x:1207,y:950,t:1527272315263};\\\", \\\"{x:1209,y:951,t:1527272315278};\\\", \\\"{x:1208,y:953,t:1527272315311};\\\", \\\"{x:1207,y:953,t:1527272315319};\\\", \\\"{x:1204,y:955,t:1527272315329};\\\", \\\"{x:1199,y:957,t:1527272315345};\\\", \\\"{x:1195,y:958,t:1527272315363};\\\", \\\"{x:1191,y:960,t:1527272315380};\\\", \\\"{x:1188,y:961,t:1527272315395};\\\", \\\"{x:1187,y:962,t:1527272315413};\\\", \\\"{x:1187,y:964,t:1527272315439};\\\", \\\"{x:1186,y:967,t:1527272315448};\\\", \\\"{x:1186,y:969,t:1527272315463};\\\", \\\"{x:1186,y:974,t:1527272315480};\\\", \\\"{x:1190,y:976,t:1527272315496};\\\", \\\"{x:1202,y:976,t:1527272315513};\\\", \\\"{x:1228,y:976,t:1527272315529};\\\", \\\"{x:1255,y:976,t:1527272315546};\\\", \\\"{x:1285,y:971,t:1527272315563};\\\", \\\"{x:1315,y:962,t:1527272315580};\\\", \\\"{x:1340,y:956,t:1527272315596};\\\", \\\"{x:1365,y:949,t:1527272315612};\\\", \\\"{x:1384,y:943,t:1527272315630};\\\", \\\"{x:1395,y:939,t:1527272315646};\\\", \\\"{x:1403,y:938,t:1527272315663};\\\", \\\"{x:1409,y:935,t:1527272315679};\\\", \\\"{x:1410,y:935,t:1527272315696};\\\", \\\"{x:1412,y:935,t:1527272315713};\\\", \\\"{x:1413,y:935,t:1527272315730};\\\", \\\"{x:1414,y:936,t:1527272315792};\\\", \\\"{x:1414,y:942,t:1527272315800};\\\", \\\"{x:1414,y:948,t:1527272315813};\\\", \\\"{x:1416,y:959,t:1527272315830};\\\", \\\"{x:1419,y:968,t:1527272315848};\\\", \\\"{x:1421,y:973,t:1527272315864};\\\", \\\"{x:1422,y:975,t:1527272315880};\\\", \\\"{x:1424,y:975,t:1527272315928};\\\", \\\"{x:1428,y:976,t:1527272315935};\\\", \\\"{x:1433,y:977,t:1527272315947};\\\", \\\"{x:1444,y:977,t:1527272315963};\\\", \\\"{x:1456,y:977,t:1527272315980};\\\", \\\"{x:1461,y:977,t:1527272315997};\\\", \\\"{x:1463,y:977,t:1527272316013};\\\", \\\"{x:1464,y:977,t:1527272316031};\\\", \\\"{x:1465,y:977,t:1527272316047};\\\", \\\"{x:1465,y:976,t:1527272316063};\\\", \\\"{x:1467,y:973,t:1527272316079};\\\", \\\"{x:1469,y:970,t:1527272316097};\\\", \\\"{x:1472,y:968,t:1527272316114};\\\", \\\"{x:1474,y:967,t:1527272316130};\\\", \\\"{x:1476,y:966,t:1527272316147};\\\", \\\"{x:1478,y:964,t:1527272316164};\\\", \\\"{x:1480,y:963,t:1527272316180};\\\", \\\"{x:1481,y:962,t:1527272316320};\\\", \\\"{x:1481,y:961,t:1527272316331};\\\", \\\"{x:1483,y:959,t:1527272316347};\\\", \\\"{x:1484,y:957,t:1527272316364};\\\", \\\"{x:1487,y:954,t:1527272316380};\\\", \\\"{x:1488,y:950,t:1527272316397};\\\", \\\"{x:1490,y:948,t:1527272316415};\\\", \\\"{x:1492,y:943,t:1527272316430};\\\", \\\"{x:1494,y:939,t:1527272316448};\\\", \\\"{x:1499,y:930,t:1527272316464};\\\", \\\"{x:1501,y:927,t:1527272316480};\\\", \\\"{x:1503,y:923,t:1527272316497};\\\", \\\"{x:1506,y:916,t:1527272316515};\\\", \\\"{x:1510,y:910,t:1527272316531};\\\", \\\"{x:1516,y:896,t:1527272316548};\\\", \\\"{x:1520,y:891,t:1527272316564};\\\", \\\"{x:1524,y:883,t:1527272316580};\\\", \\\"{x:1529,y:874,t:1527272316597};\\\", \\\"{x:1533,y:867,t:1527272316615};\\\", \\\"{x:1534,y:864,t:1527272316630};\\\", \\\"{x:1536,y:861,t:1527272316647};\\\", \\\"{x:1537,y:860,t:1527272316665};\\\", \\\"{x:1537,y:859,t:1527272317240};\\\", \\\"{x:1538,y:851,t:1527272317248};\\\", \\\"{x:1550,y:815,t:1527272317265};\\\", \\\"{x:1556,y:793,t:1527272317281};\\\", \\\"{x:1560,y:781,t:1527272317298};\\\", \\\"{x:1561,y:775,t:1527272317314};\\\", \\\"{x:1563,y:771,t:1527272317331};\\\", \\\"{x:1564,y:769,t:1527272317348};\\\", \\\"{x:1565,y:767,t:1527272317365};\\\", \\\"{x:1568,y:764,t:1527272317381};\\\", \\\"{x:1570,y:760,t:1527272317399};\\\", \\\"{x:1571,y:757,t:1527272317414};\\\", \\\"{x:1575,y:752,t:1527272317431};\\\", \\\"{x:1583,y:742,t:1527272317448};\\\", \\\"{x:1587,y:738,t:1527272317464};\\\", \\\"{x:1593,y:732,t:1527272317481};\\\", \\\"{x:1597,y:728,t:1527272317499};\\\", \\\"{x:1604,y:723,t:1527272317514};\\\", \\\"{x:1610,y:717,t:1527272317532};\\\", \\\"{x:1618,y:711,t:1527272317548};\\\", \\\"{x:1624,y:706,t:1527272317565};\\\", \\\"{x:1629,y:701,t:1527272317581};\\\", \\\"{x:1630,y:699,t:1527272317598};\\\", \\\"{x:1633,y:696,t:1527272317616};\\\", \\\"{x:1633,y:695,t:1527272317632};\\\", \\\"{x:1634,y:694,t:1527272317648};\\\", \\\"{x:1635,y:693,t:1527272317665};\\\", \\\"{x:1632,y:694,t:1527272317872};\\\", \\\"{x:1629,y:695,t:1527272317882};\\\", \\\"{x:1625,y:698,t:1527272317898};\\\", \\\"{x:1621,y:699,t:1527272317915};\\\", \\\"{x:1618,y:701,t:1527272317932};\\\", \\\"{x:1617,y:701,t:1527272317948};\\\", \\\"{x:1615,y:702,t:1527272317964};\\\", \\\"{x:1613,y:704,t:1527272317983};\\\", \\\"{x:1611,y:706,t:1527272317998};\\\", \\\"{x:1610,y:708,t:1527272318015};\\\", \\\"{x:1603,y:721,t:1527272318032};\\\", \\\"{x:1597,y:730,t:1527272318048};\\\", \\\"{x:1590,y:746,t:1527272318065};\\\", \\\"{x:1583,y:758,t:1527272318082};\\\", \\\"{x:1577,y:770,t:1527272318099};\\\", \\\"{x:1569,y:785,t:1527272318116};\\\", \\\"{x:1555,y:808,t:1527272318132};\\\", \\\"{x:1543,y:831,t:1527272318148};\\\", \\\"{x:1528,y:853,t:1527272318166};\\\", \\\"{x:1513,y:871,t:1527272318182};\\\", \\\"{x:1502,y:885,t:1527272318198};\\\", \\\"{x:1481,y:906,t:1527272318216};\\\", \\\"{x:1462,y:919,t:1527272318232};\\\", \\\"{x:1448,y:927,t:1527272318248};\\\", \\\"{x:1435,y:933,t:1527272318265};\\\", \\\"{x:1423,y:941,t:1527272318282};\\\", \\\"{x:1411,y:948,t:1527272318299};\\\", \\\"{x:1403,y:953,t:1527272318315};\\\", \\\"{x:1394,y:960,t:1527272318332};\\\", \\\"{x:1391,y:965,t:1527272318348};\\\", \\\"{x:1390,y:969,t:1527272318366};\\\", \\\"{x:1387,y:972,t:1527272318382};\\\", \\\"{x:1387,y:974,t:1527272318398};\\\", \\\"{x:1386,y:976,t:1527272318414};\\\", \\\"{x:1385,y:977,t:1527272318455};\\\", \\\"{x:1385,y:978,t:1527272318465};\\\", \\\"{x:1384,y:978,t:1527272318481};\\\", \\\"{x:1384,y:979,t:1527272318511};\\\", \\\"{x:1385,y:979,t:1527272318767};\\\", \\\"{x:1393,y:978,t:1527272318782};\\\", \\\"{x:1411,y:970,t:1527272318800};\\\", \\\"{x:1447,y:955,t:1527272318816};\\\", \\\"{x:1473,y:947,t:1527272318832};\\\", \\\"{x:1492,y:943,t:1527272318849};\\\", \\\"{x:1502,y:939,t:1527272318865};\\\", \\\"{x:1504,y:938,t:1527272318882};\\\", \\\"{x:1507,y:938,t:1527272318899};\\\", \\\"{x:1506,y:938,t:1527272319104};\\\", \\\"{x:1504,y:938,t:1527272319116};\\\", \\\"{x:1502,y:940,t:1527272319132};\\\", \\\"{x:1500,y:941,t:1527272319149};\\\", \\\"{x:1500,y:943,t:1527272319166};\\\", \\\"{x:1499,y:945,t:1527272319183};\\\", \\\"{x:1499,y:946,t:1527272319199};\\\", \\\"{x:1497,y:948,t:1527272319216};\\\", \\\"{x:1497,y:949,t:1527272319232};\\\", \\\"{x:1495,y:951,t:1527272319250};\\\", \\\"{x:1495,y:952,t:1527272319266};\\\", \\\"{x:1494,y:953,t:1527272319282};\\\", \\\"{x:1492,y:954,t:1527272319299};\\\", \\\"{x:1491,y:955,t:1527272319316};\\\", \\\"{x:1491,y:956,t:1527272319334};\\\", \\\"{x:1489,y:957,t:1527272319350};\\\", \\\"{x:1488,y:958,t:1527272319366};\\\", \\\"{x:1487,y:959,t:1527272319384};\\\", \\\"{x:1486,y:959,t:1527272319400};\\\", \\\"{x:1485,y:960,t:1527272319440};\\\", \\\"{x:1484,y:960,t:1527272319472};\\\", \\\"{x:1483,y:961,t:1527272319483};\\\", \\\"{x:1482,y:961,t:1527272319503};\\\", \\\"{x:1482,y:960,t:1527272322984};\\\", \\\"{x:1482,y:958,t:1527272322992};\\\", \\\"{x:1482,y:956,t:1527272323004};\\\", \\\"{x:1483,y:954,t:1527272323020};\\\", \\\"{x:1485,y:952,t:1527272323036};\\\", \\\"{x:1486,y:950,t:1527272323053};\\\", \\\"{x:1487,y:948,t:1527272323069};\\\", \\\"{x:1488,y:947,t:1527272323085};\\\", \\\"{x:1489,y:945,t:1527272323103};\\\", \\\"{x:1490,y:941,t:1527272323120};\\\", \\\"{x:1492,y:940,t:1527272323136};\\\", \\\"{x:1492,y:939,t:1527272323168};\\\", \\\"{x:1493,y:938,t:1527272323208};\\\", \\\"{x:1493,y:937,t:1527272323361};\\\", \\\"{x:1496,y:935,t:1527272323370};\\\", \\\"{x:1497,y:933,t:1527272323387};\\\", \\\"{x:1498,y:932,t:1527272323406};\\\", \\\"{x:1499,y:931,t:1527272323420};\\\", \\\"{x:1499,y:930,t:1527272323440};\\\", \\\"{x:1499,y:928,t:1527272324008};\\\", \\\"{x:1503,y:922,t:1527272324020};\\\", \\\"{x:1508,y:910,t:1527272324037};\\\", \\\"{x:1513,y:904,t:1527272324054};\\\", \\\"{x:1517,y:899,t:1527272324069};\\\", \\\"{x:1518,y:897,t:1527272324087};\\\", \\\"{x:1518,y:894,t:1527272326856};\\\", \\\"{x:1509,y:875,t:1527272326872};\\\", \\\"{x:1499,y:858,t:1527272326888};\\\", \\\"{x:1489,y:847,t:1527272326906};\\\", \\\"{x:1481,y:840,t:1527272326923};\\\", \\\"{x:1479,y:838,t:1527272326939};\\\", \\\"{x:1478,y:838,t:1527272326956};\\\", \\\"{x:1478,y:837,t:1527272327000};\\\", \\\"{x:1478,y:835,t:1527272327024};\\\", \\\"{x:1478,y:834,t:1527272327296};\\\", \\\"{x:1475,y:835,t:1527272327713};\\\", \\\"{x:1472,y:839,t:1527272327727};\\\", \\\"{x:1471,y:842,t:1527272327740};\\\", \\\"{x:1467,y:847,t:1527272327757};\\\", \\\"{x:1464,y:854,t:1527272327773};\\\", \\\"{x:1463,y:856,t:1527272327789};\\\", \\\"{x:1461,y:859,t:1527272327807};\\\", \\\"{x:1459,y:862,t:1527272327823};\\\", \\\"{x:1452,y:874,t:1527272327839};\\\", \\\"{x:1449,y:881,t:1527272327857};\\\", \\\"{x:1445,y:887,t:1527272327873};\\\", \\\"{x:1439,y:897,t:1527272327890};\\\", \\\"{x:1436,y:901,t:1527272327907};\\\", \\\"{x:1433,y:907,t:1527272327923};\\\", \\\"{x:1430,y:911,t:1527272327940};\\\", \\\"{x:1428,y:914,t:1527272327957};\\\", \\\"{x:1425,y:917,t:1527272327973};\\\", \\\"{x:1420,y:925,t:1527272327990};\\\", \\\"{x:1416,y:936,t:1527272328007};\\\", \\\"{x:1412,y:949,t:1527272328022};\\\", \\\"{x:1407,y:958,t:1527272328039};\\\", \\\"{x:1406,y:960,t:1527272328056};\\\", \\\"{x:1405,y:961,t:1527272328072};\\\", \\\"{x:1405,y:962,t:1527272328103};\\\", \\\"{x:1403,y:964,t:1527272328119};\\\", \\\"{x:1403,y:965,t:1527272328168};\\\", \\\"{x:1404,y:964,t:1527272328928};\\\", \\\"{x:1404,y:963,t:1527272328940};\\\", \\\"{x:1406,y:961,t:1527272328957};\\\", \\\"{x:1410,y:959,t:1527272329471};\\\", \\\"{x:1421,y:952,t:1527272329480};\\\", \\\"{x:1435,y:944,t:1527272329491};\\\", \\\"{x:1462,y:924,t:1527272329508};\\\", \\\"{x:1470,y:917,t:1527272329525};\\\", \\\"{x:1478,y:911,t:1527272329541};\\\", \\\"{x:1480,y:908,t:1527272329557};\\\", \\\"{x:1480,y:910,t:1527272329624};\\\", \\\"{x:1480,y:925,t:1527272329641};\\\", \\\"{x:1480,y:944,t:1527272329658};\\\", \\\"{x:1480,y:961,t:1527272329675};\\\", \\\"{x:1480,y:972,t:1527272329691};\\\", \\\"{x:1480,y:976,t:1527272329707};\\\", \\\"{x:1480,y:978,t:1527272329724};\\\", \\\"{x:1480,y:971,t:1527272329847};\\\", \\\"{x:1480,y:959,t:1527272329857};\\\", \\\"{x:1484,y:935,t:1527272329875};\\\", \\\"{x:1484,y:911,t:1527272329891};\\\", \\\"{x:1484,y:896,t:1527272329908};\\\", \\\"{x:1487,y:887,t:1527272329925};\\\", \\\"{x:1489,y:880,t:1527272329942};\\\", \\\"{x:1490,y:876,t:1527272329957};\\\", \\\"{x:1491,y:875,t:1527272329974};\\\", \\\"{x:1491,y:874,t:1527272329992};\\\", \\\"{x:1491,y:872,t:1527272330007};\\\", \\\"{x:1491,y:871,t:1527272330025};\\\", \\\"{x:1491,y:869,t:1527272330042};\\\", \\\"{x:1491,y:868,t:1527272330058};\\\", \\\"{x:1491,y:865,t:1527272330075};\\\", \\\"{x:1491,y:861,t:1527272330092};\\\", \\\"{x:1491,y:858,t:1527272330107};\\\", \\\"{x:1491,y:856,t:1527272330124};\\\", \\\"{x:1491,y:854,t:1527272330142};\\\", \\\"{x:1490,y:853,t:1527272330157};\\\", \\\"{x:1489,y:851,t:1527272330174};\\\", \\\"{x:1488,y:850,t:1527272330191};\\\", \\\"{x:1487,y:849,t:1527272330207};\\\", \\\"{x:1487,y:848,t:1527272330224};\\\", \\\"{x:1486,y:847,t:1527272330241};\\\", \\\"{x:1485,y:846,t:1527272330257};\\\", \\\"{x:1485,y:844,t:1527272330274};\\\", \\\"{x:1485,y:841,t:1527272330291};\\\", \\\"{x:1484,y:840,t:1527272330308};\\\", \\\"{x:1484,y:838,t:1527272330325};\\\", \\\"{x:1484,y:837,t:1527272330343};\\\", \\\"{x:1484,y:836,t:1527272332623};\\\", \\\"{x:1483,y:836,t:1527272332631};\\\", \\\"{x:1481,y:836,t:1527272332662};\\\", \\\"{x:1480,y:836,t:1527272332711};\\\", \\\"{x:1475,y:836,t:1527272334240};\\\", \\\"{x:1469,y:834,t:1527272334247};\\\", \\\"{x:1461,y:830,t:1527272334261};\\\", \\\"{x:1433,y:819,t:1527272334278};\\\", \\\"{x:1374,y:795,t:1527272334295};\\\", \\\"{x:1343,y:786,t:1527272334311};\\\", \\\"{x:1320,y:778,t:1527272334328};\\\", \\\"{x:1309,y:775,t:1527272334345};\\\", \\\"{x:1308,y:774,t:1527272334362};\\\", \\\"{x:1309,y:773,t:1527272334472};\\\", \\\"{x:1312,y:772,t:1527272334479};\\\", \\\"{x:1316,y:771,t:1527272334496};\\\", \\\"{x:1323,y:769,t:1527272334512};\\\", \\\"{x:1327,y:768,t:1527272334527};\\\", \\\"{x:1330,y:766,t:1527272334545};\\\", \\\"{x:1331,y:765,t:1527272334561};\\\", \\\"{x:1332,y:765,t:1527272334577};\\\", \\\"{x:1333,y:765,t:1527272334594};\\\", \\\"{x:1334,y:764,t:1527272334611};\\\", \\\"{x:1335,y:763,t:1527272334695};\\\", \\\"{x:1338,y:766,t:1527272335048};\\\", \\\"{x:1339,y:770,t:1527272335062};\\\", \\\"{x:1339,y:772,t:1527272335079};\\\", \\\"{x:1339,y:774,t:1527272335096};\\\", \\\"{x:1339,y:775,t:1527272335111};\\\", \\\"{x:1339,y:776,t:1527272335129};\\\", \\\"{x:1339,y:777,t:1527272335152};\\\", \\\"{x:1340,y:778,t:1527272335162};\\\", \\\"{x:1340,y:781,t:1527272335179};\\\", \\\"{x:1341,y:783,t:1527272335196};\\\", \\\"{x:1341,y:785,t:1527272335212};\\\", \\\"{x:1341,y:787,t:1527272335229};\\\", \\\"{x:1342,y:789,t:1527272335245};\\\", \\\"{x:1342,y:790,t:1527272335261};\\\", \\\"{x:1342,y:792,t:1527272335278};\\\", \\\"{x:1342,y:793,t:1527272335296};\\\", \\\"{x:1342,y:795,t:1527272335311};\\\", \\\"{x:1342,y:798,t:1527272335328};\\\", \\\"{x:1343,y:801,t:1527272335345};\\\", \\\"{x:1343,y:802,t:1527272335362};\\\", \\\"{x:1343,y:803,t:1527272335379};\\\", \\\"{x:1343,y:805,t:1527272335396};\\\", \\\"{x:1343,y:806,t:1527272335411};\\\", \\\"{x:1343,y:807,t:1527272335428};\\\", \\\"{x:1343,y:808,t:1527272335776};\\\", \\\"{x:1343,y:809,t:1527272335784};\\\", \\\"{x:1343,y:812,t:1527272335796};\\\", \\\"{x:1340,y:817,t:1527272335813};\\\", \\\"{x:1336,y:821,t:1527272335829};\\\", \\\"{x:1333,y:826,t:1527272335846};\\\", \\\"{x:1330,y:829,t:1527272335863};\\\", \\\"{x:1320,y:840,t:1527272335879};\\\", \\\"{x:1309,y:849,t:1527272335895};\\\", \\\"{x:1296,y:861,t:1527272335913};\\\", \\\"{x:1278,y:874,t:1527272335929};\\\", \\\"{x:1262,y:882,t:1527272335946};\\\", \\\"{x:1251,y:887,t:1527272335963};\\\", \\\"{x:1245,y:890,t:1527272335980};\\\", \\\"{x:1240,y:892,t:1527272335996};\\\", \\\"{x:1236,y:894,t:1527272336013};\\\", \\\"{x:1231,y:897,t:1527272336029};\\\", \\\"{x:1225,y:900,t:1527272336046};\\\", \\\"{x:1211,y:906,t:1527272336063};\\\", \\\"{x:1201,y:909,t:1527272336080};\\\", \\\"{x:1190,y:913,t:1527272336096};\\\", \\\"{x:1178,y:916,t:1527272336112};\\\", \\\"{x:1168,y:919,t:1527272336129};\\\", \\\"{x:1155,y:920,t:1527272336146};\\\", \\\"{x:1142,y:923,t:1527272336163};\\\", \\\"{x:1133,y:925,t:1527272336180};\\\", \\\"{x:1122,y:926,t:1527272336196};\\\", \\\"{x:1116,y:928,t:1527272336213};\\\", \\\"{x:1111,y:929,t:1527272336230};\\\", \\\"{x:1109,y:929,t:1527272336246};\\\", \\\"{x:1110,y:929,t:1527272337118};\\\", \\\"{x:1117,y:925,t:1527272339880};\\\", \\\"{x:1135,y:900,t:1527272339887};\\\", \\\"{x:1163,y:858,t:1527272339899};\\\", \\\"{x:1230,y:756,t:1527272339916};\\\", \\\"{x:1275,y:691,t:1527272339932};\\\", \\\"{x:1325,y:646,t:1527272339949};\\\", \\\"{x:1387,y:599,t:1527272339966};\\\", \\\"{x:1449,y:555,t:1527272339982};\\\", \\\"{x:1481,y:535,t:1527272339999};\\\", \\\"{x:1485,y:533,t:1527272340015};\\\", \\\"{x:1488,y:536,t:1527272340048};\\\", \\\"{x:1494,y:549,t:1527272340056};\\\", \\\"{x:1501,y:569,t:1527272340066};\\\", \\\"{x:1516,y:612,t:1527272340083};\\\", \\\"{x:1523,y:623,t:1527272340099};\\\", \\\"{x:1524,y:623,t:1527272340116};\\\", \\\"{x:1529,y:621,t:1527272340133};\\\", \\\"{x:1533,y:619,t:1527272340149};\\\", \\\"{x:1534,y:618,t:1527272340166};\\\", \\\"{x:1533,y:624,t:1527272340328};\\\", \\\"{x:1530,y:635,t:1527272340335};\\\", \\\"{x:1529,y:643,t:1527272340349};\\\", \\\"{x:1528,y:645,t:1527272340366};\\\", \\\"{x:1528,y:646,t:1527272340423};\\\", \\\"{x:1526,y:647,t:1527272340433};\\\", \\\"{x:1526,y:652,t:1527272340450};\\\", \\\"{x:1526,y:656,t:1527272340467};\\\", \\\"{x:1526,y:660,t:1527272340484};\\\", \\\"{x:1525,y:660,t:1527272340500};\\\", \\\"{x:1525,y:661,t:1527272340516};\\\", \\\"{x:1525,y:663,t:1527272340543};\\\", \\\"{x:1525,y:666,t:1527272340551};\\\", \\\"{x:1523,y:670,t:1527272340566};\\\", \\\"{x:1516,y:685,t:1527272340583};\\\", \\\"{x:1510,y:700,t:1527272340599};\\\", \\\"{x:1502,y:716,t:1527272340616};\\\", \\\"{x:1498,y:727,t:1527272340632};\\\", \\\"{x:1495,y:738,t:1527272340649};\\\", \\\"{x:1491,y:750,t:1527272340666};\\\", \\\"{x:1490,y:760,t:1527272340683};\\\", \\\"{x:1486,y:769,t:1527272340700};\\\", \\\"{x:1486,y:776,t:1527272340716};\\\", \\\"{x:1486,y:783,t:1527272340732};\\\", \\\"{x:1484,y:788,t:1527272340750};\\\", \\\"{x:1483,y:793,t:1527272340765};\\\", \\\"{x:1483,y:799,t:1527272340783};\\\", \\\"{x:1483,y:804,t:1527272340800};\\\", \\\"{x:1490,y:814,t:1527272340816};\\\", \\\"{x:1495,y:820,t:1527272340833};\\\", \\\"{x:1499,y:825,t:1527272340850};\\\", \\\"{x:1509,y:835,t:1527272340866};\\\", \\\"{x:1529,y:848,t:1527272340883};\\\", \\\"{x:1563,y:873,t:1527272340900};\\\", \\\"{x:1612,y:905,t:1527272340917};\\\", \\\"{x:1654,y:922,t:1527272340932};\\\", \\\"{x:1693,y:934,t:1527272340949};\\\", \\\"{x:1735,y:941,t:1527272340967};\\\", \\\"{x:1747,y:941,t:1527272340983};\\\", \\\"{x:1743,y:941,t:1527272341039};\\\", \\\"{x:1733,y:935,t:1527272341050};\\\", \\\"{x:1686,y:912,t:1527272341067};\\\", \\\"{x:1636,y:890,t:1527272341083};\\\", \\\"{x:1602,y:878,t:1527272341101};\\\", \\\"{x:1581,y:870,t:1527272341117};\\\", \\\"{x:1558,y:863,t:1527272341133};\\\", \\\"{x:1535,y:861,t:1527272341150};\\\", \\\"{x:1507,y:857,t:1527272341166};\\\", \\\"{x:1490,y:856,t:1527272341182};\\\", \\\"{x:1482,y:856,t:1527272341199};\\\", \\\"{x:1479,y:856,t:1527272341217};\\\", \\\"{x:1478,y:856,t:1527272341344};\\\", \\\"{x:1477,y:856,t:1527272341351};\\\", \\\"{x:1477,y:855,t:1527272341472};\\\", \\\"{x:1477,y:854,t:1527272341485};\\\", \\\"{x:1477,y:852,t:1527272341501};\\\", \\\"{x:1479,y:849,t:1527272341518};\\\", \\\"{x:1481,y:847,t:1527272341534};\\\", \\\"{x:1482,y:847,t:1527272341550};\\\", \\\"{x:1483,y:846,t:1527272341567};\\\", \\\"{x:1483,y:845,t:1527272341591};\\\", \\\"{x:1485,y:844,t:1527272341607};\\\", \\\"{x:1485,y:841,t:1527272341623};\\\", \\\"{x:1486,y:840,t:1527272341640};\\\", \\\"{x:1486,y:839,t:1527272341655};\\\", \\\"{x:1486,y:838,t:1527272341668};\\\", \\\"{x:1486,y:836,t:1527272345776};\\\", \\\"{x:1486,y:835,t:1527272345788};\\\", \\\"{x:1486,y:833,t:1527272345805};\\\", \\\"{x:1486,y:831,t:1527272345821};\\\", \\\"{x:1486,y:830,t:1527272345855};\\\", \\\"{x:1486,y:829,t:1527272345870};\\\", \\\"{x:1485,y:829,t:1527272346103};\\\", \\\"{x:1484,y:829,t:1527272346120};\\\", \\\"{x:1483,y:829,t:1527272346143};\\\", \\\"{x:1482,y:829,t:1527272346183};\\\", \\\"{x:1478,y:830,t:1527272347184};\\\", \\\"{x:1470,y:833,t:1527272347192};\\\", \\\"{x:1462,y:833,t:1527272347205};\\\", \\\"{x:1442,y:834,t:1527272347222};\\\", \\\"{x:1412,y:834,t:1527272347239};\\\", \\\"{x:1404,y:834,t:1527272347256};\\\", \\\"{x:1403,y:834,t:1527272347271};\\\", \\\"{x:1402,y:834,t:1527272347327};\\\", \\\"{x:1401,y:834,t:1527272347338};\\\", \\\"{x:1394,y:831,t:1527272347355};\\\", \\\"{x:1383,y:824,t:1527272347371};\\\", \\\"{x:1376,y:819,t:1527272347389};\\\", \\\"{x:1370,y:810,t:1527272347405};\\\", \\\"{x:1364,y:801,t:1527272347422};\\\", \\\"{x:1358,y:791,t:1527272347439};\\\", \\\"{x:1349,y:777,t:1527272347456};\\\", \\\"{x:1345,y:770,t:1527272347471};\\\", \\\"{x:1342,y:763,t:1527272347489};\\\", \\\"{x:1342,y:761,t:1527272347507};\\\", \\\"{x:1341,y:759,t:1527272347522};\\\", \\\"{x:1341,y:757,t:1527272347539};\\\", \\\"{x:1341,y:756,t:1527272347556};\\\", \\\"{x:1341,y:754,t:1527272347572};\\\", \\\"{x:1340,y:750,t:1527272347588};\\\", \\\"{x:1340,y:748,t:1527272347608};\\\", \\\"{x:1340,y:747,t:1527272347848};\\\", \\\"{x:1343,y:746,t:1527272347855};\\\", \\\"{x:1348,y:742,t:1527272347873};\\\", \\\"{x:1352,y:740,t:1527272347888};\\\", \\\"{x:1354,y:736,t:1527272347905};\\\", \\\"{x:1355,y:732,t:1527272347923};\\\", \\\"{x:1357,y:725,t:1527272347939};\\\", \\\"{x:1359,y:715,t:1527272347955};\\\", \\\"{x:1359,y:710,t:1527272347973};\\\", \\\"{x:1359,y:707,t:1527272347990};\\\", \\\"{x:1359,y:704,t:1527272348006};\\\", \\\"{x:1359,y:702,t:1527272348022};\\\", \\\"{x:1359,y:699,t:1527272348039};\\\", \\\"{x:1359,y:697,t:1527272348055};\\\", \\\"{x:1358,y:695,t:1527272348073};\\\", \\\"{x:1356,y:694,t:1527272348090};\\\", \\\"{x:1354,y:693,t:1527272348106};\\\", \\\"{x:1351,y:691,t:1527272348122};\\\", \\\"{x:1350,y:691,t:1527272348140};\\\", \\\"{x:1349,y:691,t:1527272349601};\\\", \\\"{x:1347,y:693,t:1527272349607};\\\", \\\"{x:1343,y:721,t:1527272349623};\\\", \\\"{x:1340,y:743,t:1527272349640};\\\", \\\"{x:1339,y:758,t:1527272349656};\\\", \\\"{x:1338,y:763,t:1527272349673};\\\", \\\"{x:1337,y:765,t:1527272349690};\\\", \\\"{x:1337,y:767,t:1527272349710};\\\", \\\"{x:1337,y:768,t:1527272349726};\\\", \\\"{x:1337,y:771,t:1527272349740};\\\", \\\"{x:1337,y:774,t:1527272349757};\\\", \\\"{x:1336,y:779,t:1527272349773};\\\", \\\"{x:1334,y:783,t:1527272349790};\\\", \\\"{x:1334,y:784,t:1527272349807};\\\", \\\"{x:1334,y:786,t:1527272349823};\\\", \\\"{x:1334,y:788,t:1527272349840};\\\", \\\"{x:1333,y:791,t:1527272349857};\\\", \\\"{x:1333,y:795,t:1527272349873};\\\", \\\"{x:1332,y:800,t:1527272349890};\\\", \\\"{x:1331,y:806,t:1527272349907};\\\", \\\"{x:1331,y:810,t:1527272349924};\\\", \\\"{x:1331,y:814,t:1527272349940};\\\", \\\"{x:1331,y:818,t:1527272349958};\\\", \\\"{x:1331,y:820,t:1527272349973};\\\", \\\"{x:1331,y:821,t:1527272349991};\\\", \\\"{x:1331,y:822,t:1527272350119};\\\", \\\"{x:1333,y:822,t:1527272350128};\\\", \\\"{x:1336,y:822,t:1527272350140};\\\", \\\"{x:1347,y:813,t:1527272350157};\\\", \\\"{x:1353,y:804,t:1527272350174};\\\", \\\"{x:1357,y:795,t:1527272350191};\\\", \\\"{x:1359,y:789,t:1527272350208};\\\", \\\"{x:1360,y:787,t:1527272350224};\\\", \\\"{x:1360,y:785,t:1527272350239};\\\", \\\"{x:1361,y:785,t:1527272350257};\\\", \\\"{x:1361,y:784,t:1527272350274};\\\", \\\"{x:1361,y:783,t:1527272350291};\\\", \\\"{x:1361,y:781,t:1527272350307};\\\", \\\"{x:1361,y:780,t:1527272350324};\\\", \\\"{x:1361,y:778,t:1527272350340};\\\", \\\"{x:1361,y:776,t:1527272350358};\\\", \\\"{x:1361,y:775,t:1527272350374};\\\", \\\"{x:1361,y:774,t:1527272350415};\\\", \\\"{x:1361,y:773,t:1527272350456};\\\", \\\"{x:1361,y:772,t:1527272350479};\\\", \\\"{x:1361,y:771,t:1527272350503};\\\", \\\"{x:1360,y:770,t:1527272350511};\\\", \\\"{x:1359,y:769,t:1527272350525};\\\", \\\"{x:1355,y:766,t:1527272350541};\\\", \\\"{x:1352,y:765,t:1527272350558};\\\", \\\"{x:1350,y:764,t:1527272350574};\\\", \\\"{x:1347,y:763,t:1527272350590};\\\", \\\"{x:1346,y:763,t:1527272350776};\\\", \\\"{x:1342,y:764,t:1527272350791};\\\", \\\"{x:1336,y:766,t:1527272350808};\\\", \\\"{x:1316,y:772,t:1527272350824};\\\", \\\"{x:1273,y:777,t:1527272350841};\\\", \\\"{x:1165,y:779,t:1527272350857};\\\", \\\"{x:1029,y:779,t:1527272350874};\\\", \\\"{x:894,y:779,t:1527272350891};\\\", \\\"{x:750,y:763,t:1527272350907};\\\", \\\"{x:612,y:746,t:1527272350924};\\\", \\\"{x:504,y:732,t:1527272350942};\\\", \\\"{x:447,y:719,t:1527272350957};\\\", \\\"{x:421,y:714,t:1527272350975};\\\", \\\"{x:419,y:714,t:1527272351031};\\\", \\\"{x:417,y:712,t:1527272351042};\\\", \\\"{x:409,y:702,t:1527272351059};\\\", \\\"{x:395,y:688,t:1527272351075};\\\", \\\"{x:381,y:672,t:1527272351093};\\\", \\\"{x:370,y:657,t:1527272351108};\\\", \\\"{x:365,y:645,t:1527272351125};\\\", \\\"{x:361,y:628,t:1527272351143};\\\", \\\"{x:360,y:615,t:1527272351158};\\\", \\\"{x:358,y:601,t:1527272351176};\\\", \\\"{x:356,y:587,t:1527272351192};\\\", \\\"{x:354,y:572,t:1527272351209};\\\", \\\"{x:354,y:563,t:1527272351226};\\\", \\\"{x:354,y:559,t:1527272351242};\\\", \\\"{x:355,y:556,t:1527272351258};\\\", \\\"{x:356,y:555,t:1527272351275};\\\", \\\"{x:356,y:552,t:1527272351292};\\\", \\\"{x:356,y:546,t:1527272351308};\\\", \\\"{x:356,y:544,t:1527272351325};\\\", \\\"{x:356,y:543,t:1527272351719};\\\", \\\"{x:356,y:542,t:1527272351726};\\\", \\\"{x:354,y:542,t:1527272351742};\\\", \\\"{x:345,y:544,t:1527272351759};\\\", \\\"{x:336,y:547,t:1527272351775};\\\", \\\"{x:324,y:550,t:1527272351793};\\\", \\\"{x:309,y:553,t:1527272351809};\\\", \\\"{x:292,y:559,t:1527272351827};\\\", \\\"{x:281,y:562,t:1527272351842};\\\", \\\"{x:268,y:562,t:1527272351861};\\\", \\\"{x:252,y:563,t:1527272351876};\\\", \\\"{x:233,y:566,t:1527272351893};\\\", \\\"{x:225,y:567,t:1527272351910};\\\", \\\"{x:214,y:570,t:1527272351928};\\\", \\\"{x:209,y:572,t:1527272351943};\\\", \\\"{x:207,y:572,t:1527272351958};\\\", \\\"{x:204,y:572,t:1527272351976};\\\", \\\"{x:199,y:572,t:1527272351992};\\\", \\\"{x:186,y:572,t:1527272352010};\\\", \\\"{x:170,y:570,t:1527272352026};\\\", \\\"{x:147,y:564,t:1527272352044};\\\", \\\"{x:126,y:558,t:1527272352059};\\\", \\\"{x:116,y:554,t:1527272352076};\\\", \\\"{x:113,y:553,t:1527272352092};\\\", \\\"{x:112,y:552,t:1527272352135};\\\", \\\"{x:114,y:551,t:1527272352240};\\\", \\\"{x:117,y:550,t:1527272352247};\\\", \\\"{x:122,y:548,t:1527272352259};\\\", \\\"{x:130,y:544,t:1527272352276};\\\", \\\"{x:134,y:544,t:1527272352292};\\\", \\\"{x:136,y:541,t:1527272352310};\\\", \\\"{x:137,y:541,t:1527272352327};\\\", \\\"{x:138,y:541,t:1527272352440};\\\", \\\"{x:140,y:541,t:1527272352471};\\\", \\\"{x:141,y:542,t:1527272352479};\\\", \\\"{x:142,y:542,t:1527272352493};\\\", \\\"{x:144,y:544,t:1527272352510};\\\", \\\"{x:145,y:547,t:1527272352527};\\\", \\\"{x:145,y:548,t:1527272352543};\\\", \\\"{x:147,y:548,t:1527272352559};\\\", \\\"{x:150,y:548,t:1527272353263};\\\", \\\"{x:151,y:548,t:1527272353277};\\\", \\\"{x:153,y:548,t:1527272353292};\\\", \\\"{x:155,y:548,t:1527272353310};\\\", \\\"{x:157,y:547,t:1527272353327};\\\", \\\"{x:159,y:546,t:1527272353344};\\\", \\\"{x:161,y:545,t:1527272353360};\\\", \\\"{x:163,y:544,t:1527272353377};\\\", \\\"{x:170,y:541,t:1527272353395};\\\", \\\"{x:186,y:534,t:1527272353411};\\\", \\\"{x:210,y:524,t:1527272353428};\\\", \\\"{x:244,y:515,t:1527272353443};\\\", \\\"{x:278,y:510,t:1527272353461};\\\", \\\"{x:306,y:505,t:1527272353477};\\\", \\\"{x:324,y:504,t:1527272353494};\\\", \\\"{x:326,y:504,t:1527272353510};\\\", \\\"{x:329,y:504,t:1527272353647};\\\", \\\"{x:335,y:507,t:1527272353661};\\\", \\\"{x:369,y:530,t:1527272353677};\\\", \\\"{x:488,y:573,t:1527272353695};\\\", \\\"{x:572,y:588,t:1527272353712};\\\", \\\"{x:660,y:596,t:1527272353727};\\\", \\\"{x:746,y:596,t:1527272353746};\\\", \\\"{x:803,y:594,t:1527272353760};\\\", \\\"{x:824,y:587,t:1527272353778};\\\", \\\"{x:830,y:584,t:1527272353794};\\\", \\\"{x:829,y:581,t:1527272353812};\\\", \\\"{x:820,y:575,t:1527272353828};\\\", \\\"{x:805,y:568,t:1527272353846};\\\", \\\"{x:796,y:564,t:1527272353862};\\\", \\\"{x:780,y:560,t:1527272353877};\\\", \\\"{x:741,y:550,t:1527272353894};\\\", \\\"{x:713,y:549,t:1527272353914};\\\", \\\"{x:684,y:549,t:1527272353927};\\\", \\\"{x:657,y:549,t:1527272353944};\\\", \\\"{x:630,y:549,t:1527272353961};\\\", \\\"{x:608,y:550,t:1527272353977};\\\", \\\"{x:593,y:555,t:1527272353994};\\\", \\\"{x:584,y:559,t:1527272354011};\\\", \\\"{x:580,y:564,t:1527272354027};\\\", \\\"{x:573,y:576,t:1527272354045};\\\", \\\"{x:567,y:583,t:1527272354061};\\\", \\\"{x:565,y:587,t:1527272354077};\\\", \\\"{x:561,y:595,t:1527272354094};\\\", \\\"{x:559,y:602,t:1527272354112};\\\", \\\"{x:558,y:611,t:1527272354128};\\\", \\\"{x:554,y:622,t:1527272354145};\\\", \\\"{x:549,y:632,t:1527272354161};\\\", \\\"{x:542,y:647,t:1527272354177};\\\", \\\"{x:538,y:652,t:1527272354195};\\\", \\\"{x:527,y:660,t:1527272354211};\\\", \\\"{x:518,y:662,t:1527272354228};\\\", \\\"{x:512,y:662,t:1527272354245};\\\", \\\"{x:510,y:662,t:1527272354261};\\\", \\\"{x:521,y:643,t:1527272354280};\\\", \\\"{x:546,y:621,t:1527272354295};\\\", \\\"{x:594,y:588,t:1527272354312};\\\", \\\"{x:664,y:551,t:1527272354328};\\\", \\\"{x:723,y:523,t:1527272354344};\\\", \\\"{x:761,y:508,t:1527272354362};\\\", \\\"{x:781,y:502,t:1527272354377};\\\", \\\"{x:784,y:501,t:1527272354394};\\\", \\\"{x:785,y:501,t:1527272354430};\\\", \\\"{x:786,y:500,t:1527272354444};\\\", \\\"{x:792,y:500,t:1527272354461};\\\", \\\"{x:805,y:500,t:1527272354478};\\\", \\\"{x:811,y:500,t:1527272354494};\\\", \\\"{x:812,y:500,t:1527272354534};\\\", \\\"{x:812,y:502,t:1527272354545};\\\", \\\"{x:813,y:507,t:1527272354561};\\\", \\\"{x:814,y:509,t:1527272354578};\\\", \\\"{x:815,y:510,t:1527272354594};\\\", \\\"{x:815,y:511,t:1527272354611};\\\", \\\"{x:817,y:512,t:1527272354628};\\\", \\\"{x:821,y:513,t:1527272354644};\\\", \\\"{x:826,y:513,t:1527272354662};\\\", \\\"{x:831,y:514,t:1527272354678};\\\", \\\"{x:833,y:514,t:1527272354727};\\\", \\\"{x:834,y:514,t:1527272354743};\\\", \\\"{x:835,y:514,t:1527272354751};\\\", \\\"{x:833,y:514,t:1527272355743};\\\", \\\"{x:832,y:514,t:1527272355751};\\\", \\\"{x:831,y:516,t:1527272355763};\\\", \\\"{x:830,y:517,t:1527272355780};\\\", \\\"{x:829,y:517,t:1527272355796};\\\", \\\"{x:829,y:520,t:1527272356071};\\\", \\\"{x:831,y:531,t:1527272356080};\\\", \\\"{x:857,y:563,t:1527272356096};\\\", \\\"{x:896,y:599,t:1527272356112};\\\", \\\"{x:963,y:643,t:1527272356130};\\\", \\\"{x:1059,y:696,t:1527272356145};\\\", \\\"{x:1167,y:746,t:1527272356162};\\\", \\\"{x:1277,y:798,t:1527272356179};\\\", \\\"{x:1393,y:844,t:1527272356196};\\\", \\\"{x:1484,y:884,t:1527272356212};\\\", \\\"{x:1541,y:908,t:1527272356229};\\\", \\\"{x:1557,y:914,t:1527272356246};\\\", \\\"{x:1554,y:914,t:1527272356286};\\\", \\\"{x:1548,y:914,t:1527272356296};\\\", \\\"{x:1529,y:905,t:1527272356312};\\\", \\\"{x:1510,y:900,t:1527272356329};\\\", \\\"{x:1494,y:898,t:1527272356346};\\\", \\\"{x:1486,y:898,t:1527272356362};\\\", \\\"{x:1483,y:898,t:1527272356380};\\\", \\\"{x:1481,y:898,t:1527272356397};\\\", \\\"{x:1477,y:899,t:1527272356414};\\\", \\\"{x:1467,y:902,t:1527272356430};\\\", \\\"{x:1431,y:912,t:1527272356447};\\\", \\\"{x:1397,y:924,t:1527272356463};\\\", \\\"{x:1365,y:930,t:1527272356480};\\\", \\\"{x:1340,y:934,t:1527272356497};\\\", \\\"{x:1330,y:936,t:1527272356513};\\\", \\\"{x:1325,y:938,t:1527272356530};\\\", \\\"{x:1325,y:939,t:1527272356559};\\\", \\\"{x:1325,y:941,t:1527272356567};\\\", \\\"{x:1325,y:942,t:1527272356580};\\\", \\\"{x:1325,y:945,t:1527272356597};\\\", \\\"{x:1324,y:948,t:1527272356614};\\\", \\\"{x:1324,y:952,t:1527272356629};\\\", \\\"{x:1324,y:956,t:1527272356647};\\\", \\\"{x:1324,y:958,t:1527272356663};\\\", \\\"{x:1324,y:959,t:1527272356679};\\\", \\\"{x:1324,y:965,t:1527272356696};\\\", \\\"{x:1327,y:972,t:1527272356714};\\\", \\\"{x:1329,y:978,t:1527272356730};\\\", \\\"{x:1332,y:981,t:1527272356746};\\\", \\\"{x:1334,y:983,t:1527272356763};\\\", \\\"{x:1340,y:986,t:1527272356780};\\\", \\\"{x:1345,y:987,t:1527272356796};\\\", \\\"{x:1355,y:988,t:1527272356814};\\\", \\\"{x:1365,y:990,t:1527272356830};\\\", \\\"{x:1390,y:992,t:1527272356846};\\\", \\\"{x:1404,y:992,t:1527272356864};\\\", \\\"{x:1415,y:992,t:1527272356879};\\\", \\\"{x:1428,y:990,t:1527272356897};\\\", \\\"{x:1439,y:983,t:1527272356914};\\\", \\\"{x:1447,y:972,t:1527272356930};\\\", \\\"{x:1457,y:956,t:1527272356946};\\\", \\\"{x:1464,y:941,t:1527272356964};\\\", \\\"{x:1467,y:929,t:1527272356981};\\\", \\\"{x:1471,y:919,t:1527272356997};\\\", \\\"{x:1476,y:909,t:1527272357014};\\\", \\\"{x:1482,y:895,t:1527272357031};\\\", \\\"{x:1485,y:886,t:1527272357047};\\\", \\\"{x:1487,y:876,t:1527272357064};\\\", \\\"{x:1489,y:868,t:1527272357081};\\\", \\\"{x:1489,y:861,t:1527272357097};\\\", \\\"{x:1489,y:856,t:1527272357114};\\\", \\\"{x:1488,y:849,t:1527272357131};\\\", \\\"{x:1485,y:841,t:1527272357147};\\\", \\\"{x:1483,y:837,t:1527272357164};\\\", \\\"{x:1481,y:832,t:1527272357181};\\\", \\\"{x:1480,y:829,t:1527272357197};\\\", \\\"{x:1480,y:827,t:1527272357213};\\\", \\\"{x:1479,y:822,t:1527272357231};\\\", \\\"{x:1479,y:818,t:1527272357247};\\\", \\\"{x:1479,y:817,t:1527272357264};\\\", \\\"{x:1479,y:816,t:1527272357281};\\\", \\\"{x:1478,y:814,t:1527272357311};\\\", \\\"{x:1477,y:814,t:1527272357319};\\\", \\\"{x:1471,y:814,t:1527272357332};\\\", \\\"{x:1441,y:810,t:1527272357348};\\\", \\\"{x:1331,y:796,t:1527272357364};\\\", \\\"{x:1157,y:774,t:1527272357381};\\\", \\\"{x:992,y:763,t:1527272357398};\\\", \\\"{x:837,y:763,t:1527272357414};\\\", \\\"{x:646,y:763,t:1527272357431};\\\", \\\"{x:554,y:757,t:1527272357448};\\\", \\\"{x:495,y:747,t:1527272357463};\\\", \\\"{x:467,y:742,t:1527272357480};\\\", \\\"{x:451,y:741,t:1527272357498};\\\", \\\"{x:447,y:740,t:1527272357513};\\\", \\\"{x:446,y:739,t:1527272357542};\\\", \\\"{x:446,y:733,t:1527272357551};\\\", \\\"{x:446,y:724,t:1527272357564};\\\", \\\"{x:453,y:701,t:1527272357581};\\\", \\\"{x:467,y:676,t:1527272357597};\\\", \\\"{x:488,y:651,t:1527272357614};\\\", \\\"{x:534,y:606,t:1527272357630};\\\", \\\"{x:587,y:561,t:1527272357648};\\\", \\\"{x:640,y:523,t:1527272357664};\\\", \\\"{x:670,y:505,t:1527272357681};\\\", \\\"{x:688,y:493,t:1527272357698};\\\", \\\"{x:693,y:489,t:1527272357713};\\\", \\\"{x:690,y:489,t:1527272357816};\\\", \\\"{x:659,y:504,t:1527272357831};\\\", \\\"{x:616,y:527,t:1527272357847};\\\", \\\"{x:581,y:558,t:1527272357864};\\\", \\\"{x:569,y:580,t:1527272357881};\\\", \\\"{x:565,y:588,t:1527272357897};\\\", \\\"{x:565,y:589,t:1527272357914};\\\", \\\"{x:565,y:591,t:1527272357930};\\\", \\\"{x:565,y:592,t:1527272357947};\\\", \\\"{x:568,y:592,t:1527272358039};\\\", \\\"{x:571,y:592,t:1527272358047};\\\", \\\"{x:580,y:592,t:1527272358064};\\\", \\\"{x:589,y:591,t:1527272358082};\\\", \\\"{x:593,y:589,t:1527272358098};\\\", \\\"{x:598,y:588,t:1527272358114};\\\", \\\"{x:599,y:587,t:1527272358151};\\\", \\\"{x:600,y:587,t:1527272358165};\\\", \\\"{x:604,y:587,t:1527272358182};\\\", \\\"{x:607,y:587,t:1527272358198};\\\", \\\"{x:608,y:587,t:1527272358214};\\\", \\\"{x:608,y:590,t:1527272358430};\\\", \\\"{x:608,y:610,t:1527272358439};\\\", \\\"{x:608,y:644,t:1527272358448};\\\", \\\"{x:606,y:728,t:1527272358465};\\\", \\\"{x:583,y:837,t:1527272358481};\\\", \\\"{x:548,y:912,t:1527272358497};\\\", \\\"{x:531,y:934,t:1527272358515};\\\", \\\"{x:522,y:943,t:1527272358531};\\\", \\\"{x:515,y:952,t:1527272358547};\\\", \\\"{x:513,y:952,t:1527272358564};\\\", \\\"{x:512,y:947,t:1527272358607};\\\", \\\"{x:510,y:936,t:1527272358614};\\\", \\\"{x:506,y:914,t:1527272358631};\\\", \\\"{x:503,y:894,t:1527272358648};\\\", \\\"{x:501,y:884,t:1527272358664};\\\", \\\"{x:501,y:877,t:1527272358682};\\\", \\\"{x:501,y:870,t:1527272358697};\\\", \\\"{x:503,y:861,t:1527272358714};\\\", \\\"{x:508,y:846,t:1527272358732};\\\", \\\"{x:513,y:827,t:1527272358749};\\\", \\\"{x:517,y:808,t:1527272358765};\\\", \\\"{x:519,y:795,t:1527272358782};\\\", \\\"{x:520,y:785,t:1527272358798};\\\", \\\"{x:521,y:778,t:1527272358815};\\\", \\\"{x:521,y:777,t:1527272358832};\\\", \\\"{x:521,y:776,t:1527272358848};\\\", \\\"{x:521,y:775,t:1527272358865};\\\", \\\"{x:522,y:772,t:1527272358882};\\\", \\\"{x:522,y:769,t:1527272358899};\\\", \\\"{x:524,y:768,t:1527272358916};\\\", \\\"{x:525,y:767,t:1527272358932};\\\", \\\"{x:525,y:766,t:1527272358974};\\\", \\\"{x:526,y:765,t:1527272358982};\\\", \\\"{x:528,y:764,t:1527272358997};\\\", \\\"{x:531,y:763,t:1527272359016};\\\", \\\"{x:533,y:761,t:1527272359032};\\\", \\\"{x:535,y:759,t:1527272359048};\\\", \\\"{x:541,y:756,t:1527272359065};\\\", \\\"{x:544,y:753,t:1527272359082};\\\", \\\"{x:543,y:753,t:1527272360183};\\\", \\\"{x:542,y:753,t:1527272360199};\\\" ] }, { \\\"rt\\\": 66944, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 844139, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Looking at the x - axis \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6892, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"US\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 852039, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 23970, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Spanish\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Humanities\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 877032, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 5627, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 883998, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"VB9NP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"VB9NP\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 146, dom: 981, initialDom: 1058",
  "javascriptErrors": []
}