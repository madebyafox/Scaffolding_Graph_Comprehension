var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05155582285df2a06954ff05dcbd107be6729283"] = {
  "startTime": "2018-05-15T21:14:55.1526159Z",
  "websitePageUrl": "/15",
  "visitTime": 92346,
  "engagementTime": 79050,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "b472e3ae576f769127ca44960e6e4ae1",
    "created": "2018-05-15T21:14:55.1526159+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.170",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/15",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=8LGZ4",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "6dfb3265222a9d14a958cb97fd249fa4",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/b472e3ae576f769127ca44960e6e4ae1/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 185,
      "e": 185,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 6200,
      "e": 6200,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11801,
      "e": 11300,
      "ty": 2,
      "x": 510,
      "y": 738
    },
    {
      "t": 11842,
      "e": 11341,
      "ty": 7,
      "x": 506,
      "y": 733,
      "ta": "#start"
    },
    {
      "t": 11901,
      "e": 11400,
      "ty": 2,
      "x": 503,
      "y": 730
    },
    {
      "t": 12000,
      "e": 11499,
      "ty": 2,
      "x": 484,
      "y": 727
    },
    {
      "t": 12000,
      "e": 11499,
      "ty": 41,
      "x": 27852,
      "y": 16977,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 13700,
      "e": 13199,
      "ty": 2,
      "x": 482,
      "y": 725
    },
    {
      "t": 13751,
      "e": 13250,
      "ty": 41,
      "x": 26916,
      "y": 15666,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 14100,
      "e": 13599,
      "ty": 1,
      "x": 0,
      "y": 4
    },
    {
      "t": 14201,
      "e": 13700,
      "ty": 1,
      "x": 0,
      "y": 15
    },
    {
      "t": 14301,
      "e": 13800,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 14314,
      "e": 13813,
      "ty": 6,
      "x": 482,
      "y": 741,
      "ta": "#start"
    },
    {
      "t": 14700,
      "e": 14199,
      "ty": 1,
      "x": 0,
      "y": 10
    },
    {
      "t": 14801,
      "e": 14300,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 14897,
      "e": 14396,
      "ty": 7,
      "x": 482,
      "y": 725,
      "ta": "#start"
    },
    {
      "t": 15000,
      "e": 14499,
      "ty": 1,
      "x": 0,
      "y": 2
    },
    {
      "t": 15101,
      "e": 14600,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 15200,
      "e": 14699,
      "ty": 1,
      "x": 0,
      "y": 15
    },
    {
      "t": 15301,
      "e": 14800,
      "ty": 1,
      "x": 0,
      "y": 3
    },
    {
      "t": 15400,
      "e": 14899,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 15501,
      "e": 15000,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 15601,
      "e": 15100,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 15700,
      "e": 15199,
      "ty": 1,
      "x": 0,
      "y": 10
    },
    {
      "t": 15801,
      "e": 15300,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 18801,
      "e": 18300,
      "ty": 2,
      "x": 481,
      "y": 725
    },
    {
      "t": 19001,
      "e": 18500,
      "ty": 41,
      "x": 26448,
      "y": 15666,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 19251,
      "e": 18750,
      "ty": 41,
      "x": 26448,
      "y": 15011,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 19301,
      "e": 18800,
      "ty": 2,
      "x": 481,
      "y": 724
    },
    {
      "t": 19501,
      "e": 19000,
      "ty": 2,
      "x": 481,
      "y": 722
    },
    {
      "t": 19501,
      "e": 19000,
      "ty": 41,
      "x": 26448,
      "y": 13700,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 20001,
      "e": 19500,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 27401,
      "e": 24000,
      "ty": 2,
      "x": 519,
      "y": 721
    },
    {
      "t": 27500,
      "e": 24099,
      "ty": 2,
      "x": 631,
      "y": 738
    },
    {
      "t": 27501,
      "e": 24100,
      "ty": 41,
      "x": 41961,
      "y": 40440,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 27600,
      "e": 24199,
      "ty": 2,
      "x": 789,
      "y": 784
    },
    {
      "t": 27700,
      "e": 24299,
      "ty": 2,
      "x": 1320,
      "y": 865
    },
    {
      "t": 27751,
      "e": 24350,
      "ty": 41,
      "x": 34670,
      "y": 54433,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 27800,
      "e": 24399,
      "ty": 2,
      "x": 1511,
      "y": 909
    },
    {
      "t": 27900,
      "e": 24499,
      "ty": 2,
      "x": 1563,
      "y": 936
    },
    {
      "t": 28000,
      "e": 24599,
      "ty": 2,
      "x": 1533,
      "y": 950
    },
    {
      "t": 28000,
      "e": 24599,
      "ty": 41,
      "x": 38898,
      "y": 58157,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 28101,
      "e": 24700,
      "ty": 2,
      "x": 1504,
      "y": 953
    },
    {
      "t": 28200,
      "e": 24799,
      "ty": 2,
      "x": 1493,
      "y": 964
    },
    {
      "t": 28250,
      "e": 24849,
      "ty": 41,
      "x": 35868,
      "y": 59661,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 28300,
      "e": 24899,
      "ty": 2,
      "x": 1489,
      "y": 972
    },
    {
      "t": 28401,
      "e": 25000,
      "ty": 2,
      "x": 1478,
      "y": 972
    },
    {
      "t": 28500,
      "e": 25099,
      "ty": 2,
      "x": 1474,
      "y": 967
    },
    {
      "t": 28501,
      "e": 25100,
      "ty": 41,
      "x": 34740,
      "y": 59375,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 28601,
      "e": 25200,
      "ty": 2,
      "x": 1473,
      "y": 961
    },
    {
      "t": 28700,
      "e": 25299,
      "ty": 2,
      "x": 1474,
      "y": 959
    },
    {
      "t": 28751,
      "e": 25350,
      "ty": 41,
      "x": 34740,
      "y": 58802,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 28800,
      "e": 25399,
      "ty": 2,
      "x": 1476,
      "y": 959
    },
    {
      "t": 29001,
      "e": 25600,
      "ty": 2,
      "x": 1477,
      "y": 959
    },
    {
      "t": 29001,
      "e": 25600,
      "ty": 41,
      "x": 34952,
      "y": 58802,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 29101,
      "e": 25700,
      "ty": 2,
      "x": 1483,
      "y": 959
    },
    {
      "t": 29250,
      "e": 25849,
      "ty": 41,
      "x": 655,
      "y": 64879,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > line:[13]"
    },
    {
      "t": 40001,
      "e": 30849,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 44000,
      "e": 30849,
      "ty": 2,
      "x": 1066,
      "y": 857
    },
    {
      "t": 44000,
      "e": 30849,
      "ty": 41,
      "x": 5989,
      "y": 51496,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 44101,
      "e": 30950,
      "ty": 2,
      "x": 179,
      "y": 532
    },
    {
      "t": 44111,
      "e": 30960,
      "ty": 6,
      "x": 156,
      "y": 510,
      "ta": "#bigset.midpoint > ul > li"
    },
    {
      "t": 44128,
      "e": 30977,
      "ty": 7,
      "x": 151,
      "y": 499,
      "ta": "#bigset.midpoint > ul > li"
    },
    {
      "t": 44201,
      "e": 31050,
      "ty": 2,
      "x": 139,
      "y": 477
    },
    {
      "t": 44251,
      "e": 31100,
      "ty": 41,
      "x": 8486,
      "y": 59573,
      "ta": "#bigset.midpoint > p"
    },
    {
      "t": 44288,
      "e": 31137,
      "ty": 6,
      "x": 151,
      "y": 516,
      "ta": "#bigset.midpoint > ul > li"
    },
    {
      "t": 44301,
      "e": 31150,
      "ty": 2,
      "x": 151,
      "y": 516
    },
    {
      "t": 44305,
      "e": 31154,
      "ty": 7,
      "x": 160,
      "y": 533,
      "ta": "#bigset.midpoint > ul > li"
    },
    {
      "t": 44321,
      "e": 31170,
      "ty": 6,
      "x": 161,
      "y": 543,
      "ta": "#bigset.midpoint > ul > li:[5]"
    },
    {
      "t": 44355,
      "e": 31204,
      "ty": 7,
      "x": 164,
      "y": 577,
      "ta": "#bigset.midpoint > ul > li:[5]"
    },
    {
      "t": 44355,
      "e": 31204,
      "ty": 6,
      "x": 164,
      "y": 577,
      "ta": "#bigset.midpoint > ul > li:[9]"
    },
    {
      "t": 44401,
      "e": 31250,
      "ty": 2,
      "x": 174,
      "y": 593
    },
    {
      "t": 44500,
      "e": 31349,
      "ty": 2,
      "x": 177,
      "y": 596
    },
    {
      "t": 44501,
      "e": 31350,
      "ty": 41,
      "x": 42880,
      "y": 47382,
      "ta": "#bigset.midpoint > ul > li:[9] > label"
    },
    {
      "t": 44601,
      "e": 31450,
      "ty": 2,
      "x": 177,
      "y": 583
    },
    {
      "t": 44622,
      "e": 31471,
      "ty": 7,
      "x": 178,
      "y": 570,
      "ta": "#bigset.midpoint > ul > li:[9]"
    },
    {
      "t": 44639,
      "e": 31488,
      "ty": 6,
      "x": 177,
      "y": 564,
      "ta": "#bigset.midpoint > ul > li:[5]"
    },
    {
      "t": 44701,
      "e": 31550,
      "ty": 2,
      "x": 176,
      "y": 562
    },
    {
      "t": 44751,
      "e": 31600,
      "ty": 41,
      "x": 41609,
      "y": 59298,
      "ta": "#bigset.midpoint > ul > li:[5] > label"
    },
    {
      "t": 44874,
      "e": 31723,
      "ty": 3,
      "x": 176,
      "y": 562,
      "ta": "#bigset.midpoint > ul > li:[5] > label"
    },
    {
      "t": 44953,
      "e": 31802,
      "ty": 4,
      "x": 41609,
      "y": 59298,
      "ta": "#bigset.midpoint > ul > li:[5] > label"
    },
    {
      "t": 44955,
      "e": 31804,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[5] > label > input"
    },
    {
      "t": 44958,
      "e": 31807,
      "ty": 5,
      "x": 176,
      "y": 562,
      "ta": "#bigset.midpoint > ul > li:[5] > label > input"
    },
    {
      "t": 44959,
      "e": 31808,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[5] > label > input",
      "v": "B"
    },
    {
      "t": 45100,
      "e": 31949,
      "ty": 2,
      "x": 180,
      "y": 561
    },
    {
      "t": 45155,
      "e": 32004,
      "ty": 7,
      "x": 298,
      "y": 561,
      "ta": "#bigset.midpoint > ul > li:[5]"
    },
    {
      "t": 45155,
      "e": 32004,
      "ty": 6,
      "x": 298,
      "y": 561,
      "ta": "#bigset.midpoint > ul > li:[6]"
    },
    {
      "t": 45201,
      "e": 32050,
      "ty": 2,
      "x": 438,
      "y": 562
    },
    {
      "t": 45205,
      "e": 32054,
      "ty": 7,
      "x": 514,
      "y": 567,
      "ta": "#bigset.midpoint > ul > li:[6]"
    },
    {
      "t": 45205,
      "e": 32054,
      "ty": 6,
      "x": 514,
      "y": 567,
      "ta": "#bigset.midpoint > ul > li:[7]"
    },
    {
      "t": 45222,
      "e": 32071,
      "ty": 7,
      "x": 585,
      "y": 573,
      "ta": "#bigset.midpoint > ul > li:[7]"
    },
    {
      "t": 45238,
      "e": 32087,
      "ty": 6,
      "x": 635,
      "y": 577,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 45251,
      "e": 32100,
      "ty": 41,
      "x": 39453,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 45301,
      "e": 32150,
      "ty": 2,
      "x": 664,
      "y": 583
    },
    {
      "t": 45401,
      "e": 32250,
      "ty": 2,
      "x": 661,
      "y": 585
    },
    {
      "t": 45501,
      "e": 32350,
      "ty": 2,
      "x": 660,
      "y": 586
    },
    {
      "t": 45501,
      "e": 32350,
      "ty": 41,
      "x": 46716,
      "y": 19455,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 45701,
      "e": 32550,
      "ty": 2,
      "x": 657,
      "y": 590
    },
    {
      "t": 45723,
      "e": 32572,
      "ty": 7,
      "x": 635,
      "y": 619,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 45724,
      "e": 32573,
      "ty": 6,
      "x": 635,
      "y": 619,
      "ta": "#bigset.midpoint > ul > li:[15]"
    },
    {
      "t": 45751,
      "e": 32600,
      "ty": 41,
      "x": 63026,
      "y": 48844,
      "ta": "#bigset.midpoint > ul > li:[15] > label > div"
    },
    {
      "t": 45756,
      "e": 32605,
      "ty": 7,
      "x": 608,
      "y": 646,
      "ta": "#bigset.midpoint > ul > li:[15]"
    },
    {
      "t": 45801,
      "e": 32650,
      "ty": 2,
      "x": 606,
      "y": 649
    },
    {
      "t": 45806,
      "e": 32655,
      "ty": 6,
      "x": 627,
      "y": 636,
      "ta": "#bigset.midpoint > ul > li:[15]"
    },
    {
      "t": 45823,
      "e": 32672,
      "ty": 7,
      "x": 714,
      "y": 609,
      "ta": "#bigset.midpoint > ul > li:[15]"
    },
    {
      "t": 45840,
      "e": 32689,
      "ty": 6,
      "x": 716,
      "y": 607,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 45889,
      "e": 32738,
      "ty": 7,
      "x": 741,
      "y": 583,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 45889,
      "e": 32738,
      "ty": 6,
      "x": 741,
      "y": 583,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 45901,
      "e": 32750,
      "ty": 2,
      "x": 741,
      "y": 583
    },
    {
      "t": 45906,
      "e": 32755,
      "ty": 7,
      "x": 747,
      "y": 576,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 45974,
      "e": 32823,
      "ty": 6,
      "x": 727,
      "y": 581,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 45989,
      "e": 32838,
      "ty": 7,
      "x": 691,
      "y": 591,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 45989,
      "e": 32838,
      "ty": 6,
      "x": 691,
      "y": 591,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 46001,
      "e": 32850,
      "ty": 2,
      "x": 691,
      "y": 591
    },
    {
      "t": 46001,
      "e": 32850,
      "ty": 41,
      "x": 55721,
      "y": 30378,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 46073,
      "e": 32922,
      "ty": 7,
      "x": 686,
      "y": 574,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 46090,
      "e": 32939,
      "ty": 6,
      "x": 739,
      "y": 556,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 46100,
      "e": 32949,
      "ty": 2,
      "x": 739,
      "y": 556
    },
    {
      "t": 46139,
      "e": 32988,
      "ty": 7,
      "x": 853,
      "y": 535,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 46156,
      "e": 33005,
      "ty": 6,
      "x": 876,
      "y": 531,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 46201,
      "e": 33050,
      "ty": 2,
      "x": 890,
      "y": 530
    },
    {
      "t": 46251,
      "e": 33100,
      "ty": 41,
      "x": 48286,
      "y": 63145,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 46301,
      "e": 33150,
      "ty": 2,
      "x": 891,
      "y": 530
    },
    {
      "t": 46401,
      "e": 33250,
      "ty": 2,
      "x": 894,
      "y": 530
    },
    {
      "t": 46501,
      "e": 33350,
      "ty": 2,
      "x": 901,
      "y": 525
    },
    {
      "t": 46501,
      "e": 33350,
      "ty": 41,
      "x": 51191,
      "y": 52223,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 46601,
      "e": 33450,
      "ty": 2,
      "x": 902,
      "y": 524
    },
    {
      "t": 46751,
      "e": 33600,
      "ty": 41,
      "x": 51482,
      "y": 50038,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 47330,
      "e": 34179,
      "ty": 3,
      "x": 902,
      "y": 524,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 47331,
      "e": 34180,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[5] > label > input"
    },
    {
      "t": 47461,
      "e": 34181,
      "ty": 4,
      "x": 51482,
      "y": 50038,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 48605,
      "e": 35325,
      "ty": 2,
      "x": 886,
      "y": 524
    },
    {
      "t": 48703,
      "e": 35423,
      "ty": 2,
      "x": 830,
      "y": 515
    },
    {
      "t": 48754,
      "e": 35474,
      "ty": 41,
      "x": 11571,
      "y": 22630,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 48804,
      "e": 35524,
      "ty": 2,
      "x": 830,
      "y": 514
    },
    {
      "t": 48836,
      "e": 35556,
      "ty": 3,
      "x": 830,
      "y": 514,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 48915,
      "e": 35635,
      "ty": 4,
      "x": 11571,
      "y": 22630,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 48917,
      "e": 35637,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input"
    },
    {
      "t": 48919,
      "e": 35639,
      "ty": 5,
      "x": 830,
      "y": 514,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input"
    },
    {
      "t": 48919,
      "e": 35639,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input",
      "v": "F"
    },
    {
      "t": 49045,
      "e": 35765,
      "ty": 7,
      "x": 806,
      "y": 533,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 49063,
      "e": 35783,
      "ty": 6,
      "x": 787,
      "y": 552,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 49079,
      "e": 35799,
      "ty": 7,
      "x": 769,
      "y": 576,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 49097,
      "e": 35817,
      "ty": 6,
      "x": 741,
      "y": 604,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 49104,
      "e": 35824,
      "ty": 2,
      "x": 741,
      "y": 604
    },
    {
      "t": 49112,
      "e": 35832,
      "ty": 7,
      "x": 684,
      "y": 646,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 49146,
      "e": 35866,
      "ty": 6,
      "x": 548,
      "y": 735,
      "ta": "#start"
    },
    {
      "t": 49203,
      "e": 35923,
      "ty": 2,
      "x": 513,
      "y": 761
    },
    {
      "t": 49253,
      "e": 35973,
      "ty": 41,
      "x": 35225,
      "y": 57644,
      "ta": "#start"
    },
    {
      "t": 49303,
      "e": 36023,
      "ty": 2,
      "x": 509,
      "y": 764
    },
    {
      "t": 49550,
      "e": 36270,
      "ty": 3,
      "x": 509,
      "y": 764,
      "ta": "#start"
    },
    {
      "t": 49551,
      "e": 36271,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input"
    },
    {
      "t": 49551,
      "e": 36271,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 49636,
      "e": 36356,
      "ty": 4,
      "x": 35225,
      "y": 57644,
      "ta": "#start"
    },
    {
      "t": 49646,
      "e": 36366,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 49648,
      "e": 36368,
      "ty": 5,
      "x": 509,
      "y": 764,
      "ta": "#start"
    },
    {
      "t": 49653,
      "e": 36373,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 50655,
      "e": 37375,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 51254,
      "e": 37974,
      "ty": 41,
      "x": 19560,
      "y": 40273,
      "ta": "html > body"
    },
    {
      "t": 51303,
      "e": 38023,
      "ty": 2,
      "x": 923,
      "y": 610
    },
    {
      "t": 51403,
      "e": 38123,
      "ty": 2,
      "x": 1339,
      "y": 478
    },
    {
      "t": 51503,
      "e": 38223,
      "ty": 2,
      "x": 1301,
      "y": 474
    },
    {
      "t": 51504,
      "e": 38224,
      "ty": 41,
      "x": 44527,
      "y": 25815,
      "ta": "html > body"
    },
    {
      "t": 51604,
      "e": 38324,
      "ty": 2,
      "x": 835,
      "y": 512
    },
    {
      "t": 51704,
      "e": 38424,
      "ty": 2,
      "x": 844,
      "y": 540
    },
    {
      "t": 51749,
      "e": 38469,
      "ty": 6,
      "x": 879,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51754,
      "e": 38474,
      "ty": 41,
      "x": 15356,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51804,
      "e": 38524,
      "ty": 2,
      "x": 891,
      "y": 563
    },
    {
      "t": 51903,
      "e": 38623,
      "ty": 2,
      "x": 892,
      "y": 563
    },
    {
      "t": 51957,
      "e": 38677,
      "ty": 3,
      "x": 892,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51957,
      "e": 38677,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52003,
      "e": 38723,
      "ty": 41,
      "x": 18168,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52068,
      "e": 38788,
      "ty": 4,
      "x": 18168,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52068,
      "e": 38788,
      "ty": 5,
      "x": 892,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52204,
      "e": 38924,
      "ty": 2,
      "x": 892,
      "y": 564
    },
    {
      "t": 52254,
      "e": 38974,
      "ty": 41,
      "x": 18168,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52994,
      "e": 39714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 52994,
      "e": 39714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53104,
      "e": 39824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 53144,
      "e": 39864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 53145,
      "e": 39865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53257,
      "e": 39977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 53368,
      "e": 40088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 53369,
      "e": 40089,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 53370,
      "e": 40090,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53371,
      "e": 40091,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53496,
      "e": 40216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 54112,
      "e": 40832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 54612,
      "e": 41332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 54645,
      "e": 41365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 54649,
      "e": 41369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 54649,
      "e": 41369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54745,
      "e": 41465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 54745,
      "e": 41465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54769,
      "e": 41489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 54881,
      "e": 41601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 55329,
      "e": 42049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 55330,
      "e": 42050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55448,
      "e": 42168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 55528,
      "e": 42248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 56134,
      "e": 42854,
      "ty": 7,
      "x": 898,
      "y": 576,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56185,
      "e": 42905,
      "ty": 6,
      "x": 950,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56202,
      "e": 42922,
      "ty": 7,
      "x": 954,
      "y": 715,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56204,
      "e": 42924,
      "ty": 2,
      "x": 954,
      "y": 715
    },
    {
      "t": 56254,
      "e": 42974,
      "ty": 41,
      "x": 33370,
      "y": 41104,
      "ta": "html > body"
    },
    {
      "t": 56304,
      "e": 43024,
      "ty": 2,
      "x": 977,
      "y": 750
    },
    {
      "t": 56404,
      "e": 43124,
      "ty": 2,
      "x": 978,
      "y": 750
    },
    {
      "t": 56505,
      "e": 43225,
      "ty": 2,
      "x": 987,
      "y": 717
    },
    {
      "t": 56505,
      "e": 43225,
      "ty": 41,
      "x": 33714,
      "y": 39276,
      "ta": "html > body"
    },
    {
      "t": 56604,
      "e": 43324,
      "ty": 2,
      "x": 986,
      "y": 715
    },
    {
      "t": 56684,
      "e": 43404,
      "ty": 6,
      "x": 985,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56704,
      "e": 43424,
      "ty": 2,
      "x": 983,
      "y": 699
    },
    {
      "t": 56754,
      "e": 43474,
      "ty": 41,
      "x": 44363,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56804,
      "e": 43524,
      "ty": 2,
      "x": 981,
      "y": 688
    },
    {
      "t": 56904,
      "e": 43624,
      "ty": 2,
      "x": 980,
      "y": 688
    },
    {
      "t": 57004,
      "e": 43724,
      "ty": 41,
      "x": 43332,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57485,
      "e": 44205,
      "ty": 3,
      "x": 980,
      "y": 688,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57486,
      "e": 44206,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 57487,
      "e": 44207,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57488,
      "e": 44208,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57580,
      "e": 44300,
      "ty": 4,
      "x": 43332,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57581,
      "e": 44301,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57581,
      "e": 44301,
      "ty": 5,
      "x": 980,
      "y": 688,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57581,
      "e": 44301,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 58599,
      "e": 45319,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 59304,
      "e": 46024,
      "ty": 2,
      "x": 980,
      "y": 684
    },
    {
      "t": 59404,
      "e": 46124,
      "ty": 2,
      "x": 912,
      "y": 166
    },
    {
      "t": 59504,
      "e": 46224,
      "ty": 2,
      "x": 903,
      "y": 57
    },
    {
      "t": 59504,
      "e": 46224,
      "ty": 41,
      "x": 30821,
      "y": 2714,
      "ta": "html > body"
    },
    {
      "t": 59604,
      "e": 46324,
      "ty": 2,
      "x": 897,
      "y": 77
    },
    {
      "t": 59704,
      "e": 46424,
      "ty": 2,
      "x": 880,
      "y": 198
    },
    {
      "t": 59755,
      "e": 46475,
      "ty": 41,
      "x": 14139,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 59804,
      "e": 46524,
      "ty": 2,
      "x": 881,
      "y": 209
    },
    {
      "t": 59905,
      "e": 46625,
      "ty": 2,
      "x": 880,
      "y": 236
    },
    {
      "t": 60004,
      "e": 46724,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60007,
      "e": 46727,
      "ty": 41,
      "x": 47967,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 60069,
      "e": 46789,
      "ty": 3,
      "x": 880,
      "y": 236,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 60180,
      "e": 46900,
      "ty": 4,
      "x": 47967,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 60180,
      "e": 46900,
      "ty": 5,
      "x": 880,
      "y": 236,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 60180,
      "e": 46900,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 60181,
      "e": 46901,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 60705,
      "e": 47425,
      "ty": 2,
      "x": 876,
      "y": 237
    },
    {
      "t": 60755,
      "e": 47475,
      "ty": 41,
      "x": 39779,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 60804,
      "e": 47524,
      "ty": 2,
      "x": 861,
      "y": 240
    },
    {
      "t": 60904,
      "e": 47624,
      "ty": 2,
      "x": 855,
      "y": 240
    },
    {
      "t": 61004,
      "e": 47724,
      "ty": 2,
      "x": 860,
      "y": 301
    },
    {
      "t": 61004,
      "e": 47724,
      "ty": 41,
      "x": 12090,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 61104,
      "e": 47824,
      "ty": 2,
      "x": 891,
      "y": 427
    },
    {
      "t": 61204,
      "e": 47924,
      "ty": 2,
      "x": 888,
      "y": 450
    },
    {
      "t": 61255,
      "e": 47975,
      "ty": 41,
      "x": 64032,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 61304,
      "e": 48024,
      "ty": 2,
      "x": 874,
      "y": 486
    },
    {
      "t": 61404,
      "e": 48124,
      "ty": 2,
      "x": 868,
      "y": 521
    },
    {
      "t": 61504,
      "e": 48224,
      "ty": 2,
      "x": 868,
      "y": 524
    },
    {
      "t": 61504,
      "e": 48224,
      "ty": 41,
      "x": 54508,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 61704,
      "e": 48424,
      "ty": 2,
      "x": 866,
      "y": 516
    },
    {
      "t": 61755,
      "e": 48475,
      "ty": 41,
      "x": 40010,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 61804,
      "e": 48524,
      "ty": 2,
      "x": 866,
      "y": 488
    },
    {
      "t": 62005,
      "e": 48725,
      "ty": 2,
      "x": 867,
      "y": 473
    },
    {
      "t": 62005,
      "e": 48725,
      "ty": 41,
      "x": 48176,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 62104,
      "e": 48824,
      "ty": 2,
      "x": 867,
      "y": 472
    },
    {
      "t": 62255,
      "e": 48975,
      "ty": 41,
      "x": 48176,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 62754,
      "e": 49474,
      "ty": 41,
      "x": 48176,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 62805,
      "e": 49525,
      "ty": 2,
      "x": 867,
      "y": 477
    },
    {
      "t": 62989,
      "e": 49709,
      "ty": 3,
      "x": 867,
      "y": 477,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 62990,
      "e": 49710,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 63076,
      "e": 49796,
      "ty": 4,
      "x": 48176,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 63076,
      "e": 49796,
      "ty": 5,
      "x": 867,
      "y": 477,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 63076,
      "e": 49796,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 63077,
      "e": 49797,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 63404,
      "e": 50124,
      "ty": 2,
      "x": 867,
      "y": 479
    },
    {
      "t": 63504,
      "e": 50224,
      "ty": 2,
      "x": 883,
      "y": 593
    },
    {
      "t": 63505,
      "e": 50225,
      "ty": 41,
      "x": 14614,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 63605,
      "e": 50325,
      "ty": 2,
      "x": 893,
      "y": 670
    },
    {
      "t": 63704,
      "e": 50424,
      "ty": 2,
      "x": 894,
      "y": 677
    },
    {
      "t": 63755,
      "e": 50475,
      "ty": 41,
      "x": 19487,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 63805,
      "e": 50525,
      "ty": 2,
      "x": 894,
      "y": 691
    },
    {
      "t": 63904,
      "e": 50624,
      "ty": 2,
      "x": 894,
      "y": 693
    },
    {
      "t": 64004,
      "e": 50724,
      "ty": 2,
      "x": 893,
      "y": 696
    },
    {
      "t": 64005,
      "e": 50724,
      "ty": 41,
      "x": 18036,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 64104,
      "e": 50823,
      "ty": 2,
      "x": 893,
      "y": 705
    },
    {
      "t": 64204,
      "e": 50923,
      "ty": 2,
      "x": 893,
      "y": 714
    },
    {
      "t": 64254,
      "e": 50973,
      "ty": 41,
      "x": 17224,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 64304,
      "e": 51023,
      "ty": 2,
      "x": 897,
      "y": 735
    },
    {
      "t": 64405,
      "e": 51124,
      "ty": 2,
      "x": 897,
      "y": 742
    },
    {
      "t": 64504,
      "e": 51223,
      "ty": 2,
      "x": 897,
      "y": 745
    },
    {
      "t": 64505,
      "e": 51224,
      "ty": 41,
      "x": 17936,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 64604,
      "e": 51323,
      "ty": 2,
      "x": 896,
      "y": 746
    },
    {
      "t": 64754,
      "e": 51473,
      "ty": 41,
      "x": 17699,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 64805,
      "e": 51524,
      "ty": 2,
      "x": 896,
      "y": 745
    },
    {
      "t": 65004,
      "e": 51723,
      "ty": 2,
      "x": 900,
      "y": 780
    },
    {
      "t": 65005,
      "e": 51724,
      "ty": 41,
      "x": 43990,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 65104,
      "e": 51823,
      "ty": 2,
      "x": 909,
      "y": 819
    },
    {
      "t": 65255,
      "e": 51974,
      "ty": 41,
      "x": 51692,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 65504,
      "e": 52223,
      "ty": 2,
      "x": 909,
      "y": 824
    },
    {
      "t": 65505,
      "e": 52224,
      "ty": 41,
      "x": 51692,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 65605,
      "e": 52324,
      "ty": 2,
      "x": 908,
      "y": 825
    },
    {
      "t": 65704,
      "e": 52423,
      "ty": 2,
      "x": 908,
      "y": 822
    },
    {
      "t": 65755,
      "e": 52474,
      "ty": 41,
      "x": 51101,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 65804,
      "e": 52523,
      "ty": 2,
      "x": 913,
      "y": 793
    },
    {
      "t": 65904,
      "e": 52623,
      "ty": 2,
      "x": 928,
      "y": 726
    },
    {
      "t": 66004,
      "e": 52723,
      "ty": 2,
      "x": 929,
      "y": 723
    },
    {
      "t": 66004,
      "e": 52723,
      "ty": 41,
      "x": 27000,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 66204,
      "e": 52923,
      "ty": 2,
      "x": 930,
      "y": 723
    },
    {
      "t": 66254,
      "e": 52973,
      "ty": 41,
      "x": 27251,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 66302,
      "e": 53021,
      "ty": 3,
      "x": 930,
      "y": 723,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 66303,
      "e": 53022,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 66388,
      "e": 53107,
      "ty": 4,
      "x": 27251,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 66389,
      "e": 53108,
      "ty": 5,
      "x": 930,
      "y": 723,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 66390,
      "e": 53109,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 66392,
      "e": 53111,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 66755,
      "e": 53474,
      "ty": 41,
      "x": 44470,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 66805,
      "e": 53524,
      "ty": 2,
      "x": 924,
      "y": 839
    },
    {
      "t": 66904,
      "e": 53623,
      "ty": 2,
      "x": 896,
      "y": 933
    },
    {
      "t": 67005,
      "e": 53724,
      "ty": 2,
      "x": 886,
      "y": 935
    },
    {
      "t": 67005,
      "e": 53724,
      "ty": 41,
      "x": 15325,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 67105,
      "e": 53824,
      "ty": 2,
      "x": 884,
      "y": 935
    },
    {
      "t": 67204,
      "e": 53923,
      "ty": 2,
      "x": 881,
      "y": 936
    },
    {
      "t": 67255,
      "e": 53974,
      "ty": 41,
      "x": 61797,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 67270,
      "e": 53974,
      "ty": 3,
      "x": 877,
      "y": 938,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 67272,
      "e": 53976,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 67304,
      "e": 54008,
      "ty": 2,
      "x": 876,
      "y": 938
    },
    {
      "t": 67364,
      "e": 54068,
      "ty": 4,
      "x": 59612,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 67364,
      "e": 54068,
      "ty": 5,
      "x": 876,
      "y": 938,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 67505,
      "e": 54209,
      "ty": 41,
      "x": 59612,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 67604,
      "e": 54308,
      "ty": 2,
      "x": 916,
      "y": 994
    },
    {
      "t": 67705,
      "e": 54409,
      "ty": 2,
      "x": 889,
      "y": 968
    },
    {
      "t": 67755,
      "e": 54459,
      "ty": 41,
      "x": 24660,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 67762,
      "e": 54466,
      "ty": 6,
      "x": 834,
      "y": 928,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67779,
      "e": 54483,
      "ty": 7,
      "x": 832,
      "y": 927,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67805,
      "e": 54509,
      "ty": 2,
      "x": 832,
      "y": 927
    },
    {
      "t": 67941,
      "e": 54645,
      "ty": 3,
      "x": 832,
      "y": 927,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 68004,
      "e": 54708,
      "ty": 2,
      "x": 832,
      "y": 926
    },
    {
      "t": 68004,
      "e": 54708,
      "ty": 41,
      "x": 11553,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 68028,
      "e": 54732,
      "ty": 4,
      "x": 11553,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 68028,
      "e": 54732,
      "ty": 5,
      "x": 832,
      "y": 926,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 68028,
      "e": 54732,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68028,
      "e": 54732,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 68204,
      "e": 54908,
      "ty": 2,
      "x": 832,
      "y": 925
    },
    {
      "t": 68255,
      "e": 54959,
      "ty": 41,
      "x": 11553,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 68309,
      "e": 55013,
      "ty": 6,
      "x": 835,
      "y": 931,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68316,
      "e": 55020,
      "ty": 7,
      "x": 846,
      "y": 945,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68346,
      "e": 55050,
      "ty": 6,
      "x": 922,
      "y": 1010,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68362,
      "e": 55066,
      "ty": 7,
      "x": 986,
      "y": 1052,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68404,
      "e": 55108,
      "ty": 2,
      "x": 1040,
      "y": 1081
    },
    {
      "t": 68505,
      "e": 55209,
      "ty": 2,
      "x": 1023,
      "y": 1072
    },
    {
      "t": 68505,
      "e": 55209,
      "ty": 41,
      "x": 34954,
      "y": 58942,
      "ta": "html > body"
    },
    {
      "t": 68605,
      "e": 55309,
      "ty": 2,
      "x": 953,
      "y": 1038
    },
    {
      "t": 68613,
      "e": 55317,
      "ty": 6,
      "x": 937,
      "y": 1034,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68704,
      "e": 55408,
      "ty": 2,
      "x": 920,
      "y": 1030
    },
    {
      "t": 68741,
      "e": 55445,
      "ty": 3,
      "x": 920,
      "y": 1030,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68743,
      "e": 55447,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 68743,
      "e": 55447,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68754,
      "e": 55458,
      "ty": 41,
      "x": 46683,
      "y": 49647,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68804,
      "e": 55508,
      "ty": 2,
      "x": 920,
      "y": 1029
    },
    {
      "t": 68828,
      "e": 55532,
      "ty": 4,
      "x": 47198,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68828,
      "e": 55532,
      "ty": 5,
      "x": 921,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68830,
      "e": 55534,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68831,
      "e": 55535,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 68831,
      "e": 55535,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 68904,
      "e": 55608,
      "ty": 2,
      "x": 921,
      "y": 1028
    },
    {
      "t": 69005,
      "e": 55709,
      "ty": 41,
      "x": 31441,
      "y": 56505,
      "ta": "html > body"
    },
    {
      "t": 70201,
      "e": 56905,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 72405,
      "e": 59109,
      "ty": 2,
      "x": 918,
      "y": 1024
    },
    {
      "t": 72503,
      "e": 59207,
      "ty": 2,
      "x": 917,
      "y": 1024
    },
    {
      "t": 72504,
      "e": 59208,
      "ty": 41,
      "x": 30676,
      "y": 62163,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73104,
      "e": 59808,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 73203,
      "e": 59907,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 73503,
      "e": 60207,
      "ty": 2,
      "x": 913,
      "y": 1035
    },
    {
      "t": 73504,
      "e": 60208,
      "ty": 41,
      "x": 30479,
      "y": 62925,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73604,
      "e": 60308,
      "ty": 2,
      "x": 849,
      "y": 908
    },
    {
      "t": 73704,
      "e": 60408,
      "ty": 2,
      "x": 747,
      "y": 729
    },
    {
      "t": 73754,
      "e": 60458,
      "ty": 41,
      "x": 20640,
      "y": 6153,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73804,
      "e": 60508,
      "ty": 2,
      "x": 693,
      "y": 651
    },
    {
      "t": 73904,
      "e": 60608,
      "ty": 2,
      "x": 640,
      "y": 573
    },
    {
      "t": 74003,
      "e": 60707,
      "ty": 2,
      "x": 597,
      "y": 512
    },
    {
      "t": 74004,
      "e": 60708,
      "ty": 41,
      "x": 14933,
      "y": 11513,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 74104,
      "e": 60808,
      "ty": 2,
      "x": 542,
      "y": 472
    },
    {
      "t": 74204,
      "e": 60908,
      "ty": 2,
      "x": 539,
      "y": 467
    },
    {
      "t": 74254,
      "e": 60958,
      "ty": 41,
      "x": 12030,
      "y": 15227,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 74303,
      "e": 61007,
      "ty": 2,
      "x": 536,
      "y": 466
    },
    {
      "t": 74403,
      "e": 61107,
      "ty": 2,
      "x": 525,
      "y": 481
    },
    {
      "t": 74505,
      "e": 61209,
      "ty": 41,
      "x": 11391,
      "y": 16964,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 74704,
      "e": 61408,
      "ty": 2,
      "x": 527,
      "y": 484
    },
    {
      "t": 74754,
      "e": 61458,
      "ty": 41,
      "x": 11932,
      "y": 981,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 74803,
      "e": 61507,
      "ty": 2,
      "x": 539,
      "y": 485
    },
    {
      "t": 74904,
      "e": 61608,
      "ty": 2,
      "x": 542,
      "y": 487
    },
    {
      "t": 74957,
      "e": 61661,
      "ty": 3,
      "x": 544,
      "y": 487,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 75004,
      "e": 61708,
      "ty": 2,
      "x": 547,
      "y": 487
    },
    {
      "t": 75004,
      "e": 61708,
      "ty": 41,
      "x": 12473,
      "y": 1761,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 75104,
      "e": 61808,
      "ty": 2,
      "x": 573,
      "y": 489
    },
    {
      "t": 75204,
      "e": 61908,
      "ty": 2,
      "x": 878,
      "y": 534
    },
    {
      "t": 75254,
      "e": 61958,
      "ty": 41,
      "x": 32693,
      "y": 27897,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 75304,
      "e": 62008,
      "ty": 2,
      "x": 973,
      "y": 562
    },
    {
      "t": 75404,
      "e": 62108,
      "ty": 2,
      "x": 986,
      "y": 590
    },
    {
      "t": 75504,
      "e": 62208,
      "ty": 2,
      "x": 993,
      "y": 611
    },
    {
      "t": 75504,
      "e": 62208,
      "ty": 41,
      "x": 34415,
      "y": 50132,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 75603,
      "e": 62307,
      "ty": 2,
      "x": 996,
      "y": 634
    },
    {
      "t": 75704,
      "e": 62408,
      "ty": 2,
      "x": 996,
      "y": 639
    },
    {
      "t": 75754,
      "e": 62458,
      "ty": 41,
      "x": 34563,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 75869,
      "e": 62573,
      "ty": 4,
      "x": 34563,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 75869,
      "e": 62573,
      "ty": 5,
      "x": 996,
      "y": 639,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 76357,
      "e": 63061,
      "ty": 3,
      "x": 996,
      "y": 639,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 76477,
      "e": 63181,
      "ty": 4,
      "x": 34563,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 76477,
      "e": 63181,
      "ty": 5,
      "x": 996,
      "y": 639,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 80004,
      "e": 66708,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80404,
      "e": 67108,
      "ty": 3,
      "x": 996,
      "y": 639,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 80754,
      "e": 67458,
      "ty": 41,
      "x": 33234,
      "y": 56764,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 80804,
      "e": 67508,
      "ty": 2,
      "x": 906,
      "y": 610
    },
    {
      "t": 80904,
      "e": 67608,
      "ty": 2,
      "x": 813,
      "y": 568
    },
    {
      "t": 81004,
      "e": 67708,
      "ty": 2,
      "x": 763,
      "y": 533
    },
    {
      "t": 81004,
      "e": 67708,
      "ty": 41,
      "x": 23100,
      "y": 19705,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81104,
      "e": 67808,
      "ty": 2,
      "x": 710,
      "y": 496
    },
    {
      "t": 81204,
      "e": 67908,
      "ty": 2,
      "x": 687,
      "y": 483
    },
    {
      "t": 81235,
      "e": 67939,
      "ty": 4,
      "x": 19361,
      "y": 201,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81236,
      "e": 67940,
      "ty": 5,
      "x": 687,
      "y": 483,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81254,
      "e": 67958,
      "ty": 41,
      "x": 19361,
      "y": 201,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81757,
      "e": 68461,
      "ty": 3,
      "x": 687,
      "y": 483,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81884,
      "e": 68588,
      "ty": 4,
      "x": 19361,
      "y": 201,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81884,
      "e": 68588,
      "ty": 5,
      "x": 687,
      "y": 483,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 82255,
      "e": 68959,
      "ty": 41,
      "x": 19213,
      "y": 19705,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 82304,
      "e": 69008,
      "ty": 2,
      "x": 682,
      "y": 654
    },
    {
      "t": 82404,
      "e": 69108,
      "ty": 2,
      "x": 680,
      "y": 705
    },
    {
      "t": 82505,
      "e": 69209,
      "ty": 41,
      "x": 19016,
      "y": 21366,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 82755,
      "e": 69459,
      "ty": 41,
      "x": 19016,
      "y": 17855,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 82804,
      "e": 69508,
      "ty": 2,
      "x": 680,
      "y": 698
    },
    {
      "t": 82813,
      "e": 69517,
      "ty": 3,
      "x": 680,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 82909,
      "e": 69613,
      "ty": 4,
      "x": 19016,
      "y": 17270,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 82909,
      "e": 69613,
      "ty": 5,
      "x": 680,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83004,
      "e": 69708,
      "ty": 3,
      "x": 680,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83008,
      "e": 69712,
      "ty": 41,
      "x": 19016,
      "y": 17270,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83084,
      "e": 69788,
      "ty": 4,
      "x": 19016,
      "y": 17270,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83084,
      "e": 69788,
      "ty": 5,
      "x": 680,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83172,
      "e": 69876,
      "ty": 3,
      "x": 680,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83708,
      "e": 70412,
      "ty": 4,
      "x": 19016,
      "y": 17270,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83709,
      "e": 70413,
      "ty": 5,
      "x": 680,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 85704,
      "e": 72408,
      "ty": 2,
      "x": 750,
      "y": 519
    },
    {
      "t": 85755,
      "e": 72459,
      "ty": 41,
      "x": 23789,
      "y": 38631,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 85804,
      "e": 72508,
      "ty": 2,
      "x": 782,
      "y": 402
    },
    {
      "t": 85904,
      "e": 72608,
      "ty": 2,
      "x": 783,
      "y": 397
    },
    {
      "t": 85932,
      "e": 72636,
      "ty": 3,
      "x": 783,
      "y": 397,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 86004,
      "e": 72708,
      "ty": 2,
      "x": 783,
      "y": 412
    },
    {
      "t": 86004,
      "e": 72708,
      "ty": 41,
      "x": 24084,
      "y": 24587,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 86104,
      "e": 72808,
      "ty": 2,
      "x": 775,
      "y": 634
    },
    {
      "t": 86204,
      "e": 72908,
      "ty": 2,
      "x": 772,
      "y": 870
    },
    {
      "t": 86255,
      "e": 72959,
      "ty": 41,
      "x": 23493,
      "y": 53923,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86304,
      "e": 73008,
      "ty": 2,
      "x": 771,
      "y": 915
    },
    {
      "t": 86404,
      "e": 73108,
      "ty": 2,
      "x": 770,
      "y": 921
    },
    {
      "t": 86452,
      "e": 73156,
      "ty": 4,
      "x": 23444,
      "y": 55031,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86453,
      "e": 73157,
      "ty": 5,
      "x": 770,
      "y": 921,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86505,
      "e": 73209,
      "ty": 41,
      "x": 23444,
      "y": 55031,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86804,
      "e": 73508,
      "ty": 2,
      "x": 772,
      "y": 904
    },
    {
      "t": 86904,
      "e": 73608,
      "ty": 2,
      "x": 773,
      "y": 897
    },
    {
      "t": 87004,
      "e": 73708,
      "ty": 41,
      "x": 23592,
      "y": 57379,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 87104,
      "e": 73808,
      "ty": 2,
      "x": 773,
      "y": 896
    },
    {
      "t": 87204,
      "e": 73908,
      "ty": 2,
      "x": 774,
      "y": 885
    },
    {
      "t": 87229,
      "e": 73933,
      "ty": 3,
      "x": 774,
      "y": 885,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 87254,
      "e": 73958,
      "ty": 41,
      "x": 23641,
      "y": 29293,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 87348,
      "e": 74052,
      "ty": 4,
      "x": 23641,
      "y": 29293,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 87348,
      "e": 74052,
      "ty": 5,
      "x": 774,
      "y": 885,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 87754,
      "e": 74458,
      "ty": 41,
      "x": 23739,
      "y": 26952,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 87804,
      "e": 74508,
      "ty": 2,
      "x": 793,
      "y": 890
    },
    {
      "t": 87904,
      "e": 74608,
      "ty": 2,
      "x": 886,
      "y": 964
    },
    {
      "t": 88005,
      "e": 74709,
      "ty": 2,
      "x": 928,
      "y": 1015
    },
    {
      "t": 88005,
      "e": 74709,
      "ty": 41,
      "x": 31217,
      "y": 61540,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 88080,
      "e": 74784,
      "ty": 6,
      "x": 973,
      "y": 1077,
      "ta": "#start"
    },
    {
      "t": 88105,
      "e": 74809,
      "ty": 2,
      "x": 983,
      "y": 1088
    },
    {
      "t": 88204,
      "e": 74908,
      "ty": 2,
      "x": 992,
      "y": 1096
    },
    {
      "t": 88254,
      "e": 74958,
      "ty": 41,
      "x": 45055,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 89829,
      "e": 76533,
      "ty": 3,
      "x": 992,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 89829,
      "e": 76533,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 89940,
      "e": 76644,
      "ty": 4,
      "x": 45055,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 89940,
      "e": 76644,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 89940,
      "e": 76644,
      "ty": 5,
      "x": 992,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 89941,
      "e": 76645,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 90005,
      "e": 76709,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90967,
      "e": 77671,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 92346,
      "e": 79050,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"nodeType\":3,\"id\":2585,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"full\\\"; } else if (axis == 2){ axis = \\\"partial\\\"; } else if (axis ==3){ axis = \\\"diagonal\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2582},{\"id\":2583},{\"nodeType\":3,\"id\":2586,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2584}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2587,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2588,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2587},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2589,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2588},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2589},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2591,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2588}},{\"nodeType\":1,\"id\":2592,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2591},\"parentNode\":{\"id\":2588}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2591}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2589}},{\"nodeType\":1,\"id\":2595,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2594},\"parentNode\":{\"id\":2589}},{\"nodeType\":3,\"id\":2596,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2594}},{\"nodeType\":3,\"id\":2597,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2590}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2587},{\"id\":2588},{\"id\":2591},{\"id\":2593},{\"id\":2592},{\"id\":2589},{\"id\":2594},{\"id\":2596},{\"id\":2595},{\"id\":2590},{\"id\":2597}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2601},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2603},\"parentNode\":{\"id\":2598}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2610,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2605}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2614,\"textContent\":\"English\",\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2615}},{\"nodeType\":3,\"id\":2617,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":3,\"id\":2620,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2623,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2624,\"textContent\":\"*\",\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2628},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2631},\"parentNode\":{\"id\":2601}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2635}},{\"nodeType\":3,\"id\":2637,\"textContent\":\"First\",\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2635}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":3,\"id\":2640,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2644}},{\"nodeType\":3,\"id\":2646,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":3,\"id\":2649,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2651},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2653}},{\"nodeType\":3,\"id\":2655,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2654},\"parentNode\":{\"id\":2653}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"*\",\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2657},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2660},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2663},\"parentNode\":{\"id\":2602}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2667}},{\"nodeType\":3,\"id\":2669,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2667}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2659}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":3,\"id\":2672,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2676}},{\"nodeType\":3,\"id\":2678,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2662}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":3,\"id\":2681,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2683},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2685}},{\"nodeType\":3,\"id\":2687,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2686},\"parentNode\":{\"id\":2685}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"*\",\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2603}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2689},\"parentNode\":{\"id\":2603}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2603}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2603}},{\"nodeType\":3,\"id\":2693,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2691}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"*\",\"parentNode\":{\"id\":2694}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2600},{\"id\":2605},{\"id\":2610},{\"id\":2611},{\"id\":2624},{\"id\":2606},{\"id\":2612},{\"id\":2613},{\"id\":2614},{\"id\":2607},{\"id\":2615},{\"id\":2616},{\"id\":2617},{\"id\":2608},{\"id\":2618},{\"id\":2619},{\"id\":2620},{\"id\":2609},{\"id\":2621},{\"id\":2622},{\"id\":2623},{\"id\":2601},{\"id\":2625},{\"id\":2633},{\"id\":2634},{\"id\":2656},{\"id\":2626},{\"id\":2635},{\"id\":2636},{\"id\":2637},{\"id\":2627},{\"id\":2638},{\"id\":2639},{\"id\":2640},{\"id\":2628},{\"id\":2641},{\"id\":2642},{\"id\":2643},{\"id\":2629},{\"id\":2644},{\"id\":2645},{\"id\":2646},{\"id\":2630},{\"id\":2647},{\"id\":2648},{\"id\":2649},{\"id\":2631},{\"id\":2650},{\"id\":2651},{\"id\":2652},{\"id\":2632},{\"id\":2653},{\"id\":2654},{\"id\":2655},{\"id\":2602},{\"id\":2657},{\"id\":2665},{\"id\":2666},{\"id\":2688},{\"id\":2658},{\"id\":2667},{\"id\":2668},{\"id\":2669},{\"id\":2659},{\"id\":2670},{\"id\":2671},{\"id\":2672},{\"id\":2660},{\"id\":2673},{\"id\":2674},{\"id\":2675},{\"id\":2661},{\"id\":2676},{\"id\":2677},{\"id\":2678},{\"id\":2662},{\"id\":2679},{\"id\":2680},{\"id\":2681},{\"id\":2663},{\"id\":2682},{\"id\":2683},{\"id\":2684},{\"id\":2664},{\"id\":2685},{\"id\":2686},{\"id\":2687},{\"id\":2603},{\"id\":2689},{\"id\":2693},{\"id\":2694},{\"id\":2704},{\"id\":2690},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2691},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2692},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2604}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2705,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2706,\"textContent\":\" \",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2707,\"textContent\":\" \",\"parentNode\":{\"id\":2705}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2705}},{\"nodeType\":3,\"id\":2709,\"textContent\":\" \",\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2705}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2705}},{\"nodeType\":3,\"id\":2711,\"textContent\":\" \",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2705}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2711},\"parentNode\":{\"id\":2705}},{\"nodeType\":3,\"id\":2713,\"textContent\":\" \",\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2705}},{\"nodeType\":3,\"id\":2714,\"textContent\":\" \",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2714},\"parentNode\":{\"id\":2708}},{\"nodeType\":3,\"id\":2716,\"textContent\":\" \",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2708}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"parentNode\":{\"id\":2715}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2717},\"parentNode\":{\"id\":2715}},{\"nodeType\":3,\"id\":2719,\"textContent\":\" \",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2715}},{\"nodeType\":3,\"id\":2720,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2718}},{\"nodeType\":3,\"id\":2721,\"textContent\":\" \",\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2722,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2710}},{\"nodeType\":3,\"id\":2723,\"textContent\":\" \",\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2710}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2725,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2728,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2729,\"textContent\":\" \",\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2730,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2731,\"textContent\":\" \",\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2732,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2736,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2725}},{\"nodeType\":3,\"id\":2737,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2738,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2739,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2740,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2741,\"textContent\":\" \",\"parentNode\":{\"id\":2728}},{\"nodeType\":1,\"id\":2742,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2728}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2728}},{\"nodeType\":3,\"id\":2744,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2742}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2748,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2732}},{\"nodeType\":3,\"id\":2749,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"parentNode\":{\"id\":2712}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2753,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2751}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2705},{\"id\":2707},{\"id\":2708},{\"id\":2714},{\"id\":2715},{\"id\":2717},{\"id\":2718},{\"id\":2720},{\"id\":2719},{\"id\":2716},{\"id\":2709},{\"id\":2710},{\"id\":2721},{\"id\":2722},{\"id\":2724},{\"id\":2725},{\"id\":2736},{\"id\":2726},{\"id\":2737},{\"id\":2738},{\"id\":2740},{\"id\":2739},{\"id\":2727},{\"id\":2728},{\"id\":2741},{\"id\":2742},{\"id\":2744},{\"id\":2743},{\"id\":2729},{\"id\":2730},{\"id\":2745},{\"id\":2747},{\"id\":2746},{\"id\":2731},{\"id\":2732},{\"id\":2748},{\"id\":2733},{\"id\":2734},{\"id\":2749},{\"id\":2735},{\"id\":2723},{\"id\":2711},{\"id\":2712},{\"id\":2750},{\"id\":2751},{\"id\":2753},{\"id\":2752},{\"id\":2713},{\"id\":2706}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2754,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"[ { \\\"rt\\\": 80297, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 80299, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 27241, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 108863, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 7465, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"fire\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 117335, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 19310, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 137731, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 12713, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 151448, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 52822, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 205633, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -A -08 AM-11 AM-A -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:982,y:1088,t:1526418267292};\\\", \\\"{x:982,y:1076,t:1526418267303};\\\", \\\"{x:982,y:1040,t:1526418267319};\\\", \\\"{x:993,y:986,t:1526418267336};\\\", \\\"{x:1006,y:931,t:1526418267353};\\\", \\\"{x:1019,y:879,t:1526418267369};\\\", \\\"{x:1028,y:831,t:1526418267386};\\\", \\\"{x:1032,y:795,t:1526418267403};\\\", \\\"{x:1041,y:728,t:1526418267419};\\\", \\\"{x:1059,y:601,t:1526418267436};\\\", \\\"{x:1084,y:492,t:1526418267453};\\\", \\\"{x:1110,y:382,t:1526418267469};\\\", \\\"{x:1140,y:279,t:1526418267486};\\\", \\\"{x:1171,y:174,t:1526418267503};\\\", \\\"{x:1191,y:91,t:1526418267520};\\\", \\\"{x:1216,y:31,t:1526418267536};\\\", \\\"{x:1228,y:16,t:1526418267553};\\\", \\\"{x:1238,y:16,t:1526418267570};\\\", \\\"{x:1244,y:16,t:1526418267586};\\\", \\\"{x:1254,y:16,t:1526418267603};\\\", \\\"{x:1261,y:16,t:1526418267619};\\\", \\\"{x:1262,y:16,t:1526418267636};\\\", \\\"{x:1264,y:17,t:1526418267740};\\\", \\\"{x:1268,y:39,t:1526418267753};\\\", \\\"{x:1307,y:138,t:1526418267770};\\\", \\\"{x:1356,y:220,t:1526418267786};\\\", \\\"{x:1395,y:290,t:1526418267803};\\\", \\\"{x:1460,y:395,t:1526418267819};\\\", \\\"{x:1503,y:464,t:1526418267836};\\\", \\\"{x:1525,y:514,t:1526418267853};\\\", \\\"{x:1538,y:542,t:1526418267870};\\\", \\\"{x:1545,y:567,t:1526418267886};\\\", \\\"{x:1547,y:591,t:1526418267903};\\\", \\\"{x:1550,y:610,t:1526418267920};\\\", \\\"{x:1555,y:623,t:1526418267936};\\\", \\\"{x:1560,y:636,t:1526418267953};\\\", \\\"{x:1561,y:645,t:1526418267970};\\\", \\\"{x:1555,y:656,t:1526418267986};\\\", \\\"{x:1534,y:673,t:1526418268003};\\\", \\\"{x:1495,y:706,t:1526418268019};\\\", \\\"{x:1453,y:733,t:1526418268037};\\\", \\\"{x:1397,y:761,t:1526418268053};\\\", \\\"{x:1352,y:791,t:1526418268070};\\\", \\\"{x:1329,y:834,t:1526418268087};\\\", \\\"{x:1318,y:866,t:1526418268103};\\\", \\\"{x:1313,y:880,t:1526418268120};\\\", \\\"{x:1309,y:888,t:1526418268137};\\\", \\\"{x:1308,y:891,t:1526418268153};\\\", \\\"{x:1308,y:896,t:1526418268170};\\\", \\\"{x:1315,y:910,t:1526418268187};\\\", \\\"{x:1326,y:920,t:1526418268203};\\\", \\\"{x:1335,y:926,t:1526418268220};\\\", \\\"{x:1337,y:927,t:1526418268237};\\\", \\\"{x:1338,y:932,t:1526418268253};\\\", \\\"{x:1338,y:936,t:1526418268270};\\\", \\\"{x:1338,y:938,t:1526418268287};\\\", \\\"{x:1338,y:940,t:1526418268303};\\\", \\\"{x:1336,y:942,t:1526418268320};\\\", \\\"{x:1333,y:944,t:1526418268337};\\\", \\\"{x:1330,y:949,t:1526418268353};\\\", \\\"{x:1326,y:954,t:1526418268370};\\\", \\\"{x:1322,y:957,t:1526418268387};\\\", \\\"{x:1319,y:958,t:1526418268403};\\\", \\\"{x:1313,y:958,t:1526418268420};\\\", \\\"{x:1311,y:959,t:1526418268437};\\\", \\\"{x:1309,y:959,t:1526418268540};\\\", \\\"{x:1308,y:959,t:1526418268637};\\\", \\\"{x:1308,y:958,t:1526418268655};\\\", \\\"{x:1306,y:956,t:1526418268670};\\\", \\\"{x:1305,y:956,t:1526418268687};\\\", \\\"{x:1304,y:955,t:1526418268704};\\\", \\\"{x:1303,y:954,t:1526418268720};\\\", \\\"{x:1303,y:953,t:1526418268737};\\\", \\\"{x:1302,y:952,t:1526418268754};\\\", \\\"{x:1302,y:951,t:1526418268771};\\\", \\\"{x:1301,y:949,t:1526418268787};\\\", \\\"{x:1301,y:948,t:1526418268805};\\\", \\\"{x:1298,y:945,t:1526418268820};\\\", \\\"{x:1295,y:943,t:1526418268837};\\\", \\\"{x:1294,y:942,t:1526418268854};\\\", \\\"{x:1293,y:941,t:1526418268871};\\\", \\\"{x:1292,y:940,t:1526418268900};\\\", \\\"{x:1292,y:939,t:1526418268908};\\\", \\\"{x:1291,y:939,t:1526418269109};\\\", \\\"{x:1290,y:939,t:1526418269133};\\\", \\\"{x:1289,y:939,t:1526418269213};\\\", \\\"{x:1287,y:939,t:1526418269221};\\\", \\\"{x:1286,y:939,t:1526418270596};\\\", \\\"{x:1285,y:940,t:1526418270651};\\\", \\\"{x:1284,y:940,t:1526418270667};\\\", \\\"{x:1284,y:941,t:1526418270675};\\\", \\\"{x:1283,y:942,t:1526418270689};\\\", \\\"{x:1282,y:945,t:1526418270705};\\\", \\\"{x:1281,y:947,t:1526418270722};\\\", \\\"{x:1280,y:948,t:1526418270740};\\\", \\\"{x:1280,y:950,t:1526418270755};\\\", \\\"{x:1280,y:956,t:1526418270772};\\\", \\\"{x:1279,y:960,t:1526418270789};\\\", \\\"{x:1277,y:966,t:1526418270805};\\\", \\\"{x:1277,y:967,t:1526418270822};\\\", \\\"{x:1276,y:968,t:1526418270839};\\\", \\\"{x:1275,y:968,t:1526418272645};\\\", \\\"{x:1275,y:964,t:1526418273155};\\\", \\\"{x:1275,y:957,t:1526418273163};\\\", \\\"{x:1275,y:954,t:1526418273174};\\\", \\\"{x:1278,y:943,t:1526418273190};\\\", \\\"{x:1279,y:930,t:1526418273207};\\\", \\\"{x:1282,y:920,t:1526418273224};\\\", \\\"{x:1282,y:912,t:1526418273241};\\\", \\\"{x:1283,y:907,t:1526418273258};\\\", \\\"{x:1283,y:899,t:1526418273274};\\\", \\\"{x:1284,y:883,t:1526418273291};\\\", \\\"{x:1284,y:878,t:1526418273307};\\\", \\\"{x:1285,y:874,t:1526418273324};\\\", \\\"{x:1285,y:872,t:1526418273341};\\\", \\\"{x:1285,y:870,t:1526418273358};\\\", \\\"{x:1286,y:869,t:1526418273375};\\\", \\\"{x:1286,y:868,t:1526418273395};\\\", \\\"{x:1286,y:867,t:1526418273420};\\\", \\\"{x:1286,y:866,t:1526418273436};\\\", \\\"{x:1286,y:865,t:1526418273476};\\\", \\\"{x:1286,y:862,t:1526418273492};\\\", \\\"{x:1286,y:859,t:1526418273507};\\\", \\\"{x:1286,y:855,t:1526418273524};\\\", \\\"{x:1286,y:854,t:1526418273541};\\\", \\\"{x:1286,y:852,t:1526418273558};\\\", \\\"{x:1286,y:851,t:1526418273612};\\\", \\\"{x:1286,y:850,t:1526418273707};\\\", \\\"{x:1286,y:847,t:1526418273724};\\\", \\\"{x:1286,y:842,t:1526418273742};\\\", \\\"{x:1286,y:840,t:1526418273758};\\\", \\\"{x:1286,y:838,t:1526418273774};\\\", \\\"{x:1286,y:836,t:1526418273792};\\\", \\\"{x:1286,y:835,t:1526418273809};\\\", \\\"{x:1286,y:833,t:1526418273824};\\\", \\\"{x:1286,y:832,t:1526418273844};\\\", \\\"{x:1286,y:831,t:1526418274052};\\\", \\\"{x:1286,y:830,t:1526418274076};\\\", \\\"{x:1286,y:829,t:1526418275083};\\\", \\\"{x:1286,y:828,t:1526418275107};\\\", \\\"{x:1286,y:827,t:1526418275124};\\\", \\\"{x:1286,y:826,t:1526418275148};\\\", \\\"{x:1286,y:825,t:1526418275159};\\\", \\\"{x:1286,y:824,t:1526418275175};\\\", \\\"{x:1286,y:823,t:1526418275212};\\\", \\\"{x:1286,y:822,t:1526418275227};\\\", \\\"{x:1286,y:821,t:1526418275267};\\\", \\\"{x:1286,y:820,t:1526418275348};\\\", \\\"{x:1286,y:819,t:1526418275363};\\\", \\\"{x:1286,y:818,t:1526418275379};\\\", \\\"{x:1286,y:817,t:1526418275403};\\\", \\\"{x:1286,y:816,t:1526418275420};\\\", \\\"{x:1286,y:815,t:1526418275435};\\\", \\\"{x:1285,y:815,t:1526418275443};\\\", \\\"{x:1285,y:814,t:1526418275483};\\\", \\\"{x:1285,y:813,t:1526418275507};\\\", \\\"{x:1285,y:812,t:1526418275523};\\\", \\\"{x:1285,y:811,t:1526418275611};\\\", \\\"{x:1285,y:810,t:1526418275636};\\\", \\\"{x:1285,y:809,t:1526418275644};\\\", \\\"{x:1284,y:808,t:1526418275659};\\\", \\\"{x:1284,y:807,t:1526418275684};\\\", \\\"{x:1284,y:806,t:1526418275715};\\\", \\\"{x:1283,y:805,t:1526418275731};\\\", \\\"{x:1282,y:804,t:1526418275764};\\\", \\\"{x:1282,y:803,t:1526418275779};\\\", \\\"{x:1282,y:802,t:1526418275796};\\\", \\\"{x:1282,y:801,t:1526418275868};\\\", \\\"{x:1282,y:800,t:1526418275884};\\\", \\\"{x:1282,y:799,t:1526418275894};\\\", \\\"{x:1282,y:798,t:1526418275910};\\\", \\\"{x:1282,y:797,t:1526418275927};\\\", \\\"{x:1282,y:796,t:1526418275944};\\\", \\\"{x:1282,y:794,t:1526418275963};\\\", \\\"{x:1282,y:793,t:1526418275976};\\\", \\\"{x:1282,y:792,t:1526418275993};\\\", \\\"{x:1282,y:791,t:1526418276011};\\\", \\\"{x:1282,y:790,t:1526418276027};\\\", \\\"{x:1282,y:789,t:1526418276043};\\\", \\\"{x:1282,y:788,t:1526418276091};\\\", \\\"{x:1282,y:787,t:1526418276123};\\\", \\\"{x:1282,y:786,t:1526418276148};\\\", \\\"{x:1282,y:785,t:1526418276163};\\\", \\\"{x:1282,y:784,t:1526418276176};\\\", \\\"{x:1282,y:783,t:1526418276195};\\\", \\\"{x:1283,y:782,t:1526418276209};\\\", \\\"{x:1283,y:781,t:1526418276226};\\\", \\\"{x:1283,y:779,t:1526418276243};\\\", \\\"{x:1283,y:777,t:1526418276260};\\\", \\\"{x:1283,y:775,t:1526418276276};\\\", \\\"{x:1283,y:772,t:1526418276294};\\\", \\\"{x:1283,y:771,t:1526418276309};\\\", \\\"{x:1284,y:768,t:1526418276327};\\\", \\\"{x:1284,y:766,t:1526418276344};\\\", \\\"{x:1284,y:764,t:1526418276360};\\\", \\\"{x:1284,y:760,t:1526418276376};\\\", \\\"{x:1284,y:758,t:1526418276393};\\\", \\\"{x:1284,y:757,t:1526418276411};\\\", \\\"{x:1284,y:755,t:1526418276427};\\\", \\\"{x:1284,y:754,t:1526418276443};\\\", \\\"{x:1284,y:752,t:1526418276460};\\\", \\\"{x:1284,y:751,t:1526418276477};\\\", \\\"{x:1284,y:750,t:1526418276494};\\\", \\\"{x:1284,y:749,t:1526418276539};\\\", \\\"{x:1284,y:748,t:1526418276587};\\\", \\\"{x:1284,y:747,t:1526418276595};\\\", \\\"{x:1284,y:746,t:1526418276619};\\\", \\\"{x:1284,y:744,t:1526418276643};\\\", \\\"{x:1284,y:742,t:1526418276660};\\\", \\\"{x:1284,y:741,t:1526418276676};\\\", \\\"{x:1284,y:739,t:1526418276693};\\\", \\\"{x:1283,y:738,t:1526418276731};\\\", \\\"{x:1283,y:737,t:1526418276748};\\\", \\\"{x:1283,y:736,t:1526418276761};\\\", \\\"{x:1283,y:735,t:1526418276787};\\\", \\\"{x:1282,y:733,t:1526418276803};\\\", \\\"{x:1282,y:731,t:1526418276852};\\\", \\\"{x:1282,y:730,t:1526418276876};\\\", \\\"{x:1282,y:729,t:1526418276891};\\\", \\\"{x:1282,y:728,t:1526418276915};\\\", \\\"{x:1282,y:727,t:1526418276940};\\\", \\\"{x:1282,y:726,t:1526418276955};\\\", \\\"{x:1282,y:725,t:1526418276971};\\\", \\\"{x:1282,y:724,t:1526418276987};\\\", \\\"{x:1282,y:723,t:1526418277020};\\\", \\\"{x:1282,y:722,t:1526418277027};\\\", \\\"{x:1282,y:721,t:1526418277043};\\\", \\\"{x:1282,y:720,t:1526418277068};\\\", \\\"{x:1282,y:719,t:1526418277084};\\\", \\\"{x:1282,y:718,t:1526418277099};\\\", \\\"{x:1282,y:717,t:1526418277140};\\\", \\\"{x:1282,y:716,t:1526418277163};\\\", \\\"{x:1282,y:715,t:1526418277196};\\\", \\\"{x:1282,y:714,t:1526418277228};\\\", \\\"{x:1281,y:713,t:1526418277244};\\\", \\\"{x:1279,y:713,t:1526418277324};\\\", \\\"{x:1279,y:726,t:1526418277331};\\\", \\\"{x:1279,y:744,t:1526418277345};\\\", \\\"{x:1279,y:778,t:1526418277360};\\\", \\\"{x:1279,y:804,t:1526418277378};\\\", \\\"{x:1278,y:810,t:1526418277394};\\\", \\\"{x:1277,y:813,t:1526418277410};\\\", \\\"{x:1276,y:813,t:1526418277428};\\\", \\\"{x:1276,y:812,t:1526418277667};\\\", \\\"{x:1277,y:811,t:1526418277683};\\\", \\\"{x:1277,y:809,t:1526418277695};\\\", \\\"{x:1277,y:806,t:1526418277711};\\\", \\\"{x:1277,y:803,t:1526418277727};\\\", \\\"{x:1277,y:801,t:1526418277745};\\\", \\\"{x:1278,y:799,t:1526418277762};\\\", \\\"{x:1278,y:796,t:1526418277777};\\\", \\\"{x:1278,y:795,t:1526418277794};\\\", \\\"{x:1278,y:793,t:1526418277811};\\\", \\\"{x:1278,y:791,t:1526418277836};\\\", \\\"{x:1278,y:790,t:1526418277851};\\\", \\\"{x:1278,y:788,t:1526418277875};\\\", \\\"{x:1278,y:787,t:1526418277899};\\\", \\\"{x:1278,y:785,t:1526418277915};\\\", \\\"{x:1278,y:784,t:1526418277939};\\\", \\\"{x:1278,y:782,t:1526418277988};\\\", \\\"{x:1278,y:781,t:1526418278004};\\\", \\\"{x:1278,y:779,t:1526418278027};\\\", \\\"{x:1278,y:778,t:1526418278044};\\\", \\\"{x:1278,y:776,t:1526418278099};\\\", \\\"{x:1277,y:775,t:1526418278139};\\\", \\\"{x:1277,y:773,t:1526418278179};\\\", \\\"{x:1277,y:772,t:1526418278195};\\\", \\\"{x:1277,y:771,t:1526418278211};\\\", \\\"{x:1277,y:770,t:1526418278228};\\\", \\\"{x:1277,y:769,t:1526418278251};\\\", \\\"{x:1277,y:768,t:1526418278261};\\\", \\\"{x:1277,y:767,t:1526418278279};\\\", \\\"{x:1277,y:765,t:1526418278299};\\\", \\\"{x:1277,y:764,t:1526418278315};\\\", \\\"{x:1277,y:763,t:1526418278329};\\\", \\\"{x:1277,y:761,t:1526418278344};\\\", \\\"{x:1277,y:760,t:1526418278362};\\\", \\\"{x:1277,y:758,t:1526418278379};\\\", \\\"{x:1278,y:756,t:1526418278394};\\\", \\\"{x:1278,y:753,t:1526418278412};\\\", \\\"{x:1279,y:749,t:1526418278429};\\\", \\\"{x:1280,y:748,t:1526418278445};\\\", \\\"{x:1280,y:746,t:1526418278462};\\\", \\\"{x:1280,y:743,t:1526418278478};\\\", \\\"{x:1281,y:739,t:1526418278495};\\\", \\\"{x:1281,y:737,t:1526418278511};\\\", \\\"{x:1281,y:736,t:1526418278529};\\\", \\\"{x:1281,y:735,t:1526418278545};\\\", \\\"{x:1281,y:734,t:1526418278562};\\\", \\\"{x:1281,y:732,t:1526418278579};\\\", \\\"{x:1281,y:731,t:1526418278596};\\\", \\\"{x:1282,y:730,t:1526418278612};\\\", \\\"{x:1283,y:729,t:1526418278643};\\\", \\\"{x:1283,y:728,t:1526418278667};\\\", \\\"{x:1283,y:727,t:1526418278691};\\\", \\\"{x:1283,y:725,t:1526418278699};\\\", \\\"{x:1283,y:724,t:1526418278711};\\\", \\\"{x:1283,y:722,t:1526418278728};\\\", \\\"{x:1283,y:718,t:1526418278746};\\\", \\\"{x:1283,y:716,t:1526418278762};\\\", \\\"{x:1282,y:712,t:1526418278779};\\\", \\\"{x:1282,y:708,t:1526418278795};\\\", \\\"{x:1282,y:706,t:1526418278811};\\\", \\\"{x:1280,y:702,t:1526418278828};\\\", \\\"{x:1280,y:700,t:1526418278846};\\\", \\\"{x:1280,y:698,t:1526418278862};\\\", \\\"{x:1280,y:695,t:1526418278878};\\\", \\\"{x:1280,y:694,t:1526418278896};\\\", \\\"{x:1279,y:692,t:1526418278912};\\\", \\\"{x:1279,y:691,t:1526418278928};\\\", \\\"{x:1279,y:689,t:1526418278947};\\\", \\\"{x:1279,y:688,t:1526418278963};\\\", \\\"{x:1279,y:686,t:1526418278979};\\\", \\\"{x:1278,y:685,t:1526418279003};\\\", \\\"{x:1278,y:683,t:1526418279027};\\\", \\\"{x:1277,y:682,t:1526418279035};\\\", \\\"{x:1277,y:681,t:1526418279045};\\\", \\\"{x:1277,y:680,t:1526418279067};\\\", \\\"{x:1276,y:679,t:1526418279083};\\\", \\\"{x:1276,y:678,t:1526418279107};\\\", \\\"{x:1276,y:677,t:1526418279123};\\\", \\\"{x:1276,y:676,t:1526418279156};\\\", \\\"{x:1276,y:675,t:1526418279171};\\\", \\\"{x:1276,y:674,t:1526418279196};\\\", \\\"{x:1276,y:673,t:1526418279219};\\\", \\\"{x:1276,y:672,t:1526418279228};\\\", \\\"{x:1276,y:671,t:1526418279245};\\\", \\\"{x:1275,y:669,t:1526418279263};\\\", \\\"{x:1275,y:666,t:1526418279278};\\\", \\\"{x:1275,y:663,t:1526418279296};\\\", \\\"{x:1274,y:659,t:1526418279312};\\\", \\\"{x:1274,y:657,t:1526418279328};\\\", \\\"{x:1274,y:654,t:1526418279346};\\\", \\\"{x:1274,y:651,t:1526418279363};\\\", \\\"{x:1274,y:649,t:1526418279378};\\\", \\\"{x:1274,y:646,t:1526418279396};\\\", \\\"{x:1273,y:645,t:1526418279413};\\\", \\\"{x:1273,y:644,t:1526418279460};\\\", \\\"{x:1273,y:642,t:1526418279531};\\\", \\\"{x:1273,y:641,t:1526418279548};\\\", \\\"{x:1273,y:640,t:1526418279562};\\\", \\\"{x:1272,y:633,t:1526418279579};\\\", \\\"{x:1272,y:631,t:1526418279595};\\\", \\\"{x:1272,y:629,t:1526418279612};\\\", \\\"{x:1270,y:628,t:1526418279629};\\\", \\\"{x:1270,y:624,t:1526418279646};\\\", \\\"{x:1270,y:620,t:1526418279662};\\\", \\\"{x:1270,y:616,t:1526418279680};\\\", \\\"{x:1270,y:612,t:1526418279696};\\\", \\\"{x:1270,y:609,t:1526418279713};\\\", \\\"{x:1270,y:606,t:1526418279729};\\\", \\\"{x:1270,y:605,t:1526418279745};\\\", \\\"{x:1271,y:604,t:1526418279762};\\\", \\\"{x:1271,y:601,t:1526418279779};\\\", \\\"{x:1271,y:599,t:1526418279795};\\\", \\\"{x:1271,y:598,t:1526418279819};\\\", \\\"{x:1271,y:597,t:1526418279835};\\\", \\\"{x:1271,y:596,t:1526418279846};\\\", \\\"{x:1273,y:593,t:1526418279862};\\\", \\\"{x:1273,y:592,t:1526418279883};\\\", \\\"{x:1273,y:591,t:1526418279899};\\\", \\\"{x:1273,y:590,t:1526418280027};\\\", \\\"{x:1273,y:588,t:1526418280035};\\\", \\\"{x:1273,y:586,t:1526418280047};\\\", \\\"{x:1274,y:582,t:1526418280063};\\\", \\\"{x:1275,y:577,t:1526418280080};\\\", \\\"{x:1276,y:573,t:1526418280096};\\\", \\\"{x:1276,y:569,t:1526418280113};\\\", \\\"{x:1277,y:566,t:1526418280129};\\\", \\\"{x:1278,y:563,t:1526418280147};\\\", \\\"{x:1278,y:562,t:1526418280162};\\\", \\\"{x:1278,y:561,t:1526418280444};\\\", \\\"{x:1276,y:561,t:1526418280459};\\\", \\\"{x:1276,y:560,t:1526418280467};\\\", \\\"{x:1275,y:560,t:1526418280479};\\\", \\\"{x:1274,y:560,t:1526418280499};\\\", \\\"{x:1272,y:559,t:1526418280514};\\\", \\\"{x:1270,y:559,t:1526418280529};\\\", \\\"{x:1265,y:558,t:1526418280547};\\\", \\\"{x:1256,y:557,t:1526418280563};\\\", \\\"{x:1249,y:557,t:1526418280579};\\\", \\\"{x:1243,y:557,t:1526418280596};\\\", \\\"{x:1222,y:556,t:1526418280614};\\\", \\\"{x:1187,y:552,t:1526418280629};\\\", \\\"{x:1162,y:552,t:1526418280647};\\\", \\\"{x:1140,y:552,t:1526418280664};\\\", \\\"{x:1128,y:552,t:1526418280680};\\\", \\\"{x:1124,y:552,t:1526418280697};\\\", \\\"{x:1122,y:552,t:1526418280713};\\\", \\\"{x:1121,y:552,t:1526418280931};\\\", \\\"{x:1120,y:552,t:1526418280947};\\\", \\\"{x:1119,y:552,t:1526418280963};\\\", \\\"{x:1116,y:552,t:1526418280981};\\\", \\\"{x:1114,y:552,t:1526418280997};\\\", \\\"{x:1111,y:553,t:1526418281013};\\\", \\\"{x:1107,y:553,t:1526418281031};\\\", \\\"{x:1106,y:553,t:1526418281659};\\\", \\\"{x:1096,y:558,t:1526418281667};\\\", \\\"{x:1085,y:562,t:1526418281680};\\\", \\\"{x:1044,y:573,t:1526418281698};\\\", \\\"{x:989,y:590,t:1526418281716};\\\", \\\"{x:900,y:615,t:1526418281731};\\\", \\\"{x:751,y:638,t:1526418281747};\\\", \\\"{x:656,y:652,t:1526418281764};\\\", \\\"{x:588,y:657,t:1526418281781};\\\", \\\"{x:546,y:657,t:1526418281797};\\\", \\\"{x:512,y:657,t:1526418281814};\\\", \\\"{x:490,y:657,t:1526418281830};\\\", \\\"{x:482,y:657,t:1526418281848};\\\", \\\"{x:481,y:657,t:1526418281931};\\\", \\\"{x:479,y:657,t:1526418281947};\\\", \\\"{x:476,y:656,t:1526418281964};\\\", \\\"{x:465,y:653,t:1526418281981};\\\", \\\"{x:443,y:649,t:1526418281998};\\\", \\\"{x:422,y:646,t:1526418282014};\\\", \\\"{x:411,y:643,t:1526418282032};\\\", \\\"{x:400,y:636,t:1526418282048};\\\", \\\"{x:396,y:633,t:1526418282066};\\\", \\\"{x:395,y:631,t:1526418282083};\\\", \\\"{x:395,y:629,t:1526418282099};\\\", \\\"{x:398,y:625,t:1526418282115};\\\", \\\"{x:407,y:622,t:1526418282132};\\\", \\\"{x:421,y:620,t:1526418282149};\\\", \\\"{x:437,y:615,t:1526418282166};\\\", \\\"{x:451,y:613,t:1526418282182};\\\", \\\"{x:463,y:609,t:1526418282199};\\\", \\\"{x:468,y:609,t:1526418282216};\\\", \\\"{x:468,y:608,t:1526418282233};\\\", \\\"{x:470,y:607,t:1526418282283};\\\", \\\"{x:471,y:607,t:1526418282299};\\\", \\\"{x:472,y:606,t:1526418282316};\\\", \\\"{x:475,y:606,t:1526418282332};\\\", \\\"{x:490,y:603,t:1526418282349};\\\", \\\"{x:522,y:601,t:1526418282367};\\\", \\\"{x:562,y:600,t:1526418282383};\\\", \\\"{x:591,y:597,t:1526418282400};\\\", \\\"{x:609,y:597,t:1526418282416};\\\", \\\"{x:615,y:597,t:1526418282432};\\\", \\\"{x:616,y:597,t:1526418282450};\\\", \\\"{x:614,y:597,t:1526418282483};\\\", \\\"{x:613,y:596,t:1526418282500};\\\", \\\"{x:611,y:595,t:1526418282516};\\\", \\\"{x:610,y:595,t:1526418282533};\\\", \\\"{x:608,y:595,t:1526418282550};\\\", \\\"{x:606,y:594,t:1526418282565};\\\", \\\"{x:602,y:592,t:1526418282583};\\\", \\\"{x:599,y:590,t:1526418282600};\\\", \\\"{x:599,y:589,t:1526418282613};\\\", \\\"{x:598,y:589,t:1526418282630};\\\", \\\"{x:598,y:588,t:1526418282656};\\\", \\\"{x:597,y:588,t:1526418282745};\\\", \\\"{x:595,y:588,t:1526418282761};\\\", \\\"{x:594,y:588,t:1526418282769};\\\", \\\"{x:592,y:588,t:1526418282780};\\\", \\\"{x:582,y:590,t:1526418282797};\\\", \\\"{x:564,y:596,t:1526418282814};\\\", \\\"{x:550,y:604,t:1526418282829};\\\", \\\"{x:538,y:616,t:1526418282848};\\\", \\\"{x:531,y:629,t:1526418282865};\\\", \\\"{x:528,y:634,t:1526418282880};\\\", \\\"{x:527,y:636,t:1526418282896};\\\", \\\"{x:526,y:636,t:1526418282914};\\\", \\\"{x:526,y:639,t:1526418282930};\\\", \\\"{x:522,y:644,t:1526418282947};\\\", \\\"{x:518,y:648,t:1526418282964};\\\", \\\"{x:511,y:648,t:1526418282980};\\\", \\\"{x:503,y:651,t:1526418282998};\\\", \\\"{x:492,y:651,t:1526418283014};\\\", \\\"{x:475,y:653,t:1526418283030};\\\", \\\"{x:451,y:658,t:1526418283047};\\\", \\\"{x:436,y:658,t:1526418283063};\\\", \\\"{x:417,y:658,t:1526418283079};\\\", \\\"{x:397,y:658,t:1526418283096};\\\", \\\"{x:371,y:653,t:1526418283113};\\\", \\\"{x:360,y:649,t:1526418283130};\\\", \\\"{x:349,y:647,t:1526418283146};\\\", \\\"{x:342,y:645,t:1526418283164};\\\", \\\"{x:340,y:644,t:1526418283181};\\\", \\\"{x:339,y:643,t:1526418283256};\\\", \\\"{x:338,y:642,t:1526418283264};\\\", \\\"{x:335,y:639,t:1526418283280};\\\", \\\"{x:332,y:637,t:1526418283297};\\\", \\\"{x:329,y:635,t:1526418283314};\\\", \\\"{x:323,y:633,t:1526418283331};\\\", \\\"{x:302,y:629,t:1526418283347};\\\", \\\"{x:274,y:624,t:1526418283364};\\\", \\\"{x:243,y:616,t:1526418283382};\\\", \\\"{x:216,y:610,t:1526418283398};\\\", \\\"{x:194,y:603,t:1526418283414};\\\", \\\"{x:180,y:597,t:1526418283431};\\\", \\\"{x:168,y:592,t:1526418283448};\\\", \\\"{x:162,y:590,t:1526418283464};\\\", \\\"{x:160,y:588,t:1526418283481};\\\", \\\"{x:160,y:585,t:1526418283497};\\\", \\\"{x:159,y:576,t:1526418283514};\\\", \\\"{x:158,y:559,t:1526418283532};\\\", \\\"{x:157,y:546,t:1526418283547};\\\", \\\"{x:157,y:542,t:1526418283564};\\\", \\\"{x:157,y:538,t:1526418283581};\\\", \\\"{x:158,y:533,t:1526418283597};\\\", \\\"{x:163,y:529,t:1526418283614};\\\", \\\"{x:168,y:524,t:1526418283631};\\\", \\\"{x:172,y:520,t:1526418283648};\\\", \\\"{x:175,y:515,t:1526418283664};\\\", \\\"{x:179,y:510,t:1526418283681};\\\", \\\"{x:196,y:506,t:1526418283698};\\\", \\\"{x:218,y:503,t:1526418283714};\\\", \\\"{x:239,y:499,t:1526418283731};\\\", \\\"{x:256,y:496,t:1526418283747};\\\", \\\"{x:271,y:496,t:1526418283764};\\\", \\\"{x:291,y:502,t:1526418283780};\\\", \\\"{x:310,y:510,t:1526418283797};\\\", \\\"{x:329,y:524,t:1526418283814};\\\", \\\"{x:341,y:532,t:1526418283831};\\\", \\\"{x:350,y:536,t:1526418283848};\\\", \\\"{x:349,y:536,t:1526418283921};\\\", \\\"{x:348,y:536,t:1526418283932};\\\", \\\"{x:349,y:534,t:1526418283977};\\\", \\\"{x:350,y:534,t:1526418283984};\\\", \\\"{x:350,y:533,t:1526418283997};\\\", \\\"{x:351,y:532,t:1526418284013};\\\", \\\"{x:353,y:529,t:1526418284030};\\\", \\\"{x:354,y:527,t:1526418284047};\\\", \\\"{x:360,y:523,t:1526418284064};\\\", \\\"{x:368,y:520,t:1526418284081};\\\", \\\"{x:371,y:520,t:1526418284098};\\\", \\\"{x:373,y:518,t:1526418284115};\\\", \\\"{x:374,y:518,t:1526418284650};\\\", \\\"{x:375,y:518,t:1526418284664};\\\", \\\"{x:377,y:519,t:1526418284682};\\\", \\\"{x:379,y:519,t:1526418284698};\\\", \\\"{x:381,y:519,t:1526418284715};\\\", \\\"{x:385,y:521,t:1526418284732};\\\", \\\"{x:386,y:522,t:1526418284749};\\\", \\\"{x:387,y:523,t:1526418284776};\\\", \\\"{x:393,y:525,t:1526418285306};\\\", \\\"{x:408,y:535,t:1526418285318};\\\", \\\"{x:472,y:589,t:1526418285334};\\\", \\\"{x:548,y:670,t:1526418285350};\\\", \\\"{x:613,y:760,t:1526418285366};\\\", \\\"{x:665,y:822,t:1526418285383};\\\", \\\"{x:691,y:861,t:1526418285399};\\\", \\\"{x:705,y:879,t:1526418285417};\\\", \\\"{x:708,y:884,t:1526418285433};\\\", \\\"{x:709,y:886,t:1526418285449};\\\", \\\"{x:709,y:887,t:1526418285466};\\\", \\\"{x:708,y:887,t:1526418285546};\\\", \\\"{x:707,y:887,t:1526418285657};\\\", \\\"{x:706,y:887,t:1526418286881};\\\", \\\"{x:707,y:887,t:1526418289392};\\\", \\\"{x:717,y:894,t:1526418289403};\\\", \\\"{x:758,y:907,t:1526418289419};\\\", \\\"{x:818,y:927,t:1526418289436};\\\", \\\"{x:904,y:952,t:1526418289453};\\\", \\\"{x:1005,y:973,t:1526418289470};\\\", \\\"{x:1101,y:995,t:1526418289486};\\\", \\\"{x:1187,y:1020,t:1526418289504};\\\", \\\"{x:1231,y:1037,t:1526418289519};\\\", \\\"{x:1305,y:1048,t:1526418289536};\\\", \\\"{x:1343,y:1055,t:1526418289553};\\\", \\\"{x:1368,y:1055,t:1526418289571};\\\", \\\"{x:1380,y:1053,t:1526418289586};\\\", \\\"{x:1390,y:1050,t:1526418289604};\\\", \\\"{x:1391,y:1048,t:1526418289621};\\\", \\\"{x:1389,y:1045,t:1526418289637};\\\", \\\"{x:1377,y:1038,t:1526418289653};\\\", \\\"{x:1358,y:1027,t:1526418289670};\\\", \\\"{x:1348,y:1020,t:1526418289686};\\\", \\\"{x:1343,y:1014,t:1526418289704};\\\", \\\"{x:1337,y:1007,t:1526418289720};\\\", \\\"{x:1333,y:1003,t:1526418289736};\\\", \\\"{x:1321,y:998,t:1526418289753};\\\", \\\"{x:1298,y:990,t:1526418289770};\\\", \\\"{x:1283,y:989,t:1526418289786};\\\", \\\"{x:1275,y:989,t:1526418289803};\\\", \\\"{x:1271,y:989,t:1526418289821};\\\", \\\"{x:1269,y:989,t:1526418289836};\\\", \\\"{x:1269,y:987,t:1526418289897};\\\", \\\"{x:1270,y:987,t:1526418289905};\\\", \\\"{x:1271,y:985,t:1526418289920};\\\", \\\"{x:1272,y:983,t:1526418289937};\\\", \\\"{x:1273,y:982,t:1526418289954};\\\", \\\"{x:1275,y:980,t:1526418289971};\\\", \\\"{x:1275,y:979,t:1526418290162};\\\", \\\"{x:1275,y:978,t:1526418290177};\\\", \\\"{x:1275,y:977,t:1526418290188};\\\", \\\"{x:1276,y:972,t:1526418290204};\\\", \\\"{x:1276,y:968,t:1526418290221};\\\", \\\"{x:1278,y:966,t:1526418290238};\\\", \\\"{x:1278,y:962,t:1526418290255};\\\", \\\"{x:1278,y:960,t:1526418290270};\\\", \\\"{x:1277,y:957,t:1526418290288};\\\", \\\"{x:1270,y:953,t:1526418290304};\\\", \\\"{x:1272,y:953,t:1526418290594};\\\", \\\"{x:1273,y:953,t:1526418290605};\\\", \\\"{x:1274,y:953,t:1526418290730};\\\", \\\"{x:1275,y:950,t:1526418290738};\\\", \\\"{x:1277,y:937,t:1526418290755};\\\", \\\"{x:1277,y:927,t:1526418290772};\\\", \\\"{x:1277,y:913,t:1526418290788};\\\", \\\"{x:1274,y:903,t:1526418290805};\\\", \\\"{x:1272,y:894,t:1526418290822};\\\", \\\"{x:1272,y:884,t:1526418290838};\\\", \\\"{x:1272,y:876,t:1526418290855};\\\", \\\"{x:1275,y:863,t:1526418290872};\\\", \\\"{x:1279,y:855,t:1526418290888};\\\", \\\"{x:1282,y:840,t:1526418290906};\\\", \\\"{x:1283,y:831,t:1526418290922};\\\", \\\"{x:1284,y:826,t:1526418290938};\\\", \\\"{x:1286,y:819,t:1526418290956};\\\", \\\"{x:1287,y:812,t:1526418290972};\\\", \\\"{x:1287,y:808,t:1526418290989};\\\", \\\"{x:1287,y:803,t:1526418291006};\\\", \\\"{x:1287,y:799,t:1526418291023};\\\", \\\"{x:1287,y:796,t:1526418291039};\\\", \\\"{x:1287,y:792,t:1526418291055};\\\", \\\"{x:1288,y:787,t:1526418291072};\\\", \\\"{x:1290,y:781,t:1526418291090};\\\", \\\"{x:1290,y:778,t:1526418291106};\\\", \\\"{x:1289,y:775,t:1526418291122};\\\", \\\"{x:1288,y:772,t:1526418291139};\\\", \\\"{x:1286,y:767,t:1526418291155};\\\", \\\"{x:1286,y:765,t:1526418291172};\\\", \\\"{x:1284,y:760,t:1526418291189};\\\", \\\"{x:1283,y:757,t:1526418291205};\\\", \\\"{x:1282,y:755,t:1526418291222};\\\", \\\"{x:1281,y:751,t:1526418291239};\\\", \\\"{x:1280,y:748,t:1526418291255};\\\", \\\"{x:1279,y:743,t:1526418291273};\\\", \\\"{x:1278,y:736,t:1526418291289};\\\", \\\"{x:1278,y:731,t:1526418291305};\\\", \\\"{x:1278,y:727,t:1526418291322};\\\", \\\"{x:1278,y:720,t:1526418291339};\\\", \\\"{x:1279,y:716,t:1526418291356};\\\", \\\"{x:1280,y:712,t:1526418291372};\\\", \\\"{x:1280,y:708,t:1526418291390};\\\", \\\"{x:1280,y:706,t:1526418291406};\\\", \\\"{x:1280,y:702,t:1526418291422};\\\", \\\"{x:1280,y:700,t:1526418291439};\\\", \\\"{x:1280,y:698,t:1526418291456};\\\", \\\"{x:1280,y:693,t:1526418291473};\\\", \\\"{x:1280,y:687,t:1526418291490};\\\", \\\"{x:1280,y:684,t:1526418291505};\\\", \\\"{x:1278,y:681,t:1526418291522};\\\", \\\"{x:1276,y:676,t:1526418291539};\\\", \\\"{x:1275,y:673,t:1526418291556};\\\", \\\"{x:1273,y:669,t:1526418291572};\\\", \\\"{x:1271,y:666,t:1526418291589};\\\", \\\"{x:1268,y:660,t:1526418291606};\\\", \\\"{x:1264,y:657,t:1526418291622};\\\", \\\"{x:1263,y:655,t:1526418291639};\\\", \\\"{x:1263,y:652,t:1526418291656};\\\", \\\"{x:1261,y:649,t:1526418291672};\\\", \\\"{x:1260,y:645,t:1526418291689};\\\", \\\"{x:1260,y:643,t:1526418291705};\\\", \\\"{x:1260,y:642,t:1526418291723};\\\", \\\"{x:1260,y:639,t:1526418291739};\\\", \\\"{x:1260,y:636,t:1526418291756};\\\", \\\"{x:1260,y:634,t:1526418291773};\\\", \\\"{x:1259,y:632,t:1526418291789};\\\", \\\"{x:1259,y:631,t:1526418291805};\\\", \\\"{x:1259,y:630,t:1526418291824};\\\", \\\"{x:1259,y:629,t:1526418291848};\\\", \\\"{x:1259,y:627,t:1526418291856};\\\", \\\"{x:1259,y:626,t:1526418291872};\\\", \\\"{x:1259,y:624,t:1526418291913};\\\", \\\"{x:1259,y:623,t:1526418291968};\\\", \\\"{x:1260,y:624,t:1526418292833};\\\", \\\"{x:1264,y:630,t:1526418292840};\\\", \\\"{x:1274,y:644,t:1526418292856};\\\", \\\"{x:1280,y:660,t:1526418292873};\\\", \\\"{x:1299,y:694,t:1526418292889};\\\", \\\"{x:1342,y:760,t:1526418292907};\\\", \\\"{x:1385,y:834,t:1526418292923};\\\", \\\"{x:1410,y:870,t:1526418292939};\\\", \\\"{x:1417,y:885,t:1526418292956};\\\", \\\"{x:1420,y:897,t:1526418292973};\\\", \\\"{x:1420,y:912,t:1526418292989};\\\", \\\"{x:1419,y:931,t:1526418293006};\\\", \\\"{x:1415,y:948,t:1526418293024};\\\", \\\"{x:1405,y:959,t:1526418293039};\\\", \\\"{x:1391,y:967,t:1526418293056};\\\", \\\"{x:1380,y:969,t:1526418293074};\\\", \\\"{x:1366,y:972,t:1526418293090};\\\", \\\"{x:1352,y:973,t:1526418293106};\\\", \\\"{x:1346,y:974,t:1526418293124};\\\", \\\"{x:1338,y:974,t:1526418293141};\\\", \\\"{x:1333,y:974,t:1526418293156};\\\", \\\"{x:1331,y:974,t:1526418293174};\\\", \\\"{x:1330,y:974,t:1526418293225};\\\", \\\"{x:1330,y:973,t:1526418293248};\\\", \\\"{x:1330,y:972,t:1526418293272};\\\", \\\"{x:1331,y:971,t:1526418293296};\\\", \\\"{x:1332,y:970,t:1526418293337};\\\", \\\"{x:1332,y:969,t:1526418293377};\\\", \\\"{x:1332,y:968,t:1526418293392};\\\", \\\"{x:1330,y:966,t:1526418293406};\\\", \\\"{x:1325,y:953,t:1526418293423};\\\", \\\"{x:1315,y:923,t:1526418293440};\\\", \\\"{x:1314,y:911,t:1526418293457};\\\", \\\"{x:1314,y:901,t:1526418293474};\\\", \\\"{x:1314,y:889,t:1526418293491};\\\", \\\"{x:1314,y:882,t:1526418293508};\\\", \\\"{x:1314,y:871,t:1526418293523};\\\", \\\"{x:1317,y:856,t:1526418293540};\\\", \\\"{x:1322,y:838,t:1526418293558};\\\", \\\"{x:1327,y:816,t:1526418293573};\\\", \\\"{x:1332,y:799,t:1526418293590};\\\", \\\"{x:1336,y:784,t:1526418293607};\\\", \\\"{x:1341,y:765,t:1526418293624};\\\", \\\"{x:1350,y:734,t:1526418293640};\\\", \\\"{x:1355,y:712,t:1526418293657};\\\", \\\"{x:1356,y:690,t:1526418293674};\\\", \\\"{x:1356,y:669,t:1526418293690};\\\", \\\"{x:1356,y:653,t:1526418293707};\\\", \\\"{x:1356,y:634,t:1526418293724};\\\", \\\"{x:1353,y:616,t:1526418293740};\\\", \\\"{x:1353,y:602,t:1526418293757};\\\", \\\"{x:1353,y:588,t:1526418293773};\\\", \\\"{x:1353,y:574,t:1526418293790};\\\", \\\"{x:1353,y:563,t:1526418293807};\\\", \\\"{x:1351,y:550,t:1526418293825};\\\", \\\"{x:1350,y:548,t:1526418293840};\\\", \\\"{x:1349,y:543,t:1526418293857};\\\", \\\"{x:1347,y:538,t:1526418293875};\\\", \\\"{x:1345,y:534,t:1526418293891};\\\", \\\"{x:1341,y:529,t:1526418293908};\\\", \\\"{x:1339,y:526,t:1526418293925};\\\", \\\"{x:1337,y:523,t:1526418293940};\\\", \\\"{x:1337,y:520,t:1526418293957};\\\", \\\"{x:1335,y:517,t:1526418293974};\\\", \\\"{x:1333,y:512,t:1526418293991};\\\", \\\"{x:1332,y:510,t:1526418294007};\\\", \\\"{x:1331,y:510,t:1526418294025};\\\", \\\"{x:1330,y:510,t:1526418294065};\\\", \\\"{x:1327,y:511,t:1526418294074};\\\", \\\"{x:1324,y:521,t:1526418294090};\\\", \\\"{x:1322,y:533,t:1526418294107};\\\", \\\"{x:1318,y:544,t:1526418294124};\\\", \\\"{x:1316,y:562,t:1526418294140};\\\", \\\"{x:1316,y:579,t:1526418294157};\\\", \\\"{x:1316,y:594,t:1526418294175};\\\", \\\"{x:1316,y:606,t:1526418294191};\\\", \\\"{x:1316,y:619,t:1526418294207};\\\", \\\"{x:1321,y:630,t:1526418294225};\\\", \\\"{x:1327,y:639,t:1526418294242};\\\", \\\"{x:1340,y:649,t:1526418294257};\\\", \\\"{x:1356,y:658,t:1526418294274};\\\", \\\"{x:1369,y:665,t:1526418294292};\\\", \\\"{x:1378,y:670,t:1526418294307};\\\", \\\"{x:1382,y:673,t:1526418294325};\\\", \\\"{x:1384,y:675,t:1526418294341};\\\", \\\"{x:1385,y:675,t:1526418294357};\\\", \\\"{x:1385,y:676,t:1526418294473};\\\", \\\"{x:1385,y:677,t:1526418294481};\\\", \\\"{x:1385,y:678,t:1526418294504};\\\", \\\"{x:1384,y:680,t:1526418294512};\\\", \\\"{x:1382,y:682,t:1526418294524};\\\", \\\"{x:1373,y:690,t:1526418294541};\\\", \\\"{x:1364,y:704,t:1526418294559};\\\", \\\"{x:1350,y:719,t:1526418294575};\\\", \\\"{x:1332,y:736,t:1526418294592};\\\", \\\"{x:1309,y:749,t:1526418294608};\\\", \\\"{x:1296,y:758,t:1526418294625};\\\", \\\"{x:1279,y:771,t:1526418294641};\\\", \\\"{x:1268,y:782,t:1526418294658};\\\", \\\"{x:1262,y:786,t:1526418294674};\\\", \\\"{x:1261,y:787,t:1526418294696};\\\", \\\"{x:1260,y:790,t:1526418294744};\\\", \\\"{x:1260,y:793,t:1526418294758};\\\", \\\"{x:1264,y:799,t:1526418294775};\\\", \\\"{x:1266,y:803,t:1526418294791};\\\", \\\"{x:1268,y:810,t:1526418294808};\\\", \\\"{x:1275,y:821,t:1526418294824};\\\", \\\"{x:1288,y:836,t:1526418294842};\\\", \\\"{x:1300,y:846,t:1526418294859};\\\", \\\"{x:1302,y:848,t:1526418294875};\\\", \\\"{x:1303,y:850,t:1526418294891};\\\", \\\"{x:1303,y:851,t:1526418295008};\\\", \\\"{x:1303,y:853,t:1526418295026};\\\", \\\"{x:1300,y:859,t:1526418295042};\\\", \\\"{x:1297,y:869,t:1526418295058};\\\", \\\"{x:1293,y:877,t:1526418295075};\\\", \\\"{x:1286,y:888,t:1526418295092};\\\", \\\"{x:1280,y:900,t:1526418295108};\\\", \\\"{x:1275,y:912,t:1526418295125};\\\", \\\"{x:1270,y:921,t:1526418295141};\\\", \\\"{x:1267,y:924,t:1526418295158};\\\", \\\"{x:1264,y:929,t:1526418295176};\\\", \\\"{x:1264,y:932,t:1526418295193};\\\", \\\"{x:1264,y:933,t:1526418295208};\\\", \\\"{x:1264,y:934,t:1526418295256};\\\", \\\"{x:1265,y:935,t:1526418295264};\\\", \\\"{x:1266,y:936,t:1526418295276};\\\", \\\"{x:1268,y:937,t:1526418295293};\\\", \\\"{x:1270,y:937,t:1526418295309};\\\", \\\"{x:1271,y:938,t:1526418295325};\\\", \\\"{x:1272,y:939,t:1526418295345};\\\", \\\"{x:1275,y:943,t:1526418295358};\\\", \\\"{x:1280,y:948,t:1526418295375};\\\", \\\"{x:1283,y:954,t:1526418295393};\\\", \\\"{x:1284,y:956,t:1526418295408};\\\", \\\"{x:1284,y:954,t:1526418295488};\\\", \\\"{x:1286,y:950,t:1526418295496};\\\", \\\"{x:1287,y:948,t:1526418295508};\\\", \\\"{x:1290,y:940,t:1526418295526};\\\", \\\"{x:1293,y:936,t:1526418295543};\\\", \\\"{x:1294,y:931,t:1526418295558};\\\", \\\"{x:1295,y:928,t:1526418295575};\\\", \\\"{x:1296,y:917,t:1526418295593};\\\", \\\"{x:1296,y:909,t:1526418295610};\\\", \\\"{x:1296,y:898,t:1526418295626};\\\", \\\"{x:1296,y:892,t:1526418295643};\\\", \\\"{x:1296,y:889,t:1526418295660};\\\", \\\"{x:1296,y:888,t:1526418295676};\\\", \\\"{x:1296,y:887,t:1526418295693};\\\", \\\"{x:1296,y:883,t:1526418295710};\\\", \\\"{x:1295,y:879,t:1526418295726};\\\", \\\"{x:1294,y:873,t:1526418295743};\\\", \\\"{x:1294,y:869,t:1526418295760};\\\", \\\"{x:1294,y:864,t:1526418295777};\\\", \\\"{x:1294,y:858,t:1526418295793};\\\", \\\"{x:1294,y:852,t:1526418295810};\\\", \\\"{x:1294,y:843,t:1526418295827};\\\", \\\"{x:1294,y:838,t:1526418295844};\\\", \\\"{x:1293,y:836,t:1526418295860};\\\", \\\"{x:1293,y:835,t:1526418295876};\\\", \\\"{x:1293,y:833,t:1526418295897};\\\", \\\"{x:1293,y:832,t:1526418295921};\\\", \\\"{x:1292,y:831,t:1526418295953};\\\", \\\"{x:1292,y:830,t:1526418295969};\\\", \\\"{x:1292,y:829,t:1526418295986};\\\", \\\"{x:1292,y:827,t:1526418296001};\\\", \\\"{x:1292,y:823,t:1526418296010};\\\", \\\"{x:1291,y:819,t:1526418296027};\\\", \\\"{x:1290,y:815,t:1526418296043};\\\", \\\"{x:1290,y:812,t:1526418296060};\\\", \\\"{x:1288,y:807,t:1526418296078};\\\", \\\"{x:1286,y:800,t:1526418296093};\\\", \\\"{x:1284,y:792,t:1526418296110};\\\", \\\"{x:1283,y:781,t:1526418296128};\\\", \\\"{x:1282,y:774,t:1526418296143};\\\", \\\"{x:1282,y:771,t:1526418296159};\\\", \\\"{x:1281,y:766,t:1526418296176};\\\", \\\"{x:1280,y:762,t:1526418296193};\\\", \\\"{x:1280,y:758,t:1526418296209};\\\", \\\"{x:1279,y:754,t:1526418296227};\\\", \\\"{x:1278,y:751,t:1526418296242};\\\", \\\"{x:1278,y:750,t:1526418296259};\\\", \\\"{x:1278,y:746,t:1526418296276};\\\", \\\"{x:1277,y:743,t:1526418296293};\\\", \\\"{x:1276,y:739,t:1526418296309};\\\", \\\"{x:1275,y:735,t:1526418296327};\\\", \\\"{x:1274,y:730,t:1526418296344};\\\", \\\"{x:1274,y:726,t:1526418296360};\\\", \\\"{x:1274,y:719,t:1526418296377};\\\", \\\"{x:1274,y:716,t:1526418296394};\\\", \\\"{x:1274,y:713,t:1526418296410};\\\", \\\"{x:1274,y:712,t:1526418296427};\\\", \\\"{x:1274,y:709,t:1526418296444};\\\", \\\"{x:1274,y:708,t:1526418296460};\\\", \\\"{x:1274,y:706,t:1526418296477};\\\", \\\"{x:1274,y:703,t:1526418296494};\\\", \\\"{x:1274,y:701,t:1526418296510};\\\", \\\"{x:1274,y:698,t:1526418296527};\\\", \\\"{x:1274,y:695,t:1526418296544};\\\", \\\"{x:1274,y:693,t:1526418296560};\\\", \\\"{x:1274,y:690,t:1526418296577};\\\", \\\"{x:1275,y:685,t:1526418296594};\\\", \\\"{x:1275,y:683,t:1526418296611};\\\", \\\"{x:1275,y:680,t:1526418296627};\\\", \\\"{x:1275,y:676,t:1526418296644};\\\", \\\"{x:1275,y:673,t:1526418296661};\\\", \\\"{x:1275,y:670,t:1526418296677};\\\", \\\"{x:1275,y:666,t:1526418296693};\\\", \\\"{x:1275,y:662,t:1526418296711};\\\", \\\"{x:1275,y:655,t:1526418296726};\\\", \\\"{x:1275,y:651,t:1526418296743};\\\", \\\"{x:1275,y:642,t:1526418296761};\\\", \\\"{x:1275,y:638,t:1526418296777};\\\", \\\"{x:1275,y:632,t:1526418296794};\\\", \\\"{x:1275,y:628,t:1526418296810};\\\", \\\"{x:1275,y:624,t:1526418296827};\\\", \\\"{x:1275,y:621,t:1526418296844};\\\", \\\"{x:1275,y:617,t:1526418296861};\\\", \\\"{x:1275,y:614,t:1526418296877};\\\", \\\"{x:1275,y:611,t:1526418296894};\\\", \\\"{x:1275,y:606,t:1526418296912};\\\", \\\"{x:1275,y:603,t:1526418296927};\\\", \\\"{x:1275,y:598,t:1526418296944};\\\", \\\"{x:1275,y:594,t:1526418296961};\\\", \\\"{x:1271,y:594,t:1526418297904};\\\", \\\"{x:1265,y:600,t:1526418297912};\\\", \\\"{x:1255,y:607,t:1526418297928};\\\", \\\"{x:1194,y:640,t:1526418297944};\\\", \\\"{x:1085,y:679,t:1526418297962};\\\", \\\"{x:971,y:710,t:1526418297978};\\\", \\\"{x:839,y:746,t:1526418297994};\\\", \\\"{x:717,y:780,t:1526418298012};\\\", \\\"{x:600,y:805,t:1526418298028};\\\", \\\"{x:483,y:825,t:1526418298045};\\\", \\\"{x:375,y:852,t:1526418298061};\\\", \\\"{x:297,y:864,t:1526418298079};\\\", \\\"{x:256,y:873,t:1526418298095};\\\", \\\"{x:236,y:873,t:1526418298111};\\\", \\\"{x:222,y:873,t:1526418298129};\\\", \\\"{x:218,y:872,t:1526418298145};\\\", \\\"{x:219,y:870,t:1526418298161};\\\", \\\"{x:229,y:859,t:1526418298179};\\\", \\\"{x:242,y:853,t:1526418298194};\\\", \\\"{x:256,y:846,t:1526418298212};\\\", \\\"{x:273,y:836,t:1526418298229};\\\", \\\"{x:291,y:826,t:1526418298245};\\\", \\\"{x:324,y:812,t:1526418298262};\\\", \\\"{x:359,y:798,t:1526418298279};\\\", \\\"{x:380,y:789,t:1526418298295};\\\", \\\"{x:395,y:782,t:1526418298312};\\\", \\\"{x:419,y:769,t:1526418298328};\\\", \\\"{x:429,y:762,t:1526418298344};\\\", \\\"{x:431,y:762,t:1526418298362};\\\", \\\"{x:433,y:757,t:1526418298424};\\\", \\\"{x:437,y:754,t:1526418298432};\\\", \\\"{x:442,y:750,t:1526418298446};\\\", \\\"{x:452,y:737,t:1526418298462};\\\", \\\"{x:458,y:728,t:1526418298478};\\\", \\\"{x:467,y:719,t:1526418298495};\\\", \\\"{x:474,y:712,t:1526418298511};\\\", \\\"{x:488,y:702,t:1526418298526};\\\", \\\"{x:502,y:693,t:1526418298543};\\\", \\\"{x:513,y:687,t:1526418298560};\\\", \\\"{x:514,y:687,t:1526418298577};\\\", \\\"{x:515,y:688,t:1526418298649};\\\", \\\"{x:515,y:694,t:1526418298660};\\\", \\\"{x:511,y:714,t:1526418298676};\\\", \\\"{x:504,y:731,t:1526418298693};\\\", \\\"{x:504,y:739,t:1526418298710};\\\", \\\"{x:504,y:738,t:1526418298858};\\\", \\\"{x:504,y:736,t:1526418298865};\\\", \\\"{x:504,y:735,t:1526418298882};\\\", \\\"{x:504,y:734,t:1526418298896};\\\", \\\"{x:504,y:733,t:1526418298911};\\\", \\\"{x:504,y:732,t:1526418298936};\\\", \\\"{x:504,y:731,t:1526418298976};\\\", \\\"{x:504,y:730,t:1526418298984};\\\", \\\"{x:504,y:729,t:1526418298994};\\\", \\\"{x:504,y:726,t:1526418299010};\\\", \\\"{x:504,y:725,t:1526418299028};\\\", \\\"{x:504,y:724,t:1526418299045};\\\", \\\"{x:505,y:723,t:1526418299061};\\\", \\\"{x:505,y:724,t:1526418299610};\\\", \\\"{x:504,y:724,t:1526418299625};\\\", \\\"{x:503,y:724,t:1526418299633};\\\", \\\"{x:503,y:725,t:1526418299672};\\\" ] }, { \\\"rt\\\": 38072, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 245024, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -U -D -D -D -G -G -E -D -B -B -07 PM-06:30-03:30-04 PM-E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:726,t:1526418314552};\\\", \\\"{x:509,y:727,t:1526418314563};\\\", \\\"{x:531,y:729,t:1526418314578};\\\", \\\"{x:556,y:733,t:1526418314595};\\\", \\\"{x:602,y:740,t:1526418314613};\\\", \\\"{x:661,y:750,t:1526418314628};\\\", \\\"{x:696,y:755,t:1526418314639};\\\", \\\"{x:811,y:770,t:1526418314656};\\\", \\\"{x:905,y:779,t:1526418314672};\\\", \\\"{x:988,y:789,t:1526418314689};\\\", \\\"{x:1064,y:803,t:1526418314706};\\\", \\\"{x:1122,y:810,t:1526418314722};\\\", \\\"{x:1210,y:821,t:1526418314739};\\\", \\\"{x:1299,y:832,t:1526418314756};\\\", \\\"{x:1381,y:838,t:1526418314772};\\\", \\\"{x:1443,y:839,t:1526418314789};\\\", \\\"{x:1445,y:842,t:1526418314806};\\\", \\\"{x:1446,y:842,t:1526418315369};\\\", \\\"{x:1448,y:842,t:1526418315377};\\\", \\\"{x:1450,y:842,t:1526418315389};\\\", \\\"{x:1456,y:838,t:1526418315406};\\\", \\\"{x:1463,y:834,t:1526418315423};\\\", \\\"{x:1476,y:827,t:1526418315440};\\\", \\\"{x:1503,y:801,t:1526418315456};\\\", \\\"{x:1524,y:767,t:1526418315473};\\\", \\\"{x:1557,y:722,t:1526418315490};\\\", \\\"{x:1597,y:675,t:1526418315506};\\\", \\\"{x:1646,y:622,t:1526418315524};\\\", \\\"{x:1684,y:584,t:1526418315539};\\\", \\\"{x:1698,y:566,t:1526418315556};\\\", \\\"{x:1707,y:551,t:1526418315573};\\\", \\\"{x:1712,y:542,t:1526418315590};\\\", \\\"{x:1713,y:534,t:1526418315606};\\\", \\\"{x:1714,y:523,t:1526418315624};\\\", \\\"{x:1714,y:512,t:1526418315639};\\\", \\\"{x:1714,y:501,t:1526418315656};\\\", \\\"{x:1712,y:492,t:1526418315673};\\\", \\\"{x:1707,y:482,t:1526418315690};\\\", \\\"{x:1702,y:477,t:1526418315707};\\\", \\\"{x:1690,y:471,t:1526418315724};\\\", \\\"{x:1673,y:464,t:1526418315739};\\\", \\\"{x:1655,y:453,t:1526418315757};\\\", \\\"{x:1639,y:439,t:1526418315773};\\\", \\\"{x:1630,y:425,t:1526418315790};\\\", \\\"{x:1625,y:416,t:1526418315806};\\\", \\\"{x:1620,y:408,t:1526418315823};\\\", \\\"{x:1619,y:402,t:1526418315840};\\\", \\\"{x:1619,y:401,t:1526418315856};\\\", \\\"{x:1619,y:402,t:1526418315968};\\\", \\\"{x:1619,y:404,t:1526418315976};\\\", \\\"{x:1619,y:406,t:1526418315992};\\\", \\\"{x:1619,y:407,t:1526418316006};\\\", \\\"{x:1618,y:409,t:1526418316023};\\\", \\\"{x:1612,y:414,t:1526418316040};\\\", \\\"{x:1610,y:417,t:1526418316057};\\\", \\\"{x:1609,y:418,t:1526418316074};\\\", \\\"{x:1608,y:419,t:1526418316096};\\\", \\\"{x:1608,y:420,t:1526418316296};\\\", \\\"{x:1608,y:421,t:1526418316307};\\\", \\\"{x:1609,y:421,t:1526418316368};\\\", \\\"{x:1610,y:421,t:1526418316376};\\\", \\\"{x:1611,y:421,t:1526418316391};\\\", \\\"{x:1615,y:423,t:1526418316406};\\\", \\\"{x:1618,y:424,t:1526418316423};\\\", \\\"{x:1619,y:425,t:1526418316440};\\\", \\\"{x:1619,y:427,t:1526418317481};\\\", \\\"{x:1619,y:428,t:1526418317508};\\\", \\\"{x:1619,y:430,t:1526418317524};\\\", \\\"{x:1619,y:431,t:1526418317540};\\\", \\\"{x:1619,y:433,t:1526418317688};\\\", \\\"{x:1619,y:434,t:1526418317736};\\\", \\\"{x:1619,y:435,t:1526418317751};\\\", \\\"{x:1619,y:436,t:1526418317760};\\\", \\\"{x:1619,y:437,t:1526418317784};\\\", \\\"{x:1619,y:439,t:1526418317808};\\\", \\\"{x:1618,y:440,t:1526418317824};\\\", \\\"{x:1618,y:441,t:1526418317841};\\\", \\\"{x:1618,y:442,t:1526418317858};\\\", \\\"{x:1618,y:443,t:1526418317874};\\\", \\\"{x:1617,y:445,t:1526418317892};\\\", \\\"{x:1617,y:447,t:1526418317907};\\\", \\\"{x:1617,y:450,t:1526418317924};\\\", \\\"{x:1615,y:453,t:1526418317942};\\\", \\\"{x:1614,y:456,t:1526418317957};\\\", \\\"{x:1614,y:461,t:1526418317974};\\\", \\\"{x:1613,y:466,t:1526418317991};\\\", \\\"{x:1613,y:470,t:1526418318007};\\\", \\\"{x:1610,y:479,t:1526418318025};\\\", \\\"{x:1610,y:484,t:1526418318042};\\\", \\\"{x:1610,y:487,t:1526418318058};\\\", \\\"{x:1610,y:490,t:1526418318075};\\\", \\\"{x:1609,y:493,t:1526418318092};\\\", \\\"{x:1609,y:497,t:1526418318108};\\\", \\\"{x:1607,y:503,t:1526418318125};\\\", \\\"{x:1606,y:507,t:1526418318141};\\\", \\\"{x:1606,y:509,t:1526418318157};\\\", \\\"{x:1606,y:512,t:1526418318174};\\\", \\\"{x:1605,y:517,t:1526418318192};\\\", \\\"{x:1605,y:523,t:1526418318208};\\\", \\\"{x:1603,y:531,t:1526418318224};\\\", \\\"{x:1603,y:537,t:1526418318242};\\\", \\\"{x:1602,y:539,t:1526418318258};\\\", \\\"{x:1602,y:541,t:1526418318275};\\\", \\\"{x:1602,y:545,t:1526418318291};\\\", \\\"{x:1602,y:548,t:1526418318307};\\\", \\\"{x:1602,y:552,t:1526418318325};\\\", \\\"{x:1602,y:554,t:1526418318341};\\\", \\\"{x:1601,y:555,t:1526418318358};\\\", \\\"{x:1601,y:557,t:1526418318377};\\\", \\\"{x:1601,y:558,t:1526418318393};\\\", \\\"{x:1601,y:560,t:1526418318409};\\\", \\\"{x:1601,y:562,t:1526418318425};\\\", \\\"{x:1601,y:563,t:1526418318449};\\\", \\\"{x:1602,y:565,t:1526418318481};\\\", \\\"{x:1604,y:568,t:1526418318492};\\\", \\\"{x:1609,y:574,t:1526418318508};\\\", \\\"{x:1613,y:577,t:1526418318527};\\\", \\\"{x:1614,y:580,t:1526418318542};\\\", \\\"{x:1615,y:581,t:1526418318558};\\\", \\\"{x:1616,y:581,t:1526418318575};\\\", \\\"{x:1617,y:583,t:1526418318592};\\\", \\\"{x:1617,y:582,t:1526418319017};\\\", \\\"{x:1617,y:579,t:1526418319025};\\\", \\\"{x:1617,y:574,t:1526418319042};\\\", \\\"{x:1617,y:571,t:1526418319059};\\\", \\\"{x:1616,y:570,t:1526418319289};\\\", \\\"{x:1615,y:573,t:1526418319320};\\\", \\\"{x:1615,y:574,t:1526418319337};\\\", \\\"{x:1614,y:576,t:1526418319352};\\\", \\\"{x:1614,y:577,t:1526418319361};\\\", \\\"{x:1614,y:578,t:1526418319385};\\\", \\\"{x:1614,y:579,t:1526418319401};\\\", \\\"{x:1614,y:581,t:1526418319417};\\\", \\\"{x:1614,y:582,t:1526418319433};\\\", \\\"{x:1614,y:583,t:1526418319442};\\\", \\\"{x:1614,y:585,t:1526418319459};\\\", \\\"{x:1613,y:587,t:1526418319476};\\\", \\\"{x:1613,y:588,t:1526418319492};\\\", \\\"{x:1613,y:589,t:1526418319509};\\\", \\\"{x:1612,y:591,t:1526418319526};\\\", \\\"{x:1612,y:594,t:1526418319542};\\\", \\\"{x:1612,y:598,t:1526418319559};\\\", \\\"{x:1612,y:602,t:1526418319576};\\\", \\\"{x:1611,y:605,t:1526418319592};\\\", \\\"{x:1610,y:611,t:1526418319608};\\\", \\\"{x:1610,y:614,t:1526418319626};\\\", \\\"{x:1610,y:618,t:1526418319642};\\\", \\\"{x:1609,y:622,t:1526418319659};\\\", \\\"{x:1609,y:623,t:1526418319675};\\\", \\\"{x:1608,y:624,t:1526418319691};\\\", \\\"{x:1608,y:625,t:1526418319708};\\\", \\\"{x:1608,y:628,t:1526418319725};\\\", \\\"{x:1608,y:631,t:1526418319741};\\\", \\\"{x:1608,y:636,t:1526418319758};\\\", \\\"{x:1608,y:640,t:1526418319775};\\\", \\\"{x:1608,y:642,t:1526418319791};\\\", \\\"{x:1608,y:646,t:1526418319808};\\\", \\\"{x:1608,y:649,t:1526418319826};\\\", \\\"{x:1608,y:654,t:1526418319841};\\\", \\\"{x:1608,y:656,t:1526418319859};\\\", \\\"{x:1609,y:658,t:1526418319875};\\\", \\\"{x:1609,y:659,t:1526418319891};\\\", \\\"{x:1609,y:662,t:1526418319909};\\\", \\\"{x:1609,y:666,t:1526418319926};\\\", \\\"{x:1611,y:671,t:1526418319942};\\\", \\\"{x:1611,y:675,t:1526418319959};\\\", \\\"{x:1611,y:678,t:1526418319976};\\\", \\\"{x:1611,y:680,t:1526418319991};\\\", \\\"{x:1611,y:688,t:1526418320009};\\\", \\\"{x:1610,y:693,t:1526418320026};\\\", \\\"{x:1609,y:699,t:1526418320041};\\\", \\\"{x:1609,y:701,t:1526418320058};\\\", \\\"{x:1608,y:704,t:1526418320076};\\\", \\\"{x:1608,y:706,t:1526418320091};\\\", \\\"{x:1608,y:710,t:1526418320109};\\\", \\\"{x:1608,y:714,t:1526418320125};\\\", \\\"{x:1608,y:716,t:1526418320144};\\\", \\\"{x:1607,y:717,t:1526418320160};\\\", \\\"{x:1607,y:719,t:1526418320191};\\\", \\\"{x:1607,y:720,t:1526418320208};\\\", \\\"{x:1606,y:722,t:1526418320232};\\\", \\\"{x:1605,y:724,t:1526418320256};\\\", \\\"{x:1605,y:725,t:1526418320264};\\\", \\\"{x:1605,y:726,t:1526418320275};\\\", \\\"{x:1605,y:731,t:1526418320292};\\\", \\\"{x:1605,y:736,t:1526418320308};\\\", \\\"{x:1604,y:739,t:1526418320325};\\\", \\\"{x:1604,y:741,t:1526418320342};\\\", \\\"{x:1604,y:749,t:1526418320358};\\\", \\\"{x:1604,y:761,t:1526418320376};\\\", \\\"{x:1604,y:772,t:1526418320391};\\\", \\\"{x:1604,y:778,t:1526418320409};\\\", \\\"{x:1604,y:781,t:1526418320426};\\\", \\\"{x:1604,y:786,t:1526418320442};\\\", \\\"{x:1605,y:791,t:1526418320458};\\\", \\\"{x:1606,y:796,t:1526418320475};\\\", \\\"{x:1606,y:800,t:1526418320492};\\\", \\\"{x:1606,y:801,t:1526418320508};\\\", \\\"{x:1606,y:804,t:1526418320526};\\\", \\\"{x:1606,y:806,t:1526418320544};\\\", \\\"{x:1606,y:807,t:1526418320558};\\\", \\\"{x:1606,y:809,t:1526418320575};\\\", \\\"{x:1608,y:813,t:1526418320591};\\\", \\\"{x:1608,y:814,t:1526418320609};\\\", \\\"{x:1609,y:816,t:1526418320626};\\\", \\\"{x:1609,y:817,t:1526418320642};\\\", \\\"{x:1609,y:820,t:1526418320658};\\\", \\\"{x:1609,y:824,t:1526418320675};\\\", \\\"{x:1610,y:828,t:1526418320693};\\\", \\\"{x:1612,y:832,t:1526418320710};\\\", \\\"{x:1613,y:837,t:1526418320725};\\\", \\\"{x:1614,y:841,t:1526418320742};\\\", \\\"{x:1615,y:842,t:1526418320759};\\\", \\\"{x:1616,y:848,t:1526418320775};\\\", \\\"{x:1617,y:852,t:1526418320792};\\\", \\\"{x:1619,y:861,t:1526418320809};\\\", \\\"{x:1624,y:870,t:1526418320825};\\\", \\\"{x:1625,y:874,t:1526418320842};\\\", \\\"{x:1628,y:878,t:1526418320860};\\\", \\\"{x:1628,y:879,t:1526418320876};\\\", \\\"{x:1628,y:881,t:1526418320893};\\\", \\\"{x:1628,y:882,t:1526418320909};\\\", \\\"{x:1628,y:885,t:1526418320925};\\\", \\\"{x:1628,y:889,t:1526418320942};\\\", \\\"{x:1628,y:891,t:1526418320959};\\\", \\\"{x:1628,y:894,t:1526418320975};\\\", \\\"{x:1628,y:897,t:1526418320992};\\\", \\\"{x:1628,y:899,t:1526418321009};\\\", \\\"{x:1627,y:906,t:1526418321026};\\\", \\\"{x:1627,y:912,t:1526418321042};\\\", \\\"{x:1627,y:914,t:1526418321060};\\\", \\\"{x:1624,y:916,t:1526418321075};\\\", \\\"{x:1624,y:917,t:1526418321096};\\\", \\\"{x:1624,y:919,t:1526418321109};\\\", \\\"{x:1624,y:923,t:1526418321125};\\\", \\\"{x:1624,y:927,t:1526418321143};\\\", \\\"{x:1624,y:930,t:1526418321159};\\\", \\\"{x:1624,y:931,t:1526418321175};\\\", \\\"{x:1624,y:932,t:1526418321192};\\\", \\\"{x:1624,y:933,t:1526418321216};\\\", \\\"{x:1624,y:935,t:1526418321226};\\\", \\\"{x:1624,y:937,t:1526418321243};\\\", \\\"{x:1623,y:940,t:1526418321259};\\\", \\\"{x:1623,y:942,t:1526418321275};\\\", \\\"{x:1622,y:943,t:1526418321292};\\\", \\\"{x:1622,y:945,t:1526418321310};\\\", \\\"{x:1621,y:947,t:1526418321326};\\\", \\\"{x:1621,y:952,t:1526418321342};\\\", \\\"{x:1619,y:958,t:1526418321359};\\\", \\\"{x:1618,y:962,t:1526418321375};\\\", \\\"{x:1617,y:965,t:1526418321392};\\\", \\\"{x:1617,y:966,t:1526418321410};\\\", \\\"{x:1617,y:967,t:1526418321425};\\\", \\\"{x:1617,y:968,t:1526418321488};\\\", \\\"{x:1617,y:969,t:1526418321544};\\\", \\\"{x:1616,y:969,t:1526418321584};\\\", \\\"{x:1618,y:969,t:1526418321952};\\\", \\\"{x:1624,y:963,t:1526418321959};\\\", \\\"{x:1627,y:963,t:1526418321976};\\\", \\\"{x:1632,y:957,t:1526418331200};\\\", \\\"{x:1642,y:945,t:1526418331214};\\\", \\\"{x:1656,y:930,t:1526418331231};\\\", \\\"{x:1693,y:887,t:1526418331247};\\\", \\\"{x:1726,y:853,t:1526418331264};\\\", \\\"{x:1762,y:814,t:1526418331281};\\\", \\\"{x:1782,y:787,t:1526418331298};\\\", \\\"{x:1796,y:756,t:1526418331314};\\\", \\\"{x:1808,y:732,t:1526418331330};\\\", \\\"{x:1817,y:714,t:1526418331348};\\\", \\\"{x:1821,y:705,t:1526418331364};\\\", \\\"{x:1822,y:699,t:1526418331381};\\\", \\\"{x:1822,y:698,t:1526418331398};\\\", \\\"{x:1822,y:699,t:1526418331448};\\\", \\\"{x:1822,y:706,t:1526418331464};\\\", \\\"{x:1821,y:711,t:1526418331481};\\\", \\\"{x:1818,y:716,t:1526418331498};\\\", \\\"{x:1812,y:723,t:1526418331514};\\\", \\\"{x:1799,y:734,t:1526418331531};\\\", \\\"{x:1783,y:747,t:1526418331548};\\\", \\\"{x:1767,y:760,t:1526418331564};\\\", \\\"{x:1753,y:770,t:1526418331581};\\\", \\\"{x:1730,y:782,t:1526418331598};\\\", \\\"{x:1706,y:794,t:1526418331614};\\\", \\\"{x:1682,y:805,t:1526418331631};\\\", \\\"{x:1660,y:808,t:1526418331648};\\\", \\\"{x:1655,y:808,t:1526418331664};\\\", \\\"{x:1654,y:808,t:1526418331681};\\\", \\\"{x:1653,y:808,t:1526418331704};\\\", \\\"{x:1653,y:806,t:1526418331720};\\\", \\\"{x:1657,y:802,t:1526418331731};\\\", \\\"{x:1661,y:796,t:1526418331748};\\\", \\\"{x:1666,y:790,t:1526418331765};\\\", \\\"{x:1666,y:785,t:1526418331781};\\\", \\\"{x:1666,y:782,t:1526418331799};\\\", \\\"{x:1666,y:780,t:1526418331815};\\\", \\\"{x:1666,y:779,t:1526418331831};\\\", \\\"{x:1664,y:774,t:1526418331847};\\\", \\\"{x:1662,y:772,t:1526418331865};\\\", \\\"{x:1660,y:771,t:1526418331881};\\\", \\\"{x:1660,y:770,t:1526418331968};\\\", \\\"{x:1660,y:769,t:1526418331983};\\\", \\\"{x:1659,y:769,t:1526418332008};\\\", \\\"{x:1658,y:768,t:1526418332024};\\\", \\\"{x:1657,y:767,t:1526418332032};\\\", \\\"{x:1656,y:766,t:1526418332056};\\\", \\\"{x:1655,y:763,t:1526418332071};\\\", \\\"{x:1654,y:763,t:1526418332081};\\\", \\\"{x:1653,y:762,t:1526418332098};\\\", \\\"{x:1653,y:761,t:1526418332115};\\\", \\\"{x:1651,y:759,t:1526418332131};\\\", \\\"{x:1650,y:757,t:1526418332152};\\\", \\\"{x:1649,y:756,t:1526418332175};\\\", \\\"{x:1648,y:755,t:1526418332216};\\\", \\\"{x:1648,y:754,t:1526418332239};\\\", \\\"{x:1648,y:753,t:1526418332263};\\\", \\\"{x:1648,y:751,t:1526418332304};\\\", \\\"{x:1647,y:750,t:1526418332314};\\\", \\\"{x:1647,y:749,t:1526418332336};\\\", \\\"{x:1647,y:748,t:1526418332348};\\\", \\\"{x:1647,y:747,t:1526418332367};\\\", \\\"{x:1647,y:746,t:1526418332382};\\\", \\\"{x:1647,y:745,t:1526418332397};\\\", \\\"{x:1646,y:744,t:1526418332414};\\\", \\\"{x:1646,y:742,t:1526418332432};\\\", \\\"{x:1646,y:741,t:1526418332448};\\\", \\\"{x:1646,y:740,t:1526418332472};\\\", \\\"{x:1645,y:739,t:1526418332481};\\\", \\\"{x:1645,y:738,t:1526418332498};\\\", \\\"{x:1645,y:736,t:1526418332515};\\\", \\\"{x:1644,y:735,t:1526418332532};\\\", \\\"{x:1644,y:734,t:1526418332548};\\\", \\\"{x:1644,y:733,t:1526418332565};\\\", \\\"{x:1644,y:731,t:1526418332581};\\\", \\\"{x:1644,y:729,t:1526418332597};\\\", \\\"{x:1644,y:725,t:1526418332615};\\\", \\\"{x:1644,y:723,t:1526418332632};\\\", \\\"{x:1644,y:720,t:1526418332648};\\\", \\\"{x:1644,y:718,t:1526418332665};\\\", \\\"{x:1644,y:717,t:1526418332682};\\\", \\\"{x:1644,y:714,t:1526418332698};\\\", \\\"{x:1644,y:713,t:1526418332715};\\\", \\\"{x:1644,y:712,t:1526418332732};\\\", \\\"{x:1644,y:710,t:1526418332748};\\\", \\\"{x:1644,y:708,t:1526418332765};\\\", \\\"{x:1644,y:706,t:1526418332782};\\\", \\\"{x:1644,y:704,t:1526418332798};\\\", \\\"{x:1644,y:701,t:1526418332815};\\\", \\\"{x:1644,y:698,t:1526418332831};\\\", \\\"{x:1644,y:697,t:1526418332848};\\\", \\\"{x:1644,y:694,t:1526418332865};\\\", \\\"{x:1644,y:692,t:1526418332882};\\\", \\\"{x:1644,y:689,t:1526418332897};\\\", \\\"{x:1643,y:688,t:1526418332915};\\\", \\\"{x:1643,y:685,t:1526418332932};\\\", \\\"{x:1643,y:682,t:1526418332948};\\\", \\\"{x:1643,y:678,t:1526418332965};\\\", \\\"{x:1643,y:673,t:1526418332982};\\\", \\\"{x:1643,y:667,t:1526418332998};\\\", \\\"{x:1643,y:664,t:1526418333015};\\\", \\\"{x:1643,y:659,t:1526418333032};\\\", \\\"{x:1643,y:656,t:1526418333048};\\\", \\\"{x:1643,y:653,t:1526418333065};\\\", \\\"{x:1643,y:652,t:1526418333087};\\\", \\\"{x:1643,y:651,t:1526418333098};\\\", \\\"{x:1643,y:650,t:1526418333115};\\\", \\\"{x:1643,y:649,t:1526418333132};\\\", \\\"{x:1643,y:647,t:1526418333148};\\\", \\\"{x:1643,y:645,t:1526418333165};\\\", \\\"{x:1643,y:643,t:1526418333182};\\\", \\\"{x:1643,y:640,t:1526418333199};\\\", \\\"{x:1643,y:637,t:1526418333215};\\\", \\\"{x:1643,y:633,t:1526418333231};\\\", \\\"{x:1643,y:629,t:1526418333249};\\\", \\\"{x:1643,y:624,t:1526418333265};\\\", \\\"{x:1643,y:620,t:1526418333282};\\\", \\\"{x:1643,y:616,t:1526418333299};\\\", \\\"{x:1643,y:613,t:1526418333315};\\\", \\\"{x:1643,y:609,t:1526418333332};\\\", \\\"{x:1643,y:605,t:1526418333349};\\\", \\\"{x:1643,y:601,t:1526418333365};\\\", \\\"{x:1643,y:597,t:1526418333382};\\\", \\\"{x:1643,y:592,t:1526418333399};\\\", \\\"{x:1643,y:588,t:1526418333414};\\\", \\\"{x:1643,y:583,t:1526418333432};\\\", \\\"{x:1643,y:579,t:1526418333449};\\\", \\\"{x:1643,y:576,t:1526418333465};\\\", \\\"{x:1643,y:572,t:1526418333482};\\\", \\\"{x:1643,y:568,t:1526418333499};\\\", \\\"{x:1643,y:563,t:1526418333515};\\\", \\\"{x:1643,y:560,t:1526418333532};\\\", \\\"{x:1643,y:556,t:1526418333549};\\\", \\\"{x:1643,y:555,t:1526418333565};\\\", \\\"{x:1643,y:551,t:1526418333582};\\\", \\\"{x:1643,y:548,t:1526418333599};\\\", \\\"{x:1643,y:546,t:1526418333615};\\\", \\\"{x:1643,y:543,t:1526418333632};\\\", \\\"{x:1643,y:540,t:1526418333649};\\\", \\\"{x:1643,y:538,t:1526418333664};\\\", \\\"{x:1643,y:535,t:1526418333682};\\\", \\\"{x:1643,y:531,t:1526418333699};\\\", \\\"{x:1643,y:528,t:1526418333715};\\\", \\\"{x:1644,y:525,t:1526418333732};\\\", \\\"{x:1645,y:522,t:1526418333749};\\\", \\\"{x:1645,y:519,t:1526418333765};\\\", \\\"{x:1646,y:515,t:1526418333782};\\\", \\\"{x:1646,y:512,t:1526418333799};\\\", \\\"{x:1646,y:511,t:1526418333815};\\\", \\\"{x:1646,y:508,t:1526418333832};\\\", \\\"{x:1646,y:506,t:1526418333849};\\\", \\\"{x:1646,y:505,t:1526418334192};\\\", \\\"{x:1641,y:507,t:1526418334200};\\\", \\\"{x:1628,y:514,t:1526418334216};\\\", \\\"{x:1619,y:520,t:1526418334232};\\\", \\\"{x:1612,y:524,t:1526418334249};\\\", \\\"{x:1610,y:525,t:1526418334266};\\\", \\\"{x:1607,y:528,t:1526418334282};\\\", \\\"{x:1607,y:532,t:1526418334299};\\\", \\\"{x:1605,y:535,t:1526418334316};\\\", \\\"{x:1605,y:536,t:1526418334332};\\\", \\\"{x:1605,y:537,t:1526418334349};\\\", \\\"{x:1605,y:538,t:1526418334432};\\\", \\\"{x:1605,y:541,t:1526418334455};\\\", \\\"{x:1605,y:542,t:1526418334466};\\\", \\\"{x:1605,y:543,t:1526418334482};\\\", \\\"{x:1607,y:545,t:1526418334499};\\\", \\\"{x:1609,y:548,t:1526418334516};\\\", \\\"{x:1610,y:549,t:1526418334532};\\\", \\\"{x:1612,y:551,t:1526418334549};\\\", \\\"{x:1612,y:552,t:1526418334575};\\\", \\\"{x:1613,y:552,t:1526418334696};\\\", \\\"{x:1614,y:552,t:1526418334712};\\\", \\\"{x:1616,y:550,t:1526418334719};\\\", \\\"{x:1619,y:547,t:1526418334736};\\\", \\\"{x:1620,y:545,t:1526418334752};\\\", \\\"{x:1621,y:543,t:1526418334766};\\\", \\\"{x:1622,y:539,t:1526418334783};\\\", \\\"{x:1624,y:531,t:1526418334799};\\\", \\\"{x:1627,y:519,t:1526418334816};\\\", \\\"{x:1628,y:515,t:1526418334833};\\\", \\\"{x:1628,y:511,t:1526418334848};\\\", \\\"{x:1628,y:508,t:1526418334865};\\\", \\\"{x:1628,y:504,t:1526418334883};\\\", \\\"{x:1628,y:500,t:1526418334899};\\\", \\\"{x:1628,y:496,t:1526418334916};\\\", \\\"{x:1628,y:490,t:1526418334933};\\\", \\\"{x:1628,y:488,t:1526418334949};\\\", \\\"{x:1628,y:483,t:1526418334966};\\\", \\\"{x:1628,y:478,t:1526418334983};\\\", \\\"{x:1628,y:472,t:1526418334999};\\\", \\\"{x:1627,y:467,t:1526418335015};\\\", \\\"{x:1627,y:464,t:1526418335033};\\\", \\\"{x:1627,y:458,t:1526418335049};\\\", \\\"{x:1627,y:454,t:1526418335066};\\\", \\\"{x:1627,y:449,t:1526418335083};\\\", \\\"{x:1627,y:445,t:1526418335099};\\\", \\\"{x:1627,y:439,t:1526418335116};\\\", \\\"{x:1627,y:435,t:1526418335133};\\\", \\\"{x:1627,y:434,t:1526418335149};\\\", \\\"{x:1627,y:433,t:1526418335166};\\\", \\\"{x:1627,y:432,t:1526418335183};\\\", \\\"{x:1626,y:430,t:1526418335200};\\\", \\\"{x:1625,y:428,t:1526418335217};\\\", \\\"{x:1625,y:426,t:1526418335233};\\\", \\\"{x:1624,y:425,t:1526418335249};\\\", \\\"{x:1623,y:425,t:1526418335266};\\\", \\\"{x:1620,y:425,t:1526418335283};\\\", \\\"{x:1611,y:425,t:1526418335299};\\\", \\\"{x:1597,y:428,t:1526418335316};\\\", \\\"{x:1584,y:433,t:1526418335333};\\\", \\\"{x:1527,y:448,t:1526418335350};\\\", \\\"{x:1433,y:473,t:1526418335366};\\\", \\\"{x:1325,y:487,t:1526418335383};\\\", \\\"{x:1162,y:514,t:1526418335400};\\\", \\\"{x:1065,y:531,t:1526418335416};\\\", \\\"{x:966,y:553,t:1526418335433};\\\", \\\"{x:874,y:580,t:1526418335451};\\\", \\\"{x:788,y:605,t:1526418335468};\\\", \\\"{x:739,y:618,t:1526418335484};\\\", \\\"{x:719,y:622,t:1526418335501};\\\", \\\"{x:697,y:625,t:1526418335524};\\\", \\\"{x:681,y:628,t:1526418335541};\\\", \\\"{x:667,y:629,t:1526418335557};\\\", \\\"{x:657,y:629,t:1526418335574};\\\", \\\"{x:652,y:629,t:1526418335591};\\\", \\\"{x:637,y:628,t:1526418335608};\\\", \\\"{x:628,y:627,t:1526418335624};\\\", \\\"{x:626,y:626,t:1526418335640};\\\", \\\"{x:624,y:623,t:1526418335658};\\\", \\\"{x:623,y:620,t:1526418335676};\\\", \\\"{x:621,y:617,t:1526418335692};\\\", \\\"{x:614,y:617,t:1526418335708};\\\", \\\"{x:601,y:617,t:1526418335725};\\\", \\\"{x:587,y:617,t:1526418335741};\\\", \\\"{x:572,y:617,t:1526418335758};\\\", \\\"{x:553,y:617,t:1526418335775};\\\", \\\"{x:511,y:617,t:1526418335791};\\\", \\\"{x:389,y:617,t:1526418335808};\\\", \\\"{x:314,y:617,t:1526418335825};\\\", \\\"{x:268,y:616,t:1526418335841};\\\", \\\"{x:239,y:610,t:1526418335859};\\\", \\\"{x:230,y:606,t:1526418335875};\\\", \\\"{x:229,y:606,t:1526418335891};\\\", \\\"{x:230,y:603,t:1526418335908};\\\", \\\"{x:238,y:603,t:1526418335924};\\\", \\\"{x:247,y:603,t:1526418335941};\\\", \\\"{x:254,y:603,t:1526418335958};\\\", \\\"{x:262,y:602,t:1526418335974};\\\", \\\"{x:274,y:599,t:1526418335992};\\\", \\\"{x:292,y:597,t:1526418336007};\\\", \\\"{x:301,y:596,t:1526418336025};\\\", \\\"{x:307,y:595,t:1526418336041};\\\", \\\"{x:313,y:594,t:1526418336058};\\\", \\\"{x:321,y:592,t:1526418336075};\\\", \\\"{x:329,y:588,t:1526418336092};\\\", \\\"{x:332,y:588,t:1526418336108};\\\", \\\"{x:334,y:588,t:1526418336125};\\\", \\\"{x:335,y:587,t:1526418336142};\\\", \\\"{x:336,y:586,t:1526418336158};\\\", \\\"{x:337,y:584,t:1526418336175};\\\", \\\"{x:340,y:579,t:1526418336192};\\\", \\\"{x:343,y:574,t:1526418336209};\\\", \\\"{x:344,y:571,t:1526418336225};\\\", \\\"{x:345,y:567,t:1526418336242};\\\", \\\"{x:348,y:564,t:1526418336257};\\\", \\\"{x:353,y:558,t:1526418336275};\\\", \\\"{x:361,y:549,t:1526418336292};\\\", \\\"{x:368,y:543,t:1526418336308};\\\", \\\"{x:370,y:541,t:1526418336325};\\\", \\\"{x:364,y:542,t:1526418336384};\\\", \\\"{x:353,y:547,t:1526418336392};\\\", \\\"{x:319,y:563,t:1526418336409};\\\", \\\"{x:286,y:577,t:1526418336426};\\\", \\\"{x:262,y:585,t:1526418336442};\\\", \\\"{x:247,y:588,t:1526418336458};\\\", \\\"{x:240,y:589,t:1526418336475};\\\", \\\"{x:239,y:589,t:1526418336639};\\\", \\\"{x:235,y:589,t:1526418336647};\\\", \\\"{x:226,y:589,t:1526418336659};\\\", \\\"{x:207,y:589,t:1526418336675};\\\", \\\"{x:193,y:589,t:1526418336692};\\\", \\\"{x:185,y:589,t:1526418336708};\\\", \\\"{x:183,y:589,t:1526418336725};\\\", \\\"{x:182,y:592,t:1526418336767};\\\", \\\"{x:182,y:596,t:1526418336775};\\\", \\\"{x:181,y:606,t:1526418336791};\\\", \\\"{x:181,y:616,t:1526418336808};\\\", \\\"{x:181,y:619,t:1526418336824};\\\", \\\"{x:181,y:620,t:1526418336842};\\\", \\\"{x:181,y:621,t:1526418336892};\\\", \\\"{x:181,y:622,t:1526418336911};\\\", \\\"{x:181,y:623,t:1526418336925};\\\", \\\"{x:182,y:624,t:1526418337504};\\\", \\\"{x:195,y:627,t:1526418337512};\\\", \\\"{x:212,y:629,t:1526418337526};\\\", \\\"{x:271,y:639,t:1526418337543};\\\", \\\"{x:408,y:667,t:1526418337560};\\\", \\\"{x:699,y:731,t:1526418337576};\\\", \\\"{x:918,y:782,t:1526418337593};\\\", \\\"{x:1110,y:823,t:1526418337609};\\\", \\\"{x:1269,y:854,t:1526418337626};\\\", \\\"{x:1408,y:876,t:1526418337643};\\\", \\\"{x:1524,y:894,t:1526418337660};\\\", \\\"{x:1622,y:908,t:1526418337676};\\\", \\\"{x:1698,y:915,t:1526418337693};\\\", \\\"{x:1757,y:915,t:1526418337710};\\\", \\\"{x:1802,y:915,t:1526418337726};\\\", \\\"{x:1837,y:914,t:1526418337743};\\\", \\\"{x:1886,y:905,t:1526418337759};\\\", \\\"{x:1903,y:898,t:1526418337776};\\\", \\\"{x:1910,y:891,t:1526418337793};\\\", \\\"{x:1910,y:881,t:1526418337809};\\\", \\\"{x:1913,y:875,t:1526418337826};\\\", \\\"{x:1916,y:870,t:1526418337843};\\\", \\\"{x:1918,y:864,t:1526418337860};\\\", \\\"{x:1918,y:863,t:1526418337876};\\\", \\\"{x:1918,y:862,t:1526418337903};\\\", \\\"{x:1918,y:861,t:1526418337911};\\\", \\\"{x:1918,y:859,t:1526418337927};\\\", \\\"{x:1914,y:857,t:1526418337943};\\\", \\\"{x:1886,y:853,t:1526418337960};\\\", \\\"{x:1828,y:840,t:1526418337976};\\\", \\\"{x:1782,y:836,t:1526418337993};\\\", \\\"{x:1767,y:832,t:1526418338009};\\\", \\\"{x:1761,y:829,t:1526418338026};\\\", \\\"{x:1760,y:828,t:1526418338043};\\\", \\\"{x:1759,y:828,t:1526418338104};\\\", \\\"{x:1757,y:828,t:1526418338111};\\\", \\\"{x:1754,y:828,t:1526418338126};\\\", \\\"{x:1749,y:829,t:1526418338143};\\\", \\\"{x:1746,y:830,t:1526418338400};\\\", \\\"{x:1743,y:831,t:1526418338411};\\\", \\\"{x:1732,y:837,t:1526418338427};\\\", \\\"{x:1722,y:841,t:1526418338443};\\\", \\\"{x:1709,y:844,t:1526418338460};\\\", \\\"{x:1695,y:846,t:1526418338477};\\\", \\\"{x:1678,y:846,t:1526418338493};\\\", \\\"{x:1667,y:849,t:1526418338511};\\\", \\\"{x:1664,y:849,t:1526418338527};\\\", \\\"{x:1663,y:849,t:1526418338543};\\\", \\\"{x:1663,y:848,t:1526418338616};\\\", \\\"{x:1663,y:847,t:1526418338627};\\\", \\\"{x:1663,y:846,t:1526418338664};\\\", \\\"{x:1663,y:845,t:1526418338680};\\\", \\\"{x:1663,y:844,t:1526418338695};\\\", \\\"{x:1664,y:842,t:1526418338710};\\\", \\\"{x:1666,y:839,t:1526418338728};\\\", \\\"{x:1668,y:838,t:1526418338745};\\\", \\\"{x:1669,y:836,t:1526418338768};\\\", \\\"{x:1670,y:835,t:1526418338832};\\\", \\\"{x:1671,y:835,t:1526418338848};\\\", \\\"{x:1672,y:835,t:1526418338860};\\\", \\\"{x:1674,y:834,t:1526418338878};\\\", \\\"{x:1676,y:832,t:1526418338895};\\\", \\\"{x:1678,y:831,t:1526418338910};\\\", \\\"{x:1679,y:830,t:1526418339056};\\\", \\\"{x:1679,y:829,t:1526418339072};\\\", \\\"{x:1679,y:827,t:1526418339079};\\\", \\\"{x:1679,y:826,t:1526418339112};\\\", \\\"{x:1679,y:824,t:1526418339128};\\\", \\\"{x:1679,y:823,t:1526418339143};\\\", \\\"{x:1681,y:820,t:1526418339160};\\\", \\\"{x:1681,y:819,t:1526418339178};\\\", \\\"{x:1681,y:816,t:1526418339194};\\\", \\\"{x:1681,y:815,t:1526418339211};\\\", \\\"{x:1682,y:813,t:1526418339227};\\\", \\\"{x:1682,y:811,t:1526418339244};\\\", \\\"{x:1682,y:810,t:1526418339279};\\\", \\\"{x:1682,y:808,t:1526418339294};\\\", \\\"{x:1682,y:807,t:1526418339311};\\\", \\\"{x:1682,y:804,t:1526418339327};\\\", \\\"{x:1682,y:802,t:1526418339344};\\\", \\\"{x:1682,y:801,t:1526418339367};\\\", \\\"{x:1682,y:800,t:1526418339384};\\\", \\\"{x:1682,y:799,t:1526418339394};\\\", \\\"{x:1682,y:796,t:1526418339411};\\\", \\\"{x:1682,y:792,t:1526418339427};\\\", \\\"{x:1682,y:787,t:1526418339445};\\\", \\\"{x:1678,y:781,t:1526418339461};\\\", \\\"{x:1677,y:778,t:1526418339477};\\\", \\\"{x:1676,y:776,t:1526418339495};\\\", \\\"{x:1675,y:771,t:1526418339511};\\\", \\\"{x:1672,y:762,t:1526418339527};\\\", \\\"{x:1670,y:758,t:1526418339544};\\\", \\\"{x:1670,y:757,t:1526418339664};\\\", \\\"{x:1669,y:757,t:1526418339678};\\\", \\\"{x:1665,y:757,t:1526418339694};\\\", \\\"{x:1657,y:760,t:1526418339711};\\\", \\\"{x:1637,y:768,t:1526418339728};\\\", \\\"{x:1605,y:780,t:1526418339744};\\\", \\\"{x:1555,y:794,t:1526418339761};\\\", \\\"{x:1491,y:813,t:1526418339778};\\\", \\\"{x:1428,y:828,t:1526418339794};\\\", \\\"{x:1380,y:836,t:1526418339812};\\\", \\\"{x:1337,y:851,t:1526418339829};\\\", \\\"{x:1275,y:861,t:1526418339845};\\\", \\\"{x:1224,y:870,t:1526418339862};\\\", \\\"{x:1193,y:870,t:1526418339878};\\\", \\\"{x:1155,y:870,t:1526418339894};\\\", \\\"{x:1118,y:870,t:1526418339911};\\\", \\\"{x:1082,y:870,t:1526418339928};\\\", \\\"{x:1048,y:863,t:1526418339944};\\\", \\\"{x:1011,y:858,t:1526418339961};\\\", \\\"{x:936,y:851,t:1526418339979};\\\", \\\"{x:850,y:838,t:1526418339994};\\\", \\\"{x:769,y:825,t:1526418340012};\\\", \\\"{x:697,y:817,t:1526418340028};\\\", \\\"{x:661,y:813,t:1526418340044};\\\", \\\"{x:646,y:809,t:1526418340061};\\\", \\\"{x:643,y:807,t:1526418340078};\\\", \\\"{x:641,y:806,t:1526418340096};\\\", \\\"{x:640,y:806,t:1526418340192};\\\", \\\"{x:639,y:806,t:1526418340207};\\\", \\\"{x:638,y:806,t:1526418340240};\\\", \\\"{x:637,y:806,t:1526418340248};\\\", \\\"{x:635,y:806,t:1526418340262};\\\", \\\"{x:635,y:803,t:1526418340278};\\\", \\\"{x:635,y:802,t:1526418340296};\\\", \\\"{x:632,y:800,t:1526418340839};\\\", \\\"{x:631,y:800,t:1526418340847};\\\", \\\"{x:629,y:800,t:1526418340863};\\\", \\\"{x:627,y:800,t:1526418340878};\\\", \\\"{x:624,y:799,t:1526418340896};\\\", \\\"{x:617,y:798,t:1526418340913};\\\", \\\"{x:612,y:797,t:1526418340929};\\\", \\\"{x:604,y:795,t:1526418340946};\\\", \\\"{x:590,y:793,t:1526418340962};\\\", \\\"{x:569,y:790,t:1526418340979};\\\", \\\"{x:547,y:788,t:1526418340995};\\\", \\\"{x:532,y:785,t:1526418341012};\\\", \\\"{x:517,y:783,t:1526418341029};\\\", \\\"{x:512,y:782,t:1526418341045};\\\", \\\"{x:511,y:781,t:1526418341159};\\\", \\\"{x:511,y:780,t:1526418341184};\\\", \\\"{x:511,y:778,t:1526418341200};\\\", \\\"{x:511,y:777,t:1526418341215};\\\", \\\"{x:511,y:775,t:1526418341229};\\\", \\\"{x:511,y:772,t:1526418341245};\\\", \\\"{x:511,y:770,t:1526418341262};\\\", \\\"{x:511,y:764,t:1526418341279};\\\", \\\"{x:511,y:763,t:1526418341296};\\\", \\\"{x:512,y:762,t:1526418341312};\\\", \\\"{x:512,y:761,t:1526418341391};\\\", \\\"{x:511,y:760,t:1526418341416};\\\", \\\"{x:510,y:760,t:1526418341429};\\\", \\\"{x:509,y:760,t:1526418341446};\\\", \\\"{x:507,y:760,t:1526418341462};\\\", \\\"{x:504,y:758,t:1526418341479};\\\", \\\"{x:501,y:757,t:1526418341495};\\\", \\\"{x:500,y:756,t:1526418341512};\\\", \\\"{x:500,y:755,t:1526418341529};\\\", \\\"{x:500,y:751,t:1526418341546};\\\", \\\"{x:500,y:745,t:1526418341563};\\\", \\\"{x:501,y:739,t:1526418341580};\\\", \\\"{x:502,y:735,t:1526418341597};\\\", \\\"{x:503,y:732,t:1526418341612};\\\", \\\"{x:504,y:731,t:1526418341629};\\\", \\\"{x:505,y:729,t:1526418341646};\\\", \\\"{x:505,y:728,t:1526418341663};\\\", \\\"{x:506,y:727,t:1526418341679};\\\", \\\"{x:507,y:726,t:1526418342295};\\\", \\\"{x:510,y:726,t:1526418342312};\\\", \\\"{x:513,y:726,t:1526418342320};\\\", \\\"{x:514,y:726,t:1526418342329};\\\", \\\"{x:529,y:726,t:1526418342346};\\\", \\\"{x:621,y:741,t:1526418342364};\\\", \\\"{x:787,y:790,t:1526418342379};\\\", \\\"{x:970,y:827,t:1526418342396};\\\", \\\"{x:1150,y:849,t:1526418342414};\\\", \\\"{x:1320,y:882,t:1526418342430};\\\", \\\"{x:1585,y:930,t:1526418342447};\\\", \\\"{x:1715,y:951,t:1526418342463};\\\", \\\"{x:1779,y:960,t:1526418342480};\\\", \\\"{x:1806,y:964,t:1526418342497};\\\", \\\"{x:1817,y:965,t:1526418342514};\\\", \\\"{x:1820,y:966,t:1526418342530};\\\", \\\"{x:1822,y:966,t:1526418342547};\\\", \\\"{x:1824,y:966,t:1526418342564};\\\", \\\"{x:1826,y:966,t:1526418342580};\\\", \\\"{x:1823,y:966,t:1526418342637};\\\", \\\"{x:1815,y:966,t:1526418342645};\\\", \\\"{x:1781,y:966,t:1526418342662};\\\", \\\"{x:1697,y:966,t:1526418342678};\\\", \\\"{x:1639,y:966,t:1526418342695};\\\", \\\"{x:1618,y:969,t:1526418342711};\\\", \\\"{x:1616,y:969,t:1526418342728};\\\", \\\"{x:1612,y:969,t:1526418342942};\\\", \\\"{x:1603,y:969,t:1526418342949};\\\", \\\"{x:1593,y:970,t:1526418342962};\\\", \\\"{x:1583,y:970,t:1526418342978};\\\", \\\"{x:1582,y:971,t:1526418342995};\\\", \\\"{x:1582,y:972,t:1526418343053};\\\", \\\"{x:1583,y:972,t:1526418343077};\\\", \\\"{x:1586,y:972,t:1526418343085};\\\", \\\"{x:1587,y:972,t:1526418343095};\\\", \\\"{x:1590,y:972,t:1526418343112};\\\", \\\"{x:1595,y:972,t:1526418343128};\\\", \\\"{x:1600,y:972,t:1526418343145};\\\", \\\"{x:1602,y:972,t:1526418343162};\\\", \\\"{x:1604,y:972,t:1526418343179};\\\", \\\"{x:1605,y:972,t:1526418343195};\\\", \\\"{x:1607,y:972,t:1526418343212};\\\", \\\"{x:1608,y:972,t:1526418343229};\\\", \\\"{x:1609,y:972,t:1526418343461};\\\", \\\"{x:1610,y:971,t:1526418343469};\\\", \\\"{x:1614,y:969,t:1526418343479};\\\", \\\"{x:1621,y:961,t:1526418343495};\\\", \\\"{x:1632,y:942,t:1526418343511};\\\", \\\"{x:1642,y:917,t:1526418343528};\\\", \\\"{x:1658,y:873,t:1526418343545};\\\", \\\"{x:1668,y:811,t:1526418343562};\\\", \\\"{x:1671,y:746,t:1526418343579};\\\", \\\"{x:1673,y:696,t:1526418343595};\\\", \\\"{x:1678,y:656,t:1526418343613};\\\", \\\"{x:1682,y:598,t:1526418343629};\\\", \\\"{x:1682,y:568,t:1526418343645};\\\", \\\"{x:1682,y:539,t:1526418343662};\\\", \\\"{x:1679,y:522,t:1526418343679};\\\", \\\"{x:1675,y:510,t:1526418343695};\\\", \\\"{x:1672,y:501,t:1526418343711};\\\", \\\"{x:1665,y:489,t:1526418343730};\\\", \\\"{x:1657,y:478,t:1526418343747};\\\", \\\"{x:1646,y:468,t:1526418343762};\\\", \\\"{x:1640,y:464,t:1526418343779};\\\", \\\"{x:1635,y:461,t:1526418343796};\\\", \\\"{x:1631,y:458,t:1526418343812};\\\", \\\"{x:1623,y:454,t:1526418343829};\\\", \\\"{x:1618,y:453,t:1526418343846};\\\", \\\"{x:1617,y:452,t:1526418343862};\\\", \\\"{x:1616,y:452,t:1526418343893};\\\", \\\"{x:1614,y:451,t:1526418343901};\\\", \\\"{x:1614,y:449,t:1526418343912};\\\", \\\"{x:1613,y:449,t:1526418343929};\\\", \\\"{x:1612,y:448,t:1526418343946};\\\", \\\"{x:1612,y:447,t:1526418343989};\\\", \\\"{x:1612,y:446,t:1526418344006};\\\", \\\"{x:1612,y:445,t:1526418344022};\\\", \\\"{x:1612,y:448,t:1526418344238};\\\", \\\"{x:1612,y:452,t:1526418344246};\\\", \\\"{x:1612,y:465,t:1526418344263};\\\", \\\"{x:1612,y:477,t:1526418344279};\\\", \\\"{x:1614,y:486,t:1526418344296};\\\", \\\"{x:1615,y:493,t:1526418344313};\\\", \\\"{x:1616,y:500,t:1526418344329};\\\", \\\"{x:1617,y:506,t:1526418344346};\\\", \\\"{x:1618,y:513,t:1526418344363};\\\", \\\"{x:1618,y:519,t:1526418344379};\\\", \\\"{x:1618,y:523,t:1526418344396};\\\", \\\"{x:1618,y:530,t:1526418344413};\\\", \\\"{x:1618,y:533,t:1526418344429};\\\", \\\"{x:1618,y:537,t:1526418344446};\\\", \\\"{x:1618,y:540,t:1526418344463};\\\", \\\"{x:1618,y:544,t:1526418344479};\\\", \\\"{x:1618,y:547,t:1526418344496};\\\", \\\"{x:1618,y:551,t:1526418344514};\\\", \\\"{x:1618,y:553,t:1526418344529};\\\", \\\"{x:1618,y:554,t:1526418344546};\\\", \\\"{x:1618,y:555,t:1526418344564};\\\", \\\"{x:1618,y:558,t:1526418344580};\\\", \\\"{x:1618,y:560,t:1526418344596};\\\", \\\"{x:1618,y:563,t:1526418344613};\\\", \\\"{x:1618,y:565,t:1526418344629};\\\", \\\"{x:1618,y:568,t:1526418344646};\\\", \\\"{x:1618,y:571,t:1526418344663};\\\", \\\"{x:1618,y:574,t:1526418344680};\\\", \\\"{x:1618,y:577,t:1526418344696};\\\", \\\"{x:1618,y:578,t:1526418344713};\\\", \\\"{x:1618,y:581,t:1526418344730};\\\", \\\"{x:1618,y:583,t:1526418344746};\\\", \\\"{x:1617,y:585,t:1526418344763};\\\", \\\"{x:1616,y:590,t:1526418344780};\\\", \\\"{x:1615,y:592,t:1526418344796};\\\", \\\"{x:1614,y:595,t:1526418344813};\\\", \\\"{x:1614,y:598,t:1526418344830};\\\", \\\"{x:1614,y:601,t:1526418344846};\\\", \\\"{x:1614,y:604,t:1526418344863};\\\", \\\"{x:1614,y:609,t:1526418344880};\\\", \\\"{x:1614,y:611,t:1526418344896};\\\", \\\"{x:1614,y:614,t:1526418344913};\\\", \\\"{x:1614,y:618,t:1526418344930};\\\", \\\"{x:1614,y:624,t:1526418344946};\\\", \\\"{x:1614,y:630,t:1526418344964};\\\", \\\"{x:1614,y:633,t:1526418344981};\\\", \\\"{x:1614,y:638,t:1526418344996};\\\", \\\"{x:1614,y:643,t:1526418345013};\\\", \\\"{x:1614,y:645,t:1526418345031};\\\", \\\"{x:1614,y:648,t:1526418345048};\\\", \\\"{x:1614,y:650,t:1526418345063};\\\", \\\"{x:1614,y:652,t:1526418345080};\\\", \\\"{x:1614,y:655,t:1526418345097};\\\", \\\"{x:1614,y:658,t:1526418345113};\\\", \\\"{x:1614,y:662,t:1526418345130};\\\", \\\"{x:1614,y:667,t:1526418345147};\\\", \\\"{x:1614,y:669,t:1526418345163};\\\", \\\"{x:1614,y:674,t:1526418345180};\\\", \\\"{x:1614,y:682,t:1526418345197};\\\", \\\"{x:1614,y:687,t:1526418345214};\\\", \\\"{x:1614,y:691,t:1526418345230};\\\", \\\"{x:1614,y:695,t:1526418345247};\\\", \\\"{x:1614,y:698,t:1526418345263};\\\", \\\"{x:1614,y:701,t:1526418345280};\\\", \\\"{x:1614,y:705,t:1526418345297};\\\", \\\"{x:1614,y:708,t:1526418345313};\\\", \\\"{x:1614,y:711,t:1526418345330};\\\", \\\"{x:1614,y:713,t:1526418345347};\\\", \\\"{x:1614,y:715,t:1526418345364};\\\", \\\"{x:1614,y:720,t:1526418345380};\\\", \\\"{x:1614,y:727,t:1526418345397};\\\", \\\"{x:1614,y:732,t:1526418345413};\\\", \\\"{x:1614,y:735,t:1526418345430};\\\", \\\"{x:1614,y:740,t:1526418345447};\\\", \\\"{x:1614,y:747,t:1526418345464};\\\", \\\"{x:1614,y:752,t:1526418345480};\\\", \\\"{x:1614,y:759,t:1526418345497};\\\", \\\"{x:1614,y:764,t:1526418345514};\\\", \\\"{x:1614,y:769,t:1526418345530};\\\", \\\"{x:1612,y:774,t:1526418345547};\\\", \\\"{x:1612,y:780,t:1526418345564};\\\", \\\"{x:1612,y:785,t:1526418345580};\\\", \\\"{x:1612,y:793,t:1526418345597};\\\", \\\"{x:1612,y:799,t:1526418345614};\\\", \\\"{x:1612,y:801,t:1526418345630};\\\", \\\"{x:1612,y:804,t:1526418345647};\\\", \\\"{x:1612,y:808,t:1526418345664};\\\", \\\"{x:1612,y:811,t:1526418345680};\\\", \\\"{x:1612,y:814,t:1526418345697};\\\", \\\"{x:1612,y:816,t:1526418345714};\\\", \\\"{x:1612,y:819,t:1526418345730};\\\", \\\"{x:1612,y:821,t:1526418345747};\\\", \\\"{x:1612,y:823,t:1526418345764};\\\", \\\"{x:1612,y:825,t:1526418345780};\\\", \\\"{x:1612,y:830,t:1526418345797};\\\", \\\"{x:1612,y:834,t:1526418345814};\\\", \\\"{x:1612,y:839,t:1526418345831};\\\", \\\"{x:1612,y:846,t:1526418345847};\\\", \\\"{x:1612,y:858,t:1526418345864};\\\", \\\"{x:1612,y:866,t:1526418345881};\\\", \\\"{x:1612,y:875,t:1526418345898};\\\", \\\"{x:1612,y:885,t:1526418345914};\\\", \\\"{x:1612,y:898,t:1526418345931};\\\", \\\"{x:1612,y:910,t:1526418345947};\\\", \\\"{x:1612,y:917,t:1526418345965};\\\", \\\"{x:1612,y:928,t:1526418345981};\\\", \\\"{x:1612,y:935,t:1526418345997};\\\", \\\"{x:1612,y:941,t:1526418346014};\\\", \\\"{x:1612,y:952,t:1526418346032};\\\", \\\"{x:1612,y:962,t:1526418346047};\\\", \\\"{x:1612,y:966,t:1526418346064};\\\", \\\"{x:1612,y:968,t:1526418346082};\\\", \\\"{x:1612,y:969,t:1526418346098};\\\", \\\"{x:1612,y:967,t:1526418346278};\\\", \\\"{x:1612,y:963,t:1526418346286};\\\", \\\"{x:1612,y:958,t:1526418346297};\\\", \\\"{x:1612,y:950,t:1526418346314};\\\", \\\"{x:1612,y:942,t:1526418346331};\\\", \\\"{x:1612,y:932,t:1526418346348};\\\", \\\"{x:1611,y:923,t:1526418346364};\\\", \\\"{x:1610,y:913,t:1526418346381};\\\", \\\"{x:1610,y:907,t:1526418346397};\\\", \\\"{x:1610,y:903,t:1526418346414};\\\", \\\"{x:1610,y:897,t:1526418346431};\\\", \\\"{x:1610,y:892,t:1526418346448};\\\", \\\"{x:1610,y:886,t:1526418346464};\\\", \\\"{x:1608,y:884,t:1526418346481};\\\", \\\"{x:1608,y:881,t:1526418346498};\\\", \\\"{x:1608,y:877,t:1526418346515};\\\", \\\"{x:1608,y:874,t:1526418346531};\\\", \\\"{x:1609,y:870,t:1526418346548};\\\", \\\"{x:1609,y:867,t:1526418346564};\\\", \\\"{x:1609,y:861,t:1526418346581};\\\", \\\"{x:1609,y:860,t:1526418346598};\\\", \\\"{x:1610,y:857,t:1526418346615};\\\", \\\"{x:1611,y:855,t:1526418346631};\\\", \\\"{x:1611,y:852,t:1526418346648};\\\", \\\"{x:1611,y:851,t:1526418346664};\\\", \\\"{x:1611,y:849,t:1526418346681};\\\", \\\"{x:1611,y:848,t:1526418346699};\\\", \\\"{x:1611,y:846,t:1526418346714};\\\", \\\"{x:1611,y:845,t:1526418346731};\\\", \\\"{x:1611,y:844,t:1526418346748};\\\", \\\"{x:1611,y:842,t:1526418346765};\\\", \\\"{x:1611,y:841,t:1526418346782};\\\", \\\"{x:1611,y:840,t:1526418346798};\\\", \\\"{x:1611,y:839,t:1526418346814};\\\", \\\"{x:1612,y:837,t:1526418346832};\\\", \\\"{x:1612,y:836,t:1526418346848};\\\", \\\"{x:1612,y:833,t:1526418346866};\\\", \\\"{x:1612,y:832,t:1526418346882};\\\", \\\"{x:1612,y:830,t:1526418346899};\\\", \\\"{x:1612,y:828,t:1526418346917};\\\", \\\"{x:1612,y:826,t:1526418346932};\\\", \\\"{x:1612,y:824,t:1526418346948};\\\", \\\"{x:1612,y:823,t:1526418346966};\\\", \\\"{x:1612,y:821,t:1526418346982};\\\", \\\"{x:1612,y:818,t:1526418346998};\\\", \\\"{x:1612,y:817,t:1526418347015};\\\", \\\"{x:1612,y:814,t:1526418347032};\\\", \\\"{x:1612,y:812,t:1526418347048};\\\", \\\"{x:1612,y:810,t:1526418347066};\\\", \\\"{x:1612,y:808,t:1526418347081};\\\", \\\"{x:1612,y:807,t:1526418347101};\\\", \\\"{x:1612,y:806,t:1526418347116};\\\", \\\"{x:1612,y:805,t:1526418347132};\\\", \\\"{x:1612,y:804,t:1526418347150};\\\", \\\"{x:1612,y:803,t:1526418347166};\\\", \\\"{x:1612,y:802,t:1526418347189};\\\", \\\"{x:1612,y:801,t:1526418347221};\\\", \\\"{x:1612,y:800,t:1526418347232};\\\", \\\"{x:1612,y:798,t:1526418347248};\\\", \\\"{x:1612,y:795,t:1526418347265};\\\", \\\"{x:1612,y:790,t:1526418347282};\\\", \\\"{x:1612,y:785,t:1526418347298};\\\", \\\"{x:1612,y:780,t:1526418347315};\\\", \\\"{x:1613,y:773,t:1526418347332};\\\", \\\"{x:1613,y:766,t:1526418347348};\\\", \\\"{x:1615,y:759,t:1526418347364};\\\", \\\"{x:1615,y:755,t:1526418347382};\\\", \\\"{x:1616,y:751,t:1526418347398};\\\", \\\"{x:1616,y:748,t:1526418347415};\\\", \\\"{x:1617,y:746,t:1526418347432};\\\", \\\"{x:1617,y:743,t:1526418347448};\\\", \\\"{x:1617,y:742,t:1526418347465};\\\", \\\"{x:1617,y:740,t:1526418347482};\\\", \\\"{x:1617,y:738,t:1526418347509};\\\", \\\"{x:1617,y:737,t:1526418347517};\\\", \\\"{x:1617,y:736,t:1526418347533};\\\", \\\"{x:1617,y:734,t:1526418347548};\\\", \\\"{x:1617,y:729,t:1526418347565};\\\", \\\"{x:1617,y:725,t:1526418347582};\\\", \\\"{x:1617,y:721,t:1526418347598};\\\", \\\"{x:1617,y:716,t:1526418347615};\\\", \\\"{x:1617,y:711,t:1526418347632};\\\", \\\"{x:1617,y:706,t:1526418347649};\\\", \\\"{x:1617,y:702,t:1526418347665};\\\", \\\"{x:1617,y:698,t:1526418347682};\\\", \\\"{x:1617,y:694,t:1526418347699};\\\", \\\"{x:1617,y:690,t:1526418347715};\\\", \\\"{x:1617,y:688,t:1526418347733};\\\", \\\"{x:1617,y:685,t:1526418347749};\\\", \\\"{x:1617,y:683,t:1526418347765};\\\", \\\"{x:1618,y:681,t:1526418347783};\\\", \\\"{x:1618,y:678,t:1526418347799};\\\", \\\"{x:1618,y:675,t:1526418347815};\\\", \\\"{x:1618,y:671,t:1526418347832};\\\", \\\"{x:1618,y:667,t:1526418347849};\\\", \\\"{x:1618,y:663,t:1526418347865};\\\", \\\"{x:1618,y:658,t:1526418347882};\\\", \\\"{x:1618,y:654,t:1526418347900};\\\", \\\"{x:1618,y:649,t:1526418347915};\\\", \\\"{x:1618,y:645,t:1526418347932};\\\", \\\"{x:1618,y:639,t:1526418347949};\\\", \\\"{x:1618,y:635,t:1526418347965};\\\", \\\"{x:1617,y:630,t:1526418347982};\\\", \\\"{x:1616,y:625,t:1526418348000};\\\", \\\"{x:1615,y:618,t:1526418348015};\\\", \\\"{x:1615,y:612,t:1526418348032};\\\", \\\"{x:1614,y:607,t:1526418348049};\\\", \\\"{x:1613,y:601,t:1526418348066};\\\", \\\"{x:1611,y:596,t:1526418348082};\\\", \\\"{x:1610,y:588,t:1526418348100};\\\", \\\"{x:1609,y:583,t:1526418348115};\\\", \\\"{x:1607,y:578,t:1526418348133};\\\", \\\"{x:1607,y:570,t:1526418348150};\\\", \\\"{x:1607,y:565,t:1526418348165};\\\", \\\"{x:1606,y:559,t:1526418348182};\\\", \\\"{x:1606,y:552,t:1526418348199};\\\", \\\"{x:1606,y:545,t:1526418348216};\\\", \\\"{x:1605,y:538,t:1526418348232};\\\", \\\"{x:1605,y:529,t:1526418348250};\\\", \\\"{x:1605,y:518,t:1526418348266};\\\", \\\"{x:1605,y:507,t:1526418348283};\\\", \\\"{x:1605,y:497,t:1526418348300};\\\", \\\"{x:1605,y:489,t:1526418348316};\\\", \\\"{x:1604,y:484,t:1526418348332};\\\", \\\"{x:1600,y:484,t:1526418348381};\\\", \\\"{x:1582,y:488,t:1526418348389};\\\", \\\"{x:1537,y:503,t:1526418348400};\\\", \\\"{x:1373,y:537,t:1526418348416};\\\", \\\"{x:1153,y:591,t:1526418348433};\\\", \\\"{x:971,y:643,t:1526418348449};\\\", \\\"{x:799,y:690,t:1526418348466};\\\", \\\"{x:667,y:724,t:1526418348482};\\\", \\\"{x:581,y:751,t:1526418348499};\\\", \\\"{x:546,y:763,t:1526418348516};\\\", \\\"{x:530,y:769,t:1526418348532};\\\", \\\"{x:527,y:772,t:1526418348549};\\\", \\\"{x:527,y:773,t:1526418348566};\\\", \\\"{x:526,y:773,t:1526418348597};\\\", \\\"{x:521,y:773,t:1526418348605};\\\", \\\"{x:512,y:776,t:1526418348617};\\\", \\\"{x:491,y:779,t:1526418348633};\\\", \\\"{x:473,y:783,t:1526418348649};\\\", \\\"{x:467,y:783,t:1526418348666};\\\", \\\"{x:466,y:783,t:1526418348683};\\\", \\\"{x:465,y:777,t:1526418348699};\\\", \\\"{x:465,y:764,t:1526418348716};\\\", \\\"{x:470,y:746,t:1526418348733};\\\", \\\"{x:475,y:739,t:1526418348749};\\\", \\\"{x:479,y:732,t:1526418348767};\\\", \\\"{x:480,y:731,t:1526418348784};\\\", \\\"{x:480,y:729,t:1526418348799};\\\", \\\"{x:482,y:728,t:1526418348816};\\\", \\\"{x:483,y:726,t:1526418348833};\\\", \\\"{x:486,y:725,t:1526418349566};\\\", \\\"{x:492,y:725,t:1526418349574};\\\", \\\"{x:497,y:725,t:1526418349584};\\\" ] }, { \\\"rt\\\": 27780, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 274230, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -A -2-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:499,y:724,t:1526418350905};\\\", \\\"{x:499,y:723,t:1526418352381};\\\", \\\"{x:500,y:723,t:1526418352389};\\\", \\\"{x:507,y:723,t:1526418352405};\\\", \\\"{x:519,y:723,t:1526418352422};\\\", \\\"{x:538,y:723,t:1526418352439};\\\", \\\"{x:571,y:729,t:1526418352456};\\\", \\\"{x:633,y:738,t:1526418352473};\\\", \\\"{x:728,y:753,t:1526418352485};\\\", \\\"{x:833,y:767,t:1526418352503};\\\", \\\"{x:930,y:783,t:1526418352520};\\\", \\\"{x:1033,y:796,t:1526418352536};\\\", \\\"{x:1125,y:814,t:1526418352553};\\\", \\\"{x:1206,y:825,t:1526418352569};\\\", \\\"{x:1276,y:837,t:1526418352585};\\\", \\\"{x:1341,y:847,t:1526418352602};\\\", \\\"{x:1374,y:851,t:1526418352619};\\\", \\\"{x:1394,y:854,t:1526418352636};\\\", \\\"{x:1405,y:855,t:1526418352653};\\\", \\\"{x:1417,y:859,t:1526418352669};\\\", \\\"{x:1422,y:859,t:1526418352686};\\\", \\\"{x:1424,y:859,t:1526418352702};\\\", \\\"{x:1424,y:860,t:1526418352798};\\\", \\\"{x:1424,y:861,t:1526418352814};\\\", \\\"{x:1422,y:861,t:1526418352822};\\\", \\\"{x:1418,y:861,t:1526418352836};\\\", \\\"{x:1393,y:859,t:1526418352852};\\\", \\\"{x:1347,y:853,t:1526418352869};\\\", \\\"{x:1309,y:849,t:1526418352885};\\\", \\\"{x:1251,y:844,t:1526418352902};\\\", \\\"{x:1206,y:837,t:1526418352920};\\\", \\\"{x:1187,y:833,t:1526418352936};\\\", \\\"{x:1180,y:831,t:1526418352952};\\\", \\\"{x:1179,y:830,t:1526418352969};\\\", \\\"{x:1179,y:829,t:1526418352986};\\\", \\\"{x:1181,y:829,t:1526418353125};\\\", \\\"{x:1184,y:829,t:1526418353135};\\\", \\\"{x:1198,y:829,t:1526418353152};\\\", \\\"{x:1213,y:829,t:1526418353170};\\\", \\\"{x:1226,y:829,t:1526418353186};\\\", \\\"{x:1227,y:829,t:1526418353202};\\\", \\\"{x:1229,y:829,t:1526418353219};\\\", \\\"{x:1229,y:830,t:1526418353350};\\\", \\\"{x:1227,y:831,t:1526418353382};\\\", \\\"{x:1226,y:831,t:1526418353398};\\\", \\\"{x:1223,y:832,t:1526418353405};\\\", \\\"{x:1222,y:832,t:1526418353429};\\\", \\\"{x:1222,y:833,t:1526418353437};\\\", \\\"{x:1221,y:833,t:1526418353726};\\\", \\\"{x:1220,y:833,t:1526418353903};\\\", \\\"{x:1219,y:833,t:1526418353920};\\\", \\\"{x:1218,y:833,t:1526418353937};\\\", \\\"{x:1217,y:833,t:1526418354014};\\\", \\\"{x:1216,y:833,t:1526418355645};\\\", \\\"{x:1216,y:832,t:1526418355669};\\\", \\\"{x:1215,y:832,t:1526418355685};\\\", \\\"{x:1214,y:832,t:1526418355694};\\\", \\\"{x:1214,y:831,t:1526418355709};\\\", \\\"{x:1216,y:831,t:1526418359102};\\\", \\\"{x:1218,y:831,t:1526418359109};\\\", \\\"{x:1222,y:830,t:1526418359123};\\\", \\\"{x:1224,y:830,t:1526418359139};\\\", \\\"{x:1227,y:830,t:1526418359156};\\\", \\\"{x:1235,y:830,t:1526418359172};\\\", \\\"{x:1246,y:830,t:1526418359189};\\\", \\\"{x:1266,y:830,t:1526418359205};\\\", \\\"{x:1279,y:830,t:1526418359222};\\\", \\\"{x:1284,y:830,t:1526418359239};\\\", \\\"{x:1289,y:830,t:1526418359257};\\\", \\\"{x:1290,y:830,t:1526418359272};\\\", \\\"{x:1291,y:830,t:1526418359390};\\\", \\\"{x:1292,y:830,t:1526418359429};\\\", \\\"{x:1294,y:830,t:1526418359439};\\\", \\\"{x:1297,y:830,t:1526418359456};\\\", \\\"{x:1301,y:830,t:1526418359472};\\\", \\\"{x:1304,y:830,t:1526418359489};\\\", \\\"{x:1306,y:830,t:1526418359506};\\\", \\\"{x:1307,y:830,t:1526418359522};\\\", \\\"{x:1311,y:830,t:1526418359539};\\\", \\\"{x:1317,y:830,t:1526418359557};\\\", \\\"{x:1323,y:829,t:1526418359573};\\\", \\\"{x:1329,y:829,t:1526418359590};\\\", \\\"{x:1330,y:829,t:1526418359678};\\\", \\\"{x:1331,y:829,t:1526418359690};\\\", \\\"{x:1332,y:829,t:1526418359706};\\\", \\\"{x:1333,y:829,t:1526418359722};\\\", \\\"{x:1334,y:829,t:1526418359758};\\\", \\\"{x:1335,y:829,t:1526418359773};\\\", \\\"{x:1336,y:829,t:1526418359798};\\\", \\\"{x:1337,y:829,t:1526418359814};\\\", \\\"{x:1338,y:829,t:1526418359822};\\\", \\\"{x:1339,y:829,t:1526418359847};\\\", \\\"{x:1341,y:828,t:1526418359877};\\\", \\\"{x:1342,y:827,t:1526418359890};\\\", \\\"{x:1343,y:827,t:1526418359910};\\\", \\\"{x:1345,y:826,t:1526418359934};\\\", \\\"{x:1347,y:826,t:1526418360070};\\\", \\\"{x:1348,y:826,t:1526418360118};\\\", \\\"{x:1348,y:825,t:1526418361318};\\\", \\\"{x:1348,y:824,t:1526418361349};\\\", \\\"{x:1348,y:823,t:1526418361365};\\\", \\\"{x:1349,y:823,t:1526418361373};\\\", \\\"{x:1349,y:822,t:1526418361390};\\\", \\\"{x:1349,y:821,t:1526418361406};\\\", \\\"{x:1349,y:820,t:1526418361423};\\\", \\\"{x:1349,y:819,t:1526418361446};\\\", \\\"{x:1350,y:818,t:1526418361486};\\\", \\\"{x:1350,y:817,t:1526418361494};\\\", \\\"{x:1350,y:816,t:1526418361525};\\\", \\\"{x:1350,y:815,t:1526418361565};\\\", \\\"{x:1350,y:814,t:1526418361589};\\\", \\\"{x:1350,y:813,t:1526418361606};\\\", \\\"{x:1350,y:812,t:1526418361628};\\\", \\\"{x:1350,y:811,t:1526418361640};\\\", \\\"{x:1350,y:809,t:1526418361657};\\\", \\\"{x:1350,y:807,t:1526418361673};\\\", \\\"{x:1350,y:805,t:1526418361690};\\\", \\\"{x:1350,y:803,t:1526418361707};\\\", \\\"{x:1350,y:802,t:1526418361723};\\\", \\\"{x:1350,y:800,t:1526418361740};\\\", \\\"{x:1350,y:797,t:1526418361757};\\\", \\\"{x:1350,y:796,t:1526418361773};\\\", \\\"{x:1350,y:793,t:1526418361789};\\\", \\\"{x:1349,y:791,t:1526418361807};\\\", \\\"{x:1349,y:790,t:1526418361823};\\\", \\\"{x:1349,y:788,t:1526418361840};\\\", \\\"{x:1349,y:787,t:1526418361857};\\\", \\\"{x:1348,y:785,t:1526418361873};\\\", \\\"{x:1348,y:784,t:1526418361889};\\\", \\\"{x:1348,y:782,t:1526418361907};\\\", \\\"{x:1348,y:781,t:1526418361923};\\\", \\\"{x:1347,y:778,t:1526418361940};\\\", \\\"{x:1347,y:775,t:1526418361957};\\\", \\\"{x:1346,y:773,t:1526418361972};\\\", \\\"{x:1346,y:772,t:1526418361990};\\\", \\\"{x:1346,y:768,t:1526418362007};\\\", \\\"{x:1346,y:766,t:1526418362023};\\\", \\\"{x:1346,y:761,t:1526418362040};\\\", \\\"{x:1346,y:757,t:1526418362057};\\\", \\\"{x:1346,y:753,t:1526418362073};\\\", \\\"{x:1346,y:750,t:1526418362090};\\\", \\\"{x:1345,y:747,t:1526418362107};\\\", \\\"{x:1345,y:745,t:1526418362123};\\\", \\\"{x:1344,y:741,t:1526418362141};\\\", \\\"{x:1344,y:737,t:1526418362158};\\\", \\\"{x:1344,y:736,t:1526418362173};\\\", \\\"{x:1344,y:734,t:1526418362190};\\\", \\\"{x:1344,y:731,t:1526418362207};\\\", \\\"{x:1343,y:728,t:1526418362223};\\\", \\\"{x:1343,y:725,t:1526418362240};\\\", \\\"{x:1343,y:721,t:1526418362258};\\\", \\\"{x:1342,y:718,t:1526418362274};\\\", \\\"{x:1341,y:717,t:1526418362291};\\\", \\\"{x:1341,y:715,t:1526418362308};\\\", \\\"{x:1341,y:712,t:1526418362323};\\\", \\\"{x:1341,y:711,t:1526418362341};\\\", \\\"{x:1341,y:707,t:1526418362358};\\\", \\\"{x:1341,y:705,t:1526418362374};\\\", \\\"{x:1341,y:702,t:1526418362391};\\\", \\\"{x:1341,y:699,t:1526418362408};\\\", \\\"{x:1341,y:696,t:1526418362424};\\\", \\\"{x:1341,y:694,t:1526418362441};\\\", \\\"{x:1341,y:693,t:1526418362461};\\\", \\\"{x:1341,y:692,t:1526418362474};\\\", \\\"{x:1341,y:691,t:1526418362490};\\\", \\\"{x:1341,y:688,t:1526418362507};\\\", \\\"{x:1341,y:686,t:1526418362525};\\\", \\\"{x:1341,y:685,t:1526418362550};\\\", \\\"{x:1341,y:683,t:1526418362557};\\\", \\\"{x:1341,y:682,t:1526418362573};\\\", \\\"{x:1342,y:679,t:1526418362591};\\\", \\\"{x:1342,y:677,t:1526418362608};\\\", \\\"{x:1342,y:673,t:1526418362625};\\\", \\\"{x:1342,y:672,t:1526418362641};\\\", \\\"{x:1342,y:670,t:1526418362658};\\\", \\\"{x:1342,y:669,t:1526418362674};\\\", \\\"{x:1342,y:667,t:1526418362690};\\\", \\\"{x:1342,y:666,t:1526418362708};\\\", \\\"{x:1342,y:665,t:1526418362724};\\\", \\\"{x:1342,y:663,t:1526418362740};\\\", \\\"{x:1342,y:660,t:1526418362758};\\\", \\\"{x:1342,y:657,t:1526418362774};\\\", \\\"{x:1342,y:654,t:1526418362791};\\\", \\\"{x:1342,y:653,t:1526418362807};\\\", \\\"{x:1342,y:650,t:1526418362824};\\\", \\\"{x:1342,y:647,t:1526418362840};\\\", \\\"{x:1342,y:646,t:1526418362857};\\\", \\\"{x:1342,y:644,t:1526418362874};\\\", \\\"{x:1342,y:643,t:1526418362891};\\\", \\\"{x:1342,y:642,t:1526418362910};\\\", \\\"{x:1342,y:641,t:1526418362924};\\\", \\\"{x:1342,y:640,t:1526418362941};\\\", \\\"{x:1342,y:638,t:1526418362957};\\\", \\\"{x:1342,y:637,t:1526418362982};\\\", \\\"{x:1342,y:636,t:1526418362991};\\\", \\\"{x:1342,y:635,t:1526418363007};\\\", \\\"{x:1343,y:634,t:1526418363024};\\\", \\\"{x:1344,y:634,t:1526418363997};\\\", \\\"{x:1344,y:635,t:1526418364012};\\\", \\\"{x:1343,y:636,t:1526418364024};\\\", \\\"{x:1341,y:641,t:1526418364041};\\\", \\\"{x:1340,y:643,t:1526418364058};\\\", \\\"{x:1339,y:645,t:1526418364074};\\\", \\\"{x:1339,y:646,t:1526418366301};\\\", \\\"{x:1341,y:646,t:1526418366317};\\\", \\\"{x:1341,y:645,t:1526418366341};\\\", \\\"{x:1341,y:643,t:1526418366365};\\\", \\\"{x:1344,y:641,t:1526418366375};\\\", \\\"{x:1345,y:637,t:1526418366392};\\\", \\\"{x:1345,y:634,t:1526418366408};\\\", \\\"{x:1346,y:631,t:1526418366425};\\\", \\\"{x:1346,y:629,t:1526418366442};\\\", \\\"{x:1347,y:626,t:1526418366458};\\\", \\\"{x:1347,y:624,t:1526418366475};\\\", \\\"{x:1347,y:621,t:1526418366492};\\\", \\\"{x:1348,y:618,t:1526418366508};\\\", \\\"{x:1348,y:615,t:1526418366525};\\\", \\\"{x:1348,y:614,t:1526418366548};\\\", \\\"{x:1348,y:612,t:1526418366558};\\\", \\\"{x:1348,y:610,t:1526418366575};\\\", \\\"{x:1348,y:605,t:1526418366592};\\\", \\\"{x:1348,y:603,t:1526418366609};\\\", \\\"{x:1347,y:597,t:1526418366625};\\\", \\\"{x:1347,y:592,t:1526418366642};\\\", \\\"{x:1347,y:591,t:1526418366659};\\\", \\\"{x:1347,y:587,t:1526418366674};\\\", \\\"{x:1347,y:585,t:1526418366691};\\\", \\\"{x:1346,y:576,t:1526418366708};\\\", \\\"{x:1346,y:572,t:1526418366724};\\\", \\\"{x:1344,y:568,t:1526418366741};\\\", \\\"{x:1344,y:566,t:1526418366772};\\\", \\\"{x:1344,y:565,t:1526418366781};\\\", \\\"{x:1344,y:563,t:1526418366792};\\\", \\\"{x:1344,y:547,t:1526418366809};\\\", \\\"{x:1343,y:526,t:1526418366825};\\\", \\\"{x:1342,y:514,t:1526418366842};\\\", \\\"{x:1342,y:501,t:1526418366859};\\\", \\\"{x:1342,y:494,t:1526418366875};\\\", \\\"{x:1342,y:490,t:1526418366892};\\\", \\\"{x:1340,y:476,t:1526418366908};\\\", \\\"{x:1340,y:461,t:1526418366925};\\\", \\\"{x:1339,y:450,t:1526418366941};\\\", \\\"{x:1338,y:439,t:1526418366959};\\\", \\\"{x:1338,y:430,t:1526418366975};\\\", \\\"{x:1338,y:425,t:1526418366992};\\\", \\\"{x:1338,y:418,t:1526418367008};\\\", \\\"{x:1338,y:409,t:1526418367025};\\\", \\\"{x:1338,y:404,t:1526418367042};\\\", \\\"{x:1338,y:398,t:1526418367059};\\\", \\\"{x:1338,y:393,t:1526418367075};\\\", \\\"{x:1338,y:391,t:1526418367092};\\\", \\\"{x:1338,y:390,t:1526418367109};\\\", \\\"{x:1337,y:389,t:1526418367165};\\\", \\\"{x:1335,y:389,t:1526418367181};\\\", \\\"{x:1332,y:389,t:1526418367192};\\\", \\\"{x:1314,y:398,t:1526418367209};\\\", \\\"{x:1263,y:419,t:1526418367225};\\\", \\\"{x:1186,y:449,t:1526418367242};\\\", \\\"{x:1113,y:476,t:1526418367259};\\\", \\\"{x:1051,y:497,t:1526418367275};\\\", \\\"{x:1009,y:516,t:1526418367292};\\\", \\\"{x:979,y:531,t:1526418367309};\\\", \\\"{x:966,y:540,t:1526418367326};\\\", \\\"{x:962,y:543,t:1526418367342};\\\", \\\"{x:959,y:547,t:1526418367359};\\\", \\\"{x:957,y:550,t:1526418367375};\\\", \\\"{x:955,y:551,t:1526418367392};\\\", \\\"{x:948,y:559,t:1526418367409};\\\", \\\"{x:932,y:572,t:1526418367426};\\\", \\\"{x:914,y:585,t:1526418367443};\\\", \\\"{x:880,y:604,t:1526418367466};\\\", \\\"{x:858,y:618,t:1526418367482};\\\", \\\"{x:834,y:633,t:1526418367499};\\\", \\\"{x:811,y:649,t:1526418367516};\\\", \\\"{x:780,y:662,t:1526418367532};\\\", \\\"{x:744,y:678,t:1526418367549};\\\", \\\"{x:726,y:689,t:1526418367566};\\\", \\\"{x:713,y:698,t:1526418367582};\\\", \\\"{x:702,y:701,t:1526418367599};\\\", \\\"{x:693,y:701,t:1526418367616};\\\", \\\"{x:678,y:701,t:1526418367631};\\\", \\\"{x:662,y:701,t:1526418367649};\\\", \\\"{x:651,y:702,t:1526418367666};\\\", \\\"{x:638,y:702,t:1526418367682};\\\", \\\"{x:627,y:702,t:1526418367699};\\\", \\\"{x:601,y:702,t:1526418367716};\\\", \\\"{x:553,y:702,t:1526418367732};\\\", \\\"{x:466,y:702,t:1526418367749};\\\", \\\"{x:430,y:702,t:1526418367766};\\\", \\\"{x:406,y:702,t:1526418367782};\\\", \\\"{x:395,y:700,t:1526418367798};\\\", \\\"{x:393,y:699,t:1526418367816};\\\", \\\"{x:391,y:697,t:1526418367901};\\\", \\\"{x:390,y:696,t:1526418367916};\\\", \\\"{x:377,y:690,t:1526418367932};\\\", \\\"{x:365,y:686,t:1526418367949};\\\", \\\"{x:344,y:680,t:1526418367966};\\\", \\\"{x:307,y:674,t:1526418367983};\\\", \\\"{x:260,y:668,t:1526418367999};\\\", \\\"{x:225,y:661,t:1526418368016};\\\", \\\"{x:212,y:657,t:1526418368033};\\\", \\\"{x:211,y:657,t:1526418368049};\\\", \\\"{x:210,y:656,t:1526418368092};\\\", \\\"{x:209,y:655,t:1526418368117};\\\", \\\"{x:208,y:654,t:1526418368148};\\\", \\\"{x:207,y:652,t:1526418368172};\\\", \\\"{x:206,y:651,t:1526418368183};\\\", \\\"{x:204,y:647,t:1526418368201};\\\", \\\"{x:203,y:644,t:1526418368216};\\\", \\\"{x:201,y:641,t:1526418368233};\\\", \\\"{x:200,y:638,t:1526418368248};\\\", \\\"{x:203,y:634,t:1526418368266};\\\", \\\"{x:230,y:620,t:1526418368282};\\\", \\\"{x:296,y:603,t:1526418368299};\\\", \\\"{x:386,y:587,t:1526418368316};\\\", \\\"{x:565,y:575,t:1526418368333};\\\", \\\"{x:706,y:575,t:1526418368350};\\\", \\\"{x:831,y:575,t:1526418368366};\\\", \\\"{x:917,y:575,t:1526418368383};\\\", \\\"{x:974,y:577,t:1526418368400};\\\", \\\"{x:1011,y:584,t:1526418368416};\\\", \\\"{x:1040,y:589,t:1526418368433};\\\", \\\"{x:1059,y:590,t:1526418368450};\\\", \\\"{x:1067,y:591,t:1526418368466};\\\", \\\"{x:1068,y:591,t:1526418368483};\\\", \\\"{x:1060,y:591,t:1526418368556};\\\", \\\"{x:1037,y:591,t:1526418368566};\\\", \\\"{x:954,y:591,t:1526418368583};\\\", \\\"{x:896,y:591,t:1526418368600};\\\", \\\"{x:862,y:591,t:1526418368617};\\\", \\\"{x:835,y:591,t:1526418368633};\\\", \\\"{x:818,y:588,t:1526418368650};\\\", \\\"{x:810,y:585,t:1526418368666};\\\", \\\"{x:808,y:584,t:1526418368683};\\\", \\\"{x:807,y:583,t:1526418368733};\\\", \\\"{x:804,y:581,t:1526418368751};\\\", \\\"{x:789,y:575,t:1526418368767};\\\", \\\"{x:764,y:569,t:1526418368784};\\\", \\\"{x:727,y:568,t:1526418368800};\\\", \\\"{x:696,y:568,t:1526418368817};\\\", \\\"{x:662,y:568,t:1526418368833};\\\", \\\"{x:628,y:568,t:1526418368851};\\\", \\\"{x:581,y:568,t:1526418368867};\\\", \\\"{x:500,y:568,t:1526418368883};\\\", \\\"{x:425,y:568,t:1526418368900};\\\", \\\"{x:394,y:568,t:1526418368917};\\\", \\\"{x:392,y:566,t:1526418368933};\\\", \\\"{x:390,y:566,t:1526418368988};\\\", \\\"{x:387,y:566,t:1526418369000};\\\", \\\"{x:371,y:566,t:1526418369017};\\\", \\\"{x:360,y:566,t:1526418369033};\\\", \\\"{x:349,y:566,t:1526418369050};\\\", \\\"{x:340,y:566,t:1526418369067};\\\", \\\"{x:336,y:565,t:1526418369084};\\\", \\\"{x:335,y:564,t:1526418369100};\\\", \\\"{x:332,y:562,t:1526418369124};\\\", \\\"{x:329,y:561,t:1526418369140};\\\", \\\"{x:327,y:559,t:1526418369149};\\\", \\\"{x:320,y:558,t:1526418369167};\\\", \\\"{x:312,y:554,t:1526418369184};\\\", \\\"{x:300,y:550,t:1526418369200};\\\", \\\"{x:282,y:543,t:1526418369217};\\\", \\\"{x:262,y:535,t:1526418369235};\\\", \\\"{x:238,y:524,t:1526418369250};\\\", \\\"{x:214,y:515,t:1526418369267};\\\", \\\"{x:202,y:510,t:1526418369284};\\\", \\\"{x:198,y:509,t:1526418369300};\\\", \\\"{x:197,y:509,t:1526418369356};\\\", \\\"{x:195,y:509,t:1526418369367};\\\", \\\"{x:194,y:509,t:1526418369388};\\\", \\\"{x:191,y:510,t:1526418369401};\\\", \\\"{x:188,y:514,t:1526418369417};\\\", \\\"{x:184,y:519,t:1526418369434};\\\", \\\"{x:182,y:530,t:1526418369451};\\\", \\\"{x:179,y:540,t:1526418369467};\\\", \\\"{x:179,y:545,t:1526418369485};\\\", \\\"{x:178,y:548,t:1526418369501};\\\", \\\"{x:178,y:550,t:1526418369517};\\\", \\\"{x:178,y:552,t:1526418369534};\\\", \\\"{x:179,y:555,t:1526418369551};\\\", \\\"{x:179,y:556,t:1526418369567};\\\", \\\"{x:179,y:557,t:1526418369584};\\\", \\\"{x:180,y:557,t:1526418369941};\\\", \\\"{x:182,y:557,t:1526418369951};\\\", \\\"{x:187,y:557,t:1526418369968};\\\", \\\"{x:203,y:557,t:1526418369984};\\\", \\\"{x:232,y:563,t:1526418370001};\\\", \\\"{x:282,y:579,t:1526418370018};\\\", \\\"{x:338,y:604,t:1526418370034};\\\", \\\"{x:387,y:623,t:1526418370051};\\\", \\\"{x:420,y:638,t:1526418370068};\\\", \\\"{x:448,y:649,t:1526418370084};\\\", \\\"{x:471,y:665,t:1526418370101};\\\", \\\"{x:476,y:669,t:1526418370118};\\\", \\\"{x:476,y:670,t:1526418370134};\\\", \\\"{x:476,y:671,t:1526418370151};\\\", \\\"{x:478,y:673,t:1526418370168};\\\", \\\"{x:481,y:678,t:1526418370184};\\\", \\\"{x:487,y:685,t:1526418370201};\\\", \\\"{x:491,y:692,t:1526418370218};\\\", \\\"{x:494,y:696,t:1526418370234};\\\", \\\"{x:494,y:697,t:1526418370251};\\\", \\\"{x:495,y:698,t:1526418370268};\\\", \\\"{x:496,y:698,t:1526418370285};\\\", \\\"{x:497,y:701,t:1526418370301};\\\", \\\"{x:498,y:703,t:1526418370318};\\\", \\\"{x:499,y:705,t:1526418370334};\\\", \\\"{x:499,y:707,t:1526418370421};\\\", \\\"{x:499,y:708,t:1526418370435};\\\", \\\"{x:499,y:710,t:1526418370451};\\\", \\\"{x:499,y:712,t:1526418370468};\\\", \\\"{x:499,y:714,t:1526418370485};\\\", \\\"{x:506,y:718,t:1526418374598};\\\", \\\"{x:524,y:726,t:1526418374605};\\\", \\\"{x:583,y:736,t:1526418374623};\\\", \\\"{x:682,y:755,t:1526418374638};\\\", \\\"{x:846,y:791,t:1526418374654};\\\", \\\"{x:1057,y:833,t:1526418374671};\\\", \\\"{x:1276,y:868,t:1526418374689};\\\", \\\"{x:1456,y:894,t:1526418374705};\\\", \\\"{x:1573,y:915,t:1526418374722};\\\", \\\"{x:1640,y:926,t:1526418374738};\\\", \\\"{x:1655,y:930,t:1526418374755};\\\", \\\"{x:1656,y:930,t:1526418374773};\\\", \\\"{x:1656,y:931,t:1526418374788};\\\", \\\"{x:1630,y:925,t:1526418374805};\\\", \\\"{x:1609,y:919,t:1526418374822};\\\", \\\"{x:1575,y:914,t:1526418374838};\\\", \\\"{x:1530,y:907,t:1526418374856};\\\", \\\"{x:1500,y:901,t:1526418374873};\\\", \\\"{x:1483,y:894,t:1526418374888};\\\", \\\"{x:1464,y:885,t:1526418374906};\\\", \\\"{x:1446,y:879,t:1526418374923};\\\", \\\"{x:1419,y:874,t:1526418374938};\\\", \\\"{x:1396,y:871,t:1526418374956};\\\", \\\"{x:1368,y:871,t:1526418374973};\\\", \\\"{x:1364,y:871,t:1526418374990};\\\", \\\"{x:1354,y:871,t:1526418375006};\\\", \\\"{x:1351,y:871,t:1526418375023};\\\", \\\"{x:1350,y:871,t:1526418375039};\\\", \\\"{x:1349,y:871,t:1526418375062};\\\", \\\"{x:1347,y:871,t:1526418375073};\\\", \\\"{x:1339,y:871,t:1526418375090};\\\", \\\"{x:1321,y:871,t:1526418375106};\\\", \\\"{x:1295,y:868,t:1526418375123};\\\", \\\"{x:1273,y:866,t:1526418375139};\\\", \\\"{x:1259,y:863,t:1526418375156};\\\", \\\"{x:1252,y:859,t:1526418375173};\\\", \\\"{x:1251,y:859,t:1526418375189};\\\", \\\"{x:1250,y:857,t:1526418375205};\\\", \\\"{x:1250,y:856,t:1526418375223};\\\", \\\"{x:1249,y:852,t:1526418375240};\\\", \\\"{x:1247,y:850,t:1526418375256};\\\", \\\"{x:1247,y:848,t:1526418375272};\\\", \\\"{x:1247,y:846,t:1526418375289};\\\", \\\"{x:1247,y:845,t:1526418375325};\\\", \\\"{x:1247,y:844,t:1526418375339};\\\", \\\"{x:1247,y:843,t:1526418375355};\\\", \\\"{x:1247,y:842,t:1526418375437};\\\", \\\"{x:1247,y:841,t:1526418375445};\\\", \\\"{x:1247,y:840,t:1526418375460};\\\", \\\"{x:1247,y:839,t:1526418375477};\\\", \\\"{x:1246,y:838,t:1526418375493};\\\", \\\"{x:1245,y:836,t:1526418375509};\\\", \\\"{x:1244,y:836,t:1526418375522};\\\", \\\"{x:1241,y:834,t:1526418375540};\\\", \\\"{x:1239,y:833,t:1526418375557};\\\", \\\"{x:1237,y:832,t:1526418375573};\\\", \\\"{x:1236,y:832,t:1526418375598};\\\", \\\"{x:1235,y:832,t:1526418375614};\\\", \\\"{x:1234,y:832,t:1526418375629};\\\", \\\"{x:1232,y:832,t:1526418375640};\\\", \\\"{x:1231,y:832,t:1526418375669};\\\", \\\"{x:1230,y:832,t:1526418375702};\\\", \\\"{x:1229,y:832,t:1526418375718};\\\", \\\"{x:1228,y:832,t:1526418375725};\\\", \\\"{x:1227,y:831,t:1526418375741};\\\", \\\"{x:1226,y:831,t:1526418375830};\\\", \\\"{x:1225,y:831,t:1526418375847};\\\", \\\"{x:1224,y:831,t:1526418375857};\\\", \\\"{x:1221,y:830,t:1526418375873};\\\", \\\"{x:1220,y:830,t:1526418375890};\\\", \\\"{x:1219,y:830,t:1526418375906};\\\", \\\"{x:1218,y:829,t:1526418375923};\\\", \\\"{x:1219,y:828,t:1526418376029};\\\", \\\"{x:1222,y:827,t:1526418376040};\\\", \\\"{x:1232,y:827,t:1526418376057};\\\", \\\"{x:1247,y:827,t:1526418376074};\\\", \\\"{x:1262,y:827,t:1526418376089};\\\", \\\"{x:1274,y:827,t:1526418376107};\\\", \\\"{x:1288,y:827,t:1526418376124};\\\", \\\"{x:1296,y:827,t:1526418376140};\\\", \\\"{x:1300,y:827,t:1526418376156};\\\", \\\"{x:1301,y:827,t:1526418376214};\\\", \\\"{x:1302,y:827,t:1526418376229};\\\", \\\"{x:1303,y:827,t:1526418376253};\\\", \\\"{x:1305,y:827,t:1526418376260};\\\", \\\"{x:1306,y:827,t:1526418376273};\\\", \\\"{x:1314,y:826,t:1526418376291};\\\", \\\"{x:1320,y:825,t:1526418376306};\\\", \\\"{x:1328,y:825,t:1526418376323};\\\", \\\"{x:1332,y:825,t:1526418376340};\\\", \\\"{x:1335,y:825,t:1526418376357};\\\", \\\"{x:1337,y:824,t:1526418376374};\\\", \\\"{x:1339,y:823,t:1526418376396};\\\", \\\"{x:1340,y:823,t:1526418376407};\\\", \\\"{x:1344,y:823,t:1526418376423};\\\", \\\"{x:1347,y:823,t:1526418376440};\\\", \\\"{x:1348,y:823,t:1526418376484};\\\", \\\"{x:1349,y:823,t:1526418376493};\\\", \\\"{x:1350,y:823,t:1526418376509};\\\", \\\"{x:1351,y:823,t:1526418376525};\\\", \\\"{x:1352,y:823,t:1526418376540};\\\", \\\"{x:1353,y:823,t:1526418376804};\\\", \\\"{x:1353,y:821,t:1526418376813};\\\", \\\"{x:1353,y:819,t:1526418376824};\\\", \\\"{x:1353,y:813,t:1526418376840};\\\", \\\"{x:1353,y:808,t:1526418376857};\\\", \\\"{x:1353,y:802,t:1526418376873};\\\", \\\"{x:1353,y:798,t:1526418376890};\\\", \\\"{x:1352,y:794,t:1526418376907};\\\", \\\"{x:1351,y:790,t:1526418376924};\\\", \\\"{x:1351,y:788,t:1526418376940};\\\", \\\"{x:1351,y:787,t:1526418376957};\\\", \\\"{x:1351,y:785,t:1526418376975};\\\", \\\"{x:1351,y:784,t:1526418376991};\\\", \\\"{x:1351,y:782,t:1526418377020};\\\", \\\"{x:1351,y:780,t:1526418377036};\\\", \\\"{x:1351,y:778,t:1526418377045};\\\", \\\"{x:1351,y:777,t:1526418377057};\\\", \\\"{x:1351,y:772,t:1526418377075};\\\", \\\"{x:1351,y:767,t:1526418377090};\\\", \\\"{x:1351,y:763,t:1526418377107};\\\", \\\"{x:1351,y:753,t:1526418377125};\\\", \\\"{x:1349,y:747,t:1526418377140};\\\", \\\"{x:1348,y:741,t:1526418377158};\\\", \\\"{x:1348,y:736,t:1526418377174};\\\", \\\"{x:1348,y:731,t:1526418377190};\\\", \\\"{x:1348,y:727,t:1526418377207};\\\", \\\"{x:1348,y:724,t:1526418377225};\\\", \\\"{x:1348,y:721,t:1526418377240};\\\", \\\"{x:1348,y:716,t:1526418377258};\\\", \\\"{x:1348,y:711,t:1526418377274};\\\", \\\"{x:1348,y:708,t:1526418377292};\\\", \\\"{x:1348,y:707,t:1526418377307};\\\", \\\"{x:1347,y:703,t:1526418377325};\\\", \\\"{x:1346,y:703,t:1526418377438};\\\", \\\"{x:1342,y:703,t:1526418377453};\\\", \\\"{x:1333,y:706,t:1526418377461};\\\", \\\"{x:1317,y:711,t:1526418377475};\\\", \\\"{x:1276,y:719,t:1526418377492};\\\", \\\"{x:1218,y:727,t:1526418377507};\\\", \\\"{x:1134,y:735,t:1526418377524};\\\", \\\"{x:1080,y:737,t:1526418377541};\\\", \\\"{x:1002,y:739,t:1526418377558};\\\", \\\"{x:907,y:739,t:1526418377574};\\\", \\\"{x:805,y:739,t:1526418377592};\\\", \\\"{x:704,y:743,t:1526418377608};\\\", \\\"{x:626,y:744,t:1526418377625};\\\", \\\"{x:564,y:746,t:1526418377641};\\\", \\\"{x:528,y:746,t:1526418377658};\\\", \\\"{x:509,y:746,t:1526418377674};\\\", \\\"{x:499,y:746,t:1526418377691};\\\", \\\"{x:497,y:747,t:1526418377708};\\\", \\\"{x:496,y:748,t:1526418377749};\\\", \\\"{x:495,y:749,t:1526418377758};\\\", \\\"{x:494,y:749,t:1526418377774};\\\", \\\"{x:491,y:752,t:1526418377791};\\\", \\\"{x:485,y:756,t:1526418377808};\\\", \\\"{x:481,y:760,t:1526418377825};\\\", \\\"{x:478,y:761,t:1526418377841};\\\", \\\"{x:465,y:765,t:1526418377858};\\\", \\\"{x:451,y:768,t:1526418377874};\\\", \\\"{x:438,y:771,t:1526418377891};\\\", \\\"{x:431,y:781,t:1526418377908};\\\", \\\"{x:431,y:786,t:1526418377924};\\\", \\\"{x:431,y:787,t:1526418377941};\\\", \\\"{x:435,y:787,t:1526418377958};\\\", \\\"{x:443,y:781,t:1526418377974};\\\", \\\"{x:449,y:774,t:1526418377991};\\\", \\\"{x:461,y:762,t:1526418378008};\\\", \\\"{x:479,y:750,t:1526418378025};\\\", \\\"{x:495,y:735,t:1526418378042};\\\", \\\"{x:507,y:720,t:1526418378058};\\\", \\\"{x:514,y:713,t:1526418378074};\\\", \\\"{x:515,y:710,t:1526418378091};\\\", \\\"{x:515,y:709,t:1526418378107};\\\", \\\"{x:516,y:708,t:1526418378125};\\\", \\\"{x:517,y:708,t:1526418378717};\\\", \\\"{x:519,y:708,t:1526418378724};\\\" ] }, { \\\"rt\\\": 53117, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 328666, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04:30-U -H -F -U -K -D -F -Z -Z -Z -A -2\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:708,t:1526418379733};\\\", \\\"{x:528,y:708,t:1526418380692};\\\", \\\"{x:541,y:711,t:1526418380710};\\\", \\\"{x:572,y:717,t:1526418380726};\\\", \\\"{x:638,y:726,t:1526418380743};\\\", \\\"{x:713,y:737,t:1526418380760};\\\", \\\"{x:808,y:748,t:1526418380776};\\\", \\\"{x:932,y:763,t:1526418380794};\\\", \\\"{x:1081,y:785,t:1526418380811};\\\", \\\"{x:1230,y:800,t:1526418380827};\\\", \\\"{x:1361,y:804,t:1526418380844};\\\", \\\"{x:1545,y:826,t:1526418380861};\\\", \\\"{x:1638,y:836,t:1526418380876};\\\", \\\"{x:1651,y:844,t:1526418380893};\\\", \\\"{x:1653,y:846,t:1526418380911};\\\", \\\"{x:1653,y:847,t:1526418382637};\\\", \\\"{x:1653,y:849,t:1526418382646};\\\", \\\"{x:1653,y:850,t:1526418382662};\\\", \\\"{x:1653,y:852,t:1526418382679};\\\", \\\"{x:1653,y:855,t:1526418382695};\\\", \\\"{x:1653,y:858,t:1526418382711};\\\", \\\"{x:1652,y:862,t:1526418382729};\\\", \\\"{x:1645,y:869,t:1526418382746};\\\", \\\"{x:1637,y:877,t:1526418382762};\\\", \\\"{x:1630,y:883,t:1526418382779};\\\", \\\"{x:1625,y:890,t:1526418382795};\\\", \\\"{x:1620,y:901,t:1526418382812};\\\", \\\"{x:1615,y:920,t:1526418382828};\\\", \\\"{x:1614,y:930,t:1526418382846};\\\", \\\"{x:1614,y:936,t:1526418382861};\\\", \\\"{x:1614,y:941,t:1526418382878};\\\", \\\"{x:1616,y:948,t:1526418382896};\\\", \\\"{x:1624,y:960,t:1526418382911};\\\", \\\"{x:1639,y:971,t:1526418382929};\\\", \\\"{x:1652,y:977,t:1526418382946};\\\", \\\"{x:1656,y:977,t:1526418382961};\\\", \\\"{x:1658,y:977,t:1526418382978};\\\", \\\"{x:1659,y:977,t:1526418382996};\\\", \\\"{x:1658,y:977,t:1526418383085};\\\", \\\"{x:1657,y:977,t:1526418383096};\\\", \\\"{x:1656,y:977,t:1526418383113};\\\", \\\"{x:1652,y:975,t:1526418383128};\\\", \\\"{x:1649,y:974,t:1526418383145};\\\", \\\"{x:1643,y:972,t:1526418383163};\\\", \\\"{x:1637,y:970,t:1526418383178};\\\", \\\"{x:1630,y:967,t:1526418383195};\\\", \\\"{x:1624,y:966,t:1526418383213};\\\", \\\"{x:1621,y:963,t:1526418383228};\\\", \\\"{x:1612,y:963,t:1526418383246};\\\", \\\"{x:1602,y:962,t:1526418383262};\\\", \\\"{x:1594,y:962,t:1526418383278};\\\", \\\"{x:1592,y:962,t:1526418383296};\\\", \\\"{x:1591,y:962,t:1526418383312};\\\", \\\"{x:1592,y:962,t:1526418383469};\\\", \\\"{x:1595,y:962,t:1526418383479};\\\", \\\"{x:1604,y:962,t:1526418383495};\\\", \\\"{x:1611,y:962,t:1526418383513};\\\", \\\"{x:1612,y:960,t:1526418383530};\\\", \\\"{x:1614,y:960,t:1526418383700};\\\", \\\"{x:1615,y:960,t:1526418383837};\\\", \\\"{x:1615,y:959,t:1526418383885};\\\", \\\"{x:1617,y:959,t:1526418385254};\\\", \\\"{x:1616,y:959,t:1526418386270};\\\", \\\"{x:1615,y:959,t:1526418386558};\\\", \\\"{x:1614,y:959,t:1526418386565};\\\", \\\"{x:1609,y:957,t:1526418386582};\\\", \\\"{x:1597,y:949,t:1526418386600};\\\", \\\"{x:1579,y:937,t:1526418386616};\\\", \\\"{x:1556,y:920,t:1526418386632};\\\", \\\"{x:1539,y:909,t:1526418386649};\\\", \\\"{x:1529,y:902,t:1526418386665};\\\", \\\"{x:1524,y:895,t:1526418386682};\\\", \\\"{x:1516,y:881,t:1526418386699};\\\", \\\"{x:1510,y:873,t:1526418386717};\\\", \\\"{x:1503,y:863,t:1526418386732};\\\", \\\"{x:1497,y:858,t:1526418386749};\\\", \\\"{x:1496,y:856,t:1526418386766};\\\", \\\"{x:1493,y:853,t:1526418386782};\\\", \\\"{x:1493,y:852,t:1526418386799};\\\", \\\"{x:1493,y:851,t:1526418386845};\\\", \\\"{x:1491,y:850,t:1526418386854};\\\", \\\"{x:1491,y:849,t:1526418386866};\\\", \\\"{x:1490,y:848,t:1526418386885};\\\", \\\"{x:1489,y:847,t:1526418386926};\\\", \\\"{x:1488,y:847,t:1526418386933};\\\", \\\"{x:1487,y:845,t:1526418386949};\\\", \\\"{x:1485,y:841,t:1526418386966};\\\", \\\"{x:1482,y:838,t:1526418386983};\\\", \\\"{x:1480,y:836,t:1526418386999};\\\", \\\"{x:1480,y:834,t:1526418387019};\\\", \\\"{x:1479,y:834,t:1526418387076};\\\", \\\"{x:1479,y:833,t:1526418387092};\\\", \\\"{x:1478,y:832,t:1526418387108};\\\", \\\"{x:1481,y:832,t:1526418387925};\\\", \\\"{x:1483,y:832,t:1526418387932};\\\", \\\"{x:1487,y:832,t:1526418387951};\\\", \\\"{x:1488,y:832,t:1526418387967};\\\", \\\"{x:1490,y:832,t:1526418387983};\\\", \\\"{x:1494,y:832,t:1526418388000};\\\", \\\"{x:1496,y:832,t:1526418388016};\\\", \\\"{x:1497,y:832,t:1526418388032};\\\", \\\"{x:1500,y:832,t:1526418388049};\\\", \\\"{x:1503,y:832,t:1526418388067};\\\", \\\"{x:1507,y:832,t:1526418388083};\\\", \\\"{x:1510,y:832,t:1526418388100};\\\", \\\"{x:1517,y:832,t:1526418388117};\\\", \\\"{x:1521,y:832,t:1526418388133};\\\", \\\"{x:1529,y:832,t:1526418388150};\\\", \\\"{x:1541,y:832,t:1526418388167};\\\", \\\"{x:1556,y:832,t:1526418388183};\\\", \\\"{x:1571,y:832,t:1526418388200};\\\", \\\"{x:1582,y:832,t:1526418388216};\\\", \\\"{x:1584,y:832,t:1526418388233};\\\", \\\"{x:1585,y:832,t:1526418388252};\\\", \\\"{x:1586,y:832,t:1526418388333};\\\", \\\"{x:1587,y:832,t:1526418388413};\\\", \\\"{x:1589,y:832,t:1526418388421};\\\", \\\"{x:1590,y:832,t:1526418388434};\\\", \\\"{x:1592,y:832,t:1526418388451};\\\", \\\"{x:1595,y:831,t:1526418388467};\\\", \\\"{x:1596,y:831,t:1526418388484};\\\", \\\"{x:1597,y:831,t:1526418388517};\\\", \\\"{x:1598,y:831,t:1526418388534};\\\", \\\"{x:1599,y:831,t:1526418388550};\\\", \\\"{x:1600,y:831,t:1526418388567};\\\", \\\"{x:1601,y:831,t:1526418388612};\\\", \\\"{x:1602,y:831,t:1526418388685};\\\", \\\"{x:1603,y:831,t:1526418388700};\\\", \\\"{x:1604,y:831,t:1526418388725};\\\", \\\"{x:1605,y:831,t:1526418388756};\\\", \\\"{x:1606,y:831,t:1526418388767};\\\", \\\"{x:1608,y:831,t:1526418388784};\\\", \\\"{x:1609,y:831,t:1526418388805};\\\", \\\"{x:1611,y:831,t:1526418388820};\\\", \\\"{x:1612,y:831,t:1526418388885};\\\", \\\"{x:1614,y:831,t:1526418388908};\\\", \\\"{x:1611,y:831,t:1526418391372};\\\", \\\"{x:1602,y:831,t:1526418391386};\\\", \\\"{x:1584,y:829,t:1526418391403};\\\", \\\"{x:1556,y:828,t:1526418391419};\\\", \\\"{x:1520,y:821,t:1526418391436};\\\", \\\"{x:1439,y:807,t:1526418391452};\\\", \\\"{x:1377,y:797,t:1526418391469};\\\", \\\"{x:1292,y:789,t:1526418391486};\\\", \\\"{x:1182,y:779,t:1526418391503};\\\", \\\"{x:1047,y:767,t:1526418391519};\\\", \\\"{x:927,y:744,t:1526418391536};\\\", \\\"{x:789,y:723,t:1526418391553};\\\", \\\"{x:659,y:706,t:1526418391569};\\\", \\\"{x:564,y:690,t:1526418391586};\\\", \\\"{x:452,y:684,t:1526418391603};\\\", \\\"{x:369,y:673,t:1526418391619};\\\", \\\"{x:337,y:668,t:1526418391636};\\\", \\\"{x:331,y:665,t:1526418391653};\\\", \\\"{x:331,y:664,t:1526418391748};\\\", \\\"{x:330,y:664,t:1526418391756};\\\", \\\"{x:330,y:663,t:1526418391769};\\\", \\\"{x:330,y:661,t:1526418391789};\\\", \\\"{x:332,y:657,t:1526418391804};\\\", \\\"{x:332,y:656,t:1526418391820};\\\", \\\"{x:338,y:649,t:1526418391836};\\\", \\\"{x:350,y:641,t:1526418391852};\\\", \\\"{x:370,y:637,t:1526418391869};\\\", \\\"{x:414,y:626,t:1526418391886};\\\", \\\"{x:475,y:617,t:1526418391902};\\\", \\\"{x:550,y:610,t:1526418391920};\\\", \\\"{x:596,y:607,t:1526418391936};\\\", \\\"{x:626,y:607,t:1526418391952};\\\", \\\"{x:644,y:607,t:1526418391969};\\\", \\\"{x:650,y:607,t:1526418391986};\\\", \\\"{x:650,y:606,t:1526418392141};\\\", \\\"{x:650,y:605,t:1526418392165};\\\", \\\"{x:649,y:605,t:1526418392188};\\\", \\\"{x:649,y:604,t:1526418392204};\\\", \\\"{x:647,y:604,t:1526418392228};\\\", \\\"{x:646,y:604,t:1526418392236};\\\", \\\"{x:643,y:603,t:1526418392253};\\\", \\\"{x:638,y:603,t:1526418392270};\\\", \\\"{x:635,y:602,t:1526418392286};\\\", \\\"{x:631,y:601,t:1526418392303};\\\", \\\"{x:628,y:601,t:1526418392320};\\\", \\\"{x:625,y:600,t:1526418392336};\\\", \\\"{x:623,y:599,t:1526418392353};\\\", \\\"{x:622,y:599,t:1526418392370};\\\", \\\"{x:621,y:599,t:1526418392813};\\\", \\\"{x:622,y:599,t:1526418392860};\\\", \\\"{x:627,y:599,t:1526418392870};\\\", \\\"{x:640,y:599,t:1526418392887};\\\", \\\"{x:657,y:599,t:1526418392904};\\\", \\\"{x:691,y:605,t:1526418392920};\\\", \\\"{x:746,y:610,t:1526418392938};\\\", \\\"{x:831,y:629,t:1526418392954};\\\", \\\"{x:944,y:655,t:1526418392970};\\\", \\\"{x:1054,y:670,t:1526418392987};\\\", \\\"{x:1171,y:688,t:1526418393004};\\\", \\\"{x:1261,y:703,t:1526418393020};\\\", \\\"{x:1356,y:723,t:1526418393038};\\\", \\\"{x:1397,y:732,t:1526418393054};\\\", \\\"{x:1418,y:739,t:1526418393070};\\\", \\\"{x:1432,y:741,t:1526418393087};\\\", \\\"{x:1439,y:743,t:1526418393104};\\\", \\\"{x:1441,y:745,t:1526418393120};\\\", \\\"{x:1442,y:745,t:1526418393137};\\\", \\\"{x:1443,y:747,t:1526418393154};\\\", \\\"{x:1445,y:749,t:1526418393171};\\\", \\\"{x:1448,y:751,t:1526418393187};\\\", \\\"{x:1454,y:759,t:1526418393204};\\\", \\\"{x:1472,y:773,t:1526418393220};\\\", \\\"{x:1482,y:782,t:1526418393237};\\\", \\\"{x:1487,y:788,t:1526418393254};\\\", \\\"{x:1487,y:790,t:1526418393271};\\\", \\\"{x:1488,y:791,t:1526418393287};\\\", \\\"{x:1488,y:794,t:1526418393304};\\\", \\\"{x:1488,y:795,t:1526418393321};\\\", \\\"{x:1488,y:796,t:1526418393337};\\\", \\\"{x:1487,y:796,t:1526418393354};\\\", \\\"{x:1486,y:796,t:1526418393372};\\\", \\\"{x:1484,y:797,t:1526418393387};\\\", \\\"{x:1481,y:798,t:1526418393404};\\\", \\\"{x:1478,y:800,t:1526418393421};\\\", \\\"{x:1473,y:801,t:1526418393437};\\\", \\\"{x:1470,y:803,t:1526418393454};\\\", \\\"{x:1470,y:808,t:1526418393471};\\\", \\\"{x:1470,y:815,t:1526418393488};\\\", \\\"{x:1470,y:822,t:1526418393504};\\\", \\\"{x:1470,y:824,t:1526418393521};\\\", \\\"{x:1471,y:824,t:1526418393540};\\\", \\\"{x:1473,y:825,t:1526418393805};\\\", \\\"{x:1474,y:826,t:1526418393878};\\\", \\\"{x:1474,y:825,t:1526418394765};\\\", \\\"{x:1474,y:823,t:1526418394774};\\\", \\\"{x:1474,y:822,t:1526418394789};\\\", \\\"{x:1472,y:814,t:1526418394806};\\\", \\\"{x:1469,y:808,t:1526418394823};\\\", \\\"{x:1467,y:802,t:1526418394839};\\\", \\\"{x:1465,y:798,t:1526418394856};\\\", \\\"{x:1464,y:791,t:1526418394873};\\\", \\\"{x:1461,y:786,t:1526418394888};\\\", \\\"{x:1455,y:774,t:1526418394906};\\\", \\\"{x:1449,y:763,t:1526418394923};\\\", \\\"{x:1446,y:756,t:1526418394939};\\\", \\\"{x:1444,y:750,t:1526418394955};\\\", \\\"{x:1442,y:743,t:1526418394973};\\\", \\\"{x:1441,y:738,t:1526418394989};\\\", \\\"{x:1439,y:730,t:1526418395006};\\\", \\\"{x:1436,y:721,t:1526418395023};\\\", \\\"{x:1432,y:708,t:1526418395040};\\\", \\\"{x:1429,y:698,t:1526418395055};\\\", \\\"{x:1427,y:690,t:1526418395073};\\\", \\\"{x:1426,y:683,t:1526418395090};\\\", \\\"{x:1424,y:677,t:1526418395106};\\\", \\\"{x:1422,y:668,t:1526418395123};\\\", \\\"{x:1420,y:659,t:1526418395140};\\\", \\\"{x:1419,y:654,t:1526418395156};\\\", \\\"{x:1419,y:651,t:1526418395173};\\\", \\\"{x:1419,y:649,t:1526418395189};\\\", \\\"{x:1419,y:648,t:1526418395206};\\\", \\\"{x:1418,y:646,t:1526418395223};\\\", \\\"{x:1417,y:642,t:1526418395240};\\\", \\\"{x:1416,y:639,t:1526418395256};\\\", \\\"{x:1416,y:636,t:1526418395273};\\\", \\\"{x:1416,y:631,t:1526418395290};\\\", \\\"{x:1415,y:623,t:1526418395305};\\\", \\\"{x:1413,y:620,t:1526418395322};\\\", \\\"{x:1413,y:617,t:1526418395340};\\\", \\\"{x:1413,y:616,t:1526418395356};\\\", \\\"{x:1413,y:613,t:1526418395372};\\\", \\\"{x:1413,y:610,t:1526418395389};\\\", \\\"{x:1412,y:608,t:1526418395406};\\\", \\\"{x:1412,y:606,t:1526418395423};\\\", \\\"{x:1411,y:605,t:1526418395440};\\\", \\\"{x:1411,y:601,t:1526418395456};\\\", \\\"{x:1411,y:597,t:1526418395473};\\\", \\\"{x:1411,y:593,t:1526418395490};\\\", \\\"{x:1411,y:587,t:1526418395507};\\\", \\\"{x:1411,y:581,t:1526418395523};\\\", \\\"{x:1411,y:578,t:1526418395540};\\\", \\\"{x:1411,y:571,t:1526418395557};\\\", \\\"{x:1411,y:567,t:1526418395573};\\\", \\\"{x:1412,y:563,t:1526418395589};\\\", \\\"{x:1412,y:562,t:1526418395797};\\\", \\\"{x:1411,y:562,t:1526418397421};\\\", \\\"{x:1409,y:564,t:1526418397428};\\\", \\\"{x:1408,y:564,t:1526418397440};\\\", \\\"{x:1405,y:566,t:1526418397457};\\\", \\\"{x:1402,y:568,t:1526418397475};\\\", \\\"{x:1398,y:571,t:1526418397490};\\\", \\\"{x:1393,y:576,t:1526418397508};\\\", \\\"{x:1376,y:589,t:1526418397524};\\\", \\\"{x:1361,y:600,t:1526418397540};\\\", \\\"{x:1343,y:608,t:1526418397557};\\\", \\\"{x:1335,y:613,t:1526418397574};\\\", \\\"{x:1331,y:616,t:1526418397590};\\\", \\\"{x:1330,y:617,t:1526418397607};\\\", \\\"{x:1328,y:622,t:1526418397624};\\\", \\\"{x:1325,y:626,t:1526418397641};\\\", \\\"{x:1322,y:632,t:1526418397657};\\\", \\\"{x:1320,y:636,t:1526418397674};\\\", \\\"{x:1318,y:638,t:1526418397691};\\\", \\\"{x:1318,y:642,t:1526418399125};\\\", \\\"{x:1320,y:650,t:1526418399132};\\\", \\\"{x:1326,y:658,t:1526418399142};\\\", \\\"{x:1336,y:676,t:1526418399159};\\\", \\\"{x:1346,y:693,t:1526418399175};\\\", \\\"{x:1352,y:712,t:1526418399192};\\\", \\\"{x:1360,y:734,t:1526418399209};\\\", \\\"{x:1369,y:754,t:1526418399225};\\\", \\\"{x:1376,y:768,t:1526418399242};\\\", \\\"{x:1381,y:777,t:1526418399258};\\\", \\\"{x:1382,y:781,t:1526418399275};\\\", \\\"{x:1383,y:784,t:1526418399292};\\\", \\\"{x:1384,y:785,t:1526418399308};\\\", \\\"{x:1384,y:783,t:1526418399437};\\\", \\\"{x:1384,y:779,t:1526418399444};\\\", \\\"{x:1383,y:773,t:1526418399459};\\\", \\\"{x:1382,y:771,t:1526418399475};\\\", \\\"{x:1381,y:769,t:1526418399492};\\\", \\\"{x:1381,y:768,t:1526418399580};\\\", \\\"{x:1381,y:767,t:1526418404002};\\\", \\\"{x:1382,y:767,t:1526418405042};\\\", \\\"{x:1386,y:767,t:1526418407956};\\\", \\\"{x:1389,y:767,t:1526418407963};\\\", \\\"{x:1399,y:769,t:1526418407980};\\\", \\\"{x:1408,y:774,t:1526418407996};\\\", \\\"{x:1418,y:780,t:1526418408014};\\\", \\\"{x:1434,y:790,t:1526418408030};\\\", \\\"{x:1455,y:801,t:1526418408047};\\\", \\\"{x:1476,y:807,t:1526418408064};\\\", \\\"{x:1492,y:812,t:1526418408080};\\\", \\\"{x:1501,y:815,t:1526418408097};\\\", \\\"{x:1502,y:815,t:1526418408114};\\\", \\\"{x:1503,y:816,t:1526418408131};\\\", \\\"{x:1502,y:818,t:1526418408195};\\\", \\\"{x:1500,y:819,t:1526418408202};\\\", \\\"{x:1499,y:820,t:1526418408212};\\\", \\\"{x:1497,y:822,t:1526418408229};\\\", \\\"{x:1494,y:823,t:1526418408247};\\\", \\\"{x:1494,y:824,t:1526418408262};\\\", \\\"{x:1492,y:824,t:1526418408280};\\\", \\\"{x:1491,y:825,t:1526418408297};\\\", \\\"{x:1490,y:826,t:1526418408458};\\\", \\\"{x:1489,y:828,t:1526418408490};\\\", \\\"{x:1488,y:831,t:1526418408505};\\\", \\\"{x:1488,y:832,t:1526418408514};\\\", \\\"{x:1486,y:834,t:1526418408530};\\\", \\\"{x:1484,y:835,t:1526418408547};\\\", \\\"{x:1484,y:836,t:1526418408577};\\\", \\\"{x:1483,y:836,t:1526418409041};\\\", \\\"{x:1483,y:835,t:1526418409065};\\\", \\\"{x:1483,y:833,t:1526418409096};\\\", \\\"{x:1483,y:832,t:1526418410329};\\\", \\\"{x:1483,y:831,t:1526418410337};\\\", \\\"{x:1485,y:831,t:1526418410348};\\\", \\\"{x:1490,y:831,t:1526418410365};\\\", \\\"{x:1494,y:831,t:1526418410382};\\\", \\\"{x:1500,y:831,t:1526418410398};\\\", \\\"{x:1506,y:831,t:1526418410416};\\\", \\\"{x:1513,y:831,t:1526418410432};\\\", \\\"{x:1526,y:831,t:1526418410449};\\\", \\\"{x:1541,y:831,t:1526418410465};\\\", \\\"{x:1554,y:831,t:1526418410481};\\\", \\\"{x:1556,y:831,t:1526418410498};\\\", \\\"{x:1555,y:831,t:1526418410963};\\\", \\\"{x:1553,y:831,t:1526418410978};\\\", \\\"{x:1552,y:831,t:1526418410994};\\\", \\\"{x:1556,y:830,t:1526418411523};\\\", \\\"{x:1560,y:830,t:1526418411532};\\\", \\\"{x:1568,y:830,t:1526418411549};\\\", \\\"{x:1579,y:830,t:1526418411567};\\\", \\\"{x:1589,y:830,t:1526418411582};\\\", \\\"{x:1591,y:830,t:1526418411600};\\\", \\\"{x:1592,y:830,t:1526418411616};\\\", \\\"{x:1593,y:830,t:1526418411650};\\\", \\\"{x:1594,y:830,t:1526418411667};\\\", \\\"{x:1595,y:830,t:1526418411684};\\\", \\\"{x:1596,y:830,t:1526418411706};\\\", \\\"{x:1597,y:830,t:1526418411970};\\\", \\\"{x:1598,y:830,t:1526418411986};\\\", \\\"{x:1599,y:830,t:1526418412002};\\\", \\\"{x:1600,y:830,t:1526418412026};\\\", \\\"{x:1601,y:830,t:1526418412050};\\\", \\\"{x:1603,y:830,t:1526418412066};\\\", \\\"{x:1608,y:833,t:1526418412084};\\\", \\\"{x:1609,y:833,t:1526418412099};\\\", \\\"{x:1611,y:833,t:1526418412117};\\\", \\\"{x:1612,y:833,t:1526418414850};\\\", \\\"{x:1613,y:833,t:1526418414858};\\\", \\\"{x:1613,y:830,t:1526418415227};\\\", \\\"{x:1612,y:825,t:1526418415236};\\\", \\\"{x:1601,y:804,t:1526418415253};\\\", \\\"{x:1588,y:777,t:1526418415268};\\\", \\\"{x:1568,y:740,t:1526418415286};\\\", \\\"{x:1546,y:688,t:1526418415303};\\\", \\\"{x:1533,y:652,t:1526418415320};\\\", \\\"{x:1526,y:633,t:1526418415336};\\\", \\\"{x:1523,y:620,t:1526418415353};\\\", \\\"{x:1521,y:612,t:1526418415370};\\\", \\\"{x:1521,y:609,t:1526418415387};\\\", \\\"{x:1521,y:607,t:1526418415403};\\\", \\\"{x:1518,y:603,t:1526418415420};\\\", \\\"{x:1515,y:599,t:1526418415436};\\\", \\\"{x:1514,y:597,t:1526418415452};\\\", \\\"{x:1511,y:592,t:1526418415469};\\\", \\\"{x:1504,y:585,t:1526418415485};\\\", \\\"{x:1497,y:576,t:1526418415503};\\\", \\\"{x:1494,y:573,t:1526418415519};\\\", \\\"{x:1493,y:573,t:1526418415536};\\\", \\\"{x:1492,y:573,t:1526418415561};\\\", \\\"{x:1490,y:573,t:1526418415569};\\\", \\\"{x:1481,y:584,t:1526418415585};\\\", \\\"{x:1481,y:613,t:1526418415602};\\\", \\\"{x:1492,y:654,t:1526418415619};\\\", \\\"{x:1500,y:680,t:1526418415636};\\\", \\\"{x:1506,y:691,t:1526418415652};\\\", \\\"{x:1509,y:695,t:1526418415669};\\\", \\\"{x:1510,y:689,t:1526418415713};\\\", \\\"{x:1511,y:678,t:1526418415721};\\\", \\\"{x:1511,y:668,t:1526418415736};\\\", \\\"{x:1511,y:639,t:1526418415752};\\\", \\\"{x:1511,y:601,t:1526418415769};\\\", \\\"{x:1511,y:585,t:1526418415786};\\\", \\\"{x:1511,y:575,t:1526418415802};\\\", \\\"{x:1509,y:567,t:1526418415819};\\\", \\\"{x:1508,y:565,t:1526418415836};\\\", \\\"{x:1507,y:564,t:1526418415852};\\\", \\\"{x:1505,y:564,t:1526418415869};\\\", \\\"{x:1496,y:564,t:1526418415886};\\\", \\\"{x:1481,y:564,t:1526418415903};\\\", \\\"{x:1459,y:570,t:1526418415919};\\\", \\\"{x:1438,y:583,t:1526418415936};\\\", \\\"{x:1402,y:604,t:1526418415953};\\\", \\\"{x:1367,y:615,t:1526418415969};\\\", \\\"{x:1361,y:616,t:1526418415986};\\\", \\\"{x:1359,y:615,t:1526418416002};\\\", \\\"{x:1359,y:600,t:1526418416019};\\\", \\\"{x:1363,y:581,t:1526418416036};\\\", \\\"{x:1378,y:550,t:1526418416052};\\\", \\\"{x:1396,y:525,t:1526418416069};\\\", \\\"{x:1410,y:504,t:1526418416086};\\\", \\\"{x:1418,y:491,t:1526418416103};\\\", \\\"{x:1419,y:487,t:1526418416120};\\\", \\\"{x:1419,y:486,t:1526418416162};\\\", \\\"{x:1415,y:487,t:1526418416170};\\\", \\\"{x:1406,y:506,t:1526418416186};\\\", \\\"{x:1396,y:533,t:1526418416204};\\\", \\\"{x:1385,y:555,t:1526418416220};\\\", \\\"{x:1380,y:565,t:1526418416236};\\\", \\\"{x:1380,y:568,t:1526418416254};\\\", \\\"{x:1381,y:564,t:1526418416298};\\\", \\\"{x:1383,y:552,t:1526418416306};\\\", \\\"{x:1388,y:542,t:1526418416320};\\\", \\\"{x:1392,y:524,t:1526418416336};\\\", \\\"{x:1399,y:499,t:1526418416354};\\\", \\\"{x:1403,y:490,t:1526418416370};\\\", \\\"{x:1408,y:479,t:1526418416387};\\\", \\\"{x:1412,y:470,t:1526418416404};\\\", \\\"{x:1415,y:465,t:1526418416420};\\\", \\\"{x:1416,y:462,t:1526418416437};\\\", \\\"{x:1417,y:460,t:1526418416454};\\\", \\\"{x:1412,y:460,t:1526418416514};\\\", \\\"{x:1405,y:464,t:1526418416522};\\\", \\\"{x:1402,y:466,t:1526418416537};\\\", \\\"{x:1400,y:466,t:1526418416554};\\\", \\\"{x:1402,y:466,t:1526418416761};\\\", \\\"{x:1403,y:464,t:1526418416770};\\\", \\\"{x:1406,y:457,t:1526418416786};\\\", \\\"{x:1405,y:451,t:1526418416803};\\\", \\\"{x:1402,y:445,t:1526418416820};\\\", \\\"{x:1399,y:436,t:1526418416836};\\\", \\\"{x:1395,y:431,t:1526418416853};\\\", \\\"{x:1392,y:428,t:1526418416870};\\\", \\\"{x:1391,y:428,t:1526418416887};\\\", \\\"{x:1390,y:428,t:1526418417041};\\\", \\\"{x:1391,y:428,t:1526418417202};\\\", \\\"{x:1392,y:428,t:1526418417209};\\\", \\\"{x:1393,y:428,t:1526418417226};\\\", \\\"{x:1394,y:428,t:1526418417237};\\\", \\\"{x:1397,y:432,t:1526418417253};\\\", \\\"{x:1414,y:454,t:1526418417270};\\\", \\\"{x:1456,y:511,t:1526418417287};\\\", \\\"{x:1519,y:585,t:1526418417304};\\\", \\\"{x:1552,y:645,t:1526418417320};\\\", \\\"{x:1569,y:670,t:1526418417338};\\\", \\\"{x:1571,y:672,t:1526418417354};\\\", \\\"{x:1571,y:673,t:1526418417393};\\\", \\\"{x:1571,y:674,t:1526418417475};\\\", \\\"{x:1570,y:674,t:1526418417488};\\\", \\\"{x:1562,y:669,t:1526418417505};\\\", \\\"{x:1545,y:653,t:1526418417521};\\\", \\\"{x:1509,y:618,t:1526418417538};\\\", \\\"{x:1495,y:599,t:1526418417554};\\\", \\\"{x:1491,y:586,t:1526418417571};\\\", \\\"{x:1490,y:584,t:1526418417588};\\\", \\\"{x:1491,y:591,t:1526418417626};\\\", \\\"{x:1497,y:605,t:1526418417638};\\\", \\\"{x:1511,y:633,t:1526418417655};\\\", \\\"{x:1519,y:648,t:1526418417672};\\\", \\\"{x:1523,y:655,t:1526418417688};\\\", \\\"{x:1524,y:656,t:1526418417704};\\\", \\\"{x:1525,y:656,t:1526418417721};\\\", \\\"{x:1535,y:637,t:1526418417737};\\\", \\\"{x:1537,y:611,t:1526418417754};\\\", \\\"{x:1537,y:588,t:1526418417771};\\\", \\\"{x:1536,y:565,t:1526418417788};\\\", \\\"{x:1533,y:544,t:1526418417805};\\\", \\\"{x:1533,y:529,t:1526418417820};\\\", \\\"{x:1535,y:520,t:1526418417838};\\\", \\\"{x:1535,y:518,t:1526418417855};\\\", \\\"{x:1536,y:518,t:1526418417872};\\\", \\\"{x:1541,y:520,t:1526418417888};\\\", \\\"{x:1551,y:539,t:1526418417905};\\\", \\\"{x:1568,y:572,t:1526418417922};\\\", \\\"{x:1575,y:585,t:1526418417938};\\\", \\\"{x:1579,y:593,t:1526418417955};\\\", \\\"{x:1581,y:595,t:1526418417971};\\\", \\\"{x:1584,y:595,t:1526418417987};\\\", \\\"{x:1589,y:591,t:1526418418004};\\\", \\\"{x:1596,y:575,t:1526418418021};\\\", \\\"{x:1604,y:557,t:1526418418038};\\\", \\\"{x:1608,y:540,t:1526418418055};\\\", \\\"{x:1613,y:522,t:1526418418071};\\\", \\\"{x:1616,y:512,t:1526418418087};\\\", \\\"{x:1616,y:508,t:1526418418105};\\\", \\\"{x:1616,y:504,t:1526418418121};\\\", \\\"{x:1616,y:508,t:1526418418169};\\\", \\\"{x:1615,y:514,t:1526418418178};\\\", \\\"{x:1614,y:518,t:1526418418188};\\\", \\\"{x:1612,y:522,t:1526418418205};\\\", \\\"{x:1612,y:523,t:1526418418222};\\\", \\\"{x:1612,y:519,t:1526418418259};\\\", \\\"{x:1612,y:510,t:1526418418272};\\\", \\\"{x:1615,y:484,t:1526418418288};\\\", \\\"{x:1618,y:456,t:1526418418304};\\\", \\\"{x:1613,y:421,t:1526418418322};\\\", \\\"{x:1610,y:411,t:1526418418337};\\\", \\\"{x:1609,y:410,t:1526418418395};\\\", \\\"{x:1608,y:410,t:1526418418404};\\\", \\\"{x:1605,y:424,t:1526418418421};\\\", \\\"{x:1605,y:445,t:1526418418439};\\\", \\\"{x:1609,y:472,t:1526418418454};\\\", \\\"{x:1622,y:509,t:1526418418471};\\\", \\\"{x:1648,y:558,t:1526418418489};\\\", \\\"{x:1686,y:613,t:1526418418504};\\\", \\\"{x:1739,y:701,t:1526418418521};\\\", \\\"{x:1761,y:739,t:1526418418539};\\\", \\\"{x:1772,y:762,t:1526418418554};\\\", \\\"{x:1776,y:779,t:1526418418571};\\\", \\\"{x:1778,y:789,t:1526418418589};\\\", \\\"{x:1778,y:792,t:1526418418604};\\\", \\\"{x:1777,y:797,t:1526418418621};\\\", \\\"{x:1774,y:805,t:1526418418638};\\\", \\\"{x:1770,y:809,t:1526418418654};\\\", \\\"{x:1766,y:814,t:1526418418671};\\\", \\\"{x:1766,y:815,t:1526418418697};\\\", \\\"{x:1759,y:818,t:1526418418705};\\\", \\\"{x:1745,y:822,t:1526418418721};\\\", \\\"{x:1736,y:825,t:1526418418738};\\\", \\\"{x:1731,y:825,t:1526418418755};\\\", \\\"{x:1730,y:825,t:1526418418772};\\\", \\\"{x:1729,y:826,t:1526418418789};\\\", \\\"{x:1727,y:826,t:1526418418806};\\\", \\\"{x:1723,y:827,t:1526418418822};\\\", \\\"{x:1710,y:830,t:1526418418838};\\\", \\\"{x:1701,y:830,t:1526418418855};\\\", \\\"{x:1690,y:833,t:1526418418871};\\\", \\\"{x:1677,y:835,t:1526418418888};\\\", \\\"{x:1657,y:839,t:1526418418905};\\\", \\\"{x:1646,y:839,t:1526418418921};\\\", \\\"{x:1633,y:840,t:1526418418939};\\\", \\\"{x:1619,y:843,t:1526418418955};\\\", \\\"{x:1606,y:844,t:1526418418971};\\\", \\\"{x:1585,y:844,t:1526418418988};\\\", \\\"{x:1556,y:844,t:1526418419005};\\\", \\\"{x:1518,y:844,t:1526418419021};\\\", \\\"{x:1484,y:844,t:1526418419038};\\\", \\\"{x:1460,y:845,t:1526418419055};\\\", \\\"{x:1441,y:845,t:1526418419071};\\\", \\\"{x:1431,y:845,t:1526418419088};\\\", \\\"{x:1423,y:845,t:1526418419105};\\\", \\\"{x:1422,y:845,t:1526418419123};\\\", \\\"{x:1420,y:843,t:1526418419193};\\\", \\\"{x:1419,y:843,t:1526418419205};\\\", \\\"{x:1416,y:840,t:1526418419222};\\\", \\\"{x:1413,y:836,t:1526418419239};\\\", \\\"{x:1410,y:832,t:1526418419256};\\\", \\\"{x:1405,y:827,t:1526418419272};\\\", \\\"{x:1404,y:823,t:1526418419288};\\\", \\\"{x:1400,y:817,t:1526418419305};\\\", \\\"{x:1399,y:814,t:1526418419323};\\\", \\\"{x:1398,y:810,t:1526418419338};\\\", \\\"{x:1398,y:807,t:1526418419356};\\\", \\\"{x:1397,y:801,t:1526418419372};\\\", \\\"{x:1396,y:799,t:1526418419388};\\\", \\\"{x:1396,y:798,t:1526418419405};\\\", \\\"{x:1396,y:797,t:1526418419422};\\\", \\\"{x:1396,y:796,t:1526418419441};\\\", \\\"{x:1396,y:794,t:1526418419457};\\\", \\\"{x:1396,y:793,t:1526418419472};\\\", \\\"{x:1396,y:789,t:1526418419488};\\\", \\\"{x:1395,y:784,t:1526418419505};\\\", \\\"{x:1394,y:782,t:1526418419523};\\\", \\\"{x:1393,y:779,t:1526418419538};\\\", \\\"{x:1392,y:776,t:1526418419555};\\\", \\\"{x:1390,y:773,t:1526418419572};\\\", \\\"{x:1390,y:772,t:1526418419589};\\\", \\\"{x:1388,y:769,t:1526418419858};\\\", \\\"{x:1387,y:767,t:1526418419874};\\\", \\\"{x:1386,y:766,t:1526418419890};\\\", \\\"{x:1385,y:764,t:1526418419923};\\\", \\\"{x:1384,y:762,t:1526418419939};\\\", \\\"{x:1383,y:761,t:1526418419956};\\\", \\\"{x:1382,y:761,t:1526418420201};\\\", \\\"{x:1383,y:761,t:1526418420689};\\\", \\\"{x:1389,y:761,t:1526418420706};\\\", \\\"{x:1395,y:761,t:1526418420724};\\\", \\\"{x:1402,y:761,t:1526418420739};\\\", \\\"{x:1413,y:763,t:1526418420756};\\\", \\\"{x:1420,y:763,t:1526418420774};\\\", \\\"{x:1422,y:763,t:1526418420790};\\\", \\\"{x:1424,y:763,t:1526418420841};\\\", \\\"{x:1425,y:763,t:1526418420945};\\\", \\\"{x:1426,y:763,t:1526418420956};\\\", \\\"{x:1427,y:763,t:1526418420974};\\\", \\\"{x:1432,y:763,t:1526418420991};\\\", \\\"{x:1437,y:763,t:1526418421006};\\\", \\\"{x:1446,y:763,t:1526418421024};\\\", \\\"{x:1458,y:763,t:1526418421041};\\\", \\\"{x:1465,y:763,t:1526418421057};\\\", \\\"{x:1466,y:763,t:1526418421074};\\\", \\\"{x:1464,y:763,t:1526418421241};\\\", \\\"{x:1461,y:763,t:1526418421256};\\\", \\\"{x:1455,y:763,t:1526418421273};\\\", \\\"{x:1453,y:762,t:1526418421290};\\\", \\\"{x:1452,y:762,t:1526418421641};\\\", \\\"{x:1455,y:762,t:1526418421794};\\\", \\\"{x:1462,y:762,t:1526418421807};\\\", \\\"{x:1475,y:762,t:1526418421824};\\\", \\\"{x:1486,y:762,t:1526418421841};\\\", \\\"{x:1495,y:762,t:1526418421858};\\\", \\\"{x:1496,y:762,t:1526418421875};\\\", \\\"{x:1498,y:762,t:1526418421938};\\\", \\\"{x:1499,y:762,t:1526418421947};\\\", \\\"{x:1500,y:762,t:1526418421958};\\\", \\\"{x:1507,y:761,t:1526418421976};\\\", \\\"{x:1511,y:761,t:1526418421991};\\\", \\\"{x:1515,y:761,t:1526418422008};\\\", \\\"{x:1517,y:761,t:1526418422306};\\\", \\\"{x:1518,y:761,t:1526418422313};\\\", \\\"{x:1520,y:761,t:1526418422324};\\\", \\\"{x:1530,y:761,t:1526418422342};\\\", \\\"{x:1549,y:761,t:1526418422358};\\\", \\\"{x:1568,y:761,t:1526418422374};\\\", \\\"{x:1585,y:761,t:1526418422391};\\\", \\\"{x:1588,y:761,t:1526418422407};\\\", \\\"{x:1587,y:761,t:1526418422673};\\\", \\\"{x:1585,y:761,t:1526418422681};\\\", \\\"{x:1583,y:761,t:1526418422922};\\\", \\\"{x:1582,y:761,t:1526418422929};\\\", \\\"{x:1581,y:761,t:1526418422942};\\\", \\\"{x:1577,y:761,t:1526418422958};\\\", \\\"{x:1574,y:761,t:1526418422975};\\\", \\\"{x:1570,y:763,t:1526418422992};\\\", \\\"{x:1571,y:763,t:1526418423305};\\\", \\\"{x:1572,y:764,t:1526418423313};\\\", \\\"{x:1573,y:764,t:1526418423325};\\\", \\\"{x:1575,y:765,t:1526418423341};\\\", \\\"{x:1576,y:765,t:1526418423359};\\\", \\\"{x:1577,y:767,t:1526418424723};\\\", \\\"{x:1573,y:771,t:1526418424730};\\\", \\\"{x:1565,y:778,t:1526418424742};\\\", \\\"{x:1538,y:795,t:1526418424760};\\\", \\\"{x:1485,y:820,t:1526418424777};\\\", \\\"{x:1439,y:854,t:1526418424793};\\\", \\\"{x:1436,y:855,t:1526418424810};\\\", \\\"{x:1434,y:856,t:1526418424827};\\\", \\\"{x:1433,y:857,t:1526418424857};\\\", \\\"{x:1432,y:857,t:1526418424905};\\\", \\\"{x:1430,y:857,t:1526418424913};\\\", \\\"{x:1430,y:859,t:1526418424926};\\\", \\\"{x:1427,y:862,t:1526418424944};\\\", \\\"{x:1427,y:864,t:1526418424959};\\\", \\\"{x:1422,y:867,t:1526418424976};\\\", \\\"{x:1390,y:878,t:1526418424993};\\\", \\\"{x:1367,y:885,t:1526418425009};\\\", \\\"{x:1347,y:889,t:1526418425026};\\\", \\\"{x:1337,y:892,t:1526418425044};\\\", \\\"{x:1332,y:892,t:1526418425059};\\\", \\\"{x:1329,y:894,t:1526418425076};\\\", \\\"{x:1328,y:894,t:1526418425094};\\\", \\\"{x:1331,y:895,t:1526418425265};\\\", \\\"{x:1335,y:898,t:1526418425277};\\\", \\\"{x:1345,y:901,t:1526418425294};\\\", \\\"{x:1348,y:902,t:1526418425311};\\\", \\\"{x:1348,y:903,t:1526418425327};\\\", \\\"{x:1349,y:903,t:1526418425449};\\\", \\\"{x:1349,y:902,t:1526418425460};\\\", \\\"{x:1351,y:900,t:1526418425476};\\\", \\\"{x:1353,y:897,t:1526418425494};\\\", \\\"{x:1354,y:895,t:1526418425512};\\\", \\\"{x:1356,y:894,t:1526418425526};\\\", \\\"{x:1356,y:893,t:1526418425544};\\\", \\\"{x:1356,y:892,t:1526418425673};\\\", \\\"{x:1354,y:892,t:1526418425689};\\\", \\\"{x:1353,y:892,t:1526418425697};\\\", \\\"{x:1355,y:892,t:1526418425882};\\\", \\\"{x:1357,y:892,t:1526418425894};\\\", \\\"{x:1363,y:892,t:1526418425911};\\\", \\\"{x:1365,y:892,t:1526418425927};\\\", \\\"{x:1367,y:892,t:1526418426001};\\\", \\\"{x:1368,y:892,t:1526418426017};\\\", \\\"{x:1370,y:892,t:1526418426028};\\\", \\\"{x:1372,y:891,t:1526418426043};\\\", \\\"{x:1374,y:891,t:1526418426061};\\\", \\\"{x:1378,y:891,t:1526418426078};\\\", \\\"{x:1381,y:891,t:1526418426093};\\\", \\\"{x:1385,y:890,t:1526418426111};\\\", \\\"{x:1386,y:890,t:1526418426137};\\\", \\\"{x:1387,y:890,t:1526418426154};\\\", \\\"{x:1389,y:890,t:1526418426169};\\\", \\\"{x:1391,y:890,t:1526418426177};\\\", \\\"{x:1400,y:890,t:1526418426194};\\\", \\\"{x:1409,y:891,t:1526418426211};\\\", \\\"{x:1418,y:893,t:1526418426227};\\\", \\\"{x:1424,y:894,t:1526418426244};\\\", \\\"{x:1426,y:894,t:1526418426260};\\\", \\\"{x:1427,y:894,t:1526418426277};\\\", \\\"{x:1431,y:894,t:1526418426295};\\\", \\\"{x:1431,y:895,t:1526418426386};\\\", \\\"{x:1429,y:895,t:1526418426395};\\\", \\\"{x:1424,y:897,t:1526418426411};\\\", \\\"{x:1420,y:898,t:1526418426427};\\\", \\\"{x:1418,y:898,t:1526418426445};\\\", \\\"{x:1417,y:899,t:1526418426537};\\\", \\\"{x:1412,y:899,t:1526418427027};\\\", \\\"{x:1407,y:895,t:1526418427034};\\\", \\\"{x:1397,y:889,t:1526418427045};\\\", \\\"{x:1375,y:879,t:1526418427061};\\\", \\\"{x:1341,y:870,t:1526418427079};\\\", \\\"{x:1299,y:859,t:1526418427095};\\\", \\\"{x:1279,y:853,t:1526418427112};\\\", \\\"{x:1274,y:851,t:1526418427129};\\\", \\\"{x:1273,y:849,t:1526418427145};\\\", \\\"{x:1274,y:847,t:1526418427162};\\\", \\\"{x:1275,y:846,t:1526418427179};\\\", \\\"{x:1275,y:845,t:1526418427298};\\\", \\\"{x:1275,y:844,t:1526418427312};\\\", \\\"{x:1275,y:841,t:1526418427330};\\\", \\\"{x:1277,y:840,t:1526418427346};\\\", \\\"{x:1278,y:837,t:1526418427362};\\\", \\\"{x:1280,y:835,t:1526418427380};\\\", \\\"{x:1280,y:834,t:1526418427538};\\\", \\\"{x:1280,y:833,t:1526418427546};\\\", \\\"{x:1281,y:833,t:1526418427570};\\\", \\\"{x:1282,y:833,t:1526418427585};\\\", \\\"{x:1283,y:833,t:1526418427642};\\\", \\\"{x:1284,y:833,t:1526418427682};\\\", \\\"{x:1284,y:832,t:1526418427696};\\\", \\\"{x:1286,y:832,t:1526418427712};\\\", \\\"{x:1290,y:832,t:1526418427730};\\\", \\\"{x:1292,y:832,t:1526418427746};\\\", \\\"{x:1294,y:832,t:1526418427762};\\\", \\\"{x:1296,y:832,t:1526418427779};\\\", \\\"{x:1298,y:832,t:1526418427797};\\\", \\\"{x:1300,y:832,t:1526418427812};\\\", \\\"{x:1301,y:832,t:1526418427834};\\\", \\\"{x:1302,y:832,t:1526418427850};\\\", \\\"{x:1303,y:831,t:1526418427862};\\\", \\\"{x:1313,y:831,t:1526418427879};\\\", \\\"{x:1329,y:831,t:1526418427896};\\\", \\\"{x:1347,y:831,t:1526418427913};\\\", \\\"{x:1359,y:831,t:1526418427930};\\\", \\\"{x:1364,y:831,t:1526418427947};\\\", \\\"{x:1367,y:831,t:1526418428194};\\\", \\\"{x:1369,y:831,t:1526418428202};\\\", \\\"{x:1376,y:830,t:1526418428213};\\\", \\\"{x:1398,y:829,t:1526418428230};\\\", \\\"{x:1423,y:829,t:1526418428246};\\\", \\\"{x:1446,y:829,t:1526418428263};\\\", \\\"{x:1456,y:829,t:1526418428279};\\\", \\\"{x:1457,y:828,t:1526418428306};\\\", \\\"{x:1455,y:828,t:1526418428377};\\\", \\\"{x:1454,y:828,t:1526418428385};\\\", \\\"{x:1449,y:828,t:1526418428396};\\\", \\\"{x:1434,y:829,t:1526418428413};\\\", \\\"{x:1424,y:830,t:1526418428430};\\\", \\\"{x:1420,y:831,t:1526418428446};\\\", \\\"{x:1418,y:831,t:1526418428577};\\\", \\\"{x:1415,y:831,t:1526418428586};\\\", \\\"{x:1405,y:832,t:1526418428596};\\\", \\\"{x:1349,y:838,t:1526418428613};\\\", \\\"{x:1260,y:838,t:1526418428629};\\\", \\\"{x:1179,y:838,t:1526418428646};\\\", \\\"{x:1115,y:838,t:1526418428663};\\\", \\\"{x:1079,y:838,t:1526418428679};\\\", \\\"{x:1065,y:838,t:1526418428696};\\\", \\\"{x:1064,y:838,t:1526418428713};\\\", \\\"{x:1072,y:838,t:1526418428729};\\\", \\\"{x:1086,y:836,t:1526418428746};\\\", \\\"{x:1103,y:834,t:1526418428762};\\\", \\\"{x:1116,y:834,t:1526418428780};\\\", \\\"{x:1122,y:834,t:1526418428795};\\\", \\\"{x:1125,y:834,t:1526418428812};\\\", \\\"{x:1126,y:834,t:1526418428898};\\\", \\\"{x:1126,y:833,t:1526418428914};\\\", \\\"{x:1126,y:831,t:1526418428930};\\\", \\\"{x:1124,y:829,t:1526418428948};\\\", \\\"{x:1113,y:827,t:1526418428963};\\\", \\\"{x:1105,y:827,t:1526418428980};\\\", \\\"{x:1099,y:826,t:1526418428997};\\\", \\\"{x:1092,y:825,t:1526418429013};\\\", \\\"{x:1080,y:825,t:1526418429029};\\\", \\\"{x:1063,y:825,t:1526418429047};\\\", \\\"{x:1045,y:822,t:1526418429063};\\\", \\\"{x:1022,y:822,t:1526418429080};\\\", \\\"{x:986,y:816,t:1526418429097};\\\", \\\"{x:950,y:815,t:1526418429113};\\\", \\\"{x:918,y:810,t:1526418429130};\\\", \\\"{x:913,y:809,t:1526418429146};\\\", \\\"{x:912,y:807,t:1526418429794};\\\", \\\"{x:903,y:806,t:1526418429802};\\\", \\\"{x:900,y:806,t:1526418429814};\\\", \\\"{x:886,y:805,t:1526418429831};\\\", \\\"{x:873,y:805,t:1526418429848};\\\", \\\"{x:861,y:805,t:1526418429864};\\\", \\\"{x:836,y:801,t:1526418429881};\\\", \\\"{x:797,y:797,t:1526418429898};\\\", \\\"{x:722,y:783,t:1526418429914};\\\", \\\"{x:677,y:777,t:1526418429932};\\\", \\\"{x:646,y:773,t:1526418429948};\\\", \\\"{x:628,y:771,t:1526418429964};\\\", \\\"{x:617,y:770,t:1526418429981};\\\", \\\"{x:602,y:767,t:1526418429997};\\\", \\\"{x:586,y:765,t:1526418430014};\\\", \\\"{x:569,y:762,t:1526418430031};\\\", \\\"{x:563,y:762,t:1526418430047};\\\", \\\"{x:560,y:761,t:1526418430064};\\\", \\\"{x:559,y:759,t:1526418430081};\\\", \\\"{x:559,y:758,t:1526418430145};\\\", \\\"{x:558,y:756,t:1526418430161};\\\", \\\"{x:556,y:755,t:1526418430168};\\\", \\\"{x:556,y:753,t:1526418430181};\\\", \\\"{x:551,y:746,t:1526418430198};\\\", \\\"{x:542,y:738,t:1526418430214};\\\", \\\"{x:532,y:730,t:1526418430232};\\\", \\\"{x:524,y:725,t:1526418430248};\\\", \\\"{x:520,y:722,t:1526418430264};\\\", \\\"{x:516,y:719,t:1526418430280};\\\", \\\"{x:516,y:718,t:1526418430297};\\\", \\\"{x:515,y:718,t:1526418430320};\\\", \\\"{x:514,y:718,t:1526418430858};\\\", \\\"{x:513,y:718,t:1526418430866};\\\", \\\"{x:511,y:718,t:1526418430914};\\\", \\\"{x:510,y:718,t:1526418430954};\\\" ] }, { \\\"rt\\\": 90134, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 420023, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -B -F -F -03:30-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:719,t:1526418442377};\\\", \\\"{x:508,y:720,t:1526418442473};\\\", \\\"{x:507,y:720,t:1526418442480};\\\", \\\"{x:506,y:721,t:1526418442521};\\\", \\\"{x:505,y:721,t:1526418442529};\\\", \\\"{x:504,y:721,t:1526418442642};\\\", \\\"{x:509,y:719,t:1526418443674};\\\", \\\"{x:519,y:713,t:1526418443682};\\\", \\\"{x:539,y:697,t:1526418443697};\\\", \\\"{x:557,y:684,t:1526418443714};\\\", \\\"{x:569,y:673,t:1526418443727};\\\", \\\"{x:593,y:649,t:1526418443744};\\\", \\\"{x:619,y:628,t:1526418443760};\\\", \\\"{x:673,y:581,t:1526418443777};\\\", \\\"{x:715,y:545,t:1526418443793};\\\", \\\"{x:765,y:510,t:1526418443811};\\\", \\\"{x:821,y:469,t:1526418443828};\\\", \\\"{x:873,y:430,t:1526418443843};\\\", \\\"{x:935,y:378,t:1526418443860};\\\", \\\"{x:981,y:352,t:1526418443877};\\\", \\\"{x:1015,y:342,t:1526418443893};\\\", \\\"{x:1043,y:338,t:1526418443910};\\\", \\\"{x:1065,y:336,t:1526418443928};\\\", \\\"{x:1082,y:336,t:1526418443944};\\\", \\\"{x:1096,y:336,t:1526418443961};\\\", \\\"{x:1109,y:336,t:1526418443976};\\\", \\\"{x:1118,y:337,t:1526418443993};\\\", \\\"{x:1123,y:341,t:1526418444010};\\\", \\\"{x:1132,y:356,t:1526418444027};\\\", \\\"{x:1156,y:400,t:1526418444043};\\\", \\\"{x:1202,y:464,t:1526418444061};\\\", \\\"{x:1232,y:502,t:1526418444076};\\\", \\\"{x:1253,y:520,t:1526418444094};\\\", \\\"{x:1264,y:527,t:1526418444111};\\\", \\\"{x:1267,y:529,t:1526418444126};\\\", \\\"{x:1269,y:529,t:1526418444143};\\\", \\\"{x:1271,y:530,t:1526418444202};\\\", \\\"{x:1275,y:530,t:1526418444210};\\\", \\\"{x:1289,y:532,t:1526418444227};\\\", \\\"{x:1302,y:533,t:1526418444243};\\\", \\\"{x:1310,y:533,t:1526418444259};\\\", \\\"{x:1314,y:533,t:1526418444276};\\\", \\\"{x:1316,y:533,t:1526418444294};\\\", \\\"{x:1318,y:532,t:1526418444310};\\\", \\\"{x:1318,y:530,t:1526418444326};\\\", \\\"{x:1320,y:527,t:1526418444343};\\\", \\\"{x:1321,y:526,t:1526418444360};\\\", \\\"{x:1322,y:525,t:1526418444377};\\\", \\\"{x:1322,y:524,t:1526418444394};\\\", \\\"{x:1322,y:523,t:1526418444409};\\\", \\\"{x:1324,y:521,t:1526418444427};\\\", \\\"{x:1326,y:519,t:1526418444443};\\\", \\\"{x:1330,y:516,t:1526418444459};\\\", \\\"{x:1331,y:515,t:1526418444476};\\\", \\\"{x:1331,y:514,t:1526418444493};\\\", \\\"{x:1331,y:513,t:1526418444509};\\\", \\\"{x:1331,y:511,t:1526418444553};\\\", \\\"{x:1331,y:509,t:1526418444585};\\\", \\\"{x:1329,y:507,t:1526418444593};\\\", \\\"{x:1328,y:507,t:1526418444609};\\\", \\\"{x:1327,y:507,t:1526418444626};\\\", \\\"{x:1326,y:507,t:1526418444643};\\\", \\\"{x:1325,y:507,t:1526418444660};\\\", \\\"{x:1323,y:506,t:1526418445000};\\\", \\\"{x:1322,y:506,t:1526418445017};\\\", \\\"{x:1321,y:505,t:1526418445026};\\\", \\\"{x:1320,y:505,t:1526418445057};\\\", \\\"{x:1319,y:505,t:1526418445073};\\\", \\\"{x:1318,y:505,t:1526418445081};\\\", \\\"{x:1317,y:505,t:1526418445097};\\\", \\\"{x:1316,y:505,t:1526418445108};\\\", \\\"{x:1315,y:505,t:1526418445125};\\\", \\\"{x:1314,y:505,t:1526418447106};\\\", \\\"{x:1312,y:506,t:1526418447124};\\\", \\\"{x:1311,y:510,t:1526418447140};\\\", \\\"{x:1309,y:514,t:1526418447157};\\\", \\\"{x:1309,y:521,t:1526418447174};\\\", \\\"{x:1308,y:527,t:1526418447190};\\\", \\\"{x:1307,y:536,t:1526418447207};\\\", \\\"{x:1304,y:549,t:1526418447224};\\\", \\\"{x:1303,y:560,t:1526418447239};\\\", \\\"{x:1299,y:579,t:1526418447257};\\\", \\\"{x:1295,y:590,t:1526418447273};\\\", \\\"{x:1293,y:603,t:1526418447290};\\\", \\\"{x:1289,y:616,t:1526418447307};\\\", \\\"{x:1288,y:629,t:1526418447323};\\\", \\\"{x:1284,y:643,t:1526418447339};\\\", \\\"{x:1280,y:660,t:1526418447356};\\\", \\\"{x:1278,y:676,t:1526418447372};\\\", \\\"{x:1277,y:695,t:1526418447389};\\\", \\\"{x:1273,y:714,t:1526418447407};\\\", \\\"{x:1272,y:734,t:1526418447423};\\\", \\\"{x:1269,y:753,t:1526418447440};\\\", \\\"{x:1267,y:771,t:1526418447457};\\\", \\\"{x:1266,y:793,t:1526418447473};\\\", \\\"{x:1266,y:832,t:1526418447490};\\\", \\\"{x:1266,y:853,t:1526418447506};\\\", \\\"{x:1266,y:870,t:1526418447523};\\\", \\\"{x:1266,y:890,t:1526418447539};\\\", \\\"{x:1270,y:908,t:1526418447557};\\\", \\\"{x:1277,y:924,t:1526418447572};\\\", \\\"{x:1282,y:937,t:1526418447590};\\\", \\\"{x:1284,y:942,t:1526418447606};\\\", \\\"{x:1286,y:945,t:1526418447623};\\\", \\\"{x:1286,y:946,t:1526418447639};\\\", \\\"{x:1286,y:947,t:1526418447657};\\\", \\\"{x:1287,y:948,t:1526418447721};\\\", \\\"{x:1289,y:949,t:1526418447745};\\\", \\\"{x:1290,y:949,t:1526418447761};\\\", \\\"{x:1290,y:950,t:1526418447801};\\\", \\\"{x:1291,y:951,t:1526418447809};\\\", \\\"{x:1294,y:956,t:1526418447823};\\\", \\\"{x:1296,y:961,t:1526418447839};\\\", \\\"{x:1301,y:971,t:1526418447856};\\\", \\\"{x:1303,y:974,t:1526418447873};\\\", \\\"{x:1304,y:976,t:1526418447945};\\\", \\\"{x:1304,y:977,t:1526418447985};\\\", \\\"{x:1305,y:977,t:1526418448009};\\\", \\\"{x:1306,y:977,t:1526418448049};\\\", \\\"{x:1307,y:977,t:1526418448097};\\\", \\\"{x:1307,y:976,t:1526418448137};\\\", \\\"{x:1307,y:975,t:1526418448145};\\\", \\\"{x:1308,y:973,t:1526418448156};\\\", \\\"{x:1309,y:971,t:1526418448173};\\\", \\\"{x:1310,y:968,t:1526418448189};\\\", \\\"{x:1311,y:964,t:1526418448206};\\\", \\\"{x:1312,y:962,t:1526418448222};\\\", \\\"{x:1313,y:960,t:1526418448239};\\\", \\\"{x:1313,y:959,t:1526418448256};\\\", \\\"{x:1313,y:957,t:1526418448272};\\\", \\\"{x:1314,y:955,t:1526418448314};\\\", \\\"{x:1316,y:953,t:1526418448322};\\\", \\\"{x:1316,y:952,t:1526418448345};\\\", \\\"{x:1316,y:951,t:1526418448356};\\\", \\\"{x:1316,y:950,t:1526418448372};\\\", \\\"{x:1316,y:949,t:1526418448393};\\\", \\\"{x:1317,y:949,t:1526418448406};\\\", \\\"{x:1317,y:947,t:1526418448422};\\\", \\\"{x:1317,y:946,t:1526418448569};\\\", \\\"{x:1317,y:945,t:1526418448593};\\\", \\\"{x:1317,y:944,t:1526418448729};\\\", \\\"{x:1317,y:943,t:1526418448745};\\\", \\\"{x:1317,y:941,t:1526418448755};\\\", \\\"{x:1317,y:939,t:1526418448771};\\\", \\\"{x:1317,y:937,t:1526418448788};\\\", \\\"{x:1317,y:934,t:1526418448805};\\\", \\\"{x:1317,y:933,t:1526418448822};\\\", \\\"{x:1317,y:929,t:1526418448838};\\\", \\\"{x:1317,y:925,t:1526418448855};\\\", \\\"{x:1317,y:920,t:1526418448872};\\\", \\\"{x:1315,y:914,t:1526418448888};\\\", \\\"{x:1313,y:901,t:1526418448905};\\\", \\\"{x:1313,y:892,t:1526418448921};\\\", \\\"{x:1313,y:881,t:1526418448938};\\\", \\\"{x:1313,y:871,t:1526418448954};\\\", \\\"{x:1313,y:864,t:1526418448972};\\\", \\\"{x:1312,y:858,t:1526418448988};\\\", \\\"{x:1312,y:853,t:1526418449004};\\\", \\\"{x:1312,y:849,t:1526418449022};\\\", \\\"{x:1312,y:846,t:1526418449038};\\\", \\\"{x:1312,y:841,t:1526418449055};\\\", \\\"{x:1312,y:839,t:1526418449072};\\\", \\\"{x:1312,y:836,t:1526418449088};\\\", \\\"{x:1312,y:831,t:1526418449105};\\\", \\\"{x:1312,y:828,t:1526418449121};\\\", \\\"{x:1312,y:823,t:1526418449137};\\\", \\\"{x:1312,y:819,t:1526418449155};\\\", \\\"{x:1312,y:816,t:1526418449171};\\\", \\\"{x:1312,y:810,t:1526418449187};\\\", \\\"{x:1312,y:806,t:1526418449205};\\\", \\\"{x:1311,y:796,t:1526418449221};\\\", \\\"{x:1311,y:789,t:1526418449238};\\\", \\\"{x:1310,y:776,t:1526418449254};\\\", \\\"{x:1307,y:762,t:1526418449271};\\\", \\\"{x:1307,y:747,t:1526418449287};\\\", \\\"{x:1307,y:731,t:1526418449303};\\\", \\\"{x:1307,y:707,t:1526418449321};\\\", \\\"{x:1307,y:691,t:1526418449338};\\\", \\\"{x:1307,y:674,t:1526418449355};\\\", \\\"{x:1307,y:658,t:1526418449370};\\\", \\\"{x:1306,y:640,t:1526418449388};\\\", \\\"{x:1304,y:621,t:1526418449403};\\\", \\\"{x:1302,y:604,t:1526418449421};\\\", \\\"{x:1300,y:591,t:1526418449438};\\\", \\\"{x:1297,y:577,t:1526418449454};\\\", \\\"{x:1297,y:566,t:1526418449470};\\\", \\\"{x:1297,y:552,t:1526418449488};\\\", \\\"{x:1298,y:534,t:1526418449504};\\\", \\\"{x:1303,y:517,t:1526418449521};\\\", \\\"{x:1303,y:512,t:1526418449537};\\\", \\\"{x:1304,y:509,t:1526418449554};\\\", \\\"{x:1304,y:507,t:1526418449571};\\\", \\\"{x:1304,y:506,t:1526418449588};\\\", \\\"{x:1305,y:504,t:1526418449603};\\\", \\\"{x:1306,y:504,t:1526418449625};\\\", \\\"{x:1306,y:503,t:1526418449641};\\\", \\\"{x:1306,y:502,t:1526418449654};\\\", \\\"{x:1308,y:500,t:1526418449671};\\\", \\\"{x:1309,y:499,t:1526418449779};\\\", \\\"{x:1313,y:500,t:1526418459088};\\\", \\\"{x:1317,y:505,t:1526418459097};\\\", \\\"{x:1323,y:514,t:1526418459110};\\\", \\\"{x:1340,y:537,t:1526418459127};\\\", \\\"{x:1368,y:575,t:1526418459143};\\\", \\\"{x:1391,y:613,t:1526418459160};\\\", \\\"{x:1414,y:654,t:1526418459176};\\\", \\\"{x:1448,y:711,t:1526418459193};\\\", \\\"{x:1465,y:736,t:1526418459209};\\\", \\\"{x:1482,y:755,t:1526418459226};\\\", \\\"{x:1492,y:768,t:1526418459243};\\\", \\\"{x:1504,y:778,t:1526418459260};\\\", \\\"{x:1513,y:789,t:1526418459276};\\\", \\\"{x:1520,y:795,t:1526418459293};\\\", \\\"{x:1530,y:803,t:1526418459310};\\\", \\\"{x:1531,y:804,t:1526418459326};\\\", \\\"{x:1533,y:807,t:1526418459369};\\\", \\\"{x:1534,y:811,t:1526418459376};\\\", \\\"{x:1542,y:825,t:1526418459393};\\\", \\\"{x:1544,y:836,t:1526418459410};\\\", \\\"{x:1548,y:843,t:1526418459427};\\\", \\\"{x:1548,y:844,t:1526418459448};\\\", \\\"{x:1548,y:847,t:1526418459546};\\\", \\\"{x:1546,y:851,t:1526418459559};\\\", \\\"{x:1546,y:854,t:1526418459577};\\\", \\\"{x:1546,y:857,t:1526418459593};\\\", \\\"{x:1546,y:862,t:1526418459609};\\\", \\\"{x:1546,y:864,t:1526418459626};\\\", \\\"{x:1546,y:868,t:1526418459643};\\\", \\\"{x:1546,y:870,t:1526418459659};\\\", \\\"{x:1544,y:873,t:1526418459676};\\\", \\\"{x:1544,y:880,t:1526418459693};\\\", \\\"{x:1544,y:889,t:1526418459709};\\\", \\\"{x:1544,y:898,t:1526418459726};\\\", \\\"{x:1544,y:903,t:1526418459742};\\\", \\\"{x:1544,y:908,t:1526418459759};\\\", \\\"{x:1543,y:911,t:1526418459777};\\\", \\\"{x:1543,y:922,t:1526418459793};\\\", \\\"{x:1545,y:939,t:1526418459809};\\\", \\\"{x:1545,y:942,t:1526418459827};\\\", \\\"{x:1545,y:944,t:1526418459842};\\\", \\\"{x:1545,y:949,t:1526418459859};\\\", \\\"{x:1546,y:953,t:1526418459876};\\\", \\\"{x:1548,y:955,t:1526418459892};\\\", \\\"{x:1548,y:956,t:1526418459909};\\\", \\\"{x:1548,y:957,t:1526418459927};\\\", \\\"{x:1548,y:959,t:1526418459946};\\\", \\\"{x:1549,y:961,t:1526418459960};\\\", \\\"{x:1550,y:964,t:1526418459977};\\\", \\\"{x:1550,y:965,t:1526418459993};\\\", \\\"{x:1551,y:966,t:1526418460010};\\\", \\\"{x:1552,y:967,t:1526418460409};\\\", \\\"{x:1552,y:966,t:1526418460425};\\\", \\\"{x:1552,y:965,t:1526418460442};\\\", \\\"{x:1552,y:963,t:1526418460459};\\\", \\\"{x:1552,y:962,t:1526418460475};\\\", \\\"{x:1552,y:960,t:1526418460493};\\\", \\\"{x:1552,y:959,t:1526418460509};\\\", \\\"{x:1552,y:956,t:1526418460526};\\\", \\\"{x:1552,y:955,t:1526418460541};\\\", \\\"{x:1552,y:952,t:1526418460559};\\\", \\\"{x:1552,y:950,t:1526418460576};\\\", \\\"{x:1552,y:945,t:1526418460591};\\\", \\\"{x:1552,y:942,t:1526418460609};\\\", \\\"{x:1552,y:938,t:1526418460626};\\\", \\\"{x:1552,y:934,t:1526418460641};\\\", \\\"{x:1553,y:932,t:1526418460657};\\\", \\\"{x:1553,y:927,t:1526418460675};\\\", \\\"{x:1553,y:923,t:1526418460691};\\\", \\\"{x:1553,y:918,t:1526418460708};\\\", \\\"{x:1553,y:916,t:1526418460725};\\\", \\\"{x:1553,y:912,t:1526418460741};\\\", \\\"{x:1553,y:910,t:1526418460758};\\\", \\\"{x:1554,y:906,t:1526418460775};\\\", \\\"{x:1554,y:902,t:1526418460791};\\\", \\\"{x:1554,y:897,t:1526418460809};\\\", \\\"{x:1554,y:892,t:1526418460825};\\\", \\\"{x:1554,y:887,t:1526418460841};\\\", \\\"{x:1554,y:881,t:1526418460858};\\\", \\\"{x:1554,y:873,t:1526418460875};\\\", \\\"{x:1554,y:867,t:1526418460892};\\\", \\\"{x:1554,y:865,t:1526418460908};\\\", \\\"{x:1554,y:864,t:1526418460925};\\\", \\\"{x:1554,y:861,t:1526418460942};\\\", \\\"{x:1554,y:858,t:1526418460958};\\\", \\\"{x:1554,y:856,t:1526418460975};\\\", \\\"{x:1553,y:852,t:1526418460991};\\\", \\\"{x:1553,y:851,t:1526418461010};\\\", \\\"{x:1553,y:850,t:1526418461025};\\\", \\\"{x:1553,y:848,t:1526418461042};\\\", \\\"{x:1552,y:846,t:1526418461059};\\\", \\\"{x:1551,y:845,t:1526418461075};\\\", \\\"{x:1551,y:842,t:1526418461092};\\\", \\\"{x:1550,y:840,t:1526418461108};\\\", \\\"{x:1550,y:838,t:1526418461124};\\\", \\\"{x:1549,y:836,t:1526418461141};\\\", \\\"{x:1548,y:833,t:1526418461157};\\\", \\\"{x:1547,y:829,t:1526418461174};\\\", \\\"{x:1546,y:826,t:1526418461191};\\\", \\\"{x:1545,y:824,t:1526418461207};\\\", \\\"{x:1545,y:821,t:1526418461224};\\\", \\\"{x:1545,y:816,t:1526418461241};\\\", \\\"{x:1544,y:813,t:1526418461257};\\\", \\\"{x:1544,y:808,t:1526418461275};\\\", \\\"{x:1543,y:807,t:1526418461291};\\\", \\\"{x:1543,y:805,t:1526418461307};\\\", \\\"{x:1542,y:803,t:1526418461324};\\\", \\\"{x:1541,y:802,t:1526418461341};\\\", \\\"{x:1541,y:801,t:1526418461358};\\\", \\\"{x:1541,y:798,t:1526418461374};\\\", \\\"{x:1541,y:795,t:1526418461390};\\\", \\\"{x:1540,y:794,t:1526418461407};\\\", \\\"{x:1540,y:793,t:1526418461424};\\\", \\\"{x:1540,y:790,t:1526418461440};\\\", \\\"{x:1539,y:787,t:1526418461457};\\\", \\\"{x:1538,y:782,t:1526418461474};\\\", \\\"{x:1537,y:778,t:1526418461490};\\\", \\\"{x:1536,y:772,t:1526418461507};\\\", \\\"{x:1536,y:767,t:1526418461524};\\\", \\\"{x:1535,y:763,t:1526418461540};\\\", \\\"{x:1535,y:758,t:1526418461557};\\\", \\\"{x:1535,y:754,t:1526418461574};\\\", \\\"{x:1534,y:749,t:1526418461590};\\\", \\\"{x:1533,y:745,t:1526418461607};\\\", \\\"{x:1533,y:742,t:1526418461624};\\\", \\\"{x:1533,y:740,t:1526418461640};\\\", \\\"{x:1533,y:737,t:1526418461657};\\\", \\\"{x:1533,y:734,t:1526418461674};\\\", \\\"{x:1533,y:733,t:1526418461690};\\\", \\\"{x:1533,y:731,t:1526418461707};\\\", \\\"{x:1533,y:729,t:1526418461723};\\\", \\\"{x:1533,y:728,t:1526418461740};\\\", \\\"{x:1533,y:725,t:1526418461757};\\\", \\\"{x:1534,y:722,t:1526418461774};\\\", \\\"{x:1534,y:720,t:1526418461790};\\\", \\\"{x:1534,y:719,t:1526418461807};\\\", \\\"{x:1534,y:718,t:1526418461825};\\\", \\\"{x:1534,y:716,t:1526418461849};\\\", \\\"{x:1534,y:715,t:1526418461864};\\\", \\\"{x:1534,y:713,t:1526418461881};\\\", \\\"{x:1534,y:712,t:1526418461896};\\\", \\\"{x:1534,y:710,t:1526418461921};\\\", \\\"{x:1534,y:709,t:1526418461937};\\\", \\\"{x:1534,y:707,t:1526418461953};\\\", \\\"{x:1534,y:706,t:1526418461978};\\\", \\\"{x:1504,y:699,t:1526418471780};\\\", \\\"{x:1408,y:678,t:1526418471787};\\\", \\\"{x:1290,y:652,t:1526418471798};\\\", \\\"{x:1024,y:604,t:1526418471815};\\\", \\\"{x:848,y:598,t:1526418471831};\\\", \\\"{x:734,y:621,t:1526418471849};\\\", \\\"{x:652,y:636,t:1526418471871};\\\", \\\"{x:625,y:638,t:1526418471887};\\\", \\\"{x:590,y:641,t:1526418471903};\\\", \\\"{x:560,y:641,t:1526418471920};\\\", \\\"{x:551,y:640,t:1526418471936};\\\", \\\"{x:548,y:640,t:1526418471953};\\\", \\\"{x:544,y:641,t:1526418471970};\\\", \\\"{x:536,y:646,t:1526418471986};\\\", \\\"{x:526,y:650,t:1526418472003};\\\", \\\"{x:528,y:649,t:1526418472059};\\\", \\\"{x:530,y:647,t:1526418472070};\\\", \\\"{x:544,y:641,t:1526418472086};\\\", \\\"{x:579,y:632,t:1526418472103};\\\", \\\"{x:613,y:625,t:1526418472121};\\\", \\\"{x:640,y:620,t:1526418472138};\\\", \\\"{x:649,y:616,t:1526418472153};\\\", \\\"{x:650,y:616,t:1526418472171};\\\", \\\"{x:649,y:616,t:1526418472275};\\\", \\\"{x:645,y:616,t:1526418472287};\\\", \\\"{x:640,y:616,t:1526418472305};\\\", \\\"{x:634,y:616,t:1526418472320};\\\", \\\"{x:630,y:616,t:1526418472337};\\\", \\\"{x:628,y:616,t:1526418472353};\\\", \\\"{x:627,y:616,t:1526418472370};\\\", \\\"{x:625,y:616,t:1526418472387};\\\", \\\"{x:623,y:616,t:1526418472403};\\\", \\\"{x:622,y:616,t:1526418472427};\\\", \\\"{x:621,y:616,t:1526418472437};\\\", \\\"{x:620,y:616,t:1526418472453};\\\", \\\"{x:619,y:616,t:1526418472707};\\\", \\\"{x:620,y:616,t:1526418472764};\\\", \\\"{x:625,y:616,t:1526418472771};\\\", \\\"{x:651,y:616,t:1526418472787};\\\", \\\"{x:755,y:621,t:1526418472805};\\\", \\\"{x:904,y:642,t:1526418472820};\\\", \\\"{x:1082,y:676,t:1526418472837};\\\", \\\"{x:1267,y:701,t:1526418472854};\\\", \\\"{x:1442,y:730,t:1526418472871};\\\", \\\"{x:1587,y:758,t:1526418472887};\\\", \\\"{x:1707,y:783,t:1526418472904};\\\", \\\"{x:1752,y:806,t:1526418472922};\\\", \\\"{x:1757,y:813,t:1526418472937};\\\", \\\"{x:1757,y:818,t:1526418472954};\\\", \\\"{x:1757,y:819,t:1526418473165};\\\", \\\"{x:1750,y:821,t:1526418473172};\\\", \\\"{x:1744,y:823,t:1526418473189};\\\", \\\"{x:1733,y:823,t:1526418473205};\\\", \\\"{x:1730,y:823,t:1526418473222};\\\", \\\"{x:1729,y:823,t:1526418473239};\\\", \\\"{x:1715,y:823,t:1526418473255};\\\", \\\"{x:1701,y:822,t:1526418473272};\\\", \\\"{x:1696,y:820,t:1526418473289};\\\", \\\"{x:1695,y:820,t:1526418473304};\\\", \\\"{x:1694,y:820,t:1526418473323};\\\", \\\"{x:1693,y:820,t:1526418473339};\\\", \\\"{x:1681,y:818,t:1526418473354};\\\", \\\"{x:1680,y:815,t:1526418473371};\\\", \\\"{x:1678,y:814,t:1526418473389};\\\", \\\"{x:1676,y:814,t:1526418473405};\\\", \\\"{x:1671,y:814,t:1526418473421};\\\", \\\"{x:1667,y:814,t:1526418473438};\\\", \\\"{x:1666,y:814,t:1526418473454};\\\", \\\"{x:1651,y:822,t:1526418473471};\\\", \\\"{x:1637,y:828,t:1526418473488};\\\", \\\"{x:1621,y:833,t:1526418473504};\\\", \\\"{x:1605,y:841,t:1526418473521};\\\", \\\"{x:1581,y:850,t:1526418473538};\\\", \\\"{x:1556,y:860,t:1526418473555};\\\", \\\"{x:1539,y:863,t:1526418473572};\\\", \\\"{x:1523,y:864,t:1526418473589};\\\", \\\"{x:1515,y:865,t:1526418473606};\\\", \\\"{x:1512,y:865,t:1526418473622};\\\", \\\"{x:1510,y:865,t:1526418473639};\\\", \\\"{x:1511,y:864,t:1526418474219};\\\", \\\"{x:1511,y:863,t:1526418474227};\\\", \\\"{x:1511,y:862,t:1526418474238};\\\", \\\"{x:1511,y:861,t:1526418474267};\\\", \\\"{x:1512,y:857,t:1526418474276};\\\", \\\"{x:1513,y:855,t:1526418474288};\\\", \\\"{x:1514,y:852,t:1526418474305};\\\", \\\"{x:1515,y:849,t:1526418474322};\\\", \\\"{x:1515,y:847,t:1526418474339};\\\", \\\"{x:1515,y:843,t:1526418474356};\\\", \\\"{x:1516,y:842,t:1526418474373};\\\", \\\"{x:1516,y:840,t:1526418474390};\\\", \\\"{x:1519,y:838,t:1526418474406};\\\", \\\"{x:1519,y:837,t:1526418474423};\\\", \\\"{x:1519,y:835,t:1526418474439};\\\", \\\"{x:1520,y:834,t:1526418474456};\\\", \\\"{x:1522,y:830,t:1526418474473};\\\", \\\"{x:1523,y:827,t:1526418474491};\\\", \\\"{x:1526,y:824,t:1526418474505};\\\", \\\"{x:1527,y:820,t:1526418474523};\\\", \\\"{x:1528,y:816,t:1526418474540};\\\", \\\"{x:1528,y:813,t:1526418474556};\\\", \\\"{x:1529,y:807,t:1526418474573};\\\", \\\"{x:1529,y:799,t:1526418474590};\\\", \\\"{x:1530,y:795,t:1526418474606};\\\", \\\"{x:1530,y:790,t:1526418474624};\\\", \\\"{x:1530,y:783,t:1526418474640};\\\", \\\"{x:1530,y:770,t:1526418474656};\\\", \\\"{x:1530,y:760,t:1526418474673};\\\", \\\"{x:1530,y:755,t:1526418474690};\\\", \\\"{x:1530,y:750,t:1526418474706};\\\", \\\"{x:1530,y:745,t:1526418474723};\\\", \\\"{x:1533,y:730,t:1526418474740};\\\", \\\"{x:1535,y:723,t:1526418474756};\\\", \\\"{x:1536,y:718,t:1526418474773};\\\", \\\"{x:1537,y:716,t:1526418474790};\\\", \\\"{x:1537,y:715,t:1526418474806};\\\", \\\"{x:1537,y:714,t:1526418474844};\\\", \\\"{x:1538,y:714,t:1526418474857};\\\", \\\"{x:1539,y:713,t:1526418474873};\\\", \\\"{x:1540,y:713,t:1526418474901};\\\", \\\"{x:1542,y:713,t:1526418474916};\\\", \\\"{x:1543,y:713,t:1526418474924};\\\", \\\"{x:1544,y:713,t:1526418474940};\\\", \\\"{x:1544,y:717,t:1526418474956};\\\", \\\"{x:1544,y:724,t:1526418474973};\\\", \\\"{x:1541,y:732,t:1526418474990};\\\", \\\"{x:1541,y:739,t:1526418475007};\\\", \\\"{x:1540,y:744,t:1526418475023};\\\", \\\"{x:1538,y:749,t:1526418475040};\\\", \\\"{x:1538,y:752,t:1526418475057};\\\", \\\"{x:1537,y:756,t:1526418475073};\\\", \\\"{x:1536,y:761,t:1526418475091};\\\", \\\"{x:1534,y:767,t:1526418475108};\\\", \\\"{x:1534,y:773,t:1526418475124};\\\", \\\"{x:1532,y:778,t:1526418475140};\\\", \\\"{x:1531,y:781,t:1526418475157};\\\", \\\"{x:1531,y:782,t:1526418475173};\\\", \\\"{x:1531,y:784,t:1526418475190};\\\", \\\"{x:1530,y:784,t:1526418475207};\\\", \\\"{x:1530,y:785,t:1526418475223};\\\", \\\"{x:1530,y:786,t:1526418475275};\\\", \\\"{x:1530,y:789,t:1526418475290};\\\", \\\"{x:1533,y:796,t:1526418475307};\\\", \\\"{x:1539,y:806,t:1526418475323};\\\", \\\"{x:1542,y:810,t:1526418475339};\\\", \\\"{x:1544,y:812,t:1526418475357};\\\", \\\"{x:1547,y:817,t:1526418475373};\\\", \\\"{x:1551,y:824,t:1526418475389};\\\", \\\"{x:1553,y:829,t:1526418475407};\\\", \\\"{x:1555,y:832,t:1526418475424};\\\", \\\"{x:1555,y:833,t:1526418475563};\\\", \\\"{x:1553,y:833,t:1526418475573};\\\", \\\"{x:1541,y:830,t:1526418475590};\\\", \\\"{x:1524,y:824,t:1526418475606};\\\", \\\"{x:1499,y:814,t:1526418475624};\\\", \\\"{x:1474,y:808,t:1526418475640};\\\", \\\"{x:1453,y:803,t:1526418475657};\\\", \\\"{x:1444,y:801,t:1526418475673};\\\", \\\"{x:1438,y:799,t:1526418475691};\\\", \\\"{x:1429,y:795,t:1526418475706};\\\", \\\"{x:1419,y:789,t:1526418475724};\\\", \\\"{x:1417,y:788,t:1526418475741};\\\", \\\"{x:1415,y:787,t:1526418475876};\\\", \\\"{x:1412,y:786,t:1526418475891};\\\", \\\"{x:1405,y:786,t:1526418475907};\\\", \\\"{x:1402,y:786,t:1526418475923};\\\", \\\"{x:1401,y:786,t:1526418475941};\\\", \\\"{x:1400,y:786,t:1526418476068};\\\", \\\"{x:1399,y:784,t:1526418476076};\\\", \\\"{x:1397,y:782,t:1526418476091};\\\", \\\"{x:1390,y:775,t:1526418476107};\\\", \\\"{x:1385,y:769,t:1526418476123};\\\", \\\"{x:1382,y:766,t:1526418476141};\\\", \\\"{x:1379,y:764,t:1526418476157};\\\", \\\"{x:1376,y:763,t:1526418476173};\\\", \\\"{x:1375,y:762,t:1526418476192};\\\", \\\"{x:1374,y:762,t:1526418476208};\\\", \\\"{x:1373,y:760,t:1526418478676};\\\", \\\"{x:1377,y:759,t:1526418478692};\\\", \\\"{x:1384,y:759,t:1526418478709};\\\", \\\"{x:1396,y:759,t:1526418478726};\\\", \\\"{x:1409,y:759,t:1526418478742};\\\", \\\"{x:1419,y:759,t:1526418478760};\\\", \\\"{x:1425,y:760,t:1526418478776};\\\", \\\"{x:1428,y:761,t:1526418478793};\\\", \\\"{x:1432,y:762,t:1526418478810};\\\", \\\"{x:1436,y:764,t:1526418478825};\\\", \\\"{x:1439,y:764,t:1526418478843};\\\", \\\"{x:1440,y:764,t:1526418478859};\\\", \\\"{x:1442,y:764,t:1526418478876};\\\", \\\"{x:1446,y:765,t:1526418478892};\\\", \\\"{x:1453,y:765,t:1526418478910};\\\", \\\"{x:1463,y:768,t:1526418478927};\\\", \\\"{x:1476,y:769,t:1526418478942};\\\", \\\"{x:1490,y:772,t:1526418478959};\\\", \\\"{x:1504,y:777,t:1526418478976};\\\", \\\"{x:1518,y:782,t:1526418478993};\\\", \\\"{x:1538,y:790,t:1526418479010};\\\", \\\"{x:1555,y:799,t:1526418479026};\\\", \\\"{x:1570,y:810,t:1526418479043};\\\", \\\"{x:1592,y:834,t:1526418479060};\\\", \\\"{x:1604,y:854,t:1526418479078};\\\", \\\"{x:1614,y:874,t:1526418479093};\\\", \\\"{x:1620,y:894,t:1526418479110};\\\", \\\"{x:1622,y:907,t:1526418479128};\\\", \\\"{x:1622,y:912,t:1526418479143};\\\", \\\"{x:1622,y:916,t:1526418479159};\\\", \\\"{x:1622,y:919,t:1526418479177};\\\", \\\"{x:1622,y:924,t:1526418479192};\\\", \\\"{x:1622,y:929,t:1526418479210};\\\", \\\"{x:1620,y:933,t:1526418479227};\\\", \\\"{x:1619,y:936,t:1526418479243};\\\", \\\"{x:1617,y:937,t:1526418479260};\\\", \\\"{x:1615,y:938,t:1526418479278};\\\", \\\"{x:1614,y:938,t:1526418479307};\\\", \\\"{x:1613,y:940,t:1526418479339};\\\", \\\"{x:1611,y:941,t:1526418479356};\\\", \\\"{x:1609,y:942,t:1526418479372};\\\", \\\"{x:1606,y:944,t:1526418479380};\\\", \\\"{x:1603,y:946,t:1526418479394};\\\", \\\"{x:1596,y:949,t:1526418479410};\\\", \\\"{x:1593,y:951,t:1526418479428};\\\", \\\"{x:1591,y:955,t:1526418479444};\\\", \\\"{x:1590,y:957,t:1526418479460};\\\", \\\"{x:1590,y:958,t:1526418479477};\\\", \\\"{x:1590,y:961,t:1526418479494};\\\", \\\"{x:1590,y:962,t:1526418479510};\\\", \\\"{x:1588,y:964,t:1526418479527};\\\", \\\"{x:1588,y:965,t:1526418479544};\\\", \\\"{x:1587,y:966,t:1526418479700};\\\", \\\"{x:1586,y:966,t:1526418479756};\\\", \\\"{x:1585,y:966,t:1526418479763};\\\", \\\"{x:1584,y:966,t:1526418479779};\\\", \\\"{x:1582,y:964,t:1526418480355};\\\", \\\"{x:1579,y:962,t:1526418480371};\\\", \\\"{x:1579,y:961,t:1526418480379};\\\", \\\"{x:1578,y:961,t:1526418522711};\\\", \\\"{x:1576,y:961,t:1526418522719};\\\", \\\"{x:1574,y:961,t:1526418522734};\\\", \\\"{x:1571,y:961,t:1526418522751};\\\", \\\"{x:1568,y:963,t:1526418522767};\\\", \\\"{x:1566,y:963,t:1526418522784};\\\", \\\"{x:1564,y:965,t:1526418522802};\\\", \\\"{x:1558,y:965,t:1526418522817};\\\", \\\"{x:1551,y:965,t:1526418522834};\\\", \\\"{x:1548,y:965,t:1526418522851};\\\", \\\"{x:1546,y:965,t:1526418522868};\\\", \\\"{x:1542,y:965,t:1526418522884};\\\", \\\"{x:1539,y:965,t:1526418522902};\\\", \\\"{x:1536,y:965,t:1526418522917};\\\", \\\"{x:1530,y:965,t:1526418522934};\\\", \\\"{x:1528,y:965,t:1526418522951};\\\", \\\"{x:1523,y:965,t:1526418522968};\\\", \\\"{x:1518,y:965,t:1526418522984};\\\", \\\"{x:1509,y:965,t:1526418523002};\\\", \\\"{x:1496,y:962,t:1526418523018};\\\", \\\"{x:1469,y:953,t:1526418523035};\\\", \\\"{x:1418,y:937,t:1526418523051};\\\", \\\"{x:1342,y:919,t:1526418523068};\\\", \\\"{x:1256,y:896,t:1526418523084};\\\", \\\"{x:1151,y:870,t:1526418523101};\\\", \\\"{x:948,y:825,t:1526418523119};\\\", \\\"{x:816,y:793,t:1526418523134};\\\", \\\"{x:715,y:771,t:1526418523151};\\\", \\\"{x:634,y:758,t:1526418523169};\\\", \\\"{x:569,y:747,t:1526418523184};\\\", \\\"{x:503,y:729,t:1526418523203};\\\", \\\"{x:447,y:721,t:1526418523218};\\\", \\\"{x:424,y:715,t:1526418523233};\\\", \\\"{x:410,y:712,t:1526418523248};\\\", \\\"{x:403,y:711,t:1526418523263};\\\", \\\"{x:398,y:710,t:1526418523281};\\\", \\\"{x:393,y:708,t:1526418523298};\\\", \\\"{x:389,y:708,t:1526418523313};\\\", \\\"{x:383,y:708,t:1526418523331};\\\", \\\"{x:374,y:709,t:1526418523347};\\\", \\\"{x:368,y:715,t:1526418523364};\\\", \\\"{x:350,y:724,t:1526418523381};\\\", \\\"{x:328,y:734,t:1526418523397};\\\", \\\"{x:326,y:736,t:1526418523414};\\\", \\\"{x:326,y:738,t:1526418523431};\\\", \\\"{x:326,y:739,t:1526418523448};\\\", \\\"{x:326,y:740,t:1526418523573};\\\", \\\"{x:340,y:740,t:1526418523581};\\\", \\\"{x:461,y:750,t:1526418523597};\\\", \\\"{x:641,y:755,t:1526418523615};\\\", \\\"{x:789,y:763,t:1526418523630};\\\", \\\"{x:907,y:754,t:1526418523648};\\\", \\\"{x:996,y:741,t:1526418523665};\\\", \\\"{x:1031,y:735,t:1526418523682};\\\", \\\"{x:1034,y:732,t:1526418523698};\\\", \\\"{x:1034,y:730,t:1526418523714};\\\", \\\"{x:1025,y:730,t:1526418523732};\\\", \\\"{x:997,y:730,t:1526418523748};\\\", \\\"{x:966,y:730,t:1526418523765};\\\", \\\"{x:865,y:730,t:1526418523782};\\\", \\\"{x:790,y:730,t:1526418523798};\\\", \\\"{x:682,y:728,t:1526418523815};\\\", \\\"{x:600,y:724,t:1526418523832};\\\", \\\"{x:569,y:724,t:1526418523848};\\\", \\\"{x:553,y:725,t:1526418523865};\\\", \\\"{x:548,y:726,t:1526418523882};\\\", \\\"{x:547,y:726,t:1526418523900};\\\", \\\"{x:545,y:727,t:1526418523990};\\\", \\\"{x:544,y:728,t:1526418524001};\\\", \\\"{x:541,y:731,t:1526418524018};\\\", \\\"{x:540,y:732,t:1526418524034};\\\", \\\"{x:539,y:733,t:1526418524127};\\\", \\\"{x:538,y:733,t:1526418524573};\\\" ] }, { \\\"rt\\\": 10605, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 432213, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:733,t:1526418527062};\\\", \\\"{x:542,y:716,t:1526418528086};\\\", \\\"{x:546,y:714,t:1526418528105};\\\", \\\"{x:560,y:711,t:1526418528121};\\\", \\\"{x:573,y:709,t:1526418528137};\\\", \\\"{x:599,y:705,t:1526418528154};\\\", \\\"{x:628,y:703,t:1526418528171};\\\", \\\"{x:659,y:703,t:1526418528188};\\\", \\\"{x:697,y:703,t:1526418528204};\\\", \\\"{x:741,y:703,t:1526418528221};\\\", \\\"{x:803,y:703,t:1526418528237};\\\", \\\"{x:833,y:703,t:1526418528254};\\\", \\\"{x:865,y:703,t:1526418528271};\\\", \\\"{x:887,y:703,t:1526418528288};\\\", \\\"{x:903,y:703,t:1526418528303};\\\", \\\"{x:925,y:703,t:1526418528321};\\\", \\\"{x:950,y:699,t:1526418528338};\\\", \\\"{x:973,y:695,t:1526418528354};\\\", \\\"{x:993,y:690,t:1526418528371};\\\", \\\"{x:1022,y:679,t:1526418528388};\\\", \\\"{x:1046,y:665,t:1526418528404};\\\", \\\"{x:1067,y:647,t:1526418528421};\\\", \\\"{x:1086,y:627,t:1526418528437};\\\", \\\"{x:1101,y:613,t:1526418528454};\\\", \\\"{x:1119,y:599,t:1526418528471};\\\", \\\"{x:1135,y:588,t:1526418528488};\\\", \\\"{x:1147,y:578,t:1526418528504};\\\", \\\"{x:1152,y:571,t:1526418528521};\\\", \\\"{x:1155,y:566,t:1526418528538};\\\", \\\"{x:1155,y:563,t:1526418528555};\\\", \\\"{x:1155,y:561,t:1526418528571};\\\", \\\"{x:1155,y:559,t:1526418528588};\\\", \\\"{x:1155,y:558,t:1526418528605};\\\", \\\"{x:1156,y:557,t:1526418528847};\\\", \\\"{x:1157,y:557,t:1526418528855};\\\", \\\"{x:1163,y:557,t:1526418528871};\\\", \\\"{x:1170,y:557,t:1526418528888};\\\", \\\"{x:1178,y:557,t:1526418528905};\\\", \\\"{x:1188,y:557,t:1526418528922};\\\", \\\"{x:1202,y:557,t:1526418528939};\\\", \\\"{x:1214,y:559,t:1526418528955};\\\", \\\"{x:1223,y:560,t:1526418528971};\\\", \\\"{x:1230,y:561,t:1526418528989};\\\", \\\"{x:1234,y:561,t:1526418529006};\\\", \\\"{x:1238,y:561,t:1526418529022};\\\", \\\"{x:1240,y:561,t:1526418529039};\\\", \\\"{x:1243,y:563,t:1526418529087};\\\", \\\"{x:1244,y:563,t:1526418529094};\\\", \\\"{x:1247,y:564,t:1526418529106};\\\", \\\"{x:1252,y:567,t:1526418529123};\\\", \\\"{x:1257,y:567,t:1526418529139};\\\", \\\"{x:1261,y:568,t:1526418529155};\\\", \\\"{x:1262,y:569,t:1526418529172};\\\", \\\"{x:1263,y:569,t:1526418529190};\\\", \\\"{x:1265,y:569,t:1526418529206};\\\", \\\"{x:1271,y:570,t:1526418529223};\\\", \\\"{x:1272,y:571,t:1526418529238};\\\", \\\"{x:1274,y:571,t:1526418529311};\\\", \\\"{x:1275,y:571,t:1526418529335};\\\", \\\"{x:1277,y:571,t:1526418529365};\\\", \\\"{x:1279,y:571,t:1526418529374};\\\", \\\"{x:1282,y:571,t:1526418529388};\\\", \\\"{x:1291,y:571,t:1526418529405};\\\", \\\"{x:1313,y:571,t:1526418529422};\\\", \\\"{x:1323,y:571,t:1526418529438};\\\", \\\"{x:1328,y:571,t:1526418529455};\\\", \\\"{x:1331,y:571,t:1526418529472};\\\", \\\"{x:1334,y:571,t:1526418529488};\\\", \\\"{x:1343,y:571,t:1526418529505};\\\", \\\"{x:1355,y:571,t:1526418529522};\\\", \\\"{x:1362,y:571,t:1526418529539};\\\", \\\"{x:1368,y:570,t:1526418529555};\\\", \\\"{x:1369,y:570,t:1526418529572};\\\", \\\"{x:1370,y:570,t:1526418529757};\\\", \\\"{x:1374,y:570,t:1526418529772};\\\", \\\"{x:1393,y:570,t:1526418529789};\\\", \\\"{x:1425,y:570,t:1526418529805};\\\", \\\"{x:1456,y:570,t:1526418529822};\\\", \\\"{x:1477,y:566,t:1526418529839};\\\", \\\"{x:1488,y:565,t:1526418529856};\\\", \\\"{x:1490,y:564,t:1526418529872};\\\", \\\"{x:1489,y:564,t:1526418529941};\\\", \\\"{x:1487,y:564,t:1526418529955};\\\", \\\"{x:1473,y:561,t:1526418529972};\\\", \\\"{x:1449,y:558,t:1526418529989};\\\", \\\"{x:1427,y:558,t:1526418530005};\\\", \\\"{x:1425,y:558,t:1526418530229};\\\", \\\"{x:1424,y:558,t:1526418530239};\\\", \\\"{x:1421,y:560,t:1526418530256};\\\", \\\"{x:1420,y:561,t:1526418530272};\\\", \\\"{x:1419,y:563,t:1526418530290};\\\", \\\"{x:1418,y:564,t:1526418530306};\\\", \\\"{x:1417,y:564,t:1526418530334};\\\", \\\"{x:1416,y:564,t:1526418530358};\\\", \\\"{x:1413,y:565,t:1526418533646};\\\", \\\"{x:1410,y:567,t:1526418533658};\\\", \\\"{x:1396,y:569,t:1526418533675};\\\", \\\"{x:1376,y:571,t:1526418533693};\\\", \\\"{x:1354,y:573,t:1526418533708};\\\", \\\"{x:1328,y:577,t:1526418533726};\\\", \\\"{x:1282,y:580,t:1526418533741};\\\", \\\"{x:1242,y:585,t:1526418533758};\\\", \\\"{x:1206,y:591,t:1526418533775};\\\", \\\"{x:1181,y:595,t:1526418533793};\\\", \\\"{x:1154,y:596,t:1526418533808};\\\", \\\"{x:1123,y:598,t:1526418533825};\\\", \\\"{x:1089,y:599,t:1526418533842};\\\", \\\"{x:1044,y:599,t:1526418533858};\\\", \\\"{x:1005,y:599,t:1526418533875};\\\", \\\"{x:970,y:599,t:1526418533893};\\\", \\\"{x:941,y:601,t:1526418533910};\\\", \\\"{x:913,y:601,t:1526418533925};\\\", \\\"{x:872,y:601,t:1526418533942};\\\", \\\"{x:850,y:605,t:1526418533960};\\\", \\\"{x:827,y:607,t:1526418533976};\\\", \\\"{x:806,y:608,t:1526418533992};\\\", \\\"{x:786,y:608,t:1526418534009};\\\", \\\"{x:768,y:608,t:1526418534026};\\\", \\\"{x:754,y:609,t:1526418534042};\\\", \\\"{x:739,y:609,t:1526418534059};\\\", \\\"{x:725,y:609,t:1526418534076};\\\", \\\"{x:715,y:608,t:1526418534093};\\\", \\\"{x:703,y:601,t:1526418534109};\\\", \\\"{x:700,y:596,t:1526418534125};\\\", \\\"{x:695,y:588,t:1526418534143};\\\", \\\"{x:689,y:581,t:1526418534160};\\\", \\\"{x:684,y:575,t:1526418534176};\\\", \\\"{x:680,y:570,t:1526418534193};\\\", \\\"{x:678,y:567,t:1526418534209};\\\", \\\"{x:674,y:560,t:1526418534227};\\\", \\\"{x:664,y:546,t:1526418534242};\\\", \\\"{x:658,y:531,t:1526418534259};\\\", \\\"{x:654,y:521,t:1526418534277};\\\", \\\"{x:650,y:517,t:1526418534293};\\\", \\\"{x:650,y:514,t:1526418534309};\\\", \\\"{x:646,y:511,t:1526418534325};\\\", \\\"{x:645,y:510,t:1526418534342};\\\", \\\"{x:643,y:508,t:1526418534359};\\\", \\\"{x:640,y:505,t:1526418534377};\\\", \\\"{x:636,y:502,t:1526418534393};\\\", \\\"{x:635,y:502,t:1526418534410};\\\", \\\"{x:634,y:502,t:1526418534427};\\\", \\\"{x:632,y:502,t:1526418534686};\\\", \\\"{x:640,y:502,t:1526418534702};\\\", \\\"{x:656,y:507,t:1526418534710};\\\", \\\"{x:681,y:512,t:1526418534726};\\\", \\\"{x:710,y:522,t:1526418534744};\\\", \\\"{x:746,y:531,t:1526418534760};\\\", \\\"{x:773,y:538,t:1526418534776};\\\", \\\"{x:792,y:543,t:1526418534793};\\\", \\\"{x:799,y:546,t:1526418534810};\\\", \\\"{x:802,y:547,t:1526418534826};\\\", \\\"{x:804,y:548,t:1526418534844};\\\", \\\"{x:805,y:550,t:1526418534860};\\\", \\\"{x:805,y:551,t:1526418534942};\\\", \\\"{x:805,y:552,t:1526418534960};\\\", \\\"{x:805,y:554,t:1526418534976};\\\", \\\"{x:805,y:555,t:1526418534993};\\\", \\\"{x:805,y:557,t:1526418535031};\\\", \\\"{x:805,y:559,t:1526418535044};\\\", \\\"{x:808,y:563,t:1526418535061};\\\", \\\"{x:812,y:564,t:1526418535076};\\\", \\\"{x:816,y:564,t:1526418535093};\\\", \\\"{x:827,y:555,t:1526418535111};\\\", \\\"{x:834,y:549,t:1526418535126};\\\", \\\"{x:839,y:544,t:1526418535143};\\\", \\\"{x:842,y:540,t:1526418535160};\\\", \\\"{x:844,y:537,t:1526418535177};\\\", \\\"{x:846,y:536,t:1526418535193};\\\", \\\"{x:842,y:537,t:1526418535485};\\\", \\\"{x:838,y:541,t:1526418535494};\\\", \\\"{x:829,y:549,t:1526418535509};\\\", \\\"{x:816,y:563,t:1526418535528};\\\", \\\"{x:799,y:576,t:1526418535544};\\\", \\\"{x:783,y:592,t:1526418535560};\\\", \\\"{x:765,y:606,t:1526418535577};\\\", \\\"{x:748,y:624,t:1526418535593};\\\", \\\"{x:728,y:646,t:1526418535611};\\\", \\\"{x:700,y:669,t:1526418535627};\\\", \\\"{x:676,y:688,t:1526418535643};\\\", \\\"{x:655,y:698,t:1526418535660};\\\", \\\"{x:642,y:704,t:1526418535677};\\\", \\\"{x:622,y:710,t:1526418535693};\\\", \\\"{x:616,y:710,t:1526418535711};\\\", \\\"{x:612,y:710,t:1526418535727};\\\", \\\"{x:609,y:710,t:1526418535744};\\\", \\\"{x:605,y:710,t:1526418535760};\\\", \\\"{x:604,y:710,t:1526418535821};\\\", \\\"{x:601,y:710,t:1526418535838};\\\", \\\"{x:596,y:712,t:1526418535845};\\\", \\\"{x:589,y:718,t:1526418535860};\\\", \\\"{x:565,y:743,t:1526418535877};\\\", \\\"{x:550,y:755,t:1526418535894};\\\", \\\"{x:540,y:756,t:1526418535910};\\\", \\\"{x:534,y:757,t:1526418535927};\\\", \\\"{x:531,y:757,t:1526418535944};\\\", \\\"{x:529,y:757,t:1526418535961};\\\", \\\"{x:528,y:757,t:1526418535977};\\\", \\\"{x:527,y:757,t:1526418535997};\\\", \\\"{x:526,y:757,t:1526418536022};\\\", \\\"{x:525,y:757,t:1526418536030};\\\", \\\"{x:524,y:755,t:1526418536061};\\\", \\\"{x:523,y:753,t:1526418536078};\\\", \\\"{x:521,y:750,t:1526418536094};\\\", \\\"{x:521,y:748,t:1526418536111};\\\", \\\"{x:519,y:746,t:1526418536127};\\\", \\\"{x:519,y:745,t:1526418536145};\\\", \\\"{x:519,y:744,t:1526418536161};\\\", \\\"{x:519,y:743,t:1526418536177};\\\", \\\"{x:518,y:742,t:1526418536194};\\\" ] }, { \\\"rt\\\": 31523, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 465087, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:740,t:1526418548678};\\\", \\\"{x:523,y:738,t:1526418548685};\\\", \\\"{x:540,y:735,t:1526418548702};\\\", \\\"{x:581,y:731,t:1526418548719};\\\", \\\"{x:673,y:726,t:1526418548736};\\\", \\\"{x:777,y:717,t:1526418548751};\\\", \\\"{x:833,y:709,t:1526418548772};\\\", \\\"{x:836,y:708,t:1526418548788};\\\", \\\"{x:838,y:707,t:1526418548886};\\\", \\\"{x:842,y:707,t:1526418548893};\\\", \\\"{x:847,y:704,t:1526418548905};\\\", \\\"{x:849,y:703,t:1526418548922};\\\", \\\"{x:850,y:701,t:1526418548939};\\\", \\\"{x:850,y:700,t:1526418548955};\\\", \\\"{x:850,y:699,t:1526418548972};\\\", \\\"{x:850,y:698,t:1526418548989};\\\", \\\"{x:849,y:697,t:1526418549004};\\\", \\\"{x:849,y:689,t:1526418549022};\\\", \\\"{x:857,y:677,t:1526418549039};\\\", \\\"{x:877,y:661,t:1526418549055};\\\", \\\"{x:906,y:645,t:1526418549072};\\\", \\\"{x:942,y:635,t:1526418549088};\\\", \\\"{x:975,y:627,t:1526418549105};\\\", \\\"{x:1023,y:619,t:1526418549122};\\\", \\\"{x:1075,y:614,t:1526418549139};\\\", \\\"{x:1118,y:607,t:1526418549154};\\\", \\\"{x:1140,y:602,t:1526418549172};\\\", \\\"{x:1154,y:598,t:1526418549189};\\\", \\\"{x:1164,y:594,t:1526418549205};\\\", \\\"{x:1170,y:593,t:1526418549222};\\\", \\\"{x:1171,y:593,t:1526418549301};\\\", \\\"{x:1174,y:595,t:1526418549309};\\\", \\\"{x:1175,y:598,t:1526418549322};\\\", \\\"{x:1177,y:603,t:1526418549339};\\\", \\\"{x:1179,y:609,t:1526418549356};\\\", \\\"{x:1180,y:613,t:1526418549372};\\\", \\\"{x:1180,y:618,t:1526418549389};\\\", \\\"{x:1180,y:628,t:1526418549405};\\\", \\\"{x:1180,y:631,t:1526418549423};\\\", \\\"{x:1180,y:633,t:1526418549439};\\\", \\\"{x:1180,y:634,t:1526418549501};\\\", \\\"{x:1180,y:636,t:1526418549558};\\\", \\\"{x:1180,y:637,t:1526418549573};\\\", \\\"{x:1181,y:639,t:1526418549589};\\\", \\\"{x:1182,y:642,t:1526418549606};\\\", \\\"{x:1184,y:646,t:1526418549623};\\\", \\\"{x:1187,y:653,t:1526418549639};\\\", \\\"{x:1191,y:664,t:1526418549656};\\\", \\\"{x:1197,y:678,t:1526418549673};\\\", \\\"{x:1203,y:687,t:1526418549689};\\\", \\\"{x:1206,y:693,t:1526418549706};\\\", \\\"{x:1209,y:698,t:1526418549723};\\\", \\\"{x:1212,y:701,t:1526418549739};\\\", \\\"{x:1215,y:705,t:1526418549755};\\\", \\\"{x:1216,y:706,t:1526418549772};\\\", \\\"{x:1216,y:704,t:1526418549966};\\\", \\\"{x:1217,y:702,t:1526418549974};\\\", \\\"{x:1217,y:700,t:1526418549989};\\\", \\\"{x:1217,y:699,t:1526418550006};\\\", \\\"{x:1217,y:698,t:1526418550478};\\\", \\\"{x:1218,y:698,t:1526418550549};\\\", \\\"{x:1218,y:696,t:1526418550606};\\\", \\\"{x:1218,y:695,t:1526418550614};\\\", \\\"{x:1220,y:694,t:1526418556174};\\\", \\\"{x:1230,y:694,t:1526418556182};\\\", \\\"{x:1236,y:694,t:1526418556196};\\\", \\\"{x:1257,y:694,t:1526418556213};\\\", \\\"{x:1286,y:695,t:1526418556229};\\\", \\\"{x:1296,y:695,t:1526418556246};\\\", \\\"{x:1300,y:695,t:1526418556263};\\\", \\\"{x:1304,y:695,t:1526418556279};\\\", \\\"{x:1311,y:696,t:1526418556296};\\\", \\\"{x:1316,y:697,t:1526418556313};\\\", \\\"{x:1318,y:697,t:1526418556329};\\\", \\\"{x:1319,y:697,t:1526418556438};\\\", \\\"{x:1321,y:697,t:1526418556533};\\\", \\\"{x:1322,y:697,t:1526418556547};\\\", \\\"{x:1346,y:701,t:1526418556564};\\\", \\\"{x:1377,y:706,t:1526418556581};\\\", \\\"{x:1408,y:708,t:1526418556596};\\\", \\\"{x:1439,y:708,t:1526418556614};\\\", \\\"{x:1443,y:708,t:1526418556629};\\\", \\\"{x:1444,y:708,t:1526418556646};\\\", \\\"{x:1443,y:708,t:1526418556694};\\\", \\\"{x:1440,y:708,t:1526418556702};\\\", \\\"{x:1434,y:708,t:1526418556713};\\\", \\\"{x:1415,y:708,t:1526418556730};\\\", \\\"{x:1396,y:708,t:1526418556747};\\\", \\\"{x:1382,y:708,t:1526418556763};\\\", \\\"{x:1368,y:705,t:1526418556781};\\\", \\\"{x:1359,y:704,t:1526418556796};\\\", \\\"{x:1358,y:704,t:1526418556814};\\\", \\\"{x:1356,y:704,t:1526418557086};\\\", \\\"{x:1355,y:703,t:1526418557111};\\\", \\\"{x:1354,y:702,t:1526418557118};\\\", \\\"{x:1353,y:701,t:1526418557134};\\\", \\\"{x:1352,y:700,t:1526418557151};\\\", \\\"{x:1351,y:699,t:1526418557164};\\\", \\\"{x:1351,y:698,t:1526418557182};\\\", \\\"{x:1350,y:698,t:1526418557198};\\\", \\\"{x:1347,y:698,t:1526418561773};\\\", \\\"{x:1341,y:698,t:1526418561786};\\\", \\\"{x:1292,y:698,t:1526418561801};\\\", \\\"{x:1211,y:696,t:1526418561818};\\\", \\\"{x:1114,y:696,t:1526418561836};\\\", \\\"{x:1028,y:696,t:1526418561852};\\\", \\\"{x:922,y:696,t:1526418561868};\\\", \\\"{x:747,y:678,t:1526418561885};\\\", \\\"{x:669,y:667,t:1526418561901};\\\", \\\"{x:646,y:663,t:1526418561918};\\\", \\\"{x:630,y:657,t:1526418561935};\\\", \\\"{x:617,y:652,t:1526418561951};\\\", \\\"{x:607,y:647,t:1526418561969};\\\", \\\"{x:603,y:645,t:1526418561985};\\\", \\\"{x:598,y:643,t:1526418562003};\\\", \\\"{x:578,y:635,t:1526418562018};\\\", \\\"{x:534,y:626,t:1526418562036};\\\", \\\"{x:500,y:626,t:1526418562052};\\\", \\\"{x:483,y:626,t:1526418562068};\\\", \\\"{x:471,y:625,t:1526418562083};\\\", \\\"{x:459,y:620,t:1526418562099};\\\", \\\"{x:449,y:616,t:1526418562116};\\\", \\\"{x:444,y:613,t:1526418562132};\\\", \\\"{x:440,y:611,t:1526418562149};\\\", \\\"{x:440,y:610,t:1526418562167};\\\", \\\"{x:440,y:609,t:1526418562182};\\\", \\\"{x:440,y:606,t:1526418562200};\\\", \\\"{x:442,y:602,t:1526418562216};\\\", \\\"{x:442,y:598,t:1526418562233};\\\", \\\"{x:443,y:593,t:1526418562250};\\\", \\\"{x:446,y:588,t:1526418562266};\\\", \\\"{x:446,y:587,t:1526418562282};\\\", \\\"{x:446,y:586,t:1526418562300};\\\", \\\"{x:446,y:585,t:1526418562317};\\\", \\\"{x:446,y:584,t:1526418562332};\\\", \\\"{x:445,y:581,t:1526418562349};\\\", \\\"{x:441,y:581,t:1526418562367};\\\", \\\"{x:431,y:579,t:1526418562383};\\\", \\\"{x:418,y:577,t:1526418562399};\\\", \\\"{x:406,y:575,t:1526418562417};\\\", \\\"{x:399,y:573,t:1526418562433};\\\", \\\"{x:395,y:571,t:1526418562450};\\\", \\\"{x:394,y:570,t:1526418562466};\\\", \\\"{x:392,y:569,t:1526418562484};\\\", \\\"{x:392,y:567,t:1526418562501};\\\", \\\"{x:392,y:563,t:1526418562516};\\\", \\\"{x:390,y:559,t:1526418562533};\\\", \\\"{x:389,y:556,t:1526418562550};\\\", \\\"{x:389,y:555,t:1526418562566};\\\", \\\"{x:389,y:553,t:1526418562597};\\\", \\\"{x:388,y:549,t:1526418562605};\\\", \\\"{x:387,y:547,t:1526418562617};\\\", \\\"{x:386,y:544,t:1526418562633};\\\", \\\"{x:385,y:542,t:1526418562649};\\\", \\\"{x:385,y:541,t:1526418562677};\\\", \\\"{x:384,y:541,t:1526418562693};\\\", \\\"{x:383,y:540,t:1526418562701};\\\", \\\"{x:382,y:540,t:1526418562716};\\\", \\\"{x:377,y:540,t:1526418562733};\\\", \\\"{x:371,y:540,t:1526418562750};\\\", \\\"{x:357,y:548,t:1526418562766};\\\", \\\"{x:346,y:554,t:1526418562783};\\\", \\\"{x:329,y:560,t:1526418562800};\\\", \\\"{x:311,y:563,t:1526418562816};\\\", \\\"{x:297,y:563,t:1526418562833};\\\", \\\"{x:279,y:563,t:1526418562850};\\\", \\\"{x:258,y:563,t:1526418562867};\\\", \\\"{x:248,y:563,t:1526418562883};\\\", \\\"{x:244,y:564,t:1526418562900};\\\", \\\"{x:243,y:564,t:1526418562917};\\\", \\\"{x:242,y:564,t:1526418562934};\\\", \\\"{x:241,y:564,t:1526418562964};\\\", \\\"{x:239,y:565,t:1526418562973};\\\", \\\"{x:238,y:566,t:1526418562983};\\\", \\\"{x:237,y:572,t:1526418563000};\\\", \\\"{x:230,y:583,t:1526418563016};\\\", \\\"{x:228,y:587,t:1526418563034};\\\", \\\"{x:225,y:589,t:1526418563049};\\\", \\\"{x:222,y:591,t:1526418563066};\\\", \\\"{x:220,y:592,t:1526418563083};\\\", \\\"{x:214,y:596,t:1526418563100};\\\", \\\"{x:205,y:604,t:1526418563117};\\\", \\\"{x:196,y:617,t:1526418563133};\\\", \\\"{x:193,y:622,t:1526418563150};\\\", \\\"{x:192,y:623,t:1526418563167};\\\", \\\"{x:190,y:623,t:1526418563184};\\\", \\\"{x:188,y:622,t:1526418563201};\\\", \\\"{x:186,y:619,t:1526418563218};\\\", \\\"{x:185,y:613,t:1526418563233};\\\", \\\"{x:182,y:600,t:1526418563251};\\\", \\\"{x:181,y:586,t:1526418563268};\\\", \\\"{x:179,y:570,t:1526418563283};\\\", \\\"{x:179,y:558,t:1526418563300};\\\", \\\"{x:179,y:545,t:1526418563317};\\\", \\\"{x:179,y:543,t:1526418563333};\\\", \\\"{x:178,y:541,t:1526418563350};\\\", \\\"{x:177,y:541,t:1526418563373};\\\", \\\"{x:178,y:541,t:1526418563805};\\\", \\\"{x:180,y:541,t:1526418563817};\\\", \\\"{x:185,y:540,t:1526418563835};\\\", \\\"{x:201,y:537,t:1526418563851};\\\", \\\"{x:220,y:537,t:1526418563867};\\\", \\\"{x:244,y:536,t:1526418563885};\\\", \\\"{x:276,y:536,t:1526418563901};\\\", \\\"{x:323,y:536,t:1526418563917};\\\", \\\"{x:349,y:536,t:1526418563934};\\\", \\\"{x:374,y:537,t:1526418563950};\\\", \\\"{x:395,y:539,t:1526418563967};\\\", \\\"{x:413,y:543,t:1526418563984};\\\", \\\"{x:428,y:546,t:1526418564002};\\\", \\\"{x:439,y:549,t:1526418564017};\\\", \\\"{x:453,y:551,t:1526418564034};\\\", \\\"{x:469,y:553,t:1526418564051};\\\", \\\"{x:490,y:557,t:1526418564068};\\\", \\\"{x:510,y:559,t:1526418564085};\\\", \\\"{x:538,y:564,t:1526418564102};\\\", \\\"{x:559,y:567,t:1526418564117};\\\", \\\"{x:577,y:569,t:1526418564134};\\\", \\\"{x:593,y:570,t:1526418564151};\\\", \\\"{x:609,y:571,t:1526418564168};\\\", \\\"{x:623,y:573,t:1526418564185};\\\", \\\"{x:630,y:573,t:1526418564202};\\\", \\\"{x:633,y:573,t:1526418564217};\\\", \\\"{x:634,y:573,t:1526418564261};\\\", \\\"{x:636,y:574,t:1526418564293};\\\", \\\"{x:637,y:575,t:1526418564317};\\\", \\\"{x:639,y:576,t:1526418564325};\\\", \\\"{x:640,y:578,t:1526418564334};\\\", \\\"{x:641,y:578,t:1526418564351};\\\", \\\"{x:642,y:579,t:1526418564368};\\\", \\\"{x:643,y:580,t:1526418564385};\\\", \\\"{x:643,y:581,t:1526418564405};\\\", \\\"{x:646,y:581,t:1526418564477};\\\", \\\"{x:647,y:581,t:1526418564493};\\\", \\\"{x:648,y:581,t:1526418564565};\\\", \\\"{x:649,y:580,t:1526418564638};\\\", \\\"{x:650,y:579,t:1526418564652};\\\", \\\"{x:650,y:573,t:1526418564669};\\\", \\\"{x:652,y:563,t:1526418564685};\\\", \\\"{x:659,y:545,t:1526418564702};\\\", \\\"{x:670,y:534,t:1526418564719};\\\", \\\"{x:688,y:523,t:1526418564735};\\\", \\\"{x:704,y:515,t:1526418564752};\\\", \\\"{x:720,y:509,t:1526418564768};\\\", \\\"{x:742,y:504,t:1526418564785};\\\", \\\"{x:770,y:501,t:1526418564801};\\\", \\\"{x:792,y:498,t:1526418564819};\\\", \\\"{x:801,y:496,t:1526418564836};\\\", \\\"{x:804,y:495,t:1526418564851};\\\", \\\"{x:806,y:495,t:1526418565462};\\\", \\\"{x:807,y:495,t:1526418565493};\\\", \\\"{x:808,y:495,t:1526418565501};\\\", \\\"{x:809,y:495,t:1526418565518};\\\", \\\"{x:810,y:495,t:1526418565536};\\\", \\\"{x:811,y:495,t:1526418565614};\\\", \\\"{x:812,y:495,t:1526418565654};\\\", \\\"{x:815,y:495,t:1526418565669};\\\", \\\"{x:816,y:496,t:1526418565685};\\\", \\\"{x:820,y:497,t:1526418565701};\\\", \\\"{x:823,y:500,t:1526418565719};\\\", \\\"{x:825,y:501,t:1526418565735};\\\", \\\"{x:826,y:502,t:1526418565752};\\\", \\\"{x:826,y:503,t:1526418565769};\\\", \\\"{x:827,y:503,t:1526418565786};\\\", \\\"{x:828,y:503,t:1526418565803};\\\", \\\"{x:832,y:503,t:1526418565820};\\\", \\\"{x:835,y:503,t:1526418565836};\\\", \\\"{x:838,y:502,t:1526418565853};\\\", \\\"{x:840,y:501,t:1526418565870};\\\", \\\"{x:841,y:501,t:1526418566198};\\\", \\\"{x:837,y:508,t:1526418566206};\\\", \\\"{x:829,y:518,t:1526418566221};\\\", \\\"{x:804,y:550,t:1526418566238};\\\", \\\"{x:770,y:584,t:1526418566254};\\\", \\\"{x:710,y:638,t:1526418566270};\\\", \\\"{x:668,y:678,t:1526418566286};\\\", \\\"{x:624,y:731,t:1526418566303};\\\", \\\"{x:592,y:771,t:1526418566320};\\\", \\\"{x:575,y:789,t:1526418566336};\\\", \\\"{x:561,y:799,t:1526418566353};\\\", \\\"{x:549,y:802,t:1526418566370};\\\", \\\"{x:543,y:804,t:1526418566386};\\\", \\\"{x:540,y:806,t:1526418566403};\\\", \\\"{x:539,y:806,t:1526418566420};\\\", \\\"{x:537,y:807,t:1526418566436};\\\", \\\"{x:528,y:810,t:1526418566454};\\\", \\\"{x:503,y:817,t:1526418566470};\\\", \\\"{x:483,y:822,t:1526418566486};\\\", \\\"{x:470,y:826,t:1526418566503};\\\", \\\"{x:463,y:826,t:1526418566519};\\\", \\\"{x:459,y:811,t:1526418566536};\\\", \\\"{x:459,y:794,t:1526418566552};\\\", \\\"{x:463,y:780,t:1526418566568};\\\", \\\"{x:467,y:772,t:1526418566585};\\\", \\\"{x:471,y:765,t:1526418566602};\\\", \\\"{x:476,y:759,t:1526418566618};\\\", \\\"{x:481,y:753,t:1526418566636};\\\", \\\"{x:484,y:750,t:1526418566652};\\\", \\\"{x:484,y:747,t:1526418566669};\\\" ] }, { \\\"rt\\\": 50124, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 516472, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:486,y:744,t:1526418573373};\\\", \\\"{x:488,y:740,t:1526418573388};\\\", \\\"{x:490,y:739,t:1526418573405};\\\", \\\"{x:494,y:738,t:1526418574332};\\\", \\\"{x:504,y:737,t:1526418574340};\\\", \\\"{x:516,y:736,t:1526418574353};\\\", \\\"{x:541,y:734,t:1526418574369};\\\", \\\"{x:569,y:731,t:1526418574387};\\\", \\\"{x:605,y:730,t:1526418574403};\\\", \\\"{x:672,y:726,t:1526418574426};\\\", \\\"{x:705,y:726,t:1526418574442};\\\", \\\"{x:738,y:726,t:1526418574458};\\\", \\\"{x:774,y:726,t:1526418574475};\\\", \\\"{x:821,y:726,t:1526418574493};\\\", \\\"{x:855,y:724,t:1526418574509};\\\", \\\"{x:885,y:724,t:1526418574526};\\\", \\\"{x:915,y:718,t:1526418574543};\\\", \\\"{x:944,y:717,t:1526418574560};\\\", \\\"{x:970,y:714,t:1526418574575};\\\", \\\"{x:990,y:711,t:1526418574593};\\\", \\\"{x:1018,y:706,t:1526418574610};\\\", \\\"{x:1039,y:701,t:1526418574625};\\\", \\\"{x:1062,y:696,t:1526418574642};\\\", \\\"{x:1080,y:692,t:1526418574660};\\\", \\\"{x:1092,y:689,t:1526418574676};\\\", \\\"{x:1110,y:684,t:1526418574693};\\\", \\\"{x:1121,y:681,t:1526418574709};\\\", \\\"{x:1128,y:677,t:1526418574726};\\\", \\\"{x:1135,y:673,t:1526418574743};\\\", \\\"{x:1144,y:668,t:1526418574760};\\\", \\\"{x:1152,y:666,t:1526418574776};\\\", \\\"{x:1161,y:662,t:1526418574793};\\\", \\\"{x:1172,y:659,t:1526418574809};\\\", \\\"{x:1181,y:655,t:1526418574826};\\\", \\\"{x:1192,y:649,t:1526418574843};\\\", \\\"{x:1200,y:644,t:1526418574860};\\\", \\\"{x:1204,y:641,t:1526418574876};\\\", \\\"{x:1216,y:634,t:1526418574893};\\\", \\\"{x:1225,y:627,t:1526418574910};\\\", \\\"{x:1229,y:625,t:1526418574926};\\\", \\\"{x:1232,y:622,t:1526418574943};\\\", \\\"{x:1236,y:619,t:1526418574960};\\\", \\\"{x:1240,y:616,t:1526418574977};\\\", \\\"{x:1241,y:616,t:1526418574993};\\\", \\\"{x:1247,y:615,t:1526418575284};\\\", \\\"{x:1259,y:611,t:1526418575292};\\\", \\\"{x:1271,y:611,t:1526418575310};\\\", \\\"{x:1272,y:611,t:1526418575326};\\\", \\\"{x:1272,y:610,t:1526418575429};\\\", \\\"{x:1272,y:607,t:1526418575444};\\\", \\\"{x:1272,y:598,t:1526418575460};\\\", \\\"{x:1266,y:585,t:1526418575477};\\\", \\\"{x:1263,y:578,t:1526418575494};\\\", \\\"{x:1262,y:574,t:1526418575509};\\\", \\\"{x:1259,y:565,t:1526418575527};\\\", \\\"{x:1257,y:556,t:1526418575544};\\\", \\\"{x:1255,y:548,t:1526418575560};\\\", \\\"{x:1255,y:544,t:1526418575576};\\\", \\\"{x:1254,y:541,t:1526418575594};\\\", \\\"{x:1254,y:539,t:1526418575610};\\\", \\\"{x:1254,y:537,t:1526418575627};\\\", \\\"{x:1254,y:536,t:1526418575645};\\\", \\\"{x:1254,y:535,t:1526418575661};\\\", \\\"{x:1254,y:534,t:1526418575676};\\\", \\\"{x:1254,y:532,t:1526418575694};\\\", \\\"{x:1254,y:530,t:1526418575710};\\\", \\\"{x:1255,y:528,t:1526418575727};\\\", \\\"{x:1255,y:527,t:1526418575749};\\\", \\\"{x:1256,y:527,t:1526418575760};\\\", \\\"{x:1256,y:526,t:1526418575777};\\\", \\\"{x:1256,y:525,t:1526418575793};\\\", \\\"{x:1258,y:524,t:1526418575810};\\\", \\\"{x:1258,y:523,t:1526418575837};\\\", \\\"{x:1258,y:522,t:1526418575845};\\\", \\\"{x:1259,y:522,t:1526418575860};\\\", \\\"{x:1259,y:520,t:1526418575877};\\\", \\\"{x:1260,y:520,t:1526418575894};\\\", \\\"{x:1261,y:519,t:1526418575910};\\\", \\\"{x:1262,y:519,t:1526418575928};\\\", \\\"{x:1264,y:517,t:1526418575944};\\\", \\\"{x:1265,y:517,t:1526418575961};\\\", \\\"{x:1266,y:517,t:1526418575977};\\\", \\\"{x:1267,y:517,t:1526418575994};\\\", \\\"{x:1270,y:515,t:1526418576493};\\\", \\\"{x:1274,y:514,t:1526418576501};\\\", \\\"{x:1277,y:514,t:1526418576510};\\\", \\\"{x:1284,y:511,t:1526418576528};\\\", \\\"{x:1288,y:510,t:1526418576544};\\\", \\\"{x:1291,y:510,t:1526418576561};\\\", \\\"{x:1291,y:509,t:1526418576578};\\\", \\\"{x:1293,y:508,t:1526418576594};\\\", \\\"{x:1294,y:507,t:1526418576611};\\\", \\\"{x:1295,y:506,t:1526418576797};\\\", \\\"{x:1296,y:506,t:1526418576811};\\\", \\\"{x:1297,y:505,t:1526418576828};\\\", \\\"{x:1299,y:503,t:1526418576845};\\\", \\\"{x:1302,y:501,t:1526418576860};\\\", \\\"{x:1305,y:499,t:1526418576877};\\\", \\\"{x:1307,y:498,t:1526418576895};\\\", \\\"{x:1309,y:497,t:1526418576911};\\\", \\\"{x:1310,y:497,t:1526418576981};\\\", \\\"{x:1310,y:498,t:1526418577479};\\\", \\\"{x:1307,y:505,t:1526418577495};\\\", \\\"{x:1305,y:514,t:1526418577513};\\\", \\\"{x:1302,y:526,t:1526418577529};\\\", \\\"{x:1301,y:533,t:1526418577546};\\\", \\\"{x:1298,y:541,t:1526418577562};\\\", \\\"{x:1298,y:547,t:1526418577579};\\\", \\\"{x:1297,y:550,t:1526418577596};\\\", \\\"{x:1297,y:551,t:1526418577646};\\\", \\\"{x:1297,y:552,t:1526418577662};\\\", \\\"{x:1296,y:553,t:1526418577679};\\\", \\\"{x:1296,y:554,t:1526418577885};\\\", \\\"{x:1296,y:555,t:1526418577895};\\\", \\\"{x:1294,y:556,t:1526418577912};\\\", \\\"{x:1293,y:556,t:1526418577941};\\\", \\\"{x:1292,y:557,t:1526418577965};\\\", \\\"{x:1291,y:557,t:1526418578005};\\\", \\\"{x:1290,y:558,t:1526418578037};\\\", \\\"{x:1289,y:559,t:1526418578061};\\\", \\\"{x:1273,y:553,t:1526418606681};\\\", \\\"{x:1250,y:546,t:1526418606688};\\\", \\\"{x:1211,y:541,t:1526418606704};\\\", \\\"{x:1168,y:541,t:1526418606719};\\\", \\\"{x:1154,y:538,t:1526418606737};\\\", \\\"{x:1140,y:538,t:1526418606753};\\\", \\\"{x:1111,y:538,t:1526418606769};\\\", \\\"{x:1053,y:538,t:1526418606787};\\\", \\\"{x:1011,y:538,t:1526418606804};\\\", \\\"{x:981,y:538,t:1526418606820};\\\", \\\"{x:934,y:536,t:1526418606837};\\\", \\\"{x:865,y:530,t:1526418606854};\\\", \\\"{x:799,y:528,t:1526418606874};\\\", \\\"{x:792,y:528,t:1526418606891};\\\", \\\"{x:788,y:528,t:1526418606907};\\\", \\\"{x:785,y:527,t:1526418606924};\\\", \\\"{x:775,y:525,t:1526418606941};\\\", \\\"{x:739,y:520,t:1526418606957};\\\", \\\"{x:672,y:520,t:1526418606974};\\\", \\\"{x:633,y:520,t:1526418606991};\\\", \\\"{x:611,y:520,t:1526418607007};\\\", \\\"{x:607,y:519,t:1526418607024};\\\", \\\"{x:606,y:519,t:1526418607055};\\\", \\\"{x:604,y:518,t:1526418607064};\\\", \\\"{x:600,y:517,t:1526418607080};\\\", \\\"{x:597,y:516,t:1526418607090};\\\", \\\"{x:594,y:516,t:1526418607107};\\\", \\\"{x:593,y:516,t:1526418607124};\\\", \\\"{x:593,y:515,t:1526418607192};\\\", \\\"{x:593,y:510,t:1526418607208};\\\", \\\"{x:593,y:509,t:1526418607223};\\\", \\\"{x:593,y:508,t:1526418607241};\\\", \\\"{x:598,y:508,t:1526418607681};\\\", \\\"{x:601,y:508,t:1526418607692};\\\", \\\"{x:602,y:508,t:1526418607708};\\\", \\\"{x:605,y:508,t:1526418607725};\\\", \\\"{x:609,y:508,t:1526418607741};\\\", \\\"{x:613,y:508,t:1526418607758};\\\", \\\"{x:616,y:508,t:1526418607775};\\\", \\\"{x:617,y:508,t:1526418607792};\\\", \\\"{x:618,y:508,t:1526418607808};\\\", \\\"{x:619,y:508,t:1526418607936};\\\", \\\"{x:620,y:507,t:1526418607968};\\\", \\\"{x:620,y:506,t:1526418608200};\\\", \\\"{x:619,y:506,t:1526418608208};\\\", \\\"{x:618,y:505,t:1526418608225};\\\", \\\"{x:617,y:505,t:1526418608242};\\\", \\\"{x:616,y:505,t:1526418608279};\\\", \\\"{x:615,y:505,t:1526418608304};\\\", \\\"{x:628,y:505,t:1526418608826};\\\", \\\"{x:740,y:544,t:1526418608843};\\\", \\\"{x:863,y:593,t:1526418608860};\\\", \\\"{x:973,y:619,t:1526418608877};\\\", \\\"{x:1081,y:648,t:1526418608892};\\\", \\\"{x:1194,y:681,t:1526418608909};\\\", \\\"{x:1319,y:719,t:1526418608926};\\\", \\\"{x:1430,y:754,t:1526418608942};\\\", \\\"{x:1536,y:784,t:1526418608959};\\\", \\\"{x:1658,y:823,t:1526418608976};\\\", \\\"{x:1696,y:837,t:1526418608993};\\\", \\\"{x:1714,y:847,t:1526418609009};\\\", \\\"{x:1722,y:852,t:1526418609026};\\\", \\\"{x:1735,y:857,t:1526418609044};\\\", \\\"{x:1742,y:860,t:1526418609060};\\\", \\\"{x:1743,y:861,t:1526418609076};\\\", \\\"{x:1742,y:861,t:1526418609121};\\\", \\\"{x:1733,y:861,t:1526418609129};\\\", \\\"{x:1720,y:858,t:1526418609143};\\\", \\\"{x:1698,y:852,t:1526418609159};\\\", \\\"{x:1659,y:840,t:1526418609176};\\\", \\\"{x:1640,y:835,t:1526418609193};\\\", \\\"{x:1613,y:830,t:1526418609210};\\\", \\\"{x:1591,y:828,t:1526418609227};\\\", \\\"{x:1560,y:824,t:1526418609243};\\\", \\\"{x:1518,y:821,t:1526418609259};\\\", \\\"{x:1463,y:815,t:1526418609276};\\\", \\\"{x:1407,y:808,t:1526418609293};\\\", \\\"{x:1357,y:808,t:1526418609309};\\\", \\\"{x:1311,y:806,t:1526418609326};\\\", \\\"{x:1273,y:804,t:1526418609343};\\\", \\\"{x:1248,y:804,t:1526418609359};\\\", \\\"{x:1232,y:804,t:1526418609376};\\\", \\\"{x:1224,y:804,t:1526418609392};\\\", \\\"{x:1216,y:804,t:1526418609410};\\\", \\\"{x:1207,y:804,t:1526418609426};\\\", \\\"{x:1204,y:804,t:1526418609443};\\\", \\\"{x:1202,y:804,t:1526418609505};\\\", \\\"{x:1201,y:804,t:1526418609512};\\\", \\\"{x:1200,y:802,t:1526418609526};\\\", \\\"{x:1200,y:799,t:1526418609543};\\\", \\\"{x:1201,y:790,t:1526418609560};\\\", \\\"{x:1203,y:782,t:1526418609576};\\\", \\\"{x:1206,y:774,t:1526418609593};\\\", \\\"{x:1208,y:766,t:1526418609610};\\\", \\\"{x:1209,y:761,t:1526418609626};\\\", \\\"{x:1209,y:762,t:1526418610161};\\\", \\\"{x:1209,y:765,t:1526418610177};\\\", \\\"{x:1209,y:771,t:1526418610194};\\\", \\\"{x:1209,y:779,t:1526418610211};\\\", \\\"{x:1209,y:786,t:1526418610228};\\\", \\\"{x:1209,y:789,t:1526418610244};\\\", \\\"{x:1209,y:792,t:1526418610260};\\\", \\\"{x:1209,y:796,t:1526418610277};\\\", \\\"{x:1210,y:803,t:1526418610294};\\\", \\\"{x:1212,y:808,t:1526418610310};\\\", \\\"{x:1212,y:811,t:1526418610327};\\\", \\\"{x:1213,y:814,t:1526418610344};\\\", \\\"{x:1213,y:815,t:1526418610360};\\\", \\\"{x:1213,y:816,t:1526418610377};\\\", \\\"{x:1214,y:818,t:1526418610394};\\\", \\\"{x:1214,y:819,t:1526418610410};\\\", \\\"{x:1214,y:820,t:1526418610473};\\\", \\\"{x:1213,y:820,t:1526418616240};\\\", \\\"{x:1203,y:819,t:1526418616248};\\\", \\\"{x:1145,y:797,t:1526418616266};\\\", \\\"{x:1085,y:771,t:1526418616281};\\\", \\\"{x:1041,y:762,t:1526418616298};\\\", \\\"{x:1004,y:755,t:1526418616315};\\\", \\\"{x:973,y:751,t:1526418616331};\\\", \\\"{x:949,y:748,t:1526418616348};\\\", \\\"{x:929,y:745,t:1526418616365};\\\", \\\"{x:912,y:743,t:1526418616382};\\\", \\\"{x:895,y:740,t:1526418616398};\\\", \\\"{x:885,y:738,t:1526418616415};\\\", \\\"{x:879,y:737,t:1526418616431};\\\", \\\"{x:875,y:737,t:1526418616448};\\\", \\\"{x:873,y:737,t:1526418616465};\\\", \\\"{x:872,y:737,t:1526418616482};\\\", \\\"{x:866,y:735,t:1526418616498};\\\", \\\"{x:855,y:735,t:1526418616515};\\\", \\\"{x:846,y:735,t:1526418616532};\\\", \\\"{x:837,y:735,t:1526418616548};\\\", \\\"{x:823,y:735,t:1526418616565};\\\", \\\"{x:800,y:735,t:1526418616582};\\\", \\\"{x:774,y:735,t:1526418616598};\\\", \\\"{x:749,y:735,t:1526418616615};\\\", \\\"{x:704,y:735,t:1526418616632};\\\", \\\"{x:661,y:738,t:1526418616648};\\\", \\\"{x:616,y:742,t:1526418616665};\\\", \\\"{x:590,y:746,t:1526418616682};\\\", \\\"{x:573,y:746,t:1526418616698};\\\", \\\"{x:563,y:746,t:1526418616716};\\\", \\\"{x:558,y:746,t:1526418616732};\\\", \\\"{x:555,y:746,t:1526418616748};\\\", \\\"{x:554,y:746,t:1526418616764};\\\", \\\"{x:553,y:747,t:1526418616823};\\\", \\\"{x:551,y:748,t:1526418616839};\\\", \\\"{x:550,y:748,t:1526418616847};\\\", \\\"{x:541,y:751,t:1526418616865};\\\", \\\"{x:532,y:752,t:1526418616881};\\\", \\\"{x:524,y:753,t:1526418616898};\\\", \\\"{x:517,y:754,t:1526418616915};\\\", \\\"{x:510,y:756,t:1526418616932};\\\", \\\"{x:506,y:756,t:1526418616948};\\\", \\\"{x:507,y:754,t:1526418617258};\\\", \\\"{x:508,y:753,t:1526418617267};\\\", \\\"{x:510,y:752,t:1526418617282};\\\", \\\"{x:515,y:749,t:1526418617299};\\\", \\\"{x:518,y:745,t:1526418617316};\\\", \\\"{x:522,y:744,t:1526418617334};\\\", \\\"{x:526,y:741,t:1526418617349};\\\", \\\"{x:527,y:741,t:1526418618081};\\\", \\\"{x:528,y:741,t:1526418618088};\\\", \\\"{x:529,y:741,t:1526418618200};\\\", \\\"{x:530,y:741,t:1526418619120};\\\", \\\"{x:531,y:741,t:1526418619134};\\\", \\\"{x:532,y:741,t:1526418619151};\\\", \\\"{x:533,y:742,t:1526418619184};\\\" ] }, { \\\"rt\\\": 37455, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 555189, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:742,t:1526418628913};\\\", \\\"{x:573,y:742,t:1526418628936};\\\", \\\"{x:611,y:742,t:1526418628951};\\\", \\\"{x:709,y:742,t:1526418628975};\\\", \\\"{x:789,y:742,t:1526418628993};\\\", \\\"{x:861,y:742,t:1526418629010};\\\", \\\"{x:953,y:742,t:1526418629026};\\\", \\\"{x:1045,y:742,t:1526418629043};\\\", \\\"{x:1128,y:742,t:1526418629060};\\\", \\\"{x:1195,y:742,t:1526418629076};\\\", \\\"{x:1245,y:742,t:1526418629092};\\\", \\\"{x:1277,y:742,t:1526418629109};\\\", \\\"{x:1299,y:740,t:1526418629125};\\\", \\\"{x:1317,y:736,t:1526418629143};\\\", \\\"{x:1321,y:735,t:1526418629160};\\\", \\\"{x:1322,y:735,t:1526418629185};\\\", \\\"{x:1323,y:735,t:1526418629208};\\\", \\\"{x:1323,y:734,t:1526418629216};\\\", \\\"{x:1324,y:734,t:1526418629226};\\\", \\\"{x:1327,y:731,t:1526418629242};\\\", \\\"{x:1330,y:728,t:1526418629260};\\\", \\\"{x:1334,y:725,t:1526418629277};\\\", \\\"{x:1338,y:723,t:1526418629294};\\\", \\\"{x:1341,y:721,t:1526418629310};\\\", \\\"{x:1348,y:715,t:1526418629326};\\\", \\\"{x:1355,y:709,t:1526418629343};\\\", \\\"{x:1363,y:702,t:1526418629360};\\\", \\\"{x:1365,y:701,t:1526418629377};\\\", \\\"{x:1365,y:700,t:1526418629393};\\\", \\\"{x:1366,y:699,t:1526418629416};\\\", \\\"{x:1366,y:697,t:1526418629427};\\\", \\\"{x:1369,y:695,t:1526418629444};\\\", \\\"{x:1370,y:693,t:1526418629465};\\\", \\\"{x:1370,y:692,t:1526418629480};\\\", \\\"{x:1371,y:690,t:1526418629497};\\\", \\\"{x:1371,y:689,t:1526418629528};\\\", \\\"{x:1368,y:692,t:1526418630944};\\\", \\\"{x:1365,y:698,t:1526418630962};\\\", \\\"{x:1362,y:705,t:1526418630978};\\\", \\\"{x:1359,y:712,t:1526418630995};\\\", \\\"{x:1356,y:718,t:1526418631012};\\\", \\\"{x:1353,y:726,t:1526418631028};\\\", \\\"{x:1350,y:732,t:1526418631045};\\\", \\\"{x:1350,y:739,t:1526418631062};\\\", \\\"{x:1346,y:748,t:1526418631078};\\\", \\\"{x:1345,y:754,t:1526418631094};\\\", \\\"{x:1345,y:758,t:1526418631112};\\\", \\\"{x:1345,y:760,t:1526418631200};\\\", \\\"{x:1346,y:760,t:1526418635200};\\\", \\\"{x:1354,y:760,t:1526418635216};\\\", \\\"{x:1370,y:759,t:1526418635232};\\\", \\\"{x:1394,y:759,t:1526418635249};\\\", \\\"{x:1420,y:759,t:1526418635266};\\\", \\\"{x:1443,y:759,t:1526418635282};\\\", \\\"{x:1461,y:758,t:1526418635300};\\\", \\\"{x:1472,y:758,t:1526418635316};\\\", \\\"{x:1479,y:758,t:1526418635333};\\\", \\\"{x:1484,y:758,t:1526418635349};\\\", \\\"{x:1488,y:758,t:1526418635366};\\\", \\\"{x:1491,y:758,t:1526418635439};\\\", \\\"{x:1494,y:758,t:1526418635449};\\\", \\\"{x:1504,y:758,t:1526418635466};\\\", \\\"{x:1511,y:758,t:1526418635483};\\\", \\\"{x:1516,y:758,t:1526418635499};\\\", \\\"{x:1520,y:758,t:1526418635516};\\\", \\\"{x:1520,y:757,t:1526418635533};\\\", \\\"{x:1524,y:757,t:1526418635549};\\\", \\\"{x:1525,y:757,t:1526418635566};\\\", \\\"{x:1529,y:758,t:1526418635583};\\\", \\\"{x:1530,y:758,t:1526418635599};\\\", \\\"{x:1532,y:758,t:1526418635664};\\\", \\\"{x:1533,y:758,t:1526418635672};\\\", \\\"{x:1535,y:758,t:1526418635683};\\\", \\\"{x:1537,y:758,t:1526418635700};\\\", \\\"{x:1540,y:758,t:1526418635716};\\\", \\\"{x:1541,y:758,t:1526418635733};\\\", \\\"{x:1543,y:758,t:1526418635750};\\\", \\\"{x:1545,y:758,t:1526418635766};\\\", \\\"{x:1546,y:758,t:1526418635783};\\\", \\\"{x:1548,y:758,t:1526418635831};\\\", \\\"{x:1549,y:758,t:1526418635848};\\\", \\\"{x:1551,y:758,t:1526418635888};\\\", \\\"{x:1552,y:758,t:1526418635927};\\\", \\\"{x:1554,y:758,t:1526418635960};\\\", \\\"{x:1554,y:759,t:1526418637608};\\\", \\\"{x:1554,y:760,t:1526418637648};\\\", \\\"{x:1554,y:761,t:1526418637664};\\\", \\\"{x:1554,y:762,t:1526418637672};\\\", \\\"{x:1554,y:763,t:1526418637688};\\\", \\\"{x:1547,y:763,t:1526418655940};\\\", \\\"{x:1509,y:763,t:1526418655958};\\\", \\\"{x:1422,y:759,t:1526418655975};\\\", \\\"{x:1327,y:759,t:1526418655991};\\\", \\\"{x:1216,y:759,t:1526418656008};\\\", \\\"{x:1095,y:742,t:1526418656025};\\\", \\\"{x:958,y:715,t:1526418656042};\\\", \\\"{x:831,y:683,t:1526418656058};\\\", \\\"{x:739,y:656,t:1526418656074};\\\", \\\"{x:639,y:624,t:1526418656093};\\\", \\\"{x:577,y:603,t:1526418656108};\\\", \\\"{x:540,y:590,t:1526418656126};\\\", \\\"{x:520,y:583,t:1526418656153};\\\", \\\"{x:516,y:580,t:1526418656168};\\\", \\\"{x:514,y:580,t:1526418656185};\\\", \\\"{x:512,y:579,t:1526418656202};\\\", \\\"{x:511,y:579,t:1526418656219};\\\", \\\"{x:510,y:579,t:1526418656275};\\\", \\\"{x:509,y:578,t:1526418656285};\\\", \\\"{x:508,y:578,t:1526418656331};\\\", \\\"{x:503,y:578,t:1526418656338};\\\", \\\"{x:495,y:580,t:1526418656353};\\\", \\\"{x:475,y:589,t:1526418656369};\\\", \\\"{x:455,y:597,t:1526418656387};\\\", \\\"{x:434,y:606,t:1526418656403};\\\", \\\"{x:413,y:610,t:1526418656418};\\\", \\\"{x:397,y:612,t:1526418656436};\\\", \\\"{x:387,y:615,t:1526418656452};\\\", \\\"{x:381,y:620,t:1526418656470};\\\", \\\"{x:378,y:625,t:1526418656486};\\\", \\\"{x:378,y:628,t:1526418656502};\\\", \\\"{x:377,y:627,t:1526418656612};\\\", \\\"{x:377,y:624,t:1526418656619};\\\", \\\"{x:375,y:619,t:1526418656637};\\\", \\\"{x:375,y:611,t:1526418656652};\\\", \\\"{x:373,y:603,t:1526418656670};\\\", \\\"{x:368,y:589,t:1526418656687};\\\", \\\"{x:363,y:574,t:1526418656702};\\\", \\\"{x:360,y:561,t:1526418656719};\\\", \\\"{x:360,y:552,t:1526418656737};\\\", \\\"{x:360,y:547,t:1526418656752};\\\", \\\"{x:360,y:545,t:1526418656770};\\\", \\\"{x:360,y:542,t:1526418656786};\\\", \\\"{x:355,y:541,t:1526418656884};\\\", \\\"{x:341,y:541,t:1526418656891};\\\", \\\"{x:328,y:541,t:1526418656903};\\\", \\\"{x:274,y:546,t:1526418656920};\\\", \\\"{x:229,y:553,t:1526418656937};\\\", \\\"{x:203,y:555,t:1526418656953};\\\", \\\"{x:191,y:555,t:1526418656969};\\\", \\\"{x:184,y:555,t:1526418656986};\\\", \\\"{x:179,y:551,t:1526418657003};\\\", \\\"{x:178,y:549,t:1526418657020};\\\", \\\"{x:178,y:548,t:1526418657037};\\\", \\\"{x:178,y:547,t:1526418657066};\\\", \\\"{x:178,y:546,t:1526418657091};\\\", \\\"{x:178,y:544,t:1526418657104};\\\", \\\"{x:178,y:543,t:1526418657119};\\\", \\\"{x:178,y:542,t:1526418657147};\\\", \\\"{x:178,y:541,t:1526418657163};\\\", \\\"{x:178,y:540,t:1526418657171};\\\", \\\"{x:179,y:538,t:1526418657186};\\\", \\\"{x:179,y:530,t:1526418657202};\\\", \\\"{x:179,y:526,t:1526418657219};\\\", \\\"{x:179,y:523,t:1526418657237};\\\", \\\"{x:179,y:522,t:1526418657253};\\\", \\\"{x:179,y:520,t:1526418657347};\\\", \\\"{x:179,y:519,t:1526418657371};\\\", \\\"{x:179,y:518,t:1526418657386};\\\", \\\"{x:181,y:512,t:1526418657404};\\\", \\\"{x:181,y:509,t:1526418657419};\\\", \\\"{x:181,y:508,t:1526418657443};\\\", \\\"{x:181,y:507,t:1526418657491};\\\", \\\"{x:181,y:505,t:1526418658116};\\\", \\\"{x:187,y:512,t:1526418658132};\\\", \\\"{x:199,y:521,t:1526418658141};\\\", \\\"{x:215,y:531,t:1526418658155};\\\", \\\"{x:252,y:559,t:1526418658171};\\\", \\\"{x:337,y:637,t:1526418658188};\\\", \\\"{x:393,y:698,t:1526418658204};\\\", \\\"{x:456,y:750,t:1526418658221};\\\", \\\"{x:501,y:784,t:1526418658238};\\\", \\\"{x:527,y:802,t:1526418658254};\\\", \\\"{x:540,y:813,t:1526418658270};\\\", \\\"{x:545,y:817,t:1526418658288};\\\", \\\"{x:551,y:825,t:1526418658304};\\\", \\\"{x:553,y:828,t:1526418658321};\\\", \\\"{x:553,y:829,t:1526418658338};\\\", \\\"{x:552,y:829,t:1526418658428};\\\", \\\"{x:550,y:828,t:1526418658439};\\\", \\\"{x:543,y:816,t:1526418658455};\\\", \\\"{x:533,y:800,t:1526418658472};\\\", \\\"{x:522,y:784,t:1526418658489};\\\", \\\"{x:514,y:775,t:1526418658505};\\\", \\\"{x:508,y:770,t:1526418658522};\\\", \\\"{x:504,y:766,t:1526418658539};\\\", \\\"{x:501,y:761,t:1526418658556};\\\", \\\"{x:496,y:753,t:1526418658573};\\\", \\\"{x:492,y:747,t:1526418658588};\\\", \\\"{x:489,y:740,t:1526418658604};\\\", \\\"{x:487,y:738,t:1526418658621};\\\", \\\"{x:485,y:736,t:1526418658639};\\\", \\\"{x:485,y:735,t:1526418658654};\\\", \\\"{x:485,y:736,t:1526418658860};\\\", \\\"{x:485,y:738,t:1526418658873};\\\", \\\"{x:486,y:739,t:1526418658889};\\\" ] }, { \\\"rt\\\": 71759, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 628193, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -04 PM-04 PM-Z -04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:742,t:1526418662212};\\\", \\\"{x:525,y:747,t:1526418662228};\\\", \\\"{x:619,y:757,t:1526418662245};\\\", \\\"{x:755,y:778,t:1526418662259};\\\", \\\"{x:920,y:798,t:1526418662276};\\\", \\\"{x:1089,y:822,t:1526418662291};\\\", \\\"{x:1266,y:849,t:1526418662308};\\\", \\\"{x:1449,y:851,t:1526418662324};\\\", \\\"{x:1637,y:851,t:1526418662340};\\\", \\\"{x:1789,y:853,t:1526418662358};\\\", \\\"{x:1892,y:855,t:1526418662374};\\\", \\\"{x:1919,y:855,t:1526418662390};\\\", \\\"{x:1919,y:853,t:1526418662410};\\\", \\\"{x:1915,y:845,t:1526418662460};\\\", \\\"{x:1890,y:821,t:1526418662475};\\\", \\\"{x:1837,y:776,t:1526418662491};\\\", \\\"{x:1765,y:729,t:1526418662507};\\\", \\\"{x:1711,y:700,t:1526418662525};\\\", \\\"{x:1641,y:677,t:1526418662541};\\\", \\\"{x:1553,y:658,t:1526418662558};\\\", \\\"{x:1499,y:639,t:1526418662575};\\\", \\\"{x:1466,y:637,t:1526418662590};\\\", \\\"{x:1445,y:637,t:1526418662608};\\\", \\\"{x:1435,y:637,t:1526418662625};\\\", \\\"{x:1424,y:639,t:1526418662640};\\\", \\\"{x:1420,y:640,t:1526418662657};\\\", \\\"{x:1408,y:650,t:1526418662675};\\\", \\\"{x:1396,y:665,t:1526418662691};\\\", \\\"{x:1384,y:678,t:1526418662708};\\\", \\\"{x:1369,y:686,t:1526418662724};\\\", \\\"{x:1359,y:691,t:1526418662740};\\\", \\\"{x:1356,y:693,t:1526418662758};\\\", \\\"{x:1354,y:694,t:1526418662775};\\\", \\\"{x:1354,y:695,t:1526418662795};\\\", \\\"{x:1353,y:695,t:1526418663151};\\\", \\\"{x:1352,y:695,t:1526418663179};\\\", \\\"{x:1351,y:697,t:1526418663194};\\\", \\\"{x:1350,y:697,t:1526418663219};\\\", \\\"{x:1349,y:697,t:1526418663243};\\\", \\\"{x:1348,y:698,t:1526418667604};\\\", \\\"{x:1352,y:707,t:1526418667613};\\\", \\\"{x:1390,y:744,t:1526418667628};\\\", \\\"{x:1454,y:802,t:1526418667644};\\\", \\\"{x:1531,y:871,t:1526418667661};\\\", \\\"{x:1592,y:923,t:1526418667678};\\\", \\\"{x:1642,y:967,t:1526418667693};\\\", \\\"{x:1679,y:996,t:1526418667710};\\\", \\\"{x:1694,y:1020,t:1526418667728};\\\", \\\"{x:1714,y:1040,t:1526418667744};\\\", \\\"{x:1729,y:1051,t:1526418667761};\\\", \\\"{x:1728,y:1049,t:1526418667828};\\\", \\\"{x:1719,y:1037,t:1526418667845};\\\", \\\"{x:1707,y:1024,t:1526418667862};\\\", \\\"{x:1687,y:1009,t:1526418667878};\\\", \\\"{x:1657,y:991,t:1526418667895};\\\", \\\"{x:1641,y:985,t:1526418667911};\\\", \\\"{x:1638,y:984,t:1526418667928};\\\", \\\"{x:1636,y:984,t:1526418667956};\\\", \\\"{x:1634,y:982,t:1526418667972};\\\", \\\"{x:1633,y:981,t:1526418667988};\\\", \\\"{x:1632,y:981,t:1526418668124};\\\", \\\"{x:1631,y:979,t:1526418668132};\\\", \\\"{x:1628,y:977,t:1526418668144};\\\", \\\"{x:1627,y:976,t:1526418668163};\\\", \\\"{x:1626,y:976,t:1526418668187};\\\", \\\"{x:1626,y:975,t:1526418668212};\\\", \\\"{x:1625,y:975,t:1526418668228};\\\", \\\"{x:1622,y:974,t:1526418668246};\\\", \\\"{x:1621,y:974,t:1526418668262};\\\", \\\"{x:1619,y:973,t:1526418668308};\\\", \\\"{x:1619,y:972,t:1526418668315};\\\", \\\"{x:1617,y:971,t:1526418668329};\\\", \\\"{x:1616,y:971,t:1526418668345};\\\", \\\"{x:1615,y:971,t:1526418668360};\\\", \\\"{x:1615,y:970,t:1526418668378};\\\", \\\"{x:1615,y:969,t:1526418668516};\\\", \\\"{x:1614,y:968,t:1526418668529};\\\", \\\"{x:1614,y:966,t:1526418668546};\\\", \\\"{x:1614,y:964,t:1526418668561};\\\", \\\"{x:1614,y:960,t:1526418668579};\\\", \\\"{x:1613,y:954,t:1526418668595};\\\", \\\"{x:1612,y:951,t:1526418668612};\\\", \\\"{x:1612,y:949,t:1526418668629};\\\", \\\"{x:1612,y:945,t:1526418668645};\\\", \\\"{x:1612,y:942,t:1526418668662};\\\", \\\"{x:1612,y:938,t:1526418668678};\\\", \\\"{x:1612,y:933,t:1526418668695};\\\", \\\"{x:1612,y:928,t:1526418668710};\\\", \\\"{x:1611,y:924,t:1526418668728};\\\", \\\"{x:1611,y:923,t:1526418668745};\\\", \\\"{x:1609,y:920,t:1526418668762};\\\", \\\"{x:1609,y:917,t:1526418668778};\\\", \\\"{x:1609,y:912,t:1526418668795};\\\", \\\"{x:1609,y:909,t:1526418668812};\\\", \\\"{x:1609,y:906,t:1526418668828};\\\", \\\"{x:1609,y:903,t:1526418668845};\\\", \\\"{x:1609,y:899,t:1526418668862};\\\", \\\"{x:1609,y:895,t:1526418668879};\\\", \\\"{x:1609,y:891,t:1526418668896};\\\", \\\"{x:1609,y:888,t:1526418668913};\\\", \\\"{x:1609,y:884,t:1526418668928};\\\", \\\"{x:1609,y:881,t:1526418668946};\\\", \\\"{x:1609,y:877,t:1526418668963};\\\", \\\"{x:1609,y:874,t:1526418668979};\\\", \\\"{x:1609,y:869,t:1526418668995};\\\", \\\"{x:1609,y:865,t:1526418669013};\\\", \\\"{x:1609,y:861,t:1526418669029};\\\", \\\"{x:1609,y:856,t:1526418669046};\\\", \\\"{x:1609,y:851,t:1526418669062};\\\", \\\"{x:1609,y:847,t:1526418669078};\\\", \\\"{x:1609,y:845,t:1526418669095};\\\", \\\"{x:1609,y:843,t:1526418669112};\\\", \\\"{x:1609,y:837,t:1526418669128};\\\", \\\"{x:1609,y:833,t:1526418669145};\\\", \\\"{x:1609,y:822,t:1526418669195};\\\", \\\"{x:1609,y:820,t:1526418669212};\\\", \\\"{x:1609,y:816,t:1526418669228};\\\", \\\"{x:1609,y:814,t:1526418669244};\\\", \\\"{x:1609,y:812,t:1526418669262};\\\", \\\"{x:1608,y:811,t:1526418669279};\\\", \\\"{x:1608,y:810,t:1526418669295};\\\", \\\"{x:1608,y:809,t:1526418669312};\\\", \\\"{x:1608,y:808,t:1526418669329};\\\", \\\"{x:1608,y:807,t:1526418669345};\\\", \\\"{x:1607,y:805,t:1526418669362};\\\", \\\"{x:1607,y:803,t:1526418669379};\\\", \\\"{x:1607,y:802,t:1526418669395};\\\", \\\"{x:1607,y:799,t:1526418669412};\\\", \\\"{x:1606,y:798,t:1526418669429};\\\", \\\"{x:1605,y:793,t:1526418669445};\\\", \\\"{x:1604,y:790,t:1526418669462};\\\", \\\"{x:1603,y:786,t:1526418669479};\\\", \\\"{x:1602,y:781,t:1526418669495};\\\", \\\"{x:1601,y:777,t:1526418669512};\\\", \\\"{x:1600,y:772,t:1526418669529};\\\", \\\"{x:1598,y:768,t:1526418669545};\\\", \\\"{x:1598,y:764,t:1526418669562};\\\", \\\"{x:1597,y:761,t:1526418669578};\\\", \\\"{x:1597,y:760,t:1526418669610};\\\", \\\"{x:1597,y:758,t:1526418669627};\\\", \\\"{x:1597,y:757,t:1526418669650};\\\", \\\"{x:1597,y:756,t:1526418669662};\\\", \\\"{x:1597,y:755,t:1526418669679};\\\", \\\"{x:1597,y:754,t:1526418669714};\\\", \\\"{x:1597,y:752,t:1526418669746};\\\", \\\"{x:1597,y:751,t:1526418669762};\\\", \\\"{x:1597,y:749,t:1526418669779};\\\", \\\"{x:1598,y:746,t:1526418669824};\\\", \\\"{x:1598,y:745,t:1526418669829};\\\", \\\"{x:1598,y:744,t:1526418670043};\\\", \\\"{x:1598,y:746,t:1526418670058};\\\", \\\"{x:1598,y:754,t:1526418670067};\\\", \\\"{x:1598,y:767,t:1526418670079};\\\", \\\"{x:1598,y:800,t:1526418670096};\\\", \\\"{x:1598,y:833,t:1526418670112};\\\", \\\"{x:1599,y:855,t:1526418670129};\\\", \\\"{x:1600,y:868,t:1526418670146};\\\", \\\"{x:1600,y:878,t:1526418670162};\\\", \\\"{x:1600,y:897,t:1526418670179};\\\", \\\"{x:1600,y:905,t:1526418670196};\\\", \\\"{x:1600,y:911,t:1526418670212};\\\", \\\"{x:1600,y:914,t:1526418670229};\\\", \\\"{x:1600,y:917,t:1526418670246};\\\", \\\"{x:1600,y:919,t:1526418670263};\\\", \\\"{x:1601,y:920,t:1526418670348};\\\", \\\"{x:1601,y:921,t:1526418670362};\\\", \\\"{x:1606,y:923,t:1526418670379};\\\", \\\"{x:1608,y:924,t:1526418670396};\\\", \\\"{x:1611,y:930,t:1526418670413};\\\", \\\"{x:1615,y:939,t:1526418670429};\\\", \\\"{x:1619,y:946,t:1526418670446};\\\", \\\"{x:1621,y:950,t:1526418670463};\\\", \\\"{x:1621,y:951,t:1526418670523};\\\", \\\"{x:1621,y:950,t:1526418670659};\\\", \\\"{x:1621,y:949,t:1526418670675};\\\", \\\"{x:1621,y:948,t:1526418670684};\\\", \\\"{x:1621,y:947,t:1526418670696};\\\", \\\"{x:1621,y:944,t:1526418670714};\\\", \\\"{x:1621,y:942,t:1526418670730};\\\", \\\"{x:1621,y:941,t:1526418670747};\\\", \\\"{x:1620,y:939,t:1526418670764};\\\", \\\"{x:1619,y:937,t:1526418670820};\\\", \\\"{x:1618,y:937,t:1526418670830};\\\", \\\"{x:1618,y:936,t:1526418670846};\\\", \\\"{x:1617,y:934,t:1526418670863};\\\", \\\"{x:1617,y:933,t:1526418670880};\\\", \\\"{x:1615,y:931,t:1526418670896};\\\", \\\"{x:1615,y:928,t:1526418670913};\\\", \\\"{x:1614,y:926,t:1526418670930};\\\", \\\"{x:1614,y:924,t:1526418670946};\\\", \\\"{x:1613,y:919,t:1526418670964};\\\", \\\"{x:1613,y:916,t:1526418670980};\\\", \\\"{x:1613,y:913,t:1526418670997};\\\", \\\"{x:1613,y:911,t:1526418671014};\\\", \\\"{x:1613,y:907,t:1526418671029};\\\", \\\"{x:1613,y:903,t:1526418671047};\\\", \\\"{x:1613,y:899,t:1526418671064};\\\", \\\"{x:1613,y:894,t:1526418671080};\\\", \\\"{x:1615,y:888,t:1526418671096};\\\", \\\"{x:1615,y:885,t:1526418671114};\\\", \\\"{x:1616,y:882,t:1526418671131};\\\", \\\"{x:1616,y:879,t:1526418671147};\\\", \\\"{x:1616,y:876,t:1526418671163};\\\", \\\"{x:1617,y:871,t:1526418671181};\\\", \\\"{x:1618,y:867,t:1526418671197};\\\", \\\"{x:1618,y:864,t:1526418671213};\\\", \\\"{x:1619,y:860,t:1526418671231};\\\", \\\"{x:1619,y:856,t:1526418671247};\\\", \\\"{x:1620,y:853,t:1526418671264};\\\", \\\"{x:1620,y:849,t:1526418671280};\\\", \\\"{x:1621,y:845,t:1526418671297};\\\", \\\"{x:1621,y:839,t:1526418671313};\\\", \\\"{x:1623,y:834,t:1526418671331};\\\", \\\"{x:1623,y:830,t:1526418671347};\\\", \\\"{x:1624,y:823,t:1526418671364};\\\", \\\"{x:1624,y:817,t:1526418671381};\\\", \\\"{x:1625,y:811,t:1526418671396};\\\", \\\"{x:1627,y:804,t:1526418671414};\\\", \\\"{x:1627,y:799,t:1526418671430};\\\", \\\"{x:1627,y:792,t:1526418671446};\\\", \\\"{x:1627,y:784,t:1526418671463};\\\", \\\"{x:1627,y:775,t:1526418671480};\\\", \\\"{x:1627,y:765,t:1526418671496};\\\", \\\"{x:1627,y:757,t:1526418671513};\\\", \\\"{x:1627,y:751,t:1526418671530};\\\", \\\"{x:1627,y:745,t:1526418671546};\\\", \\\"{x:1627,y:736,t:1526418671563};\\\", \\\"{x:1627,y:732,t:1526418671580};\\\", \\\"{x:1627,y:726,t:1526418671597};\\\", \\\"{x:1627,y:724,t:1526418671613};\\\", \\\"{x:1627,y:723,t:1526418671630};\\\", \\\"{x:1627,y:722,t:1526418671648};\\\", \\\"{x:1627,y:721,t:1526418671675};\\\", \\\"{x:1626,y:720,t:1526418671715};\\\", \\\"{x:1626,y:718,t:1526418671748};\\\", \\\"{x:1624,y:714,t:1526418671763};\\\", \\\"{x:1624,y:710,t:1526418671781};\\\", \\\"{x:1622,y:705,t:1526418671798};\\\", \\\"{x:1621,y:703,t:1526418671813};\\\", \\\"{x:1620,y:702,t:1526418671830};\\\", \\\"{x:1619,y:699,t:1526418671847};\\\", \\\"{x:1618,y:698,t:1526418671863};\\\", \\\"{x:1617,y:697,t:1526418671880};\\\", \\\"{x:1616,y:696,t:1526418671898};\\\", \\\"{x:1607,y:701,t:1526418673980};\\\", \\\"{x:1591,y:715,t:1526418673986};\\\", \\\"{x:1580,y:723,t:1526418673999};\\\", \\\"{x:1554,y:748,t:1526418674015};\\\", \\\"{x:1534,y:786,t:1526418674031};\\\", \\\"{x:1523,y:840,t:1526418674048};\\\", \\\"{x:1520,y:930,t:1526418674066};\\\", \\\"{x:1518,y:1011,t:1526418674081};\\\", \\\"{x:1518,y:1078,t:1526418674098};\\\", \\\"{x:1529,y:1136,t:1526418674115};\\\", \\\"{x:1535,y:1157,t:1526418674132};\\\", \\\"{x:1541,y:1171,t:1526418674149};\\\", \\\"{x:1545,y:1177,t:1526418674166};\\\", \\\"{x:1552,y:1177,t:1526418674181};\\\", \\\"{x:1558,y:1177,t:1526418674198};\\\", \\\"{x:1564,y:1174,t:1526418674216};\\\", \\\"{x:1566,y:1172,t:1526418674231};\\\", \\\"{x:1571,y:1167,t:1526418674248};\\\", \\\"{x:1590,y:1147,t:1526418674265};\\\", \\\"{x:1604,y:1128,t:1526418674281};\\\", \\\"{x:1611,y:1113,t:1526418674298};\\\", \\\"{x:1612,y:1101,t:1526418674315};\\\", \\\"{x:1613,y:1097,t:1526418674331};\\\", \\\"{x:1614,y:1097,t:1526418674349};\\\", \\\"{x:1614,y:1095,t:1526418674365};\\\", \\\"{x:1614,y:1091,t:1526418674382};\\\", \\\"{x:1614,y:1087,t:1526418674398};\\\", \\\"{x:1614,y:1082,t:1526418674415};\\\", \\\"{x:1614,y:1072,t:1526418674431};\\\", \\\"{x:1614,y:1065,t:1526418674449};\\\", \\\"{x:1616,y:1051,t:1526418674466};\\\", \\\"{x:1616,y:1043,t:1526418674482};\\\", \\\"{x:1615,y:1033,t:1526418674498};\\\", \\\"{x:1613,y:1026,t:1526418674515};\\\", \\\"{x:1612,y:1024,t:1526418674532};\\\", \\\"{x:1612,y:1023,t:1526418674549};\\\", \\\"{x:1612,y:1022,t:1526418674571};\\\", \\\"{x:1611,y:1022,t:1526418674583};\\\", \\\"{x:1611,y:1019,t:1526418674598};\\\", \\\"{x:1611,y:1016,t:1526418674616};\\\", \\\"{x:1611,y:1012,t:1526418674632};\\\", \\\"{x:1611,y:1007,t:1526418674648};\\\", \\\"{x:1611,y:1001,t:1526418674666};\\\", \\\"{x:1610,y:992,t:1526418674682};\\\", \\\"{x:1610,y:987,t:1526418674698};\\\", \\\"{x:1610,y:986,t:1526418674715};\\\", \\\"{x:1609,y:985,t:1526418674732};\\\", \\\"{x:1609,y:984,t:1526418674770};\\\", \\\"{x:1609,y:982,t:1526418674782};\\\", \\\"{x:1610,y:978,t:1526418674798};\\\", \\\"{x:1611,y:975,t:1526418674815};\\\", \\\"{x:1611,y:974,t:1526418674874};\\\", \\\"{x:1612,y:973,t:1526418674955};\\\", \\\"{x:1613,y:973,t:1526418674970};\\\", \\\"{x:1614,y:973,t:1526418674982};\\\", \\\"{x:1614,y:972,t:1526418674998};\\\", \\\"{x:1615,y:972,t:1526418675015};\\\", \\\"{x:1615,y:971,t:1526418675051};\\\", \\\"{x:1615,y:970,t:1526418675065};\\\", \\\"{x:1615,y:967,t:1526418675083};\\\", \\\"{x:1616,y:967,t:1526418675100};\\\", \\\"{x:1616,y:966,t:1526418675123};\\\", \\\"{x:1618,y:964,t:1526418675139};\\\", \\\"{x:1619,y:961,t:1526418675150};\\\", \\\"{x:1620,y:957,t:1526418675165};\\\", \\\"{x:1620,y:956,t:1526418675182};\\\", \\\"{x:1620,y:957,t:1526418675331};\\\", \\\"{x:1620,y:958,t:1526418675339};\\\", \\\"{x:1619,y:959,t:1526418675468};\\\", \\\"{x:1619,y:961,t:1526418675603};\\\", \\\"{x:1618,y:963,t:1526418675616};\\\", \\\"{x:1616,y:965,t:1526418675633};\\\", \\\"{x:1604,y:965,t:1526418718967};\\\", \\\"{x:1553,y:946,t:1526418718981};\\\", \\\"{x:1423,y:910,t:1526418718996};\\\", \\\"{x:1239,y:864,t:1526418719013};\\\", \\\"{x:972,y:799,t:1526418719031};\\\", \\\"{x:812,y:761,t:1526418719046};\\\", \\\"{x:679,y:723,t:1526418719063};\\\", \\\"{x:571,y:690,t:1526418719080};\\\", \\\"{x:476,y:654,t:1526418719099};\\\", \\\"{x:425,y:630,t:1526418719113};\\\", \\\"{x:382,y:609,t:1526418719130};\\\", \\\"{x:366,y:594,t:1526418719159};\\\", \\\"{x:366,y:590,t:1526418719176};\\\", \\\"{x:366,y:586,t:1526418719192};\\\", \\\"{x:366,y:584,t:1526418719209};\\\", \\\"{x:367,y:583,t:1526418719225};\\\", \\\"{x:367,y:582,t:1526418719242};\\\", \\\"{x:367,y:580,t:1526418719258};\\\", \\\"{x:370,y:579,t:1526418719275};\\\", \\\"{x:375,y:576,t:1526418719293};\\\", \\\"{x:381,y:576,t:1526418719309};\\\", \\\"{x:385,y:576,t:1526418719326};\\\", \\\"{x:387,y:576,t:1526418719343};\\\", \\\"{x:393,y:577,t:1526418719359};\\\", \\\"{x:401,y:578,t:1526418719376};\\\", \\\"{x:408,y:578,t:1526418719392};\\\", \\\"{x:414,y:578,t:1526418719410};\\\", \\\"{x:417,y:578,t:1526418719425};\\\", \\\"{x:422,y:578,t:1526418719443};\\\", \\\"{x:428,y:579,t:1526418719460};\\\", \\\"{x:435,y:581,t:1526418719476};\\\", \\\"{x:443,y:584,t:1526418719493};\\\", \\\"{x:457,y:585,t:1526418719509};\\\", \\\"{x:474,y:585,t:1526418719526};\\\", \\\"{x:501,y:585,t:1526418719544};\\\", \\\"{x:523,y:585,t:1526418719560};\\\", \\\"{x:539,y:585,t:1526418719575};\\\", \\\"{x:548,y:585,t:1526418719593};\\\", \\\"{x:550,y:585,t:1526418719609};\\\", \\\"{x:551,y:584,t:1526418719626};\\\", \\\"{x:553,y:584,t:1526418719685};\\\", \\\"{x:554,y:584,t:1526418719693};\\\", \\\"{x:564,y:583,t:1526418719709};\\\", \\\"{x:569,y:583,t:1526418719725};\\\", \\\"{x:576,y:580,t:1526418719743};\\\", \\\"{x:578,y:580,t:1526418719760};\\\", \\\"{x:579,y:580,t:1526418719777};\\\", \\\"{x:581,y:580,t:1526418719797};\\\", \\\"{x:584,y:580,t:1526418719813};\\\", \\\"{x:587,y:580,t:1526418719827};\\\", \\\"{x:592,y:580,t:1526418719842};\\\", \\\"{x:595,y:581,t:1526418719859};\\\", \\\"{x:598,y:581,t:1526418719877};\\\", \\\"{x:599,y:581,t:1526418719892};\\\", \\\"{x:600,y:581,t:1526418719910};\\\", \\\"{x:600,y:582,t:1526418720182};\\\", \\\"{x:600,y:592,t:1526418720193};\\\", \\\"{x:592,y:616,t:1526418720209};\\\", \\\"{x:589,y:641,t:1526418720227};\\\", \\\"{x:580,y:670,t:1526418720242};\\\", \\\"{x:569,y:696,t:1526418720260};\\\", \\\"{x:560,y:710,t:1526418720277};\\\", \\\"{x:547,y:728,t:1526418720293};\\\", \\\"{x:544,y:731,t:1526418720309};\\\", \\\"{x:543,y:731,t:1526418720326};\\\" ] }, { \\\"rt\\\": 21776, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 651620, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-05 PM-06 PM-07 PM-03 PM-02 PM-01 PM-12 PM-12 PM-B -B -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:565,y:740,t:1526418737206};\\\", \\\"{x:669,y:802,t:1526418737223};\\\", \\\"{x:759,y:848,t:1526418737241};\\\", \\\"{x:860,y:884,t:1526418737258};\\\", \\\"{x:978,y:913,t:1526418737273};\\\", \\\"{x:1105,y:930,t:1526418737291};\\\", \\\"{x:1233,y:949,t:1526418737307};\\\", \\\"{x:1352,y:967,t:1526418737324};\\\", \\\"{x:1465,y:975,t:1526418737340};\\\", \\\"{x:1605,y:981,t:1526418737357};\\\", \\\"{x:1674,y:981,t:1526418737374};\\\", \\\"{x:1733,y:981,t:1526418737390};\\\", \\\"{x:1783,y:981,t:1526418737407};\\\", \\\"{x:1818,y:983,t:1526418737425};\\\", \\\"{x:1829,y:984,t:1526418737441};\\\", \\\"{x:1830,y:984,t:1526418737457};\\\", \\\"{x:1828,y:984,t:1526418737533};\\\", \\\"{x:1820,y:983,t:1526418737541};\\\", \\\"{x:1796,y:977,t:1526418737557};\\\", \\\"{x:1763,y:972,t:1526418737575};\\\", \\\"{x:1735,y:972,t:1526418737590};\\\", \\\"{x:1705,y:972,t:1526418737607};\\\", \\\"{x:1661,y:972,t:1526418737624};\\\", \\\"{x:1620,y:974,t:1526418737640};\\\", \\\"{x:1595,y:977,t:1526418737657};\\\", \\\"{x:1576,y:979,t:1526418737674};\\\", \\\"{x:1554,y:981,t:1526418737690};\\\", \\\"{x:1535,y:981,t:1526418737707};\\\", \\\"{x:1518,y:981,t:1526418737724};\\\", \\\"{x:1492,y:981,t:1526418737740};\\\", \\\"{x:1474,y:981,t:1526418737757};\\\", \\\"{x:1454,y:981,t:1526418737775};\\\", \\\"{x:1443,y:983,t:1526418737791};\\\", \\\"{x:1441,y:983,t:1526418737807};\\\", \\\"{x:1440,y:983,t:1526418737824};\\\", \\\"{x:1438,y:983,t:1526418737842};\\\", \\\"{x:1435,y:983,t:1526418737857};\\\", \\\"{x:1430,y:983,t:1526418737874};\\\", \\\"{x:1421,y:983,t:1526418737891};\\\", \\\"{x:1415,y:983,t:1526418737907};\\\", \\\"{x:1411,y:983,t:1526418737924};\\\", \\\"{x:1400,y:983,t:1526418737941};\\\", \\\"{x:1384,y:983,t:1526418737958};\\\", \\\"{x:1363,y:983,t:1526418737974};\\\", \\\"{x:1353,y:983,t:1526418737991};\\\", \\\"{x:1349,y:983,t:1526418738007};\\\", \\\"{x:1345,y:983,t:1526418738024};\\\", \\\"{x:1343,y:983,t:1526418738041};\\\", \\\"{x:1343,y:982,t:1526418738350};\\\", \\\"{x:1343,y:981,t:1526418738366};\\\", \\\"{x:1343,y:980,t:1526418738390};\\\", \\\"{x:1343,y:979,t:1526418738471};\\\", \\\"{x:1343,y:978,t:1526418738494};\\\", \\\"{x:1343,y:976,t:1526418738534};\\\", \\\"{x:1344,y:976,t:1526418738550};\\\", \\\"{x:1345,y:976,t:1526418738558};\\\", \\\"{x:1348,y:976,t:1526418738576};\\\", \\\"{x:1349,y:976,t:1526418738592};\\\", \\\"{x:1350,y:976,t:1526418738610};\\\", \\\"{x:1351,y:976,t:1526418738951};\\\", \\\"{x:1352,y:976,t:1526418738959};\\\", \\\"{x:1353,y:975,t:1526418742445};\\\", \\\"{x:1353,y:974,t:1526418742461};\\\", \\\"{x:1352,y:968,t:1526418742477};\\\", \\\"{x:1351,y:965,t:1526418742495};\\\", \\\"{x:1351,y:964,t:1526418742511};\\\", \\\"{x:1350,y:963,t:1526418742527};\\\", \\\"{x:1350,y:961,t:1526418743005};\\\", \\\"{x:1350,y:959,t:1526418743013};\\\", \\\"{x:1350,y:957,t:1526418743028};\\\", \\\"{x:1350,y:954,t:1526418743046};\\\", \\\"{x:1350,y:951,t:1526418743062};\\\", \\\"{x:1350,y:949,t:1526418743078};\\\", \\\"{x:1350,y:946,t:1526418743095};\\\", \\\"{x:1348,y:944,t:1526418743112};\\\", \\\"{x:1348,y:943,t:1526418743129};\\\", \\\"{x:1348,y:941,t:1526418743145};\\\", \\\"{x:1348,y:940,t:1526418743161};\\\", \\\"{x:1348,y:938,t:1526418743178};\\\", \\\"{x:1348,y:937,t:1526418743205};\\\", \\\"{x:1348,y:935,t:1526418743229};\\\", \\\"{x:1348,y:934,t:1526418743261};\\\", \\\"{x:1347,y:932,t:1526418743293};\\\", \\\"{x:1347,y:931,t:1526418743405};\\\", \\\"{x:1347,y:929,t:1526418743429};\\\", \\\"{x:1347,y:927,t:1526418743445};\\\", \\\"{x:1346,y:925,t:1526418743461};\\\", \\\"{x:1346,y:924,t:1526418743478};\\\", \\\"{x:1346,y:922,t:1526418743494};\\\", \\\"{x:1345,y:922,t:1526418743512};\\\", \\\"{x:1345,y:921,t:1526418743529};\\\", \\\"{x:1345,y:920,t:1526418743544};\\\", \\\"{x:1345,y:919,t:1526418743562};\\\", \\\"{x:1345,y:918,t:1526418743581};\\\", \\\"{x:1345,y:917,t:1526418743606};\\\", \\\"{x:1345,y:916,t:1526418743613};\\\", \\\"{x:1345,y:915,t:1526418743629};\\\", \\\"{x:1345,y:914,t:1526418743645};\\\", \\\"{x:1345,y:910,t:1526418743661};\\\", \\\"{x:1345,y:909,t:1526418743685};\\\", \\\"{x:1345,y:907,t:1526418743709};\\\", \\\"{x:1345,y:906,t:1526418743749};\\\", \\\"{x:1345,y:904,t:1526418743765};\\\", \\\"{x:1345,y:903,t:1526418743789};\\\", \\\"{x:1345,y:901,t:1526418743854};\\\", \\\"{x:1345,y:900,t:1526418743885};\\\", \\\"{x:1345,y:898,t:1526418743909};\\\", \\\"{x:1345,y:897,t:1526418743925};\\\", \\\"{x:1345,y:895,t:1526418743941};\\\", \\\"{x:1345,y:894,t:1526418743957};\\\", \\\"{x:1345,y:892,t:1526418743973};\\\", \\\"{x:1345,y:891,t:1526418743998};\\\", \\\"{x:1345,y:889,t:1526418744030};\\\", \\\"{x:1345,y:888,t:1526418744045};\\\", \\\"{x:1345,y:886,t:1526418744063};\\\", \\\"{x:1345,y:885,t:1526418744079};\\\", \\\"{x:1345,y:882,t:1526418744096};\\\", \\\"{x:1345,y:879,t:1526418744113};\\\", \\\"{x:1345,y:875,t:1526418744129};\\\", \\\"{x:1345,y:872,t:1526418744146};\\\", \\\"{x:1345,y:868,t:1526418744163};\\\", \\\"{x:1345,y:866,t:1526418744179};\\\", \\\"{x:1345,y:865,t:1526418744195};\\\", \\\"{x:1345,y:862,t:1526418744213};\\\", \\\"{x:1345,y:861,t:1526418744229};\\\", \\\"{x:1345,y:858,t:1526418744246};\\\", \\\"{x:1345,y:856,t:1526418744263};\\\", \\\"{x:1345,y:854,t:1526418744280};\\\", \\\"{x:1345,y:850,t:1526418744296};\\\", \\\"{x:1345,y:847,t:1526418744314};\\\", \\\"{x:1345,y:845,t:1526418744329};\\\", \\\"{x:1345,y:842,t:1526418744346};\\\", \\\"{x:1345,y:839,t:1526418744363};\\\", \\\"{x:1345,y:836,t:1526418744379};\\\", \\\"{x:1345,y:832,t:1526418744397};\\\", \\\"{x:1345,y:826,t:1526418744414};\\\", \\\"{x:1345,y:824,t:1526418744429};\\\", \\\"{x:1346,y:818,t:1526418744447};\\\", \\\"{x:1346,y:816,t:1526418744463};\\\", \\\"{x:1348,y:813,t:1526418744479};\\\", \\\"{x:1348,y:811,t:1526418744496};\\\", \\\"{x:1348,y:808,t:1526418744513};\\\", \\\"{x:1348,y:807,t:1526418744530};\\\", \\\"{x:1348,y:805,t:1526418744546};\\\", \\\"{x:1348,y:804,t:1526418744563};\\\", \\\"{x:1349,y:802,t:1526418744580};\\\", \\\"{x:1349,y:801,t:1526418744596};\\\", \\\"{x:1349,y:799,t:1526418744614};\\\", \\\"{x:1349,y:798,t:1526418744638};\\\", \\\"{x:1349,y:797,t:1526418744654};\\\", \\\"{x:1349,y:796,t:1526418744663};\\\", \\\"{x:1349,y:793,t:1526418744680};\\\", \\\"{x:1349,y:790,t:1526418744696};\\\", \\\"{x:1349,y:788,t:1526418744714};\\\", \\\"{x:1349,y:785,t:1526418744730};\\\", \\\"{x:1349,y:784,t:1526418744747};\\\", \\\"{x:1349,y:782,t:1526418744763};\\\", \\\"{x:1349,y:779,t:1526418744780};\\\", \\\"{x:1349,y:777,t:1526418744797};\\\", \\\"{x:1349,y:775,t:1526418744813};\\\", \\\"{x:1349,y:773,t:1526418744830};\\\", \\\"{x:1349,y:771,t:1526418744846};\\\", \\\"{x:1349,y:770,t:1526418744863};\\\", \\\"{x:1349,y:768,t:1526418744883};\\\", \\\"{x:1349,y:764,t:1526418744897};\\\", \\\"{x:1349,y:761,t:1526418744912};\\\", \\\"{x:1349,y:756,t:1526418744930};\\\", \\\"{x:1349,y:753,t:1526418744945};\\\", \\\"{x:1349,y:749,t:1526418744962};\\\", \\\"{x:1349,y:746,t:1526418744980};\\\", \\\"{x:1349,y:743,t:1526418744997};\\\", \\\"{x:1349,y:740,t:1526418745012};\\\", \\\"{x:1349,y:739,t:1526418745029};\\\", \\\"{x:1349,y:737,t:1526418745047};\\\", \\\"{x:1349,y:736,t:1526418745063};\\\", \\\"{x:1349,y:733,t:1526418745079};\\\", \\\"{x:1349,y:730,t:1526418745097};\\\", \\\"{x:1349,y:728,t:1526418745113};\\\", \\\"{x:1349,y:727,t:1526418745129};\\\", \\\"{x:1348,y:724,t:1526418745147};\\\", \\\"{x:1348,y:721,t:1526418745162};\\\", \\\"{x:1347,y:719,t:1526418745180};\\\", \\\"{x:1347,y:716,t:1526418745197};\\\", \\\"{x:1347,y:713,t:1526418745213};\\\", \\\"{x:1345,y:708,t:1526418745230};\\\", \\\"{x:1345,y:704,t:1526418745247};\\\", \\\"{x:1345,y:703,t:1526418745269};\\\", \\\"{x:1345,y:702,t:1526418745280};\\\", \\\"{x:1345,y:701,t:1526418745297};\\\", \\\"{x:1345,y:700,t:1526418745334};\\\", \\\"{x:1345,y:699,t:1526418745349};\\\", \\\"{x:1344,y:697,t:1526418745362};\\\", \\\"{x:1344,y:696,t:1526418745381};\\\", \\\"{x:1344,y:695,t:1526418745397};\\\", \\\"{x:1344,y:693,t:1526418745412};\\\", \\\"{x:1343,y:692,t:1526418745430};\\\", \\\"{x:1343,y:691,t:1526418745447};\\\", \\\"{x:1341,y:691,t:1526418746182};\\\", \\\"{x:1331,y:691,t:1526418746198};\\\", \\\"{x:1296,y:688,t:1526418746214};\\\", \\\"{x:1271,y:686,t:1526418746232};\\\", \\\"{x:1246,y:685,t:1526418746247};\\\", \\\"{x:1208,y:680,t:1526418746264};\\\", \\\"{x:1160,y:672,t:1526418746281};\\\", \\\"{x:1108,y:667,t:1526418746297};\\\", \\\"{x:1054,y:664,t:1526418746313};\\\", \\\"{x:1004,y:664,t:1526418746331};\\\", \\\"{x:957,y:660,t:1526418746347};\\\", \\\"{x:910,y:654,t:1526418746363};\\\", \\\"{x:848,y:646,t:1526418746380};\\\", \\\"{x:790,y:637,t:1526418746397};\\\", \\\"{x:736,y:631,t:1526418746415};\\\", \\\"{x:708,y:626,t:1526418746431};\\\", \\\"{x:683,y:624,t:1526418746447};\\\", \\\"{x:657,y:620,t:1526418746466};\\\", \\\"{x:634,y:615,t:1526418746482};\\\", \\\"{x:610,y:611,t:1526418746499};\\\", \\\"{x:587,y:607,t:1526418746515};\\\", \\\"{x:566,y:604,t:1526418746532};\\\", \\\"{x:551,y:603,t:1526418746548};\\\", \\\"{x:529,y:602,t:1526418746565};\\\", \\\"{x:499,y:600,t:1526418746582};\\\", \\\"{x:477,y:600,t:1526418746598};\\\", \\\"{x:462,y:600,t:1526418746615};\\\", \\\"{x:460,y:600,t:1526418746632};\\\", \\\"{x:455,y:599,t:1526418746648};\\\", \\\"{x:447,y:598,t:1526418746666};\\\", \\\"{x:432,y:598,t:1526418746683};\\\", \\\"{x:422,y:598,t:1526418746698};\\\", \\\"{x:417,y:599,t:1526418746716};\\\", \\\"{x:415,y:599,t:1526418746733};\\\", \\\"{x:413,y:599,t:1526418746830};\\\", \\\"{x:406,y:599,t:1526418746838};\\\", \\\"{x:394,y:599,t:1526418746850};\\\", \\\"{x:366,y:599,t:1526418746866};\\\", \\\"{x:325,y:599,t:1526418746883};\\\", \\\"{x:283,y:599,t:1526418746900};\\\", \\\"{x:254,y:599,t:1526418746916};\\\", \\\"{x:234,y:599,t:1526418746933};\\\", \\\"{x:213,y:597,t:1526418746950};\\\", \\\"{x:202,y:594,t:1526418746968};\\\", \\\"{x:200,y:593,t:1526418746983};\\\", \\\"{x:199,y:592,t:1526418747053};\\\", \\\"{x:198,y:589,t:1526418747066};\\\", \\\"{x:197,y:581,t:1526418747081};\\\", \\\"{x:196,y:567,t:1526418747098};\\\", \\\"{x:196,y:559,t:1526418747116};\\\", \\\"{x:192,y:548,t:1526418747132};\\\", \\\"{x:191,y:544,t:1526418747149};\\\", \\\"{x:188,y:540,t:1526418747165};\\\", \\\"{x:187,y:539,t:1526418747182};\\\", \\\"{x:186,y:538,t:1526418747199};\\\", \\\"{x:185,y:537,t:1526418747216};\\\", \\\"{x:187,y:537,t:1526418747598};\\\", \\\"{x:201,y:537,t:1526418747605};\\\", \\\"{x:214,y:537,t:1526418747617};\\\", \\\"{x:239,y:537,t:1526418747633};\\\", \\\"{x:265,y:537,t:1526418747650};\\\", \\\"{x:296,y:537,t:1526418747667};\\\", \\\"{x:346,y:542,t:1526418747682};\\\", \\\"{x:397,y:549,t:1526418747701};\\\", \\\"{x:444,y:556,t:1526418747717};\\\", \\\"{x:455,y:558,t:1526418747732};\\\", \\\"{x:481,y:565,t:1526418747750};\\\", \\\"{x:493,y:568,t:1526418747767};\\\", \\\"{x:499,y:572,t:1526418747783};\\\", \\\"{x:501,y:572,t:1526418747800};\\\", \\\"{x:501,y:573,t:1526418747816};\\\", \\\"{x:502,y:574,t:1526418747832};\\\", \\\"{x:506,y:578,t:1526418747850};\\\", \\\"{x:521,y:590,t:1526418747867};\\\", \\\"{x:540,y:600,t:1526418747883};\\\", \\\"{x:558,y:605,t:1526418747900};\\\", \\\"{x:575,y:607,t:1526418747917};\\\", \\\"{x:605,y:607,t:1526418747933};\\\", \\\"{x:635,y:607,t:1526418747949};\\\", \\\"{x:661,y:603,t:1526418747967};\\\", \\\"{x:672,y:601,t:1526418747983};\\\", \\\"{x:674,y:600,t:1526418748000};\\\", \\\"{x:675,y:599,t:1526418748016};\\\", \\\"{x:676,y:599,t:1526418748033};\\\", \\\"{x:676,y:598,t:1526418748049};\\\", \\\"{x:676,y:597,t:1526418748067};\\\", \\\"{x:677,y:596,t:1526418748084};\\\", \\\"{x:678,y:593,t:1526418748100};\\\", \\\"{x:678,y:589,t:1526418748117};\\\", \\\"{x:678,y:587,t:1526418748134};\\\", \\\"{x:678,y:586,t:1526418748165};\\\", \\\"{x:677,y:586,t:1526418748173};\\\", \\\"{x:673,y:586,t:1526418748183};\\\", \\\"{x:653,y:588,t:1526418748199};\\\", \\\"{x:632,y:601,t:1526418748217};\\\", \\\"{x:615,y:616,t:1526418748233};\\\", \\\"{x:605,y:623,t:1526418748249};\\\", \\\"{x:598,y:627,t:1526418748267};\\\", \\\"{x:597,y:626,t:1526418748293};\\\", \\\"{x:601,y:620,t:1526418748301};\\\", \\\"{x:661,y:599,t:1526418748317};\\\", \\\"{x:754,y:576,t:1526418748334};\\\", \\\"{x:825,y:550,t:1526418748350};\\\", \\\"{x:873,y:528,t:1526418748367};\\\", \\\"{x:898,y:512,t:1526418748384};\\\", \\\"{x:908,y:502,t:1526418748399};\\\", \\\"{x:909,y:499,t:1526418748416};\\\", \\\"{x:910,y:498,t:1526418748434};\\\", \\\"{x:910,y:497,t:1526418748509};\\\", \\\"{x:910,y:496,t:1526418748517};\\\", \\\"{x:903,y:494,t:1526418748533};\\\", \\\"{x:895,y:493,t:1526418748550};\\\", \\\"{x:892,y:493,t:1526418748567};\\\", \\\"{x:888,y:493,t:1526418748583};\\\", \\\"{x:886,y:494,t:1526418748600};\\\", \\\"{x:881,y:496,t:1526418748616};\\\", \\\"{x:877,y:498,t:1526418748633};\\\", \\\"{x:870,y:498,t:1526418748650};\\\", \\\"{x:866,y:500,t:1526418748667};\\\", \\\"{x:860,y:506,t:1526418749101};\\\", \\\"{x:846,y:521,t:1526418749118};\\\", \\\"{x:831,y:538,t:1526418749135};\\\", \\\"{x:810,y:559,t:1526418749151};\\\", \\\"{x:785,y:582,t:1526418749168};\\\", \\\"{x:752,y:609,t:1526418749184};\\\", \\\"{x:718,y:633,t:1526418749201};\\\", \\\"{x:672,y:658,t:1526418749217};\\\", \\\"{x:617,y:682,t:1526418749234};\\\", \\\"{x:561,y:700,t:1526418749251};\\\", \\\"{x:525,y:721,t:1526418749268};\\\", \\\"{x:502,y:736,t:1526418749284};\\\", \\\"{x:477,y:748,t:1526418749301};\\\", \\\"{x:469,y:752,t:1526418749318};\\\", \\\"{x:466,y:755,t:1526418749335};\\\", \\\"{x:464,y:756,t:1526418749389};\\\", \\\"{x:464,y:758,t:1526418749400};\\\", \\\"{x:463,y:760,t:1526418749417};\\\", \\\"{x:463,y:762,t:1526418749435};\\\", \\\"{x:462,y:764,t:1526418749451};\\\", \\\"{x:460,y:766,t:1526418749468};\\\", \\\"{x:458,y:773,t:1526418749485};\\\", \\\"{x:456,y:776,t:1526418749501};\\\", \\\"{x:454,y:777,t:1526418749518};\\\", \\\"{x:450,y:779,t:1526418749534};\\\", \\\"{x:445,y:780,t:1526418749550};\\\", \\\"{x:440,y:780,t:1526418749568};\\\", \\\"{x:438,y:780,t:1526418749585};\\\", \\\"{x:438,y:779,t:1526418749973};\\\", \\\"{x:438,y:778,t:1526418749985};\\\", \\\"{x:439,y:775,t:1526418750002};\\\", \\\"{x:440,y:773,t:1526418750018};\\\", \\\"{x:441,y:770,t:1526418750035};\\\", \\\"{x:443,y:768,t:1526418750051};\\\", \\\"{x:444,y:767,t:1526418750068};\\\", \\\"{x:444,y:766,t:1526418750101};\\\", \\\"{x:444,y:765,t:1526418750141};\\\", \\\"{x:446,y:763,t:1526418750173};\\\", \\\"{x:446,y:761,t:1526418754357};\\\", \\\"{x:446,y:760,t:1526418754372};\\\", \\\"{x:446,y:759,t:1526418754388};\\\", \\\"{x:446,y:757,t:1526418754405};\\\", \\\"{x:446,y:755,t:1526418754422};\\\", \\\"{x:446,y:754,t:1526418754438};\\\", \\\"{x:446,y:753,t:1526418754455};\\\", \\\"{x:446,y:752,t:1526418754472};\\\", \\\"{x:446,y:751,t:1526418754750};\\\", \\\"{x:447,y:751,t:1526418754758};\\\", \\\"{x:448,y:751,t:1526418754772};\\\", \\\"{x:451,y:751,t:1526418754789};\\\", \\\"{x:452,y:751,t:1526418754803};\\\", \\\"{x:455,y:750,t:1526418754820};\\\", \\\"{x:456,y:749,t:1526418754837};\\\", \\\"{x:457,y:749,t:1526418754853};\\\", \\\"{x:458,y:747,t:1526418754917};\\\", \\\"{x:459,y:746,t:1526418754973};\\\", \\\"{x:460,y:745,t:1526418754987};\\\", \\\"{x:462,y:742,t:1526418755003};\\\", \\\"{x:465,y:738,t:1526418755020};\\\" ] }, { \\\"rt\\\": 13202, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 666081, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:465,y:731,t:1526418762606};\\\", \\\"{x:465,y:723,t:1526418762613};\\\", \\\"{x:465,y:710,t:1526418762630};\\\", \\\"{x:463,y:695,t:1526418762645};\\\", \\\"{x:459,y:686,t:1526418762662};\\\", \\\"{x:457,y:675,t:1526418762678};\\\", \\\"{x:455,y:668,t:1526418762696};\\\", \\\"{x:454,y:665,t:1526418762712};\\\", \\\"{x:452,y:660,t:1526418762728};\\\", \\\"{x:451,y:655,t:1526418762745};\\\", \\\"{x:448,y:651,t:1526418762763};\\\", \\\"{x:446,y:647,t:1526418762780};\\\", \\\"{x:444,y:644,t:1526418762795};\\\", \\\"{x:443,y:640,t:1526418762812};\\\", \\\"{x:439,y:634,t:1526418762829};\\\", \\\"{x:438,y:632,t:1526418762845};\\\", \\\"{x:436,y:630,t:1526418762863};\\\", \\\"{x:434,y:628,t:1526418762879};\\\", \\\"{x:433,y:625,t:1526418762895};\\\", \\\"{x:432,y:624,t:1526418762913};\\\", \\\"{x:431,y:623,t:1526418762929};\\\", \\\"{x:428,y:621,t:1526418762945};\\\", \\\"{x:424,y:620,t:1526418762962};\\\", \\\"{x:421,y:618,t:1526418762979};\\\", \\\"{x:419,y:617,t:1526418762996};\\\", \\\"{x:417,y:616,t:1526418763016};\\\", \\\"{x:409,y:614,t:1526418763032};\\\", \\\"{x:400,y:609,t:1526418763050};\\\", \\\"{x:385,y:605,t:1526418763066};\\\", \\\"{x:376,y:603,t:1526418763083};\\\", \\\"{x:364,y:602,t:1526418763100};\\\", \\\"{x:354,y:599,t:1526418763116};\\\", \\\"{x:338,y:598,t:1526418763133};\\\", \\\"{x:323,y:595,t:1526418763149};\\\", \\\"{x:306,y:593,t:1526418763167};\\\", \\\"{x:289,y:590,t:1526418763183};\\\", \\\"{x:280,y:589,t:1526418763199};\\\", \\\"{x:272,y:588,t:1526418763217};\\\", \\\"{x:258,y:585,t:1526418763233};\\\", \\\"{x:245,y:579,t:1526418763255};\\\", \\\"{x:231,y:572,t:1526418763266};\\\", \\\"{x:224,y:570,t:1526418763283};\\\", \\\"{x:217,y:566,t:1526418763300};\\\", \\\"{x:212,y:562,t:1526418763317};\\\", \\\"{x:207,y:558,t:1526418763333};\\\", \\\"{x:203,y:555,t:1526418763350};\\\", \\\"{x:202,y:552,t:1526418763366};\\\", \\\"{x:201,y:551,t:1526418763383};\\\", \\\"{x:200,y:550,t:1526418763400};\\\", \\\"{x:200,y:549,t:1526418763416};\\\", \\\"{x:199,y:547,t:1526418763433};\\\", \\\"{x:199,y:545,t:1526418763464};\\\", \\\"{x:198,y:544,t:1526418763472};\\\", \\\"{x:198,y:543,t:1526418763483};\\\", \\\"{x:203,y:550,t:1526418763913};\\\", \\\"{x:213,y:559,t:1526418763921};\\\", \\\"{x:227,y:569,t:1526418763934};\\\", \\\"{x:251,y:586,t:1526418763950};\\\", \\\"{x:280,y:603,t:1526418763968};\\\", \\\"{x:314,y:621,t:1526418763983};\\\", \\\"{x:348,y:637,t:1526418764000};\\\", \\\"{x:387,y:655,t:1526418764018};\\\", \\\"{x:401,y:662,t:1526418764034};\\\", \\\"{x:407,y:664,t:1526418764050};\\\", \\\"{x:409,y:665,t:1526418764067};\\\", \\\"{x:408,y:664,t:1526418764177};\\\", \\\"{x:394,y:653,t:1526418764184};\\\", \\\"{x:312,y:606,t:1526418764201};\\\", \\\"{x:215,y:560,t:1526418764217};\\\", \\\"{x:157,y:536,t:1526418764235};\\\", \\\"{x:138,y:527,t:1526418764250};\\\", \\\"{x:129,y:524,t:1526418764267};\\\", \\\"{x:125,y:521,t:1526418764284};\\\", \\\"{x:122,y:519,t:1526418764300};\\\", \\\"{x:123,y:519,t:1526418764465};\\\", \\\"{x:130,y:521,t:1526418764473};\\\", \\\"{x:139,y:525,t:1526418764485};\\\", \\\"{x:149,y:530,t:1526418764501};\\\", \\\"{x:155,y:532,t:1526418764517};\\\", \\\"{x:160,y:535,t:1526418764534};\\\", \\\"{x:162,y:535,t:1526418764551};\\\", \\\"{x:163,y:536,t:1526418764567};\\\", \\\"{x:164,y:536,t:1526418765089};\\\", \\\"{x:169,y:540,t:1526418765101};\\\", \\\"{x:193,y:549,t:1526418765118};\\\", \\\"{x:220,y:561,t:1526418765135};\\\", \\\"{x:267,y:581,t:1526418765152};\\\", \\\"{x:313,y:600,t:1526418765169};\\\", \\\"{x:383,y:634,t:1526418765184};\\\", \\\"{x:419,y:649,t:1526418765201};\\\", \\\"{x:442,y:664,t:1526418765218};\\\", \\\"{x:460,y:677,t:1526418765236};\\\", \\\"{x:472,y:687,t:1526418765252};\\\", \\\"{x:478,y:694,t:1526418765268};\\\", \\\"{x:480,y:697,t:1526418765285};\\\", \\\"{x:481,y:699,t:1526418765360};\\\", \\\"{x:482,y:700,t:1526418765368};\\\", \\\"{x:483,y:702,t:1526418765385};\\\", \\\"{x:483,y:703,t:1526418765401};\\\", \\\"{x:485,y:704,t:1526418765418};\\\", \\\"{x:487,y:718,t:1526418765435};\\\", \\\"{x:491,y:744,t:1526418765451};\\\", \\\"{x:502,y:771,t:1526418765468};\\\", \\\"{x:508,y:789,t:1526418765486};\\\", \\\"{x:514,y:796,t:1526418765502};\\\", \\\"{x:514,y:797,t:1526418765518};\\\", \\\"{x:514,y:798,t:1526418765617};\\\", \\\"{x:513,y:798,t:1526418765625};\\\", \\\"{x:513,y:795,t:1526418765641};\\\", \\\"{x:513,y:794,t:1526418765652};\\\", \\\"{x:512,y:788,t:1526418765668};\\\", \\\"{x:511,y:780,t:1526418765686};\\\", \\\"{x:510,y:776,t:1526418765703};\\\", \\\"{x:509,y:773,t:1526418765718};\\\", \\\"{x:509,y:772,t:1526418766162};\\\", \\\"{x:508,y:768,t:1526418766169};\\\", \\\"{x:507,y:761,t:1526418766186};\\\", \\\"{x:507,y:757,t:1526418766203};\\\", \\\"{x:506,y:753,t:1526418766220};\\\", \\\"{x:506,y:748,t:1526418766236};\\\", \\\"{x:506,y:742,t:1526418766252};\\\", \\\"{x:506,y:740,t:1526418766269};\\\" ] }, { \\\"rt\\\": 73414, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 740685, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:736,t:1526418794569};\\\", \\\"{x:515,y:727,t:1526418794577};\\\", \\\"{x:523,y:718,t:1526418794589};\\\", \\\"{x:535,y:704,t:1526418794604};\\\", \\\"{x:543,y:690,t:1526418794620};\\\", \\\"{x:559,y:670,t:1526418794638};\\\", \\\"{x:575,y:655,t:1526418794655};\\\", \\\"{x:584,y:644,t:1526418794671};\\\", \\\"{x:589,y:637,t:1526418794688};\\\", \\\"{x:590,y:636,t:1526418794705};\\\", \\\"{x:591,y:633,t:1526418794722};\\\", \\\"{x:595,y:628,t:1526418794739};\\\", \\\"{x:598,y:623,t:1526418794755};\\\", \\\"{x:599,y:620,t:1526418794777};\\\", \\\"{x:599,y:619,t:1526418794793};\\\", \\\"{x:599,y:617,t:1526418794809};\\\", \\\"{x:599,y:616,t:1526418794827};\\\", \\\"{x:600,y:613,t:1526418794843};\\\", \\\"{x:601,y:612,t:1526418794897};\\\", \\\"{x:601,y:611,t:1526418794909};\\\", \\\"{x:601,y:610,t:1526418794926};\\\", \\\"{x:602,y:607,t:1526418794944};\\\", \\\"{x:602,y:606,t:1526418794977};\\\", \\\"{x:603,y:603,t:1526418794994};\\\", \\\"{x:603,y:600,t:1526418795011};\\\", \\\"{x:604,y:599,t:1526418795026};\\\", \\\"{x:604,y:597,t:1526418795043};\\\", \\\"{x:604,y:595,t:1526418795061};\\\", \\\"{x:604,y:594,t:1526418795080};\\\", \\\"{x:604,y:593,t:1526418795097};\\\", \\\"{x:604,y:592,t:1526418795110};\\\", \\\"{x:605,y:590,t:1526418795127};\\\", \\\"{x:607,y:586,t:1526418795143};\\\", \\\"{x:607,y:585,t:1526418795160};\\\", \\\"{x:615,y:584,t:1526418795521};\\\", \\\"{x:632,y:585,t:1526418795529};\\\", \\\"{x:668,y:594,t:1526418795545};\\\", \\\"{x:837,y:646,t:1526418795561};\\\", \\\"{x:993,y:702,t:1526418795577};\\\", \\\"{x:1160,y:760,t:1526418795593};\\\", \\\"{x:1306,y:802,t:1526418795611};\\\", \\\"{x:1432,y:827,t:1526418795627};\\\", \\\"{x:1545,y:858,t:1526418795644};\\\", \\\"{x:1633,y:881,t:1526418795661};\\\", \\\"{x:1686,y:894,t:1526418795677};\\\", \\\"{x:1710,y:900,t:1526418795694};\\\", \\\"{x:1724,y:905,t:1526418795711};\\\", \\\"{x:1718,y:902,t:1526418795825};\\\", \\\"{x:1712,y:900,t:1526418795833};\\\", \\\"{x:1707,y:897,t:1526418795844};\\\", \\\"{x:1698,y:893,t:1526418795861};\\\", \\\"{x:1697,y:893,t:1526418795879};\\\", \\\"{x:1696,y:893,t:1526418795896};\\\", \\\"{x:1693,y:893,t:1526418795911};\\\", \\\"{x:1688,y:889,t:1526418795928};\\\", \\\"{x:1680,y:884,t:1526418795944};\\\", \\\"{x:1663,y:878,t:1526418795961};\\\", \\\"{x:1650,y:874,t:1526418795978};\\\", \\\"{x:1645,y:874,t:1526418795994};\\\", \\\"{x:1644,y:874,t:1526418796011};\\\", \\\"{x:1643,y:874,t:1526418796081};\\\", \\\"{x:1642,y:873,t:1526418796094};\\\", \\\"{x:1640,y:871,t:1526418796111};\\\", \\\"{x:1638,y:867,t:1526418796129};\\\", \\\"{x:1635,y:862,t:1526418796145};\\\", \\\"{x:1633,y:859,t:1526418796161};\\\", \\\"{x:1632,y:858,t:1526418796178};\\\", \\\"{x:1632,y:857,t:1526418796195};\\\", \\\"{x:1631,y:854,t:1526418796211};\\\", \\\"{x:1629,y:853,t:1526418796228};\\\", \\\"{x:1628,y:850,t:1526418796245};\\\", \\\"{x:1627,y:848,t:1526418796261};\\\", \\\"{x:1627,y:847,t:1526418796278};\\\", \\\"{x:1626,y:846,t:1526418796296};\\\", \\\"{x:1625,y:846,t:1526418796327};\\\", \\\"{x:1625,y:845,t:1526418796345};\\\", \\\"{x:1624,y:844,t:1526418796376};\\\", \\\"{x:1624,y:843,t:1526418796384};\\\", \\\"{x:1622,y:843,t:1526418796395};\\\", \\\"{x:1620,y:841,t:1526418796411};\\\", \\\"{x:1618,y:840,t:1526418796427};\\\", \\\"{x:1617,y:840,t:1526418796444};\\\", \\\"{x:1616,y:839,t:1526418796461};\\\", \\\"{x:1613,y:839,t:1526418796477};\\\", \\\"{x:1612,y:838,t:1526418796494};\\\", \\\"{x:1612,y:837,t:1526418796657};\\\", \\\"{x:1612,y:836,t:1526418796673};\\\", \\\"{x:1612,y:835,t:1526418796681};\\\", \\\"{x:1612,y:834,t:1526418796729};\\\", \\\"{x:1612,y:833,t:1526418797401};\\\", \\\"{x:1613,y:832,t:1526418797417};\\\", \\\"{x:1614,y:832,t:1526418797433};\\\", \\\"{x:1616,y:832,t:1526418797447};\\\", \\\"{x:1619,y:832,t:1526418797463};\\\", \\\"{x:1620,y:831,t:1526418799728};\\\", \\\"{x:1594,y:827,t:1526418841996};\\\", \\\"{x:1482,y:811,t:1526418842004};\\\", \\\"{x:1183,y:792,t:1526418842022};\\\", \\\"{x:844,y:792,t:1526418842038};\\\", \\\"{x:529,y:792,t:1526418842054};\\\", \\\"{x:287,y:792,t:1526418842070};\\\", \\\"{x:82,y:791,t:1526418842087};\\\", \\\"{x:0,y:781,t:1526418842105};\\\", \\\"{x:0,y:766,t:1526418842121};\\\", \\\"{x:0,y:748,t:1526418842137};\\\", \\\"{x:0,y:740,t:1526418842154};\\\", \\\"{x:0,y:739,t:1526418842171};\\\", \\\"{x:2,y:738,t:1526418842219};\\\", \\\"{x:9,y:738,t:1526418842227};\\\", \\\"{x:20,y:738,t:1526418842237};\\\", \\\"{x:36,y:736,t:1526418842254};\\\", \\\"{x:50,y:732,t:1526418842271};\\\", \\\"{x:66,y:724,t:1526418842287};\\\", \\\"{x:81,y:714,t:1526418842304};\\\", \\\"{x:97,y:703,t:1526418842321};\\\", \\\"{x:116,y:689,t:1526418842338};\\\", \\\"{x:138,y:677,t:1526418842354};\\\", \\\"{x:172,y:663,t:1526418842373};\\\", \\\"{x:184,y:659,t:1526418842387};\\\", \\\"{x:186,y:657,t:1526418842404};\\\", \\\"{x:185,y:653,t:1526418842418};\\\", \\\"{x:179,y:649,t:1526418842436};\\\", \\\"{x:177,y:644,t:1526418842452};\\\", \\\"{x:177,y:638,t:1526418842469};\\\", \\\"{x:179,y:633,t:1526418842486};\\\", \\\"{x:183,y:627,t:1526418842503};\\\", \\\"{x:184,y:622,t:1526418842520};\\\", \\\"{x:184,y:620,t:1526418842537};\\\", \\\"{x:186,y:615,t:1526418842553};\\\", \\\"{x:196,y:610,t:1526418842571};\\\", \\\"{x:210,y:600,t:1526418842587};\\\", \\\"{x:215,y:597,t:1526418842602};\\\", \\\"{x:217,y:596,t:1526418842620};\\\", \\\"{x:217,y:597,t:1526418842683};\\\", \\\"{x:218,y:603,t:1526418842692};\\\", \\\"{x:218,y:608,t:1526418842703};\\\", \\\"{x:218,y:615,t:1526418842719};\\\", \\\"{x:218,y:624,t:1526418842737};\\\", \\\"{x:218,y:638,t:1526418842754};\\\", \\\"{x:218,y:644,t:1526418842771};\\\", \\\"{x:218,y:647,t:1526418842786};\\\", \\\"{x:218,y:649,t:1526418842804};\\\", \\\"{x:221,y:652,t:1526418842820};\\\", \\\"{x:229,y:656,t:1526418842837};\\\", \\\"{x:237,y:660,t:1526418842853};\\\", \\\"{x:247,y:662,t:1526418842869};\\\", \\\"{x:271,y:663,t:1526418842887};\\\", \\\"{x:286,y:663,t:1526418842904};\\\", \\\"{x:290,y:663,t:1526418842919};\\\", \\\"{x:305,y:663,t:1526418842936};\\\", \\\"{x:361,y:641,t:1526418842954};\\\", \\\"{x:452,y:620,t:1526418842971};\\\", \\\"{x:597,y:603,t:1526418842987};\\\", \\\"{x:655,y:603,t:1526418843004};\\\", \\\"{x:680,y:603,t:1526418843020};\\\", \\\"{x:693,y:601,t:1526418843037};\\\", \\\"{x:694,y:600,t:1526418843076};\\\", \\\"{x:693,y:598,t:1526418843086};\\\", \\\"{x:688,y:594,t:1526418843103};\\\", \\\"{x:667,y:588,t:1526418843122};\\\", \\\"{x:623,y:573,t:1526418843137};\\\", \\\"{x:603,y:570,t:1526418843153};\\\", \\\"{x:599,y:568,t:1526418843171};\\\", \\\"{x:591,y:564,t:1526418843187};\\\", \\\"{x:577,y:559,t:1526418843204};\\\", \\\"{x:555,y:555,t:1526418843220};\\\", \\\"{x:540,y:554,t:1526418843237};\\\", \\\"{x:535,y:552,t:1526418843253};\\\", \\\"{x:533,y:551,t:1526418843270};\\\", \\\"{x:533,y:550,t:1526418843307};\\\", \\\"{x:533,y:549,t:1526418843320};\\\", \\\"{x:537,y:543,t:1526418843337};\\\", \\\"{x:558,y:537,t:1526418843353};\\\", \\\"{x:597,y:526,t:1526418843371};\\\", \\\"{x:617,y:520,t:1526418843388};\\\", \\\"{x:630,y:516,t:1526418843404};\\\", \\\"{x:640,y:513,t:1526418843420};\\\", \\\"{x:641,y:513,t:1526418843437};\\\", \\\"{x:635,y:512,t:1526418843460};\\\", \\\"{x:624,y:512,t:1526418843471};\\\", \\\"{x:600,y:512,t:1526418843488};\\\", \\\"{x:584,y:512,t:1526418843504};\\\", \\\"{x:582,y:512,t:1526418843521};\\\", \\\"{x:583,y:512,t:1526418843571};\\\", \\\"{x:603,y:513,t:1526418843586};\\\", \\\"{x:628,y:516,t:1526418843604};\\\", \\\"{x:651,y:520,t:1526418843621};\\\", \\\"{x:673,y:522,t:1526418843636};\\\", \\\"{x:694,y:525,t:1526418843654};\\\", \\\"{x:736,y:527,t:1526418843672};\\\", \\\"{x:792,y:527,t:1526418843688};\\\", \\\"{x:848,y:527,t:1526418843703};\\\", \\\"{x:880,y:527,t:1526418843721};\\\", \\\"{x:887,y:527,t:1526418843738};\\\", \\\"{x:887,y:525,t:1526418843755};\\\", \\\"{x:884,y:524,t:1526418843772};\\\", \\\"{x:883,y:524,t:1526418843787};\\\", \\\"{x:882,y:523,t:1526418843805};\\\", \\\"{x:880,y:522,t:1526418843821};\\\", \\\"{x:878,y:519,t:1526418843838};\\\", \\\"{x:875,y:517,t:1526418843856};\\\", \\\"{x:867,y:514,t:1526418843872};\\\", \\\"{x:857,y:511,t:1526418843889};\\\", \\\"{x:854,y:510,t:1526418843905};\\\", \\\"{x:852,y:509,t:1526418844178};\\\", \\\"{x:847,y:509,t:1526418844188};\\\", \\\"{x:829,y:526,t:1526418844205};\\\", \\\"{x:811,y:543,t:1526418844221};\\\", \\\"{x:789,y:559,t:1526418844238};\\\", \\\"{x:739,y:592,t:1526418844255};\\\", \\\"{x:687,y:636,t:1526418844270};\\\", \\\"{x:649,y:668,t:1526418844287};\\\", \\\"{x:616,y:693,t:1526418844305};\\\", \\\"{x:590,y:703,t:1526418844322};\\\", \\\"{x:574,y:708,t:1526418844338};\\\", \\\"{x:558,y:716,t:1526418844355};\\\", \\\"{x:553,y:720,t:1526418844371};\\\", \\\"{x:552,y:721,t:1526418844388};\\\", \\\"{x:551,y:721,t:1526418844427};\\\", \\\"{x:550,y:721,t:1526418844532};\\\", \\\"{x:548,y:721,t:1526418844539};\\\", \\\"{x:547,y:722,t:1526418844555};\\\", \\\"{x:547,y:724,t:1526418844668};\\\", \\\"{x:547,y:726,t:1526418844675};\\\", \\\"{x:547,y:727,t:1526418844689};\\\", \\\"{x:547,y:732,t:1526418844706};\\\", \\\"{x:544,y:735,t:1526418844723};\\\", \\\"{x:544,y:736,t:1526418844740};\\\" ] }, { \\\"rt\\\": 48162, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 790471, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:738,t:1526418846493};\\\", \\\"{x:533,y:738,t:1526418846552};\\\", \\\"{x:532,y:738,t:1526418846557};\\\", \\\"{x:531,y:738,t:1526418846573};\\\", \\\"{x:532,y:740,t:1526418851507};\\\", \\\"{x:545,y:744,t:1526418851515};\\\", \\\"{x:562,y:748,t:1526418851527};\\\", \\\"{x:635,y:758,t:1526418851545};\\\", \\\"{x:746,y:775,t:1526418851560};\\\", \\\"{x:881,y:791,t:1526418851577};\\\", \\\"{x:1028,y:811,t:1526418851595};\\\", \\\"{x:1166,y:830,t:1526418851610};\\\", \\\"{x:1353,y:855,t:1526418851627};\\\", \\\"{x:1445,y:872,t:1526418851644};\\\", \\\"{x:1506,y:881,t:1526418851660};\\\", \\\"{x:1539,y:889,t:1526418851677};\\\", \\\"{x:1551,y:891,t:1526418851694};\\\", \\\"{x:1552,y:891,t:1526418851710};\\\", \\\"{x:1552,y:892,t:1526418851727};\\\", \\\"{x:1547,y:893,t:1526418851744};\\\", \\\"{x:1544,y:894,t:1526418851760};\\\", \\\"{x:1542,y:895,t:1526418851778};\\\", \\\"{x:1540,y:896,t:1526418851794};\\\", \\\"{x:1540,y:897,t:1526418851810};\\\", \\\"{x:1545,y:909,t:1526418851827};\\\", \\\"{x:1554,y:923,t:1526418851844};\\\", \\\"{x:1556,y:926,t:1526418851860};\\\", \\\"{x:1556,y:927,t:1526418851877};\\\", \\\"{x:1556,y:929,t:1526418851894};\\\", \\\"{x:1556,y:935,t:1526418851911};\\\", \\\"{x:1559,y:941,t:1526418851927};\\\", \\\"{x:1561,y:947,t:1526418851944};\\\", \\\"{x:1562,y:949,t:1526418851961};\\\", \\\"{x:1562,y:950,t:1526418851977};\\\", \\\"{x:1562,y:951,t:1526418852035};\\\", \\\"{x:1561,y:951,t:1526418852044};\\\", \\\"{x:1560,y:952,t:1526418852061};\\\", \\\"{x:1560,y:953,t:1526418852091};\\\", \\\"{x:1559,y:954,t:1526418852123};\\\", \\\"{x:1557,y:954,t:1526418852131};\\\", \\\"{x:1556,y:955,t:1526418852145};\\\", \\\"{x:1553,y:956,t:1526418852162};\\\", \\\"{x:1552,y:956,t:1526418852427};\\\", \\\"{x:1552,y:955,t:1526418852475};\\\", \\\"{x:1552,y:954,t:1526418852483};\\\", \\\"{x:1552,y:953,t:1526418852495};\\\", \\\"{x:1552,y:951,t:1526418852512};\\\", \\\"{x:1550,y:947,t:1526418852529};\\\", \\\"{x:1549,y:945,t:1526418852545};\\\", \\\"{x:1549,y:943,t:1526418852561};\\\", \\\"{x:1549,y:938,t:1526418852579};\\\", \\\"{x:1549,y:933,t:1526418852595};\\\", \\\"{x:1548,y:929,t:1526418852611};\\\", \\\"{x:1546,y:925,t:1526418852629};\\\", \\\"{x:1546,y:922,t:1526418852645};\\\", \\\"{x:1546,y:920,t:1526418852662};\\\", \\\"{x:1546,y:917,t:1526418852679};\\\", \\\"{x:1546,y:914,t:1526418852694};\\\", \\\"{x:1546,y:910,t:1526418852711};\\\", \\\"{x:1546,y:907,t:1526418852729};\\\", \\\"{x:1546,y:903,t:1526418852744};\\\", \\\"{x:1546,y:900,t:1526418852762};\\\", \\\"{x:1546,y:894,t:1526418852778};\\\", \\\"{x:1546,y:890,t:1526418852795};\\\", \\\"{x:1546,y:885,t:1526418852812};\\\", \\\"{x:1546,y:883,t:1526418852829};\\\", \\\"{x:1546,y:881,t:1526418852846};\\\", \\\"{x:1546,y:877,t:1526418852862};\\\", \\\"{x:1546,y:875,t:1526418852879};\\\", \\\"{x:1546,y:873,t:1526418852896};\\\", \\\"{x:1545,y:869,t:1526418852912};\\\", \\\"{x:1545,y:867,t:1526418852929};\\\", \\\"{x:1545,y:862,t:1526418852946};\\\", \\\"{x:1545,y:858,t:1526418852962};\\\", \\\"{x:1545,y:852,t:1526418852979};\\\", \\\"{x:1545,y:845,t:1526418852995};\\\", \\\"{x:1545,y:843,t:1526418853012};\\\", \\\"{x:1545,y:841,t:1526418853028};\\\", \\\"{x:1545,y:838,t:1526418853046};\\\", \\\"{x:1545,y:836,t:1526418853062};\\\", \\\"{x:1545,y:835,t:1526418853079};\\\", \\\"{x:1545,y:834,t:1526418853100};\\\", \\\"{x:1545,y:833,t:1526418853116};\\\", \\\"{x:1545,y:832,t:1526418853129};\\\", \\\"{x:1545,y:829,t:1526418853145};\\\", \\\"{x:1545,y:826,t:1526418853162};\\\", \\\"{x:1545,y:825,t:1526418853179};\\\", \\\"{x:1545,y:822,t:1526418853195};\\\", \\\"{x:1545,y:819,t:1526418853212};\\\", \\\"{x:1545,y:816,t:1526418853229};\\\", \\\"{x:1546,y:813,t:1526418853246};\\\", \\\"{x:1546,y:809,t:1526418853262};\\\", \\\"{x:1546,y:808,t:1526418853279};\\\", \\\"{x:1546,y:806,t:1526418853295};\\\", \\\"{x:1546,y:802,t:1526418853311};\\\", \\\"{x:1546,y:797,t:1526418853329};\\\", \\\"{x:1546,y:792,t:1526418853346};\\\", \\\"{x:1546,y:788,t:1526418853363};\\\", \\\"{x:1546,y:783,t:1526418853379};\\\", \\\"{x:1546,y:779,t:1526418853395};\\\", \\\"{x:1546,y:776,t:1526418853413};\\\", \\\"{x:1546,y:774,t:1526418853429};\\\", \\\"{x:1546,y:771,t:1526418853445};\\\", \\\"{x:1546,y:770,t:1526418853462};\\\", \\\"{x:1546,y:768,t:1526418853479};\\\", \\\"{x:1546,y:765,t:1526418853496};\\\", \\\"{x:1546,y:761,t:1526418853513};\\\", \\\"{x:1546,y:758,t:1526418853528};\\\", \\\"{x:1547,y:753,t:1526418853546};\\\", \\\"{x:1547,y:751,t:1526418853562};\\\", \\\"{x:1547,y:747,t:1526418853579};\\\", \\\"{x:1548,y:742,t:1526418853596};\\\", \\\"{x:1549,y:736,t:1526418853613};\\\", \\\"{x:1549,y:732,t:1526418853629};\\\", \\\"{x:1549,y:729,t:1526418853646};\\\", \\\"{x:1549,y:728,t:1526418853663};\\\", \\\"{x:1550,y:724,t:1526418853679};\\\", \\\"{x:1550,y:721,t:1526418853696};\\\", \\\"{x:1551,y:716,t:1526418853713};\\\", \\\"{x:1551,y:714,t:1526418853729};\\\", \\\"{x:1551,y:710,t:1526418853746};\\\", \\\"{x:1551,y:708,t:1526418853763};\\\", \\\"{x:1551,y:705,t:1526418853779};\\\", \\\"{x:1551,y:701,t:1526418853796};\\\", \\\"{x:1551,y:698,t:1526418853813};\\\", \\\"{x:1551,y:696,t:1526418853829};\\\", \\\"{x:1551,y:694,t:1526418853846};\\\", \\\"{x:1551,y:692,t:1526418853862};\\\", \\\"{x:1551,y:688,t:1526418853879};\\\", \\\"{x:1551,y:686,t:1526418853896};\\\", \\\"{x:1551,y:682,t:1526418853913};\\\", \\\"{x:1551,y:678,t:1526418853930};\\\", \\\"{x:1551,y:674,t:1526418853946};\\\", \\\"{x:1551,y:672,t:1526418853963};\\\", \\\"{x:1551,y:666,t:1526418853979};\\\", \\\"{x:1551,y:660,t:1526418853996};\\\", \\\"{x:1551,y:656,t:1526418854013};\\\", \\\"{x:1551,y:652,t:1526418854030};\\\", \\\"{x:1551,y:649,t:1526418854046};\\\", \\\"{x:1551,y:646,t:1526418854063};\\\", \\\"{x:1551,y:643,t:1526418854080};\\\", \\\"{x:1551,y:639,t:1526418854096};\\\", \\\"{x:1551,y:637,t:1526418854113};\\\", \\\"{x:1551,y:633,t:1526418854130};\\\", \\\"{x:1552,y:631,t:1526418854146};\\\", \\\"{x:1552,y:629,t:1526418854162};\\\", \\\"{x:1552,y:625,t:1526418854179};\\\", \\\"{x:1552,y:623,t:1526418854195};\\\", \\\"{x:1552,y:619,t:1526418854213};\\\", \\\"{x:1552,y:617,t:1526418854229};\\\", \\\"{x:1552,y:615,t:1526418854246};\\\", \\\"{x:1552,y:613,t:1526418854263};\\\", \\\"{x:1552,y:610,t:1526418854279};\\\", \\\"{x:1552,y:609,t:1526418854296};\\\", \\\"{x:1552,y:607,t:1526418854313};\\\", \\\"{x:1552,y:604,t:1526418854330};\\\", \\\"{x:1552,y:602,t:1526418854347};\\\", \\\"{x:1552,y:601,t:1526418854363};\\\", \\\"{x:1552,y:597,t:1526418854379};\\\", \\\"{x:1552,y:593,t:1526418854397};\\\", \\\"{x:1552,y:589,t:1526418854413};\\\", \\\"{x:1552,y:586,t:1526418854430};\\\", \\\"{x:1552,y:583,t:1526418854446};\\\", \\\"{x:1552,y:579,t:1526418854463};\\\", \\\"{x:1552,y:575,t:1526418854480};\\\", \\\"{x:1552,y:572,t:1526418854497};\\\", \\\"{x:1552,y:569,t:1526418854513};\\\", \\\"{x:1552,y:565,t:1526418854530};\\\", \\\"{x:1552,y:562,t:1526418854547};\\\", \\\"{x:1552,y:558,t:1526418854563};\\\", \\\"{x:1552,y:553,t:1526418854579};\\\", \\\"{x:1552,y:548,t:1526418854597};\\\", \\\"{x:1552,y:545,t:1526418854613};\\\", \\\"{x:1550,y:542,t:1526418854630};\\\", \\\"{x:1550,y:541,t:1526418854647};\\\", \\\"{x:1550,y:540,t:1526418854662};\\\", \\\"{x:1550,y:539,t:1526418854680};\\\", \\\"{x:1550,y:538,t:1526418854697};\\\", \\\"{x:1548,y:538,t:1526418855299};\\\", \\\"{x:1539,y:540,t:1526418855314};\\\", \\\"{x:1511,y:552,t:1526418855330};\\\", \\\"{x:1500,y:556,t:1526418855347};\\\", \\\"{x:1498,y:557,t:1526418855379};\\\", \\\"{x:1496,y:558,t:1526418855387};\\\", \\\"{x:1495,y:559,t:1526418855396};\\\", \\\"{x:1492,y:560,t:1526418855413};\\\", \\\"{x:1489,y:563,t:1526418855431};\\\", \\\"{x:1488,y:566,t:1526418855448};\\\", \\\"{x:1484,y:581,t:1526418855464};\\\", \\\"{x:1476,y:611,t:1526418855481};\\\", \\\"{x:1473,y:645,t:1526418855497};\\\", \\\"{x:1471,y:667,t:1526418855514};\\\", \\\"{x:1470,y:688,t:1526418855531};\\\", \\\"{x:1474,y:718,t:1526418855546};\\\", \\\"{x:1490,y:769,t:1526418855563};\\\", \\\"{x:1501,y:792,t:1526418855580};\\\", \\\"{x:1511,y:807,t:1526418855597};\\\", \\\"{x:1518,y:816,t:1526418855614};\\\", \\\"{x:1524,y:825,t:1526418855631};\\\", \\\"{x:1534,y:841,t:1526418855646};\\\", \\\"{x:1543,y:857,t:1526418855664};\\\", \\\"{x:1550,y:869,t:1526418855681};\\\", \\\"{x:1554,y:873,t:1526418855697};\\\", \\\"{x:1556,y:875,t:1526418855713};\\\", \\\"{x:1556,y:876,t:1526418855731};\\\", \\\"{x:1556,y:877,t:1526418855828};\\\", \\\"{x:1556,y:876,t:1526418855851};\\\", \\\"{x:1554,y:875,t:1526418855864};\\\", \\\"{x:1554,y:874,t:1526418855902};\\\", \\\"{x:1554,y:873,t:1526418855913};\\\", \\\"{x:1554,y:870,t:1526418855931};\\\", \\\"{x:1554,y:869,t:1526418855994};\\\", \\\"{x:1554,y:868,t:1526418856002};\\\", \\\"{x:1554,y:867,t:1526418856013};\\\", \\\"{x:1555,y:864,t:1526418856031};\\\", \\\"{x:1555,y:863,t:1526418856047};\\\", \\\"{x:1555,y:861,t:1526418856067};\\\", \\\"{x:1555,y:859,t:1526418856082};\\\", \\\"{x:1555,y:856,t:1526418856098};\\\", \\\"{x:1554,y:848,t:1526418856114};\\\", \\\"{x:1553,y:846,t:1526418856130};\\\", \\\"{x:1553,y:849,t:1526418856227};\\\", \\\"{x:1553,y:854,t:1526418856235};\\\", \\\"{x:1553,y:864,t:1526418856248};\\\", \\\"{x:1553,y:880,t:1526418856265};\\\", \\\"{x:1553,y:893,t:1526418856280};\\\", \\\"{x:1553,y:904,t:1526418856298};\\\", \\\"{x:1553,y:918,t:1526418856314};\\\", \\\"{x:1553,y:926,t:1526418856331};\\\", \\\"{x:1551,y:932,t:1526418856348};\\\", \\\"{x:1551,y:934,t:1526418856364};\\\", \\\"{x:1551,y:935,t:1526418856381};\\\", \\\"{x:1550,y:936,t:1526418856398};\\\", \\\"{x:1548,y:937,t:1526418856452};\\\", \\\"{x:1545,y:937,t:1526418856465};\\\", \\\"{x:1534,y:937,t:1526418856481};\\\", \\\"{x:1521,y:937,t:1526418856498};\\\", \\\"{x:1510,y:937,t:1526418856516};\\\", \\\"{x:1504,y:936,t:1526418856531};\\\", \\\"{x:1493,y:932,t:1526418856547};\\\", \\\"{x:1484,y:930,t:1526418856565};\\\", \\\"{x:1481,y:928,t:1526418856581};\\\", \\\"{x:1481,y:927,t:1526418856668};\\\", \\\"{x:1481,y:926,t:1526418856700};\\\", \\\"{x:1481,y:924,t:1526418856715};\\\", \\\"{x:1484,y:924,t:1526418856732};\\\", \\\"{x:1491,y:924,t:1526418856748};\\\", \\\"{x:1504,y:925,t:1526418856765};\\\", \\\"{x:1517,y:933,t:1526418856782};\\\", \\\"{x:1526,y:938,t:1526418856798};\\\", \\\"{x:1532,y:944,t:1526418856815};\\\", \\\"{x:1537,y:949,t:1526418856832};\\\", \\\"{x:1549,y:959,t:1526418856848};\\\", \\\"{x:1557,y:964,t:1526418856866};\\\", \\\"{x:1561,y:967,t:1526418856883};\\\", \\\"{x:1561,y:965,t:1526418857068};\\\", \\\"{x:1561,y:964,t:1526418857082};\\\", \\\"{x:1561,y:963,t:1526418857156};\\\", \\\"{x:1560,y:963,t:1526418857188};\\\", \\\"{x:1559,y:963,t:1526418857199};\\\", \\\"{x:1558,y:963,t:1526418857215};\\\", \\\"{x:1557,y:963,t:1526418857232};\\\", \\\"{x:1555,y:961,t:1526418857249};\\\", \\\"{x:1554,y:961,t:1526418857265};\\\", \\\"{x:1552,y:960,t:1526418857282};\\\", \\\"{x:1548,y:958,t:1526418857299};\\\", \\\"{x:1548,y:957,t:1526418857323};\\\", \\\"{x:1547,y:955,t:1526418857412};\\\", \\\"{x:1547,y:954,t:1526418857443};\\\", \\\"{x:1547,y:953,t:1526418857459};\\\", \\\"{x:1547,y:952,t:1526418857467};\\\", \\\"{x:1547,y:951,t:1526418857483};\\\", \\\"{x:1547,y:949,t:1526418857507};\\\", \\\"{x:1547,y:948,t:1526418857523};\\\", \\\"{x:1547,y:947,t:1526418857531};\\\", \\\"{x:1547,y:946,t:1526418857549};\\\", \\\"{x:1548,y:945,t:1526418857571};\\\", \\\"{x:1549,y:943,t:1526418857620};\\\", \\\"{x:1549,y:942,t:1526418857635};\\\", \\\"{x:1550,y:942,t:1526418857648};\\\", \\\"{x:1550,y:940,t:1526418857706};\\\", \\\"{x:1551,y:938,t:1526418857731};\\\", \\\"{x:1551,y:937,t:1526418857754};\\\", \\\"{x:1552,y:936,t:1526418857771};\\\", \\\"{x:1552,y:935,t:1526418857782};\\\", \\\"{x:1552,y:933,t:1526418857799};\\\", \\\"{x:1553,y:931,t:1526418857816};\\\", \\\"{x:1553,y:927,t:1526418857831};\\\", \\\"{x:1554,y:924,t:1526418857848};\\\", \\\"{x:1554,y:922,t:1526418857866};\\\", \\\"{x:1554,y:920,t:1526418857882};\\\", \\\"{x:1554,y:919,t:1526418857899};\\\", \\\"{x:1554,y:918,t:1526418857916};\\\", \\\"{x:1555,y:922,t:1526418858115};\\\", \\\"{x:1557,y:937,t:1526418858132};\\\", \\\"{x:1557,y:952,t:1526418858149};\\\", \\\"{x:1557,y:961,t:1526418858166};\\\", \\\"{x:1557,y:965,t:1526418858182};\\\", \\\"{x:1557,y:966,t:1526418858198};\\\", \\\"{x:1556,y:966,t:1526418858371};\\\", \\\"{x:1555,y:966,t:1526418858387};\\\", \\\"{x:1554,y:966,t:1526418858412};\\\", \\\"{x:1553,y:966,t:1526418858547};\\\", \\\"{x:1552,y:966,t:1526418858566};\\\", \\\"{x:1551,y:966,t:1526418858780};\\\", \\\"{x:1549,y:966,t:1526418858795};\\\", \\\"{x:1548,y:966,t:1526418858819};\\\", \\\"{x:1544,y:966,t:1526418872797};\\\", \\\"{x:1537,y:966,t:1526418872810};\\\", \\\"{x:1512,y:960,t:1526418872827};\\\", \\\"{x:1478,y:950,t:1526418872843};\\\", \\\"{x:1422,y:930,t:1526418872859};\\\", \\\"{x:1380,y:920,t:1526418872876};\\\", \\\"{x:1358,y:913,t:1526418872893};\\\", \\\"{x:1342,y:907,t:1526418872909};\\\", \\\"{x:1322,y:899,t:1526418872927};\\\", \\\"{x:1301,y:889,t:1526418872944};\\\", \\\"{x:1274,y:874,t:1526418872960};\\\", \\\"{x:1225,y:851,t:1526418872977};\\\", \\\"{x:1168,y:831,t:1526418872994};\\\", \\\"{x:1079,y:804,t:1526418873009};\\\", \\\"{x:922,y:761,t:1526418873027};\\\", \\\"{x:820,y:733,t:1526418873043};\\\", \\\"{x:766,y:707,t:1526418873061};\\\", \\\"{x:736,y:691,t:1526418873076};\\\", \\\"{x:715,y:683,t:1526418873093};\\\", \\\"{x:693,y:670,t:1526418873111};\\\", \\\"{x:676,y:656,t:1526418873126};\\\", \\\"{x:666,y:641,t:1526418873143};\\\", \\\"{x:665,y:632,t:1526418873160};\\\", \\\"{x:665,y:625,t:1526418873178};\\\", \\\"{x:665,y:617,t:1526418873193};\\\", \\\"{x:664,y:606,t:1526418873210};\\\", \\\"{x:662,y:597,t:1526418873229};\\\", \\\"{x:658,y:586,t:1526418873245};\\\", \\\"{x:647,y:576,t:1526418873262};\\\", \\\"{x:634,y:567,t:1526418873279};\\\", \\\"{x:625,y:561,t:1526418873296};\\\", \\\"{x:624,y:560,t:1526418873346};\\\", \\\"{x:623,y:559,t:1526418873362};\\\", \\\"{x:618,y:559,t:1526418873378};\\\", \\\"{x:611,y:559,t:1526418873396};\\\", \\\"{x:597,y:559,t:1526418873412};\\\", \\\"{x:586,y:567,t:1526418873430};\\\", \\\"{x:572,y:573,t:1526418873446};\\\", \\\"{x:539,y:584,t:1526418873462};\\\", \\\"{x:491,y:599,t:1526418873479};\\\", \\\"{x:451,y:606,t:1526418873497};\\\", \\\"{x:420,y:612,t:1526418873513};\\\", \\\"{x:400,y:614,t:1526418873529};\\\", \\\"{x:386,y:614,t:1526418873547};\\\", \\\"{x:385,y:614,t:1526418873562};\\\", \\\"{x:384,y:614,t:1526418873618};\\\", \\\"{x:384,y:613,t:1526418873642};\\\", \\\"{x:384,y:612,t:1526418873650};\\\", \\\"{x:384,y:611,t:1526418873738};\\\", \\\"{x:384,y:610,t:1526418873746};\\\", \\\"{x:384,y:609,t:1526418873778};\\\", \\\"{x:384,y:607,t:1526418873802};\\\", \\\"{x:382,y:604,t:1526418873814};\\\", \\\"{x:378,y:596,t:1526418873830};\\\", \\\"{x:374,y:588,t:1526418873846};\\\", \\\"{x:367,y:582,t:1526418873863};\\\", \\\"{x:355,y:574,t:1526418873879};\\\", \\\"{x:333,y:567,t:1526418873896};\\\", \\\"{x:308,y:561,t:1526418873914};\\\", \\\"{x:288,y:557,t:1526418873929};\\\", \\\"{x:273,y:557,t:1526418873946};\\\", \\\"{x:263,y:557,t:1526418873962};\\\", \\\"{x:256,y:557,t:1526418873980};\\\", \\\"{x:250,y:557,t:1526418873996};\\\", \\\"{x:249,y:557,t:1526418874013};\\\", \\\"{x:248,y:557,t:1526418874099};\\\", \\\"{x:246,y:557,t:1526418874123};\\\", \\\"{x:245,y:561,t:1526418874131};\\\", \\\"{x:244,y:566,t:1526418874148};\\\", \\\"{x:239,y:583,t:1526418874163};\\\", \\\"{x:233,y:597,t:1526418874180};\\\", \\\"{x:224,y:622,t:1526418874196};\\\", \\\"{x:214,y:661,t:1526418874214};\\\", \\\"{x:190,y:712,t:1526418874231};\\\", \\\"{x:171,y:739,t:1526418874246};\\\", \\\"{x:158,y:751,t:1526418874263};\\\", \\\"{x:151,y:754,t:1526418874279};\\\", \\\"{x:147,y:755,t:1526418874297};\\\", \\\"{x:146,y:755,t:1526418874313};\\\", \\\"{x:145,y:755,t:1526418874370};\\\", \\\"{x:145,y:750,t:1526418874386};\\\", \\\"{x:147,y:740,t:1526418874397};\\\", \\\"{x:186,y:709,t:1526418874413};\\\", \\\"{x:272,y:654,t:1526418874431};\\\", \\\"{x:385,y:599,t:1526418874449};\\\", \\\"{x:524,y:554,t:1526418874465};\\\", \\\"{x:648,y:522,t:1526418874480};\\\", \\\"{x:749,y:502,t:1526418874497};\\\", \\\"{x:832,y:493,t:1526418874513};\\\", \\\"{x:890,y:491,t:1526418874530};\\\", \\\"{x:905,y:491,t:1526418874546};\\\", \\\"{x:908,y:491,t:1526418874562};\\\", \\\"{x:910,y:490,t:1526418874610};\\\", \\\"{x:907,y:491,t:1526418874707};\\\", \\\"{x:900,y:496,t:1526418874714};\\\", \\\"{x:881,y:511,t:1526418874731};\\\", \\\"{x:863,y:522,t:1526418874747};\\\", \\\"{x:847,y:531,t:1526418874764};\\\", \\\"{x:833,y:541,t:1526418874780};\\\", \\\"{x:817,y:553,t:1526418874797};\\\", \\\"{x:802,y:565,t:1526418874815};\\\", \\\"{x:795,y:569,t:1526418874830};\\\", \\\"{x:794,y:570,t:1526418874846};\\\", \\\"{x:795,y:570,t:1526418874873};\\\", \\\"{x:800,y:570,t:1526418874882};\\\", \\\"{x:804,y:570,t:1526418874897};\\\", \\\"{x:823,y:567,t:1526418874914};\\\", \\\"{x:837,y:562,t:1526418874931};\\\", \\\"{x:857,y:556,t:1526418874947};\\\", \\\"{x:869,y:553,t:1526418874965};\\\", \\\"{x:871,y:552,t:1526418874980};\\\", \\\"{x:870,y:549,t:1526418875075};\\\", \\\"{x:866,y:544,t:1526418875083};\\\", \\\"{x:862,y:539,t:1526418875097};\\\", \\\"{x:849,y:520,t:1526418875115};\\\", \\\"{x:841,y:508,t:1526418875131};\\\", \\\"{x:834,y:499,t:1526418875146};\\\", \\\"{x:831,y:495,t:1526418875164};\\\", \\\"{x:830,y:495,t:1526418876035};\\\", \\\"{x:830,y:496,t:1526418876051};\\\", \\\"{x:828,y:497,t:1526418876075};\\\", \\\"{x:828,y:498,t:1526418876083};\\\", \\\"{x:827,y:501,t:1526418876098};\\\", \\\"{x:824,y:505,t:1526418876115};\\\", \\\"{x:822,y:509,t:1526418876131};\\\", \\\"{x:819,y:515,t:1526418876149};\\\", \\\"{x:816,y:522,t:1526418876166};\\\", \\\"{x:811,y:532,t:1526418876182};\\\", \\\"{x:806,y:545,t:1526418876198};\\\", \\\"{x:797,y:564,t:1526418876216};\\\", \\\"{x:783,y:587,t:1526418876231};\\\", \\\"{x:766,y:612,t:1526418876250};\\\", \\\"{x:750,y:633,t:1526418876265};\\\", \\\"{x:730,y:651,t:1526418876281};\\\", \\\"{x:698,y:674,t:1526418876297};\\\", \\\"{x:668,y:692,t:1526418876315};\\\", \\\"{x:643,y:707,t:1526418876332};\\\", \\\"{x:628,y:717,t:1526418876348};\\\", \\\"{x:616,y:722,t:1526418876365};\\\", \\\"{x:607,y:725,t:1526418876382};\\\", \\\"{x:600,y:726,t:1526418876398};\\\", \\\"{x:592,y:729,t:1526418876415};\\\", \\\"{x:589,y:731,t:1526418876432};\\\", \\\"{x:586,y:731,t:1526418876515};\\\", \\\"{x:585,y:732,t:1526418876532};\\\", \\\"{x:581,y:732,t:1526418876549};\\\", \\\"{x:579,y:733,t:1526418876565};\\\", \\\"{x:578,y:733,t:1526418876582};\\\", \\\"{x:576,y:733,t:1526418876600};\\\", \\\"{x:573,y:734,t:1526418876787};\\\", \\\"{x:571,y:734,t:1526418876799};\\\", \\\"{x:560,y:735,t:1526418876818};\\\", \\\"{x:553,y:737,t:1526418876832};\\\", \\\"{x:540,y:740,t:1526418876848};\\\", \\\"{x:526,y:742,t:1526418876865};\\\", \\\"{x:504,y:747,t:1526418876881};\\\", \\\"{x:495,y:752,t:1526418876898};\\\", \\\"{x:492,y:752,t:1526418876915};\\\", \\\"{x:491,y:753,t:1526418876932};\\\", \\\"{x:490,y:753,t:1526418877315};\\\", \\\"{x:496,y:753,t:1526418877331};\\\", \\\"{x:508,y:753,t:1526418877338};\\\", \\\"{x:520,y:753,t:1526418877350};\\\", \\\"{x:549,y:749,t:1526418877367};\\\", \\\"{x:564,y:747,t:1526418877383};\\\", \\\"{x:567,y:747,t:1526418877400};\\\", \\\"{x:568,y:747,t:1526418877416};\\\", \\\"{x:567,y:747,t:1526418877595};\\\", \\\"{x:561,y:749,t:1526418877603};\\\", \\\"{x:552,y:752,t:1526418877617};\\\", \\\"{x:537,y:756,t:1526418877633};\\\", \\\"{x:519,y:760,t:1526418877650};\\\", \\\"{x:511,y:761,t:1526418877667};\\\", \\\"{x:508,y:761,t:1526418877682};\\\", \\\"{x:507,y:760,t:1526418877867};\\\", \\\"{x:509,y:750,t:1526418877884};\\\", \\\"{x:512,y:741,t:1526418877899};\\\", \\\"{x:513,y:739,t:1526418877916};\\\", \\\"{x:514,y:738,t:1526418877932};\\\", \\\"{x:514,y:736,t:1526418877949};\\\", \\\"{x:513,y:737,t:1526418878203};\\\", \\\"{x:512,y:737,t:1526418878217};\\\", \\\"{x:511,y:738,t:1526418878234};\\\" ] }, { \\\"rt\\\": 49454, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 841138, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:738,t:1526418907470};\\\", \\\"{x:509,y:738,t:1526418907487};\\\", \\\"{x:508,y:736,t:1526418907493};\\\", \\\"{x:508,y:735,t:1526418907509};\\\", \\\"{x:506,y:733,t:1526418907526};\\\", \\\"{x:504,y:731,t:1526418907541};\\\", \\\"{x:503,y:730,t:1526418907581};\\\", \\\"{x:503,y:729,t:1526418907589};\\\", \\\"{x:501,y:729,t:1526418907605};\\\", \\\"{x:499,y:728,t:1526418907619};\\\", \\\"{x:494,y:727,t:1526418907637};\\\", \\\"{x:484,y:727,t:1526418907653};\\\", \\\"{x:483,y:726,t:1526418909319};\\\", \\\"{x:483,y:725,t:1526418909350};\\\", \\\"{x:482,y:725,t:1526418909374};\\\", \\\"{x:481,y:725,t:1526418914446};\\\", \\\"{x:481,y:724,t:1526418914910};\\\", \\\"{x:481,y:723,t:1526418915110};\\\", \\\"{x:481,y:722,t:1526418915166};\\\", \\\"{x:484,y:722,t:1526418923038};\\\", \\\"{x:490,y:722,t:1526418923047};\\\", \\\"{x:501,y:721,t:1526418923064};\\\", \\\"{x:519,y:721,t:1526418923081};\\\", \\\"{x:540,y:719,t:1526418923097};\\\", \\\"{x:564,y:719,t:1526418923114};\\\", \\\"{x:584,y:721,t:1526418923130};\\\", \\\"{x:606,y:728,t:1526418923147};\\\", \\\"{x:618,y:731,t:1526418923164};\\\", \\\"{x:631,y:738,t:1526418923180};\\\", \\\"{x:645,y:744,t:1526418923197};\\\", \\\"{x:676,y:756,t:1526418923213};\\\", \\\"{x:694,y:764,t:1526418923230};\\\", \\\"{x:727,y:770,t:1526418923246};\\\", \\\"{x:737,y:778,t:1526418923264};\\\", \\\"{x:789,y:784,t:1526418923280};\\\", \\\"{x:866,y:795,t:1526418923297};\\\", \\\"{x:963,y:808,t:1526418923314};\\\", \\\"{x:1064,y:826,t:1526418923330};\\\", \\\"{x:1147,y:837,t:1526418923347};\\\", \\\"{x:1236,y:851,t:1526418923364};\\\", \\\"{x:1320,y:865,t:1526418923380};\\\", \\\"{x:1383,y:877,t:1526418923397};\\\", \\\"{x:1439,y:886,t:1526418923414};\\\", \\\"{x:1473,y:898,t:1526418923430};\\\", \\\"{x:1498,y:906,t:1526418923447};\\\", \\\"{x:1508,y:908,t:1526418923464};\\\", \\\"{x:1511,y:909,t:1526418923481};\\\", \\\"{x:1513,y:909,t:1526418923501};\\\", \\\"{x:1517,y:911,t:1526418923514};\\\", \\\"{x:1530,y:920,t:1526418923530};\\\", \\\"{x:1546,y:929,t:1526418923547};\\\", \\\"{x:1558,y:934,t:1526418923564};\\\", \\\"{x:1563,y:936,t:1526418923580};\\\", \\\"{x:1563,y:937,t:1526418923597};\\\", \\\"{x:1560,y:941,t:1526418923614};\\\", \\\"{x:1552,y:944,t:1526418923630};\\\", \\\"{x:1544,y:947,t:1526418923647};\\\", \\\"{x:1538,y:949,t:1526418923664};\\\", \\\"{x:1533,y:950,t:1526418923680};\\\", \\\"{x:1526,y:951,t:1526418923697};\\\", \\\"{x:1518,y:951,t:1526418923714};\\\", \\\"{x:1512,y:951,t:1526418923730};\\\", \\\"{x:1507,y:951,t:1526418923748};\\\", \\\"{x:1504,y:953,t:1526418923764};\\\", \\\"{x:1503,y:953,t:1526418923790};\\\", \\\"{x:1502,y:953,t:1526418923798};\\\", \\\"{x:1501,y:953,t:1526418923814};\\\", \\\"{x:1499,y:953,t:1526418923830};\\\", \\\"{x:1497,y:954,t:1526418923847};\\\", \\\"{x:1494,y:959,t:1526418923865};\\\", \\\"{x:1493,y:964,t:1526418923881};\\\", \\\"{x:1492,y:968,t:1526418923897};\\\", \\\"{x:1490,y:970,t:1526418923915};\\\", \\\"{x:1490,y:971,t:1526418923930};\\\", \\\"{x:1489,y:972,t:1526418923947};\\\", \\\"{x:1488,y:972,t:1526418924022};\\\", \\\"{x:1486,y:972,t:1526418924030};\\\", \\\"{x:1483,y:972,t:1526418924047};\\\", \\\"{x:1480,y:972,t:1526418924064};\\\", \\\"{x:1478,y:972,t:1526418924080};\\\", \\\"{x:1474,y:971,t:1526418924097};\\\", \\\"{x:1474,y:969,t:1526418924166};\\\", \\\"{x:1474,y:967,t:1526418924182};\\\", \\\"{x:1474,y:966,t:1526418924197};\\\", \\\"{x:1474,y:965,t:1526418924214};\\\", \\\"{x:1473,y:962,t:1526418924230};\\\", \\\"{x:1473,y:961,t:1526418924270};\\\", \\\"{x:1473,y:960,t:1526418924287};\\\", \\\"{x:1473,y:959,t:1526418924350};\\\", \\\"{x:1474,y:959,t:1526418924365};\\\", \\\"{x:1476,y:959,t:1526418924438};\\\", \\\"{x:1477,y:959,t:1526418924670};\\\", \\\"{x:1479,y:959,t:1526418924694};\\\", \\\"{x:1480,y:959,t:1526418924702};\\\", \\\"{x:1482,y:959,t:1526418924714};\\\", \\\"{x:1483,y:959,t:1526418924731};\\\", \\\"{x:1465,y:959,t:1526418939655};\\\", \\\"{x:1361,y:938,t:1526418939662};\\\", \\\"{x:1066,y:857,t:1526418939679};\\\", \\\"{x:774,y:777,t:1526418939695};\\\", \\\"{x:571,y:705,t:1526418939711};\\\", \\\"{x:450,y:652,t:1526418939728};\\\", \\\"{x:351,y:614,t:1526418939745};\\\", \\\"{x:258,y:574,t:1526418939761};\\\", \\\"{x:179,y:532,t:1526418939778};\\\", \\\"{x:156,y:510,t:1526418939796};\\\", \\\"{x:151,y:499,t:1526418939812};\\\", \\\"{x:142,y:479,t:1526418939844};\\\", \\\"{x:140,y:478,t:1526418939855};\\\", \\\"{x:139,y:477,t:1526418939872};\\\", \\\"{x:138,y:477,t:1526418939892};\\\", \\\"{x:136,y:477,t:1526418939909};\\\", \\\"{x:134,y:478,t:1526418939924};\\\", \\\"{x:134,y:481,t:1526418939938};\\\", \\\"{x:140,y:497,t:1526418939956};\\\", \\\"{x:151,y:516,t:1526418939972};\\\", \\\"{x:160,y:533,t:1526418939989};\\\", \\\"{x:161,y:543,t:1526418940006};\\\", \\\"{x:161,y:559,t:1526418940022};\\\", \\\"{x:164,y:577,t:1526418940039};\\\", \\\"{x:170,y:588,t:1526418940056};\\\", \\\"{x:174,y:593,t:1526418940072};\\\", \\\"{x:177,y:595,t:1526418940088};\\\", \\\"{x:177,y:596,t:1526418940105};\\\", \\\"{x:177,y:593,t:1526418940238};\\\", \\\"{x:177,y:590,t:1526418940245};\\\", \\\"{x:177,y:588,t:1526418940256};\\\", \\\"{x:177,y:583,t:1526418940272};\\\", \\\"{x:178,y:578,t:1526418940290};\\\", \\\"{x:178,y:570,t:1526418940306};\\\", \\\"{x:177,y:564,t:1526418940323};\\\", \\\"{x:176,y:562,t:1526418940338};\\\", \\\"{x:176,y:561,t:1526418940725};\\\", \\\"{x:178,y:561,t:1526418940764};\\\", \\\"{x:180,y:561,t:1526418940773};\\\", \\\"{x:184,y:561,t:1526418940789};\\\", \\\"{x:204,y:561,t:1526418940807};\\\", \\\"{x:242,y:561,t:1526418940822};\\\", \\\"{x:298,y:561,t:1526418940839};\\\", \\\"{x:373,y:561,t:1526418940857};\\\", \\\"{x:438,y:562,t:1526418940873};\\\", \\\"{x:514,y:567,t:1526418940890};\\\", \\\"{x:585,y:573,t:1526418940906};\\\", \\\"{x:635,y:577,t:1526418940923};\\\", \\\"{x:657,y:581,t:1526418940939};\\\", \\\"{x:662,y:582,t:1526418940956};\\\", \\\"{x:664,y:583,t:1526418940972};\\\", \\\"{x:664,y:584,t:1526418941053};\\\", \\\"{x:661,y:584,t:1526418941069};\\\", \\\"{x:661,y:585,t:1526418941077};\\\", \\\"{x:660,y:586,t:1526418941101};\\\", \\\"{x:660,y:587,t:1526418941318};\\\", \\\"{x:659,y:587,t:1526418941366};\\\", \\\"{x:657,y:590,t:1526418941374};\\\", \\\"{x:647,y:603,t:1526418941390};\\\", \\\"{x:635,y:619,t:1526418941408};\\\", \\\"{x:619,y:636,t:1526418941423};\\\", \\\"{x:608,y:646,t:1526418941440};\\\", \\\"{x:604,y:649,t:1526418941456};\\\", \\\"{x:606,y:649,t:1526418941476};\\\", \\\"{x:627,y:636,t:1526418941490};\\\", \\\"{x:714,y:609,t:1526418941507};\\\", \\\"{x:716,y:607,t:1526418941524};\\\", \\\"{x:716,y:606,t:1526418941540};\\\", \\\"{x:718,y:603,t:1526418941556};\\\", \\\"{x:741,y:583,t:1526418941574};\\\", \\\"{x:747,y:576,t:1526418941591};\\\", \\\"{x:749,y:575,t:1526418941606};\\\", \\\"{x:749,y:574,t:1526418941629};\\\", \\\"{x:745,y:574,t:1526418941641};\\\", \\\"{x:727,y:581,t:1526418941658};\\\", \\\"{x:691,y:591,t:1526418941673};\\\", \\\"{x:671,y:600,t:1526418941690};\\\", \\\"{x:662,y:602,t:1526418941706};\\\", \\\"{x:661,y:601,t:1526418941724};\\\", \\\"{x:677,y:583,t:1526418941740};\\\", \\\"{x:686,y:574,t:1526418941758};\\\", \\\"{x:739,y:556,t:1526418941775};\\\", \\\"{x:781,y:546,t:1526418941790};\\\", \\\"{x:816,y:539,t:1526418941807};\\\", \\\"{x:853,y:535,t:1526418941823};\\\", \\\"{x:876,y:531,t:1526418941841};\\\", \\\"{x:888,y:531,t:1526418941857};\\\", \\\"{x:890,y:530,t:1526418941873};\\\", \\\"{x:891,y:530,t:1526418941890};\\\", \\\"{x:892,y:530,t:1526418942005};\\\", \\\"{x:893,y:530,t:1526418942013};\\\", \\\"{x:894,y:530,t:1526418942077};\\\", \\\"{x:896,y:529,t:1526418942093};\\\", \\\"{x:897,y:527,t:1526418942108};\\\", \\\"{x:898,y:526,t:1526418942124};\\\", \\\"{x:901,y:525,t:1526418942140};\\\", \\\"{x:902,y:524,t:1526418942197};\\\", \\\"{x:896,y:524,t:1526418944265};\\\", \\\"{x:886,y:524,t:1526418944281};\\\", \\\"{x:857,y:522,t:1526418944297};\\\", \\\"{x:842,y:519,t:1526418944313};\\\", \\\"{x:836,y:518,t:1526418944329};\\\", \\\"{x:832,y:517,t:1526418944346};\\\", \\\"{x:831,y:516,t:1526418944363};\\\", \\\"{x:830,y:515,t:1526418944379};\\\", \\\"{x:830,y:514,t:1526418944396};\\\", \\\"{x:829,y:514,t:1526418944704};\\\", \\\"{x:823,y:517,t:1526418944712};\\\", \\\"{x:806,y:533,t:1526418944729};\\\", \\\"{x:787,y:552,t:1526418944747};\\\", \\\"{x:769,y:576,t:1526418944763};\\\", \\\"{x:741,y:604,t:1526418944781};\\\", \\\"{x:684,y:646,t:1526418944796};\\\", \\\"{x:607,y:695,t:1526418944813};\\\", \\\"{x:548,y:735,t:1526418944830};\\\", \\\"{x:524,y:753,t:1526418944846};\\\", \\\"{x:514,y:760,t:1526418944863};\\\", \\\"{x:513,y:761,t:1526418944879};\\\", \\\"{x:509,y:764,t:1526418944895};\\\", \\\"{x:512,y:761,t:1526418946912};\\\", \\\"{x:536,y:752,t:1526418946920};\\\", \\\"{x:576,y:735,t:1526418946931};\\\", \\\"{x:681,y:692,t:1526418946948};\\\", \\\"{x:787,y:655,t:1526418946965};\\\", \\\"{x:923,y:610,t:1526418946981};\\\", \\\"{x:1071,y:553,t:1526418946998};\\\", \\\"{x:1210,y:507,t:1526418947015};\\\", \\\"{x:1297,y:490,t:1526418947031};\\\", \\\"{x:1337,y:479,t:1526418947048};\\\", \\\"{x:1339,y:478,t:1526418947065};\\\", \\\"{x:1340,y:477,t:1526418947137};\\\", \\\"{x:1338,y:477,t:1526418947148};\\\", \\\"{x:1330,y:475,t:1526418947165};\\\", \\\"{x:1301,y:474,t:1526418947181};\\\", \\\"{x:1203,y:474,t:1526418947198};\\\", \\\"{x:1074,y:483,t:1526418947216};\\\", \\\"{x:963,y:501,t:1526418947231};\\\", \\\"{x:885,y:512,t:1526418947248};\\\", \\\"{x:836,y:512,t:1526418947264};\\\", \\\"{x:835,y:512,t:1526418947282};\\\", \\\"{x:835,y:514,t:1526418947298};\\\", \\\"{x:837,y:523,t:1526418947316};\\\", \\\"{x:840,y:534,t:1526418947331};\\\", \\\"{x:841,y:537,t:1526418947349};\\\", \\\"{x:842,y:540,t:1526418947365};\\\", \\\"{x:844,y:540,t:1526418947385};\\\", \\\"{x:846,y:542,t:1526418947399};\\\", \\\"{x:861,y:550,t:1526418947415};\\\", \\\"{x:879,y:559,t:1526418947434};\\\", \\\"{x:887,y:561,t:1526418947448};\\\", \\\"{x:889,y:563,t:1526418947465};\\\", \\\"{x:891,y:563,t:1526418947482};\\\", \\\"{x:892,y:563,t:1526418947498};\\\", \\\"{x:892,y:564,t:1526418947881};\\\", \\\"{x:898,y:576,t:1526418951818};\\\", \\\"{x:930,y:630,t:1526418951835};\\\", \\\"{x:945,y:673,t:1526418951853};\\\", \\\"{x:950,y:695,t:1526418951870};\\\", \\\"{x:954,y:715,t:1526418951886};\\\", \\\"{x:963,y:735,t:1526418951903};\\\", \\\"{x:971,y:746,t:1526418951920};\\\", \\\"{x:977,y:750,t:1526418951936};\\\", \\\"{x:978,y:750,t:1526418951993};\\\", \\\"{x:979,y:747,t:1526418952119};\\\", \\\"{x:981,y:740,t:1526418952136};\\\", \\\"{x:983,y:729,t:1526418952152};\\\", \\\"{x:985,y:720,t:1526418952169};\\\", \\\"{x:987,y:717,t:1526418952185};\\\", \\\"{x:987,y:716,t:1526418952201};\\\", \\\"{x:986,y:715,t:1526418952273};\\\", \\\"{x:986,y:714,t:1526418952329};\\\", \\\"{x:985,y:714,t:1526418952337};\\\", \\\"{x:985,y:713,t:1526418952352};\\\", \\\"{x:985,y:708,t:1526418952369};\\\", \\\"{x:983,y:699,t:1526418952384};\\\", \\\"{x:983,y:694,t:1526418952403};\\\", \\\"{x:982,y:691,t:1526418952420};\\\", \\\"{x:982,y:690,t:1526418952440};\\\", \\\"{x:981,y:689,t:1526418952456};\\\", \\\"{x:981,y:688,t:1526418952470};\\\", \\\"{x:980,y:688,t:1526418952496};\\\", \\\"{x:980,y:684,t:1526418954969};\\\", \\\"{x:982,y:659,t:1526418954988};\\\", \\\"{x:988,y:614,t:1526418955005};\\\", \\\"{x:988,y:555,t:1526418955022};\\\", \\\"{x:976,y:469,t:1526418955038};\\\", \\\"{x:950,y:369,t:1526418955054};\\\", \\\"{x:926,y:276,t:1526418955071};\\\", \\\"{x:912,y:166,t:1526418955088};\\\", \\\"{x:911,y:132,t:1526418955104};\\\", \\\"{x:911,y:105,t:1526418955122};\\\", \\\"{x:909,y:80,t:1526418955139};\\\", \\\"{x:905,y:64,t:1526418955154};\\\", \\\"{x:903,y:57,t:1526418955171};\\\", \\\"{x:903,y:56,t:1526418955188};\\\", \\\"{x:902,y:57,t:1526418955249};\\\", \\\"{x:900,y:66,t:1526418955256};\\\", \\\"{x:897,y:77,t:1526418955272};\\\", \\\"{x:888,y:104,t:1526418955289};\\\", \\\"{x:883,y:114,t:1526418955306};\\\", \\\"{x:880,y:129,t:1526418955321};\\\", \\\"{x:880,y:154,t:1526418955338};\\\", \\\"{x:880,y:179,t:1526418955356};\\\", \\\"{x:880,y:198,t:1526418955371};\\\", \\\"{x:881,y:203,t:1526418955388};\\\", \\\"{x:881,y:204,t:1526418955406};\\\", \\\"{x:881,y:205,t:1526418955422};\\\", \\\"{x:881,y:206,t:1526418955439};\\\", \\\"{x:881,y:207,t:1526418955456};\\\", \\\"{x:881,y:209,t:1526418955472};\\\", \\\"{x:881,y:217,t:1526418955489};\\\", \\\"{x:881,y:227,t:1526418955506};\\\", \\\"{x:881,y:233,t:1526418955522};\\\", \\\"{x:881,y:235,t:1526418955539};\\\", \\\"{x:881,y:236,t:1526418955556};\\\", \\\"{x:880,y:236,t:1526418955571};\\\", \\\"{x:879,y:236,t:1526418956337};\\\", \\\"{x:878,y:236,t:1526418956360};\\\", \\\"{x:876,y:237,t:1526418956373};\\\", \\\"{x:875,y:237,t:1526418956390};\\\", \\\"{x:872,y:238,t:1526418956405};\\\", \\\"{x:870,y:238,t:1526418956423};\\\", \\\"{x:867,y:238,t:1526418956440};\\\", \\\"{x:863,y:240,t:1526418956456};\\\", \\\"{x:861,y:240,t:1526418956473};\\\", \\\"{x:860,y:240,t:1526418956528};\\\", \\\"{x:859,y:240,t:1526418956544};\\\", \\\"{x:858,y:240,t:1526418956555};\\\", \\\"{x:855,y:240,t:1526418956572};\\\", \\\"{x:854,y:240,t:1526418956608};\\\", \\\"{x:853,y:241,t:1526418956624};\\\", \\\"{x:852,y:243,t:1526418956639};\\\", \\\"{x:852,y:270,t:1526418956657};\\\", \\\"{x:860,y:301,t:1526418956673};\\\", \\\"{x:869,y:346,t:1526418956689};\\\", \\\"{x:881,y:384,t:1526418956706};\\\", \\\"{x:886,y:403,t:1526418956722};\\\", \\\"{x:890,y:416,t:1526418956739};\\\", \\\"{x:891,y:421,t:1526418956756};\\\", \\\"{x:891,y:427,t:1526418956773};\\\", \\\"{x:891,y:433,t:1526418956790};\\\", \\\"{x:891,y:437,t:1526418956807};\\\", \\\"{x:891,y:439,t:1526418956823};\\\", \\\"{x:890,y:443,t:1526418956840};\\\", \\\"{x:889,y:447,t:1526418956856};\\\", \\\"{x:888,y:450,t:1526418956880};\\\", \\\"{x:887,y:450,t:1526418956890};\\\", \\\"{x:886,y:452,t:1526418956907};\\\", \\\"{x:882,y:461,t:1526418956923};\\\", \\\"{x:878,y:474,t:1526418956940};\\\", \\\"{x:877,y:482,t:1526418956957};\\\", \\\"{x:874,y:486,t:1526418956975};\\\", \\\"{x:873,y:490,t:1526418956990};\\\", \\\"{x:870,y:497,t:1526418957007};\\\", \\\"{x:869,y:505,t:1526418957024};\\\", \\\"{x:868,y:514,t:1526418957040};\\\", \\\"{x:868,y:520,t:1526418957057};\\\", \\\"{x:868,y:521,t:1526418957074};\\\", \\\"{x:868,y:522,t:1526418957090};\\\", \\\"{x:868,y:523,t:1526418957106};\\\", \\\"{x:868,y:524,t:1526418957129};\\\", \\\"{x:866,y:524,t:1526418957337};\\\", \\\"{x:866,y:523,t:1526418957344};\\\", \\\"{x:866,y:521,t:1526418957357};\\\", \\\"{x:866,y:516,t:1526418957374};\\\", \\\"{x:866,y:507,t:1526418957390};\\\", \\\"{x:866,y:496,t:1526418957408};\\\", \\\"{x:866,y:491,t:1526418957424};\\\", \\\"{x:866,y:488,t:1526418957441};\\\", \\\"{x:866,y:486,t:1526418957617};\\\", \\\"{x:866,y:484,t:1526418957624};\\\", \\\"{x:866,y:480,t:1526418957640};\\\", \\\"{x:867,y:473,t:1526418957658};\\\", \\\"{x:867,y:472,t:1526418957753};\\\", \\\"{x:867,y:474,t:1526418958393};\\\", \\\"{x:867,y:476,t:1526418958408};\\\", \\\"{x:867,y:477,t:1526418958425};\\\", \\\"{x:867,y:479,t:1526418959081};\\\", \\\"{x:868,y:485,t:1526418959092};\\\", \\\"{x:872,y:506,t:1526418959109};\\\", \\\"{x:873,y:526,t:1526418959125};\\\", \\\"{x:877,y:546,t:1526418959142};\\\", \\\"{x:881,y:568,t:1526418959159};\\\", \\\"{x:883,y:593,t:1526418959175};\\\", \\\"{x:887,y:613,t:1526418959192};\\\", \\\"{x:890,y:636,t:1526418959208};\\\", \\\"{x:892,y:647,t:1526418959225};\\\", \\\"{x:892,y:658,t:1526418959242};\\\", \\\"{x:893,y:664,t:1526418959259};\\\", \\\"{x:893,y:670,t:1526418959275};\\\", \\\"{x:893,y:671,t:1526418959292};\\\", \\\"{x:894,y:672,t:1526418959309};\\\", \\\"{x:894,y:673,t:1526418959325};\\\", \\\"{x:894,y:674,t:1526418959342};\\\", \\\"{x:894,y:676,t:1526418959358};\\\", \\\"{x:894,y:677,t:1526418959376};\\\", \\\"{x:894,y:679,t:1526418959392};\\\", \\\"{x:894,y:680,t:1526418959408};\\\", \\\"{x:894,y:681,t:1526418959440};\\\", \\\"{x:894,y:684,t:1526418959448};\\\", \\\"{x:894,y:687,t:1526418959459};\\\", \\\"{x:894,y:691,t:1526418959476};\\\", \\\"{x:894,y:693,t:1526418959491};\\\", \\\"{x:894,y:694,t:1526418959640};\\\", \\\"{x:894,y:695,t:1526418959648};\\\", \\\"{x:893,y:696,t:1526418959658};\\\", \\\"{x:893,y:697,t:1526418959691};\\\", \\\"{x:893,y:698,t:1526418959713};\\\", \\\"{x:893,y:699,t:1526418959726};\\\", \\\"{x:893,y:701,t:1526418959742};\\\", \\\"{x:893,y:703,t:1526418959759};\\\", \\\"{x:893,y:705,t:1526418959775};\\\", \\\"{x:893,y:706,t:1526418959792};\\\", \\\"{x:893,y:708,t:1526418959833};\\\", \\\"{x:893,y:709,t:1526418959841};\\\", \\\"{x:893,y:713,t:1526418959859};\\\", \\\"{x:893,y:714,t:1526418959875};\\\", \\\"{x:893,y:715,t:1526418959892};\\\", \\\"{x:893,y:716,t:1526418959909};\\\", \\\"{x:894,y:719,t:1526418959926};\\\", \\\"{x:896,y:724,t:1526418959943};\\\", \\\"{x:896,y:731,t:1526418959959};\\\", \\\"{x:897,y:735,t:1526418959976};\\\", \\\"{x:897,y:738,t:1526418959993};\\\", \\\"{x:897,y:740,t:1526418960009};\\\", \\\"{x:897,y:742,t:1526418960033};\\\", \\\"{x:897,y:743,t:1526418960145};\\\", \\\"{x:897,y:744,t:1526418960159};\\\", \\\"{x:897,y:745,t:1526418960176};\\\", \\\"{x:896,y:746,t:1526418960193};\\\", \\\"{x:896,y:745,t:1526418960425};\\\", \\\"{x:896,y:748,t:1526418960600};\\\", \\\"{x:897,y:754,t:1526418960610};\\\", \\\"{x:899,y:760,t:1526418960627};\\\", \\\"{x:899,y:763,t:1526418960643};\\\", \\\"{x:899,y:768,t:1526418960660};\\\", \\\"{x:900,y:780,t:1526418960677};\\\", \\\"{x:906,y:794,t:1526418960692};\\\", \\\"{x:909,y:807,t:1526418960710};\\\", \\\"{x:909,y:814,t:1526418960727};\\\", \\\"{x:909,y:817,t:1526418960743};\\\", \\\"{x:909,y:818,t:1526418960760};\\\", \\\"{x:909,y:819,t:1526418960777};\\\", \\\"{x:909,y:820,t:1526418961137};\\\", \\\"{x:909,y:821,t:1526418961144};\\\", \\\"{x:909,y:822,t:1526418961160};\\\", \\\"{x:909,y:824,t:1526418961176};\\\", \\\"{x:908,y:825,t:1526418961241};\\\", \\\"{x:908,y:824,t:1526418961362};\\\", \\\"{x:908,y:822,t:1526418961377};\\\", \\\"{x:908,y:819,t:1526418961394};\\\", \\\"{x:908,y:817,t:1526418961410};\\\", \\\"{x:908,y:814,t:1526418961427};\\\", \\\"{x:908,y:811,t:1526418961444};\\\", \\\"{x:911,y:803,t:1526418961460};\\\", \\\"{x:913,y:793,t:1526418961478};\\\", \\\"{x:916,y:778,t:1526418961494};\\\", \\\"{x:919,y:763,t:1526418961511};\\\", \\\"{x:922,y:752,t:1526418961527};\\\", \\\"{x:925,y:741,t:1526418961545};\\\", \\\"{x:927,y:730,t:1526418961561};\\\", \\\"{x:928,y:726,t:1526418961577};\\\", \\\"{x:929,y:723,t:1526418961594};\\\", \\\"{x:930,y:723,t:1526418961849};\\\", \\\"{x:930,y:728,t:1526418962401};\\\", \\\"{x:929,y:736,t:1526418962411};\\\", \\\"{x:928,y:762,t:1526418962428};\\\", \\\"{x:928,y:790,t:1526418962445};\\\", \\\"{x:928,y:815,t:1526418962461};\\\", \\\"{x:924,y:839,t:1526418962478};\\\", \\\"{x:922,y:869,t:1526418962495};\\\", \\\"{x:916,y:897,t:1526418962511};\\\", \\\"{x:905,y:921,t:1526418962528};\\\", \\\"{x:901,y:927,t:1526418962544};\\\", \\\"{x:898,y:932,t:1526418962561};\\\", \\\"{x:896,y:933,t:1526418962578};\\\", \\\"{x:895,y:935,t:1526418962595};\\\", \\\"{x:894,y:935,t:1526418962611};\\\", \\\"{x:892,y:935,t:1526418962628};\\\", \\\"{x:889,y:935,t:1526418962645};\\\", \\\"{x:887,y:935,t:1526418962665};\\\", \\\"{x:886,y:935,t:1526418962680};\\\", \\\"{x:885,y:935,t:1526418962704};\\\", \\\"{x:884,y:935,t:1526418962713};\\\", \\\"{x:883,y:935,t:1526418962817};\\\", \\\"{x:882,y:936,t:1526418962833};\\\", \\\"{x:881,y:936,t:1526418962846};\\\", \\\"{x:880,y:936,t:1526418962905};\\\", \\\"{x:879,y:936,t:1526418962913};\\\", \\\"{x:878,y:937,t:1526418962929};\\\", \\\"{x:877,y:937,t:1526418962945};\\\", \\\"{x:877,y:938,t:1526418962953};\\\", \\\"{x:876,y:938,t:1526418962978};\\\", \\\"{x:876,y:938,t:1526418963048};\\\", \\\"{x:876,y:941,t:1526418963201};\\\", \\\"{x:876,y:950,t:1526418963213};\\\", \\\"{x:891,y:970,t:1526418963228};\\\", \\\"{x:902,y:984,t:1526418963245};\\\", \\\"{x:911,y:992,t:1526418963262};\\\", \\\"{x:916,y:994,t:1526418963279};\\\", \\\"{x:917,y:994,t:1526418963295};\\\", \\\"{x:912,y:989,t:1526418963361};\\\", \\\"{x:903,y:979,t:1526418963369};\\\", \\\"{x:889,y:968,t:1526418963380};\\\", \\\"{x:869,y:949,t:1526418963396};\\\", \\\"{x:856,y:941,t:1526418963413};\\\", \\\"{x:844,y:934,t:1526418963429};\\\", \\\"{x:834,y:928,t:1526418963446};\\\", \\\"{x:832,y:927,t:1526418963463};\\\", \\\"{x:832,y:926,t:1526418963646};\\\", \\\"{x:832,y:926,t:1526418963712};\\\", \\\"{x:832,y:925,t:1526418963880};\\\", \\\"{x:835,y:931,t:1526418963993};\\\", \\\"{x:846,y:945,t:1526418964001};\\\", \\\"{x:865,y:963,t:1526418964013};\\\", \\\"{x:922,y:1010,t:1526418964030};\\\", \\\"{x:986,y:1052,t:1526418964046};\\\", \\\"{x:1024,y:1074,t:1526418964062};\\\", \\\"{x:1040,y:1081,t:1526418964079};\\\", \\\"{x:1042,y:1081,t:1526418964096};\\\", \\\"{x:1040,y:1081,t:1526418964128};\\\", \\\"{x:1039,y:1081,t:1526418964136};\\\", \\\"{x:1037,y:1081,t:1526418964145};\\\", \\\"{x:1031,y:1078,t:1526418964162};\\\", \\\"{x:1023,y:1072,t:1526418964178};\\\", \\\"{x:1007,y:1061,t:1526418964196};\\\", \\\"{x:997,y:1055,t:1526418964212};\\\", \\\"{x:985,y:1049,t:1526418964228};\\\", \\\"{x:970,y:1043,t:1526418964246};\\\", \\\"{x:961,y:1040,t:1526418964262};\\\", \\\"{x:953,y:1038,t:1526418964279};\\\", \\\"{x:937,y:1034,t:1526418964297};\\\", \\\"{x:930,y:1030,t:1526418964312};\\\", \\\"{x:926,y:1030,t:1526418964330};\\\", \\\"{x:923,y:1030,t:1526418964346};\\\", \\\"{x:921,y:1030,t:1526418964363};\\\", \\\"{x:920,y:1030,t:1526418964384};\\\", \\\"{x:920,y:1030,t:1526418964428};\\\", \\\"{x:920,y:1029,t:1526418964464};\\\", \\\"{x:921,y:1028,t:1526418964504};\\\", \\\"{x:921,y:1028,t:1526418964516};\\\", \\\"{x:921,y:1027,t:1526418968025};\\\", \\\"{x:919,y:1026,t:1526418968041};\\\", \\\"{x:919,y:1025,t:1526418968049};\\\", \\\"{x:918,y:1025,t:1526418968066};\\\", \\\"{x:918,y:1024,t:1526418968082};\\\", \\\"{x:917,y:1024,t:1526418968120};\\\", \\\"{x:916,y:1038,t:1526418969137};\\\", \\\"{x:915,y:1038,t:1526418969150};\\\", \\\"{x:915,y:1037,t:1526418969166};\\\", \\\"{x:913,y:1035,t:1526418969183};\\\", \\\"{x:908,y:1030,t:1526418969201};\\\", \\\"{x:900,y:1016,t:1526418969216};\\\", \\\"{x:890,y:999,t:1526418969233};\\\", \\\"{x:878,y:972,t:1526418969250};\\\", \\\"{x:866,y:944,t:1526418969266};\\\", \\\"{x:849,y:908,t:1526418969283};\\\", \\\"{x:825,y:860,t:1526418969300};\\\", \\\"{x:796,y:815,t:1526418969317};\\\", \\\"{x:782,y:790,t:1526418969334};\\\", \\\"{x:772,y:773,t:1526418969349};\\\", \\\"{x:758,y:748,t:1526418969366};\\\", \\\"{x:747,y:729,t:1526418969384};\\\", \\\"{x:738,y:717,t:1526418969400};\\\", \\\"{x:720,y:690,t:1526418969417};\\\", \\\"{x:713,y:679,t:1526418969433};\\\", \\\"{x:706,y:671,t:1526418969449};\\\", \\\"{x:698,y:662,t:1526418969467};\\\", \\\"{x:693,y:651,t:1526418969483};\\\", \\\"{x:686,y:637,t:1526418969500};\\\", \\\"{x:676,y:622,t:1526418969517};\\\", \\\"{x:665,y:608,t:1526418969534};\\\", \\\"{x:652,y:593,t:1526418969550};\\\", \\\"{x:644,y:583,t:1526418969567};\\\", \\\"{x:640,y:573,t:1526418969583};\\\", \\\"{x:633,y:561,t:1526418969599};\\\", \\\"{x:621,y:544,t:1526418969616};\\\", \\\"{x:615,y:532,t:1526418969633};\\\", \\\"{x:609,y:525,t:1526418969649};\\\", \\\"{x:605,y:519,t:1526418969666};\\\", \\\"{x:597,y:512,t:1526418969683};\\\", \\\"{x:585,y:504,t:1526418969700};\\\", \\\"{x:575,y:498,t:1526418969716};\\\", \\\"{x:560,y:487,t:1526418969733};\\\", \\\"{x:548,y:477,t:1526418969750};\\\", \\\"{x:542,y:473,t:1526418969766};\\\", \\\"{x:542,y:472,t:1526418969782};\\\", \\\"{x:541,y:471,t:1526418969800};\\\", \\\"{x:540,y:470,t:1526418969816};\\\", \\\"{x:539,y:469,t:1526418969832};\\\", \\\"{x:539,y:468,t:1526418969880};\\\", \\\"{x:539,y:467,t:1526418969888};\\\", \\\"{x:539,y:466,t:1526418969899};\\\", \\\"{x:538,y:466,t:1526418969919};\\\", \\\"{x:537,y:466,t:1526418969968};\\\", \\\"{x:536,y:466,t:1526418969982};\\\", \\\"{x:532,y:469,t:1526418969999};\\\", \\\"{x:529,y:477,t:1526418970017};\\\", \\\"{x:526,y:481,t:1526418970032};\\\", \\\"{x:525,y:481,t:1526418970057};\\\", \\\"{x:525,y:482,t:1526418970337};\\\", \\\"{x:526,y:483,t:1526418970350};\\\", \\\"{x:527,y:484,t:1526418970365};\\\", \\\"{x:529,y:485,t:1526418970392};\\\", \\\"{x:532,y:485,t:1526418970409};\\\", \\\"{x:534,y:485,t:1526418970416};\\\", \\\"{x:536,y:485,t:1526418970433};\\\", \\\"{x:538,y:485,t:1526418970449};\\\", \\\"{x:539,y:485,t:1526418970466};\\\", \\\"{x:540,y:485,t:1526418970488};\\\", \\\"{x:542,y:487,t:1526418970504};\\\", \\\"{x:544,y:487,t:1526418970593};\\\", \\\"{x:545,y:487,t:1526418970649};\\\", \\\"{x:547,y:487,t:1526418970666};\\\", \\\"{x:548,y:487,t:1526418970705};\\\", \\\"{x:549,y:487,t:1526418970715};\\\", \\\"{x:550,y:487,t:1526418970733};\\\", \\\"{x:552,y:487,t:1526418970748};\\\", \\\"{x:558,y:487,t:1526418970766};\\\", \\\"{x:573,y:489,t:1526418970782};\\\", \\\"{x:600,y:494,t:1526418970798};\\\", \\\"{x:654,y:500,t:1526418970817};\\\", \\\"{x:710,y:510,t:1526418970834};\\\", \\\"{x:771,y:518,t:1526418970851};\\\", \\\"{x:830,y:526,t:1526418970868};\\\", \\\"{x:878,y:534,t:1526418970885};\\\", \\\"{x:918,y:541,t:1526418970901};\\\", \\\"{x:941,y:549,t:1526418970917};\\\", \\\"{x:958,y:554,t:1526418970935};\\\", \\\"{x:968,y:557,t:1526418970951};\\\", \\\"{x:971,y:560,t:1526418970968};\\\", \\\"{x:973,y:562,t:1526418970985};\\\", \\\"{x:975,y:564,t:1526418971002};\\\", \\\"{x:977,y:567,t:1526418971018};\\\", \\\"{x:981,y:574,t:1526418971035};\\\", \\\"{x:982,y:581,t:1526418971052};\\\", \\\"{x:985,y:586,t:1526418971068};\\\", \\\"{x:986,y:590,t:1526418971085};\\\", \\\"{x:989,y:594,t:1526418971102};\\\", \\\"{x:989,y:597,t:1526418971118};\\\", \\\"{x:991,y:601,t:1526418971135};\\\", \\\"{x:992,y:608,t:1526418971151};\\\", \\\"{x:992,y:609,t:1526418971168};\\\", \\\"{x:993,y:611,t:1526418971186};\\\", \\\"{x:994,y:616,t:1526418971202};\\\", \\\"{x:995,y:623,t:1526418971218};\\\", \\\"{x:996,y:628,t:1526418971235};\\\", \\\"{x:996,y:632,t:1526418971253};\\\", \\\"{x:996,y:634,t:1526418971268};\\\", \\\"{x:996,y:635,t:1526418971289};\\\", \\\"{x:996,y:636,t:1526418971303};\\\", \\\"{x:996,y:637,t:1526418971318};\\\", \\\"{x:996,y:638,t:1526418971335};\\\", \\\"{x:996,y:639,t:1526418971353};\\\", \\\"{x:996,y:639,t:1526418971554};\\\", \\\"{x:992,y:638,t:1526418976392};\\\", \\\"{x:985,y:635,t:1526418976405};\\\", \\\"{x:969,y:628,t:1526418976422};\\\", \\\"{x:940,y:620,t:1526418976440};\\\", \\\"{x:926,y:616,t:1526418976457};\\\", \\\"{x:906,y:610,t:1526418976473};\\\", \\\"{x:889,y:604,t:1526418976489};\\\", \\\"{x:875,y:596,t:1526418976506};\\\", \\\"{x:854,y:586,t:1526418976523};\\\", \\\"{x:839,y:580,t:1526418976539};\\\", \\\"{x:824,y:572,t:1526418976556};\\\", \\\"{x:813,y:568,t:1526418976573};\\\", \\\"{x:803,y:561,t:1526418976589};\\\", \\\"{x:794,y:555,t:1526418976606};\\\", \\\"{x:783,y:546,t:1526418976623};\\\", \\\"{x:778,y:543,t:1526418976640};\\\", \\\"{x:770,y:539,t:1526418976656};\\\", \\\"{x:763,y:533,t:1526418976673};\\\", \\\"{x:759,y:529,t:1526418976689};\\\", \\\"{x:748,y:520,t:1526418976706};\\\", \\\"{x:739,y:516,t:1526418976723};\\\", \\\"{x:728,y:509,t:1526418976739};\\\", \\\"{x:721,y:503,t:1526418976756};\\\", \\\"{x:710,y:496,t:1526418976773};\\\", \\\"{x:702,y:492,t:1526418976790};\\\", \\\"{x:695,y:487,t:1526418976806};\\\", \\\"{x:688,y:484,t:1526418976823};\\\", \\\"{x:687,y:483,t:1526418976839};\\\", \\\"{x:687,y:483,t:1526418976920};\\\", \\\"{x:684,y:488,t:1526418977904};\\\", \\\"{x:684,y:508,t:1526418977912};\\\", \\\"{x:684,y:533,t:1526418977924};\\\", \\\"{x:683,y:598,t:1526418977941};\\\", \\\"{x:682,y:629,t:1526418977958};\\\", \\\"{x:682,y:654,t:1526418977974};\\\", \\\"{x:682,y:671,t:1526418977991};\\\", \\\"{x:680,y:681,t:1526418978008};\\\", \\\"{x:680,y:691,t:1526418978024};\\\", \\\"{x:680,y:701,t:1526418978041};\\\", \\\"{x:680,y:705,t:1526418978058};\\\", \\\"{x:680,y:702,t:1526418978409};\\\", \\\"{x:680,y:699,t:1526418978424};\\\", \\\"{x:680,y:698,t:1526418978441};\\\", \\\"{x:683,y:693,t:1526418981305};\\\", \\\"{x:686,y:685,t:1526418981313};\\\", \\\"{x:692,y:673,t:1526418981327};\\\", \\\"{x:710,y:620,t:1526418981344};\\\", \\\"{x:732,y:566,t:1526418981360};\\\", \\\"{x:750,y:519,t:1526418981377};\\\", \\\"{x:764,y:484,t:1526418981394};\\\", \\\"{x:773,y:452,t:1526418981411};\\\", \\\"{x:777,y:430,t:1526418981427};\\\", \\\"{x:780,y:416,t:1526418981444};\\\", \\\"{x:781,y:407,t:1526418981461};\\\", \\\"{x:782,y:402,t:1526418981477};\\\", \\\"{x:782,y:399,t:1526418981494};\\\", \\\"{x:783,y:397,t:1526418981511};\\\", \\\"{x:783,y:404,t:1526418981672};\\\", \\\"{x:783,y:412,t:1526418981679};\\\", \\\"{x:782,y:424,t:1526418981693};\\\", \\\"{x:779,y:449,t:1526418981710};\\\", \\\"{x:775,y:490,t:1526418981727};\\\", \\\"{x:775,y:534,t:1526418981744};\\\", \\\"{x:775,y:581,t:1526418981761};\\\", \\\"{x:775,y:634,t:1526418981777};\\\", \\\"{x:775,y:690,t:1526418981794};\\\", \\\"{x:772,y:744,t:1526418981810};\\\", \\\"{x:772,y:789,t:1526418981827};\\\", \\\"{x:772,y:822,t:1526418981845};\\\", \\\"{x:772,y:848,t:1526418981861};\\\", \\\"{x:772,y:870,t:1526418981878};\\\", \\\"{x:772,y:886,t:1526418981894};\\\", \\\"{x:771,y:899,t:1526418981910};\\\", \\\"{x:771,y:905,t:1526418981927};\\\", \\\"{x:771,y:907,t:1526418981945};\\\", \\\"{x:771,y:911,t:1526418981960};\\\", \\\"{x:771,y:915,t:1526418981977};\\\", \\\"{x:771,y:918,t:1526418981994};\\\", \\\"{x:771,y:920,t:1526418982011};\\\", \\\"{x:770,y:921,t:1526418982027};\\\", \\\"{x:770,y:921,t:1526418982138};\\\", \\\"{x:770,y:918,t:1526418982441};\\\", \\\"{x:770,y:915,t:1526418982448};\\\", \\\"{x:770,y:911,t:1526418982463};\\\", \\\"{x:772,y:904,t:1526418982479};\\\", \\\"{x:773,y:897,t:1526418982497};\\\", \\\"{x:773,y:896,t:1526418982785};\\\", \\\"{x:774,y:893,t:1526418982797};\\\", \\\"{x:774,y:891,t:1526418982813};\\\", \\\"{x:774,y:888,t:1526418982830};\\\", \\\"{x:774,y:887,t:1526418982847};\\\", \\\"{x:774,y:885,t:1526418982864};\\\", \\\"{x:775,y:884,t:1526418983425};\\\", \\\"{x:776,y:884,t:1526418983432};\\\", \\\"{x:780,y:884,t:1526418983446};\\\", \\\"{x:787,y:886,t:1526418983462};\\\", \\\"{x:793,y:890,t:1526418983479};\\\", \\\"{x:806,y:900,t:1526418983496};\\\", \\\"{x:823,y:913,t:1526418983512};\\\", \\\"{x:841,y:930,t:1526418983528};\\\", \\\"{x:857,y:943,t:1526418983546};\\\", \\\"{x:874,y:955,t:1526418983562};\\\", \\\"{x:886,y:964,t:1526418983579};\\\", \\\"{x:895,y:972,t:1526418983596};\\\", \\\"{x:903,y:978,t:1526418983613};\\\", \\\"{x:909,y:984,t:1526418983629};\\\", \\\"{x:912,y:990,t:1526418983646};\\\", \\\"{x:920,y:1003,t:1526418983663};\\\", \\\"{x:928,y:1015,t:1526418983679};\\\", \\\"{x:937,y:1028,t:1526418983696};\\\", \\\"{x:941,y:1035,t:1526418983712};\\\", \\\"{x:948,y:1048,t:1526418983729};\\\", \\\"{x:958,y:1060,t:1526418983746};\\\", \\\"{x:973,y:1077,t:1526418983764};\\\", \\\"{x:983,y:1088,t:1526418983779};\\\", \\\"{x:991,y:1095,t:1526418983796};\\\", \\\"{x:992,y:1096,t:1526418983813};\\\" ] }, { \\\"rt\\\": 6927, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 849072, \\\"internal_node_id\\\": \\\"0.0-7.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 10232, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 860322, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 19751, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 881431, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"8LGZ4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"fire\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2754}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"8LGZ4\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2273,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2274},{\"nodeType\":3,\"id\":2275,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2276},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2280,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"start\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2281,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2282,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2284,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2285},{\"nodeType\":3,\"id\":2286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2287,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2288,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2289,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2290,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2291,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2292,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2293,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2294,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2295,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2296,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2297,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2298,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2300,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2301,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2303,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2304,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2305,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2306,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2307,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2308,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2309,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2310,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2311,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2313,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2315,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2317,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2319,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2321,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2323,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2325,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2327,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2329,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2331,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2333,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2335,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2337,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2339,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2341,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2345,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2346,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2349,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2350,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2353,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2354,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2357,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2358,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2361,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2362,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2365,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2366,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2369,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2370,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2373,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2374,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2377,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2378,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2381,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2382,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2385,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2386,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2389,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2390,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2394,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2400,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2401,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2404,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2405,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2406,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2407,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2408,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2413,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2414,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2425,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2427,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2429,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2431,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2433,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2435,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2439,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2440,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2443,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2444,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2447,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2451,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2452,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2455,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2459,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2460,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2461,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2462,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2463,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2464,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2465,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2466,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2467,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2470,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2471,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2475,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2478,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2500,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2502,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2504,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2505,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2506,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2508,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2509,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2510,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2512,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2513,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2514,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2516,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2517,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2518,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2520,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2521,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2522,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2524,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2526,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2528,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2530,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2532,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2534,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2536,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2538,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2540,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2544,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2545,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2548,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2549,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2552,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2553,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2556,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2557,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2560,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2561,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2564,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2565,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2568,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2569,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2572,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2573,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2576,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2577,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2578,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2579},{\"nodeType\":3,\"id\":2580,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2581,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2582,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2583,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2584,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 227, dom: 1613, initialDom: 2718",
  "javascriptErrors": []
}