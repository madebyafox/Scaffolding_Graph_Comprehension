var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3a675634e9ea949129fb8af08787427e",
  "created": "2018-06-01T11:10:39.9647664-07:00",
  "lastActivity": "2018-06-01T11:10:51.528158-07:00",
  "pageViews": [
    {
      "id": "060140248c585e0bb7d5a6f803fbdaeedb285a0a",
      "startTime": "2018-06-01T11:10:39.9647664-07:00",
      "endTime": "2018-06-01T11:10:51.528158-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 11699,
      "engagementTime": 11699,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 11699,
  "engagementTime": 11699,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.24",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DJRH1",
    "CONDITION=311",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1809c03a73706c8c8c62c1acdf38ad3a",
  "gdpr": false
}