var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "97cf7ae0c338a57c2bec2bc5a1fdb030",
  "created": "2018-05-29T16:15:17.1957518-07:00",
  "lastActivity": "2018-05-29T16:16:36.2783252-07:00",
  "pageViews": [
    {
      "id": "05291772fcc01ba5475dc651284db1e308af04ff",
      "startTime": "2018-05-29T16:15:17.2883252-07:00",
      "endTime": "2018-05-29T16:16:36.2783252-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 78990,
      "engagementTime": 74392,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 78990,
  "engagementTime": 74392,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.48",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=SQ6AK",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8b7b66b01a7173054d34e6967e9c0409",
  "gdpr": false
}