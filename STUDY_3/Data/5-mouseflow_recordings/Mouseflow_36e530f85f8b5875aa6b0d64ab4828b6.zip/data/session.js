var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "36e530f85f8b5875aa6b0d64ab4828b6",
  "created": "2018-05-29T15:14:53.5944726-07:00",
  "lastActivity": "2018-05-29T15:15:13.7058605-07:00",
  "pageViews": [
    {
      "id": "05295419fe1683237a0c9f2d1ffbc4f0d6aaf665",
      "startTime": "2018-05-29T15:14:53.5944726-07:00",
      "endTime": "2018-05-29T15:15:13.7058605-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 20112,
      "engagementTime": 9345,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 20112,
  "engagementTime": 9345,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8TUB0",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f61ad1324437987771ca47963778e48a",
  "gdpr": false
}