var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "57a1ef725ec5eeccb9a83555fb3634fc",
  "created": "2018-05-25T09:20:11.1905036-07:00",
  "lastActivity": "2018-05-25T09:21:28.9779083-07:00",
  "pageViews": [
    {
      "id": "05251181f8c0994ec36a9116ba4b542d81c880ac",
      "startTime": "2018-05-25T09:20:11.3951645-07:00",
      "endTime": "2018-05-25T09:21:28.9779083-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 77824,
      "engagementTime": 75295,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 77824,
  "engagementTime": 75295,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=MW3RC",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "96ed832f0aac6aa9fe7ca9250e7f654d",
  "gdpr": false
}