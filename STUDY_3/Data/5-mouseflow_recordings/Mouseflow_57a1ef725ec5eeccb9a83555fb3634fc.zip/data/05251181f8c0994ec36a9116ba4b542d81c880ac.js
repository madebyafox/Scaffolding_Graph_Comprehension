var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05251181f8c0994ec36a9116ba4b542d81c880ac"] = {
  "startTime": "2018-05-25T16:20:11.3951645Z",
  "websitePageUrl": "/16",
  "visitTime": 77824,
  "engagementTime": 75295,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "57a1ef725ec5eeccb9a83555fb3634fc",
    "created": "2018-05-25T16:20:11.1905036+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=MW3RC",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "96ed832f0aac6aa9fe7ca9250e7f654d",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/57a1ef725ec5eeccb9a83555fb3634fc/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 210,
      "e": 210,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 520,
      "y": 682
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 47763,
      "y": 35842,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 524,
      "y": 633
    },
    {
      "t": 1395,
      "e": 1395,
      "ty": 6,
      "x": 527,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 527,
      "y": 602
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 530,
      "y": 584
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 48662,
      "y": 49568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 530,
      "y": 582
    },
    {
      "t": 1694,
      "e": 1694,
      "ty": 3,
      "x": 530,
      "y": 582,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1696,
      "e": 1696,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 48662,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1886,
      "e": 1886,
      "ty": 4,
      "x": 48662,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1886,
      "e": 1886,
      "ty": 5,
      "x": 530,
      "y": 582,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8600,
      "e": 6886,
      "ty": 2,
      "x": 533,
      "y": 582
    },
    {
      "t": 8701,
      "e": 6987,
      "ty": 2,
      "x": 549,
      "y": 582
    },
    {
      "t": 8751,
      "e": 7037,
      "ty": 41,
      "x": 50911,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8800,
      "e": 7086,
      "ty": 2,
      "x": 585,
      "y": 590
    },
    {
      "t": 8868,
      "e": 7154,
      "ty": 7,
      "x": 641,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8901,
      "e": 7187,
      "ty": 2,
      "x": 679,
      "y": 617
    },
    {
      "t": 9000,
      "e": 7286,
      "ty": 2,
      "x": 799,
      "y": 650
    },
    {
      "t": 9000,
      "e": 7286,
      "ty": 41,
      "x": 917,
      "y": 36670,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9101,
      "e": 7387,
      "ty": 2,
      "x": 841,
      "y": 654
    },
    {
      "t": 9251,
      "e": 7537,
      "ty": 41,
      "x": 3876,
      "y": 36957,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9500,
      "e": 7786,
      "ty": 2,
      "x": 902,
      "y": 654
    },
    {
      "t": 9501,
      "e": 7787,
      "ty": 41,
      "x": 8175,
      "y": 36957,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9907,
      "e": 8193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 10001,
      "e": 8287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 10001,
      "e": 8287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10002,
      "e": 8288,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10049,
      "e": 8335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i"
    },
    {
      "t": 10121,
      "e": 8407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 10170,
      "e": 8456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i"
    },
    {
      "t": 10209,
      "e": 8495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10209,
      "e": 8495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10265,
      "e": 8551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i "
    },
    {
      "t": 10337,
      "e": 8623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 10337,
      "e": 8623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10369,
      "e": 8655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i L"
    },
    {
      "t": 10425,
      "e": 8711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i L"
    },
    {
      "t": 10521,
      "e": 8807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10521,
      "e": 8807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10586,
      "e": 8872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i LO"
    },
    {
      "t": 10666,
      "e": 8952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10667,
      "e": 8953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10729,
      "e": 9015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 10874,
      "e": 9160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 10874,
      "e": 9160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10945,
      "e": 9231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||K"
    },
    {
      "t": 11138,
      "e": 9424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11184,
      "e": 9470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i LOO"
    },
    {
      "t": 11265,
      "e": 9551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11361,
      "e": 9647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i LO"
    },
    {
      "t": 11441,
      "e": 9727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11603,
      "e": 9889,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i L"
    },
    {
      "t": 11941,
      "e": 10227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11973,
      "e": 10259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12006,
      "e": 10292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12039,
      "e": 10325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12072,
      "e": 10358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12106,
      "e": 10392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12138,
      "e": 10424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12171,
      "e": 10457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12205,
      "e": 10491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12238,
      "e": 10524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12249,
      "e": 10535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 12409,
      "e": 10695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12409,
      "e": 10695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12577,
      "e": 10863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 12593,
      "e": 10879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 12698,
      "e": 10984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12698,
      "e": 10984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12737,
      "e": 11023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 12761,
      "e": 11047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12762,
      "e": 11048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12817,
      "e": 11103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I l"
    },
    {
      "t": 12856,
      "e": 11142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I l"
    },
    {
      "t": 12937,
      "e": 11223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12937,
      "e": 11223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13001,
      "e": 11287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I lo"
    },
    {
      "t": 13106,
      "e": 11392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13106,
      "e": 11392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13168,
      "e": 11454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 13249,
      "e": 11535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 13250,
      "e": 11536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13385,
      "e": 11671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 13465,
      "e": 11751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13466,
      "e": 11752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13601,
      "e": 11887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13617,
      "e": 11903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13617,
      "e": 11903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13706,
      "e": 11992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13706,
      "e": 11992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13760,
      "e": 12046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 13792,
      "e": 12078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13793,
      "e": 12079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13840,
      "e": 12126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13873,
      "e": 12159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13873,
      "e": 12159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13913,
      "e": 12199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13985,
      "e": 12271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13986,
      "e": 12272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14033,
      "e": 12319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14130,
      "e": 12416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14130,
      "e": 12416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14131,
      "e": 12417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14249,
      "e": 12535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14249,
      "e": 12535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14377,
      "e": 12663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 14394,
      "e": 12680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15265,
      "e": 13551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 15267,
      "e": 13553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15337,
      "e": 13623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15337,
      "e": 13623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15385,
      "e": 13671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 15449,
      "e": 13735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15569,
      "e": 13855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15570,
      "e": 13856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15641,
      "e": 13927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 15641,
      "e": 13927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15681,
      "e": 13967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15681,
      "e": 13967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15753,
      "e": 14039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||int"
    },
    {
      "t": 15777,
      "e": 14063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15801,
      "e": 14087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15802,
      "e": 14088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15826,
      "e": 14112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 15833,
      "e": 14119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15833,
      "e": 14119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15970,
      "e": 14256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15985,
      "e": 14271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17018,
      "e": 15304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17018,
      "e": 15304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17090,
      "e": 15376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17091,
      "e": 15377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17202,
      "e": 15488,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the points on"
    },
    {
      "t": 17217,
      "e": 15503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 17241,
      "e": 15527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17257,
      "e": 15543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17258,
      "e": 15544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17403,
      "e": 15689,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the points on "
    },
    {
      "t": 17433,
      "e": 15719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17754,
      "e": 16040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17755,
      "e": 16041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17833,
      "e": 16119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17834,
      "e": 16120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17865,
      "e": 16151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 17880,
      "e": 16166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17881,
      "e": 16167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17953,
      "e": 16239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 17977,
      "e": 16263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17977,
      "e": 16263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18042,
      "e": 16328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18154,
      "e": 16440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 18155,
      "e": 16441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18161,
      "e": 16447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 18289,
      "e": 16447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 18291,
      "e": 16449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18329,
      "e": 16487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 18441,
      "e": 16599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18754,
      "e": 16912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18754,
      "e": 16912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18865,
      "e": 17023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18897,
      "e": 17055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 18898,
      "e": 17056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18937,
      "e": 17095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 18938,
      "e": 17096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19034,
      "e": 17192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 19097,
      "e": 17255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19099,
      "e": 17257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19105,
      "e": 17263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19305,
      "e": 17463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19458,
      "e": 17616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 19458,
      "e": 17616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19603,
      "e": 17761,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the points on the 12 pm y"
    },
    {
      "t": 19609,
      "e": 17767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19609,
      "e": 17767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19625,
      "e": 17783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 19761,
      "e": 17919,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20033,
      "e": 18191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20033,
      "e": 18191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20178,
      "e": 18336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20465,
      "e": 18623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 20465,
      "e": 18623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20586,
      "e": 18744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20588,
      "e": 18746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20593,
      "e": 18751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||xi"
    },
    {
      "t": 20754,
      "e": 18912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20921,
      "e": 19079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20922,
      "e": 19080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21081,
      "e": 19239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23809,
      "e": 21967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23809,
      "e": 21967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23952,
      "e": 22110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24024,
      "e": 22182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24024,
      "e": 22182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24081,
      "e": 22239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24192,
      "e": 22350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24193,
      "e": 22351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24281,
      "e": 22439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 24281,
      "e": 22439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24329,
      "e": 22487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 24361,
      "e": 22519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24361,
      "e": 22519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24440,
      "e": 22598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24553,
      "e": 22711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29954,
      "e": 27711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29954,
      "e": 27711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30000,
      "e": 27757,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30024,
      "e": 27781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30024,
      "e": 27781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30065,
      "e": 27822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 30121,
      "e": 27878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30121,
      "e": 27878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30145,
      "e": 27902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30257,
      "e": 28014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30257,
      "e": 28014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30321,
      "e": 28078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30321,
      "e": 28078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30360,
      "e": 28117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 30410,
      "e": 28167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30498,
      "e": 28255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30818,
      "e": 28575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 30818,
      "e": 28575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30905,
      "e": 28662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 30993,
      "e": 28750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30994,
      "e": 28751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31056,
      "e": 28813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31113,
      "e": 28870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31113,
      "e": 28870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31201,
      "e": 28958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31282,
      "e": 29039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 31282,
      "e": 29039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31386,
      "e": 29143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 31401,
      "e": 29158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31402,
      "e": 29159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31529,
      "e": 29286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31585,
      "e": 29342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31587,
      "e": 29344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31704,
      "e": 29461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31705,
      "e": 29462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31768,
      "e": 29525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 31793,
      "e": 29550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31793,
      "e": 29550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31808,
      "e": 29565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31905,
      "e": 29662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31912,
      "e": 29669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31913,
      "e": 29670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31969,
      "e": 29726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32034,
      "e": 29791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32035,
      "e": 29792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32112,
      "e": 29869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32298,
      "e": 30055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32369,
      "e": 30126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the points on the 12 pm y axis and then look at t"
    },
    {
      "t": 32441,
      "e": 30198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32513,
      "e": 30270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the points on the 12 pm y axis and then look at "
    },
    {
      "t": 32666,
      "e": 30423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32666,
      "e": 30423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32753,
      "e": 30510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32761,
      "e": 30518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32761,
      "e": 30518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32857,
      "e": 30614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32873,
      "e": 30630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32873,
      "e": 30630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32945,
      "e": 30702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32946,
      "e": 30703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33017,
      "e": 30774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 33025,
      "e": 30782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 33029,
      "e": 30786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33112,
      "e": 30869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33113,
      "e": 30870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33136,
      "e": 30893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r "
    },
    {
      "t": 33137,
      "e": 30894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33249,
      "e": 31006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33305,
      "e": 31062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 33306,
      "e": 31063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33361,
      "e": 31118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33361,
      "e": 31118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33433,
      "e": 31190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 33474,
      "e": 31231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33561,
      "e": 31318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33563,
      "e": 31320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33657,
      "e": 31414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33658,
      "e": 31415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33704,
      "e": 31461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33705,
      "e": 31462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33721,
      "e": 31478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||int"
    },
    {
      "t": 33793,
      "e": 31550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33793,
      "e": 31550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33817,
      "e": 31574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 33849,
      "e": 31606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33872,
      "e": 31629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33873,
      "e": 31630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34002,
      "e": 31759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34009,
      "e": 31766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34066,
      "e": 31823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34066,
      "e": 31823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34193,
      "e": 31950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34193,
      "e": 31950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34248,
      "e": 32005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34249,
      "e": 32006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34289,
      "e": 32046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to "
    },
    {
      "t": 34330,
      "e": 32087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34434,
      "e": 32191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34707,
      "e": 32464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 34707,
      "e": 32464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34721,
      "e": 32478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34721,
      "e": 32478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34865,
      "e": 32622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 34873,
      "e": 32630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35025,
      "e": 32782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35027,
      "e": 32784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35201,
      "e": 32958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35201,
      "e": 32958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35217,
      "e": 32974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 35377,
      "e": 33134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37466,
      "e": 35223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37466,
      "e": 35223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37585,
      "e": 35342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 37585,
      "e": 35342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37592,
      "e": 35349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||if"
    },
    {
      "t": 37625,
      "e": 35382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37626,
      "e": 35383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37681,
      "e": 35438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37793,
      "e": 35550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39489,
      "e": 37246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39490,
      "e": 37247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39601,
      "e": 37358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 39601,
      "e": 37358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39608,
      "e": 37365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ev"
    },
    {
      "t": 39697,
      "e": 37454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39697,
      "e": 37454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39721,
      "e": 37478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39753,
      "e": 37510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 39754,
      "e": 37511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39881,
      "e": 37638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 39938,
      "e": 37695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39993,
      "e": 37750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39994,
      "e": 37751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40105,
      "e": 37862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40105,
      "e": 37862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40136,
      "e": 37893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 40169,
      "e": 37926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40169,
      "e": 37926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40282,
      "e": 38039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40329,
      "e": 38086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40865,
      "e": 38622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40866,
      "e": 38623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40954,
      "e": 38711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40961,
      "e": 38718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40962,
      "e": 38719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41057,
      "e": 38814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 41097,
      "e": 38854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 41097,
      "e": 38854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41185,
      "e": 38942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 41186,
      "e": 38943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41186,
      "e": 38943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41248,
      "e": 39005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 41248,
      "e": 39005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41336,
      "e": 39093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 41353,
      "e": 39110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 41353,
      "e": 39110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41401,
      "e": 39158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 41408,
      "e": 39165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41409,
      "e": 39166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41473,
      "e": 39230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41570,
      "e": 39327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41618,
      "e": 39375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 41618,
      "e": 39375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41705,
      "e": 39462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41705,
      "e": 39462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41792,
      "e": 39549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||la"
    },
    {
      "t": 41825,
      "e": 39582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41825,
      "e": 39582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41873,
      "e": 39630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41922,
      "e": 39679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41923,
      "e": 39680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41945,
      "e": 39702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 42056,
      "e": 39813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 42057,
      "e": 39814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42153,
      "e": 39910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42154,
      "e": 39911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42185,
      "e": 39942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r "
    },
    {
      "t": 42208,
      "e": 39965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42297,
      "e": 40054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42480,
      "e": 40237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 42481,
      "e": 40238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42593,
      "e": 40350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 42594,
      "e": 40351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42601,
      "e": 40358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||co"
    },
    {
      "t": 42624,
      "e": 40381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 42626,
      "e": 40383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42689,
      "e": 40446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 42738,
      "e": 40495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42857,
      "e": 40614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 42858,
      "e": 40615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42929,
      "e": 40686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 42930,
      "e": 40687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42960,
      "e": 40717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ld"
    },
    {
      "t": 43017,
      "e": 40774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43017,
      "e": 40774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43073,
      "e": 40830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43203,
      "e": 40960,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the points on the 12 pm y axis and then look at other points to see if events ending later could "
    },
    {
      "t": 43240,
      "e": 40997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43955,
      "e": 41712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 43956,
      "e": 41713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44020,
      "e": 41777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 44021,
      "e": 41778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44068,
      "e": 41825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 44125,
      "e": 41882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 44125,
      "e": 41882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44149,
      "e": 41906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 44205,
      "e": 41962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44277,
      "e": 42034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 44277,
      "e": 42034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44340,
      "e": 42097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44340,
      "e": 42097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44388,
      "e": 42145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||si"
    },
    {
      "t": 44467,
      "e": 42224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44549,
      "e": 42306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 44549,
      "e": 42306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44603,
      "e": 42360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 44603,
      "e": 42360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44652,
      "e": 42409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||bl"
    },
    {
      "t": 44708,
      "e": 42465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44796,
      "e": 42553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 44797,
      "e": 42554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44924,
      "e": 42681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 44941,
      "e": 42698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44941,
      "e": 42698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45099,
      "e": 42856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45428,
      "e": 43185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 45429,
      "e": 43186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45524,
      "e": 43281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45525,
      "e": 43282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45628,
      "e": 43385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 45651,
      "e": 43408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45652,
      "e": 43409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45676,
      "e": 43433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 45764,
      "e": 43521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 45765,
      "e": 43522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45812,
      "e": 43569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 45843,
      "e": 43600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45844,
      "e": 43601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45964,
      "e": 43721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45972,
      "e": 43729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45973,
      "e": 43730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46020,
      "e": 43730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46092,
      "e": 43802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46277,
      "e": 43987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 46277,
      "e": 43987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46405,
      "e": 44115,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the points on the 12 pm y axis and then look at other points to see if events ending later could possibly start a"
    },
    {
      "t": 46412,
      "e": 44122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46412,
      "e": 44122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46452,
      "e": 44162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 46476,
      "e": 44186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46478,
      "e": 44188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46523,
      "e": 44233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46612,
      "e": 44322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46885,
      "e": 44595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 46885,
      "e": 44595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46980,
      "e": 44690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 46981,
      "e": 44691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47043,
      "e": 44753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 47213,
      "e": 44923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47308,
      "e": 45018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47309,
      "e": 45019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47411,
      "e": 45121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 47412,
      "e": 45122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47436,
      "e": 45146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| p"
    },
    {
      "t": 47500,
      "e": 45210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 47500,
      "e": 45210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47564,
      "e": 45274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 47620,
      "e": 45330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47668,
      "e": 45378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47669,
      "e": 45379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47772,
      "e": 45482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47924,
      "e": 45634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 47925,
      "e": 45635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48052,
      "e": 45762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 48268,
      "e": 45978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48324,
      "e": 46034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the points on the 12 pm y axis and then look at other points to see if events ending later could possibly start at 12 pm "
    },
    {
      "t": 48492,
      "e": 46202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 48493,
      "e": 46203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48579,
      "e": 46289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 48579,
      "e": 46289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48659,
      "e": 46369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||by"
    },
    {
      "t": 48763,
      "e": 46473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48772,
      "e": 46482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48772,
      "e": 46482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48822,
      "e": 46532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 48822,
      "e": 46532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48884,
      "e": 46594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| s"
    },
    {
      "t": 48932,
      "e": 46642,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49292,
      "e": 47002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 49293,
      "e": 47003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49380,
      "e": 47090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 49380,
      "e": 47090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49436,
      "e": 47146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ub"
    },
    {
      "t": 49515,
      "e": 47225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49588,
      "e": 47298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49588,
      "e": 47298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49716,
      "e": 47426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49716,
      "e": 47426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49755,
      "e": 47465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49756,
      "e": 47466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49780,
      "e": 47490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||tra"
    },
    {
      "t": 49867,
      "e": 47577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49923,
      "e": 47633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50011,
      "e": 47721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 50012,
      "e": 47722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50100,
      "e": 47810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 50205,
      "e": 47915,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the points on the 12 pm y axis and then look at other points to see if events ending later could possibly start at 12 pm by subtrac"
    },
    {
      "t": 50253,
      "e": 47963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50254,
      "e": 47964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50324,
      "e": 48034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 50340,
      "e": 48050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 50340,
      "e": 48050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50404,
      "e": 48114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 50404,
      "e": 48114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50516,
      "e": 48226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 50524,
      "e": 48234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50532,
      "e": 48242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 50533,
      "e": 48243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50580,
      "e": 48290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50580,
      "e": 48290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50604,
      "e": 48314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g "
    },
    {
      "t": 50667,
      "e": 48377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50700,
      "e": 48410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 50700,
      "e": 48410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50781,
      "e": 48411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 50782,
      "e": 48412,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50875,
      "e": 48505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ho"
    },
    {
      "t": 50875,
      "e": 48505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 50875,
      "e": 48505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50883,
      "e": 48513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 50884,
      "e": 48514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50891,
      "e": 48521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 50892,
      "e": 48522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50899,
      "e": 48529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||urs"
    },
    {
      "t": 50932,
      "e": 48562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50955,
      "e": 48585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51084,
      "e": 48714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51156,
      "e": 48786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 51157,
      "e": 48787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51291,
      "e": 48921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 52003,
      "e": 49633,
      "ty": 2,
      "x": 911,
      "y": 655
    },
    {
      "t": 52003,
      "e": 49633,
      "ty": 41,
      "x": 8809,
      "y": 37029,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 52103,
      "e": 49733,
      "ty": 2,
      "x": 988,
      "y": 642
    },
    {
      "t": 52204,
      "e": 49834,
      "ty": 2,
      "x": 930,
      "y": 698
    },
    {
      "t": 52254,
      "e": 49884,
      "ty": 41,
      "x": 9796,
      "y": 40968,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 52303,
      "e": 49933,
      "ty": 2,
      "x": 925,
      "y": 710
    },
    {
      "t": 52503,
      "e": 50133,
      "ty": 2,
      "x": 920,
      "y": 710
    },
    {
      "t": 52504,
      "e": 50134,
      "ty": 41,
      "x": 9443,
      "y": 40968,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 52603,
      "e": 50233,
      "ty": 2,
      "x": 697,
      "y": 713
    },
    {
      "t": 52703,
      "e": 50333,
      "ty": 2,
      "x": 687,
      "y": 700
    },
    {
      "t": 52753,
      "e": 50383,
      "ty": 41,
      "x": 57093,
      "y": 37891,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 52790,
      "e": 50420,
      "ty": 6,
      "x": 413,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 52803,
      "e": 50433,
      "ty": 2,
      "x": 413,
      "y": 673
    },
    {
      "t": 52822,
      "e": 50452,
      "ty": 7,
      "x": 321,
      "y": 659,
      "ta": "#strategyButton"
    },
    {
      "t": 52903,
      "e": 50533,
      "ty": 2,
      "x": 281,
      "y": 650
    },
    {
      "t": 53003,
      "e": 50633,
      "ty": 2,
      "x": 285,
      "y": 651
    },
    {
      "t": 53004,
      "e": 50634,
      "ty": 41,
      "x": 21122,
      "y": 35620,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 53103,
      "e": 50733,
      "ty": 2,
      "x": 332,
      "y": 670
    },
    {
      "t": 53106,
      "e": 50736,
      "ty": 6,
      "x": 339,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 53203,
      "e": 50833,
      "ty": 2,
      "x": 350,
      "y": 675
    },
    {
      "t": 53225,
      "e": 50855,
      "ty": 3,
      "x": 351,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 53226,
      "e": 50856,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the points on the 12 pm y axis and then look at other points to see if events ending later could possibly start at 12 pm by subtracting hours\n"
    },
    {
      "t": 53227,
      "e": 50857,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53227,
      "e": 50857,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 53253,
      "e": 50883,
      "ty": 41,
      "x": 6775,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 53303,
      "e": 50933,
      "ty": 2,
      "x": 351,
      "y": 675
    },
    {
      "t": 53328,
      "e": 50958,
      "ty": 4,
      "x": 6775,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 53338,
      "e": 50968,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 53339,
      "e": 50969,
      "ty": 5,
      "x": 351,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 53344,
      "e": 50974,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 53703,
      "e": 51333,
      "ty": 2,
      "x": 360,
      "y": 672
    },
    {
      "t": 53753,
      "e": 51383,
      "ty": 41,
      "x": 12122,
      "y": 36783,
      "ta": "html > body"
    },
    {
      "t": 54003,
      "e": 51633,
      "ty": 2,
      "x": 376,
      "y": 647
    },
    {
      "t": 54003,
      "e": 51633,
      "ty": 41,
      "x": 12673,
      "y": 35398,
      "ta": "html > body"
    },
    {
      "t": 54103,
      "e": 51733,
      "ty": 2,
      "x": 379,
      "y": 582
    },
    {
      "t": 54203,
      "e": 51833,
      "ty": 2,
      "x": 389,
      "y": 546
    },
    {
      "t": 54253,
      "e": 51883,
      "ty": 41,
      "x": 13120,
      "y": 29803,
      "ta": "html > body"
    },
    {
      "t": 54303,
      "e": 51933,
      "ty": 2,
      "x": 389,
      "y": 545
    },
    {
      "t": 54346,
      "e": 51976,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 54504,
      "e": 52134,
      "ty": 41,
      "x": 13120,
      "y": 29748,
      "ta": "html > body"
    },
    {
      "t": 54703,
      "e": 52333,
      "ty": 2,
      "x": 444,
      "y": 540
    },
    {
      "t": 54753,
      "e": 52383,
      "ty": 41,
      "x": 17804,
      "y": 29415,
      "ta": "html > body"
    },
    {
      "t": 54803,
      "e": 52433,
      "ty": 2,
      "x": 732,
      "y": 559
    },
    {
      "t": 54808,
      "e": 52438,
      "ty": 6,
      "x": 822,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54903,
      "e": 52533,
      "ty": 2,
      "x": 937,
      "y": 569
    },
    {
      "t": 55003,
      "e": 52633,
      "ty": 2,
      "x": 974,
      "y": 569
    },
    {
      "t": 55003,
      "e": 52633,
      "ty": 41,
      "x": 35903,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55232,
      "e": 52862,
      "ty": 3,
      "x": 974,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55232,
      "e": 52862,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55312,
      "e": 52942,
      "ty": 4,
      "x": 35903,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55312,
      "e": 52942,
      "ty": 5,
      "x": 974,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55979,
      "e": 53609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 55980,
      "e": 53610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56133,
      "e": 53763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 56171,
      "e": 53801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 56172,
      "e": 53802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56276,
      "e": 53906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 56944,
      "e": 54574,
      "ty": 7,
      "x": 919,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57004,
      "e": 54634,
      "ty": 2,
      "x": 793,
      "y": 593
    },
    {
      "t": 57004,
      "e": 54634,
      "ty": 41,
      "x": 27033,
      "y": 32407,
      "ta": "html > body"
    },
    {
      "t": 57104,
      "e": 54734,
      "ty": 2,
      "x": 803,
      "y": 629
    },
    {
      "t": 57204,
      "e": 54834,
      "ty": 2,
      "x": 864,
      "y": 646
    },
    {
      "t": 57228,
      "e": 54858,
      "ty": 6,
      "x": 878,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57253,
      "e": 54883,
      "ty": 41,
      "x": 15788,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57303,
      "e": 54933,
      "ty": 2,
      "x": 896,
      "y": 659
    },
    {
      "t": 57404,
      "e": 55034,
      "ty": 2,
      "x": 903,
      "y": 656
    },
    {
      "t": 57504,
      "e": 55134,
      "ty": 2,
      "x": 907,
      "y": 652
    },
    {
      "t": 57504,
      "e": 55134,
      "ty": 41,
      "x": 21412,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57528,
      "e": 55158,
      "ty": 3,
      "x": 907,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57530,
      "e": 55160,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 57530,
      "e": 55160,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57531,
      "e": 55161,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57591,
      "e": 55221,
      "ty": 4,
      "x": 21412,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57591,
      "e": 55221,
      "ty": 5,
      "x": 907,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58045,
      "e": 55675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 58268,
      "e": 55898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 58396,
      "e": 56026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 58492,
      "e": 56122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 58700,
      "e": 56330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 58828,
      "e": 56458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 58829,
      "e": 56459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58836,
      "e": 56466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 58924,
      "e": 56554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 58971,
      "e": 56601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 59052,
      "e": 56682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 59060,
      "e": 56690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 59060,
      "e": 56690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59123,
      "e": 56753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 59124,
      "e": 56754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59156,
      "e": 56786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 59268,
      "e": 56898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 59269,
      "e": 56899,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59308,
      "e": 56938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 59411,
      "e": 57041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 59419,
      "e": 57049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 59420,
      "e": 57050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59605,
      "e": 57235,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 59644,
      "e": 57274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 59945,
      "e": 57575,
      "ty": 7,
      "x": 948,
      "y": 639,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60004,
      "e": 57576,
      "ty": 2,
      "x": 1192,
      "y": 542
    },
    {
      "t": 60004,
      "e": 57576,
      "ty": 41,
      "x": 40774,
      "y": 29582,
      "ta": "html > body"
    },
    {
      "t": 60104,
      "e": 57676,
      "ty": 2,
      "x": 1240,
      "y": 522
    },
    {
      "t": 60204,
      "e": 57776,
      "ty": 2,
      "x": 1166,
      "y": 526
    },
    {
      "t": 60229,
      "e": 57801,
      "ty": 6,
      "x": 1100,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60246,
      "e": 57818,
      "ty": 7,
      "x": 1053,
      "y": 594,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60253,
      "e": 57825,
      "ty": 41,
      "x": 52990,
      "y": 7751,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 60279,
      "e": 57851,
      "ty": 6,
      "x": 929,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60295,
      "e": 57867,
      "ty": 7,
      "x": 835,
      "y": 692,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60303,
      "e": 57875,
      "ty": 2,
      "x": 835,
      "y": 692
    },
    {
      "t": 60403,
      "e": 57975,
      "ty": 2,
      "x": 795,
      "y": 717
    },
    {
      "t": 60496,
      "e": 58068,
      "ty": 6,
      "x": 911,
      "y": 694,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60503,
      "e": 58075,
      "ty": 2,
      "x": 911,
      "y": 694
    },
    {
      "t": 60503,
      "e": 58075,
      "ty": 41,
      "x": 7771,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60603,
      "e": 58175,
      "ty": 2,
      "x": 965,
      "y": 677
    },
    {
      "t": 60745,
      "e": 58317,
      "ty": 3,
      "x": 965,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60746,
      "e": 58318,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 60746,
      "e": 58318,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60747,
      "e": 58319,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60754,
      "e": 58326,
      "ty": 41,
      "x": 35602,
      "y": 1985,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60823,
      "e": 58395,
      "ty": 4,
      "x": 35602,
      "y": 1985,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60824,
      "e": 58396,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60824,
      "e": 58396,
      "ty": 5,
      "x": 965,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 60824,
      "e": 58396,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 61846,
      "e": 59418,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 62604,
      "e": 60176,
      "ty": 2,
      "x": 973,
      "y": 687
    },
    {
      "t": 62754,
      "e": 60326,
      "ty": 41,
      "x": 35973,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 63004,
      "e": 60576,
      "ty": 2,
      "x": 838,
      "y": 349
    },
    {
      "t": 63004,
      "e": 60576,
      "ty": 41,
      "x": 3934,
      "y": 14048,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 63104,
      "e": 60676,
      "ty": 2,
      "x": 801,
      "y": 245
    },
    {
      "t": 63204,
      "e": 60776,
      "ty": 2,
      "x": 805,
      "y": 217
    },
    {
      "t": 63254,
      "e": 60826,
      "ty": 41,
      "x": 27515,
      "y": 11467,
      "ta": "html > body"
    },
    {
      "t": 63303,
      "e": 60875,
      "ty": 2,
      "x": 820,
      "y": 215
    },
    {
      "t": 63404,
      "e": 60976,
      "ty": 2,
      "x": 831,
      "y": 225
    },
    {
      "t": 63504,
      "e": 61076,
      "ty": 2,
      "x": 835,
      "y": 230
    },
    {
      "t": 63504,
      "e": 61076,
      "ty": 41,
      "x": 11118,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 63520,
      "e": 61092,
      "ty": 6,
      "x": 837,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 63603,
      "e": 61175,
      "ty": 2,
      "x": 838,
      "y": 237
    },
    {
      "t": 63754,
      "e": 61326,
      "ty": 41,
      "x": 58367,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 63803,
      "e": 61375,
      "ty": 2,
      "x": 837,
      "y": 243
    },
    {
      "t": 63813,
      "e": 61385,
      "ty": 7,
      "x": 837,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 63849,
      "e": 61421,
      "ty": 6,
      "x": 832,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 63903,
      "e": 61475,
      "ty": 2,
      "x": 832,
      "y": 265
    },
    {
      "t": 64004,
      "e": 61576,
      "ty": 41,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 64082,
      "e": 61654,
      "ty": 7,
      "x": 832,
      "y": 259,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 64104,
      "e": 61676,
      "ty": 2,
      "x": 832,
      "y": 258
    },
    {
      "t": 64203,
      "e": 61775,
      "ty": 2,
      "x": 832,
      "y": 257
    },
    {
      "t": 64254,
      "e": 61826,
      "ty": 41,
      "x": 8818,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 64288,
      "e": 61860,
      "ty": 6,
      "x": 834,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 64304,
      "e": 61876,
      "ty": 2,
      "x": 834,
      "y": 262
    },
    {
      "t": 64332,
      "e": 61904,
      "ty": 7,
      "x": 834,
      "y": 275,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 64404,
      "e": 61976,
      "ty": 2,
      "x": 835,
      "y": 284
    },
    {
      "t": 64503,
      "e": 62075,
      "ty": 41,
      "x": 3222,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 64552,
      "e": 62124,
      "ty": 3,
      "x": 835,
      "y": 284,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 64616,
      "e": 62188,
      "ty": 4,
      "x": 3222,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 64616,
      "e": 62188,
      "ty": 5,
      "x": 835,
      "y": 284,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 64736,
      "e": 62308,
      "ty": 6,
      "x": 835,
      "y": 288,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 64754,
      "e": 62326,
      "ty": 41,
      "x": 43243,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 64804,
      "e": 62376,
      "ty": 2,
      "x": 835,
      "y": 290
    },
    {
      "t": 64928,
      "e": 62500,
      "ty": 3,
      "x": 835,
      "y": 290,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 64929,
      "e": 62501,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 65000,
      "e": 62572,
      "ty": 4,
      "x": 43243,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 65001,
      "e": 62573,
      "ty": 5,
      "x": 835,
      "y": 290,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 65002,
      "e": 62573,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 65004,
      "e": 62575,
      "ty": 41,
      "x": 43243,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 65148,
      "e": 62719,
      "ty": 7,
      "x": 835,
      "y": 304,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 65204,
      "e": 62775,
      "ty": 2,
      "x": 835,
      "y": 311
    },
    {
      "t": 65254,
      "e": 62825,
      "ty": 41,
      "x": 3222,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 65300,
      "e": 62871,
      "ty": 6,
      "x": 834,
      "y": 322,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 65303,
      "e": 62874,
      "ty": 2,
      "x": 834,
      "y": 322
    },
    {
      "t": 65333,
      "e": 62904,
      "ty": 7,
      "x": 834,
      "y": 337,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 65404,
      "e": 62975,
      "ty": 2,
      "x": 834,
      "y": 354
    },
    {
      "t": 65503,
      "e": 63074,
      "ty": 2,
      "x": 834,
      "y": 395
    },
    {
      "t": 65503,
      "e": 63074,
      "ty": 41,
      "x": 2985,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 65600,
      "e": 63171,
      "ty": 6,
      "x": 833,
      "y": 416,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 65604,
      "e": 63175,
      "ty": 2,
      "x": 833,
      "y": 416
    },
    {
      "t": 65703,
      "e": 63274,
      "ty": 2,
      "x": 833,
      "y": 419
    },
    {
      "t": 65754,
      "e": 63325,
      "ty": 41,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 65760,
      "e": 63331,
      "ty": 3,
      "x": 833,
      "y": 419,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 65762,
      "e": 63333,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 65762,
      "e": 63333,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 65831,
      "e": 63402,
      "ty": 4,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 65831,
      "e": 63402,
      "ty": 5,
      "x": 833,
      "y": 419,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 65831,
      "e": 63402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 66049,
      "e": 63620,
      "ty": 7,
      "x": 831,
      "y": 423,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 66083,
      "e": 63654,
      "ty": 6,
      "x": 827,
      "y": 441,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 66100,
      "e": 63671,
      "ty": 7,
      "x": 827,
      "y": 450,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 66103,
      "e": 63674,
      "ty": 2,
      "x": 827,
      "y": 450
    },
    {
      "t": 66204,
      "e": 63775,
      "ty": 2,
      "x": 819,
      "y": 554
    },
    {
      "t": 66254,
      "e": 63825,
      "ty": 41,
      "x": 27756,
      "y": 32573,
      "ta": "html > body"
    },
    {
      "t": 66303,
      "e": 63874,
      "ty": 2,
      "x": 813,
      "y": 608
    },
    {
      "t": 66404,
      "e": 63975,
      "ty": 2,
      "x": 819,
      "y": 643
    },
    {
      "t": 66503,
      "e": 64074,
      "ty": 2,
      "x": 825,
      "y": 675
    },
    {
      "t": 66503,
      "e": 64074,
      "ty": 41,
      "x": 960,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 66517,
      "e": 64088,
      "ty": 6,
      "x": 826,
      "y": 678,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 66604,
      "e": 64175,
      "ty": 2,
      "x": 826,
      "y": 680
    },
    {
      "t": 66616,
      "e": 64187,
      "ty": 7,
      "x": 826,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 66704,
      "e": 64275,
      "ty": 2,
      "x": 827,
      "y": 682
    },
    {
      "t": 66754,
      "e": 64325,
      "ty": 41,
      "x": 1497,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 67218,
      "e": 64789,
      "ty": 6,
      "x": 828,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 67254,
      "e": 64825,
      "ty": 41,
      "x": 12996,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 67304,
      "e": 64875,
      "ty": 2,
      "x": 829,
      "y": 678
    },
    {
      "t": 67504,
      "e": 65075,
      "ty": 41,
      "x": 12996,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 67744,
      "e": 65315,
      "ty": 3,
      "x": 829,
      "y": 678,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 67744,
      "e": 65315,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67744,
      "e": 65315,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 67808,
      "e": 65379,
      "ty": 4,
      "x": 12996,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 67808,
      "e": 65379,
      "ty": 5,
      "x": 829,
      "y": 678,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 67808,
      "e": 65379,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 68129,
      "e": 65700,
      "ty": 7,
      "x": 829,
      "y": 682,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 68204,
      "e": 65775,
      "ty": 2,
      "x": 813,
      "y": 817
    },
    {
      "t": 68254,
      "e": 65825,
      "ty": 41,
      "x": 27619,
      "y": 46201,
      "ta": "html > body"
    },
    {
      "t": 68304,
      "e": 65875,
      "ty": 2,
      "x": 810,
      "y": 844
    },
    {
      "t": 68404,
      "e": 65975,
      "ty": 2,
      "x": 810,
      "y": 845
    },
    {
      "t": 68504,
      "e": 66075,
      "ty": 41,
      "x": 27619,
      "y": 46367,
      "ta": "html > body"
    },
    {
      "t": 68604,
      "e": 66175,
      "ty": 2,
      "x": 821,
      "y": 880
    },
    {
      "t": 68707,
      "e": 66278,
      "ty": 2,
      "x": 823,
      "y": 915
    },
    {
      "t": 68753,
      "e": 66324,
      "ty": 41,
      "x": 374,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 68803,
      "e": 66374,
      "ty": 2,
      "x": 824,
      "y": 960
    },
    {
      "t": 68903,
      "e": 66374,
      "ty": 6,
      "x": 827,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68904,
      "e": 66375,
      "ty": 2,
      "x": 827,
      "y": 961
    },
    {
      "t": 69003,
      "e": 66474,
      "ty": 7,
      "x": 833,
      "y": 955,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69004,
      "e": 66475,
      "ty": 2,
      "x": 833,
      "y": 955
    },
    {
      "t": 69004,
      "e": 66475,
      "ty": 41,
      "x": 9365,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 69103,
      "e": 66574,
      "ty": 2,
      "x": 833,
      "y": 945
    },
    {
      "t": 69204,
      "e": 66675,
      "ty": 2,
      "x": 833,
      "y": 941
    },
    {
      "t": 69254,
      "e": 66725,
      "ty": 41,
      "x": 12646,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 69465,
      "e": 66936,
      "ty": 6,
      "x": 833,
      "y": 940,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69504,
      "e": 66975,
      "ty": 2,
      "x": 833,
      "y": 940
    },
    {
      "t": 69504,
      "e": 66975,
      "ty": 41,
      "x": 33161,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69600,
      "e": 67071,
      "ty": 7,
      "x": 833,
      "y": 942,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 69603,
      "e": 67074,
      "ty": 2,
      "x": 833,
      "y": 942
    },
    {
      "t": 69704,
      "e": 67175,
      "ty": 2,
      "x": 832,
      "y": 955
    },
    {
      "t": 69754,
      "e": 67225,
      "ty": 41,
      "x": 8556,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 69784,
      "e": 67255,
      "ty": 6,
      "x": 832,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69804,
      "e": 67275,
      "ty": 2,
      "x": 832,
      "y": 958
    },
    {
      "t": 69904,
      "e": 67375,
      "ty": 2,
      "x": 832,
      "y": 959
    },
    {
      "t": 70000,
      "e": 67471,
      "ty": 3,
      "x": 832,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 70002,
      "e": 67473,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 70002,
      "e": 67473,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 70004,
      "e": 67475,
      "ty": 41,
      "x": 28120,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 70112,
      "e": 67583,
      "ty": 4,
      "x": 28120,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 70112,
      "e": 67583,
      "ty": 5,
      "x": 832,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 70112,
      "e": 67583,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 70204,
      "e": 67675,
      "ty": 2,
      "x": 832,
      "y": 962
    },
    {
      "t": 70236,
      "e": 67707,
      "ty": 7,
      "x": 834,
      "y": 972,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 70254,
      "e": 67725,
      "ty": 41,
      "x": 3222,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 70304,
      "e": 67775,
      "ty": 2,
      "x": 841,
      "y": 986
    },
    {
      "t": 70387,
      "e": 67858,
      "ty": 6,
      "x": 849,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70403,
      "e": 67874,
      "ty": 2,
      "x": 849,
      "y": 1011
    },
    {
      "t": 70505,
      "e": 67976,
      "ty": 2,
      "x": 852,
      "y": 1019
    },
    {
      "t": 70505,
      "e": 67976,
      "ty": 41,
      "x": 11636,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70604,
      "e": 68075,
      "ty": 2,
      "x": 858,
      "y": 1030
    },
    {
      "t": 70665,
      "e": 68136,
      "ty": 3,
      "x": 858,
      "y": 1030,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70666,
      "e": 68137,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 70667,
      "e": 68138,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70754,
      "e": 68225,
      "ty": 41,
      "x": 14728,
      "y": 49647,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70759,
      "e": 68230,
      "ty": 4,
      "x": 14728,
      "y": 49647,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70760,
      "e": 68231,
      "ty": 5,
      "x": 858,
      "y": 1030,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70762,
      "e": 68233,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 70763,
      "e": 68234,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 70764,
      "e": 68235,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 72108,
      "e": 69579,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 73104,
      "e": 70575,
      "ty": 2,
      "x": 865,
      "y": 1030
    },
    {
      "t": 73203,
      "e": 70674,
      "ty": 2,
      "x": 936,
      "y": 1049
    },
    {
      "t": 73253,
      "e": 70724,
      "ty": 41,
      "x": 32398,
      "y": 64240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73303,
      "e": 70774,
      "ty": 2,
      "x": 952,
      "y": 1054
    },
    {
      "t": 73504,
      "e": 70975,
      "ty": 2,
      "x": 952,
      "y": 1058
    },
    {
      "t": 73504,
      "e": 70975,
      "ty": 41,
      "x": 32398,
      "y": 64517,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73555,
      "e": 71026,
      "ty": 6,
      "x": 955,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 73603,
      "e": 71074,
      "ty": 2,
      "x": 955,
      "y": 1078
    },
    {
      "t": 73703,
      "e": 71174,
      "ty": 2,
      "x": 957,
      "y": 1083
    },
    {
      "t": 73753,
      "e": 71224,
      "ty": 41,
      "x": 25940,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 73803,
      "e": 71274,
      "ty": 2,
      "x": 957,
      "y": 1089
    },
    {
      "t": 74003,
      "e": 71474,
      "ty": 2,
      "x": 958,
      "y": 1089
    },
    {
      "t": 74004,
      "e": 71475,
      "ty": 41,
      "x": 26487,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 74103,
      "e": 71574,
      "ty": 2,
      "x": 958,
      "y": 1087
    },
    {
      "t": 74253,
      "e": 71724,
      "ty": 41,
      "x": 26487,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 74761,
      "e": 72232,
      "ty": 3,
      "x": 958,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 74762,
      "e": 72233,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 74968,
      "e": 72439,
      "ty": 4,
      "x": 26487,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 74969,
      "e": 72440,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 74970,
      "e": 72441,
      "ty": 5,
      "x": 958,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 74971,
      "e": 72442,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 76012,
      "e": 73483,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 77703,
      "e": 75174,
      "ty": 2,
      "x": 951,
      "y": 1082
    },
    {
      "t": 77753,
      "e": 75224,
      "ty": 41,
      "x": 32038,
      "y": 32854,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 77804,
      "e": 75275,
      "ty": 2,
      "x": 913,
      "y": 1025
    },
    {
      "t": 77824,
      "e": 75295,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 82291, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 82298, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 4081, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 87733, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9792, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"LIMA\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 98530, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9325, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 108945, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9054, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 119001, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 32564, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 152919, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-11 AM-Z -02 PM-12 PM-A -A -A -C -C -C -A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:970,y:1086,t:1527264538685};\\\", \\\"{x:1000,y:1072,t:1527264538698};\\\", \\\"{x:1096,y:1032,t:1527264538713};\\\", \\\"{x:1128,y:997,t:1527264538729};\\\", \\\"{x:1107,y:907,t:1527264538746};\\\", \\\"{x:1028,y:726,t:1527264538763};\\\", \\\"{x:1006,y:617,t:1527264538779};\\\", \\\"{x:1004,y:528,t:1527264538796};\\\", \\\"{x:1011,y:461,t:1527264538813};\\\", \\\"{x:1031,y:404,t:1527264538830};\\\", \\\"{x:1052,y:364,t:1527264538846};\\\", \\\"{x:1074,y:330,t:1527264538863};\\\", \\\"{x:1094,y:308,t:1527264538880};\\\", \\\"{x:1116,y:289,t:1527264538896};\\\", \\\"{x:1132,y:272,t:1527264538913};\\\", \\\"{x:1140,y:262,t:1527264538930};\\\", \\\"{x:1140,y:261,t:1527264538946};\\\", \\\"{x:1140,y:259,t:1527264538963};\\\", \\\"{x:1140,y:260,t:1527264539172};\\\", \\\"{x:1137,y:267,t:1527264539180};\\\", \\\"{x:1122,y:284,t:1527264539197};\\\", \\\"{x:1107,y:305,t:1527264539213};\\\", \\\"{x:1094,y:322,t:1527264539231};\\\", \\\"{x:1087,y:334,t:1527264539248};\\\", \\\"{x:1079,y:346,t:1527264539263};\\\", \\\"{x:1073,y:356,t:1527264539280};\\\", \\\"{x:1067,y:365,t:1527264539298};\\\", \\\"{x:1060,y:373,t:1527264539313};\\\", \\\"{x:1052,y:382,t:1527264539330};\\\", \\\"{x:1037,y:390,t:1527264539348};\\\", \\\"{x:1030,y:395,t:1527264539363};\\\", \\\"{x:1026,y:396,t:1527264539380};\\\", \\\"{x:1025,y:398,t:1527264539436};\\\", \\\"{x:1025,y:403,t:1527264539448};\\\", \\\"{x:1021,y:424,t:1527264539463};\\\", \\\"{x:1015,y:467,t:1527264539481};\\\", \\\"{x:1006,y:536,t:1527264539497};\\\", \\\"{x:1005,y:590,t:1527264539514};\\\", \\\"{x:1005,y:623,t:1527264539530};\\\", \\\"{x:1018,y:648,t:1527264539548};\\\", \\\"{x:1036,y:657,t:1527264539563};\\\", \\\"{x:1050,y:658,t:1527264539581};\\\", \\\"{x:1064,y:658,t:1527264539598};\\\", \\\"{x:1078,y:658,t:1527264539613};\\\", \\\"{x:1092,y:660,t:1527264539631};\\\", \\\"{x:1107,y:662,t:1527264539647};\\\", \\\"{x:1135,y:664,t:1527264539664};\\\", \\\"{x:1165,y:664,t:1527264539680};\\\", \\\"{x:1168,y:664,t:1527264539697};\\\", \\\"{x:1170,y:664,t:1527264539987};\\\", \\\"{x:1171,y:669,t:1527264539997};\\\", \\\"{x:1179,y:697,t:1527264540014};\\\", \\\"{x:1194,y:747,t:1527264540030};\\\", \\\"{x:1211,y:803,t:1527264540047};\\\", \\\"{x:1234,y:861,t:1527264540064};\\\", \\\"{x:1259,y:902,t:1527264540080};\\\", \\\"{x:1280,y:937,t:1527264540097};\\\", \\\"{x:1293,y:960,t:1527264540114};\\\", \\\"{x:1300,y:979,t:1527264540130};\\\", \\\"{x:1311,y:1001,t:1527264540148};\\\", \\\"{x:1314,y:1008,t:1527264540164};\\\", \\\"{x:1316,y:1010,t:1527264540181};\\\", \\\"{x:1316,y:1011,t:1527264540197};\\\", \\\"{x:1317,y:1011,t:1527264540236};\\\", \\\"{x:1318,y:1011,t:1527264540267};\\\", \\\"{x:1319,y:1011,t:1527264540281};\\\", \\\"{x:1321,y:1009,t:1527264540297};\\\", \\\"{x:1326,y:1006,t:1527264540314};\\\", \\\"{x:1333,y:1002,t:1527264540331};\\\", \\\"{x:1339,y:1001,t:1527264540347};\\\", \\\"{x:1342,y:999,t:1527264540364};\\\", \\\"{x:1344,y:998,t:1527264540381};\\\", \\\"{x:1343,y:998,t:1527264540459};\\\", \\\"{x:1336,y:998,t:1527264540466};\\\", \\\"{x:1331,y:998,t:1527264540481};\\\", \\\"{x:1316,y:998,t:1527264540497};\\\", \\\"{x:1299,y:998,t:1527264540514};\\\", \\\"{x:1281,y:999,t:1527264540531};\\\", \\\"{x:1276,y:999,t:1527264540547};\\\", \\\"{x:1274,y:999,t:1527264540564};\\\", \\\"{x:1273,y:999,t:1527264540580};\\\", \\\"{x:1272,y:997,t:1527264540611};\\\", \\\"{x:1271,y:996,t:1527264540618};\\\", \\\"{x:1270,y:995,t:1527264540630};\\\", \\\"{x:1269,y:994,t:1527264540647};\\\", \\\"{x:1269,y:992,t:1527264540664};\\\", \\\"{x:1269,y:989,t:1527264540680};\\\", \\\"{x:1269,y:986,t:1527264540698};\\\", \\\"{x:1269,y:984,t:1527264540713};\\\", \\\"{x:1269,y:981,t:1527264540731};\\\", \\\"{x:1269,y:980,t:1527264540747};\\\", \\\"{x:1269,y:979,t:1527264540891};\\\", \\\"{x:1269,y:977,t:1527264540906};\\\", \\\"{x:1269,y:976,t:1527264540914};\\\", \\\"{x:1271,y:970,t:1527264540931};\\\", \\\"{x:1272,y:965,t:1527264540948};\\\", \\\"{x:1276,y:957,t:1527264540963};\\\", \\\"{x:1277,y:948,t:1527264540981};\\\", \\\"{x:1278,y:941,t:1527264540997};\\\", \\\"{x:1279,y:935,t:1527264541014};\\\", \\\"{x:1281,y:929,t:1527264541031};\\\", \\\"{x:1285,y:920,t:1527264541047};\\\", \\\"{x:1288,y:911,t:1527264541064};\\\", \\\"{x:1293,y:900,t:1527264541081};\\\", \\\"{x:1297,y:888,t:1527264541098};\\\", \\\"{x:1301,y:877,t:1527264541114};\\\", \\\"{x:1303,y:871,t:1527264541131};\\\", \\\"{x:1304,y:864,t:1527264541148};\\\", \\\"{x:1306,y:858,t:1527264541165};\\\", \\\"{x:1307,y:851,t:1527264541180};\\\", \\\"{x:1308,y:842,t:1527264541198};\\\", \\\"{x:1309,y:835,t:1527264541214};\\\", \\\"{x:1310,y:827,t:1527264541231};\\\", \\\"{x:1310,y:822,t:1527264541248};\\\", \\\"{x:1311,y:816,t:1527264541264};\\\", \\\"{x:1311,y:811,t:1527264541280};\\\", \\\"{x:1311,y:808,t:1527264541298};\\\", \\\"{x:1311,y:805,t:1527264541315};\\\", \\\"{x:1311,y:802,t:1527264541331};\\\", \\\"{x:1311,y:805,t:1527264541426};\\\", \\\"{x:1310,y:811,t:1527264541434};\\\", \\\"{x:1310,y:814,t:1527264541448};\\\", \\\"{x:1309,y:819,t:1527264541465};\\\", \\\"{x:1308,y:826,t:1527264541481};\\\", \\\"{x:1308,y:833,t:1527264541498};\\\", \\\"{x:1306,y:838,t:1527264541515};\\\", \\\"{x:1306,y:839,t:1527264541588};\\\", \\\"{x:1306,y:838,t:1527264541691};\\\", \\\"{x:1306,y:837,t:1527264541699};\\\", \\\"{x:1306,y:835,t:1527264541715};\\\", \\\"{x:1306,y:834,t:1527264541732};\\\", \\\"{x:1306,y:831,t:1527264541748};\\\", \\\"{x:1306,y:830,t:1527264541765};\\\", \\\"{x:1305,y:828,t:1527264541783};\\\", \\\"{x:1305,y:827,t:1527264541798};\\\", \\\"{x:1304,y:825,t:1527264541816};\\\", \\\"{x:1304,y:822,t:1527264541832};\\\", \\\"{x:1302,y:821,t:1527264541848};\\\", \\\"{x:1302,y:817,t:1527264541864};\\\", \\\"{x:1301,y:815,t:1527264541882};\\\", \\\"{x:1299,y:812,t:1527264541898};\\\", \\\"{x:1298,y:808,t:1527264541915};\\\", \\\"{x:1296,y:803,t:1527264541932};\\\", \\\"{x:1295,y:800,t:1527264541948};\\\", \\\"{x:1294,y:793,t:1527264541965};\\\", \\\"{x:1294,y:779,t:1527264541982};\\\", \\\"{x:1294,y:761,t:1527264541998};\\\", \\\"{x:1294,y:741,t:1527264542015};\\\", \\\"{x:1294,y:720,t:1527264542032};\\\", \\\"{x:1294,y:708,t:1527264542048};\\\", \\\"{x:1294,y:700,t:1527264542065};\\\", \\\"{x:1292,y:696,t:1527264542082};\\\", \\\"{x:1291,y:693,t:1527264542098};\\\", \\\"{x:1291,y:692,t:1527264542115};\\\", \\\"{x:1290,y:694,t:1527264542204};\\\", \\\"{x:1290,y:698,t:1527264542215};\\\", \\\"{x:1290,y:709,t:1527264542232};\\\", \\\"{x:1290,y:724,t:1527264542249};\\\", \\\"{x:1290,y:742,t:1527264542266};\\\", \\\"{x:1290,y:758,t:1527264542282};\\\", \\\"{x:1290,y:783,t:1527264542299};\\\", \\\"{x:1290,y:797,t:1527264542316};\\\", \\\"{x:1290,y:808,t:1527264542332};\\\", \\\"{x:1288,y:818,t:1527264542349};\\\", \\\"{x:1285,y:835,t:1527264542365};\\\", \\\"{x:1279,y:856,t:1527264542382};\\\", \\\"{x:1273,y:871,t:1527264542399};\\\", \\\"{x:1271,y:875,t:1527264542415};\\\", \\\"{x:1271,y:876,t:1527264542436};\\\", \\\"{x:1269,y:875,t:1527264542948};\\\", \\\"{x:1270,y:872,t:1527264542972};\\\", \\\"{x:1272,y:870,t:1527264542983};\\\", \\\"{x:1276,y:867,t:1527264543000};\\\", \\\"{x:1278,y:865,t:1527264543016};\\\", \\\"{x:1279,y:864,t:1527264543033};\\\", \\\"{x:1280,y:864,t:1527264543068};\\\", \\\"{x:1282,y:864,t:1527264543083};\\\", \\\"{x:1286,y:868,t:1527264543100};\\\", \\\"{x:1288,y:878,t:1527264543117};\\\", \\\"{x:1291,y:890,t:1527264543132};\\\", \\\"{x:1295,y:907,t:1527264543149};\\\", \\\"{x:1298,y:922,t:1527264543166};\\\", \\\"{x:1302,y:932,t:1527264543183};\\\", \\\"{x:1305,y:941,t:1527264543199};\\\", \\\"{x:1306,y:946,t:1527264543217};\\\", \\\"{x:1306,y:952,t:1527264543233};\\\", \\\"{x:1306,y:954,t:1527264543249};\\\", \\\"{x:1306,y:956,t:1527264543266};\\\", \\\"{x:1306,y:960,t:1527264543283};\\\", \\\"{x:1306,y:961,t:1527264543300};\\\", \\\"{x:1306,y:964,t:1527264543318};\\\", \\\"{x:1306,y:967,t:1527264543334};\\\", \\\"{x:1305,y:970,t:1527264543350};\\\", \\\"{x:1305,y:971,t:1527264543367};\\\", \\\"{x:1304,y:973,t:1527264543383};\\\", \\\"{x:1302,y:973,t:1527264543469};\\\", \\\"{x:1299,y:973,t:1527264543484};\\\", \\\"{x:1295,y:974,t:1527264543500};\\\", \\\"{x:1294,y:974,t:1527264543517};\\\", \\\"{x:1291,y:974,t:1527264543534};\\\", \\\"{x:1287,y:974,t:1527264543550};\\\", \\\"{x:1284,y:974,t:1527264543567};\\\", \\\"{x:1282,y:974,t:1527264543583};\\\", \\\"{x:1281,y:974,t:1527264543601};\\\", \\\"{x:1280,y:974,t:1527264543617};\\\", \\\"{x:1280,y:973,t:1527264543634};\\\", \\\"{x:1280,y:968,t:1527264543651};\\\", \\\"{x:1280,y:960,t:1527264543666};\\\", \\\"{x:1280,y:937,t:1527264543684};\\\", \\\"{x:1280,y:923,t:1527264543700};\\\", \\\"{x:1280,y:916,t:1527264543717};\\\", \\\"{x:1280,y:910,t:1527264543735};\\\", \\\"{x:1280,y:905,t:1527264543750};\\\", \\\"{x:1280,y:897,t:1527264543766};\\\", \\\"{x:1280,y:890,t:1527264543783};\\\", \\\"{x:1283,y:884,t:1527264543800};\\\", \\\"{x:1283,y:878,t:1527264543817};\\\", \\\"{x:1283,y:875,t:1527264543833};\\\", \\\"{x:1283,y:872,t:1527264543850};\\\", \\\"{x:1283,y:871,t:1527264543866};\\\", \\\"{x:1283,y:867,t:1527264543883};\\\", \\\"{x:1283,y:865,t:1527264543900};\\\", \\\"{x:1282,y:863,t:1527264543916};\\\", \\\"{x:1282,y:862,t:1527264543933};\\\", \\\"{x:1282,y:861,t:1527264543950};\\\", \\\"{x:1282,y:859,t:1527264543966};\\\", \\\"{x:1281,y:858,t:1527264543983};\\\", \\\"{x:1281,y:857,t:1527264544001};\\\", \\\"{x:1281,y:855,t:1527264544017};\\\", \\\"{x:1281,y:852,t:1527264544034};\\\", \\\"{x:1281,y:851,t:1527264544053};\\\", \\\"{x:1281,y:850,t:1527264544261};\\\", \\\"{x:1280,y:849,t:1527264544268};\\\", \\\"{x:1279,y:847,t:1527264544284};\\\", \\\"{x:1278,y:845,t:1527264544301};\\\", \\\"{x:1274,y:839,t:1527264544318};\\\", \\\"{x:1272,y:837,t:1527264544333};\\\", \\\"{x:1257,y:832,t:1527264544351};\\\", \\\"{x:1228,y:823,t:1527264544367};\\\", \\\"{x:1163,y:810,t:1527264544383};\\\", \\\"{x:1068,y:796,t:1527264544400};\\\", \\\"{x:961,y:784,t:1527264544417};\\\", \\\"{x:845,y:770,t:1527264544433};\\\", \\\"{x:724,y:762,t:1527264544450};\\\", \\\"{x:579,y:742,t:1527264544467};\\\", \\\"{x:498,y:731,t:1527264544485};\\\", \\\"{x:463,y:723,t:1527264544500};\\\", \\\"{x:450,y:719,t:1527264544518};\\\", \\\"{x:448,y:718,t:1527264544534};\\\", \\\"{x:446,y:717,t:1527264544587};\\\", \\\"{x:442,y:710,t:1527264544601};\\\", \\\"{x:428,y:688,t:1527264544617};\\\", \\\"{x:416,y:674,t:1527264544635};\\\", \\\"{x:410,y:669,t:1527264544652};\\\", \\\"{x:409,y:668,t:1527264544668};\\\", \\\"{x:409,y:666,t:1527264544684};\\\", \\\"{x:409,y:654,t:1527264544701};\\\", \\\"{x:409,y:633,t:1527264544719};\\\", \\\"{x:409,y:617,t:1527264544734};\\\", \\\"{x:409,y:607,t:1527264544752};\\\", \\\"{x:408,y:597,t:1527264544768};\\\", \\\"{x:406,y:584,t:1527264544784};\\\", \\\"{x:405,y:579,t:1527264544801};\\\", \\\"{x:405,y:573,t:1527264544819};\\\", \\\"{x:404,y:564,t:1527264544835};\\\", \\\"{x:404,y:558,t:1527264544851};\\\", \\\"{x:404,y:552,t:1527264544868};\\\", \\\"{x:402,y:544,t:1527264544885};\\\", \\\"{x:400,y:536,t:1527264544902};\\\", \\\"{x:400,y:532,t:1527264544918};\\\", \\\"{x:400,y:528,t:1527264544936};\\\", \\\"{x:400,y:526,t:1527264544951};\\\", \\\"{x:397,y:520,t:1527264544971};\\\", \\\"{x:396,y:517,t:1527264544985};\\\", \\\"{x:394,y:515,t:1527264545001};\\\", \\\"{x:393,y:515,t:1527264545155};\\\", \\\"{x:392,y:515,t:1527264545196};\\\", \\\"{x:392,y:516,t:1527264545820};\\\", \\\"{x:392,y:518,t:1527264545836};\\\", \\\"{x:392,y:522,t:1527264545853};\\\", \\\"{x:394,y:526,t:1527264545870};\\\", \\\"{x:396,y:530,t:1527264545886};\\\", \\\"{x:396,y:533,t:1527264545903};\\\", \\\"{x:398,y:535,t:1527264545920};\\\", \\\"{x:399,y:536,t:1527264545935};\\\", \\\"{x:400,y:537,t:1527264545952};\\\", \\\"{x:401,y:539,t:1527264545969};\\\", \\\"{x:401,y:540,t:1527264545985};\\\", \\\"{x:402,y:541,t:1527264546003};\\\", \\\"{x:404,y:545,t:1527264546019};\\\", \\\"{x:405,y:547,t:1527264546035};\\\", \\\"{x:407,y:549,t:1527264546052};\\\", \\\"{x:408,y:552,t:1527264546069};\\\", \\\"{x:409,y:553,t:1527264546091};\\\", \\\"{x:409,y:554,t:1527264546228};\\\", \\\"{x:409,y:555,t:1527264546284};\\\", \\\"{x:410,y:556,t:1527264546333};\\\", \\\"{x:411,y:557,t:1527264546340};\\\", \\\"{x:411,y:559,t:1527264546396};\\\", \\\"{x:412,y:559,t:1527264546420};\\\", \\\"{x:412,y:560,t:1527264546436};\\\", \\\"{x:413,y:561,t:1527264546454};\\\", \\\"{x:416,y:562,t:1527264546469};\\\", \\\"{x:427,y:563,t:1527264546486};\\\", \\\"{x:445,y:566,t:1527264546502};\\\", \\\"{x:472,y:566,t:1527264546519};\\\", \\\"{x:519,y:566,t:1527264546537};\\\", \\\"{x:602,y:566,t:1527264546553};\\\", \\\"{x:719,y:566,t:1527264546569};\\\", \\\"{x:854,y:566,t:1527264546587};\\\", \\\"{x:981,y:566,t:1527264546602};\\\", \\\"{x:1134,y:579,t:1527264546619};\\\", \\\"{x:1220,y:606,t:1527264546636};\\\", \\\"{x:1281,y:641,t:1527264546653};\\\", \\\"{x:1308,y:666,t:1527264546669};\\\", \\\"{x:1322,y:699,t:1527264546687};\\\", \\\"{x:1328,y:724,t:1527264546702};\\\", \\\"{x:1328,y:751,t:1527264546719};\\\", \\\"{x:1330,y:779,t:1527264546736};\\\", \\\"{x:1333,y:802,t:1527264546752};\\\", \\\"{x:1339,y:823,t:1527264546770};\\\", \\\"{x:1343,y:840,t:1527264546787};\\\", \\\"{x:1346,y:857,t:1527264546803};\\\", \\\"{x:1349,y:882,t:1527264546820};\\\", \\\"{x:1355,y:902,t:1527264546837};\\\", \\\"{x:1362,y:916,t:1527264546854};\\\", \\\"{x:1369,y:923,t:1527264546870};\\\", \\\"{x:1381,y:929,t:1527264546887};\\\", \\\"{x:1390,y:931,t:1527264546902};\\\", \\\"{x:1399,y:931,t:1527264546919};\\\", \\\"{x:1409,y:931,t:1527264546937};\\\", \\\"{x:1420,y:936,t:1527264546953};\\\", \\\"{x:1432,y:940,t:1527264546970};\\\", \\\"{x:1448,y:946,t:1527264546987};\\\", \\\"{x:1463,y:953,t:1527264547003};\\\", \\\"{x:1485,y:966,t:1527264547019};\\\", \\\"{x:1499,y:975,t:1527264547036};\\\", \\\"{x:1508,y:979,t:1527264547053};\\\", \\\"{x:1510,y:980,t:1527264547069};\\\", \\\"{x:1511,y:981,t:1527264547086};\\\", \\\"{x:1513,y:982,t:1527264547254};\\\", \\\"{x:1513,y:983,t:1527264547270};\\\", \\\"{x:1513,y:986,t:1527264547287};\\\", \\\"{x:1514,y:989,t:1527264547303};\\\", \\\"{x:1514,y:991,t:1527264547320};\\\", \\\"{x:1514,y:992,t:1527264547337};\\\", \\\"{x:1514,y:993,t:1527264547353};\\\", \\\"{x:1514,y:994,t:1527264547372};\\\", \\\"{x:1514,y:995,t:1527264547548};\\\", \\\"{x:1518,y:996,t:1527264547556};\\\", \\\"{x:1522,y:996,t:1527264547570};\\\", \\\"{x:1523,y:996,t:1527264548188};\\\", \\\"{x:1522,y:996,t:1527264548219};\\\", \\\"{x:1521,y:996,t:1527264548237};\\\", \\\"{x:1516,y:997,t:1527264548254};\\\", \\\"{x:1512,y:997,t:1527264548270};\\\", \\\"{x:1508,y:1000,t:1527264548287};\\\", \\\"{x:1504,y:1001,t:1527264548304};\\\", \\\"{x:1503,y:1001,t:1527264548320};\\\", \\\"{x:1502,y:1001,t:1527264548337};\\\", \\\"{x:1500,y:1001,t:1527264548356};\\\", \\\"{x:1499,y:1001,t:1527264548372};\\\", \\\"{x:1496,y:1001,t:1527264548387};\\\", \\\"{x:1482,y:1000,t:1527264548404};\\\", \\\"{x:1464,y:998,t:1527264548421};\\\", \\\"{x:1452,y:995,t:1527264548437};\\\", \\\"{x:1439,y:992,t:1527264548454};\\\", \\\"{x:1430,y:990,t:1527264548470};\\\", \\\"{x:1427,y:990,t:1527264548487};\\\", \\\"{x:1426,y:990,t:1527264548504};\\\", \\\"{x:1425,y:989,t:1527264548581};\\\", \\\"{x:1423,y:989,t:1527264548596};\\\", \\\"{x:1421,y:988,t:1527264548612};\\\", \\\"{x:1416,y:987,t:1527264548620};\\\", \\\"{x:1410,y:986,t:1527264548637};\\\", \\\"{x:1402,y:985,t:1527264548654};\\\", \\\"{x:1392,y:981,t:1527264548670};\\\", \\\"{x:1378,y:979,t:1527264548687};\\\", \\\"{x:1365,y:976,t:1527264548705};\\\", \\\"{x:1354,y:971,t:1527264548720};\\\", \\\"{x:1343,y:966,t:1527264548737};\\\", \\\"{x:1330,y:960,t:1527264548754};\\\", \\\"{x:1326,y:956,t:1527264548770};\\\", \\\"{x:1324,y:956,t:1527264548787};\\\", \\\"{x:1322,y:953,t:1527264548804};\\\", \\\"{x:1320,y:947,t:1527264548820};\\\", \\\"{x:1317,y:942,t:1527264548837};\\\", \\\"{x:1313,y:931,t:1527264548854};\\\", \\\"{x:1310,y:921,t:1527264548870};\\\", \\\"{x:1305,y:911,t:1527264548887};\\\", \\\"{x:1302,y:904,t:1527264548904};\\\", \\\"{x:1296,y:895,t:1527264548920};\\\", \\\"{x:1294,y:890,t:1527264548937};\\\", \\\"{x:1290,y:884,t:1527264548954};\\\", \\\"{x:1286,y:877,t:1527264548970};\\\", \\\"{x:1285,y:871,t:1527264548987};\\\", \\\"{x:1282,y:866,t:1527264549004};\\\", \\\"{x:1282,y:865,t:1527264549028};\\\", \\\"{x:1281,y:865,t:1527264549068};\\\", \\\"{x:1281,y:864,t:1527264549092};\\\", \\\"{x:1280,y:863,t:1527264549104};\\\", \\\"{x:1280,y:862,t:1527264549121};\\\", \\\"{x:1279,y:860,t:1527264549137};\\\", \\\"{x:1279,y:858,t:1527264549154};\\\", \\\"{x:1279,y:855,t:1527264549171};\\\", \\\"{x:1279,y:852,t:1527264549187};\\\", \\\"{x:1279,y:846,t:1527264549204};\\\", \\\"{x:1279,y:842,t:1527264549220};\\\", \\\"{x:1279,y:839,t:1527264549237};\\\", \\\"{x:1279,y:835,t:1527264549256};\\\", \\\"{x:1279,y:834,t:1527264549269};\\\", \\\"{x:1279,y:833,t:1527264549315};\\\", \\\"{x:1279,y:831,t:1527264549492};\\\", \\\"{x:1279,y:829,t:1527264549508};\\\", \\\"{x:1279,y:828,t:1527264549531};\\\", \\\"{x:1279,y:827,t:1527264549540};\\\", \\\"{x:1279,y:826,t:1527264549553};\\\", \\\"{x:1280,y:825,t:1527264549604};\\\", \\\"{x:1280,y:823,t:1527264549742};\\\", \\\"{x:1280,y:822,t:1527264549860};\\\", \\\"{x:1280,y:820,t:1527264549870};\\\", \\\"{x:1280,y:819,t:1527264549887};\\\", \\\"{x:1280,y:818,t:1527264550773};\\\", \\\"{x:1280,y:815,t:1527264550787};\\\", \\\"{x:1280,y:805,t:1527264550804};\\\", \\\"{x:1280,y:804,t:1527264550820};\\\", \\\"{x:1280,y:805,t:1527264552235};\\\", \\\"{x:1278,y:810,t:1527264552244};\\\", \\\"{x:1278,y:814,t:1527264552254};\\\", \\\"{x:1275,y:819,t:1527264552270};\\\", \\\"{x:1272,y:827,t:1527264552287};\\\", \\\"{x:1272,y:830,t:1527264552304};\\\", \\\"{x:1271,y:833,t:1527264552320};\\\", \\\"{x:1271,y:834,t:1527264552337};\\\", \\\"{x:1271,y:836,t:1527264552371};\\\", \\\"{x:1271,y:840,t:1527264552387};\\\", \\\"{x:1271,y:856,t:1527264552403};\\\", \\\"{x:1271,y:864,t:1527264552420};\\\", \\\"{x:1271,y:867,t:1527264552437};\\\", \\\"{x:1271,y:866,t:1527264552532};\\\", \\\"{x:1271,y:859,t:1527264552539};\\\", \\\"{x:1271,y:852,t:1527264552554};\\\", \\\"{x:1268,y:836,t:1527264552570};\\\", \\\"{x:1268,y:818,t:1527264552587};\\\", \\\"{x:1269,y:779,t:1527264552603};\\\", \\\"{x:1274,y:760,t:1527264552620};\\\", \\\"{x:1277,y:750,t:1527264552637};\\\", \\\"{x:1277,y:744,t:1527264552654};\\\", \\\"{x:1278,y:745,t:1527264552717};\\\", \\\"{x:1280,y:749,t:1527264552724};\\\", \\\"{x:1280,y:750,t:1527264552737};\\\", \\\"{x:1281,y:751,t:1527264552754};\\\", \\\"{x:1281,y:753,t:1527264552772};\\\", \\\"{x:1281,y:754,t:1527264552796};\\\", \\\"{x:1281,y:756,t:1527264552820};\\\", \\\"{x:1281,y:761,t:1527264552837};\\\", \\\"{x:1281,y:767,t:1527264552855};\\\", \\\"{x:1281,y:772,t:1527264552870};\\\", \\\"{x:1281,y:776,t:1527264552888};\\\", \\\"{x:1281,y:782,t:1527264552904};\\\", \\\"{x:1281,y:784,t:1527264552921};\\\", \\\"{x:1281,y:786,t:1527264552937};\\\", \\\"{x:1281,y:787,t:1527264553012};\\\", \\\"{x:1281,y:785,t:1527264553028};\\\", \\\"{x:1281,y:778,t:1527264553037};\\\", \\\"{x:1281,y:757,t:1527264553054};\\\", \\\"{x:1281,y:733,t:1527264553069};\\\", \\\"{x:1281,y:708,t:1527264553086};\\\", \\\"{x:1281,y:681,t:1527264553104};\\\", \\\"{x:1281,y:656,t:1527264553119};\\\", \\\"{x:1282,y:643,t:1527264553136};\\\", \\\"{x:1284,y:636,t:1527264553153};\\\", \\\"{x:1285,y:630,t:1527264553170};\\\", \\\"{x:1285,y:625,t:1527264553186};\\\", \\\"{x:1288,y:618,t:1527264553203};\\\", \\\"{x:1288,y:617,t:1527264553220};\\\", \\\"{x:1289,y:614,t:1527264553236};\\\", \\\"{x:1291,y:609,t:1527264553253};\\\", \\\"{x:1291,y:607,t:1527264553270};\\\", \\\"{x:1291,y:605,t:1527264553299};\\\", \\\"{x:1291,y:604,t:1527264553493};\\\", \\\"{x:1290,y:603,t:1527264553532};\\\", \\\"{x:1289,y:603,t:1527264553548};\\\", \\\"{x:1289,y:602,t:1527264553556};\\\", \\\"{x:1288,y:602,t:1527264553570};\\\", \\\"{x:1286,y:601,t:1527264553596};\\\", \\\"{x:1285,y:601,t:1527264553909};\\\", \\\"{x:1284,y:602,t:1527264554227};\\\", \\\"{x:1283,y:602,t:1527264554237};\\\", \\\"{x:1282,y:603,t:1527264554253};\\\", \\\"{x:1282,y:604,t:1527264554323};\\\", \\\"{x:1282,y:605,t:1527264554337};\\\", \\\"{x:1279,y:612,t:1527264554353};\\\", \\\"{x:1277,y:623,t:1527264554370};\\\", \\\"{x:1272,y:639,t:1527264554386};\\\", \\\"{x:1267,y:663,t:1527264554403};\\\", \\\"{x:1266,y:683,t:1527264554419};\\\", \\\"{x:1266,y:706,t:1527264554437};\\\", \\\"{x:1262,y:731,t:1527264554454};\\\", \\\"{x:1258,y:757,t:1527264554470};\\\", \\\"{x:1255,y:774,t:1527264554486};\\\", \\\"{x:1253,y:783,t:1527264554504};\\\", \\\"{x:1252,y:785,t:1527264554520};\\\", \\\"{x:1252,y:787,t:1527264554579};\\\", \\\"{x:1252,y:789,t:1527264554586};\\\", \\\"{x:1252,y:795,t:1527264554603};\\\", \\\"{x:1252,y:802,t:1527264554620};\\\", \\\"{x:1252,y:811,t:1527264554637};\\\", \\\"{x:1252,y:820,t:1527264554653};\\\", \\\"{x:1252,y:833,t:1527264554669};\\\", \\\"{x:1252,y:841,t:1527264554686};\\\", \\\"{x:1252,y:845,t:1527264554703};\\\", \\\"{x:1252,y:846,t:1527264554720};\\\", \\\"{x:1252,y:847,t:1527264554819};\\\", \\\"{x:1251,y:847,t:1527264554826};\\\", \\\"{x:1249,y:847,t:1527264554837};\\\", \\\"{x:1241,y:845,t:1527264554853};\\\", \\\"{x:1231,y:841,t:1527264554870};\\\", \\\"{x:1217,y:835,t:1527264554886};\\\", \\\"{x:1209,y:829,t:1527264554903};\\\", \\\"{x:1199,y:825,t:1527264554920};\\\", \\\"{x:1198,y:825,t:1527264554937};\\\", \\\"{x:1197,y:824,t:1527264554953};\\\", \\\"{x:1195,y:824,t:1527264555436};\\\", \\\"{x:1191,y:824,t:1527264555442};\\\", \\\"{x:1186,y:820,t:1527264555454};\\\", \\\"{x:1169,y:809,t:1527264555470};\\\", \\\"{x:1153,y:792,t:1527264555486};\\\", \\\"{x:1138,y:775,t:1527264555503};\\\", \\\"{x:1120,y:754,t:1527264555520};\\\", \\\"{x:1105,y:739,t:1527264555537};\\\", \\\"{x:1092,y:725,t:1527264555553};\\\", \\\"{x:1085,y:718,t:1527264555570};\\\", \\\"{x:1078,y:710,t:1527264555587};\\\", \\\"{x:1077,y:709,t:1527264555604};\\\", \\\"{x:1076,y:708,t:1527264555779};\\\", \\\"{x:1075,y:708,t:1527264555899};\\\", \\\"{x:1075,y:710,t:1527264555915};\\\", \\\"{x:1074,y:712,t:1527264555922};\\\", \\\"{x:1073,y:714,t:1527264555939};\\\", \\\"{x:1073,y:716,t:1527264555953};\\\", \\\"{x:1073,y:717,t:1527264555970};\\\", \\\"{x:1071,y:720,t:1527264555986};\\\", \\\"{x:1071,y:722,t:1527264556004};\\\", \\\"{x:1071,y:723,t:1527264556020};\\\", \\\"{x:1071,y:726,t:1527264556036};\\\", \\\"{x:1071,y:729,t:1527264556053};\\\", \\\"{x:1071,y:731,t:1527264556069};\\\", \\\"{x:1071,y:733,t:1527264556086};\\\", \\\"{x:1071,y:736,t:1527264556104};\\\", \\\"{x:1071,y:739,t:1527264556120};\\\", \\\"{x:1070,y:742,t:1527264556136};\\\", \\\"{x:1070,y:743,t:1527264556154};\\\", \\\"{x:1070,y:745,t:1527264556169};\\\", \\\"{x:1070,y:746,t:1527264556186};\\\", \\\"{x:1069,y:748,t:1527264556203};\\\", \\\"{x:1068,y:749,t:1527264556221};\\\", \\\"{x:1068,y:750,t:1527264556243};\\\", \\\"{x:1068,y:751,t:1527264556254};\\\", \\\"{x:1068,y:754,t:1527264556271};\\\", \\\"{x:1067,y:759,t:1527264556286};\\\", \\\"{x:1067,y:763,t:1527264556303};\\\", \\\"{x:1067,y:769,t:1527264556321};\\\", \\\"{x:1067,y:773,t:1527264556337};\\\", \\\"{x:1067,y:776,t:1527264556354};\\\", \\\"{x:1068,y:783,t:1527264556370};\\\", \\\"{x:1073,y:789,t:1527264556386};\\\", \\\"{x:1078,y:794,t:1527264556403};\\\", \\\"{x:1083,y:797,t:1527264556420};\\\", \\\"{x:1090,y:801,t:1527264556436};\\\", \\\"{x:1093,y:806,t:1527264556453};\\\", \\\"{x:1097,y:808,t:1527264556470};\\\", \\\"{x:1102,y:812,t:1527264556487};\\\", \\\"{x:1108,y:816,t:1527264556504};\\\", \\\"{x:1114,y:821,t:1527264556520};\\\", \\\"{x:1118,y:824,t:1527264556536};\\\", \\\"{x:1124,y:827,t:1527264556554};\\\", \\\"{x:1133,y:832,t:1527264556570};\\\", \\\"{x:1140,y:835,t:1527264556586};\\\", \\\"{x:1144,y:838,t:1527264556604};\\\", \\\"{x:1147,y:838,t:1527264556620};\\\", \\\"{x:1149,y:839,t:1527264556637};\\\", \\\"{x:1150,y:839,t:1527264556667};\\\", \\\"{x:1151,y:839,t:1527264556674};\\\", \\\"{x:1151,y:840,t:1527264556739};\\\", \\\"{x:1152,y:840,t:1527264556754};\\\", \\\"{x:1155,y:840,t:1527264556771};\\\", \\\"{x:1161,y:840,t:1527264556786};\\\", \\\"{x:1169,y:840,t:1527264556803};\\\", \\\"{x:1181,y:840,t:1527264556820};\\\", \\\"{x:1189,y:840,t:1527264556837};\\\", \\\"{x:1198,y:840,t:1527264556854};\\\", \\\"{x:1204,y:840,t:1527264556870};\\\", \\\"{x:1210,y:840,t:1527264556886};\\\", \\\"{x:1215,y:839,t:1527264556904};\\\", \\\"{x:1217,y:839,t:1527264556920};\\\", \\\"{x:1219,y:837,t:1527264556936};\\\", \\\"{x:1218,y:837,t:1527264557107};\\\", \\\"{x:1218,y:836,t:1527264557119};\\\", \\\"{x:1217,y:836,t:1527264557137};\\\", \\\"{x:1214,y:834,t:1527264557153};\\\", \\\"{x:1212,y:833,t:1527264557170};\\\", \\\"{x:1211,y:833,t:1527264557187};\\\", \\\"{x:1210,y:833,t:1527264557234};\\\", \\\"{x:1210,y:834,t:1527264557715};\\\", \\\"{x:1210,y:835,t:1527264557747};\\\", \\\"{x:1210,y:834,t:1527264557899};\\\", \\\"{x:1210,y:833,t:1527264557907};\\\", \\\"{x:1210,y:831,t:1527264557920};\\\", \\\"{x:1210,y:829,t:1527264557936};\\\", \\\"{x:1210,y:828,t:1527264557953};\\\", \\\"{x:1212,y:827,t:1527264561915};\\\", \\\"{x:1216,y:827,t:1527264561922};\\\", \\\"{x:1220,y:827,t:1527264561937};\\\", \\\"{x:1230,y:828,t:1527264561954};\\\", \\\"{x:1251,y:829,t:1527264561970};\\\", \\\"{x:1260,y:829,t:1527264561987};\\\", \\\"{x:1266,y:829,t:1527264562003};\\\", \\\"{x:1267,y:829,t:1527264562020};\\\", \\\"{x:1269,y:829,t:1527264562066};\\\", \\\"{x:1272,y:829,t:1527264562074};\\\", \\\"{x:1274,y:829,t:1527264562087};\\\", \\\"{x:1281,y:829,t:1527264562104};\\\", \\\"{x:1285,y:829,t:1527264562120};\\\", \\\"{x:1288,y:829,t:1527264562137};\\\", \\\"{x:1289,y:829,t:1527264562154};\\\", \\\"{x:1288,y:829,t:1527264563419};\\\", \\\"{x:1286,y:829,t:1527264563435};\\\", \\\"{x:1285,y:829,t:1527264563454};\\\", \\\"{x:1283,y:829,t:1527264563471};\\\", \\\"{x:1283,y:827,t:1527264563867};\\\", \\\"{x:1283,y:824,t:1527264563875};\\\", \\\"{x:1283,y:821,t:1527264563887};\\\", \\\"{x:1286,y:812,t:1527264563904};\\\", \\\"{x:1288,y:807,t:1527264563921};\\\", \\\"{x:1292,y:795,t:1527264563937};\\\", \\\"{x:1295,y:787,t:1527264563954};\\\", \\\"{x:1301,y:776,t:1527264563970};\\\", \\\"{x:1305,y:770,t:1527264563986};\\\", \\\"{x:1308,y:763,t:1527264564004};\\\", \\\"{x:1310,y:760,t:1527264564021};\\\", \\\"{x:1313,y:755,t:1527264564037};\\\", \\\"{x:1316,y:749,t:1527264564054};\\\", \\\"{x:1319,y:746,t:1527264564071};\\\", \\\"{x:1322,y:742,t:1527264564087};\\\", \\\"{x:1324,y:739,t:1527264564104};\\\", \\\"{x:1329,y:734,t:1527264564121};\\\", \\\"{x:1333,y:729,t:1527264564137};\\\", \\\"{x:1337,y:726,t:1527264564155};\\\", \\\"{x:1340,y:722,t:1527264564170};\\\", \\\"{x:1341,y:719,t:1527264564187};\\\", \\\"{x:1342,y:717,t:1527264564203};\\\", \\\"{x:1343,y:715,t:1527264564221};\\\", \\\"{x:1344,y:712,t:1527264564237};\\\", \\\"{x:1346,y:708,t:1527264564254};\\\", \\\"{x:1346,y:705,t:1527264564271};\\\", \\\"{x:1347,y:704,t:1527264564287};\\\", \\\"{x:1347,y:702,t:1527264564307};\\\", \\\"{x:1347,y:701,t:1527264564323};\\\", \\\"{x:1348,y:701,t:1527264564337};\\\", \\\"{x:1348,y:699,t:1527264564353};\\\", \\\"{x:1349,y:698,t:1527264564371};\\\", \\\"{x:1350,y:697,t:1527264564483};\\\", \\\"{x:1348,y:699,t:1527264566907};\\\", \\\"{x:1345,y:704,t:1527264566921};\\\", \\\"{x:1340,y:709,t:1527264566938};\\\", \\\"{x:1336,y:712,t:1527264566954};\\\", \\\"{x:1328,y:716,t:1527264566970};\\\", \\\"{x:1323,y:717,t:1527264566988};\\\", \\\"{x:1311,y:719,t:1527264567004};\\\", \\\"{x:1289,y:725,t:1527264567021};\\\", \\\"{x:1246,y:729,t:1527264567038};\\\", \\\"{x:1176,y:729,t:1527264567054};\\\", \\\"{x:1087,y:729,t:1527264567071};\\\", \\\"{x:998,y:729,t:1527264567088};\\\", \\\"{x:885,y:729,t:1527264567104};\\\", \\\"{x:768,y:729,t:1527264567121};\\\", \\\"{x:665,y:725,t:1527264567138};\\\", \\\"{x:576,y:715,t:1527264567154};\\\", \\\"{x:479,y:698,t:1527264567170};\\\", \\\"{x:449,y:694,t:1527264567188};\\\", \\\"{x:434,y:690,t:1527264567204};\\\", \\\"{x:431,y:688,t:1527264567221};\\\", \\\"{x:429,y:687,t:1527264567237};\\\", \\\"{x:429,y:683,t:1527264567254};\\\", \\\"{x:426,y:675,t:1527264567271};\\\", \\\"{x:424,y:670,t:1527264567288};\\\", \\\"{x:422,y:668,t:1527264567304};\\\", \\\"{x:425,y:668,t:1527264567362};\\\", \\\"{x:427,y:670,t:1527264567370};\\\", \\\"{x:440,y:677,t:1527264567388};\\\", \\\"{x:451,y:686,t:1527264567404};\\\", \\\"{x:464,y:696,t:1527264567421};\\\", \\\"{x:477,y:703,t:1527264567438};\\\", \\\"{x:485,y:706,t:1527264567454};\\\", \\\"{x:489,y:708,t:1527264567471};\\\", \\\"{x:490,y:708,t:1527264567486};\\\", \\\"{x:491,y:708,t:1527264567555};\\\", \\\"{x:492,y:709,t:1527264567586};\\\", \\\"{x:493,y:711,t:1527264567603};\\\", \\\"{x:499,y:715,t:1527264567620};\\\", \\\"{x:503,y:717,t:1527264567637};\\\", \\\"{x:506,y:718,t:1527264567653};\\\", \\\"{x:509,y:718,t:1527264567670};\\\", \\\"{x:510,y:718,t:1527264567687};\\\", \\\"{x:511,y:718,t:1527264567704};\\\", \\\"{x:513,y:718,t:1527264567720};\\\", \\\"{x:513,y:717,t:1527264567819};\\\" ] }, { \\\"rt\\\": 150151, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 304445, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -04 PM-D -D -D -D -H -O -D -E -E -E -K -C -D -H -E -E -3-08 AM-E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:718,t:1527264569938};\\\", \\\"{x:510,y:718,t:1527264569954};\\\", \\\"{x:509,y:718,t:1527264569986};\\\", \\\"{x:508,y:718,t:1527264570042};\\\", \\\"{x:508,y:719,t:1527264570059};\\\", \\\"{x:507,y:719,t:1527264570090};\\\", \\\"{x:506,y:719,t:1527264570106};\\\", \\\"{x:505,y:719,t:1527264570121};\\\", \\\"{x:503,y:719,t:1527264570138};\\\", \\\"{x:502,y:719,t:1527264570155};\\\", \\\"{x:501,y:719,t:1527264570171};\\\", \\\"{x:500,y:719,t:1527264570188};\\\", \\\"{x:499,y:719,t:1527264570579};\\\", \\\"{x:497,y:720,t:1527264570627};\\\", \\\"{x:496,y:720,t:1527264570699};\\\", \\\"{x:495,y:720,t:1527264570738};\\\", \\\"{x:494,y:721,t:1527264570763};\\\", \\\"{x:493,y:721,t:1527264570794};\\\", \\\"{x:492,y:722,t:1527264570907};\\\", \\\"{x:492,y:724,t:1527264570922};\\\", \\\"{x:505,y:732,t:1527264570938};\\\", \\\"{x:547,y:739,t:1527264570956};\\\", \\\"{x:585,y:739,t:1527264570973};\\\", \\\"{x:638,y:739,t:1527264570990};\\\", \\\"{x:724,y:739,t:1527264571006};\\\", \\\"{x:816,y:739,t:1527264571022};\\\", \\\"{x:902,y:739,t:1527264571039};\\\", \\\"{x:958,y:739,t:1527264571056};\\\", \\\"{x:984,y:742,t:1527264571072};\\\", \\\"{x:992,y:742,t:1527264571090};\\\", \\\"{x:994,y:742,t:1527264571106};\\\", \\\"{x:994,y:744,t:1527264571354};\\\", \\\"{x:989,y:746,t:1527264571362};\\\", \\\"{x:987,y:747,t:1527264571373};\\\", \\\"{x:985,y:748,t:1527264571389};\\\", \\\"{x:983,y:750,t:1527264571406};\\\", \\\"{x:985,y:750,t:1527264571443};\\\", \\\"{x:987,y:750,t:1527264571456};\\\", \\\"{x:996,y:749,t:1527264571473};\\\", \\\"{x:1010,y:748,t:1527264571489};\\\", \\\"{x:1032,y:743,t:1527264571506};\\\", \\\"{x:1080,y:730,t:1527264571523};\\\", \\\"{x:1108,y:723,t:1527264571539};\\\", \\\"{x:1141,y:716,t:1527264571556};\\\", \\\"{x:1166,y:710,t:1527264571573};\\\", \\\"{x:1188,y:705,t:1527264571590};\\\", \\\"{x:1209,y:702,t:1527264571606};\\\", \\\"{x:1225,y:702,t:1527264571624};\\\", \\\"{x:1247,y:702,t:1527264571639};\\\", \\\"{x:1269,y:702,t:1527264571656};\\\", \\\"{x:1287,y:699,t:1527264571674};\\\", \\\"{x:1299,y:695,t:1527264571691};\\\", \\\"{x:1301,y:694,t:1527264571706};\\\", \\\"{x:1301,y:693,t:1527264572051};\\\", \\\"{x:1304,y:691,t:1527264572075};\\\", \\\"{x:1306,y:689,t:1527264572091};\\\", \\\"{x:1332,y:678,t:1527264572107};\\\", \\\"{x:1358,y:670,t:1527264572124};\\\", \\\"{x:1389,y:659,t:1527264572140};\\\", \\\"{x:1431,y:646,t:1527264572158};\\\", \\\"{x:1472,y:630,t:1527264572174};\\\", \\\"{x:1503,y:616,t:1527264572191};\\\", \\\"{x:1526,y:605,t:1527264572208};\\\", \\\"{x:1546,y:596,t:1527264572223};\\\", \\\"{x:1560,y:589,t:1527264572241};\\\", \\\"{x:1568,y:585,t:1527264572258};\\\", \\\"{x:1572,y:582,t:1527264572273};\\\", \\\"{x:1573,y:582,t:1527264572290};\\\", \\\"{x:1575,y:579,t:1527264572307};\\\", \\\"{x:1577,y:577,t:1527264572323};\\\", \\\"{x:1579,y:574,t:1527264572341};\\\", \\\"{x:1585,y:566,t:1527264572358};\\\", \\\"{x:1592,y:550,t:1527264572374};\\\", \\\"{x:1602,y:536,t:1527264572391};\\\", \\\"{x:1609,y:520,t:1527264572407};\\\", \\\"{x:1620,y:501,t:1527264572425};\\\", \\\"{x:1625,y:488,t:1527264572441};\\\", \\\"{x:1629,y:480,t:1527264572458};\\\", \\\"{x:1630,y:471,t:1527264572475};\\\", \\\"{x:1632,y:466,t:1527264572490};\\\", \\\"{x:1632,y:462,t:1527264572508};\\\", \\\"{x:1632,y:460,t:1527264572525};\\\", \\\"{x:1632,y:459,t:1527264572541};\\\", \\\"{x:1632,y:457,t:1527264572558};\\\", \\\"{x:1632,y:455,t:1527264572575};\\\", \\\"{x:1632,y:454,t:1527264572591};\\\", \\\"{x:1631,y:452,t:1527264572608};\\\", \\\"{x:1629,y:452,t:1527264572624};\\\", \\\"{x:1626,y:450,t:1527264572641};\\\", \\\"{x:1625,y:450,t:1527264572658};\\\", \\\"{x:1623,y:449,t:1527264572675};\\\", \\\"{x:1622,y:448,t:1527264572691};\\\", \\\"{x:1620,y:447,t:1527264572723};\\\", \\\"{x:1619,y:447,t:1527264572771};\\\", \\\"{x:1618,y:447,t:1527264572907};\\\", \\\"{x:1618,y:450,t:1527264572925};\\\", \\\"{x:1619,y:460,t:1527264572942};\\\", \\\"{x:1621,y:473,t:1527264572957};\\\", \\\"{x:1622,y:486,t:1527264572974};\\\", \\\"{x:1623,y:498,t:1527264572991};\\\", \\\"{x:1623,y:511,t:1527264573008};\\\", \\\"{x:1623,y:522,t:1527264573024};\\\", \\\"{x:1623,y:532,t:1527264573041};\\\", \\\"{x:1623,y:537,t:1527264573058};\\\", \\\"{x:1623,y:540,t:1527264573075};\\\", \\\"{x:1623,y:544,t:1527264573091};\\\", \\\"{x:1623,y:545,t:1527264573107};\\\", \\\"{x:1623,y:547,t:1527264573125};\\\", \\\"{x:1623,y:548,t:1527264573204};\\\", \\\"{x:1623,y:550,t:1527264573219};\\\", \\\"{x:1623,y:554,t:1527264573236};\\\", \\\"{x:1623,y:555,t:1527264573244};\\\", \\\"{x:1623,y:557,t:1527264573259};\\\", \\\"{x:1621,y:567,t:1527264573275};\\\", \\\"{x:1620,y:581,t:1527264573292};\\\", \\\"{x:1617,y:598,t:1527264573309};\\\", \\\"{x:1613,y:616,t:1527264573325};\\\", \\\"{x:1609,y:638,t:1527264573342};\\\", \\\"{x:1605,y:657,t:1527264573359};\\\", \\\"{x:1600,y:677,t:1527264573375};\\\", \\\"{x:1599,y:699,t:1527264573392};\\\", \\\"{x:1598,y:717,t:1527264573409};\\\", \\\"{x:1598,y:732,t:1527264573425};\\\", \\\"{x:1595,y:748,t:1527264573443};\\\", \\\"{x:1594,y:761,t:1527264573459};\\\", \\\"{x:1593,y:778,t:1527264573475};\\\", \\\"{x:1587,y:805,t:1527264573492};\\\", \\\"{x:1584,y:819,t:1527264573509};\\\", \\\"{x:1583,y:829,t:1527264573526};\\\", \\\"{x:1583,y:837,t:1527264573542};\\\", \\\"{x:1583,y:845,t:1527264573559};\\\", \\\"{x:1583,y:854,t:1527264573576};\\\", \\\"{x:1583,y:866,t:1527264573592};\\\", \\\"{x:1583,y:875,t:1527264573609};\\\", \\\"{x:1583,y:882,t:1527264573626};\\\", \\\"{x:1583,y:889,t:1527264573642};\\\", \\\"{x:1585,y:895,t:1527264573659};\\\", \\\"{x:1587,y:905,t:1527264573675};\\\", \\\"{x:1588,y:906,t:1527264573692};\\\", \\\"{x:1589,y:908,t:1527264573709};\\\", \\\"{x:1589,y:912,t:1527264573727};\\\", \\\"{x:1592,y:916,t:1527264573743};\\\", \\\"{x:1593,y:919,t:1527264573760};\\\", \\\"{x:1594,y:921,t:1527264573776};\\\", \\\"{x:1595,y:923,t:1527264573792};\\\", \\\"{x:1596,y:925,t:1527264573809};\\\", \\\"{x:1596,y:927,t:1527264573826};\\\", \\\"{x:1596,y:928,t:1527264573842};\\\", \\\"{x:1598,y:932,t:1527264573859};\\\", \\\"{x:1598,y:936,t:1527264573875};\\\", \\\"{x:1598,y:938,t:1527264573893};\\\", \\\"{x:1599,y:943,t:1527264573909};\\\", \\\"{x:1599,y:948,t:1527264573926};\\\", \\\"{x:1600,y:952,t:1527264573943};\\\", \\\"{x:1601,y:957,t:1527264573959};\\\", \\\"{x:1603,y:961,t:1527264573976};\\\", \\\"{x:1603,y:964,t:1527264573994};\\\", \\\"{x:1603,y:965,t:1527264574009};\\\", \\\"{x:1604,y:965,t:1527264574052};\\\", \\\"{x:1604,y:964,t:1527264574332};\\\", \\\"{x:1604,y:962,t:1527264574343};\\\", \\\"{x:1605,y:960,t:1527264574360};\\\", \\\"{x:1605,y:954,t:1527264574376};\\\", \\\"{x:1605,y:950,t:1527264574393};\\\", \\\"{x:1605,y:946,t:1527264574410};\\\", \\\"{x:1605,y:941,t:1527264574426};\\\", \\\"{x:1605,y:936,t:1527264574443};\\\", \\\"{x:1605,y:930,t:1527264574459};\\\", \\\"{x:1605,y:924,t:1527264574476};\\\", \\\"{x:1605,y:921,t:1527264574492};\\\", \\\"{x:1605,y:919,t:1527264574510};\\\", \\\"{x:1605,y:918,t:1527264574525};\\\", \\\"{x:1605,y:915,t:1527264574542};\\\", \\\"{x:1605,y:913,t:1527264574560};\\\", \\\"{x:1605,y:907,t:1527264574576};\\\", \\\"{x:1605,y:903,t:1527264574593};\\\", \\\"{x:1605,y:899,t:1527264574610};\\\", \\\"{x:1605,y:894,t:1527264574627};\\\", \\\"{x:1605,y:890,t:1527264574643};\\\", \\\"{x:1605,y:886,t:1527264574659};\\\", \\\"{x:1605,y:882,t:1527264574677};\\\", \\\"{x:1605,y:879,t:1527264574693};\\\", \\\"{x:1605,y:878,t:1527264574709};\\\", \\\"{x:1605,y:875,t:1527264574726};\\\", \\\"{x:1605,y:873,t:1527264574743};\\\", \\\"{x:1605,y:871,t:1527264574760};\\\", \\\"{x:1605,y:869,t:1527264574777};\\\", \\\"{x:1605,y:866,t:1527264574793};\\\", \\\"{x:1605,y:865,t:1527264574810};\\\", \\\"{x:1605,y:860,t:1527264574826};\\\", \\\"{x:1605,y:856,t:1527264574843};\\\", \\\"{x:1605,y:852,t:1527264574860};\\\", \\\"{x:1605,y:845,t:1527264574877};\\\", \\\"{x:1605,y:839,t:1527264574893};\\\", \\\"{x:1605,y:833,t:1527264574910};\\\", \\\"{x:1605,y:826,t:1527264574926};\\\", \\\"{x:1605,y:818,t:1527264574943};\\\", \\\"{x:1605,y:806,t:1527264574959};\\\", \\\"{x:1605,y:793,t:1527264574976};\\\", \\\"{x:1605,y:778,t:1527264574994};\\\", \\\"{x:1605,y:764,t:1527264575010};\\\", \\\"{x:1609,y:742,t:1527264575026};\\\", \\\"{x:1614,y:725,t:1527264575043};\\\", \\\"{x:1616,y:711,t:1527264575059};\\\", \\\"{x:1618,y:697,t:1527264575077};\\\", \\\"{x:1619,y:680,t:1527264575094};\\\", \\\"{x:1622,y:669,t:1527264575109};\\\", \\\"{x:1624,y:655,t:1527264575126};\\\", \\\"{x:1626,y:641,t:1527264575143};\\\", \\\"{x:1627,y:633,t:1527264575159};\\\", \\\"{x:1627,y:629,t:1527264575176};\\\", \\\"{x:1627,y:624,t:1527264575194};\\\", \\\"{x:1627,y:621,t:1527264575210};\\\", \\\"{x:1627,y:614,t:1527264575227};\\\", \\\"{x:1627,y:610,t:1527264575244};\\\", \\\"{x:1627,y:604,t:1527264575260};\\\", \\\"{x:1627,y:599,t:1527264575277};\\\", \\\"{x:1627,y:592,t:1527264575294};\\\", \\\"{x:1627,y:585,t:1527264575310};\\\", \\\"{x:1627,y:576,t:1527264575326};\\\", \\\"{x:1627,y:567,t:1527264575344};\\\", \\\"{x:1627,y:562,t:1527264575361};\\\", \\\"{x:1627,y:559,t:1527264575377};\\\", \\\"{x:1627,y:555,t:1527264575394};\\\", \\\"{x:1627,y:553,t:1527264575411};\\\", \\\"{x:1627,y:552,t:1527264575427};\\\", \\\"{x:1627,y:550,t:1527264575459};\\\", \\\"{x:1627,y:549,t:1527264575483};\\\", \\\"{x:1627,y:547,t:1527264575515};\\\", \\\"{x:1627,y:546,t:1527264575547};\\\", \\\"{x:1627,y:549,t:1527264576228};\\\", \\\"{x:1627,y:553,t:1527264576246};\\\", \\\"{x:1626,y:559,t:1527264576261};\\\", \\\"{x:1626,y:564,t:1527264576279};\\\", \\\"{x:1626,y:567,t:1527264576295};\\\", \\\"{x:1626,y:569,t:1527264576311};\\\", \\\"{x:1626,y:573,t:1527264576328};\\\", \\\"{x:1626,y:578,t:1527264576345};\\\", \\\"{x:1626,y:582,t:1527264576361};\\\", \\\"{x:1626,y:585,t:1527264576378};\\\", \\\"{x:1626,y:586,t:1527264576396};\\\", \\\"{x:1626,y:587,t:1527264576413};\\\", \\\"{x:1625,y:587,t:1527264578348};\\\", \\\"{x:1624,y:587,t:1527264578363};\\\", \\\"{x:1623,y:587,t:1527264578381};\\\", \\\"{x:1622,y:587,t:1527264578403};\\\", \\\"{x:1621,y:587,t:1527264578413};\\\", \\\"{x:1619,y:587,t:1527264578431};\\\", \\\"{x:1616,y:586,t:1527264578448};\\\", \\\"{x:1613,y:586,t:1527264578463};\\\", \\\"{x:1611,y:586,t:1527264578480};\\\", \\\"{x:1608,y:586,t:1527264578497};\\\", \\\"{x:1607,y:586,t:1527264578513};\\\", \\\"{x:1605,y:586,t:1527264578531};\\\", \\\"{x:1603,y:586,t:1527264578547};\\\", \\\"{x:1602,y:586,t:1527264578565};\\\", \\\"{x:1599,y:586,t:1527264578580};\\\", \\\"{x:1595,y:586,t:1527264578598};\\\", \\\"{x:1591,y:585,t:1527264578615};\\\", \\\"{x:1588,y:584,t:1527264578630};\\\", \\\"{x:1586,y:583,t:1527264578648};\\\", \\\"{x:1583,y:581,t:1527264578664};\\\", \\\"{x:1581,y:579,t:1527264578680};\\\", \\\"{x:1580,y:579,t:1527264578724};\\\", \\\"{x:1579,y:578,t:1527264578876};\\\", \\\"{x:1579,y:577,t:1527264578884};\\\", \\\"{x:1579,y:576,t:1527264578898};\\\", \\\"{x:1579,y:572,t:1527264578915};\\\", \\\"{x:1579,y:569,t:1527264578931};\\\", \\\"{x:1579,y:562,t:1527264578947};\\\", \\\"{x:1579,y:551,t:1527264578965};\\\", \\\"{x:1581,y:526,t:1527264578982};\\\", \\\"{x:1581,y:499,t:1527264578998};\\\", \\\"{x:1581,y:474,t:1527264579015};\\\", \\\"{x:1582,y:458,t:1527264579031};\\\", \\\"{x:1583,y:450,t:1527264579047};\\\", \\\"{x:1583,y:443,t:1527264579064};\\\", \\\"{x:1583,y:438,t:1527264579081};\\\", \\\"{x:1583,y:436,t:1527264579098};\\\", \\\"{x:1583,y:435,t:1527264579114};\\\", \\\"{x:1585,y:433,t:1527264579131};\\\", \\\"{x:1586,y:431,t:1527264579146};\\\", \\\"{x:1587,y:429,t:1527264579164};\\\", \\\"{x:1588,y:429,t:1527264579235};\\\", \\\"{x:1589,y:429,t:1527264579259};\\\", \\\"{x:1590,y:429,t:1527264579266};\\\", \\\"{x:1591,y:429,t:1527264579281};\\\", \\\"{x:1592,y:430,t:1527264579307};\\\", \\\"{x:1593,y:430,t:1527264579330};\\\", \\\"{x:1594,y:430,t:1527264579363};\\\", \\\"{x:1596,y:430,t:1527264579572};\\\", \\\"{x:1597,y:430,t:1527264579581};\\\", \\\"{x:1598,y:430,t:1527264579598};\\\", \\\"{x:1599,y:430,t:1527264579615};\\\", \\\"{x:1601,y:431,t:1527264579632};\\\", \\\"{x:1601,y:432,t:1527264579648};\\\", \\\"{x:1603,y:432,t:1527264579665};\\\", \\\"{x:1606,y:433,t:1527264579682};\\\", \\\"{x:1609,y:435,t:1527264579698};\\\", \\\"{x:1611,y:436,t:1527264579716};\\\", \\\"{x:1614,y:437,t:1527264579732};\\\", \\\"{x:1617,y:438,t:1527264579748};\\\", \\\"{x:1618,y:438,t:1527264579766};\\\", \\\"{x:1619,y:439,t:1527264579844};\\\", \\\"{x:1620,y:440,t:1527264579908};\\\", \\\"{x:1620,y:441,t:1527264579914};\\\", \\\"{x:1620,y:447,t:1527264579931};\\\", \\\"{x:1620,y:461,t:1527264579947};\\\", \\\"{x:1620,y:477,t:1527264579964};\\\", \\\"{x:1620,y:496,t:1527264579981};\\\", \\\"{x:1620,y:521,t:1527264579998};\\\", \\\"{x:1620,y:545,t:1527264580014};\\\", \\\"{x:1620,y:562,t:1527264580033};\\\", \\\"{x:1619,y:577,t:1527264580049};\\\", \\\"{x:1619,y:592,t:1527264580065};\\\", \\\"{x:1619,y:607,t:1527264580081};\\\", \\\"{x:1619,y:621,t:1527264580098};\\\", \\\"{x:1619,y:642,t:1527264580115};\\\", \\\"{x:1619,y:655,t:1527264580132};\\\", \\\"{x:1617,y:668,t:1527264580148};\\\", \\\"{x:1615,y:681,t:1527264580165};\\\", \\\"{x:1614,y:691,t:1527264580182};\\\", \\\"{x:1613,y:698,t:1527264580197};\\\", \\\"{x:1611,y:707,t:1527264580215};\\\", \\\"{x:1610,y:716,t:1527264580232};\\\", \\\"{x:1609,y:726,t:1527264580248};\\\", \\\"{x:1608,y:734,t:1527264580265};\\\", \\\"{x:1606,y:741,t:1527264580282};\\\", \\\"{x:1606,y:746,t:1527264580298};\\\", \\\"{x:1605,y:751,t:1527264580314};\\\", \\\"{x:1605,y:752,t:1527264580332};\\\", \\\"{x:1605,y:751,t:1527264580419};\\\", \\\"{x:1605,y:745,t:1527264580431};\\\", \\\"{x:1607,y:738,t:1527264580449};\\\", \\\"{x:1610,y:730,t:1527264580465};\\\", \\\"{x:1615,y:718,t:1527264580482};\\\", \\\"{x:1621,y:704,t:1527264580499};\\\", \\\"{x:1622,y:698,t:1527264580515};\\\", \\\"{x:1625,y:691,t:1527264580532};\\\", \\\"{x:1625,y:685,t:1527264580548};\\\", \\\"{x:1625,y:678,t:1527264580565};\\\", \\\"{x:1625,y:672,t:1527264580582};\\\", \\\"{x:1625,y:669,t:1527264580599};\\\", \\\"{x:1625,y:665,t:1527264580615};\\\", \\\"{x:1625,y:661,t:1527264580632};\\\", \\\"{x:1625,y:659,t:1527264580649};\\\", \\\"{x:1625,y:658,t:1527264580699};\\\", \\\"{x:1625,y:657,t:1527264580716};\\\", \\\"{x:1625,y:655,t:1527264580732};\\\", \\\"{x:1624,y:653,t:1527264580749};\\\", \\\"{x:1623,y:649,t:1527264580766};\\\", \\\"{x:1621,y:645,t:1527264580782};\\\", \\\"{x:1621,y:643,t:1527264580799};\\\", \\\"{x:1620,y:642,t:1527264580816};\\\", \\\"{x:1620,y:639,t:1527264580832};\\\", \\\"{x:1620,y:638,t:1527264580851};\\\", \\\"{x:1620,y:639,t:1527264580939};\\\", \\\"{x:1620,y:643,t:1527264580949};\\\", \\\"{x:1620,y:650,t:1527264580966};\\\", \\\"{x:1617,y:662,t:1527264580982};\\\", \\\"{x:1616,y:673,t:1527264580998};\\\", \\\"{x:1612,y:685,t:1527264581016};\\\", \\\"{x:1611,y:698,t:1527264581032};\\\", \\\"{x:1611,y:708,t:1527264581049};\\\", \\\"{x:1611,y:716,t:1527264581066};\\\", \\\"{x:1611,y:724,t:1527264581083};\\\", \\\"{x:1611,y:730,t:1527264581098};\\\", \\\"{x:1611,y:731,t:1527264581116};\\\", \\\"{x:1611,y:735,t:1527264581133};\\\", \\\"{x:1611,y:737,t:1527264581149};\\\", \\\"{x:1611,y:739,t:1527264581166};\\\", \\\"{x:1611,y:741,t:1527264581183};\\\", \\\"{x:1612,y:743,t:1527264581199};\\\", \\\"{x:1612,y:746,t:1527264581216};\\\", \\\"{x:1612,y:749,t:1527264581233};\\\", \\\"{x:1612,y:754,t:1527264581249};\\\", \\\"{x:1612,y:761,t:1527264581266};\\\", \\\"{x:1612,y:770,t:1527264581283};\\\", \\\"{x:1612,y:777,t:1527264581299};\\\", \\\"{x:1612,y:781,t:1527264581316};\\\", \\\"{x:1612,y:786,t:1527264581333};\\\", \\\"{x:1612,y:796,t:1527264581349};\\\", \\\"{x:1612,y:811,t:1527264581367};\\\", \\\"{x:1612,y:830,t:1527264581384};\\\", \\\"{x:1612,y:848,t:1527264581401};\\\", \\\"{x:1612,y:860,t:1527264581416};\\\", \\\"{x:1612,y:870,t:1527264581434};\\\", \\\"{x:1612,y:876,t:1527264581450};\\\", \\\"{x:1612,y:882,t:1527264581466};\\\", \\\"{x:1613,y:891,t:1527264581482};\\\", \\\"{x:1615,y:895,t:1527264581500};\\\", \\\"{x:1615,y:898,t:1527264581516};\\\", \\\"{x:1616,y:901,t:1527264581533};\\\", \\\"{x:1616,y:906,t:1527264581550};\\\", \\\"{x:1616,y:910,t:1527264581566};\\\", \\\"{x:1616,y:914,t:1527264581582};\\\", \\\"{x:1616,y:917,t:1527264581599};\\\", \\\"{x:1617,y:919,t:1527264581615};\\\", \\\"{x:1619,y:924,t:1527264581632};\\\", \\\"{x:1619,y:927,t:1527264581650};\\\", \\\"{x:1620,y:931,t:1527264581666};\\\", \\\"{x:1621,y:936,t:1527264581683};\\\", \\\"{x:1621,y:938,t:1527264581699};\\\", \\\"{x:1621,y:941,t:1527264581717};\\\", \\\"{x:1622,y:944,t:1527264581733};\\\", \\\"{x:1622,y:945,t:1527264581755};\\\", \\\"{x:1622,y:948,t:1527264581767};\\\", \\\"{x:1623,y:951,t:1527264581783};\\\", \\\"{x:1624,y:955,t:1527264581800};\\\", \\\"{x:1624,y:956,t:1527264581819};\\\", \\\"{x:1624,y:958,t:1527264581833};\\\", \\\"{x:1626,y:961,t:1527264581850};\\\", \\\"{x:1626,y:962,t:1527264581867};\\\", \\\"{x:1626,y:963,t:1527264581884};\\\", \\\"{x:1626,y:964,t:1527264581900};\\\", \\\"{x:1626,y:965,t:1527264582043};\\\", \\\"{x:1626,y:966,t:1527264582059};\\\", \\\"{x:1626,y:967,t:1527264582066};\\\", \\\"{x:1626,y:969,t:1527264582115};\\\", \\\"{x:1626,y:970,t:1527264582155};\\\", \\\"{x:1626,y:971,t:1527264582167};\\\", \\\"{x:1625,y:971,t:1527264582284};\\\", \\\"{x:1624,y:971,t:1527264582443};\\\", \\\"{x:1623,y:970,t:1527264582451};\\\", \\\"{x:1623,y:968,t:1527264582469};\\\", \\\"{x:1622,y:963,t:1527264582485};\\\", \\\"{x:1621,y:951,t:1527264582501};\\\", \\\"{x:1617,y:936,t:1527264582518};\\\", \\\"{x:1613,y:919,t:1527264582534};\\\", \\\"{x:1609,y:901,t:1527264582552};\\\", \\\"{x:1608,y:887,t:1527264582568};\\\", \\\"{x:1605,y:870,t:1527264582584};\\\", \\\"{x:1602,y:851,t:1527264582601};\\\", \\\"{x:1600,y:833,t:1527264582618};\\\", \\\"{x:1596,y:808,t:1527264582635};\\\", \\\"{x:1590,y:771,t:1527264582650};\\\", \\\"{x:1585,y:745,t:1527264582667};\\\", \\\"{x:1584,y:719,t:1527264582684};\\\", \\\"{x:1583,y:696,t:1527264582701};\\\", \\\"{x:1583,y:671,t:1527264582717};\\\", \\\"{x:1583,y:648,t:1527264582734};\\\", \\\"{x:1583,y:618,t:1527264582751};\\\", \\\"{x:1583,y:585,t:1527264582767};\\\", \\\"{x:1583,y:558,t:1527264582785};\\\", \\\"{x:1583,y:537,t:1527264582802};\\\", \\\"{x:1583,y:526,t:1527264582818};\\\", \\\"{x:1585,y:511,t:1527264582834};\\\", \\\"{x:1587,y:484,t:1527264582852};\\\", \\\"{x:1587,y:469,t:1527264582868};\\\", \\\"{x:1588,y:460,t:1527264582885};\\\", \\\"{x:1590,y:454,t:1527264582901};\\\", \\\"{x:1591,y:452,t:1527264582918};\\\", \\\"{x:1591,y:450,t:1527264582935};\\\", \\\"{x:1592,y:447,t:1527264582951};\\\", \\\"{x:1594,y:445,t:1527264582968};\\\", \\\"{x:1595,y:442,t:1527264582984};\\\", \\\"{x:1596,y:442,t:1527264583001};\\\", \\\"{x:1598,y:440,t:1527264583018};\\\", \\\"{x:1598,y:439,t:1527264583034};\\\", \\\"{x:1601,y:435,t:1527264583051};\\\", \\\"{x:1603,y:432,t:1527264583068};\\\", \\\"{x:1604,y:431,t:1527264583084};\\\", \\\"{x:1605,y:429,t:1527264583102};\\\", \\\"{x:1606,y:429,t:1527264583118};\\\", \\\"{x:1607,y:429,t:1527264583179};\\\", \\\"{x:1606,y:429,t:1527264583492};\\\", \\\"{x:1603,y:429,t:1527264583502};\\\", \\\"{x:1599,y:429,t:1527264583518};\\\", \\\"{x:1597,y:429,t:1527264583535};\\\", \\\"{x:1596,y:429,t:1527264583628};\\\", \\\"{x:1595,y:430,t:1527264583644};\\\", \\\"{x:1594,y:430,t:1527264583660};\\\", \\\"{x:1593,y:431,t:1527264583669};\\\", \\\"{x:1590,y:431,t:1527264583685};\\\", \\\"{x:1587,y:433,t:1527264583703};\\\", \\\"{x:1581,y:434,t:1527264583719};\\\", \\\"{x:1576,y:434,t:1527264583735};\\\", \\\"{x:1571,y:435,t:1527264583752};\\\", \\\"{x:1567,y:436,t:1527264583768};\\\", \\\"{x:1562,y:437,t:1527264583785};\\\", \\\"{x:1556,y:438,t:1527264583802};\\\", \\\"{x:1554,y:439,t:1527264583819};\\\", \\\"{x:1552,y:439,t:1527264583835};\\\", \\\"{x:1552,y:440,t:1527264584156};\\\", \\\"{x:1553,y:440,t:1527264584169};\\\", \\\"{x:1558,y:440,t:1527264584185};\\\", \\\"{x:1565,y:439,t:1527264584203};\\\", \\\"{x:1580,y:436,t:1527264584219};\\\", \\\"{x:1596,y:435,t:1527264584235};\\\", \\\"{x:1613,y:434,t:1527264584253};\\\", \\\"{x:1623,y:432,t:1527264584270};\\\", \\\"{x:1628,y:432,t:1527264584287};\\\", \\\"{x:1630,y:432,t:1527264584303};\\\", \\\"{x:1631,y:431,t:1527264584332};\\\", \\\"{x:1628,y:430,t:1527264584708};\\\", \\\"{x:1625,y:429,t:1527264584720};\\\", \\\"{x:1619,y:427,t:1527264584736};\\\", \\\"{x:1618,y:426,t:1527264584753};\\\", \\\"{x:1616,y:426,t:1527264584770};\\\", \\\"{x:1615,y:426,t:1527264584787};\\\", \\\"{x:1614,y:424,t:1527264584804};\\\", \\\"{x:1614,y:425,t:1527264584931};\\\", \\\"{x:1614,y:426,t:1527264584962};\\\", \\\"{x:1614,y:427,t:1527264589123};\\\", \\\"{x:1605,y:441,t:1527264589141};\\\", \\\"{x:1585,y:461,t:1527264589157};\\\", \\\"{x:1559,y:482,t:1527264589173};\\\", \\\"{x:1531,y:500,t:1527264589190};\\\", \\\"{x:1508,y:515,t:1527264589208};\\\", \\\"{x:1487,y:525,t:1527264589223};\\\", \\\"{x:1468,y:534,t:1527264589240};\\\", \\\"{x:1450,y:540,t:1527264589257};\\\", \\\"{x:1431,y:548,t:1527264589274};\\\", \\\"{x:1414,y:554,t:1527264589290};\\\", \\\"{x:1391,y:562,t:1527264589307};\\\", \\\"{x:1375,y:567,t:1527264589324};\\\", \\\"{x:1359,y:575,t:1527264589340};\\\", \\\"{x:1347,y:582,t:1527264589357};\\\", \\\"{x:1340,y:585,t:1527264589374};\\\", \\\"{x:1335,y:589,t:1527264589391};\\\", \\\"{x:1331,y:593,t:1527264589408};\\\", \\\"{x:1329,y:596,t:1527264589424};\\\", \\\"{x:1326,y:601,t:1527264589440};\\\", \\\"{x:1323,y:607,t:1527264589458};\\\", \\\"{x:1319,y:614,t:1527264589474};\\\", \\\"{x:1314,y:621,t:1527264589491};\\\", \\\"{x:1306,y:631,t:1527264589507};\\\", \\\"{x:1302,y:638,t:1527264589525};\\\", \\\"{x:1300,y:644,t:1527264589541};\\\", \\\"{x:1297,y:650,t:1527264589558};\\\", \\\"{x:1296,y:656,t:1527264589574};\\\", \\\"{x:1293,y:661,t:1527264589590};\\\", \\\"{x:1292,y:666,t:1527264589608};\\\", \\\"{x:1290,y:671,t:1527264589625};\\\", \\\"{x:1289,y:676,t:1527264589641};\\\", \\\"{x:1289,y:682,t:1527264589657};\\\", \\\"{x:1289,y:685,t:1527264589674};\\\", \\\"{x:1289,y:691,t:1527264589691};\\\", \\\"{x:1288,y:693,t:1527264589707};\\\", \\\"{x:1287,y:695,t:1527264589725};\\\", \\\"{x:1286,y:695,t:1527264589755};\\\", \\\"{x:1285,y:695,t:1527264590043};\\\", \\\"{x:1282,y:694,t:1527264590058};\\\", \\\"{x:1273,y:691,t:1527264590074};\\\", \\\"{x:1261,y:690,t:1527264590090};\\\", \\\"{x:1261,y:691,t:1527264590156};\\\", \\\"{x:1261,y:695,t:1527264590163};\\\", \\\"{x:1260,y:703,t:1527264590175};\\\", \\\"{x:1256,y:721,t:1527264590192};\\\", \\\"{x:1253,y:749,t:1527264590209};\\\", \\\"{x:1248,y:776,t:1527264590224};\\\", \\\"{x:1243,y:796,t:1527264590242};\\\", \\\"{x:1238,y:814,t:1527264590258};\\\", \\\"{x:1233,y:832,t:1527264590275};\\\", \\\"{x:1232,y:838,t:1527264590292};\\\", \\\"{x:1227,y:845,t:1527264590308};\\\", \\\"{x:1226,y:851,t:1527264590324};\\\", \\\"{x:1224,y:859,t:1527264590341};\\\", \\\"{x:1223,y:864,t:1527264590358};\\\", \\\"{x:1221,y:866,t:1527264590375};\\\", \\\"{x:1221,y:870,t:1527264590391};\\\", \\\"{x:1221,y:874,t:1527264590409};\\\", \\\"{x:1221,y:880,t:1527264590425};\\\", \\\"{x:1221,y:887,t:1527264590441};\\\", \\\"{x:1223,y:894,t:1527264590458};\\\", \\\"{x:1223,y:900,t:1527264590474};\\\", \\\"{x:1225,y:902,t:1527264590491};\\\", \\\"{x:1225,y:905,t:1527264590508};\\\", \\\"{x:1225,y:909,t:1527264590526};\\\", \\\"{x:1224,y:911,t:1527264590542};\\\", \\\"{x:1224,y:913,t:1527264590558};\\\", \\\"{x:1222,y:915,t:1527264590575};\\\", \\\"{x:1221,y:917,t:1527264590591};\\\", \\\"{x:1219,y:919,t:1527264590609};\\\", \\\"{x:1216,y:920,t:1527264590625};\\\", \\\"{x:1214,y:922,t:1527264590641};\\\", \\\"{x:1210,y:925,t:1527264590658};\\\", \\\"{x:1205,y:926,t:1527264590675};\\\", \\\"{x:1200,y:928,t:1527264590691};\\\", \\\"{x:1194,y:930,t:1527264590708};\\\", \\\"{x:1188,y:932,t:1527264590725};\\\", \\\"{x:1182,y:933,t:1527264590743};\\\", \\\"{x:1176,y:936,t:1527264590759};\\\", \\\"{x:1171,y:936,t:1527264590776};\\\", \\\"{x:1168,y:937,t:1527264590792};\\\", \\\"{x:1162,y:938,t:1527264590809};\\\", \\\"{x:1159,y:939,t:1527264590826};\\\", \\\"{x:1156,y:940,t:1527264590843};\\\", \\\"{x:1152,y:941,t:1527264590859};\\\", \\\"{x:1149,y:942,t:1527264590876};\\\", \\\"{x:1145,y:944,t:1527264590892};\\\", \\\"{x:1141,y:944,t:1527264590909};\\\", \\\"{x:1137,y:945,t:1527264590926};\\\", \\\"{x:1133,y:947,t:1527264590943};\\\", \\\"{x:1129,y:947,t:1527264590959};\\\", \\\"{x:1124,y:949,t:1527264590976};\\\", \\\"{x:1120,y:951,t:1527264590992};\\\", \\\"{x:1117,y:951,t:1527264591008};\\\", \\\"{x:1113,y:952,t:1527264591026};\\\", \\\"{x:1112,y:953,t:1527264591043};\\\", \\\"{x:1108,y:953,t:1527264591060};\\\", \\\"{x:1106,y:953,t:1527264591075};\\\", \\\"{x:1105,y:953,t:1527264591093};\\\", \\\"{x:1104,y:954,t:1527264591110};\\\", \\\"{x:1103,y:954,t:1527264591126};\\\", \\\"{x:1102,y:955,t:1527264591143};\\\", \\\"{x:1100,y:955,t:1527264591244};\\\", \\\"{x:1099,y:955,t:1527264591268};\\\", \\\"{x:1097,y:955,t:1527264591284};\\\", \\\"{x:1096,y:956,t:1527264591300};\\\", \\\"{x:1095,y:956,t:1527264591396};\\\", \\\"{x:1095,y:957,t:1527264591410};\\\", \\\"{x:1094,y:957,t:1527264591468};\\\", \\\"{x:1093,y:958,t:1527264591532};\\\", \\\"{x:1092,y:958,t:1527264591604};\\\", \\\"{x:1091,y:958,t:1527264591692};\\\", \\\"{x:1090,y:958,t:1527264591710};\\\", \\\"{x:1090,y:959,t:1527264591748};\\\", \\\"{x:1089,y:959,t:1527264591771};\\\", \\\"{x:1088,y:959,t:1527264591779};\\\", \\\"{x:1087,y:959,t:1527264591796};\\\", \\\"{x:1086,y:960,t:1527264591813};\\\", \\\"{x:1085,y:960,t:1527264591892};\\\", \\\"{x:1090,y:957,t:1527264592340};\\\", \\\"{x:1095,y:953,t:1527264592348};\\\", \\\"{x:1100,y:949,t:1527264592361};\\\", \\\"{x:1115,y:939,t:1527264592377};\\\", \\\"{x:1130,y:929,t:1527264592394};\\\", \\\"{x:1153,y:915,t:1527264592414};\\\", \\\"{x:1167,y:908,t:1527264592427};\\\", \\\"{x:1175,y:904,t:1527264592444};\\\", \\\"{x:1182,y:899,t:1527264592461};\\\", \\\"{x:1191,y:893,t:1527264592478};\\\", \\\"{x:1205,y:887,t:1527264592494};\\\", \\\"{x:1220,y:878,t:1527264592511};\\\", \\\"{x:1237,y:868,t:1527264592528};\\\", \\\"{x:1256,y:857,t:1527264592544};\\\", \\\"{x:1279,y:844,t:1527264592560};\\\", \\\"{x:1299,y:832,t:1527264592578};\\\", \\\"{x:1318,y:817,t:1527264592594};\\\", \\\"{x:1350,y:798,t:1527264592613};\\\", \\\"{x:1370,y:782,t:1527264592627};\\\", \\\"{x:1397,y:766,t:1527264592643};\\\", \\\"{x:1415,y:755,t:1527264592661};\\\", \\\"{x:1434,y:744,t:1527264592677};\\\", \\\"{x:1449,y:735,t:1527264592693};\\\", \\\"{x:1464,y:726,t:1527264592711};\\\", \\\"{x:1479,y:718,t:1527264592727};\\\", \\\"{x:1486,y:713,t:1527264592743};\\\", \\\"{x:1493,y:711,t:1527264592760};\\\", \\\"{x:1502,y:708,t:1527264592778};\\\", \\\"{x:1510,y:707,t:1527264592793};\\\", \\\"{x:1517,y:707,t:1527264592812};\\\", \\\"{x:1520,y:707,t:1527264592827};\\\", \\\"{x:1521,y:707,t:1527264592851};\\\", \\\"{x:1523,y:708,t:1527264592860};\\\", \\\"{x:1523,y:711,t:1527264592878};\\\", \\\"{x:1524,y:715,t:1527264592895};\\\", \\\"{x:1527,y:722,t:1527264592910};\\\", \\\"{x:1529,y:727,t:1527264592927};\\\", \\\"{x:1532,y:735,t:1527264592944};\\\", \\\"{x:1533,y:743,t:1527264592961};\\\", \\\"{x:1536,y:747,t:1527264592979};\\\", \\\"{x:1538,y:753,t:1527264592995};\\\", \\\"{x:1540,y:756,t:1527264593014};\\\", \\\"{x:1541,y:759,t:1527264593028};\\\", \\\"{x:1542,y:760,t:1527264593045};\\\", \\\"{x:1542,y:761,t:1527264593074};\\\", \\\"{x:1542,y:755,t:1527264593755};\\\", \\\"{x:1545,y:746,t:1527264593762};\\\", \\\"{x:1554,y:720,t:1527264593779};\\\", \\\"{x:1568,y:688,t:1527264593795};\\\", \\\"{x:1591,y:647,t:1527264593811};\\\", \\\"{x:1616,y:611,t:1527264593829};\\\", \\\"{x:1630,y:587,t:1527264593845};\\\", \\\"{x:1637,y:572,t:1527264593862};\\\", \\\"{x:1642,y:559,t:1527264593878};\\\", \\\"{x:1644,y:553,t:1527264593895};\\\", \\\"{x:1645,y:550,t:1527264593911};\\\", \\\"{x:1645,y:545,t:1527264593928};\\\", \\\"{x:1645,y:538,t:1527264593945};\\\", \\\"{x:1645,y:532,t:1527264593962};\\\", \\\"{x:1644,y:528,t:1527264593979};\\\", \\\"{x:1643,y:524,t:1527264593994};\\\", \\\"{x:1639,y:516,t:1527264594012};\\\", \\\"{x:1636,y:508,t:1527264594031};\\\", \\\"{x:1631,y:496,t:1527264594048};\\\", \\\"{x:1624,y:482,t:1527264594065};\\\", \\\"{x:1622,y:471,t:1527264594082};\\\", \\\"{x:1621,y:464,t:1527264594098};\\\", \\\"{x:1621,y:455,t:1527264594115};\\\", \\\"{x:1622,y:446,t:1527264594131};\\\", \\\"{x:1623,y:440,t:1527264594148};\\\", \\\"{x:1623,y:438,t:1527264594164};\\\", \\\"{x:1623,y:437,t:1527264594181};\\\", \\\"{x:1623,y:436,t:1527264594215};\\\", \\\"{x:1623,y:435,t:1527264594238};\\\", \\\"{x:1623,y:434,t:1527264594249};\\\", \\\"{x:1623,y:433,t:1527264594264};\\\", \\\"{x:1623,y:432,t:1527264594286};\\\", \\\"{x:1623,y:430,t:1527264594375};\\\", \\\"{x:1622,y:430,t:1527264594423};\\\", \\\"{x:1622,y:429,t:1527264594432};\\\", \\\"{x:1621,y:429,t:1527264594519};\\\", \\\"{x:1620,y:429,t:1527264594534};\\\", \\\"{x:1619,y:429,t:1527264594549};\\\", \\\"{x:1618,y:432,t:1527264594566};\\\", \\\"{x:1617,y:435,t:1527264594582};\\\", \\\"{x:1615,y:437,t:1527264594600};\\\", \\\"{x:1615,y:438,t:1527264594615};\\\", \\\"{x:1614,y:439,t:1527264594632};\\\", \\\"{x:1614,y:440,t:1527264594957};\\\", \\\"{x:1614,y:442,t:1527264594965};\\\", \\\"{x:1614,y:446,t:1527264594983};\\\", \\\"{x:1614,y:452,t:1527264594999};\\\", \\\"{x:1614,y:459,t:1527264595015};\\\", \\\"{x:1614,y:471,t:1527264595033};\\\", \\\"{x:1614,y:487,t:1527264595049};\\\", \\\"{x:1614,y:512,t:1527264595065};\\\", \\\"{x:1614,y:554,t:1527264595082};\\\", \\\"{x:1614,y:612,t:1527264595100};\\\", \\\"{x:1617,y:677,t:1527264595116};\\\", \\\"{x:1620,y:731,t:1527264595132};\\\", \\\"{x:1624,y:779,t:1527264595149};\\\", \\\"{x:1624,y:800,t:1527264595165};\\\", \\\"{x:1624,y:813,t:1527264595182};\\\", \\\"{x:1625,y:826,t:1527264595200};\\\", \\\"{x:1625,y:834,t:1527264595215};\\\", \\\"{x:1625,y:843,t:1527264595232};\\\", \\\"{x:1625,y:854,t:1527264595250};\\\", \\\"{x:1625,y:866,t:1527264595266};\\\", \\\"{x:1625,y:877,t:1527264595282};\\\", \\\"{x:1625,y:890,t:1527264595300};\\\", \\\"{x:1625,y:896,t:1527264595316};\\\", \\\"{x:1625,y:904,t:1527264595333};\\\", \\\"{x:1624,y:911,t:1527264595349};\\\", \\\"{x:1623,y:920,t:1527264595366};\\\", \\\"{x:1621,y:928,t:1527264595383};\\\", \\\"{x:1620,y:935,t:1527264595399};\\\", \\\"{x:1619,y:941,t:1527264595417};\\\", \\\"{x:1617,y:946,t:1527264595432};\\\", \\\"{x:1616,y:951,t:1527264595449};\\\", \\\"{x:1616,y:954,t:1527264595466};\\\", \\\"{x:1616,y:955,t:1527264595482};\\\", \\\"{x:1616,y:957,t:1527264595502};\\\", \\\"{x:1616,y:953,t:1527264595694};\\\", \\\"{x:1616,y:948,t:1527264595702};\\\", \\\"{x:1616,y:941,t:1527264595717};\\\", \\\"{x:1616,y:912,t:1527264595733};\\\", \\\"{x:1616,y:884,t:1527264595750};\\\", \\\"{x:1616,y:858,t:1527264595767};\\\", \\\"{x:1617,y:820,t:1527264595784};\\\", \\\"{x:1617,y:778,t:1527264595799};\\\", \\\"{x:1617,y:745,t:1527264595816};\\\", \\\"{x:1617,y:717,t:1527264595833};\\\", \\\"{x:1617,y:694,t:1527264595849};\\\", \\\"{x:1617,y:675,t:1527264595867};\\\", \\\"{x:1617,y:655,t:1527264595884};\\\", \\\"{x:1617,y:642,t:1527264595900};\\\", \\\"{x:1617,y:629,t:1527264595917};\\\", \\\"{x:1617,y:609,t:1527264595934};\\\", \\\"{x:1616,y:593,t:1527264595950};\\\", \\\"{x:1613,y:576,t:1527264595967};\\\", \\\"{x:1612,y:559,t:1527264595984};\\\", \\\"{x:1610,y:542,t:1527264596000};\\\", \\\"{x:1608,y:530,t:1527264596016};\\\", \\\"{x:1607,y:518,t:1527264596034};\\\", \\\"{x:1606,y:510,t:1527264596050};\\\", \\\"{x:1603,y:499,t:1527264596066};\\\", \\\"{x:1603,y:487,t:1527264596083};\\\", \\\"{x:1603,y:474,t:1527264596101};\\\", \\\"{x:1603,y:463,t:1527264596116};\\\", \\\"{x:1605,y:449,t:1527264596134};\\\", \\\"{x:1607,y:440,t:1527264596151};\\\", \\\"{x:1607,y:434,t:1527264596166};\\\", \\\"{x:1607,y:428,t:1527264596183};\\\", \\\"{x:1607,y:427,t:1527264596201};\\\", \\\"{x:1607,y:426,t:1527264596216};\\\", \\\"{x:1607,y:429,t:1527264596750};\\\", \\\"{x:1607,y:445,t:1527264596768};\\\", \\\"{x:1607,y:467,t:1527264596785};\\\", \\\"{x:1607,y:489,t:1527264596801};\\\", \\\"{x:1607,y:508,t:1527264596817};\\\", \\\"{x:1607,y:522,t:1527264596835};\\\", \\\"{x:1607,y:534,t:1527264596851};\\\", \\\"{x:1607,y:541,t:1527264596868};\\\", \\\"{x:1608,y:550,t:1527264596884};\\\", \\\"{x:1608,y:556,t:1527264596901};\\\", \\\"{x:1610,y:565,t:1527264596917};\\\", \\\"{x:1611,y:567,t:1527264596934};\\\", \\\"{x:1611,y:568,t:1527264596951};\\\", \\\"{x:1611,y:570,t:1527264602775};\\\", \\\"{x:1604,y:573,t:1527264602790};\\\", \\\"{x:1597,y:576,t:1527264602807};\\\", \\\"{x:1591,y:578,t:1527264602823};\\\", \\\"{x:1585,y:584,t:1527264602840};\\\", \\\"{x:1579,y:588,t:1527264602857};\\\", \\\"{x:1569,y:596,t:1527264602874};\\\", \\\"{x:1557,y:604,t:1527264602890};\\\", \\\"{x:1540,y:616,t:1527264602907};\\\", \\\"{x:1519,y:631,t:1527264602924};\\\", \\\"{x:1501,y:643,t:1527264602941};\\\", \\\"{x:1481,y:657,t:1527264602957};\\\", \\\"{x:1458,y:673,t:1527264602974};\\\", \\\"{x:1444,y:682,t:1527264602990};\\\", \\\"{x:1435,y:689,t:1527264603007};\\\", \\\"{x:1427,y:696,t:1527264603025};\\\", \\\"{x:1420,y:702,t:1527264603041};\\\", \\\"{x:1412,y:710,t:1527264603057};\\\", \\\"{x:1404,y:717,t:1527264603073};\\\", \\\"{x:1395,y:730,t:1527264603089};\\\", \\\"{x:1383,y:741,t:1527264603106};\\\", \\\"{x:1374,y:751,t:1527264603123};\\\", \\\"{x:1363,y:764,t:1527264603140};\\\", \\\"{x:1355,y:775,t:1527264603156};\\\", \\\"{x:1340,y:790,t:1527264603173};\\\", \\\"{x:1327,y:801,t:1527264603191};\\\", \\\"{x:1314,y:812,t:1527264603206};\\\", \\\"{x:1305,y:821,t:1527264603223};\\\", \\\"{x:1297,y:827,t:1527264603240};\\\", \\\"{x:1288,y:836,t:1527264603256};\\\", \\\"{x:1278,y:845,t:1527264603274};\\\", \\\"{x:1271,y:851,t:1527264603290};\\\", \\\"{x:1265,y:860,t:1527264603306};\\\", \\\"{x:1257,y:868,t:1527264603324};\\\", \\\"{x:1251,y:875,t:1527264603341};\\\", \\\"{x:1247,y:879,t:1527264603356};\\\", \\\"{x:1244,y:880,t:1527264603374};\\\", \\\"{x:1242,y:878,t:1527264603517};\\\", \\\"{x:1241,y:875,t:1527264603525};\\\", \\\"{x:1238,y:869,t:1527264603540};\\\", \\\"{x:1230,y:855,t:1527264603557};\\\", \\\"{x:1224,y:846,t:1527264603574};\\\", \\\"{x:1220,y:841,t:1527264603591};\\\", \\\"{x:1218,y:839,t:1527264603607};\\\", \\\"{x:1217,y:837,t:1527264603624};\\\", \\\"{x:1216,y:836,t:1527264604149};\\\", \\\"{x:1214,y:835,t:1527264604158};\\\", \\\"{x:1214,y:834,t:1527264605462};\\\", \\\"{x:1214,y:833,t:1527264605476};\\\", \\\"{x:1220,y:832,t:1527264605495};\\\", \\\"{x:1226,y:829,t:1527264605509};\\\", \\\"{x:1245,y:819,t:1527264605526};\\\", \\\"{x:1257,y:812,t:1527264605543};\\\", \\\"{x:1276,y:797,t:1527264605559};\\\", \\\"{x:1298,y:781,t:1527264605576};\\\", \\\"{x:1320,y:767,t:1527264605594};\\\", \\\"{x:1346,y:747,t:1527264605609};\\\", \\\"{x:1371,y:727,t:1527264605626};\\\", \\\"{x:1393,y:708,t:1527264605643};\\\", \\\"{x:1413,y:696,t:1527264605660};\\\", \\\"{x:1429,y:685,t:1527264605677};\\\", \\\"{x:1436,y:678,t:1527264605693};\\\", \\\"{x:1445,y:671,t:1527264605709};\\\", \\\"{x:1463,y:657,t:1527264605726};\\\", \\\"{x:1474,y:650,t:1527264605743};\\\", \\\"{x:1489,y:639,t:1527264605760};\\\", \\\"{x:1507,y:624,t:1527264605777};\\\", \\\"{x:1527,y:609,t:1527264605793};\\\", \\\"{x:1544,y:593,t:1527264605810};\\\", \\\"{x:1558,y:578,t:1527264605826};\\\", \\\"{x:1569,y:565,t:1527264605844};\\\", \\\"{x:1575,y:556,t:1527264605860};\\\", \\\"{x:1581,y:548,t:1527264605876};\\\", \\\"{x:1584,y:543,t:1527264605893};\\\", \\\"{x:1591,y:535,t:1527264605910};\\\", \\\"{x:1597,y:525,t:1527264605927};\\\", \\\"{x:1601,y:519,t:1527264605943};\\\", \\\"{x:1606,y:513,t:1527264605961};\\\", \\\"{x:1609,y:509,t:1527264605977};\\\", \\\"{x:1610,y:505,t:1527264605994};\\\", \\\"{x:1612,y:502,t:1527264606010};\\\", \\\"{x:1614,y:500,t:1527264606026};\\\", \\\"{x:1616,y:498,t:1527264606043};\\\", \\\"{x:1616,y:494,t:1527264606060};\\\", \\\"{x:1618,y:491,t:1527264606076};\\\", \\\"{x:1618,y:488,t:1527264606093};\\\", \\\"{x:1618,y:486,t:1527264606110};\\\", \\\"{x:1618,y:485,t:1527264606127};\\\", \\\"{x:1618,y:484,t:1527264606143};\\\", \\\"{x:1618,y:482,t:1527264606160};\\\", \\\"{x:1618,y:479,t:1527264606177};\\\", \\\"{x:1618,y:477,t:1527264606193};\\\", \\\"{x:1618,y:474,t:1527264606210};\\\", \\\"{x:1618,y:472,t:1527264606227};\\\", \\\"{x:1618,y:470,t:1527264606243};\\\", \\\"{x:1618,y:469,t:1527264606261};\\\", \\\"{x:1618,y:468,t:1527264606277};\\\", \\\"{x:1618,y:466,t:1527264606293};\\\", \\\"{x:1618,y:462,t:1527264606310};\\\", \\\"{x:1618,y:461,t:1527264606333};\\\", \\\"{x:1618,y:460,t:1527264606343};\\\", \\\"{x:1617,y:460,t:1527264606943};\\\", \\\"{x:1617,y:462,t:1527264606950};\\\", \\\"{x:1617,y:466,t:1527264606961};\\\", \\\"{x:1615,y:474,t:1527264606977};\\\", \\\"{x:1614,y:483,t:1527264606995};\\\", \\\"{x:1612,y:493,t:1527264607012};\\\", \\\"{x:1610,y:501,t:1527264607027};\\\", \\\"{x:1609,y:508,t:1527264607045};\\\", \\\"{x:1609,y:515,t:1527264607061};\\\", \\\"{x:1608,y:518,t:1527264607077};\\\", \\\"{x:1608,y:520,t:1527264607094};\\\", \\\"{x:1608,y:521,t:1527264607111};\\\", \\\"{x:1608,y:522,t:1527264607128};\\\", \\\"{x:1608,y:523,t:1527264607150};\\\", \\\"{x:1608,y:524,t:1527264607174};\\\", \\\"{x:1608,y:525,t:1527264607206};\\\", \\\"{x:1608,y:527,t:1527264607215};\\\", \\\"{x:1608,y:529,t:1527264607230};\\\", \\\"{x:1608,y:531,t:1527264607244};\\\", \\\"{x:1606,y:538,t:1527264607261};\\\", \\\"{x:1606,y:545,t:1527264607278};\\\", \\\"{x:1606,y:550,t:1527264607294};\\\", \\\"{x:1606,y:553,t:1527264607311};\\\", \\\"{x:1606,y:557,t:1527264607328};\\\", \\\"{x:1606,y:560,t:1527264607344};\\\", \\\"{x:1606,y:566,t:1527264607362};\\\", \\\"{x:1606,y:570,t:1527264607379};\\\", \\\"{x:1606,y:574,t:1527264607395};\\\", \\\"{x:1606,y:579,t:1527264607412};\\\", \\\"{x:1606,y:585,t:1527264607428};\\\", \\\"{x:1606,y:590,t:1527264607445};\\\", \\\"{x:1606,y:598,t:1527264607461};\\\", \\\"{x:1607,y:621,t:1527264607478};\\\", \\\"{x:1607,y:632,t:1527264607494};\\\", \\\"{x:1607,y:642,t:1527264607511};\\\", \\\"{x:1608,y:652,t:1527264607528};\\\", \\\"{x:1612,y:661,t:1527264607545};\\\", \\\"{x:1614,y:668,t:1527264607561};\\\", \\\"{x:1615,y:674,t:1527264607578};\\\", \\\"{x:1616,y:680,t:1527264607596};\\\", \\\"{x:1617,y:684,t:1527264607611};\\\", \\\"{x:1619,y:692,t:1527264607628};\\\", \\\"{x:1621,y:706,t:1527264607645};\\\", \\\"{x:1623,y:718,t:1527264607661};\\\", \\\"{x:1625,y:729,t:1527264607678};\\\", \\\"{x:1626,y:733,t:1527264607695};\\\", \\\"{x:1627,y:739,t:1527264607712};\\\", \\\"{x:1628,y:742,t:1527264607729};\\\", \\\"{x:1629,y:748,t:1527264607745};\\\", \\\"{x:1629,y:754,t:1527264607762};\\\", \\\"{x:1630,y:758,t:1527264607779};\\\", \\\"{x:1631,y:762,t:1527264607795};\\\", \\\"{x:1631,y:765,t:1527264607812};\\\", \\\"{x:1632,y:769,t:1527264607828};\\\", \\\"{x:1632,y:773,t:1527264607846};\\\", \\\"{x:1632,y:777,t:1527264607862};\\\", \\\"{x:1635,y:784,t:1527264607879};\\\", \\\"{x:1636,y:787,t:1527264607895};\\\", \\\"{x:1636,y:788,t:1527264607912};\\\", \\\"{x:1636,y:791,t:1527264607929};\\\", \\\"{x:1636,y:792,t:1527264607946};\\\", \\\"{x:1636,y:794,t:1527264607962};\\\", \\\"{x:1637,y:795,t:1527264607978};\\\", \\\"{x:1637,y:797,t:1527264607996};\\\", \\\"{x:1637,y:800,t:1527264608012};\\\", \\\"{x:1637,y:804,t:1527264608028};\\\", \\\"{x:1637,y:810,t:1527264608045};\\\", \\\"{x:1637,y:817,t:1527264608062};\\\", \\\"{x:1636,y:821,t:1527264608078};\\\", \\\"{x:1636,y:823,t:1527264608096};\\\", \\\"{x:1635,y:825,t:1527264608112};\\\", \\\"{x:1635,y:826,t:1527264608134};\\\", \\\"{x:1634,y:827,t:1527264608146};\\\", \\\"{x:1634,y:829,t:1527264608163};\\\", \\\"{x:1634,y:830,t:1527264608179};\\\", \\\"{x:1634,y:831,t:1527264608196};\\\", \\\"{x:1633,y:833,t:1527264608213};\\\", \\\"{x:1632,y:835,t:1527264608231};\\\", \\\"{x:1631,y:835,t:1527264608262};\\\", \\\"{x:1631,y:837,t:1527264608646};\\\", \\\"{x:1631,y:838,t:1527264608662};\\\", \\\"{x:1630,y:842,t:1527264608680};\\\", \\\"{x:1629,y:844,t:1527264608696};\\\", \\\"{x:1629,y:845,t:1527264608712};\\\", \\\"{x:1629,y:847,t:1527264608729};\\\", \\\"{x:1629,y:848,t:1527264608746};\\\", \\\"{x:1628,y:849,t:1527264608763};\\\", \\\"{x:1628,y:850,t:1527264608806};\\\", \\\"{x:1628,y:851,t:1527264608830};\\\", \\\"{x:1628,y:852,t:1527264608854};\\\", \\\"{x:1628,y:853,t:1527264608870};\\\", \\\"{x:1628,y:854,t:1527264608880};\\\", \\\"{x:1628,y:855,t:1527264608896};\\\", \\\"{x:1628,y:857,t:1527264608912};\\\", \\\"{x:1628,y:860,t:1527264608930};\\\", \\\"{x:1628,y:863,t:1527264608946};\\\", \\\"{x:1628,y:864,t:1527264608963};\\\", \\\"{x:1628,y:866,t:1527264608979};\\\", \\\"{x:1628,y:867,t:1527264608997};\\\", \\\"{x:1628,y:869,t:1527264609015};\\\", \\\"{x:1628,y:870,t:1527264609030};\\\", \\\"{x:1628,y:872,t:1527264609046};\\\", \\\"{x:1628,y:874,t:1527264609063};\\\", \\\"{x:1628,y:878,t:1527264609079};\\\", \\\"{x:1626,y:882,t:1527264609096};\\\", \\\"{x:1625,y:885,t:1527264609113};\\\", \\\"{x:1625,y:887,t:1527264609129};\\\", \\\"{x:1625,y:889,t:1527264609146};\\\", \\\"{x:1625,y:890,t:1527264609173};\\\", \\\"{x:1625,y:891,t:1527264609190};\\\", \\\"{x:1625,y:892,t:1527264609197};\\\", \\\"{x:1625,y:893,t:1527264609221};\\\", \\\"{x:1625,y:894,t:1527264609229};\\\", \\\"{x:1624,y:895,t:1527264609246};\\\", \\\"{x:1624,y:897,t:1527264609263};\\\", \\\"{x:1623,y:899,t:1527264609280};\\\", \\\"{x:1623,y:901,t:1527264609296};\\\", \\\"{x:1623,y:904,t:1527264609313};\\\", \\\"{x:1623,y:905,t:1527264609334};\\\", \\\"{x:1623,y:906,t:1527264609347};\\\", \\\"{x:1622,y:907,t:1527264609364};\\\", \\\"{x:1621,y:909,t:1527264609381};\\\", \\\"{x:1621,y:910,t:1527264609396};\\\", \\\"{x:1621,y:912,t:1527264609414};\\\", \\\"{x:1621,y:915,t:1527264609429};\\\", \\\"{x:1621,y:918,t:1527264609446};\\\", \\\"{x:1621,y:920,t:1527264609464};\\\", \\\"{x:1621,y:921,t:1527264609480};\\\", \\\"{x:1621,y:923,t:1527264609496};\\\", \\\"{x:1621,y:925,t:1527264609513};\\\", \\\"{x:1621,y:926,t:1527264609530};\\\", \\\"{x:1621,y:927,t:1527264609546};\\\", \\\"{x:1621,y:928,t:1527264609563};\\\", \\\"{x:1621,y:930,t:1527264609580};\\\", \\\"{x:1621,y:931,t:1527264609597};\\\", \\\"{x:1621,y:932,t:1527264609614};\\\", \\\"{x:1621,y:933,t:1527264609630};\\\", \\\"{x:1621,y:934,t:1527264609653};\\\", \\\"{x:1621,y:935,t:1527264609663};\\\", \\\"{x:1621,y:936,t:1527264609680};\\\", \\\"{x:1621,y:933,t:1527264609854};\\\", \\\"{x:1619,y:928,t:1527264609863};\\\", \\\"{x:1618,y:916,t:1527264609880};\\\", \\\"{x:1618,y:904,t:1527264609897};\\\", \\\"{x:1618,y:895,t:1527264609913};\\\", \\\"{x:1618,y:890,t:1527264609930};\\\", \\\"{x:1619,y:882,t:1527264609948};\\\", \\\"{x:1619,y:874,t:1527264609963};\\\", \\\"{x:1617,y:859,t:1527264609980};\\\", \\\"{x:1611,y:825,t:1527264609997};\\\", \\\"{x:1608,y:808,t:1527264610013};\\\", \\\"{x:1608,y:796,t:1527264610030};\\\", \\\"{x:1608,y:781,t:1527264610047};\\\", \\\"{x:1608,y:771,t:1527264610064};\\\", \\\"{x:1608,y:757,t:1527264610080};\\\", \\\"{x:1605,y:735,t:1527264610097};\\\", \\\"{x:1602,y:712,t:1527264610114};\\\", \\\"{x:1601,y:687,t:1527264610130};\\\", \\\"{x:1601,y:662,t:1527264610147};\\\", \\\"{x:1601,y:623,t:1527264610164};\\\", \\\"{x:1601,y:581,t:1527264610180};\\\", \\\"{x:1601,y:545,t:1527264610197};\\\", \\\"{x:1602,y:529,t:1527264610214};\\\", \\\"{x:1607,y:507,t:1527264610230};\\\", \\\"{x:1610,y:486,t:1527264610247};\\\", \\\"{x:1614,y:470,t:1527264610265};\\\", \\\"{x:1617,y:455,t:1527264610280};\\\", \\\"{x:1620,y:444,t:1527264610298};\\\", \\\"{x:1623,y:435,t:1527264610314};\\\", \\\"{x:1625,y:428,t:1527264610330};\\\", \\\"{x:1626,y:427,t:1527264610347};\\\", \\\"{x:1627,y:423,t:1527264610364};\\\", \\\"{x:1627,y:420,t:1527264610381};\\\", \\\"{x:1627,y:418,t:1527264610397};\\\", \\\"{x:1625,y:418,t:1527264610558};\\\", \\\"{x:1623,y:421,t:1527264610566};\\\", \\\"{x:1619,y:424,t:1527264610582};\\\", \\\"{x:1614,y:429,t:1527264610598};\\\", \\\"{x:1605,y:433,t:1527264610616};\\\", \\\"{x:1596,y:438,t:1527264610631};\\\", \\\"{x:1587,y:442,t:1527264610646};\\\", \\\"{x:1571,y:447,t:1527264610664};\\\", \\\"{x:1561,y:449,t:1527264610681};\\\", \\\"{x:1548,y:452,t:1527264610698};\\\", \\\"{x:1542,y:452,t:1527264610714};\\\", \\\"{x:1536,y:452,t:1527264610731};\\\", \\\"{x:1532,y:453,t:1527264610748};\\\", \\\"{x:1527,y:453,t:1527264610764};\\\", \\\"{x:1516,y:453,t:1527264610781};\\\", \\\"{x:1502,y:453,t:1527264610797};\\\", \\\"{x:1491,y:454,t:1527264610814};\\\", \\\"{x:1483,y:456,t:1527264610831};\\\", \\\"{x:1471,y:458,t:1527264610848};\\\", \\\"{x:1459,y:459,t:1527264610864};\\\", \\\"{x:1445,y:461,t:1527264610882};\\\", \\\"{x:1428,y:462,t:1527264610898};\\\", \\\"{x:1409,y:463,t:1527264610915};\\\", \\\"{x:1394,y:463,t:1527264610931};\\\", \\\"{x:1379,y:463,t:1527264610948};\\\", \\\"{x:1368,y:463,t:1527264610964};\\\", \\\"{x:1356,y:463,t:1527264610981};\\\", \\\"{x:1349,y:463,t:1527264610998};\\\", \\\"{x:1346,y:463,t:1527264611015};\\\", \\\"{x:1340,y:463,t:1527264611031};\\\", \\\"{x:1337,y:463,t:1527264611049};\\\", \\\"{x:1336,y:463,t:1527264611065};\\\", \\\"{x:1335,y:463,t:1527264611081};\\\", \\\"{x:1334,y:464,t:1527264611098};\\\", \\\"{x:1332,y:465,t:1527264611142};\\\", \\\"{x:1331,y:465,t:1527264611190};\\\", \\\"{x:1330,y:466,t:1527264611207};\\\", \\\"{x:1328,y:467,t:1527264613567};\\\", \\\"{x:1314,y:482,t:1527264613585};\\\", \\\"{x:1293,y:508,t:1527264613601};\\\", \\\"{x:1271,y:542,t:1527264613618};\\\", \\\"{x:1256,y:575,t:1527264613635};\\\", \\\"{x:1238,y:603,t:1527264613650};\\\", \\\"{x:1220,y:633,t:1527264613668};\\\", \\\"{x:1205,y:654,t:1527264613684};\\\", \\\"{x:1187,y:680,t:1527264613701};\\\", \\\"{x:1163,y:720,t:1527264613718};\\\", \\\"{x:1153,y:740,t:1527264613733};\\\", \\\"{x:1147,y:758,t:1527264613751};\\\", \\\"{x:1141,y:775,t:1527264613768};\\\", \\\"{x:1137,y:788,t:1527264613785};\\\", \\\"{x:1133,y:803,t:1527264613800};\\\", \\\"{x:1126,y:822,t:1527264613818};\\\", \\\"{x:1122,y:839,t:1527264613835};\\\", \\\"{x:1117,y:857,t:1527264613851};\\\", \\\"{x:1115,y:865,t:1527264613868};\\\", \\\"{x:1109,y:879,t:1527264613884};\\\", \\\"{x:1103,y:892,t:1527264613900};\\\", \\\"{x:1096,y:907,t:1527264613917};\\\", \\\"{x:1092,y:918,t:1527264613935};\\\", \\\"{x:1091,y:923,t:1527264613951};\\\", \\\"{x:1090,y:930,t:1527264613968};\\\", \\\"{x:1088,y:933,t:1527264613985};\\\", \\\"{x:1087,y:938,t:1527264614002};\\\", \\\"{x:1086,y:940,t:1527264614017};\\\", \\\"{x:1083,y:945,t:1527264614035};\\\", \\\"{x:1081,y:951,t:1527264614052};\\\", \\\"{x:1080,y:952,t:1527264614067};\\\", \\\"{x:1079,y:955,t:1527264614084};\\\", \\\"{x:1079,y:956,t:1527264614102};\\\", \\\"{x:1078,y:957,t:1527264614126};\\\", \\\"{x:1078,y:958,t:1527264614246};\\\", \\\"{x:1078,y:959,t:1527264614278};\\\", \\\"{x:1078,y:958,t:1527264615726};\\\", \\\"{x:1078,y:957,t:1527264615742};\\\", \\\"{x:1080,y:955,t:1527264615758};\\\", \\\"{x:1081,y:953,t:1527264615775};\\\", \\\"{x:1082,y:952,t:1527264615787};\\\", \\\"{x:1085,y:948,t:1527264615803};\\\", \\\"{x:1086,y:947,t:1527264615820};\\\", \\\"{x:1089,y:944,t:1527264615837};\\\", \\\"{x:1093,y:940,t:1527264615853};\\\", \\\"{x:1095,y:938,t:1527264615870};\\\", \\\"{x:1097,y:934,t:1527264615886};\\\", \\\"{x:1099,y:931,t:1527264615903};\\\", \\\"{x:1101,y:929,t:1527264615920};\\\", \\\"{x:1102,y:927,t:1527264615936};\\\", \\\"{x:1103,y:926,t:1527264615953};\\\", \\\"{x:1104,y:925,t:1527264615970};\\\", \\\"{x:1105,y:924,t:1527264615987};\\\", \\\"{x:1106,y:921,t:1527264616006};\\\", \\\"{x:1106,y:922,t:1527264616310};\\\", \\\"{x:1106,y:923,t:1527264616319};\\\", \\\"{x:1106,y:925,t:1527264616337};\\\", \\\"{x:1105,y:928,t:1527264616354};\\\", \\\"{x:1104,y:930,t:1527264616370};\\\", \\\"{x:1103,y:932,t:1527264616387};\\\", \\\"{x:1103,y:933,t:1527264616405};\\\", \\\"{x:1102,y:934,t:1527264616420};\\\", \\\"{x:1102,y:935,t:1527264616437};\\\", \\\"{x:1100,y:937,t:1527264616453};\\\", \\\"{x:1099,y:938,t:1527264616470};\\\", \\\"{x:1098,y:940,t:1527264616487};\\\", \\\"{x:1096,y:941,t:1527264616504};\\\", \\\"{x:1095,y:944,t:1527264616521};\\\", \\\"{x:1092,y:947,t:1527264616537};\\\", \\\"{x:1090,y:949,t:1527264616554};\\\", \\\"{x:1088,y:952,t:1527264616571};\\\", \\\"{x:1087,y:953,t:1527264616587};\\\", \\\"{x:1086,y:955,t:1527264616603};\\\", \\\"{x:1085,y:956,t:1527264616621};\\\", \\\"{x:1085,y:957,t:1527264616637};\\\", \\\"{x:1083,y:960,t:1527264616654};\\\", \\\"{x:1083,y:961,t:1527264616678};\\\", \\\"{x:1081,y:963,t:1527264616687};\\\", \\\"{x:1081,y:964,t:1527264616710};\\\", \\\"{x:1080,y:964,t:1527264616721};\\\", \\\"{x:1080,y:965,t:1527264616750};\\\", \\\"{x:1080,y:966,t:1527264616766};\\\", \\\"{x:1079,y:966,t:1527264617302};\\\", \\\"{x:1079,y:965,t:1527264617318};\\\", \\\"{x:1079,y:963,t:1527264617334};\\\", \\\"{x:1079,y:961,t:1527264617343};\\\", \\\"{x:1079,y:960,t:1527264617355};\\\", \\\"{x:1079,y:956,t:1527264617371};\\\", \\\"{x:1079,y:955,t:1527264617390};\\\", \\\"{x:1079,y:954,t:1527264617404};\\\", \\\"{x:1079,y:951,t:1527264617421};\\\", \\\"{x:1079,y:944,t:1527264617437};\\\", \\\"{x:1079,y:942,t:1527264617455};\\\", \\\"{x:1079,y:941,t:1527264617478};\\\", \\\"{x:1079,y:940,t:1527264617494};\\\", \\\"{x:1079,y:939,t:1527264617542};\\\", \\\"{x:1079,y:938,t:1527264617566};\\\", \\\"{x:1079,y:937,t:1527264617574};\\\", \\\"{x:1079,y:936,t:1527264617590};\\\", \\\"{x:1079,y:935,t:1527264617604};\\\", \\\"{x:1079,y:934,t:1527264617621};\\\", \\\"{x:1079,y:933,t:1527264617637};\\\", \\\"{x:1079,y:931,t:1527264617655};\\\", \\\"{x:1079,y:930,t:1527264617671};\\\", \\\"{x:1079,y:927,t:1527264617688};\\\", \\\"{x:1079,y:924,t:1527264617705};\\\", \\\"{x:1079,y:920,t:1527264617722};\\\", \\\"{x:1079,y:914,t:1527264617737};\\\", \\\"{x:1079,y:909,t:1527264617754};\\\", \\\"{x:1079,y:905,t:1527264617772};\\\", \\\"{x:1079,y:897,t:1527264617788};\\\", \\\"{x:1079,y:890,t:1527264617805};\\\", \\\"{x:1079,y:882,t:1527264617822};\\\", \\\"{x:1079,y:875,t:1527264617838};\\\", \\\"{x:1079,y:868,t:1527264617855};\\\", \\\"{x:1079,y:863,t:1527264617872};\\\", \\\"{x:1079,y:848,t:1527264617889};\\\", \\\"{x:1079,y:836,t:1527264617904};\\\", \\\"{x:1079,y:825,t:1527264617922};\\\", \\\"{x:1079,y:816,t:1527264617939};\\\", \\\"{x:1082,y:811,t:1527264617955};\\\", \\\"{x:1086,y:804,t:1527264617972};\\\", \\\"{x:1088,y:800,t:1527264617988};\\\", \\\"{x:1093,y:792,t:1527264618005};\\\", \\\"{x:1101,y:781,t:1527264618022};\\\", \\\"{x:1108,y:773,t:1527264618039};\\\", \\\"{x:1114,y:767,t:1527264618055};\\\", \\\"{x:1124,y:762,t:1527264618072};\\\", \\\"{x:1132,y:755,t:1527264618089};\\\", \\\"{x:1140,y:752,t:1527264618105};\\\", \\\"{x:1149,y:749,t:1527264618122};\\\", \\\"{x:1154,y:749,t:1527264618138};\\\", \\\"{x:1155,y:749,t:1527264618154};\\\", \\\"{x:1157,y:749,t:1527264618526};\\\", \\\"{x:1149,y:749,t:1527264618539};\\\", \\\"{x:1114,y:751,t:1527264618556};\\\", \\\"{x:1068,y:753,t:1527264618572};\\\", \\\"{x:1025,y:756,t:1527264618589};\\\", \\\"{x:984,y:760,t:1527264618606};\\\", \\\"{x:961,y:764,t:1527264618622};\\\", \\\"{x:938,y:767,t:1527264618639};\\\", \\\"{x:928,y:770,t:1527264618655};\\\", \\\"{x:914,y:772,t:1527264618673};\\\", \\\"{x:901,y:774,t:1527264618689};\\\", \\\"{x:899,y:774,t:1527264618705};\\\", \\\"{x:900,y:773,t:1527264618797};\\\", \\\"{x:904,y:773,t:1527264618804};\\\", \\\"{x:919,y:769,t:1527264618823};\\\", \\\"{x:944,y:763,t:1527264618838};\\\", \\\"{x:986,y:756,t:1527264618856};\\\", \\\"{x:1055,y:736,t:1527264618872};\\\", \\\"{x:1130,y:714,t:1527264618888};\\\", \\\"{x:1210,y:692,t:1527264618906};\\\", \\\"{x:1288,y:667,t:1527264618922};\\\", \\\"{x:1366,y:645,t:1527264618939};\\\", \\\"{x:1441,y:625,t:1527264618955};\\\", \\\"{x:1508,y:604,t:1527264618973};\\\", \\\"{x:1568,y:594,t:1527264618989};\\\", \\\"{x:1596,y:590,t:1527264619006};\\\", \\\"{x:1608,y:589,t:1527264619023};\\\", \\\"{x:1611,y:589,t:1527264619039};\\\", \\\"{x:1615,y:588,t:1527264619055};\\\", \\\"{x:1615,y:586,t:1527264619073};\\\", \\\"{x:1616,y:586,t:1527264619089};\\\", \\\"{x:1618,y:585,t:1527264619105};\\\", \\\"{x:1620,y:583,t:1527264619122};\\\", \\\"{x:1620,y:582,t:1527264619334};\\\", \\\"{x:1620,y:581,t:1527264619341};\\\", \\\"{x:1620,y:580,t:1527264619357};\\\", \\\"{x:1620,y:578,t:1527264619373};\\\", \\\"{x:1619,y:576,t:1527264619405};\\\", \\\"{x:1618,y:576,t:1527264619421};\\\", \\\"{x:1617,y:575,t:1527264619429};\\\", \\\"{x:1616,y:574,t:1527264619440};\\\", \\\"{x:1613,y:574,t:1527264619457};\\\", \\\"{x:1607,y:574,t:1527264619473};\\\", \\\"{x:1597,y:574,t:1527264619489};\\\", \\\"{x:1582,y:574,t:1527264619507};\\\", \\\"{x:1562,y:574,t:1527264619523};\\\", \\\"{x:1536,y:578,t:1527264619540};\\\", \\\"{x:1508,y:582,t:1527264619557};\\\", \\\"{x:1475,y:588,t:1527264619573};\\\", \\\"{x:1419,y:604,t:1527264619589};\\\", \\\"{x:1379,y:616,t:1527264619607};\\\", \\\"{x:1332,y:630,t:1527264619623};\\\", \\\"{x:1298,y:640,t:1527264619640};\\\", \\\"{x:1273,y:647,t:1527264619657};\\\", \\\"{x:1249,y:654,t:1527264619674};\\\", \\\"{x:1228,y:659,t:1527264619690};\\\", \\\"{x:1214,y:663,t:1527264619707};\\\", \\\"{x:1206,y:664,t:1527264619724};\\\", \\\"{x:1205,y:665,t:1527264619740};\\\", \\\"{x:1204,y:665,t:1527264619887};\\\", \\\"{x:1199,y:668,t:1527264621478};\\\", \\\"{x:1188,y:668,t:1527264621492};\\\", \\\"{x:1157,y:671,t:1527264621509};\\\", \\\"{x:1117,y:678,t:1527264621525};\\\", \\\"{x:1041,y:681,t:1527264621541};\\\", \\\"{x:977,y:681,t:1527264621559};\\\", \\\"{x:918,y:681,t:1527264621574};\\\", \\\"{x:860,y:676,t:1527264621591};\\\", \\\"{x:807,y:668,t:1527264621609};\\\", \\\"{x:767,y:663,t:1527264621625};\\\", \\\"{x:741,y:659,t:1527264621642};\\\", \\\"{x:717,y:655,t:1527264621659};\\\", \\\"{x:696,y:649,t:1527264621676};\\\", \\\"{x:673,y:646,t:1527264621691};\\\", \\\"{x:656,y:645,t:1527264621709};\\\", \\\"{x:636,y:642,t:1527264621732};\\\", \\\"{x:623,y:641,t:1527264621748};\\\", \\\"{x:600,y:634,t:1527264621767};\\\", \\\"{x:583,y:630,t:1527264621783};\\\", \\\"{x:568,y:625,t:1527264621800};\\\", \\\"{x:552,y:624,t:1527264621817};\\\", \\\"{x:536,y:622,t:1527264621833};\\\", \\\"{x:517,y:620,t:1527264621850};\\\", \\\"{x:497,y:620,t:1527264621867};\\\", \\\"{x:478,y:620,t:1527264621883};\\\", \\\"{x:463,y:621,t:1527264621899};\\\", \\\"{x:446,y:623,t:1527264621916};\\\", \\\"{x:431,y:627,t:1527264621933};\\\", \\\"{x:420,y:633,t:1527264621949};\\\", \\\"{x:413,y:638,t:1527264621967};\\\", \\\"{x:410,y:641,t:1527264621984};\\\", \\\"{x:406,y:644,t:1527264622000};\\\", \\\"{x:403,y:647,t:1527264622017};\\\", \\\"{x:401,y:651,t:1527264622034};\\\", \\\"{x:400,y:653,t:1527264622050};\\\", \\\"{x:399,y:656,t:1527264622066};\\\", \\\"{x:399,y:659,t:1527264622084};\\\", \\\"{x:399,y:660,t:1527264622100};\\\", \\\"{x:397,y:662,t:1527264622117};\\\", \\\"{x:397,y:663,t:1527264622134};\\\", \\\"{x:397,y:665,t:1527264622254};\\\", \\\"{x:397,y:666,t:1527264622277};\\\", \\\"{x:398,y:667,t:1527264622286};\\\", \\\"{x:400,y:669,t:1527264622301};\\\", \\\"{x:404,y:670,t:1527264622317};\\\", \\\"{x:410,y:673,t:1527264622333};\\\", \\\"{x:413,y:674,t:1527264622351};\\\", \\\"{x:415,y:674,t:1527264622367};\\\", \\\"{x:418,y:675,t:1527264622384};\\\", \\\"{x:424,y:675,t:1527264622401};\\\", \\\"{x:431,y:675,t:1527264622417};\\\", \\\"{x:445,y:675,t:1527264622434};\\\", \\\"{x:460,y:675,t:1527264622451};\\\", \\\"{x:480,y:675,t:1527264622467};\\\", \\\"{x:501,y:675,t:1527264622484};\\\", \\\"{x:517,y:675,t:1527264622501};\\\", \\\"{x:533,y:675,t:1527264622516};\\\", \\\"{x:554,y:675,t:1527264622534};\\\", \\\"{x:565,y:675,t:1527264622551};\\\", \\\"{x:570,y:675,t:1527264622567};\\\", \\\"{x:575,y:675,t:1527264622584};\\\", \\\"{x:580,y:675,t:1527264622601};\\\", \\\"{x:586,y:675,t:1527264622617};\\\", \\\"{x:594,y:675,t:1527264622634};\\\", \\\"{x:601,y:672,t:1527264622651};\\\", \\\"{x:609,y:671,t:1527264622667};\\\", \\\"{x:620,y:670,t:1527264622683};\\\", \\\"{x:633,y:666,t:1527264622701};\\\", \\\"{x:643,y:663,t:1527264622717};\\\", \\\"{x:653,y:661,t:1527264622734};\\\", \\\"{x:656,y:659,t:1527264622750};\\\", \\\"{x:658,y:658,t:1527264622767};\\\", \\\"{x:657,y:658,t:1527264622974};\\\", \\\"{x:653,y:657,t:1527264622984};\\\", \\\"{x:646,y:653,t:1527264623001};\\\", \\\"{x:643,y:651,t:1527264623018};\\\", \\\"{x:640,y:649,t:1527264623035};\\\", \\\"{x:638,y:647,t:1527264623050};\\\", \\\"{x:637,y:647,t:1527264623068};\\\", \\\"{x:637,y:646,t:1527264623084};\\\", \\\"{x:636,y:646,t:1527264623101};\\\", \\\"{x:636,y:645,t:1527264623126};\\\", \\\"{x:635,y:644,t:1527264623181};\\\", \\\"{x:634,y:644,t:1527264623566};\\\", \\\"{x:634,y:645,t:1527264623573};\\\", \\\"{x:634,y:647,t:1527264623586};\\\", \\\"{x:636,y:652,t:1527264623602};\\\", \\\"{x:639,y:657,t:1527264623617};\\\", \\\"{x:642,y:661,t:1527264623634};\\\", \\\"{x:645,y:665,t:1527264623650};\\\", \\\"{x:649,y:669,t:1527264623668};\\\", \\\"{x:653,y:673,t:1527264623685};\\\", \\\"{x:658,y:677,t:1527264623701};\\\", \\\"{x:663,y:679,t:1527264623718};\\\", \\\"{x:669,y:682,t:1527264623735};\\\", \\\"{x:671,y:683,t:1527264623752};\\\", \\\"{x:674,y:684,t:1527264623767};\\\", \\\"{x:676,y:686,t:1527264623785};\\\", \\\"{x:678,y:687,t:1527264623802};\\\", \\\"{x:680,y:688,t:1527264623837};\\\", \\\"{x:680,y:689,t:1527264623886};\\\", \\\"{x:681,y:689,t:1527264623902};\\\", \\\"{x:681,y:690,t:1527264623918};\\\", \\\"{x:682,y:692,t:1527264623935};\\\", \\\"{x:683,y:694,t:1527264623952};\\\", \\\"{x:684,y:695,t:1527264623968};\\\", \\\"{x:686,y:697,t:1527264624326};\\\", \\\"{x:686,y:698,t:1527264624342};\\\", \\\"{x:687,y:698,t:1527264624352};\\\", \\\"{x:690,y:698,t:1527264624369};\\\", \\\"{x:695,y:698,t:1527264624385};\\\", \\\"{x:709,y:694,t:1527264624402};\\\", \\\"{x:722,y:691,t:1527264624419};\\\", \\\"{x:739,y:683,t:1527264624435};\\\", \\\"{x:762,y:677,t:1527264624452};\\\", \\\"{x:789,y:672,t:1527264624469};\\\", \\\"{x:832,y:665,t:1527264624485};\\\", \\\"{x:915,y:654,t:1527264624502};\\\", \\\"{x:973,y:645,t:1527264624519};\\\", \\\"{x:1046,y:635,t:1527264624535};\\\", \\\"{x:1127,y:622,t:1527264624552};\\\", \\\"{x:1212,y:603,t:1527264624569};\\\", \\\"{x:1308,y:579,t:1527264624585};\\\", \\\"{x:1411,y:549,t:1527264624602};\\\", \\\"{x:1500,y:518,t:1527264624619};\\\", \\\"{x:1588,y:485,t:1527264624636};\\\", \\\"{x:1652,y:464,t:1527264624652};\\\", \\\"{x:1698,y:449,t:1527264624669};\\\", \\\"{x:1720,y:441,t:1527264624685};\\\", \\\"{x:1727,y:438,t:1527264624703};\\\", \\\"{x:1727,y:435,t:1527264624854};\\\", \\\"{x:1724,y:434,t:1527264624869};\\\", \\\"{x:1709,y:426,t:1527264624886};\\\", \\\"{x:1703,y:425,t:1527264624903};\\\", \\\"{x:1696,y:421,t:1527264624919};\\\", \\\"{x:1691,y:421,t:1527264624936};\\\", \\\"{x:1688,y:421,t:1527264624952};\\\", \\\"{x:1682,y:421,t:1527264624969};\\\", \\\"{x:1676,y:423,t:1527264624986};\\\", \\\"{x:1667,y:425,t:1527264625002};\\\", \\\"{x:1654,y:428,t:1527264625018};\\\", \\\"{x:1638,y:430,t:1527264625036};\\\", \\\"{x:1622,y:434,t:1527264625051};\\\", \\\"{x:1602,y:439,t:1527264625069};\\\", \\\"{x:1593,y:442,t:1527264625085};\\\", \\\"{x:1588,y:442,t:1527264625102};\\\", \\\"{x:1585,y:442,t:1527264625119};\\\", \\\"{x:1582,y:443,t:1527264625136};\\\", \\\"{x:1580,y:443,t:1527264625152};\\\", \\\"{x:1579,y:443,t:1527264625168};\\\", \\\"{x:1579,y:444,t:1527264625333};\\\", \\\"{x:1580,y:445,t:1527264625342};\\\", \\\"{x:1583,y:446,t:1527264625353};\\\", \\\"{x:1589,y:449,t:1527264625369};\\\", \\\"{x:1593,y:451,t:1527264625386};\\\", \\\"{x:1599,y:455,t:1527264625403};\\\", \\\"{x:1602,y:455,t:1527264625419};\\\", \\\"{x:1604,y:457,t:1527264625436};\\\", \\\"{x:1605,y:457,t:1527264625453};\\\", \\\"{x:1606,y:457,t:1527264625469};\\\", \\\"{x:1608,y:457,t:1527264625486};\\\", \\\"{x:1612,y:457,t:1527264625503};\\\", \\\"{x:1616,y:457,t:1527264625519};\\\", \\\"{x:1617,y:457,t:1527264625536};\\\", \\\"{x:1617,y:456,t:1527264625557};\\\", \\\"{x:1617,y:455,t:1527264625589};\\\", \\\"{x:1617,y:456,t:1527264625781};\\\", \\\"{x:1617,y:462,t:1527264625789};\\\", \\\"{x:1617,y:473,t:1527264625803};\\\", \\\"{x:1617,y:493,t:1527264625820};\\\", \\\"{x:1617,y:511,t:1527264625836};\\\", \\\"{x:1617,y:542,t:1527264625853};\\\", \\\"{x:1617,y:563,t:1527264625869};\\\", \\\"{x:1617,y:586,t:1527264625887};\\\", \\\"{x:1617,y:609,t:1527264625903};\\\", \\\"{x:1617,y:631,t:1527264625920};\\\", \\\"{x:1617,y:647,t:1527264625936};\\\", \\\"{x:1615,y:664,t:1527264625953};\\\", \\\"{x:1615,y:683,t:1527264625970};\\\", \\\"{x:1615,y:700,t:1527264625986};\\\", \\\"{x:1615,y:716,t:1527264626003};\\\", \\\"{x:1615,y:733,t:1527264626020};\\\", \\\"{x:1614,y:745,t:1527264626036};\\\", \\\"{x:1613,y:759,t:1527264626053};\\\", \\\"{x:1609,y:776,t:1527264626070};\\\", \\\"{x:1608,y:785,t:1527264626087};\\\", \\\"{x:1606,y:793,t:1527264626103};\\\", \\\"{x:1605,y:800,t:1527264626120};\\\", \\\"{x:1603,y:808,t:1527264626137};\\\", \\\"{x:1601,y:814,t:1527264626153};\\\", \\\"{x:1601,y:819,t:1527264626170};\\\", \\\"{x:1601,y:822,t:1527264626186};\\\", \\\"{x:1601,y:825,t:1527264626203};\\\", \\\"{x:1601,y:827,t:1527264626220};\\\", \\\"{x:1601,y:830,t:1527264626237};\\\", \\\"{x:1601,y:836,t:1527264626254};\\\", \\\"{x:1601,y:840,t:1527264626270};\\\", \\\"{x:1601,y:843,t:1527264626287};\\\", \\\"{x:1602,y:844,t:1527264626303};\\\", \\\"{x:1602,y:843,t:1527264626375};\\\", \\\"{x:1602,y:834,t:1527264626387};\\\", \\\"{x:1602,y:805,t:1527264626403};\\\", \\\"{x:1603,y:768,t:1527264626421};\\\", \\\"{x:1610,y:731,t:1527264626437};\\\", \\\"{x:1615,y:698,t:1527264626453};\\\", \\\"{x:1620,y:659,t:1527264626470};\\\", \\\"{x:1620,y:635,t:1527264626487};\\\", \\\"{x:1620,y:608,t:1527264626503};\\\", \\\"{x:1617,y:585,t:1527264626520};\\\", \\\"{x:1613,y:568,t:1527264626538};\\\", \\\"{x:1609,y:556,t:1527264626554};\\\", \\\"{x:1607,y:551,t:1527264626570};\\\", \\\"{x:1606,y:546,t:1527264626587};\\\", \\\"{x:1605,y:542,t:1527264626603};\\\", \\\"{x:1602,y:533,t:1527264626620};\\\", \\\"{x:1598,y:515,t:1527264626637};\\\", \\\"{x:1598,y:511,t:1527264626653};\\\", \\\"{x:1596,y:494,t:1527264626670};\\\", \\\"{x:1596,y:488,t:1527264626688};\\\", \\\"{x:1596,y:482,t:1527264626703};\\\", \\\"{x:1596,y:477,t:1527264626721};\\\", \\\"{x:1596,y:473,t:1527264626737};\\\", \\\"{x:1596,y:470,t:1527264626754};\\\", \\\"{x:1596,y:467,t:1527264626771};\\\", \\\"{x:1596,y:466,t:1527264626787};\\\", \\\"{x:1596,y:465,t:1527264626804};\\\", \\\"{x:1597,y:464,t:1527264626821};\\\", \\\"{x:1597,y:463,t:1527264626845};\\\", \\\"{x:1597,y:461,t:1527264626853};\\\", \\\"{x:1598,y:461,t:1527264626870};\\\", \\\"{x:1598,y:458,t:1527264626887};\\\", \\\"{x:1599,y:455,t:1527264626905};\\\", \\\"{x:1599,y:452,t:1527264626920};\\\", \\\"{x:1600,y:450,t:1527264626937};\\\", \\\"{x:1601,y:447,t:1527264626954};\\\", \\\"{x:1601,y:445,t:1527264626971};\\\", \\\"{x:1602,y:444,t:1527264626988};\\\", \\\"{x:1602,y:443,t:1527264627015};\\\", \\\"{x:1603,y:442,t:1527264627022};\\\", \\\"{x:1603,y:441,t:1527264627038};\\\", \\\"{x:1603,y:440,t:1527264627062};\\\", \\\"{x:1603,y:439,t:1527264627086};\\\", \\\"{x:1603,y:438,t:1527264627094};\\\", \\\"{x:1602,y:437,t:1527264627919};\\\", \\\"{x:1601,y:437,t:1527264627934};\\\", \\\"{x:1598,y:436,t:1527264627942};\\\", \\\"{x:1598,y:435,t:1527264627955};\\\", \\\"{x:1595,y:434,t:1527264627972};\\\", \\\"{x:1588,y:429,t:1527264627989};\\\", \\\"{x:1584,y:429,t:1527264628005};\\\", \\\"{x:1577,y:426,t:1527264628021};\\\", \\\"{x:1576,y:426,t:1527264628039};\\\", \\\"{x:1575,y:425,t:1527264628229};\\\", \\\"{x:1574,y:424,t:1527264628494};\\\", \\\"{x:1573,y:423,t:1527264628510};\\\", \\\"{x:1572,y:423,t:1527264628574};\\\", \\\"{x:1571,y:423,t:1527264632805};\\\", \\\"{x:1569,y:423,t:1527264632814};\\\", \\\"{x:1566,y:423,t:1527264632824};\\\", \\\"{x:1562,y:423,t:1527264632841};\\\", \\\"{x:1556,y:428,t:1527264632857};\\\", \\\"{x:1554,y:435,t:1527264632875};\\\", \\\"{x:1553,y:446,t:1527264632892};\\\", \\\"{x:1553,y:468,t:1527264632907};\\\", \\\"{x:1553,y:506,t:1527264632924};\\\", \\\"{x:1557,y:550,t:1527264632941};\\\", \\\"{x:1557,y:563,t:1527264632957};\\\", \\\"{x:1552,y:568,t:1527264632975};\\\", \\\"{x:1541,y:567,t:1527264632992};\\\", \\\"{x:1538,y:563,t:1527264633007};\\\", \\\"{x:1538,y:561,t:1527264633230};\\\", \\\"{x:1541,y:561,t:1527264633246};\\\", \\\"{x:1543,y:561,t:1527264633259};\\\", \\\"{x:1547,y:561,t:1527264633275};\\\", \\\"{x:1550,y:565,t:1527264633292};\\\", \\\"{x:1556,y:577,t:1527264633309};\\\", \\\"{x:1563,y:591,t:1527264633325};\\\", \\\"{x:1576,y:622,t:1527264633341};\\\", \\\"{x:1587,y:645,t:1527264633358};\\\", \\\"{x:1596,y:666,t:1527264633375};\\\", \\\"{x:1606,y:686,t:1527264633391};\\\", \\\"{x:1613,y:706,t:1527264633408};\\\", \\\"{x:1618,y:726,t:1527264633424};\\\", \\\"{x:1623,y:744,t:1527264633442};\\\", \\\"{x:1624,y:763,t:1527264633458};\\\", \\\"{x:1625,y:785,t:1527264633474};\\\", \\\"{x:1628,y:805,t:1527264633492};\\\", \\\"{x:1629,y:824,t:1527264633508};\\\", \\\"{x:1630,y:838,t:1527264633524};\\\", \\\"{x:1630,y:852,t:1527264633541};\\\", \\\"{x:1630,y:855,t:1527264633559};\\\", \\\"{x:1630,y:859,t:1527264633574};\\\", \\\"{x:1630,y:867,t:1527264633591};\\\", \\\"{x:1629,y:881,t:1527264633608};\\\", \\\"{x:1629,y:897,t:1527264633624};\\\", \\\"{x:1629,y:912,t:1527264633641};\\\", \\\"{x:1629,y:921,t:1527264633658};\\\", \\\"{x:1629,y:924,t:1527264633676};\\\", \\\"{x:1629,y:928,t:1527264633691};\\\", \\\"{x:1628,y:929,t:1527264633708};\\\", \\\"{x:1627,y:933,t:1527264633726};\\\", \\\"{x:1626,y:934,t:1527264633741};\\\", \\\"{x:1625,y:933,t:1527264633838};\\\", \\\"{x:1624,y:925,t:1527264633846};\\\", \\\"{x:1620,y:913,t:1527264633859};\\\", \\\"{x:1608,y:870,t:1527264633876};\\\", \\\"{x:1597,y:810,t:1527264633891};\\\", \\\"{x:1586,y:738,t:1527264633908};\\\", \\\"{x:1579,y:636,t:1527264633925};\\\", \\\"{x:1579,y:597,t:1527264633942};\\\", \\\"{x:1579,y:572,t:1527264633958};\\\", \\\"{x:1579,y:556,t:1527264633976};\\\", \\\"{x:1579,y:544,t:1527264633992};\\\", \\\"{x:1579,y:537,t:1527264634009};\\\", \\\"{x:1579,y:535,t:1527264634025};\\\", \\\"{x:1579,y:534,t:1527264634042};\\\", \\\"{x:1579,y:532,t:1527264634059};\\\", \\\"{x:1579,y:531,t:1527264634076};\\\", \\\"{x:1580,y:528,t:1527264634091};\\\", \\\"{x:1581,y:524,t:1527264634109};\\\", \\\"{x:1584,y:515,t:1527264634126};\\\", \\\"{x:1587,y:507,t:1527264634142};\\\", \\\"{x:1590,y:501,t:1527264634158};\\\", \\\"{x:1593,y:493,t:1527264634176};\\\", \\\"{x:1594,y:488,t:1527264634192};\\\", \\\"{x:1597,y:480,t:1527264634209};\\\", \\\"{x:1598,y:475,t:1527264634225};\\\", \\\"{x:1600,y:469,t:1527264634243};\\\", \\\"{x:1601,y:465,t:1527264634259};\\\", \\\"{x:1602,y:461,t:1527264634276};\\\", \\\"{x:1603,y:460,t:1527264634293};\\\", \\\"{x:1603,y:459,t:1527264634308};\\\", \\\"{x:1604,y:463,t:1527264634416};\\\", \\\"{x:1605,y:474,t:1527264634426};\\\", \\\"{x:1605,y:501,t:1527264634443};\\\", \\\"{x:1605,y:537,t:1527264634459};\\\", \\\"{x:1605,y:582,t:1527264634476};\\\", \\\"{x:1607,y:625,t:1527264634493};\\\", \\\"{x:1607,y:656,t:1527264634509};\\\", \\\"{x:1607,y:688,t:1527264634526};\\\", \\\"{x:1607,y:696,t:1527264634542};\\\", \\\"{x:1607,y:704,t:1527264634559};\\\", \\\"{x:1607,y:706,t:1527264634575};\\\", \\\"{x:1607,y:707,t:1527264634592};\\\", \\\"{x:1608,y:702,t:1527264634734};\\\", \\\"{x:1609,y:695,t:1527264634743};\\\", \\\"{x:1611,y:683,t:1527264634760};\\\", \\\"{x:1613,y:667,t:1527264634776};\\\", \\\"{x:1617,y:652,t:1527264634792};\\\", \\\"{x:1619,y:640,t:1527264634810};\\\", \\\"{x:1620,y:634,t:1527264634826};\\\", \\\"{x:1620,y:631,t:1527264634842};\\\", \\\"{x:1620,y:630,t:1527264634860};\\\", \\\"{x:1620,y:637,t:1527264634934};\\\", \\\"{x:1620,y:646,t:1527264634942};\\\", \\\"{x:1620,y:663,t:1527264634960};\\\", \\\"{x:1620,y:682,t:1527264634975};\\\", \\\"{x:1620,y:700,t:1527264634993};\\\", \\\"{x:1620,y:717,t:1527264635010};\\\", \\\"{x:1617,y:735,t:1527264635025};\\\", \\\"{x:1616,y:751,t:1527264635042};\\\", \\\"{x:1614,y:760,t:1527264635059};\\\", \\\"{x:1614,y:764,t:1527264635075};\\\", \\\"{x:1614,y:767,t:1527264635093};\\\", \\\"{x:1614,y:766,t:1527264635149};\\\", \\\"{x:1616,y:758,t:1527264635160};\\\", \\\"{x:1619,y:735,t:1527264635176};\\\", \\\"{x:1622,y:706,t:1527264635192};\\\", \\\"{x:1624,y:676,t:1527264635210};\\\", \\\"{x:1624,y:646,t:1527264635226};\\\", \\\"{x:1624,y:621,t:1527264635243};\\\", \\\"{x:1624,y:596,t:1527264635259};\\\", \\\"{x:1624,y:578,t:1527264635276};\\\", \\\"{x:1624,y:563,t:1527264635292};\\\", \\\"{x:1624,y:548,t:1527264635310};\\\", \\\"{x:1622,y:536,t:1527264635326};\\\", \\\"{x:1620,y:525,t:1527264635342};\\\", \\\"{x:1618,y:516,t:1527264635360};\\\", \\\"{x:1618,y:508,t:1527264635376};\\\", \\\"{x:1616,y:504,t:1527264635392};\\\", \\\"{x:1615,y:499,t:1527264635409};\\\", \\\"{x:1614,y:495,t:1527264635426};\\\", \\\"{x:1614,y:492,t:1527264635442};\\\", \\\"{x:1614,y:490,t:1527264635460};\\\", \\\"{x:1614,y:487,t:1527264635476};\\\", \\\"{x:1614,y:486,t:1527264635492};\\\", \\\"{x:1614,y:487,t:1527264635789};\\\", \\\"{x:1612,y:491,t:1527264635797};\\\", \\\"{x:1611,y:497,t:1527264635810};\\\", \\\"{x:1611,y:505,t:1527264635826};\\\", \\\"{x:1610,y:515,t:1527264635843};\\\", \\\"{x:1610,y:522,t:1527264635860};\\\", \\\"{x:1610,y:528,t:1527264635877};\\\", \\\"{x:1609,y:532,t:1527264635894};\\\", \\\"{x:1608,y:532,t:1527264636111};\\\", \\\"{x:1608,y:530,t:1527264636127};\\\", \\\"{x:1608,y:528,t:1527264636144};\\\", \\\"{x:1608,y:523,t:1527264636160};\\\", \\\"{x:1608,y:517,t:1527264636176};\\\", \\\"{x:1608,y:510,t:1527264636194};\\\", \\\"{x:1608,y:505,t:1527264636209};\\\", \\\"{x:1609,y:500,t:1527264636226};\\\", \\\"{x:1609,y:498,t:1527264636244};\\\", \\\"{x:1609,y:497,t:1527264636261};\\\", \\\"{x:1609,y:496,t:1527264636277};\\\", \\\"{x:1609,y:495,t:1527264636293};\\\", \\\"{x:1610,y:493,t:1527264636309};\\\", \\\"{x:1611,y:492,t:1527264636327};\\\", \\\"{x:1611,y:488,t:1527264636343};\\\", \\\"{x:1611,y:486,t:1527264636361};\\\", \\\"{x:1611,y:485,t:1527264636377};\\\", \\\"{x:1611,y:484,t:1527264636405};\\\", \\\"{x:1612,y:483,t:1527264636422};\\\", \\\"{x:1612,y:479,t:1527264636853};\\\", \\\"{x:1611,y:475,t:1527264636861};\\\", \\\"{x:1610,y:468,t:1527264636878};\\\", \\\"{x:1609,y:463,t:1527264636893};\\\", \\\"{x:1607,y:460,t:1527264636910};\\\", \\\"{x:1606,y:458,t:1527264636928};\\\", \\\"{x:1605,y:457,t:1527264636950};\\\", \\\"{x:1604,y:457,t:1527264638189};\\\", \\\"{x:1597,y:462,t:1527264638197};\\\", \\\"{x:1585,y:478,t:1527264638211};\\\", \\\"{x:1550,y:506,t:1527264638227};\\\", \\\"{x:1498,y:538,t:1527264638244};\\\", \\\"{x:1406,y:578,t:1527264638261};\\\", \\\"{x:1358,y:594,t:1527264638278};\\\", \\\"{x:1321,y:604,t:1527264638294};\\\", \\\"{x:1297,y:610,t:1527264638311};\\\", \\\"{x:1279,y:613,t:1527264638328};\\\", \\\"{x:1271,y:613,t:1527264638344};\\\", \\\"{x:1266,y:613,t:1527264638361};\\\", \\\"{x:1257,y:613,t:1527264638378};\\\", \\\"{x:1244,y:612,t:1527264638394};\\\", \\\"{x:1232,y:606,t:1527264638412};\\\", \\\"{x:1223,y:600,t:1527264638428};\\\", \\\"{x:1210,y:591,t:1527264638444};\\\", \\\"{x:1197,y:578,t:1527264638461};\\\", \\\"{x:1189,y:569,t:1527264638478};\\\", \\\"{x:1184,y:559,t:1527264638495};\\\", \\\"{x:1179,y:548,t:1527264638512};\\\", \\\"{x:1174,y:535,t:1527264638529};\\\", \\\"{x:1173,y:526,t:1527264638544};\\\", \\\"{x:1170,y:516,t:1527264638561};\\\", \\\"{x:1170,y:508,t:1527264638578};\\\", \\\"{x:1170,y:499,t:1527264638594};\\\", \\\"{x:1169,y:492,t:1527264638611};\\\", \\\"{x:1166,y:482,t:1527264638629};\\\", \\\"{x:1165,y:473,t:1527264638645};\\\", \\\"{x:1164,y:465,t:1527264638661};\\\", \\\"{x:1163,y:464,t:1527264638679};\\\", \\\"{x:1162,y:464,t:1527264638766};\\\", \\\"{x:1160,y:473,t:1527264638779};\\\", \\\"{x:1153,y:499,t:1527264638795};\\\", \\\"{x:1140,y:540,t:1527264638812};\\\", \\\"{x:1125,y:579,t:1527264638829};\\\", \\\"{x:1110,y:608,t:1527264638845};\\\", \\\"{x:1090,y:656,t:1527264638862};\\\", \\\"{x:1083,y:682,t:1527264638879};\\\", \\\"{x:1075,y:706,t:1527264638895};\\\", \\\"{x:1067,y:738,t:1527264638912};\\\", \\\"{x:1059,y:762,t:1527264638929};\\\", \\\"{x:1052,y:780,t:1527264638945};\\\", \\\"{x:1044,y:806,t:1527264638962};\\\", \\\"{x:1037,y:834,t:1527264638978};\\\", \\\"{x:1033,y:863,t:1527264638996};\\\", \\\"{x:1030,y:884,t:1527264639011};\\\", \\\"{x:1027,y:906,t:1527264639028};\\\", \\\"{x:1026,y:936,t:1527264639044};\\\", \\\"{x:1026,y:954,t:1527264639061};\\\", \\\"{x:1025,y:969,t:1527264639078};\\\", \\\"{x:1025,y:976,t:1527264639095};\\\", \\\"{x:1025,y:980,t:1527264639111};\\\", \\\"{x:1025,y:984,t:1527264639129};\\\", \\\"{x:1025,y:988,t:1527264639145};\\\", \\\"{x:1027,y:991,t:1527264639161};\\\", \\\"{x:1029,y:994,t:1527264639178};\\\", \\\"{x:1030,y:994,t:1527264639221};\\\", \\\"{x:1031,y:994,t:1527264639229};\\\", \\\"{x:1035,y:994,t:1527264639245};\\\", \\\"{x:1036,y:994,t:1527264639262};\\\", \\\"{x:1039,y:994,t:1527264639279};\\\", \\\"{x:1047,y:992,t:1527264639296};\\\", \\\"{x:1056,y:988,t:1527264639311};\\\", \\\"{x:1062,y:985,t:1527264639328};\\\", \\\"{x:1070,y:982,t:1527264639345};\\\", \\\"{x:1072,y:980,t:1527264639362};\\\", \\\"{x:1073,y:980,t:1527264639379};\\\", \\\"{x:1073,y:979,t:1527264639396};\\\", \\\"{x:1074,y:978,t:1527264639415};\\\", \\\"{x:1074,y:977,t:1527264639428};\\\", \\\"{x:1075,y:974,t:1527264639445};\\\", \\\"{x:1075,y:973,t:1527264639462};\\\", \\\"{x:1075,y:972,t:1527264639478};\\\", \\\"{x:1075,y:970,t:1527264639496};\\\", \\\"{x:1076,y:969,t:1527264639512};\\\", \\\"{x:1077,y:968,t:1527264639529};\\\", \\\"{x:1077,y:966,t:1527264639546};\\\", \\\"{x:1079,y:963,t:1527264639563};\\\", \\\"{x:1080,y:961,t:1527264639579};\\\", \\\"{x:1083,y:956,t:1527264639596};\\\", \\\"{x:1090,y:943,t:1527264639613};\\\", \\\"{x:1112,y:915,t:1527264639629};\\\", \\\"{x:1140,y:881,t:1527264639645};\\\", \\\"{x:1178,y:839,t:1527264639663};\\\", \\\"{x:1222,y:793,t:1527264639678};\\\", \\\"{x:1275,y:748,t:1527264639696};\\\", \\\"{x:1327,y:703,t:1527264639712};\\\", \\\"{x:1366,y:661,t:1527264639729};\\\", \\\"{x:1405,y:616,t:1527264639746};\\\", \\\"{x:1438,y:576,t:1527264639763};\\\", \\\"{x:1473,y:528,t:1527264639779};\\\", \\\"{x:1503,y:485,t:1527264639796};\\\", \\\"{x:1526,y:453,t:1527264639813};\\\", \\\"{x:1555,y:417,t:1527264639829};\\\", \\\"{x:1567,y:399,t:1527264639846};\\\", \\\"{x:1577,y:386,t:1527264639863};\\\", \\\"{x:1580,y:380,t:1527264639879};\\\", \\\"{x:1581,y:377,t:1527264639895};\\\", \\\"{x:1582,y:377,t:1527264640022};\\\", \\\"{x:1584,y:377,t:1527264640037};\\\", \\\"{x:1585,y:380,t:1527264640046};\\\", \\\"{x:1593,y:394,t:1527264640062};\\\", \\\"{x:1598,y:405,t:1527264640079};\\\", \\\"{x:1602,y:415,t:1527264640095};\\\", \\\"{x:1606,y:428,t:1527264640112};\\\", \\\"{x:1609,y:439,t:1527264640130};\\\", \\\"{x:1613,y:446,t:1527264640146};\\\", \\\"{x:1615,y:450,t:1527264640162};\\\", \\\"{x:1616,y:451,t:1527264640179};\\\", \\\"{x:1617,y:452,t:1527264640196};\\\", \\\"{x:1617,y:457,t:1527264651678};\\\", \\\"{x:1614,y:465,t:1527264651688};\\\", \\\"{x:1609,y:486,t:1527264651705};\\\", \\\"{x:1605,y:509,t:1527264651721};\\\", \\\"{x:1605,y:531,t:1527264651738};\\\", \\\"{x:1605,y:550,t:1527264651755};\\\", \\\"{x:1605,y:558,t:1527264651770};\\\", \\\"{x:1605,y:563,t:1527264651788};\\\", \\\"{x:1605,y:566,t:1527264651805};\\\", \\\"{x:1606,y:567,t:1527264652142};\\\", \\\"{x:1607,y:567,t:1527264652246};\\\", \\\"{x:1608,y:567,t:1527264652255};\\\", \\\"{x:1610,y:569,t:1527264652278};\\\", \\\"{x:1611,y:569,t:1527264652294};\\\", \\\"{x:1612,y:569,t:1527264652318};\\\", \\\"{x:1613,y:570,t:1527264652338};\\\", \\\"{x:1614,y:570,t:1527264652381};\\\", \\\"{x:1615,y:571,t:1527264652405};\\\", \\\"{x:1618,y:574,t:1527264652638};\\\", \\\"{x:1624,y:587,t:1527264652655};\\\", \\\"{x:1625,y:598,t:1527264652672};\\\", \\\"{x:1628,y:611,t:1527264652689};\\\", \\\"{x:1629,y:621,t:1527264652705};\\\", \\\"{x:1630,y:634,t:1527264652721};\\\", \\\"{x:1630,y:645,t:1527264652738};\\\", \\\"{x:1630,y:659,t:1527264652754};\\\", \\\"{x:1630,y:668,t:1527264652771};\\\", \\\"{x:1630,y:674,t:1527264652788};\\\", \\\"{x:1630,y:681,t:1527264652804};\\\", \\\"{x:1630,y:699,t:1527264652821};\\\", \\\"{x:1630,y:719,t:1527264652838};\\\", \\\"{x:1628,y:736,t:1527264652855};\\\", \\\"{x:1627,y:746,t:1527264652871};\\\", \\\"{x:1626,y:754,t:1527264652888};\\\", \\\"{x:1624,y:767,t:1527264652904};\\\", \\\"{x:1623,y:782,t:1527264652921};\\\", \\\"{x:1623,y:794,t:1527264652938};\\\", \\\"{x:1623,y:805,t:1527264652954};\\\", \\\"{x:1623,y:813,t:1527264652971};\\\", \\\"{x:1623,y:820,t:1527264652988};\\\", \\\"{x:1621,y:828,t:1527264653004};\\\", \\\"{x:1621,y:835,t:1527264653021};\\\", \\\"{x:1621,y:841,t:1527264653038};\\\", \\\"{x:1621,y:846,t:1527264653054};\\\", \\\"{x:1619,y:851,t:1527264653071};\\\", \\\"{x:1619,y:857,t:1527264653088};\\\", \\\"{x:1618,y:866,t:1527264653104};\\\", \\\"{x:1617,y:873,t:1527264653121};\\\", \\\"{x:1615,y:877,t:1527264653138};\\\", \\\"{x:1615,y:879,t:1527264653155};\\\", \\\"{x:1615,y:882,t:1527264653172};\\\", \\\"{x:1615,y:885,t:1527264653188};\\\", \\\"{x:1613,y:890,t:1527264653205};\\\", \\\"{x:1611,y:895,t:1527264653221};\\\", \\\"{x:1611,y:899,t:1527264653239};\\\", \\\"{x:1610,y:902,t:1527264653256};\\\", \\\"{x:1610,y:903,t:1527264653272};\\\", \\\"{x:1610,y:905,t:1527264653288};\\\", \\\"{x:1608,y:907,t:1527264653306};\\\", \\\"{x:1608,y:908,t:1527264653321};\\\", \\\"{x:1608,y:909,t:1527264653338};\\\", \\\"{x:1608,y:911,t:1527264653365};\\\", \\\"{x:1608,y:912,t:1527264653373};\\\", \\\"{x:1608,y:914,t:1527264653388};\\\", \\\"{x:1607,y:915,t:1527264653405};\\\", \\\"{x:1607,y:918,t:1527264653421};\\\", \\\"{x:1607,y:919,t:1527264653439};\\\", \\\"{x:1607,y:920,t:1527264653461};\\\", \\\"{x:1607,y:921,t:1527264653471};\\\", \\\"{x:1607,y:922,t:1527264653488};\\\", \\\"{x:1607,y:921,t:1527264653693};\\\", \\\"{x:1607,y:919,t:1527264653706};\\\", \\\"{x:1605,y:916,t:1527264653723};\\\", \\\"{x:1604,y:912,t:1527264653739};\\\", \\\"{x:1604,y:909,t:1527264653755};\\\", \\\"{x:1604,y:908,t:1527264653772};\\\", \\\"{x:1604,y:902,t:1527264653788};\\\", \\\"{x:1604,y:893,t:1527264653805};\\\", \\\"{x:1604,y:885,t:1527264653822};\\\", \\\"{x:1604,y:878,t:1527264653837};\\\", \\\"{x:1603,y:873,t:1527264653855};\\\", \\\"{x:1603,y:867,t:1527264653872};\\\", \\\"{x:1603,y:860,t:1527264653888};\\\", \\\"{x:1603,y:852,t:1527264653905};\\\", \\\"{x:1603,y:842,t:1527264653922};\\\", \\\"{x:1605,y:829,t:1527264653938};\\\", \\\"{x:1606,y:820,t:1527264653955};\\\", \\\"{x:1606,y:816,t:1527264653972};\\\", \\\"{x:1606,y:810,t:1527264653988};\\\", \\\"{x:1609,y:802,t:1527264654005};\\\", \\\"{x:1609,y:797,t:1527264654022};\\\", \\\"{x:1609,y:791,t:1527264654041};\\\", \\\"{x:1610,y:786,t:1527264654059};\\\", \\\"{x:1610,y:785,t:1527264654080};\\\", \\\"{x:1610,y:783,t:1527264654091};\\\", \\\"{x:1611,y:782,t:1527264654108};\\\", \\\"{x:1611,y:781,t:1527264654136};\\\", \\\"{x:1611,y:780,t:1527264654184};\\\", \\\"{x:1611,y:779,t:1527264654192};\\\", \\\"{x:1611,y:777,t:1527264654208};\\\", \\\"{x:1611,y:774,t:1527264654226};\\\", \\\"{x:1611,y:771,t:1527264654242};\\\", \\\"{x:1611,y:767,t:1527264654259};\\\", \\\"{x:1611,y:764,t:1527264654276};\\\", \\\"{x:1611,y:760,t:1527264654293};\\\", \\\"{x:1611,y:758,t:1527264654308};\\\", \\\"{x:1611,y:756,t:1527264654325};\\\", \\\"{x:1611,y:755,t:1527264654342};\\\", \\\"{x:1611,y:754,t:1527264654361};\\\", \\\"{x:1611,y:753,t:1527264654433};\\\", \\\"{x:1611,y:752,t:1527264654464};\\\", \\\"{x:1611,y:751,t:1527264654481};\\\", \\\"{x:1611,y:750,t:1527264654493};\\\", \\\"{x:1611,y:748,t:1527264654508};\\\", \\\"{x:1611,y:747,t:1527264654526};\\\", \\\"{x:1611,y:745,t:1527264654543};\\\", \\\"{x:1611,y:743,t:1527264654559};\\\", \\\"{x:1611,y:740,t:1527264654576};\\\", \\\"{x:1611,y:732,t:1527264654592};\\\", \\\"{x:1610,y:725,t:1527264654609};\\\", \\\"{x:1609,y:718,t:1527264654626};\\\", \\\"{x:1607,y:711,t:1527264654643};\\\", \\\"{x:1607,y:704,t:1527264654659};\\\", \\\"{x:1604,y:697,t:1527264654676};\\\", \\\"{x:1603,y:690,t:1527264654693};\\\", \\\"{x:1600,y:678,t:1527264654708};\\\", \\\"{x:1597,y:664,t:1527264654725};\\\", \\\"{x:1595,y:652,t:1527264654742};\\\", \\\"{x:1591,y:639,t:1527264654759};\\\", \\\"{x:1588,y:629,t:1527264654776};\\\", \\\"{x:1584,y:615,t:1527264654792};\\\", \\\"{x:1583,y:611,t:1527264654808};\\\", \\\"{x:1582,y:605,t:1527264654825};\\\", \\\"{x:1582,y:601,t:1527264654843};\\\", \\\"{x:1582,y:598,t:1527264654859};\\\", \\\"{x:1582,y:597,t:1527264654875};\\\", \\\"{x:1582,y:595,t:1527264654892};\\\", \\\"{x:1582,y:594,t:1527264654910};\\\", \\\"{x:1582,y:592,t:1527264655025};\\\", \\\"{x:1583,y:592,t:1527264655043};\\\", \\\"{x:1584,y:591,t:1527264655060};\\\", \\\"{x:1585,y:591,t:1527264655075};\\\", \\\"{x:1587,y:591,t:1527264655092};\\\", \\\"{x:1588,y:591,t:1527264655111};\\\", \\\"{x:1589,y:591,t:1527264655128};\\\", \\\"{x:1590,y:591,t:1527264655152};\\\", \\\"{x:1591,y:591,t:1527264655159};\\\", \\\"{x:1593,y:591,t:1527264655176};\\\", \\\"{x:1594,y:591,t:1527264655199};\\\", \\\"{x:1596,y:591,t:1527264655215};\\\", \\\"{x:1597,y:591,t:1527264655232};\\\", \\\"{x:1599,y:591,t:1527264655248};\\\", \\\"{x:1600,y:591,t:1527264655264};\\\", \\\"{x:1603,y:591,t:1527264655275};\\\", \\\"{x:1606,y:591,t:1527264655292};\\\", \\\"{x:1609,y:590,t:1527264655310};\\\", \\\"{x:1610,y:589,t:1527264655326};\\\", \\\"{x:1613,y:588,t:1527264655342};\\\", \\\"{x:1614,y:588,t:1527264655489};\\\", \\\"{x:1614,y:587,t:1527264655513};\\\", \\\"{x:1615,y:585,t:1527264661113};\\\", \\\"{x:1615,y:576,t:1527264661130};\\\", \\\"{x:1616,y:563,t:1527264661148};\\\", \\\"{x:1622,y:550,t:1527264661165};\\\", \\\"{x:1628,y:537,t:1527264661180};\\\", \\\"{x:1632,y:527,t:1527264661197};\\\", \\\"{x:1633,y:523,t:1527264661214};\\\", \\\"{x:1633,y:522,t:1527264661230};\\\", \\\"{x:1633,y:521,t:1527264661256};\\\", \\\"{x:1633,y:520,t:1527264661273};\\\", \\\"{x:1633,y:519,t:1527264661289};\\\", \\\"{x:1633,y:518,t:1527264661296};\\\", \\\"{x:1632,y:517,t:1527264661314};\\\", \\\"{x:1632,y:515,t:1527264661330};\\\", \\\"{x:1632,y:513,t:1527264661347};\\\", \\\"{x:1631,y:513,t:1527264661364};\\\", \\\"{x:1630,y:512,t:1527264661380};\\\", \\\"{x:1630,y:511,t:1527264661397};\\\", \\\"{x:1630,y:512,t:1527264661448};\\\", \\\"{x:1630,y:516,t:1527264661463};\\\", \\\"{x:1630,y:532,t:1527264661480};\\\", \\\"{x:1627,y:561,t:1527264661497};\\\", \\\"{x:1623,y:580,t:1527264661514};\\\", \\\"{x:1619,y:592,t:1527264661531};\\\", \\\"{x:1618,y:599,t:1527264661547};\\\", \\\"{x:1617,y:600,t:1527264661689};\\\", \\\"{x:1615,y:600,t:1527264661713};\\\", \\\"{x:1612,y:598,t:1527264661721};\\\", \\\"{x:1609,y:595,t:1527264661731};\\\", \\\"{x:1607,y:592,t:1527264661747};\\\", \\\"{x:1604,y:587,t:1527264661764};\\\", \\\"{x:1604,y:583,t:1527264661781};\\\", \\\"{x:1604,y:580,t:1527264661798};\\\", \\\"{x:1604,y:577,t:1527264661815};\\\", \\\"{x:1604,y:576,t:1527264661831};\\\", \\\"{x:1603,y:575,t:1527264661847};\\\", \\\"{x:1603,y:574,t:1527264661880};\\\", \\\"{x:1603,y:573,t:1527264661913};\\\", \\\"{x:1603,y:572,t:1527264661929};\\\", \\\"{x:1603,y:571,t:1527264661936};\\\", \\\"{x:1603,y:570,t:1527264661961};\\\", \\\"{x:1603,y:569,t:1527264661985};\\\", \\\"{x:1603,y:568,t:1527264661997};\\\", \\\"{x:1603,y:567,t:1527264662040};\\\", \\\"{x:1603,y:565,t:1527264662257};\\\", \\\"{x:1604,y:560,t:1527264662264};\\\", \\\"{x:1605,y:552,t:1527264662280};\\\", \\\"{x:1606,y:543,t:1527264662298};\\\", \\\"{x:1606,y:532,t:1527264662314};\\\", \\\"{x:1606,y:518,t:1527264662330};\\\", \\\"{x:1606,y:507,t:1527264662348};\\\", \\\"{x:1606,y:500,t:1527264662364};\\\", \\\"{x:1606,y:493,t:1527264662381};\\\", \\\"{x:1605,y:486,t:1527264662398};\\\", \\\"{x:1604,y:481,t:1527264662414};\\\", \\\"{x:1603,y:474,t:1527264662431};\\\", \\\"{x:1603,y:469,t:1527264662448};\\\", \\\"{x:1602,y:462,t:1527264662464};\\\", \\\"{x:1601,y:457,t:1527264662481};\\\", \\\"{x:1600,y:454,t:1527264662498};\\\", \\\"{x:1600,y:451,t:1527264662514};\\\", \\\"{x:1600,y:449,t:1527264662531};\\\", \\\"{x:1600,y:448,t:1527264662553};\\\", \\\"{x:1600,y:445,t:1527264662568};\\\", \\\"{x:1600,y:444,t:1527264662592};\\\", \\\"{x:1600,y:443,t:1527264662600};\\\", \\\"{x:1600,y:442,t:1527264662665};\\\", \\\"{x:1600,y:441,t:1527264662705};\\\", \\\"{x:1600,y:440,t:1527264662715};\\\", \\\"{x:1600,y:439,t:1527264662731};\\\", \\\"{x:1600,y:438,t:1527264662761};\\\", \\\"{x:1600,y:436,t:1527264662785};\\\", \\\"{x:1602,y:436,t:1527264662833};\\\", \\\"{x:1604,y:437,t:1527264668369};\\\", \\\"{x:1604,y:439,t:1527264668385};\\\", \\\"{x:1606,y:442,t:1527264668402};\\\", \\\"{x:1609,y:446,t:1527264668419};\\\", \\\"{x:1612,y:449,t:1527264668435};\\\", \\\"{x:1616,y:453,t:1527264668451};\\\", \\\"{x:1618,y:454,t:1527264668468};\\\", \\\"{x:1620,y:455,t:1527264668485};\\\", \\\"{x:1620,y:456,t:1527264668721};\\\", \\\"{x:1620,y:458,t:1527264668736};\\\", \\\"{x:1620,y:466,t:1527264668752};\\\", \\\"{x:1620,y:471,t:1527264668769};\\\", \\\"{x:1620,y:477,t:1527264668785};\\\", \\\"{x:1620,y:483,t:1527264668803};\\\", \\\"{x:1618,y:493,t:1527264668819};\\\", \\\"{x:1617,y:496,t:1527264668835};\\\", \\\"{x:1615,y:502,t:1527264668853};\\\", \\\"{x:1613,y:511,t:1527264668869};\\\", \\\"{x:1612,y:518,t:1527264668885};\\\", \\\"{x:1611,y:525,t:1527264668902};\\\", \\\"{x:1609,y:533,t:1527264668919};\\\", \\\"{x:1608,y:540,t:1527264668936};\\\", \\\"{x:1608,y:548,t:1527264668953};\\\", \\\"{x:1608,y:552,t:1527264668969};\\\", \\\"{x:1608,y:556,t:1527264668985};\\\", \\\"{x:1608,y:559,t:1527264669002};\\\", \\\"{x:1608,y:563,t:1527264669022};\\\", \\\"{x:1608,y:570,t:1527264669035};\\\", \\\"{x:1608,y:579,t:1527264669052};\\\", \\\"{x:1609,y:589,t:1527264669069};\\\", \\\"{x:1611,y:599,t:1527264669084};\\\", \\\"{x:1613,y:608,t:1527264669102};\\\", \\\"{x:1614,y:614,t:1527264669119};\\\", \\\"{x:1615,y:620,t:1527264669135};\\\", \\\"{x:1615,y:630,t:1527264669151};\\\", \\\"{x:1617,y:638,t:1527264669168};\\\", \\\"{x:1618,y:644,t:1527264669185};\\\", \\\"{x:1618,y:651,t:1527264669202};\\\", \\\"{x:1618,y:659,t:1527264669218};\\\", \\\"{x:1618,y:669,t:1527264669235};\\\", \\\"{x:1618,y:678,t:1527264669252};\\\", \\\"{x:1618,y:688,t:1527264669269};\\\", \\\"{x:1615,y:699,t:1527264669286};\\\", \\\"{x:1613,y:709,t:1527264669302};\\\", \\\"{x:1611,y:719,t:1527264669319};\\\", \\\"{x:1608,y:726,t:1527264669335};\\\", \\\"{x:1606,y:742,t:1527264669352};\\\", \\\"{x:1604,y:751,t:1527264669369};\\\", \\\"{x:1602,y:763,t:1527264669385};\\\", \\\"{x:1602,y:773,t:1527264669402};\\\", \\\"{x:1602,y:777,t:1527264669419};\\\", \\\"{x:1602,y:781,t:1527264669436};\\\", \\\"{x:1602,y:784,t:1527264669451};\\\", \\\"{x:1602,y:788,t:1527264669468};\\\", \\\"{x:1602,y:793,t:1527264669486};\\\", \\\"{x:1602,y:797,t:1527264669501};\\\", \\\"{x:1602,y:801,t:1527264669518};\\\", \\\"{x:1604,y:804,t:1527264669535};\\\", \\\"{x:1604,y:808,t:1527264669552};\\\", \\\"{x:1604,y:812,t:1527264669568};\\\", \\\"{x:1605,y:816,t:1527264669586};\\\", \\\"{x:1605,y:819,t:1527264669602};\\\", \\\"{x:1606,y:824,t:1527264669618};\\\", \\\"{x:1607,y:827,t:1527264669636};\\\", \\\"{x:1607,y:831,t:1527264669652};\\\", \\\"{x:1608,y:837,t:1527264669669};\\\", \\\"{x:1608,y:840,t:1527264669685};\\\", \\\"{x:1608,y:845,t:1527264669702};\\\", \\\"{x:1608,y:847,t:1527264669718};\\\", \\\"{x:1609,y:854,t:1527264669736};\\\", \\\"{x:1609,y:858,t:1527264669752};\\\", \\\"{x:1609,y:862,t:1527264669769};\\\", \\\"{x:1610,y:865,t:1527264669786};\\\", \\\"{x:1611,y:869,t:1527264669802};\\\", \\\"{x:1611,y:871,t:1527264669819};\\\", \\\"{x:1612,y:873,t:1527264669836};\\\", \\\"{x:1612,y:874,t:1527264669852};\\\", \\\"{x:1612,y:876,t:1527264669870};\\\", \\\"{x:1612,y:881,t:1527264669886};\\\", \\\"{x:1612,y:883,t:1527264669902};\\\", \\\"{x:1612,y:888,t:1527264669920};\\\", \\\"{x:1612,y:894,t:1527264669936};\\\", \\\"{x:1612,y:896,t:1527264669952};\\\", \\\"{x:1612,y:898,t:1527264669970};\\\", \\\"{x:1612,y:900,t:1527264669986};\\\", \\\"{x:1612,y:901,t:1527264670003};\\\", \\\"{x:1612,y:905,t:1527264670019};\\\", \\\"{x:1612,y:909,t:1527264670036};\\\", \\\"{x:1611,y:915,t:1527264670052};\\\", \\\"{x:1610,y:920,t:1527264670069};\\\", \\\"{x:1609,y:925,t:1527264670087};\\\", \\\"{x:1608,y:931,t:1527264670103};\\\", \\\"{x:1604,y:937,t:1527264670119};\\\", \\\"{x:1601,y:945,t:1527264670136};\\\", \\\"{x:1601,y:947,t:1527264670153};\\\", \\\"{x:1600,y:949,t:1527264670169};\\\", \\\"{x:1600,y:952,t:1527264670186};\\\", \\\"{x:1599,y:957,t:1527264670203};\\\", \\\"{x:1599,y:959,t:1527264670218};\\\", \\\"{x:1599,y:961,t:1527264670236};\\\", \\\"{x:1598,y:962,t:1527264670253};\\\", \\\"{x:1598,y:963,t:1527264670272};\\\", \\\"{x:1598,y:962,t:1527264670472};\\\", \\\"{x:1598,y:959,t:1527264670486};\\\", \\\"{x:1595,y:947,t:1527264670503};\\\", \\\"{x:1591,y:927,t:1527264670519};\\\", \\\"{x:1581,y:892,t:1527264670536};\\\", \\\"{x:1575,y:872,t:1527264670553};\\\", \\\"{x:1571,y:858,t:1527264670570};\\\", \\\"{x:1567,y:838,t:1527264670586};\\\", \\\"{x:1566,y:810,t:1527264670603};\\\", \\\"{x:1566,y:762,t:1527264670620};\\\", \\\"{x:1566,y:720,t:1527264670636};\\\", \\\"{x:1566,y:687,t:1527264670653};\\\", \\\"{x:1566,y:661,t:1527264670670};\\\", \\\"{x:1566,y:635,t:1527264670686};\\\", \\\"{x:1567,y:608,t:1527264670703};\\\", \\\"{x:1574,y:539,t:1527264670720};\\\", \\\"{x:1579,y:514,t:1527264670736};\\\", \\\"{x:1580,y:505,t:1527264670753};\\\", \\\"{x:1582,y:492,t:1527264670770};\\\", \\\"{x:1583,y:482,t:1527264670786};\\\", \\\"{x:1584,y:475,t:1527264670803};\\\", \\\"{x:1585,y:473,t:1527264670820};\\\", \\\"{x:1585,y:472,t:1527264670837};\\\", \\\"{x:1585,y:471,t:1527264670912};\\\", \\\"{x:1586,y:469,t:1527264670921};\\\", \\\"{x:1595,y:466,t:1527264670936};\\\", \\\"{x:1601,y:462,t:1527264670954};\\\", \\\"{x:1609,y:460,t:1527264670970};\\\", \\\"{x:1612,y:458,t:1527264670986};\\\", \\\"{x:1614,y:458,t:1527264671004};\\\", \\\"{x:1614,y:457,t:1527264671020};\\\", \\\"{x:1615,y:457,t:1527264671113};\\\", \\\"{x:1616,y:456,t:1527264671137};\\\", \\\"{x:1617,y:456,t:1527264671153};\\\", \\\"{x:1617,y:455,t:1527264671185};\\\", \\\"{x:1617,y:453,t:1527264671233};\\\", \\\"{x:1617,y:452,t:1527264671257};\\\", \\\"{x:1616,y:451,t:1527264671270};\\\", \\\"{x:1615,y:449,t:1527264671288};\\\", \\\"{x:1614,y:447,t:1527264671304};\\\", \\\"{x:1611,y:444,t:1527264671321};\\\", \\\"{x:1609,y:442,t:1527264671337};\\\", \\\"{x:1608,y:442,t:1527264691896};\\\", \\\"{x:1606,y:442,t:1527264691905};\\\", \\\"{x:1604,y:441,t:1527264691920};\\\", \\\"{x:1603,y:441,t:1527264691935};\\\", \\\"{x:1602,y:440,t:1527264691952};\\\", \\\"{x:1636,y:430,t:1527264708833};\\\", \\\"{x:1713,y:416,t:1527264708847};\\\", \\\"{x:1803,y:396,t:1527264708862};\\\", \\\"{x:1802,y:393,t:1527264708880};\\\", \\\"{x:1756,y:314,t:1527264708896};\\\", \\\"{x:1675,y:217,t:1527264708912};\\\", \\\"{x:1612,y:141,t:1527264708929};\\\", \\\"{x:1585,y:78,t:1527264708947};\\\", \\\"{x:1585,y:66,t:1527264708962};\\\", \\\"{x:1560,y:66,t:1527264709472};\\\", \\\"{x:1522,y:72,t:1527264709480};\\\", \\\"{x:1480,y:78,t:1527264709495};\\\", \\\"{x:1468,y:80,t:1527264709513};\\\", \\\"{x:1468,y:79,t:1527264709544};\\\", \\\"{x:1468,y:78,t:1527264709552};\\\", \\\"{x:1476,y:80,t:1527264709897};\\\", \\\"{x:1476,y:83,t:1527264709913};\\\", \\\"{x:1448,y:109,t:1527264709930};\\\", \\\"{x:1392,y:143,t:1527264709946};\\\", \\\"{x:1263,y:199,t:1527264709963};\\\", \\\"{x:1097,y:281,t:1527264709981};\\\", \\\"{x:919,y:371,t:1527264709996};\\\", \\\"{x:733,y:471,t:1527264710014};\\\", \\\"{x:553,y:570,t:1527264710030};\\\", \\\"{x:367,y:668,t:1527264710047};\\\", \\\"{x:182,y:751,t:1527264710063};\\\", \\\"{x:9,y:824,t:1527264710074};\\\", \\\"{x:0,y:875,t:1527264710090};\\\", \\\"{x:0,y:907,t:1527264710108};\\\", \\\"{x:0,y:928,t:1527264710124};\\\", \\\"{x:0,y:936,t:1527264710141};\\\", \\\"{x:0,y:934,t:1527264710175};\\\", \\\"{x:0,y:932,t:1527264710240};\\\", \\\"{x:0,y:925,t:1527264710247};\\\", \\\"{x:5,y:912,t:1527264710257};\\\", \\\"{x:14,y:878,t:1527264710275};\\\", \\\"{x:28,y:837,t:1527264710291};\\\", \\\"{x:40,y:805,t:1527264710307};\\\", \\\"{x:50,y:780,t:1527264710325};\\\", \\\"{x:65,y:744,t:1527264710341};\\\", \\\"{x:80,y:701,t:1527264710358};\\\", \\\"{x:90,y:677,t:1527264710375};\\\", \\\"{x:98,y:659,t:1527264710392};\\\", \\\"{x:103,y:637,t:1527264710409};\\\", \\\"{x:106,y:629,t:1527264710425};\\\", \\\"{x:110,y:625,t:1527264710442};\\\", \\\"{x:112,y:623,t:1527264710458};\\\", \\\"{x:113,y:623,t:1527264710474};\\\", \\\"{x:115,y:623,t:1527264710492};\\\", \\\"{x:118,y:623,t:1527264710507};\\\", \\\"{x:119,y:623,t:1527264710525};\\\", \\\"{x:123,y:624,t:1527264710541};\\\", \\\"{x:127,y:626,t:1527264710744};\\\", \\\"{x:137,y:626,t:1527264710759};\\\", \\\"{x:144,y:627,t:1527264710775};\\\", \\\"{x:150,y:633,t:1527264710793};\\\", \\\"{x:150,y:636,t:1527264710809};\\\", \\\"{x:150,y:637,t:1527264713376};\\\", \\\"{x:155,y:636,t:1527264717595};\\\", \\\"{x:163,y:629,t:1527264717603};\\\", \\\"{x:169,y:622,t:1527264717617};\\\", \\\"{x:186,y:599,t:1527264717635};\\\", \\\"{x:207,y:561,t:1527264717650};\\\", \\\"{x:230,y:526,t:1527264717684};\\\", \\\"{x:232,y:522,t:1527264717701};\\\", \\\"{x:232,y:520,t:1527264717717};\\\", \\\"{x:233,y:519,t:1527264717733};\\\", \\\"{x:227,y:519,t:1527264717778};\\\", \\\"{x:222,y:519,t:1527264717786};\\\", \\\"{x:216,y:519,t:1527264717800};\\\", \\\"{x:201,y:520,t:1527264717817};\\\", \\\"{x:186,y:525,t:1527264717833};\\\", \\\"{x:170,y:533,t:1527264717850};\\\", \\\"{x:158,y:541,t:1527264717867};\\\", \\\"{x:148,y:548,t:1527264717884};\\\", \\\"{x:140,y:553,t:1527264717900};\\\", \\\"{x:137,y:556,t:1527264717917};\\\", \\\"{x:134,y:559,t:1527264717934};\\\", \\\"{x:131,y:566,t:1527264717950};\\\", \\\"{x:128,y:570,t:1527264717967};\\\", \\\"{x:127,y:577,t:1527264717984};\\\", \\\"{x:127,y:582,t:1527264718002};\\\", \\\"{x:127,y:588,t:1527264718017};\\\", \\\"{x:130,y:594,t:1527264718034};\\\", \\\"{x:139,y:598,t:1527264718050};\\\", \\\"{x:145,y:602,t:1527264718067};\\\", \\\"{x:149,y:603,t:1527264718084};\\\", \\\"{x:150,y:603,t:1527264718100};\\\", \\\"{x:150,y:604,t:1527264718130};\\\", \\\"{x:151,y:604,t:1527264718138};\\\", \\\"{x:151,y:605,t:1527264718150};\\\", \\\"{x:151,y:608,t:1527264718166};\\\", \\\"{x:152,y:611,t:1527264718184};\\\", \\\"{x:152,y:613,t:1527264718200};\\\", \\\"{x:152,y:614,t:1527264718217};\\\", \\\"{x:153,y:614,t:1527264718235};\\\", \\\"{x:154,y:615,t:1527264718307};\\\", \\\"{x:155,y:616,t:1527264718317};\\\", \\\"{x:155,y:617,t:1527264718334};\\\", \\\"{x:155,y:619,t:1527264718351};\\\", \\\"{x:155,y:621,t:1527264718368};\\\", \\\"{x:155,y:626,t:1527264718385};\\\", \\\"{x:155,y:631,t:1527264718402};\\\", \\\"{x:155,y:636,t:1527264718417};\\\", \\\"{x:155,y:642,t:1527264718435};\\\", \\\"{x:155,y:643,t:1527264718450};\\\", \\\"{x:156,y:646,t:1527264718786};\\\", \\\"{x:175,y:654,t:1527264718802};\\\", \\\"{x:261,y:679,t:1527264718818};\\\", \\\"{x:320,y:687,t:1527264718834};\\\", \\\"{x:368,y:696,t:1527264718851};\\\", \\\"{x:421,y:696,t:1527264718867};\\\", \\\"{x:460,y:696,t:1527264718885};\\\", \\\"{x:484,y:693,t:1527264718901};\\\", \\\"{x:491,y:691,t:1527264718919};\\\", \\\"{x:491,y:690,t:1527264718971};\\\", \\\"{x:491,y:689,t:1527264718995};\\\", \\\"{x:491,y:688,t:1527264719002};\\\", \\\"{x:497,y:692,t:1527264719107};\\\", \\\"{x:501,y:695,t:1527264719119};\\\", \\\"{x:511,y:709,t:1527264719136};\\\", \\\"{x:521,y:722,t:1527264719152};\\\", \\\"{x:522,y:725,t:1527264719168};\\\", \\\"{x:522,y:726,t:1527264719891};\\\", \\\"{x:522,y:727,t:1527264719915};\\\", \\\"{x:522,y:729,t:1527264719939};\\\", \\\"{x:521,y:729,t:1527264719953};\\\", \\\"{x:520,y:730,t:1527264719968};\\\", \\\"{x:517,y:731,t:1527264719985};\\\", \\\"{x:509,y:737,t:1527264720002};\\\", \\\"{x:491,y:757,t:1527264720018};\\\", \\\"{x:490,y:758,t:1527264720035};\\\", \\\"{x:491,y:757,t:1527264720370};\\\", \\\"{x:493,y:756,t:1527264720385};\\\", \\\"{x:493,y:754,t:1527264720411};\\\", \\\"{x:497,y:751,t:1527264720419};\\\", \\\"{x:512,y:744,t:1527264720436};\\\", \\\"{x:532,y:735,t:1527264720453};\\\", \\\"{x:558,y:728,t:1527264720468};\\\", \\\"{x:595,y:715,t:1527264720485};\\\", \\\"{x:643,y:702,t:1527264720511};\\\", \\\"{x:654,y:699,t:1527264720518};\\\", \\\"{x:671,y:694,t:1527264720554};\\\", \\\"{x:678,y:692,t:1527264720568};\\\" ] }, { \\\"rt\\\": 21994, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 327995, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -A -C -Z -Z -Z -Z -Z -Z -Z -Z -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:686,y:692,t:1527264722515};\\\", \\\"{x:704,y:692,t:1527264722523};\\\", \\\"{x:735,y:692,t:1527264722538};\\\", \\\"{x:884,y:649,t:1527264722555};\\\", \\\"{x:1014,y:586,t:1527264722571};\\\", \\\"{x:1164,y:507,t:1527264722588};\\\", \\\"{x:1295,y:433,t:1527264722605};\\\", \\\"{x:1399,y:377,t:1527264722622};\\\", \\\"{x:1456,y:346,t:1527264722638};\\\", \\\"{x:1480,y:337,t:1527264722656};\\\", \\\"{x:1482,y:335,t:1527264722671};\\\", \\\"{x:1481,y:336,t:1527264722730};\\\", \\\"{x:1479,y:336,t:1527264722738};\\\", \\\"{x:1475,y:341,t:1527264722755};\\\", \\\"{x:1471,y:349,t:1527264722772};\\\", \\\"{x:1467,y:361,t:1527264722788};\\\", \\\"{x:1463,y:367,t:1527264722805};\\\", \\\"{x:1456,y:382,t:1527264722821};\\\", \\\"{x:1447,y:403,t:1527264722838};\\\", \\\"{x:1439,y:427,t:1527264722855};\\\", \\\"{x:1430,y:446,t:1527264722871};\\\", \\\"{x:1428,y:452,t:1527264722888};\\\", \\\"{x:1426,y:453,t:1527264723091};\\\", \\\"{x:1426,y:456,t:1527264723105};\\\", \\\"{x:1425,y:461,t:1527264723122};\\\", \\\"{x:1424,y:463,t:1527264723138};\\\", \\\"{x:1422,y:478,t:1527264723155};\\\", \\\"{x:1422,y:489,t:1527264723172};\\\", \\\"{x:1429,y:504,t:1527264723189};\\\", \\\"{x:1437,y:520,t:1527264723205};\\\", \\\"{x:1445,y:538,t:1527264723222};\\\", \\\"{x:1456,y:560,t:1527264723238};\\\", \\\"{x:1466,y:579,t:1527264723255};\\\", \\\"{x:1476,y:596,t:1527264723271};\\\", \\\"{x:1485,y:613,t:1527264723289};\\\", \\\"{x:1493,y:630,t:1527264723305};\\\", \\\"{x:1498,y:643,t:1527264723322};\\\", \\\"{x:1502,y:667,t:1527264723339};\\\", \\\"{x:1504,y:677,t:1527264723355};\\\", \\\"{x:1504,y:684,t:1527264723372};\\\", \\\"{x:1501,y:693,t:1527264723389};\\\", \\\"{x:1492,y:707,t:1527264723405};\\\", \\\"{x:1489,y:712,t:1527264723422};\\\", \\\"{x:1489,y:713,t:1527264723740};\\\", \\\"{x:1481,y:714,t:1527264723756};\\\", \\\"{x:1466,y:715,t:1527264723773};\\\", \\\"{x:1450,y:721,t:1527264723790};\\\", \\\"{x:1437,y:726,t:1527264723806};\\\", \\\"{x:1417,y:735,t:1527264723822};\\\", \\\"{x:1398,y:746,t:1527264723839};\\\", \\\"{x:1376,y:756,t:1527264723856};\\\", \\\"{x:1359,y:765,t:1527264723873};\\\", \\\"{x:1341,y:776,t:1527264723889};\\\", \\\"{x:1324,y:785,t:1527264723906};\\\", \\\"{x:1314,y:791,t:1527264723922};\\\", \\\"{x:1310,y:795,t:1527264723939};\\\", \\\"{x:1307,y:798,t:1527264723957};\\\", \\\"{x:1307,y:800,t:1527264723979};\\\", \\\"{x:1306,y:803,t:1527264723989};\\\", \\\"{x:1298,y:811,t:1527264724006};\\\", \\\"{x:1288,y:819,t:1527264724022};\\\", \\\"{x:1276,y:830,t:1527264724042};\\\", \\\"{x:1262,y:837,t:1527264724057};\\\", \\\"{x:1248,y:842,t:1527264724072};\\\", \\\"{x:1231,y:846,t:1527264724089};\\\", \\\"{x:1211,y:849,t:1527264724106};\\\", \\\"{x:1199,y:851,t:1527264724122};\\\", \\\"{x:1182,y:852,t:1527264724139};\\\", \\\"{x:1177,y:853,t:1527264724156};\\\", \\\"{x:1173,y:853,t:1527264724172};\\\", \\\"{x:1172,y:853,t:1527264724189};\\\", \\\"{x:1171,y:853,t:1527264724206};\\\", \\\"{x:1172,y:853,t:1527264724259};\\\", \\\"{x:1177,y:851,t:1527264724273};\\\", \\\"{x:1180,y:850,t:1527264724289};\\\", \\\"{x:1187,y:847,t:1527264724306};\\\", \\\"{x:1193,y:844,t:1527264724323};\\\", \\\"{x:1194,y:844,t:1527264724339};\\\", \\\"{x:1195,y:843,t:1527264724396};\\\", \\\"{x:1196,y:843,t:1527264724406};\\\", \\\"{x:1199,y:843,t:1527264724423};\\\", \\\"{x:1204,y:842,t:1527264724439};\\\", \\\"{x:1206,y:842,t:1527264724456};\\\", \\\"{x:1209,y:841,t:1527264724473};\\\", \\\"{x:1211,y:841,t:1527264724490};\\\", \\\"{x:1211,y:840,t:1527264724507};\\\", \\\"{x:1212,y:840,t:1527264724595};\\\", \\\"{x:1214,y:840,t:1527264724611};\\\", \\\"{x:1215,y:840,t:1527264724623};\\\", \\\"{x:1217,y:840,t:1527264724640};\\\", \\\"{x:1218,y:840,t:1527264724657};\\\", \\\"{x:1219,y:841,t:1527264724673};\\\", \\\"{x:1219,y:843,t:1527264724690};\\\", \\\"{x:1219,y:847,t:1527264724706};\\\", \\\"{x:1219,y:857,t:1527264724723};\\\", \\\"{x:1219,y:866,t:1527264724740};\\\", \\\"{x:1219,y:878,t:1527264724757};\\\", \\\"{x:1219,y:891,t:1527264724773};\\\", \\\"{x:1219,y:899,t:1527264724790};\\\", \\\"{x:1218,y:908,t:1527264724806};\\\", \\\"{x:1217,y:913,t:1527264724823};\\\", \\\"{x:1216,y:916,t:1527264724840};\\\", \\\"{x:1216,y:922,t:1527264724857};\\\", \\\"{x:1217,y:929,t:1527264724873};\\\", \\\"{x:1221,y:936,t:1527264724890};\\\", \\\"{x:1224,y:940,t:1527264724906};\\\", \\\"{x:1226,y:945,t:1527264724923};\\\", \\\"{x:1226,y:947,t:1527264724940};\\\", \\\"{x:1226,y:950,t:1527264724956};\\\", \\\"{x:1226,y:953,t:1527264724974};\\\", \\\"{x:1225,y:954,t:1527264725003};\\\", \\\"{x:1224,y:952,t:1527264725044};\\\", \\\"{x:1222,y:945,t:1527264725056};\\\", \\\"{x:1221,y:929,t:1527264725073};\\\", \\\"{x:1221,y:906,t:1527264725091};\\\", \\\"{x:1230,y:864,t:1527264725107};\\\", \\\"{x:1236,y:849,t:1527264725123};\\\", \\\"{x:1241,y:841,t:1527264725140};\\\", \\\"{x:1244,y:835,t:1527264725156};\\\", \\\"{x:1245,y:828,t:1527264725172};\\\", \\\"{x:1246,y:824,t:1527264725190};\\\", \\\"{x:1247,y:821,t:1527264725206};\\\", \\\"{x:1248,y:819,t:1527264725222};\\\", \\\"{x:1247,y:819,t:1527264725323};\\\", \\\"{x:1243,y:819,t:1527264725340};\\\", \\\"{x:1238,y:821,t:1527264725357};\\\", \\\"{x:1231,y:825,t:1527264725373};\\\", \\\"{x:1227,y:828,t:1527264725390};\\\", \\\"{x:1223,y:831,t:1527264725407};\\\", \\\"{x:1218,y:834,t:1527264725423};\\\", \\\"{x:1216,y:835,t:1527264725440};\\\", \\\"{x:1214,y:836,t:1527264725457};\\\", \\\"{x:1212,y:836,t:1527264725604};\\\", \\\"{x:1212,y:837,t:1527264725611};\\\", \\\"{x:1211,y:837,t:1527264725625};\\\", \\\"{x:1210,y:837,t:1527264725640};\\\", \\\"{x:1209,y:838,t:1527264725657};\\\", \\\"{x:1208,y:838,t:1527264725674};\\\", \\\"{x:1210,y:838,t:1527264725788};\\\", \\\"{x:1216,y:838,t:1527264725796};\\\", \\\"{x:1220,y:838,t:1527264725807};\\\", \\\"{x:1234,y:838,t:1527264725824};\\\", \\\"{x:1246,y:838,t:1527264725841};\\\", \\\"{x:1258,y:838,t:1527264725857};\\\", \\\"{x:1271,y:838,t:1527264725874};\\\", \\\"{x:1278,y:838,t:1527264725890};\\\", \\\"{x:1287,y:838,t:1527264725907};\\\", \\\"{x:1289,y:838,t:1527264725924};\\\", \\\"{x:1290,y:838,t:1527264725940};\\\", \\\"{x:1291,y:838,t:1527264726004};\\\", \\\"{x:1292,y:838,t:1527264726012};\\\", \\\"{x:1294,y:838,t:1527264726024};\\\", \\\"{x:1302,y:838,t:1527264726041};\\\", \\\"{x:1311,y:838,t:1527264726057};\\\", \\\"{x:1323,y:840,t:1527264726074};\\\", \\\"{x:1336,y:840,t:1527264726091};\\\", \\\"{x:1340,y:840,t:1527264726107};\\\", \\\"{x:1344,y:840,t:1527264726124};\\\", \\\"{x:1346,y:840,t:1527264726141};\\\", \\\"{x:1347,y:841,t:1527264726157};\\\", \\\"{x:1348,y:842,t:1527264726174};\\\", \\\"{x:1346,y:842,t:1527264726347};\\\", \\\"{x:1345,y:843,t:1527264726357};\\\", \\\"{x:1342,y:844,t:1527264726374};\\\", \\\"{x:1338,y:844,t:1527264726391};\\\", \\\"{x:1337,y:844,t:1527264726408};\\\", \\\"{x:1335,y:845,t:1527264726425};\\\", \\\"{x:1334,y:845,t:1527264726443};\\\", \\\"{x:1332,y:845,t:1527264726483};\\\", \\\"{x:1331,y:845,t:1527264726507};\\\", \\\"{x:1330,y:845,t:1527264726563};\\\", \\\"{x:1329,y:843,t:1527264726575};\\\", \\\"{x:1329,y:842,t:1527264726596};\\\", \\\"{x:1329,y:841,t:1527264726608};\\\", \\\"{x:1328,y:840,t:1527264726624};\\\", \\\"{x:1328,y:839,t:1527264726644};\\\", \\\"{x:1327,y:842,t:1527264726771};\\\", \\\"{x:1326,y:845,t:1527264726779};\\\", \\\"{x:1325,y:845,t:1527264726791};\\\", \\\"{x:1324,y:849,t:1527264726808};\\\", \\\"{x:1323,y:852,t:1527264726825};\\\", \\\"{x:1322,y:857,t:1527264726842};\\\", \\\"{x:1322,y:859,t:1527264726859};\\\", \\\"{x:1322,y:862,t:1527264726876};\\\", \\\"{x:1322,y:863,t:1527264726891};\\\", \\\"{x:1322,y:865,t:1527264726908};\\\", \\\"{x:1323,y:866,t:1527264726925};\\\", \\\"{x:1325,y:870,t:1527264726941};\\\", \\\"{x:1329,y:873,t:1527264726958};\\\", \\\"{x:1332,y:877,t:1527264726976};\\\", \\\"{x:1334,y:880,t:1527264726991};\\\", \\\"{x:1337,y:887,t:1527264727008};\\\", \\\"{x:1341,y:896,t:1527264727026};\\\", \\\"{x:1346,y:907,t:1527264727042};\\\", \\\"{x:1350,y:915,t:1527264727058};\\\", \\\"{x:1354,y:921,t:1527264727075};\\\", \\\"{x:1354,y:922,t:1527264727092};\\\", \\\"{x:1355,y:922,t:1527264727109};\\\", \\\"{x:1356,y:923,t:1527264727126};\\\", \\\"{x:1357,y:924,t:1527264727141};\\\", \\\"{x:1358,y:924,t:1527264727158};\\\", \\\"{x:1358,y:923,t:1527264727276};\\\", \\\"{x:1358,y:919,t:1527264727292};\\\", \\\"{x:1358,y:915,t:1527264727308};\\\", \\\"{x:1357,y:910,t:1527264727325};\\\", \\\"{x:1357,y:907,t:1527264727343};\\\", \\\"{x:1357,y:905,t:1527264727359};\\\", \\\"{x:1357,y:904,t:1527264727375};\\\", \\\"{x:1357,y:902,t:1527264727392};\\\", \\\"{x:1357,y:901,t:1527264727676};\\\", \\\"{x:1356,y:900,t:1527264727692};\\\", \\\"{x:1354,y:899,t:1527264727715};\\\", \\\"{x:1353,y:899,t:1527264727731};\\\", \\\"{x:1352,y:898,t:1527264727759};\\\", \\\"{x:1353,y:897,t:1527264729491};\\\", \\\"{x:1354,y:897,t:1527264729548};\\\", \\\"{x:1354,y:896,t:1527264729948};\\\", \\\"{x:1354,y:895,t:1527264729964};\\\", \\\"{x:1354,y:894,t:1527264729977};\\\", \\\"{x:1354,y:893,t:1527264729995};\\\", \\\"{x:1354,y:892,t:1527264730010};\\\", \\\"{x:1353,y:891,t:1527264730027};\\\", \\\"{x:1353,y:890,t:1527264730044};\\\", \\\"{x:1352,y:888,t:1527264730060};\\\", \\\"{x:1352,y:887,t:1527264730077};\\\", \\\"{x:1352,y:886,t:1527264730094};\\\", \\\"{x:1351,y:883,t:1527264730110};\\\", \\\"{x:1350,y:882,t:1527264730126};\\\", \\\"{x:1349,y:879,t:1527264730143};\\\", \\\"{x:1349,y:877,t:1527264730160};\\\", \\\"{x:1347,y:874,t:1527264730176};\\\", \\\"{x:1347,y:870,t:1527264730194};\\\", \\\"{x:1344,y:862,t:1527264730210};\\\", \\\"{x:1343,y:858,t:1527264730226};\\\", \\\"{x:1342,y:855,t:1527264730243};\\\", \\\"{x:1342,y:853,t:1527264730261};\\\", \\\"{x:1341,y:851,t:1527264730277};\\\", \\\"{x:1341,y:850,t:1527264730294};\\\", \\\"{x:1341,y:849,t:1527264730314};\\\", \\\"{x:1341,y:851,t:1527264730499};\\\", \\\"{x:1340,y:854,t:1527264730511};\\\", \\\"{x:1339,y:858,t:1527264730527};\\\", \\\"{x:1338,y:862,t:1527264730544};\\\", \\\"{x:1338,y:865,t:1527264730561};\\\", \\\"{x:1336,y:868,t:1527264730576};\\\", \\\"{x:1336,y:869,t:1527264730594};\\\", \\\"{x:1336,y:871,t:1527264730610};\\\", \\\"{x:1336,y:873,t:1527264730627};\\\", \\\"{x:1336,y:874,t:1527264730650};\\\", \\\"{x:1336,y:875,t:1527264730666};\\\", \\\"{x:1336,y:876,t:1527264730698};\\\", \\\"{x:1336,y:877,t:1527264730711};\\\", \\\"{x:1337,y:878,t:1527264730728};\\\", \\\"{x:1338,y:880,t:1527264730744};\\\", \\\"{x:1339,y:881,t:1527264730761};\\\", \\\"{x:1340,y:882,t:1527264730802};\\\", \\\"{x:1340,y:883,t:1527264730826};\\\", \\\"{x:1341,y:884,t:1527264730834};\\\", \\\"{x:1341,y:885,t:1527264730866};\\\", \\\"{x:1342,y:886,t:1527264730882};\\\", \\\"{x:1342,y:887,t:1527264730906};\\\", \\\"{x:1343,y:888,t:1527264730930};\\\", \\\"{x:1344,y:888,t:1527264730946};\\\", \\\"{x:1345,y:889,t:1527264730960};\\\", \\\"{x:1345,y:890,t:1527264730978};\\\", \\\"{x:1346,y:892,t:1527264730994};\\\", \\\"{x:1347,y:893,t:1527264731162};\\\", \\\"{x:1347,y:894,t:1527264731202};\\\", \\\"{x:1347,y:896,t:1527264731234};\\\", \\\"{x:1348,y:896,t:1527264731258};\\\", \\\"{x:1348,y:897,t:1527264731290};\\\", \\\"{x:1348,y:899,t:1527264731362};\\\", \\\"{x:1347,y:899,t:1527264735250};\\\", \\\"{x:1345,y:898,t:1527264735274};\\\", \\\"{x:1345,y:897,t:1527264735282};\\\", \\\"{x:1345,y:892,t:1527264735298};\\\", \\\"{x:1345,y:888,t:1527264735314};\\\", \\\"{x:1345,y:884,t:1527264735331};\\\", \\\"{x:1345,y:882,t:1527264735348};\\\", \\\"{x:1346,y:880,t:1527264735364};\\\", \\\"{x:1347,y:880,t:1527264735539};\\\", \\\"{x:1347,y:882,t:1527264735548};\\\", \\\"{x:1347,y:887,t:1527264735564};\\\", \\\"{x:1347,y:890,t:1527264735582};\\\", \\\"{x:1347,y:893,t:1527264735599};\\\", \\\"{x:1347,y:895,t:1527264735723};\\\", \\\"{x:1347,y:896,t:1527264735732};\\\", \\\"{x:1347,y:899,t:1527264735748};\\\", \\\"{x:1347,y:901,t:1527264735765};\\\", \\\"{x:1347,y:902,t:1527264735782};\\\", \\\"{x:1347,y:903,t:1527264735799};\\\", \\\"{x:1346,y:903,t:1527264736051};\\\", \\\"{x:1344,y:902,t:1527264736065};\\\", \\\"{x:1344,y:900,t:1527264736123};\\\", \\\"{x:1344,y:899,t:1527264736133};\\\", \\\"{x:1344,y:897,t:1527264736148};\\\", \\\"{x:1344,y:894,t:1527264736165};\\\", \\\"{x:1345,y:892,t:1527264736183};\\\", \\\"{x:1345,y:891,t:1527264736228};\\\", \\\"{x:1345,y:895,t:1527264739003};\\\", \\\"{x:1345,y:900,t:1527264739017};\\\", \\\"{x:1345,y:904,t:1527264739034};\\\", \\\"{x:1345,y:907,t:1527264739051};\\\", \\\"{x:1345,y:905,t:1527264739554};\\\", \\\"{x:1345,y:904,t:1527264739568};\\\", \\\"{x:1345,y:900,t:1527264739584};\\\", \\\"{x:1345,y:897,t:1527264739601};\\\", \\\"{x:1345,y:894,t:1527264739617};\\\", \\\"{x:1345,y:891,t:1527264739635};\\\", \\\"{x:1345,y:890,t:1527264739931};\\\", \\\"{x:1345,y:889,t:1527264739938};\\\", \\\"{x:1344,y:887,t:1527264739971};\\\", \\\"{x:1341,y:887,t:1527264739987};\\\", \\\"{x:1340,y:887,t:1527264740002};\\\", \\\"{x:1333,y:887,t:1527264740019};\\\", \\\"{x:1327,y:887,t:1527264740035};\\\", \\\"{x:1322,y:888,t:1527264740052};\\\", \\\"{x:1307,y:888,t:1527264740069};\\\", \\\"{x:1285,y:888,t:1527264740085};\\\", \\\"{x:1250,y:885,t:1527264740102};\\\", \\\"{x:1205,y:872,t:1527264740119};\\\", \\\"{x:1150,y:857,t:1527264740136};\\\", \\\"{x:1090,y:835,t:1527264740152};\\\", \\\"{x:1034,y:808,t:1527264740169};\\\", \\\"{x:968,y:770,t:1527264740186};\\\", \\\"{x:897,y:729,t:1527264740201};\\\", \\\"{x:803,y:667,t:1527264740218};\\\", \\\"{x:757,y:642,t:1527264740236};\\\", \\\"{x:718,y:623,t:1527264740252};\\\", \\\"{x:691,y:608,t:1527264740268};\\\", \\\"{x:680,y:603,t:1527264740281};\\\", \\\"{x:660,y:598,t:1527264740297};\\\", \\\"{x:635,y:597,t:1527264740314};\\\", \\\"{x:620,y:597,t:1527264740331};\\\", \\\"{x:605,y:601,t:1527264740353};\\\", \\\"{x:588,y:610,t:1527264740368};\\\", \\\"{x:567,y:622,t:1527264740386};\\\", \\\"{x:544,y:637,t:1527264740402};\\\", \\\"{x:528,y:646,t:1527264740418};\\\", \\\"{x:510,y:653,t:1527264740436};\\\", \\\"{x:497,y:657,t:1527264740452};\\\", \\\"{x:479,y:659,t:1527264740468};\\\", \\\"{x:464,y:659,t:1527264740485};\\\", \\\"{x:447,y:655,t:1527264740502};\\\", \\\"{x:433,y:648,t:1527264740518};\\\", \\\"{x:425,y:643,t:1527264740535};\\\", \\\"{x:416,y:632,t:1527264740552};\\\", \\\"{x:409,y:622,t:1527264740570};\\\", \\\"{x:406,y:610,t:1527264740585};\\\", \\\"{x:405,y:595,t:1527264740603};\\\", \\\"{x:405,y:588,t:1527264740618};\\\", \\\"{x:405,y:586,t:1527264740635};\\\", \\\"{x:405,y:585,t:1527264740652};\\\", \\\"{x:405,y:584,t:1527264740699};\\\", \\\"{x:406,y:584,t:1527264740714};\\\", \\\"{x:407,y:584,t:1527264740722};\\\", \\\"{x:407,y:580,t:1527264740845};\\\", \\\"{x:405,y:577,t:1527264740852};\\\", \\\"{x:400,y:572,t:1527264740870};\\\", \\\"{x:393,y:569,t:1527264740885};\\\", \\\"{x:387,y:567,t:1527264740902};\\\", \\\"{x:375,y:567,t:1527264740919};\\\", \\\"{x:365,y:567,t:1527264740936};\\\", \\\"{x:351,y:567,t:1527264740952};\\\", \\\"{x:335,y:567,t:1527264740969};\\\", \\\"{x:317,y:567,t:1527264740985};\\\", \\\"{x:282,y:571,t:1527264741002};\\\", \\\"{x:249,y:582,t:1527264741020};\\\", \\\"{x:231,y:589,t:1527264741036};\\\", \\\"{x:223,y:597,t:1527264741052};\\\", \\\"{x:222,y:600,t:1527264741069};\\\", \\\"{x:221,y:600,t:1527264741098};\\\", \\\"{x:220,y:600,t:1527264741106};\\\", \\\"{x:215,y:600,t:1527264741120};\\\", \\\"{x:202,y:596,t:1527264741136};\\\", \\\"{x:196,y:594,t:1527264741152};\\\", \\\"{x:190,y:592,t:1527264741170};\\\", \\\"{x:181,y:589,t:1527264741185};\\\", \\\"{x:170,y:586,t:1527264741202};\\\", \\\"{x:163,y:584,t:1527264741220};\\\", \\\"{x:160,y:583,t:1527264741236};\\\", \\\"{x:158,y:582,t:1527264741252};\\\", \\\"{x:154,y:581,t:1527264741270};\\\", \\\"{x:153,y:581,t:1527264741290};\\\", \\\"{x:152,y:581,t:1527264741302};\\\", \\\"{x:151,y:581,t:1527264741319};\\\", \\\"{x:151,y:580,t:1527264741475};\\\", \\\"{x:151,y:579,t:1527264741499};\\\", \\\"{x:151,y:577,t:1527264741539};\\\", \\\"{x:151,y:576,t:1527264741554};\\\", \\\"{x:151,y:574,t:1527264741572};\\\", \\\"{x:151,y:572,t:1527264741586};\\\", \\\"{x:152,y:572,t:1527264741603};\\\", \\\"{x:152,y:570,t:1527264741690};\\\", \\\"{x:153,y:568,t:1527264741703};\\\", \\\"{x:157,y:563,t:1527264741720};\\\", \\\"{x:160,y:558,t:1527264741736};\\\", \\\"{x:163,y:553,t:1527264741754};\\\", \\\"{x:165,y:551,t:1527264741769};\\\", \\\"{x:166,y:549,t:1527264741786};\\\", \\\"{x:167,y:547,t:1527264741803};\\\", \\\"{x:168,y:548,t:1527264742218};\\\", \\\"{x:173,y:554,t:1527264742226};\\\", \\\"{x:181,y:563,t:1527264742236};\\\", \\\"{x:197,y:580,t:1527264742254};\\\", \\\"{x:215,y:595,t:1527264742271};\\\", \\\"{x:240,y:610,t:1527264742286};\\\", \\\"{x:285,y:631,t:1527264742304};\\\", \\\"{x:333,y:647,t:1527264742321};\\\", \\\"{x:377,y:657,t:1527264742337};\\\", \\\"{x:415,y:667,t:1527264742353};\\\", \\\"{x:489,y:684,t:1527264742370};\\\", \\\"{x:536,y:694,t:1527264742387};\\\", \\\"{x:554,y:697,t:1527264742403};\\\", \\\"{x:557,y:697,t:1527264742421};\\\", \\\"{x:558,y:698,t:1527264742571};\\\", \\\"{x:547,y:706,t:1527264742590};\\\", \\\"{x:526,y:722,t:1527264742604};\\\", \\\"{x:505,y:738,t:1527264742621};\\\", \\\"{x:486,y:748,t:1527264742637};\\\", \\\"{x:476,y:752,t:1527264742653};\\\", \\\"{x:473,y:753,t:1527264742671};\\\", \\\"{x:472,y:753,t:1527264742687};\\\", \\\"{x:469,y:750,t:1527264742703};\\\", \\\"{x:469,y:746,t:1527264742720};\\\", \\\"{x:469,y:741,t:1527264742738};\\\", \\\"{x:469,y:736,t:1527264742754};\\\", \\\"{x:475,y:725,t:1527264742770};\\\", \\\"{x:482,y:717,t:1527264742787};\\\", \\\"{x:488,y:709,t:1527264742803};\\\", \\\"{x:489,y:706,t:1527264742820};\\\" ] }, { \\\"rt\\\": 32885, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 362169, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"U\\\", \\\"D\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-E -E -E -E -E -E -E -02 PM-01 PM-12 PM-Z -Z -F -U -C -C -C -A -I -I -O -O -O -O -O -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:492,y:708,t:1527264745034};\\\", \\\"{x:493,y:710,t:1527264745042};\\\", \\\"{x:496,y:712,t:1527264745057};\\\", \\\"{x:503,y:719,t:1527264745073};\\\", \\\"{x:515,y:724,t:1527264745090};\\\", \\\"{x:540,y:734,t:1527264745106};\\\", \\\"{x:552,y:740,t:1527264745124};\\\", \\\"{x:567,y:745,t:1527264745139};\\\", \\\"{x:596,y:750,t:1527264745155};\\\", \\\"{x:641,y:753,t:1527264745173};\\\", \\\"{x:716,y:752,t:1527264745189};\\\", \\\"{x:774,y:741,t:1527264745206};\\\", \\\"{x:815,y:732,t:1527264745222};\\\", \\\"{x:847,y:729,t:1527264745238};\\\", \\\"{x:894,y:729,t:1527264745255};\\\", \\\"{x:958,y:729,t:1527264745273};\\\", \\\"{x:995,y:730,t:1527264745289};\\\", \\\"{x:1026,y:734,t:1527264745305};\\\", \\\"{x:1085,y:745,t:1527264745322};\\\", \\\"{x:1114,y:754,t:1527264745339};\\\", \\\"{x:1143,y:763,t:1527264745355};\\\", \\\"{x:1175,y:775,t:1527264745373};\\\", \\\"{x:1202,y:779,t:1527264745389};\\\", \\\"{x:1227,y:782,t:1527264745406};\\\", \\\"{x:1236,y:774,t:1527264745422};\\\", \\\"{x:1236,y:772,t:1527264745438};\\\", \\\"{x:1237,y:771,t:1527264745754};\\\", \\\"{x:1240,y:772,t:1527264745762};\\\", \\\"{x:1245,y:776,t:1527264745772};\\\", \\\"{x:1262,y:787,t:1527264745789};\\\", \\\"{x:1285,y:797,t:1527264745806};\\\", \\\"{x:1311,y:808,t:1527264745823};\\\", \\\"{x:1344,y:822,t:1527264745840};\\\", \\\"{x:1383,y:838,t:1527264745855};\\\", \\\"{x:1424,y:857,t:1527264745873};\\\", \\\"{x:1468,y:882,t:1527264745890};\\\", \\\"{x:1516,y:906,t:1527264745905};\\\", \\\"{x:1576,y:934,t:1527264745922};\\\", \\\"{x:1605,y:947,t:1527264745939};\\\", \\\"{x:1624,y:958,t:1527264745956};\\\", \\\"{x:1631,y:961,t:1527264745973};\\\", \\\"{x:1635,y:964,t:1527264745989};\\\", \\\"{x:1636,y:966,t:1527264746005};\\\", \\\"{x:1637,y:966,t:1527264746023};\\\", \\\"{x:1637,y:968,t:1527264746039};\\\", \\\"{x:1638,y:969,t:1527264746055};\\\", \\\"{x:1638,y:971,t:1527264746138};\\\", \\\"{x:1638,y:972,t:1527264746146};\\\", \\\"{x:1636,y:973,t:1527264746156};\\\", \\\"{x:1633,y:975,t:1527264746173};\\\", \\\"{x:1630,y:976,t:1527264746189};\\\", \\\"{x:1627,y:976,t:1527264746206};\\\", \\\"{x:1622,y:976,t:1527264746223};\\\", \\\"{x:1620,y:975,t:1527264746239};\\\", \\\"{x:1617,y:974,t:1527264746255};\\\", \\\"{x:1615,y:973,t:1527264746272};\\\", \\\"{x:1612,y:972,t:1527264746290};\\\", \\\"{x:1609,y:971,t:1527264746305};\\\", \\\"{x:1606,y:969,t:1527264746323};\\\", \\\"{x:1605,y:968,t:1527264746355};\\\", \\\"{x:1605,y:967,t:1527264746402};\\\", \\\"{x:1605,y:966,t:1527264746410};\\\", \\\"{x:1605,y:965,t:1527264746422};\\\", \\\"{x:1605,y:962,t:1527264746440};\\\", \\\"{x:1605,y:960,t:1527264746455};\\\", \\\"{x:1606,y:956,t:1527264746473};\\\", \\\"{x:1606,y:949,t:1527264746489};\\\", \\\"{x:1606,y:942,t:1527264746506};\\\", \\\"{x:1606,y:926,t:1527264746523};\\\", \\\"{x:1606,y:917,t:1527264746539};\\\", \\\"{x:1606,y:909,t:1527264746555};\\\", \\\"{x:1606,y:901,t:1527264746572};\\\", \\\"{x:1606,y:893,t:1527264746589};\\\", \\\"{x:1606,y:885,t:1527264746606};\\\", \\\"{x:1607,y:878,t:1527264746623};\\\", \\\"{x:1608,y:872,t:1527264746640};\\\", \\\"{x:1610,y:867,t:1527264746655};\\\", \\\"{x:1611,y:865,t:1527264746672};\\\", \\\"{x:1611,y:861,t:1527264746690};\\\", \\\"{x:1612,y:860,t:1527264746705};\\\", \\\"{x:1613,y:857,t:1527264746723};\\\", \\\"{x:1614,y:854,t:1527264746740};\\\", \\\"{x:1614,y:850,t:1527264746756};\\\", \\\"{x:1615,y:844,t:1527264746773};\\\", \\\"{x:1616,y:839,t:1527264746790};\\\", \\\"{x:1617,y:831,t:1527264746805};\\\", \\\"{x:1617,y:828,t:1527264746823};\\\", \\\"{x:1618,y:826,t:1527264746839};\\\", \\\"{x:1618,y:824,t:1527264746856};\\\", \\\"{x:1618,y:818,t:1527264746873};\\\", \\\"{x:1618,y:808,t:1527264746889};\\\", \\\"{x:1618,y:788,t:1527264746906};\\\", \\\"{x:1619,y:773,t:1527264746922};\\\", \\\"{x:1620,y:758,t:1527264746940};\\\", \\\"{x:1624,y:741,t:1527264746957};\\\", \\\"{x:1629,y:712,t:1527264746972};\\\", \\\"{x:1634,y:673,t:1527264746990};\\\", \\\"{x:1638,y:643,t:1527264747006};\\\", \\\"{x:1640,y:624,t:1527264747022};\\\", \\\"{x:1642,y:606,t:1527264747040};\\\", \\\"{x:1645,y:589,t:1527264747056};\\\", \\\"{x:1645,y:567,t:1527264747073};\\\", \\\"{x:1645,y:545,t:1527264747090};\\\", \\\"{x:1645,y:522,t:1527264747106};\\\", \\\"{x:1645,y:511,t:1527264747122};\\\", \\\"{x:1645,y:505,t:1527264747140};\\\", \\\"{x:1645,y:499,t:1527264747156};\\\", \\\"{x:1644,y:496,t:1527264747172};\\\", \\\"{x:1643,y:493,t:1527264747190};\\\", \\\"{x:1643,y:492,t:1527264747207};\\\", \\\"{x:1642,y:492,t:1527264747306};\\\", \\\"{x:1639,y:495,t:1527264747322};\\\", \\\"{x:1638,y:501,t:1527264747339};\\\", \\\"{x:1635,y:508,t:1527264747356};\\\", \\\"{x:1635,y:513,t:1527264747373};\\\", \\\"{x:1634,y:516,t:1527264747389};\\\", \\\"{x:1633,y:518,t:1527264747406};\\\", \\\"{x:1632,y:520,t:1527264747423};\\\", \\\"{x:1632,y:523,t:1527264747440};\\\", \\\"{x:1631,y:526,t:1527264747456};\\\", \\\"{x:1630,y:531,t:1527264747473};\\\", \\\"{x:1630,y:532,t:1527264747489};\\\", \\\"{x:1630,y:535,t:1527264747506};\\\", \\\"{x:1630,y:536,t:1527264747523};\\\", \\\"{x:1630,y:537,t:1527264747539};\\\", \\\"{x:1630,y:538,t:1527264747562};\\\", \\\"{x:1630,y:540,t:1527264747573};\\\", \\\"{x:1627,y:544,t:1527264747589};\\\", \\\"{x:1627,y:548,t:1527264747607};\\\", \\\"{x:1626,y:550,t:1527264747623};\\\", \\\"{x:1625,y:552,t:1527264747639};\\\", \\\"{x:1624,y:552,t:1527264747682};\\\", \\\"{x:1623,y:553,t:1527264747706};\\\", \\\"{x:1621,y:554,t:1527264747723};\\\", \\\"{x:1620,y:554,t:1527264747746};\\\", \\\"{x:1619,y:554,t:1527264747834};\\\", \\\"{x:1618,y:555,t:1527264747874};\\\", \\\"{x:1615,y:556,t:1527264748515};\\\", \\\"{x:1614,y:557,t:1527264748530};\\\", \\\"{x:1612,y:558,t:1527264748542};\\\", \\\"{x:1610,y:558,t:1527264748557};\\\", \\\"{x:1609,y:558,t:1527264748574};\\\", \\\"{x:1608,y:559,t:1527264748590};\\\", \\\"{x:1609,y:559,t:1527264749195};\\\", \\\"{x:1610,y:560,t:1527264749207};\\\", \\\"{x:1612,y:560,t:1527264749224};\\\", \\\"{x:1614,y:560,t:1527264749241};\\\", \\\"{x:1615,y:561,t:1527264749274};\\\", \\\"{x:1614,y:561,t:1527264749610};\\\", \\\"{x:1612,y:562,t:1527264749623};\\\", \\\"{x:1609,y:564,t:1527264749641};\\\", \\\"{x:1608,y:564,t:1527264749657};\\\", \\\"{x:1609,y:564,t:1527264750259};\\\", \\\"{x:1611,y:564,t:1527264750274};\\\", \\\"{x:1612,y:564,t:1527264750298};\\\", \\\"{x:1611,y:564,t:1527264750458};\\\", \\\"{x:1610,y:564,t:1527264750474};\\\", \\\"{x:1609,y:564,t:1527264750491};\\\", \\\"{x:1610,y:564,t:1527264751418};\\\", \\\"{x:1611,y:564,t:1527264751434};\\\", \\\"{x:1612,y:564,t:1527264751466};\\\", \\\"{x:1613,y:564,t:1527264751490};\\\", \\\"{x:1614,y:564,t:1527264751498};\\\", \\\"{x:1614,y:562,t:1527264752330};\\\", \\\"{x:1614,y:557,t:1527264752342};\\\", \\\"{x:1614,y:546,t:1527264752358};\\\", \\\"{x:1615,y:532,t:1527264752375};\\\", \\\"{x:1618,y:523,t:1527264752392};\\\", \\\"{x:1618,y:516,t:1527264752408};\\\", \\\"{x:1618,y:509,t:1527264752425};\\\", \\\"{x:1618,y:498,t:1527264752442};\\\", \\\"{x:1617,y:489,t:1527264752458};\\\", \\\"{x:1615,y:479,t:1527264752475};\\\", \\\"{x:1615,y:470,t:1527264752492};\\\", \\\"{x:1615,y:464,t:1527264752508};\\\", \\\"{x:1615,y:460,t:1527264752525};\\\", \\\"{x:1615,y:458,t:1527264752542};\\\", \\\"{x:1615,y:456,t:1527264752558};\\\", \\\"{x:1615,y:455,t:1527264752575};\\\", \\\"{x:1615,y:454,t:1527264752592};\\\", \\\"{x:1614,y:453,t:1527264752608};\\\", \\\"{x:1613,y:449,t:1527264752625};\\\", \\\"{x:1612,y:443,t:1527264752642};\\\", \\\"{x:1611,y:442,t:1527264752658};\\\", \\\"{x:1611,y:440,t:1527264752675};\\\", \\\"{x:1611,y:441,t:1527264752858};\\\", \\\"{x:1611,y:452,t:1527264752875};\\\", \\\"{x:1611,y:464,t:1527264752892};\\\", \\\"{x:1611,y:484,t:1527264752908};\\\", \\\"{x:1611,y:501,t:1527264752925};\\\", \\\"{x:1611,y:507,t:1527264752942};\\\", \\\"{x:1611,y:509,t:1527264752959};\\\", \\\"{x:1611,y:510,t:1527264752975};\\\", \\\"{x:1611,y:511,t:1527264753011};\\\", \\\"{x:1611,y:513,t:1527264753025};\\\", \\\"{x:1611,y:521,t:1527264753043};\\\", \\\"{x:1611,y:528,t:1527264753059};\\\", \\\"{x:1609,y:535,t:1527264753075};\\\", \\\"{x:1608,y:540,t:1527264753092};\\\", \\\"{x:1608,y:542,t:1527264753109};\\\", \\\"{x:1608,y:544,t:1527264753124};\\\", \\\"{x:1608,y:545,t:1527264753146};\\\", \\\"{x:1608,y:546,t:1527264753171};\\\", \\\"{x:1608,y:547,t:1527264753186};\\\", \\\"{x:1608,y:548,t:1527264753203};\\\", \\\"{x:1608,y:549,t:1527264753211};\\\", \\\"{x:1608,y:550,t:1527264753225};\\\", \\\"{x:1608,y:551,t:1527264753242};\\\", \\\"{x:1608,y:553,t:1527264753259};\\\", \\\"{x:1608,y:554,t:1527264753298};\\\", \\\"{x:1608,y:555,t:1527264753314};\\\", \\\"{x:1608,y:556,t:1527264753325};\\\", \\\"{x:1610,y:557,t:1527264753343};\\\", \\\"{x:1610,y:559,t:1527264753359};\\\", \\\"{x:1610,y:560,t:1527264753411};\\\", \\\"{x:1610,y:562,t:1527264753443};\\\", \\\"{x:1610,y:566,t:1527264753459};\\\", \\\"{x:1610,y:574,t:1527264753476};\\\", \\\"{x:1610,y:592,t:1527264753493};\\\", \\\"{x:1607,y:619,t:1527264753509};\\\", \\\"{x:1603,y:646,t:1527264753526};\\\", \\\"{x:1599,y:671,t:1527264753543};\\\", \\\"{x:1597,y:688,t:1527264753560};\\\", \\\"{x:1596,y:700,t:1527264753576};\\\", \\\"{x:1596,y:719,t:1527264753593};\\\", \\\"{x:1596,y:744,t:1527264753610};\\\", \\\"{x:1596,y:767,t:1527264753626};\\\", \\\"{x:1593,y:805,t:1527264753643};\\\", \\\"{x:1591,y:826,t:1527264753659};\\\", \\\"{x:1587,y:844,t:1527264753676};\\\", \\\"{x:1585,y:861,t:1527264753693};\\\", \\\"{x:1585,y:875,t:1527264753710};\\\", \\\"{x:1585,y:884,t:1527264753726};\\\", \\\"{x:1585,y:890,t:1527264753742};\\\", \\\"{x:1584,y:895,t:1527264753760};\\\", \\\"{x:1582,y:899,t:1527264753775};\\\", \\\"{x:1582,y:905,t:1527264753793};\\\", \\\"{x:1582,y:910,t:1527264753809};\\\", \\\"{x:1582,y:917,t:1527264753825};\\\", \\\"{x:1582,y:925,t:1527264753843};\\\", \\\"{x:1582,y:928,t:1527264753859};\\\", \\\"{x:1582,y:934,t:1527264753877};\\\", \\\"{x:1582,y:936,t:1527264753892};\\\", \\\"{x:1582,y:939,t:1527264753910};\\\", \\\"{x:1583,y:942,t:1527264753927};\\\", \\\"{x:1587,y:946,t:1527264753943};\\\", \\\"{x:1590,y:948,t:1527264753960};\\\", \\\"{x:1593,y:950,t:1527264753977};\\\", \\\"{x:1594,y:951,t:1527264753992};\\\", \\\"{x:1599,y:954,t:1527264754009};\\\", \\\"{x:1602,y:958,t:1527264754027};\\\", \\\"{x:1602,y:959,t:1527264754043};\\\", \\\"{x:1602,y:960,t:1527264754059};\\\", \\\"{x:1603,y:961,t:1527264754076};\\\", \\\"{x:1605,y:962,t:1527264754098};\\\", \\\"{x:1608,y:964,t:1527264754109};\\\", \\\"{x:1612,y:966,t:1527264754126};\\\", \\\"{x:1614,y:966,t:1527264754142};\\\", \\\"{x:1615,y:966,t:1527264754158};\\\", \\\"{x:1615,y:967,t:1527264754540};\\\", \\\"{x:1615,y:968,t:1527264754563};\\\", \\\"{x:1613,y:968,t:1527264754595};\\\", \\\"{x:1612,y:968,t:1527264754610};\\\", \\\"{x:1609,y:968,t:1527264754626};\\\", \\\"{x:1604,y:967,t:1527264754643};\\\", \\\"{x:1599,y:966,t:1527264754660};\\\", \\\"{x:1592,y:964,t:1527264754677};\\\", \\\"{x:1585,y:964,t:1527264754692};\\\", \\\"{x:1571,y:962,t:1527264754710};\\\", \\\"{x:1557,y:962,t:1527264754727};\\\", \\\"{x:1545,y:962,t:1527264754743};\\\", \\\"{x:1530,y:962,t:1527264754760};\\\", \\\"{x:1514,y:963,t:1527264754776};\\\", \\\"{x:1503,y:964,t:1527264754793};\\\", \\\"{x:1491,y:966,t:1527264754810};\\\", \\\"{x:1471,y:970,t:1527264754827};\\\", \\\"{x:1452,y:970,t:1527264754843};\\\", \\\"{x:1431,y:970,t:1527264754860};\\\", \\\"{x:1414,y:970,t:1527264754876};\\\", \\\"{x:1398,y:970,t:1527264754893};\\\", \\\"{x:1385,y:970,t:1527264754909};\\\", \\\"{x:1376,y:970,t:1527264754926};\\\", \\\"{x:1370,y:970,t:1527264754943};\\\", \\\"{x:1365,y:970,t:1527264754960};\\\", \\\"{x:1360,y:970,t:1527264754976};\\\", \\\"{x:1353,y:970,t:1527264754994};\\\", \\\"{x:1348,y:969,t:1527264755010};\\\", \\\"{x:1341,y:969,t:1527264755026};\\\", \\\"{x:1337,y:969,t:1527264755042};\\\", \\\"{x:1334,y:969,t:1527264755059};\\\", \\\"{x:1334,y:967,t:1527264755252};\\\", \\\"{x:1334,y:965,t:1527264755259};\\\", \\\"{x:1335,y:963,t:1527264755276};\\\", \\\"{x:1335,y:960,t:1527264755293};\\\", \\\"{x:1337,y:958,t:1527264755309};\\\", \\\"{x:1337,y:954,t:1527264755326};\\\", \\\"{x:1337,y:952,t:1527264755343};\\\", \\\"{x:1337,y:950,t:1527264755359};\\\", \\\"{x:1337,y:948,t:1527264755376};\\\", \\\"{x:1337,y:945,t:1527264755393};\\\", \\\"{x:1337,y:942,t:1527264755409};\\\", \\\"{x:1337,y:938,t:1527264755426};\\\", \\\"{x:1337,y:935,t:1527264755443};\\\", \\\"{x:1337,y:933,t:1527264755459};\\\", \\\"{x:1337,y:930,t:1527264755476};\\\", \\\"{x:1337,y:928,t:1527264755493};\\\", \\\"{x:1337,y:926,t:1527264755509};\\\", \\\"{x:1337,y:922,t:1527264755526};\\\", \\\"{x:1337,y:918,t:1527264755543};\\\", \\\"{x:1337,y:915,t:1527264755560};\\\", \\\"{x:1338,y:912,t:1527264755576};\\\", \\\"{x:1338,y:910,t:1527264755593};\\\", \\\"{x:1339,y:909,t:1527264755610};\\\", \\\"{x:1340,y:907,t:1527264755627};\\\", \\\"{x:1340,y:906,t:1527264755675};\\\", \\\"{x:1341,y:906,t:1527264755683};\\\", \\\"{x:1341,y:905,t:1527264755693};\\\", \\\"{x:1341,y:904,t:1527264755710};\\\", \\\"{x:1342,y:903,t:1527264755726};\\\", \\\"{x:1343,y:902,t:1527264755743};\\\", \\\"{x:1343,y:901,t:1527264755760};\\\", \\\"{x:1344,y:900,t:1527264755776};\\\", \\\"{x:1344,y:899,t:1527264755818};\\\", \\\"{x:1344,y:898,t:1527264755834};\\\", \\\"{x:1344,y:897,t:1527264755843};\\\", \\\"{x:1344,y:894,t:1527264756011};\\\", \\\"{x:1344,y:887,t:1527264756026};\\\", \\\"{x:1344,y:878,t:1527264756043};\\\", \\\"{x:1344,y:872,t:1527264756061};\\\", \\\"{x:1344,y:866,t:1527264756077};\\\", \\\"{x:1344,y:861,t:1527264756094};\\\", \\\"{x:1344,y:857,t:1527264756110};\\\", \\\"{x:1344,y:853,t:1527264756127};\\\", \\\"{x:1343,y:847,t:1527264756144};\\\", \\\"{x:1342,y:843,t:1527264756161};\\\", \\\"{x:1340,y:839,t:1527264756177};\\\", \\\"{x:1340,y:836,t:1527264756194};\\\", \\\"{x:1340,y:833,t:1527264756210};\\\", \\\"{x:1340,y:832,t:1527264756226};\\\", \\\"{x:1340,y:829,t:1527264756244};\\\", \\\"{x:1340,y:827,t:1527264756261};\\\", \\\"{x:1340,y:823,t:1527264756277};\\\", \\\"{x:1342,y:820,t:1527264756294};\\\", \\\"{x:1345,y:815,t:1527264756310};\\\", \\\"{x:1346,y:813,t:1527264756326};\\\", \\\"{x:1348,y:810,t:1527264756344};\\\", \\\"{x:1350,y:808,t:1527264756360};\\\", \\\"{x:1351,y:806,t:1527264756376};\\\", \\\"{x:1353,y:804,t:1527264756393};\\\", \\\"{x:1357,y:801,t:1527264756411};\\\", \\\"{x:1359,y:799,t:1527264756426};\\\", \\\"{x:1360,y:798,t:1527264756444};\\\", \\\"{x:1361,y:798,t:1527264756461};\\\", \\\"{x:1363,y:795,t:1527264756477};\\\", \\\"{x:1364,y:794,t:1527264756494};\\\", \\\"{x:1365,y:793,t:1527264756511};\\\", \\\"{x:1366,y:792,t:1527264756527};\\\", \\\"{x:1367,y:791,t:1527264756544};\\\", \\\"{x:1369,y:790,t:1527264756561};\\\", \\\"{x:1371,y:788,t:1527264756576};\\\", \\\"{x:1373,y:785,t:1527264756594};\\\", \\\"{x:1376,y:782,t:1527264756610};\\\", \\\"{x:1377,y:780,t:1527264756626};\\\", \\\"{x:1378,y:779,t:1527264756643};\\\", \\\"{x:1379,y:777,t:1527264756660};\\\", \\\"{x:1380,y:775,t:1527264756682};\\\", \\\"{x:1380,y:774,t:1527264756698};\\\", \\\"{x:1380,y:773,t:1527264756714};\\\", \\\"{x:1381,y:772,t:1527264756726};\\\", \\\"{x:1381,y:771,t:1527264756754};\\\", \\\"{x:1381,y:770,t:1527264756770};\\\", \\\"{x:1382,y:770,t:1527264756778};\\\", \\\"{x:1382,y:769,t:1527264756793};\\\", \\\"{x:1382,y:768,t:1527264756810};\\\", \\\"{x:1382,y:767,t:1527264756826};\\\", \\\"{x:1383,y:766,t:1527264756843};\\\", \\\"{x:1383,y:765,t:1527264756860};\\\", \\\"{x:1383,y:764,t:1527264756876};\\\", \\\"{x:1383,y:763,t:1527264756906};\\\", \\\"{x:1383,y:762,t:1527264756922};\\\", \\\"{x:1383,y:761,t:1527264756930};\\\", \\\"{x:1383,y:760,t:1527264756971};\\\", \\\"{x:1383,y:759,t:1527264756986};\\\", \\\"{x:1386,y:758,t:1527264757356};\\\", \\\"{x:1390,y:758,t:1527264757363};\\\", \\\"{x:1394,y:759,t:1527264757378};\\\", \\\"{x:1401,y:762,t:1527264757394};\\\", \\\"{x:1420,y:769,t:1527264757411};\\\", \\\"{x:1428,y:773,t:1527264757427};\\\", \\\"{x:1432,y:774,t:1527264757444};\\\", \\\"{x:1433,y:775,t:1527264757461};\\\", \\\"{x:1435,y:776,t:1527264757491};\\\", \\\"{x:1435,y:777,t:1527264757499};\\\", \\\"{x:1437,y:780,t:1527264757511};\\\", \\\"{x:1441,y:784,t:1527264757528};\\\", \\\"{x:1443,y:789,t:1527264757543};\\\", \\\"{x:1445,y:795,t:1527264757561};\\\", \\\"{x:1446,y:797,t:1527264757578};\\\", \\\"{x:1446,y:798,t:1527264757594};\\\", \\\"{x:1446,y:800,t:1527264757611};\\\", \\\"{x:1446,y:801,t:1527264757627};\\\", \\\"{x:1446,y:803,t:1527264757644};\\\", \\\"{x:1443,y:806,t:1527264757660};\\\", \\\"{x:1437,y:809,t:1527264757677};\\\", \\\"{x:1432,y:811,t:1527264757693};\\\", \\\"{x:1428,y:812,t:1527264757711};\\\", \\\"{x:1425,y:813,t:1527264757727};\\\", \\\"{x:1424,y:813,t:1527264757743};\\\", \\\"{x:1423,y:814,t:1527264757761};\\\", \\\"{x:1422,y:814,t:1527264757875};\\\", \\\"{x:1421,y:814,t:1527264757883};\\\", \\\"{x:1419,y:812,t:1527264757893};\\\", \\\"{x:1418,y:801,t:1527264757911};\\\", \\\"{x:1413,y:784,t:1527264757928};\\\", \\\"{x:1403,y:762,t:1527264757945};\\\", \\\"{x:1394,y:748,t:1527264757961};\\\", \\\"{x:1388,y:733,t:1527264757978};\\\", \\\"{x:1384,y:721,t:1527264757993};\\\", \\\"{x:1382,y:703,t:1527264758010};\\\", \\\"{x:1381,y:688,t:1527264758027};\\\", \\\"{x:1381,y:672,t:1527264758044};\\\", \\\"{x:1381,y:663,t:1527264758060};\\\", \\\"{x:1383,y:655,t:1527264758078};\\\", \\\"{x:1384,y:650,t:1527264758095};\\\", \\\"{x:1387,y:645,t:1527264758110};\\\", \\\"{x:1387,y:643,t:1527264758128};\\\", \\\"{x:1388,y:642,t:1527264758145};\\\", \\\"{x:1388,y:641,t:1527264758161};\\\", \\\"{x:1389,y:641,t:1527264758178};\\\", \\\"{x:1389,y:640,t:1527264758203};\\\", \\\"{x:1390,y:640,t:1527264758211};\\\", \\\"{x:1393,y:640,t:1527264758228};\\\", \\\"{x:1399,y:645,t:1527264758244};\\\", \\\"{x:1407,y:658,t:1527264758261};\\\", \\\"{x:1413,y:682,t:1527264758277};\\\", \\\"{x:1417,y:710,t:1527264758295};\\\", \\\"{x:1420,y:736,t:1527264758310};\\\", \\\"{x:1424,y:758,t:1527264758327};\\\", \\\"{x:1426,y:775,t:1527264758344};\\\", \\\"{x:1429,y:788,t:1527264758361};\\\", \\\"{x:1432,y:797,t:1527264758377};\\\", \\\"{x:1443,y:808,t:1527264758394};\\\", \\\"{x:1453,y:816,t:1527264758410};\\\", \\\"{x:1462,y:821,t:1527264758427};\\\", \\\"{x:1469,y:826,t:1527264758445};\\\", \\\"{x:1476,y:829,t:1527264758460};\\\", \\\"{x:1477,y:830,t:1527264758477};\\\", \\\"{x:1478,y:830,t:1527264758494};\\\", \\\"{x:1479,y:830,t:1527264758555};\\\", \\\"{x:1481,y:830,t:1527264758795};\\\", \\\"{x:1483,y:832,t:1527264758811};\\\", \\\"{x:1485,y:832,t:1527264758851};\\\", \\\"{x:1486,y:832,t:1527264758867};\\\", \\\"{x:1485,y:832,t:1527264759947};\\\", \\\"{x:1483,y:832,t:1527264759961};\\\", \\\"{x:1479,y:832,t:1527264759979};\\\", \\\"{x:1476,y:832,t:1527264759995};\\\", \\\"{x:1472,y:831,t:1527264760013};\\\", \\\"{x:1469,y:831,t:1527264760029};\\\", \\\"{x:1468,y:829,t:1527264760044};\\\", \\\"{x:1467,y:829,t:1527264760516};\\\", \\\"{x:1466,y:829,t:1527264760529};\\\", \\\"{x:1462,y:829,t:1527264760545};\\\", \\\"{x:1458,y:829,t:1527264760562};\\\", \\\"{x:1449,y:829,t:1527264760578};\\\", \\\"{x:1444,y:829,t:1527264760594};\\\", \\\"{x:1442,y:829,t:1527264760612};\\\", \\\"{x:1440,y:829,t:1527264760629};\\\", \\\"{x:1439,y:829,t:1527264760645};\\\", \\\"{x:1438,y:829,t:1527264760662};\\\", \\\"{x:1437,y:829,t:1527264760707};\\\", \\\"{x:1438,y:829,t:1527264760899};\\\", \\\"{x:1431,y:829,t:1527264761027};\\\", \\\"{x:1422,y:829,t:1527264761035};\\\", \\\"{x:1411,y:829,t:1527264761046};\\\", \\\"{x:1384,y:829,t:1527264761062};\\\", \\\"{x:1348,y:829,t:1527264761079};\\\", \\\"{x:1306,y:829,t:1527264761095};\\\", \\\"{x:1267,y:829,t:1527264761111};\\\", \\\"{x:1235,y:829,t:1527264761129};\\\", \\\"{x:1209,y:829,t:1527264761146};\\\", \\\"{x:1192,y:827,t:1527264761161};\\\", \\\"{x:1185,y:825,t:1527264761178};\\\", \\\"{x:1184,y:825,t:1527264761259};\\\", \\\"{x:1184,y:826,t:1527264761274};\\\", \\\"{x:1184,y:827,t:1527264761282};\\\", \\\"{x:1186,y:830,t:1527264761296};\\\", \\\"{x:1188,y:836,t:1527264761312};\\\", \\\"{x:1190,y:842,t:1527264761329};\\\", \\\"{x:1192,y:845,t:1527264761345};\\\", \\\"{x:1194,y:847,t:1527264761362};\\\", \\\"{x:1198,y:850,t:1527264761378};\\\", \\\"{x:1203,y:851,t:1527264761396};\\\", \\\"{x:1206,y:854,t:1527264761412};\\\", \\\"{x:1211,y:855,t:1527264761428};\\\", \\\"{x:1213,y:855,t:1527264761445};\\\", \\\"{x:1215,y:855,t:1527264761462};\\\", \\\"{x:1217,y:855,t:1527264761478};\\\", \\\"{x:1218,y:855,t:1527264761627};\\\", \\\"{x:1218,y:853,t:1527264761635};\\\", \\\"{x:1218,y:850,t:1527264761646};\\\", \\\"{x:1218,y:847,t:1527264761662};\\\", \\\"{x:1218,y:845,t:1527264761679};\\\", \\\"{x:1218,y:843,t:1527264761932};\\\", \\\"{x:1217,y:835,t:1527264761947};\\\", \\\"{x:1217,y:817,t:1527264761962};\\\", \\\"{x:1217,y:795,t:1527264761979};\\\", \\\"{x:1217,y:787,t:1527264761996};\\\", \\\"{x:1218,y:781,t:1527264762013};\\\", \\\"{x:1221,y:774,t:1527264762029};\\\", \\\"{x:1221,y:771,t:1527264762046};\\\", \\\"{x:1221,y:770,t:1527264762063};\\\", \\\"{x:1221,y:769,t:1527264762090};\\\", \\\"{x:1223,y:769,t:1527264762097};\\\", \\\"{x:1224,y:769,t:1527264762122};\\\", \\\"{x:1226,y:769,t:1527264762130};\\\", \\\"{x:1227,y:769,t:1527264762146};\\\", \\\"{x:1235,y:773,t:1527264762162};\\\", \\\"{x:1239,y:776,t:1527264762178};\\\", \\\"{x:1243,y:781,t:1527264762195};\\\", \\\"{x:1247,y:785,t:1527264762213};\\\", \\\"{x:1250,y:786,t:1527264762228};\\\", \\\"{x:1252,y:787,t:1527264762245};\\\", \\\"{x:1258,y:789,t:1527264762263};\\\", \\\"{x:1260,y:789,t:1527264762279};\\\", \\\"{x:1261,y:789,t:1527264762296};\\\", \\\"{x:1262,y:789,t:1527264762315};\\\", \\\"{x:1263,y:789,t:1527264762330};\\\", \\\"{x:1264,y:789,t:1527264762346};\\\", \\\"{x:1266,y:786,t:1527264762362};\\\", \\\"{x:1267,y:785,t:1527264762378};\\\", \\\"{x:1270,y:783,t:1527264762396};\\\", \\\"{x:1271,y:781,t:1527264762413};\\\", \\\"{x:1272,y:780,t:1527264762428};\\\", \\\"{x:1273,y:780,t:1527264762450};\\\", \\\"{x:1274,y:780,t:1527264762498};\\\", \\\"{x:1275,y:781,t:1527264762763};\\\", \\\"{x:1276,y:786,t:1527264762779};\\\", \\\"{x:1277,y:793,t:1527264762796};\\\", \\\"{x:1277,y:804,t:1527264762813};\\\", \\\"{x:1277,y:818,t:1527264762829};\\\", \\\"{x:1278,y:836,t:1527264762846};\\\", \\\"{x:1287,y:857,t:1527264762864};\\\", \\\"{x:1294,y:880,t:1527264762879};\\\", \\\"{x:1304,y:898,t:1527264762895};\\\", \\\"{x:1313,y:910,t:1527264762913};\\\", \\\"{x:1330,y:923,t:1527264762929};\\\", \\\"{x:1345,y:932,t:1527264762945};\\\", \\\"{x:1365,y:942,t:1527264762962};\\\", \\\"{x:1371,y:946,t:1527264762979};\\\", \\\"{x:1374,y:949,t:1527264762995};\\\", \\\"{x:1375,y:950,t:1527264763013};\\\", \\\"{x:1375,y:951,t:1527264763029};\\\", \\\"{x:1375,y:953,t:1527264763122};\\\", \\\"{x:1373,y:954,t:1527264763138};\\\", \\\"{x:1370,y:955,t:1527264763154};\\\", \\\"{x:1368,y:955,t:1527264763162};\\\", \\\"{x:1361,y:955,t:1527264763179};\\\", \\\"{x:1355,y:955,t:1527264763196};\\\", \\\"{x:1351,y:955,t:1527264763212};\\\", \\\"{x:1342,y:948,t:1527264763229};\\\", \\\"{x:1331,y:930,t:1527264763246};\\\", \\\"{x:1319,y:907,t:1527264763263};\\\", \\\"{x:1307,y:880,t:1527264763280};\\\", \\\"{x:1302,y:853,t:1527264763296};\\\", \\\"{x:1301,y:836,t:1527264763313};\\\", \\\"{x:1308,y:819,t:1527264763330};\\\", \\\"{x:1316,y:803,t:1527264763346};\\\", \\\"{x:1323,y:792,t:1527264763363};\\\", \\\"{x:1323,y:790,t:1527264763387};\\\", \\\"{x:1324,y:791,t:1527264763452};\\\", \\\"{x:1326,y:795,t:1527264763463};\\\", \\\"{x:1327,y:806,t:1527264763480};\\\", \\\"{x:1330,y:817,t:1527264763496};\\\", \\\"{x:1331,y:833,t:1527264763513};\\\", \\\"{x:1331,y:849,t:1527264763530};\\\", \\\"{x:1325,y:871,t:1527264763546};\\\", \\\"{x:1321,y:884,t:1527264763562};\\\", \\\"{x:1315,y:898,t:1527264763580};\\\", \\\"{x:1309,y:908,t:1527264763596};\\\", \\\"{x:1304,y:916,t:1527264763613};\\\", \\\"{x:1301,y:920,t:1527264763630};\\\", \\\"{x:1301,y:923,t:1527264763646};\\\", \\\"{x:1301,y:924,t:1527264763663};\\\", \\\"{x:1301,y:925,t:1527264763681};\\\", \\\"{x:1301,y:928,t:1527264763696};\\\", \\\"{x:1301,y:930,t:1527264763712};\\\", \\\"{x:1301,y:934,t:1527264763730};\\\", \\\"{x:1301,y:938,t:1527264763746};\\\", \\\"{x:1301,y:942,t:1527264763763};\\\", \\\"{x:1301,y:944,t:1527264763780};\\\", \\\"{x:1302,y:944,t:1527264763811};\\\", \\\"{x:1304,y:944,t:1527264763875};\\\", \\\"{x:1305,y:943,t:1527264763882};\\\", \\\"{x:1307,y:940,t:1527264763897};\\\", \\\"{x:1311,y:925,t:1527264763913};\\\", \\\"{x:1316,y:906,t:1527264763930};\\\", \\\"{x:1321,y:867,t:1527264763946};\\\", \\\"{x:1321,y:844,t:1527264763963};\\\", \\\"{x:1321,y:814,t:1527264763979};\\\", \\\"{x:1314,y:775,t:1527264763996};\\\", \\\"{x:1302,y:731,t:1527264764013};\\\", \\\"{x:1295,y:700,t:1527264764030};\\\", \\\"{x:1293,y:679,t:1527264764046};\\\", \\\"{x:1293,y:658,t:1527264764063};\\\", \\\"{x:1294,y:636,t:1527264764080};\\\", \\\"{x:1298,y:614,t:1527264764097};\\\", \\\"{x:1300,y:594,t:1527264764113};\\\", \\\"{x:1300,y:577,t:1527264764130};\\\", \\\"{x:1300,y:565,t:1527264764146};\\\", \\\"{x:1300,y:547,t:1527264764163};\\\", \\\"{x:1300,y:538,t:1527264764180};\\\", \\\"{x:1301,y:524,t:1527264764197};\\\", \\\"{x:1310,y:506,t:1527264764213};\\\", \\\"{x:1320,y:485,t:1527264764230};\\\", \\\"{x:1328,y:469,t:1527264764247};\\\", \\\"{x:1334,y:458,t:1527264764263};\\\", \\\"{x:1337,y:453,t:1527264764280};\\\", \\\"{x:1339,y:450,t:1527264764297};\\\", \\\"{x:1338,y:451,t:1527264764403};\\\", \\\"{x:1336,y:455,t:1527264764413};\\\", \\\"{x:1334,y:459,t:1527264764430};\\\", \\\"{x:1327,y:469,t:1527264764447};\\\", \\\"{x:1321,y:475,t:1527264764464};\\\", \\\"{x:1316,y:481,t:1527264764480};\\\", \\\"{x:1311,y:485,t:1527264764497};\\\", \\\"{x:1309,y:488,t:1527264764513};\\\", \\\"{x:1308,y:490,t:1527264764530};\\\", \\\"{x:1308,y:491,t:1527264764900};\\\", \\\"{x:1309,y:491,t:1527264764922};\\\", \\\"{x:1310,y:492,t:1527264764931};\\\", \\\"{x:1312,y:494,t:1527264764947};\\\", \\\"{x:1313,y:496,t:1527264764964};\\\", \\\"{x:1316,y:502,t:1527264764980};\\\", \\\"{x:1319,y:511,t:1527264764997};\\\", \\\"{x:1322,y:523,t:1527264765014};\\\", \\\"{x:1322,y:534,t:1527264765030};\\\", \\\"{x:1322,y:544,t:1527264765048};\\\", \\\"{x:1322,y:552,t:1527264765064};\\\", \\\"{x:1322,y:559,t:1527264765080};\\\", \\\"{x:1322,y:566,t:1527264765097};\\\", \\\"{x:1320,y:577,t:1527264765114};\\\", \\\"{x:1316,y:587,t:1527264765130};\\\", \\\"{x:1315,y:605,t:1527264765146};\\\", \\\"{x:1313,y:617,t:1527264765164};\\\", \\\"{x:1312,y:623,t:1527264765180};\\\", \\\"{x:1312,y:627,t:1527264765198};\\\", \\\"{x:1312,y:628,t:1527264765235};\\\", \\\"{x:1312,y:629,t:1527264765251};\\\", \\\"{x:1312,y:630,t:1527264765266};\\\", \\\"{x:1312,y:633,t:1527264765281};\\\", \\\"{x:1312,y:635,t:1527264765298};\\\", \\\"{x:1312,y:636,t:1527264765314};\\\", \\\"{x:1312,y:637,t:1527264765329};\\\", \\\"{x:1313,y:635,t:1527264765619};\\\", \\\"{x:1315,y:631,t:1527264765630};\\\", \\\"{x:1317,y:628,t:1527264765647};\\\", \\\"{x:1319,y:624,t:1527264765665};\\\", \\\"{x:1319,y:623,t:1527264765891};\\\", \\\"{x:1317,y:623,t:1527264765907};\\\", \\\"{x:1316,y:623,t:1527264765930};\\\", \\\"{x:1315,y:623,t:1527264766075};\\\", \\\"{x:1315,y:624,t:1527264766210};\\\", \\\"{x:1315,y:625,t:1527264766218};\\\", \\\"{x:1315,y:628,t:1527264766230};\\\", \\\"{x:1315,y:630,t:1527264766246};\\\", \\\"{x:1315,y:632,t:1527264766263};\\\", \\\"{x:1315,y:634,t:1527264766280};\\\", \\\"{x:1315,y:635,t:1527264766296};\\\", \\\"{x:1315,y:636,t:1527264766314};\\\", \\\"{x:1314,y:638,t:1527264766330};\\\", \\\"{x:1314,y:639,t:1527264766347};\\\", \\\"{x:1313,y:640,t:1527264766364};\\\", \\\"{x:1312,y:643,t:1527264766381};\\\", \\\"{x:1310,y:646,t:1527264766396};\\\", \\\"{x:1308,y:647,t:1527264766414};\\\", \\\"{x:1306,y:651,t:1527264766431};\\\", \\\"{x:1305,y:655,t:1527264766447};\\\", \\\"{x:1301,y:661,t:1527264766464};\\\", \\\"{x:1296,y:670,t:1527264766481};\\\", \\\"{x:1293,y:678,t:1527264766497};\\\", \\\"{x:1290,y:690,t:1527264766514};\\\", \\\"{x:1285,y:712,t:1527264766530};\\\", \\\"{x:1284,y:729,t:1527264766547};\\\", \\\"{x:1284,y:746,t:1527264766564};\\\", \\\"{x:1284,y:761,t:1527264766581};\\\", \\\"{x:1284,y:776,t:1527264766597};\\\", \\\"{x:1284,y:791,t:1527264766614};\\\", \\\"{x:1284,y:805,t:1527264766631};\\\", \\\"{x:1284,y:809,t:1527264766647};\\\", \\\"{x:1284,y:810,t:1527264766675};\\\", \\\"{x:1284,y:811,t:1527264766843};\\\", \\\"{x:1283,y:813,t:1527264766850};\\\", \\\"{x:1283,y:814,t:1527264766864};\\\", \\\"{x:1283,y:817,t:1527264766881};\\\", \\\"{x:1283,y:822,t:1527264766897};\\\", \\\"{x:1283,y:823,t:1527264766913};\\\", \\\"{x:1283,y:826,t:1527264766931};\\\", \\\"{x:1283,y:827,t:1527264766948};\\\", \\\"{x:1283,y:829,t:1527264766986};\\\", \\\"{x:1283,y:831,t:1527264767010};\\\", \\\"{x:1283,y:832,t:1527264767026};\\\", \\\"{x:1282,y:832,t:1527264767042};\\\", \\\"{x:1281,y:834,t:1527264767058};\\\", \\\"{x:1281,y:835,t:1527264767074};\\\", \\\"{x:1281,y:836,t:1527264767082};\\\", \\\"{x:1281,y:837,t:1527264767098};\\\", \\\"{x:1281,y:839,t:1527264767114};\\\", \\\"{x:1281,y:843,t:1527264767131};\\\", \\\"{x:1281,y:846,t:1527264767148};\\\", \\\"{x:1281,y:850,t:1527264767164};\\\", \\\"{x:1281,y:854,t:1527264767181};\\\", \\\"{x:1282,y:860,t:1527264767198};\\\", \\\"{x:1282,y:865,t:1527264767214};\\\", \\\"{x:1282,y:868,t:1527264767231};\\\", \\\"{x:1282,y:873,t:1527264767248};\\\", \\\"{x:1282,y:876,t:1527264767264};\\\", \\\"{x:1282,y:881,t:1527264767281};\\\", \\\"{x:1282,y:885,t:1527264767298};\\\", \\\"{x:1282,y:889,t:1527264767314};\\\", \\\"{x:1282,y:897,t:1527264767330};\\\", \\\"{x:1282,y:902,t:1527264767348};\\\", \\\"{x:1281,y:908,t:1527264767364};\\\", \\\"{x:1280,y:912,t:1527264767381};\\\", \\\"{x:1279,y:917,t:1527264767399};\\\", \\\"{x:1277,y:921,t:1527264767414};\\\", \\\"{x:1276,y:924,t:1527264767431};\\\", \\\"{x:1276,y:927,t:1527264767449};\\\", \\\"{x:1276,y:931,t:1527264767464};\\\", \\\"{x:1277,y:935,t:1527264767482};\\\", \\\"{x:1277,y:941,t:1527264767498};\\\", \\\"{x:1277,y:944,t:1527264767514};\\\", \\\"{x:1278,y:949,t:1527264767530};\\\", \\\"{x:1278,y:952,t:1527264767548};\\\", \\\"{x:1278,y:953,t:1527264767571};\\\", \\\"{x:1278,y:954,t:1527264767595};\\\", \\\"{x:1278,y:952,t:1527264767699};\\\", \\\"{x:1278,y:945,t:1527264767714};\\\", \\\"{x:1282,y:920,t:1527264767731};\\\", \\\"{x:1286,y:909,t:1527264767748};\\\", \\\"{x:1290,y:898,t:1527264767764};\\\", \\\"{x:1293,y:885,t:1527264767781};\\\", \\\"{x:1295,y:872,t:1527264767798};\\\", \\\"{x:1297,y:860,t:1527264767814};\\\", \\\"{x:1300,y:851,t:1527264767831};\\\", \\\"{x:1301,y:849,t:1527264767848};\\\", \\\"{x:1301,y:848,t:1527264767864};\\\", \\\"{x:1302,y:845,t:1527264767881};\\\", \\\"{x:1303,y:841,t:1527264768019};\\\", \\\"{x:1303,y:838,t:1527264768031};\\\", \\\"{x:1306,y:826,t:1527264768048};\\\", \\\"{x:1310,y:812,t:1527264768065};\\\", \\\"{x:1317,y:775,t:1527264768081};\\\", \\\"{x:1323,y:723,t:1527264768098};\\\", \\\"{x:1331,y:649,t:1527264768114};\\\", \\\"{x:1337,y:628,t:1527264768132};\\\", \\\"{x:1343,y:614,t:1527264768149};\\\", \\\"{x:1347,y:604,t:1527264768166};\\\", \\\"{x:1351,y:596,t:1527264768181};\\\", \\\"{x:1353,y:585,t:1527264768198};\\\", \\\"{x:1357,y:572,t:1527264768215};\\\", \\\"{x:1362,y:559,t:1527264768231};\\\", \\\"{x:1372,y:541,t:1527264768249};\\\", \\\"{x:1384,y:524,t:1527264768265};\\\", \\\"{x:1391,y:506,t:1527264768281};\\\", \\\"{x:1397,y:494,t:1527264768298};\\\", \\\"{x:1402,y:483,t:1527264768314};\\\", \\\"{x:1404,y:475,t:1527264768331};\\\", \\\"{x:1407,y:467,t:1527264768348};\\\", \\\"{x:1409,y:461,t:1527264768365};\\\", \\\"{x:1412,y:449,t:1527264768381};\\\", \\\"{x:1413,y:443,t:1527264768399};\\\", \\\"{x:1413,y:442,t:1527264768415};\\\", \\\"{x:1413,y:441,t:1527264768595};\\\", \\\"{x:1413,y:440,t:1527264768602};\\\", \\\"{x:1413,y:438,t:1527264768619};\\\", \\\"{x:1413,y:437,t:1527264768643};\\\", \\\"{x:1412,y:437,t:1527264769147};\\\", \\\"{x:1396,y:444,t:1527264769165};\\\", \\\"{x:1363,y:462,t:1527264769182};\\\", \\\"{x:1306,y:484,t:1527264769198};\\\", \\\"{x:1215,y:507,t:1527264769215};\\\", \\\"{x:1101,y:521,t:1527264769232};\\\", \\\"{x:972,y:531,t:1527264769249};\\\", \\\"{x:842,y:534,t:1527264769266};\\\", \\\"{x:668,y:534,t:1527264769283};\\\", \\\"{x:620,y:534,t:1527264769297};\\\", \\\"{x:538,y:525,t:1527264769309};\\\", \\\"{x:493,y:520,t:1527264769326};\\\", \\\"{x:473,y:520,t:1527264769342};\\\", \\\"{x:464,y:520,t:1527264769359};\\\", \\\"{x:463,y:520,t:1527264769375};\\\", \\\"{x:461,y:520,t:1527264769394};\\\", \\\"{x:461,y:522,t:1527264769409};\\\", \\\"{x:462,y:523,t:1527264769425};\\\", \\\"{x:468,y:525,t:1527264769603};\\\", \\\"{x:471,y:527,t:1527264769611};\\\", \\\"{x:472,y:527,t:1527264769627};\\\", \\\"{x:470,y:532,t:1527264769642};\\\", \\\"{x:449,y:541,t:1527264769660};\\\", \\\"{x:419,y:549,t:1527264769676};\\\", \\\"{x:374,y:562,t:1527264769692};\\\", \\\"{x:322,y:577,t:1527264769709};\\\", \\\"{x:275,y:589,t:1527264769726};\\\", \\\"{x:230,y:595,t:1527264769743};\\\", \\\"{x:197,y:598,t:1527264769758};\\\", \\\"{x:173,y:599,t:1527264769776};\\\", \\\"{x:160,y:599,t:1527264769792};\\\", \\\"{x:150,y:599,t:1527264769809};\\\", \\\"{x:132,y:594,t:1527264769826};\\\", \\\"{x:118,y:589,t:1527264769842};\\\", \\\"{x:109,y:587,t:1527264769859};\\\", \\\"{x:99,y:586,t:1527264769876};\\\", \\\"{x:97,y:585,t:1527264769893};\\\", \\\"{x:96,y:585,t:1527264769909};\\\", \\\"{x:95,y:584,t:1527264769954};\\\", \\\"{x:96,y:584,t:1527264769962};\\\", \\\"{x:98,y:584,t:1527264769976};\\\", \\\"{x:105,y:584,t:1527264769993};\\\", \\\"{x:119,y:584,t:1527264770010};\\\", \\\"{x:127,y:585,t:1527264770026};\\\", \\\"{x:135,y:591,t:1527264770043};\\\", \\\"{x:144,y:599,t:1527264770060};\\\", \\\"{x:150,y:605,t:1527264770076};\\\", \\\"{x:156,y:612,t:1527264770093};\\\", \\\"{x:162,y:615,t:1527264770110};\\\", \\\"{x:163,y:617,t:1527264770126};\\\", \\\"{x:164,y:617,t:1527264770290};\\\", \\\"{x:165,y:621,t:1527264770299};\\\", \\\"{x:166,y:623,t:1527264770310};\\\", \\\"{x:167,y:628,t:1527264770327};\\\", \\\"{x:167,y:634,t:1527264770343};\\\", \\\"{x:167,y:637,t:1527264770359};\\\", \\\"{x:167,y:639,t:1527264770377};\\\", \\\"{x:167,y:641,t:1527264770394};\\\", \\\"{x:166,y:642,t:1527264770410};\\\", \\\"{x:164,y:642,t:1527264770426};\\\", \\\"{x:162,y:642,t:1527264770442};\\\", \\\"{x:159,y:642,t:1527264770460};\\\", \\\"{x:156,y:642,t:1527264770477};\\\", \\\"{x:155,y:642,t:1527264770493};\\\", \\\"{x:153,y:642,t:1527264770509};\\\", \\\"{x:152,y:642,t:1527264770561};\\\", \\\"{x:152,y:641,t:1527264770841};\\\", \\\"{x:155,y:639,t:1527264770850};\\\", \\\"{x:158,y:639,t:1527264770860};\\\", \\\"{x:170,y:637,t:1527264770876};\\\", \\\"{x:181,y:635,t:1527264770892};\\\", \\\"{x:198,y:631,t:1527264770910};\\\", \\\"{x:214,y:627,t:1527264770927};\\\", \\\"{x:226,y:623,t:1527264770943};\\\", \\\"{x:232,y:621,t:1527264770959};\\\", \\\"{x:235,y:620,t:1527264770977};\\\", \\\"{x:236,y:619,t:1527264770994};\\\", \\\"{x:238,y:619,t:1527264771010};\\\", \\\"{x:239,y:619,t:1527264771034};\\\", \\\"{x:239,y:618,t:1527264771044};\\\", \\\"{x:239,y:617,t:1527264771066};\\\", \\\"{x:239,y:616,t:1527264771082};\\\", \\\"{x:239,y:612,t:1527264771094};\\\", \\\"{x:232,y:605,t:1527264771110};\\\", \\\"{x:218,y:593,t:1527264771127};\\\", \\\"{x:202,y:582,t:1527264771144};\\\", \\\"{x:191,y:577,t:1527264771161};\\\", \\\"{x:184,y:572,t:1527264771177};\\\", \\\"{x:178,y:568,t:1527264771194};\\\", \\\"{x:176,y:567,t:1527264771210};\\\", \\\"{x:171,y:565,t:1527264771227};\\\", \\\"{x:167,y:564,t:1527264771244};\\\", \\\"{x:158,y:563,t:1527264771259};\\\", \\\"{x:152,y:562,t:1527264771277};\\\", \\\"{x:154,y:562,t:1527264771378};\\\", \\\"{x:165,y:562,t:1527264771394};\\\", \\\"{x:184,y:562,t:1527264771411};\\\", \\\"{x:208,y:562,t:1527264771428};\\\", \\\"{x:247,y:562,t:1527264771444};\\\", \\\"{x:300,y:562,t:1527264771461};\\\", \\\"{x:378,y:562,t:1527264771478};\\\", \\\"{x:456,y:562,t:1527264771494};\\\", \\\"{x:529,y:558,t:1527264771511};\\\", \\\"{x:596,y:548,t:1527264771527};\\\", \\\"{x:647,y:548,t:1527264771543};\\\", \\\"{x:689,y:548,t:1527264771560};\\\", \\\"{x:738,y:548,t:1527264771578};\\\", \\\"{x:760,y:548,t:1527264771593};\\\", \\\"{x:772,y:548,t:1527264771611};\\\", \\\"{x:776,y:548,t:1527264771626};\\\", \\\"{x:776,y:547,t:1527264771722};\\\", \\\"{x:776,y:545,t:1527264771738};\\\", \\\"{x:776,y:544,t:1527264771746};\\\", \\\"{x:776,y:543,t:1527264771762};\\\", \\\"{x:777,y:540,t:1527264771777};\\\", \\\"{x:777,y:539,t:1527264771794};\\\", \\\"{x:777,y:538,t:1527264771811};\\\", \\\"{x:777,y:536,t:1527264771843};\\\", \\\"{x:776,y:536,t:1527264771861};\\\", \\\"{x:775,y:536,t:1527264771877};\\\", \\\"{x:774,y:535,t:1527264771894};\\\", \\\"{x:773,y:534,t:1527264771938};\\\", \\\"{x:773,y:533,t:1527264771994};\\\", \\\"{x:776,y:532,t:1527264772011};\\\", \\\"{x:781,y:532,t:1527264772028};\\\", \\\"{x:787,y:532,t:1527264772044};\\\", \\\"{x:792,y:532,t:1527264772061};\\\", \\\"{x:804,y:532,t:1527264772078};\\\", \\\"{x:819,y:532,t:1527264772094};\\\", \\\"{x:828,y:529,t:1527264772111};\\\", \\\"{x:832,y:528,t:1527264772127};\\\", \\\"{x:833,y:528,t:1527264772144};\\\", \\\"{x:836,y:527,t:1527264772161};\\\", \\\"{x:836,y:526,t:1527264772507};\\\", \\\"{x:832,y:526,t:1527264772530};\\\", \\\"{x:828,y:528,t:1527264772545};\\\", \\\"{x:813,y:532,t:1527264772562};\\\", \\\"{x:797,y:537,t:1527264772579};\\\", \\\"{x:795,y:537,t:1527264772595};\\\", \\\"{x:796,y:537,t:1527264772683};\\\", \\\"{x:797,y:536,t:1527264772696};\\\", \\\"{x:799,y:535,t:1527264772712};\\\", \\\"{x:801,y:535,t:1527264772729};\\\", \\\"{x:805,y:534,t:1527264772745};\\\", \\\"{x:804,y:534,t:1527264772827};\\\", \\\"{x:799,y:535,t:1527264772835};\\\", \\\"{x:794,y:539,t:1527264772846};\\\", \\\"{x:780,y:545,t:1527264772863};\\\", \\\"{x:759,y:551,t:1527264772878};\\\", \\\"{x:735,y:559,t:1527264772895};\\\", \\\"{x:713,y:561,t:1527264772912};\\\", \\\"{x:689,y:564,t:1527264772928};\\\", \\\"{x:669,y:564,t:1527264772944};\\\", \\\"{x:640,y:564,t:1527264772962};\\\", \\\"{x:633,y:565,t:1527264772979};\\\", \\\"{x:632,y:565,t:1527264772994};\\\", \\\"{x:632,y:567,t:1527264773147};\\\", \\\"{x:634,y:571,t:1527264773163};\\\", \\\"{x:634,y:573,t:1527264773179};\\\", \\\"{x:634,y:574,t:1527264773194};\\\", \\\"{x:634,y:575,t:1527264773218};\\\", \\\"{x:634,y:576,t:1527264773228};\\\", \\\"{x:634,y:577,t:1527264773323};\\\", \\\"{x:634,y:579,t:1527264773338};\\\", \\\"{x:634,y:580,t:1527264773346};\\\", \\\"{x:634,y:583,t:1527264773363};\\\", \\\"{x:634,y:585,t:1527264773379};\\\", \\\"{x:634,y:587,t:1527264773396};\\\", \\\"{x:633,y:588,t:1527264773412};\\\", \\\"{x:633,y:589,t:1527264773490};\\\", \\\"{x:632,y:589,t:1527264773497};\\\", \\\"{x:630,y:590,t:1527264773514};\\\", \\\"{x:630,y:591,t:1527264773529};\\\", \\\"{x:629,y:591,t:1527264773546};\\\", \\\"{x:628,y:592,t:1527264773562};\\\", \\\"{x:627,y:592,t:1527264773738};\\\", \\\"{x:627,y:592,t:1527264773767};\\\", \\\"{x:626,y:592,t:1527264773785};\\\", \\\"{x:626,y:593,t:1527264773890};\\\", \\\"{x:625,y:595,t:1527264773898};\\\", \\\"{x:620,y:597,t:1527264773913};\\\", \\\"{x:611,y:603,t:1527264773930};\\\", \\\"{x:590,y:615,t:1527264773946};\\\", \\\"{x:567,y:625,t:1527264773964};\\\", \\\"{x:548,y:631,t:1527264773979};\\\", \\\"{x:528,y:638,t:1527264773996};\\\", \\\"{x:508,y:644,t:1527264774013};\\\", \\\"{x:493,y:647,t:1527264774029};\\\", \\\"{x:479,y:648,t:1527264774046};\\\", \\\"{x:467,y:649,t:1527264774061};\\\", \\\"{x:454,y:649,t:1527264774079};\\\", \\\"{x:442,y:649,t:1527264774095};\\\", \\\"{x:431,y:649,t:1527264774112};\\\", \\\"{x:422,y:649,t:1527264774128};\\\", \\\"{x:418,y:649,t:1527264774145};\\\", \\\"{x:417,y:649,t:1527264774186};\\\", \\\"{x:416,y:648,t:1527264774210};\\\", \\\"{x:415,y:648,t:1527264774218};\\\", \\\"{x:414,y:646,t:1527264774233};\\\", \\\"{x:409,y:644,t:1527264774249};\\\", \\\"{x:401,y:640,t:1527264774265};\\\", \\\"{x:388,y:632,t:1527264774283};\\\", \\\"{x:380,y:629,t:1527264774299};\\\", \\\"{x:375,y:627,t:1527264774316};\\\", \\\"{x:369,y:626,t:1527264774333};\\\", \\\"{x:363,y:625,t:1527264774350};\\\", \\\"{x:362,y:625,t:1527264774366};\\\", \\\"{x:361,y:625,t:1527264774384};\\\", \\\"{x:360,y:624,t:1527264774654};\\\", \\\"{x:359,y:623,t:1527264774667};\\\", \\\"{x:357,y:620,t:1527264774684};\\\", \\\"{x:354,y:618,t:1527264774702};\\\", \\\"{x:350,y:617,t:1527264774717};\\\", \\\"{x:343,y:615,t:1527264774733};\\\", \\\"{x:336,y:615,t:1527264774749};\\\", \\\"{x:329,y:615,t:1527264774766};\\\", \\\"{x:322,y:615,t:1527264774784};\\\", \\\"{x:312,y:616,t:1527264774800};\\\", \\\"{x:301,y:617,t:1527264774816};\\\", \\\"{x:288,y:619,t:1527264774833};\\\", \\\"{x:273,y:619,t:1527264774849};\\\", \\\"{x:255,y:619,t:1527264774867};\\\", \\\"{x:231,y:612,t:1527264774884};\\\", \\\"{x:205,y:604,t:1527264774900};\\\", \\\"{x:180,y:597,t:1527264774917};\\\", \\\"{x:164,y:592,t:1527264774934};\\\", \\\"{x:163,y:591,t:1527264774951};\\\", \\\"{x:168,y:591,t:1527264775109};\\\", \\\"{x:176,y:591,t:1527264775117};\\\", \\\"{x:194,y:592,t:1527264775133};\\\", \\\"{x:216,y:592,t:1527264775151};\\\", \\\"{x:242,y:592,t:1527264775166};\\\", \\\"{x:269,y:592,t:1527264775184};\\\", \\\"{x:298,y:591,t:1527264775201};\\\", \\\"{x:338,y:582,t:1527264775216};\\\", \\\"{x:373,y:577,t:1527264775234};\\\", \\\"{x:406,y:572,t:1527264775250};\\\", \\\"{x:435,y:569,t:1527264775268};\\\", \\\"{x:451,y:566,t:1527264775283};\\\", \\\"{x:464,y:565,t:1527264775301};\\\", \\\"{x:485,y:565,t:1527264775317};\\\", \\\"{x:498,y:565,t:1527264775334};\\\", \\\"{x:511,y:565,t:1527264775351};\\\", \\\"{x:526,y:565,t:1527264775368};\\\", \\\"{x:541,y:564,t:1527264775384};\\\", \\\"{x:562,y:560,t:1527264775400};\\\", \\\"{x:583,y:558,t:1527264775418};\\\", \\\"{x:608,y:554,t:1527264775434};\\\", \\\"{x:630,y:549,t:1527264775451};\\\", \\\"{x:650,y:543,t:1527264775468};\\\", \\\"{x:665,y:541,t:1527264775483};\\\", \\\"{x:675,y:539,t:1527264775501};\\\", \\\"{x:681,y:539,t:1527264775517};\\\", \\\"{x:683,y:538,t:1527264775533};\\\", \\\"{x:682,y:539,t:1527264775638};\\\", \\\"{x:680,y:540,t:1527264775654};\\\", \\\"{x:677,y:542,t:1527264775668};\\\", \\\"{x:673,y:546,t:1527264775686};\\\", \\\"{x:668,y:551,t:1527264775700};\\\", \\\"{x:662,y:559,t:1527264775717};\\\", \\\"{x:659,y:566,t:1527264775735};\\\", \\\"{x:657,y:572,t:1527264775751};\\\", \\\"{x:657,y:579,t:1527264775768};\\\", \\\"{x:657,y:586,t:1527264775785};\\\", \\\"{x:664,y:594,t:1527264775800};\\\", \\\"{x:682,y:599,t:1527264775817};\\\", \\\"{x:700,y:604,t:1527264775835};\\\", \\\"{x:718,y:609,t:1527264775850};\\\", \\\"{x:739,y:613,t:1527264775868};\\\", \\\"{x:756,y:615,t:1527264775885};\\\", \\\"{x:768,y:615,t:1527264775901};\\\", \\\"{x:775,y:615,t:1527264775917};\\\", \\\"{x:776,y:615,t:1527264775934};\\\", \\\"{x:777,y:615,t:1527264775951};\\\", \\\"{x:778,y:615,t:1527264776007};\\\", \\\"{x:779,y:615,t:1527264776022};\\\", \\\"{x:781,y:615,t:1527264776035};\\\", \\\"{x:788,y:613,t:1527264776051};\\\", \\\"{x:801,y:610,t:1527264776069};\\\", \\\"{x:810,y:608,t:1527264776085};\\\", \\\"{x:818,y:608,t:1527264776101};\\\", \\\"{x:827,y:608,t:1527264776118};\\\", \\\"{x:830,y:608,t:1527264776134};\\\", \\\"{x:832,y:608,t:1527264776157};\\\", \\\"{x:833,y:608,t:1527264776167};\\\", \\\"{x:835,y:606,t:1527264776185};\\\", \\\"{x:837,y:606,t:1527264776202};\\\", \\\"{x:836,y:606,t:1527264776509};\\\", \\\"{x:830,y:608,t:1527264776518};\\\", \\\"{x:816,y:621,t:1527264776535};\\\", \\\"{x:797,y:635,t:1527264776552};\\\", \\\"{x:765,y:655,t:1527264776569};\\\", \\\"{x:740,y:673,t:1527264776585};\\\", \\\"{x:714,y:687,t:1527264776602};\\\", \\\"{x:694,y:695,t:1527264776618};\\\", \\\"{x:672,y:701,t:1527264776634};\\\", \\\"{x:651,y:706,t:1527264776651};\\\", \\\"{x:630,y:707,t:1527264776668};\\\", \\\"{x:612,y:711,t:1527264776684};\\\", \\\"{x:581,y:711,t:1527264776701};\\\", \\\"{x:563,y:711,t:1527264776718};\\\", \\\"{x:552,y:711,t:1527264776735};\\\", \\\"{x:544,y:711,t:1527264776751};\\\", \\\"{x:539,y:711,t:1527264776768};\\\", \\\"{x:537,y:711,t:1527264776784};\\\", \\\"{x:536,y:711,t:1527264776830};\\\", \\\"{x:532,y:711,t:1527264776870};\\\", \\\"{x:530,y:711,t:1527264776885};\\\", \\\"{x:526,y:711,t:1527264776901};\\\", \\\"{x:522,y:711,t:1527264776918};\\\", \\\"{x:512,y:711,t:1527264776934};\\\", \\\"{x:504,y:711,t:1527264776951};\\\", \\\"{x:490,y:711,t:1527264776968};\\\", \\\"{x:482,y:711,t:1527264776984};\\\", \\\"{x:477,y:711,t:1527264777002};\\\", \\\"{x:474,y:710,t:1527264777018};\\\", \\\"{x:471,y:709,t:1527264777847};\\\", \\\"{x:469,y:707,t:1527264777854};\\\", \\\"{x:468,y:706,t:1527264777869};\\\", \\\"{x:463,y:703,t:1527264777885};\\\", \\\"{x:461,y:702,t:1527264777903};\\\", \\\"{x:457,y:698,t:1527264777919};\\\", \\\"{x:454,y:696,t:1527264777936};\\\", \\\"{x:452,y:695,t:1527264777952};\\\", \\\"{x:451,y:694,t:1527264778070};\\\", \\\"{x:448,y:692,t:1527264778191};\\\", \\\"{x:447,y:691,t:1527264778203};\\\", \\\"{x:441,y:687,t:1527264778234};\\\", \\\"{x:440,y:687,t:1527264778239};\\\", \\\"{x:439,y:687,t:1527264778252};\\\", \\\"{x:437,y:686,t:1527264778269};\\\", \\\"{x:436,y:685,t:1527264778285};\\\" ] }, { \\\"rt\\\": 98540, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 461930, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -O -O -I -I -06 PM-12 PM-12 PM-12 PM-01 PM-02 PM-03 PM-04 PM-05 PM-06 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:435,y:685,t:1527264778486};\\\", \\\"{x:434,y:684,t:1527264778506};\\\", \\\"{x:433,y:684,t:1527264778525};\\\", \\\"{x:431,y:683,t:1527264778565};\\\", \\\"{x:430,y:682,t:1527264778597};\\\", \\\"{x:429,y:682,t:1527264778718};\\\", \\\"{x:428,y:681,t:1527264779919};\\\", \\\"{x:439,y:685,t:1527264779935};\\\", \\\"{x:462,y:694,t:1527264779941};\\\", \\\"{x:489,y:707,t:1527264779954};\\\", \\\"{x:537,y:729,t:1527264779972};\\\", \\\"{x:581,y:749,t:1527264779988};\\\", \\\"{x:612,y:759,t:1527264780005};\\\", \\\"{x:637,y:767,t:1527264780021};\\\", \\\"{x:658,y:775,t:1527264780037};\\\", \\\"{x:662,y:778,t:1527264780054};\\\", \\\"{x:663,y:778,t:1527264780070};\\\", \\\"{x:655,y:778,t:1527264780088};\\\", \\\"{x:637,y:774,t:1527264780105};\\\", \\\"{x:636,y:774,t:1527264780120};\\\", \\\"{x:639,y:774,t:1527264780478};\\\", \\\"{x:642,y:774,t:1527264780488};\\\", \\\"{x:645,y:773,t:1527264780505};\\\", \\\"{x:648,y:773,t:1527264780522};\\\", \\\"{x:650,y:773,t:1527264780538};\\\", \\\"{x:652,y:773,t:1527264780557};\\\", \\\"{x:653,y:773,t:1527264780574};\\\", \\\"{x:654,y:772,t:1527264780589};\\\", \\\"{x:657,y:771,t:1527264780606};\\\", \\\"{x:661,y:769,t:1527264780622};\\\", \\\"{x:663,y:767,t:1527264780639};\\\", \\\"{x:668,y:766,t:1527264780655};\\\", \\\"{x:669,y:765,t:1527264780672};\\\", \\\"{x:671,y:763,t:1527264780689};\\\", \\\"{x:671,y:762,t:1527264781998};\\\", \\\"{x:670,y:762,t:1527264782030};\\\", \\\"{x:669,y:762,t:1527264782040};\\\", \\\"{x:669,y:761,t:1527264782062};\\\", \\\"{x:668,y:761,t:1527264782246};\\\", \\\"{x:667,y:761,t:1527264782257};\\\", \\\"{x:666,y:761,t:1527264782274};\\\", \\\"{x:665,y:760,t:1527264782294};\\\", \\\"{x:663,y:759,t:1527264782310};\\\", \\\"{x:662,y:758,t:1527264782334};\\\", \\\"{x:662,y:757,t:1527264782350};\\\", \\\"{x:660,y:757,t:1527264782358};\\\", \\\"{x:659,y:756,t:1527264782382};\\\", \\\"{x:658,y:755,t:1527264782391};\\\", \\\"{x:657,y:755,t:1527264782408};\\\", \\\"{x:657,y:754,t:1527264782424};\\\", \\\"{x:656,y:754,t:1527264782678};\\\", \\\"{x:656,y:753,t:1527264782690};\\\", \\\"{x:655,y:752,t:1527264782708};\\\", \\\"{x:654,y:751,t:1527264782724};\\\", \\\"{x:653,y:751,t:1527264782740};\\\", \\\"{x:652,y:750,t:1527264782758};\\\", \\\"{x:651,y:750,t:1527264782773};\\\", \\\"{x:651,y:749,t:1527264782862};\\\", \\\"{x:652,y:749,t:1527264783974};\\\", \\\"{x:657,y:750,t:1527264783982};\\\", \\\"{x:667,y:754,t:1527264783992};\\\", \\\"{x:689,y:764,t:1527264784009};\\\", \\\"{x:722,y:779,t:1527264784026};\\\", \\\"{x:767,y:792,t:1527264784042};\\\", \\\"{x:815,y:808,t:1527264784059};\\\", \\\"{x:874,y:826,t:1527264784076};\\\", \\\"{x:927,y:841,t:1527264784092};\\\", \\\"{x:983,y:859,t:1527264784109};\\\", \\\"{x:1094,y:878,t:1527264784125};\\\", \\\"{x:1154,y:892,t:1527264784142};\\\", \\\"{x:1204,y:896,t:1527264784159};\\\", \\\"{x:1261,y:900,t:1527264784176};\\\", \\\"{x:1314,y:900,t:1527264784193};\\\", \\\"{x:1370,y:900,t:1527264784209};\\\", \\\"{x:1412,y:900,t:1527264784226};\\\", \\\"{x:1441,y:900,t:1527264784243};\\\", \\\"{x:1465,y:900,t:1527264784259};\\\", \\\"{x:1476,y:900,t:1527264784276};\\\", \\\"{x:1481,y:901,t:1527264784293};\\\", \\\"{x:1482,y:902,t:1527264784309};\\\", \\\"{x:1482,y:901,t:1527264784622};\\\", \\\"{x:1480,y:900,t:1527264784638};\\\", \\\"{x:1473,y:900,t:1527264784646};\\\", \\\"{x:1462,y:900,t:1527264784660};\\\", \\\"{x:1428,y:900,t:1527264784676};\\\", \\\"{x:1378,y:900,t:1527264784694};\\\", \\\"{x:1294,y:900,t:1527264784710};\\\", \\\"{x:1244,y:900,t:1527264784727};\\\", \\\"{x:1207,y:900,t:1527264784744};\\\", \\\"{x:1182,y:900,t:1527264784761};\\\", \\\"{x:1165,y:900,t:1527264784778};\\\", \\\"{x:1153,y:901,t:1527264784794};\\\", \\\"{x:1150,y:901,t:1527264784810};\\\", \\\"{x:1147,y:902,t:1527264784828};\\\", \\\"{x:1147,y:903,t:1527264784844};\\\", \\\"{x:1150,y:910,t:1527264784861};\\\", \\\"{x:1171,y:921,t:1527264784878};\\\", \\\"{x:1179,y:926,t:1527264784894};\\\", \\\"{x:1206,y:941,t:1527264784910};\\\", \\\"{x:1225,y:947,t:1527264784928};\\\", \\\"{x:1246,y:951,t:1527264784944};\\\", \\\"{x:1265,y:953,t:1527264784961};\\\", \\\"{x:1282,y:954,t:1527264784978};\\\", \\\"{x:1297,y:954,t:1527264784994};\\\", \\\"{x:1308,y:954,t:1527264785010};\\\", \\\"{x:1314,y:954,t:1527264785028};\\\", \\\"{x:1317,y:952,t:1527264785044};\\\", \\\"{x:1320,y:951,t:1527264785060};\\\", \\\"{x:1321,y:951,t:1527264785078};\\\", \\\"{x:1326,y:948,t:1527264785093};\\\", \\\"{x:1333,y:945,t:1527264785110};\\\", \\\"{x:1342,y:940,t:1527264785127};\\\", \\\"{x:1354,y:935,t:1527264785144};\\\", \\\"{x:1368,y:929,t:1527264785160};\\\", \\\"{x:1386,y:923,t:1527264785177};\\\", \\\"{x:1407,y:914,t:1527264785194};\\\", \\\"{x:1435,y:901,t:1527264785210};\\\", \\\"{x:1468,y:889,t:1527264785227};\\\", \\\"{x:1502,y:879,t:1527264785244};\\\", \\\"{x:1540,y:868,t:1527264785260};\\\", \\\"{x:1584,y:857,t:1527264785277};\\\", \\\"{x:1624,y:842,t:1527264785293};\\\", \\\"{x:1641,y:834,t:1527264785309};\\\", \\\"{x:1653,y:825,t:1527264785327};\\\", \\\"{x:1663,y:815,t:1527264785344};\\\", \\\"{x:1666,y:808,t:1527264785361};\\\", \\\"{x:1668,y:799,t:1527264785377};\\\", \\\"{x:1668,y:794,t:1527264785394};\\\", \\\"{x:1668,y:787,t:1527264785411};\\\", \\\"{x:1667,y:780,t:1527264785427};\\\", \\\"{x:1665,y:775,t:1527264785444};\\\", \\\"{x:1660,y:759,t:1527264785461};\\\", \\\"{x:1653,y:745,t:1527264785478};\\\", \\\"{x:1644,y:730,t:1527264785494};\\\", \\\"{x:1631,y:716,t:1527264785512};\\\", \\\"{x:1616,y:698,t:1527264785527};\\\", \\\"{x:1600,y:684,t:1527264785544};\\\", \\\"{x:1587,y:672,t:1527264785561};\\\", \\\"{x:1577,y:663,t:1527264785577};\\\", \\\"{x:1570,y:656,t:1527264785594};\\\", \\\"{x:1562,y:647,t:1527264785611};\\\", \\\"{x:1555,y:637,t:1527264785627};\\\", \\\"{x:1547,y:628,t:1527264785645};\\\", \\\"{x:1543,y:622,t:1527264785662};\\\", \\\"{x:1540,y:616,t:1527264785678};\\\", \\\"{x:1538,y:611,t:1527264785695};\\\", \\\"{x:1533,y:603,t:1527264785712};\\\", \\\"{x:1528,y:593,t:1527264785729};\\\", \\\"{x:1521,y:580,t:1527264785745};\\\", \\\"{x:1515,y:564,t:1527264785762};\\\", \\\"{x:1505,y:544,t:1527264785779};\\\", \\\"{x:1496,y:528,t:1527264785795};\\\", \\\"{x:1485,y:512,t:1527264785812};\\\", \\\"{x:1476,y:498,t:1527264785828};\\\", \\\"{x:1463,y:482,t:1527264785844};\\\", \\\"{x:1448,y:465,t:1527264785862};\\\", \\\"{x:1434,y:451,t:1527264785878};\\\", \\\"{x:1432,y:447,t:1527264785895};\\\", \\\"{x:1430,y:446,t:1527264785911};\\\", \\\"{x:1428,y:445,t:1527264785928};\\\", \\\"{x:1427,y:445,t:1527264785958};\\\", \\\"{x:1427,y:444,t:1527264785966};\\\", \\\"{x:1426,y:444,t:1527264785979};\\\", \\\"{x:1424,y:444,t:1527264785996};\\\", \\\"{x:1417,y:441,t:1527264786012};\\\", \\\"{x:1413,y:441,t:1527264786029};\\\", \\\"{x:1400,y:441,t:1527264786046};\\\", \\\"{x:1383,y:442,t:1527264786062};\\\", \\\"{x:1361,y:449,t:1527264786078};\\\", \\\"{x:1353,y:452,t:1527264786096};\\\", \\\"{x:1343,y:455,t:1527264786112};\\\", \\\"{x:1335,y:458,t:1527264786128};\\\", \\\"{x:1331,y:461,t:1527264786146};\\\", \\\"{x:1329,y:461,t:1527264786162};\\\", \\\"{x:1327,y:462,t:1527264786179};\\\", \\\"{x:1324,y:463,t:1527264786196};\\\", \\\"{x:1323,y:464,t:1527264786212};\\\", \\\"{x:1321,y:466,t:1527264786228};\\\", \\\"{x:1321,y:468,t:1527264786246};\\\", \\\"{x:1317,y:476,t:1527264786262};\\\", \\\"{x:1316,y:481,t:1527264786279};\\\", \\\"{x:1312,y:488,t:1527264786296};\\\", \\\"{x:1309,y:497,t:1527264786315};\\\", \\\"{x:1307,y:502,t:1527264786328};\\\", \\\"{x:1307,y:505,t:1527264786345};\\\", \\\"{x:1306,y:506,t:1527264786362};\\\", \\\"{x:1306,y:503,t:1527264786622};\\\", \\\"{x:1307,y:503,t:1527264786629};\\\", \\\"{x:1308,y:500,t:1527264786645};\\\", \\\"{x:1310,y:498,t:1527264786662};\\\", \\\"{x:1310,y:500,t:1527264786814};\\\", \\\"{x:1310,y:509,t:1527264786832};\\\", \\\"{x:1310,y:520,t:1527264786847};\\\", \\\"{x:1310,y:530,t:1527264786863};\\\", \\\"{x:1310,y:536,t:1527264786880};\\\", \\\"{x:1310,y:547,t:1527264786896};\\\", \\\"{x:1310,y:555,t:1527264786912};\\\", \\\"{x:1310,y:564,t:1527264786929};\\\", \\\"{x:1310,y:572,t:1527264786946};\\\", \\\"{x:1310,y:578,t:1527264786962};\\\", \\\"{x:1310,y:587,t:1527264786980};\\\", \\\"{x:1310,y:595,t:1527264786997};\\\", \\\"{x:1310,y:602,t:1527264787012};\\\", \\\"{x:1310,y:610,t:1527264787030};\\\", \\\"{x:1312,y:619,t:1527264787046};\\\", \\\"{x:1313,y:627,t:1527264787063};\\\", \\\"{x:1314,y:633,t:1527264787079};\\\", \\\"{x:1315,y:638,t:1527264787097};\\\", \\\"{x:1316,y:642,t:1527264787112};\\\", \\\"{x:1317,y:645,t:1527264787130};\\\", \\\"{x:1318,y:650,t:1527264787147};\\\", \\\"{x:1322,y:658,t:1527264787162};\\\", \\\"{x:1326,y:664,t:1527264787179};\\\", \\\"{x:1328,y:668,t:1527264787197};\\\", \\\"{x:1329,y:672,t:1527264787214};\\\", \\\"{x:1329,y:673,t:1527264787229};\\\", \\\"{x:1330,y:676,t:1527264787246};\\\", \\\"{x:1332,y:681,t:1527264787264};\\\", \\\"{x:1333,y:684,t:1527264787280};\\\", \\\"{x:1333,y:686,t:1527264787297};\\\", \\\"{x:1333,y:691,t:1527264787314};\\\", \\\"{x:1333,y:694,t:1527264787330};\\\", \\\"{x:1333,y:700,t:1527264787346};\\\", \\\"{x:1333,y:706,t:1527264787363};\\\", \\\"{x:1333,y:713,t:1527264787379};\\\", \\\"{x:1333,y:718,t:1527264787396};\\\", \\\"{x:1333,y:726,t:1527264787414};\\\", \\\"{x:1333,y:732,t:1527264787430};\\\", \\\"{x:1332,y:736,t:1527264787447};\\\", \\\"{x:1332,y:742,t:1527264787464};\\\", \\\"{x:1332,y:747,t:1527264787479};\\\", \\\"{x:1331,y:751,t:1527264787496};\\\", \\\"{x:1331,y:755,t:1527264787513};\\\", \\\"{x:1331,y:757,t:1527264787530};\\\", \\\"{x:1331,y:760,t:1527264787546};\\\", \\\"{x:1331,y:763,t:1527264787564};\\\", \\\"{x:1331,y:765,t:1527264787581};\\\", \\\"{x:1331,y:769,t:1527264787597};\\\", \\\"{x:1331,y:772,t:1527264787614};\\\", \\\"{x:1331,y:774,t:1527264787630};\\\", \\\"{x:1329,y:779,t:1527264787646};\\\", \\\"{x:1329,y:780,t:1527264787663};\\\", \\\"{x:1329,y:782,t:1527264787680};\\\", \\\"{x:1329,y:785,t:1527264787696};\\\", \\\"{x:1329,y:788,t:1527264787713};\\\", \\\"{x:1329,y:790,t:1527264787730};\\\", \\\"{x:1328,y:795,t:1527264787747};\\\", \\\"{x:1327,y:799,t:1527264787763};\\\", \\\"{x:1326,y:806,t:1527264787780};\\\", \\\"{x:1324,y:813,t:1527264787797};\\\", \\\"{x:1321,y:820,t:1527264787813};\\\", \\\"{x:1320,y:827,t:1527264787831};\\\", \\\"{x:1319,y:833,t:1527264787847};\\\", \\\"{x:1317,y:840,t:1527264787863};\\\", \\\"{x:1316,y:847,t:1527264787881};\\\", \\\"{x:1315,y:853,t:1527264787898};\\\", \\\"{x:1315,y:859,t:1527264787913};\\\", \\\"{x:1315,y:865,t:1527264787931};\\\", \\\"{x:1315,y:870,t:1527264787947};\\\", \\\"{x:1315,y:874,t:1527264787963};\\\", \\\"{x:1315,y:879,t:1527264787980};\\\", \\\"{x:1315,y:883,t:1527264787998};\\\", \\\"{x:1315,y:886,t:1527264788014};\\\", \\\"{x:1315,y:890,t:1527264788031};\\\", \\\"{x:1315,y:891,t:1527264788048};\\\", \\\"{x:1315,y:895,t:1527264788063};\\\", \\\"{x:1315,y:898,t:1527264788081};\\\", \\\"{x:1315,y:900,t:1527264788097};\\\", \\\"{x:1315,y:902,t:1527264788114};\\\", \\\"{x:1315,y:905,t:1527264788130};\\\", \\\"{x:1315,y:908,t:1527264788148};\\\", \\\"{x:1315,y:911,t:1527264788165};\\\", \\\"{x:1315,y:915,t:1527264788180};\\\", \\\"{x:1315,y:921,t:1527264788198};\\\", \\\"{x:1315,y:924,t:1527264788213};\\\", \\\"{x:1315,y:928,t:1527264788231};\\\", \\\"{x:1315,y:931,t:1527264788248};\\\", \\\"{x:1315,y:935,t:1527264788264};\\\", \\\"{x:1315,y:938,t:1527264788280};\\\", \\\"{x:1316,y:940,t:1527264788297};\\\", \\\"{x:1316,y:942,t:1527264788314};\\\", \\\"{x:1316,y:943,t:1527264788341};\\\", \\\"{x:1316,y:944,t:1527264788358};\\\", \\\"{x:1316,y:945,t:1527264788374};\\\", \\\"{x:1316,y:946,t:1527264788399};\\\", \\\"{x:1316,y:947,t:1527264788415};\\\", \\\"{x:1316,y:948,t:1527264788431};\\\", \\\"{x:1317,y:949,t:1527264788448};\\\", \\\"{x:1317,y:950,t:1527264788477};\\\", \\\"{x:1317,y:951,t:1527264788501};\\\", \\\"{x:1317,y:952,t:1527264788533};\\\", \\\"{x:1317,y:953,t:1527264788549};\\\", \\\"{x:1317,y:954,t:1527264788565};\\\", \\\"{x:1317,y:955,t:1527264788581};\\\", \\\"{x:1317,y:956,t:1527264788597};\\\", \\\"{x:1317,y:957,t:1527264788614};\\\", \\\"{x:1317,y:959,t:1527264788637};\\\", \\\"{x:1317,y:960,t:1527264788654};\\\", \\\"{x:1317,y:961,t:1527264788670};\\\", \\\"{x:1317,y:962,t:1527264788702};\\\", \\\"{x:1317,y:963,t:1527264789575};\\\", \\\"{x:1317,y:965,t:1527264789599};\\\", \\\"{x:1316,y:965,t:1527264789615};\\\", \\\"{x:1315,y:966,t:1527264789622};\\\", \\\"{x:1314,y:966,t:1527264789638};\\\", \\\"{x:1313,y:967,t:1527264789742};\\\", \\\"{x:1312,y:966,t:1527264792606};\\\", \\\"{x:1312,y:961,t:1527264792620};\\\", \\\"{x:1312,y:953,t:1527264792637};\\\", \\\"{x:1312,y:945,t:1527264792653};\\\", \\\"{x:1312,y:934,t:1527264792670};\\\", \\\"{x:1312,y:929,t:1527264792686};\\\", \\\"{x:1313,y:917,t:1527264792703};\\\", \\\"{x:1315,y:906,t:1527264792720};\\\", \\\"{x:1316,y:892,t:1527264792736};\\\", \\\"{x:1319,y:871,t:1527264792753};\\\", \\\"{x:1319,y:849,t:1527264792770};\\\", \\\"{x:1319,y:833,t:1527264792786};\\\", \\\"{x:1319,y:816,t:1527264792803};\\\", \\\"{x:1317,y:796,t:1527264792820};\\\", \\\"{x:1311,y:773,t:1527264792837};\\\", \\\"{x:1308,y:752,t:1527264792853};\\\", \\\"{x:1303,y:715,t:1527264792870};\\\", \\\"{x:1301,y:688,t:1527264792886};\\\", \\\"{x:1301,y:661,t:1527264792902};\\\", \\\"{x:1300,y:638,t:1527264792920};\\\", \\\"{x:1300,y:621,t:1527264792937};\\\", \\\"{x:1300,y:608,t:1527264792953};\\\", \\\"{x:1300,y:593,t:1527264792970};\\\", \\\"{x:1300,y:576,t:1527264792987};\\\", \\\"{x:1300,y:564,t:1527264793003};\\\", \\\"{x:1300,y:553,t:1527264793020};\\\", \\\"{x:1300,y:544,t:1527264793037};\\\", \\\"{x:1300,y:536,t:1527264793052};\\\", \\\"{x:1302,y:526,t:1527264793070};\\\", \\\"{x:1302,y:522,t:1527264793087};\\\", \\\"{x:1303,y:516,t:1527264793104};\\\", \\\"{x:1305,y:505,t:1527264793120};\\\", \\\"{x:1307,y:499,t:1527264793137};\\\", \\\"{x:1309,y:492,t:1527264793153};\\\", \\\"{x:1310,y:491,t:1527264793170};\\\", \\\"{x:1313,y:495,t:1527264793575};\\\", \\\"{x:1316,y:503,t:1527264793588};\\\", \\\"{x:1322,y:522,t:1527264793604};\\\", \\\"{x:1325,y:537,t:1527264793621};\\\", \\\"{x:1326,y:554,t:1527264793637};\\\", \\\"{x:1326,y:581,t:1527264793654};\\\", \\\"{x:1326,y:604,t:1527264793670};\\\", \\\"{x:1325,y:626,t:1527264793687};\\\", \\\"{x:1321,y:652,t:1527264793703};\\\", \\\"{x:1318,y:674,t:1527264793721};\\\", \\\"{x:1316,y:695,t:1527264793736};\\\", \\\"{x:1314,y:712,t:1527264793754};\\\", \\\"{x:1313,y:728,t:1527264793771};\\\", \\\"{x:1313,y:745,t:1527264793787};\\\", \\\"{x:1311,y:759,t:1527264793804};\\\", \\\"{x:1311,y:765,t:1527264793821};\\\", \\\"{x:1311,y:777,t:1527264793838};\\\", \\\"{x:1311,y:786,t:1527264793854};\\\", \\\"{x:1311,y:797,t:1527264793871};\\\", \\\"{x:1308,y:815,t:1527264793887};\\\", \\\"{x:1305,y:836,t:1527264793904};\\\", \\\"{x:1302,y:858,t:1527264793921};\\\", \\\"{x:1300,y:879,t:1527264793938};\\\", \\\"{x:1296,y:895,t:1527264793954};\\\", \\\"{x:1294,y:911,t:1527264793971};\\\", \\\"{x:1291,y:924,t:1527264793987};\\\", \\\"{x:1290,y:932,t:1527264794004};\\\", \\\"{x:1290,y:939,t:1527264794021};\\\", \\\"{x:1290,y:944,t:1527264794038};\\\", \\\"{x:1290,y:947,t:1527264794054};\\\", \\\"{x:1290,y:950,t:1527264794071};\\\", \\\"{x:1290,y:954,t:1527264794087};\\\", \\\"{x:1290,y:957,t:1527264794105};\\\", \\\"{x:1291,y:959,t:1527264794121};\\\", \\\"{x:1291,y:960,t:1527264794138};\\\", \\\"{x:1292,y:961,t:1527264794155};\\\", \\\"{x:1293,y:962,t:1527264794171};\\\", \\\"{x:1294,y:962,t:1527264794270};\\\", \\\"{x:1296,y:962,t:1527264794288};\\\", \\\"{x:1297,y:964,t:1527264794305};\\\", \\\"{x:1299,y:964,t:1527264794321};\\\", \\\"{x:1300,y:964,t:1527264794338};\\\", \\\"{x:1300,y:965,t:1527264794355};\\\", \\\"{x:1301,y:965,t:1527264794390};\\\", \\\"{x:1302,y:966,t:1527264794406};\\\", \\\"{x:1303,y:966,t:1527264794422};\\\", \\\"{x:1305,y:967,t:1527264794438};\\\", \\\"{x:1306,y:967,t:1527264794454};\\\", \\\"{x:1307,y:967,t:1527264794565};\\\", \\\"{x:1308,y:968,t:1527264794719};\\\", \\\"{x:1309,y:968,t:1527264794726};\\\", \\\"{x:1310,y:968,t:1527264794739};\\\", \\\"{x:1310,y:969,t:1527264794755};\\\", \\\"{x:1311,y:969,t:1527264794782};\\\", \\\"{x:1312,y:969,t:1527264794814};\\\", \\\"{x:1313,y:969,t:1527264795246};\\\", \\\"{x:1314,y:969,t:1527264795262};\\\", \\\"{x:1315,y:969,t:1527264795278};\\\", \\\"{x:1316,y:969,t:1527264795303};\\\", \\\"{x:1316,y:968,t:1527264795990};\\\", \\\"{x:1316,y:964,t:1527264796007};\\\", \\\"{x:1316,y:959,t:1527264796023};\\\", \\\"{x:1316,y:955,t:1527264796041};\\\", \\\"{x:1316,y:952,t:1527264796057};\\\", \\\"{x:1316,y:950,t:1527264796073};\\\", \\\"{x:1316,y:949,t:1527264796090};\\\", \\\"{x:1316,y:947,t:1527264796107};\\\", \\\"{x:1316,y:946,t:1527264796270};\\\", \\\"{x:1316,y:944,t:1527264796294};\\\", \\\"{x:1316,y:943,t:1527264796326};\\\", \\\"{x:1316,y:941,t:1527264796343};\\\", \\\"{x:1316,y:940,t:1527264796471};\\\", \\\"{x:1316,y:941,t:1527264796533};\\\", \\\"{x:1316,y:943,t:1527264796541};\\\", \\\"{x:1315,y:945,t:1527264796556};\\\", \\\"{x:1314,y:951,t:1527264796573};\\\", \\\"{x:1314,y:953,t:1527264796591};\\\", \\\"{x:1313,y:954,t:1527264796606};\\\", \\\"{x:1313,y:951,t:1527264796823};\\\", \\\"{x:1311,y:946,t:1527264796830};\\\", \\\"{x:1310,y:943,t:1527264796840};\\\", \\\"{x:1309,y:930,t:1527264796858};\\\", \\\"{x:1307,y:913,t:1527264796873};\\\", \\\"{x:1303,y:893,t:1527264796891};\\\", \\\"{x:1300,y:869,t:1527264796908};\\\", \\\"{x:1296,y:842,t:1527264796924};\\\", \\\"{x:1291,y:816,t:1527264796941};\\\", \\\"{x:1289,y:789,t:1527264796958};\\\", \\\"{x:1288,y:776,t:1527264796974};\\\", \\\"{x:1288,y:761,t:1527264796991};\\\", \\\"{x:1288,y:746,t:1527264797007};\\\", \\\"{x:1288,y:733,t:1527264797024};\\\", \\\"{x:1290,y:718,t:1527264797041};\\\", \\\"{x:1291,y:705,t:1527264797058};\\\", \\\"{x:1293,y:691,t:1527264797074};\\\", \\\"{x:1296,y:673,t:1527264797092};\\\", \\\"{x:1301,y:652,t:1527264797108};\\\", \\\"{x:1304,y:634,t:1527264797125};\\\", \\\"{x:1308,y:613,t:1527264797142};\\\", \\\"{x:1313,y:585,t:1527264797158};\\\", \\\"{x:1315,y:567,t:1527264797176};\\\", \\\"{x:1318,y:549,t:1527264797192};\\\", \\\"{x:1318,y:535,t:1527264797208};\\\", \\\"{x:1318,y:527,t:1527264797225};\\\", \\\"{x:1318,y:520,t:1527264797241};\\\", \\\"{x:1318,y:518,t:1527264797258};\\\", \\\"{x:1318,y:514,t:1527264797276};\\\", \\\"{x:1313,y:508,t:1527264797292};\\\", \\\"{x:1312,y:504,t:1527264797308};\\\", \\\"{x:1309,y:501,t:1527264797325};\\\", \\\"{x:1307,y:498,t:1527264797341};\\\", \\\"{x:1306,y:496,t:1527264797358};\\\", \\\"{x:1305,y:496,t:1527264797375};\\\", \\\"{x:1304,y:495,t:1527264797414};\\\", \\\"{x:1303,y:495,t:1527264797855};\\\", \\\"{x:1301,y:495,t:1527264797895};\\\", \\\"{x:1300,y:494,t:1527264798055};\\\", \\\"{x:1300,y:493,t:1527264798110};\\\", \\\"{x:1299,y:493,t:1527264798141};\\\", \\\"{x:1298,y:492,t:1527264798165};\\\", \\\"{x:1300,y:492,t:1527264810950};\\\", \\\"{x:1301,y:493,t:1527264810958};\\\", \\\"{x:1301,y:497,t:1527264810974};\\\", \\\"{x:1304,y:500,t:1527264810991};\\\", \\\"{x:1305,y:502,t:1527264811008};\\\", \\\"{x:1308,y:505,t:1527264811024};\\\", \\\"{x:1311,y:507,t:1527264811041};\\\", \\\"{x:1315,y:510,t:1527264811058};\\\", \\\"{x:1319,y:512,t:1527264811074};\\\", \\\"{x:1321,y:513,t:1527264811091};\\\", \\\"{x:1324,y:515,t:1527264811108};\\\", \\\"{x:1325,y:515,t:1527264811124};\\\", \\\"{x:1328,y:516,t:1527264811141};\\\", \\\"{x:1336,y:519,t:1527264811158};\\\", \\\"{x:1340,y:520,t:1527264811174};\\\", \\\"{x:1344,y:520,t:1527264811191};\\\", \\\"{x:1347,y:522,t:1527264811208};\\\", \\\"{x:1355,y:523,t:1527264811225};\\\", \\\"{x:1369,y:524,t:1527264811240};\\\", \\\"{x:1387,y:527,t:1527264811257};\\\", \\\"{x:1408,y:529,t:1527264811275};\\\", \\\"{x:1424,y:529,t:1527264811290};\\\", \\\"{x:1438,y:529,t:1527264811307};\\\", \\\"{x:1453,y:529,t:1527264811324};\\\", \\\"{x:1467,y:529,t:1527264811340};\\\", \\\"{x:1477,y:528,t:1527264811357};\\\", \\\"{x:1481,y:526,t:1527264811374};\\\", \\\"{x:1485,y:523,t:1527264811390};\\\", \\\"{x:1489,y:522,t:1527264811408};\\\", \\\"{x:1492,y:520,t:1527264811424};\\\", \\\"{x:1496,y:519,t:1527264811440};\\\", \\\"{x:1503,y:517,t:1527264811458};\\\", \\\"{x:1510,y:516,t:1527264811475};\\\", \\\"{x:1518,y:516,t:1527264811492};\\\", \\\"{x:1531,y:516,t:1527264811508};\\\", \\\"{x:1552,y:516,t:1527264811524};\\\", \\\"{x:1607,y:517,t:1527264811541};\\\", \\\"{x:1630,y:520,t:1527264811558};\\\", \\\"{x:1639,y:522,t:1527264811575};\\\", \\\"{x:1646,y:522,t:1527264811592};\\\", \\\"{x:1651,y:524,t:1527264811608};\\\", \\\"{x:1652,y:524,t:1527264811624};\\\", \\\"{x:1652,y:523,t:1527264811790};\\\", \\\"{x:1652,y:522,t:1527264811798};\\\", \\\"{x:1649,y:520,t:1527264811809};\\\", \\\"{x:1645,y:518,t:1527264811825};\\\", \\\"{x:1638,y:516,t:1527264811842};\\\", \\\"{x:1632,y:513,t:1527264811859};\\\", \\\"{x:1629,y:511,t:1527264811875};\\\", \\\"{x:1627,y:511,t:1527264811894};\\\", \\\"{x:1626,y:511,t:1527264811909};\\\", \\\"{x:1625,y:510,t:1527264811925};\\\", \\\"{x:1625,y:511,t:1527264811982};\\\", \\\"{x:1625,y:515,t:1527264811992};\\\", \\\"{x:1625,y:523,t:1527264812009};\\\", \\\"{x:1629,y:537,t:1527264812025};\\\", \\\"{x:1636,y:554,t:1527264812041};\\\", \\\"{x:1645,y:572,t:1527264812058};\\\", \\\"{x:1652,y:594,t:1527264812075};\\\", \\\"{x:1658,y:615,t:1527264812091};\\\", \\\"{x:1662,y:639,t:1527264812109};\\\", \\\"{x:1667,y:677,t:1527264812125};\\\", \\\"{x:1667,y:697,t:1527264812141};\\\", \\\"{x:1667,y:719,t:1527264812159};\\\", \\\"{x:1667,y:744,t:1527264812175};\\\", \\\"{x:1667,y:764,t:1527264812191};\\\", \\\"{x:1664,y:787,t:1527264812209};\\\", \\\"{x:1659,y:810,t:1527264812226};\\\", \\\"{x:1652,y:831,t:1527264812241};\\\", \\\"{x:1646,y:847,t:1527264812258};\\\", \\\"{x:1639,y:863,t:1527264812276};\\\", \\\"{x:1632,y:876,t:1527264812292};\\\", \\\"{x:1627,y:889,t:1527264812308};\\\", \\\"{x:1624,y:904,t:1527264812325};\\\", \\\"{x:1620,y:910,t:1527264812342};\\\", \\\"{x:1619,y:913,t:1527264812358};\\\", \\\"{x:1618,y:915,t:1527264812376};\\\", \\\"{x:1617,y:920,t:1527264812392};\\\", \\\"{x:1617,y:922,t:1527264812408};\\\", \\\"{x:1617,y:926,t:1527264812425};\\\", \\\"{x:1617,y:931,t:1527264812443};\\\", \\\"{x:1617,y:933,t:1527264812458};\\\", \\\"{x:1617,y:936,t:1527264812475};\\\", \\\"{x:1617,y:938,t:1527264812492};\\\", \\\"{x:1618,y:941,t:1527264812509};\\\", \\\"{x:1620,y:945,t:1527264812525};\\\", \\\"{x:1621,y:946,t:1527264812542};\\\", \\\"{x:1621,y:947,t:1527264812559};\\\", \\\"{x:1622,y:949,t:1527264812576};\\\", \\\"{x:1624,y:950,t:1527264812593};\\\", \\\"{x:1624,y:952,t:1527264812609};\\\", \\\"{x:1627,y:955,t:1527264812626};\\\", \\\"{x:1628,y:958,t:1527264812643};\\\", \\\"{x:1629,y:960,t:1527264812659};\\\", \\\"{x:1631,y:962,t:1527264812676};\\\", \\\"{x:1633,y:966,t:1527264812693};\\\", \\\"{x:1637,y:970,t:1527264812709};\\\", \\\"{x:1637,y:971,t:1527264812735};\\\", \\\"{x:1638,y:972,t:1527264812742};\\\", \\\"{x:1639,y:972,t:1527264812774};\\\", \\\"{x:1640,y:972,t:1527264812782};\\\", \\\"{x:1642,y:972,t:1527264812806};\\\", \\\"{x:1643,y:972,t:1527264812830};\\\", \\\"{x:1645,y:972,t:1527264812843};\\\", \\\"{x:1651,y:971,t:1527264812859};\\\", \\\"{x:1663,y:967,t:1527264812876};\\\", \\\"{x:1680,y:962,t:1527264812893};\\\", \\\"{x:1701,y:958,t:1527264812909};\\\", \\\"{x:1714,y:957,t:1527264812925};\\\", \\\"{x:1725,y:956,t:1527264812942};\\\", \\\"{x:1732,y:955,t:1527264812959};\\\", \\\"{x:1733,y:955,t:1527264812981};\\\", \\\"{x:1735,y:955,t:1527264813350};\\\", \\\"{x:1736,y:955,t:1527264813360};\\\", \\\"{x:1737,y:956,t:1527264813377};\\\", \\\"{x:1739,y:958,t:1527264813394};\\\", \\\"{x:1741,y:960,t:1527264813410};\\\", \\\"{x:1744,y:963,t:1527264813427};\\\", \\\"{x:1745,y:963,t:1527264813478};\\\", \\\"{x:1746,y:964,t:1527264813534};\\\", \\\"{x:1746,y:965,t:1527264813661};\\\", \\\"{x:1747,y:965,t:1527264813677};\\\", \\\"{x:1748,y:966,t:1527264813791};\\\", \\\"{x:1749,y:966,t:1527264813830};\\\", \\\"{x:1749,y:967,t:1527264813844};\\\", \\\"{x:1751,y:967,t:1527264813861};\\\", \\\"{x:1752,y:967,t:1527264813877};\\\", \\\"{x:1754,y:969,t:1527264813895};\\\", \\\"{x:1755,y:969,t:1527264813911};\\\", \\\"{x:1757,y:969,t:1527264813982};\\\", \\\"{x:1757,y:970,t:1527264813998};\\\", \\\"{x:1758,y:970,t:1527264814011};\\\", \\\"{x:1761,y:971,t:1527264814028};\\\", \\\"{x:1762,y:972,t:1527264814044};\\\", \\\"{x:1764,y:973,t:1527264814061};\\\", \\\"{x:1765,y:973,t:1527264814085};\\\", \\\"{x:1767,y:973,t:1527264814118};\\\", \\\"{x:1768,y:973,t:1527264814128};\\\", \\\"{x:1770,y:973,t:1527264814145};\\\", \\\"{x:1771,y:973,t:1527264814161};\\\", \\\"{x:1773,y:973,t:1527264814178};\\\", \\\"{x:1774,y:972,t:1527264814195};\\\", \\\"{x:1776,y:971,t:1527264814211};\\\", \\\"{x:1778,y:971,t:1527264814228};\\\", \\\"{x:1780,y:969,t:1527264814245};\\\", \\\"{x:1784,y:968,t:1527264814261};\\\", \\\"{x:1786,y:967,t:1527264814277};\\\", \\\"{x:1785,y:966,t:1527264816717};\\\", \\\"{x:1784,y:966,t:1527264816733};\\\", \\\"{x:1784,y:965,t:1527264816746};\\\", \\\"{x:1783,y:965,t:1527264816763};\\\", \\\"{x:1780,y:964,t:1527264818046};\\\", \\\"{x:1778,y:961,t:1527264818054};\\\", \\\"{x:1777,y:959,t:1527264818066};\\\", \\\"{x:1775,y:957,t:1527264818082};\\\", \\\"{x:1774,y:954,t:1527264818098};\\\", \\\"{x:1773,y:953,t:1527264818115};\\\", \\\"{x:1772,y:952,t:1527264818131};\\\", \\\"{x:1771,y:950,t:1527264818148};\\\", \\\"{x:1771,y:948,t:1527264818164};\\\", \\\"{x:1771,y:946,t:1527264818181};\\\", \\\"{x:1770,y:945,t:1527264818199};\\\", \\\"{x:1770,y:944,t:1527264818216};\\\", \\\"{x:1770,y:942,t:1527264818231};\\\", \\\"{x:1770,y:941,t:1527264818248};\\\", \\\"{x:1770,y:939,t:1527264818266};\\\", \\\"{x:1770,y:937,t:1527264818282};\\\", \\\"{x:1770,y:936,t:1527264818299};\\\", \\\"{x:1770,y:932,t:1527264818316};\\\", \\\"{x:1770,y:926,t:1527264818332};\\\", \\\"{x:1770,y:917,t:1527264818349};\\\", \\\"{x:1770,y:913,t:1527264818365};\\\", \\\"{x:1770,y:902,t:1527264818383};\\\", \\\"{x:1770,y:889,t:1527264818398};\\\", \\\"{x:1770,y:880,t:1527264818415};\\\", \\\"{x:1770,y:872,t:1527264818432};\\\", \\\"{x:1770,y:870,t:1527264818448};\\\", \\\"{x:1770,y:866,t:1527264818466};\\\", \\\"{x:1770,y:864,t:1527264818482};\\\", \\\"{x:1770,y:860,t:1527264818499};\\\", \\\"{x:1770,y:859,t:1527264818516};\\\", \\\"{x:1770,y:857,t:1527264818532};\\\", \\\"{x:1770,y:856,t:1527264818549};\\\", \\\"{x:1770,y:851,t:1527264818566};\\\", \\\"{x:1770,y:850,t:1527264818590};\\\", \\\"{x:1770,y:848,t:1527264818621};\\\", \\\"{x:1770,y:847,t:1527264818638};\\\", \\\"{x:1770,y:845,t:1527264818649};\\\", \\\"{x:1770,y:844,t:1527264818666};\\\", \\\"{x:1770,y:841,t:1527264818683};\\\", \\\"{x:1770,y:840,t:1527264818700};\\\", \\\"{x:1770,y:837,t:1527264818716};\\\", \\\"{x:1770,y:834,t:1527264818733};\\\", \\\"{x:1770,y:830,t:1527264818750};\\\", \\\"{x:1770,y:829,t:1527264818767};\\\", \\\"{x:1770,y:828,t:1527264818783};\\\", \\\"{x:1770,y:827,t:1527264819190};\\\", \\\"{x:1770,y:826,t:1527264819229};\\\", \\\"{x:1771,y:826,t:1527264819246};\\\", \\\"{x:1771,y:824,t:1527264819261};\\\", \\\"{x:1771,y:822,t:1527264819270};\\\", \\\"{x:1771,y:820,t:1527264819286};\\\", \\\"{x:1769,y:817,t:1527264819300};\\\", \\\"{x:1765,y:808,t:1527264819317};\\\", \\\"{x:1764,y:801,t:1527264819334};\\\", \\\"{x:1764,y:795,t:1527264819350};\\\", \\\"{x:1763,y:788,t:1527264819367};\\\", \\\"{x:1763,y:781,t:1527264819385};\\\", \\\"{x:1763,y:773,t:1527264819400};\\\", \\\"{x:1763,y:765,t:1527264819418};\\\", \\\"{x:1763,y:753,t:1527264819435};\\\", \\\"{x:1763,y:741,t:1527264819450};\\\", \\\"{x:1763,y:734,t:1527264819467};\\\", \\\"{x:1763,y:731,t:1527264819485};\\\", \\\"{x:1763,y:724,t:1527264819501};\\\", \\\"{x:1764,y:719,t:1527264819517};\\\", \\\"{x:1765,y:712,t:1527264819534};\\\", \\\"{x:1765,y:707,t:1527264819551};\\\", \\\"{x:1765,y:700,t:1527264819567};\\\", \\\"{x:1765,y:696,t:1527264819585};\\\", \\\"{x:1765,y:689,t:1527264819601};\\\", \\\"{x:1765,y:681,t:1527264819617};\\\", \\\"{x:1766,y:672,t:1527264819634};\\\", \\\"{x:1767,y:661,t:1527264819652};\\\", \\\"{x:1770,y:654,t:1527264819667};\\\", \\\"{x:1771,y:648,t:1527264819684};\\\", \\\"{x:1771,y:641,t:1527264819701};\\\", \\\"{x:1771,y:638,t:1527264819718};\\\", \\\"{x:1773,y:633,t:1527264819734};\\\", \\\"{x:1773,y:630,t:1527264819751};\\\", \\\"{x:1773,y:628,t:1527264819767};\\\", \\\"{x:1773,y:626,t:1527264819784};\\\", \\\"{x:1773,y:624,t:1527264819801};\\\", \\\"{x:1773,y:622,t:1527264819817};\\\", \\\"{x:1774,y:620,t:1527264819838};\\\", \\\"{x:1774,y:619,t:1527264819851};\\\", \\\"{x:1774,y:618,t:1527264819867};\\\", \\\"{x:1774,y:617,t:1527264819884};\\\", \\\"{x:1774,y:615,t:1527264819901};\\\", \\\"{x:1774,y:611,t:1527264819917};\\\", \\\"{x:1777,y:603,t:1527264819934};\\\", \\\"{x:1777,y:598,t:1527264819951};\\\", \\\"{x:1777,y:592,t:1527264819969};\\\", \\\"{x:1778,y:589,t:1527264819985};\\\", \\\"{x:1778,y:586,t:1527264820001};\\\", \\\"{x:1778,y:585,t:1527264820018};\\\", \\\"{x:1778,y:583,t:1527264820034};\\\", \\\"{x:1778,y:579,t:1527264820051};\\\", \\\"{x:1778,y:575,t:1527264820068};\\\", \\\"{x:1778,y:570,t:1527264820084};\\\", \\\"{x:1780,y:566,t:1527264820101};\\\", \\\"{x:1780,y:565,t:1527264820118};\\\", \\\"{x:1780,y:564,t:1527264820135};\\\", \\\"{x:1780,y:563,t:1527264820152};\\\", \\\"{x:1780,y:562,t:1527264820169};\\\", \\\"{x:1780,y:560,t:1527264820185};\\\", \\\"{x:1780,y:557,t:1527264820202};\\\", \\\"{x:1780,y:555,t:1527264820218};\\\", \\\"{x:1780,y:554,t:1527264820236};\\\", \\\"{x:1781,y:551,t:1527264820251};\\\", \\\"{x:1781,y:546,t:1527264820269};\\\", \\\"{x:1781,y:541,t:1527264820285};\\\", \\\"{x:1781,y:537,t:1527264820301};\\\", \\\"{x:1781,y:530,t:1527264820318};\\\", \\\"{x:1781,y:528,t:1527264820335};\\\", \\\"{x:1781,y:526,t:1527264820352};\\\", \\\"{x:1781,y:525,t:1527264820368};\\\", \\\"{x:1781,y:524,t:1527264820384};\\\", \\\"{x:1781,y:523,t:1527264820401};\\\", \\\"{x:1781,y:521,t:1527264820417};\\\", \\\"{x:1781,y:518,t:1527264820435};\\\", \\\"{x:1781,y:516,t:1527264820452};\\\", \\\"{x:1781,y:515,t:1527264820468};\\\", \\\"{x:1781,y:514,t:1527264820485};\\\", \\\"{x:1781,y:513,t:1527264820509};\\\", \\\"{x:1781,y:512,t:1527264820541};\\\", \\\"{x:1781,y:511,t:1527264820557};\\\", \\\"{x:1781,y:510,t:1527264820568};\\\", \\\"{x:1781,y:508,t:1527264820585};\\\", \\\"{x:1781,y:507,t:1527264820614};\\\", \\\"{x:1781,y:506,t:1527264820621};\\\", \\\"{x:1781,y:505,t:1527264820636};\\\", \\\"{x:1781,y:504,t:1527264820652};\\\", \\\"{x:1781,y:502,t:1527264820668};\\\", \\\"{x:1781,y:500,t:1527264820685};\\\", \\\"{x:1781,y:499,t:1527264820701};\\\", \\\"{x:1781,y:498,t:1527264820765};\\\", \\\"{x:1780,y:498,t:1527264821591};\\\", \\\"{x:1778,y:499,t:1527264821604};\\\", \\\"{x:1773,y:500,t:1527264821619};\\\", \\\"{x:1764,y:504,t:1527264821636};\\\", \\\"{x:1749,y:508,t:1527264821653};\\\", \\\"{x:1718,y:511,t:1527264821670};\\\", \\\"{x:1693,y:511,t:1527264821686};\\\", \\\"{x:1670,y:514,t:1527264821704};\\\", \\\"{x:1649,y:514,t:1527264821720};\\\", \\\"{x:1636,y:514,t:1527264821736};\\\", \\\"{x:1630,y:514,t:1527264821753};\\\", \\\"{x:1628,y:514,t:1527264821814};\\\", \\\"{x:1626,y:514,t:1527264821830};\\\", \\\"{x:1625,y:514,t:1527264821838};\\\", \\\"{x:1624,y:513,t:1527264821854};\\\", \\\"{x:1616,y:510,t:1527264821870};\\\", \\\"{x:1605,y:505,t:1527264821886};\\\", \\\"{x:1599,y:504,t:1527264821903};\\\", \\\"{x:1589,y:501,t:1527264821921};\\\", \\\"{x:1578,y:499,t:1527264821937};\\\", \\\"{x:1565,y:496,t:1527264821953};\\\", \\\"{x:1561,y:496,t:1527264821970};\\\", \\\"{x:1559,y:496,t:1527264822038};\\\", \\\"{x:1559,y:495,t:1527264822054};\\\", \\\"{x:1563,y:495,t:1527264822189};\\\", \\\"{x:1566,y:496,t:1527264822202};\\\", \\\"{x:1575,y:499,t:1527264822220};\\\", \\\"{x:1580,y:501,t:1527264822237};\\\", \\\"{x:1586,y:504,t:1527264822253};\\\", \\\"{x:1587,y:505,t:1527264822270};\\\", \\\"{x:1587,y:504,t:1527264822414};\\\", \\\"{x:1587,y:503,t:1527264822429};\\\", \\\"{x:1586,y:503,t:1527264822438};\\\", \\\"{x:1585,y:503,t:1527264822454};\\\", \\\"{x:1584,y:502,t:1527264822654};\\\", \\\"{x:1583,y:502,t:1527264822678};\\\", \\\"{x:1582,y:502,t:1527264822687};\\\", \\\"{x:1581,y:502,t:1527264822704};\\\", \\\"{x:1580,y:502,t:1527264823790};\\\", \\\"{x:1577,y:501,t:1527264825454};\\\", \\\"{x:1574,y:501,t:1527264825462};\\\", \\\"{x:1573,y:500,t:1527264825475};\\\", \\\"{x:1566,y:500,t:1527264825490};\\\", \\\"{x:1556,y:497,t:1527264825507};\\\", \\\"{x:1547,y:497,t:1527264825525};\\\", \\\"{x:1538,y:496,t:1527264825540};\\\", \\\"{x:1531,y:496,t:1527264825557};\\\", \\\"{x:1528,y:500,t:1527264825943};\\\", \\\"{x:1526,y:521,t:1527264825958};\\\", \\\"{x:1526,y:541,t:1527264825975};\\\", \\\"{x:1526,y:562,t:1527264825992};\\\", \\\"{x:1523,y:587,t:1527264826009};\\\", \\\"{x:1519,y:614,t:1527264826024};\\\", \\\"{x:1508,y:652,t:1527264826042};\\\", \\\"{x:1493,y:700,t:1527264826059};\\\", \\\"{x:1466,y:751,t:1527264826074};\\\", \\\"{x:1437,y:800,t:1527264826092};\\\", \\\"{x:1410,y:837,t:1527264826108};\\\", \\\"{x:1391,y:865,t:1527264826125};\\\", \\\"{x:1374,y:898,t:1527264826141};\\\", \\\"{x:1362,y:923,t:1527264826158};\\\", \\\"{x:1348,y:949,t:1527264826175};\\\", \\\"{x:1335,y:970,t:1527264826191};\\\", \\\"{x:1323,y:991,t:1527264826208};\\\", \\\"{x:1313,y:1014,t:1527264826225};\\\", \\\"{x:1308,y:1027,t:1527264826241};\\\", \\\"{x:1303,y:1039,t:1527264826258};\\\", \\\"{x:1302,y:1044,t:1527264826275};\\\", \\\"{x:1302,y:1048,t:1527264826290};\\\", \\\"{x:1299,y:1053,t:1527264826308};\\\", \\\"{x:1298,y:1056,t:1527264826324};\\\", \\\"{x:1297,y:1058,t:1527264826356};\\\", \\\"{x:1297,y:1057,t:1527264826430};\\\", \\\"{x:1297,y:1052,t:1527264826443};\\\", \\\"{x:1297,y:1037,t:1527264826458};\\\", \\\"{x:1298,y:1016,t:1527264826475};\\\", \\\"{x:1303,y:999,t:1527264826492};\\\", \\\"{x:1307,y:986,t:1527264826508};\\\", \\\"{x:1310,y:975,t:1527264826524};\\\", \\\"{x:1310,y:972,t:1527264826542};\\\", \\\"{x:1312,y:968,t:1527264826558};\\\", \\\"{x:1312,y:967,t:1527264826597};\\\", \\\"{x:1312,y:966,t:1527264826609};\\\", \\\"{x:1312,y:965,t:1527264826630};\\\", \\\"{x:1313,y:964,t:1527264826686};\\\", \\\"{x:1314,y:964,t:1527264826694};\\\", \\\"{x:1316,y:964,t:1527264828381};\\\", \\\"{x:1317,y:964,t:1527264828394};\\\", \\\"{x:1324,y:967,t:1527264828410};\\\", \\\"{x:1331,y:970,t:1527264828427};\\\", \\\"{x:1337,y:972,t:1527264828444};\\\", \\\"{x:1340,y:974,t:1527264828460};\\\", \\\"{x:1341,y:974,t:1527264828477};\\\", \\\"{x:1342,y:974,t:1527264828509};\\\", \\\"{x:1344,y:975,t:1527264828678};\\\", \\\"{x:1345,y:975,t:1527264828694};\\\", \\\"{x:1347,y:976,t:1527264828712};\\\", \\\"{x:1348,y:977,t:1527264828728};\\\", \\\"{x:1349,y:977,t:1527264828950};\\\", \\\"{x:1349,y:973,t:1527264828962};\\\", \\\"{x:1351,y:966,t:1527264828979};\\\", \\\"{x:1353,y:960,t:1527264828994};\\\", \\\"{x:1354,y:959,t:1527264829013};\\\", \\\"{x:1354,y:958,t:1527264829365};\\\", \\\"{x:1352,y:958,t:1527264829389};\\\", \\\"{x:1351,y:958,t:1527264829397};\\\", \\\"{x:1349,y:958,t:1527264829411};\\\", \\\"{x:1348,y:958,t:1527264829429};\\\", \\\"{x:1346,y:958,t:1527264829462};\\\", \\\"{x:1346,y:960,t:1527264830022};\\\", \\\"{x:1349,y:962,t:1527264830030};\\\", \\\"{x:1365,y:969,t:1527264830046};\\\", \\\"{x:1382,y:973,t:1527264830063};\\\", \\\"{x:1404,y:976,t:1527264830079};\\\", \\\"{x:1430,y:977,t:1527264830096};\\\", \\\"{x:1454,y:977,t:1527264830112};\\\", \\\"{x:1476,y:977,t:1527264830130};\\\", \\\"{x:1504,y:977,t:1527264830146};\\\", \\\"{x:1532,y:977,t:1527264830162};\\\", \\\"{x:1568,y:977,t:1527264830180};\\\", \\\"{x:1602,y:977,t:1527264830196};\\\", \\\"{x:1629,y:977,t:1527264830213};\\\", \\\"{x:1665,y:977,t:1527264830229};\\\", \\\"{x:1682,y:975,t:1527264830246};\\\", \\\"{x:1693,y:972,t:1527264830263};\\\", \\\"{x:1701,y:972,t:1527264830279};\\\", \\\"{x:1705,y:972,t:1527264830297};\\\", \\\"{x:1708,y:972,t:1527264830313};\\\", \\\"{x:1709,y:972,t:1527264830329};\\\", \\\"{x:1710,y:972,t:1527264830405};\\\", \\\"{x:1712,y:972,t:1527264830413};\\\", \\\"{x:1723,y:972,t:1527264830429};\\\", \\\"{x:1729,y:972,t:1527264830446};\\\", \\\"{x:1734,y:972,t:1527264830463};\\\", \\\"{x:1740,y:971,t:1527264830479};\\\", \\\"{x:1743,y:971,t:1527264830496};\\\", \\\"{x:1744,y:971,t:1527264830513};\\\", \\\"{x:1744,y:970,t:1527264830662};\\\", \\\"{x:1742,y:969,t:1527264830669};\\\", \\\"{x:1739,y:968,t:1527264830681};\\\", \\\"{x:1729,y:967,t:1527264830696};\\\", \\\"{x:1714,y:965,t:1527264830714};\\\", \\\"{x:1696,y:963,t:1527264830730};\\\", \\\"{x:1679,y:961,t:1527264830746};\\\", \\\"{x:1663,y:958,t:1527264830763};\\\", \\\"{x:1649,y:956,t:1527264830781};\\\", \\\"{x:1638,y:954,t:1527264830796};\\\", \\\"{x:1626,y:954,t:1527264830813};\\\", \\\"{x:1622,y:954,t:1527264830831};\\\", \\\"{x:1618,y:954,t:1527264830846};\\\", \\\"{x:1611,y:954,t:1527264830863};\\\", \\\"{x:1609,y:954,t:1527264830881};\\\", \\\"{x:1605,y:954,t:1527264830897};\\\", \\\"{x:1605,y:955,t:1527264830914};\\\", \\\"{x:1603,y:957,t:1527264830930};\\\", \\\"{x:1602,y:957,t:1527264830947};\\\", \\\"{x:1600,y:959,t:1527264830964};\\\", \\\"{x:1597,y:960,t:1527264830981};\\\", \\\"{x:1588,y:962,t:1527264830998};\\\", \\\"{x:1582,y:962,t:1527264831013};\\\", \\\"{x:1572,y:962,t:1527264831031};\\\", \\\"{x:1560,y:962,t:1527264831048};\\\", \\\"{x:1549,y:962,t:1527264831064};\\\", \\\"{x:1536,y:962,t:1527264831081};\\\", \\\"{x:1532,y:962,t:1527264831098};\\\", \\\"{x:1529,y:962,t:1527264831114};\\\", \\\"{x:1532,y:962,t:1527264831278};\\\", \\\"{x:1534,y:960,t:1527264831286};\\\", \\\"{x:1536,y:960,t:1527264831298};\\\", \\\"{x:1537,y:956,t:1527264831315};\\\", \\\"{x:1540,y:947,t:1527264831331};\\\", \\\"{x:1540,y:935,t:1527264831348};\\\", \\\"{x:1540,y:926,t:1527264831365};\\\", \\\"{x:1540,y:917,t:1527264831381};\\\", \\\"{x:1534,y:887,t:1527264831397};\\\", \\\"{x:1530,y:862,t:1527264831415};\\\", \\\"{x:1523,y:837,t:1527264831431};\\\", \\\"{x:1521,y:811,t:1527264831448};\\\", \\\"{x:1517,y:792,t:1527264831465};\\\", \\\"{x:1517,y:773,t:1527264831481};\\\", \\\"{x:1516,y:758,t:1527264831497};\\\", \\\"{x:1513,y:743,t:1527264831515};\\\", \\\"{x:1512,y:731,t:1527264831531};\\\", \\\"{x:1510,y:717,t:1527264831548};\\\", \\\"{x:1508,y:703,t:1527264831565};\\\", \\\"{x:1508,y:690,t:1527264831582};\\\", \\\"{x:1508,y:683,t:1527264831598};\\\", \\\"{x:1510,y:678,t:1527264831615};\\\", \\\"{x:1513,y:672,t:1527264831632};\\\", \\\"{x:1516,y:665,t:1527264831648};\\\", \\\"{x:1520,y:657,t:1527264831665};\\\", \\\"{x:1523,y:651,t:1527264831682};\\\", \\\"{x:1525,y:647,t:1527264831697};\\\", \\\"{x:1528,y:642,t:1527264831715};\\\", \\\"{x:1529,y:640,t:1527264831732};\\\", \\\"{x:1530,y:636,t:1527264831748};\\\", \\\"{x:1532,y:631,t:1527264831765};\\\", \\\"{x:1534,y:621,t:1527264831782};\\\", \\\"{x:1536,y:615,t:1527264831798};\\\", \\\"{x:1539,y:607,t:1527264831815};\\\", \\\"{x:1540,y:601,t:1527264831832};\\\", \\\"{x:1544,y:592,t:1527264831848};\\\", \\\"{x:1545,y:585,t:1527264831865};\\\", \\\"{x:1546,y:579,t:1527264831882};\\\", \\\"{x:1548,y:570,t:1527264831898};\\\", \\\"{x:1549,y:561,t:1527264831915};\\\", \\\"{x:1549,y:555,t:1527264831932};\\\", \\\"{x:1549,y:552,t:1527264831949};\\\", \\\"{x:1549,y:551,t:1527264831964};\\\", \\\"{x:1549,y:549,t:1527264831998};\\\", \\\"{x:1550,y:550,t:1527264832742};\\\", \\\"{x:1551,y:551,t:1527264832750};\\\", \\\"{x:1552,y:553,t:1527264832766};\\\", \\\"{x:1552,y:554,t:1527264832783};\\\", \\\"{x:1553,y:555,t:1527264832800};\\\", \\\"{x:1554,y:557,t:1527264832816};\\\", \\\"{x:1554,y:558,t:1527264833078};\\\", \\\"{x:1554,y:559,t:1527264833253};\\\", \\\"{x:1552,y:561,t:1527264833277};\\\", \\\"{x:1551,y:561,t:1527264833301};\\\", \\\"{x:1550,y:561,t:1527264833316};\\\", \\\"{x:1548,y:562,t:1527264833332};\\\", \\\"{x:1547,y:563,t:1527264833349};\\\", \\\"{x:1546,y:564,t:1527264833367};\\\", \\\"{x:1545,y:565,t:1527264833389};\\\", \\\"{x:1544,y:565,t:1527264833405};\\\", \\\"{x:1543,y:567,t:1527264833416};\\\", \\\"{x:1542,y:567,t:1527264833434};\\\", \\\"{x:1542,y:568,t:1527264833453};\\\", \\\"{x:1542,y:567,t:1527264834689};\\\", \\\"{x:1543,y:565,t:1527264834705};\\\", \\\"{x:1544,y:564,t:1527264834721};\\\", \\\"{x:1545,y:564,t:1527264834737};\\\", \\\"{x:1540,y:562,t:1527264874193};\\\", \\\"{x:1531,y:556,t:1527264874201};\\\", \\\"{x:1509,y:547,t:1527264874217};\\\", \\\"{x:1489,y:544,t:1527264874234};\\\", \\\"{x:1480,y:544,t:1527264874251};\\\", \\\"{x:1479,y:544,t:1527264874267};\\\", \\\"{x:1478,y:544,t:1527264874284};\\\", \\\"{x:1477,y:544,t:1527264874328};\\\", \\\"{x:1475,y:547,t:1527264874336};\\\", \\\"{x:1469,y:553,t:1527264874351};\\\", \\\"{x:1442,y:563,t:1527264874368};\\\", \\\"{x:1391,y:572,t:1527264874385};\\\", \\\"{x:1284,y:574,t:1527264874400};\\\", \\\"{x:1191,y:581,t:1527264874417};\\\", \\\"{x:1073,y:590,t:1527264874434};\\\", \\\"{x:926,y:594,t:1527264874451};\\\", \\\"{x:791,y:594,t:1527264874467};\\\", \\\"{x:683,y:594,t:1527264874483};\\\", \\\"{x:648,y:594,t:1527264874500};\\\", \\\"{x:626,y:594,t:1527264874517};\\\", \\\"{x:610,y:594,t:1527264874533};\\\", \\\"{x:587,y:594,t:1527264874551};\\\", \\\"{x:541,y:573,t:1527264874568};\\\", \\\"{x:534,y:567,t:1527264874583};\\\", \\\"{x:535,y:567,t:1527264874615};\\\", \\\"{x:539,y:568,t:1527264874623};\\\", \\\"{x:543,y:575,t:1527264874634};\\\", \\\"{x:544,y:596,t:1527264874651};\\\", \\\"{x:544,y:612,t:1527264874667};\\\", \\\"{x:542,y:621,t:1527264874685};\\\", \\\"{x:543,y:612,t:1527264874727};\\\", \\\"{x:546,y:601,t:1527264874735};\\\", \\\"{x:550,y:589,t:1527264874751};\\\", \\\"{x:563,y:566,t:1527264874768};\\\", \\\"{x:571,y:562,t:1527264874785};\\\", \\\"{x:578,y:559,t:1527264874800};\\\", \\\"{x:585,y:558,t:1527264874818};\\\", \\\"{x:594,y:557,t:1527264874835};\\\", \\\"{x:601,y:556,t:1527264874851};\\\", \\\"{x:602,y:556,t:1527264874868};\\\", \\\"{x:601,y:561,t:1527264874993};\\\", \\\"{x:598,y:569,t:1527264875003};\\\", \\\"{x:593,y:582,t:1527264875017};\\\", \\\"{x:592,y:583,t:1527264875035};\\\", \\\"{x:591,y:584,t:1527264875051};\\\", \\\"{x:591,y:585,t:1527264875167};\\\", \\\"{x:591,y:586,t:1527264875184};\\\", \\\"{x:593,y:586,t:1527264875202};\\\", \\\"{x:593,y:587,t:1527264875218};\\\", \\\"{x:593,y:590,t:1527264875378};\\\", \\\"{x:587,y:598,t:1527264875385};\\\", \\\"{x:578,y:608,t:1527264875400};\\\", \\\"{x:578,y:608,t:1527264875417};\\\", \\\"{x:576,y:608,t:1527264875439};\\\", \\\"{x:574,y:605,t:1527264875450};\\\", \\\"{x:569,y:604,t:1527264875467};\\\", \\\"{x:545,y:604,t:1527264875484};\\\", \\\"{x:517,y:614,t:1527264875500};\\\", \\\"{x:511,y:617,t:1527264875517};\\\", \\\"{x:511,y:614,t:1527264875560};\\\", \\\"{x:511,y:610,t:1527264875568};\\\", \\\"{x:511,y:602,t:1527264875583};\\\", \\\"{x:511,y:597,t:1527264875600};\\\", \\\"{x:511,y:596,t:1527264875640};\\\", \\\"{x:512,y:596,t:1527264875650};\\\", \\\"{x:513,y:596,t:1527264875672};\\\", \\\"{x:514,y:597,t:1527264875712};\\\", \\\"{x:515,y:597,t:1527264875720};\\\", \\\"{x:516,y:597,t:1527264875734};\\\", \\\"{x:525,y:599,t:1527264875751};\\\", \\\"{x:554,y:602,t:1527264875768};\\\", \\\"{x:569,y:603,t:1527264875784};\\\", \\\"{x:583,y:603,t:1527264875801};\\\", \\\"{x:593,y:603,t:1527264875817};\\\", \\\"{x:599,y:603,t:1527264875834};\\\", \\\"{x:601,y:603,t:1527264875850};\\\", \\\"{x:602,y:603,t:1527264875896};\\\", \\\"{x:606,y:601,t:1527264875904};\\\", \\\"{x:608,y:593,t:1527264875919};\\\", \\\"{x:612,y:579,t:1527264875936};\\\", \\\"{x:617,y:567,t:1527264875951};\\\", \\\"{x:620,y:562,t:1527264875969};\\\", \\\"{x:620,y:563,t:1527264876056};\\\", \\\"{x:620,y:564,t:1527264876079};\\\", \\\"{x:619,y:564,t:1527264876208};\\\", \\\"{x:618,y:564,t:1527264876272};\\\", \\\"{x:617,y:565,t:1527264876487};\\\", \\\"{x:615,y:574,t:1527264876502};\\\", \\\"{x:601,y:607,t:1527264876519};\\\", \\\"{x:562,y:673,t:1527264876535};\\\", \\\"{x:537,y:709,t:1527264876553};\\\", \\\"{x:523,y:728,t:1527264876569};\\\", \\\"{x:513,y:739,t:1527264876586};\\\", \\\"{x:507,y:744,t:1527264876602};\\\", \\\"{x:506,y:744,t:1527264876619};\\\", \\\"{x:506,y:745,t:1527264876636};\\\", \\\"{x:505,y:745,t:1527264876721};\\\", \\\"{x:503,y:744,t:1527264876736};\\\", \\\"{x:502,y:737,t:1527264876752};\\\", \\\"{x:498,y:728,t:1527264876769};\\\", \\\"{x:497,y:722,t:1527264876786};\\\", \\\"{x:497,y:720,t:1527264876802};\\\", \\\"{x:497,y:725,t:1527264877224};\\\", \\\"{x:497,y:733,t:1527264877237};\\\", \\\"{x:497,y:745,t:1527264877253};\\\", \\\"{x:499,y:739,t:1527264877544};\\\", \\\"{x:504,y:731,t:1527264877553};\\\", \\\"{x:516,y:711,t:1527264877570};\\\", \\\"{x:533,y:686,t:1527264877587};\\\", \\\"{x:557,y:652,t:1527264877603};\\\", \\\"{x:580,y:618,t:1527264877620};\\\", \\\"{x:604,y:584,t:1527264877636};\\\", \\\"{x:616,y:564,t:1527264877653};\\\", \\\"{x:624,y:548,t:1527264877669};\\\", \\\"{x:627,y:541,t:1527264877687};\\\" ] }, { \\\"rt\\\": 9245, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 472746, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-08 AM-0\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:636,y:540,t:1527264880688};\\\", \\\"{x:688,y:531,t:1527264880696};\\\", \\\"{x:739,y:522,t:1527264880706};\\\", \\\"{x:867,y:478,t:1527264880739};\\\", \\\"{x:913,y:475,t:1527264880756};\\\", \\\"{x:938,y:480,t:1527264880773};\\\", \\\"{x:958,y:492,t:1527264880788};\\\", \\\"{x:978,y:513,t:1527264880805};\\\", \\\"{x:1000,y:563,t:1527264880823};\\\", \\\"{x:1055,y:662,t:1527264880839};\\\", \\\"{x:1146,y:795,t:1527264880855};\\\", \\\"{x:1217,y:870,t:1527264880872};\\\", \\\"{x:1306,y:933,t:1527264880888};\\\", \\\"{x:1368,y:979,t:1527264880906};\\\", \\\"{x:1394,y:1000,t:1527264880922};\\\", \\\"{x:1403,y:1009,t:1527264880939};\\\", \\\"{x:1404,y:1010,t:1527264880955};\\\", \\\"{x:1404,y:1011,t:1527264880972};\\\", \\\"{x:1404,y:1013,t:1527264880989};\\\", \\\"{x:1401,y:1014,t:1527264881006};\\\", \\\"{x:1394,y:1016,t:1527264881023};\\\", \\\"{x:1372,y:1017,t:1527264881040};\\\", \\\"{x:1341,y:1017,t:1527264881056};\\\", \\\"{x:1273,y:1015,t:1527264881072};\\\", \\\"{x:1199,y:1006,t:1527264881090};\\\", \\\"{x:1124,y:986,t:1527264881106};\\\", \\\"{x:1081,y:971,t:1527264881123};\\\", \\\"{x:1057,y:961,t:1527264881140};\\\", \\\"{x:1038,y:951,t:1527264881156};\\\", \\\"{x:1025,y:939,t:1527264881173};\\\", \\\"{x:1022,y:926,t:1527264881190};\\\", \\\"{x:1022,y:909,t:1527264881206};\\\", \\\"{x:1022,y:885,t:1527264881223};\\\", \\\"{x:1028,y:852,t:1527264881240};\\\", \\\"{x:1035,y:834,t:1527264881256};\\\", \\\"{x:1040,y:822,t:1527264881273};\\\", \\\"{x:1046,y:815,t:1527264881290};\\\", \\\"{x:1051,y:813,t:1527264881306};\\\", \\\"{x:1055,y:812,t:1527264881323};\\\", \\\"{x:1070,y:811,t:1527264881339};\\\", \\\"{x:1093,y:811,t:1527264881357};\\\", \\\"{x:1113,y:811,t:1527264881373};\\\", \\\"{x:1136,y:817,t:1527264881390};\\\", \\\"{x:1156,y:823,t:1527264881407};\\\", \\\"{x:1170,y:830,t:1527264881423};\\\", \\\"{x:1179,y:837,t:1527264881440};\\\", \\\"{x:1182,y:843,t:1527264881456};\\\", \\\"{x:1183,y:848,t:1527264881473};\\\", \\\"{x:1183,y:854,t:1527264881490};\\\", \\\"{x:1183,y:857,t:1527264881507};\\\", \\\"{x:1183,y:858,t:1527264881523};\\\", \\\"{x:1182,y:857,t:1527264881601};\\\", \\\"{x:1180,y:850,t:1527264881608};\\\", \\\"{x:1177,y:839,t:1527264881623};\\\", \\\"{x:1173,y:811,t:1527264881641};\\\", \\\"{x:1173,y:793,t:1527264881657};\\\", \\\"{x:1173,y:774,t:1527264881673};\\\", \\\"{x:1173,y:762,t:1527264881691};\\\", \\\"{x:1173,y:749,t:1527264881707};\\\", \\\"{x:1173,y:733,t:1527264881724};\\\", \\\"{x:1173,y:712,t:1527264881741};\\\", \\\"{x:1173,y:699,t:1527264881758};\\\", \\\"{x:1173,y:695,t:1527264881774};\\\", \\\"{x:1173,y:694,t:1527264881790};\\\", \\\"{x:1173,y:690,t:1527264881807};\\\", \\\"{x:1175,y:687,t:1527264881824};\\\", \\\"{x:1176,y:685,t:1527264881841};\\\", \\\"{x:1178,y:683,t:1527264881856};\\\", \\\"{x:1179,y:680,t:1527264881874};\\\", \\\"{x:1183,y:668,t:1527264881890};\\\", \\\"{x:1188,y:656,t:1527264881907};\\\", \\\"{x:1198,y:640,t:1527264881924};\\\", \\\"{x:1204,y:625,t:1527264881940};\\\", \\\"{x:1209,y:608,t:1527264881957};\\\", \\\"{x:1210,y:589,t:1527264881974};\\\", \\\"{x:1210,y:566,t:1527264881991};\\\", \\\"{x:1209,y:547,t:1527264882007};\\\", \\\"{x:1204,y:524,t:1527264882024};\\\", \\\"{x:1202,y:521,t:1527264882040};\\\", \\\"{x:1198,y:519,t:1527264882057};\\\", \\\"{x:1196,y:518,t:1527264882074};\\\", \\\"{x:1195,y:519,t:1527264882128};\\\", \\\"{x:1195,y:520,t:1527264882141};\\\", \\\"{x:1201,y:534,t:1527264882157};\\\", \\\"{x:1216,y:549,t:1527264882173};\\\", \\\"{x:1238,y:565,t:1527264882191};\\\", \\\"{x:1277,y:585,t:1527264882207};\\\", \\\"{x:1317,y:592,t:1527264882223};\\\", \\\"{x:1334,y:592,t:1527264882241};\\\", \\\"{x:1348,y:592,t:1527264882257};\\\", \\\"{x:1356,y:590,t:1527264882273};\\\", \\\"{x:1358,y:588,t:1527264882290};\\\", \\\"{x:1358,y:587,t:1527264882307};\\\", \\\"{x:1358,y:586,t:1527264882336};\\\", \\\"{x:1358,y:585,t:1527264882344};\\\", \\\"{x:1357,y:584,t:1527264882357};\\\", \\\"{x:1355,y:584,t:1527264882375};\\\", \\\"{x:1350,y:583,t:1527264882391};\\\", \\\"{x:1344,y:583,t:1527264882407};\\\", \\\"{x:1341,y:583,t:1527264882424};\\\", \\\"{x:1339,y:583,t:1527264882441};\\\", \\\"{x:1336,y:582,t:1527264882457};\\\", \\\"{x:1333,y:581,t:1527264882474};\\\", \\\"{x:1330,y:580,t:1527264882491};\\\", \\\"{x:1327,y:579,t:1527264882507};\\\", \\\"{x:1326,y:577,t:1527264882524};\\\", \\\"{x:1325,y:576,t:1527264882541};\\\", \\\"{x:1325,y:572,t:1527264882558};\\\", \\\"{x:1326,y:569,t:1527264882574};\\\", \\\"{x:1334,y:567,t:1527264882592};\\\", \\\"{x:1344,y:567,t:1527264882607};\\\", \\\"{x:1355,y:567,t:1527264882625};\\\", \\\"{x:1360,y:567,t:1527264882641};\\\", \\\"{x:1363,y:570,t:1527264882658};\\\", \\\"{x:1363,y:576,t:1527264882675};\\\", \\\"{x:1359,y:586,t:1527264882691};\\\", \\\"{x:1334,y:604,t:1527264882709};\\\", \\\"{x:1273,y:621,t:1527264882724};\\\", \\\"{x:1172,y:638,t:1527264882741};\\\", \\\"{x:1042,y:640,t:1527264882759};\\\", \\\"{x:903,y:640,t:1527264882774};\\\", \\\"{x:784,y:640,t:1527264882791};\\\", \\\"{x:678,y:640,t:1527264882808};\\\", \\\"{x:630,y:632,t:1527264882824};\\\", \\\"{x:604,y:626,t:1527264882842};\\\", \\\"{x:585,y:614,t:1527264882858};\\\", \\\"{x:580,y:609,t:1527264882873};\\\", \\\"{x:579,y:609,t:1527264883088};\\\", \\\"{x:578,y:608,t:1527264883128};\\\", \\\"{x:576,y:606,t:1527264883141};\\\", \\\"{x:571,y:602,t:1527264883158};\\\", \\\"{x:571,y:598,t:1527264883175};\\\", \\\"{x:578,y:590,t:1527264883191};\\\", \\\"{x:611,y:572,t:1527264883207};\\\", \\\"{x:639,y:557,t:1527264883225};\\\", \\\"{x:661,y:548,t:1527264883241};\\\", \\\"{x:675,y:542,t:1527264883257};\\\", \\\"{x:681,y:539,t:1527264883275};\\\", \\\"{x:683,y:539,t:1527264883290};\\\", \\\"{x:681,y:539,t:1527264883328};\\\", \\\"{x:680,y:540,t:1527264883340};\\\", \\\"{x:676,y:541,t:1527264883358};\\\", \\\"{x:674,y:541,t:1527264883375};\\\", \\\"{x:665,y:538,t:1527264883391};\\\", \\\"{x:648,y:524,t:1527264883408};\\\", \\\"{x:636,y:518,t:1527264883425};\\\", \\\"{x:624,y:513,t:1527264883441};\\\", \\\"{x:617,y:511,t:1527264883458};\\\", \\\"{x:614,y:509,t:1527264883475};\\\", \\\"{x:612,y:509,t:1527264883490};\\\", \\\"{x:612,y:508,t:1527264883508};\\\", \\\"{x:612,y:506,t:1527264883525};\\\", \\\"{x:612,y:503,t:1527264883542};\\\", \\\"{x:612,y:500,t:1527264883558};\\\", \\\"{x:612,y:498,t:1527264883575};\\\", \\\"{x:611,y:498,t:1527264883592};\\\", \\\"{x:605,y:500,t:1527264883872};\\\", \\\"{x:593,y:507,t:1527264883880};\\\", \\\"{x:583,y:512,t:1527264883891};\\\", \\\"{x:554,y:524,t:1527264883909};\\\", \\\"{x:511,y:540,t:1527264883925};\\\", \\\"{x:465,y:557,t:1527264883943};\\\", \\\"{x:437,y:567,t:1527264883959};\\\", \\\"{x:422,y:571,t:1527264883974};\\\", \\\"{x:410,y:573,t:1527264883992};\\\", \\\"{x:406,y:573,t:1527264884009};\\\", \\\"{x:405,y:573,t:1527264884025};\\\", \\\"{x:404,y:573,t:1527264884041};\\\", \\\"{x:401,y:572,t:1527264884059};\\\", \\\"{x:397,y:571,t:1527264884075};\\\", \\\"{x:396,y:571,t:1527264884092};\\\", \\\"{x:391,y:571,t:1527264884110};\\\", \\\"{x:390,y:571,t:1527264884125};\\\", \\\"{x:384,y:570,t:1527264884142};\\\", \\\"{x:380,y:570,t:1527264884159};\\\", \\\"{x:373,y:570,t:1527264884176};\\\", \\\"{x:361,y:570,t:1527264884191};\\\", \\\"{x:355,y:576,t:1527264884208};\\\", \\\"{x:353,y:582,t:1527264884225};\\\", \\\"{x:352,y:587,t:1527264884242};\\\", \\\"{x:351,y:591,t:1527264884259};\\\", \\\"{x:351,y:592,t:1527264884275};\\\", \\\"{x:351,y:595,t:1527264884293};\\\", \\\"{x:348,y:599,t:1527264884309};\\\", \\\"{x:340,y:605,t:1527264884326};\\\", \\\"{x:330,y:608,t:1527264884341};\\\", \\\"{x:320,y:611,t:1527264884359};\\\", \\\"{x:305,y:612,t:1527264884374};\\\", \\\"{x:273,y:612,t:1527264884391};\\\", \\\"{x:248,y:612,t:1527264884410};\\\", \\\"{x:226,y:612,t:1527264884425};\\\", \\\"{x:205,y:612,t:1527264884442};\\\", \\\"{x:184,y:612,t:1527264884459};\\\", \\\"{x:170,y:612,t:1527264884476};\\\", \\\"{x:161,y:612,t:1527264884491};\\\", \\\"{x:158,y:612,t:1527264884509};\\\", \\\"{x:155,y:612,t:1527264884526};\\\", \\\"{x:154,y:612,t:1527264884542};\\\", \\\"{x:153,y:612,t:1527264884559};\\\", \\\"{x:154,y:612,t:1527264884616};\\\", \\\"{x:157,y:612,t:1527264884627};\\\", \\\"{x:165,y:614,t:1527264884642};\\\", \\\"{x:173,y:618,t:1527264884660};\\\", \\\"{x:177,y:619,t:1527264884676};\\\", \\\"{x:180,y:621,t:1527264884692};\\\", \\\"{x:183,y:621,t:1527264884709};\\\", \\\"{x:187,y:621,t:1527264884726};\\\", \\\"{x:198,y:621,t:1527264884743};\\\", \\\"{x:216,y:621,t:1527264884758};\\\", \\\"{x:280,y:621,t:1527264884776};\\\", \\\"{x:348,y:619,t:1527264884792};\\\", \\\"{x:424,y:614,t:1527264884809};\\\", \\\"{x:494,y:614,t:1527264884825};\\\", \\\"{x:562,y:610,t:1527264884842};\\\", \\\"{x:637,y:608,t:1527264884859};\\\", \\\"{x:699,y:608,t:1527264884876};\\\", \\\"{x:746,y:608,t:1527264884894};\\\", \\\"{x:783,y:608,t:1527264884908};\\\", \\\"{x:808,y:608,t:1527264884925};\\\", \\\"{x:828,y:606,t:1527264884943};\\\", \\\"{x:843,y:602,t:1527264884959};\\\", \\\"{x:865,y:596,t:1527264884976};\\\", \\\"{x:873,y:593,t:1527264884993};\\\", \\\"{x:875,y:590,t:1527264885009};\\\", \\\"{x:875,y:588,t:1527264885031};\\\", \\\"{x:875,y:587,t:1527264885043};\\\", \\\"{x:875,y:582,t:1527264885059};\\\", \\\"{x:875,y:576,t:1527264885076};\\\", \\\"{x:878,y:564,t:1527264885093};\\\", \\\"{x:888,y:549,t:1527264885111};\\\", \\\"{x:895,y:540,t:1527264885126};\\\", \\\"{x:904,y:531,t:1527264885143};\\\", \\\"{x:906,y:529,t:1527264885158};\\\", \\\"{x:908,y:527,t:1527264885176};\\\", \\\"{x:906,y:527,t:1527264885200};\\\", \\\"{x:900,y:528,t:1527264885209};\\\", \\\"{x:886,y:532,t:1527264885226};\\\", \\\"{x:873,y:536,t:1527264885243};\\\", \\\"{x:860,y:539,t:1527264885261};\\\", \\\"{x:847,y:543,t:1527264885275};\\\", \\\"{x:836,y:547,t:1527264885293};\\\", \\\"{x:829,y:549,t:1527264885308};\\\", \\\"{x:824,y:551,t:1527264885325};\\\", \\\"{x:819,y:551,t:1527264885343};\\\", \\\"{x:814,y:551,t:1527264885359};\\\", \\\"{x:813,y:551,t:1527264885376};\\\", \\\"{x:812,y:551,t:1527264885528};\\\", \\\"{x:814,y:550,t:1527264885583};\\\", \\\"{x:815,y:549,t:1527264885599};\\\", \\\"{x:816,y:549,t:1527264885615};\\\", \\\"{x:817,y:549,t:1527264885857};\\\", \\\"{x:817,y:551,t:1527264885864};\\\", \\\"{x:815,y:557,t:1527264885877};\\\", \\\"{x:807,y:571,t:1527264885893};\\\", \\\"{x:796,y:586,t:1527264885910};\\\", \\\"{x:788,y:598,t:1527264885927};\\\", \\\"{x:785,y:600,t:1527264885943};\\\", \\\"{x:789,y:597,t:1527264885975};\\\", \\\"{x:802,y:590,t:1527264885985};\\\", \\\"{x:817,y:578,t:1527264885993};\\\", \\\"{x:852,y:550,t:1527264886010};\\\", \\\"{x:884,y:533,t:1527264886026};\\\", \\\"{x:904,y:523,t:1527264886043};\\\", \\\"{x:918,y:519,t:1527264886059};\\\", \\\"{x:920,y:518,t:1527264886077};\\\", \\\"{x:921,y:518,t:1527264886103};\\\", \\\"{x:920,y:520,t:1527264886112};\\\", \\\"{x:917,y:520,t:1527264886127};\\\", \\\"{x:908,y:526,t:1527264886144};\\\", \\\"{x:888,y:537,t:1527264886160};\\\", \\\"{x:876,y:543,t:1527264886177};\\\", \\\"{x:859,y:550,t:1527264886194};\\\", \\\"{x:842,y:555,t:1527264886211};\\\", \\\"{x:833,y:558,t:1527264886227};\\\", \\\"{x:828,y:560,t:1527264886243};\\\", \\\"{x:827,y:560,t:1527264886260};\\\", \\\"{x:824,y:560,t:1527264886277};\\\", \\\"{x:822,y:559,t:1527264886352};\\\", \\\"{x:822,y:556,t:1527264886359};\\\", \\\"{x:822,y:552,t:1527264886377};\\\", \\\"{x:825,y:545,t:1527264886394};\\\", \\\"{x:826,y:542,t:1527264886409};\\\", \\\"{x:826,y:541,t:1527264886426};\\\", \\\"{x:827,y:541,t:1527264886444};\\\", \\\"{x:827,y:540,t:1527264886536};\\\", \\\"{x:827,y:540,t:1527264886675};\\\", \\\"{x:824,y:544,t:1527264886744};\\\", \\\"{x:800,y:562,t:1527264886761};\\\", \\\"{x:769,y:581,t:1527264886777};\\\", \\\"{x:723,y:604,t:1527264886794};\\\", \\\"{x:670,y:629,t:1527264886810};\\\", \\\"{x:618,y:650,t:1527264886828};\\\", \\\"{x:571,y:673,t:1527264886844};\\\", \\\"{x:516,y:696,t:1527264886861};\\\", \\\"{x:472,y:712,t:1527264886876};\\\", \\\"{x:446,y:722,t:1527264886894};\\\", \\\"{x:426,y:730,t:1527264886910};\\\", \\\"{x:393,y:746,t:1527264886928};\\\", \\\"{x:370,y:759,t:1527264886944};\\\", \\\"{x:348,y:775,t:1527264886961};\\\", \\\"{x:334,y:788,t:1527264886978};\\\", \\\"{x:328,y:796,t:1527264886993};\\\", \\\"{x:327,y:798,t:1527264887011};\\\", \\\"{x:328,y:798,t:1527264887071};\\\", \\\"{x:329,y:798,t:1527264887079};\\\", \\\"{x:330,y:798,t:1527264887095};\\\", \\\"{x:338,y:798,t:1527264887110};\\\", \\\"{x:359,y:792,t:1527264887128};\\\", \\\"{x:381,y:782,t:1527264887145};\\\", \\\"{x:412,y:769,t:1527264887161};\\\", \\\"{x:456,y:753,t:1527264887179};\\\", \\\"{x:496,y:737,t:1527264887195};\\\", \\\"{x:519,y:727,t:1527264887211};\\\", \\\"{x:533,y:719,t:1527264887227};\\\", \\\"{x:543,y:715,t:1527264887244};\\\", \\\"{x:550,y:711,t:1527264887261};\\\", \\\"{x:551,y:713,t:1527264887496};\\\", \\\"{x:551,y:715,t:1527264887511};\\\", \\\"{x:551,y:718,t:1527264887528};\\\", \\\"{x:550,y:719,t:1527264887545};\\\", \\\"{x:549,y:720,t:1527264887604};\\\", \\\"{x:549,y:721,t:1527264887761};\\\", \\\"{x:549,y:721,t:1527264887792};\\\", \\\"{x:549,y:722,t:1527264887823};\\\", \\\"{x:549,y:725,t:1527264887832};\\\", \\\"{x:548,y:728,t:1527264887844};\\\", \\\"{x:545,y:734,t:1527264887861};\\\", \\\"{x:540,y:741,t:1527264887878};\\\", \\\"{x:533,y:749,t:1527264887894};\\\", \\\"{x:524,y:759,t:1527264887911};\\\", \\\"{x:515,y:770,t:1527264887927};\\\", \\\"{x:510,y:776,t:1527264887945};\\\", \\\"{x:507,y:780,t:1527264887961};\\\", \\\"{x:506,y:784,t:1527264887978};\\\", \\\"{x:504,y:788,t:1527264887995};\\\", \\\"{x:503,y:791,t:1527264888011};\\\", \\\"{x:500,y:798,t:1527264888028};\\\", \\\"{x:498,y:804,t:1527264888045};\\\", \\\"{x:493,y:815,t:1527264888062};\\\", \\\"{x:482,y:824,t:1527264888078};\\\", \\\"{x:472,y:829,t:1527264888095};\\\", \\\"{x:470,y:829,t:1527264888112};\\\", \\\"{x:470,y:828,t:1527264888400};\\\", \\\"{x:470,y:824,t:1527264888412};\\\", \\\"{x:475,y:814,t:1527264888428};\\\", \\\"{x:482,y:803,t:1527264888446};\\\", \\\"{x:492,y:789,t:1527264888462};\\\", \\\"{x:499,y:778,t:1527264888478};\\\", \\\"{x:509,y:767,t:1527264888495};\\\", \\\"{x:520,y:748,t:1527264888511};\\\", \\\"{x:522,y:744,t:1527264888528};\\\", \\\"{x:523,y:742,t:1527264888546};\\\", \\\"{x:523,y:741,t:1527264888839};\\\" ] }, { \\\"rt\\\": 17609, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 491580, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:737,t:1527264889002};\\\", \\\"{x:509,y:735,t:1527264889029};\\\", \\\"{x:508,y:735,t:1527264889045};\\\", \\\"{x:506,y:734,t:1527264889062};\\\", \\\"{x:504,y:733,t:1527264889079};\\\", \\\"{x:503,y:733,t:1527264889112};\\\", \\\"{x:502,y:732,t:1527264889135};\\\", \\\"{x:500,y:731,t:1527264889200};\\\", \\\"{x:498,y:730,t:1527264889216};\\\", \\\"{x:497,y:730,t:1527264889231};\\\", \\\"{x:496,y:729,t:1527264889246};\\\", \\\"{x:494,y:728,t:1527264889262};\\\", \\\"{x:493,y:727,t:1527264889279};\\\", \\\"{x:490,y:726,t:1527264889295};\\\", \\\"{x:488,y:725,t:1527264889313};\\\", \\\"{x:487,y:724,t:1527264889329};\\\", \\\"{x:486,y:724,t:1527264889346};\\\", \\\"{x:485,y:724,t:1527264889363};\\\", \\\"{x:484,y:724,t:1527264889380};\\\", \\\"{x:481,y:722,t:1527264889482};\\\", \\\"{x:480,y:722,t:1527264889720};\\\", \\\"{x:480,y:723,t:1527264891984};\\\", \\\"{x:480,y:729,t:1527264891999};\\\", \\\"{x:476,y:744,t:1527264892017};\\\", \\\"{x:476,y:748,t:1527264892032};\\\", \\\"{x:480,y:763,t:1527264892049};\\\", \\\"{x:482,y:772,t:1527264892065};\\\", \\\"{x:486,y:779,t:1527264892081};\\\", \\\"{x:493,y:788,t:1527264892099};\\\", \\\"{x:502,y:793,t:1527264892115};\\\", \\\"{x:513,y:795,t:1527264892131};\\\", \\\"{x:525,y:796,t:1527264892148};\\\", \\\"{x:537,y:799,t:1527264892165};\\\", \\\"{x:551,y:803,t:1527264892181};\\\", \\\"{x:564,y:804,t:1527264892198};\\\", \\\"{x:575,y:804,t:1527264892216};\\\", \\\"{x:576,y:804,t:1527264892232};\\\", \\\"{x:575,y:804,t:1527264892264};\\\", \\\"{x:574,y:805,t:1527264892591};\\\", \\\"{x:576,y:805,t:1527264892632};\\\", \\\"{x:579,y:805,t:1527264892649};\\\", \\\"{x:580,y:805,t:1527264892665};\\\", \\\"{x:582,y:804,t:1527264892683};\\\", \\\"{x:585,y:804,t:1527264892700};\\\", \\\"{x:588,y:803,t:1527264892716};\\\", \\\"{x:591,y:802,t:1527264892732};\\\", \\\"{x:595,y:800,t:1527264892750};\\\", \\\"{x:601,y:798,t:1527264892766};\\\", \\\"{x:610,y:796,t:1527264892783};\\\", \\\"{x:621,y:794,t:1527264892798};\\\", \\\"{x:645,y:790,t:1527264892816};\\\", \\\"{x:665,y:786,t:1527264892832};\\\", \\\"{x:685,y:784,t:1527264892849};\\\", \\\"{x:703,y:783,t:1527264892865};\\\", \\\"{x:727,y:779,t:1527264892883};\\\", \\\"{x:749,y:775,t:1527264892900};\\\", \\\"{x:768,y:773,t:1527264892915};\\\", \\\"{x:785,y:772,t:1527264892933};\\\", \\\"{x:795,y:770,t:1527264892949};\\\", \\\"{x:801,y:770,t:1527264892965};\\\", \\\"{x:804,y:770,t:1527264892982};\\\", \\\"{x:806,y:770,t:1527264893000};\\\", \\\"{x:806,y:772,t:1527264893017};\\\", \\\"{x:806,y:778,t:1527264893033};\\\", \\\"{x:804,y:780,t:1527264893050};\\\", \\\"{x:803,y:780,t:1527264893066};\\\", \\\"{x:802,y:781,t:1527264893544};\\\", \\\"{x:799,y:781,t:1527264893551};\\\", \\\"{x:798,y:781,t:1527264893696};\\\", \\\"{x:798,y:780,t:1527264893704};\\\", \\\"{x:799,y:780,t:1527264893717};\\\", \\\"{x:801,y:778,t:1527264893733};\\\", \\\"{x:803,y:776,t:1527264893750};\\\", \\\"{x:805,y:775,t:1527264893767};\\\", \\\"{x:810,y:773,t:1527264893784};\\\", \\\"{x:812,y:772,t:1527264893800};\\\", \\\"{x:816,y:770,t:1527264893817};\\\", \\\"{x:817,y:770,t:1527264894851};\\\", \\\"{x:818,y:770,t:1527264894875};\\\", \\\"{x:820,y:770,t:1527264894891};\\\", \\\"{x:821,y:770,t:1527264894903};\\\", \\\"{x:825,y:771,t:1527264894921};\\\", \\\"{x:836,y:779,t:1527264894936};\\\", \\\"{x:861,y:790,t:1527264894953};\\\", \\\"{x:909,y:800,t:1527264894970};\\\", \\\"{x:956,y:806,t:1527264894987};\\\", \\\"{x:1017,y:812,t:1527264895004};\\\", \\\"{x:1084,y:814,t:1527264895021};\\\", \\\"{x:1159,y:814,t:1527264895036};\\\", \\\"{x:1220,y:814,t:1527264895053};\\\", \\\"{x:1271,y:814,t:1527264895071};\\\", \\\"{x:1301,y:814,t:1527264895088};\\\", \\\"{x:1322,y:814,t:1527264895104};\\\", \\\"{x:1327,y:814,t:1527264895120};\\\", \\\"{x:1328,y:814,t:1527264895138};\\\", \\\"{x:1318,y:814,t:1527264895154};\\\", \\\"{x:1313,y:814,t:1527264895171};\\\", \\\"{x:1311,y:815,t:1527264895650};\\\", \\\"{x:1308,y:816,t:1527264895666};\\\", \\\"{x:1305,y:816,t:1527264895674};\\\", \\\"{x:1302,y:818,t:1527264895687};\\\", \\\"{x:1293,y:821,t:1527264895704};\\\", \\\"{x:1282,y:822,t:1527264895720};\\\", \\\"{x:1277,y:823,t:1527264895737};\\\", \\\"{x:1264,y:825,t:1527264895755};\\\", \\\"{x:1253,y:825,t:1527264895770};\\\", \\\"{x:1247,y:825,t:1527264895787};\\\", \\\"{x:1241,y:824,t:1527264895805};\\\", \\\"{x:1238,y:824,t:1527264895821};\\\", \\\"{x:1233,y:822,t:1527264895837};\\\", \\\"{x:1229,y:820,t:1527264895855};\\\", \\\"{x:1225,y:817,t:1527264895871};\\\", \\\"{x:1220,y:813,t:1527264895887};\\\", \\\"{x:1215,y:805,t:1527264895905};\\\", \\\"{x:1209,y:799,t:1527264895922};\\\", \\\"{x:1204,y:791,t:1527264895938};\\\", \\\"{x:1198,y:782,t:1527264895955};\\\", \\\"{x:1194,y:777,t:1527264895970};\\\", \\\"{x:1190,y:773,t:1527264895987};\\\", \\\"{x:1190,y:769,t:1527264896005};\\\", \\\"{x:1190,y:764,t:1527264896022};\\\", \\\"{x:1190,y:758,t:1527264896038};\\\", \\\"{x:1190,y:753,t:1527264896055};\\\", \\\"{x:1190,y:748,t:1527264896072};\\\", \\\"{x:1190,y:743,t:1527264896088};\\\", \\\"{x:1190,y:738,t:1527264896105};\\\", \\\"{x:1190,y:731,t:1527264896122};\\\", \\\"{x:1190,y:723,t:1527264896138};\\\", \\\"{x:1190,y:714,t:1527264896155};\\\", \\\"{x:1190,y:708,t:1527264896172};\\\", \\\"{x:1190,y:703,t:1527264896188};\\\", \\\"{x:1190,y:700,t:1527264896205};\\\", \\\"{x:1190,y:696,t:1527264896222};\\\", \\\"{x:1192,y:692,t:1527264896239};\\\", \\\"{x:1195,y:685,t:1527264896255};\\\", \\\"{x:1197,y:679,t:1527264896272};\\\", \\\"{x:1200,y:672,t:1527264896288};\\\", \\\"{x:1201,y:667,t:1527264896305};\\\", \\\"{x:1201,y:662,t:1527264896322};\\\", \\\"{x:1203,y:656,t:1527264896339};\\\", \\\"{x:1203,y:654,t:1527264896355};\\\", \\\"{x:1204,y:653,t:1527264896372};\\\", \\\"{x:1206,y:653,t:1527264896389};\\\", \\\"{x:1208,y:652,t:1527264896405};\\\", \\\"{x:1211,y:650,t:1527264896422};\\\", \\\"{x:1219,y:647,t:1527264896438};\\\", \\\"{x:1229,y:644,t:1527264896454};\\\", \\\"{x:1250,y:638,t:1527264896471};\\\", \\\"{x:1286,y:629,t:1527264896488};\\\", \\\"{x:1322,y:620,t:1527264896505};\\\", \\\"{x:1371,y:611,t:1527264896521};\\\", \\\"{x:1437,y:601,t:1527264896538};\\\", \\\"{x:1473,y:597,t:1527264896554};\\\", \\\"{x:1512,y:597,t:1527264896571};\\\", \\\"{x:1546,y:597,t:1527264896588};\\\", \\\"{x:1568,y:597,t:1527264896605};\\\", \\\"{x:1580,y:597,t:1527264896621};\\\", \\\"{x:1586,y:597,t:1527264896639};\\\", \\\"{x:1587,y:597,t:1527264896691};\\\", \\\"{x:1587,y:598,t:1527264896705};\\\", \\\"{x:1586,y:605,t:1527264896722};\\\", \\\"{x:1580,y:619,t:1527264896739};\\\", \\\"{x:1569,y:631,t:1527264896756};\\\", \\\"{x:1559,y:641,t:1527264896772};\\\", \\\"{x:1544,y:652,t:1527264896789};\\\", \\\"{x:1523,y:663,t:1527264896806};\\\", \\\"{x:1505,y:671,t:1527264896822};\\\", \\\"{x:1484,y:680,t:1527264896839};\\\", \\\"{x:1466,y:685,t:1527264896855};\\\", \\\"{x:1449,y:690,t:1527264896872};\\\", \\\"{x:1437,y:691,t:1527264896889};\\\", \\\"{x:1430,y:692,t:1527264896906};\\\", \\\"{x:1426,y:694,t:1527264896922};\\\", \\\"{x:1425,y:694,t:1527264896939};\\\", \\\"{x:1424,y:694,t:1527264897021};\\\", \\\"{x:1421,y:694,t:1527264897039};\\\", \\\"{x:1417,y:693,t:1527264897056};\\\", \\\"{x:1414,y:693,t:1527264897072};\\\", \\\"{x:1410,y:693,t:1527264897089};\\\", \\\"{x:1407,y:693,t:1527264897106};\\\", \\\"{x:1406,y:692,t:1527264897122};\\\", \\\"{x:1405,y:691,t:1527264897138};\\\", \\\"{x:1404,y:690,t:1527264897156};\\\", \\\"{x:1402,y:690,t:1527264897172};\\\", \\\"{x:1401,y:690,t:1527264897203};\\\", \\\"{x:1400,y:690,t:1527264897228};\\\", \\\"{x:1399,y:690,t:1527264897299};\\\", \\\"{x:1398,y:690,t:1527264897315};\\\", \\\"{x:1397,y:690,t:1527264897332};\\\", \\\"{x:1395,y:690,t:1527264897339};\\\", \\\"{x:1393,y:690,t:1527264897356};\\\", \\\"{x:1388,y:690,t:1527264897373};\\\", \\\"{x:1384,y:690,t:1527264897389};\\\", \\\"{x:1376,y:692,t:1527264897406};\\\", \\\"{x:1369,y:694,t:1527264897423};\\\", \\\"{x:1363,y:696,t:1527264897439};\\\", \\\"{x:1359,y:698,t:1527264897457};\\\", \\\"{x:1356,y:698,t:1527264897473};\\\", \\\"{x:1356,y:699,t:1527264897489};\\\", \\\"{x:1354,y:699,t:1527264897531};\\\", \\\"{x:1353,y:699,t:1527264897550};\\\", \\\"{x:1351,y:699,t:1527264897572};\\\", \\\"{x:1350,y:699,t:1527264897590};\\\", \\\"{x:1348,y:699,t:1527264897608};\\\", \\\"{x:1347,y:699,t:1527264897639};\\\", \\\"{x:1344,y:699,t:1527264897655};\\\", \\\"{x:1343,y:700,t:1527264897698};\\\", \\\"{x:1344,y:700,t:1527264898442};\\\", \\\"{x:1345,y:700,t:1527264898457};\\\", \\\"{x:1347,y:700,t:1527264898473};\\\", \\\"{x:1348,y:700,t:1527264898489};\\\", \\\"{x:1349,y:700,t:1527264898747};\\\", \\\"{x:1350,y:701,t:1527264898763};\\\", \\\"{x:1351,y:702,t:1527264898775};\\\", \\\"{x:1353,y:709,t:1527264898790};\\\", \\\"{x:1353,y:714,t:1527264898807};\\\", \\\"{x:1353,y:718,t:1527264898824};\\\", \\\"{x:1353,y:727,t:1527264898839};\\\", \\\"{x:1352,y:734,t:1527264898857};\\\", \\\"{x:1349,y:740,t:1527264898874};\\\", \\\"{x:1348,y:743,t:1527264898890};\\\", \\\"{x:1346,y:748,t:1527264898907};\\\", \\\"{x:1345,y:753,t:1527264898924};\\\", \\\"{x:1345,y:757,t:1527264898941};\\\", \\\"{x:1345,y:760,t:1527264898957};\\\", \\\"{x:1345,y:761,t:1527264898990};\\\", \\\"{x:1345,y:762,t:1527264899007};\\\", \\\"{x:1345,y:763,t:1527264899024};\\\", \\\"{x:1345,y:764,t:1527264899041};\\\", \\\"{x:1345,y:765,t:1527264899056};\\\", \\\"{x:1345,y:766,t:1527264899073};\\\", \\\"{x:1345,y:770,t:1527264899091};\\\", \\\"{x:1345,y:772,t:1527264899106};\\\", \\\"{x:1345,y:773,t:1527264899123};\\\", \\\"{x:1345,y:775,t:1527264899141};\\\", \\\"{x:1345,y:776,t:1527264899156};\\\", \\\"{x:1345,y:780,t:1527264899173};\\\", \\\"{x:1345,y:781,t:1527264899191};\\\", \\\"{x:1344,y:783,t:1527264899207};\\\", \\\"{x:1344,y:785,t:1527264899223};\\\", \\\"{x:1343,y:785,t:1527264899241};\\\", \\\"{x:1342,y:785,t:1527264899307};\\\", \\\"{x:1340,y:785,t:1527264899339};\\\", \\\"{x:1339,y:785,t:1527264899355};\\\", \\\"{x:1338,y:785,t:1527264899371};\\\", \\\"{x:1338,y:784,t:1527264899387};\\\", \\\"{x:1338,y:782,t:1527264899403};\\\", \\\"{x:1338,y:781,t:1527264899411};\\\", \\\"{x:1338,y:780,t:1527264899424};\\\", \\\"{x:1338,y:778,t:1527264899441};\\\", \\\"{x:1339,y:775,t:1527264899459};\\\", \\\"{x:1340,y:773,t:1527264899475};\\\", \\\"{x:1341,y:771,t:1527264899491};\\\", \\\"{x:1341,y:772,t:1527264899740};\\\", \\\"{x:1341,y:774,t:1527264899747};\\\", \\\"{x:1341,y:776,t:1527264899758};\\\", \\\"{x:1341,y:779,t:1527264899774};\\\", \\\"{x:1341,y:783,t:1527264899791};\\\", \\\"{x:1341,y:787,t:1527264899808};\\\", \\\"{x:1341,y:789,t:1527264899824};\\\", \\\"{x:1341,y:791,t:1527264899841};\\\", \\\"{x:1341,y:793,t:1527264899858};\\\", \\\"{x:1341,y:795,t:1527264899876};\\\", \\\"{x:1341,y:796,t:1527264899891};\\\", \\\"{x:1341,y:797,t:1527264899908};\\\", \\\"{x:1341,y:799,t:1527264899931};\\\", \\\"{x:1342,y:800,t:1527264899947};\\\", \\\"{x:1343,y:801,t:1527264899963};\\\", \\\"{x:1344,y:801,t:1527264899979};\\\", \\\"{x:1345,y:802,t:1527264899991};\\\", \\\"{x:1346,y:803,t:1527264900008};\\\", \\\"{x:1346,y:804,t:1527264900025};\\\", \\\"{x:1346,y:805,t:1527264900041};\\\", \\\"{x:1346,y:808,t:1527264900058};\\\", \\\"{x:1346,y:810,t:1527264900075};\\\", \\\"{x:1346,y:813,t:1527264900091};\\\", \\\"{x:1345,y:814,t:1527264900108};\\\", \\\"{x:1345,y:815,t:1527264900125};\\\", \\\"{x:1344,y:815,t:1527264900141};\\\", \\\"{x:1344,y:816,t:1527264900158};\\\", \\\"{x:1343,y:816,t:1527264900196};\\\", \\\"{x:1342,y:816,t:1527264900208};\\\", \\\"{x:1343,y:815,t:1527264900348};\\\", \\\"{x:1347,y:814,t:1527264900358};\\\", \\\"{x:1351,y:812,t:1527264900375};\\\", \\\"{x:1359,y:808,t:1527264900392};\\\", \\\"{x:1371,y:803,t:1527264900408};\\\", \\\"{x:1380,y:801,t:1527264900425};\\\", \\\"{x:1393,y:798,t:1527264900443};\\\", \\\"{x:1407,y:794,t:1527264900458};\\\", \\\"{x:1425,y:788,t:1527264900475};\\\", \\\"{x:1439,y:785,t:1527264900492};\\\", \\\"{x:1452,y:782,t:1527264900508};\\\", \\\"{x:1463,y:781,t:1527264900525};\\\", \\\"{x:1474,y:778,t:1527264900542};\\\", \\\"{x:1486,y:777,t:1527264900558};\\\", \\\"{x:1495,y:776,t:1527264900575};\\\", \\\"{x:1497,y:776,t:1527264900592};\\\", \\\"{x:1499,y:776,t:1527264900607};\\\", \\\"{x:1501,y:776,t:1527264900624};\\\", \\\"{x:1502,y:776,t:1527264900642};\\\", \\\"{x:1501,y:776,t:1527264900730};\\\", \\\"{x:1500,y:777,t:1527264900741};\\\", \\\"{x:1495,y:780,t:1527264900758};\\\", \\\"{x:1490,y:783,t:1527264900775};\\\", \\\"{x:1479,y:789,t:1527264900792};\\\", \\\"{x:1469,y:793,t:1527264900808};\\\", \\\"{x:1460,y:798,t:1527264900825};\\\", \\\"{x:1444,y:807,t:1527264900842};\\\", \\\"{x:1414,y:817,t:1527264900859};\\\", \\\"{x:1391,y:823,t:1527264900875};\\\", \\\"{x:1366,y:830,t:1527264900892};\\\", \\\"{x:1342,y:836,t:1527264900909};\\\", \\\"{x:1315,y:842,t:1527264900925};\\\", \\\"{x:1296,y:846,t:1527264900942};\\\", \\\"{x:1283,y:850,t:1527264900959};\\\", \\\"{x:1271,y:851,t:1527264900975};\\\", \\\"{x:1266,y:852,t:1527264900992};\\\", \\\"{x:1261,y:853,t:1527264901009};\\\", \\\"{x:1254,y:854,t:1527264901025};\\\", \\\"{x:1251,y:854,t:1527264901042};\\\", \\\"{x:1250,y:854,t:1527264901059};\\\", \\\"{x:1245,y:854,t:1527264901372};\\\", \\\"{x:1238,y:854,t:1527264901379};\\\", \\\"{x:1228,y:854,t:1527264901392};\\\", \\\"{x:1201,y:854,t:1527264901409};\\\", \\\"{x:1165,y:854,t:1527264901427};\\\", \\\"{x:1109,y:846,t:1527264901442};\\\", \\\"{x:996,y:816,t:1527264901459};\\\", \\\"{x:904,y:787,t:1527264901476};\\\", \\\"{x:809,y:755,t:1527264901492};\\\", \\\"{x:717,y:712,t:1527264901509};\\\", \\\"{x:641,y:668,t:1527264901526};\\\", \\\"{x:571,y:623,t:1527264901544};\\\", \\\"{x:521,y:587,t:1527264901559};\\\", \\\"{x:486,y:560,t:1527264901576};\\\", \\\"{x:467,y:542,t:1527264901593};\\\", \\\"{x:457,y:527,t:1527264901609};\\\", \\\"{x:454,y:519,t:1527264901625};\\\", \\\"{x:453,y:514,t:1527264901642};\\\", \\\"{x:453,y:512,t:1527264901658};\\\", \\\"{x:453,y:511,t:1527264901676};\\\", \\\"{x:453,y:510,t:1527264901692};\\\", \\\"{x:454,y:510,t:1527264901708};\\\", \\\"{x:453,y:510,t:1527264901787};\\\", \\\"{x:449,y:513,t:1527264901795};\\\", \\\"{x:443,y:517,t:1527264901809};\\\", \\\"{x:431,y:525,t:1527264901826};\\\", \\\"{x:421,y:531,t:1527264901842};\\\", \\\"{x:404,y:540,t:1527264901860};\\\", \\\"{x:395,y:545,t:1527264901875};\\\", \\\"{x:387,y:548,t:1527264901892};\\\", \\\"{x:376,y:553,t:1527264901909};\\\", \\\"{x:368,y:556,t:1527264901926};\\\", \\\"{x:363,y:561,t:1527264901942};\\\", \\\"{x:359,y:564,t:1527264901960};\\\", \\\"{x:357,y:565,t:1527264901975};\\\", \\\"{x:354,y:567,t:1527264901992};\\\", \\\"{x:353,y:568,t:1527264902009};\\\", \\\"{x:352,y:568,t:1527264902025};\\\", \\\"{x:351,y:571,t:1527264902043};\\\", \\\"{x:351,y:573,t:1527264902067};\\\", \\\"{x:350,y:574,t:1527264902075};\\\", \\\"{x:349,y:576,t:1527264902092};\\\", \\\"{x:348,y:583,t:1527264902109};\\\", \\\"{x:340,y:599,t:1527264902126};\\\", \\\"{x:324,y:614,t:1527264902143};\\\", \\\"{x:314,y:613,t:1527264902159};\\\", \\\"{x:297,y:609,t:1527264902175};\\\", \\\"{x:281,y:607,t:1527264902193};\\\", \\\"{x:266,y:607,t:1527264902210};\\\", \\\"{x:258,y:608,t:1527264902226};\\\", \\\"{x:258,y:609,t:1527264902242};\\\", \\\"{x:256,y:609,t:1527264902259};\\\", \\\"{x:250,y:609,t:1527264902275};\\\", \\\"{x:251,y:609,t:1527264902515};\\\", \\\"{x:251,y:610,t:1527264902563};\\\", \\\"{x:250,y:611,t:1527264902576};\\\", \\\"{x:244,y:612,t:1527264902593};\\\", \\\"{x:239,y:613,t:1527264902610};\\\", \\\"{x:222,y:617,t:1527264902627};\\\", \\\"{x:216,y:619,t:1527264902642};\\\", \\\"{x:213,y:619,t:1527264902660};\\\", \\\"{x:211,y:620,t:1527264902676};\\\", \\\"{x:211,y:618,t:1527264902715};\\\", \\\"{x:213,y:617,t:1527264902726};\\\", \\\"{x:219,y:614,t:1527264902743};\\\", \\\"{x:228,y:611,t:1527264902760};\\\", \\\"{x:246,y:606,t:1527264902777};\\\", \\\"{x:270,y:601,t:1527264902793};\\\", \\\"{x:300,y:592,t:1527264902812};\\\", \\\"{x:360,y:573,t:1527264902826};\\\", \\\"{x:396,y:565,t:1527264902843};\\\", \\\"{x:428,y:562,t:1527264902860};\\\", \\\"{x:460,y:562,t:1527264902877};\\\", \\\"{x:493,y:562,t:1527264902893};\\\", \\\"{x:523,y:561,t:1527264902909};\\\", \\\"{x:549,y:556,t:1527264902927};\\\", \\\"{x:572,y:554,t:1527264902944};\\\", \\\"{x:596,y:550,t:1527264902960};\\\", \\\"{x:622,y:547,t:1527264902976};\\\", \\\"{x:647,y:544,t:1527264902993};\\\", \\\"{x:670,y:540,t:1527264903010};\\\", \\\"{x:705,y:534,t:1527264903026};\\\", \\\"{x:719,y:533,t:1527264903043};\\\", \\\"{x:733,y:531,t:1527264903061};\\\", \\\"{x:743,y:529,t:1527264903076};\\\", \\\"{x:757,y:527,t:1527264903093};\\\", \\\"{x:767,y:526,t:1527264903110};\\\", \\\"{x:774,y:524,t:1527264903127};\\\", \\\"{x:779,y:524,t:1527264903142};\\\", \\\"{x:787,y:524,t:1527264903160};\\\", \\\"{x:791,y:524,t:1527264903177};\\\", \\\"{x:792,y:524,t:1527264903194};\\\", \\\"{x:793,y:524,t:1527264903299};\\\", \\\"{x:795,y:524,t:1527264903311};\\\", \\\"{x:800,y:522,t:1527264903327};\\\", \\\"{x:805,y:519,t:1527264903344};\\\", \\\"{x:813,y:516,t:1527264903363};\\\", \\\"{x:817,y:515,t:1527264903376};\\\", \\\"{x:821,y:514,t:1527264903394};\\\", \\\"{x:826,y:513,t:1527264903410};\\\", \\\"{x:827,y:513,t:1527264903426};\\\", \\\"{x:828,y:512,t:1527264903474};\\\", \\\"{x:823,y:514,t:1527264903834};\\\", \\\"{x:817,y:518,t:1527264903844};\\\", \\\"{x:796,y:528,t:1527264903861};\\\", \\\"{x:768,y:540,t:1527264903878};\\\", \\\"{x:720,y:557,t:1527264903894};\\\", \\\"{x:666,y:575,t:1527264903911};\\\", \\\"{x:603,y:590,t:1527264903928};\\\", \\\"{x:545,y:605,t:1527264903944};\\\", \\\"{x:494,y:613,t:1527264903962};\\\", \\\"{x:450,y:617,t:1527264903978};\\\", \\\"{x:411,y:623,t:1527264903994};\\\", \\\"{x:367,y:628,t:1527264904011};\\\", \\\"{x:346,y:632,t:1527264904028};\\\", \\\"{x:332,y:634,t:1527264904044};\\\", \\\"{x:319,y:635,t:1527264904060};\\\", \\\"{x:309,y:637,t:1527264904078};\\\", \\\"{x:301,y:638,t:1527264904094};\\\", \\\"{x:289,y:638,t:1527264904111};\\\", \\\"{x:273,y:631,t:1527264904128};\\\", \\\"{x:247,y:614,t:1527264904145};\\\", \\\"{x:226,y:601,t:1527264904161};\\\", \\\"{x:203,y:591,t:1527264904179};\\\", \\\"{x:170,y:583,t:1527264904195};\\\", \\\"{x:148,y:577,t:1527264904211};\\\", \\\"{x:138,y:574,t:1527264904228};\\\", \\\"{x:126,y:569,t:1527264904245};\\\", \\\"{x:118,y:563,t:1527264904260};\\\", \\\"{x:109,y:557,t:1527264904278};\\\", \\\"{x:108,y:555,t:1527264904296};\\\", \\\"{x:108,y:553,t:1527264904310};\\\", \\\"{x:108,y:552,t:1527264904328};\\\", \\\"{x:108,y:550,t:1527264904395};\\\", \\\"{x:108,y:548,t:1527264904419};\\\", \\\"{x:110,y:548,t:1527264904427};\\\", \\\"{x:113,y:548,t:1527264904445};\\\", \\\"{x:117,y:548,t:1527264904460};\\\", \\\"{x:121,y:550,t:1527264904478};\\\", \\\"{x:126,y:550,t:1527264904495};\\\", \\\"{x:129,y:551,t:1527264904511};\\\", \\\"{x:132,y:552,t:1527264904527};\\\", \\\"{x:134,y:552,t:1527264904545};\\\", \\\"{x:138,y:552,t:1527264904561};\\\", \\\"{x:140,y:552,t:1527264904578};\\\", \\\"{x:141,y:552,t:1527264904594};\\\", \\\"{x:142,y:552,t:1527264904611};\\\", \\\"{x:144,y:551,t:1527264904628};\\\", \\\"{x:147,y:554,t:1527264904906};\\\", \\\"{x:153,y:563,t:1527264904915};\\\", \\\"{x:158,y:569,t:1527264904927};\\\", \\\"{x:171,y:584,t:1527264904944};\\\", \\\"{x:183,y:598,t:1527264904962};\\\", \\\"{x:203,y:614,t:1527264904978};\\\", \\\"{x:217,y:625,t:1527264904995};\\\", \\\"{x:234,y:635,t:1527264905012};\\\", \\\"{x:258,y:646,t:1527264905029};\\\", \\\"{x:279,y:655,t:1527264905045};\\\", \\\"{x:302,y:663,t:1527264905062};\\\", \\\"{x:330,y:670,t:1527264905078};\\\", \\\"{x:361,y:680,t:1527264905094};\\\", \\\"{x:389,y:687,t:1527264905111};\\\", \\\"{x:415,y:696,t:1527264905128};\\\", \\\"{x:437,y:702,t:1527264905144};\\\", \\\"{x:451,y:705,t:1527264905162};\\\", \\\"{x:460,y:709,t:1527264905178};\\\", \\\"{x:461,y:710,t:1527264905210};\\\", \\\"{x:450,y:702,t:1527264905506};\\\", \\\"{x:429,y:686,t:1527264905514};\\\", \\\"{x:391,y:663,t:1527264905529};\\\", \\\"{x:307,y:618,t:1527264905546};\\\", \\\"{x:255,y:597,t:1527264905563};\\\", \\\"{x:222,y:582,t:1527264905579};\\\", \\\"{x:211,y:576,t:1527264905596};\\\", \\\"{x:203,y:570,t:1527264905611};\\\", \\\"{x:201,y:569,t:1527264905629};\\\", \\\"{x:201,y:568,t:1527264905645};\\\", \\\"{x:200,y:566,t:1527264905662};\\\", \\\"{x:200,y:565,t:1527264905762};\\\", \\\"{x:194,y:561,t:1527264905779};\\\", \\\"{x:187,y:557,t:1527264905796};\\\", \\\"{x:178,y:553,t:1527264905813};\\\", \\\"{x:173,y:551,t:1527264905829};\\\", \\\"{x:168,y:550,t:1527264905846};\\\", \\\"{x:165,y:549,t:1527264905863};\\\", \\\"{x:163,y:548,t:1527264905879};\\\", \\\"{x:172,y:548,t:1527264906162};\\\", \\\"{x:206,y:567,t:1527264906179};\\\", \\\"{x:231,y:585,t:1527264906196};\\\", \\\"{x:263,y:606,t:1527264906213};\\\", \\\"{x:292,y:626,t:1527264906229};\\\", \\\"{x:324,y:645,t:1527264906246};\\\", \\\"{x:356,y:663,t:1527264906262};\\\", \\\"{x:389,y:677,t:1527264906280};\\\", \\\"{x:421,y:696,t:1527264906295};\\\", \\\"{x:447,y:709,t:1527264906313};\\\", \\\"{x:463,y:717,t:1527264906328};\\\", \\\"{x:474,y:720,t:1527264906346};\\\", \\\"{x:475,y:721,t:1527264906363};\\\" ] }, { \\\"rt\\\": 23090, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 515903, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:477,y:723,t:1527264908938};\\\", \\\"{x:485,y:726,t:1527264908948};\\\", \\\"{x:519,y:728,t:1527264908965};\\\", \\\"{x:582,y:731,t:1527264908982};\\\", \\\"{x:635,y:731,t:1527264908998};\\\", \\\"{x:669,y:731,t:1527264909015};\\\", \\\"{x:701,y:731,t:1527264909031};\\\", \\\"{x:743,y:731,t:1527264909048};\\\", \\\"{x:783,y:725,t:1527264909065};\\\", \\\"{x:806,y:722,t:1527264909082};\\\", \\\"{x:832,y:722,t:1527264909098};\\\", \\\"{x:841,y:722,t:1527264909115};\\\", \\\"{x:849,y:723,t:1527264909132};\\\", \\\"{x:852,y:724,t:1527264909148};\\\", \\\"{x:851,y:723,t:1527264909178};\\\", \\\"{x:843,y:717,t:1527264909186};\\\", \\\"{x:836,y:714,t:1527264909198};\\\", \\\"{x:836,y:711,t:1527264909215};\\\", \\\"{x:836,y:710,t:1527264909643};\\\", \\\"{x:840,y:710,t:1527264909650};\\\", \\\"{x:847,y:710,t:1527264909664};\\\", \\\"{x:879,y:710,t:1527264909681};\\\", \\\"{x:895,y:710,t:1527264909699};\\\", \\\"{x:914,y:709,t:1527264909715};\\\", \\\"{x:936,y:709,t:1527264909731};\\\", \\\"{x:964,y:704,t:1527264909749};\\\", \\\"{x:994,y:701,t:1527264909765};\\\", \\\"{x:1034,y:695,t:1527264909782};\\\", \\\"{x:1082,y:688,t:1527264909799};\\\", \\\"{x:1135,y:680,t:1527264909815};\\\", \\\"{x:1191,y:672,t:1527264909832};\\\", \\\"{x:1215,y:659,t:1527264909849};\\\", \\\"{x:1219,y:655,t:1527264909866};\\\", \\\"{x:1222,y:652,t:1527264910242};\\\", \\\"{x:1230,y:648,t:1527264910250};\\\", \\\"{x:1237,y:642,t:1527264910267};\\\", \\\"{x:1243,y:636,t:1527264910282};\\\", \\\"{x:1248,y:629,t:1527264910299};\\\", \\\"{x:1255,y:621,t:1527264910316};\\\", \\\"{x:1264,y:611,t:1527264910333};\\\", \\\"{x:1267,y:605,t:1527264910349};\\\", \\\"{x:1268,y:596,t:1527264910366};\\\", \\\"{x:1266,y:585,t:1527264910383};\\\", \\\"{x:1260,y:573,t:1527264910399};\\\", \\\"{x:1255,y:564,t:1527264910416};\\\", \\\"{x:1245,y:549,t:1527264910433};\\\", \\\"{x:1236,y:536,t:1527264910449};\\\", \\\"{x:1221,y:523,t:1527264910466};\\\", \\\"{x:1211,y:516,t:1527264910482};\\\", \\\"{x:1207,y:513,t:1527264910499};\\\", \\\"{x:1203,y:510,t:1527264910516};\\\", \\\"{x:1202,y:510,t:1527264910533};\\\", \\\"{x:1203,y:510,t:1527264910618};\\\", \\\"{x:1206,y:510,t:1527264910633};\\\", \\\"{x:1223,y:513,t:1527264910649};\\\", \\\"{x:1237,y:516,t:1527264910666};\\\", \\\"{x:1256,y:516,t:1527264910683};\\\", \\\"{x:1279,y:516,t:1527264910700};\\\", \\\"{x:1305,y:515,t:1527264910716};\\\", \\\"{x:1330,y:509,t:1527264910733};\\\", \\\"{x:1361,y:506,t:1527264910750};\\\", \\\"{x:1401,y:499,t:1527264910766};\\\", \\\"{x:1431,y:495,t:1527264910783};\\\", \\\"{x:1447,y:492,t:1527264910800};\\\", \\\"{x:1454,y:490,t:1527264910816};\\\", \\\"{x:1455,y:489,t:1527264910833};\\\", \\\"{x:1452,y:489,t:1527264910914};\\\", \\\"{x:1449,y:491,t:1527264910922};\\\", \\\"{x:1446,y:491,t:1527264910933};\\\", \\\"{x:1433,y:496,t:1527264910950};\\\", \\\"{x:1417,y:501,t:1527264910966};\\\", \\\"{x:1402,y:504,t:1527264910983};\\\", \\\"{x:1382,y:509,t:1527264911000};\\\", \\\"{x:1361,y:515,t:1527264911016};\\\", \\\"{x:1344,y:519,t:1527264911032};\\\", \\\"{x:1327,y:523,t:1527264911050};\\\", \\\"{x:1323,y:523,t:1527264911066};\\\", \\\"{x:1320,y:523,t:1527264911083};\\\", \\\"{x:1318,y:523,t:1527264911100};\\\", \\\"{x:1317,y:523,t:1527264911116};\\\", \\\"{x:1315,y:523,t:1527264911133};\\\", \\\"{x:1311,y:524,t:1527264911150};\\\", \\\"{x:1308,y:525,t:1527264911166};\\\", \\\"{x:1302,y:527,t:1527264911182};\\\", \\\"{x:1299,y:528,t:1527264911200};\\\", \\\"{x:1292,y:529,t:1527264911217};\\\", \\\"{x:1286,y:532,t:1527264911233};\\\", \\\"{x:1275,y:534,t:1527264911250};\\\", \\\"{x:1274,y:534,t:1527264911267};\\\", \\\"{x:1272,y:534,t:1527264911283};\\\", \\\"{x:1272,y:535,t:1527264914300};\\\", \\\"{x:1272,y:536,t:1527264914307};\\\", \\\"{x:1273,y:536,t:1527264914323};\\\", \\\"{x:1274,y:536,t:1527264914336};\\\", \\\"{x:1276,y:537,t:1527264914353};\\\", \\\"{x:1280,y:538,t:1527264914370};\\\", \\\"{x:1286,y:538,t:1527264914387};\\\", \\\"{x:1287,y:538,t:1527264914420};\\\", \\\"{x:1289,y:538,t:1527264914437};\\\", \\\"{x:1291,y:538,t:1527264914453};\\\", \\\"{x:1294,y:538,t:1527264914470};\\\", \\\"{x:1298,y:538,t:1527264914487};\\\", \\\"{x:1303,y:536,t:1527264914503};\\\", \\\"{x:1308,y:534,t:1527264914520};\\\", \\\"{x:1310,y:533,t:1527264914536};\\\", \\\"{x:1313,y:532,t:1527264914553};\\\", \\\"{x:1314,y:532,t:1527264914570};\\\", \\\"{x:1314,y:531,t:1527264914587};\\\", \\\"{x:1315,y:531,t:1527264914635};\\\", \\\"{x:1315,y:530,t:1527264914659};\\\", \\\"{x:1315,y:529,t:1527264914675};\\\", \\\"{x:1315,y:528,t:1527264914687};\\\", \\\"{x:1315,y:527,t:1527264914703};\\\", \\\"{x:1315,y:525,t:1527264914720};\\\", \\\"{x:1313,y:523,t:1527264914736};\\\", \\\"{x:1309,y:522,t:1527264914753};\\\", \\\"{x:1304,y:520,t:1527264914770};\\\", \\\"{x:1300,y:518,t:1527264914787};\\\", \\\"{x:1299,y:518,t:1527264914804};\\\", \\\"{x:1298,y:518,t:1527264915108};\\\", \\\"{x:1298,y:523,t:1527264915120};\\\", \\\"{x:1297,y:538,t:1527264915137};\\\", \\\"{x:1294,y:554,t:1527264915153};\\\", \\\"{x:1289,y:567,t:1527264915169};\\\", \\\"{x:1283,y:583,t:1527264915185};\\\", \\\"{x:1279,y:598,t:1527264915203};\\\", \\\"{x:1278,y:612,t:1527264915220};\\\", \\\"{x:1278,y:628,t:1527264915236};\\\", \\\"{x:1278,y:645,t:1527264915253};\\\", \\\"{x:1277,y:664,t:1527264915270};\\\", \\\"{x:1275,y:679,t:1527264915286};\\\", \\\"{x:1273,y:693,t:1527264915303};\\\", \\\"{x:1271,y:704,t:1527264915320};\\\", \\\"{x:1270,y:709,t:1527264915336};\\\", \\\"{x:1270,y:716,t:1527264915354};\\\", \\\"{x:1269,y:723,t:1527264915371};\\\", \\\"{x:1268,y:725,t:1527264915386};\\\", \\\"{x:1268,y:726,t:1527264915507};\\\", \\\"{x:1268,y:727,t:1527264915520};\\\", \\\"{x:1268,y:729,t:1527264915536};\\\", \\\"{x:1272,y:731,t:1527264915553};\\\", \\\"{x:1280,y:734,t:1527264915570};\\\", \\\"{x:1290,y:734,t:1527264915587};\\\", \\\"{x:1301,y:736,t:1527264915603};\\\", \\\"{x:1318,y:738,t:1527264915620};\\\", \\\"{x:1336,y:738,t:1527264915637};\\\", \\\"{x:1352,y:739,t:1527264915653};\\\", \\\"{x:1369,y:741,t:1527264915670};\\\", \\\"{x:1377,y:743,t:1527264915687};\\\", \\\"{x:1383,y:744,t:1527264915703};\\\", \\\"{x:1389,y:744,t:1527264915721};\\\", \\\"{x:1393,y:744,t:1527264915737};\\\", \\\"{x:1394,y:744,t:1527264915753};\\\", \\\"{x:1395,y:744,t:1527264915860};\\\", \\\"{x:1395,y:743,t:1527264915875};\\\", \\\"{x:1395,y:741,t:1527264915888};\\\", \\\"{x:1393,y:736,t:1527264915904};\\\", \\\"{x:1389,y:735,t:1527264915921};\\\", \\\"{x:1385,y:732,t:1527264915938};\\\", \\\"{x:1381,y:731,t:1527264915954};\\\", \\\"{x:1376,y:728,t:1527264915971};\\\", \\\"{x:1369,y:724,t:1527264915987};\\\", \\\"{x:1365,y:721,t:1527264916004};\\\", \\\"{x:1364,y:720,t:1527264916021};\\\", \\\"{x:1363,y:720,t:1527264916038};\\\", \\\"{x:1362,y:718,t:1527264916054};\\\", \\\"{x:1362,y:717,t:1527264916083};\\\", \\\"{x:1362,y:715,t:1527264916091};\\\", \\\"{x:1362,y:714,t:1527264916107};\\\", \\\"{x:1362,y:712,t:1527264916120};\\\", \\\"{x:1362,y:709,t:1527264916138};\\\", \\\"{x:1362,y:704,t:1527264916154};\\\", \\\"{x:1362,y:701,t:1527264916171};\\\", \\\"{x:1361,y:698,t:1527264916188};\\\", \\\"{x:1361,y:694,t:1527264916205};\\\", \\\"{x:1358,y:690,t:1527264916221};\\\", \\\"{x:1356,y:686,t:1527264916238};\\\", \\\"{x:1351,y:679,t:1527264916255};\\\", \\\"{x:1346,y:673,t:1527264916271};\\\", \\\"{x:1340,y:666,t:1527264916288};\\\", \\\"{x:1336,y:660,t:1527264916304};\\\", \\\"{x:1330,y:651,t:1527264916321};\\\", \\\"{x:1324,y:640,t:1527264916338};\\\", \\\"{x:1317,y:627,t:1527264916355};\\\", \\\"{x:1312,y:618,t:1527264916371};\\\", \\\"{x:1312,y:614,t:1527264916388};\\\", \\\"{x:1311,y:609,t:1527264916404};\\\", \\\"{x:1310,y:606,t:1527264916420};\\\", \\\"{x:1309,y:604,t:1527264916437};\\\", \\\"{x:1309,y:603,t:1527264916454};\\\", \\\"{x:1308,y:601,t:1527264916472};\\\", \\\"{x:1308,y:600,t:1527264916487};\\\", \\\"{x:1308,y:597,t:1527264916505};\\\", \\\"{x:1308,y:592,t:1527264916521};\\\", \\\"{x:1308,y:586,t:1527264916537};\\\", \\\"{x:1307,y:582,t:1527264916555};\\\", \\\"{x:1306,y:580,t:1527264916571};\\\", \\\"{x:1306,y:579,t:1527264916587};\\\", \\\"{x:1306,y:578,t:1527264916604};\\\", \\\"{x:1305,y:577,t:1527264916622};\\\", \\\"{x:1305,y:576,t:1527264916643};\\\", \\\"{x:1305,y:575,t:1527264916655};\\\", \\\"{x:1305,y:574,t:1527264916672};\\\", \\\"{x:1304,y:572,t:1527264916688};\\\", \\\"{x:1303,y:570,t:1527264916705};\\\", \\\"{x:1303,y:569,t:1527264916731};\\\", \\\"{x:1303,y:568,t:1527264916739};\\\", \\\"{x:1303,y:567,t:1527264916755};\\\", \\\"{x:1303,y:566,t:1527264916779};\\\", \\\"{x:1303,y:565,t:1527264916795};\\\", \\\"{x:1303,y:564,t:1527264916805};\\\", \\\"{x:1303,y:563,t:1527264917690};\\\", \\\"{x:1303,y:562,t:1527264917705};\\\", \\\"{x:1301,y:561,t:1527264917721};\\\", \\\"{x:1298,y:559,t:1527264917738};\\\", \\\"{x:1297,y:559,t:1527264917755};\\\", \\\"{x:1296,y:558,t:1527264917772};\\\", \\\"{x:1294,y:558,t:1527264917789};\\\", \\\"{x:1290,y:556,t:1527264917805};\\\", \\\"{x:1289,y:556,t:1527264917822};\\\", \\\"{x:1288,y:555,t:1527264917839};\\\", \\\"{x:1287,y:554,t:1527264917855};\\\", \\\"{x:1286,y:554,t:1527264917899};\\\", \\\"{x:1285,y:554,t:1527264917939};\\\", \\\"{x:1284,y:554,t:1527264918147};\\\", \\\"{x:1285,y:554,t:1527264918162};\\\", \\\"{x:1287,y:554,t:1527264918179};\\\", \\\"{x:1287,y:555,t:1527264918188};\\\", \\\"{x:1288,y:555,t:1527264918205};\\\", \\\"{x:1289,y:555,t:1527264918339};\\\", \\\"{x:1290,y:556,t:1527264918356};\\\", \\\"{x:1291,y:556,t:1527264918373};\\\", \\\"{x:1293,y:556,t:1527264918389};\\\", \\\"{x:1294,y:556,t:1527264918406};\\\", \\\"{x:1295,y:558,t:1527264918423};\\\", \\\"{x:1296,y:558,t:1527264918440};\\\", \\\"{x:1297,y:558,t:1527264918455};\\\", \\\"{x:1299,y:558,t:1527264918850};\\\", \\\"{x:1299,y:557,t:1527264918858};\\\", \\\"{x:1299,y:556,t:1527264918874};\\\", \\\"{x:1299,y:555,t:1527264918889};\\\", \\\"{x:1299,y:553,t:1527264918906};\\\", \\\"{x:1299,y:552,t:1527264918922};\\\", \\\"{x:1300,y:551,t:1527264918955};\\\", \\\"{x:1302,y:551,t:1527264918979};\\\", \\\"{x:1303,y:551,t:1527264918990};\\\", \\\"{x:1307,y:551,t:1527264919007};\\\", \\\"{x:1310,y:558,t:1527264919022};\\\", \\\"{x:1314,y:572,t:1527264919040};\\\", \\\"{x:1315,y:593,t:1527264919057};\\\", \\\"{x:1315,y:616,t:1527264919073};\\\", \\\"{x:1315,y:643,t:1527264919089};\\\", \\\"{x:1315,y:681,t:1527264919107};\\\", \\\"{x:1315,y:707,t:1527264919123};\\\", \\\"{x:1313,y:727,t:1527264919139};\\\", \\\"{x:1309,y:742,t:1527264919156};\\\", \\\"{x:1305,y:757,t:1527264919173};\\\", \\\"{x:1301,y:768,t:1527264919189};\\\", \\\"{x:1298,y:774,t:1527264919207};\\\", \\\"{x:1295,y:779,t:1527264919223};\\\", \\\"{x:1291,y:785,t:1527264919240};\\\", \\\"{x:1288,y:791,t:1527264919257};\\\", \\\"{x:1283,y:801,t:1527264919273};\\\", \\\"{x:1281,y:810,t:1527264919289};\\\", \\\"{x:1276,y:818,t:1527264919306};\\\", \\\"{x:1274,y:821,t:1527264919323};\\\", \\\"{x:1273,y:826,t:1527264919340};\\\", \\\"{x:1267,y:836,t:1527264919357};\\\", \\\"{x:1261,y:850,t:1527264919373};\\\", \\\"{x:1256,y:863,t:1527264919389};\\\", \\\"{x:1253,y:871,t:1527264919407};\\\", \\\"{x:1249,y:876,t:1527264919423};\\\", \\\"{x:1246,y:879,t:1527264919440};\\\", \\\"{x:1244,y:880,t:1527264919456};\\\", \\\"{x:1241,y:881,t:1527264919474};\\\", \\\"{x:1236,y:881,t:1527264919490};\\\", \\\"{x:1228,y:881,t:1527264919507};\\\", \\\"{x:1221,y:881,t:1527264919524};\\\", \\\"{x:1206,y:872,t:1527264919540};\\\", \\\"{x:1187,y:860,t:1527264919557};\\\", \\\"{x:1165,y:842,t:1527264919574};\\\", \\\"{x:1148,y:824,t:1527264919591};\\\", \\\"{x:1136,y:807,t:1527264919607};\\\", \\\"{x:1128,y:795,t:1527264919625};\\\", \\\"{x:1123,y:782,t:1527264919641};\\\", \\\"{x:1121,y:768,t:1527264919657};\\\", \\\"{x:1120,y:751,t:1527264919674};\\\", \\\"{x:1122,y:722,t:1527264919690};\\\", \\\"{x:1130,y:700,t:1527264919706};\\\", \\\"{x:1142,y:678,t:1527264919723};\\\", \\\"{x:1157,y:660,t:1527264919740};\\\", \\\"{x:1169,y:645,t:1527264919756};\\\", \\\"{x:1183,y:631,t:1527264919773};\\\", \\\"{x:1198,y:616,t:1527264919790};\\\", \\\"{x:1212,y:601,t:1527264919807};\\\", \\\"{x:1224,y:589,t:1527264919823};\\\", \\\"{x:1237,y:575,t:1527264919841};\\\", \\\"{x:1245,y:567,t:1527264919857};\\\", \\\"{x:1252,y:562,t:1527264919874};\\\", \\\"{x:1260,y:552,t:1527264919890};\\\", \\\"{x:1263,y:547,t:1527264919907};\\\", \\\"{x:1266,y:542,t:1527264919923};\\\", \\\"{x:1268,y:539,t:1527264919940};\\\", \\\"{x:1268,y:537,t:1527264919957};\\\", \\\"{x:1269,y:534,t:1527264919974};\\\", \\\"{x:1270,y:532,t:1527264919991};\\\", \\\"{x:1270,y:531,t:1527264920007};\\\", \\\"{x:1271,y:530,t:1527264920024};\\\", \\\"{x:1271,y:529,t:1527264920042};\\\", \\\"{x:1272,y:526,t:1527264920058};\\\", \\\"{x:1273,y:524,t:1527264920107};\\\", \\\"{x:1273,y:523,t:1527264920124};\\\", \\\"{x:1275,y:523,t:1527264920235};\\\", \\\"{x:1276,y:522,t:1527264920243};\\\", \\\"{x:1277,y:522,t:1527264920259};\\\", \\\"{x:1279,y:521,t:1527264920274};\\\", \\\"{x:1280,y:520,t:1527264920291};\\\", \\\"{x:1281,y:520,t:1527264920626};\\\", \\\"{x:1283,y:520,t:1527264920640};\\\", \\\"{x:1285,y:520,t:1527264920658};\\\", \\\"{x:1287,y:522,t:1527264920674};\\\", \\\"{x:1287,y:524,t:1527264920691};\\\", \\\"{x:1287,y:526,t:1527264920714};\\\", \\\"{x:1289,y:526,t:1527264922891};\\\", \\\"{x:1291,y:526,t:1527264922909};\\\", \\\"{x:1294,y:528,t:1527264922926};\\\", \\\"{x:1301,y:531,t:1527264922943};\\\", \\\"{x:1302,y:532,t:1527264922960};\\\", \\\"{x:1303,y:533,t:1527264922975};\\\", \\\"{x:1304,y:535,t:1527264922993};\\\", \\\"{x:1304,y:536,t:1527264923018};\\\", \\\"{x:1304,y:537,t:1527264923027};\\\", \\\"{x:1304,y:538,t:1527264923219};\\\", \\\"{x:1304,y:539,t:1527264923244};\\\", \\\"{x:1304,y:540,t:1527264923261};\\\", \\\"{x:1305,y:541,t:1527264923277};\\\", \\\"{x:1305,y:543,t:1527264923293};\\\", \\\"{x:1305,y:546,t:1527264923310};\\\", \\\"{x:1306,y:548,t:1527264923327};\\\", \\\"{x:1306,y:550,t:1527264923343};\\\", \\\"{x:1306,y:553,t:1527264923360};\\\", \\\"{x:1306,y:555,t:1527264923377};\\\", \\\"{x:1306,y:557,t:1527264923393};\\\", \\\"{x:1306,y:559,t:1527264923409};\\\", \\\"{x:1306,y:562,t:1527264923426};\\\", \\\"{x:1306,y:564,t:1527264923443};\\\", \\\"{x:1306,y:565,t:1527264923459};\\\", \\\"{x:1306,y:566,t:1527264923522};\\\", \\\"{x:1306,y:568,t:1527264923530};\\\", \\\"{x:1306,y:569,t:1527264923543};\\\", \\\"{x:1306,y:573,t:1527264923560};\\\", \\\"{x:1304,y:576,t:1527264923577};\\\", \\\"{x:1301,y:582,t:1527264923594};\\\", \\\"{x:1298,y:585,t:1527264923609};\\\", \\\"{x:1295,y:590,t:1527264923626};\\\", \\\"{x:1292,y:593,t:1527264923644};\\\", \\\"{x:1289,y:595,t:1527264923660};\\\", \\\"{x:1287,y:597,t:1527264923677};\\\", \\\"{x:1286,y:597,t:1527264923694};\\\", \\\"{x:1286,y:598,t:1527264923710};\\\", \\\"{x:1284,y:598,t:1527264923835};\\\", \\\"{x:1283,y:598,t:1527264923867};\\\", \\\"{x:1281,y:598,t:1527264923979};\\\", \\\"{x:1280,y:598,t:1527264923994};\\\", \\\"{x:1278,y:598,t:1527264924012};\\\", \\\"{x:1278,y:597,t:1527264924235};\\\", \\\"{x:1278,y:596,t:1527264924251};\\\", \\\"{x:1278,y:595,t:1527264924275};\\\", \\\"{x:1278,y:594,t:1527264924291};\\\", \\\"{x:1278,y:592,t:1527264924315};\\\", \\\"{x:1278,y:591,t:1527264924347};\\\", \\\"{x:1278,y:589,t:1527264924379};\\\", \\\"{x:1278,y:588,t:1527264924403};\\\", \\\"{x:1278,y:586,t:1527264924427};\\\", \\\"{x:1278,y:585,t:1527264924451};\\\", \\\"{x:1278,y:583,t:1527264924475};\\\", \\\"{x:1278,y:581,t:1527264924491};\\\", \\\"{x:1278,y:579,t:1527264924507};\\\", \\\"{x:1279,y:577,t:1527264924523};\\\", \\\"{x:1279,y:576,t:1527264924538};\\\", \\\"{x:1279,y:575,t:1527264924547};\\\", \\\"{x:1279,y:574,t:1527264924563};\\\", \\\"{x:1279,y:573,t:1527264924578};\\\", \\\"{x:1280,y:572,t:1527264924595};\\\", \\\"{x:1281,y:570,t:1527264924611};\\\", \\\"{x:1281,y:569,t:1527264924631};\\\", \\\"{x:1281,y:567,t:1527264924660};\\\", \\\"{x:1281,y:566,t:1527264924690};\\\", \\\"{x:1281,y:567,t:1527264926091};\\\", \\\"{x:1281,y:571,t:1527264926101};\\\", \\\"{x:1281,y:575,t:1527264926113};\\\", \\\"{x:1281,y:586,t:1527264926129};\\\", \\\"{x:1278,y:597,t:1527264926145};\\\", \\\"{x:1272,y:609,t:1527264926162};\\\", \\\"{x:1260,y:631,t:1527264926178};\\\", \\\"{x:1253,y:643,t:1527264926196};\\\", \\\"{x:1244,y:658,t:1527264926213};\\\", \\\"{x:1238,y:669,t:1527264926229};\\\", \\\"{x:1233,y:681,t:1527264926245};\\\", \\\"{x:1228,y:693,t:1527264926262};\\\", \\\"{x:1223,y:704,t:1527264926279};\\\", \\\"{x:1217,y:713,t:1527264926296};\\\", \\\"{x:1213,y:724,t:1527264926312};\\\", \\\"{x:1210,y:733,t:1527264926329};\\\", \\\"{x:1205,y:750,t:1527264926347};\\\", \\\"{x:1205,y:755,t:1527264926362};\\\", \\\"{x:1203,y:772,t:1527264926379};\\\", \\\"{x:1202,y:780,t:1527264926397};\\\", \\\"{x:1202,y:789,t:1527264926412};\\\", \\\"{x:1202,y:797,t:1527264926429};\\\", \\\"{x:1202,y:806,t:1527264926447};\\\", \\\"{x:1202,y:820,t:1527264926463};\\\", \\\"{x:1206,y:833,t:1527264926479};\\\", \\\"{x:1209,y:842,t:1527264926497};\\\", \\\"{x:1210,y:846,t:1527264926512};\\\", \\\"{x:1211,y:851,t:1527264926529};\\\", \\\"{x:1212,y:853,t:1527264926546};\\\", \\\"{x:1212,y:854,t:1527264926563};\\\", \\\"{x:1213,y:854,t:1527264926851};\\\", \\\"{x:1215,y:854,t:1527264926863};\\\", \\\"{x:1220,y:848,t:1527264926879};\\\", \\\"{x:1223,y:844,t:1527264926897};\\\", \\\"{x:1225,y:841,t:1527264926914};\\\", \\\"{x:1227,y:838,t:1527264926930};\\\", \\\"{x:1228,y:837,t:1527264926946};\\\", \\\"{x:1229,y:836,t:1527264926963};\\\", \\\"{x:1229,y:835,t:1527264927003};\\\", \\\"{x:1228,y:835,t:1527264927043};\\\", \\\"{x:1227,y:835,t:1527264927059};\\\", \\\"{x:1225,y:835,t:1527264927075};\\\", \\\"{x:1223,y:835,t:1527264927082};\\\", \\\"{x:1222,y:836,t:1527264927099};\\\", \\\"{x:1221,y:836,t:1527264927114};\\\", \\\"{x:1220,y:837,t:1527264927131};\\\", \\\"{x:1218,y:839,t:1527264927146};\\\", \\\"{x:1217,y:840,t:1527264927163};\\\", \\\"{x:1216,y:840,t:1527264927443};\\\", \\\"{x:1215,y:841,t:1527264927499};\\\", \\\"{x:1214,y:841,t:1527264927603};\\\", \\\"{x:1211,y:837,t:1527264927614};\\\", \\\"{x:1207,y:831,t:1527264927630};\\\", \\\"{x:1203,y:825,t:1527264927647};\\\", \\\"{x:1199,y:818,t:1527264927664};\\\", \\\"{x:1193,y:812,t:1527264927680};\\\", \\\"{x:1188,y:807,t:1527264927696};\\\", \\\"{x:1183,y:804,t:1527264927713};\\\", \\\"{x:1176,y:800,t:1527264927730};\\\", \\\"{x:1174,y:800,t:1527264927746};\\\", \\\"{x:1172,y:797,t:1527264927763};\\\", \\\"{x:1170,y:797,t:1527264927780};\\\", \\\"{x:1168,y:795,t:1527264927796};\\\", \\\"{x:1167,y:794,t:1527264927813};\\\", \\\"{x:1165,y:790,t:1527264927830};\\\", \\\"{x:1165,y:788,t:1527264927850};\\\", \\\"{x:1165,y:787,t:1527264927863};\\\", \\\"{x:1165,y:785,t:1527264927879};\\\", \\\"{x:1165,y:781,t:1527264927896};\\\", \\\"{x:1165,y:777,t:1527264927913};\\\", \\\"{x:1166,y:769,t:1527264927930};\\\", \\\"{x:1171,y:761,t:1527264927946};\\\", \\\"{x:1173,y:758,t:1527264927963};\\\", \\\"{x:1174,y:757,t:1527264927987};\\\", \\\"{x:1175,y:757,t:1527264928043};\\\", \\\"{x:1176,y:758,t:1527264928059};\\\", \\\"{x:1177,y:760,t:1527264928075};\\\", \\\"{x:1177,y:761,t:1527264928099};\\\", \\\"{x:1177,y:762,t:1527264928114};\\\", \\\"{x:1177,y:763,t:1527264928130};\\\", \\\"{x:1179,y:764,t:1527264928403};\\\", \\\"{x:1181,y:765,t:1527264928426};\\\", \\\"{x:1181,y:766,t:1527264928442};\\\", \\\"{x:1181,y:768,t:1527264928466};\\\", \\\"{x:1175,y:765,t:1527264929157};\\\", \\\"{x:1165,y:761,t:1527264929165};\\\", \\\"{x:1135,y:751,t:1527264929182};\\\", \\\"{x:1080,y:740,t:1527264929199};\\\", \\\"{x:997,y:729,t:1527264929214};\\\", \\\"{x:900,y:718,t:1527264929232};\\\", \\\"{x:795,y:702,t:1527264929248};\\\", \\\"{x:697,y:688,t:1527264929264};\\\", \\\"{x:612,y:678,t:1527264929281};\\\", \\\"{x:512,y:669,t:1527264929298};\\\", \\\"{x:478,y:669,t:1527264929316};\\\", \\\"{x:460,y:669,t:1527264929331};\\\", \\\"{x:452,y:670,t:1527264929348};\\\", \\\"{x:451,y:671,t:1527264929364};\\\", \\\"{x:452,y:675,t:1527264929381};\\\", \\\"{x:462,y:678,t:1527264929398};\\\", \\\"{x:465,y:679,t:1527264929415};\\\", \\\"{x:466,y:679,t:1527264929514};\\\", \\\"{x:471,y:677,t:1527264929531};\\\", \\\"{x:485,y:669,t:1527264929549};\\\", \\\"{x:500,y:657,t:1527264929566};\\\", \\\"{x:515,y:637,t:1527264929582};\\\", \\\"{x:534,y:609,t:1527264929599};\\\", \\\"{x:551,y:587,t:1527264929615};\\\", \\\"{x:564,y:570,t:1527264929632};\\\", \\\"{x:578,y:558,t:1527264929648};\\\", \\\"{x:590,y:548,t:1527264929665};\\\", \\\"{x:607,y:534,t:1527264929682};\\\", \\\"{x:614,y:529,t:1527264929698};\\\", \\\"{x:617,y:527,t:1527264929715};\\\", \\\"{x:620,y:525,t:1527264929732};\\\", \\\"{x:621,y:525,t:1527264929770};\\\", \\\"{x:622,y:524,t:1527264929786};\\\", \\\"{x:623,y:522,t:1527264929799};\\\", \\\"{x:623,y:520,t:1527264929815};\\\", \\\"{x:623,y:519,t:1527264929831};\\\", \\\"{x:623,y:517,t:1527264929849};\\\", \\\"{x:623,y:514,t:1527264929865};\\\", \\\"{x:620,y:508,t:1527264929882};\\\", \\\"{x:615,y:503,t:1527264929898};\\\", \\\"{x:612,y:501,t:1527264929915};\\\", \\\"{x:610,y:498,t:1527264929932};\\\", \\\"{x:609,y:497,t:1527264929949};\\\", \\\"{x:606,y:499,t:1527264930298};\\\", \\\"{x:597,y:520,t:1527264930316};\\\", \\\"{x:586,y:546,t:1527264930332};\\\", \\\"{x:573,y:569,t:1527264930349};\\\", \\\"{x:558,y:595,t:1527264930366};\\\", \\\"{x:549,y:614,t:1527264930382};\\\", \\\"{x:543,y:629,t:1527264930399};\\\", \\\"{x:541,y:638,t:1527264930417};\\\", \\\"{x:541,y:645,t:1527264930432};\\\", \\\"{x:540,y:652,t:1527264930449};\\\", \\\"{x:539,y:658,t:1527264930465};\\\", \\\"{x:537,y:667,t:1527264930482};\\\", \\\"{x:532,y:683,t:1527264930498};\\\", \\\"{x:531,y:693,t:1527264930515};\\\", \\\"{x:531,y:700,t:1527264930531};\\\", \\\"{x:530,y:703,t:1527264930548};\\\", \\\"{x:530,y:708,t:1527264930565};\\\", \\\"{x:528,y:712,t:1527264930582};\\\", \\\"{x:528,y:717,t:1527264930598};\\\", \\\"{x:527,y:718,t:1527264930615};\\\", \\\"{x:526,y:720,t:1527264930632};\\\", \\\"{x:526,y:721,t:1527264930647};\\\", \\\"{x:525,y:722,t:1527264930666};\\\", \\\"{x:525,y:723,t:1527264930683};\\\", \\\"{x:525,y:727,t:1527264930699};\\\", \\\"{x:525,y:730,t:1527264930716};\\\", \\\"{x:525,y:734,t:1527264930733};\\\" ] }, { \\\"rt\\\": 93347, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 610475, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -O -B -J -I -J -I -F -F -F -I -I -J -B -E -X -X -B -B -B -J -J -J -J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:735,t:1527264932603};\\\", \\\"{x:530,y:738,t:1527264932971};\\\", \\\"{x:552,y:748,t:1527264932987};\\\", \\\"{x:576,y:755,t:1527264933004};\\\", \\\"{x:601,y:758,t:1527264933019};\\\", \\\"{x:628,y:761,t:1527264933033};\\\", \\\"{x:653,y:761,t:1527264933051};\\\", \\\"{x:669,y:761,t:1527264933068};\\\", \\\"{x:678,y:761,t:1527264933083};\\\", \\\"{x:684,y:761,t:1527264933101};\\\", \\\"{x:687,y:762,t:1527264933118};\\\", \\\"{x:692,y:765,t:1527264933133};\\\", \\\"{x:696,y:765,t:1527264933151};\\\", \\\"{x:699,y:768,t:1527264933168};\\\", \\\"{x:701,y:769,t:1527264933184};\\\", \\\"{x:703,y:769,t:1527264933619};\\\", \\\"{x:711,y:769,t:1527264933635};\\\", \\\"{x:725,y:767,t:1527264933651};\\\", \\\"{x:733,y:766,t:1527264933669};\\\", \\\"{x:739,y:765,t:1527264933685};\\\", \\\"{x:743,y:763,t:1527264933701};\\\", \\\"{x:745,y:763,t:1527264933718};\\\", \\\"{x:747,y:761,t:1527264933735};\\\", \\\"{x:753,y:758,t:1527264933751};\\\", \\\"{x:755,y:756,t:1527264933769};\\\", \\\"{x:764,y:754,t:1527264933785};\\\", \\\"{x:777,y:753,t:1527264933802};\\\", \\\"{x:795,y:751,t:1527264933819};\\\", \\\"{x:802,y:751,t:1527264933834};\\\", \\\"{x:806,y:751,t:1527264933851};\\\", \\\"{x:805,y:751,t:1527264933907};\\\", \\\"{x:804,y:751,t:1527264933918};\\\", \\\"{x:796,y:749,t:1527264933936};\\\", \\\"{x:796,y:748,t:1527264934211};\\\", \\\"{x:797,y:747,t:1527264934250};\\\", \\\"{x:798,y:747,t:1527264934259};\\\", \\\"{x:801,y:747,t:1527264934269};\\\", \\\"{x:809,y:747,t:1527264934286};\\\", \\\"{x:822,y:746,t:1527264934302};\\\", \\\"{x:837,y:744,t:1527264934318};\\\", \\\"{x:859,y:742,t:1527264934335};\\\", \\\"{x:885,y:738,t:1527264934353};\\\", \\\"{x:926,y:731,t:1527264934370};\\\", \\\"{x:974,y:724,t:1527264934385};\\\", \\\"{x:1046,y:713,t:1527264934403};\\\", \\\"{x:1097,y:706,t:1527264934419};\\\", \\\"{x:1136,y:699,t:1527264934436};\\\", \\\"{x:1168,y:694,t:1527264934453};\\\", \\\"{x:1190,y:689,t:1527264934469};\\\", \\\"{x:1205,y:687,t:1527264934485};\\\", \\\"{x:1213,y:687,t:1527264934503};\\\", \\\"{x:1215,y:687,t:1527264934520};\\\", \\\"{x:1216,y:687,t:1527264934536};\\\", \\\"{x:1217,y:687,t:1527264934552};\\\", \\\"{x:1219,y:687,t:1527264934571};\\\", \\\"{x:1220,y:687,t:1527264934586};\\\", \\\"{x:1229,y:687,t:1527264934603};\\\", \\\"{x:1242,y:685,t:1527264934620};\\\", \\\"{x:1253,y:683,t:1527264934635};\\\", \\\"{x:1267,y:682,t:1527264934653};\\\", \\\"{x:1276,y:678,t:1527264934670};\\\", \\\"{x:1287,y:675,t:1527264934686};\\\", \\\"{x:1288,y:674,t:1527264934703};\\\", \\\"{x:1289,y:674,t:1527264934803};\\\", \\\"{x:1289,y:673,t:1527264934859};\\\", \\\"{x:1289,y:672,t:1527264934875};\\\", \\\"{x:1288,y:671,t:1527264934891};\\\", \\\"{x:1288,y:670,t:1527264934903};\\\", \\\"{x:1286,y:668,t:1527264934920};\\\", \\\"{x:1284,y:665,t:1527264934937};\\\", \\\"{x:1281,y:661,t:1527264934952};\\\", \\\"{x:1278,y:659,t:1527264934970};\\\", \\\"{x:1278,y:658,t:1527264934987};\\\", \\\"{x:1277,y:658,t:1527264935132};\\\", \\\"{x:1275,y:657,t:1527264935163};\\\", \\\"{x:1274,y:656,t:1527264935267};\\\", \\\"{x:1273,y:656,t:1527264935547};\\\", \\\"{x:1272,y:655,t:1527264935555};\\\", \\\"{x:1273,y:650,t:1527264935786};\\\", \\\"{x:1289,y:638,t:1527264935803};\\\", \\\"{x:1304,y:628,t:1527264935820};\\\", \\\"{x:1315,y:622,t:1527264935836};\\\", \\\"{x:1322,y:618,t:1527264935854};\\\", \\\"{x:1329,y:613,t:1527264935870};\\\", \\\"{x:1336,y:610,t:1527264935886};\\\", \\\"{x:1339,y:608,t:1527264935903};\\\", \\\"{x:1344,y:606,t:1527264935921};\\\", \\\"{x:1350,y:604,t:1527264935937};\\\", \\\"{x:1357,y:603,t:1527264935954};\\\", \\\"{x:1369,y:602,t:1527264935970};\\\", \\\"{x:1376,y:602,t:1527264935987};\\\", \\\"{x:1380,y:602,t:1527264936004};\\\", \\\"{x:1386,y:602,t:1527264936020};\\\", \\\"{x:1395,y:603,t:1527264936037};\\\", \\\"{x:1404,y:606,t:1527264936054};\\\", \\\"{x:1411,y:608,t:1527264936070};\\\", \\\"{x:1415,y:609,t:1527264936088};\\\", \\\"{x:1419,y:610,t:1527264936104};\\\", \\\"{x:1421,y:611,t:1527264936120};\\\", \\\"{x:1423,y:611,t:1527264936138};\\\", \\\"{x:1426,y:611,t:1527264936154};\\\", \\\"{x:1428,y:611,t:1527264936171};\\\", \\\"{x:1429,y:611,t:1527264936188};\\\", \\\"{x:1430,y:611,t:1527264936203};\\\", \\\"{x:1432,y:611,t:1527264936221};\\\", \\\"{x:1434,y:611,t:1527264936238};\\\", \\\"{x:1436,y:611,t:1527264936254};\\\", \\\"{x:1439,y:611,t:1527264936271};\\\", \\\"{x:1441,y:611,t:1527264936288};\\\", \\\"{x:1443,y:611,t:1527264936304};\\\", \\\"{x:1446,y:611,t:1527264936320};\\\", \\\"{x:1450,y:611,t:1527264936338};\\\", \\\"{x:1456,y:610,t:1527264936354};\\\", \\\"{x:1471,y:610,t:1527264936371};\\\", \\\"{x:1483,y:610,t:1527264936388};\\\", \\\"{x:1496,y:610,t:1527264936404};\\\", \\\"{x:1508,y:610,t:1527264936421};\\\", \\\"{x:1517,y:610,t:1527264936438};\\\", \\\"{x:1522,y:613,t:1527264936454};\\\", \\\"{x:1533,y:619,t:1527264936471};\\\", \\\"{x:1542,y:624,t:1527264936487};\\\", \\\"{x:1550,y:628,t:1527264936504};\\\", \\\"{x:1558,y:634,t:1527264936521};\\\", \\\"{x:1565,y:640,t:1527264936538};\\\", \\\"{x:1571,y:644,t:1527264936555};\\\", \\\"{x:1577,y:649,t:1527264936571};\\\", \\\"{x:1580,y:652,t:1527264936587};\\\", \\\"{x:1583,y:655,t:1527264936605};\\\", \\\"{x:1584,y:659,t:1527264936620};\\\", \\\"{x:1585,y:661,t:1527264936638};\\\", \\\"{x:1586,y:662,t:1527264936655};\\\", \\\"{x:1586,y:664,t:1527264936670};\\\", \\\"{x:1588,y:668,t:1527264936688};\\\", \\\"{x:1589,y:671,t:1527264936705};\\\", \\\"{x:1590,y:675,t:1527264936721};\\\", \\\"{x:1592,y:682,t:1527264936737};\\\", \\\"{x:1593,y:690,t:1527264936754};\\\", \\\"{x:1594,y:695,t:1527264936770};\\\", \\\"{x:1596,y:698,t:1527264936787};\\\", \\\"{x:1597,y:701,t:1527264936804};\\\", \\\"{x:1597,y:705,t:1527264936820};\\\", \\\"{x:1597,y:709,t:1527264936837};\\\", \\\"{x:1596,y:714,t:1527264936854};\\\", \\\"{x:1592,y:720,t:1527264936870};\\\", \\\"{x:1589,y:723,t:1527264936887};\\\", \\\"{x:1585,y:727,t:1527264936905};\\\", \\\"{x:1581,y:731,t:1527264936920};\\\", \\\"{x:1574,y:735,t:1527264936937};\\\", \\\"{x:1565,y:739,t:1527264936955};\\\", \\\"{x:1557,y:741,t:1527264936971};\\\", \\\"{x:1547,y:745,t:1527264936988};\\\", \\\"{x:1536,y:749,t:1527264937004};\\\", \\\"{x:1524,y:753,t:1527264937022};\\\", \\\"{x:1517,y:755,t:1527264937037};\\\", \\\"{x:1507,y:760,t:1527264937055};\\\", \\\"{x:1500,y:763,t:1527264937072};\\\", \\\"{x:1492,y:766,t:1527264937088};\\\", \\\"{x:1486,y:766,t:1527264937105};\\\", \\\"{x:1480,y:766,t:1527264937122};\\\", \\\"{x:1477,y:766,t:1527264937137};\\\", \\\"{x:1472,y:764,t:1527264937155};\\\", \\\"{x:1472,y:763,t:1527264937171};\\\", \\\"{x:1472,y:761,t:1527264937188};\\\", \\\"{x:1475,y:755,t:1527264937205};\\\", \\\"{x:1480,y:750,t:1527264937222};\\\", \\\"{x:1490,y:741,t:1527264937238};\\\", \\\"{x:1501,y:727,t:1527264937255};\\\", \\\"{x:1511,y:715,t:1527264937272};\\\", \\\"{x:1524,y:693,t:1527264937288};\\\", \\\"{x:1534,y:673,t:1527264937304};\\\", \\\"{x:1545,y:648,t:1527264937321};\\\", \\\"{x:1554,y:620,t:1527264937337};\\\", \\\"{x:1564,y:589,t:1527264937355};\\\", \\\"{x:1568,y:572,t:1527264937372};\\\", \\\"{x:1571,y:555,t:1527264937387};\\\", \\\"{x:1574,y:540,t:1527264937405};\\\", \\\"{x:1574,y:529,t:1527264937422};\\\", \\\"{x:1574,y:522,t:1527264937439};\\\", \\\"{x:1574,y:521,t:1527264937455};\\\", \\\"{x:1574,y:520,t:1527264937472};\\\", \\\"{x:1574,y:519,t:1527264937499};\\\", \\\"{x:1572,y:519,t:1527264937531};\\\", \\\"{x:1571,y:519,t:1527264937539};\\\", \\\"{x:1564,y:519,t:1527264937555};\\\", \\\"{x:1558,y:520,t:1527264937572};\\\", \\\"{x:1549,y:523,t:1527264937589};\\\", \\\"{x:1543,y:526,t:1527264937605};\\\", \\\"{x:1535,y:532,t:1527264937622};\\\", \\\"{x:1528,y:537,t:1527264937639};\\\", \\\"{x:1517,y:545,t:1527264937655};\\\", \\\"{x:1504,y:557,t:1527264937672};\\\", \\\"{x:1493,y:567,t:1527264937689};\\\", \\\"{x:1481,y:576,t:1527264937705};\\\", \\\"{x:1468,y:587,t:1527264937721};\\\", \\\"{x:1452,y:599,t:1527264937739};\\\", \\\"{x:1444,y:603,t:1527264937755};\\\", \\\"{x:1437,y:609,t:1527264937772};\\\", \\\"{x:1430,y:612,t:1527264937789};\\\", \\\"{x:1427,y:615,t:1527264937805};\\\", \\\"{x:1423,y:617,t:1527264937822};\\\", \\\"{x:1419,y:620,t:1527264937838};\\\", \\\"{x:1416,y:623,t:1527264937854};\\\", \\\"{x:1413,y:625,t:1527264937871};\\\", \\\"{x:1407,y:632,t:1527264937888};\\\", \\\"{x:1403,y:640,t:1527264937906};\\\", \\\"{x:1398,y:649,t:1527264937922};\\\", \\\"{x:1390,y:662,t:1527264937938};\\\", \\\"{x:1383,y:670,t:1527264937955};\\\", \\\"{x:1373,y:682,t:1527264937972};\\\", \\\"{x:1367,y:689,t:1527264937989};\\\", \\\"{x:1360,y:698,t:1527264938005};\\\", \\\"{x:1355,y:707,t:1527264938021};\\\", \\\"{x:1350,y:714,t:1527264938039};\\\", \\\"{x:1346,y:718,t:1527264938056};\\\", \\\"{x:1344,y:722,t:1527264938072};\\\", \\\"{x:1341,y:727,t:1527264938089};\\\", \\\"{x:1340,y:730,t:1527264938106};\\\", \\\"{x:1338,y:732,t:1527264938121};\\\", \\\"{x:1338,y:739,t:1527264938139};\\\", \\\"{x:1338,y:742,t:1527264938156};\\\", \\\"{x:1338,y:746,t:1527264938172};\\\", \\\"{x:1338,y:750,t:1527264938189};\\\", \\\"{x:1338,y:753,t:1527264938205};\\\", \\\"{x:1338,y:755,t:1527264938221};\\\", \\\"{x:1339,y:757,t:1527264938238};\\\", \\\"{x:1342,y:760,t:1527264938255};\\\", \\\"{x:1342,y:761,t:1527264938272};\\\", \\\"{x:1344,y:761,t:1527264938291};\\\", \\\"{x:1345,y:761,t:1527264938306};\\\", \\\"{x:1346,y:762,t:1527264938322};\\\", \\\"{x:1347,y:762,t:1527264938339};\\\", \\\"{x:1347,y:763,t:1527264938395};\\\", \\\"{x:1347,y:764,t:1527264938410};\\\", \\\"{x:1345,y:765,t:1527264938426};\\\", \\\"{x:1343,y:767,t:1527264938438};\\\", \\\"{x:1338,y:768,t:1527264938455};\\\", \\\"{x:1329,y:771,t:1527264938472};\\\", \\\"{x:1319,y:773,t:1527264938489};\\\", \\\"{x:1309,y:776,t:1527264938505};\\\", \\\"{x:1295,y:781,t:1527264938521};\\\", \\\"{x:1284,y:785,t:1527264938538};\\\", \\\"{x:1274,y:789,t:1527264938555};\\\", \\\"{x:1263,y:795,t:1527264938572};\\\", \\\"{x:1255,y:798,t:1527264938588};\\\", \\\"{x:1249,y:802,t:1527264938606};\\\", \\\"{x:1243,y:805,t:1527264938622};\\\", \\\"{x:1238,y:808,t:1527264938638};\\\", \\\"{x:1237,y:809,t:1527264938656};\\\", \\\"{x:1235,y:811,t:1527264938673};\\\", \\\"{x:1234,y:811,t:1527264938689};\\\", \\\"{x:1232,y:813,t:1527264938706};\\\", \\\"{x:1229,y:815,t:1527264938723};\\\", \\\"{x:1228,y:815,t:1527264938755};\\\", \\\"{x:1226,y:816,t:1527264938773};\\\", \\\"{x:1225,y:817,t:1527264938790};\\\", \\\"{x:1224,y:817,t:1527264938805};\\\", \\\"{x:1221,y:818,t:1527264938823};\\\", \\\"{x:1218,y:818,t:1527264938840};\\\", \\\"{x:1215,y:820,t:1527264938856};\\\", \\\"{x:1213,y:821,t:1527264938873};\\\", \\\"{x:1211,y:822,t:1527264938889};\\\", \\\"{x:1210,y:822,t:1527264938915};\\\", \\\"{x:1208,y:822,t:1527264939291};\\\", \\\"{x:1207,y:822,t:1527264941019};\\\", \\\"{x:1206,y:821,t:1527264941051};\\\", \\\"{x:1205,y:820,t:1527264941058};\\\", \\\"{x:1203,y:820,t:1527264941155};\\\", \\\"{x:1201,y:819,t:1527264941163};\\\", \\\"{x:1201,y:818,t:1527264941175};\\\", \\\"{x:1197,y:814,t:1527264941191};\\\", \\\"{x:1196,y:811,t:1527264941207};\\\", \\\"{x:1195,y:808,t:1527264941225};\\\", \\\"{x:1194,y:805,t:1527264941241};\\\", \\\"{x:1194,y:804,t:1527264941258};\\\", \\\"{x:1193,y:801,t:1527264941275};\\\", \\\"{x:1192,y:799,t:1527264941291};\\\", \\\"{x:1191,y:795,t:1527264941308};\\\", \\\"{x:1189,y:791,t:1527264941325};\\\", \\\"{x:1187,y:786,t:1527264941341};\\\", \\\"{x:1186,y:785,t:1527264941358};\\\", \\\"{x:1186,y:784,t:1527264941375};\\\", \\\"{x:1185,y:781,t:1527264941391};\\\", \\\"{x:1185,y:780,t:1527264941408};\\\", \\\"{x:1185,y:779,t:1527264941435};\\\", \\\"{x:1185,y:777,t:1527264941467};\\\", \\\"{x:1184,y:776,t:1527264941490};\\\", \\\"{x:1183,y:775,t:1527264941522};\\\", \\\"{x:1182,y:774,t:1527264941546};\\\", \\\"{x:1182,y:773,t:1527264941586};\\\", \\\"{x:1181,y:772,t:1527264941666};\\\", \\\"{x:1181,y:771,t:1527264941691};\\\", \\\"{x:1180,y:770,t:1527264941706};\\\", \\\"{x:1179,y:769,t:1527264941731};\\\", \\\"{x:1179,y:768,t:1527264941755};\\\", \\\"{x:1179,y:767,t:1527264941774};\\\", \\\"{x:1180,y:767,t:1527264947226};\\\", \\\"{x:1185,y:767,t:1527264947234};\\\", \\\"{x:1189,y:770,t:1527264947247};\\\", \\\"{x:1200,y:780,t:1527264947264};\\\", \\\"{x:1205,y:786,t:1527264947279};\\\", \\\"{x:1208,y:790,t:1527264947296};\\\", \\\"{x:1209,y:793,t:1527264947313};\\\", \\\"{x:1209,y:794,t:1527264947330};\\\", \\\"{x:1211,y:796,t:1527264947347};\\\", \\\"{x:1212,y:798,t:1527264947363};\\\", \\\"{x:1213,y:804,t:1527264947379};\\\", \\\"{x:1214,y:807,t:1527264947396};\\\", \\\"{x:1216,y:812,t:1527264947413};\\\", \\\"{x:1217,y:815,t:1527264947430};\\\", \\\"{x:1217,y:816,t:1527264947447};\\\", \\\"{x:1217,y:817,t:1527264947463};\\\", \\\"{x:1217,y:818,t:1527264947539};\\\", \\\"{x:1217,y:819,t:1527264947723};\\\", \\\"{x:1217,y:820,t:1527264947811};\\\", \\\"{x:1217,y:821,t:1527264947818};\\\", \\\"{x:1217,y:822,t:1527264947835};\\\", \\\"{x:1217,y:823,t:1527264947847};\\\", \\\"{x:1217,y:824,t:1527264947863};\\\", \\\"{x:1216,y:825,t:1527264947881};\\\", \\\"{x:1215,y:827,t:1527264947896};\\\", \\\"{x:1214,y:828,t:1527264950531};\\\", \\\"{x:1213,y:828,t:1527264950562};\\\", \\\"{x:1209,y:828,t:1527264952386};\\\", \\\"{x:1203,y:828,t:1527264952401};\\\", \\\"{x:1196,y:828,t:1527264952417};\\\", \\\"{x:1192,y:828,t:1527264952433};\\\", \\\"{x:1187,y:828,t:1527264952451};\\\", \\\"{x:1185,y:828,t:1527264952468};\\\", \\\"{x:1184,y:828,t:1527264952611};\\\", \\\"{x:1182,y:828,t:1527264952627};\\\", \\\"{x:1181,y:828,t:1527264952659};\\\", \\\"{x:1180,y:828,t:1527264952675};\\\", \\\"{x:1178,y:828,t:1527264952691};\\\", \\\"{x:1176,y:828,t:1527264952707};\\\", \\\"{x:1175,y:828,t:1527264952722};\\\", \\\"{x:1172,y:828,t:1527264952734};\\\", \\\"{x:1171,y:828,t:1527264952750};\\\", \\\"{x:1168,y:828,t:1527264952769};\\\", \\\"{x:1165,y:828,t:1527264952784};\\\", \\\"{x:1163,y:828,t:1527264952800};\\\", \\\"{x:1161,y:829,t:1527264952818};\\\", \\\"{x:1159,y:830,t:1527264952835};\\\", \\\"{x:1158,y:830,t:1527264952851};\\\", \\\"{x:1158,y:831,t:1527264953068};\\\", \\\"{x:1158,y:832,t:1527264953084};\\\", \\\"{x:1159,y:832,t:1527264953100};\\\", \\\"{x:1160,y:832,t:1527264953118};\\\", \\\"{x:1161,y:832,t:1527264953135};\\\", \\\"{x:1162,y:832,t:1527264953151};\\\", \\\"{x:1163,y:832,t:1527264953169};\\\", \\\"{x:1168,y:832,t:1527264953185};\\\", \\\"{x:1171,y:832,t:1527264953201};\\\", \\\"{x:1172,y:832,t:1527264953218};\\\", \\\"{x:1174,y:832,t:1527264953234};\\\", \\\"{x:1175,y:832,t:1527264953250};\\\", \\\"{x:1178,y:832,t:1527264953267};\\\", \\\"{x:1179,y:832,t:1527264953284};\\\", \\\"{x:1180,y:832,t:1527264953300};\\\", \\\"{x:1181,y:831,t:1527264953330};\\\", \\\"{x:1182,y:831,t:1527264953345};\\\", \\\"{x:1182,y:830,t:1527264953354};\\\", \\\"{x:1183,y:830,t:1527264953370};\\\", \\\"{x:1183,y:828,t:1527264953386};\\\", \\\"{x:1183,y:827,t:1527264953402};\\\", \\\"{x:1183,y:824,t:1527264953418};\\\", \\\"{x:1183,y:821,t:1527264953434};\\\", \\\"{x:1183,y:817,t:1527264953452};\\\", \\\"{x:1183,y:814,t:1527264953467};\\\", \\\"{x:1182,y:811,t:1527264953484};\\\", \\\"{x:1181,y:807,t:1527264953501};\\\", \\\"{x:1180,y:804,t:1527264953517};\\\", \\\"{x:1179,y:800,t:1527264953535};\\\", \\\"{x:1179,y:799,t:1527264953552};\\\", \\\"{x:1179,y:797,t:1527264953568};\\\", \\\"{x:1178,y:796,t:1527264953585};\\\", \\\"{x:1178,y:795,t:1527264953602};\\\", \\\"{x:1177,y:793,t:1527264953618};\\\", \\\"{x:1176,y:791,t:1527264953635};\\\", \\\"{x:1176,y:788,t:1527264953651};\\\", \\\"{x:1174,y:785,t:1527264953668};\\\", \\\"{x:1174,y:784,t:1527264953684};\\\", \\\"{x:1173,y:782,t:1527264953701};\\\", \\\"{x:1173,y:781,t:1527264953717};\\\", \\\"{x:1173,y:780,t:1527264953734};\\\", \\\"{x:1174,y:778,t:1527264954090};\\\", \\\"{x:1174,y:777,t:1527264954114};\\\", \\\"{x:1176,y:777,t:1527264954131};\\\", \\\"{x:1177,y:777,t:1527264954139};\\\", \\\"{x:1178,y:776,t:1527264954163};\\\", \\\"{x:1178,y:775,t:1527264954170};\\\", \\\"{x:1179,y:774,t:1527264954194};\\\", \\\"{x:1179,y:773,t:1527264954203};\\\", \\\"{x:1180,y:772,t:1527264954219};\\\", \\\"{x:1181,y:770,t:1527264954235};\\\", \\\"{x:1181,y:769,t:1527264954469};\\\", \\\"{x:1181,y:768,t:1527264954489};\\\", \\\"{x:1181,y:766,t:1527264954504};\\\", \\\"{x:1181,y:765,t:1527264954522};\\\", \\\"{x:1181,y:764,t:1527264954539};\\\", \\\"{x:1183,y:764,t:1527264960397};\\\", \\\"{x:1189,y:766,t:1527264960410};\\\", \\\"{x:1201,y:771,t:1527264960426};\\\", \\\"{x:1206,y:772,t:1527264960443};\\\", \\\"{x:1212,y:775,t:1527264960459};\\\", \\\"{x:1218,y:777,t:1527264960477};\\\", \\\"{x:1223,y:779,t:1527264960493};\\\", \\\"{x:1234,y:778,t:1527264960510};\\\", \\\"{x:1251,y:772,t:1527264960527};\\\", \\\"{x:1271,y:763,t:1527264960543};\\\", \\\"{x:1289,y:755,t:1527264960560};\\\", \\\"{x:1309,y:745,t:1527264960576};\\\", \\\"{x:1329,y:738,t:1527264960593};\\\", \\\"{x:1340,y:729,t:1527264960610};\\\", \\\"{x:1347,y:725,t:1527264960627};\\\", \\\"{x:1351,y:721,t:1527264960643};\\\", \\\"{x:1357,y:711,t:1527264960660};\\\", \\\"{x:1361,y:702,t:1527264960677};\\\", \\\"{x:1362,y:696,t:1527264960693};\\\", \\\"{x:1365,y:691,t:1527264960710};\\\", \\\"{x:1365,y:689,t:1527264960822};\\\", \\\"{x:1365,y:688,t:1527264960854};\\\", \\\"{x:1363,y:687,t:1527264960878};\\\", \\\"{x:1362,y:687,t:1527264960893};\\\", \\\"{x:1359,y:687,t:1527264960911};\\\", \\\"{x:1356,y:687,t:1527264960927};\\\", \\\"{x:1353,y:687,t:1527264960944};\\\", \\\"{x:1349,y:688,t:1527264960960};\\\", \\\"{x:1347,y:689,t:1527264960977};\\\", \\\"{x:1345,y:690,t:1527264961005};\\\", \\\"{x:1345,y:691,t:1527264961286};\\\", \\\"{x:1345,y:692,t:1527264961311};\\\", \\\"{x:1346,y:694,t:1527264961758};\\\", \\\"{x:1349,y:696,t:1527264961766};\\\", \\\"{x:1351,y:697,t:1527264961778};\\\", \\\"{x:1354,y:699,t:1527264961796};\\\", \\\"{x:1355,y:700,t:1527264961811};\\\", \\\"{x:1357,y:702,t:1527264961828};\\\", \\\"{x:1358,y:703,t:1527264961845};\\\", \\\"{x:1357,y:703,t:1527264962030};\\\", \\\"{x:1356,y:703,t:1527264962069};\\\", \\\"{x:1355,y:703,t:1527264962077};\\\", \\\"{x:1352,y:703,t:1527264962094};\\\", \\\"{x:1350,y:702,t:1527264962111};\\\", \\\"{x:1349,y:701,t:1527264962129};\\\", \\\"{x:1348,y:701,t:1527264962144};\\\", \\\"{x:1345,y:701,t:1527264962318};\\\", \\\"{x:1337,y:701,t:1527264962330};\\\", \\\"{x:1325,y:701,t:1527264962345};\\\", \\\"{x:1311,y:702,t:1527264962362};\\\", \\\"{x:1296,y:704,t:1527264962379};\\\", \\\"{x:1278,y:705,t:1527264962396};\\\", \\\"{x:1261,y:708,t:1527264962412};\\\", \\\"{x:1240,y:712,t:1527264962429};\\\", \\\"{x:1221,y:714,t:1527264962445};\\\", \\\"{x:1204,y:715,t:1527264962462};\\\", \\\"{x:1188,y:719,t:1527264962479};\\\", \\\"{x:1180,y:720,t:1527264962495};\\\", \\\"{x:1174,y:724,t:1527264962512};\\\", \\\"{x:1168,y:728,t:1527264962529};\\\", \\\"{x:1165,y:731,t:1527264962546};\\\", \\\"{x:1163,y:739,t:1527264962562};\\\", \\\"{x:1160,y:745,t:1527264962579};\\\", \\\"{x:1157,y:756,t:1527264962596};\\\", \\\"{x:1156,y:763,t:1527264962611};\\\", \\\"{x:1155,y:770,t:1527264962629};\\\", \\\"{x:1154,y:777,t:1527264962646};\\\", \\\"{x:1154,y:779,t:1527264962671};\\\", \\\"{x:1154,y:780,t:1527264962686};\\\", \\\"{x:1154,y:782,t:1527264962710};\\\", \\\"{x:1155,y:783,t:1527264962718};\\\", \\\"{x:1157,y:784,t:1527264962734};\\\", \\\"{x:1159,y:784,t:1527264962746};\\\", \\\"{x:1160,y:784,t:1527264962763};\\\", \\\"{x:1163,y:786,t:1527264962779};\\\", \\\"{x:1164,y:786,t:1527264962796};\\\", \\\"{x:1166,y:788,t:1527264962813};\\\", \\\"{x:1168,y:788,t:1527264962829};\\\", \\\"{x:1169,y:788,t:1527264962927};\\\", \\\"{x:1171,y:788,t:1527264962934};\\\", \\\"{x:1172,y:788,t:1527264962951};\\\", \\\"{x:1173,y:788,t:1527264962963};\\\", \\\"{x:1174,y:788,t:1527264962979};\\\", \\\"{x:1177,y:787,t:1527264962996};\\\", \\\"{x:1178,y:786,t:1527264963013};\\\", \\\"{x:1179,y:786,t:1527264963029};\\\", \\\"{x:1180,y:785,t:1527264963062};\\\", \\\"{x:1181,y:785,t:1527264963079};\\\", \\\"{x:1182,y:785,t:1527264963119};\\\", \\\"{x:1183,y:785,t:1527264963135};\\\", \\\"{x:1184,y:785,t:1527264963150};\\\", \\\"{x:1185,y:784,t:1527264963190};\\\", \\\"{x:1185,y:783,t:1527264964039};\\\", \\\"{x:1185,y:782,t:1527264964046};\\\", \\\"{x:1185,y:779,t:1527264964064};\\\", \\\"{x:1184,y:776,t:1527264964079};\\\", \\\"{x:1183,y:773,t:1527264964097};\\\", \\\"{x:1182,y:768,t:1527264964114};\\\", \\\"{x:1182,y:766,t:1527264964129};\\\", \\\"{x:1182,y:765,t:1527264964147};\\\", \\\"{x:1182,y:763,t:1527264964163};\\\", \\\"{x:1182,y:761,t:1527264964180};\\\", \\\"{x:1182,y:760,t:1527264964196};\\\", \\\"{x:1183,y:760,t:1527264964222};\\\", \\\"{x:1183,y:759,t:1527264967470};\\\", \\\"{x:1182,y:757,t:1527264967483};\\\", \\\"{x:1178,y:754,t:1527264967499};\\\", \\\"{x:1173,y:752,t:1527264967516};\\\", \\\"{x:1168,y:749,t:1527264967533};\\\", \\\"{x:1162,y:747,t:1527264967549};\\\", \\\"{x:1157,y:745,t:1527264967566};\\\", \\\"{x:1156,y:745,t:1527264967583};\\\", \\\"{x:1156,y:748,t:1527264967846};\\\", \\\"{x:1156,y:751,t:1527264967854};\\\", \\\"{x:1156,y:754,t:1527264967866};\\\", \\\"{x:1158,y:761,t:1527264967883};\\\", \\\"{x:1160,y:768,t:1527264967900};\\\", \\\"{x:1162,y:772,t:1527264967916};\\\", \\\"{x:1163,y:775,t:1527264967934};\\\", \\\"{x:1163,y:776,t:1527264967950};\\\", \\\"{x:1164,y:778,t:1527264967966};\\\", \\\"{x:1165,y:779,t:1527264967990};\\\", \\\"{x:1166,y:780,t:1527264968006};\\\", \\\"{x:1166,y:782,t:1527264968016};\\\", \\\"{x:1166,y:783,t:1527264968033};\\\", \\\"{x:1168,y:785,t:1527264968050};\\\", \\\"{x:1168,y:789,t:1527264968067};\\\", \\\"{x:1169,y:791,t:1527264968083};\\\", \\\"{x:1170,y:793,t:1527264968100};\\\", \\\"{x:1171,y:796,t:1527264968117};\\\", \\\"{x:1172,y:799,t:1527264968133};\\\", \\\"{x:1173,y:802,t:1527264968150};\\\", \\\"{x:1175,y:803,t:1527264968167};\\\", \\\"{x:1175,y:804,t:1527264968183};\\\", \\\"{x:1175,y:805,t:1527264968200};\\\", \\\"{x:1178,y:806,t:1527264968255};\\\", \\\"{x:1183,y:807,t:1527264968266};\\\", \\\"{x:1189,y:810,t:1527264968284};\\\", \\\"{x:1195,y:811,t:1527264968299};\\\", \\\"{x:1203,y:811,t:1527264968317};\\\", \\\"{x:1212,y:811,t:1527264968333};\\\", \\\"{x:1223,y:811,t:1527264968351};\\\", \\\"{x:1225,y:812,t:1527264968367};\\\", \\\"{x:1226,y:812,t:1527264968383};\\\", \\\"{x:1227,y:813,t:1527264968549};\\\", \\\"{x:1227,y:815,t:1527264968574};\\\", \\\"{x:1227,y:816,t:1527264968590};\\\", \\\"{x:1227,y:818,t:1527264968614};\\\", \\\"{x:1229,y:818,t:1527264968718};\\\", \\\"{x:1233,y:818,t:1527264968735};\\\", \\\"{x:1239,y:817,t:1527264968750};\\\", \\\"{x:1252,y:812,t:1527264968767};\\\", \\\"{x:1264,y:807,t:1527264968784};\\\", \\\"{x:1273,y:802,t:1527264968800};\\\", \\\"{x:1287,y:797,t:1527264968817};\\\", \\\"{x:1298,y:793,t:1527264968834};\\\", \\\"{x:1307,y:790,t:1527264968850};\\\", \\\"{x:1318,y:789,t:1527264968868};\\\", \\\"{x:1325,y:786,t:1527264968884};\\\", \\\"{x:1332,y:785,t:1527264968901};\\\", \\\"{x:1340,y:784,t:1527264968917};\\\", \\\"{x:1348,y:784,t:1527264968935};\\\", \\\"{x:1350,y:782,t:1527264968950};\\\", \\\"{x:1351,y:782,t:1527264968967};\\\", \\\"{x:1351,y:781,t:1527264969327};\\\", \\\"{x:1352,y:780,t:1527264969350};\\\", \\\"{x:1352,y:779,t:1527264969368};\\\", \\\"{x:1352,y:778,t:1527264969384};\\\", \\\"{x:1352,y:777,t:1527264969406};\\\", \\\"{x:1352,y:776,t:1527264969423};\\\", \\\"{x:1352,y:775,t:1527264969446};\\\", \\\"{x:1351,y:774,t:1527264969766};\\\", \\\"{x:1350,y:772,t:1527264969822};\\\", \\\"{x:1350,y:771,t:1527264969871};\\\", \\\"{x:1350,y:770,t:1527264969894};\\\", \\\"{x:1350,y:769,t:1527264969911};\\\", \\\"{x:1350,y:768,t:1527264969974};\\\", \\\"{x:1350,y:767,t:1527264970006};\\\", \\\"{x:1350,y:766,t:1527264970022};\\\", \\\"{x:1349,y:766,t:1527264975998};\\\", \\\"{x:1348,y:765,t:1527264976198};\\\", \\\"{x:1347,y:764,t:1527264976206};\\\", \\\"{x:1345,y:761,t:1527264976223};\\\", \\\"{x:1343,y:760,t:1527264976239};\\\", \\\"{x:1342,y:759,t:1527264976257};\\\", \\\"{x:1341,y:757,t:1527264976274};\\\", \\\"{x:1340,y:757,t:1527264976290};\\\", \\\"{x:1339,y:756,t:1527264976902};\\\", \\\"{x:1337,y:755,t:1527264976909};\\\", \\\"{x:1334,y:752,t:1527264976923};\\\", \\\"{x:1323,y:744,t:1527264976940};\\\", \\\"{x:1310,y:734,t:1527264976957};\\\", \\\"{x:1265,y:711,t:1527264976973};\\\", \\\"{x:1248,y:702,t:1527264976990};\\\", \\\"{x:1238,y:699,t:1527264977007};\\\", \\\"{x:1237,y:697,t:1527264977023};\\\", \\\"{x:1234,y:695,t:1527264977041};\\\", \\\"{x:1231,y:693,t:1527264977057};\\\", \\\"{x:1230,y:693,t:1527264977073};\\\", \\\"{x:1230,y:691,t:1527264977091};\\\", \\\"{x:1229,y:691,t:1527264977108};\\\", \\\"{x:1228,y:690,t:1527264977123};\\\", \\\"{x:1227,y:688,t:1527264977140};\\\", \\\"{x:1224,y:685,t:1527264977157};\\\", \\\"{x:1221,y:681,t:1527264977173};\\\", \\\"{x:1219,y:672,t:1527264977190};\\\", \\\"{x:1218,y:666,t:1527264977207};\\\", \\\"{x:1218,y:661,t:1527264977224};\\\", \\\"{x:1218,y:654,t:1527264977240};\\\", \\\"{x:1218,y:649,t:1527264977257};\\\", \\\"{x:1218,y:647,t:1527264977274};\\\", \\\"{x:1217,y:644,t:1527264977290};\\\", \\\"{x:1217,y:643,t:1527264977307};\\\", \\\"{x:1217,y:640,t:1527264977323};\\\", \\\"{x:1217,y:638,t:1527264977341};\\\", \\\"{x:1219,y:636,t:1527264977357};\\\", \\\"{x:1226,y:634,t:1527264977374};\\\", \\\"{x:1232,y:633,t:1527264977390};\\\", \\\"{x:1237,y:630,t:1527264977408};\\\", \\\"{x:1244,y:627,t:1527264977424};\\\", \\\"{x:1250,y:623,t:1527264977441};\\\", \\\"{x:1255,y:619,t:1527264977457};\\\", \\\"{x:1259,y:617,t:1527264977475};\\\", \\\"{x:1261,y:615,t:1527264977491};\\\", \\\"{x:1264,y:613,t:1527264977507};\\\", \\\"{x:1265,y:612,t:1527264977525};\\\", \\\"{x:1267,y:610,t:1527264977541};\\\", \\\"{x:1270,y:607,t:1527264977557};\\\", \\\"{x:1273,y:602,t:1527264977574};\\\", \\\"{x:1275,y:600,t:1527264977590};\\\", \\\"{x:1276,y:599,t:1527264977608};\\\", \\\"{x:1276,y:600,t:1527264977830};\\\", \\\"{x:1276,y:604,t:1527264977842};\\\", \\\"{x:1276,y:615,t:1527264977858};\\\", \\\"{x:1276,y:628,t:1527264977874};\\\", \\\"{x:1276,y:637,t:1527264977891};\\\", \\\"{x:1276,y:644,t:1527264977907};\\\", \\\"{x:1276,y:647,t:1527264977925};\\\", \\\"{x:1276,y:648,t:1527264977943};\\\", \\\"{x:1277,y:649,t:1527264977958};\\\", \\\"{x:1278,y:650,t:1527264977975};\\\", \\\"{x:1278,y:653,t:1527264977992};\\\", \\\"{x:1279,y:656,t:1527264978008};\\\", \\\"{x:1280,y:658,t:1527264978025};\\\", \\\"{x:1280,y:661,t:1527264978041};\\\", \\\"{x:1282,y:664,t:1527264978058};\\\", \\\"{x:1283,y:667,t:1527264978074};\\\", \\\"{x:1284,y:672,t:1527264978092};\\\", \\\"{x:1284,y:674,t:1527264978107};\\\", \\\"{x:1285,y:676,t:1527264978124};\\\", \\\"{x:1285,y:678,t:1527264978141};\\\", \\\"{x:1285,y:679,t:1527264978157};\\\", \\\"{x:1285,y:681,t:1527264978175};\\\", \\\"{x:1285,y:682,t:1527264978198};\\\", \\\"{x:1285,y:683,t:1527264978214};\\\", \\\"{x:1285,y:684,t:1527264978225};\\\", \\\"{x:1285,y:685,t:1527264978246};\\\", \\\"{x:1285,y:687,t:1527264978258};\\\", \\\"{x:1285,y:689,t:1527264978275};\\\", \\\"{x:1283,y:692,t:1527264978291};\\\", \\\"{x:1281,y:697,t:1527264978309};\\\", \\\"{x:1279,y:701,t:1527264978325};\\\", \\\"{x:1277,y:706,t:1527264978341};\\\", \\\"{x:1274,y:710,t:1527264978358};\\\", \\\"{x:1272,y:713,t:1527264978375};\\\", \\\"{x:1272,y:714,t:1527264978391};\\\", \\\"{x:1272,y:716,t:1527264978407};\\\", \\\"{x:1271,y:718,t:1527264978424};\\\", \\\"{x:1270,y:719,t:1527264978441};\\\", \\\"{x:1270,y:721,t:1527264978470};\\\", \\\"{x:1270,y:722,t:1527264978493};\\\", \\\"{x:1269,y:724,t:1527264978526};\\\", \\\"{x:1269,y:725,t:1527264978631};\\\", \\\"{x:1269,y:726,t:1527264978662};\\\", \\\"{x:1269,y:727,t:1527264978678};\\\", \\\"{x:1269,y:729,t:1527264978710};\\\", \\\"{x:1270,y:729,t:1527264978725};\\\", \\\"{x:1270,y:735,t:1527264978742};\\\", \\\"{x:1270,y:741,t:1527264978758};\\\", \\\"{x:1271,y:750,t:1527264978775};\\\", \\\"{x:1274,y:754,t:1527264978791};\\\", \\\"{x:1274,y:755,t:1527264978808};\\\", \\\"{x:1274,y:757,t:1527264978825};\\\", \\\"{x:1274,y:761,t:1527264978842};\\\", \\\"{x:1272,y:763,t:1527264978859};\\\", \\\"{x:1264,y:765,t:1527264978876};\\\", \\\"{x:1253,y:766,t:1527264978892};\\\", \\\"{x:1247,y:766,t:1527264978909};\\\", \\\"{x:1248,y:766,t:1527264979127};\\\", \\\"{x:1249,y:766,t:1527264979167};\\\", \\\"{x:1250,y:765,t:1527264979239};\\\", \\\"{x:1251,y:764,t:1527264979246};\\\", \\\"{x:1251,y:763,t:1527264979259};\\\", \\\"{x:1252,y:759,t:1527264979276};\\\", \\\"{x:1252,y:755,t:1527264979293};\\\", \\\"{x:1255,y:747,t:1527264979308};\\\", \\\"{x:1256,y:742,t:1527264979325};\\\", \\\"{x:1259,y:734,t:1527264979343};\\\", \\\"{x:1260,y:728,t:1527264979358};\\\", \\\"{x:1262,y:722,t:1527264979376};\\\", \\\"{x:1263,y:715,t:1527264979392};\\\", \\\"{x:1265,y:710,t:1527264979409};\\\", \\\"{x:1267,y:704,t:1527264979425};\\\", \\\"{x:1268,y:695,t:1527264979442};\\\", \\\"{x:1268,y:686,t:1527264979459};\\\", \\\"{x:1272,y:676,t:1527264979476};\\\", \\\"{x:1273,y:668,t:1527264979493};\\\", \\\"{x:1274,y:660,t:1527264979509};\\\", \\\"{x:1274,y:657,t:1527264979526};\\\", \\\"{x:1274,y:653,t:1527264979542};\\\", \\\"{x:1274,y:652,t:1527264979559};\\\", \\\"{x:1274,y:651,t:1527264979576};\\\", \\\"{x:1274,y:650,t:1527264979592};\\\", \\\"{x:1274,y:649,t:1527264979610};\\\", \\\"{x:1274,y:647,t:1527264979625};\\\", \\\"{x:1274,y:645,t:1527264979642};\\\", \\\"{x:1274,y:641,t:1527264979659};\\\", \\\"{x:1274,y:640,t:1527264979675};\\\", \\\"{x:1274,y:638,t:1527264979692};\\\", \\\"{x:1274,y:637,t:1527264979709};\\\", \\\"{x:1274,y:635,t:1527264979725};\\\", \\\"{x:1274,y:634,t:1527264979743};\\\", \\\"{x:1273,y:632,t:1527264979766};\\\", \\\"{x:1273,y:631,t:1527264979782};\\\", \\\"{x:1273,y:629,t:1527264979798};\\\", \\\"{x:1273,y:627,t:1527264979810};\\\", \\\"{x:1273,y:620,t:1527264979825};\\\", \\\"{x:1273,y:612,t:1527264979843};\\\", \\\"{x:1273,y:604,t:1527264979860};\\\", \\\"{x:1273,y:598,t:1527264979876};\\\", \\\"{x:1275,y:591,t:1527264979892};\\\", \\\"{x:1278,y:585,t:1527264979910};\\\", \\\"{x:1278,y:584,t:1527264979926};\\\", \\\"{x:1282,y:574,t:1527264979943};\\\", \\\"{x:1284,y:570,t:1527264979960};\\\", \\\"{x:1286,y:564,t:1527264979976};\\\", \\\"{x:1291,y:560,t:1527264979992};\\\", \\\"{x:1298,y:552,t:1527264980008};\\\", \\\"{x:1304,y:548,t:1527264980026};\\\", \\\"{x:1308,y:546,t:1527264980042};\\\", \\\"{x:1311,y:544,t:1527264980059};\\\", \\\"{x:1312,y:544,t:1527264980076};\\\", \\\"{x:1313,y:544,t:1527264980092};\\\", \\\"{x:1315,y:544,t:1527264980109};\\\", \\\"{x:1323,y:543,t:1527264980125};\\\", \\\"{x:1328,y:543,t:1527264980142};\\\", \\\"{x:1337,y:543,t:1527264980159};\\\", \\\"{x:1351,y:543,t:1527264980177};\\\", \\\"{x:1365,y:543,t:1527264980192};\\\", \\\"{x:1373,y:543,t:1527264980209};\\\", \\\"{x:1378,y:543,t:1527264980226};\\\", \\\"{x:1380,y:543,t:1527264980242};\\\", \\\"{x:1385,y:545,t:1527264980260};\\\", \\\"{x:1388,y:546,t:1527264980277};\\\", \\\"{x:1389,y:548,t:1527264980292};\\\", \\\"{x:1390,y:548,t:1527264980309};\\\", \\\"{x:1391,y:548,t:1527264980350};\\\", \\\"{x:1391,y:549,t:1527264980382};\\\", \\\"{x:1391,y:551,t:1527264980392};\\\", \\\"{x:1393,y:554,t:1527264980409};\\\", \\\"{x:1395,y:557,t:1527264980426};\\\", \\\"{x:1397,y:561,t:1527264980443};\\\", \\\"{x:1398,y:562,t:1527264980458};\\\", \\\"{x:1400,y:566,t:1527264980476};\\\", \\\"{x:1403,y:572,t:1527264980493};\\\", \\\"{x:1406,y:577,t:1527264980509};\\\", \\\"{x:1409,y:581,t:1527264980526};\\\", \\\"{x:1410,y:583,t:1527264980543};\\\", \\\"{x:1412,y:587,t:1527264980559};\\\", \\\"{x:1414,y:588,t:1527264980576};\\\", \\\"{x:1414,y:589,t:1527264980594};\\\", \\\"{x:1417,y:590,t:1527264980609};\\\", \\\"{x:1418,y:591,t:1527264980626};\\\", \\\"{x:1419,y:591,t:1527264980643};\\\", \\\"{x:1420,y:592,t:1527264980660};\\\", \\\"{x:1420,y:593,t:1527264983359};\\\", \\\"{x:1420,y:594,t:1527264983366};\\\", \\\"{x:1420,y:595,t:1527264983379};\\\", \\\"{x:1420,y:597,t:1527264983396};\\\", \\\"{x:1420,y:599,t:1527264983412};\\\", \\\"{x:1420,y:601,t:1527264983485};\\\", \\\"{x:1420,y:602,t:1527264983495};\\\", \\\"{x:1421,y:604,t:1527264983512};\\\", \\\"{x:1421,y:607,t:1527264983528};\\\", \\\"{x:1424,y:614,t:1527264983545};\\\", \\\"{x:1428,y:623,t:1527264983562};\\\", \\\"{x:1434,y:635,t:1527264983578};\\\", \\\"{x:1440,y:650,t:1527264983595};\\\", \\\"{x:1446,y:662,t:1527264983612};\\\", \\\"{x:1451,y:675,t:1527264983628};\\\", \\\"{x:1456,y:695,t:1527264983645};\\\", \\\"{x:1460,y:711,t:1527264983662};\\\", \\\"{x:1464,y:721,t:1527264983679};\\\", \\\"{x:1466,y:730,t:1527264983695};\\\", \\\"{x:1466,y:737,t:1527264983712};\\\", \\\"{x:1469,y:746,t:1527264983729};\\\", \\\"{x:1470,y:756,t:1527264983745};\\\", \\\"{x:1473,y:770,t:1527264983763};\\\", \\\"{x:1474,y:779,t:1527264983779};\\\", \\\"{x:1474,y:786,t:1527264983796};\\\", \\\"{x:1474,y:793,t:1527264983813};\\\", \\\"{x:1474,y:796,t:1527264983829};\\\", \\\"{x:1474,y:802,t:1527264983846};\\\", \\\"{x:1474,y:807,t:1527264983862};\\\", \\\"{x:1474,y:810,t:1527264983879};\\\", \\\"{x:1474,y:816,t:1527264983896};\\\", \\\"{x:1474,y:818,t:1527264983913};\\\", \\\"{x:1474,y:820,t:1527264983930};\\\", \\\"{x:1474,y:821,t:1527264983950};\\\", \\\"{x:1475,y:821,t:1527264983966};\\\", \\\"{x:1475,y:822,t:1527264983980};\\\", \\\"{x:1475,y:823,t:1527264983998};\\\", \\\"{x:1475,y:825,t:1527264984013};\\\", \\\"{x:1476,y:827,t:1527264984035};\\\", \\\"{x:1476,y:829,t:1527264984045};\\\", \\\"{x:1476,y:830,t:1527264984069};\\\", \\\"{x:1476,y:831,t:1527264984079};\\\", \\\"{x:1476,y:832,t:1527264984095};\\\", \\\"{x:1477,y:833,t:1527264984117};\\\", \\\"{x:1477,y:834,t:1527264984270};\\\", \\\"{x:1478,y:834,t:1527264984279};\\\", \\\"{x:1479,y:834,t:1527264985479};\\\", \\\"{x:1480,y:833,t:1527264985510};\\\", \\\"{x:1480,y:832,t:1527264985517};\\\", \\\"{x:1481,y:829,t:1527264985530};\\\", \\\"{x:1481,y:824,t:1527264985547};\\\", \\\"{x:1483,y:817,t:1527264985564};\\\", \\\"{x:1486,y:808,t:1527264985581};\\\", \\\"{x:1489,y:804,t:1527264985598};\\\", \\\"{x:1491,y:800,t:1527264985614};\\\", \\\"{x:1492,y:799,t:1527264985654};\\\", \\\"{x:1493,y:797,t:1527264985670};\\\", \\\"{x:1493,y:796,t:1527264985681};\\\", \\\"{x:1495,y:794,t:1527264985697};\\\", \\\"{x:1497,y:789,t:1527264985714};\\\", \\\"{x:1499,y:787,t:1527264985730};\\\", \\\"{x:1501,y:785,t:1527264985747};\\\", \\\"{x:1503,y:782,t:1527264985764};\\\", \\\"{x:1506,y:778,t:1527264985780};\\\", \\\"{x:1512,y:772,t:1527264985797};\\\", \\\"{x:1516,y:769,t:1527264985814};\\\", \\\"{x:1519,y:768,t:1527264985830};\\\", \\\"{x:1521,y:766,t:1527264985848};\\\", \\\"{x:1523,y:764,t:1527264985863};\\\", \\\"{x:1523,y:765,t:1527264986462};\\\", \\\"{x:1523,y:766,t:1527264986471};\\\", \\\"{x:1523,y:768,t:1527264986481};\\\", \\\"{x:1523,y:771,t:1527264986498};\\\", \\\"{x:1522,y:775,t:1527264986514};\\\", \\\"{x:1522,y:777,t:1527264986531};\\\", \\\"{x:1521,y:779,t:1527264986547};\\\", \\\"{x:1516,y:779,t:1527264989303};\\\", \\\"{x:1510,y:779,t:1527264989317};\\\", \\\"{x:1499,y:774,t:1527264989334};\\\", \\\"{x:1495,y:773,t:1527264989350};\\\", \\\"{x:1490,y:771,t:1527264989367};\\\", \\\"{x:1483,y:768,t:1527264989384};\\\", \\\"{x:1479,y:766,t:1527264989400};\\\", \\\"{x:1477,y:765,t:1527264989417};\\\", \\\"{x:1475,y:764,t:1527264989434};\\\", \\\"{x:1473,y:762,t:1527264989450};\\\", \\\"{x:1470,y:756,t:1527264989468};\\\", \\\"{x:1469,y:752,t:1527264989484};\\\", \\\"{x:1469,y:745,t:1527264989500};\\\", \\\"{x:1469,y:739,t:1527264989517};\\\", \\\"{x:1469,y:731,t:1527264989534};\\\", \\\"{x:1469,y:724,t:1527264989550};\\\", \\\"{x:1469,y:716,t:1527264989568};\\\", \\\"{x:1467,y:705,t:1527264989584};\\\", \\\"{x:1466,y:693,t:1527264989600};\\\", \\\"{x:1465,y:685,t:1527264989617};\\\", \\\"{x:1464,y:681,t:1527264989634};\\\", \\\"{x:1463,y:677,t:1527264989650};\\\", \\\"{x:1462,y:675,t:1527264989667};\\\", \\\"{x:1461,y:673,t:1527264989684};\\\", \\\"{x:1459,y:671,t:1527264989701};\\\", \\\"{x:1456,y:668,t:1527264989717};\\\", \\\"{x:1452,y:666,t:1527264989734};\\\", \\\"{x:1452,y:665,t:1527264989758};\\\", \\\"{x:1451,y:665,t:1527264989774};\\\", \\\"{x:1451,y:664,t:1527264989784};\\\", \\\"{x:1450,y:662,t:1527264989801};\\\", \\\"{x:1448,y:660,t:1527264989817};\\\", \\\"{x:1448,y:659,t:1527264989838};\\\", \\\"{x:1447,y:659,t:1527264989851};\\\", \\\"{x:1447,y:658,t:1527264989867};\\\", \\\"{x:1447,y:657,t:1527264989884};\\\", \\\"{x:1447,y:655,t:1527264989901};\\\", \\\"{x:1447,y:654,t:1527264990134};\\\", \\\"{x:1447,y:653,t:1527264990166};\\\", \\\"{x:1447,y:652,t:1527264990182};\\\", \\\"{x:1448,y:652,t:1527264990190};\\\", \\\"{x:1449,y:652,t:1527264990270};\\\", \\\"{x:1449,y:651,t:1527264990631};\\\", \\\"{x:1449,y:649,t:1527264990654};\\\", \\\"{x:1449,y:648,t:1527264990678};\\\", \\\"{x:1450,y:647,t:1527264990726};\\\", \\\"{x:1447,y:647,t:1527264996182};\\\", \\\"{x:1445,y:647,t:1527264996189};\\\", \\\"{x:1443,y:647,t:1527264996205};\\\", \\\"{x:1432,y:650,t:1527264996221};\\\", \\\"{x:1420,y:655,t:1527264996238};\\\", \\\"{x:1409,y:656,t:1527264996255};\\\", \\\"{x:1401,y:659,t:1527264996272};\\\", \\\"{x:1396,y:659,t:1527264996289};\\\", \\\"{x:1396,y:660,t:1527264996305};\\\", \\\"{x:1395,y:660,t:1527264996591};\\\", \\\"{x:1395,y:659,t:1527264996606};\\\", \\\"{x:1396,y:658,t:1527264996623};\\\", \\\"{x:1401,y:656,t:1527264996640};\\\", \\\"{x:1403,y:655,t:1527264996657};\\\", \\\"{x:1407,y:654,t:1527264996672};\\\", \\\"{x:1408,y:654,t:1527264996689};\\\", \\\"{x:1409,y:654,t:1527264996706};\\\", \\\"{x:1410,y:653,t:1527264996722};\\\", \\\"{x:1412,y:652,t:1527264996740};\\\", \\\"{x:1413,y:652,t:1527264996755};\\\", \\\"{x:1416,y:651,t:1527264996772};\\\", \\\"{x:1420,y:649,t:1527264996789};\\\", \\\"{x:1434,y:643,t:1527264996806};\\\", \\\"{x:1436,y:642,t:1527264996823};\\\", \\\"{x:1437,y:641,t:1527264996838};\\\", \\\"{x:1438,y:641,t:1527264996917};\\\", \\\"{x:1439,y:640,t:1527264996925};\\\", \\\"{x:1440,y:640,t:1527264996939};\\\", \\\"{x:1441,y:640,t:1527264996965};\\\", \\\"{x:1442,y:639,t:1527264997006};\\\", \\\"{x:1441,y:639,t:1527265009399};\\\", \\\"{x:1440,y:639,t:1527265009438};\\\", \\\"{x:1439,y:639,t:1527265009518};\\\", \\\"{x:1437,y:639,t:1527265010861};\\\", \\\"{x:1436,y:639,t:1527265010868};\\\", \\\"{x:1434,y:639,t:1527265010885};\\\", \\\"{x:1433,y:639,t:1527265010900};\\\", \\\"{x:1430,y:639,t:1527265010917};\\\", \\\"{x:1427,y:639,t:1527265010934};\\\", \\\"{x:1425,y:639,t:1527265010950};\\\", \\\"{x:1423,y:639,t:1527265010967};\\\", \\\"{x:1420,y:641,t:1527265010984};\\\", \\\"{x:1415,y:643,t:1527265011000};\\\", \\\"{x:1412,y:645,t:1527265011017};\\\", \\\"{x:1408,y:647,t:1527265011033};\\\", \\\"{x:1401,y:652,t:1527265011051};\\\", \\\"{x:1397,y:654,t:1527265011067};\\\", \\\"{x:1390,y:658,t:1527265011083};\\\", \\\"{x:1386,y:664,t:1527265011101};\\\", \\\"{x:1379,y:669,t:1527265011118};\\\", \\\"{x:1375,y:675,t:1527265011134};\\\", \\\"{x:1372,y:679,t:1527265011150};\\\", \\\"{x:1370,y:682,t:1527265011168};\\\", \\\"{x:1369,y:684,t:1527265011184};\\\", \\\"{x:1369,y:687,t:1527265011201};\\\", \\\"{x:1369,y:690,t:1527265011218};\\\", \\\"{x:1369,y:697,t:1527265011234};\\\", \\\"{x:1369,y:702,t:1527265011251};\\\", \\\"{x:1369,y:710,t:1527265011268};\\\", \\\"{x:1369,y:716,t:1527265011284};\\\", \\\"{x:1369,y:720,t:1527265011301};\\\", \\\"{x:1369,y:724,t:1527265011318};\\\", \\\"{x:1369,y:725,t:1527265011334};\\\", \\\"{x:1369,y:726,t:1527265011351};\\\", \\\"{x:1369,y:727,t:1527265011368};\\\", \\\"{x:1368,y:728,t:1527265011430};\\\", \\\"{x:1368,y:729,t:1527265011438};\\\", \\\"{x:1367,y:731,t:1527265011454};\\\", \\\"{x:1366,y:731,t:1527265011468};\\\", \\\"{x:1365,y:732,t:1527265011485};\\\", \\\"{x:1363,y:734,t:1527265011501};\\\", \\\"{x:1360,y:736,t:1527265011518};\\\", \\\"{x:1360,y:737,t:1527265011535};\\\", \\\"{x:1358,y:737,t:1527265011551};\\\", \\\"{x:1357,y:738,t:1527265011568};\\\", \\\"{x:1356,y:738,t:1527265011585};\\\", \\\"{x:1355,y:738,t:1527265011614};\\\", \\\"{x:1354,y:738,t:1527265011622};\\\", \\\"{x:1352,y:739,t:1527265011638};\\\", \\\"{x:1351,y:740,t:1527265011670};\\\", \\\"{x:1350,y:741,t:1527265011839};\\\", \\\"{x:1350,y:742,t:1527265011851};\\\", \\\"{x:1350,y:744,t:1527265011868};\\\", \\\"{x:1350,y:748,t:1527265011885};\\\", \\\"{x:1349,y:750,t:1527265011902};\\\", \\\"{x:1349,y:753,t:1527265011918};\\\", \\\"{x:1348,y:756,t:1527265011935};\\\", \\\"{x:1347,y:756,t:1527265011952};\\\", \\\"{x:1347,y:757,t:1527265011968};\\\", \\\"{x:1346,y:759,t:1527265011985};\\\", \\\"{x:1346,y:760,t:1527265012017};\\\", \\\"{x:1346,y:761,t:1527265012035};\\\", \\\"{x:1346,y:762,t:1527265012052};\\\", \\\"{x:1346,y:765,t:1527265012067};\\\", \\\"{x:1344,y:769,t:1527265012084};\\\", \\\"{x:1343,y:773,t:1527265012101};\\\", \\\"{x:1342,y:776,t:1527265012118};\\\", \\\"{x:1342,y:778,t:1527265012134};\\\", \\\"{x:1341,y:780,t:1527265012151};\\\", \\\"{x:1340,y:783,t:1527265012168};\\\", \\\"{x:1340,y:785,t:1527265012197};\\\", \\\"{x:1340,y:786,t:1527265012598};\\\", \\\"{x:1340,y:787,t:1527265012613};\\\", \\\"{x:1341,y:787,t:1527265012622};\\\", \\\"{x:1344,y:787,t:1527265012635};\\\", \\\"{x:1348,y:786,t:1527265012652};\\\", \\\"{x:1355,y:784,t:1527265012670};\\\", \\\"{x:1359,y:782,t:1527265012686};\\\", \\\"{x:1361,y:781,t:1527265012702};\\\", \\\"{x:1361,y:780,t:1527265012878};\\\", \\\"{x:1361,y:778,t:1527265012885};\\\", \\\"{x:1360,y:770,t:1527265012903};\\\", \\\"{x:1358,y:767,t:1527265012920};\\\", \\\"{x:1358,y:764,t:1527265012936};\\\", \\\"{x:1358,y:763,t:1527265012957};\\\", \\\"{x:1357,y:762,t:1527265013103};\\\", \\\"{x:1356,y:761,t:1527265013119};\\\", \\\"{x:1355,y:759,t:1527265013136};\\\", \\\"{x:1354,y:758,t:1527265013152};\\\", \\\"{x:1352,y:755,t:1527265013169};\\\", \\\"{x:1352,y:753,t:1527265013187};\\\", \\\"{x:1352,y:751,t:1527265013203};\\\", \\\"{x:1351,y:750,t:1527265013219};\\\", \\\"{x:1351,y:749,t:1527265013236};\\\", \\\"{x:1350,y:749,t:1527265013261};\\\", \\\"{x:1350,y:748,t:1527265013285};\\\", \\\"{x:1349,y:746,t:1527265013334};\\\", \\\"{x:1348,y:746,t:1527265013358};\\\", \\\"{x:1348,y:745,t:1527265013374};\\\", \\\"{x:1347,y:743,t:1527265014737};\\\", \\\"{x:1346,y:743,t:1527265014744};\\\", \\\"{x:1345,y:743,t:1527265014757};\\\", \\\"{x:1342,y:741,t:1527265014772};\\\", \\\"{x:1341,y:741,t:1527265014785};\\\", \\\"{x:1339,y:740,t:1527265014800};\\\", \\\"{x:1338,y:739,t:1527265014818};\\\", \\\"{x:1336,y:739,t:1527265014834};\\\", \\\"{x:1335,y:738,t:1527265014852};\\\", \\\"{x:1334,y:738,t:1527265014944};\\\", \\\"{x:1333,y:738,t:1527265014951};\\\", \\\"{x:1333,y:738,t:1527265015009};\\\", \\\"{x:1332,y:738,t:1527265015209};\\\", \\\"{x:1324,y:738,t:1527265015218};\\\", \\\"{x:1304,y:738,t:1527265015235};\\\", \\\"{x:1277,y:738,t:1527265015252};\\\", \\\"{x:1232,y:738,t:1527265015268};\\\", \\\"{x:1176,y:738,t:1527265015285};\\\", \\\"{x:1115,y:738,t:1527265015302};\\\", \\\"{x:1048,y:738,t:1527265015319};\\\", \\\"{x:989,y:735,t:1527265015335};\\\", \\\"{x:955,y:730,t:1527265015352};\\\", \\\"{x:919,y:728,t:1527265015368};\\\", \\\"{x:904,y:727,t:1527265015385};\\\", \\\"{x:895,y:725,t:1527265015402};\\\", \\\"{x:894,y:725,t:1527265015419};\\\", \\\"{x:892,y:725,t:1527265015513};\\\", \\\"{x:891,y:725,t:1527265017041};\\\", \\\"{x:891,y:727,t:1527265017048};\\\", \\\"{x:892,y:729,t:1527265017058};\\\", \\\"{x:893,y:736,t:1527265017076};\\\", \\\"{x:898,y:745,t:1527265017093};\\\", \\\"{x:901,y:753,t:1527265017109};\\\", \\\"{x:911,y:762,t:1527265017126};\\\", \\\"{x:924,y:774,t:1527265017142};\\\", \\\"{x:934,y:784,t:1527265017159};\\\", \\\"{x:951,y:793,t:1527265017176};\\\", \\\"{x:964,y:798,t:1527265017192};\\\", \\\"{x:982,y:802,t:1527265017209};\\\", \\\"{x:1009,y:805,t:1527265017226};\\\", \\\"{x:1039,y:806,t:1527265017243};\\\", \\\"{x:1064,y:806,t:1527265017259};\\\", \\\"{x:1091,y:806,t:1527265017276};\\\", \\\"{x:1121,y:806,t:1527265017293};\\\", \\\"{x:1147,y:806,t:1527265017309};\\\", \\\"{x:1170,y:806,t:1527265017326};\\\", \\\"{x:1184,y:806,t:1527265017343};\\\", \\\"{x:1193,y:806,t:1527265017359};\\\", \\\"{x:1195,y:806,t:1527265017376};\\\", \\\"{x:1196,y:806,t:1527265017393};\\\", \\\"{x:1196,y:805,t:1527265017617};\\\", \\\"{x:1196,y:804,t:1527265017633};\\\", \\\"{x:1196,y:803,t:1527265017643};\\\", \\\"{x:1196,y:802,t:1527265017661};\\\", \\\"{x:1197,y:802,t:1527265017676};\\\", \\\"{x:1197,y:803,t:1527265017873};\\\", \\\"{x:1197,y:805,t:1527265017880};\\\", \\\"{x:1198,y:807,t:1527265017893};\\\", \\\"{x:1198,y:810,t:1527265017910};\\\", \\\"{x:1198,y:816,t:1527265017927};\\\", \\\"{x:1198,y:820,t:1527265017944};\\\", \\\"{x:1199,y:824,t:1527265017961};\\\", \\\"{x:1203,y:827,t:1527265017977};\\\", \\\"{x:1205,y:831,t:1527265017993};\\\", \\\"{x:1205,y:832,t:1527265018010};\\\", \\\"{x:1207,y:835,t:1527265018027};\\\", \\\"{x:1209,y:836,t:1527265018044};\\\", \\\"{x:1211,y:838,t:1527265018065};\\\", \\\"{x:1212,y:838,t:1527265018078};\\\", \\\"{x:1213,y:838,t:1527265018093};\\\", \\\"{x:1214,y:839,t:1527265018110};\\\", \\\"{x:1215,y:839,t:1527265018127};\\\", \\\"{x:1213,y:838,t:1527265018481};\\\", \\\"{x:1213,y:837,t:1527265018496};\\\", \\\"{x:1213,y:835,t:1527265018511};\\\", \\\"{x:1212,y:833,t:1527265018527};\\\", \\\"{x:1212,y:832,t:1527265018544};\\\", \\\"{x:1212,y:831,t:1527265018560};\\\", \\\"{x:1212,y:829,t:1527265018577};\\\", \\\"{x:1210,y:828,t:1527265018594};\\\", \\\"{x:1210,y:827,t:1527265018610};\\\", \\\"{x:1210,y:826,t:1527265018627};\\\", \\\"{x:1209,y:825,t:1527265018645};\\\", \\\"{x:1208,y:825,t:1527265018681};\\\", \\\"{x:1208,y:824,t:1527265018705};\\\", \\\"{x:1208,y:822,t:1527265018728};\\\", \\\"{x:1209,y:822,t:1527265019057};\\\", \\\"{x:1213,y:823,t:1527265019065};\\\", \\\"{x:1219,y:825,t:1527265019078};\\\", \\\"{x:1222,y:827,t:1527265019095};\\\", \\\"{x:1224,y:828,t:1527265019111};\\\", \\\"{x:1225,y:828,t:1527265019233};\\\", \\\"{x:1226,y:828,t:1527265019401};\\\", \\\"{x:1225,y:829,t:1527265019425};\\\", \\\"{x:1224,y:829,t:1527265019440};\\\", \\\"{x:1222,y:829,t:1527265019472};\\\", \\\"{x:1221,y:829,t:1527265020585};\\\", \\\"{x:1220,y:829,t:1527265020689};\\\", \\\"{x:1219,y:829,t:1527265020753};\\\", \\\"{x:1218,y:829,t:1527265020776};\\\", \\\"{x:1217,y:828,t:1527265020800};\\\", \\\"{x:1216,y:827,t:1527265020816};\\\", \\\"{x:1215,y:827,t:1527265020849};\\\", \\\"{x:1214,y:827,t:1527265020864};\\\", \\\"{x:1213,y:827,t:1527265020878};\\\", \\\"{x:1212,y:827,t:1527265020895};\\\", \\\"{x:1211,y:828,t:1527265020912};\\\", \\\"{x:1210,y:828,t:1527265021840};\\\", \\\"{x:1210,y:826,t:1527265021848};\\\", \\\"{x:1210,y:823,t:1527265021864};\\\", \\\"{x:1208,y:814,t:1527265021880};\\\", \\\"{x:1208,y:811,t:1527265021896};\\\", \\\"{x:1206,y:809,t:1527265021913};\\\", \\\"{x:1206,y:808,t:1527265021930};\\\", \\\"{x:1204,y:807,t:1527265021946};\\\", \\\"{x:1202,y:806,t:1527265021963};\\\", \\\"{x:1198,y:803,t:1527265021980};\\\", \\\"{x:1186,y:798,t:1527265021996};\\\", \\\"{x:1170,y:791,t:1527265022013};\\\", \\\"{x:1161,y:788,t:1527265022030};\\\", \\\"{x:1159,y:787,t:1527265022045};\\\", \\\"{x:1158,y:786,t:1527265022062};\\\", \\\"{x:1157,y:786,t:1527265022112};\\\", \\\"{x:1157,y:784,t:1527265022192};\\\", \\\"{x:1158,y:783,t:1527265022208};\\\", \\\"{x:1160,y:783,t:1527265022224};\\\", \\\"{x:1161,y:782,t:1527265022232};\\\", \\\"{x:1163,y:780,t:1527265022246};\\\", \\\"{x:1166,y:777,t:1527265022263};\\\", \\\"{x:1169,y:773,t:1527265022280};\\\", \\\"{x:1170,y:772,t:1527265022505};\\\", \\\"{x:1171,y:772,t:1527265022514};\\\", \\\"{x:1173,y:771,t:1527265022560};\\\", \\\"{x:1173,y:770,t:1527265022569};\\\", \\\"{x:1174,y:770,t:1527265022584};\\\", \\\"{x:1175,y:769,t:1527265022608};\\\", \\\"{x:1176,y:769,t:1527265022616};\\\", \\\"{x:1177,y:768,t:1527265022632};\\\", \\\"{x:1177,y:767,t:1527265022648};\\\", \\\"{x:1177,y:765,t:1527265022680};\\\", \\\"{x:1177,y:764,t:1527265022696};\\\", \\\"{x:1175,y:764,t:1527265022946};\\\", \\\"{x:1163,y:765,t:1527265022964};\\\", \\\"{x:1147,y:766,t:1527265022980};\\\", \\\"{x:1119,y:767,t:1527265022998};\\\", \\\"{x:1079,y:767,t:1527265023014};\\\", \\\"{x:1026,y:767,t:1527265023030};\\\", \\\"{x:972,y:758,t:1527265023048};\\\", \\\"{x:900,y:732,t:1527265023064};\\\", \\\"{x:859,y:714,t:1527265023081};\\\", \\\"{x:833,y:703,t:1527265023097};\\\", \\\"{x:809,y:685,t:1527265023115};\\\", \\\"{x:792,y:667,t:1527265023130};\\\", \\\"{x:777,y:651,t:1527265023148};\\\", \\\"{x:765,y:634,t:1527265023164};\\\", \\\"{x:758,y:620,t:1527265023183};\\\", \\\"{x:750,y:606,t:1527265023197};\\\", \\\"{x:745,y:594,t:1527265023214};\\\", \\\"{x:741,y:582,t:1527265023232};\\\", \\\"{x:735,y:569,t:1527265023246};\\\", \\\"{x:723,y:548,t:1527265023264};\\\", \\\"{x:717,y:542,t:1527265023281};\\\", \\\"{x:714,y:539,t:1527265023296};\\\", \\\"{x:713,y:538,t:1527265023314};\\\", \\\"{x:712,y:538,t:1527265023449};\\\", \\\"{x:715,y:540,t:1527265023464};\\\", \\\"{x:717,y:541,t:1527265023481};\\\", \\\"{x:724,y:544,t:1527265023499};\\\", \\\"{x:731,y:548,t:1527265023515};\\\", \\\"{x:739,y:550,t:1527265023530};\\\", \\\"{x:747,y:554,t:1527265023548};\\\", \\\"{x:752,y:555,t:1527265023564};\\\", \\\"{x:757,y:555,t:1527265023581};\\\", \\\"{x:758,y:556,t:1527265023598};\\\", \\\"{x:759,y:556,t:1527265023614};\\\", \\\"{x:760,y:556,t:1527265023631};\\\", \\\"{x:766,y:556,t:1527265023648};\\\", \\\"{x:763,y:560,t:1527265023761};\\\", \\\"{x:755,y:568,t:1527265023769};\\\", \\\"{x:745,y:577,t:1527265023781};\\\", \\\"{x:708,y:598,t:1527265023798};\\\", \\\"{x:656,y:620,t:1527265023815};\\\", \\\"{x:588,y:632,t:1527265023831};\\\", \\\"{x:470,y:637,t:1527265023848};\\\", \\\"{x:420,y:650,t:1527265023865};\\\", \\\"{x:398,y:657,t:1527265023881};\\\", \\\"{x:378,y:668,t:1527265023898};\\\", \\\"{x:366,y:674,t:1527265023914};\\\", \\\"{x:364,y:674,t:1527265023931};\\\", \\\"{x:365,y:674,t:1527265024105};\\\", \\\"{x:371,y:671,t:1527265024114};\\\", \\\"{x:378,y:669,t:1527265024132};\\\", \\\"{x:384,y:662,t:1527265024147};\\\", \\\"{x:385,y:652,t:1527265024165};\\\", \\\"{x:385,y:637,t:1527265024181};\\\", \\\"{x:385,y:616,t:1527265024198};\\\", \\\"{x:385,y:597,t:1527265024216};\\\", \\\"{x:383,y:568,t:1527265024232};\\\", \\\"{x:383,y:552,t:1527265024248};\\\", \\\"{x:383,y:539,t:1527265024265};\\\", \\\"{x:383,y:529,t:1527265024281};\\\", \\\"{x:379,y:523,t:1527265024298};\\\", \\\"{x:376,y:518,t:1527265024315};\\\", \\\"{x:365,y:513,t:1527265024332};\\\", \\\"{x:344,y:510,t:1527265024348};\\\", \\\"{x:321,y:506,t:1527265024365};\\\", \\\"{x:295,y:504,t:1527265024382};\\\", \\\"{x:266,y:504,t:1527265024399};\\\", \\\"{x:233,y:502,t:1527265024415};\\\", \\\"{x:197,y:502,t:1527265024432};\\\", \\\"{x:176,y:499,t:1527265024448};\\\", \\\"{x:164,y:499,t:1527265024465};\\\", \\\"{x:162,y:499,t:1527265024496};\\\", \\\"{x:161,y:499,t:1527265024528};\\\", \\\"{x:159,y:499,t:1527265024568};\\\", \\\"{x:158,y:500,t:1527265024601};\\\", \\\"{x:161,y:504,t:1527265024791};\\\", \\\"{x:167,y:512,t:1527265024799};\\\", \\\"{x:180,y:526,t:1527265024816};\\\", \\\"{x:237,y:575,t:1527265024832};\\\", \\\"{x:285,y:611,t:1527265024849};\\\", \\\"{x:338,y:647,t:1527265024866};\\\", \\\"{x:405,y:690,t:1527265024882};\\\", \\\"{x:461,y:732,t:1527265024900};\\\", \\\"{x:501,y:759,t:1527265024915};\\\", \\\"{x:516,y:774,t:1527265024932};\\\", \\\"{x:521,y:778,t:1527265024949};\\\", \\\"{x:523,y:779,t:1527265024965};\\\", \\\"{x:522,y:779,t:1527265025225};\\\", \\\"{x:519,y:776,t:1527265025232};\\\", \\\"{x:514,y:764,t:1527265025249};\\\", \\\"{x:511,y:757,t:1527265025265};\\\", \\\"{x:510,y:753,t:1527265025283};\\\", \\\"{x:509,y:750,t:1527265025298};\\\", \\\"{x:509,y:748,t:1527265025315};\\\" ] }, { \\\"rt\\\": 33503, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 645493, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -Z -Z -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:748,t:1527265027720};\\\", \\\"{x:521,y:752,t:1527265027736};\\\", \\\"{x:549,y:758,t:1527265027754};\\\", \\\"{x:569,y:760,t:1527265027769};\\\", \\\"{x:587,y:764,t:1527265027784};\\\", \\\"{x:609,y:764,t:1527265027800};\\\", \\\"{x:636,y:764,t:1527265027817};\\\", \\\"{x:664,y:760,t:1527265027834};\\\", \\\"{x:695,y:755,t:1527265027851};\\\", \\\"{x:729,y:755,t:1527265027867};\\\", \\\"{x:758,y:755,t:1527265027884};\\\", \\\"{x:777,y:755,t:1527265027900};\\\", \\\"{x:790,y:755,t:1527265027918};\\\", \\\"{x:797,y:755,t:1527265027935};\\\", \\\"{x:798,y:755,t:1527265027952};\\\", \\\"{x:800,y:755,t:1527265028009};\\\", \\\"{x:801,y:749,t:1527265028018};\\\", \\\"{x:802,y:733,t:1527265028034};\\\", \\\"{x:802,y:732,t:1527265028305};\\\", \\\"{x:803,y:733,t:1527265028352};\\\", \\\"{x:803,y:734,t:1527265028367};\\\", \\\"{x:805,y:734,t:1527265028383};\\\", \\\"{x:805,y:735,t:1527265028400};\\\", \\\"{x:807,y:735,t:1527265028425};\\\", \\\"{x:808,y:734,t:1527265028434};\\\", \\\"{x:809,y:733,t:1527265028450};\\\", \\\"{x:813,y:731,t:1527265028467};\\\", \\\"{x:816,y:729,t:1527265028483};\\\", \\\"{x:822,y:726,t:1527265028501};\\\", \\\"{x:826,y:724,t:1527265028517};\\\", \\\"{x:830,y:721,t:1527265028534};\\\", \\\"{x:834,y:722,t:1527265033241};\\\", \\\"{x:837,y:725,t:1527265033250};\\\", \\\"{x:846,y:727,t:1527265033267};\\\", \\\"{x:858,y:732,t:1527265033283};\\\", \\\"{x:885,y:737,t:1527265033301};\\\", \\\"{x:937,y:743,t:1527265033317};\\\", \\\"{x:1018,y:743,t:1527265033334};\\\", \\\"{x:1104,y:743,t:1527265033350};\\\", \\\"{x:1204,y:743,t:1527265033367};\\\", \\\"{x:1307,y:738,t:1527265033384};\\\", \\\"{x:1435,y:717,t:1527265033400};\\\", \\\"{x:1489,y:706,t:1527265033417};\\\", \\\"{x:1510,y:701,t:1527265033434};\\\", \\\"{x:1515,y:699,t:1527265033451};\\\", \\\"{x:1515,y:698,t:1527265033480};\\\", \\\"{x:1513,y:697,t:1527265033488};\\\", \\\"{x:1511,y:697,t:1527265033500};\\\", \\\"{x:1508,y:696,t:1527265033516};\\\", \\\"{x:1507,y:696,t:1527265033533};\\\", \\\"{x:1505,y:696,t:1527265033550};\\\", \\\"{x:1504,y:695,t:1527265033567};\\\", \\\"{x:1503,y:694,t:1527265033583};\\\", \\\"{x:1500,y:692,t:1527265033600};\\\", \\\"{x:1499,y:692,t:1527265033617};\\\", \\\"{x:1498,y:691,t:1527265033640};\\\", \\\"{x:1497,y:689,t:1527265033650};\\\", \\\"{x:1494,y:682,t:1527265033667};\\\", \\\"{x:1493,y:679,t:1527265033684};\\\", \\\"{x:1490,y:675,t:1527265033701};\\\", \\\"{x:1486,y:671,t:1527265033717};\\\", \\\"{x:1483,y:670,t:1527265033734};\\\", \\\"{x:1478,y:667,t:1527265033751};\\\", \\\"{x:1476,y:667,t:1527265033766};\\\", \\\"{x:1467,y:667,t:1527265033784};\\\", \\\"{x:1447,y:667,t:1527265033800};\\\", \\\"{x:1431,y:669,t:1527265033817};\\\", \\\"{x:1409,y:673,t:1527265033833};\\\", \\\"{x:1384,y:680,t:1527265033851};\\\", \\\"{x:1360,y:686,t:1527265033866};\\\", \\\"{x:1337,y:692,t:1527265033884};\\\", \\\"{x:1321,y:697,t:1527265033900};\\\", \\\"{x:1312,y:700,t:1527265033917};\\\", \\\"{x:1304,y:702,t:1527265033934};\\\", \\\"{x:1300,y:704,t:1527265033951};\\\", \\\"{x:1298,y:705,t:1527265033967};\\\", \\\"{x:1297,y:706,t:1527265033984};\\\", \\\"{x:1297,y:707,t:1527265034000};\\\", \\\"{x:1296,y:708,t:1527265034057};\\\", \\\"{x:1296,y:709,t:1527265034067};\\\", \\\"{x:1296,y:711,t:1527265034084};\\\", \\\"{x:1299,y:711,t:1527265034100};\\\", \\\"{x:1303,y:713,t:1527265034117};\\\", \\\"{x:1306,y:714,t:1527265034134};\\\", \\\"{x:1312,y:717,t:1527265034151};\\\", \\\"{x:1318,y:719,t:1527265034167};\\\", \\\"{x:1321,y:719,t:1527265034183};\\\", \\\"{x:1325,y:719,t:1527265034201};\\\", \\\"{x:1329,y:719,t:1527265034217};\\\", \\\"{x:1332,y:719,t:1527265034234};\\\", \\\"{x:1337,y:719,t:1527265034251};\\\", \\\"{x:1339,y:719,t:1527265034267};\\\", \\\"{x:1342,y:719,t:1527265034283};\\\", \\\"{x:1343,y:719,t:1527265034301};\\\", \\\"{x:1344,y:719,t:1527265034317};\\\", \\\"{x:1347,y:719,t:1527265034335};\\\", \\\"{x:1348,y:719,t:1527265034351};\\\", \\\"{x:1350,y:719,t:1527265034367};\\\", \\\"{x:1350,y:718,t:1527265034384};\\\", \\\"{x:1351,y:718,t:1527265034401};\\\", \\\"{x:1352,y:717,t:1527265034417};\\\", \\\"{x:1352,y:716,t:1527265034441};\\\", \\\"{x:1352,y:715,t:1527265034451};\\\", \\\"{x:1352,y:713,t:1527265034473};\\\", \\\"{x:1352,y:712,t:1527265034496};\\\", \\\"{x:1352,y:711,t:1527265034528};\\\", \\\"{x:1352,y:710,t:1527265034544};\\\", \\\"{x:1351,y:709,t:1527265034552};\\\", \\\"{x:1350,y:709,t:1527265034584};\\\", \\\"{x:1349,y:708,t:1527265034601};\\\", \\\"{x:1348,y:708,t:1527265034633};\\\", \\\"{x:1347,y:708,t:1527265034673};\\\", \\\"{x:1346,y:707,t:1527265035240};\\\", \\\"{x:1346,y:706,t:1527265035251};\\\", \\\"{x:1346,y:705,t:1527265035273};\\\", \\\"{x:1355,y:705,t:1527265043193};\\\", \\\"{x:1366,y:705,t:1527265043200};\\\", \\\"{x:1383,y:705,t:1527265043217};\\\", \\\"{x:1405,y:705,t:1527265043233};\\\", \\\"{x:1434,y:705,t:1527265043251};\\\", \\\"{x:1465,y:705,t:1527265043267};\\\", \\\"{x:1488,y:705,t:1527265043283};\\\", \\\"{x:1505,y:705,t:1527265043300};\\\", \\\"{x:1518,y:705,t:1527265043317};\\\", \\\"{x:1526,y:705,t:1527265043335};\\\", \\\"{x:1530,y:705,t:1527265043350};\\\", \\\"{x:1531,y:705,t:1527265043368};\\\", \\\"{x:1533,y:705,t:1527265043383};\\\", \\\"{x:1537,y:705,t:1527265043400};\\\", \\\"{x:1541,y:705,t:1527265043417};\\\", \\\"{x:1547,y:705,t:1527265043434};\\\", \\\"{x:1552,y:705,t:1527265043451};\\\", \\\"{x:1559,y:705,t:1527265043468};\\\", \\\"{x:1564,y:705,t:1527265043484};\\\", \\\"{x:1568,y:705,t:1527265043500};\\\", \\\"{x:1571,y:705,t:1527265043517};\\\", \\\"{x:1573,y:705,t:1527265043533};\\\", \\\"{x:1577,y:705,t:1527265043549};\\\", \\\"{x:1581,y:705,t:1527265043566};\\\", \\\"{x:1587,y:705,t:1527265043583};\\\", \\\"{x:1595,y:705,t:1527265043600};\\\", \\\"{x:1600,y:704,t:1527265043616};\\\", \\\"{x:1605,y:701,t:1527265043633};\\\", \\\"{x:1608,y:701,t:1527265043650};\\\", \\\"{x:1609,y:701,t:1527265043666};\\\", \\\"{x:1610,y:701,t:1527265043683};\\\", \\\"{x:1611,y:701,t:1527265043701};\\\", \\\"{x:1611,y:700,t:1527265043769};\\\", \\\"{x:1612,y:699,t:1527265043783};\\\", \\\"{x:1613,y:699,t:1527265043800};\\\", \\\"{x:1611,y:700,t:1527265046505};\\\", \\\"{x:1609,y:700,t:1527265046518};\\\", \\\"{x:1605,y:702,t:1527265046535};\\\", \\\"{x:1596,y:702,t:1527265046550};\\\", \\\"{x:1570,y:702,t:1527265046566};\\\", \\\"{x:1540,y:702,t:1527265046583};\\\", \\\"{x:1498,y:702,t:1527265046600};\\\", \\\"{x:1476,y:702,t:1527265046617};\\\", \\\"{x:1460,y:702,t:1527265046634};\\\", \\\"{x:1450,y:702,t:1527265046651};\\\", \\\"{x:1440,y:702,t:1527265046667};\\\", \\\"{x:1432,y:702,t:1527265046684};\\\", \\\"{x:1426,y:702,t:1527265046700};\\\", \\\"{x:1420,y:703,t:1527265046716};\\\", \\\"{x:1413,y:704,t:1527265046734};\\\", \\\"{x:1407,y:704,t:1527265046750};\\\", \\\"{x:1400,y:706,t:1527265046766};\\\", \\\"{x:1392,y:708,t:1527265046783};\\\", \\\"{x:1386,y:710,t:1527265046800};\\\", \\\"{x:1379,y:712,t:1527265046816};\\\", \\\"{x:1374,y:714,t:1527265046833};\\\", \\\"{x:1369,y:715,t:1527265046850};\\\", \\\"{x:1368,y:717,t:1527265046866};\\\", \\\"{x:1365,y:723,t:1527265046883};\\\", \\\"{x:1364,y:730,t:1527265046900};\\\", \\\"{x:1364,y:737,t:1527265046916};\\\", \\\"{x:1363,y:743,t:1527265046934};\\\", \\\"{x:1363,y:747,t:1527265046950};\\\", \\\"{x:1363,y:752,t:1527265046966};\\\", \\\"{x:1363,y:756,t:1527265046983};\\\", \\\"{x:1363,y:765,t:1527265046999};\\\", \\\"{x:1363,y:772,t:1527265047016};\\\", \\\"{x:1366,y:781,t:1527265047034};\\\", \\\"{x:1367,y:785,t:1527265047050};\\\", \\\"{x:1367,y:793,t:1527265047066};\\\", \\\"{x:1367,y:797,t:1527265047083};\\\", \\\"{x:1367,y:804,t:1527265047100};\\\", \\\"{x:1367,y:811,t:1527265047117};\\\", \\\"{x:1367,y:818,t:1527265047134};\\\", \\\"{x:1367,y:825,t:1527265047150};\\\", \\\"{x:1367,y:831,t:1527265047167};\\\", \\\"{x:1367,y:834,t:1527265047183};\\\", \\\"{x:1366,y:838,t:1527265047200};\\\", \\\"{x:1365,y:842,t:1527265047216};\\\", \\\"{x:1364,y:843,t:1527265047233};\\\", \\\"{x:1362,y:840,t:1527265047345};\\\", \\\"{x:1359,y:830,t:1527265047353};\\\", \\\"{x:1357,y:823,t:1527265047367};\\\", \\\"{x:1350,y:809,t:1527265047384};\\\", \\\"{x:1345,y:796,t:1527265047400};\\\", \\\"{x:1338,y:778,t:1527265047417};\\\", \\\"{x:1337,y:771,t:1527265047433};\\\", \\\"{x:1334,y:764,t:1527265047450};\\\", \\\"{x:1332,y:755,t:1527265047467};\\\", \\\"{x:1332,y:746,t:1527265047483};\\\", \\\"{x:1332,y:743,t:1527265047499};\\\", \\\"{x:1332,y:738,t:1527265047516};\\\", \\\"{x:1332,y:736,t:1527265047534};\\\", \\\"{x:1332,y:735,t:1527265047550};\\\", \\\"{x:1332,y:734,t:1527265047567};\\\", \\\"{x:1333,y:733,t:1527265047584};\\\", \\\"{x:1333,y:732,t:1527265047600};\\\", \\\"{x:1334,y:731,t:1527265047616};\\\", \\\"{x:1336,y:730,t:1527265047634};\\\", \\\"{x:1337,y:729,t:1527265047650};\\\", \\\"{x:1340,y:728,t:1527265047667};\\\", \\\"{x:1343,y:726,t:1527265047683};\\\", \\\"{x:1348,y:725,t:1527265047700};\\\", \\\"{x:1359,y:722,t:1527265047717};\\\", \\\"{x:1383,y:717,t:1527265047735};\\\", \\\"{x:1412,y:714,t:1527265047749};\\\", \\\"{x:1441,y:711,t:1527265047766};\\\", \\\"{x:1470,y:708,t:1527265047784};\\\", \\\"{x:1501,y:704,t:1527265047800};\\\", \\\"{x:1533,y:700,t:1527265047817};\\\", \\\"{x:1538,y:699,t:1527265047833};\\\", \\\"{x:1541,y:699,t:1527265047850};\\\", \\\"{x:1542,y:699,t:1527265047977};\\\", \\\"{x:1544,y:699,t:1527265047985};\\\", \\\"{x:1547,y:699,t:1527265048000};\\\", \\\"{x:1554,y:699,t:1527265048016};\\\", \\\"{x:1564,y:699,t:1527265048034};\\\", \\\"{x:1571,y:699,t:1527265048050};\\\", \\\"{x:1583,y:701,t:1527265048067};\\\", \\\"{x:1590,y:702,t:1527265048084};\\\", \\\"{x:1594,y:702,t:1527265048100};\\\", \\\"{x:1596,y:702,t:1527265048117};\\\", \\\"{x:1597,y:702,t:1527265048135};\\\", \\\"{x:1599,y:702,t:1527265048193};\\\", \\\"{x:1600,y:702,t:1527265048201};\\\", \\\"{x:1604,y:702,t:1527265048216};\\\", \\\"{x:1609,y:703,t:1527265048234};\\\", \\\"{x:1611,y:703,t:1527265048249};\\\", \\\"{x:1616,y:705,t:1527265048267};\\\", \\\"{x:1619,y:706,t:1527265048284};\\\", \\\"{x:1622,y:707,t:1527265048299};\\\", \\\"{x:1625,y:708,t:1527265048317};\\\", \\\"{x:1626,y:708,t:1527265048335};\\\", \\\"{x:1627,y:709,t:1527265048350};\\\", \\\"{x:1627,y:710,t:1527265048705};\\\", \\\"{x:1627,y:712,t:1527265048716};\\\", \\\"{x:1627,y:717,t:1527265048734};\\\", \\\"{x:1627,y:720,t:1527265048750};\\\", \\\"{x:1627,y:725,t:1527265048767};\\\", \\\"{x:1627,y:728,t:1527265048783};\\\", \\\"{x:1627,y:732,t:1527265048800};\\\", \\\"{x:1627,y:735,t:1527265048816};\\\", \\\"{x:1627,y:736,t:1527265048833};\\\", \\\"{x:1627,y:737,t:1527265049025};\\\", \\\"{x:1626,y:737,t:1527265049033};\\\", \\\"{x:1623,y:737,t:1527265049050};\\\", \\\"{x:1620,y:737,t:1527265049067};\\\", \\\"{x:1617,y:736,t:1527265049083};\\\", \\\"{x:1616,y:735,t:1527265049128};\\\", \\\"{x:1615,y:735,t:1527265049144};\\\", \\\"{x:1615,y:733,t:1527265049161};\\\", \\\"{x:1615,y:731,t:1527265049176};\\\", \\\"{x:1615,y:729,t:1527265049184};\\\", \\\"{x:1615,y:728,t:1527265049200};\\\", \\\"{x:1615,y:723,t:1527265049217};\\\", \\\"{x:1615,y:722,t:1527265049234};\\\", \\\"{x:1615,y:719,t:1527265049249};\\\", \\\"{x:1616,y:717,t:1527265049267};\\\", \\\"{x:1616,y:715,t:1527265049283};\\\", \\\"{x:1616,y:711,t:1527265049299};\\\", \\\"{x:1616,y:710,t:1527265049317};\\\", \\\"{x:1617,y:709,t:1527265049334};\\\", \\\"{x:1617,y:708,t:1527265049352};\\\", \\\"{x:1617,y:707,t:1527265049937};\\\", \\\"{x:1617,y:706,t:1527265049949};\\\", \\\"{x:1617,y:704,t:1527265049967};\\\", \\\"{x:1617,y:703,t:1527265049983};\\\", \\\"{x:1617,y:702,t:1527265050000};\\\", \\\"{x:1617,y:701,t:1527265050049};\\\", \\\"{x:1617,y:700,t:1527265050200};\\\", \\\"{x:1617,y:696,t:1527265050216};\\\", \\\"{x:1617,y:692,t:1527265050234};\\\", \\\"{x:1617,y:686,t:1527265050251};\\\", \\\"{x:1617,y:681,t:1527265050267};\\\", \\\"{x:1617,y:678,t:1527265050284};\\\", \\\"{x:1617,y:676,t:1527265050300};\\\", \\\"{x:1617,y:672,t:1527265050317};\\\", \\\"{x:1617,y:669,t:1527265050334};\\\", \\\"{x:1617,y:665,t:1527265050349};\\\", \\\"{x:1617,y:661,t:1527265050366};\\\", \\\"{x:1617,y:657,t:1527265050384};\\\", \\\"{x:1617,y:653,t:1527265050400};\\\", \\\"{x:1617,y:650,t:1527265050417};\\\", \\\"{x:1617,y:646,t:1527265050433};\\\", \\\"{x:1617,y:640,t:1527265050450};\\\", \\\"{x:1617,y:635,t:1527265050467};\\\", \\\"{x:1617,y:632,t:1527265050483};\\\", \\\"{x:1617,y:629,t:1527265050500};\\\", \\\"{x:1617,y:625,t:1527265050517};\\\", \\\"{x:1616,y:623,t:1527265050535};\\\", \\\"{x:1616,y:621,t:1527265050550};\\\", \\\"{x:1615,y:618,t:1527265050567};\\\", \\\"{x:1614,y:611,t:1527265050584};\\\", \\\"{x:1612,y:606,t:1527265050600};\\\", \\\"{x:1611,y:599,t:1527265050616};\\\", \\\"{x:1609,y:596,t:1527265050634};\\\", \\\"{x:1609,y:592,t:1527265050650};\\\", \\\"{x:1609,y:588,t:1527265050667};\\\", \\\"{x:1609,y:582,t:1527265050684};\\\", \\\"{x:1609,y:576,t:1527265050700};\\\", \\\"{x:1609,y:570,t:1527265050716};\\\", \\\"{x:1609,y:566,t:1527265050734};\\\", \\\"{x:1608,y:562,t:1527265050750};\\\", \\\"{x:1608,y:558,t:1527265050767};\\\", \\\"{x:1608,y:551,t:1527265050784};\\\", \\\"{x:1608,y:545,t:1527265050800};\\\", \\\"{x:1608,y:540,t:1527265050816};\\\", \\\"{x:1608,y:537,t:1527265050833};\\\", \\\"{x:1608,y:533,t:1527265050850};\\\", \\\"{x:1607,y:528,t:1527265050866};\\\", \\\"{x:1607,y:525,t:1527265050883};\\\", \\\"{x:1605,y:519,t:1527265050900};\\\", \\\"{x:1605,y:518,t:1527265050917};\\\", \\\"{x:1605,y:515,t:1527265050933};\\\", \\\"{x:1605,y:514,t:1527265050949};\\\", \\\"{x:1604,y:512,t:1527265050967};\\\", \\\"{x:1604,y:511,t:1527265050991};\\\", \\\"{x:1605,y:512,t:1527265051231};\\\", \\\"{x:1605,y:513,t:1527265051247};\\\", \\\"{x:1605,y:514,t:1527265051255};\\\", \\\"{x:1605,y:515,t:1527265051266};\\\", \\\"{x:1605,y:516,t:1527265051283};\\\", \\\"{x:1606,y:519,t:1527265051299};\\\", \\\"{x:1606,y:520,t:1527265051316};\\\", \\\"{x:1606,y:521,t:1527265051332};\\\", \\\"{x:1606,y:522,t:1527265051349};\\\", \\\"{x:1608,y:525,t:1527265051376};\\\", \\\"{x:1608,y:526,t:1527265051416};\\\", \\\"{x:1609,y:526,t:1527265051447};\\\", \\\"{x:1609,y:527,t:1527265051464};\\\", \\\"{x:1609,y:528,t:1527265051496};\\\", \\\"{x:1609,y:529,t:1527265051512};\\\", \\\"{x:1609,y:530,t:1527265051520};\\\", \\\"{x:1609,y:531,t:1527265051551};\\\", \\\"{x:1609,y:533,t:1527265051584};\\\", \\\"{x:1609,y:534,t:1527265051616};\\\", \\\"{x:1609,y:536,t:1527265051640};\\\", \\\"{x:1609,y:537,t:1527265051656};\\\", \\\"{x:1609,y:539,t:1527265051673};\\\", \\\"{x:1609,y:540,t:1527265051688};\\\", \\\"{x:1609,y:542,t:1527265051704};\\\", \\\"{x:1609,y:543,t:1527265051717};\\\", \\\"{x:1609,y:545,t:1527265051733};\\\", \\\"{x:1609,y:546,t:1527265051750};\\\", \\\"{x:1609,y:548,t:1527265051767};\\\", \\\"{x:1609,y:551,t:1527265051783};\\\", \\\"{x:1609,y:556,t:1527265051800};\\\", \\\"{x:1609,y:558,t:1527265051817};\\\", \\\"{x:1609,y:562,t:1527265051833};\\\", \\\"{x:1609,y:566,t:1527265051850};\\\", \\\"{x:1609,y:571,t:1527265051867};\\\", \\\"{x:1609,y:577,t:1527265051883};\\\", \\\"{x:1609,y:582,t:1527265051900};\\\", \\\"{x:1609,y:587,t:1527265051917};\\\", \\\"{x:1609,y:592,t:1527265051933};\\\", \\\"{x:1609,y:595,t:1527265051950};\\\", \\\"{x:1609,y:599,t:1527265051967};\\\", \\\"{x:1609,y:601,t:1527265051983};\\\", \\\"{x:1609,y:605,t:1527265052000};\\\", \\\"{x:1609,y:609,t:1527265052016};\\\", \\\"{x:1609,y:612,t:1527265052033};\\\", \\\"{x:1609,y:616,t:1527265052050};\\\", \\\"{x:1609,y:620,t:1527265052067};\\\", \\\"{x:1609,y:623,t:1527265052083};\\\", \\\"{x:1609,y:627,t:1527265052100};\\\", \\\"{x:1610,y:632,t:1527265052116};\\\", \\\"{x:1611,y:637,t:1527265052132};\\\", \\\"{x:1612,y:641,t:1527265052149};\\\", \\\"{x:1612,y:645,t:1527265052166};\\\", \\\"{x:1612,y:650,t:1527265052182};\\\", \\\"{x:1612,y:653,t:1527265052199};\\\", \\\"{x:1612,y:661,t:1527265052216};\\\", \\\"{x:1612,y:664,t:1527265052232};\\\", \\\"{x:1612,y:668,t:1527265052250};\\\", \\\"{x:1612,y:671,t:1527265052266};\\\", \\\"{x:1612,y:675,t:1527265052283};\\\", \\\"{x:1612,y:678,t:1527265052300};\\\", \\\"{x:1612,y:682,t:1527265052316};\\\", \\\"{x:1612,y:686,t:1527265052332};\\\", \\\"{x:1612,y:689,t:1527265052350};\\\", \\\"{x:1612,y:692,t:1527265052367};\\\", \\\"{x:1612,y:696,t:1527265052382};\\\", \\\"{x:1612,y:699,t:1527265052399};\\\", \\\"{x:1612,y:702,t:1527265052417};\\\", \\\"{x:1612,y:705,t:1527265052433};\\\", \\\"{x:1612,y:707,t:1527265052450};\\\", \\\"{x:1612,y:709,t:1527265052467};\\\", \\\"{x:1612,y:711,t:1527265052483};\\\", \\\"{x:1612,y:713,t:1527265052500};\\\", \\\"{x:1612,y:717,t:1527265052517};\\\", \\\"{x:1612,y:718,t:1527265052533};\\\", \\\"{x:1612,y:721,t:1527265052550};\\\", \\\"{x:1612,y:724,t:1527265052566};\\\", \\\"{x:1612,y:725,t:1527265052585};\\\", \\\"{x:1612,y:727,t:1527265052600};\\\", \\\"{x:1612,y:730,t:1527265052617};\\\", \\\"{x:1612,y:731,t:1527265052633};\\\", \\\"{x:1612,y:733,t:1527265052650};\\\", \\\"{x:1612,y:734,t:1527265052667};\\\", \\\"{x:1612,y:735,t:1527265052721};\\\", \\\"{x:1612,y:736,t:1527265052735};\\\", \\\"{x:1612,y:737,t:1527265052768};\\\", \\\"{x:1612,y:738,t:1527265052784};\\\", \\\"{x:1612,y:739,t:1527265052800};\\\", \\\"{x:1612,y:740,t:1527265052817};\\\", \\\"{x:1612,y:741,t:1527265052832};\\\", \\\"{x:1612,y:743,t:1527265052850};\\\", \\\"{x:1612,y:744,t:1527265052866};\\\", \\\"{x:1612,y:746,t:1527265052883};\\\", \\\"{x:1612,y:748,t:1527265052912};\\\", \\\"{x:1612,y:749,t:1527265052920};\\\", \\\"{x:1612,y:750,t:1527265052945};\\\", \\\"{x:1612,y:751,t:1527265052952};\\\", \\\"{x:1612,y:752,t:1527265052968};\\\", \\\"{x:1612,y:753,t:1527265052985};\\\", \\\"{x:1612,y:754,t:1527265053040};\\\", \\\"{x:1612,y:756,t:1527265053065};\\\", \\\"{x:1612,y:757,t:1527265053072};\\\", \\\"{x:1612,y:759,t:1527265053089};\\\", \\\"{x:1612,y:760,t:1527265053100};\\\", \\\"{x:1612,y:761,t:1527265053117};\\\", \\\"{x:1612,y:762,t:1527265053136};\\\", \\\"{x:1612,y:763,t:1527265053150};\\\", \\\"{x:1612,y:764,t:1527265053169};\\\", \\\"{x:1612,y:765,t:1527265053184};\\\", \\\"{x:1612,y:767,t:1527265053200};\\\", \\\"{x:1613,y:770,t:1527265053216};\\\", \\\"{x:1613,y:771,t:1527265053248};\\\", \\\"{x:1613,y:773,t:1527265053273};\\\", \\\"{x:1613,y:774,t:1527265053304};\\\", \\\"{x:1613,y:775,t:1527265053320};\\\", \\\"{x:1613,y:776,t:1527265053333};\\\", \\\"{x:1613,y:777,t:1527265053350};\\\", \\\"{x:1613,y:779,t:1527265053400};\\\", \\\"{x:1613,y:780,t:1527265053448};\\\", \\\"{x:1613,y:782,t:1527265053505};\\\", \\\"{x:1610,y:783,t:1527265055265};\\\", \\\"{x:1578,y:783,t:1527265055283};\\\", \\\"{x:1533,y:783,t:1527265055300};\\\", \\\"{x:1480,y:783,t:1527265055316};\\\", \\\"{x:1422,y:783,t:1527265055335};\\\", \\\"{x:1374,y:783,t:1527265055350};\\\", \\\"{x:1350,y:783,t:1527265055366};\\\", \\\"{x:1336,y:783,t:1527265055383};\\\", \\\"{x:1330,y:781,t:1527265055400};\\\", \\\"{x:1327,y:778,t:1527265055416};\\\", \\\"{x:1325,y:775,t:1527265055433};\\\", \\\"{x:1324,y:771,t:1527265055450};\\\", \\\"{x:1323,y:768,t:1527265055466};\\\", \\\"{x:1323,y:766,t:1527265055482};\\\", \\\"{x:1323,y:762,t:1527265055500};\\\", \\\"{x:1323,y:758,t:1527265055516};\\\", \\\"{x:1323,y:753,t:1527265055534};\\\", \\\"{x:1323,y:751,t:1527265055550};\\\", \\\"{x:1324,y:747,t:1527265055566};\\\", \\\"{x:1327,y:741,t:1527265055583};\\\", \\\"{x:1333,y:729,t:1527265055600};\\\", \\\"{x:1335,y:723,t:1527265055616};\\\", \\\"{x:1338,y:719,t:1527265055633};\\\", \\\"{x:1341,y:714,t:1527265055650};\\\", \\\"{x:1342,y:712,t:1527265055666};\\\", \\\"{x:1343,y:710,t:1527265055683};\\\", \\\"{x:1345,y:708,t:1527265055700};\\\", \\\"{x:1345,y:707,t:1527265055716};\\\", \\\"{x:1347,y:704,t:1527265055734};\\\", \\\"{x:1349,y:701,t:1527265055750};\\\", \\\"{x:1349,y:700,t:1527265055766};\\\", \\\"{x:1351,y:697,t:1527265055783};\\\", \\\"{x:1349,y:697,t:1527265056177};\\\", \\\"{x:1344,y:697,t:1527265056184};\\\", \\\"{x:1336,y:697,t:1527265056201};\\\", \\\"{x:1326,y:697,t:1527265056216};\\\", \\\"{x:1315,y:697,t:1527265056233};\\\", \\\"{x:1304,y:697,t:1527265056250};\\\", \\\"{x:1294,y:697,t:1527265056266};\\\", \\\"{x:1284,y:697,t:1527265056282};\\\", \\\"{x:1275,y:697,t:1527265056300};\\\", \\\"{x:1262,y:697,t:1527265056316};\\\", \\\"{x:1251,y:693,t:1527265056332};\\\", \\\"{x:1236,y:693,t:1527265056349};\\\", \\\"{x:1219,y:693,t:1527265056365};\\\", \\\"{x:1200,y:693,t:1527265056382};\\\", \\\"{x:1161,y:693,t:1527265056399};\\\", \\\"{x:1125,y:693,t:1527265056416};\\\", \\\"{x:1085,y:693,t:1527265056432};\\\", \\\"{x:1053,y:692,t:1527265056449};\\\", \\\"{x:1016,y:691,t:1527265056466};\\\", \\\"{x:990,y:691,t:1527265056483};\\\", \\\"{x:978,y:691,t:1527265056500};\\\", \\\"{x:976,y:691,t:1527265056515};\\\", \\\"{x:978,y:694,t:1527265056631};\\\", \\\"{x:985,y:696,t:1527265056639};\\\", \\\"{x:995,y:697,t:1527265056649};\\\", \\\"{x:1018,y:698,t:1527265056666};\\\", \\\"{x:1044,y:698,t:1527265056682};\\\", \\\"{x:1078,y:699,t:1527265056700};\\\", \\\"{x:1125,y:699,t:1527265056715};\\\", \\\"{x:1170,y:699,t:1527265056734};\\\", \\\"{x:1220,y:699,t:1527265056750};\\\", \\\"{x:1262,y:699,t:1527265056765};\\\", \\\"{x:1290,y:699,t:1527265056783};\\\", \\\"{x:1331,y:702,t:1527265056800};\\\", \\\"{x:1345,y:702,t:1527265056815};\\\", \\\"{x:1352,y:702,t:1527265056832};\\\", \\\"{x:1357,y:702,t:1527265056850};\\\", \\\"{x:1359,y:702,t:1527265056865};\\\", \\\"{x:1360,y:702,t:1527265056883};\\\", \\\"{x:1360,y:704,t:1527265057112};\\\", \\\"{x:1359,y:706,t:1527265057120};\\\", \\\"{x:1358,y:710,t:1527265057133};\\\", \\\"{x:1356,y:720,t:1527265057150};\\\", \\\"{x:1356,y:727,t:1527265057166};\\\", \\\"{x:1356,y:736,t:1527265057182};\\\", \\\"{x:1356,y:748,t:1527265057200};\\\", \\\"{x:1356,y:754,t:1527265057216};\\\", \\\"{x:1356,y:760,t:1527265057233};\\\", \\\"{x:1356,y:764,t:1527265057249};\\\", \\\"{x:1356,y:770,t:1527265057265};\\\", \\\"{x:1355,y:774,t:1527265057284};\\\", \\\"{x:1353,y:778,t:1527265057300};\\\", \\\"{x:1353,y:779,t:1527265057316};\\\", \\\"{x:1353,y:780,t:1527265057334};\\\", \\\"{x:1353,y:781,t:1527265057385};\\\", \\\"{x:1352,y:781,t:1527265057400};\\\", \\\"{x:1352,y:782,t:1527265057425};\\\", \\\"{x:1351,y:784,t:1527265057448};\\\", \\\"{x:1350,y:784,t:1527265057456};\\\", \\\"{x:1347,y:785,t:1527265057466};\\\", \\\"{x:1333,y:789,t:1527265057483};\\\", \\\"{x:1306,y:795,t:1527265057500};\\\", \\\"{x:1255,y:806,t:1527265057516};\\\", \\\"{x:1208,y:818,t:1527265057535};\\\", \\\"{x:1168,y:831,t:1527265057550};\\\", \\\"{x:1112,y:848,t:1527265057566};\\\", \\\"{x:1047,y:861,t:1527265057583};\\\", \\\"{x:940,y:874,t:1527265057600};\\\", \\\"{x:879,y:874,t:1527265057616};\\\", \\\"{x:815,y:874,t:1527265057633};\\\", \\\"{x:748,y:864,t:1527265057650};\\\", \\\"{x:689,y:856,t:1527265057666};\\\", \\\"{x:657,y:847,t:1527265057683};\\\", \\\"{x:638,y:836,t:1527265057700};\\\", \\\"{x:622,y:824,t:1527265057715};\\\", \\\"{x:597,y:803,t:1527265057735};\\\", \\\"{x:575,y:787,t:1527265057750};\\\", \\\"{x:574,y:786,t:1527265057766};\\\", \\\"{x:572,y:786,t:1527265057783};\\\", \\\"{x:572,y:784,t:1527265057969};\\\", \\\"{x:570,y:784,t:1527265057983};\\\", \\\"{x:569,y:784,t:1527265057999};\\\", \\\"{x:559,y:777,t:1527265058016};\\\", \\\"{x:558,y:763,t:1527265058033};\\\", \\\"{x:561,y:736,t:1527265058050};\\\", \\\"{x:567,y:681,t:1527265058066};\\\", \\\"{x:579,y:613,t:1527265058083};\\\", \\\"{x:610,y:510,t:1527265058109};\\\", \\\"{x:631,y:458,t:1527265058125};\\\", \\\"{x:641,y:435,t:1527265058142};\\\", \\\"{x:646,y:418,t:1527265058159};\\\", \\\"{x:652,y:408,t:1527265058175};\\\", \\\"{x:652,y:406,t:1527265058193};\\\", \\\"{x:653,y:406,t:1527265058223};\\\", \\\"{x:654,y:406,t:1527265058232};\\\", \\\"{x:655,y:406,t:1527265058242};\\\", \\\"{x:664,y:409,t:1527265058258};\\\", \\\"{x:677,y:418,t:1527265058275};\\\", \\\"{x:691,y:428,t:1527265058292};\\\", \\\"{x:706,y:438,t:1527265058309};\\\", \\\"{x:715,y:444,t:1527265058326};\\\", \\\"{x:720,y:448,t:1527265058343};\\\", \\\"{x:721,y:450,t:1527265058358};\\\", \\\"{x:718,y:464,t:1527265058376};\\\", \\\"{x:706,y:480,t:1527265058393};\\\", \\\"{x:680,y:498,t:1527265058411};\\\", \\\"{x:633,y:529,t:1527265058426};\\\", \\\"{x:575,y:555,t:1527265058443};\\\", \\\"{x:492,y:577,t:1527265058461};\\\", \\\"{x:417,y:599,t:1527265058476};\\\", \\\"{x:361,y:607,t:1527265058493};\\\", \\\"{x:324,y:607,t:1527265058510};\\\", \\\"{x:302,y:607,t:1527265058525};\\\", \\\"{x:294,y:607,t:1527265058542};\\\", \\\"{x:294,y:605,t:1527265058575};\\\", \\\"{x:294,y:602,t:1527265058592};\\\", \\\"{x:294,y:600,t:1527265058609};\\\", \\\"{x:294,y:597,t:1527265058625};\\\", \\\"{x:297,y:593,t:1527265058644};\\\", \\\"{x:301,y:590,t:1527265058660};\\\", \\\"{x:306,y:584,t:1527265058676};\\\", \\\"{x:314,y:581,t:1527265058693};\\\", \\\"{x:320,y:577,t:1527265058710};\\\", \\\"{x:326,y:574,t:1527265058726};\\\", \\\"{x:331,y:571,t:1527265058743};\\\", \\\"{x:337,y:569,t:1527265058760};\\\", \\\"{x:335,y:568,t:1527265058848};\\\", \\\"{x:332,y:568,t:1527265058860};\\\", \\\"{x:321,y:568,t:1527265058876};\\\", \\\"{x:302,y:564,t:1527265058893};\\\", \\\"{x:280,y:558,t:1527265058911};\\\", \\\"{x:255,y:548,t:1527265058929};\\\", \\\"{x:231,y:539,t:1527265058943};\\\", \\\"{x:196,y:528,t:1527265058959};\\\", \\\"{x:180,y:524,t:1527265058977};\\\", \\\"{x:172,y:524,t:1527265058992};\\\", \\\"{x:167,y:524,t:1527265059010};\\\", \\\"{x:165,y:524,t:1527265059026};\\\", \\\"{x:164,y:524,t:1527265059042};\\\", \\\"{x:163,y:524,t:1527265059059};\\\", \\\"{x:162,y:525,t:1527265059120};\\\", \\\"{x:162,y:530,t:1527265059127};\\\", \\\"{x:161,y:537,t:1527265059143};\\\", \\\"{x:157,y:552,t:1527265059160};\\\", \\\"{x:156,y:558,t:1527265059177};\\\", \\\"{x:155,y:561,t:1527265059193};\\\", \\\"{x:154,y:564,t:1527265059210};\\\", \\\"{x:153,y:563,t:1527265059440};\\\", \\\"{x:153,y:560,t:1527265059449};\\\", \\\"{x:153,y:557,t:1527265059459};\\\", \\\"{x:153,y:552,t:1527265059477};\\\", \\\"{x:153,y:549,t:1527265059494};\\\", \\\"{x:153,y:548,t:1527265059743};\\\", \\\"{x:160,y:550,t:1527265059761};\\\", \\\"{x:172,y:554,t:1527265059777};\\\", \\\"{x:189,y:564,t:1527265059794};\\\", \\\"{x:208,y:578,t:1527265059809};\\\", \\\"{x:227,y:590,t:1527265059826};\\\", \\\"{x:250,y:603,t:1527265059844};\\\", \\\"{x:272,y:617,t:1527265059860};\\\", \\\"{x:296,y:631,t:1527265059877};\\\", \\\"{x:318,y:646,t:1527265059894};\\\", \\\"{x:339,y:658,t:1527265059911};\\\", \\\"{x:359,y:665,t:1527265059926};\\\", \\\"{x:373,y:673,t:1527265059944};\\\", \\\"{x:379,y:674,t:1527265059961};\\\", \\\"{x:382,y:677,t:1527265059977};\\\", \\\"{x:387,y:681,t:1527265059993};\\\", \\\"{x:393,y:685,t:1527265060010};\\\", \\\"{x:401,y:689,t:1527265060028};\\\", \\\"{x:409,y:693,t:1527265060044};\\\", \\\"{x:413,y:694,t:1527265060060};\\\", \\\"{x:417,y:697,t:1527265060078};\\\", \\\"{x:421,y:697,t:1527265060094};\\\", \\\"{x:424,y:698,t:1527265060111};\\\", \\\"{x:425,y:699,t:1527265060128};\\\", \\\"{x:429,y:701,t:1527265060143};\\\", \\\"{x:433,y:703,t:1527265060161};\\\", \\\"{x:441,y:708,t:1527265060178};\\\", \\\"{x:449,y:714,t:1527265060195};\\\", \\\"{x:456,y:719,t:1527265060211};\\\", \\\"{x:463,y:726,t:1527265060229};\\\", \\\"{x:468,y:731,t:1527265060244};\\\", \\\"{x:471,y:736,t:1527265060260};\\\", \\\"{x:471,y:737,t:1527265060277};\\\", \\\"{x:471,y:738,t:1527265061071};\\\", \\\"{x:470,y:738,t:1527265061080};\\\", \\\"{x:469,y:738,t:1527265061095};\\\", \\\"{x:468,y:738,t:1527265061111};\\\", \\\"{x:467,y:738,t:1527265061128};\\\", \\\"{x:466,y:738,t:1527265061280};\\\" ] }, { \\\"rt\\\": 7642, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 654404, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:468,y:738,t:1527265062585};\\\", \\\"{x:496,y:752,t:1527265062609};\\\", \\\"{x:510,y:764,t:1527265062615};\\\", \\\"{x:527,y:775,t:1527265062630};\\\", \\\"{x:567,y:797,t:1527265062646};\\\", \\\"{x:602,y:811,t:1527265062662};\\\", \\\"{x:638,y:819,t:1527265062679};\\\", \\\"{x:685,y:826,t:1527265062695};\\\", \\\"{x:704,y:830,t:1527265062713};\\\", \\\"{x:718,y:833,t:1527265062729};\\\", \\\"{x:724,y:835,t:1527265062746};\\\", \\\"{x:727,y:836,t:1527265062763};\\\", \\\"{x:728,y:838,t:1527265062779};\\\", \\\"{x:728,y:842,t:1527265062796};\\\", \\\"{x:724,y:843,t:1527265062813};\\\", \\\"{x:723,y:843,t:1527265062828};\\\", \\\"{x:721,y:842,t:1527265063105};\\\", \\\"{x:722,y:839,t:1527265063113};\\\", \\\"{x:723,y:836,t:1527265063130};\\\", \\\"{x:731,y:831,t:1527265063146};\\\", \\\"{x:750,y:819,t:1527265063163};\\\", \\\"{x:776,y:805,t:1527265063180};\\\", \\\"{x:850,y:790,t:1527265063196};\\\", \\\"{x:956,y:784,t:1527265063213};\\\", \\\"{x:1068,y:778,t:1527265063231};\\\", \\\"{x:1190,y:778,t:1527265063247};\\\", \\\"{x:1295,y:778,t:1527265063263};\\\", \\\"{x:1428,y:785,t:1527265063280};\\\", \\\"{x:1486,y:793,t:1527265063296};\\\", \\\"{x:1517,y:798,t:1527265063313};\\\", \\\"{x:1537,y:805,t:1527265063330};\\\", \\\"{x:1543,y:808,t:1527265063346};\\\", \\\"{x:1544,y:810,t:1527265063363};\\\", \\\"{x:1542,y:814,t:1527265063380};\\\", \\\"{x:1532,y:819,t:1527265063396};\\\", \\\"{x:1524,y:826,t:1527265063413};\\\", \\\"{x:1512,y:837,t:1527265063430};\\\", \\\"{x:1498,y:851,t:1527265063446};\\\", \\\"{x:1487,y:863,t:1527265063463};\\\", \\\"{x:1470,y:881,t:1527265063480};\\\", \\\"{x:1455,y:891,t:1527265063498};\\\", \\\"{x:1439,y:899,t:1527265063513};\\\", \\\"{x:1421,y:909,t:1527265063530};\\\", \\\"{x:1408,y:916,t:1527265063547};\\\", \\\"{x:1399,y:920,t:1527265063564};\\\", \\\"{x:1393,y:922,t:1527265063580};\\\", \\\"{x:1390,y:924,t:1527265063597};\\\", \\\"{x:1385,y:927,t:1527265063613};\\\", \\\"{x:1374,y:933,t:1527265063630};\\\", \\\"{x:1364,y:939,t:1527265063648};\\\", \\\"{x:1351,y:946,t:1527265063663};\\\", \\\"{x:1343,y:952,t:1527265063680};\\\", \\\"{x:1340,y:954,t:1527265063698};\\\", \\\"{x:1338,y:955,t:1527265063713};\\\", \\\"{x:1337,y:955,t:1527265063730};\\\", \\\"{x:1337,y:956,t:1527265063840};\\\", \\\"{x:1337,y:957,t:1527265063864};\\\", \\\"{x:1340,y:959,t:1527265063880};\\\", \\\"{x:1343,y:960,t:1527265063897};\\\", \\\"{x:1346,y:962,t:1527265063913};\\\", \\\"{x:1348,y:962,t:1527265063931};\\\", \\\"{x:1349,y:959,t:1527265064169};\\\", \\\"{x:1349,y:950,t:1527265064180};\\\", \\\"{x:1349,y:933,t:1527265064198};\\\", \\\"{x:1349,y:921,t:1527265064214};\\\", \\\"{x:1349,y:910,t:1527265064230};\\\", \\\"{x:1349,y:896,t:1527265064247};\\\", \\\"{x:1349,y:884,t:1527265064264};\\\", \\\"{x:1349,y:878,t:1527265064280};\\\", \\\"{x:1347,y:871,t:1527265064298};\\\", \\\"{x:1346,y:862,t:1527265064315};\\\", \\\"{x:1346,y:852,t:1527265064331};\\\", \\\"{x:1345,y:845,t:1527265064348};\\\", \\\"{x:1343,y:838,t:1527265064365};\\\", \\\"{x:1342,y:833,t:1527265064381};\\\", \\\"{x:1342,y:826,t:1527265064397};\\\", \\\"{x:1342,y:818,t:1527265064415};\\\", \\\"{x:1342,y:809,t:1527265064430};\\\", \\\"{x:1342,y:804,t:1527265064447};\\\", \\\"{x:1343,y:796,t:1527265064464};\\\", \\\"{x:1343,y:791,t:1527265064481};\\\", \\\"{x:1343,y:788,t:1527265064498};\\\", \\\"{x:1343,y:786,t:1527265064515};\\\", \\\"{x:1343,y:784,t:1527265064530};\\\", \\\"{x:1343,y:783,t:1527265064548};\\\", \\\"{x:1343,y:781,t:1527265064564};\\\", \\\"{x:1343,y:780,t:1527265064581};\\\", \\\"{x:1343,y:779,t:1527265064597};\\\", \\\"{x:1343,y:778,t:1527265064713};\\\", \\\"{x:1343,y:777,t:1527265064728};\\\", \\\"{x:1343,y:776,t:1527265064744};\\\", \\\"{x:1343,y:774,t:1527265065017};\\\", \\\"{x:1343,y:772,t:1527265065032};\\\", \\\"{x:1343,y:769,t:1527265065047};\\\", \\\"{x:1343,y:767,t:1527265065065};\\\", \\\"{x:1343,y:766,t:1527265065084};\\\", \\\"{x:1343,y:765,t:1527265065376};\\\", \\\"{x:1343,y:761,t:1527265065384};\\\", \\\"{x:1343,y:758,t:1527265065400};\\\", \\\"{x:1343,y:754,t:1527265065414};\\\", \\\"{x:1343,y:751,t:1527265065431};\\\", \\\"{x:1343,y:745,t:1527265065448};\\\", \\\"{x:1343,y:743,t:1527265065465};\\\", \\\"{x:1343,y:741,t:1527265065482};\\\", \\\"{x:1343,y:738,t:1527265065499};\\\", \\\"{x:1343,y:736,t:1527265065514};\\\", \\\"{x:1343,y:731,t:1527265065532};\\\", \\\"{x:1344,y:728,t:1527265065548};\\\", \\\"{x:1345,y:725,t:1527265065565};\\\", \\\"{x:1345,y:724,t:1527265065582};\\\", \\\"{x:1345,y:721,t:1527265065599};\\\", \\\"{x:1345,y:720,t:1527265065614};\\\", \\\"{x:1345,y:718,t:1527265065631};\\\", \\\"{x:1345,y:717,t:1527265065648};\\\", \\\"{x:1345,y:714,t:1527265065666};\\\", \\\"{x:1345,y:711,t:1527265065681};\\\", \\\"{x:1345,y:710,t:1527265065705};\\\", \\\"{x:1345,y:709,t:1527265065744};\\\", \\\"{x:1346,y:709,t:1527265065905};\\\", \\\"{x:1346,y:708,t:1527265066193};\\\", \\\"{x:1338,y:706,t:1527265066200};\\\", \\\"{x:1324,y:702,t:1527265066215};\\\", \\\"{x:1248,y:678,t:1527265066231};\\\", \\\"{x:1189,y:661,t:1527265066248};\\\", \\\"{x:1109,y:637,t:1527265066265};\\\", \\\"{x:1012,y:611,t:1527265066282};\\\", \\\"{x:926,y:588,t:1527265066299};\\\", \\\"{x:840,y:563,t:1527265066315};\\\", \\\"{x:757,y:540,t:1527265066333};\\\", \\\"{x:690,y:519,t:1527265066349};\\\", \\\"{x:629,y:502,t:1527265066367};\\\", \\\"{x:584,y:489,t:1527265066382};\\\", \\\"{x:555,y:484,t:1527265066399};\\\", \\\"{x:521,y:478,t:1527265066415};\\\", \\\"{x:504,y:476,t:1527265066432};\\\", \\\"{x:484,y:475,t:1527265066449};\\\", \\\"{x:461,y:473,t:1527265066466};\\\", \\\"{x:432,y:471,t:1527265066481};\\\", \\\"{x:408,y:471,t:1527265066499};\\\", \\\"{x:389,y:471,t:1527265066516};\\\", \\\"{x:372,y:474,t:1527265066531};\\\", \\\"{x:362,y:481,t:1527265066549};\\\", \\\"{x:357,y:487,t:1527265066566};\\\", \\\"{x:355,y:490,t:1527265066583};\\\", \\\"{x:355,y:491,t:1527265066599};\\\", \\\"{x:355,y:493,t:1527265066616};\\\", \\\"{x:354,y:500,t:1527265066633};\\\", \\\"{x:354,y:513,t:1527265066649};\\\", \\\"{x:354,y:527,t:1527265066666};\\\", \\\"{x:354,y:537,t:1527265066682};\\\", \\\"{x:354,y:543,t:1527265066699};\\\", \\\"{x:355,y:546,t:1527265066715};\\\", \\\"{x:356,y:547,t:1527265066855};\\\", \\\"{x:358,y:547,t:1527265066865};\\\", \\\"{x:367,y:545,t:1527265066883};\\\", \\\"{x:382,y:540,t:1527265066899};\\\", \\\"{x:409,y:535,t:1527265066916};\\\", \\\"{x:456,y:530,t:1527265066933};\\\", \\\"{x:498,y:528,t:1527265066949};\\\", \\\"{x:540,y:522,t:1527265066966};\\\", \\\"{x:580,y:521,t:1527265066983};\\\", \\\"{x:633,y:521,t:1527265066999};\\\", \\\"{x:710,y:523,t:1527265067016};\\\", \\\"{x:747,y:526,t:1527265067033};\\\", \\\"{x:767,y:526,t:1527265067049};\\\", \\\"{x:777,y:526,t:1527265067066};\\\", \\\"{x:782,y:526,t:1527265067083};\\\", \\\"{x:783,y:526,t:1527265067144};\\\", \\\"{x:781,y:525,t:1527265067152};\\\", \\\"{x:779,y:524,t:1527265067166};\\\", \\\"{x:768,y:523,t:1527265067183};\\\", \\\"{x:741,y:522,t:1527265067200};\\\", \\\"{x:712,y:522,t:1527265067216};\\\", \\\"{x:667,y:522,t:1527265067233};\\\", \\\"{x:595,y:522,t:1527265067250};\\\", \\\"{x:501,y:522,t:1527265067266};\\\", \\\"{x:392,y:522,t:1527265067283};\\\", \\\"{x:293,y:522,t:1527265067300};\\\", \\\"{x:185,y:522,t:1527265067315};\\\", \\\"{x:101,y:522,t:1527265067333};\\\", \\\"{x:54,y:522,t:1527265067350};\\\", \\\"{x:33,y:524,t:1527265067366};\\\", \\\"{x:29,y:526,t:1527265067383};\\\", \\\"{x:29,y:527,t:1527265067465};\\\", \\\"{x:29,y:530,t:1527265067472};\\\", \\\"{x:31,y:532,t:1527265067483};\\\", \\\"{x:37,y:536,t:1527265067500};\\\", \\\"{x:43,y:539,t:1527265067517};\\\", \\\"{x:49,y:541,t:1527265067534};\\\", \\\"{x:61,y:542,t:1527265067551};\\\", \\\"{x:75,y:544,t:1527265067567};\\\", \\\"{x:92,y:544,t:1527265067583};\\\", \\\"{x:114,y:544,t:1527265067600};\\\", \\\"{x:130,y:544,t:1527265067617};\\\", \\\"{x:140,y:542,t:1527265067633};\\\", \\\"{x:148,y:540,t:1527265067651};\\\", \\\"{x:150,y:540,t:1527265067668};\\\", \\\"{x:152,y:539,t:1527265067682};\\\", \\\"{x:154,y:538,t:1527265067783};\\\", \\\"{x:154,y:538,t:1527265067890};\\\", \\\"{x:157,y:538,t:1527265067959};\\\", \\\"{x:162,y:538,t:1527265067967};\\\", \\\"{x:169,y:538,t:1527265067982};\\\", \\\"{x:208,y:538,t:1527265068000};\\\", \\\"{x:251,y:538,t:1527265068017};\\\", \\\"{x:314,y:535,t:1527265068034};\\\", \\\"{x:394,y:526,t:1527265068050};\\\", \\\"{x:465,y:520,t:1527265068067};\\\", \\\"{x:542,y:511,t:1527265068085};\\\", \\\"{x:597,y:507,t:1527265068099};\\\", \\\"{x:638,y:504,t:1527265068117};\\\", \\\"{x:666,y:504,t:1527265068134};\\\", \\\"{x:689,y:501,t:1527265068150};\\\", \\\"{x:706,y:500,t:1527265068167};\\\", \\\"{x:722,y:500,t:1527265068184};\\\", \\\"{x:726,y:500,t:1527265068201};\\\", \\\"{x:730,y:499,t:1527265068217};\\\", \\\"{x:734,y:499,t:1527265068234};\\\", \\\"{x:744,y:499,t:1527265068250};\\\", \\\"{x:759,y:499,t:1527265068267};\\\", \\\"{x:774,y:499,t:1527265068284};\\\", \\\"{x:793,y:499,t:1527265068300};\\\", \\\"{x:815,y:499,t:1527265068318};\\\", \\\"{x:835,y:499,t:1527265068335};\\\", \\\"{x:848,y:499,t:1527265068350};\\\", \\\"{x:854,y:499,t:1527265068366};\\\", \\\"{x:858,y:499,t:1527265068384};\\\", \\\"{x:852,y:504,t:1527265068735};\\\", \\\"{x:842,y:510,t:1527265068751};\\\", \\\"{x:806,y:537,t:1527265068767};\\\", \\\"{x:763,y:562,t:1527265068785};\\\", \\\"{x:724,y:587,t:1527265068801};\\\", \\\"{x:678,y:613,t:1527265068818};\\\", \\\"{x:652,y:629,t:1527265068834};\\\", \\\"{x:630,y:640,t:1527265068851};\\\", \\\"{x:620,y:644,t:1527265068868};\\\", \\\"{x:615,y:647,t:1527265068884};\\\", \\\"{x:612,y:650,t:1527265068901};\\\", \\\"{x:610,y:651,t:1527265068918};\\\", \\\"{x:608,y:653,t:1527265068934};\\\", \\\"{x:607,y:655,t:1527265068951};\\\", \\\"{x:602,y:660,t:1527265068968};\\\", \\\"{x:596,y:670,t:1527265068984};\\\", \\\"{x:584,y:681,t:1527265069001};\\\", \\\"{x:571,y:694,t:1527265069018};\\\", \\\"{x:554,y:709,t:1527265069035};\\\", \\\"{x:533,y:723,t:1527265069052};\\\", \\\"{x:517,y:735,t:1527265069068};\\\", \\\"{x:502,y:745,t:1527265069085};\\\", \\\"{x:494,y:750,t:1527265069101};\\\", \\\"{x:494,y:749,t:1527265069320};\\\", \\\"{x:495,y:749,t:1527265069336};\\\", \\\"{x:496,y:748,t:1527265069351};\\\", \\\"{x:497,y:748,t:1527265069368};\\\", \\\"{x:497,y:748,t:1527265069452};\\\" ] }, { \\\"rt\\\": 54209, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 709861, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -B -B -F -F -F -G -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:745,t:1527265076940};\\\", \\\"{x:504,y:736,t:1527265076948};\\\", \\\"{x:509,y:727,t:1527265076960};\\\", \\\"{x:514,y:715,t:1527265076979};\\\", \\\"{x:520,y:701,t:1527265076994};\\\", \\\"{x:530,y:682,t:1527265077010};\\\", \\\"{x:543,y:653,t:1527265077028};\\\", \\\"{x:560,y:628,t:1527265077044};\\\", \\\"{x:580,y:593,t:1527265077061};\\\", \\\"{x:593,y:570,t:1527265077078};\\\", \\\"{x:604,y:555,t:1527265077095};\\\", \\\"{x:612,y:542,t:1527265077111};\\\", \\\"{x:617,y:532,t:1527265077128};\\\", \\\"{x:619,y:528,t:1527265077144};\\\", \\\"{x:619,y:526,t:1527265077161};\\\", \\\"{x:617,y:526,t:1527265077340};\\\", \\\"{x:613,y:526,t:1527265077347};\\\", \\\"{x:607,y:529,t:1527265077363};\\\", \\\"{x:592,y:534,t:1527265077378};\\\", \\\"{x:567,y:541,t:1527265077394};\\\", \\\"{x:551,y:547,t:1527265077410};\\\", \\\"{x:530,y:550,t:1527265077428};\\\", \\\"{x:512,y:550,t:1527265077445};\\\", \\\"{x:494,y:550,t:1527265077462};\\\", \\\"{x:482,y:550,t:1527265077478};\\\", \\\"{x:468,y:549,t:1527265077494};\\\", \\\"{x:458,y:548,t:1527265077511};\\\", \\\"{x:451,y:547,t:1527265077528};\\\", \\\"{x:450,y:547,t:1527265077544};\\\", \\\"{x:449,y:547,t:1527265077561};\\\", \\\"{x:448,y:547,t:1527265077676};\\\", \\\"{x:447,y:547,t:1527265077700};\\\", \\\"{x:446,y:547,t:1527265077715};\\\", \\\"{x:445,y:547,t:1527265077727};\\\", \\\"{x:442,y:547,t:1527265077747};\\\", \\\"{x:440,y:549,t:1527265077761};\\\", \\\"{x:432,y:550,t:1527265077777};\\\", \\\"{x:414,y:554,t:1527265077794};\\\", \\\"{x:384,y:559,t:1527265077812};\\\", \\\"{x:366,y:565,t:1527265077827};\\\", \\\"{x:356,y:565,t:1527265077845};\\\", \\\"{x:350,y:565,t:1527265077862};\\\", \\\"{x:341,y:568,t:1527265077878};\\\", \\\"{x:333,y:568,t:1527265077895};\\\", \\\"{x:320,y:564,t:1527265077912};\\\", \\\"{x:308,y:561,t:1527265077928};\\\", \\\"{x:301,y:557,t:1527265077945};\\\", \\\"{x:293,y:552,t:1527265077962};\\\", \\\"{x:280,y:544,t:1527265077978};\\\", \\\"{x:266,y:537,t:1527265077996};\\\", \\\"{x:258,y:535,t:1527265078012};\\\", \\\"{x:255,y:535,t:1527265078027};\\\", \\\"{x:252,y:535,t:1527265078045};\\\", \\\"{x:249,y:535,t:1527265078062};\\\", \\\"{x:245,y:535,t:1527265078077};\\\", \\\"{x:240,y:535,t:1527265078095};\\\", \\\"{x:238,y:535,t:1527265078112};\\\", \\\"{x:237,y:535,t:1527265078131};\\\", \\\"{x:235,y:535,t:1527265078171};\\\", \\\"{x:231,y:538,t:1527265078892};\\\", \\\"{x:226,y:541,t:1527265078899};\\\", \\\"{x:219,y:546,t:1527265078912};\\\", \\\"{x:203,y:551,t:1527265078929};\\\", \\\"{x:157,y:551,t:1527265078946};\\\", \\\"{x:87,y:551,t:1527265078962};\\\", \\\"{x:27,y:551,t:1527265078979};\\\", \\\"{x:10,y:551,t:1527265078995};\\\", \\\"{x:3,y:551,t:1527265079013};\\\", \\\"{x:1,y:551,t:1527265079028};\\\", \\\"{x:0,y:551,t:1527265079045};\\\", \\\"{x:2,y:551,t:1527265079091};\\\", \\\"{x:6,y:551,t:1527265079099};\\\", \\\"{x:17,y:548,t:1527265079113};\\\", \\\"{x:44,y:537,t:1527265079129};\\\", \\\"{x:68,y:526,t:1527265079146};\\\", \\\"{x:94,y:516,t:1527265079164};\\\", \\\"{x:103,y:512,t:1527265079179};\\\", \\\"{x:107,y:511,t:1527265079195};\\\", \\\"{x:110,y:511,t:1527265079212};\\\", \\\"{x:116,y:511,t:1527265079229};\\\", \\\"{x:122,y:513,t:1527265079245};\\\", \\\"{x:128,y:515,t:1527265079262};\\\", \\\"{x:134,y:518,t:1527265079280};\\\", \\\"{x:138,y:520,t:1527265079295};\\\", \\\"{x:142,y:521,t:1527265079313};\\\", \\\"{x:143,y:522,t:1527265079329};\\\", \\\"{x:145,y:523,t:1527265079346};\\\", \\\"{x:146,y:525,t:1527265079364};\\\", \\\"{x:147,y:526,t:1527265079379};\\\", \\\"{x:148,y:529,t:1527265079396};\\\", \\\"{x:151,y:531,t:1527265079413};\\\", \\\"{x:151,y:533,t:1527265079430};\\\", \\\"{x:151,y:534,t:1527265079446};\\\", \\\"{x:153,y:537,t:1527265079803};\\\", \\\"{x:155,y:545,t:1527265079813};\\\", \\\"{x:156,y:559,t:1527265079830};\\\", \\\"{x:156,y:574,t:1527265079848};\\\", \\\"{x:156,y:586,t:1527265079863};\\\", \\\"{x:156,y:604,t:1527265079881};\\\", \\\"{x:156,y:619,t:1527265079897};\\\", \\\"{x:156,y:633,t:1527265079914};\\\", \\\"{x:156,y:645,t:1527265079931};\\\", \\\"{x:156,y:658,t:1527265079946};\\\", \\\"{x:156,y:662,t:1527265079963};\\\", \\\"{x:156,y:665,t:1527265079980};\\\", \\\"{x:156,y:666,t:1527265079997};\\\", \\\"{x:156,y:667,t:1527265080013};\\\", \\\"{x:156,y:668,t:1527265080051};\\\", \\\"{x:156,y:669,t:1527265080091};\\\", \\\"{x:156,y:670,t:1527265082821};\\\", \\\"{x:156,y:676,t:1527265082830};\\\", \\\"{x:156,y:689,t:1527265082847};\\\", \\\"{x:157,y:701,t:1527265082867};\\\", \\\"{x:160,y:714,t:1527265082882};\\\", \\\"{x:165,y:728,t:1527265082899};\\\", \\\"{x:168,y:735,t:1527265082916};\\\", \\\"{x:170,y:738,t:1527265082932};\\\", \\\"{x:172,y:742,t:1527265082949};\\\", \\\"{x:173,y:744,t:1527265082966};\\\", \\\"{x:174,y:746,t:1527265082986};\\\", \\\"{x:179,y:747,t:1527265089036};\\\", \\\"{x:189,y:748,t:1527265089043};\\\", \\\"{x:220,y:748,t:1527265089059};\\\", \\\"{x:284,y:748,t:1527265089076};\\\", \\\"{x:367,y:748,t:1527265089093};\\\", \\\"{x:462,y:748,t:1527265089110};\\\", \\\"{x:567,y:748,t:1527265089125};\\\", \\\"{x:684,y:743,t:1527265089142};\\\", \\\"{x:743,y:739,t:1527265089153};\\\", \\\"{x:890,y:725,t:1527265089171};\\\", \\\"{x:944,y:724,t:1527265089188};\\\", \\\"{x:975,y:724,t:1527265089205};\\\", \\\"{x:992,y:724,t:1527265089221};\\\", \\\"{x:1011,y:731,t:1527265089238};\\\", \\\"{x:1024,y:736,t:1527265089254};\\\", \\\"{x:1033,y:739,t:1527265089271};\\\", \\\"{x:1038,y:741,t:1527265089288};\\\", \\\"{x:1043,y:743,t:1527265089305};\\\", \\\"{x:1048,y:745,t:1527265089321};\\\", \\\"{x:1052,y:745,t:1527265089338};\\\", \\\"{x:1058,y:745,t:1527265089355};\\\", \\\"{x:1067,y:745,t:1527265089371};\\\", \\\"{x:1083,y:742,t:1527265089388};\\\", \\\"{x:1102,y:737,t:1527265089404};\\\", \\\"{x:1123,y:731,t:1527265089421};\\\", \\\"{x:1145,y:723,t:1527265089438};\\\", \\\"{x:1169,y:718,t:1527265089454};\\\", \\\"{x:1190,y:713,t:1527265089471};\\\", \\\"{x:1205,y:710,t:1527265089488};\\\", \\\"{x:1222,y:708,t:1527265089506};\\\", \\\"{x:1231,y:708,t:1527265089521};\\\", \\\"{x:1234,y:708,t:1527265089538};\\\", \\\"{x:1237,y:708,t:1527265089555};\\\", \\\"{x:1239,y:708,t:1527265089571};\\\", \\\"{x:1240,y:708,t:1527265089604};\\\", \\\"{x:1243,y:708,t:1527265089611};\\\", \\\"{x:1246,y:708,t:1527265089621};\\\", \\\"{x:1262,y:708,t:1527265089638};\\\", \\\"{x:1279,y:708,t:1527265089656};\\\", \\\"{x:1301,y:707,t:1527265089672};\\\", \\\"{x:1322,y:702,t:1527265089688};\\\", \\\"{x:1344,y:698,t:1527265089710};\\\", \\\"{x:1360,y:697,t:1527265089722};\\\", \\\"{x:1367,y:696,t:1527265089738};\\\", \\\"{x:1372,y:695,t:1527265089754};\\\", \\\"{x:1374,y:694,t:1527265089771};\\\", \\\"{x:1372,y:693,t:1527265089963};\\\", \\\"{x:1371,y:693,t:1527265089971};\\\", \\\"{x:1367,y:691,t:1527265089989};\\\", \\\"{x:1365,y:690,t:1527265090006};\\\", \\\"{x:1362,y:688,t:1527265090022};\\\", \\\"{x:1361,y:687,t:1527265090038};\\\", \\\"{x:1360,y:687,t:1527265090055};\\\", \\\"{x:1358,y:687,t:1527265090292};\\\", \\\"{x:1357,y:687,t:1527265090307};\\\", \\\"{x:1353,y:688,t:1527265090322};\\\", \\\"{x:1349,y:690,t:1527265090342};\\\", \\\"{x:1346,y:693,t:1527265090356};\\\", \\\"{x:1345,y:699,t:1527265090372};\\\", \\\"{x:1345,y:710,t:1527265090389};\\\", \\\"{x:1345,y:718,t:1527265090404};\\\", \\\"{x:1347,y:726,t:1527265090422};\\\", \\\"{x:1349,y:734,t:1527265090438};\\\", \\\"{x:1351,y:737,t:1527265090455};\\\", \\\"{x:1352,y:743,t:1527265090471};\\\", \\\"{x:1352,y:745,t:1527265090488};\\\", \\\"{x:1353,y:745,t:1527265090506};\\\", \\\"{x:1353,y:746,t:1527265090659};\\\", \\\"{x:1353,y:748,t:1527265090672};\\\", \\\"{x:1353,y:749,t:1527265090689};\\\", \\\"{x:1353,y:754,t:1527265090706};\\\", \\\"{x:1353,y:757,t:1527265090721};\\\", \\\"{x:1353,y:762,t:1527265090738};\\\", \\\"{x:1353,y:764,t:1527265090756};\\\", \\\"{x:1353,y:765,t:1527265090772};\\\", \\\"{x:1353,y:766,t:1527265090788};\\\", \\\"{x:1353,y:767,t:1527265090805};\\\", \\\"{x:1353,y:768,t:1527265091138};\\\", \\\"{x:1353,y:770,t:1527265091156};\\\", \\\"{x:1353,y:771,t:1527265091173};\\\", \\\"{x:1353,y:774,t:1527265091189};\\\", \\\"{x:1353,y:771,t:1527265091323};\\\", \\\"{x:1343,y:747,t:1527265091340};\\\", \\\"{x:1334,y:727,t:1527265091357};\\\", \\\"{x:1332,y:723,t:1527265091373};\\\", \\\"{x:1332,y:722,t:1527265091788};\\\", \\\"{x:1332,y:720,t:1527265091796};\\\", \\\"{x:1334,y:717,t:1527265091806};\\\", \\\"{x:1335,y:714,t:1527265091823};\\\", \\\"{x:1335,y:712,t:1527265091840};\\\", \\\"{x:1337,y:708,t:1527265091857};\\\", \\\"{x:1338,y:706,t:1527265091873};\\\", \\\"{x:1339,y:704,t:1527265091890};\\\", \\\"{x:1339,y:703,t:1527265091908};\\\", \\\"{x:1340,y:702,t:1527265091923};\\\", \\\"{x:1341,y:702,t:1527265091956};\\\", \\\"{x:1342,y:701,t:1527265091979};\\\", \\\"{x:1343,y:702,t:1527265103468};\\\", \\\"{x:1343,y:703,t:1527265103482};\\\", \\\"{x:1344,y:703,t:1527265103499};\\\", \\\"{x:1345,y:704,t:1527265103515};\\\", \\\"{x:1346,y:704,t:1527265103627};\\\", \\\"{x:1346,y:705,t:1527265104060};\\\", \\\"{x:1347,y:706,t:1527265104067};\\\", \\\"{x:1348,y:706,t:1527265104099};\\\", \\\"{x:1349,y:708,t:1527265104299};\\\", \\\"{x:1348,y:716,t:1527265104315};\\\", \\\"{x:1345,y:726,t:1527265104332};\\\", \\\"{x:1343,y:732,t:1527265104349};\\\", \\\"{x:1339,y:741,t:1527265104365};\\\", \\\"{x:1334,y:748,t:1527265104383};\\\", \\\"{x:1331,y:755,t:1527265104399};\\\", \\\"{x:1329,y:761,t:1527265104416};\\\", \\\"{x:1328,y:768,t:1527265104433};\\\", \\\"{x:1327,y:775,t:1527265104449};\\\", \\\"{x:1327,y:783,t:1527265104465};\\\", \\\"{x:1327,y:792,t:1527265104483};\\\", \\\"{x:1327,y:796,t:1527265104500};\\\", \\\"{x:1327,y:801,t:1527265104516};\\\", \\\"{x:1328,y:805,t:1527265104533};\\\", \\\"{x:1329,y:809,t:1527265104548};\\\", \\\"{x:1330,y:811,t:1527265104565};\\\", \\\"{x:1331,y:815,t:1527265104583};\\\", \\\"{x:1332,y:818,t:1527265104599};\\\", \\\"{x:1333,y:820,t:1527265104616};\\\", \\\"{x:1333,y:821,t:1527265104633};\\\", \\\"{x:1333,y:822,t:1527265104651};\\\", \\\"{x:1335,y:823,t:1527265104667};\\\", \\\"{x:1336,y:820,t:1527265104756};\\\", \\\"{x:1337,y:808,t:1527265104766};\\\", \\\"{x:1337,y:769,t:1527265104783};\\\", \\\"{x:1337,y:743,t:1527265104799};\\\", \\\"{x:1340,y:725,t:1527265104816};\\\", \\\"{x:1342,y:708,t:1527265104832};\\\", \\\"{x:1345,y:699,t:1527265104850};\\\", \\\"{x:1345,y:692,t:1527265104866};\\\", \\\"{x:1345,y:689,t:1527265104884};\\\", \\\"{x:1345,y:691,t:1527265105044};\\\", \\\"{x:1345,y:693,t:1527265105052};\\\", \\\"{x:1345,y:694,t:1527265105066};\\\", \\\"{x:1345,y:699,t:1527265105083};\\\", \\\"{x:1346,y:700,t:1527265105107};\\\", \\\"{x:1347,y:700,t:1527265105243};\\\", \\\"{x:1348,y:699,t:1527265105291};\\\", \\\"{x:1349,y:698,t:1527265105299};\\\", \\\"{x:1350,y:690,t:1527265105318};\\\", \\\"{x:1353,y:683,t:1527265105332};\\\", \\\"{x:1357,y:674,t:1527265105350};\\\", \\\"{x:1364,y:658,t:1527265105367};\\\", \\\"{x:1368,y:648,t:1527265105382};\\\", \\\"{x:1373,y:637,t:1527265105400};\\\", \\\"{x:1375,y:629,t:1527265105417};\\\", \\\"{x:1378,y:623,t:1527265105433};\\\", \\\"{x:1379,y:618,t:1527265105451};\\\", \\\"{x:1379,y:612,t:1527265105467};\\\", \\\"{x:1381,y:604,t:1527265105483};\\\", \\\"{x:1383,y:598,t:1527265105500};\\\", \\\"{x:1384,y:596,t:1527265105517};\\\", \\\"{x:1385,y:594,t:1527265105533};\\\", \\\"{x:1386,y:590,t:1527265105549};\\\", \\\"{x:1388,y:587,t:1527265105566};\\\", \\\"{x:1391,y:582,t:1527265105584};\\\", \\\"{x:1394,y:578,t:1527265105600};\\\", \\\"{x:1396,y:575,t:1527265105616};\\\", \\\"{x:1399,y:572,t:1527265105634};\\\", \\\"{x:1400,y:571,t:1527265105650};\\\", \\\"{x:1403,y:568,t:1527265105667};\\\", \\\"{x:1406,y:566,t:1527265105683};\\\", \\\"{x:1410,y:564,t:1527265105700};\\\", \\\"{x:1412,y:564,t:1527265105717};\\\", \\\"{x:1413,y:562,t:1527265105733};\\\", \\\"{x:1414,y:562,t:1527265105750};\\\", \\\"{x:1415,y:562,t:1527265105779};\\\", \\\"{x:1413,y:562,t:1527265111700};\\\", \\\"{x:1412,y:566,t:1527265111707};\\\", \\\"{x:1410,y:572,t:1527265111722};\\\", \\\"{x:1406,y:582,t:1527265111739};\\\", \\\"{x:1402,y:597,t:1527265111754};\\\", \\\"{x:1387,y:625,t:1527265111771};\\\", \\\"{x:1381,y:639,t:1527265111788};\\\", \\\"{x:1376,y:649,t:1527265111804};\\\", \\\"{x:1371,y:664,t:1527265111821};\\\", \\\"{x:1368,y:678,t:1527265111838};\\\", \\\"{x:1365,y:687,t:1527265111854};\\\", \\\"{x:1365,y:692,t:1527265111871};\\\", \\\"{x:1363,y:695,t:1527265111888};\\\", \\\"{x:1362,y:699,t:1527265111907};\\\", \\\"{x:1361,y:701,t:1527265111932};\\\", \\\"{x:1360,y:702,t:1527265111948};\\\", \\\"{x:1359,y:702,t:1527265111964};\\\", \\\"{x:1356,y:703,t:1527265111971};\\\", \\\"{x:1354,y:704,t:1527265111988};\\\", \\\"{x:1352,y:704,t:1527265112005};\\\", \\\"{x:1351,y:705,t:1527265112027};\\\", \\\"{x:1350,y:705,t:1527265112051};\\\", \\\"{x:1349,y:705,t:1527265112067};\\\", \\\"{x:1349,y:706,t:1527265112139};\\\", \\\"{x:1348,y:706,t:1527265112291};\\\", \\\"{x:1346,y:706,t:1527265112828};\\\", \\\"{x:1345,y:706,t:1527265112884};\\\", \\\"{x:1344,y:706,t:1527265112948};\\\", \\\"{x:1344,y:703,t:1527265113524};\\\", \\\"{x:1344,y:696,t:1527265113540};\\\", \\\"{x:1347,y:690,t:1527265113557};\\\", \\\"{x:1348,y:684,t:1527265113572};\\\", \\\"{x:1351,y:679,t:1527265113590};\\\", \\\"{x:1352,y:675,t:1527265113606};\\\", \\\"{x:1354,y:672,t:1527265113622};\\\", \\\"{x:1355,y:671,t:1527265113638};\\\", \\\"{x:1356,y:669,t:1527265113656};\\\", \\\"{x:1356,y:668,t:1527265113674};\\\", \\\"{x:1357,y:667,t:1527265113688};\\\", \\\"{x:1359,y:664,t:1527265113706};\\\", \\\"{x:1362,y:660,t:1527265113722};\\\", \\\"{x:1364,y:657,t:1527265113739};\\\", \\\"{x:1366,y:653,t:1527265113755};\\\", \\\"{x:1371,y:649,t:1527265113773};\\\", \\\"{x:1372,y:648,t:1527265113789};\\\", \\\"{x:1376,y:644,t:1527265113806};\\\", \\\"{x:1381,y:640,t:1527265113823};\\\", \\\"{x:1386,y:638,t:1527265113839};\\\", \\\"{x:1390,y:636,t:1527265113856};\\\", \\\"{x:1391,y:635,t:1527265113873};\\\", \\\"{x:1392,y:635,t:1527265113888};\\\", \\\"{x:1393,y:634,t:1527265114043};\\\", \\\"{x:1393,y:633,t:1527265114056};\\\", \\\"{x:1396,y:630,t:1527265114073};\\\", \\\"{x:1398,y:623,t:1527265114090};\\\", \\\"{x:1405,y:611,t:1527265114106};\\\", \\\"{x:1408,y:603,t:1527265114123};\\\", \\\"{x:1410,y:600,t:1527265114139};\\\", \\\"{x:1413,y:593,t:1527265114156};\\\", \\\"{x:1417,y:584,t:1527265114173};\\\", \\\"{x:1420,y:578,t:1527265114189};\\\", \\\"{x:1421,y:576,t:1527265114206};\\\", \\\"{x:1421,y:575,t:1527265114491};\\\", \\\"{x:1421,y:574,t:1527265114522};\\\", \\\"{x:1421,y:573,t:1527265114540};\\\", \\\"{x:1421,y:572,t:1527265114611};\\\", \\\"{x:1421,y:571,t:1527265116842};\\\", \\\"{x:1420,y:570,t:1527265116858};\\\", \\\"{x:1419,y:570,t:1527265116890};\\\", \\\"{x:1418,y:569,t:1527265116955};\\\", \\\"{x:1415,y:569,t:1527265118244};\\\", \\\"{x:1412,y:570,t:1527265118259};\\\", \\\"{x:1407,y:575,t:1527265118276};\\\", \\\"{x:1402,y:579,t:1527265118293};\\\", \\\"{x:1396,y:583,t:1527265118310};\\\", \\\"{x:1393,y:586,t:1527265118327};\\\", \\\"{x:1390,y:589,t:1527265118342};\\\", \\\"{x:1389,y:590,t:1527265118359};\\\", \\\"{x:1387,y:592,t:1527265118376};\\\", \\\"{x:1387,y:593,t:1527265118392};\\\", \\\"{x:1387,y:596,t:1527265118410};\\\", \\\"{x:1386,y:599,t:1527265118427};\\\", \\\"{x:1384,y:604,t:1527265118442};\\\", \\\"{x:1384,y:610,t:1527265118459};\\\", \\\"{x:1384,y:612,t:1527265118476};\\\", \\\"{x:1384,y:617,t:1527265118492};\\\", \\\"{x:1384,y:618,t:1527265118509};\\\", \\\"{x:1384,y:620,t:1527265118527};\\\", \\\"{x:1384,y:621,t:1527265118544};\\\", \\\"{x:1385,y:624,t:1527265118560};\\\", \\\"{x:1386,y:628,t:1527265118577};\\\", \\\"{x:1386,y:632,t:1527265118594};\\\", \\\"{x:1386,y:634,t:1527265118610};\\\", \\\"{x:1386,y:637,t:1527265118626};\\\", \\\"{x:1385,y:638,t:1527265119596};\\\", \\\"{x:1384,y:638,t:1527265119635};\\\", \\\"{x:1383,y:638,t:1527265119659};\\\", \\\"{x:1382,y:638,t:1527265119683};\\\", \\\"{x:1380,y:638,t:1527265121508};\\\", \\\"{x:1379,y:638,t:1527265121515};\\\", \\\"{x:1378,y:638,t:1527265121528};\\\", \\\"{x:1377,y:638,t:1527265121547};\\\", \\\"{x:1376,y:638,t:1527265121562};\\\", \\\"{x:1375,y:638,t:1527265121578};\\\", \\\"{x:1374,y:637,t:1527265121708};\\\", \\\"{x:1373,y:637,t:1527265121731};\\\", \\\"{x:1372,y:637,t:1527265121747};\\\", \\\"{x:1372,y:636,t:1527265121772};\\\", \\\"{x:1363,y:636,t:1527265124188};\\\", \\\"{x:1345,y:636,t:1527265124197};\\\", \\\"{x:1289,y:636,t:1527265124214};\\\", \\\"{x:1214,y:636,t:1527265124231};\\\", \\\"{x:1115,y:645,t:1527265124247};\\\", \\\"{x:1001,y:663,t:1527265124264};\\\", \\\"{x:876,y:682,t:1527265124281};\\\", \\\"{x:769,y:704,t:1527265124297};\\\", \\\"{x:664,y:733,t:1527265124313};\\\", \\\"{x:535,y:753,t:1527265124332};\\\", \\\"{x:487,y:761,t:1527265124346};\\\", \\\"{x:462,y:764,t:1527265124363};\\\", \\\"{x:455,y:765,t:1527265124376};\\\", \\\"{x:448,y:766,t:1527265124392};\\\", \\\"{x:448,y:765,t:1527265124627};\\\", \\\"{x:458,y:760,t:1527265124643};\\\", \\\"{x:465,y:756,t:1527265124659};\\\", \\\"{x:471,y:753,t:1527265124677};\\\", \\\"{x:473,y:751,t:1527265124693};\\\", \\\"{x:475,y:750,t:1527265124716};\\\", \\\"{x:475,y:749,t:1527265124755};\\\", \\\"{x:477,y:749,t:1527265124764};\\\", \\\"{x:479,y:748,t:1527265124783};\\\", \\\"{x:482,y:747,t:1527265124800};\\\", \\\"{x:484,y:746,t:1527265124816};\\\", \\\"{x:485,y:746,t:1527265124834};\\\", \\\"{x:485,y:746,t:1527265124909};\\\" ] }, { \\\"rt\\\": 24189, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 735264, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -Z -Z -B -B -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:491,y:746,t:1527265126803};\\\", \\\"{x:510,y:745,t:1527265126820};\\\", \\\"{x:533,y:743,t:1527265126837};\\\", \\\"{x:561,y:741,t:1527265126853};\\\", \\\"{x:587,y:741,t:1527265126871};\\\", \\\"{x:615,y:741,t:1527265126888};\\\", \\\"{x:642,y:741,t:1527265126901};\\\", \\\"{x:668,y:741,t:1527265126918};\\\", \\\"{x:688,y:742,t:1527265126935};\\\", \\\"{x:708,y:745,t:1527265126952};\\\", \\\"{x:723,y:747,t:1527265126968};\\\", \\\"{x:734,y:750,t:1527265126984};\\\", \\\"{x:741,y:753,t:1527265127002};\\\", \\\"{x:748,y:758,t:1527265127019};\\\", \\\"{x:753,y:759,t:1527265127035};\\\", \\\"{x:749,y:759,t:1527265127090};\\\", \\\"{x:738,y:759,t:1527265127101};\\\", \\\"{x:710,y:753,t:1527265127118};\\\", \\\"{x:703,y:753,t:1527265127135};\\\", \\\"{x:703,y:751,t:1527265127379};\\\", \\\"{x:703,y:750,t:1527265127387};\\\", \\\"{x:704,y:750,t:1527265127403};\\\", \\\"{x:708,y:749,t:1527265127419};\\\", \\\"{x:710,y:748,t:1527265127435};\\\", \\\"{x:713,y:748,t:1527265127452};\\\", \\\"{x:717,y:746,t:1527265127468};\\\", \\\"{x:722,y:745,t:1527265127485};\\\", \\\"{x:728,y:742,t:1527265127503};\\\", \\\"{x:739,y:740,t:1527265127519};\\\", \\\"{x:749,y:738,t:1527265127535};\\\", \\\"{x:758,y:737,t:1527265127552};\\\", \\\"{x:769,y:735,t:1527265127568};\\\", \\\"{x:779,y:735,t:1527265127586};\\\", \\\"{x:790,y:735,t:1527265127603};\\\", \\\"{x:793,y:735,t:1527265127618};\\\", \\\"{x:796,y:734,t:1527265127635};\\\", \\\"{x:799,y:734,t:1527265128604};\\\", \\\"{x:806,y:734,t:1527265128619};\\\", \\\"{x:813,y:734,t:1527265128636};\\\", \\\"{x:822,y:731,t:1527265128653};\\\", \\\"{x:834,y:727,t:1527265128669};\\\", \\\"{x:850,y:723,t:1527265128687};\\\", \\\"{x:871,y:717,t:1527265128703};\\\", \\\"{x:896,y:709,t:1527265128719};\\\", \\\"{x:929,y:699,t:1527265128736};\\\", \\\"{x:967,y:691,t:1527265128753};\\\", \\\"{x:1000,y:684,t:1527265128770};\\\", \\\"{x:1064,y:673,t:1527265128786};\\\", \\\"{x:1109,y:659,t:1527265128804};\\\", \\\"{x:1174,y:646,t:1527265128820};\\\", \\\"{x:1233,y:637,t:1527265128836};\\\", \\\"{x:1290,y:632,t:1527265128854};\\\", \\\"{x:1336,y:625,t:1527265128870};\\\", \\\"{x:1378,y:618,t:1527265128887};\\\", \\\"{x:1407,y:616,t:1527265128903};\\\", \\\"{x:1434,y:612,t:1527265128919};\\\", \\\"{x:1455,y:612,t:1527265128937};\\\", \\\"{x:1474,y:612,t:1527265128954};\\\", \\\"{x:1490,y:611,t:1527265128970};\\\", \\\"{x:1493,y:610,t:1527265128986};\\\", \\\"{x:1494,y:610,t:1527265129004};\\\", \\\"{x:1492,y:610,t:1527265129267};\\\", \\\"{x:1485,y:612,t:1527265129275};\\\", \\\"{x:1479,y:614,t:1527265129287};\\\", \\\"{x:1469,y:618,t:1527265129304};\\\", \\\"{x:1461,y:622,t:1527265129322};\\\", \\\"{x:1453,y:625,t:1527265129337};\\\", \\\"{x:1447,y:627,t:1527265129356};\\\", \\\"{x:1436,y:632,t:1527265129373};\\\", \\\"{x:1430,y:634,t:1527265129387};\\\", \\\"{x:1423,y:636,t:1527265129404};\\\", \\\"{x:1417,y:640,t:1527265129422};\\\", \\\"{x:1413,y:641,t:1527265129438};\\\", \\\"{x:1411,y:643,t:1527265129454};\\\", \\\"{x:1410,y:643,t:1527265129475};\\\", \\\"{x:1409,y:644,t:1527265129488};\\\", \\\"{x:1409,y:645,t:1527265129504};\\\", \\\"{x:1409,y:646,t:1527265129521};\\\", \\\"{x:1411,y:648,t:1527265129538};\\\", \\\"{x:1412,y:648,t:1527265129554};\\\", \\\"{x:1414,y:647,t:1527265129571};\\\", \\\"{x:1412,y:647,t:1527265130067};\\\", \\\"{x:1410,y:647,t:1527265130075};\\\", \\\"{x:1407,y:648,t:1527265130088};\\\", \\\"{x:1400,y:651,t:1527265130105};\\\", \\\"{x:1391,y:655,t:1527265130122};\\\", \\\"{x:1379,y:660,t:1527265130138};\\\", \\\"{x:1366,y:664,t:1527265130156};\\\", \\\"{x:1358,y:665,t:1527265130171};\\\", \\\"{x:1353,y:668,t:1527265130188};\\\", \\\"{x:1347,y:669,t:1527265130205};\\\", \\\"{x:1343,y:669,t:1527265130223};\\\", \\\"{x:1340,y:669,t:1527265130238};\\\", \\\"{x:1338,y:669,t:1527265130255};\\\", \\\"{x:1336,y:669,t:1527265130272};\\\", \\\"{x:1340,y:669,t:1527265130371};\\\", \\\"{x:1349,y:668,t:1527265130388};\\\", \\\"{x:1359,y:663,t:1527265130405};\\\", \\\"{x:1368,y:661,t:1527265130422};\\\", \\\"{x:1384,y:656,t:1527265130438};\\\", \\\"{x:1393,y:655,t:1527265130455};\\\", \\\"{x:1400,y:652,t:1527265130472};\\\", \\\"{x:1408,y:650,t:1527265130488};\\\", \\\"{x:1414,y:648,t:1527265130505};\\\", \\\"{x:1415,y:648,t:1527265130522};\\\", \\\"{x:1417,y:647,t:1527265130539};\\\", \\\"{x:1419,y:647,t:1527265130555};\\\", \\\"{x:1420,y:647,t:1527265130596};\\\", \\\"{x:1423,y:646,t:1527265130605};\\\", \\\"{x:1424,y:645,t:1527265130622};\\\", \\\"{x:1426,y:644,t:1527265130638};\\\", \\\"{x:1430,y:641,t:1527265130655};\\\", \\\"{x:1435,y:638,t:1527265130673};\\\", \\\"{x:1440,y:635,t:1527265130689};\\\", \\\"{x:1444,y:633,t:1527265130706};\\\", \\\"{x:1446,y:631,t:1527265130722};\\\", \\\"{x:1450,y:628,t:1527265130739};\\\", \\\"{x:1454,y:625,t:1527265130756};\\\", \\\"{x:1457,y:622,t:1527265130772};\\\", \\\"{x:1467,y:618,t:1527265130789};\\\", \\\"{x:1478,y:610,t:1527265130805};\\\", \\\"{x:1487,y:604,t:1527265130822};\\\", \\\"{x:1495,y:600,t:1527265130839};\\\", \\\"{x:1503,y:598,t:1527265130855};\\\", \\\"{x:1511,y:594,t:1527265130872};\\\", \\\"{x:1520,y:592,t:1527265130889};\\\", \\\"{x:1524,y:590,t:1527265130905};\\\", \\\"{x:1528,y:589,t:1527265130922};\\\", \\\"{x:1531,y:587,t:1527265130939};\\\", \\\"{x:1533,y:587,t:1527265130955};\\\", \\\"{x:1534,y:587,t:1527265130972};\\\", \\\"{x:1536,y:587,t:1527265130990};\\\", \\\"{x:1537,y:587,t:1527265131011};\\\", \\\"{x:1541,y:587,t:1527265131099};\\\", \\\"{x:1541,y:589,t:1527265131106};\\\", \\\"{x:1546,y:593,t:1527265131121};\\\", \\\"{x:1557,y:611,t:1527265131138};\\\", \\\"{x:1566,y:623,t:1527265131156};\\\", \\\"{x:1576,y:635,t:1527265131171};\\\", \\\"{x:1583,y:644,t:1527265131188};\\\", \\\"{x:1591,y:652,t:1527265131205};\\\", \\\"{x:1596,y:658,t:1527265131221};\\\", \\\"{x:1603,y:666,t:1527265131238};\\\", \\\"{x:1608,y:670,t:1527265131256};\\\", \\\"{x:1612,y:673,t:1527265131272};\\\", \\\"{x:1612,y:674,t:1527265131289};\\\", \\\"{x:1614,y:677,t:1527265131322};\\\", \\\"{x:1615,y:679,t:1527265131339};\\\", \\\"{x:1620,y:687,t:1527265131356};\\\", \\\"{x:1623,y:693,t:1527265131371};\\\", \\\"{x:1625,y:697,t:1527265131389};\\\", \\\"{x:1626,y:700,t:1527265131406};\\\", \\\"{x:1626,y:701,t:1527265131423};\\\", \\\"{x:1626,y:702,t:1527265131438};\\\", \\\"{x:1626,y:703,t:1527265131500};\\\", \\\"{x:1626,y:705,t:1527265131507};\\\", \\\"{x:1625,y:706,t:1527265131523};\\\", \\\"{x:1624,y:706,t:1527265131571};\\\", \\\"{x:1623,y:706,t:1527265131644};\\\", \\\"{x:1622,y:706,t:1527265131655};\\\", \\\"{x:1620,y:706,t:1527265131673};\\\", \\\"{x:1619,y:706,t:1527265131689};\\\", \\\"{x:1617,y:705,t:1527265131860};\\\", \\\"{x:1617,y:704,t:1527265132508};\\\", \\\"{x:1616,y:703,t:1527265132523};\\\", \\\"{x:1615,y:703,t:1527265132540};\\\", \\\"{x:1614,y:703,t:1527265139438};\\\", \\\"{x:1614,y:702,t:1527265144031};\\\", \\\"{x:1605,y:698,t:1527265144053};\\\", \\\"{x:1591,y:695,t:1527265144069};\\\", \\\"{x:1579,y:693,t:1527265144086};\\\", \\\"{x:1568,y:691,t:1527265144102};\\\", \\\"{x:1567,y:691,t:1527265144119};\\\", \\\"{x:1565,y:691,t:1527265144478};\\\", \\\"{x:1562,y:691,t:1527265144486};\\\", \\\"{x:1552,y:693,t:1527265144504};\\\", \\\"{x:1527,y:703,t:1527265144519};\\\", \\\"{x:1496,y:713,t:1527265144536};\\\", \\\"{x:1470,y:721,t:1527265144553};\\\", \\\"{x:1445,y:730,t:1527265144569};\\\", \\\"{x:1424,y:733,t:1527265144586};\\\", \\\"{x:1404,y:737,t:1527265144604};\\\", \\\"{x:1385,y:737,t:1527265144621};\\\", \\\"{x:1366,y:737,t:1527265144636};\\\", \\\"{x:1340,y:735,t:1527265144654};\\\", \\\"{x:1331,y:731,t:1527265144669};\\\", \\\"{x:1324,y:728,t:1527265144687};\\\", \\\"{x:1321,y:726,t:1527265144704};\\\", \\\"{x:1320,y:725,t:1527265144720};\\\", \\\"{x:1319,y:721,t:1527265144736};\\\", \\\"{x:1319,y:717,t:1527265144754};\\\", \\\"{x:1319,y:713,t:1527265144770};\\\", \\\"{x:1319,y:708,t:1527265144786};\\\", \\\"{x:1322,y:702,t:1527265144804};\\\", \\\"{x:1326,y:699,t:1527265144821};\\\", \\\"{x:1329,y:697,t:1527265144837};\\\", \\\"{x:1332,y:696,t:1527265144854};\\\", \\\"{x:1333,y:696,t:1527265144870};\\\", \\\"{x:1334,y:695,t:1527265144894};\\\", \\\"{x:1334,y:694,t:1527265144942};\\\", \\\"{x:1335,y:694,t:1527265144953};\\\", \\\"{x:1338,y:694,t:1527265144970};\\\", \\\"{x:1340,y:695,t:1527265144987};\\\", \\\"{x:1341,y:697,t:1527265145003};\\\", \\\"{x:1342,y:703,t:1527265145020};\\\", \\\"{x:1343,y:711,t:1527265145037};\\\", \\\"{x:1344,y:715,t:1527265145054};\\\", \\\"{x:1345,y:721,t:1527265145070};\\\", \\\"{x:1347,y:724,t:1527265145088};\\\", \\\"{x:1348,y:728,t:1527265145103};\\\", \\\"{x:1348,y:730,t:1527265145120};\\\", \\\"{x:1350,y:733,t:1527265145137};\\\", \\\"{x:1350,y:736,t:1527265145153};\\\", \\\"{x:1350,y:739,t:1527265145170};\\\", \\\"{x:1350,y:744,t:1527265145187};\\\", \\\"{x:1350,y:747,t:1527265145203};\\\", \\\"{x:1350,y:752,t:1527265145220};\\\", \\\"{x:1350,y:759,t:1527265145238};\\\", \\\"{x:1349,y:762,t:1527265145253};\\\", \\\"{x:1349,y:764,t:1527265145270};\\\", \\\"{x:1349,y:769,t:1527265145289};\\\", \\\"{x:1347,y:772,t:1527265145304};\\\", \\\"{x:1346,y:776,t:1527265145320};\\\", \\\"{x:1345,y:778,t:1527265145337};\\\", \\\"{x:1344,y:780,t:1527265145354};\\\", \\\"{x:1343,y:782,t:1527265145371};\\\", \\\"{x:1340,y:788,t:1527265145387};\\\", \\\"{x:1338,y:793,t:1527265145403};\\\", \\\"{x:1334,y:798,t:1527265145420};\\\", \\\"{x:1328,y:806,t:1527265145437};\\\", \\\"{x:1324,y:812,t:1527265145454};\\\", \\\"{x:1319,y:815,t:1527265145470};\\\", \\\"{x:1314,y:819,t:1527265145487};\\\", \\\"{x:1307,y:822,t:1527265145504};\\\", \\\"{x:1303,y:823,t:1527265145520};\\\", \\\"{x:1291,y:826,t:1527265145537};\\\", \\\"{x:1275,y:828,t:1527265145554};\\\", \\\"{x:1252,y:828,t:1527265145570};\\\", \\\"{x:1213,y:828,t:1527265145588};\\\", \\\"{x:1149,y:823,t:1527265145605};\\\", \\\"{x:1056,y:801,t:1527265145620};\\\", \\\"{x:921,y:765,t:1527265145638};\\\", \\\"{x:836,y:748,t:1527265145654};\\\", \\\"{x:783,y:740,t:1527265145671};\\\", \\\"{x:741,y:734,t:1527265145687};\\\", \\\"{x:717,y:731,t:1527265145704};\\\", \\\"{x:695,y:728,t:1527265145720};\\\", \\\"{x:674,y:722,t:1527265145737};\\\", \\\"{x:664,y:720,t:1527265145754};\\\", \\\"{x:659,y:717,t:1527265145770};\\\", \\\"{x:660,y:717,t:1527265145996};\\\", \\\"{x:664,y:717,t:1527265146004};\\\", \\\"{x:669,y:718,t:1527265146021};\\\", \\\"{x:673,y:719,t:1527265146037};\\\", \\\"{x:674,y:720,t:1527265146053};\\\", \\\"{x:673,y:720,t:1527265146071};\\\", \\\"{x:659,y:720,t:1527265146087};\\\", \\\"{x:655,y:717,t:1527265146104};\\\", \\\"{x:660,y:712,t:1527265146310};\\\", \\\"{x:664,y:708,t:1527265146320};\\\", \\\"{x:664,y:703,t:1527265146337};\\\", \\\"{x:664,y:697,t:1527265146354};\\\", \\\"{x:654,y:690,t:1527265146371};\\\", \\\"{x:640,y:681,t:1527265146389};\\\", \\\"{x:622,y:667,t:1527265146404};\\\", \\\"{x:599,y:646,t:1527265146421};\\\", \\\"{x:583,y:624,t:1527265146439};\\\", \\\"{x:555,y:584,t:1527265146455};\\\", \\\"{x:529,y:542,t:1527265146471};\\\", \\\"{x:512,y:506,t:1527265146487};\\\", \\\"{x:500,y:479,t:1527265146504};\\\", \\\"{x:491,y:459,t:1527265146519};\\\", \\\"{x:485,y:445,t:1527265146536};\\\", \\\"{x:480,y:433,t:1527265146554};\\\", \\\"{x:479,y:429,t:1527265146570};\\\", \\\"{x:478,y:427,t:1527265146661};\\\", \\\"{x:477,y:428,t:1527265146708};\\\", \\\"{x:477,y:434,t:1527265146721};\\\", \\\"{x:477,y:460,t:1527265146737};\\\", \\\"{x:484,y:501,t:1527265146755};\\\", \\\"{x:488,y:532,t:1527265146771};\\\", \\\"{x:488,y:559,t:1527265146788};\\\", \\\"{x:490,y:577,t:1527265146805};\\\", \\\"{x:490,y:588,t:1527265146819};\\\", \\\"{x:490,y:601,t:1527265146837};\\\", \\\"{x:490,y:603,t:1527265146853};\\\", \\\"{x:490,y:604,t:1527265146870};\\\", \\\"{x:489,y:604,t:1527265146887};\\\", \\\"{x:484,y:604,t:1527265146904};\\\", \\\"{x:475,y:602,t:1527265146919};\\\", \\\"{x:468,y:597,t:1527265146938};\\\", \\\"{x:464,y:592,t:1527265146955};\\\", \\\"{x:460,y:582,t:1527265146970};\\\", \\\"{x:460,y:572,t:1527265146987};\\\", \\\"{x:470,y:561,t:1527265147005};\\\", \\\"{x:490,y:553,t:1527265147021};\\\", \\\"{x:557,y:541,t:1527265147037};\\\", \\\"{x:618,y:541,t:1527265147054};\\\", \\\"{x:690,y:541,t:1527265147070};\\\", \\\"{x:741,y:541,t:1527265147087};\\\", \\\"{x:765,y:538,t:1527265147104};\\\", \\\"{x:773,y:535,t:1527265147120};\\\", \\\"{x:772,y:532,t:1527265147148};\\\", \\\"{x:769,y:530,t:1527265147156};\\\", \\\"{x:764,y:527,t:1527265147170};\\\", \\\"{x:755,y:524,t:1527265147187};\\\", \\\"{x:748,y:521,t:1527265147203};\\\", \\\"{x:736,y:518,t:1527265147220};\\\", \\\"{x:724,y:516,t:1527265147237};\\\", \\\"{x:711,y:514,t:1527265147254};\\\", \\\"{x:686,y:512,t:1527265147271};\\\", \\\"{x:653,y:508,t:1527265147287};\\\", \\\"{x:640,y:508,t:1527265147304};\\\", \\\"{x:639,y:509,t:1527265147321};\\\", \\\"{x:635,y:512,t:1527265147336};\\\", \\\"{x:634,y:513,t:1527265147354};\\\", \\\"{x:633,y:514,t:1527265147371};\\\", \\\"{x:632,y:514,t:1527265147386};\\\", \\\"{x:623,y:514,t:1527265147404};\\\", \\\"{x:586,y:514,t:1527265147420};\\\", \\\"{x:527,y:514,t:1527265147436};\\\", \\\"{x:434,y:519,t:1527265147455};\\\", \\\"{x:331,y:525,t:1527265147472};\\\", \\\"{x:262,y:532,t:1527265147489};\\\", \\\"{x:240,y:534,t:1527265147504};\\\", \\\"{x:235,y:535,t:1527265147520};\\\", \\\"{x:234,y:535,t:1527265147537};\\\", \\\"{x:233,y:535,t:1527265147638};\\\", \\\"{x:232,y:536,t:1527265147654};\\\", \\\"{x:230,y:537,t:1527265147672};\\\", \\\"{x:229,y:538,t:1527265147688};\\\", \\\"{x:228,y:539,t:1527265147704};\\\", \\\"{x:226,y:541,t:1527265147721};\\\", \\\"{x:222,y:543,t:1527265147738};\\\", \\\"{x:217,y:544,t:1527265147754};\\\", \\\"{x:211,y:548,t:1527265147771};\\\", \\\"{x:204,y:551,t:1527265147788};\\\", \\\"{x:197,y:554,t:1527265147804};\\\", \\\"{x:188,y:558,t:1527265147823};\\\", \\\"{x:184,y:559,t:1527265147838};\\\", \\\"{x:182,y:559,t:1527265147854};\\\", \\\"{x:178,y:558,t:1527265147871};\\\", \\\"{x:174,y:556,t:1527265147888};\\\", \\\"{x:171,y:551,t:1527265147904};\\\", \\\"{x:169,y:547,t:1527265147922};\\\", \\\"{x:168,y:544,t:1527265147937};\\\", \\\"{x:167,y:543,t:1527265147955};\\\", \\\"{x:167,y:542,t:1527265148168};\\\", \\\"{x:165,y:540,t:1527265148188};\\\", \\\"{x:166,y:540,t:1527265148292};\\\", \\\"{x:171,y:540,t:1527265148305};\\\", \\\"{x:186,y:543,t:1527265148322};\\\", \\\"{x:199,y:544,t:1527265148338};\\\", \\\"{x:217,y:544,t:1527265148355};\\\", \\\"{x:238,y:544,t:1527265148371};\\\", \\\"{x:256,y:544,t:1527265148387};\\\", \\\"{x:275,y:550,t:1527265148406};\\\", \\\"{x:289,y:553,t:1527265148421};\\\", \\\"{x:304,y:554,t:1527265148438};\\\", \\\"{x:314,y:556,t:1527265148455};\\\", \\\"{x:317,y:556,t:1527265148472};\\\", \\\"{x:317,y:557,t:1527265148549};\\\", \\\"{x:317,y:560,t:1527265148557};\\\", \\\"{x:317,y:563,t:1527265148572};\\\", \\\"{x:314,y:573,t:1527265148588};\\\", \\\"{x:307,y:586,t:1527265148604};\\\", \\\"{x:304,y:590,t:1527265148622};\\\", \\\"{x:301,y:592,t:1527265148638};\\\", \\\"{x:299,y:594,t:1527265148656};\\\", \\\"{x:298,y:595,t:1527265148672};\\\", \\\"{x:296,y:596,t:1527265148688};\\\", \\\"{x:291,y:596,t:1527265148705};\\\", \\\"{x:284,y:601,t:1527265148722};\\\", \\\"{x:268,y:608,t:1527265148741};\\\", \\\"{x:255,y:617,t:1527265148755};\\\", \\\"{x:247,y:623,t:1527265148772};\\\", \\\"{x:246,y:625,t:1527265148788};\\\", \\\"{x:248,y:625,t:1527265148845};\\\", \\\"{x:257,y:623,t:1527265148855};\\\", \\\"{x:300,y:612,t:1527265148872};\\\", \\\"{x:394,y:585,t:1527265148889};\\\", \\\"{x:521,y:555,t:1527265148906};\\\", \\\"{x:664,y:520,t:1527265148922};\\\", \\\"{x:814,y:492,t:1527265148940};\\\", \\\"{x:942,y:467,t:1527265148956};\\\", \\\"{x:1034,y:455,t:1527265148972};\\\", \\\"{x:1100,y:443,t:1527265148989};\\\", \\\"{x:1111,y:442,t:1527265149005};\\\", \\\"{x:1112,y:442,t:1527265149022};\\\", \\\"{x:1113,y:442,t:1527265149053};\\\", \\\"{x:1107,y:444,t:1527265149102};\\\", \\\"{x:1098,y:448,t:1527265149109};\\\", \\\"{x:1081,y:456,t:1527265149123};\\\", \\\"{x:1029,y:475,t:1527265149139};\\\", \\\"{x:958,y:502,t:1527265149156};\\\", \\\"{x:900,y:519,t:1527265149172};\\\", \\\"{x:864,y:525,t:1527265149189};\\\", \\\"{x:858,y:529,t:1527265149207};\\\", \\\"{x:856,y:529,t:1527265149294};\\\", \\\"{x:855,y:529,t:1527265149305};\\\", \\\"{x:854,y:529,t:1527265149322};\\\", \\\"{x:853,y:529,t:1527265149357};\\\", \\\"{x:853,y:527,t:1527265149373};\\\", \\\"{x:853,y:517,t:1527265149388};\\\", \\\"{x:853,y:512,t:1527265149405};\\\", \\\"{x:853,y:509,t:1527265149422};\\\", \\\"{x:853,y:507,t:1527265149438};\\\", \\\"{x:853,y:506,t:1527265149468};\\\", \\\"{x:852,y:507,t:1527265149652};\\\", \\\"{x:849,y:509,t:1527265149660};\\\", \\\"{x:845,y:514,t:1527265149672};\\\", \\\"{x:829,y:527,t:1527265149690};\\\", \\\"{x:798,y:546,t:1527265149706};\\\", \\\"{x:760,y:567,t:1527265149723};\\\", \\\"{x:714,y:593,t:1527265149739};\\\", \\\"{x:668,y:618,t:1527265149757};\\\", \\\"{x:633,y:640,t:1527265149772};\\\", \\\"{x:619,y:651,t:1527265149789};\\\", \\\"{x:614,y:659,t:1527265149806};\\\", \\\"{x:609,y:669,t:1527265149822};\\\", \\\"{x:605,y:675,t:1527265149839};\\\", \\\"{x:599,y:682,t:1527265149856};\\\", \\\"{x:596,y:686,t:1527265149872};\\\", \\\"{x:594,y:689,t:1527265149889};\\\", \\\"{x:592,y:691,t:1527265149906};\\\", \\\"{x:590,y:693,t:1527265149922};\\\", \\\"{x:586,y:697,t:1527265149939};\\\", \\\"{x:582,y:701,t:1527265149956};\\\", \\\"{x:578,y:704,t:1527265149972};\\\", \\\"{x:575,y:708,t:1527265149988};\\\", \\\"{x:574,y:709,t:1527265150005};\\\", \\\"{x:573,y:709,t:1527265150029};\\\", \\\"{x:571,y:711,t:1527265150045};\\\", \\\"{x:568,y:712,t:1527265150055};\\\", \\\"{x:561,y:716,t:1527265150073};\\\", \\\"{x:555,y:720,t:1527265150090};\\\", \\\"{x:548,y:722,t:1527265150105};\\\", \\\"{x:545,y:724,t:1527265150123};\\\", \\\"{x:538,y:727,t:1527265150139};\\\", \\\"{x:534,y:729,t:1527265150157};\\\", \\\"{x:533,y:729,t:1527265150173};\\\", \\\"{x:533,y:730,t:1527265150190};\\\" ] }, { \\\"rt\\\": 20027, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 756533, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:731,t:1527265152341};\\\", \\\"{x:541,y:737,t:1527265152358};\\\", \\\"{x:552,y:758,t:1527265152376};\\\", \\\"{x:565,y:784,t:1527265152392};\\\", \\\"{x:569,y:796,t:1527265152408};\\\", \\\"{x:571,y:798,t:1527265152425};\\\", \\\"{x:574,y:802,t:1527265152441};\\\", \\\"{x:577,y:803,t:1527265152458};\\\", \\\"{x:578,y:803,t:1527265152669};\\\", \\\"{x:581,y:803,t:1527265152685};\\\", \\\"{x:582,y:796,t:1527265152692};\\\", \\\"{x:582,y:792,t:1527265152708};\\\", \\\"{x:590,y:773,t:1527265152724};\\\", \\\"{x:605,y:760,t:1527265152742};\\\", \\\"{x:620,y:749,t:1527265152758};\\\", \\\"{x:646,y:737,t:1527265152775};\\\", \\\"{x:678,y:726,t:1527265152792};\\\", \\\"{x:732,y:718,t:1527265152808};\\\", \\\"{x:809,y:708,t:1527265152825};\\\", \\\"{x:902,y:692,t:1527265152843};\\\", \\\"{x:988,y:681,t:1527265152858};\\\", \\\"{x:1071,y:670,t:1527265152875};\\\", \\\"{x:1158,y:652,t:1527265152892};\\\", \\\"{x:1253,y:634,t:1527265152909};\\\", \\\"{x:1301,y:626,t:1527265152925};\\\", \\\"{x:1327,y:620,t:1527265152942};\\\", \\\"{x:1334,y:619,t:1527265152960};\\\", \\\"{x:1335,y:618,t:1527265152976};\\\", \\\"{x:1335,y:617,t:1527265152997};\\\", \\\"{x:1334,y:617,t:1527265153102};\\\", \\\"{x:1333,y:617,t:1527265153206};\\\", \\\"{x:1334,y:617,t:1527265153613};\\\", \\\"{x:1336,y:617,t:1527265153626};\\\", \\\"{x:1340,y:615,t:1527265153642};\\\", \\\"{x:1342,y:615,t:1527265153659};\\\", \\\"{x:1345,y:617,t:1527265153676};\\\", \\\"{x:1358,y:630,t:1527265153693};\\\", \\\"{x:1374,y:640,t:1527265153710};\\\", \\\"{x:1396,y:653,t:1527265153726};\\\", \\\"{x:1421,y:670,t:1527265153744};\\\", \\\"{x:1444,y:686,t:1527265153760};\\\", \\\"{x:1464,y:698,t:1527265153777};\\\", \\\"{x:1482,y:707,t:1527265153793};\\\", \\\"{x:1495,y:715,t:1527265153810};\\\", \\\"{x:1507,y:721,t:1527265153827};\\\", \\\"{x:1514,y:725,t:1527265153843};\\\", \\\"{x:1519,y:729,t:1527265153859};\\\", \\\"{x:1524,y:732,t:1527265153877};\\\", \\\"{x:1530,y:740,t:1527265153894};\\\", \\\"{x:1530,y:748,t:1527265153910};\\\", \\\"{x:1534,y:765,t:1527265153927};\\\", \\\"{x:1534,y:791,t:1527265153944};\\\", \\\"{x:1534,y:823,t:1527265153959};\\\", \\\"{x:1534,y:871,t:1527265153976};\\\", \\\"{x:1530,y:925,t:1527265153994};\\\", \\\"{x:1526,y:959,t:1527265154010};\\\", \\\"{x:1524,y:978,t:1527265154027};\\\", \\\"{x:1524,y:983,t:1527265154043};\\\", \\\"{x:1524,y:984,t:1527265154060};\\\", \\\"{x:1524,y:985,t:1527265154077};\\\", \\\"{x:1524,y:986,t:1527265154093};\\\", \\\"{x:1524,y:988,t:1527265154111};\\\", \\\"{x:1525,y:990,t:1527265154127};\\\", \\\"{x:1525,y:993,t:1527265154144};\\\", \\\"{x:1525,y:994,t:1527265154161};\\\", \\\"{x:1526,y:995,t:1527265154177};\\\", \\\"{x:1527,y:995,t:1527265154206};\\\", \\\"{x:1529,y:995,t:1527265154245};\\\", \\\"{x:1529,y:993,t:1527265154261};\\\", \\\"{x:1530,y:988,t:1527265154276};\\\", \\\"{x:1532,y:984,t:1527265154294};\\\", \\\"{x:1533,y:982,t:1527265154311};\\\", \\\"{x:1535,y:982,t:1527265154327};\\\", \\\"{x:1535,y:981,t:1527265154366};\\\", \\\"{x:1536,y:980,t:1527265154397};\\\", \\\"{x:1537,y:979,t:1527265154413};\\\", \\\"{x:1537,y:978,t:1527265154438};\\\", \\\"{x:1538,y:977,t:1527265154518};\\\", \\\"{x:1539,y:977,t:1527265154566};\\\", \\\"{x:1541,y:977,t:1527265154598};\\\", \\\"{x:1541,y:976,t:1527265154611};\\\", \\\"{x:1542,y:975,t:1527265154628};\\\", \\\"{x:1543,y:974,t:1527265154646};\\\", \\\"{x:1543,y:973,t:1527265154661};\\\", \\\"{x:1544,y:972,t:1527265154677};\\\", \\\"{x:1545,y:972,t:1527265154694};\\\", \\\"{x:1545,y:970,t:1527265154711};\\\", \\\"{x:1546,y:967,t:1527265154729};\\\", \\\"{x:1549,y:962,t:1527265154744};\\\", \\\"{x:1550,y:957,t:1527265154761};\\\", \\\"{x:1553,y:949,t:1527265154777};\\\", \\\"{x:1556,y:943,t:1527265154795};\\\", \\\"{x:1557,y:936,t:1527265154811};\\\", \\\"{x:1560,y:927,t:1527265154828};\\\", \\\"{x:1561,y:918,t:1527265154844};\\\", \\\"{x:1562,y:910,t:1527265154860};\\\", \\\"{x:1562,y:893,t:1527265154877};\\\", \\\"{x:1563,y:879,t:1527265154895};\\\", \\\"{x:1563,y:868,t:1527265154910};\\\", \\\"{x:1563,y:852,t:1527265154927};\\\", \\\"{x:1563,y:839,t:1527265154944};\\\", \\\"{x:1563,y:830,t:1527265154961};\\\", \\\"{x:1563,y:823,t:1527265154978};\\\", \\\"{x:1563,y:816,t:1527265154995};\\\", \\\"{x:1563,y:809,t:1527265155011};\\\", \\\"{x:1563,y:801,t:1527265155027};\\\", \\\"{x:1563,y:796,t:1527265155044};\\\", \\\"{x:1563,y:790,t:1527265155060};\\\", \\\"{x:1563,y:783,t:1527265155077};\\\", \\\"{x:1563,y:778,t:1527265155095};\\\", \\\"{x:1561,y:775,t:1527265155110};\\\", \\\"{x:1560,y:769,t:1527265155128};\\\", \\\"{x:1559,y:764,t:1527265155144};\\\", \\\"{x:1557,y:756,t:1527265155162};\\\", \\\"{x:1557,y:751,t:1527265155177};\\\", \\\"{x:1555,y:746,t:1527265155194};\\\", \\\"{x:1554,y:742,t:1527265155212};\\\", \\\"{x:1552,y:738,t:1527265155227};\\\", \\\"{x:1551,y:737,t:1527265155245};\\\", \\\"{x:1549,y:730,t:1527265155261};\\\", \\\"{x:1544,y:722,t:1527265155278};\\\", \\\"{x:1542,y:714,t:1527265155294};\\\", \\\"{x:1540,y:703,t:1527265155312};\\\", \\\"{x:1537,y:691,t:1527265155328};\\\", \\\"{x:1536,y:678,t:1527265155345};\\\", \\\"{x:1534,y:664,t:1527265155361};\\\", \\\"{x:1532,y:656,t:1527265155377};\\\", \\\"{x:1531,y:649,t:1527265155394};\\\", \\\"{x:1530,y:644,t:1527265155412};\\\", \\\"{x:1529,y:637,t:1527265155427};\\\", \\\"{x:1528,y:633,t:1527265155445};\\\", \\\"{x:1526,y:623,t:1527265155461};\\\", \\\"{x:1524,y:618,t:1527265155479};\\\", \\\"{x:1522,y:612,t:1527265155494};\\\", \\\"{x:1522,y:607,t:1527265155512};\\\", \\\"{x:1520,y:602,t:1527265155529};\\\", \\\"{x:1519,y:596,t:1527265155545};\\\", \\\"{x:1519,y:590,t:1527265155562};\\\", \\\"{x:1519,y:586,t:1527265155578};\\\", \\\"{x:1518,y:581,t:1527265155594};\\\", \\\"{x:1518,y:578,t:1527265155612};\\\", \\\"{x:1517,y:577,t:1527265155628};\\\", \\\"{x:1517,y:576,t:1527265155645};\\\", \\\"{x:1516,y:575,t:1527265155766};\\\", \\\"{x:1516,y:573,t:1527265155779};\\\", \\\"{x:1515,y:572,t:1527265155794};\\\", \\\"{x:1515,y:570,t:1527265155812};\\\", \\\"{x:1515,y:569,t:1527265155829};\\\", \\\"{x:1516,y:569,t:1527265156966};\\\", \\\"{x:1516,y:571,t:1527265156982};\\\", \\\"{x:1516,y:572,t:1527265156996};\\\", \\\"{x:1515,y:576,t:1527265157012};\\\", \\\"{x:1510,y:583,t:1527265157030};\\\", \\\"{x:1505,y:590,t:1527265157047};\\\", \\\"{x:1495,y:600,t:1527265157062};\\\", \\\"{x:1487,y:614,t:1527265157079};\\\", \\\"{x:1481,y:631,t:1527265157097};\\\", \\\"{x:1474,y:656,t:1527265157112};\\\", \\\"{x:1469,y:683,t:1527265157129};\\\", \\\"{x:1463,y:711,t:1527265157147};\\\", \\\"{x:1454,y:735,t:1527265157163};\\\", \\\"{x:1446,y:765,t:1527265157179};\\\", \\\"{x:1439,y:795,t:1527265157197};\\\", \\\"{x:1429,y:828,t:1527265157213};\\\", \\\"{x:1423,y:845,t:1527265157230};\\\", \\\"{x:1419,y:859,t:1527265157247};\\\", \\\"{x:1415,y:871,t:1527265157264};\\\", \\\"{x:1412,y:883,t:1527265157279};\\\", \\\"{x:1409,y:888,t:1527265157297};\\\", \\\"{x:1406,y:891,t:1527265157313};\\\", \\\"{x:1405,y:892,t:1527265157330};\\\", \\\"{x:1401,y:894,t:1527265157347};\\\", \\\"{x:1399,y:897,t:1527265157364};\\\", \\\"{x:1395,y:900,t:1527265157379};\\\", \\\"{x:1390,y:903,t:1527265157396};\\\", \\\"{x:1383,y:905,t:1527265157413};\\\", \\\"{x:1380,y:906,t:1527265157429};\\\", \\\"{x:1374,y:907,t:1527265157446};\\\", \\\"{x:1368,y:907,t:1527265157463};\\\", \\\"{x:1365,y:907,t:1527265157479};\\\", \\\"{x:1361,y:907,t:1527265157497};\\\", \\\"{x:1360,y:907,t:1527265157513};\\\", \\\"{x:1358,y:907,t:1527265157530};\\\", \\\"{x:1356,y:906,t:1527265157546};\\\", \\\"{x:1354,y:904,t:1527265157564};\\\", \\\"{x:1351,y:901,t:1527265157580};\\\", \\\"{x:1349,y:894,t:1527265157597};\\\", \\\"{x:1347,y:880,t:1527265157613};\\\", \\\"{x:1347,y:867,t:1527265157630};\\\", \\\"{x:1347,y:852,t:1527265157646};\\\", \\\"{x:1347,y:836,t:1527265157664};\\\", \\\"{x:1347,y:818,t:1527265157681};\\\", \\\"{x:1347,y:803,t:1527265157697};\\\", \\\"{x:1347,y:796,t:1527265157714};\\\", \\\"{x:1347,y:789,t:1527265157731};\\\", \\\"{x:1347,y:786,t:1527265157747};\\\", \\\"{x:1347,y:782,t:1527265157764};\\\", \\\"{x:1347,y:780,t:1527265157781};\\\", \\\"{x:1347,y:779,t:1527265157886};\\\", \\\"{x:1346,y:779,t:1527265157902};\\\", \\\"{x:1345,y:777,t:1527265157914};\\\", \\\"{x:1345,y:775,t:1527265158294};\\\", \\\"{x:1345,y:774,t:1527265158302};\\\", \\\"{x:1345,y:773,t:1527265158317};\\\", \\\"{x:1345,y:772,t:1527265158334};\\\", \\\"{x:1345,y:771,t:1527265158348};\\\", \\\"{x:1345,y:770,t:1527265158365};\\\", \\\"{x:1345,y:769,t:1527265158382};\\\", \\\"{x:1345,y:768,t:1527265158400};\\\", \\\"{x:1345,y:767,t:1527265158430};\\\", \\\"{x:1345,y:766,t:1527265158447};\\\", \\\"{x:1345,y:765,t:1527265158468};\\\", \\\"{x:1346,y:765,t:1527265159517};\\\", \\\"{x:1352,y:766,t:1527265159532};\\\", \\\"{x:1363,y:771,t:1527265159550};\\\", \\\"{x:1375,y:764,t:1527265168918};\\\", \\\"{x:1454,y:683,t:1527265168925};\\\", \\\"{x:1591,y:526,t:1527265168941};\\\", \\\"{x:1642,y:370,t:1527265168958};\\\", \\\"{x:1614,y:193,t:1527265168974};\\\", \\\"{x:1521,y:10,t:1527265168991};\\\", \\\"{x:1402,y:0,t:1527265169008};\\\", \\\"{x:1249,y:0,t:1527265169024};\\\", \\\"{x:1090,y:0,t:1527265169041};\\\", \\\"{x:932,y:0,t:1527265169059};\\\", \\\"{x:807,y:0,t:1527265169074};\\\", \\\"{x:761,y:9,t:1527265169091};\\\", \\\"{x:714,y:28,t:1527265169108};\\\", \\\"{x:678,y:53,t:1527265169124};\\\", \\\"{x:672,y:60,t:1527265169141};\\\", \\\"{x:670,y:73,t:1527265169158};\\\", \\\"{x:663,y:82,t:1527265169175};\\\", \\\"{x:663,y:83,t:1527265169422};\\\", \\\"{x:652,y:91,t:1527265169429};\\\", \\\"{x:621,y:117,t:1527265169442};\\\", \\\"{x:534,y:163,t:1527265169458};\\\", \\\"{x:431,y:218,t:1527265169475};\\\", \\\"{x:367,y:274,t:1527265169492};\\\", \\\"{x:314,y:342,t:1527265169508};\\\", \\\"{x:254,y:429,t:1527265169525};\\\", \\\"{x:219,y:472,t:1527265169542};\\\", \\\"{x:202,y:495,t:1527265169559};\\\", \\\"{x:193,y:509,t:1527265169575};\\\", \\\"{x:185,y:522,t:1527265169592};\\\", \\\"{x:181,y:541,t:1527265169605};\\\", \\\"{x:175,y:553,t:1527265169622};\\\", \\\"{x:174,y:554,t:1527265169638};\\\", \\\"{x:173,y:555,t:1527265169908};\\\", \\\"{x:172,y:555,t:1527265169922};\\\", \\\"{x:171,y:555,t:1527265169924};\\\", \\\"{x:171,y:555,t:1527265169939};\\\", \\\"{x:169,y:555,t:1527265169956};\\\", \\\"{x:169,y:557,t:1527265169989};\\\", \\\"{x:188,y:567,t:1527265170006};\\\", \\\"{x:234,y:595,t:1527265170023};\\\", \\\"{x:291,y:615,t:1527265170039};\\\", \\\"{x:350,y:635,t:1527265170056};\\\", \\\"{x:402,y:654,t:1527265170072};\\\", \\\"{x:431,y:662,t:1527265170089};\\\", \\\"{x:446,y:665,t:1527265170106};\\\", \\\"{x:450,y:666,t:1527265170122};\\\", \\\"{x:453,y:668,t:1527265170139};\\\", \\\"{x:454,y:669,t:1527265170205};\\\", \\\"{x:454,y:673,t:1527265170213};\\\", \\\"{x:457,y:679,t:1527265170223};\\\", \\\"{x:462,y:694,t:1527265170239};\\\", \\\"{x:464,y:701,t:1527265170256};\\\", \\\"{x:464,y:703,t:1527265170273};\\\", \\\"{x:463,y:703,t:1527265170333};\\\", \\\"{x:460,y:701,t:1527265170340};\\\", \\\"{x:449,y:690,t:1527265170357};\\\", \\\"{x:429,y:674,t:1527265170373};\\\", \\\"{x:388,y:643,t:1527265170390};\\\", \\\"{x:337,y:617,t:1527265170407};\\\", \\\"{x:284,y:590,t:1527265170424};\\\", \\\"{x:244,y:569,t:1527265170439};\\\", \\\"{x:222,y:561,t:1527265170456};\\\", \\\"{x:214,y:557,t:1527265170473};\\\", \\\"{x:210,y:557,t:1527265170489};\\\", \\\"{x:208,y:557,t:1527265170620};\\\", \\\"{x:205,y:557,t:1527265170628};\\\", \\\"{x:202,y:557,t:1527265170639};\\\", \\\"{x:192,y:554,t:1527265170656};\\\", \\\"{x:186,y:551,t:1527265170672};\\\", \\\"{x:179,y:548,t:1527265170691};\\\", \\\"{x:175,y:546,t:1527265170706};\\\", \\\"{x:172,y:544,t:1527265170723};\\\", \\\"{x:170,y:542,t:1527265170739};\\\", \\\"{x:169,y:540,t:1527265170756};\\\", \\\"{x:167,y:538,t:1527265170773};\\\", \\\"{x:167,y:537,t:1527265170789};\\\", \\\"{x:170,y:543,t:1527265170989};\\\", \\\"{x:177,y:552,t:1527265170997};\\\", \\\"{x:188,y:565,t:1527265171006};\\\", \\\"{x:209,y:582,t:1527265171023};\\\", \\\"{x:230,y:594,t:1527265171040};\\\", \\\"{x:249,y:604,t:1527265171057};\\\", \\\"{x:272,y:612,t:1527265171072};\\\", \\\"{x:294,y:619,t:1527265171090};\\\", \\\"{x:315,y:624,t:1527265171105};\\\", \\\"{x:337,y:631,t:1527265171123};\\\", \\\"{x:369,y:645,t:1527265171141};\\\", \\\"{x:410,y:660,t:1527265171156};\\\", \\\"{x:429,y:666,t:1527265171173};\\\", \\\"{x:446,y:671,t:1527265171190};\\\", \\\"{x:461,y:681,t:1527265171205};\\\", \\\"{x:471,y:685,t:1527265171223};\\\", \\\"{x:472,y:686,t:1527265171239};\\\", \\\"{x:473,y:687,t:1527265171257};\\\", \\\"{x:473,y:689,t:1527265171273};\\\", \\\"{x:474,y:698,t:1527265171289};\\\", \\\"{x:476,y:703,t:1527265171307};\\\", \\\"{x:476,y:706,t:1527265171324};\\\", \\\"{x:476,y:712,t:1527265171340};\\\", \\\"{x:477,y:720,t:1527265171357};\\\", \\\"{x:477,y:723,t:1527265171374};\\\", \\\"{x:477,y:725,t:1527265171389};\\\" ] }, { \\\"rt\\\": 37499, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 795235, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:474,y:725,t:1527265175614};\\\", \\\"{x:472,y:725,t:1527265175627};\\\", \\\"{x:459,y:730,t:1527265175644};\\\", \\\"{x:441,y:734,t:1527265175661};\\\", \\\"{x:410,y:741,t:1527265175678};\\\", \\\"{x:393,y:744,t:1527265175694};\\\", \\\"{x:383,y:746,t:1527265175710};\\\", \\\"{x:379,y:746,t:1527265175727};\\\", \\\"{x:377,y:746,t:1527265175743};\\\", \\\"{x:376,y:746,t:1527265179878};\\\", \\\"{x:376,y:748,t:1527265179885};\\\", \\\"{x:374,y:748,t:1527265179896};\\\", \\\"{x:371,y:751,t:1527265179914};\\\", \\\"{x:366,y:751,t:1527265179931};\\\", \\\"{x:364,y:753,t:1527265179947};\\\", \\\"{x:363,y:753,t:1527265179965};\\\", \\\"{x:366,y:756,t:1527265180004};\\\", \\\"{x:378,y:759,t:1527265180013};\\\", \\\"{x:431,y:762,t:1527265180030};\\\", \\\"{x:515,y:764,t:1527265180047};\\\", \\\"{x:640,y:764,t:1527265180063};\\\", \\\"{x:775,y:752,t:1527265180080};\\\", \\\"{x:915,y:735,t:1527265180096};\\\", \\\"{x:1072,y:720,t:1527265180114};\\\", \\\"{x:1212,y:711,t:1527265180129};\\\", \\\"{x:1335,y:703,t:1527265180146};\\\", \\\"{x:1429,y:691,t:1527265180163};\\\", \\\"{x:1503,y:686,t:1527265180180};\\\", \\\"{x:1526,y:686,t:1527265180196};\\\", \\\"{x:1544,y:691,t:1527265180214};\\\", \\\"{x:1550,y:695,t:1527265180231};\\\", \\\"{x:1551,y:698,t:1527265180246};\\\", \\\"{x:1544,y:704,t:1527265180264};\\\", \\\"{x:1541,y:709,t:1527265180281};\\\", \\\"{x:1540,y:709,t:1527265180470};\\\", \\\"{x:1540,y:708,t:1527265180518};\\\", \\\"{x:1538,y:706,t:1527265180531};\\\", \\\"{x:1538,y:708,t:1527265180582};\\\", \\\"{x:1537,y:724,t:1527265180597};\\\", \\\"{x:1535,y:741,t:1527265180614};\\\", \\\"{x:1535,y:763,t:1527265180631};\\\", \\\"{x:1535,y:786,t:1527265180647};\\\", \\\"{x:1535,y:811,t:1527265180664};\\\", \\\"{x:1536,y:830,t:1527265180681};\\\", \\\"{x:1538,y:853,t:1527265180698};\\\", \\\"{x:1538,y:876,t:1527265180714};\\\", \\\"{x:1537,y:894,t:1527265180731};\\\", \\\"{x:1533,y:913,t:1527265180748};\\\", \\\"{x:1528,y:924,t:1527265180764};\\\", \\\"{x:1521,y:936,t:1527265180781};\\\", \\\"{x:1517,y:942,t:1527265180797};\\\", \\\"{x:1514,y:949,t:1527265180814};\\\", \\\"{x:1510,y:953,t:1527265180831};\\\", \\\"{x:1510,y:956,t:1527265180848};\\\", \\\"{x:1509,y:960,t:1527265180864};\\\", \\\"{x:1508,y:962,t:1527265180881};\\\", \\\"{x:1507,y:964,t:1527265180898};\\\", \\\"{x:1506,y:966,t:1527265180914};\\\", \\\"{x:1506,y:967,t:1527265180931};\\\", \\\"{x:1505,y:968,t:1527265181046};\\\", \\\"{x:1504,y:967,t:1527265181054};\\\", \\\"{x:1504,y:963,t:1527265181064};\\\", \\\"{x:1504,y:955,t:1527265181082};\\\", \\\"{x:1503,y:948,t:1527265181098};\\\", \\\"{x:1502,y:939,t:1527265181114};\\\", \\\"{x:1500,y:926,t:1527265181131};\\\", \\\"{x:1498,y:911,t:1527265181148};\\\", \\\"{x:1497,y:897,t:1527265181164};\\\", \\\"{x:1493,y:875,t:1527265181181};\\\", \\\"{x:1492,y:869,t:1527265181198};\\\", \\\"{x:1490,y:865,t:1527265181214};\\\", \\\"{x:1490,y:863,t:1527265181230};\\\", \\\"{x:1489,y:861,t:1527265181248};\\\", \\\"{x:1488,y:858,t:1527265181265};\\\", \\\"{x:1488,y:851,t:1527265181281};\\\", \\\"{x:1487,y:846,t:1527265181297};\\\", \\\"{x:1485,y:837,t:1527265181314};\\\", \\\"{x:1483,y:832,t:1527265181331};\\\", \\\"{x:1483,y:831,t:1527265181347};\\\", \\\"{x:1482,y:829,t:1527265181365};\\\", \\\"{x:1482,y:828,t:1527265181453};\\\", \\\"{x:1481,y:827,t:1527265181501};\\\", \\\"{x:1480,y:827,t:1527265181637};\\\", \\\"{x:1479,y:827,t:1527265184677};\\\", \\\"{x:1476,y:825,t:1527265184687};\\\", \\\"{x:1474,y:824,t:1527265184701};\\\", \\\"{x:1472,y:823,t:1527265184717};\\\", \\\"{x:1470,y:823,t:1527265184734};\\\", \\\"{x:1469,y:823,t:1527265184750};\\\", \\\"{x:1468,y:824,t:1527265184767};\\\", \\\"{x:1468,y:825,t:1527265184783};\\\", \\\"{x:1467,y:826,t:1527265184801};\\\", \\\"{x:1465,y:829,t:1527265184817};\\\", \\\"{x:1463,y:833,t:1527265184833};\\\", \\\"{x:1460,y:836,t:1527265184850};\\\", \\\"{x:1457,y:841,t:1527265184868};\\\", \\\"{x:1454,y:844,t:1527265184883};\\\", \\\"{x:1451,y:847,t:1527265184900};\\\", \\\"{x:1447,y:851,t:1527265184918};\\\", \\\"{x:1444,y:854,t:1527265184933};\\\", \\\"{x:1441,y:857,t:1527265184950};\\\", \\\"{x:1438,y:861,t:1527265184967};\\\", \\\"{x:1435,y:864,t:1527265184986};\\\", \\\"{x:1432,y:867,t:1527265185001};\\\", \\\"{x:1429,y:869,t:1527265185017};\\\", \\\"{x:1427,y:871,t:1527265185035};\\\", \\\"{x:1423,y:873,t:1527265185050};\\\", \\\"{x:1419,y:875,t:1527265185067};\\\", \\\"{x:1417,y:876,t:1527265185086};\\\", \\\"{x:1416,y:876,t:1527265185100};\\\", \\\"{x:1411,y:880,t:1527265185117};\\\", \\\"{x:1407,y:883,t:1527265185133};\\\", \\\"{x:1404,y:886,t:1527265185151};\\\", \\\"{x:1403,y:887,t:1527265185167};\\\", \\\"{x:1400,y:890,t:1527265185184};\\\", \\\"{x:1398,y:891,t:1527265185200};\\\", \\\"{x:1395,y:893,t:1527265185217};\\\", \\\"{x:1394,y:894,t:1527265185234};\\\", \\\"{x:1393,y:896,t:1527265185250};\\\", \\\"{x:1391,y:896,t:1527265185267};\\\", \\\"{x:1391,y:897,t:1527265185285};\\\", \\\"{x:1388,y:898,t:1527265185301};\\\", \\\"{x:1386,y:900,t:1527265185317};\\\", \\\"{x:1385,y:901,t:1527265185334};\\\", \\\"{x:1383,y:902,t:1527265185350};\\\", \\\"{x:1381,y:903,t:1527265185368};\\\", \\\"{x:1381,y:904,t:1527265185384};\\\", \\\"{x:1380,y:905,t:1527265185401};\\\", \\\"{x:1378,y:906,t:1527265185417};\\\", \\\"{x:1377,y:906,t:1527265188757};\\\", \\\"{x:1373,y:906,t:1527265188769};\\\", \\\"{x:1354,y:912,t:1527265188786};\\\", \\\"{x:1324,y:919,t:1527265188803};\\\", \\\"{x:1283,y:929,t:1527265188819};\\\", \\\"{x:1236,y:933,t:1527265188836};\\\", \\\"{x:1194,y:936,t:1527265188852};\\\", \\\"{x:1179,y:936,t:1527265188869};\\\", \\\"{x:1167,y:932,t:1527265188886};\\\", \\\"{x:1160,y:927,t:1527265188903};\\\", \\\"{x:1151,y:922,t:1527265188919};\\\", \\\"{x:1143,y:914,t:1527265188936};\\\", \\\"{x:1140,y:906,t:1527265188953};\\\", \\\"{x:1137,y:901,t:1527265188969};\\\", \\\"{x:1137,y:900,t:1527265188986};\\\", \\\"{x:1137,y:898,t:1527265189002};\\\", \\\"{x:1137,y:894,t:1527265189019};\\\", \\\"{x:1139,y:890,t:1527265189037};\\\", \\\"{x:1146,y:880,t:1527265189052};\\\", \\\"{x:1152,y:874,t:1527265189069};\\\", \\\"{x:1158,y:868,t:1527265189086};\\\", \\\"{x:1160,y:867,t:1527265189104};\\\", \\\"{x:1161,y:865,t:1527265189120};\\\", \\\"{x:1162,y:865,t:1527265189136};\\\", \\\"{x:1163,y:865,t:1527265189153};\\\", \\\"{x:1166,y:864,t:1527265189169};\\\", \\\"{x:1168,y:863,t:1527265189186};\\\", \\\"{x:1170,y:861,t:1527265189203};\\\", \\\"{x:1173,y:859,t:1527265189220};\\\", \\\"{x:1174,y:857,t:1527265189236};\\\", \\\"{x:1177,y:851,t:1527265189253};\\\", \\\"{x:1179,y:847,t:1527265189270};\\\", \\\"{x:1181,y:843,t:1527265189286};\\\", \\\"{x:1184,y:840,t:1527265189303};\\\", \\\"{x:1187,y:837,t:1527265189320};\\\", \\\"{x:1188,y:834,t:1527265189336};\\\", \\\"{x:1190,y:833,t:1527265189353};\\\", \\\"{x:1190,y:832,t:1527265189370};\\\", \\\"{x:1191,y:831,t:1527265189387};\\\", \\\"{x:1191,y:830,t:1527265189403};\\\", \\\"{x:1192,y:830,t:1527265189421};\\\", \\\"{x:1193,y:829,t:1527265189437};\\\", \\\"{x:1194,y:828,t:1527265189453};\\\", \\\"{x:1197,y:826,t:1527265189470};\\\", \\\"{x:1203,y:826,t:1527265189486};\\\", \\\"{x:1210,y:826,t:1527265189503};\\\", \\\"{x:1217,y:829,t:1527265189520};\\\", \\\"{x:1225,y:832,t:1527265189537};\\\", \\\"{x:1228,y:833,t:1527265189553};\\\", \\\"{x:1229,y:834,t:1527265189570};\\\", \\\"{x:1231,y:835,t:1527265189586};\\\", \\\"{x:1229,y:836,t:1527265189870};\\\", \\\"{x:1226,y:836,t:1527265189888};\\\", \\\"{x:1225,y:836,t:1527265189903};\\\", \\\"{x:1223,y:836,t:1527265189921};\\\", \\\"{x:1222,y:836,t:1527265189938};\\\", \\\"{x:1220,y:836,t:1527265189953};\\\", \\\"{x:1219,y:836,t:1527265189973};\\\", \\\"{x:1222,y:834,t:1527265190469};\\\", \\\"{x:1228,y:831,t:1527265190476};\\\", \\\"{x:1229,y:829,t:1527265190487};\\\", \\\"{x:1242,y:820,t:1527265190504};\\\", \\\"{x:1259,y:809,t:1527265190520};\\\", \\\"{x:1276,y:799,t:1527265190537};\\\", \\\"{x:1288,y:792,t:1527265190554};\\\", \\\"{x:1302,y:785,t:1527265190570};\\\", \\\"{x:1307,y:781,t:1527265190587};\\\", \\\"{x:1309,y:779,t:1527265190605};\\\", \\\"{x:1311,y:777,t:1527265190621};\\\", \\\"{x:1313,y:775,t:1527265190637};\\\", \\\"{x:1313,y:774,t:1527265190655};\\\", \\\"{x:1314,y:774,t:1527265190701};\\\", \\\"{x:1315,y:774,t:1527265190709};\\\", \\\"{x:1316,y:774,t:1527265190722};\\\", \\\"{x:1318,y:774,t:1527265190737};\\\", \\\"{x:1321,y:773,t:1527265190754};\\\", \\\"{x:1323,y:773,t:1527265190770};\\\", \\\"{x:1328,y:773,t:1527265190787};\\\", \\\"{x:1334,y:774,t:1527265190804};\\\", \\\"{x:1339,y:775,t:1527265190820};\\\", \\\"{x:1341,y:776,t:1527265190837};\\\", \\\"{x:1343,y:776,t:1527265190868};\\\", \\\"{x:1344,y:776,t:1527265190884};\\\", \\\"{x:1346,y:776,t:1527265190900};\\\", \\\"{x:1348,y:776,t:1527265190932};\\\", \\\"{x:1350,y:776,t:1527265191020};\\\", \\\"{x:1351,y:775,t:1527265191044};\\\", \\\"{x:1353,y:775,t:1527265191060};\\\", \\\"{x:1354,y:774,t:1527265191076};\\\", \\\"{x:1355,y:774,t:1527265191140};\\\", \\\"{x:1355,y:771,t:1527265191981};\\\", \\\"{x:1355,y:765,t:1527265191989};\\\", \\\"{x:1357,y:755,t:1527265192005};\\\", \\\"{x:1359,y:748,t:1527265192021};\\\", \\\"{x:1359,y:744,t:1527265192038};\\\", \\\"{x:1359,y:740,t:1527265192055};\\\", \\\"{x:1359,y:736,t:1527265192071};\\\", \\\"{x:1359,y:731,t:1527265192088};\\\", \\\"{x:1359,y:729,t:1527265192105};\\\", \\\"{x:1359,y:727,t:1527265192121};\\\", \\\"{x:1359,y:726,t:1527265192140};\\\", \\\"{x:1359,y:725,t:1527265192261};\\\", \\\"{x:1359,y:724,t:1527265192277};\\\", \\\"{x:1358,y:722,t:1527265192293};\\\", \\\"{x:1355,y:720,t:1527265192325};\\\", \\\"{x:1354,y:720,t:1527265192339};\\\", \\\"{x:1352,y:717,t:1527265192355};\\\", \\\"{x:1352,y:716,t:1527265192373};\\\", \\\"{x:1351,y:714,t:1527265192388};\\\", \\\"{x:1350,y:711,t:1527265192405};\\\", \\\"{x:1350,y:710,t:1527265192423};\\\", \\\"{x:1349,y:709,t:1527265192438};\\\", \\\"{x:1348,y:709,t:1527265192456};\\\", \\\"{x:1348,y:708,t:1527265193877};\\\", \\\"{x:1347,y:707,t:1527265193889};\\\", \\\"{x:1345,y:706,t:1527265193906};\\\", \\\"{x:1344,y:706,t:1527265193923};\\\", \\\"{x:1341,y:704,t:1527265193939};\\\", \\\"{x:1341,y:703,t:1527265193956};\\\", \\\"{x:1339,y:701,t:1527265193973};\\\", \\\"{x:1340,y:701,t:1527265195440};\\\", \\\"{x:1341,y:701,t:1527265195457};\\\", \\\"{x:1342,y:701,t:1527265195489};\\\", \\\"{x:1343,y:701,t:1527265195536};\\\", \\\"{x:1342,y:701,t:1527265195567};\\\", \\\"{x:1341,y:702,t:1527265195625};\\\", \\\"{x:1340,y:703,t:1527265195856};\\\", \\\"{x:1339,y:703,t:1527265195865};\\\", \\\"{x:1339,y:704,t:1527265195913};\\\", \\\"{x:1338,y:704,t:1527265196193};\\\", \\\"{x:1335,y:704,t:1527265196200};\\\", \\\"{x:1333,y:703,t:1527265196210};\\\", \\\"{x:1329,y:697,t:1527265196227};\\\", \\\"{x:1325,y:691,t:1527265196244};\\\", \\\"{x:1320,y:686,t:1527265196260};\\\", \\\"{x:1314,y:678,t:1527265196277};\\\", \\\"{x:1309,y:663,t:1527265196294};\\\", \\\"{x:1304,y:649,t:1527265196310};\\\", \\\"{x:1297,y:628,t:1527265196327};\\\", \\\"{x:1293,y:618,t:1527265196344};\\\", \\\"{x:1289,y:608,t:1527265196360};\\\", \\\"{x:1287,y:604,t:1527265196377};\\\", \\\"{x:1284,y:598,t:1527265196395};\\\", \\\"{x:1281,y:594,t:1527265196410};\\\", \\\"{x:1279,y:591,t:1527265196427};\\\", \\\"{x:1276,y:588,t:1527265196444};\\\", \\\"{x:1274,y:584,t:1527265196460};\\\", \\\"{x:1274,y:583,t:1527265196478};\\\", \\\"{x:1273,y:583,t:1527265196494};\\\", \\\"{x:1273,y:582,t:1527265198272};\\\", \\\"{x:1282,y:576,t:1527265200745};\\\", \\\"{x:1308,y:564,t:1527265200752};\\\", \\\"{x:1331,y:555,t:1527265200764};\\\", \\\"{x:1387,y:538,t:1527265200781};\\\", \\\"{x:1439,y:527,t:1527265200797};\\\", \\\"{x:1493,y:514,t:1527265200813};\\\", \\\"{x:1526,y:509,t:1527265200830};\\\", \\\"{x:1543,y:508,t:1527265200847};\\\", \\\"{x:1544,y:508,t:1527265200863};\\\", \\\"{x:1543,y:510,t:1527265200959};\\\", \\\"{x:1542,y:514,t:1527265200968};\\\", \\\"{x:1540,y:517,t:1527265200981};\\\", \\\"{x:1532,y:528,t:1527265200998};\\\", \\\"{x:1519,y:541,t:1527265201013};\\\", \\\"{x:1506,y:554,t:1527265201031};\\\", \\\"{x:1484,y:566,t:1527265201048};\\\", \\\"{x:1475,y:570,t:1527265201064};\\\", \\\"{x:1469,y:571,t:1527265201080};\\\", \\\"{x:1465,y:573,t:1527265201097};\\\", \\\"{x:1463,y:573,t:1527265201113};\\\", \\\"{x:1461,y:573,t:1527265201130};\\\", \\\"{x:1457,y:573,t:1527265201147};\\\", \\\"{x:1455,y:573,t:1527265201164};\\\", \\\"{x:1452,y:572,t:1527265201181};\\\", \\\"{x:1448,y:571,t:1527265201198};\\\", \\\"{x:1447,y:570,t:1527265201215};\\\", \\\"{x:1446,y:570,t:1527265201240};\\\", \\\"{x:1445,y:569,t:1527265201271};\\\", \\\"{x:1448,y:567,t:1527265201535};\\\", \\\"{x:1451,y:566,t:1527265201547};\\\", \\\"{x:1454,y:565,t:1527265201565};\\\", \\\"{x:1456,y:565,t:1527265201580};\\\", \\\"{x:1458,y:563,t:1527265201598};\\\", \\\"{x:1459,y:563,t:1527265201615};\\\", \\\"{x:1460,y:563,t:1527265201631};\\\", \\\"{x:1460,y:567,t:1527265201849};\\\", \\\"{x:1459,y:568,t:1527265201865};\\\", \\\"{x:1455,y:573,t:1527265201882};\\\", \\\"{x:1451,y:578,t:1527265201898};\\\", \\\"{x:1446,y:581,t:1527265201915};\\\", \\\"{x:1443,y:582,t:1527265201932};\\\", \\\"{x:1442,y:582,t:1527265201948};\\\", \\\"{x:1441,y:582,t:1527265202049};\\\", \\\"{x:1439,y:582,t:1527265202065};\\\", \\\"{x:1437,y:582,t:1527265202083};\\\", \\\"{x:1432,y:582,t:1527265202098};\\\", \\\"{x:1428,y:581,t:1527265202115};\\\", \\\"{x:1425,y:581,t:1527265202132};\\\", \\\"{x:1421,y:579,t:1527265202148};\\\", \\\"{x:1416,y:577,t:1527265202165};\\\", \\\"{x:1413,y:576,t:1527265202183};\\\", \\\"{x:1409,y:574,t:1527265202198};\\\", \\\"{x:1408,y:574,t:1527265202233};\\\", \\\"{x:1408,y:573,t:1527265202449};\\\", \\\"{x:1410,y:572,t:1527265202472};\\\", \\\"{x:1410,y:571,t:1527265202482};\\\", \\\"{x:1411,y:571,t:1527265202505};\\\", \\\"{x:1412,y:571,t:1527265202521};\\\", \\\"{x:1413,y:571,t:1527265204983};\\\", \\\"{x:1413,y:577,t:1527265204999};\\\", \\\"{x:1413,y:583,t:1527265205017};\\\", \\\"{x:1413,y:589,t:1527265205033};\\\", \\\"{x:1413,y:594,t:1527265205049};\\\", \\\"{x:1416,y:602,t:1527265205067};\\\", \\\"{x:1419,y:607,t:1527265205083};\\\", \\\"{x:1422,y:612,t:1527265205099};\\\", \\\"{x:1424,y:615,t:1527265205117};\\\", \\\"{x:1426,y:617,t:1527265205133};\\\", \\\"{x:1430,y:622,t:1527265205149};\\\", \\\"{x:1434,y:625,t:1527265205167};\\\", \\\"{x:1441,y:635,t:1527265205183};\\\", \\\"{x:1446,y:639,t:1527265205200};\\\", \\\"{x:1449,y:642,t:1527265205216};\\\", \\\"{x:1451,y:643,t:1527265205233};\\\", \\\"{x:1452,y:643,t:1527265205249};\\\", \\\"{x:1452,y:645,t:1527265205960};\\\", \\\"{x:1451,y:649,t:1527265205967};\\\", \\\"{x:1439,y:662,t:1527265205983};\\\", \\\"{x:1419,y:677,t:1527265206000};\\\", \\\"{x:1395,y:688,t:1527265206017};\\\", \\\"{x:1363,y:708,t:1527265206034};\\\", \\\"{x:1322,y:736,t:1527265206050};\\\", \\\"{x:1263,y:764,t:1527265206067};\\\", \\\"{x:1197,y:781,t:1527265206084};\\\", \\\"{x:1111,y:790,t:1527265206101};\\\", \\\"{x:1017,y:790,t:1527265206118};\\\", \\\"{x:895,y:790,t:1527265206134};\\\", \\\"{x:770,y:775,t:1527265206151};\\\", \\\"{x:580,y:743,t:1527265206167};\\\", \\\"{x:463,y:725,t:1527265206184};\\\", \\\"{x:358,y:697,t:1527265206201};\\\", \\\"{x:278,y:674,t:1527265206218};\\\", \\\"{x:232,y:659,t:1527265206235};\\\", \\\"{x:211,y:647,t:1527265206252};\\\", \\\"{x:209,y:645,t:1527265206271};\\\", \\\"{x:209,y:641,t:1527265206287};\\\", \\\"{x:214,y:633,t:1527265206305};\\\", \\\"{x:220,y:625,t:1527265206321};\\\", \\\"{x:231,y:617,t:1527265206337};\\\", \\\"{x:245,y:606,t:1527265206356};\\\", \\\"{x:264,y:594,t:1527265206372};\\\", \\\"{x:282,y:579,t:1527265206388};\\\", \\\"{x:297,y:569,t:1527265206406};\\\", \\\"{x:308,y:558,t:1527265206421};\\\", \\\"{x:314,y:552,t:1527265206438};\\\", \\\"{x:317,y:550,t:1527265206455};\\\", \\\"{x:318,y:552,t:1527265206504};\\\", \\\"{x:318,y:554,t:1527265206511};\\\", \\\"{x:320,y:557,t:1527265206522};\\\", \\\"{x:320,y:559,t:1527265206539};\\\", \\\"{x:320,y:562,t:1527265206555};\\\", \\\"{x:320,y:565,t:1527265206572};\\\", \\\"{x:314,y:569,t:1527265206589};\\\", \\\"{x:307,y:572,t:1527265206606};\\\", \\\"{x:294,y:577,t:1527265206622};\\\", \\\"{x:274,y:584,t:1527265206638};\\\", \\\"{x:263,y:593,t:1527265206655};\\\", \\\"{x:252,y:599,t:1527265206671};\\\", \\\"{x:248,y:599,t:1527265206688};\\\", \\\"{x:244,y:600,t:1527265206704};\\\", \\\"{x:234,y:602,t:1527265206722};\\\", \\\"{x:224,y:604,t:1527265206738};\\\", \\\"{x:218,y:601,t:1527265206755};\\\", \\\"{x:207,y:595,t:1527265206772};\\\", \\\"{x:199,y:592,t:1527265206789};\\\", \\\"{x:191,y:591,t:1527265206807};\\\", \\\"{x:188,y:589,t:1527265206822};\\\", \\\"{x:186,y:590,t:1527265206919};\\\", \\\"{x:186,y:593,t:1527265206927};\\\", \\\"{x:186,y:596,t:1527265206938};\\\", \\\"{x:186,y:604,t:1527265206955};\\\", \\\"{x:186,y:609,t:1527265206972};\\\", \\\"{x:186,y:616,t:1527265206989};\\\", \\\"{x:186,y:620,t:1527265207005};\\\", \\\"{x:186,y:624,t:1527265207021};\\\", \\\"{x:186,y:625,t:1527265207039};\\\", \\\"{x:186,y:627,t:1527265207056};\\\", \\\"{x:185,y:627,t:1527265207120};\\\", \\\"{x:185,y:629,t:1527265207152};\\\", \\\"{x:188,y:630,t:1527265207167};\\\", \\\"{x:194,y:630,t:1527265207176};\\\", \\\"{x:203,y:631,t:1527265207189};\\\", \\\"{x:227,y:632,t:1527265207206};\\\", \\\"{x:257,y:632,t:1527265207222};\\\", \\\"{x:297,y:621,t:1527265207239};\\\", \\\"{x:374,y:604,t:1527265207256};\\\", \\\"{x:429,y:589,t:1527265207271};\\\", \\\"{x:483,y:578,t:1527265207289};\\\", \\\"{x:542,y:570,t:1527265207306};\\\", \\\"{x:604,y:566,t:1527265207323};\\\", \\\"{x:647,y:566,t:1527265207339};\\\", \\\"{x:680,y:566,t:1527265207355};\\\", \\\"{x:711,y:566,t:1527265207372};\\\", \\\"{x:745,y:566,t:1527265207390};\\\", \\\"{x:785,y:566,t:1527265207406};\\\", \\\"{x:825,y:564,t:1527265207422};\\\", \\\"{x:868,y:557,t:1527265207439};\\\", \\\"{x:914,y:544,t:1527265207456};\\\", \\\"{x:934,y:540,t:1527265207472};\\\", \\\"{x:947,y:536,t:1527265207489};\\\", \\\"{x:956,y:533,t:1527265207505};\\\", \\\"{x:961,y:530,t:1527265207523};\\\", \\\"{x:965,y:526,t:1527265207539};\\\", \\\"{x:968,y:522,t:1527265207556};\\\", \\\"{x:968,y:520,t:1527265207573};\\\", \\\"{x:967,y:518,t:1527265207591};\\\", \\\"{x:965,y:516,t:1527265207606};\\\", \\\"{x:951,y:510,t:1527265207623};\\\", \\\"{x:920,y:503,t:1527265207640};\\\", \\\"{x:902,y:503,t:1527265207655};\\\", \\\"{x:885,y:508,t:1527265207671};\\\", \\\"{x:870,y:511,t:1527265207688};\\\", \\\"{x:853,y:514,t:1527265207706};\\\", \\\"{x:836,y:517,t:1527265207722};\\\", \\\"{x:821,y:518,t:1527265207739};\\\", \\\"{x:814,y:519,t:1527265207756};\\\", \\\"{x:812,y:520,t:1527265207773};\\\", \\\"{x:814,y:520,t:1527265207928};\\\", \\\"{x:814,y:520,t:1527265207985};\\\", \\\"{x:815,y:521,t:1527265208079};\\\", \\\"{x:813,y:526,t:1527265208090};\\\", \\\"{x:802,y:544,t:1527265208107};\\\", \\\"{x:784,y:568,t:1527265208123};\\\", \\\"{x:748,y:611,t:1527265208140};\\\", \\\"{x:714,y:646,t:1527265208156};\\\", \\\"{x:686,y:675,t:1527265208173};\\\", \\\"{x:670,y:687,t:1527265208190};\\\", \\\"{x:664,y:690,t:1527265208205};\\\", \\\"{x:666,y:689,t:1527265208264};\\\", \\\"{x:672,y:683,t:1527265208273};\\\", \\\"{x:694,y:664,t:1527265208290};\\\", \\\"{x:733,y:630,t:1527265208307};\\\", \\\"{x:774,y:593,t:1527265208323};\\\", \\\"{x:810,y:563,t:1527265208342};\\\", \\\"{x:833,y:544,t:1527265208357};\\\", \\\"{x:851,y:529,t:1527265208373};\\\", \\\"{x:868,y:517,t:1527265208389};\\\", \\\"{x:885,y:502,t:1527265208407};\\\", \\\"{x:888,y:500,t:1527265208423};\\\", \\\"{x:888,y:499,t:1527265208440};\\\", \\\"{x:887,y:497,t:1527265208487};\\\", \\\"{x:887,y:496,t:1527265208495};\\\", \\\"{x:884,y:496,t:1527265208506};\\\", \\\"{x:879,y:495,t:1527265208522};\\\", \\\"{x:874,y:493,t:1527265208540};\\\", \\\"{x:868,y:493,t:1527265208555};\\\", \\\"{x:860,y:493,t:1527265208573};\\\", \\\"{x:852,y:495,t:1527265208590};\\\", \\\"{x:844,y:498,t:1527265208606};\\\", \\\"{x:837,y:502,t:1527265208623};\\\", \\\"{x:826,y:507,t:1527265208640};\\\", \\\"{x:823,y:507,t:1527265208657};\\\", \\\"{x:822,y:508,t:1527265208673};\\\", \\\"{x:821,y:509,t:1527265208690};\\\", \\\"{x:821,y:510,t:1527265208920};\\\", \\\"{x:822,y:510,t:1527265208927};\\\", \\\"{x:826,y:514,t:1527265208940};\\\", \\\"{x:832,y:527,t:1527265208957};\\\", \\\"{x:833,y:545,t:1527265208975};\\\", \\\"{x:833,y:561,t:1527265208991};\\\", \\\"{x:822,y:589,t:1527265209008};\\\", \\\"{x:788,y:639,t:1527265209023};\\\", \\\"{x:766,y:668,t:1527265209040};\\\", \\\"{x:748,y:684,t:1527265209056};\\\", \\\"{x:737,y:692,t:1527265209073};\\\", \\\"{x:733,y:694,t:1527265209090};\\\", \\\"{x:732,y:692,t:1527265209135};\\\", \\\"{x:734,y:685,t:1527265209143};\\\", \\\"{x:740,y:676,t:1527265209157};\\\", \\\"{x:760,y:647,t:1527265209174};\\\", \\\"{x:791,y:609,t:1527265209190};\\\", \\\"{x:830,y:571,t:1527265209207};\\\", \\\"{x:872,y:532,t:1527265209224};\\\", \\\"{x:880,y:522,t:1527265209240};\\\", \\\"{x:882,y:517,t:1527265209257};\\\", \\\"{x:882,y:516,t:1527265209274};\\\", \\\"{x:882,y:514,t:1527265209291};\\\", \\\"{x:878,y:513,t:1527265209307};\\\", \\\"{x:872,y:513,t:1527265209324};\\\", \\\"{x:863,y:516,t:1527265209342};\\\", \\\"{x:857,y:519,t:1527265209357};\\\", \\\"{x:850,y:521,t:1527265209374};\\\", \\\"{x:848,y:522,t:1527265209391};\\\", \\\"{x:846,y:523,t:1527265209407};\\\", \\\"{x:845,y:523,t:1527265209424};\\\", \\\"{x:844,y:523,t:1527265209679};\\\", \\\"{x:840,y:526,t:1527265209691};\\\", \\\"{x:831,y:548,t:1527265209708};\\\", \\\"{x:810,y:583,t:1527265209725};\\\", \\\"{x:777,y:638,t:1527265209742};\\\", \\\"{x:731,y:715,t:1527265209759};\\\", \\\"{x:684,y:777,t:1527265209774};\\\", \\\"{x:636,y:819,t:1527265209791};\\\", \\\"{x:608,y:837,t:1527265209807};\\\", \\\"{x:585,y:844,t:1527265209824};\\\", \\\"{x:579,y:844,t:1527265209841};\\\", \\\"{x:574,y:844,t:1527265209857};\\\", \\\"{x:569,y:843,t:1527265209874};\\\", \\\"{x:561,y:837,t:1527265209891};\\\", \\\"{x:548,y:832,t:1527265209907};\\\", \\\"{x:532,y:826,t:1527265209924};\\\", \\\"{x:521,y:818,t:1527265209940};\\\", \\\"{x:513,y:810,t:1527265209957};\\\", \\\"{x:509,y:800,t:1527265209974};\\\", \\\"{x:508,y:788,t:1527265209990};\\\", \\\"{x:508,y:777,t:1527265210007};\\\", \\\"{x:511,y:755,t:1527265210024};\\\", \\\"{x:513,y:746,t:1527265210040};\\\", \\\"{x:516,y:741,t:1527265210058};\\\", \\\"{x:516,y:738,t:1527265210074};\\\", \\\"{x:517,y:737,t:1527265210319};\\\", \\\"{x:518,y:737,t:1527265210327};\\\", \\\"{x:519,y:737,t:1527265210359};\\\", \\\"{x:520,y:738,t:1527265210375};\\\" ] }, { \\\"rt\\\": 53121, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 849580, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"I look at the points on the 12 pm y axis and then look at other points to see if events ending later could possibly start at 12 pm by subtracting hours\\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6479, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 857066, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8916, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Math or Computer Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 867005, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 2867, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 871212, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"MW3RC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"lima\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"MW3RC\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 300, dom: 843, initialDom: 1466",
  "javascriptErrors": []
}